## 专精概览

Welcome to our Shadow Priest guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Shadow Priest in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Shadow Mythic+ Resources

[NEW! Top Shadow Talent Builds](<https://raider.io/specs/shadow-priest/talents>)

[Top Shadow Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/priest/shadow>)

[Shadow Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=priest--shadow>)

[Popular Shadow Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=priest--shadow>)

1.

### Shadow Priest Overview

In Midnight, Shadow Priest continues on the builder-spender
design while also having some interesting damage over time and AoE mechanics.
You gain access to two different Hero Talents that change your core
playstyle significantly: ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon focuses on sustained damage through 
cooldown windows with [[spell:228260]] and [[spell:120644]], while 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver focuses on
burst damage through building up [[spell:447444]] with
[[spell:450405]] casts. Both Hero Talents are strong in their own right
and have their own strengths and weaknesses depending on the encounter.

[观看原文视频](<https://www.youtube.com/embed/2OS9e2aMAlw>)

Strong Sustained Damage with Better Spread Pressure

Shadow Priest is now a strong sustained damage spec in Midnight Season 2, centered
on DoT uptime and well-timed cooldown windows. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon
provides extended, predictable windows for high sustained throughput, while
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver enables some burst and cleave when building up
[[spell:447444]].

Proper talent choices shift you between
reliable long fights and stronger spread-cleave scenarios.

Great Raid Choice

In Midnight raiding, Shadow shines on encounters with long steady phases where
DoTs and coordinated cooldown alignment matter. Fights that permit sustained
[[spell:228260]] windows or uninterrupted DoT uptime favor Shadow heavily.

On very fast clearing, burst heavy encounters Shadow falls closer to the middle of the
damage charts, but it remains a safe, flexible choice for progression, particularly
in spread cleave environments.

Strong Mythic+ Choice with Good Spread Damage

Shadow is a strong option in Midnight Mythic+. It delivers excellent single-target
and improved spread-target damage when you can maintain DoTs.

High-mobility keys and heavy add packs can still punish Shadow's limited movement.
Your value often comes from utility: [[spell:10060]], [[spell:15487]], and controlled
sustain via [[spell:15286]], so coordination and pull planning are critical.

High Utility

Shadow's utility is a major reason to bring the spec in Midnight. Reliable
cooldown support like [[spell:10060]], crowd control via
[[spell:15487]]/[[spell:9484]], and group sustain from
[[spell:15286]] make Shadow valuable beyond raw damage.

These tools
keep Shadow relevant in both raid and dungeon settings even when tuning dips.

Durable

Survivability is strong in Midnight, thanks to built-in sustain and defensive
options. Lifesteal from [[spell:335467]], passive healing nodes, and
[[spell:47585]] provide reliable personal survivability.

Talents that boost
instant heals and damage mitigation complement proactive play; used well,
Shadow can comfortably survive most raid mechanics and emergency Mythic+ bursts.

Limited Mobility

Mobility is Shadow's weakest area in Midnight. The spec lacks a built-in gap
closer or displacement, so high-movement fights and Mythic+ mechanics can be
punishing. You can mitigate this with [[spell:64129]], talent choices, and
external movement tools, but the core limitation remains, plan positioning and
use cooldown windows to minimize movement penalties.

2.

### Shadow Priest in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

There are no changes to mention to Shadow Priest in this patch. This
patch does offer 2 new endgame content, one new Raid and new 
[Delves](<https://www.icy-veins.com/wow/delves-guide>) content. Make sure to check out both the information on the 
new Kith'ix Raid encounter, as well as the new exciting Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) continues Season 2 progression in Midnight with the new Unbinding of
Kith'ix raid and Labyrinth of Kindo'jan Mega-Delve, alongside catch-up gear and access to
ascended item levels. The Kith'ix raid also adds new gear, including a trinket, ring, and
legs. Starting October 20, [[item:280562]] can be used to upgrade weapons,
necks, and trinkets. Visit our patch hub for a full breakdown of what's new in Patch 12.1.5.

2.3.

#### Class Changes

Unfortunately there have been no changes to Shadow Priest with Patch 12.1.5 itself.
Our Talents, Rotation, Gear, and Enchants guides have been updated for the patch. You can
click the dropdown below to see the list of Shadow Priest changes from the previous 12.1 Patch.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_deathmark.jpg>) Click for Previous Season 2 Changes
[Curse of Ula'tek Patch Notes](<https://us.forums.blizzard.com/en/wow/t/2317811/1>)

**Shadow Priest**

<em>Developers' notes: For Shadow in Curses of Ula'tek, we're intending to improve [[spell:228260]] 
    gameplay and are adding an additional source of multi-target damage to reduce the spec's reliance on 
    [[spell:199484]] in AoE situations. For Voidform, we're updating [[spell:1240401]] to be a limited 
    use ability that can be used a set number of times during Voidform which leaves more room in the 
    rotation while giving you the chance to use it at its most opportune moment. We've also updated 
    Voidform support talents to have more noticeable effects to align with our goals.</em>

- New Talent: [[spell:1231479]] - [[spell:341491]] that float towards your primary 
      target explode, dealing Shadow damage to all enemies within 8 yards. Damage reduced beyond 5 targets.
- [[spell:341240]] has been redesigned - [[spell:228260]] increases your spell damage by an 
      additional 5% and grants 2 additional uses of [[spell:1240401]].
- [[spell:341240]] has been redesigned - [[spell:335467]] increases your Haste during 
      [[spell:228260]] by 2% and increases its duration by 1.5 seconds, stacking up to 5 times. When Voidform 
      ends, the Haste lingers and decays over 10 seconds.
- [[spell:228260]] now grants 3 uses of [[spell:1240401]] instead of Void Volley having a cooldown 
      during Voidform.
- [[spell:17]] absorb increased by 25%.
- Phantom Menace has been removed.
- Hero Talents
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon
    
    - [[spell:1272320]] has been redesigned - [[spell:1240401]] deals 15% increased damage and 
                  [[spell:335467]] casts during [[spell:228260]] unleash a [[spell:1240401]] at your target.
    - [[spell:453845]] has been slightly redesigned - Creating a [[spell:120644]] increases your 
                  spell damage by 2% for 10 seconds, stacking up to 4 times.

:::

### Midnight   Changes Overview

2.4.

#### Midnight Summary for Shadow Priest

[观看原文视频](<https://www.youtube.com/embed/c_fDQWyqhwM>)

2.5.

#### Apex Talents

Once you start leveling in Midnight you will start getting access to the new 
Apex Talents in the spec tree. These points exist separately on the Spec Tree and you can
commit up to 4 points into them.

You must put these points in sequentially and the biggest value node is the final point.

- [[spell:1264096]]
- [[spell:1264104]] (2-points)
- [[spell:1264107]]

These talents do more than simply cap the tree with extra power, they actively reshape 
how we approach the rest of our build. While their baseline functionality may be straightforward, 
their downstream impact is where the real gameplay shift occurs.

One of the most noticeable effects is how strongly they incentivize investing in talents that 
enhance [[spell:341491]]. Due to this synergy we are strongly encouraged to
build around maximizing our [[spell:341491]] generation and damage, which in turn 
encourages us to take more talents that support this playstyle.

With the full power of all Apex talents you are also introduced to the new gameplay loop
with encouraging Idol spawns to proc more [[spell:341491]]. This becomes one of the
core gameplay loops of the spec in Midnight, where you want to generate as many Idol procs as 
possible to spawn more [[spell:341491]].

2.6.

#### Summary of Changes

Due to the size of the changes I have broken it up into sections to
make it easier to digest how Shadow Priest is different this patch. Note that in
addition to these changes there were also many changes to overall tuning of
spells in our kit.

- We had several changes to our core **Shadow Priest** spells.  
  
  
  
  - Dark Ascension has been removed and [[spell:228260]] is now our main 
                cooldown spell. Instead of granting access to Void Bolt it now gives you access to 
                [[spell:1240401]] with a 15 second cooldown reduced by Haste. This does not 
                refresh our DoTs.
  - [[spell:34433]], [[spell:200174]], and [[spell:451234]] are all 
                passive spells.
  - [[spell:1279355]] is a new talent that gives us sustained DoT extension in AoE.
  - Devouring Plague has been renamed to [[spell:335467]].
  - Shadow Crash has been reworked into [[spell:1227280]].
  - [[spell:1279350]] is a new choice-node against [[spell:238558]] that brings
                back DoT management gameplay for a large payoff in low target count situations.
  - [[spell:375888]] now grants a temporary charge of [[spell:8092]]
                instead of just resetting a charge.
  - [[spell:341491]] are no longer triggered by [[spell:8092]].
- Our **Hero Talents** have had several baseline updates.  
  
  
  
  2.7. 
  
  ### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon
  
  
  
  
  - [[spell:120644]] is now exclusive to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon.
  - [[spell:391399]] procs are now exclusive to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon 
                and only proc from [[spell:120644]].
  - [[spell:453844]] has been removed.
  - New Talent: [[spell:1247178]] - Increases the damage of [[spell:341491]].
  - New Talent: [[spell:1272308]] - [[spell:453109]] lasts an additional 5 seconds (effectively grants one extra [[spell:120644]]).
  - New Talent: [[spell:1272326]] - [[spell:32379]] damage increased its cooldown is reduced.
  - New Talent: [[spell:1272320]] - [[spell:1240401]] damage increased and its cooldown is reduced.
  - [[spell:453917]] now increases damage during [[spell:228260]] by 5% (was 20%).
  
  
    
  
  
  
  2.8. 
  
  ### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver
  
  
  
  
  - [[spell:263165]] is now exclusive to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver.
  - New Talent: [[spell:1266883]] - [[spell:263165]] deals increased damage.
  - New Talent: [[spell:1266845]] - [[spell:589]] and [[spell:447444]] deal damage more often.
  - New Talent: [[spell:1266856]] - [[spell:449880]] now persists for a short duration after [[spell:447444]] ends.
  - Depth of Shadows is now [[spell:34433]] as a spec tree talent. This means we always get [[spell:451234]] in its new passive version.
  - [[spell:450138]] now grants a charge of [[spell:375888]] instead of [[spell:373202]].
- Mostly unchanged, we had some small updates to our **Utility Spells**.  
  
  
  
  - [[spell:15487]], [[spell:47585]], and [[spell:15286]] are all baseline spells for Shadow Priests.
  - [[spell:1250691]] - Instead of being its own active ability it now roots enemies when [[spell:8122]] debuff ends.
  - Shackle Undead is now [[spell:9484]] and can additionally be used against Aberrations.
- Here are a few other changes that are notable for Shadow Priest.  
  
  
  
  - [[spell:8092]] is now in the class tree and [[spell:32379]]
                is no longer granted by default. [[spell:34433]] was also removed by
                default and instead added to the spec tree as a proc.
  - [[spell:8122]], [[spell:19236]], and [[spell:586]] have been moved into the
                Class Tree (were baseline).
  - Void Shift has been removed.
  - [[spell:321291]] is now a choice node in the spec tree against [[spell:392507]].
  - Psychic Horror has been removed.

3.

### Basics of Shadow Priest Gameplay

Shadow Priest gameplay combines the basic builder-spender idea used
in other specs while twisting in being an active DoT class with lots of
cooldowns to use. The basics of the rotation involve getting as much uptime as
possible on your cooldowns while making sure to keep up all three of your DoTs on as
many active targets as possible, especially [[spell:335467]].

Shadow Priest can be broken down into the following three tenants to help better understand 
the backbone of the specialization.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) **Manage your Insanity**  
  
    Shadow's resource is Insanity, which is spent on
    [[spell:335467]]. It builds up as you deal damage with your spell,
    and has a cap of 100, so avoid waste.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_unholyfrenzy.jpg>) **Cast Cooldowns**  
   
    Shadow has many spells that can be available to press at any given time.
    To get started your goal is to make sure nothing is sitting off cooldown unnecessarily. 
    This primarily includes spells like [[spell:8092]] and [[spell:1227280]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_shadowwordpain.jpg>) **Keep Debuffs Active**  
  
    As a Shadow Priest you gain damage on all your spells when you have your damage over 
    time effects (DoTs) active. Keep [[spell:589]] and [[spell:34914]] 
    up on your targets at all times.

4.

### How to Gear Up as a Shadow Priest

While we always recommend simming yourself for ideal results, we do provide a
dedicated Shadow gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Voidweaver Raid builds.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **01 Sep. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Default combat potion update and caveat.
- **01 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add Ula'tek variation on the raid build.
- **25 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add high-key build variant for Voidweaver.
- **25 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add 3-target build for The Lost Explorers in the Raid sections.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update crafted suggestions after Hunter Ritual Stone nerf.
- **17 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update single-target breakdown by talent build.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket rankings to reflect upcoming tuning.
- **11 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add more direct advice to crafting and bonus rolls.
- **11 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Simplify Ring enchant notes.
- **11 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add clarity to a few sections that changed in Season 2.
- **11 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add no-tier variants for all builds.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Update for Season 2 and Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update for Season 2 and Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update gear lists with more information on Catalyst Sources and Bonus Roll guidance.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Updated for Season 2 and Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Updated for Season 2 and Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Update for Season 2 and Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update for Season 2 and Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add back Haunting Shadows in the Archon Mythic+ build.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update for Season 2 and Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Rotation updates around Void Volley and Shadow Word: Madness usage.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update for Season 2 and Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add back Haunting Shadows in the Archon Mythic+ build.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Update for Season 2 and Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated for Season 2 and Patch 12.1.
- **10 Aug. 2026 (this page):** Update for Season 2 and Patch 12.1.
- **03 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Combine Archon and Voidweaver trinket rankings into one tier list and cap Darkmoon trinkets at C-tier.
- **03 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update rotation switches and dungeon utility tips for Season 2 utility grid.
- **22 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket tooltips to have proper item levels.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed for 12.0.7 with specific Y'Shaarj build for Voidweaver.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7 with Omnium Folio information.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Update for 12.0.7.
- **19 May 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add note about neck choices.
- **19 May 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add note about Idol of Y'Shaarj for Voidweaver build.
- **19 May 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Voidweaver 3 target build.
- **22 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update ring enchant after recent buffs.
- **22 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add Phantasm for Deathspeaker Voidweaver build variant.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add new section for Ascendant and Nebulous Voidcores.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.5 with corrected stat DR thresholds.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Update for 12.0.5.
- **10 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Voidweaver Raid builds.
- **09 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add a fully dedicated log review section with workflow, checklists, and troubleshooting guidance.
- **09 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Remove Distorted Reality for 3 targe builds, simplify Voidweaver 3T setup.
- **09 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add back dedicated 3 target builds for clarity.
- **08 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Remove Mind's Eye from Archon Raid build.
- **06 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add a dropdown with additional Shadow Priest simulation resources.
- **06 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add FAQ guidance on sim profile selection and interpreting small stat deltas.
- **06 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Mythic+ execution checklist and a practical log review section.
- **06 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add movement handling, log review checklist, and validation FAQ guidance.
- **06 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add FAQ guidance for sim and log-driven talent adjustments.
- **06 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Add a How to Improve Fast fieldset with core execution tips.
- **06 Apr. 2026 (this page):** Add a quick improvement dropdown and additional resources fieldset.
- **04 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update Mythic+ Builds.
- **04 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update talent defaults for several builds.
- **04 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Archon Raid and Mythic+ Builds and Voidweaver Mythic+ Build.
- **04 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update talent builds after recent hotfixes.
- **02 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add Shadow Word Death build variant for Voidweaver Raid.
- **01 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Swap out embellishments to not use the Arcanoweave Set.
- **01 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add caveat for Voidtouched.
- **29 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Adjust trinket rankings after weeky 1 of the season.
- **29 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Suggest Archon for high key dungeons and add note about getting even more AoE damage.
- **29 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Increase priority of Shadow Word: Death and add more notes about Distorted Reality.
- **29 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update 3 Target Talent build for Raiding.
- **29 Mar. 2026 (this page):** Update guide for upcoming class tuning on March 31st.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Remove mention of Tea consumables and add alternative enchants.
- **22 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Adjust ranking of Vessel of Tortured Souls.
- **22 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update Power Infusion Suggestions and add note on Tentacle Slam and adjust note on Halo.
- **22 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add 3 Target build for Raiding.
- **18 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update talent builds.
- **18 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Mythic+ and Delve talent builds.
- **18 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update AoE build.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated for the launch of Midnight season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update for the launch of Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Swap in mention of Royal Roast personal food.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated for Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Added more detail on spending Tentacle Slam charges.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Builds reviewed for launch of Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated rotation section for Season 1.
- **16 Mar. 2026 (this page):** Updated for the Launch of Midnight Season 1.
- **06 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket rankings.
- **06 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Add in Void Torrent + Halo macro.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Add import strings for starting to level at 80.
- **02 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update crafting suggestions ready for Season 1 launch.
- **02 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Correct food consumable and add in mention of teas.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** New leveling builds for Midnight launch to level 90.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated page for Midnight Pre-Season.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Adjust trinket rankings to account for Mythic dungeon item levels.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Update style to allow for easily copying of macros.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Added new consumables and enchants for Midnight launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Updated for stat ranges at level 90.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Added a dedicated section on the Apex talents.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated with new builds for the launch of the Midnight expansion.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Added a dedicated section for the Apex Talents.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated Talent builds for Midnight launch.
- **26 Feb. 2026 (this page):** Updated for the launch of the Midnight expansion.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated Talent Trees for changes to class point gating.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Increase ranking of Screams of the Forgotten Sky trinket.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Swap from Shackle Undead to Shackle Horror.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated Talent Trees for changes to class point gating.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Remove mention of Maddening Slam interaction and place Tentacle Slam earlier in the opener after bug fixes.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated Talent Trees for changes to class point gating.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Swap from Shackle Undead to Shackle Horror.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated Talent Trees for changes to class point gating.
- **10 Feb. 2026 (this page):** Updated Talent Trees for changes to class point gating.
- **23 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Added more FAQ entries for Pre-Patch.
- **23 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Added more FAQ entries for Pre-Patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 (this page):** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **21 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Further clarity and detail to the Puzzling Cartel Chips section.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Added Dinar section and adjusted trinket rankings from the Turbo Boost item level.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **29 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Update Power Infusion macros to use Trinkets before casting Power Infusion.
- **29 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add note about using Mind Blasts in the Archon opener.
- **29 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed after the launch of Season 3.
- **26 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add video guide for talents and add Phantasm to Streets.
- **26 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add video guide.
- **18 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Small adjustments to trinket tier rankings.
- **18 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add a few more dungeon tips after week 1.
- **11 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Update all in one Shadow Crash macro.
- **07 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update Voidweaver builds after Deathspeaker bug was fixed.
- **07 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add note about Void Torrent cancel and update default Voidweaver talents.
- **07 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Voidweaver builds after Deathspeaker bug was fixed.
- **07 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update Voidweaver builds after Deathspeaker bug was fixed.
- **07 Aug. 2025 (this page):** Update Voidweaver builds after Deathspeaker bug was fixed.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Update for Patch 11.2.0.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update for Patch 11.2.0.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Update for Patch 11.2.0 with a new macro.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update for Patch 11.2.0.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Update for Patch 11.2.0.
- **04 Aug. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Talents updated to suggest Archon.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update for Patch 11.2.0.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update for Patch 11.2.0.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update for Patch 11.2.0.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Update for Patch 11.2.0.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update for Patch 11.2.0.
- **04 Aug. 2025 (this page):** Update for Patch 11.2.0.
- **22 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Adjust D.I.S.C. belt powers for upcoming hotfixes.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Review information for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add information on the Durable Information Securing Container Waist item.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Review information for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Review information for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Review information for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Review information for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Review information for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add information about the Combat Assistant.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Review information for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Review information for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Add information about the Combat Assistant.
- **15 Jun. 2025 (this page):** Update for Patch 11.1.7.
- **28 May 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Add Mythic Gallywix Video.
- **25 May 2025 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed information after recent hotfixes to still be accurate.
- **25 May 2025 (this page):** Update from end of May hotfixes.
- **20 May 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Add Mythic Stix PoV.
- **19 May 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update corruption rankings and add video guide.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add note about purchasing Signet of the Priory.
- **09 May 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Add more tips for the last few Mythic bosses.
- **08 May 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Cyrce's Circlet is no longer Best in Slot.
- **05 May 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update Cartel Chips section.
- **05 May 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update Corruption section with more up-to-date info.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Add note about the new Cooldown Manager for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5 with a new Corruption section.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Update for Patch 11.1.5.
- **06 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Update videos for Rik and Sprocketmonger and add a few new tips for Mythic bosses.
- **02 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Update Archon Talent Builds.
- **02 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update default talent loadout for Archon Raid builds.
- **02 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Archon Single Target builds to remove Yogg-Saron.
- **28 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket rankings after recent hotfixes.
- **28 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add Other Consumables section.
- **19 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Remove mention of Amorphous Relic after the bug fix.
- **19 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Update videos for Mythic Vexie and Mythic Cauldron of Carnage.
- **19 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add video link for the Rookery.
- **19 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Remove use of Shadow Crash in pure single target when you have Unfurling Darkness talented.
- **14 Mar. 2025 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Adjustments to stat goals for Season 2 after more testing.
- **13 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket rankings and add more info to various sections.
- **13 Mar. 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Remove Mind Flay: Insanity macros that are no longer useful.
- **13 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Update note about standing in the middle for Cauldron of Carnage.
- **13 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Remove Unfurling Darkness from the Voidweaver AoE build.
- **12 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Add more tips and update videos for the encounters.
- **10 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add more dungeon tips with video and weak aura links.
- **09 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add dungeon tips after week 1.
- **09 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Remove confusing mention of targets dying in DP AoE section.
- **05 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add note about when to swap to the Season 2 Tier.
- **05 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Adjust some boss tips after day 1 of the raid releasing.
- **03 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add info on using Hyperthread Wristwraps.
- **03 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Swapped to Voidweaver for Vexie and fixed issue with conflicting ST + Crash Archon builds.
- **03 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add section on Hyperthread Wristwraps.
- **01 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update Cyrce's Circlet gems for Season 2.
- **01 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Mind Flay Voidweaver build and a few more dungeon tips.
- **01 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add new Power Infusion targets for Season 2.
- **28 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Remove Void Bolt's ability to be cast while channeling other spells.
- **28 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Remove Unfurling Darkness from the Voidweaver Single Target build.
- **28 Feb. 2025 (this page):** Remove Void Bolt's ability to be cast while channeling other spells.
- **26 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket rankings for Season 2.
- **26 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Update stat goals for Mythic+ in Season 2.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Update talent build for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update page for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Update stat goals for Patch 11.1.0.
- **24 Feb. 2025 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Updated talent strings to work with Patch 11.1.0.
- **24 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated builds for Season 2 with new tips for each dungeon.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update rotation for Season 2. Removed higher priority on Shadow Word: Death and Mind Blast actions with Inescapable Torment, use Void Bolt while channeling spells, and add new trinkets.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Added new talent builds for 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated for 11.1.0 with new talent builds.
- **24 Feb. 2025 (this page):** Updated for 11.1.0.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update Cyrce's Circlet tooltips and give alternative wind gem.
- **16 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update Cyrce's Circlet gems after recent buffs.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add new Cyrce's Circlet Ring for 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update Cyrce's Circlet suggestions after initially posting.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Add a few video PoVs for certain bosses.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Recommend starting with Triple Idol.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Suggest starting out with Archon builds for most content.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Simplify the rotation section.
- **15 Dec. 2024 (this page):** Add note about 11.0.7 content updates.
- **16 Nov. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Update all in one dispel macro and stopmacro channeling to be more concise.
- **04 Nov. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Update Halo priority for Archon rotation.
- **04 Nov. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add caveat for overall BiS list weapons.
- **04 Nov. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed from recent hotfixes.
- **04 Nov. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Clarify usage of weapon enchants.
- **04 Nov. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for recent hotfixes.
- **04 Nov. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Add extra information for Sikran.
- **04 Nov. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed for recent hotfixes.
- **04 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update Power Infusion target suggestions.
- **04 Nov. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Minds Eye vs. Distorted Reality section to be more clear.
- **04 Nov. 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed from recent hotfixes.
- **04 Nov. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Add easy to copy talent strings and updated Halo's position in the rotation section.
- **04 Nov. 2024 (this page):** November review.
- **27 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Remove Burst of Knowledge.
- **22 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Adjust Archon opener to use Halo pre-pull.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for 11.0.5 with more tips and extra information for many fights in Mythic difficulty.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Swapped to using Sustained Potency by default for the pause mechanic out of combat for Archon builds.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Swapped to using Sustained Potency by default for the pause mechanic out of combat for Archon builds.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **17 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Fix Mythic+ gear set bug with rings.
- **15 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Remove Phantasm from City of Threads.
- **14 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Update stat suggestions after more testing to be more precise.
- **11 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Removed Voidwraith for Voidweaver leveling.
- **10 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Update Voidweaver builds to use Mental Decay and Inescapable Torment in some cases.
- **10 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update Voidweaver builds.
- **10 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update Spymaster's Web usage.
- **10 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add Voidweaver Raid Cleave talent selector.
- **10 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Use Mental Decay for Voidweaver builds and use Inescapable Torment for ST + Crash variant. UFD is now optional for Mythic+.
- **09 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Swap out Voidwraith for Depth of Shadows for Voidweaver builds.
- **09 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update Single Target + Shadow Crash Voidweaver build.
- **09 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update default talents for the Voidweaver Single Target build.
- **09 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Swap out Voidwraith for Depth of Shadows for Voidweaver Raid builds.
- **07 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Update default build suggestions to include more Voidweaver and add more Voidweaver tips.
- **07 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update build suggestions after recent hotfixes.
- **07 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update default talents for Voidweaver.
- **07 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update talent builds from recent hotfixes.
- **06 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update rotation for recent hotfixes.
- **06 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update Voidweaver AoE build to default with Depth of Shadows.
- **06 Oct. 2024 (this page):** Updated from recent hotfixes.
- **04 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Update Dungeon Stat suggestions to index for higher key levels.
- **04 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Remove redundant Shadow Word: Death entry when using Depth of Shadows.
- **01 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Adjust gear setups to include more one handed weapons.
- **01 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add tip for Mistcaller about using Dodge Ball to kill the adds.
- **30 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket rankings and add a few extra gear options for BiS lists from dungeons.
- **25 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Give the Hybrid build its own section.
- **22 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Add Queen Ansurek Guide.
- **19 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add Candle Confidant.
- **18 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Updated for Patch 11.0.5, removed older macros and added new WeakAuras.
- **18 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Start week 2 updates.
- **17 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Change fateweaved weapon mention.
- **17 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Update tips after week 1.
- **17 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add section on Idol of Yogg-Saron.
- **16 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket rankings and mention Fateweaved Needle weapon.
- **16 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add in specific stat suggestions for Archon and Voidweaver.
- **16 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update talent sections to be more readable.
- **16 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Fix a few issues with Devouring Plague priority in the rotation sections, particularly with Voidweaver AoE.
- **16 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add new rotational sections to provide more detail on cooldown usage.
- **15 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Refactor talent build section to be easier to use.
- **13 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update default Delve build to use Archon.
- **12 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Remove Pre-Season BiS list.
- **10 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Swap to full single target build for Ulgrax.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Increase Mad Queen's Mandate on Raid tier list.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add note about Hearty Food.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add variant to Archon M+ build to get more single target.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add Mind Blast section to rotational notes.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add variant to Archon M+ build to get more single target.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Updated for The War Within Season 1.
- **06 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Adjust guidance on Epic Gem to include Elusive Blasphemite.
- **05 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Fix opener sequences for Voidweaver builds and Archon AoE.
- **04 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add AoE Weapon enchant option.
- **01 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Remove Binding of Binding from crafting gear suggestions.
- **01 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add note about Ring Enchants.
- **31 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update crafted gear suggestions for Season 1.
- **31 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update Single Target + Shadow Crash build for Voidweaver and condense Archon into a single build.
- **31 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Voidweaver Single Target + Shadow Crash build, add Unfurling Darkness to Delve builds, and consolidate Archon AoE into one build.
- **29 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add note about pre-season enchants.
- **25 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add Delve build and Pre-Season Archon Dungeon variants and adjust percent difference for Archon vs. Voidweaver.
- **23 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add Archon High Key M+ build selector
- **22 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated page for the launch of The War Within.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated for the launch of The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated for the launch of The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Add new WeakAura links.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update enchants and consumables for the launch of The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Updated for the launch of The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation for the launch of The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated talent builds for the launch The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Added entries for Hero Talents.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated builds and rotation for the launch of The War Within.
- **21 Aug. 2024 (this page):** Updated for the launch of The War Within.
- **13 Aug. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** Update talent builds to start using Idol of C'Thun again and adjust for Class Tree changes.
- **13 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update talent builds to start using Idol of C'Thun again and adjust for Class Tree changes.
- **13 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update talent builds to start using Idol of C'Thun again and adjust for Class Tree changes.
- **13 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update talent builds to start using Idol of C'Thun again and adjust for Class Tree changes.
- **25 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update talent builds to not use Idol of C'Thun while it is still bugged.
- **25 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update talent builds to not use Idol of C'Thun while it is still bugged.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **07 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/shadow-priest-the-war-within-pve-guide>)):** Update from the rename of Void Crash.
- **01 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/shadow-priest-the-war-within-pve-guide>)):** Update videos.
- **17 Jun. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** Correct end-game Mastery value to respect cap of 67%.
- **16 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/shadow-priest-the-war-within-pve-guide>)):** Page added.
- **27 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** Update Tinker gem rankings and add goals for secondary stats. Change default build for Shadow Crash in raid.
- **20 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** Update Tinker gem rankings after recent hotfixes.
- **18 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** Update Tinker gem rankings with more options and rank the various Meta gems.
- **17 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** Update initial Tinker Gem rankings and adjust build path for Dungeon Build to prioritize Shadow Crash.
- **15 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** Page added.
- **15 May 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Put Call to Suffering in S-tier for Mythic+.
- **13 May 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add note about buying defensive trinkets for Mythic+.
- **13 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add section on gearing defensively for high keys.
- **09 May 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** More info around Vessel and the Fire damage procs and add trinket combination examples for Mythic+.
- **09 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add note about Mind Control tech on Granyth in Nokhud.
- **09 May 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add option to cancel Mind Flay: Insanity in AoE situations.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Update video to Season 4 playlist.
- **05 May 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add more detail around Vessel and swap a few rankings around.
- **02 May 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Increase priority of Void Bolt and correct opener from this change.
- **01 May 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update ranking of Vessel of Searing Shadows since it can help proc the rings.
- **30 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add more info on bullion purchases and additional fire damage sources.
- **30 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Phantasm suggestion for Uldaman and add note about Maddening Touch usage.
- **30 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add note about Maddening Touch in the Mythic+ build.
- **29 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Fix bug in switcher for suggesting Purify Disease in Ulda.
- **28 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add note about on-use trinkets in Mythic+.
- **28 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Phantasm for Halls of Infusion.
- **26 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Purify Disease and Dominate Mind for Nokhud.
- **26 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Adjust Mind Flay: Insanity and Mind Spike: Insanity priority in AoE.
- **25 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add bonus IDs to display crafted gear more clearly and add new video for Bullions and split suggestions for Raid and Mythic+.
- **25 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Adjust plater mod links and add personal profile.
- **25 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add new video link.
- **25 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Remove Phantasm suggestion for Azure Vault.
- **25 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add new video link and clarify Nymue trinket usage with Shadowfiend.
- **25 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add new talent video.
- **25 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Add new video playlist for Season 4.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update for Season 4 with new gear suggestions.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Update for Season 4, including a new weak aura to track the tier set bonus.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update leg enchant suggestion and review for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Update secondary stat goals for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update builds for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update rotation for Season 4 with new placeholder builds and options.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update all builds for Season 4 and replace pathing sections with an in-depth Class Talent guide.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Updated for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update builds for Season 4.
- **22 Apr. 2024 (this page):** Update for Season 4.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update embellishment guidance for high Mythic+ dungeons.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Extra clarification on gem choices.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Holy Nova suggestion for Throne of the Tides and new Mind Control tech for Black Rook Hold and Galakrond's Fall.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Update changelog for Patch 10.2.6.
- **10 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Update Power Infusion special macro to work outside of raid without someone set.
- **19 Feb. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Mind Flay Mind's Eye variant for the Ghost Priority build.
- **14 Feb. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Fix name in widget for the Ghost build and add direct talent strings for Mind's Eye versions.
- **13 Feb. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update dungeon trinket rankings to match the tier list.
- **13 Feb. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Remove mention of Stinger Mind Control in Everbloom.
- **13 Feb. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update default class talents for all builds and update Shadowy Apparitions build to be the Ghost Priority Build version.
- **13 Feb. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update default class talents and utility choices in the Mythic+ build.
- **09 Feb. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add note about Rockspine Stinger Mind Control.
- **08 Feb. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add Versatility video link.
- **08 Feb. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add aoe rotation video link.
- **08 Feb. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add aoe rotation video link.
- **28 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Suggest Mass Dispel for all Afflicted keys.
- **25 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Increase rank of Balefire Branch and Ashes of the Embersoul in Mythic+ Rankings.
- **21 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add extra clarity on stacking Versatility.
- **21 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update Void Eruption Mythic+ build defaults from recent buffs.
- **21 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update 3-target council build from recent buffs.
- **21 Jan. 2024 (this page):** Update from upcoming hotfix buffs to Shadow Priest.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Clarify usage on Hood of Surging Time in Mythic+.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add alternative Boot enchant for more mobility.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Clarify Haste thresholds with Hood of Surging Time and mention the value of Versatility for pushing Mythic+ dungeons.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add video links and a few more WeakAuras.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add optional change to the ST + Shadow Crash build and update the 3 target council build.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update default build for Patch 10.2.5 to be more well rounded.
- **15 Jan. 2024 (this page):** Update changelog for Patch 10.2.5.
- **02 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add more detail around spending stacks of Death's Torment in the tier section.
- **23 Dec. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add build option for dropping Mindbender and Inescapable Torment.
- **20 Dec. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Lower Nymue in the trinket rankings for Dungeons.
- **19 Dec. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update gear sets with more Neck options.
- **19 Dec. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Remove outdated section and adjust Mind Flay options.
- **18 Dec. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add extra note about Augury of the Primal Flame.
- **18 Dec. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update Mythic+ builds from recent Psychic Link buffs.
- **18 Dec. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add note for loss in ST on the Shadow Crash build.
- **18 Dec. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update flex point talents in default Mythic+ build and update the 3 target council build.
- **13 Dec. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add note about prioritizing helm upgrades for Incandescent Essence.
- **13 Dec. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add section about Incandescent Essence.
- **13 Dec. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Dropped Idol of Y'Shaarj to use Insidious Ire instead for key builds.
- **12 Dec. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update default Mythic+ build to not use Idol of Y'Shaarj.
- **08 Dec. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Suggest Mass Dispel by default in Throne of the Tides.
- **03 Dec. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update Dark Ascension Triple Idol build to default to Mind Flay.
- **03 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add clarifying note about how the 4pc set bonus works.
- **03 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add section on optimizing Idol of Y'Shaarj.
- **03 Dec. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update default Mythic+ build to use Mind Flay.
- **03 Dec. 2023 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Add more detail about Idol of Y'Shaarj.
- **01 Dec. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add crafted gear widget.
- **01 Dec. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add more info about when to pick which build. Refactor Shadowy Apparitions build to work better with the Season 3 set bonus.
- **01 Dec. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update 3 Target council build to default to Mind Flay.
- **30 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add trinket tier lists as well as more detailed info on some options.
- **30 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Add a few new WeakAuras and Plater mods.
- **25 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add more Dispel suggestions to various dungeons.
- **24 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket and weapon rankings/comments.
- **24 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Purify Disease to Atal'Dazar suggestions.
- **24 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Remove Power Word: Shield action during movement.
- **20 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Change the name of the Season 2 build to the Shadowy Apparitions build and go over use cases.
- **19 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add extra SW:D line when only using the 2-piece set bonus.
- **17 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update Mythic+ builds for Season 3 to be more streamlined.
- **17 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update builds for 3 target and Mythic+ to be more streamlined.
- **16 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update note about Ashes trinket.
- **16 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Season 2 tier set build to use while gearing up.
- **14 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add small note about using Iridal in execute.
- **14 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add link to the trinket video.
- **14 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add Mind Flay build option to the Single Target + Shadow Crash build.
- **13 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update trinket suggestions and add more detail about when to use each one.
- **08 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add link to crafted gear video.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update embellishment suggestions after the Undulating Sporecloak nerf.
- **07 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add note about Crit/Vers scaling with cantrip items.
- **07 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Small clarifying update to using Belor'relos, the Suncaller.
- **07 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Adjust movement GCDs in main rotation priority.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated for Patch 10.2 with a new talent build.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update gear lists and suggestions for Season 3 and Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.0.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update all consumables for Season 3.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Updated stat thresholds and goals for Patch 10.2.0.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reorder sections and update information for Season 3 and Patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.0 and the new Season 3 set bonus.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update talent builds and suggestions for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Update spells from changes in Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated talent build and add rotational goals for Patch 10.2.0.
- **06 Nov. 2023 (this page):** Updated changelog for Patch 10.2.0.
- **03 Oct. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Use correct name for the socket item for Season 2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add new gear lists.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Reorganize headers to be more readable and move talent spell breakdown.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Update description of Angel's Mercy from the change in 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Added info on changes for Patch 10.1.7.
- **18 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Correct typo in the description for the Triple Idol Dark Ascension build.
- **13 Aug. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add video link.
- **13 Aug. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update video link.
- **13 Aug. 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add video link.
- **13 Aug. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update video link and clarify differences between triple idol setups.
- **13 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update video link.
- **13 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Clarify note on Triple Idol setups in high keys and update video link.
- **13 Aug. 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update video link.
- **10 Aug. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add note about Irideus Fragment for Dark Ascension builds.
- **10 Aug. 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add secondary stat deep dive section for optimizing top end gear.
- **09 Aug. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add more detail on when to pick which build as well as touching up several sections to make things clearer.
- **09 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Added note to the Dark Ascension opener to make it clearer.
- **09 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Removed Shadow Word: Death in Void Eruption opener when using Inescapable Torment.
- **08 Aug. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add new section clarifying when to use each dungeon build.
- **08 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Adjust Dark Ascension opener to account for Distorted Reality.
- **08 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Fix issue where Dark Ascension Single Target build was not using Distorted Reality.
- **08 Aug. 2023 (this page):** Update video link.
- **07 Aug. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add new builds from recent hotfix nerfs to various spells.
- **07 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add new builds from the recent hotfixes.
- **07 Aug. 2023 (this page):** Added a changelog from the recent hotfixes to our DoTs, Shadowy Apparitions, and Vampiric Embrace.
- **31 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add a few missing entries for Mass Dispel use cases.
- **31 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Swap to Distorted Reality by default for the Dark Ascension ST build.
- **26 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Adjust sections for Divine Star and Mindgames usage to set them at a lower priority.
- **25 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add Dark Ascension + Shadow Crash build.
- **23 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Reviewed from the recent hotfixes.
- **23 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed from the recent hotfixes.
- **23 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed from the recent hotfixes.
- **23 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed from the recent hotfixes.
- **23 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Reviewed from the recent hotfixes and mentioned new talent options.
- **23 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed from the recent hotfixes.
- **23 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Reviewed from the recent hotfixes. Noted difference in single target builds.
- **23 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed from the recent hotfixes.
- **23 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed from the recent hotfixes.
- **23 Jul. 2023 (this page):** Added a changelog from the recent hotfixes.
- **17 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Refactor to use new talent layout.
- **17 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Refactor to use new talent layout.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated for Patch 10.1.5 with new talent strings.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updates for Patch 10.1.5 including new items from Dawn of the Infinite.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Add a new Power Infusion macro.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated talent strings for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5 and small update to Voidform opener.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update talent strings for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Add in references to Benevolence and Essence Devourer talents for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Add new talent strings for 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5 with new changes.
- **28 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Swap out Malediction for Deathspeaker on the Dark Ascension build.
- **27 Jun. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Clarify a few choices on trinkets and embellished items.
- **27 Jun. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Adjust wording on Onyx Annulet do not use statement.
- **27 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Adjust builds to include Distorted Reality, Dark Ascension, and Mindbender options.
- **27 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Rotational updates for Shadow Word: Death depending on talents selected. Clarify some Distorted Reality usage.
- **27 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add new talent builds from the recent hotfixes.
- **27 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update default build.
- **27 Jun. 2023 (this page):** Add note about recent hotfixes to Shadow.
- **23 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update some figures for Distorted Reality.
- **23 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Adjust notes about Distorted Reality.
- **22 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Correct issue with Mind Flay vs. Mind Spike comparisons.
- **20 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Clarify DR vs. ME and Mind Spike vs. Mind Flay DPS breakdowns.
- **20 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update Devouring Plague refreshing details.
- **20 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Add clarifying notes about Distorted Reality.
- **16 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add more detail on why to use Mind Spike in keys.
- **15 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Clarifying note to Void Torrent around Devouring Plague.
- **07 Jun. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add note about Beacon to the Beyond in Mythic+.
- **07 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add section on burst damage.
- **06 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add note clarifying Void Torrent should always be fully channeled.
- **01 Jun. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Clarifying technical note about how the T30 set bonus works and adding rough numbers.
- **01 Jun. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Add simple Mass Dispel macro.
- **01 Jun. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add note about rough value of a socket.
- **01 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Clarifying note about how the tier set bonus works.
- **01 Jun. 2023 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Add a bit more detail to Shadow Crash.
- **31 May 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add a bit more detail on weapon crafting.
- **30 May 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Add a few mouseover macros for handling Season 2 affixes.
- **30 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add a few mouseover macros for handling Season 2 affixes.
- **28 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Remove Purify Disease and Mind Control suggestion for Halls of Infusion.
- **26 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Shuffle sections around and add more detail around defensive usage.
- **26 May 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add a note about tier set optimization in Mythic+.
- **25 May 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add extra note about Ominous Chromatic Essence.
- **24 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Remove part of the sample opener in favor of the rotation page.
- **23 May 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add timewalking section.
- **23 May 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Adjust timewalking section from recent changes
- **22 May 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Add more detail on Haste soft caps.
- **22 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** More tips and details for Season 2.
- **22 May 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add more detail on using Halo, Divine Star, and Shadow Crash during pre-pull. Add note about Spoils usage.
- **21 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add easy way to see utility choices by dungeon and affix.
- **19 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Mind Control section for interesting mobs to control.
- **18 May 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Correct typo in the intro section.
- **16 May 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add bug to Undulating Sporecloak and remove old Neltharion's Lair items.
- **16 May 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Remove reference to Undulating Sporecloak bug as it was fixed.
- **15 May 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Correct Undulating Sporecloak info now that it has fixed stats.
- **15 May 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Rage Phial has been fixed so adjusting back suggestions and adding belt clasp.
- **06 May 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add note about Ominous Chromatic Essence flight choice.
- **06 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Suggest Mass Dispel for Halls of Infusion and add more detail on Mind Flay in Mythic+.
- **05 May 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update weapon and trinket rankings from recent changes.
- **05 May 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Clarify Shadow Crash usage is only for refreshing DoTs.
- **04 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Season 2 dungeon utility section.
- **04 May 2023 (this page):** Remove Pending Changes section.
- **03 May 2023 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Fix Shadow Crash note before you have Whispering Shadows.
- **03 May 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Change default Phial back to Vers with Rage being bugged.
- **03 May 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Lower priority for Shadow Word: Death.
- **02 May 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add extra note on Sophic vs. Wafting.
- **02 May 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Clarification for Dstar and Halo and expanded on Distorted Reality in Devouring Plague section.
- **02 May 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Small caveat to the flex points
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Update builds for Patch 10.1.0.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update all gearing suggestions for 10.1 and Season 2.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Change suggested Phials and review other enchants for 10.1.0.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Updated stat priority references to bugs that were fixed in 10.1.0.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated talent builds and suggestions for 10.1.0.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Significant updates to support the 10.1 rework.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update talent builds for the 10.1.0 rework.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Updated for new spells in 10.1.0.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated for Patch 10.1.0.
- **01 May 2023 (this page):** Updated for patch 10.1.
- **25 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.
- **23 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update Onyx Annulet suggestions from recent hotfixes.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update Onyx Annulet suggestions from recent hotfixes.
- **22 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update Onyx Annulet suggestions from recent info on Prophetic Twilight Stone interactions.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Update Onyx Annulet suggestions from recent info on Prophetic Twilight Stone interactions.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/shadow-priest-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update for Patch 10.0.7 with new section on the Onyx Annulet.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.7 and add info about the Onyx Annulet ring.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7 and added section for known bugs.
- **05 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Small tweak to Dungeon trinket suggestions.
- **26 Feb. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Correct error in Mindgames target cap.
- **25 Feb. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Clarify Void Torrent use in opener.
- **23 Feb. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Fix issue with Void Torrent in single target, should only cast with all 3 DoTs active.
- **22 Feb. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add caveat for using Mind Sear in Mythic+.
- **17 Feb. 2023 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Update leveling build from recent balance changes.
- **17 Feb. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add more detail to the example opener.
- **15 Feb. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Clarify gem usage.
- **04 Feb. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Adjust single target differences for common builds.
- **04 Feb. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update 2-target build and add a note about VF on single target.
- **03 Feb. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Fix issue with Mind Control macro.
- **03 Feb. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Adjust high priority Mind Flay: Insanity action to only use when Void Torrent is not available.
- **02 Feb. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add more uses for Dispel and Mass Dispel.
- **31 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Correct high priority Mind Flay: Insanity line with Cthun when not taking Mindbender. Condense AoE rotation down to be easier to read.
- **25 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Update tree for Patch 10.0.5.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Update gear suggestions for 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Add a macro for Mind Control and clean up a few others.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Added mention of Haste/Mastery combo gem.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Update talent builds and suggestions for 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update rotation guide for 10.0.5 with Void Torrent usage.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update talent builds for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Add new talents for 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update talents for 10.0.5 builds.
- **24 Jan. 2023 (this page):** Reviewed and updated for Patch 10.0.5.
- **12 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add Void Tendrils suggestion for Spiteful affix.
- **12 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Remove Mind Sear usage on single target.
- **11 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add new talent builds from the recent buffs.
- **11 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Rotational updates for 10.0.5, mostly formatting changes with some small clarity updates.
- **11 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update Mythic+ talent builds from the recent changes.
- **04 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Small clarification on Devouring Plague refresh notes and add some Trinket notes.
- **03 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Update openers with more detail. Split them out by cooldown to be easier to maintain.
- **01 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Lower priority on Shadow Word: Death with Inescapable Torment.
- **29 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Add new logic for Mind Flay: Insanity and change default checkboxes.
- **24 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add Desperate Invokers Codex trinket.
- **23 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add more detail to picking between the two talent builds in Mythic+.
- **23 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Update talent builds to account for Screams of the Void bug.
- **21 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add some more detail to crafted gear sections.
- **21 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add extra clarification on when to use Vers phial.
- **21 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Update talent suggestions to be simpler to start with.
- **13 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Add video guide for crafted gear and remove note about having different elements in Elemental Lariat.
- **13 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Add alternate ST build that offers more burst.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated for Season 1 launch.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Add note about more Phials that I would not suggest using.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add some start of season 1 tips.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Added section discussing Tier 29 set bonus rotational changes.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **09 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Added extra note about Mind Spike vs. Mind Flay with Mind Melt and Idol of C'Thun.
- **08 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Moved racials out of the rotation into their own section. Fixed opener to be easier to read.
- **07 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Made some parts of the rotation around Mind Blast easier to read.
- **07 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated Marileth soulbind calc to remove Dissonant Echoes conduit.
- **05 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Add a section on the Mythic+ opener and easy version of the priority list.
- **05 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Cleaned up Devouring Plague lines to be more clear.
- **03 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Updated the rotations filler sections to be clearer. Added a new section on how to use Mind Sear.
- **03 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Included acronyms and commonly used references to spells.
- **02 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Made it clearer when to use your filler spells with the bottom section.
- **31 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated talent builds to no longer suggest Psychic Link and removed Idol-less build.
- **31 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated talent builds to no longer suggest Psychic Link and changed default Mythic+ build to Yogg-Saron.
- **31 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated talent builds to no longer suggest Psychic Link.
- **30 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Added extra movement macro.
- **27 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Updated PI macro and added a new one for talent choice nodes.
- **26 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-castle-nathria-raid-guide>)):** Updated suggested build to use Idol of Y'Shaarj and Talbadar's Stratagem Legendary.
- **26 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-sanctum-of-domination-raid-guide>)):** Updated suggested build to use Idol of Y'Shaarj and Talbadar's Stratagem Legendary.
- **26 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated suggested build to use Idol of Y'Shaarj and Talbadar's Stratagem Legendary.
- **26 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated builds to pickup Translucent Image.
- **26 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Added more rotation switches to make things easier to look at.
- **26 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated talent builds from recent bug finding for Screams of the Void.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/shadow-priest-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/shadow-priest-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/shadow-priest-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** Adjusted priority of Shadow Word: Death, Mind Flay, and Mind Spike.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **29 Jul. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/shadow-priest-patch-9-2-changes-analysis>)):** Added changes for 9.2.5 and Season 4.
- **22 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/shadow-priest-patch-9-2-changes-analysis>)):** Updated changelog from Pallid Command nerfs.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/shadow-priest-patch-9-2-changes-analysis>)):** Added Patch 9.2 changes and initial thoughts.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** Added Patch 9.1.5 changes.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** Added new hotfixes and remove PTR blurb.
- **06 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** Removed Anima Power section.
- **29 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** Added all changes with up to date commentary.
- **02 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** More PTR changes from the latest build affecting base spells, Legendaries, and Conduits.
- **22 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** Added initial content.
- **26 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-ny-alotha-raid-guide>)):** Updated suggestions for Mindbender and Ancient Madness post pre-patch tuning.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **13 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-the-eternal-palace-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **06 Oct. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-the-eternal-palace-raid-guide>)):** Added more tips to a few bosses.
- **05 Oct. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-the-eternal-palace-raid-guide>)):** Added more tips.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **11 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-crucible-of-storms-raid-guide>)):** Updated talent suggestions and added tips for Uu'nat.
- **14 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **26 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated several talent suggestions and playstyle tips.
- **29 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added the remaining talent advice and boss tips.
- **24 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** Filled in most of the talent advice and boss tips.
- **22 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added boss tips for Shadow Priest in Battle of Dazar'alor.
- **12 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** Updated some of the talent recommendations and fight tips.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** Updated for Patch 8.1 changes.
- **04 Oct. 2018 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** Updated now that proper conclusions can be drawn based on data.
- **11 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** Updated after seeing data from the first week of Uldir.
- **05 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** Restructured playstyle advice and updated talent suggestions.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** Preliminary updated for Uldir launch.
- **09 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** Removed Legion info and added a placeholder for Uldir.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Shadow Priest leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Priest leveling guide](<https://www.icy-veins.com/wow/priest-leveling-guide>).

1.

### Shadow Priest Leveling Guide for Midnight

Shadow Priest offers a sort of unique take on leveling where 

you have a few options on how to play, depending on your preferred pacing. As a

damage-over-time specialist, you can pull lots of mobs at once and let your

DoT effects tick down on them, or you can pull a group of mobs and burst them

down, depending on your talents.

When leveling as a Shadow Priest you want to prioritize tagging mobs

with [[spell:589]] and [[spell:1227280]], and let

your DoTs do the rest. You can then use [[spell:586]] and [[spell:8122]]

to avoid being hit by mobs and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver can further extend this

by casting [[spell:263165]] while moving.

In between combat be sure to use [[spell:1231418]] to quickly restore health out of 

combat without needing to eat consumable food. This can be found in the General 

tab of your spellbook.

1.1.

#### Leveling Gear Options

When it comes to gearing out your Shadow Priest, you should always take the

piece with a higher Intellect value, typically referenced by the item

level of that piece. Intellect is far and away our better stat and will make

everything you do hit harder and kill mobs quicker.

When you get pieces of gear that have the same Intellect, you should roughly 

prioritize pieces with Haste, Mastery, or ideally both to be slightly more optimal.

When using Heirloom items, we recommend using those with Haste as they will 

slightly improve the gameplay flow while leveling.

1.2.

#### Useful Leveling Consumables for Midnight

Leveling in a new expansion is all about minimizing downtime and front loading power. 

While endgame enchants and consumables are often disabled or heavily scaled during early 

leveling, there are still several items worth stockpiling ahead of time to make the 

process smoother, faster, and less frustrating. The recommendations below focus on 

items that historically remain useful at expansion launch and provide value 

regardless of tuning changes.

The War Within enchants will still work throughout the leveling process, and can be 

a cheap way to add small boosts of power. Enchants that grant haste or speed are 

particularly valuable early on when gear upgrades are sparse. 

Prioritize the following:

- [[item:223674]] (helps as you lose haste while leveling)
- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

Tempered Potions remain usable at lower levels can significantly speed up 

difficult pulls, elite quests, or story encounters. Stock a small supply for moments 

where burst damage or survivability matters. Be sure to use these before you get to max

level content!

Once you hit level 81 you can acquire

[[item:241305]], which is a great addition to your self-healing.

Certain consumables can dramatically improve leveling flow:

- [[item:109076]]
- [[item:132516]] or [[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]] or [[item:133576]]

2.

### Leveling Talents

You unlock the Talent Trees at Level 10. Further below is the recommended Leveling 

Talent path. If you are still leveling up to Level 80 feel free to pick either of the

leveling builds.

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Leveling Build

This build gives you a leveling build that is centered around big damage with 

[[spell:391399]] and [[spell:120644]] while still relying on baseline 

damage from your main damage over time effects.

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80

import string for you. You can follow the point-by-point

allocation of the below tree once you start gaining levels in Midnight.

:::talents Archon Level 80 Starting Talents
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAAzmBAAAAAAAAAAAwYsYGjlxYmZzwMDMYmZGLIzYxMNAGgZWMDzmBgMGLAYmZmhxMzMzsxMAYGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAAzmBAAAAAAAAAAAwYsYGjlxYmZzwMDbzYMzMjFkZsYmGADwMLmhZzAQGjFAMzMzwYmZmZ2YmtlBYGMA"
}
```
:::

:::details 来源计算器编码
```
#CE-BAkWldvNOsbKKqHoaQw4K2edaaWUghJdJxA-ZaDxqS7wNJZx1Y55JpZSCEaTzwvviiD-AAAA-IGAUSOKCMKohxS-
```

:::

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Leveling Build

This build leans more heavily into damage over time effects with access to

[[spell:448278]] and [[spell:1266845]], as well as getting

[[spell:451018]] for cast while moving [[spell:263165]].

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80

import string for you. You can follow the point-by-point

allocation of the below tree once you start gaining levels in Midnight.

:::talents Archon Level 80 Starting Talents
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAAzmBAAAAAAAAAAAwYsYGjlxYmZzMmZgBzMzYBZGLmpBwMzAABY2mNgZDAjZmhxMzMzsxMwMYGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAAzmBAAAAAAAAAAAwYsYGjlxYmZzMmZYbGjZmZsgMjFz0AYmZAgAMbz2GY2YAGzMDjZmZmZjZwMDmBDA"
}
```
:::

:::details 来源计算器编码
```
#CE-BAkWldvNOsbKKqHoaQw4K2edaaWUghJdJxA-ZaDxqS7wNJZR31Y55pZSCEaTzwvviiD-AAAA-TOGYIUEgohZRBJ-
```

:::

2.3.

#### War Mode Talents for Leveling

In this section, we will go over each of the War

Mode/PvP talents you should consider using while leveling up.

1. [[spell:211522]] will do a sizable chunk of damage 
   
   on a relatively low cooldown.
2. Use [[spell:199445]] and make sure you try to full 
   
   channel [[spell:391399]].
3. Use [[spell:1246968]] until you unlock more talents.
4. [[spell:199259]] allows you to use your main 
   
   cooldown more often. Feel free to start using this on cooldown instead of just saving 
   
   it for big packs or important enemies.

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider 

to select your level, and watch as the leveling rotation grows with each 

level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

Use the following to switch which leveling build rotation is shown.

<table>&#10;<tr>&#10;<th colspan="2">Build Selector</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<strong> <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp"/> Archon</span></strong>&#10;</td>&#10;<td>&#10;<strong> <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp"/> Voidweaver</span></strong>&#10;</td>&#10;</tr>&#10;</table>

The builds suggested for leveling are focused around DoTs and moving 

quickly through the leveling process. When leveling, particularly in a group,

mobs will not live very long, so we prioritize just being able to get DoTs 

up on a target and then moving on to the next one. This lets you continuously 

pull mobs with [[spell:589]] and [[spell:1227280]] and let your dots

do the heavy lifting for you. Once you have your DoTs active on the enemies you 

care about, then you can use your other spells.

**适用条件：Archon（启用）。** The current rotation is for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon, use the build selector above to switch this.

**适用条件：Voidweaver（启用）。** The current rotation is for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver, use the build selector above to switch this.

**等级 1–2：**Starting at Level 1, you only have [[spell:585]], so

just spam this for now.

**等级 6 起：**Before combat, make sure you have the following buffs active:

- **等级 6 起：**[[spell:21562]]
- **等级 10 起：**[[spell:232698]]

1. **等级 2 起：**Keep up [[spell:589]] on as many targets as possible.
2. **等级 10–14：**Keep up [[spell:34914]] on as many targets as possible.
3. **等级 15 起：**Use [[spell:1227280]] to quickly apply [[spell:34914]] to multiple targets.
4. **等级 71 起：**Use [[spell:120644]] on cooldown.
5. **等级 27 起：**Use [[spell:228260]] as your main cooldown when fighting harder enemies.
6. **等级 12 起：**Use [[spell:10060]] as a cooldown when fighting harder enemies.
7. **等级 27 起：**Cast [[spell:1240401]] while [[spell:228260]] is active.
8. **等级 11 起：**Use [[spell:335467]] to spend Insanity for damaging a single-target.
9. **等级 10 起：**Use [[spell:8092]] on cooldown.
10. **等级 75 起：**Cast [[spell:391399]] to spend all charges of [[spell:391399]].
11. **等级 30 起：**Use [[spell:32379]] on any target below 20% health.
12. **等级 10 起：**Use [[spell:15407]] as your filler spell.
13. **等级 2–9：**Use [[spell:585]] as a filler spell.

1. **等级 2 起：**Keep up [[spell:589]] on as many targets as possible.
2. **等级 10–14：**Keep up [[spell:34914]] on as many targets as possible.
3. **等级 15 起：**Use [[spell:1227280]] to quickly apply [[spell:34914]] to multiple targets.
4. **等级 27 起：**Use [[spell:228260]] as your main cooldown when fighting harder enemies.
5. **等级 12 起：**Use [[spell:10060]] as a cooldown when fighting harder enemies.
6. **等级 27 起：**Cast [[spell:1240401]] while [[spell:228260]] is active.
7. **等级 77 起：**Use [[spell:32379]] if the target has an absorb shield active.
8. **等级 71 起：**Use [[spell:450405]] during [[spell:447444]].
9. **等级 11 起：**Use [[spell:335467]] to spend Insanity for damaging a single-target.
10. **等级 71 起：**Use [[spell:263165]] on cooldown.
11. **等级 10 起：**Use [[spell:8092]] on cooldown.
12. **等级 30 起：**Use [[spell:32379]] on any target below 20% health.
13. **等级 10 起：**Use [[spell:15407]] as your filler spell.
14. **等级 2–9：**Use [[spell:585]] as a filler spell.

You also have the following spells you can use.

- [[spell:17]] for an extra defensive shield.
- **等级 10 起：**[[spell:8122]] as an AoE Crowd Control ability.
- **等级 40 起：**[[spell:19236]] as a defensive ability.
- **等级 18 起：**[[spell:453]] to help skip past enemies.
- **等级 18 起：**[[spell:528]] to remove buffs off enemies.
- **等级 36–81：**[[spell:586]] to help skip past mobs with the reduced aggro radius.
- **等级 82 起：**[[spell:586]] to help skip past mobs with the reduced aggro 
  
  radius or as a defensive.
- **等级 26 起：**[[spell:15487]] to interrupt enemies casting.
- **等级 13 起：**[[spell:47585]] as your most powerful defensive ability.
- **等级 10–87：**[[spell:2061]] if you are running low on health.
- **等级 88 起：**[[spell:2061]] if you are running low on health or 
  
  for the defensive buff of [[spell:193063]].
- **等级 25 起：**[[spell:15286]] for powerful healing during large damage windows.
- **等级 16–21：**[[spell:121536]] for movement.
- **等级 22 起：**[[spell:121536]] or [[spell:17]] for movement.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Update for Season 2 and Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for the launch of Midnight season 1.
- **02 Mar. 2026:** Add import strings for starting to level at 80.
- **26 Feb. 2026:** New leveling builds for Midnight launch to level 90.
- **10 Feb. 2026:** Updated Talent Trees for changes to class point gating.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Update for Patch 11.2.0.
- **15 Jun. 2025:** Review information for Patch 11.1.7.
- **25 May 2025:** Reviewed information after recent hotfixes to still be accurate.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Update talent build for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **04 Nov. 2024:** Update Halo priority for Archon rotation.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **11 Oct. 2024:** Removed Voidwraith for Voidweaver leveling.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for the launch of The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2 with a new talent build.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5 with new talent strings.
- **03 May 2023:** Fix Shadow Crash note before you have Whispering Shadows.
- **01 May 2023:** Update builds for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **17 Feb. 2023:** Update leveling build from recent balance changes.
- **25 Jan. 2023:** Update tree for Patch 10.0.5.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Shadow Priest in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Shadow Priest

This section is intended for players who are new to the game or class or 

simply want a more straightforward way to play their specialization without 

being overwhelmed by the numerous priorities and active abilities that 

need to be taken into consideration for optimal play.

Shadow Priest, at its core, is a builder spender spec 

specializing in damage over time (DoT) effects. At a high level, the spec 

mostly revolves around keeping your DoT effects up on as many targets as possible

while also building Insanity to spend on [[spell:335467]]. The rest of

this page is dedicated to getting you to that goal in the easiest way possible

to reduce the demands of the specialization at the top end of play without

causing a large drop in numerical output.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) **Manage your Insanity**  
  
  
    Shadow's resource is Insanity, which is spent on
  
    [[spell:335467]]. It builds up as you deal damage with your spell,
  
    and has a cap of 100, so avoid waste.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_unholyfrenzy.jpg>) **Cast Cooldowns**  
   
  
    Shadow has many spells that can be available to press at any given time.
  
    To get started your goal is to make sure nothing is sitting off cooldown unnecessarily. 
  
    This primarily includes spells like [[spell:8092]] and [[spell:1227280]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_shadowwordpain.jpg>) **Keep Debuffs Active**  
  
  
    As a Shadow Priest you gain damage on all your spells when you have your damage over 
  
    time effects (DoTs) active. Keep [[spell:589]] and [[spell:34914]] 
  
    up on your targets at all times.

2.

### Beginner's Guide to Shadow Priest in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver   Single-Target Build

2.1.

#### Beginner Single-Target Talents for Shadow Priest

This build is your best starting point for single-target situations, such as a Raid Boss Encounter.

The build below suggests starting with [[spell:409044]]. 

 This can make it more forgiving to maintain a high uptime of [[spell:335467]]

 and slows the spec down slightly while still being capable of good damage.

Note: for pure single-target encounters, you can remove [[spell:199484]]

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Single-Target Easy Mode
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMjZGAAAAAAAAAAAAMbmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGz2YGMzgZwA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMjZGAAAAAAAAAAAAMbmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGz2YGMzgZwA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaDT7Uhx15pSMRpI980YJU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver   Dungeon Build

2.2.

#### Beginner AoE and Mythic+ Talents for Shadow Priest

For encounters or situations that are AoE-focused, use this build as your starting point.

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Misery Mythic+ - Voidweaver
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx15NRdlkosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

### Shadow Priest   Basic Rotation

2.3.

#### Beginner Shadow Priest Rotation

When playing Shadow Priest, you can boil down the rotation to maintaining

 core DoT spells with [[spell:34914]], building up Insanity, and then

 spending it on [[spell:335467]]. These steps are broken down into

 four rotational goals when playing the spec. If you get these goals down,

 you will have a good platform to play the spec in PvE content.

1. Maintain [[spell:34914]] and [[spell:589]] roughly
   
    up to 12 targets. Use [[spell:1227280]] to help with this.
2. Maintain maximum uptime of [[spell:335467]] on the main 
   
    priority target. Try to avoid refreshing until it is about to expire, or 
   
    if you will cap on Insanity.
3. Use short cooldown Insanity generating spells to make sure you do not 
   
    lose uses of them. This includes spells like [[spell:8092]] and [[spell:1227280]].
4. Use your long cooldown spells ideally when you will not lose uses
   
    of any short cooldown spells, being sure not to hold too long to still 
   
    take advantage of any active buffs. This includes spells like [[spell:120644]] 
   
    or [[spell:263165]].

If you can get these goals right, the rotation should make more sense and

 fall into play naturally. Check out the priority list below for more specific

 suggestions.

Due to [[spell:199484]] being one of our core-AoE abilities, our playstyle broadly 

 does not change when facing multiple targets. The biggest change is just making

 sure to keep DoTs on targets with [[spell:1227280]] or [[spell:34914]]

 as a pack is being grouped.

2.3.1.

##### Priority List

Before you start combat, make sure you have [[spell:232698]] and 

 [[spell:21562]] active and then use [[spell:34914]] to start 

 combat.

1. Keep [[spell:589]] and [[spell:34914]] applied on as many
   
    targets as possible. Note that with [[spell:238558]], you should always use
   
    [[spell:34914]] to refresh either of these DoTs, 
   
    unless you are moving. [[spell:1227280]] should be used whenever possible
   
    so you are not wasting time manually DoTing each mob.
2. Cast [[spell:228260]] on cooldown.
3. Cast [[spell:10060]] on cooldown (make sure you cast it on an ally with [[spell:373466]]).
4. Spend Insanity on [[spell:335467]].
5. Cast [[spell:1240401]] on cooldown.
6. Cast [[spell:8092]] whenever available to generate Insanity.
7. Cast [[spell:263165]].
8. Cast [[spell:1227280]] if you have any charges available.
9. Cast [[spell:32379]] when the target is in execute range.
10. Cast [[spell:15407]] to generate Insanity as a filler spell.

:::details **How to Improve Fast**
**Never Idle Globals**

- Queue your next cast before the current cast finishes so you do not lose casts over a fight.

**Plan Movement**

- Stutter-step with instant casts like

[[spell:1240401]]

,

[[spell:32379]]

, and

[[spell:375888]]

procs before defaulting to

[[spell:589]]

on the move.

**Track Cooldown Uses**

- Missing casts of

[[spell:228260]]

,

[[spell:10060]]

, or

[[spell:263165]]

is usually a larger DPS loss than small stat or gear differences.

:::

2.3.2.

##### Apex Talent: ![Void Apparitions Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) Void Apparitions

Once you get access to the Apex talents it is crucial that you never let

 [[spell:1227280]] sit at max charges. Ideally you are spending this cooldown

 regularly, especially during cooldowns to get more procs of our Idol spells

 and [[spell:341491]].

2.3.3.

##### Season 2 Tier Set

This season as a Shadow Priest you have access to the following set bonuses:

- 2-Piece Bonus: [[spell:1296579]] - [[spell:1227280]] cooldown is 
  
      reduced by 3 sec and its damage is increased by 100%.
- 4-Piece Bonus: [[spell:1296580]] - [[spell:1227280]] has a 100% 
  
      chance to grant a free use of [[spell:1240401]] at 100% effectiveness.

Rotationally this set bonus will make [[spell:1227280]] a more central part of your 

rotation, allowing for more casts and procs that grant use of 

[[spell:1240401]].

More than ever it is crucial to never let [[spell:1227280]] sit at max charges.

   When you cast it you will get a free cast of [[spell:1240401]], so you want to 

   make sure you weave in casts of Void Volley as well.

### Shadow Priest   Defensive Spells

2.4.

#### Defensive Spells for Shadow Priest

Shadow Priests has access to many defensive spells. Use the following list

 to help survive incoming damage.

- [[spell:47585]] is your biggest active defensive ability that should be 
  
   used when you are in dire circumstances or to help mitigate a big incoming hit 
  
   of damage. During the effect, you are unable to cast, but you can cast the spell
  
   again to cancel it early.
- [[spell:19236]] acts as both a medium-sized heal as well as a
  
   defensive by increasing your health pool. This can situationally save your life
  
   and is very powerful, especially with talents like [[spell:238100]] or 
  
   [[spell:373450]] in the class tree.
- [[spell:586]] with [[spell:373446]] talented turns this spell into a 
  
   low cooldown defensive that should be used early and often to reduce incoming
  
   damage.
- [[spell:2061]] with [[spell:193063]] talented turns a spell
  
   that is a small heal into another active defensive spell that we can layer
  
   [[spell:586]] to get roughly 20% damage reduction when needed.
- [[spell:17]] is one of your last resort spells that can save
  
   your life by providing a small shield to yourself when cast.

### Shadow Priest   Stat Priority

2.5.

#### Stat Priority for Shadow Priest

When playing Shadow Priest, you can start gearing by

following the priority below as a rough guideline. This should only be used

as a starting point, as simming your character for specific gear upgrades

will always be the most accurate.

For more information on what's presented on this page, check out our main 

[Stat Priority page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>).

Item Level

Haste

Mastery

Critical Strike

Versatility

Typically, you will be looking for Haste/Mastery pieces, but because of the

strength of Intellect, having anything at a high item level will be a

good place to start. While learning fights, you will get more value out 

of Haste stacking as it can help cover up mistakes more than other stats.

Certain setups will favor Mastery over Haste when being fully optimal, but as a 

new player prioritizing Haste makes the spec more fluid and less punishing 

overall. As you get comfortable with the spec consider using the stats page

guidance for your stat priority.

### Blizzard   Combat Assistant

2.6.

#### Combat Assistant for Shadow Priest

The [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) is a way for newer players to drop into the 

 game without having to understand the full rotation priority list. After enabling 

 the feature you get access to a dynamically updating single-button assistant. This will 

 automatically rotate through your spells in a defined order.

As a Shadow Priest this assistant will not use all of your spells for you, just 

 the common rotational ones. You will need to weave in the following major cooldown 

 spells to get full use out of this tool:

- [[spell:228260]]
- [[spell:10060]]
- On-Use Trinkets
- Combat Potion: [[item:241308]]
- Racial abilities like [[spell:33697]] or [[spell:26297]]

By using this assistant and weaving in your cooldowns you'll be playing 

 as well as possible. The way the game balances this is by increasing the base

 global cooldown to slow down your gameplay. With this added in you can expect

 to be roughly 15% behind in DPS compared to someone playing without the assistant.

This tool is a great way to dive into the game, once you get comfortable try playing

 the rotation yourself to further improve your gameplay!

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Season 2 and Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **06 Apr. 2026:** Add a How to Improve Fast fieldset with core execution tips.
- **04 Apr. 2026:** Update talent builds after recent hotfixes.
- **18 Mar. 2026:** Update AoE build.
- **16 Mar. 2026:** Updated rotation section for Season 1.
- **26 Feb. 2026:** Updated Talent builds for Midnight launch.
- **10 Feb. 2026:** Updated Talent Trees for changes to class point gating.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **29 Aug. 2025:** Reviewed after the launch of Season 3.
- **07 Aug. 2025:** Update Voidweaver builds after Deathspeaker bug was fixed.
- **04 Aug. 2025:** Update for Patch 11.2.0.
- **15 Jun. 2025:** Add information about the Combat Assistant.
- **25 May 2025:** Reviewed information after recent hotfixes to still be accurate.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **13 Mar. 2025:** Remove Unfurling Darkness from the Voidweaver AoE build.
- **28 Feb. 2025:** Remove Unfurling Darkness from the Voidweaver Single Target build.
- **24 Feb. 2025:** Updated for 11.1.0 with new talent builds.
- **15 Dec. 2024:** Simplify the rotation section.
- **04 Nov. 2024:** Add easy to copy talent strings and updated Halo's position in the rotation section.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **06 Oct. 2024:** Update Voidweaver AoE build to default with Depth of Shadows.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated builds and rotation for the launch of The War Within.
- **13 Aug. 2024:** Update talent builds to start using Idol of C'Thun again and adjust for Class Tree changes.
- **25 Jul. 2024:** Update talent builds to not use Idol of C'Thun while it is still bugged.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **25 Apr. 2024:** Add new video playlist for Season 4.
- **22 Apr. 2024:** Update builds for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Update default build for Patch 10.2.5 to be more well rounded.
- **06 Nov. 2023:** Updated talent build and add rotational goals for Patch 10.2.0.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **13 Aug. 2023:** Update video link.
- **23 Jul. 2023:** Reviewed from the recent hotfixes.
- **10 Jul. 2023:** Add new talent strings for 10.1.5.
- **27 Jun. 2023:** Update default build.
- **20 Jun. 2023:** Add clarifying notes about Distorted Reality.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Update talents for 10.0.5 builds.
- **21 Dec. 2022:** Update talent suggestions to be simpler to start with.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **07 Nov. 2022:** Updated Marileth soulbind calc to remove Dissonant Echoes conduit.
- **31 Oct. 2022:** Updated talent builds to no longer suggest Psychic Link.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Shadow Priest in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Shadow Priest

As a Shadow Priest in Midnight Season 2, we

have the freedom to run either Hero Talent Tree, and both of 

them are very strong. We would strongly suggest starting out

with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver, and then adapting to 

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon should you want a more sustained damage pattern.

To see fully specialized builds in full detail for both 

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver, use the tool 

below to toggle recommendations based on your desired Hero 

Talent Tree. Note that whichever you pick will affect the 

<em>entire page</em> and information will be tailored to 

that selection.

:::details FAQShould I use the pre-tier builds if I am still on Season 1 tier or do not have any Season 2 tier?
If you are still using Season 1 tier or do not yet have any Season 2 tier, you
should avoid using the

[[spell:1242666]]

and

[[spell:1279354]]

builds.
Instead, drop those points in the builds that use them in favor of

[[spell:377349]]

and an appropriate point in the middle section of the tree.

:::

**Quick Start Import Codes:**

:::talents Shadow Raid - Archon
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA"
}
```
:::

:::talents Shadow AoE - Voidweaver
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::talents Shadow Delves - Voidweaver
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYmx2MYmZmZDZGLb0AMzMDAEgZb2WAzGDAMwMzMzMbMDmZwMYA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Archon

Raid

recommended

Mythic+

Delves

Voidweaver

Raid

Mythic+

recommended

Delves

recommended

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Raid Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Shadow Priests revolve around
casting [[spell:120644]] to empower [[spell:228260]].
Use this build as your default for most raid encounters.

:::details FAQWhat should I import if I do not have the Season 2 4-piece yet?
Use this alternate no-4pc import string:

:::talents Archon Raid - No 4pc Season 2
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAgxMMjx2MDzsNzwMjtZMmZmBmMwMNzAzAMzmZ0sZAIjxCAmBYMzMjZbMz2yAMDGA"
}
```
:::

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) Click for per-Boss Raid Talent Options
While the raid build above is your default for most encounters there are a
few talents swaps you can do to be more optimal.

1.1.1.

##### [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

This boss is pure single-target so we do not need to take [[spell:199484]].

:::talents Archon Raid - Sszorak
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMGz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA"
}
```
:::

- **Take**: [[spell:407469]]
- **Drop**: [[spell:199484]]

1.1.2.

##### [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)

This boss is a spread 2 target encounter, so we remove some of our
[[spell:1227280]] damage since we cannot hit both targets with slam.

:::talents Archon Raid - Entombed Sentinels
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMmZxMGbzMmZ2mBzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA"
}
```
:::

- **Take**: [[spell:407469]] and [[spell:377349]]
- **Drop**: [[spell:1242666]] and [[spell:1279354]]

1.1.3.

##### [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)

This boss is a 3 target encounter, so we can index more into
damage over time talents.

:::talents Archon Raid - Lost Explorers
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPAAAAAAAAAAAAghZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZMYMzMjZjZ2WGgZwA"
}
```
:::

- **Take**: [[spell:1242862]] x2 and [[spell:377349]]
- **Drop**: [[spell:391151]] x2 and [[spell:373212]] x1

1.1.4.

##### [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

This boss has a lot of multi-target and many adds that have a low amount of
health. For this reason you can choose to adjust a few talents depending on what
you are looking for.

Below string is the 3 target build and then drops [[spell:454001]]
in the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon tree for [[spell:449874]]. This is a minor
optimization that gives the raid more healing and more widespread add damage.
You typically are lining up [[spell:228260]] with the damage amp, which only
lasts 20 seconds, with nothing to hit after, so the extra duration is less useful.
For similar reasons you can also use [[spell:341240]] instead of
[[spell:341240]] for more burst in that window, but its generally a
loss of damage over the course of the fight.

On Heroic you can probably keep [[spell:391151]] and [[spell:373212]]
for more boss damage, but on Mythic I would consider using [[spell:1242862]]
and [[spell:377349]].

:::talents Archon Raid - Ulatek (Heroic)
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZZmxMz2MGzw2MzYmZGbIzYxMNAzAMziZY2MAkxYBAzMIjZmZMbMz2yAMTMA"
}
```
:::

:::talents Archon Raid - Ulatek (Mythic)
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPAAAAAAAAAAAAghZxMmZZmxMz2MGzw2MzYmZGbIzYxMNAzAMziZY2MAkxYBAzMGZMzMjZjZ2WGgZiB"
}
```
:::

- **Take**: [[spell:341240]], [[spell:449874]], [[spell:1242862]] x2 and [[spell:377349]]
- **Drop**: [[spell:341240]], [[spell:454001]], [[spell:391151]] x2 and [[spell:373212]] x1

:::

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Mythic+ Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon thrives when you need large sustained damage in AoE. If you
are just starting out in your Dungeons journey, or are just pugging keys in uncoordinated
groups it might feel a bit sluggish to start and you should consider trying out
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver instead.

I would suggest defaulting to [[spell:238558]] for most situations, but with enough setup
and good gameplay you can make [[spell:1279350]] work in Dungeons as well.

:::details FAQWhat should I import if I do not have the Season 2 4-piece yet?
Use this alternate no-4pc import string:

:::talents Archon AoE - No 4pc Season 2
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGbzMmZWmZYmx2MGzMzYDZGLmpBYGgZ2MjmNDAZMWAwMAjZmZMbjZ2WGgZwA"
}
```
:::

:::

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Delves Build

This build is specifically crafted for [Delves](<https://www.icy-veins.com/wow/delves-guide>) in Midnight Season 2.
The spec tree is near identical to the Dungeons build, but the Class tree has heavy
modifications to prioritize utility that is relevant in Delves.

- [[spell:205364]] - Can be used to take control over an extra enemy to
          help you progress through difficult sections.
- [[spell:9484]] - Hard crowd control ability to use where possible.
- [[spell:1250378]] - Turns [[spell:586]] into a mini-taunt, allows
          you to use either the Healing or Damage spec with Valeera.
- [[spell:528]] and [[spell:32375]] - Easily remove nasty debuffs on enemies.
- [[spell:213634]] - Easily get rid of any Diseases that you are afflicted with.
- [[spell:108942]] - Causes [[spell:586]] to also remove certain movement impairing effects.

**Note:** This build specifically drops [[spell:373466]] to pick up more utility.
If you are playing with another player consider adding this back into your talent tree.

[[spell:32379]] has been removed from this build since its damage contribution is
already quite low. This allows us to get even more utility talents.

:::details FAQWhat should I import if I do not have the Season 2 4-piece yet?
For Delves, use this alternate AoE no-4pc import string:

:::talents Archon Delves - No 4pc Season 2
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGbzMmZWmZYmx2MGzMzYDZGLmpBYGgZ2MjmNDAZMWAwMAjZmZMbjZ2WGgZwA"
}
```
:::

:::

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Raid Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Shadow Priests revolve around casting [[spell:263165]]
to create an [[spell:447444]] and cast as many [[spell:450405]] as possible.
Use this build as your default for most raid encounters.

:::details FAQWhat should I import if I do not have the Season 2 4-piece yet?
Use this alternate no-4pc import string:

:::talents Voidweaver Raid - No 4pc Season 2
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAgxMMjx2MDzsNzwMsNzMmZmxGyMWMTDwMzMAQAmtZbJY2YAmBYMzMjZbMDmZwMYA"
}
```
:::

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) Click for per-Boss Raid Talent Options
While the raid build above is your default for most encounters there are a
few talents swaps you can do to be more optimal.

1.4.1.

##### [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

This boss is pure single-target so we do not need to take [[spell:199484]].

:::talents Voidweaver Raid - Sszorak
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMjZGAAAAAAAAAAAAegZxMmZbmBz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGz2YGMzgZwA"
}
```
:::

1.4.2.

##### [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)

This boss is a spread 2 target encounter, so we remove some of our
[[spell:1227280]] damage since we cannot hit both targets with slam.

:::talents Voidweaver Raid - Entombed Sentinels
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMjZGAAAAAAAAAAAgxDMLmxYbmhZ2mZYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGz2YGMzgZwA"
}
```
:::

1.4.3.

##### [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)

This boss is a 3 target encounter, so we can index more into
damage over time talents.

:::talents Voidweaver Raid - Lost Explorers
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMj5BAAAAAAAAAAAAgZxMzMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stEMbMAwMMmZmxsNmBzMYGMA"
}
```
:::

:::

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Mythic+ Build

This build is your starting point for your journey into Dungeons,
or other AoE scenarios. While doing great AoE damage, these builds also deal great
priority target damage during AoE while also having decent single-target.

I would suggest defaulting to [[spell:238558]] for most situations, but with enough setup
and good gameplay you can make [[spell:1279350]] work in Dungeons as well.

:::details FAQWhy does this build not use [[spell:406788]]?
Right now

[[spell:8092]]

and even

[[spell:450405]]

are fairly
weak in comparison to other spells. On top of this

[[spell:406788]]

is in a tough spot to pickup as our top section of the talent tree is very
crowded, especially when it is gated behind

[[spell:199484]]

. In addition,
Mind Blast itself no longer generates a

[[spell:341491]]

, which
severely hurst the value of the spell. Luckily

[[spell:375888]]

helps make up for this loss.

:::

:::details FAQWhat should I import if I do not have the Season 2 4-piece yet?
Use this alternate no-4pc import string:

:::talents Voidweaver AoE - No 4pc Season 2
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGbzMmZWmZYmx2MGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB"
}
```
:::

:::

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Delves Build

This build is specifically crafted for [Delves](<https://www.icy-veins.com/wow/delves-guide>) in Midnight Season 2.
The spec tree is near identical to the Dungeons build, but the Class tree has heavy
modifications to prioritize utility that is relevant in Delves.

- [[spell:205364]] - Can be used to take control over an extra enemy to
          help you progress through difficult sections.
- [[spell:9484]] - Hard crowd control ability to use where possible.
- [[spell:1250378]] - Turns [[spell:586]] into a mini-taunt, allows
          you to use either the Healing or Damage spec with Valeera.
- [[spell:528]] and [[spell:32375]] - Easily remove nasty debuffs on enemies.
- [[spell:213634]] - Easily get rid of any Diseases that you are afflicted with.
- [[spell:108942]] - Causes [[spell:586]] to also remove certain movement impairing effects.

**Note:** This build specifically drops [[spell:373466]] to pick up more utility.
If you are playing with another player consider adding this back into your talent tree.

[[spell:32379]] has been removed from this build since its damage contribution is
already quite low. This allows us to get even more utility talents.

:::details FAQWhat should I import if I do not have the Season 2 4-piece yet?
For Delves, use this alternate AoE no-4pc import string:

:::talents Voidweaver Delves - No 4pc Season 2
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGbzMmZWmZYmx2MGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB"
}
```
:::

:::

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaDT7Uhx5NSWqMRdlksQ6GoQRRTDUEA-AAAA-CIMm0Ic4QhBQxS-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMmZWmxYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYGgxMzMmNmZbZAmBDA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx5NSqMRdZkksQ6GoQRRTDUEA-AAAA-CIMm0Ic4QhBQxS-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbjxMzyMGzM2mBzMzMbIzYZjGgZAmZzMMbGAyYsAgZGgZmZmZ2YmtlBYGMA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04c1py26+eoogawwYaeKUcI9J74C-ZaCT7Uhx5NSWqMdZkksQ6GoQRRTDUEA-AAAA-CIMm0Ic4QhBQxS-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAegZxMzMbzMmZ2mZGzw2MzYmZGbIzYxMNAzMzAABY2mtFwsxAADGzMzY2YGMzgZwA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaDT7Uhx159MRdlosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx15NRdlkosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYmx2MYmZmZDZGLb0AMzMDAEgZb2WAzGDAMwMzMzMbMDmZwMYA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04c1py26+eoogawwYaeKUMb6wz4C-ZaCT7Uhx15NRdlkosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

The builds listed above are popular recommendations,

covering various different loadouts suited to each style of endgame content.

Each Talent Build will have it's own rotation, and can also be manipulated 

further for specific types of content and to better benefit your group.

2.

### Omnium Folio

Added in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), the Omnium Folio unlocks after a short questline and

lets you choose from small, flexible bonuses. Some runes are geared toward throughput,

while others provide survivability and utility.

Use the order below as your default early progression path. Since Folio runes can be

swapped at any time, you can always adjust based on the encounter or your personal

preference once you are comfortable with the baseline picks:

1. [[spell:1279599]]
2. [[spell:1279603]]
3. [[spell:1287555]]
4. [[spell:1279609]]
5. [[spell:1279614]]

:::details FAQWhich secondary stat rune should I pick?
The generic answer as a Shadow Priest should be to default to the

[[spell:1279609]]

. While Haste and Mastery are our most desirable stats
as a Shadow Priest, at this point in the patch we have quite a lot of those already.
Since these runes give rating of stats that means they are subject to Diminishing Returns,
so the more of a stat you have the less value you get out of it. While you are gearing
up you might get more value out of Haste or Mastery runes, be sure to sim what makes sense
for your character.

:::

3.

### Apex Talent: ![Void Apparitions Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) Void Apparitions

The Apex Talents are available once you start leveling throughout Midnight, as a 

capstone in the spec tree. There are 4 total points to commit here, with the last

one being the most impactful.

- [[spell:1264096]]
- [[spell:1264104]] (2 points)
- [[spell:1264107]]

These talents do more than simply cap the tree with extra power, they actively reshape 

how we approach the rest of our build. While their baseline functionality may be straightforward, 

their downstream impact is where the real gameplay shift occurs.

One of the most noticeable effects is how strongly they incentivize investing in talents that 

enhance [[spell:341491]]. Due to this synergy we are strongly encouraged to

build around maximizing our [[spell:341491]] generation and damage, which in turn 

encourages us to take more talents that support this playstyle.

With the full power of all Apex talents you are also introduced to the new gameplay loop

with encouraging Idol spawns to proc more [[spell:341491]]. This becomes one of the

core gameplay loops of the spec in Midnight, where you want to generate as many Idol procs as 

possible to spawn more [[spell:341491]].

4.

### Hero Talents

Starting at level 71 you gain access to brand new Hero Talents. This is

where you get to pick between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon or ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Shadow Priest gameplay revolves around using 

[[spell:120644]] to empower your [[spell:228260]] and to cast extremely powerful

[[spell:391399]] spells.

Utility wise ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon gives you [[spell:453726]] for 

5% more stamina. This only applies to yourself as the Priest. For Mythic+ 

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon also brings important utility for your

group in the form of [[spell:453918]] for an extra stop.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Shadow Priests get access to [[spell:263165]] to 

create a heavy hitting [[spell:447444]] that pulses AoE damage to enemies 

in its radius. This then gives you access to an upgraded [[spell:8092]] in 

the form of [[spell:450405]] while the Rift is active. Voidweaver gets even 

better during raid encounters where you can take advantage of 

[[spell:451840]].

Utility of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver is much better compared to 

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon for Raiding as it not only has great self-defensive

options with [[spell:451311]] or [[spell:451569]] but also

grants cast while moving to [[spell:263165]] with [[spell:451018]].

5.

### Shadow Priest Choice Talent Nodes

This section is intended to give more context on the various choice 

nodes we have in the Shadow Priest spec tree and when each choice might 

make sense.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_priest_tentacleslam.jpg>) Click for Additional Talent Information
5.1.

#### Invoked Nightmare vs Misery

This is one of the most impactful and playstyle defining choice nodes in the 

Shadow Priest tree.[[spell:1279350]] and [[spell:238558]] fundamentally 

change how damage is ramped and applied, making this decision highly dependent on 

encounter structure and target longevity.

[[spell:1279350]] is best suited for low target count situations where 

enemies live long enough to justify manually applying [[spell:589]]. When these 

conditions are met, it offers a significant damage gain and rewards deliberate, 

methodical gameplay. While it can function in certain AoE scenarios, its effectiveness 

drops sharply if targets die too quickly, as the ramp time becomes a liability.

[[spell:238558]] is the preferred option for most dungeon and burst oriented environments. 

By automatically applying [[spell:589]] through [[spell:34914]], it removes a 

major setup cost and allows Shadow Priest to enter its damage profile much faster. This makes 

Misery the more practical and consistent choice in Mythic+ and any encounter where rapid 

target swapping or short-lived enemies are common.

5.2.

#### Improved Voidform vs Ancient Madness

This choice node directly augments [[spell:228260]] and is almost always 

taken for both power and pathing reasons, as it leads into key talents like 

[[spell:407470]] or [[spell:409044]]. While both talents modify the same 

cooldown, they cater to very different damage profiles and hero talent synergies.

[[spell:341240]] will generally not see much play, but can be more

burst in niche situations where you want to maximize the damage of a single [[spell:228260]]

window and cast more [[spell:1240401]].

[[spell:341240]] is our default starting in Season 2 and represents the 

[[spell:228260]] extension playstyle, 

increasing the base value of the cooldown and working well with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon.

This talent does not change how you play but will make our main cooldown feel

more impactful. This can also allow you to run slightly less haste than usual.

5.3.

#### Mind's Eye vs Distorted Reality

Modifying the way we spend Insanity can have large implications when it 

comes to playstyle and damage output, which is what makes [[spell:407470]] 

and [[spell:409044]] often a big choice to make in your build.

Builds that prefer [[spell:407470]] will typically already have a good

amount of Insanity generation so that you can keep up high uptime of 

[[spell:335467]] and also play off of interactions that reward more

casts of Shadow Word: Madness, such as generating [[spell:341491]] or

more [[spell:375767]] uptime.

On the other hand, builds that prefer [[spell:409044]] will

typically like this choice when you are looking to maximize uptime on

[[spell:335467]] (especially at lower gear levels). Distorted Reality

builds also can make more use of spreading Shadow Word: Madness in AoE situations

to take advantage of effects like [[spell:407469]] if you are

okay giving up some priority target damage.

5.4.

#### Deathspeaker vs Death and Madness

This choice node is currently one of the weakest points in the Shadow Priest tree 

due to the undertuned state of [[spell:32379]]. As a result, most builds will 

avoid both options unless forced by pathing or encounter specific add patterns. While 

[[spell:392507]] and [[spell:321291]] historically synergized well together, 

being mutually exclusive causes their value propositions to clash, limiting the 

effectiveness of either choice in practical play.

Between the two, [[spell:392507]] is generally the superior option when a 

point must be spent, largely because it enhances execute phase value and synergizes 

better with [[spell:34433]] starting at 35% health. This provides more consistent 

value in longer boss encounters where execute damage matters. [[spell:321291]], 

by contrast, is highly situational and primarily useful for encounters with frequent, 

predictable low health add spawns that can be reliably sniped.

6.

### Priest Class Talent Choices

While the builds above have sane defaults for Class Talents, this 

section will go in-depth about the various choices we have with class 

talents depending on the situation you are in.

6.1.

#### Always Use Class Talents

The following is a list of class talents I would always use as a 

Shadow Priest. These are useful in just about every situation in PvE 

and will be the core talents for any build.

- [[spell:8092]] - Baseline
- [[spell:8122]] - Baseline
- [[spell:121536]] and/or [[spell:64129]] - 
  
  Movement talents, typically I would suggest having both.
- [[spell:528]] and [[spell:73325]] - Useful 
  
  for pathing and great utility.
- [[spell:10060]] and [[spell:373466]] - 
  
  Damage cooldown and massive group throughput utility.
- [[spell:1250818]], [[spell:1251030]], 
  
  [[spell:1250820]], [[spell:1251077]], 
  
  [[spell:1251029]], [[spell:1249230]], and 
  
  [[spell:1250835]] all
  
  provide minor offensive or defensive benefits we always take.
- [[spell:32379]] is typically taken, in some cases 
  
  you can skip this but you then need to take [[spell:373218]].
- [[spell:390972]] - Execute damage that unlocks nodes 
  
  in the bottom section.
- [[spell:586]] - One of our most powerful utility and defensive spells.
- [[spell:368275]] into [[spell:19236]] for another defensive.
- [[spell:459559]] gives us a large increase in the range of our spells.
- [[spell:373446]] turns [[spell:586]] into a key defensive.

6.2.

#### Situational Class Talents

Now that you have an idea of the baseline suggested class talents, you can 

finish off your build based on the content that you are doing.

Depending on the specific raid boss or dungeon environment you should

tweak these choices based on what you need. In some situations, you

might need more utility, and for others, if you do not need that utility,

you can instead pick up more defensive choices.

The following talents are the utility choices we have as a Priest.

You should only take these if you need them; otherwise, fill out points 

elsewhere.

- [[spell:196704]] - Gives a reduction in the cooldown of 
  
  [[spell:8122]], which can be useful to get more AoE CC 
  
  available.
- [[spell:108942]] - Transforms [[spell:586]] to also break snare 
  
  effects. Note that this is different from root effects.
- [[spell:9484]] - Hard CC ability that works on Undead 
  
  or Aberration enemies.
- [[spell:1250691]] - AoE root ability for enemies 
  
  after [[spell:8122]] ends.
- [[spell:205364]] - Turns your [[spell:605]] spell
  
  into one that instead makes the enemy a pet. This can be particularly
  
  useful in some Mythic+ Dungeons. This node is also required for
  
  certain pathing decisions and is often taken for just that reason.
- [[spell:32375]] - Powerful dispel tool.
- [[spell:1250378]] can be useful while leveling.

Once you get all the utility points you need for the content you are 

doing, you can then add the defensive points you need. This part is tricky 

as depending on the content, this can vary wildly, but here are your options 

roughly ranked in terms of strength.

1. [[spell:390667]] - 4% magic damage reduction
2. [[spell:390670]] - Allows you to press [[spell:586]] 
   
   more often for the defensive value.
3. [[spell:193063]]
4. [[spell:238100]] - Can be useful depending on timings of a 
   
   mechanic you are trying to counter, but pathing into it can be 
   
   cumbersome.
5. [[spell:373450]] - Makes [[spell:19236]] stronger 
   
   but usually, this increase does not actually change what would be considered 
   
   lethal.
6. [[spell:108945]] - Inconsistent cheat death-like shield that
   
   usually does not proc when you actually need it.

:::

:::details FAQWhat If My Sim or Logs Disagree With the Recommended Talent Build?
Keep the recommended build as your default baseline, then adjust only the contested nodes and re-test.
When comparing options, check both sim output and log execution quality (cast counts, cooldown timing, and
DoT uptime) before concluding a build is worse. For advanced comparisons, use the public

[WarcraftPriests charts](<https://warcraftpriests.github.io/>)

and

[simulation repository](<https://github.com/WarcraftPriests/mid-shadow-priest>)

.

:::

7.

### PvP Talents (War Mode)

In the open world, you can go into "War Mode." Enabling War

Mode provides the following benefits:

- PvP talents enabled in the outdoor world.
- 10%+ increase in World Quest rewards at maximum level.
- 10%+ more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is

recommended enabling the feature to maximize your leveling and rewards at

maximum level. However, you will make yourself available for open-world PvP,

and the possibility of being "ganked" while leveling or doing World Quests

exists.

[Shadow Priest PvP guide](<https://www.icy-veins.com/wow/shadow-priest-pvp-guide>)

In this section, we will rank the PvP talents best for leveling and doing

solo / small group PvE content. Below is a ranking of

[Shadow Priest](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>)-specific

PvE talents.

- [[spell:199259]] gives you your cooldown back faster for better
  
  uptime.
- [[spell:199445]] is great for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon builds as 
  
  [[spell:391399]] stacks this up.
- The final choice is typically [[spell:357711]] for more overall 
  
  damage, although [[spell:375901]] or [[spell:211522]] can also be 
  
  considerations for more single-target.

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Update Voidweaver Raid builds.
- **01 Sep. 2026:** Add Ula'tek variation on the raid build.
- **25 Aug. 2026:** Add 3-target build for The Lost Explorers in the Raid sections.
- **11 Aug. 2026:** Add no-tier variants for all builds.
- **10 Aug. 2026:** Add back Haunting Shadows in the Archon Mythic+ build.
- **10 Aug. 2026:** Update for Season 2 and Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Omnium Folio information.
- **19 May 2026:** Update Voidweaver 3 target build.
- **22 Apr. 2026:** Add Phantasm for Deathspeaker Voidweaver build variant.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **10 Apr. 2026:** Update Voidweaver Raid builds.
- **09 Apr. 2026:** Add back dedicated 3 target builds for clarity.
- **09 Apr. 2026:** Remove Distorted Reality for 3 targe builds, simplify Voidweaver 3T setup.
- **08 Apr. 2026:** Remove Mind's Eye from Archon Raid build.
- **06 Apr. 2026:** Add FAQ guidance for sim and log-driven talent adjustments.
- **04 Apr. 2026:** Update Archon Raid and Mythic+ Builds and Voidweaver Mythic+ Build.
- **02 Apr. 2026:** Add Shadow Word Death build variant for Voidweaver Raid.
- **29 Mar. 2026:** Update 3 Target Talent build for Raiding.
- **22 Mar. 2026:** Add 3 Target build for Raiding.
- **18 Mar. 2026:** Update Mythic+ and Delve talent builds.
- **16 Mar. 2026:** Builds reviewed for launch of Season 1.
- **26 Feb. 2026:** Updated with new builds for the launch of the Midnight expansion.
- **10 Feb. 2026:** Updated Talent Trees for changes to class point gating.
- **23 Jan. 2026:** Added more FAQ entries for Pre-Patch.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **26 Aug. 2025:** Add video guide.
- **07 Aug. 2025:** Update Voidweaver builds after Deathspeaker bug was fixed.
- **04 Aug. 2025:** Update for Patch 11.2.0.
- **15 Jun. 2025:** Review information for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **02 Apr. 2025:** Update Archon Single Target builds to remove Yogg-Saron.
- **24 Feb. 2025:** Added new talent builds for 11.1.0.
- **15 Dec. 2024:** Suggest starting out with Archon builds for most content.
- **04 Nov. 2024:** Update Minds Eye vs. Distorted Reality section to be more clear.
- **21 Oct. 2024:** Swapped to using Sustained Potency by default for the pause mechanic out of combat for Archon builds.
- **10 Oct. 2024:** Use Mental Decay for Voidweaver builds and use Inescapable Torment for ST + Crash variant. UFD is now optional for Mythic+.
- **09 Oct. 2024:** Swap out Voidwraith for Depth of Shadows for Voidweaver Raid builds.
- **07 Oct. 2024:** Update talent builds from recent hotfixes.
- **15 Sep. 2024:** Refactor talent build section to be easier to use.
- **13 Sep. 2024:** Update default Delve build to use Archon.
- **09 Sep. 2024:** Add variant to Archon M+ build to get more single target.
- **31 Aug. 2024:** Update Voidweaver Single Target + Shadow Crash build, add Unfurling Darkness to Delve builds, and consolidate Archon AoE into one build.
- **25 Aug. 2024:** Add Delve build and Pre-Season Archon Dungeon variants and adjust percent difference for Archon vs. Voidweaver.
- **21 Aug. 2024:** Updated talent builds for the launch The War Within.
- **13 Aug. 2024:** Update talent builds to start using Idol of C'Thun again and adjust for Class Tree changes.
- **25 Jul. 2024:** Update talent builds to not use Idol of C'Thun while it is still bugged.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **30 Apr. 2024:** Add note about Maddening Touch in the Mythic+ build.
- **25 Apr. 2024:** Add new talent video.
- **22 Apr. 2024:** Update all builds for Season 4 and replace pathing sections with an in-depth Class Talent guide.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **13 Feb. 2024:** Update default class talents and utility choices in the Mythic+ build.
- **21 Jan. 2024:** Update 3-target council build from recent buffs.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **15 Jan. 2024:** Add optional change to the ST + Shadow Crash build and update the 3 target council build.
- **19 Dec. 2023:** Remove outdated section and adjust Mind Flay options.
- **18 Dec. 2023:** Update flex point talents in default Mythic+ build and update the 3 target council build.
- **18 Dec. 2023:** Add note for loss in ST on the Shadow Crash build.
- **12 Dec. 2023:** Update default Mythic+ build to not use Idol of Y'Shaarj.
- **03 Dec. 2023:** Update default Mythic+ build to use Mind Flay.
- **01 Dec. 2023:** Update 3 Target council build to default to Mind Flay.
- **17 Nov. 2023:** Update builds for 3 target and Mythic+ to be more streamlined.
- **14 Nov. 2023:** Add Mind Flay build option to the Single Target + Shadow Crash build.
- **06 Nov. 2023:** Update talent builds and suggestions for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Reorganize headers to be more readable and move talent spell breakdown.
- **18 Aug. 2023:** Correct typo in the description for the Triple Idol Dark Ascension build.
- **13 Aug. 2023:** Clarify note on Triple Idol setups in high keys and update video link.
- **08 Aug. 2023:** Fix issue where Dark Ascension Single Target build was not using Distorted Reality.
- **07 Aug. 2023:** Add new builds from the recent hotfixes.
- **31 Jul. 2023:** Swap to Distorted Reality by default for the Dark Ascension ST build.
- **25 Jul. 2023:** Add Dark Ascension + Shadow Crash build.
- **23 Jul. 2023:** Reviewed from the recent hotfixes. Noted difference in single target builds.
- **17 Jul. 2023:** Refactor to use new talent layout.
- **10 Jul. 2023:** Update talent strings for Patch 10.1.5.
- **28 Jun. 2023:** Swap out Malediction for Deathspeaker on the Dark Ascension build.
- **27 Jun. 2023:** Add new talent builds from the recent hotfixes.
- **23 Jun. 2023:** Adjust notes about Distorted Reality.
- **02 May 2023:** Small caveat to the flex points
- **01 May 2023:** Update talent builds for the 10.1.0 rework.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **04 Feb. 2023:** Update 2-target build and add a note about VF on single target.
- **24 Jan. 2023:** Update talent builds for Patch 10.0.5.
- **11 Jan. 2023:** Update Mythic+ talent builds from the recent changes.
- **23 Dec. 2022:** Update talent builds to account for Screams of the Void bug.
- **13 Dec. 2022:** Add alternate ST build that offers more burst.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **31 Oct. 2022:** Updated talent builds to no longer suggest Psychic Link and changed default Mythic+ build to Yogg-Saron.
- **26 Oct. 2022:** Updated talent builds from recent bug finding for Screams of the Void.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Shadow Priest in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Shadow Priest Gameplay and Rotation Guide

The [Shadow Priest](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>) rotation is a builder-spender playstyle focused on maintaining
damage-over-time effects and spending Insanity on [[spell:335467]]. Generate
Insanity with short-cooldown spells and spend it to refresh Madness while avoiding capping Insanity.

**TL;DR:** Keep [[spell:34914]] + [[spell:589]] up, spend Insanity on
[[spell:335467]] (refresh if less than 1 second remaining or Insanity deficit less than 35), use
[[spell:8092]] to avoid losing their cooldowns, and sync
[[spell:228260]] + [[spell:10060]] for burst windows.

For a video presentation on what's changing for Shadow Priest with Patch 
12.1, [check out this video from Publik](<https://www.youtube.com/watch?v=2OS9e2aMAlw>).

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver

Single Target

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:1279350]]

[[spell:238558]]

[[spell:407470]]

[[spell:409044]]

[[spell:228260]]

[[spell:1227280]]

[[spell:373310]]

[[spell:34433]]

[[spell:373427]]

[[spell:373202]]

[[spell:392507]]

[[spell:200174]]

[[spell:375888]]

[[spell:1264107]]

[[spell:1279353]]

[[spell:1296580]]

### Shadow Priest Explained

1.1.

#### Single-Target Rotation Goals for Shadow Priest

These goals describe the core spells that drive the priority list below.

1. **适用条件：Tentacle Slam（启用）。** Keep [[spell:34914]] and [[spell:589]] active at all times. Use [[spell:1227280]] to apply or refresh if available.
2. **适用条件：Tentacle Slam（未启用）。** Keep [[spell:34914]] and [[spell:589]] active at all times.
3. Maintain [[spell:335467]] uptime without capping Insanity.
4. **适用条件：Voidform（启用）。** Use short-cooldown Insanity generators (e.g., [[spell:1240401]] or [[spell:8092]]).
5. **适用条件：Voidform（未启用）。** Use short-cooldown Insanity generators (e.g., [[spell:8092]]).
6. **适用条件：Voidweaver（启用）。** Use long cooldowns (e.g., [[spell:263165]]) when they will not cause you to lose short-cooldown use.
7. **适用条件：Archon（启用）。** Use long cooldowns (e.g., [[spell:120644]]) when they will not cause you to lose short-cooldown use.
8. Fill with [[spell:15407]] when nothing higher priority is available.

**适用条件：Archon（启用）。**

:::details FAQShould I Always Finish a Mind Flay Cast?
No, you should not.

[[spell:15407]]

is regarded as a filler spell, which means
it is only used when nothing else more important can be cast. You typically want to
start thinking about recasting Mind Flay about halfway through the channel.

[[spell:391399]]

is only 1 GCD long and thus cannot be ended early.

:::

**适用条件：Archon（未启用）。**

:::details FAQShould I Always Finish a Mind Flay Cast?
No, you should not.

[[spell:15407]]

is regarded as a filler spell, which means
it is only used when nothing else more important can be cast. You typically want to
start thinking about recasting Mind Flay about halfway through the channel.

:::

If you can get these goals right, the Rotation should make more sense and fall into play naturally. The rest is just for min-maxing even further.

1.2.

#### AoE Rotation Goals for Shadow Priest

**适用条件：Tentacle Slam（未启用）。** **WARNING** [[spell:1227280]] is not selected in the table above, or you are not using an AoE preset. Please select this above to see an accurate advice for AoE. AoE content as a Shadow Priest without this will be torturous.

The Shadow Priest multi-target rotation is very similar to the single target priority list above, with only small differences. Our AoE damage is mostly unlocked by performing our single target rotation well. If you can do that well, you just need to maintain DoTs, and things should fall into place naturally.

During AoE, you will be using any tools you can to maintain [[spell:34914]] and [[spell:589]] on several targets. You should try to maintain these DoTs on up to 12 targets roughly. [[spell:1227280]] should be able to cover 6 stacked targets. You can initially get up to 12 dotted with 2 casts but will need to manually refresh to supplement large target counts in some situations. Do not bother manually DoTing any target that will not last for at least 18 seconds.

As a Shadow Priest you should lean into your strength of priority target damage while dealing AoE by funneling [[spell:335467]] casts into the highest health priority target enemy. Spreading this around can be an AoE increase though, but is not suggested in Mythic+. Check out the dedicated section on Shadow Word: Madness below to learn more.

**适用条件：Distorted Reality（启用）。** When using [[spell:409044]] you can optionally choose to spread [[spell:335467]] around by casting it on a new target each time you have enough Insanity to cast it. In certain cases this can result in an overall damage increase, particularly for long-lived targets.

1. **适用条件：Tentacle Slam（启用）。** Use [[spell:1227280]] to get your DoTs rolling. If this is on cooldown as you pull the pack, you need to do your best to DoT as many targets manually as possible while weaving in other spells.
2. At this point, your highest priority is maintaining DoTs. You should pick a main priority target to funnel in your [[spell:335467]] into. This is typically the target with the highest amount of health or a particularly powerful enemy.
3. **适用条件：Voidform（启用）。** Use short-cooldown Insanity generators (e.g., [[spell:1240401]] or [[spell:8092]]).
4. **适用条件：Voidform（未启用）。** Use short-cooldown Insanity generators (e.g., [[spell:8092]]).
5. **适用条件：Voidweaver（启用）。** Use long cooldowns (e.g., [[spell:263165]]) when they will not cause you to lose short-cooldown use.
6. **适用条件：Archon（启用）。** Use long cooldowns (e.g., [[spell:120644]]) when they will not cause you to lose short-cooldown use.
7. Fill with [[spell:15407]] when nothing higher priority is available.

### Single-Target Rotation

1.3.

#### Single-Target Opener for Shadow Priest

These openers assume no procs and are a brief snapshot of the rotation. Follow the priority list below for variations and proc-driven changes.

**适用条件：Priest Shadow 12.1 Class Set 4pc（启用）；Tentacle Slam（启用）。**

[[spell:8092]]

**适用条件：Tentacle Slam（未启用）。**

[[spell:34914]]

**适用条件：Tentacle Slam（启用）。**

[[spell:1227280]]

**适用条件：Invoked Nightmare（启用）。**

[[spell:589]]

**适用条件：Archon（启用）。**

[[spell:120644]]

**适用条件：Priest Shadow 12.1 Class Set 4pc（启用）。**

[[spell:1240401]]

**适用条件：Voidform（启用）。**

[[spell:228264]]

[[spell:10060]]

[[item:241288]]

[[item:250215]]

**适用条件：Priest Shadow 12.1 Class Set 4pc（未启用）。**

[[spell:1240401]]

[[spell:335467]]

**适用条件：Voidweaver（启用）。**

[[spell:263165]]

Before combat starts, make sure you have [[spell:232698]] and [[spell:21562]] active.

1. **适用条件：Tentacle Slam（未启用）。** Pre-Cast [[spell:34914]].
2. **适用条件：Priest Shadow 12.1 Class Set 4pc（启用）；Tentacle Slam（启用）。** Pre-Cast [[spell:8092]].
3. **适用条件：Tentacle Slam（启用）；Priest Shadow 12.1 Class Set 4pc（未启用）。** Pre-Cast [[spell:1227280]].
4. **适用条件：Tentacle Slam（启用）；Priest Shadow 12.1 Class Set 4pc（启用）。** Cast [[spell:1227280]].
5. **适用条件：Invoked Nightmare（启用）。** Cast [[spell:589]].
6. **适用条件：Archon（启用）。** Cast [[spell:120644]].
7. **适用条件：Priest Shadow 12.1 Class Set 4pc（启用）。** Cast [[spell:1240401]].
8. **适用条件：Voidform（启用）。** Cast [[spell:228260]].
9. Use any on-use Trinkets you have equipped.
10. Use [[item:241288]].
11. Cast [[spell:10060]] and any stat-based racial abilities. Make sure to cast Power Infusion on an ally if using [[spell:373466]].
12. **适用条件：Priest Shadow 12.1 Class Set 4pc（未启用）。** Cast [[spell:1240401]].
13. Cast [[spell:335467]].
14. **适用条件：Voidweaver（启用）。** Cast [[spell:263165]].
15. Continue with the priority list as described below.

1.4.

#### Single Target Priority List for Shadow Priest

Below is a condensed priority list to use as your baseline for single-target fights. For a gentler introduction, see the [Beginner page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>).

1. **适用条件：Misery（启用）；Tentacle Slam（未启用）。** Keep [[spell:34914]] and [[spell:589]] active by using Vampiric Touch to apply both DoTs. Refresh these during the proper pandemic window (see below).
2. **适用条件：Invoked Nightmare（启用）；Tentacle Slam（未启用）。** Keep [[spell:34914]] and [[spell:589]] active. Refresh these during the proper pandemic window (see below).
3. **适用条件：Misery（启用）；Tentacle Slam（启用）。** Keep [[spell:34914]] and [[spell:589]] active by using Vampiric Touch to apply both DoTs. Use [[spell:1227280]] if available when you need to refresh [[spell:34914]]. Refresh these during the proper pandemic window (see below).
4. **适用条件：Invoked Nightmare（启用）；Tentacle Slam（启用）。** Keep [[spell:34914]] and [[spell:589]] active. Use [[spell:1227280]] if available when you need to refresh [[spell:34914]]. Refresh these during the proper pandemic window (see below).
5. **适用条件：Archon（启用）。** Cast [[spell:120644]].
6. **适用条件：Voidform（启用）。** Cast [[spell:228260]].
7. Cast [[spell:10060]].
8. Sync any trinkets you have with your cooldowns (see trinket section).
9. **适用条件：Voidweaver（启用）。** Cast [[spell:32379]] if the target has an absorb shield for [[spell:451840]].
10. **适用条件：Mind Devourer（未启用）。** Maintain [[spell:335467]] uptime without capping Insanity. Refresh it when it is about to expire, when you are closing to capping Insanity, or while in [[spell:228260]] to keep the burst window active. Pool Insanity if Voidform will be available in 25 seconds or less.
11. **适用条件：Mind Devourer（启用）。** Maintain [[spell:335467]] uptime without capping Insanity. Refresh it when it is about to expire, when you are closing to capping Insanity, [[spell:373202]] is active, or while in [[spell:228260]] to keep the burst window active. Pool Insanity if Voidform will be available in 25 seconds or less.
12. **适用条件：Voidweaver（启用）。** Cast [[spell:450405]] while available if [[spell:335467]] is active or [[spell:447444]] is about to expire.
13. **适用条件：Tentacle Slam（启用）。** Cast [[spell:1227280]] if you are about to cap on charges or [[spell:34914]] is not active.
14. **适用条件：Voidweaver（启用）。** Cast [[spell:263165]] to open up [[spell:447444]].
15. Cast [[spell:8092]].
16. **适用条件：Tentacle Slam（启用）；Void Apparitions（启用）。** Fully consume [[spell:1227280]] charges if adds are not coming soon you need to hold a charge for.
17. **适用条件：Archon（启用）。** Cast [[spell:391399]] if [[spell:335467]] is active.
18. **适用条件：Idol of Y'Shaarj（启用）；Shadowfiend（启用）；Inescapable Torment（启用）；Deathspeaker（未启用）。** Cast [[spell:32379]] if any pet is active or the target is below 20% health.
19. **适用条件：Idol of Y'Shaarj（启用）；Shadowfiend（启用）；Inescapable Torment（启用）；Deathspeaker（启用）。** Cast [[spell:32379]] if any pet is active or the target is below 35% health.
20. **适用条件：Deathspeaker（未启用）。** Cast [[spell:32379]] if the target is below 20% health.
21. **适用条件：Deathspeaker（启用）。** Cast [[spell:32379]] if the target is below 35% health.
22. **适用条件：Voidform（启用）。** Cast [[spell:1240401]].
23. Cast [[spell:15407]]. Interrupt this for any other action as it becomes available.
24. **适用条件：Shadowfiend（未启用）。** Cast [[spell:32379]] for movement if you have nothing else to press.

:::details FAQWhen Should I Refresh My DoTs?
[[spell:34914]] and [[spell:589]] both benefit from
something called 'Pandemic.' You can refresh both DoTs
at 30% or less of their duration without getting penalized. What this
essentially does is extend the window you have to refresh your
DoTs. As an example, Shadow Word: Pain lasts for 16 seconds (without [[spell:238558]]),
so its Pandemic is
4.8 seconds. In other words, the best time to refresh Shadow Word: Pain is when
it has 4.8 or fewer seconds left. Doing so at or below this threshold
will add the remaining time to the original duration. If you were to refresh
Shadow Word: Pain when it has 3 seconds left; that would leave the new duration
at 19 seconds, as an example.

With [[spell:238558]] talented [[spell:34914]] and [[spell:589]]
both have a duration of 21 seconds, so their pandemic threshold is 6.3 seconds.

[[spell:335467]] is a unique DoT that benefits from specific
refresh mechanics. [[spell:335467]] rolls over damage when refreshed,
meaning that whatever damage the DoT has left when you refresh the DoT gets
carried over and added as a multiplier to the new DoT's ticks. As such,
refreshing has no "cost" associated, even though we spent the Insanity
to cast the spell. This should not change your rotation much; just do
not feel you have to wait for the current DoT to finish before recasting
it.
You still want to try and refresh around 1s remaining to get maximum
DoT uptime for our [[spell:343690]]. It will add the time
to the next tick to the new DoT so that you do not miss a tick.

:::

### AoE Rotation

1.5.

#### AoE Opener for Shadow Priest

**适用条件：Tentacle Slam（未启用）。** **WARNING** [[spell:1227280]] is not selected in the table above, or you are not using an AoE preset. Please select this above to see an accurate advice for AoE. AoE content as a Shadow Priest without this will be torturous.

This is meant as a very basic example for opening on a pack in an AoE environment. The exact mob count and the way the mobs are grouped will naturally change what you will do from pull to pull, especially depending on your cooldown state. Use this as a starting point along with the general priority list.

Before combat starts, make sure you have [[spell:232698]] and [[spell:21562]] active.

**适用条件：Invoked Nightmare（启用）。**

[[spell:589]]

**适用条件：Misery（启用）。**

[[spell:34914]]

**适用条件：Tentacle Slam（启用）。**

[[spell:1227280]]

**适用条件：Archon（启用）。**

[[spell:120644]]

**适用条件：Priest Shadow 12.1 Class Set 4pc（启用）。**

[[spell:1240401]]

**适用条件：Voidform（启用）。**

[[spell:228264]]

[[spell:10060]]

[[item:241288]]

[[item:250215]]

**适用条件：Priest Shadow 12.1 Class Set 4pc（未启用）。**

[[spell:1240401]]

[[spell:335467]]

**适用条件：Voidweaver（启用）。**

[[spell:263165]]

1. **适用条件：Invoked Nightmare（启用）。** Cast [[spell:589]] on any targets as the pack is being grouped up with [[spell:586]].
2. **适用条件：Misery（启用）。** Cast [[spell:34914]] on any targets as the pack is being grouped up with [[spell:586]].
3. **适用条件：Tentacle Slam（启用）。** Cast [[spell:1227280]] to put up DoTs on targets once everything is grouped. Consider using both charges if the pack is big enough and you have them available.
4. **适用条件：Archon（启用）。** Cast [[spell:120644]] once all mobs are engaged in combat and within range.
5. **适用条件：Priest Shadow 12.1 Class Set 4pc（启用）。** Cast [[spell:1240401]] to be able to cast [[spell:228260]].
6. **适用条件：Voidform（启用）。** Cast [[spell:228260]].
7. Use your combat potion [[item:241288]] unless you want to save for an upcoming pack or boss.
8. Use [[spell:10060]] and any stat-based racial abilities. Make sure to cast Power Infusion on an ally if using [[spell:373466]].
9. **适用条件：Priest Shadow 12.1 Class Set 4pc（未启用）。** Cast [[spell:1240401]].
10. Cast [[spell:335467]].
11. **适用条件：Voidweaver（启用）。** Cast [[spell:263165]].
12. Continue with the Rotation as normal.

**适用条件：Tentacle Slam（启用）。** Note if the pack has more than 6 targets or they are too spread for [[spell:1227280]] You should do your best to pull with the tank by using [[spell:586]] to not get aggro but still putting your DoTs up as the pack gets pulled.

1.6.

#### AoE Priority List for Shadow Priest

If you are looking for something easier to digest or you are just getting started, I strongly suggest looking at the [Beginner page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>) page. The rotation guide below is meant for advanced users who want to min/max their Rotation as much as possible.

When dealing damage in AoE, it is crucial to make sure you are casting spells onto targets that have [[spell:335467]] active. This ensures the damage from [[spell:199484]] is being boosted as much as possible through spells like [[spell:343690]] or [[spell:373212]].

1. **适用条件：Misery（启用）；Tentacle Slam（未启用）。** Keep [[spell:34914]] and [[spell:589]] active by using Vampiric Touch to apply both DoTs. Refresh these during the proper pandemic window (see below).
2. **适用条件：Invoked Nightmare（启用）；Tentacle Slam（未启用）。** Keep [[spell:34914]] and [[spell:589]] active. Refresh these during the proper pandemic window (see below).
3. **适用条件：Tentacle Slam（启用）；Misery（启用）。** Keep [[spell:34914]] and [[spell:589]] active by using Vampiric Touch to apply both DoTs. Use [[spell:1227280]] if available when you need to refresh [[spell:34914]]. Refresh these during the proper pandemic window (see below).
4. **适用条件：Tentacle Slam（启用）；Invoked Nightmare（启用）。** Keep [[spell:34914]] and [[spell:589]] active. Use [[spell:1227280]] if available when you need to refresh [[spell:34914]]. Refresh these during the proper pandemic window (see below).
5. **适用条件：Archon（启用）。** Cast [[spell:120644]].
6. **适用条件：Voidform（启用）。** Cast [[spell:228260]].
7. Cast [[spell:10060]].
8. Sync any trinkets you have with your cooldowns (see trinket section).
9. **适用条件：Voidweaver（启用）。** Cast [[spell:32379]] if the target has an absorb shield for [[spell:451840]].
10. **适用条件：Mind Devourer（未启用）；Distorted Reality（未启用）。** Spend Insanity on [[spell:335467]] with high priority if it is not active, about to expire, or you are about to cap out on Insanity. For more AoE damage you can cast this on a new target each time you get enough resources for more AoE damage.
11. **适用条件：Distorted Reality（启用）；Mind Devourer（未启用）。** Spend Insanity on [[spell:335467]] with high priority if it is not active, about to expire, or you are about to cap out on Insanity. Cast this on a new target each time you get enough resources for more AoE damage.
12. **适用条件：Mind Devourer（启用）；Distorted Reality（未启用）。** Spend Insanity on [[spell:335467]] with high priority if it is not active, about to expire, you are about to cap out on Insanity, or [[spell:373202]] is active.
13. **适用条件：Distorted Reality（启用）；Mind Devourer（启用）。** Spend Insanity on [[spell:335467]] with high priority if it is not active, about to expire, you are about to cap out on Insanity, or [[spell:373202]] is active. Cast this on a new target each time you get enough resources for more AoE damage.
14. **适用条件：Voidweaver（启用）。** Cast [[spell:450405]] while available if [[spell:335467]] is active or [[spell:447444]] is about to expire.
15. **适用条件：Tentacle Slam（启用）。** Cast [[spell:1227280]] if you are about to cap on charges or [[spell:34914]] is not active.
16. **适用条件：Voidweaver（启用）。** Cast [[spell:263165]] to open up [[spell:447444]].
17. **适用条件：Invoked Nightmare（启用）。** Cast [[spell:589]] on any targets if not active and will live for at least 12 seconds.
18. Cast [[spell:8092]].
19. **适用条件：Archon（启用）。** Cast [[spell:391399]] if [[spell:335467]] is active.
20. **适用条件：Inescapable Torment（启用）；Shadowfiend（启用）；Idol of Y'Shaarj（启用）；Deathspeaker（未启用）。** Cast [[spell:32379]] if any pet is active or the target is below 20% health.
21. **适用条件：Inescapable Torment（启用）；Deathspeaker（启用）；Shadowfiend（启用）；Idol of Y'Shaarj（启用）。** Cast [[spell:32379]] if any pet is active or the target is below 35% health.
22. **适用条件：Deathspeaker（未启用）。** Cast [[spell:32379]] if the target is below 20% health.
23. **适用条件：Deathspeaker（启用）。** Cast [[spell:32379]] if the target is below 35% health.
24. **适用条件：Voidform（启用）。** Cast [[spell:1240401]].
25. Cast [[spell:15407]]. Interrupt this for any other action as it becomes available.
26. **适用条件：Shadowfiend（未启用）。** Cast [[spell:32379]] for movement scenarios when you do not have other instant cast spells to press.

:::details TipsSpreading [[spell:589]] without [[spell:238558]]
If you choose to play with

[[spell:1279350]]

instead of

[[spell:238558]]

you will get a lot of benefit maintaining

[[spell:589]]

. With these builds it is essential that you use
your time as the pack is gathering to apply these DoTs manually
to as many targets as possible, and then once grouped you can
use

[[spell:1227280]]

to get

[[spell:34914]]

rolling as well.
Once you have access to the new Apex Talents this should be enough to sustain
you throughout most of the pull.

:::

In addition to the AoE priority list above, keep in mind these important target swaps:

- 12+ targets: Threshold for manually DoTing targets, typically not worth ever going over this unless it is as the pack is being gathered with [[spell:586]] (including the 6 from [[spell:1227280]]).

For specific tips about playing [Shadow Priest](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>) in Mythic+, feel free to check out that dedicated page below. From a rotation standpoint, things will follow the priority list above.

[Shadow Priest Mythic+ guide](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)

2.

### Midnight Season 2 Tier Set

During Midnight Season 2 of Midnight you will gain access to the following 
Tier Set Bonuses:

- [[spell:1296579]]
- [[spell:1296580]]

This tier set is important rotationally for a few reasons:

- It is more important to use [[spell:1227280]] more often to prevent 
      sitting at max charges of the spell now that the cooldown is shorter with the 
      [[spell:1296579]].
- When you get access to the [[spell:1296580]], you will
      need to weave in [[spell:1240401]] into your normal rotation to get the most 
      out of the set bonus, even outside of [[spell:228260]]. Treat this as your 
      highest priority spell behind capping Insanity.
- Due to the buff from the 4pc resetting on combat start you should avoid
      using [[spell:1227280]] as your pre-pull opener. Instead opt to pre cast
      [[spell:8092]] once you get the tier set and then go into your first 
      [[spell:1227280]].

3.

### Trinket Usage

Any on-use trinket offering a stat bonus should ideally be used
inside your cooldowns to get the most benefit. Any exceptions to this are
noted below.

1. [[item:270169]] should be used during [[spell:10060]] when you 
       have more than 5 stacks of [[spell:1307470]] or if the encounter is ending
       in less than 30 seconds.
2. [[item:270602]] should be used every one minute.
3. [[item:250215]] is used like any other trinket as if it had a 2-minute cooldown.
4. **DEFAULT**: Sync all other trinkets with [[spell:228260]] or [[spell:10060]].
   If the cooldown is a minute or less, use it on CD. Lastly, use it if the fight will
   end before your cooldowns will come back up.

For any on-use trinkets that strictly deal damage, you want to try using these
on cooldown as much as possible. Trinkets that deal Shadow damage are buffed by
[[spell:447444]] with [[spell:449880]], so try to line up those casts with
those trinket uses. Note that Shadow damage also buffs Chaos, Cosmic, Plague, Shadowflame,
Shadowfrost, Spellshadow, Shadowstrike, or Twilight damage types.

4.

### Class and Spec Mechanics Explained

### [[spell:8092]]

4.1.

#### Mind Blast

[[spell:8092]] is one of our main rotational abilities where the goal
is not to lose any potential casts on the spell in most cases. With [[spell:406788]]
this is made much easier by giving us 2 charges of the spell. Since only one
charge can cool down at a time, we prioritize casting Mind Blast more only when
you are capped on charges, which in this case is 2 charges.

In addition to the normal gameplay, we also have access to
[[spell:375888]] spec talent, which is taken in almost all
scenarios. The important thing to understand about these procs is
that they do not specifically change your rotational priority.
This is because Shadowy Insight procs grant you a full temporary charge
of [[spell:8092]], so it can be used whenever you would normally use
a cast of Mind Blast.

The other important rotational note with [[spell:8092]]
specifically concerns the usage of the spell as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver.
Since Mind Blast is transformed into [[spell:450405]] while
[[spell:447444]] is active we want to make sure and get as
many casts out of the spell as possible.

From an opener standpoint, if you have the Season 2 4-piece bonus, 
your first spell should be [[spell:8092]], followed by your 
first [[spell:1227280]]. This keeps the burst windows clean and avoids 
losing value from the reset effect at combat start.

### [[spell:335467]]

4.2.

#### Shadow Word: Madness

[[spell:335467]] is a relatively unique DoT that works differently
from [[spell:34914]] or [[spell:589]]. As such, you must
understand how it works at a high level to avoid misuse of its unique effects.

When refreshing [[spell:335467]], it rolls over any damage remaining
on the future ticks and adds that in the form
of a modifier to the new DoT ticks. This effectively means that when you are
in a case where you often hit or get close to 100 Insanity (referred to as
capping), you can freely refresh Shadow Word: Madness and not lose any damage,
assuming the target lives for the entire DoT duration. It is important to note
that no part of this process is snapshotting stats but instead converting
future damage ticks into a modifier value to the new ticks. Because of this
period, Intellect and Haste's changes do not change how the rollover happens; it
always works the same way regardless.

While the damage does roll over regardless of when you use
[[spell:335467]] the exact timing of the refresh is important. Shadow
Priests Mastery, [[spell:343690]], benefits from uptime of
Shadow Word: Madness. So to get the most damage out of the DoT, you want to
only refresh the DoT when it has less than a GCD remaining, or you are getting
close to capping on Insanity (deficit of ~35 or less) to get maximum damage
out of our Mastery. Furthermore, playing like this also gets the most value
out of the [[spell:373212]] talent if you are using that.

This mechanic is mostly passive but can be used to your advantage to burst
down a specific target. By banking up 100 Insanity (or 150 with
[[spell:407430]]) you can use multiple [[spell:335467]] casts back to
back and get a new DoT with much more powerful ticks in the same amount of time
as a single [[spell:335467]]. Otherwise, if your target lives, you
should always prioritize keeping the DoT active on the target for as long as
possible for maximum benefit with our Mastery. While maximizing this, make sure
you are also NOT capping on Insanity. Juggling these two conditions will be how
you master this spell.

For most types of content, you should play completely normally; there is
nothing to game with how this works unless you are trying to burst something
down specifically. Just play normally and enjoy not losing damage when you
would have otherwise capped Insanity.

If you want to see this change explained in video form, I go over this in
more detail in [this video](<https://youtu.be/5PBi816Qy5w>).

4.2.1.

##### Multi-Target

The way you play with [[spell:335467]] strictly depends
on what you want to prioritize: overall AoE damage or priority target
damage. Both of these are viable strategies and can be used with
just about any talent combination.

To prioritize overall AoE damage you can **spread**
[[spell:335467]]. This is done by simply casting Shadow Word: Madness
on a new target every time you get enough Insanity and then using that
as your new main target until you build up enough Insanity to restart
the process. This playstyle works particularly well with talents like
[[spell:409044]] and [[spell:407469]], but these
are not necessarily required to see gains with this playstyle. While
Shadow Word: Madness does roll its damage over when re-applying; you can
end up losing out on damage depending on when targets die. By spreading
the DoT around to whatever is the current highest health target, you can
see gains from this playstyle.

Alternatively, you can choose to increase your priority target
damage while in AoE but funneling casts of [[spell:335467]]
onto the most important mob of a pack. This damage pattern is less
commonly found in other specs in the game, which makes Shadow Priest,
in particular, highly desired in high-end key compositions. Often, packs
have a few priority target mobs that either have more health
than most of the pack or perhaps have a set of deadly abilities that
make it important to kill the mob first. This playstyle typically
prefers running [[spell:407470]] to get more casts off of Shadow Word: 
Madness in a dungeon.

:::details FAQDoes Applying DoTs to Secondary Targets Increase Single-Target DPS?
It depends on talents and desired outcome. Spreading DoTs gives more proc opportunities (with
decay), while funneling increases priority-target damage. Decide based on talents like

[[spell:391228]]

,

[[spell:155271]]

, and your group's strategy.

:::

### [[spell:586]] Pulling

4.3.

#### Fade Pulling

For dungeon pulls specifically, you should always be pulling WITH the tank,
not after. By getting proper setup as the tank is pulling by putting up
[[spell:34914]] ASAP, you will further increase the damage to the pack
without suffering from loss in casting our Insanity spenders. This is only
possible by using [[spell:586]] as a threat drop, as the tank is pulling to be
able to DPS before the threat is fully established. Mastering this is crucial to
doing well in Mythic+.

Typically, we only maintain DoTs up to 12 targets during a pull (6 from
[[spell:1227280]] and up to 6 from manual [[spell:34914]]). You can
double cast if the investment is worth. By pulling
with the tank this allows you to get more manual Vampiric Touch DoTs out
to increase the number of targets we can sustain our damage on.

:::details FAQHow Do I Handle Unavoidable Movement Without Losing Too Much Damage?
Use a stutter-step approach: move in small bursts between globals and prioritize instant casts while moving,
such as

[[spell:1240401]]

,

[[spell:32379]]

,

[[spell:335467]]

, and

[[spell:375888]]

procs. If no instant casts are available, use

[[spell:589]]

as your fallback
instead of fully stopping your rotation.

:::

:::details Log Review Checklist for Rotation Improvement
- Compare against a similar kill time and similar gear level before drawing conclusions.
- Check cast counts first for key spells and cooldowns like [[spell:228260]] and [[spell:10060]].
- Check DoT uptime ([[spell:589]] and [[spell:34914]]) and major buff windows.
- Review cooldown timing, potion usage, and trinket alignment with encounter phases.

:::

### [[spell:373273]]

4.4.

#### Idol of Yogg-Saron

[[spell:373273]] is a common question when looking to maximize
damage on your Shadow Priest. In particular, getting this to proc at better
points can be advantageous if you can play around it cleanly, particularly
in Mythic+ environments.

Every time you generate a [[spell:341491]] you generate a stack
of [[spell:373273]]. Unfortunately,
we do not have too much control over this as so many of our spells generate Apparitions,
but you can choose to sacrifice your damage at the end of one pack to try and
game the proc to happen at the start of the next one.

Crucially if you are trying to game the proc of [[spell:373273]]
you need to think about this earlier than you might think. Due to
[[spell:391284]] proccing randomly while you have your [[spell:589]]
active you can easily proc this a few times if you are trying to save for the next pull.
As such, waiting at 24 stacks is never suggested; you would always need to plan
earlier than that, likely around 20 stacks.

Note that while you can cancel the buff for building up [[spell:373273]]
this is almost never going to be worth it from an overall DPS perspective. Be
extra careful with these micro-optimizations of the spell, as if done incorrectly,
you can lose quite a lot of damage.

### Apex Talent: [[spell:1264096]]

4.5.

#### Void Apparitions

Our Apex Talents are largely passive, but importantly buff the things we 
already care about pressing. The core gameplay loop enabled by [[spell:1264096]] 
is wanting to generate as many Idol procs as possible to then get 
[[spell:341491]].

The best way to play around this is by simply playing normally. We will 
naturally be generating lots of Idol procs by doing so. The important thing to
keep in mind is to never let [[spell:1227280]] cap on charges, especially 
during cooldowns. In addition, you should feel free to be more liberal with the 
cooldown usage inside of your main cooldowns to get optimal damage.

5.

### Important Cooldowns for Shadow Priest

### [[spell:228260]]

5.1.

#### Voidform

[[spell:228260]] is one of Shadow Priest's Major Cooldown abilities. 
This is a 2-minute cooldown that syncs nicely with [[spell:10060]] 
and gives you access to [[spell:1240401]].

For the basic rotation, the main idea is simple: line up [[spell:228260]] with 
[[spell:10060]] and with any major trinket windows, then spend the burst cycle 
efficiently. This is the main burst window that Shadow Priest is optimizing around, so 
do not treat it as a standalone cooldown that is safe to leave unsynced.

This cooldown gives you access to:

- 3 charges of [[spell:1240401]] (An additional 2 charges is added when using [[spell:341240]]).
- Spells deal damage as if [[spell:343690]] is fully stacked.
- +5% damage with [[spell:453917]] (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon)
- +5% damage (An additional +5% is added when using [[spell:341240]])
- Replaces [[spell:232698]] (cancelling out the damage increases)

Another key part of [[spell:228260]] is the [[spell:341240]] talent which adds
the buff extension mechanic and stacking haste to the spell. This talent increases the duration of Voidform
for every cast of [[spell:335467]] while in Voidform.

5.1.1.

##### Void Volley

[[spell:1240401]] is an instant, charge-based spell that you gain access to during
[[spell:228260]] and can also become a regular rotational button with your set bonuses.
As a baseline, treat it as a low-priority cast: it does not have a cooldown so your
goal is to simply use all charges before the end of Voidform.

**Advanced Optimization:** If you want to optimize further, bank
charges for your [[spell:453845]] window, then dump charges once [[spell:228260]]
is within a Halo cycle, while in Voidform, or if you are about to overcap value.

- **No [[spell:453845]]:** Cast [[spell:1240401]] freely.
- **With [[spell:453845]]:** Bank [[spell:1240401]] for the buff window when possible.
- **Dump triggers:** [[spell:228260]] in less than 60 seconds, currently in [[spell:228260]], [[spell:453845]] damage buff active, [[spell:1279354]] at 4+ stacks, or fight ending (less than 45 seconds).

### [[spell:10060]]

5.2.

#### Power Infusion

In addition to our core cooldown choice, you also gain access to [[spell:10060]]. This is
a 2-minute cooldown spell, so it naturally syncs with every cast of [[spell:228260]]. This 
cooldown simply gives you a Haste buff for the duration.

This becomes one of the most powerful external buffs in the game with [[spell:373466]]
talent in our class tree, allowing you to give someone else [[spell:10060]] and then also
get the buff yourself. This is critically important as a Shadow Priest when playing in a group
environment, as this can easily be an extra 4-5% DPS increase for your group as a whole, depending
on who you are buffing.

Shadow Priest is on somewhat strict timers and likes to use [[spell:10060]] on cooldown.
This can influence the choice we make on who we give Power Infusion to so that ideally we can
continue casting it when it is best for us. Here is a list of strong targets for Power Infusion on
2-minute timers.

1. [Windwalker Monk](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-guide>)
2. [Devastation Evoker](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-guide>) (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper)
3. [Affliction Warlock](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-guide>)
4. [Marksmanship Hunter](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-guide>) (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel)
5. [Devourer Demon Hunter](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-guide>)

Note that this list assumes equal play among players to give the buff to, which is not always a
good assumption. Sometimes, it makes more sense to buff up the best person in your raid rather than
simply buffing what is a good spec for [[spell:10060]].

### [[spell:120644]]

5.3.

#### Halo

If you are playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon you gain access to [[spell:120644]]. 
This spell is used on cooldown so it is important to know where it fits into 
the Rotation.

Since [[spell:120644]] has a cast time and is cast twice as often as
[[spell:228260]], the cooldown will get slightly desynced over the
course of a pull. This is normal, you will just cast it slightly 
further into Voidform over time.

### [[spell:263165]]

5.4.

#### Void Torrent

[[spell:263165]] is a powerful talent that is available to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver
Shadow Priests. This is a fixed 3-second channeled spell that adds
more ticks of damage as you get more Haste. The Insanity generation is always
fixed regardless of how many ticks you get.

Notably, this spell does not snapshot with any part of our kit; each tick
re-checks modifiers like [[spell:343690]].

The main driver of this spell is that at the start of the cast it spawns an 
[[spell:447444]] and then refreshes it to the full duration when the channel
of [[spell:263165]] ends.

From a rotational perspective, be sure to keep these tips in mind:

- Be sure to have [[spell:335467]] active before casting the channel.
- Prioritize using this early on in your burst windows so that the high
      Insanity generation can fuel your opening burst longer.
- In AoE environments, you can choose to hold for up to 10 seconds if you know
      you will need AoE burst coming up for a pack.

### [[spell:1227280]]

5.5.

#### Tentacle Slam

**Overview:** [[spell:1227280]] is an instant cleave damage effect
summons a massive shadowy appendage dealing damage in front of you and around your
target. This applies [[spell:34914]] to up to 6 enemies, prioritizing ones without
the DoT already applied. Note that this does not strictly speaking prioritize your 
target. When talented into [[spell:1279353]] Tentacle Slam also applies [[spell:335467]] 
at 25% reduced effectiveness to your current target (does not AoE).

In practice, Tentacle Slam is most important as a maintenance tool. Use it to refresh 
[[spell:34914]] on an add-heavy pull, prevent charges from capping, or set up a 
burst window when you are already rotating through the key damage spells. It is a strong 
AoE tool, but the APL also values it heavily for keeping your DoTs active and for 
spacing out your uses in the pull.

Note that if you overwrite a normal [[spell:335467]] with the one from 
[[spell:1227280]], the ticking damage in the tooltip will go down. This is expected
as you are only adding 25% damage but fully refreshing the DoT for the full duration.
This is working as intended and correctly rolling over damage.

By far the biggest reason this is a critical cooldown is with the upcoming Apex Talents
in Midnight, Void Apparitions. When you talent into these effects it also grants an effect
from one of your Idol spells, regardless of if you are talented into them. This is further
extended with the Apex talents where it causes each generated Idol spell to spawn
[[spell:341491]].

5.5.1.

##### Mechanics and Behavior

- **Area/Cleave:** It hits multiple nearby enemies depending on tentacle placement and add placement.
- **Partial [[spell:335467]] application:** If [[spell:1227280]]
       is empowered by [[spell:1279353]], it applies a free Shadow Word: Madness at 25% effectiveness.
- **Cooldown/charges:** Be mindful of cooldown charges capping and do not waste slams on low value targets.

6.

### How to Review Your Shadow Priest Logs

Log review is one of the fastest ways to improve your damage as a
[Shadow Priest](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>). Use logs to evaluate **execution** (casts, uptime,
timing), and use sims to evaluate **setup** (gear, talents, enchants).
Do both and you will improve faster than relying on either tool alone.

:::details **Fast Log Review Order**
**1) Match a Comparable Log**

- Similar kill time, fight length, and gear level.

**2) Check Cast Counts**

- Look for missing uses of cooldowns and core generators.

**3) Check Uptime**

- Verify DoTs and key buffs/debuffs are maintained.

**4) Check Cooldown Timing**

- Confirm alignment with phases, add waves, and buffs.

**5) Check Opener + Movement**

- Compare timeline execution to your planned sequence.

:::

6.1.

#### Step 1: Find a Comparable Log

Before reviewing details, compare against a run that is actually comparable.
Pick a player on the same boss with a similar kill time and roughly similar gear.
If fight lengths differ a lot, cast count comparisons become misleading.

If needed, trim timeline ranges to equivalent fight windows before comparing
spell counts and cooldown usage.

6.2.

#### Step 2: Check Cast Counts First

Cast counts are usually the highest-impact issue. If you are missing casts
across the board, this commonly means downtime from movement, slow queueing,
or holding cooldowns too long.

:::details Cast Count Checklist
- Did you lose casts of [[spell:228260]], [[spell:10060]], or [[spell:263165]]?
- Did you keep using [[spell:8092]] and [[spell:1240401]] enough to avoid lost cooldown uses?
- Did movement windows create empty globals where no spell was cast?
- Did you over-invest in manual [[spell:34914]] casts where [[spell:1227280]] setup was possible?

:::

6.3.

#### Step 3: Validate Uptime and Buff Windows

Once cast counts are acceptable, review uptime quality. For DoTs, aim to keep
coverage very high while still prioritizing mechanics safely.

- [[spell:589]] uptime: generally target 99%+ on priority targets.
- [[spell:34914]] uptime: generally target 99%+ on priority targets.
- [[spell:335467]] uptime: generally target 90%+.
- Check [[spell:228260]] windows for clean Insanity generation and spender usage.

Do not forget context: if your group used [[spell:2825]] at a very different
time, direct comparison can be distorted.

6.4.

#### Step 4: Cooldown Timing and Encounter Context

Good logs are not only about pressing cooldowns on cooldown. Many fights reward
slight delays to align with adds, execute windows, or damage amplifiers.

Compare exact timestamps for your major cooldowns and trinket/potion usage,
then ask if your timings matched meaningful encounter events.

:::details FAQShould I Always Use Cooldowns Exactly On Cooldown?
Not always. Default to using cooldowns quickly to avoid losing total uses,
but small planned delays can be correct when they line up with high-value boss
phases, add spawns, or group buffs.

:::

6.5.

#### Step 5: Review Opener and Movement Execution

Use timeline view to compare your opener and first major cooldown cycle
against your intended sequence. Most large losses come from early drift that
cascades into fewer high-value casts over the full fight.

For movement, focus on whether you maintained actions while repositioning.
Stutter-step between globals and cover movement with instant casts where possible
instead of full dead time.

6.6.

#### Advanced Tools and Common Pitfalls

For encounter-specific timing comparisons, [lorrgs.io](<https://lorrgs.io/>)
is useful for seeing cast timelines from many top logs side by side.

:::details Common Log Review Mistakes
- Comparing total damage from different kill times without normalizing windows.
- Ignoring externals and group context (for example extra [[spell:10060]] support).
- Overreacting to very small sim/log deltas that are within normal variance.
- Treating Mythic+ end-of-dungeon totals as direct apples-to-apples comparisons.

:::

6.7.

#### When to use your Racial Abilities

Depending on the race you decide to play, you will get various amounts of
spells that you can use to buff your character further. Unfortunately, not all
of these are useful. Use this section if you are curious about how to use
them in combat.

Note that as of writing, the DPS difference between the various
racial buffs is anywhere between 1-2%. Because this is so small, picking a race
just for the DPS output is generally not suggested. Often, you will get
more value out of picking the one that has better non-DPS options, such as
Goblin's [[spell:69070]] or Dwarf's [[spell:20594]].

- [[spell:265221]], [[spell:26297]], [[spell:33697]], and
  [[spell:274738]] should be synced up with [[spell:10060]] to
  maximize damage.
- Lightforged Draenei's [[spell:255647]] should be a
  low-priority action above your fillers. It gets better with adds and is
  worth saving and using for them.
- Blood Elf's [[spell:28730]] should only be used before combat; it is
  a DPS loss to use during combat.
- As a Zandalari Troll, I suggest sticking with [[spell:292361]] for your
  [[spell:292752]].
- Nightborne's [[spell:260364]] is not worth using for DPS purposes.
- Vulpera's [[spell:312411]] is not worth using for DPS purposes.

:::details FAQWhich Race is Best for Shadow Priest?
All races are close to one another regarding the DPS benefit they
provide you, so the answer is generally just to pick what you like.
Perhaps more importantly, look at the benefits each of the races gives you apart
from DPS; for example, tools like [[spell:20594]] or [[spell:58984]] do
not directly increase your DPS, but the utility they provide you can be way
more useful to the group than any tiny DPS that another race could offer.

You could also consider Dracthyr, Goblin, or Void Elf to help with mobility.
All of these can improve your mobility in different ways and which one is better is
purely personal choice.

- Dracthyr: [[spell:131347]]
- Goblin: [[spell:69070]]
- Void Elf: [[spell:256948]]

:::

:::details FAQHow Do I Validate If I Am Playing the Rotation Correctly?
Start by checking your opener and cooldown timings in logs, then compare cast counts and DoT uptime to strong
logs with similar encounter length. Once the rotation is clean, use simulations to evaluate gear and talent swaps;
sims are best for setup decisions, while logs are best for execution decisions.

:::

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **11 Aug. 2026:** Add clarity to a few sections that changed in Season 2.
- **10 Aug. 2026:** Rotation updates around Void Volley and Shadow Word: Madness usage.
- **10 Aug. 2026:** Update for Season 2 and Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **09 Apr. 2026:** Add a fully dedicated log review section with workflow, checklists, and troubleshooting guidance.
- **06 Apr. 2026:** Add movement handling, log review checklist, and validation FAQ guidance.
- **04 Apr. 2026:** Update talent defaults for several builds.
- **29 Mar. 2026:** Increase priority of Shadow Word: Death and add more notes about Distorted Reality.
- **22 Mar. 2026:** Update Power Infusion Suggestions and add note on Tentacle Slam and adjust note on Halo.
- **16 Mar. 2026:** Added more detail on spending Tentacle Slam charges.
- **26 Feb. 2026:** Added a dedicated section on the Apex talents.
- **10 Feb. 2026:** Remove mention of Maddening Slam interaction and place Tentacle Slam earlier in the opener after bug fixes.
- **23 Jan. 2026:** Added more FAQ entries for Pre-Patch.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **29 Aug. 2025:** Add note about using Mind Blasts in the Archon opener.
- **07 Aug. 2025:** Add note about Void Torrent cancel and update default Voidweaver talents.
- **04 Aug. 2025:** Update for Patch 11.2.0.
- **15 Jun. 2025:** Add information about the Combat Assistant.
- **25 May 2025:** Reviewed information after recent hotfixes to still be accurate.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **02 Apr. 2025:** Update default talent loadout for Archon Raid builds.
- **19 Mar. 2025:** Remove use of Shadow Crash in pure single target when you have Unfurling Darkness talented.
- **09 Mar. 2025:** Remove confusing mention of targets dying in DP AoE section.
- **03 Mar. 2025:** Add section on Hyperthread Wristwraps.
- **01 Mar. 2025:** Add new Power Infusion targets for Season 2.
- **28 Feb. 2025:** Remove Void Bolt's ability to be cast while channeling other spells.
- **24 Feb. 2025:** Update rotation for Season 2. Removed higher priority on Shadow Word: Death and Mind Blast actions with Inescapable Torment, use Void Bolt while channeling spells, and add new trinkets.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **04 Nov. 2024:** Update Power Infusion target suggestions.
- **22 Oct. 2024:** Adjust Archon opener to use Halo pre-pull.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **10 Oct. 2024:** Add Voidweaver Raid Cleave talent selector.
- **10 Oct. 2024:** Update Spymaster's Web usage.
- **09 Oct. 2024:** Update default talents for the Voidweaver Single Target build.
- **07 Oct. 2024:** Update default talents for Voidweaver.
- **06 Oct. 2024:** Update rotation for recent hotfixes.
- **04 Oct. 2024:** Remove redundant Shadow Word: Death entry when using Depth of Shadows.
- **17 Sep. 2024:** Add section on Idol of Yogg-Saron.
- **16 Sep. 2024:** Add new rotational sections to provide more detail on cooldown usage.
- **16 Sep. 2024:** Fix a few issues with Devouring Plague priority in the rotation sections, particularly with Voidweaver AoE.
- **09 Sep. 2024:** Add Mind Blast section to rotational notes.
- **05 Sep. 2024:** Fix opener sequences for Voidweaver builds and Archon AoE.
- **23 Aug. 2024:** Add Archon High Key M+ build selector
- **21 Aug. 2024:** Updated rotation for the launch of The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **09 May 2024:** Add option to cancel Mind Flay: Insanity in AoE situations.
- **07 May 2024:** Reviewed for 10.2.7.
- **02 May 2024:** Increase priority of Void Bolt and correct opener from this change.
- **26 Apr. 2024:** Adjust Mind Flay: Insanity and Mind Spike: Insanity priority in AoE.
- **25 Apr. 2024:** Add new video link and clarify Nymue trinket usage with Shadowfiend.
- **22 Apr. 2024:** Update rotation for Season 4 with new placeholder builds and options.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **08 Feb. 2024:** Add aoe rotation video link.
- **15 Jan. 2024:** Reviewed for 10.2.5.
- **02 Jan. 2024:** Add more detail around spending stacks of Death's Torment in the tier section.
- **03 Dec. 2023:** Add section on optimizing Idol of Y'Shaarj.
- **03 Dec. 2023:** Add clarifying note about how the 4pc set bonus works.
- **24 Nov. 2023:** Remove Power Word: Shield action during movement.
- **19 Nov. 2023:** Add extra SW:D line when only using the 2-piece set bonus.
- **07 Nov. 2023:** Adjust movement GCDs in main rotation priority.
- **07 Nov. 2023:** Small clarifying update to using Belor'relos, the Suncaller.
- **06 Nov. 2023:** Updated for Patch 10.2.0 and the new Season 3 set bonus.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **13 Aug. 2023:** Update video link.
- **09 Aug. 2023:** Removed Shadow Word: Death in Void Eruption opener when using Inescapable Torment.
- **09 Aug. 2023:** Added note to the Dark Ascension opener to make it clearer.
- **08 Aug. 2023:** Adjust Dark Ascension opener to account for Distorted Reality.
- **26 Jul. 2023:** Adjust sections for Divine Star and Mindgames usage to set them at a lower priority.
- **23 Jul. 2023:** Reviewed from the recent hotfixes.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5 and small update to Voidform opener.
- **27 Jun. 2023:** Rotational updates for Shadow Word: Death depending on talents selected. Clarify some Distorted Reality usage.
- **20 Jun. 2023:** Update Devouring Plague refreshing details.
- **15 Jun. 2023:** Clarifying note to Void Torrent around Devouring Plague.
- **06 Jun. 2023:** Add note clarifying Void Torrent should always be fully channeled.
- **01 Jun. 2023:** Clarifying note about how the tier set bonus works.
- **26 May 2023:** Add a note about tier set optimization in Mythic+.
- **22 May 2023:** Add more detail on using Halo, Divine Star, and Shadow Crash during pre-pull. Add note about Spoils usage.
- **18 May 2023:** Correct typo in the intro section.
- **05 May 2023:** Clarify Shadow Crash usage is only for refreshing DoTs.
- **03 May 2023:** Lower priority for Shadow Word: Death.
- **02 May 2023:** Clarification for Dstar and Halo and expanded on Distorted Reality in Devouring Plague section.
- **01 May 2023:** Significant updates to support the 10.1 rework.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **25 Feb. 2023:** Clarify Void Torrent use in opener.
- **23 Feb. 2023:** Fix issue with Void Torrent in single target, should only cast with all 3 DoTs active.
- **03 Feb. 2023:** Adjust high priority Mind Flay: Insanity action to only use when Void Torrent is not available.
- **31 Jan. 2023:** Correct high priority Mind Flay: Insanity line with Cthun when not taking Mindbender. Condense AoE rotation down to be easier to read.
- **24 Jan. 2023:** Update rotation guide for 10.0.5 with Void Torrent usage.
- **12 Jan. 2023:** Remove Mind Sear usage on single target.
- **11 Jan. 2023:** Rotational updates for 10.0.5, mostly formatting changes with some small clarity updates.
- **04 Jan. 2023:** Small clarification on Devouring Plague refresh notes and add some Trinket notes.
- **03 Jan. 2023:** Update openers with more detail. Split them out by cooldown to be easier to maintain.
- **01 Jan. 2023:** Lower priority on Shadow Word: Death with Inescapable Torment.
- **29 Dec. 2022:** Add new logic for Mind Flay: Insanity and change default checkboxes.
- **11 Dec. 2022:** Added section discussing Tier 29 set bonus rotational changes.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **09 Nov. 2022:** Added extra note about Mind Spike vs. Mind Flay with Mind Melt and Idol of C'Thun.
- **08 Nov. 2022:** Moved racials out of the rotation into their own section. Fixed opener to be easier to read.
- **07 Nov. 2022:** Made some parts of the rotation around Mind Blast easier to read.
- **05 Nov. 2022:** Cleaned up Devouring Plague lines to be more clear.
- **03 Nov. 2022:** Updated the rotations filler sections to be clearer. Added a new section on how to use Mind Sear.
- **02 Nov. 2022:** Made it clearer when to use your filler spells with the bottom section.
- **26 Oct. 2022:** Added more rotation switches to make things easier to look at.
- **25 Oct. 2022:** Adjusted priority of Shadow Word: Death, Mind Flay, and Mind Spike.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Shadow Priest in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Shadow Priest

Welcome to our Gearing Page for Shadow Priest. This section

will cover everything you need to know about equipping your character

correctly for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) and Season 2. Check out the sections below

to see information on the best gear from all sources and specifics

for Trinkets and Crafted items.

Many people overthink the distribution of their secondary

stats. An important thing to remember is that a higher **quantity** of stats

is usually better than a better **quality** of stats. Because of this,

wearing higher item-level gear with worse stats is often better than lower

item-level gear with great stats. Keep this in mind when considering gear.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you

increase the item level of gear along tracks that relate to where you obtained the

item, which harder content dropping gear that can be upgraded to higher Item Levels.

For more information, read up on our dedicated page on how the 

[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 

changed in the Midnight expansion.

For a video presentation on what's changing for Shadow Priest with Patch 

12.1, [check out this video from Publik](<https://www.youtube.com/watch?v=2OS9e2aMAlw>).

### Overall

This list contains the highest DPS setup from all sources for Shadow Priest. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces Do I Want?
You should prioritize getting the **Helm, Chest, Legs, and Gloves** set pieces. However this tier is is less important than ever to have the specific slots since we have a lot more choice in the stats of the items.

In Season 2 of Midnight when you [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) an item it not only gains the Tier Set bonus on the core 5 slots, but it also retains the stats of that item and any bonus effects it might have. This means you can use the catalyst to get ideal stats in any item as long as there is a base item to catalyze. This is a huge change from previous seasons where the stats of the item were lost when it was used for the Tier Set bonus.

- Helmet: [[item:271874]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:239045]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Chest: [[item:273785]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Gloves: [[item:268243]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: [[item:251160]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

When using a Tier Piece token the stats are still fixed, and for Shadow Priest all 5 stats that come from the tokens are good for us, aside from Legs which are Haste and Versatility. Due to the cantrip helm you will ideally catalyze both Tier Helm and Tier Legs.

:::

:::details FAQWhat to Craft Early?
While you might be tempted to craft a staff or off-hand early, we recommend crafting one of the following items with

[[item:240167]]

for optimal use of your sparks and crests early into the season:

- [[item:239648@JAAKAAwt1ENMMYTWiAGM]]
- [[item:239649@JAAKAAwt1ENMMYTWiAGM]]
- [[item:239656@JAAKAAwt1ENMMYTWiAGM]]

The [[item:273060]] on an off-hand is an option for an early craft, but it is generally not desirable long term.

:::

:::details FAQWhat Should I Prioritize From The Great Vault and Voidcores?
Use your Great Vault rewards to secure a strong weapon, a key trinket, or a missing piece of your tier set as early as possible. If you are still missing a specific upgrade and want to push a single slot faster, a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) can be a very efficient way to target a Myth-track weapon or trinket without waiting on the vault.

For Shadow Priest, your highest-priority targets should be your bonus rolls on [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) as Holy Loot Spec for the 3 Cantrip items, especially the mainhand. The helm and neck are also very strong and are worth bonus rolling Heroic over the first few bosses in Mythic. These items drop at Myth track on Heroic difficulty. Continue to bonus roll this boss and upgrade those items to max.

You should be bonus rolling [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in Holy loot spec to avoid getting the damage trinket on the loot table that we do not want. After those bonus rolls, you will likely shift to smaller-value rolls. This can either be targeting one of your ideal trinkets from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>) or [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>), or some of your off pieces you can acquire in things like [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>). At this point the options are tough, as you are really waiting until you get to the later half of the raid in Mythic to bonus roll those bosses; the early ones usually do not have great options for us.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271555@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Helm from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Hands from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:239649@JAAKAAwt1ENMMYTWiAGM]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Shoulders</th><td>[[item:239045@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Legs from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Chest from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAKAAwt1ENMMYTWiAGM]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span></div></td></tr></tbody></table>

### Mythic+

This list consists of the best items that solely drop and are farmable for Season 2 Mythic+ dungeons. This list is not meant at being your Best-In-Slot list for pushing keys, use the Overall List for that.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): Great trinket choice with [[item:250215@JAACAAgNyA]] and a great Neck.
- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): Cantrip weapon that will last you for a while, as well as a decent Trinket.
- [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Good Cloak and Waist items.

:::

:::details FAQWhich Tier Set Pieces Do I Want?
You should prioritize getting the **Helm, Chest, Legs, and Gloves** set pieces. However this tier is is less important than ever to have the specific slots since we have a lot more choice in the stats of the items.

In Season 2 of Midnight when you [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) an item it not only gains the Tier Set bonus on the core 5 slots, but it also retains the stats of that item and any bonus effects it might have. This means you can use the catalyst to get ideal stats in any item as long as there is a base item to catalyze. This is a huge change from previous seasons where the stats of the item were lost when it was used for the Tier Set bonus.

- Helmet: [[item:251232]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Shoulders: [[item:239045]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Chest: [[item:273785]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Gloves: [[item:273773]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Legs: [[item:251160]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

When using a Tier Piece token the stats are still fixed, and for Shadow Priest all 5 stats that come from the tokens are good for us, aside from Legs which are Haste and Versatility. Due to the cantrip helm you will ideally catalyze both Tier Helm and Tier Legs.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271555@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Helm from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Hands from<a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:251185@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Shoulders</th><td>[[item:239045@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Legs from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:251137@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Chest from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Bracers</th><td>[[item:251127@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Trinket</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251191@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span></div></td></tr></tbody></table>

### Raid

This list consists of the best items that solely drop from Season 2 Raids. This list is not meant at being your Best-In-Slot list for raiding, use the Overall List for that.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details TipsWhich Raid Items Do I Want Most?
Use this below list to help guide your farming priorities for raids.

- All 3 Cantrip items from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>). We will Catalyze [[item:271874@JAACAAAG2A]] into tier and then use [[item:268265@JAACAAAG2A]] and [[item:271092@JAACAAAG2A]].
- [[item:270169@JAACAAAG2A]]: Our best on-use trinket that drops from raids, particularly strong for encounters with damage amp phases.
- [[item:270167@JAACAAgNyA]]: This is typically our best passive option for trinkets in Season 2, just slightly ahead of Gebbos.
- [[item:270164@JAACAAgNyA]]: One of the best raid trinkets. Drops from [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

:::

:::details FAQWhich Tier Set Pieces Do I Want?
You should prioritize getting the **Helm, Chest, Legs, and Gloves** set pieces. However this tier is is less important than ever to have the specific slots since we have a lot more choice in the stats of the items.

In Season 2 of Midnight when you [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) an item it not only gains the Tier Set bonus on the core 5 slots, but it also retains the stats of that item and any bonus effects it might have. This means you can use the catalyst to get ideal stats in any item as long as there is a base item to catalyze. This is a huge change from previous seasons where the stats of the item were lost when it was used for the Tier Set bonus.

- Helmet: [[item:271874]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: Tier Set Token from [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- Chest: Tier Set Token from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Gloves: [[item:268243]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: Tier Set Token from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

When using a Tier Piece token the stats are still fixed, and for Shadow Priest all 5 stats that come from the tokens are good for us, aside from Legs which are Haste and Versatility. Due to the cantrip helm you will ideally catalyze both Tier Helm and Tier Legs.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271555@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Helm from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Hands from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> Legs from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270169@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:268228@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Shadow Priest

Shadow Priest has many great Trinkets to choose from throughout the season. The guide

below is designed to help you understand which are best to target and what to expect 

from the trinket options in Season 2. These are

generic suggestions of what to target, but anything that is a big item-level jump

might be an upgrade, even if it is not on this list. Be sure to get familiar

with the [Gear Upgrade System](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) system.

This season, you should aim for 1 On-Use trinket and 1 Passive trinket. Use the list below to help guide you here,

generally you want one from each category. [[item:270169@JAACAAAG2A]] in particular

is a strong on-use trinket from raids, and rewards lining up usage of this with damage amp phases

or when you particularly need the damage.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Shadow Priest Trinkets**
**Best On-Use -**

[[item:250215@JAACAAgNyA]]

or

[[item:270169@JAACAAAG2A]]

**Best Passive -**

[[item:281215@JAACAAgNyA]]

or

[[item:270164@JAACAAgNyA]]

:::

There are lots of other competitive options out there, be sure to see the full 

rankings below.

2.1.

#### Single-Target Trinket Rankings

- [Voidweaver](<https://warcraftpriests.github.io/?talents=voidweaver&sims=trinkets&fightStyle=Single>)
- [Archon](<https://warcraftpriests.github.io/?talents=archon&sims=trinkets&fightStyle=Single>)

2.2.

#### Dungeon Trinket Rankings

- [Voidweaver](<https://warcraftpriests.github.io/?talents=voidweaver&sims=trinkets&fightStyle=Dungeons>)
- [Archon](<https://warcraftpriests.github.io/?talents=archon&sims=trinkets&fightStyle=Dungeons>)

2.3.

#### Trinket Breakdown

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Shadow Priest Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Both Hero Talents (Combined)</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:270169@JAACAAAG2A]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;<li>[[item:273649@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:248583@JAACAAgNyA]]</li>&#10;<li>[[item:251792@JAACAAgNyA]]</li>&#10;<li>[[item:250144@JAACAAgNyA]]</li>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:250256@JAACAAgNyA]]</li>&#10;<li>[[item:251786@JAACAAgNyA]]</li>&#10;<li>[[item:251785@JAACAAgNyA]]</li>&#10;<li>[[item:246304@JAAGAAwt1ENMMYD]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) is a currency that guarantees loot from your target boss or dungeon. 

While the specific item is random, you'll never receive duplicates, each new 

voidcore guarantees a different drop until you've collected everything available 

from that source.

3.1.

#### Recommended Nebulous Voidcore Usage for Shadow Priest

Your Nebulous Voidcores are a valuable resource for targeting gear that would otherwise elude you. 

Your voidcore strategy should prioritize closing gaps in your current setup, keeping in mind what 

you have already obtained from the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) and your raid progression tier. Spending 

voidcores on items you can access through higher difficulty content in the coming weeks is generally 

inefficient. Here is what you should focus on:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore Targeting Priority**
1. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) for the Cantrip Items as Holy Loot Spec
2. Myth-track weapons (1H or 2H)
3. Cantrip Items and Mythic-track trinkets like [[item:281215@JAACAAgNyA]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
4. Tier set pieces you are missing for your 2 or 4-piece bonus
5. High-impact slots from your BiS list

:::

3.2.

#### Ascendant Venomstones

When deciding on what to spend your [[item:280562]] on, you should 

  prioritize the following order:

1. Your Mainhand Weapon is the highest priority
2. Your Offhand weapon
3. Your on-use trinket
4. Your passive trinket
5. Your neck item.

You can also upgrade cantrip items from the last two bosses of the raid that 

were bonus rolled on Heroic. They get upgraded to 340 item level.

4.

### Best Crafted Items for Shadow Priest

Crafting gear yourself or commissioning profession items is a great 

way to augment your character's power.

As a Shadow Priest, craft one of your eventual BiS slots early using

[[item:240167]]: Wrists, Waist, or Cloak. The [[item:273060]]

on an off-hand is an option to craft early, but it is generally not something you want

long term.

You can further push your character's strength by using your

two crafted embellishment slots. You can equip as many crafted pieces as you want,

but you are limited to 2 embellishments.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Shadow Priest Crafted Gear Priority**
- [[item:239648@JAAKAAwt1ENMMYTWiAGM]] with [[item:240167]]
- [[item:239649@JAAKAAwt1ENMMYTWiAGM]] with [[item:240167]]
- [[item:239656@JAAKAAwt1ENMMYTWiAGM]] with [[item:240167]]
- [[item:273060]] on an off-hand is an optional early craft, but not a long-term recommendation.
- Any item you do not yet have on Myth track

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Shadow Priest

As a Shadow Priest, you have a few options for your two embellished slots,

depending on what gear you currently have. You should use these crafted items

to make up for any gaps in your gearing process or slots you need in particular.

- [[item:239648@JAAKAAwt1ENMMYTWiAGM]] and [[item:239649@JAAKAAwt1ENMMYTWiAGM]] with [[item:240167]] - Eventual BiS Wrist and Waist crafts.
- [[item:239656@JAAKAAwt1ENMMYTWiAGM]] with [[item:240167]] - Alternative craft for the Cloak slot.
- [[item:273060]] - Optional early off-hand craft, but generally not desirable long term.
- [[item:239662]] and [[item:239661]] - Two-piece bonus that can be 
  
      optimal for certain situations. Uptime is typically lower on progression, so it's not our default choice.
- [[item:240167]] - Strong general embellishment used on low budget slots when needed.
- [[item:251513]] - Can be good early if you are struggling to find a good ring. The proc changes 
  
      based on gem colors you have, our best procs are usually with Garnet or Peridot gems.

4.2.

#### Adding Sockets to Gear

During Season 2 you can add sockets to any Head, Waist, or Wrist item with the 

[[item:275707]] consumable that you can get if you do not select any of the choices in

your Great Vault. Not picking a choice will grant you tokens, six of which can be

traded in for the [[item:275707]] item that allows you to add a socket to the above piece

of gear, if you acquired them in Season 2.

5.

### Crest Usage

Mistcrests are a limited time-gated resource that you want to spend optimally

to make sure your player power gains are maximized as you progress through the season.

These Mistcrests can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)

to higher item levels. It is important that you prioritize

your usage of them on items you plan on not replacing anytime soon, or that offer the

biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Shadow Priest Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Off-hand**

➜

**Shoulders/Gloves/Belt/Boots**

:::

These are not the only items worth upgrading, of course. They simply offer

the highest DPS gain early into the tier when your upgrade currency is limited.

Note that exceptions are possible, such as special items that have additional

procs attached to them.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the

importance of simming yourself on Raidbots. This is because every character is

unique, and each gear piece you have access to can change what is best

right now for you.

While we do offer recommendations for gear and trinkets, these are not complete

replacements for simming yourself. The only way to truly optimize your character

to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **18 Aug. 2026:** Update crafted suggestions after Hunter Ritual Stone nerf.
- **15 Aug. 2026:** Update trinket rankings to reflect upcoming tuning.
- **11 Aug. 2026:** Add more direct advice to crafting and bonus rolls.
- **10 Aug. 2026:** Update gear lists with more information on Catalyst Sources and Bonus Roll guidance.
- **10 Aug. 2026:** Update for Season 2 and Patch 12.1.
- **03 Aug. 2026:** Combine Archon and Voidweaver trinket rankings into one tier list and cap Darkmoon trinkets at C-tier.
- **22 Jun. 2026:** Update trinket tooltips to have proper item levels.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **19 May 2026:** Add note about neck choices.
- **20 Apr. 2026:** Add new section for Ascendant and Nebulous Voidcores.
- **06 Apr. 2026:** Add a dropdown with additional Shadow Priest simulation resources.
- **01 Apr. 2026:** Swap out embellishments to not use the Arcanoweave Set.
- **29 Mar. 2026:** Adjust trinket rankings after weeky 1 of the season.
- **22 Mar. 2026:** Adjust ranking of Vessel of Tortured Souls.
- **16 Mar. 2026:** Update for the launch of Season 1.
- **06 Mar. 2026:** Update trinket rankings.
- **02 Mar. 2026:** Update crafting suggestions ready for Season 1 launch.
- **26 Feb. 2026:** Adjust trinket rankings to account for Mythic dungeon item levels.
- **26 Feb. 2026:** Updated page for Midnight Pre-Season.
- **10 Feb. 2026:** Increase ranking of Screams of the Forgotten Sky trinket.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **21 Oct. 2025:** Further clarity and detail to the Puzzling Cartel Chips section.
- **05 Oct. 2025:** Added Dinar section and adjusted trinket rankings from the Turbo Boost item level.
- **18 Aug. 2025:** Small adjustments to trinket tier rankings.
- **04 Aug. 2025:** Update for Patch 11.2.0.
- **22 Jun. 2025:** Adjust D.I.S.C. belt powers for upcoming hotfixes.
- **15 Jun. 2025:** Add information on the Durable Information Securing Container Waist item.
- **25 May 2025:** Reviewed information after recent hotfixes to still be accurate.
- **12 May 2025:** Add note about purchasing Signet of the Priory.
- **08 May 2025:** Cyrce's Circlet is no longer Best in Slot.
- **05 May 2025:** Update Cartel Chips section.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **28 Mar. 2025:** Update trinket rankings after recent hotfixes.
- **19 Mar. 2025:** Remove mention of Amorphous Relic after the bug fix.
- **13 Mar. 2025:** Update trinket rankings and add more info to various sections.
- **05 Mar. 2025:** Add note about when to swap to the Season 2 Tier.
- **03 Mar. 2025:** Add info on using Hyperthread Wristwraps.
- **01 Mar. 2025:** Update Cyrce's Circlet gems for Season 2.
- **26 Feb. 2025:** Update trinket rankings for Season 2.
- **24 Feb. 2025:** Update page for Patch 11.1.0.
- **17 Dec. 2024:** Update Cyrce's Circlet tooltips and give alternative wind gem.
- **16 Dec. 2024:** Update Cyrce's Circlet gems after recent buffs.
- **15 Dec. 2024:** Update Cyrce's Circlet suggestions after initially posting.
- **15 Dec. 2024:** Add new Cyrce's Circlet Ring for 11.0.7.
- **04 Nov. 2024:** Add caveat for overall BiS list weapons.
- **27 Oct. 2024:** Remove Burst of Knowledge.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **17 Oct. 2024:** Fix Mythic+ gear set bug with rings.
- **01 Oct. 2024:** Adjust gear setups to include more one handed weapons.
- **30 Sep. 2024:** Update trinket rankings and add a few extra gear options for BiS lists from dungeons.
- **19 Sep. 2024:** Add Candle Confidant.
- **17 Sep. 2024:** Change fateweaved weapon mention.
- **16 Sep. 2024:** Update trinket rankings and mention Fateweaved Needle weapon.
- **12 Sep. 2024:** Remove Pre-Season BiS list.
- **09 Sep. 2024:** Increase Mad Queen's Mandate on Raid tier list.
- **01 Sep. 2024:** Remove Binding of Binding from crafting gear suggestions.
- **31 Aug. 2024:** Update crafted gear suggestions for Season 1.
- **21 Aug. 2024:** Updated for the launch of The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **15 May 2024:** Put Call to Suffering in S-tier for Mythic+.
- **13 May 2024:** Add note about buying defensive trinkets for Mythic+.
- **09 May 2024:** More info around Vessel and the Fire damage procs and add trinket combination examples for Mythic+.
- **07 May 2024:** Updated for 10.2.7.
- **05 May 2024:** Add more detail around Vessel and swap a few rankings around.
- **01 May 2024:** Update ranking of Vessel of Searing Shadows since it can help proc the rings.
- **30 Apr. 2024:** Add more info on bullion purchases and additional fire damage sources.
- **28 Apr. 2024:** Add note about on-use trinkets in Mythic+.
- **25 Apr. 2024:** Add bonus IDs to display crafted gear more clearly and add new video for Bullions and split suggestions for Raid and Mythic+.
- **22 Apr. 2024:** Update for Season 4 with new gear suggestions.
- **19 Mar. 2024:** Update embellishment guidance for high Mythic+ dungeons.
- **13 Feb. 2024:** Update dungeon trinket rankings to match the tier list.
- **25 Jan. 2024:** Increase rank of Balefire Branch and Ashes of the Embersoul in Mythic+ Rankings.
- **15 Jan. 2024:** Clarify usage on Hood of Surging Time in Mythic+.
- **20 Dec. 2023:** Lower Nymue in the trinket rankings for Dungeons.
- **19 Dec. 2023:** Update gear sets with more Neck options.
- **18 Dec. 2023:** Add extra note about Augury of the Primal Flame.
- **13 Dec. 2023:** Add note about prioritizing helm upgrades for Incandescent Essence.
- **01 Dec. 2023:** Add crafted gear widget.
- **30 Nov. 2023:** Add trinket tier lists as well as more detailed info on some options.
- **24 Nov. 2023:** Update trinket and weapon rankings/comments.
- **16 Nov. 2023:** Update note about Ashes trinket.
- **14 Nov. 2023:** Add link to the trinket video.
- **14 Nov. 2023:** Add small note about using Iridal in execute.
- **13 Nov. 2023:** Update trinket suggestions and add more detail about when to use each one.
- **08 Nov. 2023:** Add link to crafted gear video.
- **07 Nov. 2023:** Update embellishment suggestions after the Undulating Sporecloak nerf.
- **06 Nov. 2023:** Update gear lists and suggestions for Season 3 and Patch 10.2.
- **04 Sep. 2023:** Add new gear lists.
- **13 Aug. 2023:** Add video link.
- **10 Aug. 2023:** Add note about Irideus Fragment for Dark Ascension builds.
- **23 Jul. 2023:** Reviewed from the recent hotfixes.
- **10 Jul. 2023:** Updates for Patch 10.1.5 including new items from Dawn of the Infinite.
- **27 Jun. 2023:** Clarify a few choices on trinkets and embellished items.
- **07 Jun. 2023:** Add note about Beacon to the Beyond in Mythic+.
- **01 Jun. 2023:** Clarifying technical note about how the T30 set bonus works and adding rough numbers.
- **31 May 2023:** Add a bit more detail on weapon crafting.
- **23 May 2023:** Adjust timewalking section from recent changes
- **23 May 2023:** Add timewalking section.
- **16 May 2023:** Remove reference to Undulating Sporecloak bug as it was fixed.
- **16 May 2023:** Add bug to Undulating Sporecloak and remove old Neltharion's Lair items.
- **15 May 2023:** Correct Undulating Sporecloak info now that it has fixed stats.
- **06 May 2023:** Add note about Ominous Chromatic Essence flight choice.
- **05 May 2023:** Update weapon and trinket rankings from recent changes.
- **01 May 2023:** Update all gearing suggestions for 10.1 and Season 2.
- **23 Mar. 2023:** Update Onyx Annulet suggestions from recent hotfixes.
- **22 Mar. 2023:** Update Onyx Annulet suggestions from recent info on Prophetic Twilight Stone interactions.
- **20 Mar. 2023:** Update for Patch 10.0.7 with new section on the Onyx Annulet.
- **05 Mar. 2023:** Small tweak to Dungeon trinket suggestions.
- **24 Jan. 2023:** Update gear suggestions for 10.0.5.
- **24 Dec. 2022:** Add Desperate Invokers Codex trinket.
- **21 Dec. 2022:** Add some more detail to crafted gear sections.
- **13 Dec. 2022:** Add video guide for crafted gear and remove note about having different elements in Elemental Lariat.
- **11 Dec. 2022:** Updated for Season 1 launch.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Shadow Priest. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Shadow Priest Stat Priority

As a Shadow Priest, your Hero Talent choice and the type of encounter you are

playing both affect how strongly you should value your secondary stats. In

general, **Haste** and **Mastery** are your most important secondary stats,

with **Critical Strike** and **Versatility** taking a back seat. The exact

balance between Haste and Mastery shifts depending on your Hero Talent and whether

you are playing single-target or multi-target content.

Item Level

Haste

Mastery

Critical Strike

Versatility

The broad priority above is a simple summary. The sections below give the more

specific guidance you should use when choosing gear for a particular playstyle.

If you want to optimize for multiple types of content, it is worth maintaining

two gear sets: one for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver and one for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon.

Voidweaver generally favors Haste over Mastery, while Archon performs best when

Haste and Mastery stay closer together.

1.1.

#### Single-Target Stat Priority

These are the practical stat targets for single-target encounters. The rating

ranges are approximate goals rather than strict minimums or maximums. They

represent stat distributions that have performed well in simulations while helping

you avoid over-stacking a stat and falling into excessive diminishing returns.

1.1.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon

1. Intellect
2. Mastery (1200 - 1400 Rating)
3. Critical Strike (800 - 1200 Rating)
4. Haste (1400 - 1600 Rating)
5. Versatility (400 Rating or Below)

1.1.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver

1. Intellect
2. Mastery (1200 - 1400 Rating)
3. Haste (1400 - 1800 Rating)
4. Critical Strike (800 - 1200 Rating)
5. Versatility (400 Rating or Below)

1.2.

#### Multi-Target Stat Priority

These are the practical stat targets for AoE and Mythic+ style content. The

ranges below are rough goals for an un-buffed character in a Mythic+ environment,

not hard caps, and they are meant to help you stay close to the recommended

balance without over-investing in a single stat.

1.2.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon

1. Intellect
2. Mastery (1000 - 1200 Rating)
3. Haste (1600 - 1800 Rating)
4. Critical Strike (800 - 1200 Rating)
5. Versatility (400 Rating or below)

1.2.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver

1. Intellect
2. Haste (1600 - 1800 Rating)
3. Mastery (1000 - 1200 Rating)
4. Critical Strike (800 - 1200 Rating)
5. Versatility (400 Rating or Below)

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. You should look for this stat in all

of your upgrades. It provides you with Spell Power, which increases the damage

of your spells.

**Critical Strike** increases your chance to critically hit with

all spells and abilities. Crits deal double damage by default, but several 

effects can increase your crit damage, and make crits even stronger.

**Haste** increases your spell-casting speed and the tick rate of your

periodic effects.

:::details FAQIs There a Haste Cap for Shadow Priest?
No, there is no hard Haste cap for Shadow Priest. You do not need to stop at a
specific amount of Haste, Critical Strike, Mastery, or Versatility for the spec
to function. That said, once you reach roughly 30% Haste, Critical Strike, or
Versatility, those stats begin to lose value through diminishing returns. Mastery
begins to do this around 19%.

:::

**Mastery** ([[spell:343690]]) increases the damage of your

spells for each damage over time effect you have active on that target. This

only works with [[spell:589]], [[spell:34914]], and

[[spell:335467]]. While [[spell:228260]] is active, you get the benefit

on every target as if they had all three dots active.

**Versatility** increases all your damage and healing done, and decreases

all damage taken.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point

gained, which are known as the points of diminishing return. Once you have reached

these amounts, stats will become progressively less valuable and may fall behind

other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Update for Season 2 and Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5 with corrected stat DR thresholds.
- **06 Apr. 2026:** Add FAQ guidance on sim profile selection and interpreting small stat deltas.
- **16 Mar. 2026:** Reviewed for Season 1.
- **26 Feb. 2026:** Updated for stat ranges at level 90.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Update for Patch 11.2.0.
- **15 Jun. 2025:** Review information for Patch 11.1.7.
- **25 May 2025:** Reviewed information after recent hotfixes to still be accurate.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **14 Mar. 2025:** Adjustments to stat goals for Season 2 after more testing.
- **26 Feb. 2025:** Update stat goals for Mythic+ in Season 2.
- **24 Feb. 2025:** Update stat goals for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **04 Nov. 2024:** Reviewed for recent hotfixes.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **14 Oct. 2024:** Update stat suggestions after more testing to be more precise.
- **04 Oct. 2024:** Update Dungeon Stat suggestions to index for higher key levels.
- **16 Sep. 2024:** Add in specific stat suggestions for Archon and Voidweaver.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for the launch of The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **25 Apr. 2024:** Add new video link.
- **22 Apr. 2024:** Update secondary stat goals for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **08 Feb. 2024:** Add Versatility video link.
- **21 Jan. 2024:** Add extra clarity on stacking Versatility.
- **15 Jan. 2024:** Clarify Haste thresholds with Hood of Surging Time and mention the value of Versatility for pushing Mythic+ dungeons.
- **07 Nov. 2023:** Add note about Crit/Vers scaling with cantrip items.
- **06 Nov. 2023:** Updated stat thresholds and goals for Patch 10.2.0.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **13 Aug. 2023:** Add video link.
- **10 Aug. 2023:** Add secondary stat deep dive section for optimizing top end gear.
- **23 Jul. 2023:** Reviewed from the recent hotfixes.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **25 May 2023:** Add extra note about Ominous Chromatic Essence.
- **22 May 2023:** Add more detail on Haste soft caps.
- **01 May 2023:** Updated stat priority references to bugs that were fixed in 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Shadow Priest, based on your [stat priority](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You will have two categories of gems to choose from:
Rare or Epic. The Rare gems are either just a single stat or a combination
of two secondary stats on one gem. The Epic gems are
significantly stronger, but you can only use one at a time for your entire
character.

As a Shadow Priest you should utilize the [[item:240983]] 
as your Epic gem of choice.

To best optimize your rare gems, you should use gems with Haste and Mastery 
on them. If you are not using crafted items (see the below FAQ), you should stack either 
[[item:240892]] or [[item:240900]] alongside 
[[item:240983]]. Usually, early on in the gearing 
process, you will lean towards the gems providing more
Haste, and towards the end, you will stack more Mastery. On single-target,
you will typically notice Mastery being more valuable; on AoE, Haste is
more valuable. Regardless of your choice, don't overthink your gem-choices, as long as they
have both stats on them.

Rare gems are roughly worth 0.4% DPS. If you are considering
replacing an item with a socket, keep this in mind. As you get more gear, this
could be even higher, but this is a rough number you can use. Simming different
gem choices is extremely difficult because of how low of an increase this is, you
should take gem sims with a large amount of caution as, typically, gains that are
that small when comparing gems are within the margin of error; meaning, they are equal
in value, and you can just pick the cheaper option.

:::details TCWhat Gems Should I Use When Needing Multiple Different Colors?
Certain crafted items get more benefit from having gems of all
colors, so use the list below to optimize your gem-usage.

- Peridot: [[item:240892]]
- Garnet: [[item:240908]] or [[item:240906]]
- Amethyst: [[item:240900]]
- Lapis: [[item:240917]] or [[item:240916]]

:::

2.

### Best Enchants and Weapon Augments

For your temporary weapon oil, you should use [[item:243733]].

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best</th>&#10;<th>Alternative</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244031]]</li>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244031]]</li>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm (non-throughput)</td>&#10;<td>[[item:243981]]</td>&#10;<td>[[item:243979]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;<td>[[item:244003]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders (non-throughput)</td>&#10;<td>[[item:243963]]</td>&#10;<td>[[item:243961]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240133]]</td>&#10;<td>[[item:240156]]</td>&#10;</tr>&#10;<tr>&#10;<td>Ring</td>&#10;<td>[[item:243957]]</td>&#10;<td>[[item:244010]]</td>&#10;</tr>&#10;<tr>&#10;<td>Feet (non-throughput)</td>&#10;<td>[[item:244009]]</td>&#10;<td>[[item:243953]]</td>&#10;</tr>&#10;</table>

For most people you will find the Haste proc, [[item:243973]],
will be good early on. Once you get a solid amount of Haste (at least 20-25%), you will
likely find the swap to [[item:244031]] will perform better.

When picking tertiary enchants, I would suggest defaulting to Speed
as a Shadow Priest due to our lack of mobility. Avoidance or Leech can
provide more defensive benefit, but in my experience being able to dodge things
easier is more valuable.

3.

### Optimal Consumables

3.1.

#### Flask

For Season 2, you should use one of the following depending on
which stat you need more of.

- [[item:241322]] - Mastery
- [[item:241325]] - Haste
- [[item:241320]] - Versatility (Defensive Option)

3.2.

#### Potions

Our theoretical best combat potion in all content is [[item:241288]].
This potion can be gear dependent though, and can cause wild changes in damage even 
swapping a single item. For this
reason the potion is not used by default in our sims, but it is still a very strong option. 
If you are not using this potion, [[item:241308]] is a solid alternative.

In Season 2 you now have access to [[item:271883]] 
which is significantly better than [[item:241305]].

3.3.

#### Food Buff

As a Shadow Priest our preferred food in all content is the 
[[item:255845]] or [[item:255846]] feasts.
If you do not have access to feasts we prefer using [[item:242275]] 
as our personal food of choice, as it has the same stats as those feasts.

If you want cheaper personal food you can also use [[item:242285]] or 
[[item:242286]].

Depending on the level of progression content,
you can also choose to craft Hearty versions of most food, which gives
the exact same effect (despite a few wrong tooltips), but the buff
now persists through death. This costs 5 normal food to produce 1 hearty
version.

3.4.

#### Augment Rune

You should aim to use an Augment Rune to get a boost of
Intellect during any progression content. This is a gain of about 1% DPS. For
Season 2 the following Augment Runes are available:

- [[item:259085]] (Consumable version)

3.5.

#### Other Consumables

In addition to the above items you should also always make sure you have
the following in your bags for Raiding and Mythic+ environments as a
Shadow Priest.

- [[item:188152]] - Reusable item that will auto-click a
          nearby Warlock Gateway.
- [[item:244639]] - Provides a weaker [[spell:2825]]
          effect for the group that can be useful in Mythic+ dungeons without
          a class to provide it naturally.
- [[item:269586]] - Castable Battle
          Resurrection item that can be used in combat, even as a
          non-engineer.
- [[item:241303]] - Invisibility potion that can
          be used instead of a [[item:241308]] to skip trash in
          certain Mythic+ dungeon routes.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **01 Sep. 2026:** Default combat potion update and caveat.
- **11 Aug. 2026:** Simplify Ring enchant notes.
- **10 Aug. 2026:** Updated for Season 2 and Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **22 Apr. 2026:** Update ring enchant after recent buffs.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **23 Mar. 2026:** Remove mention of Tea consumables and add alternative enchants.
- **16 Mar. 2026:** Swap in mention of Royal Roast personal food.
- **02 Mar. 2026:** Correct food consumable and add in mention of teas.
- **26 Feb. 2026:** Added new consumables and enchants for Midnight launch.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Update for Patch 11.2.0.
- **15 Jun. 2025:** Review information for Patch 11.1.7.
- **25 May 2025:** Reviewed information after recent hotfixes to still be accurate.
- **19 May 2025:** Update corruption rankings and add video guide.
- **05 May 2025:** Update Corruption section with more up-to-date info.
- **21 Apr. 2025:** Updated for Patch 11.1.5 with a new Corruption section.
- **28 Mar. 2025:** Add Other Consumables section.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **04 Nov. 2024:** Clarify usage of weapon enchants.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Add note about Hearty Food.
- **06 Sep. 2024:** Adjust guidance on Epic Gem to include Elusive Blasphemite.
- **04 Sep. 2024:** Add AoE Weapon enchant option.
- **01 Sep. 2024:** Add note about Ring Enchants.
- **29 Aug. 2024:** Add note about pre-season enchants.
- **21 Aug. 2024:** Update enchants and consumables for the launch of The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Update leg enchant suggestion and review for Season 4.
- **19 Mar. 2024:** Extra clarification on gem choices.
- **15 Jan. 2024:** Add alternative Boot enchant for more mobility.
- **13 Dec. 2023:** Add section about Incandescent Essence.
- **06 Nov. 2023:** Update all consumables for Season 3.
- **03 Oct. 2023:** Use correct name for the socket item for Season 2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **13 Aug. 2023:** Update video link.
- **23 Jul. 2023:** Reviewed from the recent hotfixes.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **27 Jun. 2023:** Adjust wording on Onyx Annulet do not use statement.
- **01 Jun. 2023:** Add note about rough value of a socket.
- **15 May 2023:** Rage Phial has been fixed so adjusting back suggestions and adding belt clasp.
- **03 May 2023:** Change default Phial back to Vers with Rage being bugged.
- **02 May 2023:** Add extra note on Sophic vs. Wafting.
- **01 May 2023:** Change suggested Phials and review other enchants for 10.1.0.
- **23 Mar. 2023:** Update Onyx Annulet suggestions from recent hotfixes.
- **22 Mar. 2023:** Update Onyx Annulet suggestions from recent info on Prophetic Twilight Stone interactions.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7 and add info about the Onyx Annulet ring.
- **15 Feb. 2023:** Clarify gem usage.
- **24 Jan. 2023:** Added mention of Haste/Mastery combo gem.
- **21 Dec. 2022:** Add extra clarification on when to use Vers phial.
- **11 Dec. 2022:** Add note about more Phials that I would not suggest using.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Shadow Priest in World of Warcraft Patch 12.1.5.

1.

### Shadow Priest in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Priest in

Mythic+ dungeons, including the best way to set up your character, how your

rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you

can read more about it on our dedicated Mythic+ pages below.

2.

### Best Talents for Shadow Priest

Shadow Priest can do almost any key with either ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon or

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver. Picking which one makes sense to you will depend on the

playstyle you enjoy and the advantages and disadvantages of each build but they

are all considered viable. Check out each section individually to learn more.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver [[spell:1240401]]

If you are still starting in your Mythic+ journey on the Shadow Priest, I would suggest

taking ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver [[spell:1240401]] for a spin. This build excels at doing one pack at a time which

is what most PUG groups end up doing, and still has a great damage pattern to scale as the key

level goes up.

**Use the Copy button below to generate an Import Code to use in-game!** If you prefer a

more DoT heavy playstyle, particularly for lower target count or sustained-length pulls,

you can play [[spell:1279350]] instead [[spell:238558]].

:::talents Misery Mythic+ - Voidweaver
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::talents Invoked Nightmare Mythic+ - Voidweaver
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx15NRdlkosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

2.1.

#### Strengths

- Facing off with smaller pulls, more of them instead of chain-pulling packs together.
- Good damage options every 30 seconds with [[spell:447444]].
- [[spell:451840]] turns this build into a power house during [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>) weeks or certain dungeons with shields.

2.2.

#### Weaknesses

- Facing packs that constantly move around while [[spell:447444]] is active.

2.3.

#### Build Options

- [[spell:238558]] is the default choice, however if you prefer a more DoT heavy 
  
      playstyle you can use [[spell:1279350]] instead for more damage on low 
  
      target count pulls, or more sustained damage in really long high key pulls.
- If you are in a dungeon with lots of deadly Magic damage you can
  
      consider using  [[spell:451569]] over [[spell:451311]].
- If you are looking for more mob control, you can experiment with using
  
      [[spell:451204]] instead of [[spell:451018]]. This might make the tanks
  
      job harder in some cases, so be sure to coordinate with your group on what is
  
      best for that key.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver [[spell:373310]]

As you start progressing into higher keys you can consider adding 

[[spell:373310]] for more raw AoE damage. This build relies on manually 

spreading [[spell:589]] to long-lived targets to let 

[[spell:1279350]] do maximum damage.

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Mythic+ High Key - Voidweaver
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMjZMAAAAAAAAAAAAYMLzMGbzMmZ2mZGzw2MzYmZGbIzYxMNAzMzAABY2mtFwsxAADGzMzY2GzgZGMDGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMjZMAAAAAAAAAAAAYMLzMGbzMmZ2mZGzw2MzYmZGbIzYxMNAzMzAABY2mtFwsxAADGzMzY2GzgZGMDGA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaDT7Uhx15pSMRdpsQ65JD0GoASTDQA-AAAA-FKmo0AQYcEBTwC-
```

:::

2.4.

#### Strengths

- Large pulls that last a long time (do not spread [[spell:589]] if they will not live at least 10 seconds).
- Good damage options every 30 seconds with [[spell:447444]].

2.5.

#### Weaknesses

- Anything that is short lived and many targets where you do not have time to spread [[spell:589]].
- Facing packs that constantly move around while [[spell:447444]] is active.

2.6.

#### Build Options

- If you are in a dungeon with lots of deadly Magic damage you can
  
      consider using  [[spell:451569]] over [[spell:451311]].
- If you are looking for more mob control, you can experiment with using
  
      [[spell:451204]] instead of [[spell:451018]]. This might make the tanks
  
      job harder in some cases, so be sure to coordinate with your group on what is
  
      best for that key.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon

If you are looking for a build that relies more on [[spell:15407]] and [[spell:120644]], 

I would try out the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Mythic+ build.

**Use the Copy button below to generate an Import Code to use in-game!** If you prefer a

more DoT heavy playstyle, particularly for lower target count or sustained-length pulls,

you can play [[spell:1279350]] instead [[spell:238558]].

:::talents Misery Mythic+ - Archon
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMmZWmxYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYGgxMzMmNmZbZAmBDA"
}
```
:::

:::talents Invoked Nightmare Mythic+ - Archon
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMmZ2mxYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYGgxMzMmNmZbZAmBDA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMmZWmxYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYGgxMzMmNmZbZAmBDA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx5NSqMRdZkksQ6GoQRRTDUEA-AAAA-CIMm0Ic4QhBQxS-
```

:::

2.7.

#### Strengths

- More single-target than the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver builds.

2.8.

#### Weaknesses

- Requires more coordinated pulls around your cooldowns.
- Only has damage windows every 60 seconds.

2.9.

#### Build Options

- [[spell:238558]] is the default choice, however if you prefer a more DoT heavy 
  
      playstyle you can use [[spell:1279350]] instead for more damage on low 
  
      target count pulls, or more sustained damage.
- You can adjust your Hero Talent choice node depending on the key:
  
          
  
  - [[spell:449874]] - Generic AoE damage, current default option
  - [[spell:454001]] - Does better for longer fights and activates
    
                the [[spell:228260]] duration pause outside of combat or while stunned. This
    
                pause can be very helpful for lower key levels.

3.

### Quick Rotation Tips

Shadow's playstyle in AoE is very similar to single-target, relying on

interactions from those single-target abilities for cleave damage through

[[spell:199484]]. The trick will be managing DoTs with [[spell:1227280]]

or supplementing that with your manual casts of [[spell:34914]].

Without this, you deal substantially less AoE damage.

The core playstyle in AoE with these spells requires you to make a

fundamental choice in terms of how you deal damage.

- **More Priority Target damage in AoE?** Funnel [[spell:335467]]
  
   on the highest health/most important target.
- **More Overall AoE?** Cast [[spell:335467]] on a new target each
  
   time you get enough Insanity.

Typically builds with [[spell:407470]] only funnel [[spell:335467]]

casts onto the main target but with [[spell:409044]] you can choose

to do this as well. Taking Distorted Reality is typically required

if you are interested in spreading though.

You will find that most Shadow Priest players will prefer to index into more

priority target damage, mostly because this is a more uncommon pattern and helps

you fit into the group composition better, particularly in high keys. Note that

depending on which choice you want to prefer you should take the associated

talent as indicated above. The builds below default to more priority target

damage.

3.1.

#### Single-Target Breakdown

Shadow Priest has several builds that will see play at various levels of dungeons.

You should choose the build that makes sense for your group depending on how much AoE

or Single-Target you need. The more Single-Target damage a build adds, the less AoE

damage it is capable of, but all of the dungeon builds are good options.

The following lists a rough breakdown of single-target damage with our various

builds. I have included this to help you make your decisions on what build to play

where you want single-target damage.

<table>&#10;<tr>&#10;<th>Hero Talent</th>&#10;<th>Build</th>&#10;<th>Difference</th>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp"/> Archon</span></td>&#10;<td>[[spell:1279350]]</td>&#10;<td>0.0% (216k)</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp"/> Archon</span></td>&#10;<td>[[spell:238558]]</td>&#10;<td>-2.8% (210k)</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp"/> Voidweaver</span></td>&#10;<td>[[spell:1279350]]</td>&#10;<td>-4.0% (207k)</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp"/> Voidweaver</span></td>&#10;<td>[[spell:1279350]] (Y'Shaarj)</td>&#10;<td>-6.3% (202k)</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp"/> Voidweaver</span></td>&#10;<td>[[spell:238558]]</td>&#10;<td>-9.2% (196k)</td>&#10;</tr>&#10;</table>

You should make many choices in our tree depending on your group's needs, the

type of damage that works best for that key, and the actual key level and

affixes.

4.

### Utility Kit and Abilities

### Interrupts, Stuns, and Stops

4.1.

#### Interrupts

[[spell:15487]] is your interrupt ability as a Shadow Priest, which can also prevent a mob

from casting for a few seconds after, depending on the type of mob.

To make kicking a target easier, it is highly suggested that you use a Focus Kick macro

for Silence. This allows you to attack a particular high-priority mob but keep your

Focus on the mob you might want to kick. This macro will prefer to cast on your Focus

if it exists, then on your Mouseover target, and lastly, your current target.

#### Silence

```wow-macro
#showtooltip

/stopcasting

/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Silence
```

To quickly set a focus target in hectic scenarios, we also recommend a

**Focus Mouseover macro**. This will set your Focus to whatever your

current mouseover target is.

#### Focus Macro

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you

are always able to kick it on cooldown or in coordination with the rest of your

group.

4.2.

#### Stunning and "Stops"

[[spell:8122]] is your primary AoE stop ability. The fear aspect is not

that important in PvE, but it does act as a pseudo AoE interrupt (otherwise known

as a stop) for all enemies within 8 yards. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon, you can take

[[spell:453918]] to get an additional stop out of this. Depending

on how much damage is going out, you can also consider using

[[spell:55676]]. However, if you can make good use of it, consider

using [[spell:196704]] to get more overall stops in the key.

[[spell:9484]] allows you to crowd-control a single Undead or Aberration enemy at a time.

This has rare use cases in Season 2 and will not be used often.

[[spell:205364]] can also be used as a single-target stop to a certain degree.

While this is a bit more involved, it can be used to lock down a mob for up to 30 seconds.

You can always cancel this early with a **/petdismiss** macro. Several dungeons also

have mobs that still cast useful abilities when Mind Controlled.

#### Mind Control

```wow-macro
#showtooltip

/petdismiss

/cast [known:Mind Control] Mind Control; Dominate Mind
```

### Other Utility

4.3.

#### Other Utility

Due to the sheer amount of options the spec has in terms of utility, it is

critical that you adjust class talents before every key you start

to make sure you are optimizing utility when needed or taking more

defensive options if you do not need the utility.

While we do not bring a battle resurrection to Mythic+ you can purchase

[[item:269586]] to support your group. You do

not need to be an Engineer to use this item.

[[spell:21562]] gives everyone in your party an extra 5%

Stamina, which provides a unique boost to help survive some of those

hard-hitting abilities.

[[spell:453]] provides an interesting alternative to

[[spell:114018]] that might help your group skip past a more

deadly Mythic+ pack, depending on the available space. This is changed to be

an AoE cast ability that works on all mobs within the 10-yard radius on a

short cooldown. Creative uses of this can make routing a key much easier.

[[spell:586]] has a few good pieces of utility to call out, the most

important being the aggro drop mechanic. If you find yourself getting aggro

over the tank on the pull, you can use [[spell:586]] to bypass this drop

easily and continue with the key. With the [[spell:373446]] class

talent, this also turns Fade into a small defensive. With [[spell:108942]]

this becomes an easy tool to break out of certain snare effects.

[[spell:373466]] is by far the biggest piece of utility in

the class tree, effectively giving your group an extra

[[spell:10060]] when used on an ally. While there is contentious

debate on who the best specs are for this, I would generally prefer

giving this out to Unholy Death Knights, Mages, Warlocks, Devastation Evoker,

Enhancement Shamans or anyone that is on a 2-minute cooldown timer.

[[spell:528]] allows you to dispel beneficial buffs from enemies.

This is extremely useful in dungeons, as many mob packs in many of the

dungeons tend to have some buff that they cast on themselves. While this is

more important in some dungeons than others, it is still precious to be

able to do it. You can also use this to spot dispel

[Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>).

[[spell:213634]] dispels all Disease effects from friendly targets.

This is fairly niche but still situationally extremely useful. The biggest

use case this season will be dispelling off [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>).

[[spell:32375]] remains a beneficial ability to have in our arsenal.

Dispelling is very important, and Mass Dispel allows for both offensive and

defensive dispels. The fact that you can dispel multiple enemies or friendly

targets with just one global is situationally powerful. However, Mass Dispel

does have a fairly lengthy 2-minute cooldown.

You can also Mass Dispel [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>) as well.

[[spell:15286]] heals allies based on the single-target

damage you do on a 2-minute cooldown. It can be

potent depending on the situation. Note that the

damage of our DoTs also gets converted to healing.

[[spell:73325]] pulls a friendly party member towards you. It could be

more useful generally, but it can sometimes save someone.

[[spell:1250691]] offers an AoE root.

5.

### Dungeon-Specific Tips

This section is focused on Priest-specific tips and tricks to help in

specific dungeons' bosses and trash.

### Talent Choice Cheat Sheet

For a quick guide of which talents to use, check the dungeon and affixes

in the table below and see the list of suggested utility talents you should

make sure you work into your build. You can also use the 

[Mythic Plus Utility](<https://www.curseforge.com/wow/addons/mythic-plus-utility-mpu>) 

Addon to remind you to swap to various talents.

<table>&#10;<tr>&#10;<th>Dungeons</th>&#10;<th>Affixes</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=148" rel="noopener noreferrer">Xal'atath's Bargain: Ascendant</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=158" rel="noopener noreferrer">Xal'atath's Bargain: Voidbound</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=162" rel="noopener noreferrer">Xal'atath's Bargain: Pulsar</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=160" rel="noopener noreferrer">Xal'atath's Bargain: Devour</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></td>&#10;<td></td>&#10;</tr>&#10;</table>

Based on the selections above, you should run the following class talents:

![Purify Disease not Talented](<https://static.icy-veins.com/images/wow/classes/priest/purify_disease.jpg>)**适用条件：Xal'atath's Bargain: Devour（未启用）；Altar of Fangs（未启用）；King's Rest（未启用）。**

![Purify Disease Talented](<https://static.icy-veins.com/images/wow/classes/priest/purify_disease.jpg>)**适用条件：Xal'atath's Bargain: Devour（启用）；Altar of Fangs（启用）；King's Rest（启用）。**

![Mass Dispel not Talented](<https://static.icy-veins.com/images/wow/classes/priest/mass_dispel.jpg>)**适用条件：Xal'atath's Bargain: Ascendant（未启用）；Xal'atath's Bargain: Devour（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Murder Row（未启用）；Ruby Life Pools（未启用）；Temple of Sethraliss（未启用）。**

![Mass Dispel Talented](<https://static.icy-veins.com/images/wow/classes/priest/mass_dispel.jpg>)**适用条件：Xal'atath's Bargain: Ascendant（启用）；Xal'atath's Bargain: Devour（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Ruby Life Pools（启用）；Temple of Sethraliss（启用）。**

![Phantasm not Talented](<https://static.icy-veins.com/images/wow/classes/priest/phantasm.jpg>)**适用条件：Xal'atath's Bargain: Devour（未启用）；Altar of Fangs（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Ruby Life Pools（未启用）；Blinding Vale（未启用）；Voidscar Arena（未启用）。**

![Phantasm Talented](<https://static.icy-veins.com/images/wow/classes/priest/phantasm.jpg>)**适用条件：Xal'atath's Bargain: Devour（启用）；Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；Blinding Vale（启用）；Voidscar Arena（启用）。**

- **适用条件：Xal'atath's Bargain: Devour（启用）；Altar of Fangs（启用）；King's Rest（启用）。** [[spell:213634]]
- **适用条件：Xal'atath's Bargain: Ascendant（启用）；Xal'atath's Bargain: Devour（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Ruby Life Pools（启用）；Temple of Sethraliss（启用）。** [[spell:32375]]
- **适用条件：Xal'atath's Bargain: Devour（启用）；Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；Blinding Vale（启用）；Voidscar Arena（启用）。** [[spell:108942]]
- **适用条件：Xal'atath's Bargain: Voidbound（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver for access to [[spell:451840]]
- **适用条件：Xal'atath's Bargain: Devour（未启用）；Xal'atath's Bargain: Voidbound（未启用）；Xal'atath's Bargain: Ascendant（未启用）；Altar of Fangs（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Murder Row（未启用）；Ruby Life Pools（未启用）；Temple of Sethraliss（未启用）；Blinding Vale（未启用）；Voidscar Arena（未启用）。** There are no specific talent suggestions.

### Altar of Fangs

5.1.

#### Rav'i

- Use [[spell:213634]] to dispel [[spell:1296069]] from [Rav'i](<https://www.wowhead.com/npc=259445>).
- Use [[spell:586]] with [[spell:108942]] to remove [[spell:1296069]] from [Rav'i](<https://www.wowhead.com/npc=259445>).

5.2.

#### The Writhing Coil

- Use [[spell:586]] with [[spell:108942]] to remove [[spell:1310974]] from [The Writhing Coil](<https://www.wowhead.com/npc=259446>).

5.3.

#### Zul'jan

- No specific tips.

5.4.

#### Trash

- Use [[spell:586]] with [[spell:108942]] to remove [[spell:1294569]] from [Twinfang Harrower](<https://www.wowhead.com/npc=261554>).

### Den of Nalorakk

5.5.

#### The Hoardmonger

- No specific tips.

5.6.

#### Sentinel of Winter

- No specific tips.

5.7.

#### Nalorakk

- No specific tips.

5.8.

#### Trash

- Use [[spell:32375]] for [[spell:1297696]] from [Earthwhisper Tender](<https://www.wowhead.com/npc=241814>).
- Use [[spell:586]] with [[spell:108942]] to remove [[spell:1309919]] from [Frigid Mauler](<https://www.wowhead.com/npc=241872>).

### Kings' Rest

5.9.

#### The Golden Serpent

- No specific tips.

5.10.

#### Mchimba the Embalmer

- No specific tips.

5.11.

#### The Council of Tribes

- No specific tips.

5.12.

#### Dazar, The First King

- No specific tips.

5.13.

#### Trash

- Use [[spell:32375]] for [[spell:270920]] from [Queen Wasi](<https://www.wowhead.com/npc=137478>).
- Use [[spell:32375]] for [[spell:270901]] from [Seneschal M'bara](<https://www.wowhead.com/npc=134251>).
- Use [[spell:32375]] for [[spell:269935]] from [Minion of Zul](<https://www.wowhead.com/npc=133943>).
- Use [[spell:32375]] for [[spell:1296671]] from [Guard Captain Atu](<https://www.wowhead.com/npc=137473>).
- Use [[spell:213634]] for [[spell:267763]] from [Half-Finished Mummy](<https://www.wowhead.com/npc=136264>).
- Use [[spell:586]] with [[spell:108942]] to remove [[spell:12548]] from [Spectral Shaman](<https://www.wowhead.com/npc=135239>).
- Use [[spell:586]] with [[spell:108942]] to remove [[spell:271564]] from [Embalming Fluid](<https://www.wowhead.com/npc=137989>).
- Use [[spell:586]] with [[spell:108942]] to remove [[spell:106823]] from [Queen Patlaa](<https://www.wowhead.com/npc=137486>).
- Use [[spell:586]] with [[spell:108942]] to remove [[spell:1294815]] from [Risen Hexer](<https://www.wowhead.com/npc=134174>).

### Murder Row

5.14.

#### Kystia Manaheart

- No specific tips.

5.15.

#### Zaen Bladesorrow

- No specific tips.

5.16.

#### Xathuux the Annihilator

- No specific tips.

5.17.

#### Lithiel Cinderfury

- No specific tips.

5.18.

#### Trash

- Use [[spell:32375]] for [[spell:1229433]] from [Felonious Mage](<https://www.wowhead.com/npc=236084>).

### Ruby Life Pools

5.19.

#### Melidrussa Chillworn

- No specific tips.

5.20.

#### Kokia Blazehoof

- No specific tips.

5.21.

#### Kyrakka and Erkhart Stormvein

- No specific tips.

5.22.

#### Trash

- Use [[spell:32375]] for [[spell:373973]] from [Primalist Cinderweaver](<https://www.wowhead.com/npc=190207>).
- Use [[spell:32375]] for [[spell:391031]] from [Primal Thundercloud](<https://www.wowhead.com/npc=197509>).
- Use [[spell:586]] with [[spell:108942]] to remove [[spell:373803]] from [Infused Whelp](<https://www.wowhead.com/npc=187894>).

### Temple of Sethraliss

5.23.

#### Adderis and Aspix

- No specific tips.

5.24.

#### Merektha

- No specific tips.

5.25.

#### Galvazzt

- No specific tips.

5.26.

#### Avatar of Sethraliss

- No specific tips.

5.27.

#### Trash

- Use [[spell:32375]] for [[spell:1310739]] from [Agitated Nimbus](<https://www.wowhead.com/npc=136076>).

### Blinding Vale

5.28.

#### Lightblossom Trinity

- No specific tips.

5.29.

#### Ikuzz the Light Hunter

- No specific tips.

5.30.

#### Lightwarden Ruia

- No specific tips.

5.31.

#### Ziekket

- No specific tips.

5.32.

#### Trash

- Use [[spell:586]] with [[spell:108942]] to remove [[spell:1238084]] from [Lasher](<https://www.wowhead.com/npc=245410>).

### Voidscar Arena

5.33.

#### Taz'Rah

- No specific tips.

5.34.

#### Atroxus

- No specific tips.

5.35.

#### Charonus

- No specific tips.

5.36.

#### Trash

- Use [[spell:586]] with [[spell:108942]] to remove [[spell:1263983]] from [[spell:1285066]].
- Use [[spell:586]] with [[spell:108942]] to remove [[spell:1249621]] from [Angry Krolusk](<https://www.wowhead.com/npc=249590>).

6.

### Dealing with Affixes

### Affix: Ascendant

6.1.

#### Ascendant Affix Management for Shadow Priest

Periodically, orbs of cosmic energy will spawn near your group.

As a Shadow Priest, you can use the following spells to get rid of these orbs:

- [[spell:8122]]
- [[spell:32375]] - Capped at 5 targets
- [[spell:15487]] - Usually best to save this for something else
- [[spell:64044]]
- [[spell:528]]

### Affix: Voidbound

6.2.

#### Voidbound Affix Management for Shadow Priest

When the Voidbound affix spawns, you should immediately swap targets to

focus this down. If you are a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver, be sure to prioritize

casts of [[spell:32379]] for the increase from [[spell:451840]].

The important thing to realize is the extra damage from [[spell:451840]]

will contribute to [[spell:199484]] damage, so prioritizing

[[spell:32379]] casts into this mob is a large boost in damage for us.

### Affix: Pulsar

6.3.

#### Pulsar Affix Management for Shadow Priest

As a Shadow Priest there is no specific advice for handling the Pulsar affix.

### Affix: Devour

6.4.

#### Devour Affix Management for Shadow Priest

When [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>) is present that week, you should always

be prepared to use [[spell:32375]] or [[spell:213634]] to dispel

[[spell:440313]] as often as you can on your party. You can also remove this

with [[spell:586]] with [[spell:108942]] talented or racials such as 

[[spell:20594]].

If you are out of tools to dispel off the debuff, you can also use

[[spell:19236]], [[spell:373481]], or [[spell:2061]]

to help get the debuff off.

7.

### In-Depth Rotation Tips for Mythic+

Both the single-target and multi-target rotations do not change in Mythic+

content. For more information about the [Shadow Priest](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>) DPS rotation,

refer back to the

[Rotation, Cooldowns, and Abilities page](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>).

If you are looking for a mere detailed setup with different talents, please

check out the rotation page.

[Shadow Priest Rotation and Cooldowns](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)

:::details **Mythic+ Execution Checklist**
**Pull With The Tank**

- Start DoT setup early and use

[[spell:586]]

to safely front-load damage while threat stabilizes.

**Move in Bursts**

- Stutter-step between globals and cover movement with instant casts like

[[spell:1240401]]

,

[[spell:32379]]

, and

[[spell:335467]]

.

**Do Not Miss Cooldown Uses**

- Lost uses of

[[spell:228260]]

,

[[spell:10060]]

, or

[[spell:263165]]

usually matter more than small gear differences.

:::

:::details FAQWhy Is My Mythic+ Damage Inconsistent Between Similar Keys?
Mythic+ logs vary heavily with route, pull size, tank pacing, target count, and priority target assignments.
Compare specific boss pulls or individual large trash pulls instead of only looking at total key DPS. When reviewing
logs, focus on cast counts, cooldown timings, and DoT uptime first.

:::

:::details How to Review Mythic+ Logs Effectively
- Compare equivalent pulls and boss phases, not just end-of-dungeon totals.
- Check if major cooldowns were used in the same pull windows and with similar target counts.
- Confirm [[spell:589]] and [[spell:34914]] uptime stayed high while moving between packs.
- Use sims for build and gear decisions, then use logs to refine execution and pull-by-pull planning.

:::

7.1.

#### Creating Burst Damage as a Shadow Priest

Occasionally, in dungeons, it can be worth breaking from the standard rotation

in order to facilitate bursting down a priority target. In this section, I will

go over the options you have for these cases as a Shadow Priest.

In the standard talent build, your best spell for burst damage is

[[spell:120644]] (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon) or [[spell:263165]] (particularly with

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver). If there is ever a high-priority target, you want to make

sure you have these spells available. Typically, you will combo this

together with something like this:

1. Pool up max Insanity before the target spawns you need to burst.
2. Cast [[spell:34914]] as it spawns, or time [[spell:1227280]]
   
   to land as it spawns, if possible.
3. Cast [[spell:120644]] as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon
4. Dump all Insanity into [[spell:335467]].
5. Cast [[spell:391399]] if ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon.
6. Cast [[spell:263165]].

Your burst will be even better if you are just performing your normal

rotation inside of cooldowns (especially at the start of them with [[spell:341240]]),

but the above sequence can be done outside of cooldowns if you prepare enough.

8.

### Defensive and Survivability Guide

As you get into higher keys or particularly challenging bosses,

it can be hard to survive through mechanics if you are not properly

prepared or if you do not react appropriately. In this section, I will

list out all the tools we have in our kit to survive keys as a Shadow Priest.

Before starting a key, you should evaluate your talent choices

to prepare for how intense that key will be. For any incoming mechanic,

you should know if you need to use a

Defensive to mitigate the hit to survive using the lists below.

8.1.

#### Talent Choice

Before you start a key, you should evaluate how difficult the dungeon is for

your group. If you are in a push key where it is relatively high for your group,

you should strongly consider adding more defensive talents, even if they cost you

some damage. This will need to be on a key-by-key basis, but here are your options.

If you find yourself wanting more defensive points but have run out of

points, you can choose to sacrifice various class talents that are less valuable.

8.1.1.

##### Class Talents

- [[spell:390667]]
- [[spell:193063]]
- [[spell:373446]]
- [[spell:238100]]
- [[spell:373450]]
- [[spell:108945]]

8.1.2.

##### Spec Talents

- [[spell:377065]]

8.2.

#### Gearing Defensively

One way to improve your defensiveness is to consider gear choices that you can make.

You have two primary ways of doing this: Adding in defensive items or adjusting

secondary stats. This can be critical for pushing higher keystones that become harder

to live and could even be worth losing some DPS to get more defensiveness.

8.2.1.

##### Secondary Stats

Another thing to consider is your secondary stats. By default Shadow Priests are

typically stacking a lot of Haste and Mastery gear, but you can also shift

some of this budget directly into Versatility for more damage. Shifting stats into

Versatility often is not that much of a DPS loss, even at lower gear levels. Check

out the stats page for more info on how to work this into your gear.

[Shadow Priest Stat Priority](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)

8.3.

#### Defensive Abilities

Shadow Priest has several defensive abilities that you should plan to use and rotate

throughout mechanics. You should opt to use the smaller cooldown spells often

as needed with incoming mechanics and save bigger cooldowns like [[spell:47585]]

for large incoming damage.

- [[spell:2061]] with [[spell:193063]] talented.
- [[spell:17]] for a small absorb.
- [[spell:586]] with [[spell:373446]] talented.
- [[spell:19236]]
- [[spell:47585]]

You can also use the [Not Even Close](<https://not-even-close.com/>)

site to help know what you need to live certain mechanics.

8.3.1.

##### Addons

- [
  
  Deadly Boss Mods - Dungeons](<https://www.curseforge.com/wow/addons/deadly-boss-mods-dbm-dungeons>) or
  
  [LittleWigs](<https://www.curseforge.com/wow/addons/little-wigs>)

9.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **25 Aug. 2026:** Add high-key build variant for Voidweaver.
- **17 Aug. 2026:** Update single-target breakdown by talent build.
- **10 Aug. 2026:** Add back Haunting Shadows in the Archon Mythic+ build.
- **10 Aug. 2026:** Update for Season 2 and Patch 12.1.
- **03 Aug. 2026:** Update rotation switches and dungeon utility tips for Season 2 utility grid.
- **15 Jun. 2026:** Reviewed for 12.0.7 with specific Y'Shaarj build for Voidweaver.
- **19 May 2026:** Add note about Idol of Y'Shaarj for Voidweaver build.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **06 Apr. 2026:** Add Mythic+ execution checklist and a practical log review section.
- **04 Apr. 2026:** Update Mythic+ Builds.
- **01 Apr. 2026:** Add caveat for Voidtouched.
- **29 Mar. 2026:** Suggest Archon for high key dungeons and add note about getting even more AoE damage.
- **18 Mar. 2026:** Update talent builds.
- **16 Mar. 2026:** Updated for Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent Trees for changes to class point gating.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **26 Aug. 2025:** Add video guide for talents and add Phantasm to Streets.
- **18 Aug. 2025:** Add a few more dungeon tips after week 1.
- **07 Aug. 2025:** Update Voidweaver builds after Deathspeaker bug was fixed.
- **04 Aug. 2025:** Update for Patch 11.2.0.
- **15 Jun. 2025:** Review information for Patch 11.1.7.
- **25 May 2025:** Reviewed information after recent hotfixes to still be accurate.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **19 Mar. 2025:** Add video link for the Rookery.
- **10 Mar. 2025:** Add more dungeon tips with video and weak aura links.
- **09 Mar. 2025:** Add dungeon tips after week 1.
- **01 Mar. 2025:** Add Mind Flay Voidweaver build and a few more dungeon tips.
- **24 Feb. 2025:** Updated builds for Season 2 with new tips for each dungeon.
- **15 Dec. 2024:** Recommend starting with Triple Idol.
- **04 Nov. 2024:** Reviewed for recent hotfixes.
- **21 Oct. 2024:** Swapped to using Sustained Potency by default for the pause mechanic out of combat for Archon builds.
- **15 Oct. 2024:** Remove Phantasm from City of Threads.
- **10 Oct. 2024:** Update Voidweaver builds.
- **09 Oct. 2024:** Update Single Target + Shadow Crash Voidweaver build.
- **07 Oct. 2024:** Update build suggestions after recent hotfixes.
- **01 Oct. 2024:** Add tip for Mistcaller about using Dodge Ball to kill the adds.
- **25 Sep. 2024:** Give the Hybrid build its own section.
- **16 Sep. 2024:** Update talent sections to be more readable.
- **09 Sep. 2024:** Add variant to Archon M+ build to get more single target.
- **31 Aug. 2024:** Update Single Target + Shadow Crash build for Voidweaver and condense Archon into a single build.
- **22 Aug. 2024:** Updated page for the launch of The War Within.
- **13 Aug. 2024:** Update talent builds to start using Idol of C'Thun again and adjust for Class Tree changes.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **13 May 2024:** Add section on gearing defensively for high keys.
- **09 May 2024:** Add note about Mind Control tech on Granyth in Nokhud.
- **07 May 2024:** Reviewed for 10.2.7.
- **30 Apr. 2024:** Add Phantasm suggestion for Uldaman and add note about Maddening Touch usage.
- **29 Apr. 2024:** Fix bug in switcher for suggesting Purify Disease in Ulda.
- **28 Apr. 2024:** Add Phantasm for Halls of Infusion.
- **26 Apr. 2024:** Add Purify Disease and Dominate Mind for Nokhud.
- **25 Apr. 2024:** Remove Phantasm suggestion for Azure Vault.
- **22 Apr. 2024:** Update builds for Season 4.
- **19 Mar. 2024:** Add Holy Nova suggestion for Throne of the Tides and new Mind Control tech for Black Rook Hold and Galakrond's Fall.
- **19 Feb. 2024:** Add Mind Flay Mind's Eye variant for the Ghost Priority build.
- **14 Feb. 2024:** Fix name in widget for the Ghost build and add direct talent strings for Mind's Eye versions.
- **13 Feb. 2024:** Update default class talents for all builds and update Shadowy Apparitions build to be the Ghost Priority Build version.
- **13 Feb. 2024:** Remove mention of Stinger Mind Control in Everbloom.
- **09 Feb. 2024:** Add note about Rockspine Stinger Mind Control.
- **08 Feb. 2024:** Add aoe rotation video link.
- **28 Jan. 2024:** Suggest Mass Dispel for all Afflicted keys.
- **21 Jan. 2024:** Update Void Eruption Mythic+ build defaults from recent buffs.
- **15 Jan. 2024:** Add video links and a few more WeakAuras.
- **23 Dec. 2023:** Add build option for dropping Mindbender and Inescapable Torment.
- **18 Dec. 2023:** Update Mythic+ builds from recent Psychic Link buffs.
- **13 Dec. 2023:** Dropped Idol of Y'Shaarj to use Insidious Ire instead for key builds.
- **08 Dec. 2023:** Suggest Mass Dispel by default in Throne of the Tides.
- **03 Dec. 2023:** Update Dark Ascension Triple Idol build to default to Mind Flay.
- **01 Dec. 2023:** Add more info about when to pick which build. Refactor Shadowy Apparitions build to work better with the Season 3 set bonus.
- **25 Nov. 2023:** Add more Dispel suggestions to various dungeons.
- **24 Nov. 2023:** Add Purify Disease to Atal'Dazar suggestions.
- **20 Nov. 2023:** Change the name of the Season 2 build to the Shadowy Apparitions build and go over use cases.
- **17 Nov. 2023:** Update Mythic+ builds for Season 3 to be more streamlined.
- **16 Nov. 2023:** Add Season 2 tier set build to use while gearing up.
- **06 Nov. 2023:** Reorder sections and update information for Season 3 and Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **13 Aug. 2023:** Update video link and clarify differences between triple idol setups.
- **09 Aug. 2023:** Add more detail on when to pick which build as well as touching up several sections to make things clearer.
- **08 Aug. 2023:** Add new section clarifying when to use each dungeon build.
- **07 Aug. 2023:** Add new builds from recent hotfix nerfs to various spells.
- **31 Jul. 2023:** Add a few missing entries for Mass Dispel use cases.
- **23 Jul. 2023:** Reviewed from the recent hotfixes and mentioned new talent options.
- **17 Jul. 2023:** Refactor to use new talent layout.
- **10 Jul. 2023:** Updated talent strings for Patch 10.1.5.
- **27 Jun. 2023:** Adjust builds to include Distorted Reality, Dark Ascension, and Mindbender options.
- **23 Jun. 2023:** Update some figures for Distorted Reality.
- **22 Jun. 2023:** Correct issue with Mind Flay vs. Mind Spike comparisons.
- **20 Jun. 2023:** Clarify DR vs. ME and Mind Spike vs. Mind Flay DPS breakdowns.
- **16 Jun. 2023:** Add more detail on why to use Mind Spike in keys.
- **07 Jun. 2023:** Add section on burst damage.
- **30 May 2023:** Add a few mouseover macros for handling Season 2 affixes.
- **28 May 2023:** Remove Purify Disease and Mind Control suggestion for Halls of Infusion.
- **26 May 2023:** Shuffle sections around and add more detail around defensive usage.
- **24 May 2023:** Remove part of the sample opener in favor of the rotation page.
- **22 May 2023:** More tips and details for Season 2.
- **21 May 2023:** Add easy way to see utility choices by dungeon and affix.
- **19 May 2023:** Add Mind Control section for interesting mobs to control.
- **06 May 2023:** Suggest Mass Dispel for Halls of Infusion and add more detail on Mind Flay in Mythic+.
- **04 May 2023:** Add Season 2 dungeon utility section.
- **01 May 2023:** Updated talent builds and suggestions for 10.1.0.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **26 Feb. 2023:** Correct error in Mindgames target cap.
- **22 Feb. 2023:** Add caveat for using Mind Sear in Mythic+.
- **17 Feb. 2023:** Add more detail to the example opener.
- **04 Feb. 2023:** Adjust single target differences for common builds.
- **02 Feb. 2023:** Add more uses for Dispel and Mass Dispel.
- **24 Jan. 2023:** Update talent builds and suggestions for 10.0.5.
- **12 Jan. 2023:** Add Void Tendrils suggestion for Spiteful affix.
- **11 Jan. 2023:** Add new talent builds from the recent buffs.
- **23 Dec. 2022:** Add more detail to picking between the two talent builds in Mythic+.
- **11 Dec. 2022:** Add some start of season 1 tips.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **05 Nov. 2022:** Add a section on the Mythic+ opener and easy version of the priority list.
- **31 Oct. 2022:** Updated talent builds to no longer suggest Psychic Link and removed Idol-less build.
- **26 Oct. 2022:** Updated builds to pickup Translucent Image.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Shadow Priest in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Shadow Priest macros. You can import
these by simply clicking the "Copy" button on each individual block.

1.1.

#### Angelic Feather

#### Angelic Feather

```wow-macro
#showtooltip
/cast [@player] Angelic Feather
```

This is a simple macro that will always cast [[spell:121536]] at your 
feet.

1.2.

#### Angelic Feather + Body and Soul

#### Movement All-in-One

```wow-macro
#showtooltip
/cast [known:121536,mod:shift,@player] Angelic Feather; Power Word: Shield
```

This macro simply combines [[spell:121536]] and
[[spell:17]] with
one macro, so you can easily use both with mostly the same keybind. This has
default press Power Word: Shield, or pressing the same keybind with Shift
casts Angelic Feather.

#### Movement Rotation

```wow-macro
#showtooltip
/castsequence [known:121536,@mouseover,help,nodead][known:121536,@player] reset=6 Power Word: Shield, Angelic Feather, Angelic Feather, Angelic Feather; Power Word: Shield
```

This is another version of a movement macro that lets you spam the button
over and over to cast the right movement spell, starting with 
[[spell:17]]. If you are looking for something simpler and do not 
want a mod:shift one, you can try this one out instead.

1.3.

#### Power Infusion

#### Basic Power Infusion

```wow-macro
#showtooltip
/cast [@INSERTPLAYERNAMEHERE,help,nodead][] Power Infusion
/cast [@player] Power Infusion
```

When using [[spell:373466]], this is a useful macro to
cast [[spell:10060]] on an ally to make sure your group gets the most out
of it.
You will need to manually type in the player you wish to give Power Infusion to,
but it should handle if the target is out of range of you to still cast it on
yourself. If you want to cast it on different players throughout an encounter
I would suggest replacing **@INSERTPLAYERNAMEHERE** with **@mouseover** and mousing
over the target you want to give it on for each cast.

If you are having issues with this sometimes not working correctly, you should
try to avoid spamming the macro when you want to cast it. If you queue the macro
as an action mid-cast of something else, it can short-circuit.

1.4.

#### Advanced Power Infusion Macro

If you find yourself editing the macro often to swap who you are giving
[[spell:10060]] to, you can use the below combination of macros to make this 
easier.

The first macro requires you to target the player you want to give 
[[spell:10060]] to. When clicking the macro, it will then update the
second macro with the name of the target, so you do not need to manually type it in.

#### Advanced Power Infusion

```wow-macro
/run local n=UnitName("target") or "player" if not InCombatLockdown() then EditMacro(GetMacroIndexByName("PI"),nil,nil,"#showtooltip\n/use 13\n/cast [@mouseover,help,nodead][@"..n..",exists,nodead][] Power Infusion") print("PI Updated to "..n) end
```

The second macro will be automatically edited and overwritten when 
clicking the first macro. If you want to change anything in this macro, you
must change it in the first one. You **MUST** name this second macro
<em>PI</em> in order for it to work properly.

This macro will be the one you actually end up binding to your bars
and pressing. It will cast [[spell:10060]] on your **mouseover**
if it exists and is alive, then the Player you selected with the first macro,
and finally yourself if the first two conditions failed. It will also use your
trinket in the top slot, if you want to use the trinket in the bottom slot
instead, change it from 13 to 14 on the last line.

#### Power Infusion + First Trinket

```wow-macro
#showtooltip
/use 13
/cast [@mouseover,help,nodead][@PLAYERNAME] Power Infusion
/cast Power Infusion
```

1.5.

#### All in one Dispel Macro

#### Dispel All-in-One

```wow-macro
#showtooltip
/cast [mod:alt,known:32375] !Mass Dispel; [@mouseover,help,nodead] Purify Disease; [@mouseover,harm,nodead] [harm] Dispel Magic; Purify Disease
```

This gives you one button in-game that handles all of your dispel needs across the Priest specs.
Alt is used for [[spell:32375]]; if the target is an enemy, it uses [[spell:528]], and
the default case is either [[spell:213634]] or [[spell:527]].

If you are just looking for a simple mouseover for one of these, you can use this instead:

#### Purify Disease Mouseover

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] Purify Disease
```

Simple [[spell:32375]] Cursor Macro:

#### Mass Dispel Cursor

```wow-macro
#showtooltip
/cast [@cursor] Mass Dispel
```

1.6.

#### Shackle Horror Macro

#### Shackle Horror Mouseover

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] Shackle Horror
```

This is a simple mouseover macro for [[spell:9484]] that can be 
useful in certain Mythic+ situations.

1.7.

#### Mind Control Macro

This macro offers a one-button solution for either [[spell:605]] or [[spell:205364]].
Clicking it without an active pet will cast either spell on your current target. If you have an active
pet Mind Controlled, it will instead dismiss it.

#### Mind Control

```wow-macro
#showtooltip
/petdismiss
/cast [known:Mind Control] Mind Control; Dominate Mind
```

You can also use this additional step to control where the pet moves:

#### Mind Control Move

```wow-macro
/petmoveto [@cursor]
```

2.

### Macros for Shadow Priests

2.1.

#### Void Torrent and Halo

If you want a simple macro to swap between these two spells you can do something like this:

#### Void Torrent and Halo

```wow-macro
#showtooltip
/cast [known:Void Torrent] Void Torrent; Halo
```

2.2.

#### No-Cancel Stop Casting

If you find yourself spamming your buttons too quickly and cancelling 
important spells like [[spell:263165]] you can adjust your spells like so.

#### Mind Blast

```wow-macro
#showtooltip
/stopmacro [channeling:Void Torrent]
/cast Mind Blast
```

With these kinds of macros, it will only cast [[spell:8092]]
if you are not channeling [[spell:263165]]. This can be useful if you 
like to spam your buttons.

2.3.

#### Silence

#### Focus Silence

```wow-macro
#showtooltip
/cast [@focus,harm,nodead][] Silence
```

This is a basic macro I would suggest to anyone playing a spec with a kick.
It prioritizes
kicking your focus target and then defaults to your current target if you do not
have a focus.
You can also add mod:shift as an extra conditional if you only want to kick your
focus target
with a keybind used.

2.4.

#### Mind Flay Camera Spin

#### Camera Spin

```wow-macro
/console cameraSmoothTrackingStyle 0
```

This is not a macro, but a console command that will prevent
[[spell:15407]] from spinning your camera when it channels. This can be very
helpful for players who find the camera interference annoying.

2.5.

#### Mouseover Macro for DoTs

#### SW:P Mouseover

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] [] Shadow Word: Pain
```

#### VT Mouseover

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] [] Vampiric Touch
```

These macros cast [[spell:589]] and [[spell:34914]] at your
current mouseover target without having to target their nameplate directly.
This is particularly useful in multi-DoT situations in council boss
scenarios.

3.

### Best Addons

In Midnight there are many addons that you can add to customize your UI experience.
For a full walkthrough of my guide you can check out the 
[Book of 
Shadows](<https://warcraftpriests.github.io/bookofshadows/guides/ui>).

Below is a list of the Addons I suggest checking out.

3.1.

#### Main HUD

For the main interface I utilize EllesmereUI and then add a few extra pieces.

- [EllesmereUI](<https://www.curseforge.com/wow/addons/ellesmereui>)
- [Platynator](<https://www.curseforge.com/wow/addons/platynator>)

3.2.

#### Combat Related Addons

- [TargetedSpells](<https://www.curseforge.com/wow/addons/targetedspells>)
- [BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>)

3.3.

#### Generic Addons

- [Astral Keys](<https://www.curseforge.com/wow/addons/astral-keys>)
- [Plumber](<https://www.curseforge.com/wow/addons/plumber>)
- [Glider](<https://www.curseforge.com/wow/addons/glider>)
- [MinimapStats](<https://www.curseforge.com/wow/addons/minimapstats>)

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Season 2 and Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Season 1.
- **06 Mar. 2026:** Add in Void Torrent + Halo macro.
- **26 Feb. 2026:** Update style to allow for easily copying of macros.
- **10 Feb. 2026:** Swap from Shackle Undead to Shackle Horror.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **29 Aug. 2025:** Update Power Infusion macros to use Trinkets before casting Power Infusion.
- **11 Aug. 2025:** Update all in one Shadow Crash macro.
- **04 Aug. 2025:** Update for Patch 11.2.0 with a new macro.
- **15 Jun. 2025:** Review information for Patch 11.1.7.
- **25 May 2025:** Reviewed information after recent hotfixes to still be accurate.
- **21 Apr. 2025:** Add note about the new Cooldown Manager for Patch 11.1.5.
- **13 Mar. 2025:** Remove Mind Flay: Insanity macros that are no longer useful.
- **24 Feb. 2025:** Reviewed for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **16 Nov. 2024:** Update all in one dispel macro and stopmacro channeling to be more concise.
- **04 Nov. 2024:** Reviewed from recent hotfixes.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **18 Sep. 2024:** Updated for Patch 11.0.5, removed older macros and added new WeakAuras.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Add new WeakAura links.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **25 Apr. 2024:** Adjust plater mod links and add personal profile.
- **22 Apr. 2024:** Update for Season 4, including a new weak aura to track the tier set bonus.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **10 Mar. 2024:** Update Power Infusion special macro to work outside of raid without someone set.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **30 Nov. 2023:** Add a few new WeakAuras and Plater mods.
- **06 Nov. 2023:** Reviewed for Patch 10.2.0.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **23 Jul. 2023:** Reviewed from the recent hotfixes.
- **10 Jul. 2023:** Add a new Power Infusion macro.
- **01 Jun. 2023:** Add simple Mass Dispel macro.
- **30 May 2023:** Add a few mouseover macros for handling Season 2 affixes.
- **25 Apr. 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **03 Feb. 2023:** Fix issue with Mind Control macro.
- **24 Jan. 2023:** Add a macro for Mind Control and clean up a few others.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **30 Oct. 2022:** Added extra movement macro.
- **27 Oct. 2022:** Updated PI macro and added a new one for talent choice nodes.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
