## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Saeldur。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-guide>)
- [练级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)

## 专精概览

欢迎阅读我们的 增辉 唤魔师 指南，适用于《魔兽世界》12.1.5 补丁。在这里，你将学习如何在团队副本和大秘境地下城中扮演 增辉 唤魔师：从最基础的入门到最大化你的伤害输出。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

增辉 大秘境资源

[全新！顶尖 增辉 天赋构建](<https://raider.io/specs/augmentation-evoker/talents>)

[顶尖 增辉 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/evoker/augmentation>)

[增辉 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=evoker--augmentation>)

[热门 增辉 队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=evoker--augmentation>)

1.

### 增辉 唤魔师 概览

增辉 唤魔师 是一个以辅助为导向的远程法术伤害专精，专注于在队友身上维持强大的增益效果以造成伤害。

增辉 是目前游戏中唯一以辅助为导向的伤害输出专精，与现有的其他伤害输出选择相比提供了独特的体验。增辉 唤魔师 提供了大量实用技能，可以在战斗中使用以进一步协助队友。总体而言，凭借强大的伤害和实用性，它是团队副本和大秘境的绝佳选择。

增辉 唤魔师 是《魔兽世界》中第一个以辅助为导向的专精，充当中距离法术伤害输出，并且拥有 **25码射程** 适用于其大部分技能，不过你的有益法术（增益、治疗）可以通过 [[spell:454983]] 延伸至30码。

强大而灵活的伤害

增辉 唤魔师拥有强大而独特的伤害机制，其伤害会镜像其盟友造成的伤害。这让你能够在任何场景下进一步强化队伍的优势，使你能够应对战斗中出现的任何情况。

增辉 唤魔师的巅峰天赋非常出色，既能增强增益效果，也能提升自身伤害。

增辉 唤魔师在与较弱的队友配合时，DPS会略有下降，因为其大部分伤害来自增益效果。尽管如此，在你的特定团队中它始终具有竞争力。

出色的团队副本选择

在团队副本中，唤魔师 的 增辉 对于任何团队来说都是非常强大的选择，提供强大的功能性、高机动性、良好的防御能力和一次免死机会。此外，唤魔师 的 增辉 可以使用强大的可叠加的 唤魔师 团队副本功能性技能，例如 [[spell:374227]]、[[spell:406732]] 或 [[spell:374968]]。

大秘境中出色的伤害与功能

增辉唤魔师在至暗之夜第2赛季的表现比第1赛季略弱，但仍是可行的选择。尽管第2赛季遭到了削弱，增辉唤魔师仍明显强于至暗之夜之前的状态。

此外，增辉 唤魔师拥有非常适合大秘境的技能组合，包括来自[[spell:396286]]的频繁群体控制、用于跳怪的真正控制技能[[spell:360806]]，以及像[[spell:374251]]这样可以移除流血效果的强大功能技能。

多功能工具

增辉拥有大量功能技能，在所有内容中都非常强大。增辉可以通过[[spell:374227]]提高其他盟友的生存能力；通过[[spell:406732]]、[[spell:374968]]、[[spell:370665]]或[[spell:408233]]改善盟友的机动性；通过[[spell:358385]]、[[spell:360806]]、[[spell:396286]]、[[spell:357214]]或[[spell:307974]]控制敌人。

增辉 唤魔师可以通过被[[spell:418101]]强化的[[spell:369459]]来提升治疗者的能力。这有助于弥补大秘境中缺乏强力团队增益的不足。除此之外，[[spell:374251]]让增辉每分钟可以驱散几乎任何负面效果，包括流血效果！这极大地帮助治疗者应对战斗，因为游戏中充满了极其危险的负面效果。

出色的防御技能和免死效果！

增辉 唤魔师拥有免死效果以及强大的防御技能。增辉的主要防御技能[[spell:363916]]有两次充能，提供了出色的灵活性和顶级的生存能力。

增辉 唤魔师拥有的防御技能包括：[[spell:363916]]、[[spell:374227]]和[[spell:404195]]（这是一个冷却时间为6分钟的免死效果，使用[[spell:1268881]]后为5分钟）。

卓越的机动性

增辉 唤魔师拥有出色的机动性，可以使用[[spell:358267]]，使其在移动时可以施放所有法术，除了蓄力技能（[[spell:357208]]和[[spell:396286]]）之外。

此外，[[spell:358267]]允许它在按住方向键时快速穿越很远的距离，因为它会向该方向冲刺。

1.

### 增辉 唤魔师在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

本次更新带来了两个有趣的新终局内容：一场可以挑战的新团队副本，以及全新的终局 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)
内容等待探索。请务必查看关于全新基斯希克斯团队副本首领战以及令人兴奋的全新迷宫巨型地下堡的信息！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

主要变化将来自基斯希克斯团队副本遭遇战的新物品。最值得注意的是一个饰品、一个戒指和一副手套。此外，你将能够从10月20日起使用[[item:280562]]升级物品。武器、项链和饰品都可以升级。

2.3.

#### 职业改动

唤魔师增辉在12.1.5补丁中对[[spell:406380]]进行了一些小的错误修复。他们将之前遗漏的几个法术添加到了持续时间延长效果中。最值得注意的新加入法术包括来自的[[spell:431695]]
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫的[[spell:1297728]]以及来自[[spell:1296638]]的法术。这略微提升了我们的精通收益，但精通本来就是我们最强的属性，因此这不会改变任何配装选择。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/classicon_evoker_augmentation.jpg>)点击查看上赛季第二赛季的改动
2.4.

#### 12.1版本改动

随着第二赛季一同到来的是一个广阔的新区域，其中包含大量新地点和活动，与终局PvE和PvP内容并行。新区域是 [盘卷岛](<https://www.icy-veins.com/wow/the-coiled-isle-guide>) 它将使你能够进入
[阿塔尔乌泰克宝库](<https://www.icy-veins.com/wow/vaults-of-atalutek-guide>) 这里是12.1版本故事发生的主要地点，包含需要狩猎的新稀有怪和宝藏，以及新的房屋和幻化物品。暴风雪还对现有系统进行了重大更新，并添加了更多生活质量改进。欲了解更多信息，请查看下方链接的12.1版本专题页面！

2.5.

#### 补丁12.1职业改动

增辉 唤魔师的英雄天赋在至暗之夜第二赛季中获得了一些影响深远的改动，这些改动改变了最优英雄天赋选择、天赋构建和属性优先级。我们将在下方简要介绍这些改动。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长的[[spell:441206]]遭到了大幅削弱，极大地降低了该天赋的威力。现在你在单体目标上获得的冷却缩减大约只有之前的一半。暴风雪试图通过增强与[[spell:403631]]施放相关的伤害节点来弥补伤害损失，但这不足以抵消[[spell:1259173]]正常运行时间的损失。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫的[[spell:431874]]已重新设计为施放[[spell:395152]]时获得的临时增益，而不再持续整个施法过程。此改动会使以下构筑的DPS降低约1-2%：
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫的DPS大约降低了1-2%，并削弱了增辉的暴击属性收益。

此外，在第二赛季中，作为增辉 唤魔师，你可以获得一套新的套装奖励，详情如下：

- 2件套奖励：[[spell:1296637]] — [[spell:396286]]的冷却时间缩短10秒。
- 4件套奖励：[[spell:1296638]] — 施放[[spell:396286]]会使你的[[spell:412774]]效果强化8秒，将伤害回响的数值提升至45%（通常为15%）。

由于上述所有改动以及新的套装奖励，我们将转向 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫以增益为核心的玩法。我们将专注于堆叠精通，同时使用[[spell:409267]]以获得更强的[[spell:413984]]以及更高的其他辅助增益（如[[spell:409311]]）的正常运行时间，尤其是我们的新套装奖励提升了[[spell:412774]]的伤害。

由于更加重视增辉的增益，正确选择[[spell:409311]]的目标现在更加重要，相比使用自动选目标大约可获得3-5%的DPS提升。

要查看完整的改动列表，请见下方：

[乌拉特克之诅咒 补丁说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281/#item16>)

**增辉 唤魔师**

<em>开发者说明：重复施放地壳激变所带来的额外控制力对地下城玩法的影响超出了预期，并且由于其时机不可控，在某些情况下可能会令人沮丧。</em>

- 顶峰天赋：[[spell:1259173]] — 你的[[spell:1259173]]施放的[[spell:396286]]不再将敌人击飞。
- 所有技能和宠物伤害提高3%。
- 至暗之夜第一赛季的2件套奖励不再增加喷发延长[[spell:395152]]的持续时间。
- [[spell:404195]]、[[spell:355913]]、[[spell:361469]]、[[spell:410643]]、[[spell:387761]]和[[spell:360995]]的治疗量提高25%。
- 英雄天赋
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫
  - - <em>开发者说明：[[spell:395152]]暴击时的属性加成持续整个[[spell:395152]]持续时间这一行为，对追踪[[spell:395152]]的暴击状态的重视程度超出了预期，并且在是否重新施放[[spell:395152]]这一问题上造成了不直观的决策空间。</em>
    - [[spell:431874]]已更新 — 当[[spell:395152]]暴击时获得的额外属性现在持续15秒（受[[spell:406380]]影响）。如果[[spell:395152]]在[[spell:431874]]已激活时重新施加，[[spell:431874]]的持续时间将被延长，而不是覆盖之前的[[spell:431874]]效果。[[spell:431874]]与[[spell:409311]]的互动机制保持不变。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长
  - - <em>开发者说明：[[spell:441206]]的冷却缩减机制强烈鼓励将[[spell:434300]]的应用分散到多个目标上。我们认为这种玩法本身并不直观，并且还会产生不健康的行为，例如囤积[[spell:438587]]。此次重新设计旨在保留该天赋的多目标重点，同时解决这些问题。我们正在增加鳞长的部分范围伤害来源，以补偿新的[[spell:441206]]所提供的冷却缩减减少，并将在PTR期间密切关注湮灭和增辉的表现，以便根据需要进行进一步调整。</em>
    - [[spell:441206]]已重新设计 — [[spell:438587]]每命中一个目标，就会使[[spell:403631]]的剩余冷却时间减少1.5秒。
    - [[spell:1260745]]的[[spell:1236970]]伤害提高40%。
    - [[spell:433871]]的持续伤害提高40%。

:::

### 至暗之夜改动概述

2.6.

#### 至暗之夜 增辉 唤魔师改动总结

随着至暗之夜资料片的上线，增辉 唤魔师获得了一系列改动，这些改动对其玩法进行了小幅调整，总体目标是简化其在增益方面的即时决策，主要是在团队副本中。我们将这些改动细分为更小的类别，以便更容易理解增辉 唤魔师在至暗之夜期间所获得的改动。增辉 唤魔师所获得的所有改动已列于下方。

2.7.

#### 巅峰天赋

在至暗之夜中升级时，你将获得顶峰天赋。这些是位于专精天赋树底部的强大节点。你可以在81、84、87和90级时将天赋点投入到这些节点中。增辉的顶峰天赋如下：

- [[spell:1259173]]
- [[spell:1259174]]
- [[spell:1259175]]

增辉的顶峰天赋围绕[[spell:1259173]]展开。这使[[spell:403631]]能够召唤一个宠物，与你一同施放[[spell:396286]]、[[spell:357208]]和[[spell:395160]]。这些施放只造成伤害，不会延长你的[[spell:395152]]或触发[[spell:413984]]。在分形期间，由于第四个顶峰天赋点[[spell:1259175]]，你会获得个人伤害和[[spell:395152]]威力的显著提升。

增辉 唤魔师的第二和第三个顶峰天赋点[[spell:1259174]]和[[spell:1259175]]将使任何延长[[spell:395152]]的效果也会以50%/100%的效果延长分形。这使你转向专注于急速和暴击几率，因为这两者都会影响分形的正常运行时间，而全能和精通则不会。

有关顶峰天赋的更多信息，请查看
[我们天赋页面上的专属部分](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents#apex>).

2.8.

#### 增益改动

我们的增益机制获得了重大改动。这些改动不影响大秘境中的玩法，同时使团队副本的玩法与大秘境更加相似。在团队副本中，今后唯一需要你手动选择目标施放的增益是[[spell:409311]]，它不再有次要影响，因为[[spell:395152]]现在会影响所有人。这让你可以专注于增益那些造成最多伤害的队友 **现在**，而无需考虑他们30秒后会打出多少伤害。

这些改动导致团队副本中增益威力略有下降，团队副本中增益管理大幅简化，以及大秘境中增益效果显著提升（[[spell:395152]]提升45%，[[spell:403631]]提升36%）。

总而言之，这些改动使团队副本和大秘境的玩法在循环和输出方面更加同步，规范了该职业在所有内容中的运作方式。这应该会让暴风雪今后的调整工作变得更加容易。

:::details **点击展开查看改动。**
[至暗之夜测试服开发说明](<https://www.wowhead.com/blue-tracker/topic/us/midnight-beta-test-development-notes-2174760>)

开发者说明：这些改动的目标是简化团队副本环境中黑檀之力的目标选择。由于它现在会作用于团队中的所有成员，因此无需再对应该施放在谁身上进行微管理。仍然会有一些关于先知先觉的增益管理玩法，它将继续为那些不想在敌人和盟友之间频繁切换目标的玩家提供智能选目标选项。总体而言，这应该会让团队副本玩法更加流畅，并与地下城玩法相似。

- [[spell:395152]]会作用于100码范围内的所有造成伤害的盟友，DPS现在可以受到任意数量的[[spell:395152]]影响。
- [[spell:403631]]和[[spell:403631]]现在在影响超过两名其他盟友时会降低效果。
- [[spell:395152]]现在提供8%的主属性（原为5%）。
- [[spell:403631]]现在累积15%的伤害（原为10%）。
- [[spell:396043]]已被禁用，因为它不再需要用来使大秘境和团队副本达到平衡。
- [[spell:409311]]仍然最多只能存在2个（每个增辉 唤魔师1个）。
- [[spell:413984]]仍然最多只能存在1个。

:::

2.9.

#### 时空守卫改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫获得了相对重大的改动，使其整体游戏体验更加流畅，玩起来更加一致，并降低了循环摩擦。现在的设计侧重于更强的[[spell:409311]]施放，同时移除了诸如试图在[[spell:431695]]期间最大化强化施放次数之类的限制。这些改动与将 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫打造为增辉 唤魔师主要增益型英雄天赋的目标相一致。

:::details **点击展开查看改动。**
- 移除的天赋：[[spell:431715]]和[[spell:431840]]。
- 重做的天赋：[[spell:432004]] — 现在使[[spell:409311]]的持续时间延长15%（之前为20%几率延长100%）。
- 新天赋：[[spell:431715]] — 使[[spell:409311]]的冷却时间缩短2秒，并将其提供的暴击几率加成从1%提高到4%。
- 新天赋：[[spell:1260484]] — 使[[spell:370553]]的冷却时间缩短30秒。
- 新天赋：[[spell:1260568]] — [[spell:431695]]每6秒提供一次[[spell:396187]]（总计5次[[spell:396187]]）。
- 新天赋：[[spell:293930]] — [[spell:431442]]的最大伤害提高40%。

:::

2.10.

#### 鳞长改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长获得了相对较小的改动，选择进一步加倍下注于提高[[spell:395160]]的伤害以及增辉 唤魔师的个人伤害输出。这些改动不会改变你的玩法，并允许你进一步专精于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长已经擅长的领域。

:::details **点击展开查看改动。**
- 新天赋：[[spell:1260745]] — 在[[spell:403631]]或[[spell:357210]]飞行期间召唤2个龙希尔，每个最多施放4次[[spell:1236970]]（总计8次）。
- 新天赋：[[spell:1261448]] — [[spell:438587]]额外命中1个目标。
- 新天赋：[[spell:1261452]] — [[spell:395160]]的伤害提高15%。
- 调整过的天赋：[[spell:441257]] — 现在只提供一层[[spell:358267]]，而不是重置所有层数。

:::

2.11.

#### 防御改动

增辉 唤魔师的防御天赋遭到了几次削弱，导致今后生存能力略有下降，其中最值得注意的是失去了[[spell:370888]]这一防御选项。作为更广泛的全游戏治疗和防御平衡调整的一部分，其他专精也正在对其防御能力进行类似的削弱，因此增辉 唤魔师相对于其他职业仍然非常耐打。

:::details **点击展开查看改动。**
- 重做的天赋：[[spell:370888]] — 现在使你和[[spell:370665]]目标的移动速度提高100%，并允许在移动中施法3秒，而不是提供一个相当于你30%生命值的吸收护盾。
- 重做的天赋：[[spell:374348]] — 这现在是一个被动效果，使[[spell:363916]]在8秒内治疗你相当于其减免伤害的100%（之前是一个主动防御技能）。
- 新天赋：[[spell:1268881]] — 使Defy Fate的冷却时间缩短1分钟，并使其治疗量提高100%。
- 移动位置的天赋：[[spell:410352]] — 这现在位于职业天赋树上，而不是专精天赋树上，并且已被增强，在[[spell:403631]]期间延迟承受你受到的所有伤害的100%。
- 移除的天赋：[[spell:386405]]

:::

2.12.

#### 核心法术和天赋改动

增辉 唤魔师的法术和天赋获得了一些改动，这些改动只会对循环产生微小的影响。最重要的循环改动来自于[[spell:459725]]。有了新的[[spell:459725]]，现在最优的策略是只使用1级[[spell:357208]]，而不是升级它。其他改动主要贡献于生活质量以及对伤害输出的小幅调整。

:::details **点击展开查看改动。**
- 法术改动：[[spell:358267]] — 现在可以在施法时施放，为你提供[[spell:358267]]增益。它也不再有施法动画锁定，让你几乎可以在任何时候使用它（强化施法期间除外）。
- 新天赋：[[spell:1250914]] — 使[[spell:409267]]的触发几率提高10%，并允许它为盟友提供[[spell:409311]]。
- 重做的天赋：[[spell:459725]] — 受[[spell:357208]]影响的敌人现在受到的黑色法术伤害提高25%（之前，根据强化等级在10%到40%之间浮动）。
- 重做的天赋：[[spell:459537]] — [[spell:403631]]使你接下来的4次[[spell:395160]]的精华消耗降低1点，最多可叠加8层（之前持续15秒，并在持续期间使[[spell:395160]]伤害提高10%）。
- 增强的天赋：[[spell:408775]] — [[spell:396187]]使[[spell:395160]]的施法时间缩短40%，并使其伤害提高20%（之前只缩短施法时间）。移动到了[[spell:1219236]]的原位置。
- 增强的天赋：[[spell:406907]] — 现在使[[spell:360827]]的伤害提高20%，并阻止其损失层数（之前，增加5层，并且每当你施放[[spell:395160]]时获得额外一层）。
- 增强的天赋：[[spell:410261]] — 当施放[[spell:357208]]时，你和一名附近盟友获得炼狱祝福增益。[[spell:410261]]的伤害提高了4倍，以补偿其影响的目标减少（之前影响你和4名盟友）。
- 移除的天赋：[[spell:1219236]]
- [[spell:351338]]现在在增辉天赋树中学习。

:::

1.

### 增辉 唤魔师玩法基础

增辉 唤魔师的核心玩法是增益你的盟友，并通过施放[[spell:409311]]和维持[[spell:395152]]来实现这一目标。增辉 唤魔师有许多有助于此的互动机制。增辉 唤魔师的骨干玩法最好通过这三个概念来总结。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_sarkareth.jpg>)
  **维持你的黑檀之力**
  
  
  
  
  ```
  Augmentation's main damage contributor is [[spell:395152]], as it
  provides a large primary stat buff to your allies while also boosting your
  own damage. Your highest priority is to maintain this buff by casting
  [[spell:395152]], [[spell:357208]], [[spell:396286]] and
  [[spell:395160]] as much as possible.
  ```
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_prescience.jpg>)
  **循环使用技能冷却**
  
  
  
  
  ```
  Augmentation has three important short cooldown abilities:
  [[spell:357208]], [[spell:396286]] and [[spell:409311]]. These
  abilities cause powerful buffs on allies that make up a large portion of
  your damage meaning it is crucial to maximise uses!
  ```
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_eruption.jpg>)
  **消耗所有可用资源**
  
  
  
  
  ```
  Augmentation has two important resources: Essence and
  [[spell:396187]]. These can be used to cast
  [[spell:395160]] which is crucial to deal damage and maintain
  [[spell:395152]]. You will generate Essence over time and get
  [[spell:396187]] from [[spell:409311]] and
  [[spell:361469]].
  ```

你的循环深度大部分来自于为[[spell:409311]]选择正确的目标，并利用上述各种互动机制尽可能长时间地延长[[spell:395152]]。

1.

### 作为增辉 唤魔师如何配装

虽然我们始终建议你自己进行模拟以获得理想结果，但我们确实提供了一个专门的增辉配装页面。我们目前涵盖了第二赛季装备的建议，以便在终局至暗之夜内容发布时有一个良好的开端。一旦你获得了一些装备，你就需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对12.1.5补丁更新。
- **2026年10月12日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对12.1.5补丁更新，添加了新的团队副本首领物品。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审阅
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对12.1.5补丁更新，包括新的大秘境配装。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 根据这些改动更新了饰品天梯榜和制造建议。
- **2026年8月18日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 在时空守卫的起手循环中添加了缺失的永恒之焰施放。
- **2026年8月12日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 修正了大秘境物品来源中戒指和披风的错别字。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（本页）：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月26日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 由于导致平均层数减少的错误未被修复，在大秘境梯队列表中移除了奥恩之眼。
- **2026年6月16日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 孢子融合部分的错别字修复。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 新增孢子融合装备部分。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已更新至12.0.7补丁。为高层钥匙添加了霸主构建。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 为12.0.7版本更新，添加了万法书页的信息。将高层大秘境天赋改为霸主。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月4日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新大秘境饰品排名。
- **2026年5月4日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 调整天赋构建的注释。天赋构建本身没有变化。
- **2026年5月4日（本页）：** 为5月5日/6日的平衡性调整更新。
- **2026年4月30日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 修正拼写错误。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新装备部分，添加升腾虚空核心和缥缈虚空核心。更新饰品层级列表。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 修正推荐宝石中的错别字。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为12.0.5版本更新。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 为12.0.5版本更新，包含新的天赋构建。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 为12.0.5版本更新，转向回响突袭构建。
- **2026年4月20日（本页）：** 为12.0.5版本更新。
- **2026年3月27日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 添加光盲之怒圣歌饰品。
- **2026年3月23日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 在层级列表中降低折磨灵魂容器的排名。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 从消耗品部分移除茶集。它们不再起作用。
- **2026年3月19日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 捕魂者护符饰品现在会正确地为唤魔者掉落。
- **2026年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 可能性之尘已从所有时空守卫构建中移除。
- **2026年3月19日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 可能性之尘已从所有时空守卫构建中移除。
- **2026年3月19日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 为可能性之尘的改动更新。
- **2026年3月19日（本页）：** 为更多关于可能性之尘改动的信息更新。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新饰品和套装信息。
- **2026年3月17日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 根据削弱更新天赋构建。
- **2026年3月17日（本页）：** 为最后时刻的平衡性调整更新。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 为至暗之夜前赛季更新。
- **2026年2月26日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已为至暗之夜前赛季审查。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 为至暗之夜前赛季更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 为至暗之夜前赛季更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前赛季更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已为至暗之夜前赛季审查。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前赛季更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 为至暗之夜前赛季更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 为 至暗之夜 发布添加了巅峰天赋。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 为至暗之夜前赛季更新。
- **2026年2月26日（本页）：** 为至暗之夜前赛季更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 修复起手式中 火焰 吐息被隐藏的问题
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已为 至暗之夜 12.0.1 预补丁更新配装
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（本页面）：** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对至暗之夜前夕进行更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对11.2.7版本审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对 11.2.7 补丁进行审阅
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.2.7版本审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已为11.2.7版本进行更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对 11.2.7 补丁进行审阅
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对 11.2.7 补丁进行审阅
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 已更新 11.2.7 补丁的简介
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 为11.2.5补丁更新。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已更新以包含关于代币和套装对比的信息。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 修复了一个技能名称中的拼写错误。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 为11.2.5补丁更新。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 为11.2.5补丁更新。
- **2025年10月5日（本页）：** 已更新 11.2.5 补丁的简介
- **2025年9月10日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新装备页面，标明热修后的套装表现。
- **2025年9月10日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 移除套装免责声明。输出循环保持不变。
- **2025年9月10日（本页）：** 已更新简介，加入关于 11.2 补丁热修的信息。
- **2025年8月22日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 修复 时空守卫 起手式的输出循环顺序问题。
- **2025年8月20日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已更新 鳞长 天赋配装。
- **2025年8月12日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 添加第3赛季增益信息。
- **2025年8月12日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 在饰品初步调整后更新饰品套装层级。
- **2025年8月9日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 调整简单模式输出循环的顺序，以减少玩家的困惑。
- **2025年8月5日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新 鳞长 的套装数值，更改饰品层级列表，并调整毕业配装列表。
- **2025年8月5日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对英雄天赋调整热修进行更新。（团本使用 时空守卫，大秘境使用 鳞长）
- **2025年8月5日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 从简单模式中移除 时空守卫 属性优先级（因为我们推荐 鳞长）。
- **2025年8月5日（本页）：** 添加关于持续不断调整的警告。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 更新 11.2 补丁的简易模式页面
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 因削弱更新属性优先级推荐
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已更新至 11.1.7 补丁，包含属性优先级腰带。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 为11.1.7补丁更新。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.7补丁更新，包含关于战斗助手和单键助手的信息。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对11.1.7补丁审核，修正了一个描述部分中的错误。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 针对11.1.7补丁和战斗辅助更新简易模式。将配装方案换成时空守卫，因为它们在战斗助手下的表现更好，不依赖时间跳跃。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月12日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新了几个饰品的评论。
- **2025年5月8日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 完全更新了装备列表，因为11.1.5补丁的在线修正导致属性优先级发生变化。
- **2025年5月8日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁的在线修正更新，更改了最佳附魔和宝石。
- **2025年5月8日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对11.1.5补丁的在线修正更新，更改了属性优先级。
- **2025年5月8日（[解放安德迈页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** 天赋配装方案因11.1.5补丁的在线修正而更新。
- **2025年5月8日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 针对11.1.5补丁的在线修正更新了天赋配装方案。
- **2025年5月8日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 因11.1.5补丁的在线修正更新了简易模式的天赋和属性。
- **2025年5月8日（本页）：** 已针对11.1.5补丁的在线修正更新，这导致了配装方案和装备选择的重大变化。
- **2025年5月2日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新了迪纳尔部分。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁更新，包含惊魂幻象附魔。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年4月12日（本页）：** 已针对11.1.0补丁的第二轮在线修正更新。
- **2025 年 3 月 25 日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对11.1.0补丁的在线修正更新，包括来自团队副本的初始数据。
- **2025年3月25日（本页）：** 已针对11.1.0补丁的在线修正更新。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** 已更新了关于加里维克斯的信息。
- **2025年3月4日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对团队副本第一周的装备调整更新。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对11.1补丁更新，由于新增天赋，天赋排序有所不同。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 所有增益机制均已针对11.1补丁更新。最佳增益部分暂时移除。
- **2025年2月24日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对11.1补丁更新，包含新的毕业装备列表和饰品信息。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对11.1补丁进行审查
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对11.1补丁更新，精通属性对所有英雄天赋均为首选。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1补丁更新，包含第2赛季套装的循环改动。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对11.1补丁更新新的天赋改动。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1补丁改动进行更新
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年1月4日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新饰品排行榜，提升Cirrals Concoctory的排名。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已根据改动更新瑟尔奇之戒的推荐。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 推荐装备页面已更新瑟尔奇之戒。在大秘境装备部分添加了关于咆哮战争女王的说明。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对11.0.7补丁更新，添加了瑟尔奇之戒，毕业装备已更改。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对11.0.7补丁更新，对鳞长而言暴击属性优于精通。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对11.0.7补丁进行审查
- **2024年12月15日（本页）：** 针对11.0.7版本进行了更新。
- **2024年12月5日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已根据11.0.5补丁的最新平衡调整更新
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 针对11.0.5版本进行了更新。
- **2024年10月21日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 为11.0.5补丁添加了免责声明
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 11.0.5补丁更新
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对11.0.5补丁进行审核
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对11.0.5补丁进行审核
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对11.0.5补丁进行审核
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** 已为11.0.5补丁更新新的默认构筑字符串
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已为11.0.5补丁更新职业天赋树。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.5补丁进行审核
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已为11.0.5补丁更新新的职业天赋树。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 针对11.0.5版本进行了更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对11.0.5补丁进行审核
- **2024年10月21日（本页）：** 11.0.5补丁更新
- **2024年10月4日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** 添加了关于丝缚宫廷的信息以及大量关于安苏雷克女王的信息。更新了拉夏南。
- **2024年10月4日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 根据在线修复更新默认的鳞长大秘境构筑。
- **2024年10月4日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 根据在线修复更新默认的鳞长大秘境构筑。
- **2024年10月4日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 根据在线修复更新默认的鳞长大秘境构筑。
- **2024年10月4日（本页）：** 更新以提及针对霸主的新在线修复。
- **2024年9月22日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 修正拼写错误。
- **2024年9月22日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 更新鳞长与熔火余烬的输出循环。
- **2024年9月22日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 修正拼写错误。
- **2024年9月22日（本页）：** 更新以提及熔火余烬和鳞长。
- **2024年9月21日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已为新的鳞长信息更新。
- **2024年9月21日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已为新的鳞长信息更新。
- **2024年9月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** 所有推荐已切换为鳞长。
- **2024年9月21日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 为新的鳞长构筑更新，并改为熔火余烬。
- **2024年9月21日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已为熔火余烬改动更新
- **2024年9月21日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 所有推荐已切换为鳞长。
- **2024年9月17日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 更新增益页面，以更好地呈现史诗钥石地下城周的开季情况。
- **2024年9月17日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新史诗钥石地下城开季的饰品排行榜。
- **2024年9月13日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 移除前瞻装备列表
- **2024年9月11日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 修正一个拼写错误
- **2024年9月11日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 修正另一个拼写错误
- **2024年9月10日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 初步更新《地心之战》第1赛季的增益目标。
- **2024年9月10日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 因熔火余烬而更新关于提升烈焰之息优先级的说明。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 添加《地心之战》第1赛季装备与饰品的毕业列表。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 添加《地心之战》第1赛季的镶金边信息
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 修正拼写错误
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 为大秘境添加关于光辉力量之威权的说明。添加迅捷亵渎宝石。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已为《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 改进扭转天平信息的可读性。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 更新不正确的天赋链接，并添加关于大秘境中时光聚汇的信息
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月27日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 添加关于地下堡的说明
- **2024年8月22日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 修正一个拼写错误
- **2024年8月22日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 为镶金边物品添加免责声明
- **2024年8月22日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 更新最佳武器油/临时武器附魔的说明
- **2024年8月22日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 修正拼写错误
- **2024年8月22日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 修正不正确的技能链接
- **2024年8月22日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 修正大秘境天赋构筑（缺少了压制怒吼和梦游）
- **2024年8月22日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 修正不正确的技能链接
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已为《地心之战》上线更新新的构筑。
- **2024年8月21日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 所有增益机制均已针对《地心之战》上线进行更新。最佳增益部分暂时移除。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已更新为《地心之战》上线的前瞻毕业装备。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》上线更新，包含所有新的消耗品和附魔。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已为《地心之战》上线更新，包括时空守卫的新属性。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已为《地心之战》上线更新，加入英雄天赋支持。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已为《地心之战》上线更新，添加英雄天赋。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已为《地心之战》上线更新，添加英雄天赋。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 针对《地心之战》上线对输出循环进行了微调，并添加了英雄天赋。
- **2024年8月21日（本页）：** 已针对《地心之战》上线进行更新。
- **2024年8月18日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对《地心之战》上线进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/augmentation-evoker-mists-of-pandaria-remix-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 为《地心之战》前夕添加了免责声明。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 修正了大秘境天赋树。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 起手式已随熔火余烬修正。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 修正了大秘境天赋树。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年7月19日（[地心之战](<https://www.icy-veins.com/wow/augmentation-evoker-the-war-within-pve-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月19日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月15日（[地心之战](<https://www.icy-veins.com/wow/augmentation-evoker-the-war-within-pve-guide>)):** 更新关于可能性微粒的说明。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/augmentation-evoker-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月20日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/augmentation-evoker-mists-of-pandaria-remix-guide>)):** 在审阅改动后进行了进一步更新。
- **2024年5月19日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/augmentation-evoker-mists-of-pandaria-remix-guide>)):** 在实际测试后更新。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/augmentation-evoker-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对第4赛季进行审查。
- **2024年4月22日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已为巨龙时代第4赛季审核并更新
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已为巨龙时代第4赛季审核并更新
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对巨龙时代第4赛季审核
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代第4赛季审核并重新排版
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已为巨龙时代第4赛季审核并更新
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对巨龙时代第4赛季审核
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代第4赛季审核并更新
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已为巨龙时代第4赛季更新并审核。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已为巨龙时代第4赛季审核并更新
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月19日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对10.2.6版本进行审阅
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对10.2.6版本进行审阅
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对10.2.6版本进行审阅
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对10.2.6版本进行审阅
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对10.2.6版本进行审阅
- **2024年3月8日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 措辞调整与拼写错误修正
- **2024年3月8日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 更新属性并更改格式
- **2024年3月8日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 在默认大秘境构筑中使用再生甲壳。
- **2024年3月8日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 默认构筑已更新。
- **2024年3月8日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 更新默认构筑。
- **2024年1月19日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对10.2.6版本进行审阅
- **2024年1月19日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对10.2.6版本进行审阅
- **2024年1月19日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对10.2.6版本进行审阅
- **2024年1月19日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.6版本进行审阅
- **2024年1月19日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对10.2.6版本进行审阅
- **2024年1月19日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对10.2.6版本进行审阅
- **2024年1月19日（本页）：** 已针对10.2.6版本进行审阅
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 根据最新优先级更新增益目标。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已为10.2.5补丁更新，更改了地下城限定的毕业武器
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核
- **2024年1月15日（本页）：** 已为10.2.5版本进行更新。
- **2023年11月24日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 修正地下城装备中的拼写错误。
- **2023年11月22日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 更新增益页面 - 现为属性页
- **2023年11月21日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 更新毕业饰品以考虑层数损失。
- **2023年11月13日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 在最新的在线修复与平衡调整后更新增益目标
- **2023年11月13日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 根据最新的在线修复进行装备调整与更新。
- **2023年11月13日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已为在线修复更新
- **2023年11月13日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 为在线修复更新
- **2023年11月13日（本页）：** 已为11月14日的在线修复更新
- **2023年11月9日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 略微更新增益目标
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 根据最新的在线修复进行装备调整与更新。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已为10.2补丁更新
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 已针对10.2版本进行更新
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2版本进行更新
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 已针对10.2版本进行更新
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 已针对10.2补丁进行审核
- **2023年11月6日（本页）：** 已为10.2补丁更新
- **2023年10月6日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 本页已添加更多信息。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** 页面已添加。
- **2023年9月4日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 已针对10.1.7补丁审核并更新格式
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 针对 10.1.7 补丁进行了审阅
- **2023年8月9日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 根据近期改动更新增益信息。
- **2023年8月9日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 为本周补丁更新构筑。
- **2023年8月9日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 构筑已为本周改动更新。
- **2023年8月9日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 已为天赋改动更新。
- **2023年7月15日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 根据近期的纪元改动重做优先级列表。
- **2023年7月13日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 元素萨满祭司起手优先级的改动说明。
- **2023年7月13日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 修正默认天赋复选框，并加入自动选怪说明。
- **2023年7月12日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 增益优先级已针对野性进行调整。
- **2023年7月10日（[增益效果](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** 页面已添加。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** 页面已添加。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** 页面已添加。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** 页面已添加。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** 页面已添加。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** 页面已添加。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 页面已添加。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** 页面已添加。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** 页面已添加。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** 页面已添加。
- **2023年7月10日（本页）：** 页面已添加。

显示更多

显示更少

:::

## 练级

在本页，你将找到我们的增辉唤魔师逐级升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[唤魔师 练级指南](<https://www.icy-veins.com/wow/evoker-leveling-guide>).

1.

### 增辉 唤魔师练级指南——至暗之夜

增辉 唤魔师是一个以辅助为导向的专精，因此其个人伤害输出明显低于湮灭 唤魔师。如果你选择主要通过地下城练级，这不会成为问题。但如果你以湮灭身份在开放世界中通过任务练级，游戏体验可能会更加顺畅。如果你想改为以湮灭身份练级，我们建议参考我们的 [湮灭 唤魔师练级指南](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>).

1.1.

#### 升级装备选择

在大多数情况下，你在练级过程中应优先考虑物品等级。这意味着选择物品等级最高的装备。在选择首饰（项链或戒指）时，牺牲少量物品等级来使用没有全能属性的装备是值得的，因为该属性对增辉 唤魔师来说并不出色。

使用传家宝装备时，我们建议使用任何没有全能属性的传家宝。如果你是单人游戏，应尽量优先考虑急速和暴击几率，因为精通在没有队友可供增益的情况下对你的伤害输出影响很小。

1.2.

#### 至暗之夜升级实用消耗品

在本节中，我们将介绍一些在至暗之夜练级期间有用的消耗品。这些将主要集中在能提升你速度的物品上——包括实际移动速度和每秒伤害。

- [[item:225592]] —— 最新的食物增益，提供大量速度加成，能让练级速度显著加快。
- [[item:172063]] 或 [[item:133576]] —— 较旧的食物增益，仍能提供明显的速度提升。如果你在之前的资料片练级时还留有这些食物，再次使用会是不错的选择。
- [[item:212265]]：这是来自地心之战的战斗药水。可在71级及以上使用，可用于加快任务Boss的击杀速度，或让大型拉怪更快（从而更安全）。如果你已经拥有这些药水，我们建议在练级过程中使用。
- 生命药水在练级期间对挽救你的生命至关重要。我们建议在开始至暗之夜之前储备一些[[item:244835]]（地心之战生命药水，71级以上），但不要储备太多，因为在你达到81级后[[item:241305]]和[[item:271883]]会使这些药水失效，而且1星品质的药水通常非常便宜。

我们建议确保你备有一些这些消耗品，因为它们能让练级速度显著加快。

- [[item:109076]]
- [[item:132516]]或[[item:212268]]
- [[item:168412]]

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 增辉 80级至暗之夜练级
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzYmZMzGAAAAAAAAmBmBjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0IWwYMzAAPA"
}
```
:::

:::talents 通用配装——时空守卫
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA"
}
```
:::

:::details 来源计算器编码
```
#BX-UacsFKLLRRZblqqIIPXYYkkpEWejnDfhmWB-CVELHWGuSMNCIWOpQBWE+BjD5LVrbDC-AAAA-UAQaYMECKWOIMA-
```

:::

2.1.

#### 升级用战争模式天赋

在这里，你将找到关于练级以及进行单人/小型队伍PvE内容时最佳PvP天赋的信息。

增辉 唤魔师的PvP天赋几乎不会在战斗中提供任何明显的加速效果。我们在下方列出了最佳的常驻天赋。

- [[spell:378464]] 是推荐选择，因为它为你提供了一种简便的方式，可以免疫来自试图偷袭你的NPC和敌方玩家的控制效果。
- [[spell:378444]] 可让你在敌人试图击退你时安全地施放法术。
- [[spell:378437]] 在你试图逃离一群敌人且不被减速致盲时会很有用。

1.

### 升级循环

为了在练级和学习专精时保持简单，使用滑块选择你的等级，观察练级循环随着每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

- **等级 35 起：**施放 [[spell:409311]]
- **等级 11 起：**施放 [[spell:395152]]
- **等级 1–42：**施放 [[spell:357210]]
- **等级 43 起：**施放 [[spell:403631]]
- **等级 27 起：**施放 [[spell:370553]]
- **等级 11 起：**如果[[spell:395152]]处于激活状态，则以1级蓄力施放[[spell:357208]]。
- **等级 1–10：**以1级蓄力施放[[spell:357208]]。
- **等级 57 起：**如果[[spell:357208]]和[[spell:396286]]都在冷却中，则施放[[spell:404977]]。
- **等级 19 起：**如果[[spell:395152]]处于激活状态，则以1级蓄力施放[[spell:396286]]。在AOE场景中，你可以提高蓄力等级以命中尽可能多的敌人。
- **等级 15 起：**如果[[spell:395152]]处于激活状态，或者你拥有2个[[spell:369297]]或精华已满，则施放[[spell:395160]]。
- **等级 1–14：**施放 [[spell:356995]]
- 施放 [[spell:361469]]
- 如果你需要在施法时移动，请使用[[spell:358267]]。如果你没有[[spell:358267]]的剩余充能，则使用[[spell:362969]]。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁更新。
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜前赛季更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁更新，由于新增天赋，天赋排序有所不同。
- **2024年12月15日：** 已针对11.0.7补丁进行审查
- **2024年10月21日：** 针对11.0.5版本进行了更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为《地心之战》上线更新新的构筑。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年10月6日：** 本页已添加更多信息。
- **2023年9月4日：** 页面已添加。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将向你说明如何在《魔兽世界》12.1.5补丁中轻松游玩增辉 唤魔师，使用最简单的循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能表现。

1.

### 增辉 唤魔师在至暗之夜中的基础

本页面面向刚接触游戏或该职业的玩家，他们不打算参与史诗难度团队副本，或者只是想要一种更直接的方式来游玩他们的专精，而不会被为实现最优游玩所需考虑的众多细节和主动技能所淹没。

增辉的玩法非常流畅，围绕着为队友施加增益效果，然后施放你的伤害法术来延长你的增益效果。

增辉 唤魔师拥有增益自动选中目标的功能，尽可能让新玩家更容易上手。例如，在选中敌人时，施放[[spell:409311]]会默认选中最近的伤害输出者，而[[spell:360827]]会以敌人当前的目标为目标。[[spell:395152]]会自动作用于所有伤害输出者。

在大秘境中，你完全不必担心增益的目标选择，因为它们大多会自动施放在正确的目标上。在大秘境中手动选择[[spell:409311]]的目标最多只能带来1%的伤害提升。

虽然在团队副本中优化增益对象是可能的，但随着[[spell:395152]]改为全团生效的改动，其收益比历史上的要小。话虽如此，确保[[spell:409311]]施放在你最强的输出职业身上仍然是显著的提升，我们建议你在整场战斗中尽可能保持在他们身上。然而，我们并不认为这是享受该职业的必要条件。如果你更愿意让游戏自动处理，这对于所有内容都是完全可行的。

增辉 唤魔师的最高优先级是 **始终保持施法**。你的所有行动都会以某种方式对你的总伤害做出贡献，按下一个技能，即使是错误的键位，也比什么都不按要好！以下是需要关注的一些简单要点：

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_sarkareth.jpg>)
  **维持你的黑檀之力**
  
  
  
  
  ```
  Augmentation's main damage contributor is [[spell:395152]], as it
  provides a large primary stat buff to your allies while also boosting your
  own damage. Your highest priority is to maintain this buff by casting
  [[spell:395152]], [[spell:357208]], [[spell:396286]] and
  [[spell:395160]] as much as possible.
  ```
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_prescience.jpg>)
  **循环使用技能冷却**
  
  
  
  
  ```
  Augmentation has three important short cooldown abilities:
  [[spell:357208]], [[spell:396286]] and [[spell:409311]]. These
  abilities cause powerful buffs on allies that make up a large portion of
  your damage meaning it is crucial to maximise uses!
  ```
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_eruption.jpg>)
  **消耗所有可用资源**
  
  
  
  
  ```
  Augmentation has two important resources: Essence and
  [[spell:396187]]. These can be used to cast
  [[spell:395160]] which is crucial to deal damage and maintain
  [[spell:395152]]. You will generate Essence over time and get
  [[spell:396187]] from [[spell:409311]] and
  [[spell:361469]].
  ```

1.

### 至暗之夜中唤魔师增辉新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫通用天赋

2.1.

#### 唤魔师增辉通用天赋构建

这套配装在团队副本和大秘境中都适用，但我们仍然建议在大秘境中使用专门的大秘境天赋，因为这套配装缺少一些功能选项和[[spell:360827]]天赋。我们目前建议使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫，因为它造成的伤害明显更高，且对个人操作的要求更低。

我们在这套配装中选择[[spell:412713]]，以最大限度地降低输出循环的整体复杂性。使用[[spell:404977]]搭配[[spell:410260]]确实能多造成约1%的伤害，前提是你能舒适地管理这个额外的冷却技能。

:::talents 简易配装 - 时空守卫
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMmZAgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMmZAgB"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKbpkkIIWeEnmG:WDHWWA-CVELHDWuSMNCIWOpQBGu4hDB77cqW3G-AAAA-UAQMECaYKWOIMA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫大秘境天赋

2.2.

#### 唤魔师增辉大秘境与地下堡天赋

这套配装同样使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫并切换为[[spell:360827]]天赋。这些天赋专精于造成范围伤害，在目标数量较少的场合（如许多团队副本首领战）表现不佳，但在大秘境中表现出色。记得在地下城开始时对坦克施放你的[[spell:360827]]！

在职业天赋树的功能性天赋点上，我们从[[spell:375554]]中移出两点，分别投入到[[spell:360806]]和[[spell:371032]]，因为它们在大秘境中是有用的功能性天赋。

:::talents 简易大秘境配装 - 时空守卫
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZmZMmZWGzMwMbGYMjFWgBmhhGYBjxMDAM"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZmZMmZWGzMwMbGYMjFWgBmhhGYBjxMDAM"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKJbpkkIIWeEnmG:WDH6A-CVELHDWuSMNCIWOpQB+whg9dOVrjxRD-AAAA-UAQMECaYKWOIMA-
```

:::

### 增辉 唤魔师基础输出循环

2.3.

#### 增辉唤魔师新手输出循环

优先级系统对于 [增辉 唤魔师](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-guide>) 整体上并不复杂，因为你主要关注几个短冷却技能，并用[[spell:361469]]来填补间隙。然而，延迟施放[[spell:409311]]或[[spell:395152]]可能导致伤害输出快速大幅下降。重要的是只在[[spell:395152]]期间使用蓄力法术。

- 如果你的坦克当前没有[[spell:360827]]，请施放它。
- 施放 [[spell:395152]]。
- 施放 [[spell:409311]]。
- 施放 [[spell:403631]]。
- 施放 [[spell:370553]]。
- 如果[[spell:395152]]处于激活状态，则以3级蓄力施放[[spell:357208]]。
- 如果[[spell:395152]]处于激活状态，则以1级蓄力施放[[spell:396286]]。
- 如果[[spell:395152]]处于激活状态，则施放[[spell:395160]]。
- 施放 [[spell:361469]]。
- 如果你需要在施法时移动，请使用[[spell:358267]]。如果你没有[[spell:358267]]的剩余充能，则使用[[spell:362969]]。

2.3.1.

##### 套装

增辉的至暗之夜第二赛季套装并不会改变你的输出循环。不过，它能让你更频繁地施放[[spell:396286]]。

2.3.2.

##### 巅峰天赋： ![Duplicate Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_recall.jpg>) 复制

增辉的巅峰天赋[[spell:1259173]]不会直接影响你的实时操作，只是提升你角色的伤害输出和增益强度。

### 增辉 唤魔师防御法术

2.4.

#### 唤魔师增辉防御技能

唤魔师增辉的所有防御技能都是 **预防性的**。你需要在伤害发生之前使用它们以获得最大效果，事后使用则没有任何作用。

[[spell:404195]]是一个假死效果，每六分钟可以救你一命。

[[spell:363916]]是你最基础的防御技能，提供30%的伤害减免，冷却时间为90秒，由于[[spell:375406]]的影响拥有两次充能。这个天赋通常还会受到[[spell:374348]]的进一步增强，它会使你回复相当于[[spell:363916]]所减免伤害的生命值，使其成为一个非常强大的防御技能。

[[spell:374227]]使你和最近的4名队友受到的范围伤害降低20%。由于影响5个人，即使只对AOE伤害生效，这也是非常强大的。大多数战斗都有高伤害的AOE技能，这个技能对此非常有效。

[[spell:429483]]搭配[[spell:431873]]（![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫英雄天赋）提供20%递减的伤害减免，每0.3秒降低2%。

### 增辉 唤魔师属性优先级

2.5.

#### 唤魔师增辉属性优先级

目前，智力是你每点收益最重要的属性，精通紧随其后。精通目前明显领先于其他属性，而全能的价值极低。这意味着装备物品等级较低但副属性更好的装备可能是正确的选择。

精通

暴击

急速

全能

### 暴风雪战斗助手

2.6.

#### 唤魔师增辉战斗助手

该 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 旨在帮助新玩家接触内容，而不至于被《魔兽世界》复杂的输出循环所淹没。你可以让游戏为你高亮显示下一个动作，或让游戏为你执行操作。本节其余部分主要指的是单键助手，因为高亮显示的性能是可接受的，没有真正的性能损失。你可以在法术书中找到单键助手，它是一个可以拖到快捷栏上的按钮，将按照暴风雪定义的优先级循环使用你的技能。

对于 增辉 唤魔师，战斗助手在施放像 [[spell:357208]] 或 [[spell:396286]] 这样的蓄力法术时存在问题。如果你在它建议施放蓄力法术时过于频繁地按键，战斗助手会取消蓄力法术，而不是正确地将其加入队列。为了解决这个问题，我们建议注意法术即将冷却完毕时，放慢你的按键速度。当它施放蓄力法术时，它的工作方式类似于“按下并轻触”施法模式，即开始施法，再次按下则释放法术。

战斗助手的另一个显著问题是它无法在移动时帮助你。尽管 增辉 唤魔师 拥有 [[spell:358267]]，但它不会建议你使用它，并且可能会卡在建议你在移动时施放蓄力法术，而即使你手动施放 [[spell:358267]]，这也是无法做到的。因此，我们确实建议在冷却技能之外，将一些基础法术也进行键位绑定。我们建议确保 [[spell:395160]]、[[spell:361469]] 和 [[spell:362969]] 已绑定键位，以及下文列出的所有职业技能冷却技能，还有功能性和防御性法术。

作为一名 增辉 唤魔师，本助手不会替你使用所有技能。助手不会使用你的冷却技能或物品，你需要穿插使用以下技能，才能从你的职业和该功能中获得最大伤害输出：

- [[spell:403631]]
- [[spell:370553]]
- [[spell:404977]]
- 主动使用饰品
- 战斗药水
- [[spell:358267]]用于移动

通过使用本助手并穿插使用你的冷却技能，你可以在循环操作上达到高水平。暴风雪 通过在使用战斗助手时增加你的全局冷却时间来平衡这一点。目前战斗助手的伤害比手动操作落后 5.4%。

这个工具是入门游戏并开始游玩的绝佳方式。在你适应之后，我们建议你尝试手动进行循环操作，以进一步提升你的游戏水平。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁更新，包括新的大秘境配装。
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 为12.0.5版本更新，转向回响突袭构建。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜前赛季更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年9月10日：** 移除套装免责声明。输出循环保持不变。
- **2025年8月9日：** 调整简单模式输出循环的顺序，以减少玩家的困惑。
- **2025年8月5日：** 从简单模式中移除 时空守卫 属性优先级（因为我们推荐 鳞长）。
- **2025年8月4日：** 更新 11.2 补丁的简易模式页面
- **2025年6月15日：** 针对11.1.7补丁和战斗辅助更新简易模式。将配装方案换成时空守卫，因为它们在战斗助手下的表现更好，不依赖时间跳跃。
- **2025年5月8日：** 因11.1.5补丁的在线修正更新了简易模式的天赋和属性。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查
- **2024年10月21日：** 已针对11.0.5补丁进行审核
- **2024年9月21日：** 所有推荐已切换为鳞长。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 针对《地心之战》上线对输出循环进行了微调，并添加了英雄天赋。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为巨龙时代第4赛季审核并更新
- **2024年3月19日：** 已针对10.2.6版本进行审阅
- **2024年3月8日：** 更新默认构筑。
- **2024年1月15日：** 已针对10.2.5补丁进行审核
- **2023年11月6日：** 已针对10.2补丁进行审核
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 页面已添加。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到魔兽世界 12.1.5 补丁中你的 增辉 唤魔师 的最佳天赋。我们还为团队副本或大秘境等各类内容提供了默认天赋搭配。如果你开启了战争模式进行游戏，我们也为你提供了 PvP 天赋。

1.

### 增辉 唤魔师 最佳 至暗之夜 天赋

增辉 拥有两个侧重于职业不同方面的英雄天赋。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 更侧重于 [[spell:409311]] 和你增益效果的力量。与此同时， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 侧重于通过 [[spell:395160]] 的增益以及像 [[spell:434300]] 这样的额外伤害来源来获得更高的伤害输出。

此外， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 的节奏会更快，因为它会提供额外的 [[spell:369297]] 触发和急速增益，从而加快你的循环速度。

我们推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫作为默认团本选择，因为它会大幅优于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长在团本所有场景中的表现。我们目前推荐使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长用于每周大秘境 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫用于更高层数的大秘境。

如需更深入的信息，请查看下方每个构筑和英雄天赋的专属章节。

**推荐构筑导入代码：**

:::talents 团本构筑 - 时空守卫
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA"
}
```
:::

:::talents 大秘境构筑 - 时空守卫
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMzMDAM"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

时空守卫

团队副本构建

推荐

大秘境天赋构建

推荐

鳞长

团队副本构建

每周大秘境/探宝构筑

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫团队副本构建

此构筑侧重提升你所提供增益的强度，其DPS比下述构筑高15%： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫与我们第二赛季套装的协同极佳，因为它拥有专门针对[[spell:396286]]的天赋节点以及更多对[[spell:409311]]的支持。

我们在此构筑中选择[[spell:404977]]，以便腾出一个额外点数来点出[[spell:410260]]，当你能用[[spell:403631]]同时命中多个目标时，该天赋能带来可观的伤害。此外，目前使用[[spell:404977]]配合[[spell:410260]]或[[spell:410261]]，比基线的[[spell:412713]]表现约高出0.5%。

选择使用[[spell:412713]]、[[spell:412723]]还是基础的[[spell:404977]]，最重要的考量之一就是[[spell:403631]]的时机。根据不同的战斗，你可能会发现[[spell:403631]]与小怪或其他重要时刻的配合，使用其中某一天赋时会自然地更契合。这种提升足以抵消对[[spell:404977]]的轻微默认偏好，所以我们建议尝试两种选择，使用手感最好的那个。

当你使用[[spell:404977]]变体时，需要为[[spell:370553]]使用取消光环宏。更多信息请参阅我们的循环指南。

#### 时空守卫取消光环 扭转天平

```wow-macro
#showtooltip
/cast 扭转天平
/cancelaura 扭转天平
```

此外，如果你只是不喜欢使用[[spell:404977]]，你可以将点数从[[spell:410260]]移到[[spell:412713]]，损失约0.5%的DPS，但能获得明显更流畅的游戏体验和略有不同的冷却时间。

我们的团本构筑以通用天赋配置开始，该配置在任何地方都适用，但并非每个首领都需要你点出[[spell:351338]]。如果你面对的首领没有需要打断的技能，我们建议将其移到其他实用技能上，如[[spell:454983]]、[[spell:408233]]或[[spell:407243]]。这是一个非常小的收益，所以我们选择默认始终包含它！

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫大秘境构建

我们目前推荐使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫用于所有大秘境，因为它能造成显著更高的单体伤害，使大秘境明显更快。然而，如果你更喜欢 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长的游戏体验，它的表现也并不落后太多，尤其是在较低层数的大秘境中。

该构筑选择使用[[spell:412713]]而非[[spell:404977]]，这能带来更流畅的游戏体验。我们还点出了[[spell:360827]]和[[spell:409329]]。这些天赋现在在AOE战斗中能造成可观的伤害，值得投入。

我们的大秘境构筑以通用天赋配置开始，该配置在任何地方都适用。你可以调整职业树中的实用技能点，例如如果你愿意，可以将点数从[[spell:370888]]移到[[spell:372048]]或[[spell:371032]]等其他实用技能上。

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长团本构筑

此构筑的DPS大约落后15%，比较对象为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫约15%，因此我们强烈建议不要使用它。

在至暗之夜第二赛季中，[[spell:441206]]遭到大幅削弱，极大地降低了 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长的整体表现。此外，
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长与第二赛季套装的协同相对较差，因为它与[[spell:409311]]没有任何特殊互动。

就像我们的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫团本构筑一样，这个构筑围绕[[spell:409267]]和[[spell:410260]]进行，但有一个关键区别：我们将点数从[[spell:275339]]移到[[spell:412713]]。这让我们能获得明显更流畅的[[spell:412713]]游戏体验，它与[[spell:441206]]协同良好。我们无法在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫上做出这种替换，因为它需要使用[[spell:275339]]才能在单体战斗中获得[[spell:431657]]的最大效果。

我们的团本构筑以通用天赋配置开始，该配置在任何地方都适用，但并非每个首领都需要你点出[[spell:351338]]。如果你面对的首领没有需要打断的技能，我们建议将其移到其他实用技能上，如[[spell:454983]]、[[spell:408233]]或[[spell:407243]]。这是一个非常小的收益，所以我们选择默认始终包含它！

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长大秘境和探宝构筑

我们目前不推荐在高层大秘境中使用此构筑，因为它的表现会比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫更差。话虽如此，差距相当小，所以如果你更喜欢 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长的游戏风格或玩法，它仍然可行，尤其是用于每周大秘境。

该构筑专注于使用[[spell:412713]]和[[spell:407866]]，并最大化你通过[[spell:403631]]施放所造成的个人伤害。

我们在此构筑中选择[[spell:410784]]以获得轻微的单体DPS提升。由于使用了[[spell:410784]]，你将在所有目标数量下使用[[spell:362969]]而非[[spell:361469]]。你仍然需要使用[[spell:361469]]来消耗[[spell:369939]]。

我们在此构筑中选择[[spell:410784]]的另一个原因是，由于在所有情况下都以瞬发技能作为主要产生器，它玩起来要简单得多。与使用[[spell:407814]]相比，你将获得约2%的单体DPS提升，代价是AOE伤害降低2%。如果你更想使用[[spell:407814]]，你可以切换过去，并将职业树中[[spell:369909]]的点数移到[[spell:376930]]或其他实用技能点上。

此构筑的潜在伤害输出略低于其
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫对应构筑相比，该构筑的潜在DPS略低，但对队友表现的依赖较小。这意味着它的平均表现可能更好，但当然具体情况因人而异。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKbpkkIIWeEnmG:WDHWWA-CVELHDWuSMNCIWOpQBGu4hDB7LVrbDC-AAAA-UAQMECaYKWOIMA-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMzMDAM"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKJbpkkIIWeEnmG:WDHaB-CVELHDWuSMNCIWOpQB+whg9lq1dmxRD-AAAA-UAQMECaYKWOIMA-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbjZmxyMYmlZMzMmBAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZzYwCsMGGbDgZQshxAzMAG"
}
```
:::

:::details 来源计算器编码
```
#BX-UacsFKRRZblqqIIPXYYkkpEWejnDfhmWXWA-CELVWuAHOSYcQZCUYURs8Bj77cqW3GE-AAAA-JOQSaACIYowIzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzMzyAzsNjxMmBAAAAAAAAmhHYGYM1YmZGAAAAMzMjxMz2YmBmZzYwCsMGGbDgZQshxMYmBDG"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFtZUYYlXPpcKJkkIjWeEnm:WDVV72cB-CVELHWHATMNyoQ54CQss4hD77cqWXDC-AAAA-JSCUg0wscMAIwI-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

万世卷册是至暗之夜中新增的一个系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)。完成一段简短的任务线后，你将能够从几个提供额外治疗量、生存能力或实用性的增益中进行选择。我们建议尽快完成这些任务，因为该系统将在至暗之夜的剩余时间里保持活跃，并提供明显的战力提升。

我们目前建议以下天赋作为你的默认进度路线。由于你可以随时更换符文，一旦你更加熟悉后，你总是可以根据战斗或个人喜好稍后进行调整：

- 第一符文：[[spell:1279599]]
- 第二符文：[[spell:1279603]]
- 第三符文：[[spell:1287555]]
- 第四符文：[[spell:1279612]]
- 第五符文：[[spell:1279614]]

:::details 常见问题 我应该选择哪个副属性符文？
作为一名增辉唤魔师，你应该始终点出

[[spell:1279612]]

.

:::

1.

### 巅峰天赋： ![Duplicate Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_recall.jpg>) 复制

在至暗之夜中，增辉唤魔师获得了巅峰天赋：[[spell:1259173]]。这个巅峰天赋及其升级对增辉唤魔师的天赋选择和属性优先级有重大影响。

第一点[[spell:1259173]]会在你施放[[spell:403631]]后召唤一个宠物，该宠物在激活期间能造成可观的伤害。这个宠物会施放[[spell:395160]]、[[spell:357208]]和[[spell:396286]]。这些施放不会延长[[spell:395152]]。[[spell:395160]]的施放会随增辉的所有天赋进行缩放，但[[spell:438587]]和[[spell:441176]]除外。

第二和第三点巅峰天赋[[spell:1259174]]允许任何触发[[spell:395153]]的效果也延长[[spell:1259173]]。这带来了一个与维持[[spell:395152]]非常类似的小游戏，你需要尝试最大化[[spell:1259173]]的覆盖率。这极大地提升了急速和暴击的收益，因为它们能提升[[spell:1259173]]的覆盖率。此外，它还显著增强了[[spell:403631]]系天赋[[spell:459537]]和[[spell:407866]]的强度，因为它们能增加你在[[spell:1259173]]期间可以施放的次数。

最后一点巅峰天赋[[spell:1259175]]使复制体提供一个极其强大的增益效果，使你的[[spell:395152]]对盟友的效果提高75%，并显著提升你的[[spell:396286]]的伤害。

[[spell:1259175]]的另一个重要意义在于，它极大地鼓励你卡着冷却时间使用[[spell:403631]]。最大化该增益提供的翻倍主属性覆盖率，最终对整体DPS的贡献要大于将[[spell:403631]]留给理想的伤害窗口。

即使[[spell:403631]]的增幅比拥有[[spell:1259173]]并配合[[spell:1259175]]所带来的12%主属性提升是更显著的DPS提升，卡着冷却时间使用[[spell:403631]]仍会带来显著更高的[[spell:1259173]]覆盖率，因为更频繁的施放会被[[spell:1259174]]延长。

与此同时，由于大多数DPS的伤害分布各不相同，你仍然会获得足够强力的[[spell:403631]]窗口。

1.

### 英雄天赋

英雄天赋在71级时解锁，它们是互斥的天赋树，提供略有不同的游戏体验和视觉效果。作为一名增辉唤魔师，你可以在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫之间选择。我们在下方详细介绍它们的一些细节和差异！

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长是专注于个人伤害的英雄天赋树，对以增益为基础的游戏玩法强调最少，而是选择强化赋能法术和精华消耗技能。这非常适合那些想要即放即忘的游戏体验、不想追踪队友DPS冷却时间的玩家。

目前我们推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长用于大秘境的每周大秘境，因为它在队友表现较差时运作得更好。在最佳条件下
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫能显著优于
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长，但两者在所有层级的大秘境中都可行，取决于你最喜欢哪个。

对于团本 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长的表现落后15%，比较对象为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫15%，我们强烈建议不要使用它。

的核心重点是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 的玩法核心在于使用 [[spell:395160]] 施放 [[spell:434300]]，这需要先通过使用 [[spell:357208]] 和 [[spell:396286]] 获得层数。施放 [[spell:434300]] 后，你需要在拥有天赋 [[spell:441212]] 的情况下，尽可能通过施放 [[spell:395160]] 来延长它。这些轰炸会从你的盟友那里触发额外的伤害，随着时间推移最终会造成可观的伤害！

另一个核心支柱是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 的玩法核心是 [[spell:438587]]。在你每次施放蓄力技能后，你会获得一层 [[spell:438587]]，这将使你的下一次 [[spell:395160]] 施放产生顺劈效果，对其他附近敌人造成额外一击。这现在尤其重要，因为 [[spell:441206]] 与 [[spell:438587]] 而非 [[spell:434300]] 挂钩。[[spell:403631]] 提供的额外冷却缩减使得
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长更倾向于[[spell:403631]]系天赋，如[[spell:459537]]和[[spell:407866]]。综合来看，你被强烈鼓励最大化[[spell:403631]]的整体施放次数以获取个人收益，而不是选择能从盟友处获得更多伤害的更高质量施放。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫是以增益为导向的英雄天赋树，以时间魔法为主题。作为一名 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫，你更大一部分的伤害来自增益效果，而非 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长，因为你能从[[spell:431715]]和[[spell:431874]]获得更强的[[spell:409311]]和[[spell:395152]]增益。这棵天赋树非常适合那些希望自己的朋友尽可能强大、并且对个人操作更宽容的玩家。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫强化了你的[[spell:361469]]，将其转化为[[spell:431442]]，并用青铜魔法进行强化，根据最近造成的伤害造成额外伤害。[[spell:431442]]仍然作为普通的[[spell:361469]]运作，与所有[[spell:361469]]天赋完全互动，每发射一个弹丸都会造成额外的[[spell:431442]]伤害。

这目前是我们为高端大秘境和团本推荐的英雄天赋树，因为它优于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长相当多。

如果你作为以下职业使用 [[spell:404977]] ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫使用[[spell:370553]]，你需要为[[spell:370553]]使用取消光环宏。这能让你保持[[spell:404977]]和[[spell:370553]]的冷却时间对齐。你需要这样做，因为[[spell:370553]]的冷却时间只有在增益被消耗后才会开始。

#### 取消光环扭转天平宏

```wow-macro
#showtooltip
/cast 扭转天平
/cancelaura 扭转天平
```

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫不会增加任何你需要应对的额外循环玩法元素。相反，它只是为你提供更多资源和属性。你从[[spell:431657]]和[[spell:431695]]获得更多的急速，从[[spell:1291522]]和[[spell:431875]]获得更好的资源生成，以帮助提升你基础循环的表现。这些资源和属性使你更容易维持增益效果。

:::details 常见问题：我什么时候应该使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫而非 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长?
我们推荐在大多数场景中使用

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫

而非

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长

。话虽如此，由于

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫

严重依赖队友表现，你可能会在大秘境中平均体验到

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长

更好的表现。

:::

1.

### PvP天赋（战争模式）

开启战争模式能让你在开放世界中获得几项好处，你可能会认为这些好处是有益的。我们在下方列出了主要好处。

- 户外世界中启用的PvP天赋。
- 在最高等级时，世界任务奖励至少提高 10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

我们不建议在一般升级和PvE内容中开启战争模式，因为它允许其他玩家击杀你，这非常令人沮丧。增辉唤魔师可用的战争模式天赋并不能节省大量时间，因为它们都没有提供显著的DPS提升。话虽如此，如果你愿意参与PvP，开启它是最优选择。

增辉 唤魔师的PvP天赋几乎不会在战斗中提供任何明显的加速效果。我们在下方列出了最佳的常驻天赋。

1. [[spell:378464]] 是推荐选择，因为它为你提供了一种简便的方式，可以免疫来自试图偷袭你的NPC和敌方玩家的控制效果。
2. [[spell:378444]] 可让你在敌人试图击退你时安全地施放法术。
3. [[spell:378437]] 在你试图逃离一群敌人且不被减速致盲时会很有用。
4.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月15日：** 为12.0.7版本更新，添加了万法书页的信息。将高层大秘境天赋改为霸主。
- **2026年5月4日：** 调整天赋构建的注释。天赋构建本身没有变化。
- **2026年4月20日：** 为12.0.5版本更新，包含新的天赋构建。
- **2026年3月19日：** 可能性之尘已从所有时空守卫构建中移除。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜前赛季更新。
- **2026年2月10日：** 已为 至暗之夜 12.0.1 预补丁更新配装
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 已针对 11.2.7 补丁进行审阅
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月20日：** 已更新 鳞长 天赋配装。
- **2025年8月5日：** 已针对英雄天赋调整热修进行更新。（团本使用 时空守卫，大秘境使用 鳞长）
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已针对11.1.7补丁审核，修正了一个描述部分中的错误。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁更新新的天赋改动。
- **2024年12月15日：** 已针对11.0.7补丁进行审查
- **2024年10月21日：** 已为11.0.5补丁更新新的职业天赋树。
- **2024年10月4日：** 根据在线修复更新默认的鳞长大秘境构筑。
- **2024年9月21日：** 为新的鳞长构筑更新，并改为熔火余烬。
- **2024年9月9日：** 更新不正确的天赋链接，并添加关于大秘境中时光聚汇的信息
- **2024年8月27日：** 添加关于地下堡的说明
- **2024年8月22日：** 修正大秘境天赋构筑（缺少了压制怒吼和梦游）
- **2024年8月22日：** 修正不正确的技能链接
- **2024年8月21日：** 已为《地心之战》上线更新，添加英雄天赋。
- **2024年7月23日：** 修正了大秘境天赋树。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为巨龙时代第4赛季更新并审核。
- **2024年3月19日：** 已针对10.2.6版本进行审阅
- **2024年3月8日：** 默认构筑已更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月9日：** 构筑已为本周改动更新。
- **2023年7月10日：** 页面已添加。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面，你将学习如何在单体和多目标场景中优化你的增辉唤魔师循环。我们还有关于冷却时间、触发等的进阶章节，以便你最大化DPS。我们的所有内容均针对《魔兽世界》12.1.5版本进行了更新。

1.

### 增辉唤魔师玩法与循环指南

欢迎来到我们的 增辉 唤魔师循环页面。在本页面中，你将了解到该专精在团队副本和大秘境场景中关于循环玩法所需的一切信息。

⟧S0094⟧的循环 [唤魔师](<https://www.icy-veins.com/wow/evoker-class-overview-dragonflight>) 主要围绕你的赋能法术（[[spell:357208]]和[[spell:396286]]）和[[spell:395152]]以30秒为周期进行。在这些周期之间，你使用[[spell:395160]]、[[spell:409311]]和像[[spell:361469]]这样的填充法术。

每两分钟，你可以使用 [[spell:403631]]，并且你需要搭配 [[spell:395152]]，以确保 [[spell:395152]] 持续完整的 [[spell:403631]] 持续时间。

1.1.

#### 增辉 唤魔师 通用循环目标

1. 卡冷却使用 [[spell:403631]]。
2. 避免叠满 [[spell:409311]] 的层数。
3. 使用你的蓄力技能为盟友提供 [[spell:413984]] 使其获得全能，并延长 [[spell:395152]]。
4. 通过 [[spell:395160]] 和蓄力技能尽可能长时间地维持 [[spell:395152]]。
5. 最大化你施放法术的时间——即使你的大部分伤害来自盟友，你的法术仍然很有价值！这应该会通过维持 [[spell:395152]] 自然实现。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长

团队副本构建

每周大秘境、地下宝库与开放世界

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫

团队副本构建

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

高层大秘境、地下宝库与开放世界

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:404977]]

[[spell:412713]]

[[spell:360995]]

[[spell:396286]]

[[spell:403631]]

[[spell:360827]]

[[spell:409311]]

[[spell:412723]]

[[spell:407814]]

[[spell:410784]]

[[spell:369939]]

[[spell:406907]]

### 增辉 单体目标

1.2.

#### 核心循环目标

**适用条件：时空守卫（未启用）。** 增辉 唤魔师 单体目标相对简单，重点是通过穿插其其他技能来尽可能长时间地维持 [[spell:395152]]。在维持 [[spell:395152]] 的同时，增辉 唤魔师 应该卡冷却使用其短冷却技能，如 [[spell:357208]]、[[spell:396286]] 和 [[spell:409311]]，以获得最佳 DPS，并在间隙中用 [[spell:395160]] 和 [[spell:362969]] 填充。目前，[[spell:362969]] 在单体目标中是更好的产生者， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 即使没有 [[spell:410784]] 也是如此。

**适用条件：时空守卫（启用）。** 增辉 唤魔师 单体目标相对简单，重点是通过穿插其其他技能来尽可能长时间地维持 [[spell:395152]]。在维持 [[spell:395152]] 的同时，增辉 唤魔师 应该卡冷却使用其短冷却技能，如 [[spell:357208]]、[[spell:396286]] 和 [[spell:409311]]，以获得最佳 DPS，并在间隙中用 [[spell:395160]] 和 [[spell:431442]] 填充。

更详细的循环优先级列表如下所示：

1.3.

#### 完整循环优先级

1. **适用条件：时空守卫（未启用）。** 如果 [[spell:395152]] 的持续时间剩余 4 秒或更少，则施放它。
2. **适用条件：时空守卫（启用）。** 卡冷却施放 [[spell:395152]]，除非你即将施放 [[spell:403631]] 而 [[spell:395152]] 未激活。
3. **适用条件：亘古吐息（启用）。** 卡冷却施放 [[spell:403631]]。
4. **适用条件：亘古吐息（未启用）。** 卡冷却施放 [[spell:357210]]。
5. **适用条件：先知先觉（启用）。** 卡冷却施放 [[spell:409311]]。
6. **适用条件：时空守卫（未启用）。** 如果 [[spell:357208]] 激活，则施放 [[spell:370553]]。
7. **适用条件：时空守卫（启用）。** 卡冷却施放 [[spell:370553]]。
8. 以可用的最高阶级施放 [[spell:357208]]。
9. 卡冷却施放 [[spell:396286]]。
10. **适用条件：时空守卫（启用）；Interwoven Threads（未启用）。** 如果你在下一个 GCD 内没有可用的蓄力技能，则取消 [[spell:370553]] 增益，以最大化 [[spell:431695]] 的覆盖率。
11. **适用条件：Time Skip（启用）。** 如果 [[spell:357208]] 和 [[spell:396286]] 都在冷却中，则施放 [[spell:404977]]。
12. 如果你需要移动，则施放 [[spell:358267]]。
13. 如果 [[spell:395152]] 激活或你拥有两个 [[spell:396187]]，则施放 [[spell:395160]]。
14. **适用条件：炽火龙鳞（启用）。** 如果任何坦克身上当前没有该效果，则施放 [[spell:360827]]。
15. **适用条件：时空守卫（未启用）。** 施放 [[spell:362969]]。
16. **适用条件：时空守卫（启用）。** 施放 [[spell:431442]]。
17. **适用条件：时空守卫（启用）。** 如果你没有剩余的 [[spell:358267]] 层数，则使用 [[spell:362969]] 进行移动。
18. **适用条件：炽火龙鳞（启用）；Regenerative Chitin（未启用）。** 在没有敌人可攻击的空闲时间施放 [[spell:360827]]。

### 增辉 2T+

1.4.

#### 核心循环目标

**适用条件：时空守卫（未启用）。** 增辉 唤魔师 AoE 循环与其单体目标循环非常相似，仅在填充优先级上有细微变化。除此之外，该循环仍然相对简单，重点是通过穿插其其他技能来尽可能长时间地维持 [[spell:395152]]。在维持 [[spell:395152]] 的同时，增辉 唤魔师 应该卡冷却使用其短冷却技能，如 [[spell:357208]]、[[spell:396286]] 和 [[spell:409311]]，以获得最佳 DPS，并在间隙中用 [[spell:395160]] 和 [[spell:361469]] 填充。

**适用条件：时空守卫（启用）。** 增辉 唤魔师 AoE 循环与其单体目标循环非常相似，仅在填充优先级上有细微变化。除此之外，该循环仍然相对简单，重点是通过穿插其其他技能来尽可能长时间地维持 [[spell:395152]]。在维持 [[spell:395152]] 的同时，增辉 唤魔师 应该卡冷却使用其短冷却技能，如 [[spell:357208]]、[[spell:396286]] 和 [[spell:409311]]，以获得最佳 DPS，并在间隙中用 [[spell:395160]] 和 [[spell:431442]] 填充。

更详细的循环优先级列表如下所示：

1.5.

#### 完整循环优先级

1. **适用条件：时空守卫（未启用）。** 如果 [[spell:395152]] 的持续时间剩余 4 秒或更少，则施放它。
2. **适用条件：时空守卫（启用）。** 卡冷却施放 [[spell:395152]]，除非你即将施放 [[spell:403631]] 而 [[spell:395152]] 未激活。
3. **适用条件：亘古吐息（启用）。** 卡冷却施放 [[spell:403631]]。
4. **适用条件：亘古吐息（未启用）。** 卡冷却施放 [[spell:357210]]。
5. **适用条件：先知先觉（启用）。** 卡冷却施放 [[spell:409311]]。
6. **适用条件：时空守卫（启用）。** 卡冷却施放 [[spell:370553]]。
7. **适用条件：时空守卫（未启用）。** 如果 [[spell:357208]] 激活，则施放 [[spell:370553]]。
8. 以可用的最高阶级施放 [[spell:357208]]。
9. 卡冷却施放 [[spell:396286]]。
10. **适用条件：时空守卫（启用）。** 如果你在下一个 GCD 内没有可用的蓄力技能，则取消 [[spell:370553]] 增益，以最大化 [[spell:431695]] 的覆盖率。
11. **适用条件：Time Skip（启用）。** 如果 [[spell:357208]] 和 [[spell:396286]] 都在冷却中，则施放 [[spell:404977]]。
12. 如果你需要移动，则施放 [[spell:358267]]。
13. 如果 [[spell:395152]] 激活或你拥有两个 [[spell:396187]]，则施放 [[spell:395160]]。
14. **适用条件：炽火龙鳞（启用）。** 如果任何坦克身上当前没有该效果，则施放 [[spell:360827]]。
15. **适用条件：Echoing Strike（启用）；时空守卫（未启用）。** 施放 [[spell:362969]]。
16. **适用条件：时空守卫（启用）。** 施放 [[spell:431442]]。
17. **适用条件：Pupil of Alexstrasza（启用）；时空守卫（未启用）；Echoing Strike（未启用）。** 施放 [[spell:361469]]。
18. **适用条件：Pupil of Alexstrasza（启用）；Echoing Strike（未启用）。** 如果你没有剩余的 [[spell:358267]] 层数，则使用 [[spell:362969]] 进行移动。
19. **适用条件：Echoing Strike（启用）；时空守卫（启用）。** 如果你没有剩余的 [[spell:358267]] 层数，则使用 [[spell:362969]] 进行移动。
20. **适用条件：炽火龙鳞（启用）；Regenerative Chitin（未启用）。** 在没有敌人可攻击的空闲时间施放 [[spell:360827]]。

### 起手式

1.6.

#### 示例起手序列

**适用条件：炽火龙鳞（启用）。**

[[spell:360827]]

预读

**适用条件：时空守卫（启用）。**

[[spell:431442]]

预读

**适用条件：时空守卫（未启用）。**

[[spell:361469]]

预读

拉怪

**适用条件：时空守卫（未启用）。**

[[spell:395152]]

**适用条件：先知先觉（启用）。**

[[spell:409311]]

x2

[[item:241288]]

[[item:249346]]

**适用条件：亘古吐息（未启用）。**

[[spell:357210]]

**适用条件：亘古吐息（启用）。**

[[spell:403631]]

**适用条件：时空守卫（启用）。**

[[spell:395152]]

[[spell:370553]]

[[spell:357208]]

**适用条件：Upheaval（启用）。**

[[spell:396286]]

**适用条件：Time Skip（启用）。**

[[spell:404977]]

**适用条件：Time Skip（启用）；时空守卫（启用）。**

[[spell:395152]]

**适用条件：Time Skip（启用）。**

[[spell:357208]]

**适用条件：先知先觉（启用）；Time Skip（启用）。**

[[spell:409311]]

x2

**适用条件：Time Skip（启用）。**

[[spell:395160]]

x2

**适用条件：Time Skip（启用）。**

[[spell:396286]]

[[spell:395160]]

x3

1.6.1.

##### 战斗开始前

1. **适用条件：炽火龙鳞（启用）。** 对主坦克施放 [[spell:360827]]。
2. **适用条件：时空守卫（启用）。** 提前 1.5 秒预读 [[spell:431442]]。
3. **适用条件：时空守卫（未启用）。** 提前 1.5 秒预读 [[spell:361469]]

1.7.

#### 战斗开始后

1. **适用条件：时空守卫（未启用）。** 施放 [[spell:395152]]。
2. 使用 DPS 药水。
3. 使用饰品。
4. 施放 [[spell:409311]]。
5. 施放 [[spell:409311]]。
6. **适用条件：亘古吐息（启用）。** 施放 [[spell:403631]]。
7. **适用条件：亘古吐息（未启用）。** 施放 [[spell:357210]]。
8. **适用条件：时空守卫（启用）。** 施放 [[spell:395152]]
9. 使用 [[spell:370553]]。
10. 施放 [[spell:357208]]。
11. 以能将所有敌人纳入 AoE 范围的最低阶级施放 [[spell:396286]]。
12. **适用条件：Time Skip（启用）；Interwoven Threads（未启用）。** 施放 [[spell:404977]]。
13. **适用条件：Time Skip（启用）；时空守卫（启用）。** 施放 [[spell:395152]]
14. **适用条件：Time Skip（启用）。** 以尽可能高的阶级施放 [[spell:357208]]。
15. **适用条件：Time Skip（启用）；Interwoven Threads（未启用）。** 施放 [[spell:409311]]。
16. **适用条件：Time Skip（启用）。** 施放 [[spell:409311]]。
17. 施放 [[spell:395160]]。
18. 施放 [[spell:395160]]。
19. **适用条件：Time Skip（启用）。** 以能将所有敌人纳入 AoE 范围的最低阶级施放 [[spell:396286]]。
20. 施放 [[spell:395160]]。
21. 继续按照常规循环优先级进行。

:::details 小贴士增辉 是否与 暴风雪 的 DPS 统计插件/Warcraft Logs 兼容？
增辉 不能完全与 暴风雪 的 DPS 统计插件配合使用。暴风雪 的 DPS 统计插件只显示你个人的伤害，不显示你的增益效果的影响，也不显示像 [[spell:434300]] 这样的简单效果。我们 **强烈** 建议你改用 Warcraft Logs，因为 暴风雪 已经为日志实现了战斗钩子，所以你的支援效果带来的伤害会被重新归因到你身上。这意味着它们会显示你的总伤害输出，包括通过增益效果或像 [[spell:434300]] 这样的伤害触发贡献的任何伤害。

战斗钩子的实现并不完美，对于某些事件可能不准确。如果你在归因计算中发现明显的错误，请务必向 暴风雪 报告！

:::

:::details 常见问题我应该何时使用 亘古吐息？
你应该卡冷却使用 [[spell:403631]] 以最大化 [[spell:1259173]] 的覆盖率。

在大秘境中，如果你即将结束一波拉怪，你应该保留 [[spell:403631]]，因为否则你会浪费 [[spell:1259173]] 的持续时间。

在团队副本环境中，如果你的整个团队都在为全团伤害增效效果对齐冷却时间，那么将 [[spell:403631]] 保留到那时会带来轻微的 DPS 收益，只要这不会让你少用一次。

:::

:::details 常见问题我应该何时使用蓄力技能和喷发？
你应该在 [[spell:395152]] 期间使用你的蓄力技能和喷发。如果它不在激活状态，你不应该施放它们，因为这样会浪费你本可以从 [[spell:395153]] 获得的延长效果。

:::

:::details 常见问题为什么 Echoing Strike 构建在单体目标中使用碧蓝打击？
目前 [[spell:361469]] 和 [[spell:362969]] 的单体目标每秒伤害是相同的，[[spell:396187]] 的产生量也相当。如果你使用 [[spell:410784]]，它在完全瞬发施放的情况下能产生更高的 DPS 和每秒更多的 [[spell:396187]]。

[[spell:362969]] 是瞬发的，这使得它玩起来更容易、容错率更高，让你可以更自由地保留 [[spell:358267]] 层数。你将能够在更重要的战斗时刻保留更多层数，从而让你继续施放 [[spell:395160]]。

:::

:::details 小贴士我该如何在输出伤害的同时移动？
作为 唤魔师，你有多种选择可以在移动时输出伤害。

1. 悬空是最优选，因为这将允许你在短暂的动画后边移动边施法。
2. [[spell:409311]] 是一个瞬发法术，可以用来高效地填充一个 GCD 以便移动。
3. 最后，你随时可以使用 [[spell:362969]]，它仍然可以产生 [[spell:369297]]，让你在移动结束后弥补损失的伤害。

:::

1.

### 至暗之夜 第2赛季套装

第 2 赛季的增辉套装如下所示：

- 2件套奖励：[[spell:1296637]] — [[spell:396286]]的冷却时间缩短10秒。
- 4件套奖励：[[spell:1296638]] — 施放[[spell:396286]]会使你的[[spell:412774]]效果强化8秒，将伤害回响的数值提升至45%（通常为15%）。

至暗之夜 第 2 赛季套装对 增辉 唤魔师 的循环决策没有直接影响。然而，套装确实让你可以更频繁地施放 [[spell:396286]]，并使其与你的 [[spell:395152]] 不同步。但是，4 件套加成确实增加了 [[spell:409311]] 良好目标选择的重要性，因为它增加了大量的额外伤害。

1.

### 职业与专精机制详解

接下来我们将介绍一些玩 增辉 唤魔师 的核心机制。我们希望帮助你理解为什么循环中的某些决策是这样做出的，这样你就能将你的游戏水平提升到更高的层次。

### 延长黑檀之力

3.1.

#### 延长黑檀之力

[[spell:395152]] 是一个强大的增益效果，是你最重要的伤害来源之一。[[spell:395152]] 既增加你自己的伤害，又提升盟友 DPS 的主属性。因此，在玩 增辉 唤魔师 时，维持这个增益效果是最高优先级，大多数决策都是围绕以某种方式最大化 [[spell:395152]] 的覆盖率来进行的。

延长 [[spell:395152]] 是 增辉 唤魔师 的核心游戏循环。[[spell:395152]] 可以通过以下方式延长：

- 施放蓄力技能——[[spell:357208]] 和 [[spell:396286]]。
- 施放 [[spell:395160]]——这意味着产生额外的资源，无论是精华还是 [[spell:396187]]，都会让你施放更多的 [[spell:395160]]，从而增加 [[spell:395152]] 的覆盖率。
- 施放 [[spell:403631]]——如果在 [[spell:395152]] 未激活时施放，它将作为一次全新的施放。如果在 [[spell:395152]] 期间施放，它将延长 [[spell:395152]]。
- 施放 [[spell:395152]]——黑檀之力可以利用大流行机制，最多额外延长 30% 的持续时间。这意味着你可以在 [[spell:395152]] 过期前刷新它！
- 在 [[spell:414969]] 激活时施放 [[spell:355913]]。

### 先知先觉 目标选择

3.2.

#### 先知先觉 目标选择

[[spell:409311]] 是一个重要的增益效果，你可以将其施放在盟友身上，为他们提供暴击几率。如果你将 [[spell:409311]] 施放在敌人身上，它会自动施加给附近的 DPS，优先选择激活了 [[spell:361021]] 的玩家。

通过手动选择目标，你可以获得更高品质的目标，尤其是当你的队友表现参差不齐时。某些玩家或职业在特定战斗中往往表现更好，为他们施加增益可能比默认的 [[spell:361021]] 目标选择高出 3-5%！

对于大多数想尝试手动选择目标的玩家来说，一个不错的通用建议是选择团队中表现最好的玩家。这些玩家将从先知先觉中获益最多。

另一个改进方法是查看某场战斗的日志，看看玩家们在什么时候造成最多伤害，尤其是在重要时刻周围，比如小怪、团队虚弱阶段和玩家冷却技能期间。这些是通过手动选择目标以最小的工作量获得显著更多伤害的绝佳机会。你甚至可以在这些重要窗口之间使用通用的自动目标选择！

一个例子是在其升腾期间选择像 元素 萨满祭司 这样的强力冷却专精，然后在它们之间为伤害曲线更平缓的职业如 野兽控制 猎人 或 噬灭 恶魔猎手 施加增益。

### 复制

3.3.

#### 复制

[[spell:1259173]] 是 增辉 唤魔师 的巅峰天赋。[[spell:1259173]] 对 增辉 唤魔师 的输出循环、属性优先级和天赋选择有重大影响。

[[spell:1259173]] 在激活期间通过施放 [[spell:395160]]、[[spell:357208]] 和 [[spell:396286]] 造成大量伤害。[[spell:395160]] 将强化 增辉 的所有天赋，除了 [[spell:438587]]、[[spell:441176]]。这些施法不会延长你的 [[spell:395152]]。

[[spell:1259173]] 有额外的天赋，[[spell:1259174]]（2点）和 [[spell:1259175]]，它们显著增强了 [[spell:1259173]] 的威力并维持其高覆盖率。

[[spell:1259175]] 在 [[spell:1259173]] 期间赋予一个极其强大的增益效果，使你的 [[spell:395152]] 对盟友的效果提高 75%，并显著提升你的 [[spell:396286]] 的伤害。

[[spell:1259174]] 使任何触发 [[spell:395153]] 的效果也能延长 [[spell:1259173]]。这导致了一个非常类似于维持 [[spell:395152]] 的小游戏，你试图最大化 [[spell:1259173]] 的覆盖率。此外，它还显著增强了来自 [[spell:403631]]、[[spell:459537]] 和 [[spell:407866]] 的天赋的威力，增加了你在 [[spell:1259173]] 期间能获得的施法次数。

[[spell:1259175]]的另一个重要意义在于，它极大地鼓励你卡着冷却时间使用[[spell:403631]]。最大化该增益提供的翻倍主属性覆盖率，最终对整体DPS的贡献要大于将[[spell:403631]]留给理想的伤害窗口。

值得注意的是，[[spell:403631]] 在其持续时间内储存团队 30% 的 DPS，这比拥有 [[spell:1259173]] 时额外获得的 12% 主属性带来的 DPS 提升更大。然而，按冷却时间使用 [[spell:403631]] 会导致 [[spell:1259173]] 的覆盖率显著更高，因为施法更频繁且被 [[spell:1259174]] 延长。同时，由于大多数 DPS 的伤害曲线各不相同，你仍将获得足够强大的 [[spell:403631]] 窗口。

### 移动处理

3.4.

#### 移动处理

在 增辉 唤魔师 上处理移动非常简单，因为你拥有 [[spell:358267]]。[[spell:358267]] 可以在任何非蓄力施法期间施放，使你获得移动施法的能力。如果在向任何方向移动时使用 [[spell:358267]]，它将向该方向进行一次短距离冲刺。

对于短距离移动事件，我们建议使用一次 [[spell:409311]] 的充能来处理，以保留 [[spell:358267]] 的充能用于更重要的时刻。

如果你发现自己在没有 [[spell:358267]] 或任何 [[spell:409311]] 充能可用的情况下，你应该使用 [[spell:362969]] 来填充。这仍然可以为你产生 [[spell:396187]]，使 DPS 损失非常小。

1.

### 增辉 唤魔师 的重要冷却技能

增辉 唤魔师 没有很多法术可以使用，但正确使用至关重要，因为该职业的大部分威力来自于使用其短冷却法术和填充输出循环。

### [[spell:403631]]

4.1.

#### 亘古吐息

[[spell:403631]] 是 增辉 唤魔师的主要冷却技能。[[spell:403631]] 会给敌人施加减益效果，储存盟友造成的一部分伤害，并在减益效果到期时爆炸造成该伤害。

确保用 [[spell:403631]] 击中每一个敌人，因为这会对每个目标施加伤害放大效果。

你应该尽量在最短距离使用 [[spell:403631]]，因为线越长，你被锁定无法使用其他法术的时间就越长。如果你需要移动得更远，这是不可避免的，但你会损失一些潜在的伤害。

增辉 唤魔师 有许多增强 [[spell:403631]] 的天赋，例如 [[spell:459537]]、[[spell:407866]] 和 [[spell:441176]]、[[spell:433871]]、[[spell:1260745]] 和 [[spell:441206]]，来自 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 英雄天赋。

作为一名 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长，你会想要按冷却时间施放 [[spell:403631]]，因为它的巅峰天赋 [[spell:1259173]] 为每次施放增加了显著的价值。

作为一名 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 你会获得 [[spell:433871]]，它让你可以引导你的 [[spell:403631]] 并随时结束它。尽快结束它很重要，但要等待来自你的 [[spell:1260745]] 的所有 [[spell:1236970]] 施法。它们大约需要两秒来完成所有施法。

请参阅我们专属的 [增益页面](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)
以获取关于 [[spell:403631]] 如何运作的更精确机制。

### [[spell:395152]]

4.2.

#### 黑檀之力

[[spell:395152]] 是 增辉 唤魔师 伤害输出和玩法的基础。所有决策都围绕着尽可能多地维持这个增益。

你应该在增益剩余 3 秒或更少时施放 [[spell:395152]]。我们选择在 3 秒或更少时施放 [[spell:395152]]，因为它可以产生大瘟疫，将其持续时间的最多 30% 加到下一次施放上而不损失任何持续时间，这使其成为重新施放以优化效果和冷却效率的最有效时机。

如果你在打大秘境并且接近一波怪物的尾声，暂停 [[spell:395152]] 并让它在最后几秒内消失可能是正确的，以保证你在下一波开始时拥有它。如果你知道当前波次结束和下一波开始之间有足够的时间让冷却恢复，那么你仍然应该使用它。

请参阅我们专属的 [增益页面](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)
以获取关于 [[spell:395152]] 如何运作的更精确机制。

### [[spell:370553]]

4.3.

#### 扭转天平

[[spell:370553]] 是一个 2 分钟的冷却技能，将使你的下一次蓄力施法瞬间完成，达到最高层数。

[[spell:370553]] 在你通过使用蓄力法术消耗增益之前不会开始冷却。

作为一名 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 这个法术最好与 [[spell:357208]] 配合按冷却时间使用，让你在不花费额外时间的情况下获得更高的层数。

作为一名 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 你会获得几个增强 [[spell:370553]] 威力的天赋。最值得注意的是 [[spell:431695]]，它被 [[spell:1260484]] 进一步强化。这些额外的天赋将 [[spell:370553]] 变成了一个强大的冷却技能。

如果你作为以下职业使用 [[spell:404977]] ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 那么我们建议使用宏来立即取消增益。如果你在一个 GCD 内有蓄力法术可用，你应该改用它。这是一个 DPS 收益，因为 [[spell:370553]] 在使用时不会进入冷却，而是在被消耗时进入冷却。如果它没有几乎按冷却时间使用，这会导致它与 [[spell:404977]] 失去同步。

#### 时空守卫取消光环 扭转天平

```wow-macro
#showtooltip
/cast 扭转天平
/cancelaura 扭转天平
```

作为一名 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫，我们按冷却时间使用 [[spell:370553]] 以获得尽可能高的属性增益覆盖率。这有助于尽可能长时间地维持 [[spell:395152]] 和 [[spell:1259173]]。

如果你不想按冷却时间使用 [[spell:370553]]，那么我们强烈建议将其保留与 [[spell:403631]] 一起使用，因为这仍然是完全可行的，尽管在性能上略弱一些。

### [[spell:409311]]

4.4.

#### 先知先觉

[[spell:409311]] 是一个短冷却、2 层数的增益法术，增辉 唤魔师 应该在循环中使用。[[spell:409311]] 增益将为你选择的一名盟友提供暴击几率。你应该避免在没有被迫因停机时间的情况下溢出 [[spell:409311]] 的层数。

[[spell:409311]] 被 [[spell:407869]] 增强，它让你在施放时有机会获得一次 [[spell:396187]]，[[spell:412774]] 使拥有 [[spell:409311]] 的玩家有机会复制造成的伤害。此外，还有三个
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 天赋强化 [[spell:409311]]：[[spell:431874]]、[[spell:431715]] 和 [[spell:432004]]。

你可以选择通过将这个增益给团队中造成最多伤害的玩家来优化其目标选择，但这在 DPS 上不会有显著差异。你也可以选择将其施放在首领身上，让游戏的自动目标选择来处理。手动目标选择从最差情况到最好情况可能带来高达 5% 的 DPS 收益。

请参阅我们专属的 [增益页面](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>) 以获取关于 [[spell:409311]] 如何运作的更精确机制。

### 蓄力法术

4.5.

#### 蓄力法术

增辉 唤魔师 有两个蓄力法术：[[spell:357208]] 和 [[spell:396286]]。

增辉 唤魔师 施放蓄力法术会获得额外效果。最重要的效果是你将为附近的一名 DPS 提供 [[spell:413984]] 增益，提高他们的全能。请参阅我们专属的 [增益页面](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>) 以更具体地了解 [[spell:413984]] 的运作方式。此外，增辉 将通过 [[spell:395153]] 延长 [[spell:395152]]。

你不应该在 [[spell:395152]] 未激活时施放 [[spell:357208]] 或 [[spell:396286]]，因为这会浪费来自 [[spell:395153]] 的延长效果，而这大部分是其价值所在。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月18日：** 在时空守卫的起手循环中添加了缺失的永恒之焰施放。
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月30日：** 修正拼写错误。
- **2026年4月20日：** 为12.0.5版本更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜前赛季更新。
- **2026年2月10日：** 修复起手式中 火焰 吐息被隐藏的问题
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 已为11.2.7版本进行更新。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月22日：** 修复 时空守卫 起手式的输出循环顺序问题。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已针对11.1.7补丁更新，包含关于战斗助手和单键助手的信息。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁更新，包含第2赛季套装的循环改动。
- **2024年12月15日：** 已针对11.0.7补丁进行审查
- **2024年10月21日：** 已针对11.0.5补丁进行审核
- **2024年10月4日：** 根据在线修复更新默认的鳞长大秘境构筑。
- **2024年9月22日：** 修正拼写错误。
- **2024年9月22日：** 更新鳞长与熔火余烬的输出循环。
- **2024年9月10日：** 因熔火余烬而更新关于提升烈焰之息优先级的说明。
- **2024年9月9日：** 改进扭转天平信息的可读性。
- **2024年8月21日：** 已为《地心之战》上线更新，加入英雄天赋支持。
- **2024年7月23日：** 起手式已随熔火余烬修正。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为巨龙时代第4赛季审核并更新
- **2024年1月19日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月13日：** 修正默认天赋复选框，并加入自动选怪说明。
- **2023年7月10日：** 页面已添加。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到《魔兽世界》12.1.5 中你的 增辉 唤魔师 的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们都为你准备好了！

1.

### 增辉 唤魔师 毕业装备指南

欢迎来到我们的 增辉 唤魔师 至暗之夜 第2赛季装备页面。本节将涵盖你正确装备角色所需了解的一切。请查看以下部分以获取关于最佳装备的信息，包括饰品和制造物品。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面  [配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表突出了 增辉 唤魔师 可获取的一套整体毕业配置。还有其他装备配置可能具有等效的 DPS 输出。其他配置取决于你的角色掉落了什么物品。如果你想获得针对你特定角色的个性化推荐，我们建议查看我们关于模拟角色的完整指南，该指南位于 [此处](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，催化剂将保留你催化物品的属性和效果。我们在下面列出了每个部位最值得催化的物品：

- 头盔：来自的 [[item:159374@JAAEAAgNyQWN]] [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 肩膀：[[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 胸甲：来自的 [[item:271876@JAAEAAAG2YhN]] [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手套：来自的 [[item:281238@JAAEAAgNyEuN]] [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 腿部：[[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 常见问题：获取优先级最高的物品是什么？
获取优先级最高的物品是来自的全部三件奇物物品 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)。我们建议每周 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 每周尽可能使用它，并在进行时使用困难难度 **恩护**时在英雄难度下使用，这会移除伤害饰品，直到你拥有全部三件为止。

其他优先级是高精通物品，例如来自的 [[item:193752@JAAIAAQkCYHKvbRLfA]] [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>).

其他高优先级物品包括：[[item:268249@JAACAAgNyA]]、[[item:158366@JAACAAgNyA]] 和 [[item:250224@JAACAAgNyA]]。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271502@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268251@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271504@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>副手</th><td>[[item:268197@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含来自第2赛季大秘境地下城的可刷取装备的最高 DPS 配置。还有其他装备配置可能具有等效的 DPS 输出。其他配置取决于你的角色掉落了什么物品。如果你想获得针对你特定角色的个性化推荐，我们建议查看我们关于模拟角色的完整指南，该指南位于 [此处](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

:::details 常见问题我需要哪些套装部件？
对于 至暗之夜 第2赛季，转化器将保留你转化物品的属性和效果。我们列出了以下每个部位从大秘境转化的最佳物品：

- 头盔：来自的 [[item:159374@JAAEAAgNyQWN]] [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 肩膀：[[item:239049@JAACAAgNyA]]，掉落于 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 胸部：[[item:251233@JAACAAgNyA]]，掉落于 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 手套：来自的 [[item:193752@JAAKAAQkCYHKvbRLfYjM]] [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- 腿部：[[item:159375@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：这个地下城拥有所有地下城中最多的毕业物品数量，所以我们强烈建议从这里开始刷取。确保你处于 恩护 战利品专精以避免饰品。
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：这里拥有 增辉 唤魔师最好的饰品之一（[[item:250224@JAACAAgNyA]]），以及一条不错的腰带、头盔和项链。
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：这里拥有另一个不错的大秘境饰品（[[item:250215@JAACAAgNyA]]）和我们第二好的戒指。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271499@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271500@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271504@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250224@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>副手</th><td>[[item:271681@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含来自 至暗之夜 第2赛季团队副本物品的最高 DPS 配置。还有其他装备配置可能具有等效的 DPS 输出。其他配置取决于你的角色掉落了什么物品。如果你想获得针对你特定角色的个性化推荐，我们建议查看我们关于模拟角色的完整指南，该指南位于 [此处](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，催化剂将保留你催化物品的属性和效果。我们在下面列出了每个部位最值得催化的物品：

- 头盔：来自的 [[item:268230@JAAEAAgNyQWN]] [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 肩膀：[[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 胸甲：来自的 [[item:271876@JAAEAAAG2YhN]] [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 手套：来自的 [[item:281238@JAAEAAgNyEuN]] [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 腿部：[[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

:::

:::details 常见问题：获取优先级最高的物品是什么？
获取优先级最高的物品是来自的全部三件奇物物品 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)。我们建议每周 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 每周尽可能使用它，并在进行时使用困难难度 **恩护**时在英雄难度下使用，这会移除伤害饰品，直到你拥有全部三件为止。

其他高优先级物品包括：[[item:268249@JAACAAgNyA]]、好饰品如 [[item:270170@JAACAAAKxA]]、[[item:270161@JAACAAAKxA]] 或 [[item:270164@JAACAAAKxA]]。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271502@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268251@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271504@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>副手</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 增辉 唤魔师 饰品推荐

增辉 唤魔师 目前更倾向于佩戴被动饰品，因为 [[spell:403631]] 的冷却时间由于冷却缩减效果的影响，通常无法与饰品对齐。如果你使用主动饰品，你可以按冷却时间使用它们。

本层级可用的主要突出饰品是 [[item:270168@JAACAAAG2A]]、[[item:281215@JAACAAAOyA]] 和 [[item:270161@JAACAAAOyA]]。对于团队副本，我们建议使用 [[item:281215@JAACAAAOyA]] 和 [[item:270168@JAACAAAG2A]]。对于大秘境，我们建议使用 [[item:270161@JAACAAAOyA]] 和 [[item:281215@JAACAAAOyA]]。

有这么多饰品可供选择，我们建议查看下面的饰品排名图表，以更好地了解哪些饰品是好的。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 增辉 唤魔师 饰品排名
除非为了比较而指定较低的物品等级，否则所有饰品均假设为史诗物品等级。其理念是在最大可获取物品等级下比较饰品，以便你了解它们的位置。即使这些饰品在此列表中的排名高于被动饰品，我们也不建议使用两个主动饰品。有关饰品对你自己角色表现的更准确信息，请 [模拟你的角色](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

此列表中定义的“Tier”差距约为 0.5% DPS，这意味着 S 级饰品比 A 级饰品好约 0.5%，以此类推。

<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>团本</th>&#10;<th>秘境+</th>&#10;</tr>&#10;<tr>&#10;<td><span><strong>S级</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个引导式主动饰品，在使用时造成极大的爆发伤害，冷却时间长达 4 分钟。这个饰品在 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 和 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a>&#10;             上表现卓越，因为有伤害易伤阶段。在其他战斗中，这个饰品仍然表现极佳。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个被动饰品，提供大量平均暴击几率且高度稳定。额外效果显著改善了在有小怪的战斗中提供的平均属性。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:249346@JAACAAgV1A]] - <span><em>点击查看详情</em></span>&#10;<span>尽管是第1赛季的饰品，但这是 增辉 本层级获得更高爆发 DPS 的极具竞争力的饰品。在 298 物品等级下，这个饰品仅被幻象饰品超越。如果你没有 298 物品等级的这个饰品，你将无法在本赛季获得它，需要使用另一个饰品。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270161@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个伤害触发饰品，在敌人身上留下可叠加的持续伤害。这个持续伤害本身伤害合理，但使其在大秘境中真正强大的是击杀敌人时的额外效果。这些爆炸造成大量伤害，并极大地奖励连锁拉怪，让持续伤害效果在敌人之间传递。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个被动饰品，提供大量平均暴击几率且高度稳定。额外效果显著改善了在大秘境中提供的平均属性，因为每一波怪都会给你带来大量的额外层数爆发。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>A级</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270169@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个有趣的主动饰品，具有递增的主属性减益效果。当你使用主动效果时，它会移除减益并给你一个强大的主动增益。尽管可以在 344 物品等级获取，但这个饰品目前略微调整不足。这个饰品可用于有伤害易伤阶段或小怪的首领，将你的伤害转移到这些窗口。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270167@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个被动饰品，提供一个在战斗中起伏的智力增益。这个饰品评价很高，因为它既经过良好调整，在多目标顺劈战斗中又比伤害饰品有更好的成长性。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270170@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个不错的主动伤害饰品。这个饰品的额外效果获得很少的冷却缩减，因为尽管有小怪战斗，但需要你完成最后一击。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个精通触发饰品，为被动精通提供巨大提升，而精通是增辉的最佳属性。这个饰品会触发一个你需要站进去的区域，提供更多精通。这总是生成在你的头顶，相当容易看到，但你不能保证 100% 覆盖。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270161@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个伤害触发饰品，在敌人身上留下可叠加的持续伤害。这个持续伤害本身提供优秀的单体伤害，在团队副本中是主要贡献，因为你通常不会从爆炸中获得太多伤害。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250224@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个被动饰品，本身没有任何属性，而是同时具有伤害触发和主属性触发。这对单体目标来说调整得相当不错，但在多目标战斗中略逊于属性饰品。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是本赛季可用的最佳主动属性饰品。如果你想在战斗中提高爆发伤害，尤其是在处理小怪或伤害爆发时，这个饰品很好。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个高预算属性饰品，尽管增辉的副属性成长性较差，但它仍提供强大且稳定的 DPS 提升。这个饰品对 AoE 伤害评价很高，而 AoE 伤害在本团队副本中占很大比例。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个引导式主动饰品，在使用时造成大量爆发伤害。如果你在地下城中需要在特定波次获得额外爆发，可以使用这个饰品。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250224@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个没有任何属性的被动饰品，取而代之的是同时拥有一个伤害触发和一个主属性触发。它在单体目标上调整得相当不错，但在AoE中略逊于属性饰品。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270167@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个被动饰品，提供一个在战斗中起伏的智力增益。这个饰品评价很高，因为它既经过良好调整，在多目标顺劈战斗中又比伤害饰品有更好的成长性。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个高预算的属性饰品，尽管增辉的副属性加成效果较差，它仍能提供强大而稳定的DPS提升。在大秘境中它的评级更高，因为属性饰品相对于团本更强，因为强力的伤害饰品通常无法有效加成。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个精通触发饰品，为被动精通提供巨大提升，而精通是增辉的最佳属性。这个饰品会触发一个你需要站进去的区域，提供更多精通。这总是生成在你的头顶，相当容易看到，但你不能保证 100% 覆盖。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是本赛季第二好的主动使用饰品，仅次于第一赛季的[[item:249346@JAACAAgV1A]]。如果你想在一场战斗中提升爆发伤害，尤其是在处理小怪或伤害爆发阶段时，这个饰品很不错。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270170@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个可以从团本获得的强力单体目标伤害饰品。在整个大秘境钥匙过程中，它都能提供优秀的优先目标和单体目标伤害。此外，当敌人死亡时，这个饰品会获得额外的冷却缩减，让你在整个地下城中能使用更多次。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270169@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个有趣的主动使用饰品，带有一个递增的负面主属性减益效果。当你使用主动效果时，它会移除该减益并给你一个强大的主动增益。这个饰品可以让你把伤害从一波怪物中不太重要的部分（比如清理残余小怪的尾段）转移到一波怪物的起始部分，此时DPS的技能正在冷却中。尽管如此，它目前略微调整不足，仅在344装等时推荐使用。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>B级</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:248583@JAAEAAANyE4M]]（英雄）- <span><em>点击查看详情</em></span>&#10;<span>这是一件可探索饰品，其属性可以更改以触发四种类型中的任何一种。对于 增辉 唤魔师，我们希望这件饰品触发精通。在赞达拉神庙使用该饰品即可获得此属性。注意：请确保从任何宏中移除饰品栏位，因为该饰品的使用效果会破坏你的宏。</span>&#10;</li>&#10;<li>[[item:273794@JAACAAAOyA]]</li>&#10;<li>[[item:273796@JAACAAAOyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfgjM]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:248583@JAAEAAANyE4M]]（英雄）- <span><em>点击查看详情</em></span>&#10;<span>这是一件可探索饰品，其属性可以更改以触发四种类型中的任何一种。对于 增辉 唤魔师，我们希望这件饰品触发精通。在赞达拉神庙使用该饰品即可获得此属性。注意：请确保从任何宏中移除饰品栏位，因为该饰品的使用效果会破坏你的宏。</span>&#10;</li>&#10;<li>[[item:273794@JAACAAAOyA]]</li>&#10;<li>[[item:273796@JAACAAAOyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfgjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>C级</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>[[item:251792@JAACAAANyA]]（英雄）</li>&#10;<li>[[item:249809@JAACAAgV1A]]</li>&#10;<li>[[item:249343@JAACAAgV1A]]</li>&#10;<li>&#10;&#10;&#10;[[item:245829@JAAKAAwt1wgNRDjexwhN]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个可制作的暗月卡牌饰品。它是表现最好的暗月卡牌，但和所有其他暗月卡牌一样，会占用你一个美化栏位。失去一个美化效果相当于损失约1%的DPS，这会将该饰品从A级降到C级。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAAOyA]]</li>&#10;<li>[[item:251792@JAACAAANyA]]（英雄）</li>&#10;<li>[[item:249809@JAACAAgV1A]]</li>&#10;<li>&#10;&#10;&#10;[[item:245829@JAAKAAwt1wgNRDjexwhN]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个可制作的暗月卡牌饰品。它是表现最好的暗月卡牌，但和所有其他暗月卡牌一样，会占用你一个美化栏位。失去一个美化效果相当于损失约1%的DPS，这会将该饰品从A级降到C级。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>D级</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAACAAAOyA]]</li>&#10;<li>[[item:251786@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:245855@JAAKAAwt1wgNRDjexwhN]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个可制作的暗月卡牌饰品。它会占用你一个美化栏位。失去一个美化效果相当于损失约1%的DPS，这会将该饰品从B级降到D级。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:245846@JAAKAAwt1wgNRDjexwhN]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个可制作的暗月卡牌饰品。它会占用你一个美化栏位。失去一个美化效果相当于损失约1%的DPS，这会将该饰品从B级降到D级。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:245750@JAAKAAwt1wgNRDjexwhN]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个可制作的暗月卡牌饰品。它会占用你一个美化栏位。失去一个美化效果相当于损失约1%的DPS，这会将该饰品从B级降到D级。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAACAAAOyA]]</li>&#10;<li>[[item:251786@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:245855@JAAKAAwt1wgNRDjexwhN]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个可制作的暗月卡牌饰品。它会占用你一个美化栏位。失去一个美化效果相当于损失约1%的DPS，这会将该饰品从B级降到D级。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:245846@JAAKAAwt1wgNRDjexwhN]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个可制作的暗月卡牌饰品。它会占用你一个美化栏位。失去一个美化效果相当于损失约1%的DPS，这会将该饰品从B级降到D级。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:245750@JAAKAAwt1wgNRDjexwhN]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个可制作的暗月卡牌饰品。它会占用你一个美化栏位。失去一个美化效果相当于损失约1%的DPS，这会将该饰品从B级降到D级。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

该 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 12.0.5版本中加入的额外骰点在12.1版本中得以延续。这些可以在地下城中使用，或在击杀特定团本首领后使用，让你从该地下城或团本首领处获得一件保底战利品。你获得的物品是随机的，但不会获得重复物品，因此在特定地点再次使用会给你在剩余物品中另一次机会。

3.1.

#### 增辉 唤魔师 推荐的虚空星云核心使用方法

对于第二赛季，我们建议从一个 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 中心的额外骰点策略开始。如果你使用一个 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 在英雄难度 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
上，你将从该首领处获得一个1/6神话物品。这非常强大，因为这些物品都是咒法物品，而且它们非常强，只有在击败史诗难度战斗后获得的升级版本才能超越它们。

我们将通过采取以下策略来执行此方案： [混沌虚空核心](<https://www.wowhead.com/currency=3418>)从赛季开始后你的前三次宏伟宝库中获取，以代替宝库中的物品。如果你看到一件极品装备，否则获取起来会很耗时，比如一件属性完美的大秘境物品，那么你可以放心地跳过该周的
[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 的那一周。

此外，即使你没有通关 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 在其开放的第二周，你也可以保留你的 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)，等你通关它后，即使在锁定状态下，也可以重复攻略该战斗三次，并使用你的额外骰点！

在使用你的 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)于 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)之后，另一个使用你硬币的好地方是 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>) 用于 [[item:268249@JAACAAgNyA]] 和 [[item:268254@JAACAAgNyA]]。你也可以在这里切换为 恩护 战利品专精，以避免在你已经拥有适合团队副本的优质饰品时获得 [[item:270161@JAACAAgNyA]]。如果你主要是为了大秘境配装，那么我们建议保持输出战利品专精，因为该饰品是大秘境的毕业选择。

在此之后，我们建议使用你的硬币去寻找你仍然需要的剩余极品装备清单物品。

以下是上述策略的简短总结：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 在 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 使用DPS拾取专精，以获取全部三件咒法物品和该饰品。
2. 在 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 上骰点，以获取戒指和饰品。
3. 在 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>) ，直到获得[[item:268249@JAACAAgNyA]]和[[item:268254@JAACAAgNyA]]为止。
4. 可选地，在 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>) 上骰点，同时使用DPS拾取专精以获取[[item:270161@JAACAAgNyA]]，如果你主要面向大秘境。你需要在从瓦什尼克处获得每一件物品之前切换到DPS拾取专精。
5. 剩余的毕业装备列表物品

:::

3.2.

#### 晋升毒液石

在花费你的[[item:280562]]时，我们建议按以下顺序优先考虑栏位：

1. 你的武器
2. 你的副手
3. 你的主动使用饰品
4. 你的被动饰品
5. 你的项链

:::details 小贴士：使用剧毒石时，最好的项链是什么？
一条精通项链，比如

[[item:268251@JAACAAAOyA]]

在340装等时，将优于神话难度的

[[item:268265@JAACAAAG2A]]

在344装等，因为它之前仅因装等更高而成为极品装备。

:::

1.

### 增辉 唤魔师 最佳制造物品

专业装备在至暗之夜第2赛季中对增辉唤魔师极为有用。增辉目前最优先考虑精通属性，超过其他所有属性，因此能够在制造装备上选择完美属性非常强大。此外，你的制造装备总共可以使用最多两个装饰品，这能进一步提升你的伤害输出！

本节重点介绍以最优化的顺序制作物品，以获得即时、高效且有效的威力提升。你在这里制作的一些物品最终不会成为你终局毕业装备清单的一部分，需要被替换。但我们仍然会制作它们，因为它们是从你的火花和迷雾纹章中获得伤害输出的极其有效的方式。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **增辉制造装备优先级**
- [[item:245769@JAAMAAwt1wgNRDzViscNcYD]]搭配[[item:273060]]。你最终会用神话副手替换它，因为[[item:240167]]强于[[item:273060]]或[[item:245876]]中的任何一个。
- 如果你没能立即用硬币获得[[item:271092@JAACAAgNyA]]，你可以选择制作[[item:237838@JAAMAAwt1wgNRDzViscNcYD]]并搭配[[item:273060]]。你只应在需要早期提升实力时这样做，因为你的武器栏位是唯一可能带来最大实力提升的地方。你会继续使用它，直到你获得同等或更高装等的[[item:271092@JAACAAgNyA]]，并有另一个空余火花来制作一件带有[[item:240167]]的护甲。
- 升级价值最高的护甲栏位搭配[[item:240167]]。这不会是你极品装备的一部分，而是用于开荒的临时实力物品。你可以选择改为制作下面所示的腰带和护腕。
- [[item:244584@JAAKAAgIvYTNbWCYwclI]]搭配[[item:240167]]，如果你仍在使用制作武器，则移除武器上的美化效果。
- [[item:244581@JAAKAAgIvYTNbWCYwclI]]搭配[[item:240167]]，如果你仍在使用制作副手，则移除副手上的美化效果。
- 工程学制品，如[[item:244745@JAAKAAAD2cbNbWit1E4K]]和[[item:244773@JAAKAAAD2cbNbWit1E4K]]。
- 任何你尚未获得神话级的物品。

:::

:::details 常见问题：如果主手或法杖预算更高，为什么先制作副手？
我们选择先制作副手，因为我们假设你正在遵循

[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

“虚空核心”部分中概述的额外骰点策略。如果我们有机会在下周获得更好的武器，我们不想立即制作主手，而副手是下一个可用的最高预算制作选择。如果你不打算遵循此策略，你应该制作法杖。

:::

:::details 常见问题：为什么增辉要使用[[item:240167]]？
我们选择使用

[[item:240167]]

因为它目前是预算最高的美化效果之一，这包括了给予盟友的主要属性。

:::

:::details 常见问题：有哪些部位要避免制作？
随着团本套装转化机制的改动，现在没有需要避免制作的栏位了，尽管你在套装栏位上制作时仍应稍加小心。

:::

4.1.

#### 增辉唤魔师最佳装饰品

美化物品比相同装等的其他物品更强大。这意味着，尽管它们不是装等最高的，但它们被用作我们极品装备清单的一部分。

对于增辉唤魔师来说，只有少数几个好用的装饰品：[[item:240167]]、[[item:273060]]、[[item:245876]]和[[item:251487]]。你应该在制造装备上使用这些，以填补装备上的空缺。

[[item:273060]]是12.1版本中新增的一个美化效果。这个美化效果可以以相等的概率触发任何副属性增益。这是一个非常强大的美化效果，因为它提供大量的属性。它只能制作在武器和副手上。

所有这些美化效果都可以叠加。拥有两个相同的效果会使触发效果的强度翻倍！

[[item:245876]]在你的法术或技能触发它时提供临时的副属性增益。提供的属性取决于
**你正在战斗的生物类型**:

- **急速：** 元素、异怪、恶魔
- **暴击：** 野兽、机械
- **精通：** 人型、龙类
- **全能：** 亡灵、巨人、其他

对于增辉唤魔师来说，这个装饰品非常强大，因为它有着极高的覆盖率。这个效果是完全被动的，不需要你围绕它进行操作。

**重要提示：**

- 获得的属性是 **由敌人生物类型决定的**，这意味着它的价值会根据地下城或团本战斗而变化，从而使这个美化效果时好时坏。
- 许多团本首领和地下城敌人属于 **人型或恶魔类别**，这通常导致 **精通或急速**。急速对增辉唤魔师来说是非常优秀的属性，而精通则较差，因此这个装饰品的强度会根据不同的首领而有很大波动。
- 我们建议一旦你能制作第三件制作物品，就尽快移除这个美化效果，因为你将获得的属性是不确定的。

[[item:240167]]有几率召唤一个 **法力幼龙** ，它会为你和一名附近的盟友施加[[spell:1229746]]。这个效果会提高 **主属性** 两名玩家的主属性，持续一小段时间。

这是增辉唤魔师的最佳装饰品，提供接近1%的伤害提升。增辉唤魔师从主属性获得的收益远超副属性，因为它几乎影响你所有的伤害输出，甚至包括[[spell:395152]]！

[[item:251487]]是一个单体目标伤害触发美化效果，只能制作在珠宝栏位上。

这可以添加到以下两件物品之一：

- [[item:240949@JAAKAAgIvYTNbWyVi0IN]]
- [[item:240950@JAAKAAgIvYTNbWyVi0IN]]

**重要提示：**

- 这个美化效果的伤害会根据你装备的宝石总类型（即主属性）进行加成。尽管如此，提升非常小，因此我们不建议为全能或精通镶嵌宝石。不过，你至少需要各镶嵌一颗急速和暴击宝石！
- 这个效果在 **单体目标战斗**中表现最佳，因为它只伤害一个敌人。
- 在多于一个目标时，这个美化效果比上面的[[item:240167]]更差，在单目标时则大致相当。

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽。你可以在宏伟宝库附近的商贩处用未选择物品时获得的代币兑换该物品。你需要上交六个才能获得一个[[item:275707]]。

1.

### 纹章使用

在赛季初期，你获取纹章的机会受到每周上限的限制。在此期间，你需要高效地使用
[秘境雾崖](<https://www.wowhead.com/currency=3446>) 和 [英雄迷雾徽记](<https://www.wowhead.com/currency=3445>)时要尽可能高效。你可以使用这些货币 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 来提升物品等级。我们建议只升级你会长期使用的物品，或者按照提升幅度最大的顺序进行升级。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **增辉 唤魔师升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

理想情况下，你会将所有物品升级到最大可能等级，但在赛季初期高效使用纹章非常重要，这样可以避免落后于同伴，保持竞争力！

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁更新，添加了新的团队副本首领物品。
- **2026年8月18日：** 根据这些改动更新了饰品天梯榜和制造建议。
- **2026年8月12日：** 修正了大秘境物品来源中戒指和披风的错别字。
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月26日：** 由于导致平均层数减少的错误未被修复，在大秘境梯队列表中移除了奥恩之眼。
- **2026年6月16日：** 孢子融合部分的错别字修复。
- **2026年6月15日：** 新增孢子融合装备部分。
- **2026年5月4日：** 更新大秘境饰品排名。
- **2026年4月20日：** 更新装备部分，添加升腾虚空核心和缥缈虚空核心。更新饰品层级列表。
- **2026年3月27日：** 添加光盲之怒圣歌饰品。
- **2026年3月23日：** 在层级列表中降低折磨灵魂容器的排名。
- **2026年3月19日：** 捕魂者护符饰品现在会正确地为唤魔者掉落。
- **2026 年 3 月 17 日：** 更新饰品和套装信息。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜前赛季更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已更新以包含关于代币和套装对比的信息。
- **2025年9月10日：** 更新装备页面，标明热修后的套装表现。
- **2025年8月12日：** 在饰品初步调整后更新饰品套装层级。
- **2025年8月5日：** 更新 鳞长 的套装数值，更改饰品层级列表，并调整毕业配装列表。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月24日：** 因削弱更新属性优先级推荐
- **2025年6月15日：** 已更新至 11.1.7 补丁，包含属性优先级腰带。
- **2025年5月12日：** 更新了几个饰品的评论。
- **2025年5月8日：** 完全更新了装备列表，因为11.1.5补丁的在线修正导致属性优先级发生变化。
- **2025年5月2日：** 更新了迪纳尔部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月4日：** 已针对团队副本第一周的装备调整更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁更新，包含新的毕业装备列表和饰品信息。
- **2025年1月4日：** 更新饰品排行榜，提升Cirrals Concoctory的排名。
- **2024年12月17日：** 推荐装备页面已更新瑟尔奇之戒。在大秘境装备部分添加了关于咆哮战争女王的说明。
- **2024年12月17日：** 已根据改动更新瑟尔奇之戒的推荐。
- **2024年12月15日：** 已针对11.0.7补丁更新，添加了瑟尔奇之戒，毕业装备已更改。
- **2024年10月21日：** 11.0.5补丁更新
- **2024年9月22日：** 修正拼写错误。
- **2024年9月21日：** 已为新的鳞长信息更新。
- **2024年9月17日：** 更新史诗钥石地下城开季的饰品排行榜。
- **2024年9月13日：** 移除前瞻装备列表
- **2024年9月9日：** 添加《地心之战》第1赛季的镶金边信息
- **2024年9月9日：** 添加《地心之战》第1赛季装备与饰品的毕业列表。
- **2024年8月22日：** 为镶金边物品添加免责声明
- **2024年8月22日：** 修正一个拼写错误
- **2024年8月21日：** 已更新为《地心之战》上线的前瞻毕业装备。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为巨龙时代第4赛季审核并更新
- **2024年1月19日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已为10.2.5补丁更新，更改了地下城限定的毕业武器
- **2023年11月24日：** 修正地下城装备中的拼写错误。
- **2023年11月21日：** 更新毕业饰品以考虑层数损失。
- **2023年11月13日：** 根据最新的在线修复进行装备调整与更新。
- **2023年11月7日：** 根据最新的在线修复进行装备调整与更新。
- **2023年11月6日：** 已为10.2补丁更新
- **2023年9月4日：** 已针对10.1.7补丁审核并更新格式
- **2023年7月10日：** 页面已添加。

显示更多

显示更少

:::

## 属性优先级

在本页面中，你将找到你的增辉 唤魔师的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和玩法互动。我们的内容已根据《魔兽世界》12.1.5版本补丁更新。

1.

### 增辉 唤魔师属性优先级

目前 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长有着相似的属性优先级，两者都重度投入精通并使用[[spell:409267]]以及[[spell:1250914]]。作为一个
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫来说，暴击略优于急速，但两者非常接近。作为一个 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长来说，两者等效。全能对两个英雄天赋来说都很差。

装备等级

精通

暴击

急速

全能

对于非珠宝槽位来说，物品等级是配装中最重要的方面。在珠宝上，牺牲少量物品等级换取更好的属性是值得的，因为增辉的属性收益不会随副属性而大幅提升。

目前精通明显领先于其他任何属性，直到你接近1840精通左右的第二属性递减阈值。在那一点上，它大致等于急速和暴击几率。在此之前，你会优先堆尽可能多的精通，理想情况下让暴击几率或急速作为物品上的第二属性。

作为一名 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 作为时空守卫并拥有[[spell:431874]]，你可以让[[spell:395152]]和[[spell:409311]]产生暴击，使这些增益效果的强度在暴击时提高50%。这使暴击的收益超过急速，成为增辉唤魔师的第二佳属性。

1.

### 深入属性解析

**智力** 是你的主属性。你应该在所有升级中寻找该属性。它为你提供法术强度，增加你法术的伤害。

**精通** （[[spell:406380]]）使你施放的强化法术给予一个伤害输出[[spell:413984]]，为另一名盟友提供10秒的全能加成。此外，它还延长[[spell:413984]]、[[spell:403631]]、[[spell:395152]]和其他增益光环的持续时间。

**暴击** 提高你的技能造成200%伤害的几率。[[spell:395153]]意味着你的[[spell:395152]]延长效果可以暴击，使延长量增加50%。

**急速** 提高你的施法速度（包括强化法术）和你的周期性效果的跳数频率。

**全能** 增加你造成的所有伤害和治疗，并减少你受到的所有伤害。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已为至暗之夜前赛季审查。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月8日：** 已针对11.1.5补丁的在线修正更新，更改了属性优先级。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁更新，精通属性对所有英雄天赋均为首选。
- **2024年12月15日：** 已针对11.0.7补丁更新，对鳞长而言暴击属性优于精通。
- **2024年10月21日：** 已针对11.0.5补丁进行审核
- **2024年9月21日：** 已为新的鳞长信息更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为《地心之战》上线更新，包括时空守卫的新属性。
- **2024年8月18日：** 已针对《地心之战》上线进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为巨龙时代第4赛季审核并更新
- **2024年3月19日：** 已针对10.2.6版本进行审阅
- **2024年3月8日：** 更新属性并更改格式
- **2024年1月15日：** 已针对10.2.5补丁进行审核
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 页面已添加。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面中，我们列出了你的增辉 唤魔师可以获得的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

在至暗之夜中，既有主属性宝石（史诗品质）也有主属性宝石（稀有品质）。目前，主属性宝石明显强于副属性宝石。

你只能使用一颗主属性宝石，我们推荐使用[[item:240983]]，因为它提供最多的主属性。我们建议用  

[[item:240898]]填满你所有剩余的插槽，因为精通和暴击几率是增辉唤魔师的最佳属性。如果你想让角色多一点急速，可以使用[[item:240900]]。

1.

### 最佳附魔和武器强化

你应该始终使用[[item:243733]]。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>[[item:244031]]</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>[[item:243959]]</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

你应该在所有内容中使用[[item:241322]]，因为精通是增辉 唤魔师的最佳属性。

3.2.

#### 药水

我们建议确保你有新的[[item:271883]]治疗药水，因为它们的治疗量远超旧的[[item:241305]]。

如果精通是你最高的属性，我们建议在所有内容中使用副属性药水[[item:241288]]。如果精通不是你最高的属性，我们建议使用主属性药水，如[[item:241292]]或[[item:241308]]。

[[item:241292]]比[[item:241308]]更强，但有一个缺点，它会生成沉默你的虚空区域，这些区域可以通过使用悬空并在看到脚下出现时移动来轻松避开。如果你不想处理这个，那么[[item:241308]]也可以。

3.3.

#### 食物增益

作为一名增辉 唤魔师，你需要使用你能获得的最佳主属性食物。目前这将是[[item:255845]]盛宴。如果盛宴不可用，或者放置了副属性盛宴，你应该使用[[item:242275]]以确保获得主属性增益。

3.4.

#### 强化符文

如果你负担得起，在挑战游戏提供的最难内容时，你应该使用[[item:259085]]。我们不建议在日常刷怪或地下城中经常使用它们，因为它们通常很昂贵，但如果你的钱包允许，你可以期望使用这些获得约1%的伤害输出提升。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审阅
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 修正推荐宝石中的错别字。
- **2026年3月23日：** 从消耗品部分移除茶集。它们不再起作用。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜前赛季更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月8日：** 已针对11.1.5补丁的在线修正更新，更改了最佳附魔和宝石。
- **2025年4月21日：** 已针对11.1.5补丁更新，包含惊魂幻象附魔。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查
- **2024年10月21日：** 已针对11.0.5补丁进行审核
- **2024年9月9日：** 为大秘境添加关于光辉力量之威权的说明。添加迅捷亵渎宝石。
- **2024年9月9日：** 修正拼写错误
- **2024年8月22日：** 修正拼写错误
- **2024年8月22日：** 更新最佳武器油/临时武器附魔的说明
- **2024年8月21日：** 已为《地心之战》上线更新，包含所有新的消耗品和附魔。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为巨龙时代第4赛季审核并重新排版
- **2024年1月19日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 页面已添加。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5版本补丁中使用你的增辉 唤魔师挑战大秘境地下城的技巧和建议。

1.

### 增辉 唤魔师在至暗之夜第2赛季的大秘境中

[增辉 唤魔师](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-guide>) 是一个以辅助为核心的专精，通过为队友提供增益来为团队带来价值。25码的范围可能需要一些适应时间，但职业的其他部分被设计得尽可能简单流畅！

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

在5人内容中，你的大部分增益会自动为你选择正确的目标。例如，[[spell:395152]]总是会命中整个小队，[[spell:409311]]会自动优先选择另外两名伤害输出者，然后才是治疗者或坦克，[[spell:360827]]总是会给坦克。这有助于减轻你的负担，让你专注于钥匙中的敌人。

然而，如果两名伤害输出者都有[[spell:409311]]，自动选择目标的施法可能选择次优目标。理想情况下，你希望先知先觉在两名伤害输出者和你或坦克身上，但自动选择可能会给治疗者。在钥匙中，手动选择[[spell:409311]]以在最优玩家身上最大化持续时间，大约可以获得1%的伤害输出提升。

1.

### 增辉 唤魔师最佳天赋

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫之线反应皮

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫之线反应皮大秘境配装，适用于增辉 唤魔师

我们目前推荐使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫在所有大秘境中，因为它造成明显更多的单体目标伤害，使钥匙明显更快。然而，如果你更喜欢 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长的玩法，它并没有落后太多，尤其是在较低层数的钥匙中。

这个配装选择使用[[spell:412713]]而不是[[spell:404977]]，这提供了更流畅的游戏体验。我们还选择了[[spell:360827]]和[[spell:409329]]。这些天赋现在在范围伤害怪物群中造成可观的伤害，值得投入。

我们同时使用[[spell:459537]]和[[spell:407866]]，因为它们在你的[[spell:403631]]窗口期间提供额外的急速和资源，带来舒适的游戏体验。这两个天赋的表现与选择[[spell:1250914]]和[[spell:410260]]非常相似。因此，你可以根据自己的喜好选择其中一种。

我们的大秘境构筑以通用天赋配置开始，该配置在任何地方都适用。你可以调整职业树中的实用技能点，例如如果你愿意，可以将点数从[[spell:370888]]移到[[spell:372048]]或[[spell:371032]]等其他实用技能上。

**请务必使用"导出天赋"按钮将此构建直接导入到你的游戏中！**

:::talents 大秘境构筑 - 时空守卫
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMzMDAM"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMzMDAM"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKJbpkkIIWeEnmG:WDHaB-CVELHDWuSMNCIWOpQB+whg9lq1dmxRD-AAAA-UAQMECaYKWOIMA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 Threads Reactive Hide

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长之线霸主大秘境配装，适用于增辉 唤魔师

该构筑专注于使用[[spell:412713]]和[[spell:407866]]，并最大化你通过[[spell:403631]]施放所造成的个人伤害。

我们在此构筑中选择[[spell:410784]]以获得轻微的单体DPS提升。由于使用了[[spell:410784]]，你将在所有目标数量下使用[[spell:362969]]而非[[spell:361469]]。你仍然需要使用[[spell:361469]]来消耗[[spell:369939]]。

我们为这个配装选择[[spell:410784]]的另一个原因是它玩起来简单得多，因为在所有情况下它的主要资源生成技能都是瞬发的。与使用[[spell:407814]]相比，你会获得约2%的单体目标伤害输出提升，但范围伤害会减少2%。如果你更想使用[[spell:407814]]，你可以切换过去，并将职业树中[[spell:369909]]的天赋点移到[[spell:376930]]或其他功能点上。

此构筑的潜在伤害输出略低于其
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫对应构筑相比，该构筑的潜在DPS略低，但对队友表现的依赖较小。这意味着它的平均表现可能更好，但当然具体情况因人而异。

**请务必使用"导出天赋"按钮将此构建直接导入到你的游戏中！**

:::talents 大秘境配装 - 鳞长
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzMzyAzsNjxMmBAAAAAAAAmhHYGYM1YmZGAAAAMzMjxMz2YmBmZzYwCsMGGbDgZQshxMYmBDG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzMzyAzsNjxMmBAAAAAAAAmhHYGYM1YmZGAAAAMzMjxMz2YmBmZzYwCsMGGbDgZQshxMYmBDG"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFtZUYYlXPpcKJkkIjWeEnm:WDVV72cB-CVELHWHATMNyoQ54CQss4hD77cqWXDC-AAAA-JSCUg0wscMAIwI-
```

:::

1.

### 增辉 唤魔师输出循环变化

在大秘境中，你将与成群的敌人战斗。增辉在范围伤害方面的玩法调整很少，列在下面。

- 你可以将[[spell:396286]]强化到1级以上的阶段，在所有敌人都进入其范围伤害范围时停止。
- 如果没有天赋[[spell:407814]]，你会在2个及以上目标时使用[[spell:362969]]而不是[[spell:361469]]。
- 你应该在小怪群接近结束时保留[[spell:395152]]，除非你认为坦克拉下一波敌人并聚怪还需要三十秒。
- 你会想在怪物群接近结束时保留[[spell:403631]]，而不是冷却好就用。如果你在一个怪物群即将结束时使用它，你会浪费很多你的顶峰天赋[[spell:1259173]]的持续时间！偶尔，保留几秒以更好地与伤害输出冷却技能同步也是好的，但这不是必需的。目前，由于顶峰天赋的存在，两个英雄天赋仅通过尽可能频繁地使用它就能获得显著的伤害输出提升。

1.

### 功能技能与能力

### 打断、昏迷和阻止

4.1.

#### 打断、昏迷、阻止和其他控制

[[spell:351338]]是你的打断技能，由于路径原因在职业树上总是必点。我们还在增辉树上选择[[spell:371016]]以将冷却时间降低到20秒。

[[spell:396286]]是你的主要循环伤害技能之一，但它也会将所有敌人击飞到空中。对于大多数敌人，这会打断他们的施法。有些敌人落地后会重新施法，但有些不会；这不一致，你需要逐个怪物学习。你经常过度强化[[spell:396286]]或延迟几个公共冷却时间来取消重要法术，以让小队的打断技能冷却完毕并阻止施法。

[[spell:357214]]将敌人击退远离你，这可以让你重新定位敌人或取消他们的施法。击退会打断大多数施法。有些敌人落地后会重新施法，但有些不会；这不一致，你需要逐个怪物学习。

[[spell:368970]]将敌人击飞到空中。对于大多数敌人，这会打断他们当前的施法。大多数敌人落地后会重新施法，但有些不会——这不一致，你需要逐个怪物学习。

[[spell:360806]]是一个出色的单体控制技能，冷却时间为15秒。这算作真正的控制，意味着如果你走过被控制的怪物，它不会让你或你的盟友进入战斗，这使其对跳怪非常有价值；此外，它也可以在紧急情况下用于打断施法或减轻特定一波拉怪的压力。

[[spell:358385]]是一个90秒冷却的范围定身技能。这使用频率不高，但作为备用选择很好，尤其是在灾难情况下，比如坦克死亡时。

[[spell:371032]]使你的[[spell:403631]]昏迷敌人3秒。

[[spell:372048]]是一个2分钟冷却的技能，使对敌人的控制效果持续时间增加50%。这通常与复仇恶魔猎手的符咒配合，长时间控制怪物，或与长时间的范围昏迷配合使用。

[[spell:408543]]是一个非常小众且很少选择的天赋，它使[[spell:358385]]能够昏迷在空中的敌人。这相对难以命中，需要你使用你的其他控制技能之一，如[[spell:396286]]或[[spell:368970]]。在大多数情况下，使用这些法术之一已经阻止了施法，使后续的昏迷变得不必要。

### 团队生存冷却技能

4.2.

#### 团队生存冷却技能

[[spell:409676]]根据你的整个小队在[[spell:403631]]期间造成的伤害，给予他们一个吸收护盾，最多相当于他们生命值的30%。这通常可以吸收即将到来的大量危险技能伤害，让治疗者的生活更轻松。

[[spell:374227]]使你和你的整个队伍受到的范围攻击伤害降低20%。

[[spell:403208]]使你和你的整个队伍的最大生命值提高2%。

[[spell:410643]]是一个小众天赋，使[[spell:360827]]给目标一个小护盾。这通常不被选择，因为在大多数内容中护盾太微不足道了。这有时会在极高层的钥匙中选择，因为队伍中有人需要这个小吸收来在某个机制下存活。

### 辅助增益

4.3.

#### 辅助增益

[[spell:395152]]在激活期间，为队伍中的另外两名伤害输出者提供你主属性的8%。

[[spell:409311]]为拥有该增益的玩家提供3%的暴击几率加成。此外，拥有[[spell:409311]]的玩家还会从[[spell:412774]]获得约3%的伤害和治疗加成。这通常放在你的伤害输出队友身上，因为它对治疗者的效果很小。

[[spell:413984]]根据你的精通为玩家提供全能。这非常强大，因为它不仅贡献了你造成的大量伤害，还因为全能提供伤害减免，所以提高了拥有[[spell:413984]]的玩家的生存能力。

[[spell:403631]]是你的主要冷却技能。这实际上相当于你的伤害输出者在10秒内造成15%的额外伤害。由于我们的顶峰天赋[[spell:1259173]]比同步更重要，我们主要按冷却使用它。在拉怪的尾声保留[[spell:403631]]是值得的，这样可以不浪费[[spell:1259173]]的持续时间，并更好地与伤害输出冷却技能同步（因为它们通常在拉怪开始时使用）。

[[spell:369459]]与[[spell:418101]]一起为你的治疗者提供增益，使他们获得3%的治疗和伤害加成。

[[spell:360827]]为坦克提供你护甲值的20%。这提供的伤害减免量取决于坦克，但对于大多数坦克来说，大约相当于7%的额外物理伤害减免。

### 其他功能

4.4.

#### 其他功能

[[spell:390386]]为你的队伍提供[[spell:80353]]/[[spell:32182]]/[[spell:2825]]效果。这非常强大，大多数队伍都希望至少有一个职业能提供这个。

[[spell:365585]]是你的驱散技能，可以移除所有中毒效果。这在第2赛季中极为有用，因为这些地下城中有大量中毒。此外，这让你可以在期间驱散受到[[spell:440313]]影响的人
[萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>) 周。

[[spell:374251]]是唤魔师最好的功能性法术之一，可以移除目标身上所有的流血、中毒、诅咒和疾病效果。在大秘境中你总是需要带上它。用它来为队友移除重要的减益效果。此外，这让你可以在期间驱散第二个受到[[spell:440313]]影响的人
[萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>) 周。

[[spell:406732]]为你和你的治疗者提供一个增益，将你所有法术的射程提高100%，并让你们都能移动施法。这在特定情况下很有用，可以使一些治疗者在艰难的机制下更容易保住你的生命。

[[spell:374968]]为你的队伍中每个人提供一次额外的主要移动技能使用机会。这比较小众，但坦克通常很欣赏额外的机动性，帮助他们快速聚怪。

1.

### 应对词缀

### 词缀：升腾

5.1.

#### 增辉 唤魔师的升华词缀应对

在 [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>) 周期中，宇宙能量宝珠会定期在你的队伍附近生成。作为一名增辉 唤魔师，你可以使用以下法术来清除这些宝珠：

- [[spell:396286]]
- [[spell:351338]] - 这通常最好用在怪物群中的怪物身上，而不是词缀上。
- [[spell:368970]]
- [[spell:357214]]
- [[spell:403631]]配合[[spell:371032]]。确保同时击中敌方怪物。

### 词缀：虚缚

5.2.

#### 增辉 唤魔师的虚空束缚词缀应对

当虚空束缚词缀生成时，你应该立即切换目标优先击杀它。不值得点出[[spell:368432]]来帮助击杀这些，因为它造成的伤害不够。

### 词缀：脉冲星

5.3.

#### 增辉 唤魔师的脉冲星词缀应对

在 [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>) 通过走入环绕盟友的脉冲星来帮助你的盟友。

### 词缀：吞噬

5.4.

#### 增辉 唤魔师的吞噬词缀应对

在 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>) 准备好使用你的[[spell:365585]]和[[spell:374251]]来移除队友身上的减益效果。需要注意的是，这是 <em>非</em> 一个吸收效果，尽管看起来像减益效果，它只是追踪对目标造成的治疗量。

治疗者通常会治疗掉这个机制，但如果对伤害输出爆发更好，或者减益效果即将到期，用驱散快速移除它们也是好的。如果减益效果到期，附近所有怪物都会被治疗，这非常糟糕。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月15日：** 已更新至12.0.7补丁。为高层钥匙添加了霸主构建。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月19日：** 可能性之尘已从所有时空守卫构建中移除。
- **2026 年 3 月 17 日：** 根据削弱更新天赋构建。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 已针对11.2.7版本审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月8日：** 针对11.1.5补丁的在线修正更新了天赋配装方案。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查
- **2024年10月21日：** 已为11.0.5补丁更新职业天赋树。
- **2024年10月4日：** 根据在线修复更新默认的鳞长大秘境构筑。
- **2024年9月9日：** 已为《地心之战》第1赛季更新。
- **2024年7月23日：** 修正了大秘境天赋树。
- **2024年7月19日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季审核
- **2024年3月19日：** 已针对10.2.6版本进行审阅
- **2024年3月8日：** 在默认大秘境构筑中使用再生甲壳。
- **2024年1月15日：** 已针对10.2.5补丁进行审核
- **2023年11月13日：** 已为在线修复更新
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月9日：** 为本周补丁更新构筑。
- **2023年7月10日：** 页面已添加。

显示更多

显示更少

:::

## 宏与插件

在本页面中，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5版本补丁中使用增辉 唤魔师时更加轻松。

1.

### 最佳宏

1.1.

#### 翡翠之花鼠标悬停

这个宏会在你的鼠标悬停目标上施放[[spell:355913]]；如果他们不是友方目标（或已死亡的友方目标），它会改为对你自己施放。

#### 翡翠之花鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 翡翠之花
```

1.2.

#### 营救鼠标悬停

这个宏会在你的鼠标悬停目标上施放[[spell:370665]]；如果他们不是友方目标（或已死亡的友方目标），它会尝试改为对你的当前目标施放。

#### 营救鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 营救
```

1.3.

#### 青翠之拥鼠标悬停

此宏会对你的鼠标悬停目标施放 [[spell:360995]]；如果目标不是友方目标（或已死亡的友方目标），则改为对自己施放。

#### 青翠之拥鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 青翠之拥
```

1.4.

#### 灼烧之焰鼠标悬停

此宏会对你的鼠标悬停目标施放 [[spell:374251]]；如果目标不是友方目标（或已死亡的友方目标），则改为对自己施放。

#### 灼烧之焰鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 灼烧之焰
```

1.

### 增辉 唤魔师专用宏

2.1.

#### 鼠标悬停施放 先知先觉

此宏会对你的鼠标悬停目标施放 [[spell:409311]]；如果目标不是友方目标（或已死亡的友方目标），则改用 暴风雪 的默认目标选择。

#### 鼠标悬停施放 先知先觉

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 先知先觉
```

2.2.

#### 鼠标悬停施放 炽火龙鳞

此宏会对你的鼠标悬停目标施放 [[spell:360827]]；如果目标不是友方目标（或已死亡的友方目标），则改用 暴风雪 的默认目标选择。

#### 鼠标悬停施放 炽火龙鳞

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 炽火龙鳞
```

2.3.

#### 鼠标悬停施放 空间悖论

此宏会对你的鼠标悬停目标施放 [[spell:406732]]；如果目标不是友方目标（或已死亡的友方目标），则改用 暴风雪 的默认目标选择。

#### 鼠标悬停施放 空间悖论

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 空间悖论
```

2.4.

#### 鼠标悬停赐予维姆斯通

此宏会对你的鼠标悬停目标施放 [[spell:408233]]；如果目标不是友方目标（或已死亡的友方目标），则改用 暴风雪 的默认目标选择。

#### 鼠标悬停赐予维姆斯通

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 赋予军营之石
```

2.5.

#### 随机最爱坐骑青铜协调宏

此宏是召唤随机最爱坐骑快捷键的替代方案，能为其增加一些额外的便利性。如果你希望鼠标提示显示某个坐骑，请将该坐骑添加到 showtooltip 行中。此外，如果你希望它只召唤某个特定坐骑，请将最后一行替换为 /cast 坐骑名称。

此宏会在你按下坐骑快捷键时自动让你进入 [[spell:403265]]，如果你再次按下坐骑快捷键下马，则会将你送回 [[spell:403295]]。

#### 协调坐骑宏

```wow-macro
#showtooltip 
/cast [nostance:2] 青铜协调
/cast [mounted,nostance:1] 黑龙协调
/run C_MountJournal.SummonByID(0)
```

2.6.

#### 非姿态 黑龙协调 宏

如果你当前不处于该姿态，此宏会自动切换回 [[spell:403295]]。这个特定示例是为喷发编写的，但你可以将 黑龙协调 行复制到你的其他宏中，或者更换技能！

这很有用，因为每次你在点了 [[spell:407243]] 天赋的情况下使用 [[spell:358267]] 时，使用 [[spell:358267]] 后你会自动被切换到 [[spell:403265]]。

切换姿态不占用公共冷却时间，不会干扰你的输出循环，而且在切换回来之前有3秒的锁定时间，因此你仍然能充分享受巨龙化身恩惠带来的悬空移动速度加成。

如果你在打旧副本并且希望全程处于 [[spell:403265]] 状态，这个宏可能会有些烦人，但在其他情况下它是不错的便利性提升。

#### 黑龙协调 喷发

```wow-macro
#showtooltip 喷发
/cast [nostance:1] 黑龙协调
/cast 喷发
```

2.7.

#### 上马青铜协调宏

此宏会在你上马时自动让你进入 [[spell:403265]]，为你提供略高的移动速度。如果你通过此宏下马，它也会自动将你送回 [[spell:403295]]。

此宏设置为召唤你收藏的坐骑，如果你想召唤特定坐骑，请将底部的 run 行替换为 /cast 加上该坐骑的名称。你可能还想调整宏顶部的 showtooltip，使其始终显示你收藏的坐骑之一。

#### 召唤收藏坐骑并切换协调宏

```wow-macro
#showtooltip
/cast [nostance:2] 青铜协调
/cast [mounted,nostance:1] 黑龙协调
/run C_MountJournal.SummonByID(0)
```

2.8.

#### 取消光环扭转天平宏

此宏能让你立即取消 [[spell:370553]] 增益效果，使其更快进入冷却。这是一种 DPS 提升， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫，因为该法术在增益效果被消耗之前不会开始冷却。最大化[[spell:370553]]的总施放次数远比快速获得满层强化更重要。不过，你仍然应该在理想情况下在[[spell:357208]]即将在下一个GCD转好时对其使用[[spell:370553]]。

#### 时空守卫取消光环 扭转天平

```wow-macro
#showtooltip
/cast 扭转天平
/cancelaura 扭转天平
```

1.

### 最佳插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

3.1.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

3.2.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

3.2.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

3.2.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

3.2.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

3.3.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

3.3.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

3.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

3.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

3.4.

#### 团队框架插件

3.4.1.

##### Harreks高级团队框架

[Harreks高级团队框架](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>)
是一款高度可定制的插件，能改善团队框架的可用性。此插件支持 暴风雪 团队框架以及流行的团队框架插件。此插件允许你自定义团队框架上增益效果的外观和位置，使你更容易看到谁拥有你的增益效果。如果你有其他问题或需要帮助，可以访问 Harreks 的 discord， [Spiritbloom.Pro](<https://discord.gg/spiritbloompro>).

3.4.2.

##### Xephs Spotlights

[Spotlights](<https://www.curseforge.com/wow/addons/spotlights>)
是一款新的可定制插件，让你能够创建聚光灯式团队框架。你可以自由自定义这些团队框架的外观、配置每个框架显示的增益效果等等，帮助你为增益效果选择正确的目标！如果你有其他问题或需要帮助，可以加入 唤魔师 的 Discord，
[龙息神殿](<https://discord.com/invite/Evoker>).

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 为至暗之夜前赛季更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 已针对 11.2.7 补丁进行审阅
- **2025 年 10 月 5 日：** 修复了一个技能名称中的拼写错误。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行审查
- **2024年12月15日：** 已针对11.0.7补丁进行审查
- **2024年10月21日：** 已针对11.0.5补丁进行审核
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季审核
- **2024年1月19日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 页面已添加。

显示更多

显示更少

:::
