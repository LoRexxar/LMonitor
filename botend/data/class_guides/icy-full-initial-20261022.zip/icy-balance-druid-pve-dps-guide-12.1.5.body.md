## 专精概览

欢迎阅读我们的 平衡 德鲁伊 攻略，适用于《魔兽世界》12.1.5 补丁。在这里，你将学习如何在团队副本和大秘境中扮演 平衡 德鲁伊：从入门到最大化你的输出伤害。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

平衡 大秘境资源

[全新！顶尖 平衡 天赋构建](<https://raider.io/specs/balance-druid/talents>)

[顶尖 平衡 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/druid/balance>)

[平衡 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=druid--balance>)

[热门 平衡 团队组合](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=druid--balance>)

1.

### 平衡 德鲁伊 概述

平衡 专精提供了一套简单却富有回报的输出循环，非常适合新手玩家，同时又保留了一定的深度，让老手和经验丰富的玩家也能保持参与感和竞争力。它在多目标战斗中表现出色，在单体战斗中更是出类拔萃，此外它还拥有其他技能手段和一个团队增益，以弥补其在顺劈和多目标爆发等场景中的不足。

输出循环的另一个主要目标是循环触发日蚀，这是你的主要增益状态。有多个天赋会受到进入或离开日蚀的影响，这激励你尽可能长时间地保持在日蚀状态。

优秀的优先目标伤害

平衡 德鲁伊 在伤害光谱的两端都表现出色。平衡 德鲁伊 目前是一个极度偏混合型的专精，其输出循环中包含大量

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者

和

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

多目标元素，使他们能够适应大多数情况。考虑到它还能造成不错的单体伤害，这使它跻身于在所有 PvE 内容中都表现出色的高端施法者职业之列。

爆发优秀，持续输出稍弱

平衡 德鲁伊 是各技术水平下远程输出位置的强有力竞争者。它拥有灵活的主要和次要冷却技能，可以持续输出伤害，也可以积攒资源为优先目标或易伤窗口打出更好的爆发。此外，在团队战斗中适用的情况下，平衡 德鲁伊 确实能填补分散多目标输出的角色。它通常不是整体最佳的远程选择，但在几场更具挑战性的战斗中确实能提供宝贵伤害。

无上限多目标

平衡 德鲁伊 在大秘境钥石中伤害表现出色，并在 Boss 之间的清理小怪阶段大放异彩。它能造成极高的输出，同时还能提供

[[spell:78675]]

以及各种击退和控怪能力。它还可以

[[spell:2908]]

以及驱散，并施放

[[spell:1126]]

，这是最强的职业增益之一。当前的构建在单体战斗中也很灵活，因为两个构建之间共用了许多相同天赋。

多样的工具箱

平衡 德鲁伊 拥有种类繁多的实用法术。他们还有许多天赋可以改变或强化这些实用法术。他们拥有

[[spell:106898]]

用于机动性，以及击退、定身、净化和

[[spell:2908]]

。这些法术在所有类型的内容中都能找到用武之地。

中等生存能力

平衡 德鲁伊确实有一些手段来提高他们的生存能力。

[[spell:5487]]

始终可用以提高生命值，通常最好用于承受大伤害。

[[spell:22812]]

还提供了一个低冷却时间的减伤效果，在一场战斗中可以使用多次。它最缺乏的是被动生存能力以及免疫或免死手段。它并不需要这些，但从一个拥有部分此类工具的职业切换到 平衡 德鲁伊 时，差别是显而易见的。

高机动性

平衡 德鲁伊 拥有出色的机动性选择。它拥有团队实用技能

[[spell:106898]]

以及基础的

[[spell:1850]]

。它还拥有被动移动天赋和灵狐守护。虽然它确实拥有出色的机动性，但在长距离移动时维持输出循环仍然很困难，如果可能的话，通常最好缩短奔跑时间，而不是施放次优法术。

1.

### 平衡 德鲁伊 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5补丁对德鲁伊或平衡德鲁伊专精没有实质性改动。该补丁的主要重点是2项新的终局内容，一项面向团队副本队伍，另一项面向 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。请务必查看关于新的基斯提克斯团队副本战斗的信息，以及令人兴奋的全新迷宫巨型地下堡！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

主要改动将来自基斯提克斯团队副本战斗的新物品。最值得注意的是一个饰品、一个戒指和一件胸甲。此外，你将能够从 10 月 20 日起使用[[item:280562]]升级物品。武器、项链和饰品都可以升级。

2.3.

#### 职业改动

12.1.5 补丁中 平衡 德鲁伊 专精没有任何改动，但我们网站上的通用和团队副本装备推荐将会更新，
[装备](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>) 页面。我们还提供了一份高价值物品清单，供你决定如何花费你的第一批[[item:280562]]。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_moonglow.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1版本职业平衡调整 隐藏12.1版本职业平衡调整
[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**平衡 德鲁伊**

<em>开发者笔记：我们在 乌拉特克 的诅咒中对 平衡 的目标是强调其积蓄、消耗和囤积星界能量的核心玩法。在 至暗之夜 中，平衡 的星界能量生成很高，并且有很多免费的消耗技能触发，这意味着在施放消耗技能后没有多少公共冷却时间可用。在 乌拉特克 的诅咒中，我们降低了星界能量的生成和免费消耗技能的数量，但提高了每个消耗技能造成的伤害。意图是提供更多时间来对星界能量的获取做出反应，并使在日蚀外囤积星界能量、在日蚀内消耗更有影响力。我们还调整了一些天赋强度以增加构筑的多样性。</em>

- **职业**
  
  
  
  
  - [[spell:385786]] 吸收量提高 25%。
  - [[spell:319454]] 强化的[[spell:48438]]治疗量提高 25%。
- **英雄天赋**
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者：星涌不再由愤怒获取星界能量触发。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者：星涌有 30% 的几率发射一道效果为 50% 的星涌术（原为 40% 几率，效果为 70%）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者：繁盛绽放现在使自然之力树人的持续时间延长 4 秒，而不是召唤第四个树人。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者：塞纳留斯之力的急速加成降低至 6%（原为 8%）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者：强力附魔的急速加成降低至 6%（原为 10%）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者：林地召唤的树妖的星辰坠落伤害提高至 250% 效果（原为 200%）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者：林地之魂使星辰坠落伤害提高 18%（原为 12%）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者：梦境爆发伤害提高 30%。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者：自然之力使你的树人近战伤害提高 300%（原为 200%）。
- **平衡**
  
  
  
  
  - 造成的伤害提高 8%。
  - 巅峰天赋：[[spell:1261565]]（2 级）已更新 – 星界余烬伤害降低至暴击伤害的 10%/20%（原为 12%/24%），持续时间延长至 8 秒（原为 6 秒）。
  - 巅峰天赋：[[spell:1261566]]（3 级）– 阳炎箭头伤害提高 27%，月神箭头伤害提高 10%。
  - [[spell:383195]] 已更新 – 现在始终使愤怒和星火术伤害提高 12%。
  - [[spell:1240188]] 和 [[spell:202359]] 在天赋树中互换了位置。雕琢星辰使日蚀冷却时间缩短 3 秒（原为 2 秒）。
  - [[spell:450212]] 现在仅作用于 1 个目标。
  - [[spell:8921]] 伤害提高 5%。
  - [[spell:93402]] 伤害提高 5%。
  - [[spell:5176]] 伤害提高 10%。
  - [[spell:194153]] 伤害提高 20%。
  - [[spell:78674]] 伤害提高 71%。
  - [[spell:191034]] 伤害提高 4%。
  - [[spell:202342]] 伤害提高 10%。
  - [[spell:1240907]] 伤害提高 15%。
  - [[spell:1240185]] 使月火术、阳炎术和坠星的伤害提高 10%（原为 8%）。
  - [[spell:383197]] 效果降低至 50%（原为 60%）。
  - [[spell:394414]] 由愤怒触发的几率降低至 12%（原为 15%），由星火术触发的几率降低至 15%（原为 20%）。
  - [[spell:1240206]] 触发几率提高至 15%/30%（原为 10%/20%）。
  - [[spell:774]] 治疗量提高 25%。
  - [[spell:48438]] 治疗量提高 25%。
  - [[spell:8936]] 治疗量提高 25%。

:::

:::

### 至暗之夜改动概述

2.4.

#### 平衡 德鲁伊 专精与攻略在 至暗之夜 上线时的改动

至暗之夜 为游戏带来了许多改动，包括职业改动。平衡 德鲁伊 将可以使用三个新的英雄天赋，分别对应 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者，但最重要的是，我们将迎来全新的日蚀系统。这一改动旨在减少当你需要输出伤害时进入日蚀所需的时间。

2.5.

#### 日蚀重做

日蚀已被重新设计。它不再需要施放两次相反类型的填充技能来进入日蚀。现在，它是一个法术，会根据你最后施放的法术使你进入相应的日蚀。如果你施放[[spell:5176]]，你将进入日光日蚀；如果你施放[[spell:194153]]，你将进入月光日蚀。日蚀仍将提供与其之前相同的增益和属性。将会有新的天赋与这个日蚀系统互动，稍后将进行讨论。

2.6.

#### 平衡 德鲁伊 巅峰天赋

至暗之夜 为每个职业引入了三个新的巅峰天赋，这些天赋将在你升到满级时获得。平衡 德鲁伊 的巅峰天赋组名为升腾日蚀。

1. [[spell:1261564]] – 激活日蚀会使你的下一个[[spell:5176]]或[[spell:194153]]变为瞬发。你在每个日蚀期间施放的前三个[[spell:78674]]或[[spell:191034]]造成的伤害提高 20%。
2. [[spell:1261565]] – 你在日蚀期间造成的暴击会使受害者在 8 秒内额外承受所造成伤害 20% 的持续伤害。
3. [[spell:1261566]] – 激活日蚀还会向 40 码内的敌人发射必定暴击的阳炎箭头或月神箭头。[[spell:1261573]]命中一个目标，[[spell:1263137]]命中三个目标并造成溅射伤害。

这些天赋本质上是被动的，通常不需要围绕它们进行操作，也不会以任何有意义的方式与工具箱的其他部分互动。瞬发填充技能以及多目标的一些爆发潜力确实有一些切实的好处，但你通常不会为了这些天赋而改变你的输出循环。

1.

### 平衡 德鲁伊 玩法基础

平衡 德鲁伊 是一个利用日蚀和星界能量两大主要系统的专精。日蚀是你输出伤害的主要手段。它根据你所处的日蚀类型增益你的法术伤害和施法速度。你可以选择进入日光日蚀以造成更多单体伤害，或进入月光日蚀以造成更多多目标伤害。

你的几乎所有法术都会生成星界能量，要么直接通过造成伤害，要么通过你的部分持续伤害效果。你应始终在任何可行的目标身上保持你的持续伤害效果，并尽力不断施放法术以维持星界能量的生成。当你有足够的星界能量时，你可以选择将其用于单体的[[spell:78674]]或多目标的[[spell:191034]]。

你应始终点出你的主要冷却技能[[spell:194223]]，这将使你同时获得两种日蚀状态，让你可以在造成更高伤害的同时施放合适的法术。平衡 德鲁伊 的主要原则简要概述见下方列表。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_moonglow.jpg>) **积攒你的星界能量**
  
  
  
  
  你的许多法术都会生成你的主要资源——星界能量。你可以将星界能量用于[[spell:78674]]和[[spell:191034]]，造成巨额伤害。你应始终积攒这个资源，且永远不要让资源溢出。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_eclipseorange.jpg>) **保持高日蚀覆盖率**
  
  
  
  
  日蚀是平衡 德鲁伊的主要增益。你应尽可能长时间地处于日蚀状态。当你不在日蚀状态时，你想通过施放[[spell:8921]]和[[spell:93402]]并积攒星界能量来为下一个日蚀做准备。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_natureguardian.jpg>) **管理你的冷却技能**
  
  
  
  
  平衡 德鲁伊 很早就能获得其主要冷却技能[[spell:194223]]。这个冷却技能通过[[spell:468743]]多次强化，有时也通过[[spell:394013]]强化。你应将冷却技能叠加使用，例如[[spell:391528]]、[[spell:205636]]或[[spell:202770]]，以叠加它们的收益，并在需要时造成大量爆发伤害。

1.

### 作为 平衡 德鲁伊 如何获取装备

虽然我们始终建议您自行使用模拟器以获得最佳结果，但我们确实提供了一个专门的 平衡 配装页面。目前我们涵盖了第二赛季装备的推荐，以便在 至暗之夜 终局内容发布时有个良好的开端。在您获得一些装备后，您需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 12.1.5 补丁更新
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔推荐。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 已针对 12.1.5 补丁更新
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 更新了专业制造和美化部分。
- **2026 年 8 月 17 日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 更新了消耗品推荐。
- **2026 年 8 月 17 日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对艾露恩之选属性偏好更新。
- **2026 年 8 月 17 日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对艾露恩之选属性偏好更新。
- **2026年8月12日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 修复了流星风暴推荐。
- **2026年8月12日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 更新了星界强化相关说明。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 更新了最佳天赋推荐。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 12.1.0 补丁更新
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 12.1.0 补丁更新
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对 12.1.0 补丁更新
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对 12.1.0 补丁进行审阅
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 12.1.0 补丁更新
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对 12.1.0 补丁进行审阅
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 12.1.0 补丁更新
- **2026年8月10日（本页）：** 已针对 12.1 补丁更新
- **2026 年 6 月 30 日（本页）：** 已针对 6月30日的职业平衡调整更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对孢子坠落发布更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 添加了野性之心宏。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 更新了戒指附魔推荐。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 更新了属性优先级推荐。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 重新排版了机制与技巧部分。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 添加了万世典籍天赋推荐。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 更新了野性之心条目。
- **2026年6月15日（本页）：** 已为10.0.7补丁更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月23日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已更新饰品推荐。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 移除了茶的提及，并为第三属性添加了说明。
- **2026年3月23日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 更新了天赋推荐。
- **2026年3月23日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 在常见问题板块中添加了关于输出循环的说明，并进一步扩展了游戏机制内容。
- **2026年3月23日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 更新了天赋推荐
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 更新了输出循环，移除了织星者的提及。
- **2026年3月17日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 更新了天赋推荐
- **2026年3月17日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 更新了天赋推荐
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年3月16日（本页面）：** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 至暗之夜 发布进行审阅和更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 至暗之夜 发布进行审阅和更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 至暗之夜 发布进行审阅和更新。
- **2026年2月26日（本页）：** 已针对 至暗之夜 发布进行审阅和更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对 至暗之夜 前瞻补丁更新
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对 至暗之夜 前瞻补丁更新
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对 至暗之夜 前瞻补丁更新
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 至暗之夜 前瞻补丁更新
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对 至暗之夜 前瞻补丁更新
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对 至暗之夜 前瞻补丁更新
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 至暗之夜 前瞻补丁更新
- **2026年2月10日（本页面）：** 已针对 至暗之夜 前瞻补丁进行审阅
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 添加了常见问题板块。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 添加了常见问题板块。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 已针对 11.2.7 补丁进行审阅
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对谜之财团代币发布和 D.I.S.C 削弱更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 11.2.5 补丁进行审阅
- **2025年10月5日（本页）：** 已针对 11.2.5 补丁进行审阅
- **2025年8月30日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 添加了配合新套装的守墓者起手手法。
- **2025年8月11日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对套装改动和饰品模拟更新。
- **2025年8月11日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对套装变动和增益更新。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 11.2.0 补丁进行审阅
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 11.2.0 补丁进行审阅
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对 11.2.0 补丁进行审阅
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对 11.2.0 补丁进行审阅
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 11.2.0 补丁进行审阅
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对 11.2.0 补丁进行审阅
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 11.2.0 补丁进行审阅
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 11.2.0 补丁进行审阅
- **2025年8月4日（本页面）：** 已针对 11.2.0 补丁进行审阅
- **2025年6月21日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对充能箭矢削弱更新。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 11.1.7 补丁进行审阅
- **2025年6月15日（本页）：** 已针对 11.1.7 补丁进行审阅
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对 11.1.5 补丁进行审阅和更新
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 11.1.5 补丁进行审阅和更新
- **2025年4月21日（本页）：** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年3月16日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 添加了一些额外的饰品说明。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了前4个史诗团本首领的攻略提示。
- **2025年3月3日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 更新了地心之战解放和第二赛季的毕业装备列表。
- **2025年3月3日（[解放安德迈页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了地心之战解放普通和英雄难度的团本提示。
- **2025年2月27日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 11.1.0 补丁进行审阅和更新。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 11.0.1 补丁进行审阅和更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 11.0.1 补丁进行审阅和更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对 11.1.0 补丁进行审阅。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对 11.0.1 补丁进行审阅和更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对 11.0.1 补丁进行审阅和更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 11.0.1 补丁进行审阅和更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对 11.0.1 补丁进行审阅和更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 11.0.1 补丁进行审阅和更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对 11.0.1 补丁进行审阅和更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 11.1.0 补丁进行审阅和更新。
- **2025年2月24日（本页面）：** 已针对 11.0.1 补丁进行审阅和更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 11.0.7 版本瑟尔赛的头环发布更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（本页）：** 已针对11.0.7补丁进行审查。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 11.0.5 补丁天赋重做更新。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 11.0.5 补丁天赋重做更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 11.0.5 补丁天赋重做更新。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（本页）：** 针对11.0.5补丁进行了审阅。
- **2024年10月7日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 更新了团本饰品推荐。
- **2024年10月7日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 更新了一些消耗品推荐。
- **2024年10月7日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 与其他属性提及保持一致。
- **2024年10月7日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 添加了额外的词缀说明。
- **2024年10月7日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 更新了一些天赋推荐。
- **2024年10月7日（本页）：** 更新了一些天赋推荐。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对第一赛季进行审阅。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对第1赛季更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对第一赛季进行审阅。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对第一赛季进行审阅。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对第一赛季进行审阅。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对第一赛季进行审阅。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对第1赛季更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对第一赛季进行审阅。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对第1赛季更新。
- **2024年9月9日（本页）：** 已针对第一赛季进行审阅。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/balance-druid-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年7月19日（[地心之战](<https://www.icy-veins.com/wow/balance-druid-the-war-within-pve-guide>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月19日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已更新至《地心之战》前夕补丁。
- **2024年6月18日（[地心之战](<https://www.icy-veins.com/wow/balance-druid-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/balance-druid-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对巨龙时代第四赛季的新套装更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 为第4赛季进行了更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（本页）：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月25日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 10.2.6 补丁进行审阅。更新了对蓝色丝质亚麻布的提及。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 10.2.6 补丁进行审阅。调整了天赋推荐。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年12月8日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 更新了一些与灾祸之枝相关的饰品推荐。
- **2023年12月8日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 更新了撼星之力增益的提及。
- **2023年11月9日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 修复了职业天赋选择树。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对最近的孢子披风削弱更新。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 10.2.0 补丁更新。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 10.2.0 补丁更新。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对 10.2.0 补丁更新。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对 10.2.0 补丁更新。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 10.2.0 补丁更新。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 10.2.0 补丁更新。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对 10.2.0 补丁更新。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 10.2.0 补丁更新。
- **2023年11月6日（本页）：** 已针对 10.2.0 补丁更新。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已为10.1.7版本审核。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已为10.1.7版本审核。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已为10.1.7版本审核。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为10.1.7版本审核。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对10.1.7补丁更新
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已为10.1.7版本审核。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已为10.1.7版本审核。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月8日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对 5月9日的在线修复更新。
- **2023年5月8日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 5月9日的补丁改动更新。
- **2023年5月8日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 新史诗钥石地下城赛季开启。
- **2023年5月8日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对 5月9日的在线修复更新。
- **2023年5月8日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 5月9日的在线修复更新。
- **2023年5月8日（本页）：** 5月9日的 平衡 德鲁伊 改动。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 将原初石英推荐移至页面底部。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 10.1.0 补丁无需更改。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 10.1.0 补丁中的新天赋更新。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（本页）：** 为10.1.0补丁进行了更新。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/balance-druid-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 10.0.7 补丁进行审阅。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 更新了药剂推荐和原初石英。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 更新了一些配装，并阐明了织星者和撼星之力的可行性。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 更新了部分章节以保持一致性。已针对10.0.7补丁进行审阅。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已为10.0.7补丁更新。
- **2023年3月20日（本页）：** 已针对10.0.7补丁进行审核。
- **2023年1月28日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 修复了失效的天赋链接。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（本页）：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月21日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 更新了美化装备并扩展了饰品推荐。
- **2022年12月21日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 添加了项链消耗品的说明。
- **2022年12月21日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 添加了关于轨道打击和脉冲星的一些说明。
- **2022年12月21日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 更新了织星者与撼星之力的对比。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已针对化身密库和第一赛季史诗钥石更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 更新了个人食物选择。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已针对化身密库和第一赛季史诗钥石更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 添加了珠宝和物品等级的说明。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对T29套装进行更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 修复了失效的天赋链接。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 更新了天赋选择和一些基本信息。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年11月15日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 更新了天赋推荐。
- **2022年11月15日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 更新了天赋推荐。
- **2022年11月15日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 更新了天赋推荐。
- **2022年11月15日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 更新了天赋推荐。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/balance-druid-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/balance-druid-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/balance-druid-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年7月30日（[9.2版本分析](<https://www.icy-veins.com/wow/balance-druid-patch-9-2-changes-analysis>)):** 已更新以反映9.2.5版本的增强。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/balance-druid-patch-9-2-changes-analysis>)):** 本页已审核并批准用于9.2补丁。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/balance-druid-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/balance-druid-patch-9-1-changes-analysis>)):** 针对9.1.5补丁更新。
- **2021年5月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/balance-druid-patch-9-1-changes-analysis>)):** 页面已创建。
- **2020年10月17日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-ny-alotha-raid-guide>)):** 更新了精华推荐。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年11月6日（[永恒宫殿页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** 更新了一些章节，并新增了关于主要精华选择的章节。
- **2019年8月26日（[永恒宫殿页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** 新增了史诗难度扎库尔和艾萨拉女王。
- **2019年7月29日（[永恒宫殿页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** 为前六个首领添加了史诗难度说明。
- **2019年7月16日（[永恒宫殿页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** 为艾萨拉女王添加了提示。
- **2019年7月16日（[永恒宫殿页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** 更改了一些精华推荐。
- **2019年7月10日（[永恒宫殿页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** 为前7个首领添加了提示。
- **2019年7月7日（[永恒宫殿页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-crucible-of-storms-raid-guide>)):** 新增了史诗难度。
- **2019年6月23日（[奥杜尔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** 本页面已经过审核，在8.2版本发布时无需更改。
- **2019年6月23日（[达萨罗之战页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审核，在8.2版本发布时无需更改。
- **2019年5月12日（[达萨罗之战页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更改了一些天赋推荐。
- **2019年4月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-crucible-of-storms-raid-guide>)):** 为英雄难度及以下添加了提示。
- **2019年4月16日（[奥杜尔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月16日（[达萨罗之战页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月16日（[风暴熔渣页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-crucible-of-storms-raid-guide>)):** 页面已添加。
- **2019年3月26日（[达萨罗之战页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了史诗难度麦卡贡。
- **2019年3月13日（[达萨罗之战页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 完成了史诗难度章节。
- **2019年2月7日（[达萨罗之战页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 修复了一些错误，并添加了一些史诗难度条目。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2019年1月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** 更新了一些天赋推荐。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** 针对8.1补丁进行了更新。
- **2018年10月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** 新增了史诗难度章节。
- **2018年10月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** 更新了天赋推荐。
- **2018年9月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** 添加了天赋。
- **2018年8月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** 添加页面。

显示更多

显示更少

:::

## 练级

在本页面中，你将找到我们的逐级 平衡 德鲁伊 升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[德鲁伊 升级指南](<https://www.icy-veins.com/wow/druid-leveling-guide>).

1.

### 德鲁伊 平衡练级指南——至暗之夜

总体而言，德鲁伊职业是一个非常出色的升级职业，它提供了多种不同的游戏风格，也是唯一一个能让你体验游戏中所有风格的职业。野性适合近战，平衡适合施法者，守护适合坦克，恢复适合治疗。平衡 德鲁伊拥有自己独特而有趣的游戏特色，我希望你在升级过程中也能享受到这些乐趣！

平衡 德鲁伊升级最大的优势在于其强大的技能组合，并且随着等级提升还会不断增强。凭借像[[spell:8921]]这样的瞬发DoT技能、无限目标的AoE（范围效果）消耗技能[[spell:191034]]，以及最终45码的施法距离，它是一个出色的引怪职业。你可以从远处快速击中怪物并将它们聚集在一起，从而快速高效地将其击杀。

作为平衡 德鲁伊，你可以轻松地治疗自己并控制敌人。一旦你掌握了诸如[[spell:132469]]和[[spell:102793]]之类的技能，你就能更轻松地拉到大量怪物，并在安全施法的同时将它们控制在远离你的位置。

在野外或地下城升级时，平衡 德鲁伊使用的是非常基础的产生-消耗循环优先级。基本思路是在持续15秒的[[spell:1239669]]之间循环。对目标施加你的DoT技能（[[spell:8921]]和[[spell:93402]]），并施放与日月之蚀状态相对应的填充技能（日蚀时使用[[spell:190984]]，月蚀时使用[[spell:194153]]）。当有足够的星界能量时，你可以施放消耗技能（单目标使用[[spell:78674]]，多目标使用[[spell:191034]]）。

以下是指南中一些短语的解释，可能有助于您更好地理解信息。

- DoT指的是持续伤害法术，例如[[spell:8921]]和[[spell:93402]]。
- 填充技能指的是产生你主要资源（即星界能量）的法术。当没有其他事情可做时，应该始终施放填充技能。我们的填充技能是[[spell:190984]]和[[spell:194153]]。
- 消耗技能是指消耗我们主要资源的技能。这些是造成伤害至关重要的强大技能。[[spell:78674]]用于单个或优先目标，[[spell:191034]]用于多个目标。

平衡 德鲁伊的所有冷却技能均来自天赋树。[[spell:194223]]是你的大型冷却技能，它同时提供[[spell:1239669]]两种状态的效果，让你可以随意施放法术，并强化你所有的法术。在单目标情况下，你仍然施放[[spell:190984]]，而在多目标情况下，你应该施放[[spell:194153]]。

另外提醒一点，拉怪结束后别忘了使用[[spell:1231418]]来恢复生命值，这比自己治疗要快得多。

1.1.

#### 升级装备选择

升级时，物品等级总是比单项属性更重要。始终选择物品等级最高的装备。带有速度副属性的物品可以帮助加快你的升级速度，尤其是在长时间室内活动期间。传家宝装备在升级时也很有用，可以让你在升级旅程的大部分时间里忽略大量配装需求。

1.2.

#### 至暗之夜升级实用消耗品

随着升级，你可能想访问拍卖行，根据你所进行的内容类型寻找合适等级的食物、药水和合剂。消耗品可以显著加快升级过程。

你可能还希望购买[[item:132516]]以便快速穿越新大陆的长距离，以及[[item:109076]]来抵消坠落伤害或从山上跳下。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 平衡 德鲁伊 80级 至暗之夜 升级
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmFmZmZDYMmZZsNjZmNWmxYMYDDAGgttxCmmZWGAAAAsxMzMD2MwYAYmBAGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmFmZmZDGjxMLjtZMzsxyMGjZmZDDAGgttxCmmZWGAAAAsxMzMD2MGGzAYmBAGA"
}
```
:::

:::details 来源计算器编码
```
#mB-nLLPO0NUJtaWA86QMehjllqYbztK86X5yxR-UWDfaBITak4QMZYAGqgh5lhpwTxRutO-AAAA-JSAUphZ5AJowAD-
```

:::

2.1.

#### 升级用战争模式天赋

在本章节中，我们将列出最适合练级以及进行单人/小队PvE内容的PvP天赋。请注意，这些在实际PvP情况下可能并非最优选择。

- [[spell:356517]]是一个被动效果，在[[spell:191034]]期间会召唤坠落的流星击中敌人。碰到这些流星的敌人会受到伤害并被击飞。盟友可以拾起这些流星并撞向敌人来引爆它们。
- [[spell:209740]]在团队战斗中表现出色，对单人内容也很强力。它可以强化你队伍中的所有成员，帮助更快地完成任务和击杀稀有怪物。我们推荐在所有团队内容中使用它。
- [[spell:305497]]可以在野外内容中提供少量的控制或伤害。
- [[spell:236147]]能让你即使在战斗中也能以100%移动速度移动。非常适合野外内容。

1.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–9：**由于平衡要到10级才能作为天赋专精解锁，在你获得该选项之前，你应该使用新手任务中提供给你的技能。

1. **等级 10 起：**进入[[spell:24858]]形态，并始终保持此形态。
2. 施放[[spell:205636]]来吸引仇恨并伤害怪物。
3. **等级 2 起：**对目标施加[[spell:8921]]。
4. **等级 10 起：**对目标施加[[spell:93402]]。
5. **等级 27 起：**施放 [[spell:194223]]，冷却好就用。
6. **等级 55 起：** 在爆发期间施放 [[spell:391528]]。
7. **等级 11 起：**如果 [[spell:194223]] 正在冷却，则施放 [[spell:1239669]]。在单目标时施放 [[spell:190984]] 以激活日蚀，在多目标时施放 [[spell:194153]] 以进入月蚀。
8. **等级 10 起：**在单目标且处于 [[spell:1239669]] 期间，可用时施放 [[spell:78674]]。
9. **等级 10 起：**对多个目标施放 [[spell:191034]]。
10. **等级 10 起：**在 [[spell:1239669]] 期间，使用 [[spell:190984]] 或 [[spell:194153]] 作为填充技能来积攒星界能量。

当你点了任何爆发技能，例如 [[spell:205636]] 或 [[spell:391528]]，你应该在它们冷却好时就使用。在升级过程中，大多数敌人不会构成太大威胁，战斗也不会持续太久。在升级时使用这些爆发技能来加快节奏。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已针对 12.1.0 补丁更新
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年2月26日：** 已针对 至暗之夜 发布进行审阅和更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月4日：** 已针对 11.2.0 补丁进行审阅
- **2025年6月15日：** 已针对 11.1.7 补丁进行审阅
- **2025年4月21日：** 已针对 11.1.5 补丁进行更新和审阅。
- **2025年2月27日：** 已针对 11.1.0 补丁进行审阅和更新。
- **2025 年 2 月 24 日：** 已针对 11.0.1 补丁进行审阅和更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对 11.0.5 补丁天赋重做更新。
- **2024年9月9日：** 已针对第一赛季进行审阅。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月25日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月9日：** 修复了职业天赋选择树。
- **2023年11月6日：** 已针对 10.2.0 补丁更新。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月8日：** 已针对 5月9日的在线修复更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月28日：** 修复了失效的天赋链接。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5 补丁中轻松游玩 平衡 德鲁伊，使用最简单的循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 平衡 德鲁伊 基础

本页面面向刚接触游戏或该职业的玩家，他们没有进行史诗难度团队副本的打算，或者只是想要一种更直接的方式来游玩自己的专精，而不会被大量需要考虑的细节和主动技能所淹没。

平衡 德鲁伊 有单目标和多目标循环，两者都要求良好的持续伤害技能覆盖率以及正确地积攒和消耗星界能量。爆发技能应在可用时使用。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_moonglow.jpg>) **积攒你的星界能量**
  
  
  
  
  你的许多法术会产生主要资源——星界能量。你可以将星界能量用于 [[spell:78674]] 和 [[spell:191034]]，造成大量伤害。你始终要积攒这个资源，且绝不要让资源溢出。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_eclipseorange.jpg>) **保持高日蚀覆盖率**
  
  
  
  
  日蚀是平衡 德鲁伊的主要增益。你应尽可能长时间地处于日蚀状态。当你不在日蚀状态时，你想通过施放[[spell:8921]]和[[spell:93402]]并积攒星界能量来为下一个日蚀做准备。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_natureguardian.jpg>) **管理你的冷却技能**
  
  
  
  
  平衡 德鲁伊 很早就能获得其主要冷却技能[[spell:194223]]。这个冷却技能通过[[spell:468743]]多次强化，有时也通过[[spell:394013]]强化。你应将冷却技能叠加使用，例如[[spell:391528]]、[[spell:205636]]或[[spell:202770]]，以叠加它们的收益，并在需要时造成大量爆发伤害。

1.

### 平衡 德鲁伊 新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者 单目标天赋

2.1.

#### 平衡 德鲁伊 新手单目标天赋

根据当前的数值调整， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者 之间的差距在 2% 以内。此构筑在单目标情况下是最优的。

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmlZmZmBYwyMbzYGzMbsMjZGjZ2wAgBYbbsgpZmlBAAAAbmZmZGsZMMmBwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04YZbpBUYEJpzTdFWebjM1NWG-UWaDJXfHNSmADFQYYo4gh15lh5JnYxR-AAAA-FGQYcgkQpBYQmF-
```

:::

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 多目标天赋

2.2.

#### 平衡 德鲁伊 新手多目标天赋

这是我们推荐的群体伤害场景构筑。它在团队副本的群体伤害战斗以及大多数大秘境中都表现出色。

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmlZmZmBYYMzyMbmZmZhlZWGjxYDDAGbLzMYMbDgJAAAALmZmZGsZMMGAAmZwyA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04YZbpBUYEJpzTdFWebjM1NWG-UWaBDHfEKNSmwwAJZY44lh5RFOxCIDXA-AAAA-GKOik0AMggBDxC-
```

:::

**你将 <em>非</em> 在游玩时能够进入太阳 [[spell:1239669]] ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 归功于[[spell:429523]]。**

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

### 平衡 德鲁伊 基础循环

2.3.

#### 平衡 德鲁伊 新手输出循环

德鲁伊 平衡拥有基于日月之蚀循环的游戏机制。在单体至三个目标时进入日蚀，四个及以上目标时进入月蚀。在日蚀期间施放[[spell:5176]]，在月蚀期间施放[[spell:194153]]。唯一的例外是你使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 中你将始终使用 [[spell:194153]] 作为填充技能。

保持你的持续伤害技能不断是产生星界能量并造成额外被动伤害的关键。[[spell:93402]]可以很容易地扩散到主目标周围的所有目标，而[[spell:8921]]在拥有[[spell:279620]]时每次施放可以额外溅射一个单位。

在单体目标战斗中，你会在冷却技能可用时使用它们，或者在可以叠加多个冷却技能时使用。你将使用[[spell:78674]]作为消耗星界能量的方式。在多目标战斗中，你会改为使用[[spell:191034]]作为消耗星界能量的主要方式。

一旦你的持续伤害效果生效并开始产生星界能量，你将有其他一些冷却技能可以利用。以下天赋是从天赋树中选择的，可能并不总是适用于特定的战斗。

- [[spell:194223]]是你的主要冷却技能，可以通过[[spell:390378]]进一步强化。这会使你同时获得[[spell:1239669]]两种状态的效果，强化特定类型的伤害。
- [[spell:391528]]是一个强大的冷却技能，在4秒内施放16个法术。这能造成不错的单体伤害，但在多目标战斗中同样有用。
- [[spell:202770]]和[[spell:274281]]是天赋树中常见的选择。狂怒艾露恩通常被选择以提升星界能量的产生。
- [[spell:205636]]在点出天赋后是一个强大的冷却技能
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者。它会触发 [[spell:433831]] 和其他被动伤害加成，并且可以与其他冷却技能叠加使用，例如 [[spell:194223]]。

还有更多法术可以选择，但这些是大多数情况下都会选择的法术。

2.3.1.

##### 功能性法术

平衡 德鲁伊 能为团队带来许多增益和功能性法术。除了能够治疗他人之外，我们还有许多标志性的法术，以独特的方式帮助我们和队友。

平衡 德鲁伊拥有多种位移法术。[[spell:132469]] 用于击退敌人。[[spell:102793]] 和 [[spell:102359]]，以及 [[spell:339]] 可以将敌人固定在原地。曾经有整场首领战和机制都是围绕这些能力的协同运用来设计的。

平衡 德鲁伊 还有其他方式来帮助团队。[[spell:106898]] 在你施放该法术时会提高你和周围队友的移动速度。如果你处于小队中，[[spell:29166]] 是帮助治疗者节省法力的绝佳法术。

2.3.2.

##### 平衡 德鲁伊 套装加成

第2赛季 至暗之夜 套装围绕日月之蚀展开。2件套为 [[spell:78674]] 提供固定的伤害加成，并通过对符合条件的目标额外进行一次瞬时结算来为 [[spell:191034]] 提供额外伤害。

4件套在日月之蚀期间提供一个此消彼长的伤害增益，当通过使用冷却技能或 [[spell:1240206]] 同时处于两种日月之蚀状态时，该增益会进一步提高。这意味着我们希望在早期叠加 [[spell:202345]] 以获得急速，然后尽可能囤积资源，以在伤害增益达到峰值时使用。

从机制上看，该套装在游戏风格上没有太大差异，但它进一步强调了早消耗、晚囤积的游戏风格，这种风格在 至暗之夜 中对 平衡 德鲁伊来说一直很流行。

### 平衡 德鲁伊 防御法术

2.4.

#### 平衡 德鲁伊 的防御法术

[[spell:22812]] 是你的主要防御资源。这是一个冷却时间短、减伤幅度低的法术，通常在你需要它的大部分时间里都是可用的。在职业天赋树中，还有几个其他被动技能可以增强树皮术，但最值得注意的是 [[spell:449191]]，它能进一步提高减伤效果。

[[spell:5487]] 是我们最容易使用但也是最不利的防御资源。它会提高你的生命值，并且始终可用，但在 熊形态 中你无法使用大多数伤害法术。

[[spell:319454]] 如果在 [[spell:5487]] 中使用，可提供30秒的生命值加成。这个额外的生命值不被视为治疗，应在承受大量伤害之前使用。当你切换回 [[spell:24858]] 时，该增益会持续存在。你也可以在任何施法者形态下施放此法术来治疗5名玩家。

这些是 平衡 德鲁伊的关键防御资源。还有其他方式来保证安全，包括强大的被动技能，如 [[spell:377847]]，但这三个法术涵盖了我们大部分的防御手段。

### 平衡 德鲁伊 属性优先级

2.5.

#### 平衡 德鲁伊 的属性优先级

平衡 德鲁伊 的一般属性优先级如下所示。这只是一个非常粗略的指南，专为不希望对自己的角色进行模拟的玩家设计。如果你正在模拟你的角色，请完全忽略此属性优先级，并遵循你的模拟结果！有关本页呈现内容的更多信息，请查看我们的主
[属性优先级页面](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>).

属性优先级 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 如下：

智力

精通

急速

暴击

全能

属性优先级 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者 如下：

智力

精通

暴击

急速

全能

### 暴风雪战斗助手

2.6.

#### 平衡 德鲁伊 战斗助手

新的 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 已与新的一键循环一同推出，后者带有轻微的公共冷却时间惩罚。战斗助手是一个很好的学习工具，其输出会损失10-15%的伤害，而一键循环则比由玩家最优操作的循环差15-20%。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月17日：** 已针对艾露恩之选属性偏好更新。
- **2026年8月10日：** 已针对 12.1.0 补丁更新
- **2026年6月15日：** 更新了野性之心条目。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 17 日：** 更新了天赋推荐
- **2026年3月16日：** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年2月26日：** 已针对 至暗之夜 发布进行审阅和更新。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁更新
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月11日：** 已针对套装变动和增益更新。
- **2025年8月4日：** 已针对 11.2.0 补丁进行审阅
- **2025年6月15日：** 已针对 11.1.7 补丁进行审阅
- **2025年4月21日：** 已针对 11.1.5 补丁进行审阅和更新
- **2025 年 2 月 24 日：** 已针对 11.1.0 补丁进行审阅和更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024 年 10 月 7 日：** 更新了一些天赋推荐。
- **2024年9月9日：** 已针对第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对 10.2.0 补丁更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月8日：** 已针对 5月9日的在线修复更新。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月11日：** 更新了天赋选择和一些基本信息。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 更新了天赋推荐。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面，你将找到《魔兽世界》12.1.5补丁中你的 平衡 德鲁伊 的最佳天赋。我们还为团队副本或大秘境等不同类型的内容提供了默认天赋构建。如果你开启了战争模式，我们也为你准备了PvP天赋。

1.

### 至暗之夜 中 平衡 德鲁伊 的最佳天赋

在 至暗之夜 的第一个赛季有些波折之后，第2赛季中 平衡 德鲁伊 终于在元游戏和循环上稳定下来，两套英雄天赋都开辟了自己独特的定位和优势。虽然玩家需要一些时间来真正弄清楚如何使用新的 [[spell:1239669]] 进行游戏，我们目前的建议如下：

- **单体目标 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 是 平衡 德鲁伊 最佳的单体目标天赋组合。它提供了出色的持续伤害输出和良好的混合伤害，而不会像 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者.
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者在全方位的顺劈和纯AoE伤害方面表现更好。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者可以在某些需要平衡德鲁伊提供超快速爆发AoE的情况下使用，甚至在较低层数的大秘境中也是如此。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者目前是单体和AoE综合表现最佳的英雄天赋组合。它的伤害稳定，且比
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者更少依赖冷却技能。它在整体天赋选择上非常灵活，能够应对纯单体、纯AoE，甚至间歇性顺劈的战斗。

**快速开始导入代码：**

:::talents 平衡德鲁伊单体目标 - 艾露恩
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLMMMmZZGGzYhlZWmZMmZDDAGbLzMYMbDgJAAAALMzMzgNjZMmBAwMDWGA"
}
```
:::

:::talents 平衡德鲁伊AoE - 艾露恩
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLMMMmZZmFzMjFWmZZMmZsgBAjttZGMmtBwEAAAgFmZmZwmxMGzAAYmBGA"
}
```
:::

:::talents 平衡德鲁伊地下堡 - 守护者
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmlZmZmZDgZZmtZWmxMzGLzYMGzshBADw22YBTzMbDAAAA2MzMzMYzYGjBgZGAYA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

艾露恩钦选者

团队副本/单体目标

推荐

秘境+

推荐

丛林守护者

团队副本/单体目标

秘境+

每周大秘境钥匙

地下堡

### 天赋方案 0-0

1.1.

#### 单目标天赋（适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

这些是平衡德鲁伊的纯单体天赋，通常是你进行团队副本时的配置，除非你知道战斗中会有小怪。

**在游玩时你将无法进入日蚀[[spell:1239669]]
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 归功于[[spell:429523]]。**

### 天赋方案 0-1

1.2.

#### 大秘境天赋，适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

这是我们针对大多数场景推荐的大秘境配置。它牺牲了一些 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者的爆发潜力以换取更持续的伤害输出。本赛季大秘境中对持续伤害的需求更高，因此我们推荐在大多数层数使用这个配置。

如果你发现敌人存活时间不够长，无法发挥平衡德鲁伊强大的持续伤害能力，敌人甚至在你完成正确的预热之前就死了，那么我们建议切换到我们的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者大秘境配置，它更侧重于爆发伤害。

### 天赋方案 1-0

1.3.

#### 单目标天赋（适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者

最好的纯单体天赋，适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者.

### 天赋方案 1-1

1.4.

#### 多目标及大秘境天赋，适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者

这是我们针对较低难度大秘境以及敌人死亡非常快的地城，或者团队副本中AoE战斗的推荐配置。如果你之前使用艾露恩钦选者，但因为小怪死得太快而无法打出完整的持续伤害，那么这个配置就是为你准备的！

### 天赋方案 1-2

1.5.

#### 最佳地下堡天赋

这是我们推荐的 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)构筑。它与多目标构筑类似，但移除了职业树中的团队辅助法术，并在专精树中为首领和小首领添加了单体冷却技能。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLMMMmZZGGzYhlZWmZMmZDDAGbLzMYMbDgJAAAALMzMzgNjZMmBAwMDWGA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUWX04EZZbpBUYEpzTdFWeeb7j7MyE-UWaBDHXfEKNSmwwADJZYww8grzrYhKj-AAAA-GKOik0AMggBDxC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgxMLzswMzswyMLjxMjNMAYssNzgxsNAmAAAAswMzMwmxMGzAAYmBLDA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUWX04EZZbpBUYEpzTdFWeeb7jbsMK-UWaBDHI+IakMtBSywwBDzLDzjKcijFWA-AAAA-GKOik0AIogBDxC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmlZmZmBMDWmZbGzYGLsMjZmZMzGGAMALbjFMNzsMAAAAYjZmZGsZgxMAmZAgBA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04YZbpBUYEJpzTdFebbck0NWG-UWaDJXfHNSmADFQYYogh15lh5BnYxsR-AAAA-FGQYcgkQpBQQmF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMwDMbzsMWmxMWYZGjxMjFMAYAW2GLYamZZAAAAwmZmHYmBbGzYMDgZGAYA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04EZbpBUYEpzbebTd1NsMW2nU-UWaBDIS+ESo0IZCDbDM0wgh5BnHRgCj-AAAA-FGQYcgkQpBQQmF-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmlZmZmZDgZZmtZWmxM2YZGjxMjNMAYA22GLYamZbAAAAwmZmZmBbGzYMDgZGAYA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUWX04YZbpBUYEJpzbe972mqbYZssU-UWaDJfHNSmADJMMUww8yw8kTsYAixNB-AAAA-FGQYcgkUpBYQmF-
```

:::

### 天赋方案 0-0

若想使用能够顺劈并施放 [[spell:191034]] 进行爆发性范围伤害的构筑，请使用以下代码：

:::talents 艾露恩钦选者顺劈构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLMMMmZZmFzMjFWmZZMmZsgBAjttZGMmtBwEAAAgFmZmZwmxMGzAAYmBGA"
}
```
:::

### 天赋方案 1-0

若想使用能够顺劈并施放 [[spell:191034]] 进行爆发性范围伤害的构筑，请使用以下代码：

:::talents 丛林守护者 顺劈构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmlZmZmBMDjZWmZZGzYhlZMmZmxCGAMALbjFMNzsMAAAAYjZmZGsZgxMAmZAgBA"
}
```
:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

我们建议你选择以下增益，但由于你可以随时在它们之间自由切换，如果你觉得推荐的选项收益不够，可以自行尝试其他选项：

- 节点1：[[spell:1279599]]
- 节点 2：[[spell:1279603]]
- 节点3：[[spell:1287555]]
- 节点 4：[[spell:1279609]]
- 节点5：[[spell:1279614]]

1.

### 巅峰天赋： ![Ascendant Eclipses Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_eclipse.jpg>) 至高日蚀

至暗之夜 为每个职业引入了三个新的巅峰天赋，这些天赋将在你升到满级时获得。平衡 德鲁伊 的巅峰天赋组名为升腾日蚀。

1. [[spell:1261564]] – 激活日蚀会使你的下一个[[spell:5176]]或[[spell:194153]]变为瞬发。你在每个日蚀期间施放的前三个[[spell:78674]]或[[spell:191034]]造成的伤害提高 20%。
2. [[spell:1261565]] – 你在日月之蚀期间造成的暴击会使受害者额外承受相当于所造成伤害20%的伤害，持续8秒。
3. [[spell:1261566]] – 激活日蚀还会向 40 码内的敌人发射必定暴击的阳炎箭头或月神箭头。[[spell:1261573]]命中一个目标，[[spell:1263137]]命中三个目标并造成溅射伤害。

第一个巅峰天赋 [[spell:1261564]] 会带来一些小的玩法变化。首先，当你进入冷却阶段时，将免费的瞬发施放用于 [[spell:194153]]。此外，你希望在起手阶段最大化使用获得增益的消耗技能，这会延迟你的第一次冷却技能施放。

第二和第三个巅峰天赋更加被动，不影响玩法。[[spell:1261565]] 大幅提升暴击的收益，并最终造成我们大部分的伤害。[[spell:1261566]] 是日月之蚀开始时的小幅伤害提升。主要的玩法调整在于 [[spell:1239669]] 的充能管理，你不希望在进入冷却阶段前保留2层充能。

1.

### 英雄天赋

达到71级时，平衡德鲁伊可以在两个承担截然不同职责的英雄天赋树之间进行选择， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者。两者都具有竞争力，并填补不同的定位。

3.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者

选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者 的好处在于它将 平衡德鲁伊 变成了一个短冷却、以爆发为主的专精。在PvE内容中更常需要爆发伤害，因为目标死得越快，杀死你的可能性就越低。无论是纯单体还是高目标数的多目标构筑，都比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 构筑稍差。丛林守护者 更有可能在中间找到自己的位置，利用 [[spell:433850]] 和 [[spell:205636]] 在许多它擅长的战斗中对优先目标造成大量伤害。

3.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 专注于 奥术 法术和 [[spell:194153]]。它目前拥有模拟中最高的单体和大规模多目标构筑。当它能够利用这些场景时，它是一个顶级的施法者DPS。[[spell:429523]] 使你在 [[spell:1239669]] 期间始终连锁施放星火术，考虑到其较长的施法时间，与 [[spell:5176]] 相比可能会有些笨拙。

1.

### PvP天赋（战争模式）

将会有进入“战争模式”的选项。启用战争模式可提供以下好处：

- 在户外世界启用PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。

鉴于启用战争模式对升级和PvE内容的好处，建议启用该功能以在满级时最大化你的升级速度和奖励。不过，你将使自己可以被公开PvP，在升级或进行世界任务时有可能被击杀。

在本节中，我们将列出最适合升级和进行单人/小队PvE内容的PvP天赋。请注意，这些在实际PvP情况下可能并非最优。

- [[spell:356517]]是一个被动效果，在[[spell:191034]]期间会召唤坠落的流星击中敌人。碰到这些流星的敌人会受到伤害并被击飞。盟友可以拾起这些流星并撞向敌人来引爆它们。
- [[spell:209740]] 在团队战斗中非常出色，在单人内容中也很强力。它可以增益你队伍中的所有成员，帮助更快地完成任务和稀有怪。我们推荐在所有团队内容中使用它。
- [[spell:305497]]可以在野外内容中提供少量的控制或伤害。
- [[spell:236147]]能让你即使在战斗中也能以100%移动速度移动。非常适合野外内容。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月12日：** 更新了最佳天赋推荐。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 添加了万世典籍天赋推荐。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 更新了天赋推荐
- **2026 年 3 月 17 日：** 更新了天赋推荐
- **2026年3月16日：** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年2月26日：** 已针对 至暗之夜 发布进行审阅和更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月4日：** 已针对 11.2.0 补丁进行审阅
- **2025年6月15日：** 已针对 11.1.7 补丁进行审阅
- **2025年4月21日：** 已针对 11.1.5 补丁进行更新和审阅。
- **2025 年 2 月 24 日：** 已针对 11.0.1 补丁进行审阅和更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对 11.0.5 补丁天赋重做更新。
- **2024年9月9日：** 已针对第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对 10.2.0 补丁更新。
- **2023年9月4日：** 已针对10.1.7补丁更新
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月21日：** 更新了织星者与撼星之力的对比。
- **2022年12月11日：** 修复了失效的天赋链接。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 更新了天赋推荐。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页，你将学习如何在单体和多目标情况下优化你的 平衡德鲁伊 的循环。我们还提供了关于冷却技能、触发效果等方面的进阶章节，以最大化你的DPS。我们的所有内容均针对《魔兽世界》12.1.5版本更新。

1.

### 平衡德鲁伊 玩法与循环指南

欢迎来到我们的 平衡德鲁伊循环页面。在本页，你将找到关于在团队副本和大秘境场景中实际游玩该专精所需了解的一切信息。

在下方选择天赋和英雄天赋后，本指南中的循环将会相应更新。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者

单目标输出与

[[spell:394013]]

单目标输出与

[[spell:391528]]

群体伤害

主动天赋

被动天赋

[[spell:205636]]

[[spell:194223]]

[[spell:88747]]

[[spell:468936]]

[[spell:394013]]

[[spell:391528]]

[[spell:202770]]

[[spell:274281]]

[[spell:202430]]

[[spell:383195]]

[[spell:1240262]]

[[spell:327541]]

[[spell:114107]]

[[spell:390378]]

[[spell:468743]]

[[spell:394414]]

[[spell:1240907]]

[[spell:393940]]

[[spell:393954]]

[[spell:394094]]

[[spell:383197]]

[[spell:394121]]

[[spell:393991]]

### 平衡 德鲁伊详解

1.1.

#### 平衡 德鲁伊基础

作为一名平衡 德鲁伊，你将使用[[spell:1239669]]系统。你会根据最后施放的填充法术来选择一个日月之蚀状态。[[spell:5176]]将使你进入[[spell:326053]]，[[spell:194153]]将使你进入[[spell:326055]]。处于[[spell:194223]]或[[spell:394013]]之中将使你获得两种日月之蚀状态的加成。

你会对所有适用的目标施加持续伤害效果，使用合适的填充法术配合[[spell:1239669]]积累星界能量，然后消耗这些星界能量造成大量伤害。这些操作的基本优先级如下：

1. 不要让星界能量溢出。即使不在[[spell:1239669]]之中，如果你的星界能量即将溢出，也要消耗星界能量。
2. 对你的目标施加[[spell:93402]]和[[spell:8921]]。持续伤害效果是高效的伤害来源，并且与许多天赋产生互动
3. 在用填充法术命中单个目标时进入[[spell:326053]]，命中多个目标时进入[[spell:326055]]。
4. 在处于[[spell:326053]]时使用[[spell:5176]]积累星界能量，在处于[[spell:326055]]时使用[[spell:194153]]积累星界能量。
5. 对单个目标消耗星界能量施放[[spell:78674]]，对多个目标消耗星界能量施放[[spell:191034]]。

**适用条件：艾露恩钦选者（启用）。**

:::details 常见问题：为什么我无法进入[[spell:326053]]？
该

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

英雄天赋树中有一个天赋会禁用

[[spell:326053]]

名为

[[spell:429523]]

。你仍然可以施放

[[spell:5176]]

但将不再能够切换

[[spell:1239669]]

类型。使用月神召唤时，你的主要填充法术将是

[[spell:194153]]

因为它造成更高的伤害。

:::

### 单体输出循环

1.2.

#### 平衡 德鲁伊单目标优先级列表

1. 不要让星界能量溢出。
2. 施加并保持[[spell:93402]]，并在进入[[spell:194223]]/[[spell:394013]]之前重新施放。
3. **适用条件：自然之力（未启用）。** 施加并保持[[spell:8921]]，并在进入[[spell:194223]]/[[spell:394013]]之前重新施放。
4. **适用条件：自然之力（启用）。** 施加并保持[[spell:8921]]。施放[[spell:205636]]时会自动为你施加它。
5. **适用条件：狂怒 of Elune（启用）。** 在进入[[spell:1239669]]或施放[[spell:194223]]/[[spell:394013]]之前施放[[spell:202770]]。
6. **适用条件：自然之力（启用）。** 在进入 [[spell:1239669]] 或施放 [[spell:194223]]/[[spell:394013]] 之前，先施放 [[spell:205636]]。
7. **适用条件：Convoke the Spirits（启用）。** 施放 [[spell:194223]]。
8. **适用条件：Convoke the Spirits（未启用）。** 施放 [[spell:394013]]。
9. **适用条件：Convoke the Spirits（启用）。** 在 [[spell:194223]] 持续期间且星界能量低于40时，施放 [[spell:391528]]。
10. **适用条件：丛林守护者（启用）。** 进入 [[spell:326053]]。
11. **适用条件：艾露恩钦选者（启用）。** 进入 [[spell:326055]]。
12. **适用条件：Starweaver（启用）；Touch the Cosmos（启用）。** 如果你触发了 [[spell:393940]] 或 [[spell:394414]]，就施放 [[spell:191034]]。
13. **适用条件：Starweaver（启用）。** 施放 [[spell:78674]] 来消耗星界能量，或者当你触发了 [[spell:393940]] 时施放。
14. **适用条件：Starweaver（未启用）。** 施放 [[spell:78674]] 来消耗星界能量。
15. **适用条件：丛林守护者（启用）。** 施放 [[spell:5176]] 来产生星界能量。
16. **适用条件：艾露恩钦选者（启用）。** 施放 [[spell:194153]] 来产生星界能量。
17. 在离开任何 [[spell:1239669]] 之前，如果你即将进入日蚀，请保留星界能量；如果你将在日蚀之外等待数秒，则消耗你的星界能量。

### 单体目标起手

[[spell:5176]]

[[spell:5176]]

**适用条件：丛林守护者（未启用）。**

[[spell:8921]]

[[spell:93402]]

**适用条件：狂怒 of Elune（启用）。**

[[spell:202770]]

**适用条件：艾露恩钦选者（启用）。**

[[spell:326055]]

**适用条件：艾露恩钦选者（启用）。**

[[spell:194153]]

**适用条件：自然之力（启用）。**

[[spell:205636]]

**适用条件：Convoke the Spirits（启用）；Incarnation: Chosen of Elune（未启用）。**

[[item:249346]]

[[spell:194223]]

[[item:241308]]

**适用条件：Incarnation: Chosen of Elune（启用）；Convoke the Spirits（未启用）。**

[[item:249346]]

[[spell:394013]]

[[item:241308]]

[[spell:194153]]

[[spell:78674]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:78674]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:78674]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:391528]]

1.3.

#### 平衡 德鲁伊 单体起手详解

在战斗开始前，确保你处于 [[spell:24858]] 形态并且 [[spell:1126]] 已激活。

1. 在开怪计时器大约剩4秒时，预读两个 [[spell:5176]]。
2. **适用条件：艾露恩钦选者（启用）。** 对目标施加并保持 [[spell:8921]]。
3. **适用条件：艾露恩钦选者（启用）。** 对目标施加并保持 [[spell:93402]]。
4. **适用条件：丛林守护者（启用）。** 对目标施加 [[spell:93402]]。你不需要施加 [[spell:8921]]，因为它会被 [[spell:205636]] 施加。保持这两个持续伤害效果。
5. **适用条件：狂怒 of Elune（启用）。** 施放 [[spell:202770]]。
6. 施放 [[spell:326055]]。
7. 施放 [[spell:194153]]。
8. **适用条件：自然之力（启用）。** 施放 [[spell:205636]]。
9. **适用条件：Convoke the Spirits（启用）。** 使用你的饰品和药水并施放 [[spell:194223]]。
10. **适用条件：Convoke the Spirits（未启用）。** 使用你的饰品和药水并施放 [[spell:394013]]。
11. **适用条件：Convoke the Spirits（启用）。** 施放 [[spell:78674]] 将星界能量降到40以下。
12. **适用条件：Convoke the Spirits（启用）。** 施放 [[spell:391528]]。
13. 在 [[spell:194223]]/[[spell:394013]] 期间，施放 [[spell:194153]] 来触发瞬发的 [[spell:1261564]]（如果你不会使星界能量溢出的话）。
14. **适用条件：艾露恩钦选者（未启用）。** 施放 [[spell:78674]] 来消耗星界能量，施放 [[spell:5176]] 来产生它。
15. **适用条件：艾露恩钦选者（启用）。** 施放 [[spell:78674]] 来消耗星界能量，施放 [[spell:194153]] 来产生它。

### AOE循环

1.4.

#### 平衡 德鲁伊 AOE优先级列表

1. 不要让星界能量溢出。
2. **适用条件：自然之力（未启用）。** 施加并保持 [[spell:8921]]，并在进入 [[spell:194223]]/[[spell:394013]] 之前重新施放。在敌人被聚拢时施放此技能。
3. **适用条件：自然之力（启用）。** 施加并保持 [[spell:8921]]。在敌人被聚拢时施放此技能。[[spell:205636]] 会将月火术扩散到6个未受影响的目标。
4. 施加并保持 [[spell:93402]]，并在进入 [[spell:194223]]/[[spell:394013]] 之前重新施放。如果可能的话，等到多个目标聚拢后再施放。
5. **适用条件：狂怒 of Elune（启用）。** 在进入[[spell:1239669]]或施放[[spell:194223]]/[[spell:394013]]之前施放[[spell:202770]]。
6. **适用条件：自然之力（启用）。** 在进入 [[spell:1239669]] 或施放 [[spell:194223]]/[[spell:394013]] 之前，先施放 [[spell:205636]]。
7. **适用条件：Convoke the Spirits（启用）。** 施放 [[spell:194223]]。
8. **适用条件：Convoke the Spirits（未启用）。** 施放 [[spell:394013]]。
9. **适用条件：Convoke the Spirits（启用）。** 如果目标少于8个且你的星界能量低于40，施放 [[spell:391528]]。
10. 进入 [[spell:326055]]。
11. **适用条件：Touch the Cosmos（启用）。** 施放 [[spell:191034]] 来消耗星界能量，或者当你触发了 [[spell:393940]] 或 [[spell:394414]] 时施放。
12. **适用条件：Starweaver（启用）。** 如果目标少于8个且你触发了 [[spell:393940]]，施放 [[spell:78674]]。
13. 施放 [[spell:194153]] 来积攒星界能量。
14. 在离开任何 [[spell:1239669]] 之前，如果你即将进入日蚀，请保留星界能量；如果你将在日蚀之外等待数秒，则消耗你的星界能量。

---

:::details 常见问题：[[spell:1240262]] 还是 [[spell:327541]]？
这是天赋树前期一个有趣的选择节点。

[[spell:1240262]]

当你以更具周期性的方式爆发性地击杀中到大型敌群时，其效果最佳。对于某些团队副本战斗，可以将其视为一种爆发选择。

[[spell:327541]]

对于持续时间较长的AOE战斗和小怪群非常有用，在这些情况下，你的持续伤害效果原本会在目标死亡前掉落或需要重新施加一次。

:::

### AoE起手

[[spell:5176]]

[[spell:5176]]

[[spell:8921]]

[[spell:93402]]

**适用条件：狂怒 of Elune（启用）。**

[[spell:202770]]

[[spell:326055]]

[[spell:194153]]

**适用条件：丛林守护者（启用）。**

[[spell:205636]]

**适用条件：化身：艾露恩之选（未启用）。**

[[item:249346]]

[[spell:194223]]

[[item:241308]]

**适用条件：Incarnation: Chosen of Elune（启用）。**

[[item:249346]]

[[spell:394013]]

[[item:241308]]

[[spell:194153]]

[[spell:191034]]

1.5.

#### 平衡 德鲁伊 AOE起手详解

在战斗开始前，确保你处于 [[spell:24858]] 形态并且 [[spell:1126]] 已激活。

1. 在开怪计时器大约剩4秒时，预读两个 [[spell:5176]]。
2. **适用条件：艾露恩钦选者（启用）。** 在敌人被聚拢时对目标施加 [[spell:8921]]。
3. **适用条件：丛林守护者（启用）。** 对目标施加 [[spell:8921]]。[[spell:205636]] 会将月火术扩散到6个未受影响的目标。
4. 在敌人被聚拢时对目标施加 [[spell:93402]]，以减少多余的公共冷却时间。
5. **适用条件：狂怒 of Elune（启用）。** 施放 [[spell:202770]]。
6. 如果你在冷却期间层数即将溢出，施放 [[spell:326055]]。
7. 在 [[spell:194223]]/[[spell:394013]] 期间，施放 [[spell:194153]] 来触发瞬发的 [[spell:1261564]]（如果你不会使星界能量溢出的话）。
8. **适用条件：丛林守护者（启用）。** 施放 [[spell:205636]]。
9. **适用条件：化身：艾露恩之选（未启用）。** 施放 [[spell:194223]]。
10. **适用条件：Incarnation: Chosen of Elune（启用）。** 施放 [[spell:394013]]。
11. 施放 [[spell:191034]] 来消耗星界能量，施放 [[spell:194153]] 来产生它。
12.

### 至暗之夜 第2赛季套装

- 2件套奖励：[[spell:78674]] 的伤害提高20%。[[spell:191034]] 在施放时也会立即对范围内所有有效敌人造成星界伤害。

2件套奖励纯粹是数值上的提升。它使我们的消耗技能更加强力。一个不错的额外好处是，它确实为 [[spell:191034]] 增加了一些小额爆发伤害。

- 4件套奖励：你在任何日蚀期间伤害提高10%。该奖励在日蚀中点时衰减至2%，然后在结束时回升至10%。

4件套奖励对游戏玩法有一定影响，但它进一步强化了积攒-消耗循环的标准模式。它与上个赛季有所不同，因为如果可能的话，你会希望将消耗技能保留到伤害加成达到顶峰时使用。

1.

### 职业与专精机制详解

为了更好地解释 平衡 德鲁伊 套装的具体用途和优势，我们编写了更详细的说明，涵盖循环的各个部分，从需要注意的重要循环机制到冷却技能及其使用方法，以便你在游玩 平衡 德鲁伊 时能发挥全部潜力。

### 利用日蚀

3.1.

#### 利用日蚀

新的 [[spell:1239669]] 系统降低了启动时间，但代价是总体覆盖率的下降。这在团队副本中最为明显，但在任何持续超过两三分钟的战斗中你都会感受到这种停工期。

平均而言，你可以维持日蚀（包括冷却技能）65-75%的时间。重要的是在需要时拥有日蚀。根据战斗需求规划你的停工期，避免日蚀层数溢出以达到最高的可实现覆盖率。例如，如果你知道你将在10秒后攻击一个优先目标，就在日蚀之外积攒星界能量。如果你在地下城中的一波小怪即将死亡，就保留你的层数。

此外，你需要考虑在日蚀内外施放的法术类型或采取的行动。在日蚀期间，你的首要任务是尽可能多地消耗星界能量，因为这是你最有效的伤害输出。诸如 [[spell:78674]] 和 [[spell:191034]] 这样的法术将是最佳选择，而 [[spell:5176]] 和 [[spell:194153]] 则是日蚀期间施放的良好法术。

在日蚀之外时，你应该施放准备或维护类法术。即那些能持续到日蚀状态或增强你即将到来技能的法术。最好的例子是你的持续伤害效果，[[spell:8921]] 和 [[spell:93402]]。它们能持续到日蚀，而且由于它们会随你的增益更新，你只会损失它们初始低伤害施加部分的伤害。你也应该施放产生星界能量或增强自身的法术，例如 [[spell:202770]] 和 [[spell:205636]]。

### 持续伤害临界点

3.2.

#### 持续伤害临界点

在对目标施加持续伤害效果时，你需要考虑这些效果将造成伤害的时间长度。当一个目标存活超过完整的持续伤害持续时间时，你用于施加该效果的那个公共冷却时间是你所能施放的每次伤害最高效的公共冷却时间。然而，并非每个目标都能存活完整的15到24秒。如果一个目标只能存活5-6秒，你应该专注于通过你的消耗技能和其他能力向该目标倾泻尽可能多的直接伤害，而放弃对该目标施加持续伤害效果，因为那样造成的伤害会低于一个 [[spell:5176]] 或 [[spell:78674]]。

在AOE中对目标施加持续伤害效果时，你还需要考虑将使用多少个公共冷却时间。如果你的目标分散，你可能只想 [[spell:8921]] 它们，因为月火术可以溅射到比 [[spell:93402]] 更远的目标。一旦目标聚拢，你就可以在那里对它们施加阳炎术，因为你可以用一个公共冷却时间击中所有目标。

施放 [[spell:93402]] 时，你要确保目标至少能存活5秒。对于 [[spell:8921]]，你要确保目标至少能存活8秒。

### 目标数量临界点

3.3.

#### 目标数量临界点

在 **单** 目标上，最好施放 [[spell:78674]] 而不是 [[spell:191034]]。

你有时会在两个目标上施放 [[spell:191034]]，有时在三个目标上施放。[[spell:191034]] 和 [[spell:78674]] 在两个目标上通常很接近，但你总是会在三个目标上施放星辰坠落。天赋在这个选择中起着重要作用。作为一个快速参考，如果你在AOE上投入足够多以至于点出 [[spell:1240907]]，你总是会在两个目标上施放星辰坠落。对于 [[spell:393940]] 也是如此，除非你使用的是纯单体天赋。

如果你点了 [[spell:450212]] 或 [[spell:394046]] 但没有点流星，在游玩 [[spell:393954]] 时，你将在两个目标上 星涌术。

重要的是要理解，当你进行AOE时，你通常会点出 [[spell:1240907]]，所以你不需要记住所有的条件。

在选择进入哪个 [[spell:1239669]] 时，你需要知道你的填充法术能击中多少个目标。如果你能用 [[spell:194153]] 稳定击中3个目标，你就应该进入月蚀。如果不能，确保你处于日蚀并施放 [[spell:5176]]。

如果你点出了 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者，你总是会进入月蚀并且总是施放 [[spell:194153]]。你可以用 [[spell:5176]] 起手以避免提前引到首领。

### 织星者与触及宇宙

3.4.

#### 织星者与触及宇宙

鉴于 平衡 德鲁伊 拥有如此多的免费消耗技能触发，理解何时使用它们以及施放哪些法术非常重要。

使用 [[spell:393940]] 时，你会获得一个与触发它相反的消耗技能的免费施放。[[spell:191034]] 触发总是会被使用，但在8个或更多目标时，你不会使用 [[spell:78674]] 触发。

[[spell:393940]] 对每个消耗技能有不同的触发几率。当你施放 [[spell:191034]] 时，你更有可能获得 [[spell:78674]] 触发，反之亦然。所以当你有点出织星者天赋并触发了 [[spell:394414]] 时，你总是会施放星辰坠落。

1.

### 平衡 德鲁伊 的重要冷却技能

### [[spell:194223]]

4.1.

#### 超凡之盟

首先需要注意的是，[[spell:194223]]和[[spell:394013]]都是更强的[[spell:1239669]]状态，「利用日月之蚀」章节中所述的规则在这里同样适用，而且对于你在这些冷却期间施放的法术类型来说更是如此。

这些法术本身提供小额属性增益，但重要的是它们同时提供 [[spell:1239669]] 状态，该状态使你的星界伤害法术获得额外伤害。这包括像 [[spell:78674]] 这样的消耗技能、像 [[spell:202342]] 这样的触发技能以及像 [[spell:202770]] 这样的冷却技能。

你总是希望将你的冷却技能重叠使用。对于 [[spell:468743]]，该技能有两层充能，这使你可以错开它们的使用时间，以便与其他冷却技能如 [[spell:391528]]、[[spell:205636]] 和 [[spell:205636]] 对齐。你能叠加的冷却技能越多，它们的威力就越大。

### [[spell:205636]]

4.2.

#### 自然之力

[[spell:205636]] 是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者 英雄天赋树的核心机制。频繁且在正确时机施放 [[spell:205636]] 将显著提升你的伤害。它本身会提供强大的 [[spell:433831]] 增益，提供按需爆发、固定4%的伤害加成，并对最多8个目标施加 [[spell:8921]]。

你总是希望将 [[spell:205636]] 与你的主要冷却技能 [[spell:194223]] 或 [[spell:394013]] 搭配使用。如果它们正在冷却中45秒（或使用 [[spell:428937]] 时为30秒），你希望将 自然之力 与你的下一个 [[spell:1239669]] 搭配使用。

### [[spell:202770]]

4.3.

#### 艾露恩之怒

[[spell:202770]] 可以与任一英雄天赋选择一起使用，但在 [[spell:202770]] 下更有效且玩法不同。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者.

当游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者，你主要使用它来产生星界能量。因此，它通常是与 [[spell:194223]] 和 [[spell:205636]] 搭配使用的，以允许你在这些增益窗口期间消耗更多星界能量。你要在进入 [[spell:1239669]] 或冷却技能之前使用它，因为它不是主要的伤害来源。

在 [[spell:202770]] 内游玩时 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者，它会变成一个强大得多的技能，因为它直接受到主要和终极英雄天赋的增益。此外，它的冷却时间被 [[spell:429539]] 大幅缩短。艾露恩钦选者 的变化在于，你总是希望在你的 [[spell:1239669]] 期间施放它，并且你希望在它冷却完毕后尽快施放，除非你需要为特定的伤害窗口保留它。

### [[spell:391528]]

4.4.

#### 万灵之召

始终尝试将 [[spell:391528]] 与 [[spell:194223]]/[[spell:394013]] 以及 [[spell:394048]] 的增益重叠使用。

[[spell:391528]] 的范围是从任何目标碰撞盒中心起45码。这意味着对于体型较大的首领，最大距离的万灵之召可能会因为距离过远而完全错过所有 平衡 法术。

在点出 [[spell:393991]] 的情况下，近战 [[spell:391528]] 不如远程万灵之召稳定。如果可能的话，避免处于近战范围内，否则你更有可能丢失一个 平衡 专属的法术。这是一个小细节，但如果可能的话应该避免。

如果你在多个目标上使用 [[spell:391528]]，在施放其他 [[spell:191034]] 之前施放万灵之召，以提高你施放免费星辰坠落的几率。

4.5.

#### 防御实用性

所有德鲁伊都从职业天赋树中获得一些天生的坦度。我们会获得更多的治疗量，承受更少的固定伤害，并且受到某些物理法术的伤害更低。我们还可以在不同情况下触发几个被动治疗效果。

- [[spell:22812]] 是你的主要防御资源。这是一个冷却时间短、减伤幅度低的法术，通常在你需要它的大部分时间里都是可用的。在职业天赋树中，还有几个其他被动技能可以增强树皮术，但最值得注意的是 [[spell:449191]]，它能进一步提高减伤效果。
- [[spell:5487]] 是我们最容易使用但也是最不利的防御资源。它会提高你的生命值，并且始终可用，但在 熊形态 中你无法使用大多数伤害法术。
- [[spell:319454]] 如果在 [[spell:5487]] 中使用，可提供30秒的生命值加成。这个额外的生命值不被视为治疗，应在承受大量伤害之前使用。当你切换回 [[spell:24858]] 时，该增益会持续存在。你也可以在任何施法者形态下施放此法术来治疗5名玩家。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月12日：** 更新了星界强化相关说明。
- **2026年8月10日：** 已针对 12.1.0 补丁进行审阅
- **2026年6月15日：** 重新排版了机制与技巧部分。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 在常见问题板块中添加了关于输出循环的说明，并进一步扩展了游戏机制内容。
- **2026 年 3 月 17 日：** 更新了输出循环，移除了织星者的提及。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁更新
- **2025年11月30日：** 添加了常见问题板块。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月30日：** 添加了配合新套装的守墓者起手手法。
- **2025年8月4日：** 已针对 11.2.0 补丁进行审阅
- **2025年6月15日：** 已针对 11.1.7 补丁进行审阅
- **2025年4月21日：** 已针对 11.1.5 补丁进行更新和审阅。
- **2025 年 2 月 24 日：** 已针对 11.0.1 补丁进行审阅和更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对第一赛季进行审阅。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第四赛季的新套装更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年12月8日：** 更新了撼星之力增益的提及。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月8日：** 已针对 5月9日的在线修复更新。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 更新了部分章节以保持一致性。已针对10.0.7补丁进行审阅。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月11日：** 已针对T29套装进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 更新了天赋推荐。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到魔兽世界12.1.5中 平衡 德鲁伊 的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们都为你准备好了！

1.

### 平衡德鲁伊毕业装备指南

欢迎来到我们的平衡德鲁伊装备与BiS页面，适用于至暗之夜第2赛季！查看此页面，了解让你的角色发挥出最大潜力所需的一切知识！

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含平衡德鲁伊在所有可用内容中的最佳装备，包括新发布的 [孢子坠落](<https://www.icy-veins.com/wow/midnight-season-1-raid-guide>) 团队副本。这是值得追求的装备，但不包括无法可靠获得的装备，例如来自每周宝库的部分装备。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在第2赛季中，你需要优先获取

**头盔、手套、胸甲和腿部**

套装组件。完成套装效果比获得完美装备更重要，所以能拿到什么就拿什么。从长远来看，你需要获取来自

[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

和

[盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

的强化物品等级装备。催化器也会保留特殊物品的效果，例如

[[item:271875]]

.

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装组件时还会保留副属性以及任何其他潜在的被动效果，如伤害和属性触发效果。这意味着我们要尝试催化那些能确保我们在装备上获得最佳副属性的物品。一些适合催化的最佳属性物品如下：

- 头盔：[[item:271875]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:268246]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 胸部：[[item:239048]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 手套：[[item:159312]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 腿部：[[item:268225]]，来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 小贴士：我最想从所有内容中获得哪些装备？
以下是一些值得使用额外拾取或在宝库中获取的装备，前提是你在合适的物品等级时看到它们。

- [[item:271092]]：我们最好的武器。它掉落自团队副本最终Boss，物品等级为强化等级。没有比这更好的武器了。
- [[item:273796]]：我们最好的主动使用饰品，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>).
- [[item:281215]]：我们最好的团队副本战斗被动饰品。

:::

:::details 常见问题：套装有多强？
平衡德鲁伊的至暗之夜第2赛季套装非常强大。在单体战斗中，2件套约提升6%-7%的DPS，4件套提升11%-13%的DPS。套装在多目标战斗中甚至更强，因为它为

[[spell:191034]]

.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:268246@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:268240@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAIAAwt1ENMMYDH2A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含使用至暗之夜第2赛季史诗钥石地下城中可刷取装备的最高DPS配置。

此列表绝不能替代 **模拟你自己**。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
对于至暗之夜第2赛季的平衡德鲁伊，你需要优先获取

**头盔、手套、胸甲和腿部**

套装组件。完成套装效果比获得完美装备更重要，所以能拿到什么就拿什么。从长远来看，你需要获取来自

[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

和

[盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

的强化物品等级装备。催化器也会保留特殊物品的效果，例如

[[item:271875]]

.

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装组件时还会保留副属性以及任何其他潜在的被动效果，如伤害和属性触发效果。这意味着我们要尝试催化那些能确保我们在装备上获得最佳副属性的物品。一些适合催化的最佳属性物品如下：

- 头盔：[[item:159318]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 肩部：[[item:251223]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 胸部：[[item:239048]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 手套：[[item:159312]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 腿部：[[item:251130]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：该地下城掉落我们最好的主动使用饰品[[item:273796]]。
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：掉落一个不错的被动饰品[[item:250224]]和一把还行的武器，但团队副本装备会更好。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:159301@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:251223@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:251183@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>饰品</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAAMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAIAAwt1ENMMYDH2A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含在至暗之夜第2赛季中，使用团队副本装备搭配推荐制造物品的最高DPS配置。

此列表绝不能替代 **模拟你自己**。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
对于至暗之夜第2赛季的平衡德鲁伊，你需要优先获取

**头盔、手套、胸甲和腿部**

套装组件。完成套装效果比获得完美装备更重要，所以能拿到什么就拿什么。从长远来看，你需要获取来自

[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

和

[盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

的强化物品等级装备。催化器也会保留特殊物品的效果，例如

[[item:271875]]

.

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装组件时还会保留副属性以及任何其他潜在的被动效果，如伤害和属性触发效果。这意味着我们要尝试催化那些能确保我们在装备上获得最佳副属性的物品。一些适合催化的最佳属性物品如下：

- 头盔：[[item:271875]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:268246]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 胸部：套装代币兑换的基础套装物品更好。
- 手套：[[item:268234]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- 腿部：[[item:268225]]，来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:271092]]：我们最好的武器。它掉落自团队副本最终Boss，物品等级为强化等级。
- [[item:281215]]：我们最好的团队副本战斗被动饰品。
- 毒咒物品，例如[[item:268265]]和[[item:271875]]。它们提供与其他物品相同的副属性数值，以及额外的暴击和急速触发效果。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:268246@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270169@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:268240@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAIAAwt1ENMMYDH2A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 平衡德鲁伊饰品推荐

在至暗之夜第2赛季中，平衡德鲁伊有许多可用的饰品。整体最佳的两个选择是主动使用的[[item:273796]]和被动饰品[[item:281215]]。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **平衡德鲁伊饰品**
**使用型 -**

[[item:273796]]

或者，作为替代，

[[item:250215]]

**被动 -**

[[item:281215]]

是我们来自新团队副本的主要被动饰品。

:::

还有不少其他有价值的饰品，所以请务必点击我们的排名图表，看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看平衡德鲁伊饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>最佳平衡德鲁伊饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:270167]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:270169]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270170]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250224]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:270161]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273794]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:158368]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

12.1版本延续了在12.0.7版本中首次引入的额外拾取系统。值得注意的是，对英雄难度团队副本Boss使用额外拾取将使你获得1/6神话等级的物品，因此只要你投入额外的纹章来升级它，就可以相当早地获得一些后期团队副本装备。

**[朦胧虚空核心](<https://www.wowhead.com/currency=3418>)** 可以在完成地下城或击杀团队副本Boss后使用，它会从地下城或Boss的掉落列表中随机奖励你一件物品。一旦通过虚空核拾取获得了一件物品，当你再次对同一Boss或地下城使用额外拾取时，该物品就不会再次出现。

8周后，你还将免费获得一个额外的虚空核心，来源为
**奥琳·微光** 免费获得一个额外的虚空核，该NPC位于银月城的催化器旁边。这将在12.1.5版本上线时发生。

3.1.

#### 平衡德鲁伊推荐的虚空核使用建议

你想追求哪件装备，很大程度上取决于你已经通过以下内容获得的装备： [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)，或者你是否预计能在你能达到的最高难度下击败某些Boss，因为你不希望把虚空核浪费在几周后可能在更高难度路线中获得的装备上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. [[item:271092]]
2. [[item:268265]]
3. [[item:281215]]
4. [[item:271875]]
5. 尽可能替换低物品等级、高属性预算的装备部位，最好替换来自最后2个团队副本Boss的强化物品。

:::

[[item:271092]]完全升级后是你绝对值得使用额外拾取的最佳物品 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)，只有同一件装备在更高物品等级或巨大的物品等级差距提升时才会被替换。[[item:271875]]和[[item:268265]]都是来自同一Boss的优秀装备，值得使用额外拾取。

一如既往，我们建议使用Raidbots模拟你的角色，看看哪些Boss有最佳装备值得拾取。

3.2.

#### 晋升毒液石

[[item:280562]]允许你将武器、副手、项链和饰品的物品等级提升6级，非制造装备最高可达340物品等级，制造装备最高可达337。你无法升级已经是344物品等级的物品。

与纹章一样，你应该优先升级能带来最大DPS提升的装备。对于平衡德鲁伊，我们推荐以下顺序：

1. 你的主手武器
2. 你的主动使用饰品
3. 你的被动饰品
4. 你的副手，如果你不使用法杖的话

通常，你应该优先升级神话路线装备而非英雄路线装备，特别是如果你预计很快就会替换掉英雄路线版本的话。如果你预计在不久的将来无法获得其神话路线的对应装备，升级英雄路线装备仍然是一个合理的选择。

归根结底，升级哪件装备取决于你当前的装备和进度。我们建议将你的毒石留给那些你预计会使用一段时间的装备，而不是花在你可能会替换的装备上。

1.

### 平衡德鲁伊最佳制造物品

你可以拥有两个美化效果，它们是附加在制造物品上的特殊效果。你制造什么完全取决于你能够击败哪些战斗。

对于参与英雄和史诗难度团队副本的竞技玩家，你应该遵循以下制造顺序：

1. [[item:245769]]是一个可以使用武器美化效果的副手，例如[[item:273060]]。在神话物品等级下将它与[[item:271092]]或[[item:268203]]搭配使用。
2. 如果你卡在英雄难度武器上并且需要战力提升，你应该接着制造一把带有第二个美化效果的主手武器，之后当你获得[[item:271092]]时再替换它。
3. 如果你已经有两个美化效果，最好将第三次制造留到你不需要纹章的时候。作为第三次制造，你应该制造 **靴子、手套或肩部** 并使用[[item:240167]]（如果可能的话）来替换你物品等级最低且不依赖套装槽位的装备。

如果无法从团队副本获得神话物品等级的武器，或者你需要立即的战力提升，可以考虑改为制造[[item:245770]]（确保是智力法杖！）。

我们推荐使用[[item:219823]]来制造你的装备，但如果你想为了另外百分之零点几进行极致的属性优化，你应该先使用Raidbots模拟你的角色，以防不同的副属性组合对你来说更好。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 平衡德鲁伊最佳美化效果

在早期，制造一把主手和一把副手并搭配[[item:273060]]，可以成为一个容易获得的DPS提升。该美化效果很强，并且可以在两件物品上使用，让你在早期叠加力量，帮助你通过大部分史诗内容。

[[item:240167]]是非武器美化效果中一个不错的选择。提供的属性数值会随物品的属性预算而变化，因此在这种情况下，在属性更高的物品上制造实际上是更优的选择。在这个团队副本中，根据你拥有的其他装备，你会以中等属性预算的物品为目标，如靴子、手套和肩部。

一如既往，建议你自己进行模拟，看看以你当前的装备情况什么最好。

在赛季后期，当你的头盔、护腕和腰带都有插槽，并且[[item:268265]]有双插槽时，你可以考虑模拟[[item:251513]]。

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于纹章每周获取量有限，而且升级不同物品所花费的纹章数量相同，你应该优先将纹章用在那些你短期内不打算更换的物品上，或是能带来最大收益的物品上。

1. 武器和饰品通常在每个物品等级上提供最佳价值
2. 头盔、胸甲和腿部提供最高的属性加成
3. 肩部、靴子、手套和腰带提供中等的属性加成
4. 披风和护腕提供最低的属性加成
5. 珠宝是最低优先级，因为它们没有主属性

一如既往，建议你自己进行模拟，看看以你当前的装备情况什么最好。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对 12.1.5 补丁更新
- **2026年8月17日：** 更新了专业制造和美化部分。
- **2026年8月10日：** 已针对 12.1.0 补丁更新
- **2026年6月15日：** 已针对孢子坠落发布更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 已更新饰品推荐。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对谜之财团代币发布和 D.I.S.C 削弱更新。
- **2025年8月11日：** 已针对套装改动和饰品模拟更新。
- **2025年8月4日：** 已针对 11.2.0 补丁进行审阅
- **2025年6月21日：** 已针对充能箭矢削弱更新。
- **2025年6月15日：** 已针对 11.1.7 补丁进行审阅
- **2025年3月16日：** 添加了一些额外的饰品说明。
- **2025年3月3日：** 更新了地心之战解放和第二赛季的毕业装备列表。
- **2025 年 2 月 24 日：** 已针对 11.0.1 补丁进行审阅和更新。
- **2024年12月15日：** 已针对 11.0.7 版本瑟尔赛的头环发布更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024 年 10 月 7 日：** 更新了团本饰品推荐。
- **2024年9月9日：** 已针对第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日：** 已针对 10.2.6 补丁进行审阅。更新了对蓝色丝质亚麻布的提及。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年12月8日：** 更新了一些与灾祸之枝相关的饰品推荐。
- **2023年11月7日：** 已针对最近的孢子披风削弱更新。
- **2023年11月6日：** 已针对 10.2.0 补丁更新。
- **2023年9月4日：** 已针对10.1.5补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月8日：** 已针对 5月9日的补丁改动更新。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已针对 10.0.7 补丁进行审阅。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月21日：** 更新了美化装备并扩展了饰品推荐。
- **2022年12月11日：** 已针对化身密库和第一赛季史诗钥石更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在此页面上，你将找到你的平衡德鲁伊的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法互动。我们的内容已针对《魔兽世界》12.1.5版本更新。

1.

### 平衡 德鲁伊 属性优先级

属性优先级 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 如下：

智力

精通

急速

暴击

全能

属性优先级 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者 如下：

智力

精通

暴击

急速

全能

精通在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 和
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者。精通为自然和奥术法术提供伤害加成，这与像[[spell:78674]]这样的奥术伤害技能形成双重增益。暴击与[[spell:1261565]]配合出色，该技能会基于你在日蚀期间造成的任何伤害施加一个持续伤害效果。急速是一个全面而实用的属性，对于艾露恩钦选者来说尤其有用，可以让[[spell:194153]]的漫长施法变得稍微容易应对一些。

:::details 常见问题：平衡德鲁伊有急速上限吗？
平衡德鲁伊没有急速上限。所有持续伤害效果都随你的急速和其他属性动态缩放。一般来说，任何副属性都没有临界点，但存在边际递减。

:::

1.

### 深入属性解析

属性优先级是动态变化的。你装备的每件装备、在装备上添加的每个插槽、以及每次更换装备，都会影响你的属性优先级。如果你过度忽视某个属性，它的优先级会越来越高，直到超过其他属性。如果该属性在上述一般优先级中排名较低，通常不需要太多该属性就能将其迅速降下来。

通常，你模拟装备后可能会看到精通很低、暴击很高，或者其他任何属性也是如此。你更换一两件装备甚至一个附魔，可能会看到截然不同的结果。使用 [最佳装备](<https://www.icy-veins.com/wow/how-to-use-the-top-gear-feature-of-raidbots>) 在 [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 上，以更准确地了解升级如何融入你角色特定的装备情况。

**智力** 是你的主属性。你应该在所有升级中寻找该属性。它为你提供法术强度，增加你法术的伤害。

**精通** 增加你的自然和奥术法术对目标造成的伤害。当分别受到[[spell:93402]]或[[spell:8921]]影响时，伤害会进一步增加。

**急速** 增加你的施法速度和星界能量的产生（因为你能够施放更多法术）。

**暴击** 提高你所有法术和技能的暴击几率。这个属性具有一定的随机性，这意味着它可能不像其他属性那样始终有效，或者在某些战斗中比其他属性更有效。

**全能** 提高你造成的所有伤害和治疗量，并降低你受到的所有伤害。在进行较难的内容时，这个属性可能被低估，因为减伤效果在大多数决策中不会被考虑进去。当进行团队副本开荒、高层大秘境或其他任何高伤害内容时，可以考虑提高全能的优先级。

2.1.

#### 装备等级

智力足够强大，使得物品等级成为衡量装备提升的良好指标。如果你有两件相同物品等级的装备，其中一件有精通而另一件没有，你可以有把握地判断那件装备至少是相当不错的。你仍然可以快速轻松地使用模拟来获得最准确的结果。

2.1.1.

##### 珠宝

这意味着戒指和项链的重要性较低，因为它们没有智力。物品等级较低的珠宝可能因为拥有更好的属性而远胜于物品等级较高的装备。

2.1.2.

##### 插槽

无法为装备上的插槽指定一个固定的物品等级数值，因为这取决于装备类型以及你在该插槽中使用的宝石类型。当在不同物品等级的类似装备之间进行选择且其中一件有插槽时，最好通过模拟来得出答案，而不是进行估算。

2.2.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月17日：** 已针对艾露恩之选属性偏好更新。
- **2026年8月10日：** 已针对 12.1.0 补丁进行审阅
- **2026年6月15日：** 更新了属性优先级推荐。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁更新
- **2025年11月30日：** 添加了常见问题板块。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月4日：** 已针对 11.2.0 补丁进行审阅
- **2025年6月15日：** 已针对 11.1.7 补丁进行审阅
- **2025年4月21日：** 已针对 11.1.5 补丁进行更新和审阅。
- **2025 年 2 月 24 日：** 已针对 11.0.1 补丁进行审阅和更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024 年 10 月 7 日：** 与其他属性提及保持一致。
- **2024年9月9日：** 已针对第一赛季进行审阅。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对 10.2.0 补丁更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 10.1.0 补丁无需更改。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 添加了珠宝和物品等级的说明。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面上，我们列出了你的 平衡德鲁伊 能获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

1.

### 平衡德鲁伊最佳宝石

你应该在一个插槽中使用[[item:240983]]，其余插槽则应镶嵌精通和急速宝石的组合。虽然在某些边缘情况下其他宝石可能略有优势，但这种配置绝对不会出错。

在模拟时比较宝石，我们建议测试以下不同变体，看看你是否想偏离标准的精通+急速推荐：

- 蓝宝石宝石 - [[item:240917]]
- 翡翠宝石 - [[item:240892]]
- 红宝石宝石 - [[item:240908]]
- 玛瑙宝石 - [[item:240900]]

1.

### 最佳附魔和武器强化

最佳武器强化/磨刀石是[[item:243733]]，你应在所有内容中将其应用于你的武器。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头盔</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;<tr>&#10;<td>肩部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240133]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</tr></table>

:::details 常见问题：我想要哪些第三属性？
急速、吸血和闪避都有其特定的应用场景。假设它们提供相同数量的属性，第三属性的类型在很大程度上是个人偏好。有特定的机制类型会影响每种类型，尤其是如果你有金币可以自由更换：

- 吸血在对抗治疗吸收和持续性伤害时最佳。
- 闪避在对抗脉冲伤害和大型攻击时最佳。
- 如果你不熟悉机制，急速是一个不错的默认第三属性，但它几乎从不是完成任何类型战斗的必需品。

:::

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

4.1.

#### 合剂

大多数情况下的默认合剂是[[item:241322]]。根据你的装备配置，如果你有足够的精通，也可以使用[[item:241325]]。

4.2.

#### 药水

最佳伤害药水是[[item:241288]]。根据你的装备，[[item:241308]]可能更好。考虑到它们的强度非常接近，你应该使用模拟来确定最佳选择。

在战斗中，你可以使用[[item:271883]]和[[item:5512]]来治疗自己。确保在有死亡危险时使用它们。

4.3.

#### 食物增益

如果可能的话，在团队副本或地下城中应使用[[item:255846]]或[[item:255845]]。否则，[[item:242275]]提供主属性但没有耐力，是所有内容的绝佳选择。宴会餐远胜于其他食物选择。

4.4.

#### 强化符文

对于接近的开荒尝试或为了提升你的伤害，你还可以使用[[item:259085]]。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 更新了武器附魔推荐。
- **2026年8月17日：** 更新了消耗品推荐。
- **2026年8月10日：** 已针对 12.1.0 补丁更新
- **2026年6月15日：** 更新了戒指附魔推荐。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 移除了茶的提及，并为第三属性添加了说明。
- **2026年3月16日：** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁更新
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月4日：** 已针对 11.2.0 补丁进行审阅
- **2025年6月15日：** 已针对 11.1.7 补丁进行审阅
- **2025年4月21日：** 已针对 11.1.5 补丁进行审阅和更新
- **2025 年 2 月 24 日：** 已针对 11.0.1 补丁进行审阅和更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024 年 10 月 7 日：** 更新了一些消耗品推荐。
- **2024年9月9日：** 已针对第一赛季进行审阅。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对 10.2.0 补丁更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 将原初石英推荐移至页面底部。
- **2023年3月20日：** 更新了药剂推荐和原初石英。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月21日：** 添加了项链消耗品的说明。
- **2022年12月11日：** 已针对化身密库和第一赛季史诗钥石更新。
- **2022年12月11日：** 更新了个人食物选择。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5版本中使用你的平衡德鲁伊挑战大秘境地下城的技巧和建议。

1.

### 平衡德鲁伊在至暗之夜第2赛季大秘境中的表现

平衡德鲁伊是高层大秘境中强力的远程竞争者。虽然它需要预热时间，使其在低层内容中表现较差，但一旦战斗全面展开，[[spell:191034]]和[[spell:194153]]在无上限的多目标伤害方面无与伦比。

除了在高层钥石等级中的良好输出外，我们还拥有强大的功能性工具组。

如果你不熟悉大秘境及其相关的一般机制，你可以在下面我们专门的大秘境页面上了解更多信息。你也可以在我们的层级列表页面上了解更多关于大秘境环境的内容。

1.

### 最佳大秘境天赋配置

### 艾露恩钦选者

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者大秘境天赋构建

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者构建专注于持续输出，其上限高于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者。在低层钥石中使用起来可能更困难（这可能因队伍水平而异）。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgxMLzswMzswyMLjxMjNMAYssNzgxsNAmAAAAswMzMwmxMGzAAYmBLDA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUWX04EZZbpBUYEpzTdFWeeb7jbsMK-UWaBDHI+IakMtBSywwBDzLDzjKcijFWA-AAAA-GKOik0AIogBDxC-
```

:::

### 丛林守护者

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者大秘境天赋构建

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者构建专注于在拉怪开始时利用[[spell:205636]]增益（如[[spell:428544]]和[[spell:433831]]）进行快速爆发伤害。它比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者稍微容易上手，因此在不冲高层钥石时是推荐的构建。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgZbmlxyMmZWYZGjxMjFMAYAW2GLYamZZAAAAwmZmHYmBbGzYMDgZGAYA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04EZbpBUYEpzbebTd1NsMW2nU-UWaBDIS+ESo0IZCDbDM0wgh5BnHxCjO-AAAA-FGQYcgkQpBQQmF-
```

:::

1.

### 大秘境深度输出循环提示

在大秘境中最重要的事情之一是在每波小怪结束时积攒你的星界能量，以减少达到最大输出所需的预热时间。能够在一波接一波之间直接进入你的输出循环，在爆发击杀优先目标时非常有帮助。

大胆使用你所有的冷却技能。将你在地下城中的全部时间视为一场团队副本战斗。在团队副本中你从不希望浪费使用次数，在地下城中你也应该努力做到同样的事情。例外情况是偶尔的超大拉怪或重要的DPS竞速Boss。

使用[[spell:468743]]时，几乎要始终保持一层充能处于冷却中，以最大化在钥石中的使用次数。

3.1.

#### 艾露恩钦选者技巧

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者英雄天赋构建专注于基于奥术的法术，如[[spell:194153]]和[[spell:202770]]。星火术是你的主要伤害输出技能，像[[spell:383195]]和[[spell:114107]]这样的天赋为我们的主要填充法术增加了多个伤害乘数。

专注于通过施加持续性伤害效果快速进入每一波怪，然后将[[spell:202345]]与[[spell:191034]]叠加使用。

[[spell:429539]]配合[[spell:394121]]使你能够在每一波怪中都拥有[[spell:202770]]，有时甚至每波多次。这些较短的冷却技能一转好就使用，除非某波怪会在效果结束前死亡。

3.2.

#### 丛林守护者技巧

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者进行快速爆发伤害，并且进入标准DPS循环的预热时间也更短。[[spell:428544]]让你可以专注于施加[[spell:93402]]，然后直接进入日月之蚀或使用冷却技能。这意味着你可以[[spell:93402]]进入[[spell:205636]]然后[[spell:390378]]一波怪造成大量伤害。

[[spell:434249]]为你的主要冷却技能提供了一些灵活性，让你不必觉得每个技能一转好就必须使用，而是根据每个技能感觉最合适的时候使用。有时在一波怪结束时保留一个冷却技能，会让你在下一波怪中使用两次。

1.

### 功能技能与能力

### 打断、昏迷和控制

4.1.

#### 打断

[[spell:78675]]打断法术施放，并阻止同系法术在4秒内再次施放。日光术还充当全团沉默技能，在敌人留在光束中的整个8秒内沉默所有可被控制的目标。你可以选择为这个技能使用焦点宏，但由于该法术的冷却时间很长，你可能不需要。

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 日光术
```

这个宏会打断你的焦点目标（如果有），如果没有焦点目标则打断鼠标悬停目标，如果两者都没有则打断你的当前目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**.

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

4.2.

#### 眩晕与"打断"

[[spell:132469]]是平衡德鲁伊的标志性法术。它会将你前方的敌人按照施法方向击退。用它将敌人从坦克、你自己或特殊的小怪机制旁击退。

[[spell:102793]]是另一种类群控技能，可以帮助风筝小怪。此外，它对会跳跃的小怪效果极佳，常常能抵消伤害。它可以与[[spell:132469]]结合使用，作为紧急停止或聚怪手段。

[[spell:99]]可用于阻止一组敌人施法。它可以打断通常无法被沉默的非施法动作。

[[spell:339]]可用于定身巡逻怪或控制免疫控制的怪物群。在这些怪物群中，主要目标通常可以被定身，让你更容易处理剩余的敌人。此外，一些Boss的召唤物也可以被定身，这可能是有利的。

[[spell:102359]]可以定身一组敌人。有时可用于Boss的小众策略。

[[spell:33786]]可用于阻止治疗、作为最后手段的打断，或阻止危险的敌人增益效果。

### 其他功能

4.3.

#### 其他功能

[[spell:2908]]将驱散施加在敌人身上的所有狂暴增益效果。

[[spell:2782]]将驱散诅咒和毒素。

[[spell:29166]]最好在团队承受大量伤害的Boss战中使用。这将扩大你治疗者的法力池，使他们能够在需要时延长战斗时间。

[[spell:106898]]提供了一些额外的机动性，用于跳怪或更快地通过地下城。

[[spell:319454]]可以提供宝贵的治疗，尤其是在
[暴君](<https://www.wowhead.com/mythic-affix=9>) 周持续造成伤害的Boss身上。

1.

### 应对词缀

本节包含应对大秘境中每周萨拉塔斯主题词缀的快速提示：

### 词缀：升腾

5.1.

#### 平衡德鲁伊的升腾词缀应对

**萨拉塔斯的交易：升腾** 会周期性地以波次形式生成若干光球，需要在它们完成施法前以某种方式控制住。每成功阻止一个光球都会为队伍提供急速加成。

平衡德鲁伊可以等待所有光球生成后施放[[spell:99]]。这通常会打断所有光球。也可以使用[[spell:132469]]，但要小心不要把小怪击退到不利的位置。

### 词缀：虚缚

5.2.

#### 平衡德鲁伊的虚缚词缀应对

**萨拉塔斯的交易：虚缚** 会周期性地召唤一个大型的虚空大使，它将开始施放[[spell:462508]]。这个敌人 **必须** 在施法完成前被击杀以阻止它，否则它会为附近的敌人提供显著的减伤。如果成功阻止，队伍将获得大量的全能和冷却缩减。

它一生成就应该作为最高优先级集火目标。大胆使用你的冷却技能，如[[spell:194223]]、[[spell:205636]]和
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者，因为击杀该小怪后它们会更快地恢复冷却。

### 词缀：脉冲星

5.3.

#### 平衡德鲁伊的脉冲星词缀应对

**萨拉塔斯的交易：脉冲星** 会生成一个围绕每个玩家旋转的光球，需要由另一名玩家在光球消失前分担。每个光球将为队伍提供4%精通和2%吸血，可叠加，持续30秒。未被分担的光球会增加附近敌人的伤害输出，并降低他们受到的伤害。

对于这个机制没有平衡德鲁伊的专属提示。作为远程施法者，你有时可以通过站出去稍后分担光球来延长计时，因为每次叠加也会刷新增益效果的持续时间。

### 词缀：吞噬

5.4.

#### 平衡德鲁伊的吞噬词缀应对

**萨拉塔斯的交易：吞噬** 会对每名队伍成员施加一个减益效果，必须通过驱散或治疗来消除（但请记住这个 <em>不会</em>
吸收即将到来的治疗）。每驱散一个减益效果都会为队伍提供最大生命值和暴击，可叠加，持续30秒。任何被 <em>非</em>
清除的减益效果都会为附近的敌人恢复大量生命值。

作为拥有[[spell:2782]]的施法者，你应该总是能够驱散自己或其他人。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月12日：** 修复了流星风暴推荐。
- **2026年8月10日：** 已针对 12.1.0 补丁更新
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 更新了天赋推荐。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁更新
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月4日：** 已针对 11.2.0 补丁进行审阅
- **2025年6月15日：** 已针对 11.1.7 补丁进行审阅
- **2025年4月21日：** 已针对 11.1.5 补丁进行更新和审阅。
- **2025 年 2 月 24 日：** 已针对 11.0.1 补丁进行审阅和更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对 11.0.5 补丁天赋重做更新。
- **2024 年 10 月 7 日：** 添加了额外的词缀说明。
- **2024年9月9日：** 已针对第1赛季更新。
- **2024年7月19日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月19日：** 已针对 10.2.6 补丁进行审阅。调整了天赋推荐。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对 10.2.0 补丁更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月8日：** 新史诗钥石地下城赛季开启。
- **2023年5月1日：** 已针对 10.1.0 补丁中的新天赋更新。
- **2023年3月20日：** 更新了一些配装，并阐明了织星者和撼星之力的可行性。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月21日：** 添加了关于轨道打击和脉冲星的一些说明。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 更新了天赋推荐。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页面上，你将找到许多有用的宏和插件，让你在《魔兽世界》12.1.5版本中游玩平衡德鲁伊时更加轻松。

1.

### 最佳宏

平衡德鲁伊，以及德鲁伊总体来说，有一些相当不错的宏可以使用，以使你的游戏体验更流畅，或在紧张时刻加快使用你的功能性技能。

1.1.

#### 德鲁伊通用宏

1.1.1.

##### 复生

#### 复生宏

```wow-macro
#showtooltip 复生
/cast [@mouseover,help]复生;复生
```

这个宏会对你的鼠标悬停目标施放[[spell:20484]]，如果他们是友方玩家的话。否则，它会对你的当前目标施放复生。

1.1.2.

##### 清除腐蚀

#### 清除腐蚀宏

```wow-macro
#showtooltip 清除腐蚀
/cast [target=mouseover,help,nodead][target=target] 清除腐蚀
```

使用这个宏会对你的鼠标悬停目标施放[[spell:2782]]，如果他们是友方玩家且未死亡的话。否则，它会施放清除腐蚀。

1.2.

#### 平衡德鲁伊专用宏

此宏可按两次以进入[[spell:5487]]，随后施放[[spell:319454]]，为你提供持续30秒的额外生命值。若你点出了[[spell:449193]]天赋，可以再施放以退出形态，否则可正常换回[[spell:24858]]。

#### 枭兽形态切换

```wow-macro
#showtooltip 德鲁伊长者之唤
/cast [nostance:1] 熊形态
/cast 德鲁伊长者之唤
```

此宏会将你置于枭兽形态中，但现在允许你双击以退出枭兽形态。根据你需要施放的技能，你可能需要设置一个按键绑定来回到人形态。

#### 枭兽形态切换

```wow-macro
#showtooltip
/cancelform [nostance:4]
/dismount [nostance:4]
/cast [nostance:4] 枭兽形态
```

使用[[spell:391528]]时，你希望在引导结束后立即开始施法，以尽量减少空档时间。使用此插件，你就可以继续快速按下你的下一个法术。我只是以[[spell:78674]]为例。

#### 禁止引导星涌术

```wow-macro
/stopmacro [channeling:Convoke the Spirits]
/cast 星涌术
```

下面的宏可以根据任何额外的非公共冷却技能进行修改。

#### 超凡之盟 + 饰品

```wow-macro
#showtooltip 超凡之盟
/use [Insert trinket name here]
/cast 狂暴
/cast 超凡之盟
```

以下是一些你可以使用的功能型鼠标悬停宏。

#### 鼠标悬停激活

```wow-macro
#showtooltip 激活
/cast [@mouseover,exists] 激活
```

#### 鼠标悬停安抚

```wow-macro
#showtooltip 安抚
/cast [@mouseover,harm,nodead][] 安抚
```

#### 鼠标悬停休眠

```wow-macro
#showtooltip 休眠
/cast [@mouseover,harm,nodead][] 休眠
```

#### 鼠标悬停飓风术

```wow-macro
#showtooltip 旋风
/cast [@mouseover,harm,nodead][] 旋风
```

#### 鼠标悬停复生

```wow-macro
#showtooltip 复生
/cast [@mouseover,exists] 复生
```

光标宏可以为你节省一次额外的点击，并将特定法术放置在你的光标处。

#### 光标自然之力

```wow-macro
#showtooltip 自然之力
/cast [@cursor] 自然之力
```

#### 光标乌索尔旋风

```wow-macro
#showtooltip 乌索尔旋风
/cast [@cursor] 乌索尔旋风
```

#### 光标超凡之盟

```wow-macro
#showtooltip 超凡之盟
/cast [@cursor] 超凡之盟
```

接下来的两个宏非常适合在不切换主目标的情况下，通过单位框架对新目标施加多目标持续伤害。

#### 鼠标悬停月火术

```wow-macro
#showtooltip 月火术
/cast [@mouseover,harm,nodead][@target,harm,nodead]月火术
```

#### 鼠标悬停日火术

```wow-macro
#showtooltip 阳炎术
/cast [@mouseover,harm,nodead][@target,harm,nodead]阳炎术
```

1.

### 最佳插件

2.1.

#### 德鲁伊通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.5.

#### 平衡德鲁伊专用插件

对于至暗之夜资料片，我们没有特定的插件推荐。重要的是你需要有办法紧密追踪你的增益和技能。你可以使用游戏内置的冷却追踪器来实现。

你应该追踪你的星界能量、日蚀和[[spell:194223]]增益，以及目标身上的持续伤害效果。你还应该追踪任何你需要的冷却或增益。通常最好将这些追踪显示在屏幕下方中央，位于你和目标的生命值条之间，但你应该选择对你来说最舒适自然的方式。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 添加了野性之心宏。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁更新
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对 11.2.5 补丁进行审阅
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 已针对 11.1.7 补丁进行审阅
- **2025年4月21日：** 已针对 11.1.5 补丁进行更新和审阅。
- **2025 年 2 月 24 日：** 已针对 11.1.0 补丁进行审阅。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对第一赛季进行审阅。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
