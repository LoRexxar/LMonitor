## 专精概览

Welcome to our Survival Hunter guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Survival Hunter in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Survival Mythic+ Resources

[NEW! Top Survival Talent Builds](<https://raider.io/specs/survival-hunter/talents>)

[Top Survival Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/hunter/survival>)

[Survival Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=hunter--survival>)

[Popular Survival Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=hunter--survival>)

1.

### Survival Hunter Overview

Survival Hunter is a highly flexible Melee DPS spec that can also do solid

damage from ranged. It is a jack-of-all-trades melee with powerful single-target

and AoE options, often within the same build. Survival Hunter got a massive

rework in Midnight that has massively improved its stock, and there is no better

time to give it a try!

Flexible, but Nothing Special

Survival has average damage in all situations, and good flexibility
that allows it to do decent single-target damage in its AoE builds,
and vice versa. It also has a very
short cooldown, which means it is able to condense its burst into
very small windows, needing little to no ramp time.

Good Cleave, Average Tuning

Survival has good flexibility in the Raid, with the ability to alter
its burst profile and do decent single-target and AoE in the same
build. It gives up very little single-target damage to do its AoE,
and its cleave on low target counts is good. Melee is not fantastic
in Season 2, but some are required, and Survival is a good choice for
that role. One Hunter is required in every Raid for

[[spell:257284]]

,
and Survival is a good choice for that role as well.

Jack of All Trades

Survival is a well-rounded DPS in Mythic+, offering good damage on
virtually any pull or boss or situation. It has no specific weakness, nor does
it have a specific niche in which it massively excels above all other specs.
It is a little better on small pulls than on very large ones.
Its damage profile is right in the middle with a 1-minute cooldown cadence,
making it moderately bursty, but not especially reliant on its burst.

Unremarkable

We bring mediocre utility to the
group. A 1-minute stun/AoE stop in

[[spell:19577]]

,
and a regular cooldown Melee kick. The flexibility and cooldown of our AoE stops are
mediocre.

[[spell:257284]]

is mandatory in raids, but it is not particularly strong in Mythic+.

Strong Active Defenses, Weak Passives

Survival has access to several strong active defensive abilities, allowing it
to mitigate heavy damage effectively. However, its passive defenses are
relatively weak, making it reliant on timing and proper use of cooldowns to
survive in high-damage situations. It suffers in "rot" damage situations, with
constantly ticking hard DoTs. As a result, Hunters often require more external
healing than other classes, and the skill ceiling is relatively high, while the
skill floor is relatively low. It has 6% extra
damage taken reduction compared to the other Hunter specs, making it true to its
name as the most survivable of the Hunter specs.

Very Good Mobility

Survival has excellent mobility, with all the same kit as Marksmanship and
Beast Mastery, no stationary casts, and even

[[spell:1261193]]

, a huge
chunk of our damage, has a much longer range than pure melee range.

[[spell:186289]]

lets us do almost all of our damage from range
for significant periods at a time,

[[spell:259495]]

is a ranged AoE,
and

[[spell:1250646]]

charges us to the target, and when we do need to
get to melee, we have

[[spell:190925]]

to help us get there.

2.

### Survival Hunter in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 adds two new pieces of endgame content to Season 2. The

Unbinding of Kith'ix is a new raid encounter, and the Labyrinth of Kindo'jan

is a new Mega-Delve. Our guides to both are linked below.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

Patch 12.1.5 is a mid-season content patch. It also brings

[[item:280562]], a new currency for upgrading your Weapon,

Trinkets and Neck up to iLvl 340. Everything else that is new is in the

Patch Hub below.

2.3.

#### Class Changes

Survival has no meaningful class changes in Patch 12.1.5, and the spec

plays the same as it did in Patch 12.1.

On our [Gear](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>) page, the

Catalyzed [[item:281238]] from the Kith'ix raid are our

new BiS Gloves, and there is a new list of what to spend your first

[[item:280562]] on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_wildfirebomb_shrapnel.jpg>) Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Changes

Patch 12.1 brings a fair bit of content outside of the new Season.

There is a new zone to explore, new rares and treasures to hunt down, and

plenty of new housing and transmog rewards to collect. Blizzard has also

updated a number of existing systems and added quality of life

improvements.

:::details Show Patch 12.1 Class ChangesHide Patch 12.1 Class Changes
2.5.

#### Class Changes

Survival leans much more strongly on Bombs now, which has caused Sentinel to

leap ahead for most content. The gameplay loop of the spec is similar to before,

however.

The [Omnium Folio](<https://www.icy-veins.com/wow/omnium-folio-guide>) borrowed-power system carries into Season 2, and it

affects both your talent choices and your gear. You can find the details on our

dedicated [Talents](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>) and

[Gear](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>) Guides.

- New Talent: [[spell:1253053]]. [[spell:186270]]/Swipe and
  
    [[spell:259489]] gain 10% increased critical strike chance and 10%
  
    increased critical damage per point.
- New Talent: [[spell:389880]]. [[spell:259495]] damage, critical
  
    strike chance, and critical damage all increased by 15%.
- [[spell:1251592]] has been removed, and references to it have been
  
    removed from several talents.
- [[spell:459729]] has been removed.
- [[spell:1252943]] now gives [[spell:259495]] a chance to
  
    imbue your weapon with flame, so your and your pet's auto-attacks deal extra
  
    Fire damage for 10 seconds.
- [[spell:459843]] now makes [[spell:1261193]] increase
  
    [[spell:259495]]'s cooldown recovery rate by 60% for 8 seconds. It is
  
    also now tracked in the Cooldown Manager.
- [[spell:1261229]] now reduces [[spell:259495]]'s cooldown by 3
  
    seconds when your [[spell:1261193]] damages one or more enemies.
- [[spell:378934]] now increases your Agility by 3% (was 2%), plus an
  
    additional 1% (was 2%) while dual-wielding.
- [[spell:1272154]] has been moved up to an easier to access location in
  
    the talent tree.
- **Pack Leader:** [[spell:472639]] now lasts for 1 minute (was 20
  
    seconds), and is cancelled when starting a raid encounter or Mythic+
  
    dungeon.
- **Sentinel:** [[spell:1264781]] has been updated. Your auto-attacks
  
    now have a very high chance to grant 3 Focus to you and your pet, instead of
  
    granting 1 Focus per auto-attack, which removes the previous bias toward
  
    dual-wielding the fastest weapons.
- **Sentinel:** [[spell:1253825]] now grants 6 seconds of
  
    [[spell:259495]] cooldown reduction when applying [[spell:1253601]]
  
    (was 4 seconds).
- **Sentinel:** [[spell:1253601]] duration increased to 16 seconds
  
    (was 12 seconds).
- **Sentinel:** [[spell:1253807]] has been redesigned to a flat 5%
  
    increase to Fire damage dealt.
- **Sentinel:** [[spell:1253892]] no longer increases stealth
  
    detection radius while using [[spell:199483]].
- **Tier Set:** **2-Set:** [[spell:259388]] increases the damage
  
    of [[spell:259495]] by 10%. **4-Set:** Each blast of
  
    [[spell:1261193]] increases the duration of [[spell:259388]] by 1
  
    second, and [[spell:259388]] effects are increased by 10%.
- **Bug Fixes:** [[spell:1259003]] no longer applies
  
    [[spell:1253601]] to a target other than your current one, and if you
  
    have no target it picks one that Raptor Swipe hits. [[spell:1259003]] no
  
    longer benefits from [[spell:1253053]] twice, [[spell:259495]] no longer
  
    benefits from [[spell:389880]] twice, and [[spell:263135]] no
  
    longer affects some ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader summons twice. [[spell:459939]]
  
    is now applied properly by periodic effects from you, your pet and your
  
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader summons.

:::

:::

### Midnight   Changes Overview

2.6.

#### Survival Hunter Changes in Midnight

The Midnight Expansion brings huge changes for all Hunter specs, primarily

focused on streamlining and simplifying aspects of the kit.

2.6.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel

- Core Mechanic: Consuming [[spell:260285]] has a chance to proc
  
  [[spell:1253601]] on the target, causing your [[spell:259495]]
  
  to deal increased damage to your target and reducing its cooldown by 6
  
  sec.
- Maximum Focus increased to 125.
- The chance of generating [[spell:1253601]] procs is 10% higher
  
  during [[spell:1250646]].
- After activating [[spell:1250646]], the Takedown button becomes
  
  [[spell:1264902]] which sends a glowy Chakram that deals heavy AoE
  
  damage as it bounces between enemies. Choice nodes can cause this Chakram to
  
  reduce the cooldown of [[spell:259495]] by 10 sec and trigger
  
  [[spell:1253601]].

2.6.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader

- The Bear has been nerfed by 40%, making it more balanced relative to the
  
  other Beasts. In the past, we often had to pay special attention to optimizing
  
  around the Bear, but now, the Beasts are much closer in terms of power.
- Our TWW S3 4PC mechanic, [[spell:201430]], is back, but it only
  
  triggers from your first [[spell:259489]] after activating
  
  [[spell:1250646]]. Which means that every minute, for around 8 seconds,
  
  you best hope that the mobs are not either moving, on a ledge, above you, below
  
  you, to the side of you, or behind you.

2.7.

#### DPS & Gameplay Changes

- [[spell:193265]] replaces [[spell:185358]] as a sort of weak
  
  filler. It may only really be used for pulling things and is more flavor than it
  
  is a real rotational button.
- [[spell:1250646]] is a new 1:30 (baseline) cooldown that replaces and
  
  aims to take the best parts of [[spell:360952]] and
  
  [[spell:269751]] in one ability. It deals heavy initial damage, gives
  
  you 50 Focus, charges you to the target, and then increases you and your pet's
  
  damage done by 20% for 8 sec. There are talents that can make this do increased
  
  and AoE damage and improve attack speed for its duration, or reduce its cooldown
  
  to 1:15/1:00.
- [[spell:259495]] now costs 10 Focus.
- [[spell:1251592]] is a new 1-minute cooldown ability that throws
  
  down a firebomb of sorts on the ground that deals damage to targets within.
  
  Talents can give it an additional charge.
- [[spell:203415]] has been redesigned to [[spell:1261193]].
  
  Mechanically almost identical, but it fires shotgun blasts instead of hitting
  
  very fast with your Spear, and it has a far longer range. It has a 1-minute
  
  cooldown. There are talents that significantly increase its single-target,
  
  dropping off its damage with more targets.
- The abilities [[spell:212436]], [[spell:269751]],
  
  [[spell:259387]], [[spell:212431]], [[spell:53351]],
  
  [[spell:360966]], and [[spell:360952]] are gone.
- The passive talents [[spell:269737]], [[spell:389880]],
  
  [[spell:1217434]], [[spell:459741]], [[spell:1217429]],
  
  [[spell:459828]], [[spell:378951]],
  
  [[spell:265895]], and [[spell:268501]] are gone.

2.8.

#### Apex Talents

Midnight introduces new Apex Talents, unlocked between Level 80 and 90.

Survival gets:

1. [[spell:1259003]]
2. [[spell:1259017]]
3. [[spell:1259019]]

They cause every second [[spell:186270]] to turn itself into

[[spell:1259003]], dealing increased damage, and causing it to hit multiple

targets as well. Very simple and passive, yet very powerful.

2.9.

#### Survivability Changes

- Hunters have +2% higher max HP than previously.
- [[spell:109304]]'s cooldown is now a 1-minute flat, instead of variable
  
  (and often lower).
- [[spell:186265]]'s cooldown is now 2:00 with talents, down from
  
  2:30.
- [[spell:186265]] can now be a 50% damage reduction with talents,
  
  up from 30%.
- [[spell:53480]] is now an external defensive that can be used on
  
  yourself or any friendly target to reduce their damage taken by 15% for 10 sec,
  
  but 50% of their damage taken will be taken by your pet. It will end prematurely
  
  if your pet drops below 25% health.
- [[spell:388035]] is now 3% passive damage reduction, instead of
  
  being an active defensive cooldown.

2.10.

#### Utility Changes

- [[spell:257284]] is now a universal 3% damage increase against a
  
  single-target. This essentially guarantees Hunter a raid spot in every raid. It
  
  is also a boost to the group in Mythic+, though it is much less potent
  
  there.
- [[spell:187707]] now spell-locks the target for 5 seconds, up from
  
  3.
- [[spell:187650]] can now slow the target by 70% for 4 sec after the
  
  trap breaks.
- [[spell:19577]] is now our sole stun/stop. A choice node either
  
  reduces its cooldown to 40 sec, or makes it a 1-second AoE stun.
  
  [[spell:462033]], [[spell:236776]], and [[spell:186387]]
  
  are all gone.
- The slows from [[spell:195645]] and [[spell:5116]] are 25% and
  
  10% stronger, respectively.
- [[spell:472729]] is now a Class Tree node and not attached to
  
  the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Hero Talent. It is a choice node with
  
  [[spell:459460]], which extends [[spell:109248]]'s stun by
  
  1 sec.
- [[spell:459466]] is gone.
- [[spell:213691]] is gone.
- [[spell:459533]] is gone.
- [[spell:321468]] is gone.

2.11.

#### Miscellaneous Changes

- [[spell:186257]]'s initial "super" speed burst is now twice as
  
  long with talents.
- [[spell:53351]] is gone and is a Marksmanship-tree exclusive.
- Successfully kicking with [[spell:187707]] now
  
  grants 30 Focus, up from 10, but soothing/purging with
  
  [[spell:19801]] no longer grants Focus.

Overall, we are gaining defensiveness and mobility, while in the utility

department, we are losing some things (like the ability to move mobs) but

gaining others (stronger Mark, streamlined AoE stun, stronger kick and more

Focus return on kicking). We think the changes are broadly positive!

3.

### Basics of Survival Hunter Gameplay

Survival Hunter is a spec about buff and cooldown management.

Between most abilities, you want to weave a [[spell:259489]] in

for the [[spell:260285]] stacks it generates. The goal is to have Tip of

the Spear cover as many of your non-Kill Command abilities as possible, such as

[[spell:259495]] and [[spell:186270]].

The rotation is very dynamic, fast-paced, and busy. The best Survival Hunters

know the spec's priorities like the back of their hand and are always able to

make the correct ability decision on the fly, even when many mechanics are vying

for their attention simultaneously. To break things down further, the bulleted list 

below describes the backbone of the specialization.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_bossmannoroth_glaivethrust.jpg>) **Tip Every Ability**  
  
  
    Every single ability that you cast besides [[spell:259489]] must
  
    be cast with [[spell:260285]] active. The only exception, which is
  
    exceedingly rare, is that it is okay to cast a [[spell:186270]] (not
  
    Raptor Swipe) without Tip if you have no Tip or [[spell:259489]]
  
    charges left. Striking without Tip is better than sitting AFK.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_killcommand.jpg>) **Do Not Waste Tip Stacks**  
  
  
    Never cast [[spell:259489]] if you already have more than one
  
    [[spell:260285]] stack, as this wastes Tip stack generation. It is a
  
    common trap to be so paranoid about Tipping every ability that you overcommit
  
    to casting [[spell:259489]] when it is not needed, costing you in
  
    the long run.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_raptorstrike.jpg>) **Always be Casting**  
  
  
    Casting as many abilities as possible matters more than pressing the perfect
  
    button every time, and dead time is the single biggest thing holding most
  
    players back from their DPS goals.

4.

### How to Gear Up as a Survival Hunter

Our dedicated Survival gearing page covers Season 2 gear from your

first upgrades through to the full best-in-slot list. We still recommend

simming yourself for the ideal answer. Once you've picked up some gear, you'll

need the appropriate consumables, gems, and enchants to go with those new

items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **30 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Fixed the Chest tooltips showing two Venomcursed effects.
- **30 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** The Sentinel Single-Target build now takes Wallop over Bloody Claws (+0.15%).
- **15 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added a Raid AoE/Cleave build, which is now our recommendation for any raid boss with adds or a second target.
- **07 Sep. 2026 (this page):** Lowered the Raid rating to 2.5.
- **04 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Moved the Font of Venomous Rage to S Tier in the Trinket Rankings.
- **30 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Sentinel single-target priority for Boomstick and Wildfire Bomb, and its Twin Fangs opener, which now opens with Boomstick to build Mongoose Fury stacks prior to Takedown.
- **29 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Weapon enchant to Rite of the Hash'ey.
- **29 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated the Weapon enchant to Rite of the Hash'ey.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Weapon enchant to Berserker's Rage.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Corrected the Missive for the crafted Weapon to the Thalassian Missive of the Feverflare.
- **24 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated the Weapon enchant to Berserker's Rage.
- **22 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Added a note on crafting Legs.
- **21 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the crafted Bracers and Belt to use Arcanoweave Lining, as Adorned Fang was oversimming.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Nebulous Voidcore bonus roll priorities.
- **18 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the Utility Talents for Raid builds.
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Trinket tier list, and corrected the note on Gebbo's Bottomless Bag.
- **17 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** The Omnium Folio setup now takes Void-Tainted Shell over Self-Mending.
- **16 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Reworked the crafting advice, corrected the Voracious Heart of Ula'tek and Gebbo's Bottomless Bag entries in the raid-items list, and added start of season Voidcore and Crest advice.
- **16 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Sentinel AoE opener, which now opens with Takedown when Twin Fangs is talented.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Trinket tier list following the latest tuning.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Mythic+ BiS weapons to two Sharpened Lightwood Slashers from Altar of Fangs, and added a section on two-handed and dual wield weapons.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Nebulous Voidcore bonus roll priorities and noted that Maze-roa, Warlord's Fury is not currently on the Survival loot table.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Removed the note about Maze-roa, Warlord's Fury not being on the Survival loot table, as it has now been added.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Raid BiS Gloves to the Catalyzed Grips of Swirling Fury from Nymrissa Wavecaller.
- **12 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Added Catalyst and Great Vault FAQs and a socket section, fixed Catalyst drop locations, and updated sources of the Raid BiS Helm and Gloves.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Delve builds now take Emergency Salve over Wilderness Medicine.
- **11 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated the Pack Leader build, moving a point from Sweeping Spear into Razor Edge.
- **11 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Clarified Wildfire Bomb target selection in the Sentinel AoE priority.
- **11 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated Pack Leader builds. Single-Target swaps Shellshock for Twin Fangs, and Mythic+ moves a point from Sweeping Spear into Razor Edge.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **16 Jul. 2026 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated Heirloom stat advice and leveling tips.
- **16 Jul. 2026 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Corrected Fortitude of the Bear and Updraft descriptions, and updated expansion references.
- **16 Jul. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Added Bracers gems and fixed BiS Boots rows.
- **16 Jul. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Fixed enchant tooltip links and updated consumable notes.
- **16 Jul. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Clarified utility and affix notes.
- **16 Jul. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Corrected Takedown's duration to 8 seconds and Stampede's length to 30 yards.
- **16 Jul. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated Omnium Folio Week 4 rune and Hero Talent guidance.
- **16 Jul. 2026 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Corrected Exhilaration's cooldown and Feign Death's description, added Hatchet Toss and Aspect of the Eagle to the glossary, and alphabetized the ability tables.
- **16 Jul. 2026 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Removed Moonlight Chakram from the beginner priority list and clarified pet advice.
- **16 Jul. 2026 (this page):** Clarified Sentinel's Mark and Moonlight Chakram cooldown reduction values.
- **17 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated recommended week 1 Folio Rune based on real-world data trumping sims.
- **16 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Clarified Weapon Enchant choice.
- **16 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Microscopic (+0.1%) M+ Build change.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **21 May 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Fixed issue where Twin Fangs rotation logic was the wrong way around.
- **28 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added extra Wildfire Bomb conditions for AoE and single-target.
- **28 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the utility talents for Pack Leader to choose Slicked Shoes over Masterful Call. Small Class Talent Utility pick changes for M+.
- **27 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated and clarified the wording on Raptor Strike/Swipe tipping.
- **25 Apr. 2026 (this page):** Updated Survival performance evaluation.
- **23 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated Crafting recommendations in preparation for Patch 12.0.7.
- **23 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated Ring Enchant.
- **23 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Opener updates.
- **21 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Expanded on preparation for Takedown windows. Opener update.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **08 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** BiS List and Trinket Tier List update.
- **31 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** BiS List Updates.
- **27 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Added info on dual wield Enchants.
- **25 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Expanded on weapon crafting across Hero Talents. Updated Mythic+ Gear BiS List
- **25 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added note on Sentinel bug and updated recommended Hero Talent/builds.
- **22 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Pack Leader Single-Target Opener.
- **19 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated to recommend Leech Enchants over Avoidance.
- **18 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Sentinel Single-Target Opener with Twin Fangs slightly.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **17 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Fix error in Sentinel M+ build.
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Sentinel Opener update.
- **17 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Fix error in Sentinel M+ build.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **04 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated Crafting recommendation for endgame.
- **04 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Added information about some old Sharpening/Weightstones from The Burning Crusade that are optimal in Midnight.
- **01 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Pack Leader Mythic+ Build update.
- **01 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Pack Leader Mythic+ Build update.
- **28 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Survival Single-Target Talent update.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Added Pack Leader Weapons.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated Mythic+ Talent Recommendation.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated Mythic+ Talent Recommendation.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 (this page):** Updated for Midnight 12.0.1.
- **12 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Added note on 2-Hand vs Dual Wielding.
- **12 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated Mythic+ Build Recommendation.
- **12 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Pack Leader Single-Target Rotation significantly.
- **12 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated Hero Talent recommendation across the board.
- **11 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added Hatchet Toss mention to the Pack Leader AoE Rotation.
- **11 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated note on Hero Talents for Mythic+. No actual recommendation change, just giving more context.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated Stat Diminishing Returns values for Level 80.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated Talent Builds for the upcoming 12.0.1 changes.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small rotational updates for the upcoming Patch 12.0.1 changes.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated Talent Builds for the upcoming 12.0.1 changes.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **04 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Small update to Sentinel M+ Build.
- **04 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Small update to Sentinel M+ Build.
- **31 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated Mythic+ Build. Dummy testing suggests identical-ish AoE and slightly more single-target with a button removed from the rotation and a 1-minute cooldown profile that matches the single-target build.
- **21 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Sentinel M+ Build Update.
- **20 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** AoE Rotation improvements.
- **19 Jan. 2026 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **04 Sep. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated recommended M+ Hero Talent to Sentinel after simulation tool fixes.
- **04 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated recommended M+ Hero Talent to Sentinel after simulation tool fixes.
- **02 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Trinket Tier List and BiS updates.
- **31 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Re-organized M+ Talent Picks slightly.
- **16 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated Trinket Tier List for tuning.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **26 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated Titan Disc recommendation.
- **23 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Titan Disc recommendation based on the latest hotfixes.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **10 May 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the wording/Dinar recommendation status for House of Cards and Signet slightly.
- **09 May 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated Corruption Enchants & Puzzling Cartel Chip Dinar section.
- **09 May 2025 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated Corruption Enchants section.
- **09 May 2025 (this page):** Updated Best Spec section.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Add list of Dinar-purchasable items.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Added Corruption Enchants information.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **30 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small opener update.
- **29 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the position of Eye of Kezan in the Mythic+ Trinket Tier List.
- **25 Mar. 2025 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for the March 25 hotfixes.
- **25 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for March 25 Updates.
- **25 Mar. 2025 (this page):** Updated for March 25 Updates.
- **18 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated the recommended MDT Sim/Mythic+ Simulation Route Pastebin.
- **16 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Removed outdated mention of Serpent Sting multidotting.
- **14 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated Amorphous Relic placement after buffs.
- **07 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated Weapon Enchant.
- **07 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Updated builds based on real-world data.
- **04 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **21 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Revisited many talent recommendations for Mythic.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for the Cyrce's Circlet now going to Item Level 658.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **23 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small single-target opener clarifications and corrections.
- **20 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added more detailed explanations of the "Why" of several rotational nuances.
- **18 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Expanded on the AoE rotation and added more detail.
- **15 Nov. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated Weapon Enchant.
- **13 Nov. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated the Mythic+ Sentinel Build to account for Ruthless Marauder previously having been undersimming.
- **13 Nov. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the Mythic+ Sentinel Build to account for Ruthless Marauder previously having been undersimming.
- **06 Nov. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Added M+ builds and added a note of a good Talent Swap for beginners.
- **06 Nov. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added M+ builds and added a note of a good Talent Swap for beginners.
- **30 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 (this page):** Updated Best Spec Section for hotfixes.
- **26 Oct. 2024 (this page):** Reinstated the Best Spec section.
- **25 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the AoE rotations, simplifying them in the process.
- **23 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated AoE Opener.
- **22 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 (this page):** Reviewed for Patch 11.0.5.
- **08 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for October 8th Hotfixes.
- **08 Oct. 2024 (this page):** Updated the "Best Hunter Spec" section for the updated October 8th Hotfixes.
- **05 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Expanded on Weapon Enchant choices.
- **02 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the BiS Trinkets for pure single-target.
- **02 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added more specific Trinket usage information.
- **29 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Recommend an alternative single-target build by default.
- **29 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added an alternative single-target build.
- **27 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated Ara-Kara Tips.
- **21 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated Stat Priority.
- **20 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the Trinket Tier List and Best Trinkets after re-evaluations and simulation tools maturing.
- **13 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Added note about double-Dawnthread Lining not working and how to fix it.
- **13 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Re-visited the best builds on every boss after Heroic experience and made some changes.
- **13 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated and clarified some tips.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 (this page):** Preliminary update for The War Within Season 1.
- **27 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Added a note about Crafted gear to the Pre-Season BiS List.
- **27 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the "short-term burst" AoE Build to be default for pre-season.
- **26 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small, various fixes, mainly to pure ST build opener.
- **24 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added a recommended Delves build.
- **23 Aug. 2024 (this page):** Re-introduced a section talking about the Best Hunter Specs in the War Within.
- **22 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for The War Within.
- **22 Aug. 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for The War Within.
- **22 Aug. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for The War Within.
- **22 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **22 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for The War Within.
- **22 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **22 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for The War Within.
- **22 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **22 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **22 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for The War Within.
- **22 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for The War Within.
- **22 Aug. 2024 (this page):** Updated for The War Within.
- **30 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the rotations and openers with small optimizations, primarily to do with holding Explosive Shot for Spearhead/Coordinated Assault.
- **29 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the single-target opener to apply Serpent Sting early on, for Outland Venom.
- **28 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Implemented rotational DPS optimizations from the Survival Hunter Discord.
- **26 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added Talent Builds for players using the Season 3 Tier Set, which is optimal.
- **25 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated the BiS Trinkets, Crafting List, BiS List, and more.
- **25 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated and simplified the rotation.
- **25 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the M+ Build in light of Bloody Claws not working in pre-patch as it does on Beta.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **26 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/survival-hunter-the-war-within-pve-guide>)):** Updated for the June 25th changes.
- **18 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/survival-hunter-the-war-within-pve-guide>)):** Page added.
- **29 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** Updated Tinker Gem recommendations.
- **20 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** Updated Tinker Gem rankings based on live server power levels.
- **17 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** Updated Tinker and Cogwheel Gem recommendations in light of recent changes and new information.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** Page added.
- **12 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Added Misdirection to the M+ Build by default.
- **12 May 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added Misdirection to the M+ Build by default.
- **11 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Added section on how to survive the highest of keys with Tank Trinkets and Embellishments.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **03 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Added tip for Chargath in Neltharus.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Updated for Patch 10.2.6.
- **29 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated the default M+ build to a No-CD Build.
- **29 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the default M+ build to a No-CD Build.
- **29 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated the default M+ build to a No-CD Build.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **18 Dec. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Added Mythic+ Dungeon Tips.
- **28 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated the Mythic+ Talent Build.
- **28 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the ST and Mythic+ Talent Builds.
- **12 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Added a T30 Mythic+ Build.
- **12 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added missing Wildfire Bomb line to the ST rotation.
- **12 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added a T30 Mythic+ Build.
- **09 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Small change to the Mythic+ build, for more single-target.
- **09 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Small change to the Mythic+ build, for more single-target.
- **07 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Fixed an issue where Wildfire Bomb would not appear in the ST rotation with the AoE build.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Patch 10.2
- **06 Nov. 2023 (this page):** Updated for Patch 10.2
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Restructured the page and updated for Patch 10.1.7
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Reviewed for Patch 10.1.7
- **17 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the AoE rotation and opener significantly in light of recent APL updates, and added on-use Trinkets to the rotation.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **29 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Death Chakram line in the single-target rotation.
- **23 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated the Mythic+ Builds in light of recent APL changes.
- **23 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the AoE and AoE No CD Builds in light of recent APL changes.
- **16 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Significant rotational overhaul with new checkboxes, a new feature that lets you select checkbox presets, and a variety of changes to both the single-target and AoE rotations.
- **15 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Removed the top line of the AoE Rotation, thereby reducing the priority of maintaining the 4PC Debuff on AoE.
- **13 Jun. 2023 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Removed the FoTE Bloodseeker Macro as the bug was fixed and it is no longer needed.
- **13 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Removed the FoTE Bloodseeker Macro as the bug was fixed and it is no longer needed.
- **13 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated the Easy Mode rotation and builds to be easier to follow.
- **03 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the AoE opener slightly.
- **03 Jun. 2023 (this page):** Updated the blurb about spec viability, and updated the Strengths and Weaknesses.
- **02 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Significant updates to the talent builds, both in terms of what is recommended for Fortified/Tyrannical, and the talent builds in themselves.
- **27 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Added separate Fortified, Tyrannical, and Cooldown Builds for Survival Mythic+.
- **26 May 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the AoE opener significantly to better reflect the AoE rotation change.
- **26 May 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added a Bombardier and Spearhead Build.
- **25 May 2023 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Added a cancelaura Bloodseeker Macro for Fury of the Eagle.
- **25 May 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Important AoE Rotation Update, and updated the default checkboxes, and added information about an important Fury of the Eagle Macro.
- **22 May 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Leg Enchant, as it was found that the Lambent Armor Kit does not provide Stamina as it was assumed.
- **19 May 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the layout of the page.
- **13 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated the recommended AoE/Mythic+ Talents.
- **13 May 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small wording change in the 4PC Rotation Line.
- **13 May 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended AoE/Mythic+ Talents.
- **12 May 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended food and Leg enchant.
- **02 May 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Weapon Rune/Temporary Enchant.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.
- **01 May 2023 (this page):** Reviewed for Patch 10.1.
- **11 Apr. 2023 (this page):** Updated the spec rankings to account for new nerfs.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Gemstones after sim updates, and the discovery of a new, powerful combination.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Yet another update to the recommended Gemstones based on a slew of hotfixes.
- **21 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated the Onyx Annulet Information in light of the March 21st buff.
- **21 Mar. 2023 (this page):** Updated with spec rankings for different types of damage.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/survival-hunter-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated the recommended M+ Build.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small rotational fixes.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended M+ build.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **08 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the recommendation status of Lunge, and re-checked Talents for correctness in light of recent buffs.
- **06 Jan. 2023 ([pets page](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** Added page.
- **04 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Phial.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommendation and description of the optimal Flasks/Phials.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Rotational update for the Set Bonus.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Harpoon's role in the rotation.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Updated for Dragonflight Season 1.
- **30 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated mentions of Kill Command having 2 charges in the priority to "cap charges" to encompass both situations with and without Alpha Predator.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **29 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated the Venthyr Mythic+ Build Talents.
- **29 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended low-target AoE Venthyr build further.
- **27 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended low-target AoE build and fixed an issue with the string.
- **26 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/survival-hunter-best-covenants-soulbinds-and-conduits>)):** Updated descriptions.
- **26 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Added a Kyrian build that is superior for heavy AoE keys.
- **26 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Added a Kyrian-based Talent Build that emphasizes strong burst, primarily for high-target Mythic+ keys.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/survival-hunter-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/survival-hunter-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/survival-hunter-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/survival-hunter-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** Updated thoughts on all of the Covenant-specific Legendaries, and added the July 13th Hunter Buffs to the changes.
- **10 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** Added information about the Venthyr-specific Legendary.
- **12 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** Added information about 4 new Covenant-specific Legendaries and updated some of the "highlighted" Soulbind Abilities.
- **03 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** Page created with initial information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **13 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-the-eternal-palace-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **25 Oct. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for Mythic TEP Bosses for Survival. Thank you to Thyminde for providing most of the tips!.
- **23 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for more bosses.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **13 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Added Survival tips for Uu'nat.
- **01 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Added Survival tips for The Restless Cabal.
- **14 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Crucible of Storms and no changes are necessary.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Crucible of Storms and no changes are necessary.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added boss tips for Survival Hunter in Battle of Dazar'alor.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** Added content to the page.
- **12 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** Page added (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Survival Hunter leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Hunter leveling guide](<https://www.icy-veins.com/wow/hunter-leveling-guide>).

1.

### Survival Hunter Leveling Guide for Midnight

Survival Hunter, thanks to being able to use its pet as a tank

to some extent, is good for both questing and dungeon leveling. Survival has the

best

survivability of the Hunter Specs, but because its pet is not as sturdy as a

[Beast Mastery Hunter](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-guide>)'s, it still cannot handle the same kind of massive

pulls.

Grab a Ferocity pet and [[spell:34477]], and activate it before tagging

as many mobs as possible, and watch the mobs

flock to your pet. Then, take out the mobs with [[spell:259495]].

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the highest item

level. The only exception to this rule is if you have a Ring or Necklace with a

slightly lower item level, but two secondary stats on it instead of one.

When using Heirloom items, and when choosing between other pieces of gear, we

recommend prioritizing Mastery, then Critical Strike, wherever possible.

1.2.

#### Useful Leveling Consumables for Midnight

When Leveling up from 80-90 in the Midnight Expansion in particular, there

are a lot of consumables that can help ease the process, aside from the

"regular" PvE consumables mentioned further below.

- [[item:132516]] — Massive movement speed boost that works when
  
  Mounts do not, and much faster than ground mounts.
- [[item:109076]] — Lets you glide off of ledges and cover vast
  
  distances quickly.
- [[item:168412]] — Do not forget this Mount Equipment to
  
  make your mounts faster on the ground.
- [[item:172063]] — An incredible amount of movement speed from a
  
  Food.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), follow the

point-by-point allocation of the below tree as you gain levels. The Leveling

Rotation section below has a slider that shows your rotation at each level.

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmZmZGDLDAAAAAAzYGzYbGjZMzATGAAAgBAGLbzMzmZmZmxMzMAMjNsMjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-PqBgEESAOMMHYTpCNNLiikeIRRFoWHu1pcE-BFMdDEbIjiZXlOFh6bhlFnmWYVlhwjH-AAAA-ZauYkAQgQJAZ4A-
```

:::

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider to

select your level, and watch as the leveling rotation grows with each level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 46 起：**Use [[spell:34477]] on your pet to shift aggro
   
   onto it.
2. **等级 78 起：**Use [[spell:1264902]] after your very first
   
   [[spell:259495]] inside each [[spell:1250646]] window. This button appears
   
   in place of your Takedown button once it is activated.
3. Use [[spell:190925]] to close gaps to enemies quickly.
4. **等级 5 起：**Use [[spell:136]] for large pulls to keep your pet
   
   healthy.
5. **等级 51 起：**Cast [[spell:1250646]] on cooldown, trying to do so with
   
   at least 2 stacks of [[spell:260285]].
6. **等级 17 起：**On AoE, use [[spell:1261193]] once you can get all of
   
   the packs' mobs into its fairly wide and long cone.
7. **等级 13 起：**Use [[spell:259495]] on cooldown.
8. **等级 11 起：**Use [[spell:259489]] on cooldown.
   
   **等级 21 起：**This generates [[spell:260285]] stacks that empower your other abilities, too, so try to use those stacks on all of your other abilities.
9. **等级 19 起：**Spam [[spell:186270]].
10. **等级 1–10：**Spam [[spell:185358]].
11. **等级 1–10：**Use [[spell:56641]] as a filler.

4.

### Best Leveling Pet

All pets do the same damage, but they vary in their utility and special

abilities. For Leveling, the best pet is any **Ferocity-type** pet, as they

heal themselves whenever they do damage, allowing you to make larger pulls.

Ferocity pets also come with [[spell:264667]], which is a Bloodlust effect.

This should be used as often as possible when you are fighting for over thirty

seconds.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Updated Heirloom stat advice and leveling tips.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Survival Hunter in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Survival Hunter

This section is intended for players who are new to the game or class, have

no intentions of raiding Mythic difficulty, or simply want a more

straightforward way to play their specialization without being overwhelmed by

the numerous priorities and active abilities that need to be taken into

consideration for optimal play.

Survival is quite simple in its execution and it is an ideal spec for someone

new to raiding, or just WoW in general.

Survival's core loop involves casting [[spell:259489]] to give

yourself [[spell:260285]] stacks, and then spending those Tip stacks on

other abilities like [[spell:259495]]/[[spell:1261193]] on cooldown, with

[[spell:186270]] as a filler.

Here are three quick rules of thumb that will help you when navigating the

spec.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_bossmannoroth_glaivethrust.jpg>) **Tip Every Ability**  
  
  
    Every single ability that you cast besides [[spell:259489]] must
  
    be cast with [[spell:260285]] active. The only exception, which is
  
    exceedingly rare, is that it is okay to cast a [[spell:186270]] (not
  
    Raptor Swipe) without Tip if you have no Tip or [[spell:259489]]
  
    charges left. Striking without Tip is better than sitting AFK.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_killcommand.jpg>) **Do Not Waste Tip Stacks**  
  
  
    Never cast [[spell:259489]] if you already have more than one
  
    [[spell:260285]] stack, as this wastes Tip stack generation. It is a
  
    common trap to be so paranoid about Tipping every ability that you overcommit
  
    to casting [[spell:259489]] when it is not needed, costing you in
  
    the long run.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_raptorstrike.jpg>) **Always be Casting**  
  
  
    Casting as many abilities as possible matters more than pressing the perfect
  
    button every time, and dead time is the single biggest thing holding most
  
    players back from their DPS goals.

2.

### Beginner's Guide to Survival Hunter in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel   Single-Target Talents

2.1.

#### Single-Target Talents for Survival Hunter

This build is our best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel single-target build, used for most

raid encounters.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGjZZAAAAAAYGzYmFzYMjZwYaGAAAgBAzYbZmZWMmZmxMzAgZssBjhxmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFHIJWYYaaceiikssw0268ADFFHLruG-ABDEFGIKKLYcceiKZiqqyy6S2GXn3nI-AAAA-BEIMQYcAJRZhpB-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel   Dungeon Talents

2.2.

#### Dungeon Talent Build for Survival Hunter

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for Mythic+. It is

based on simulating the conditions found in real Mythic+ dungeons and seeing

not just what does the most DPS, but what actually clears the dungeon quicker

in a group. There are builds that do more AoE damage, but they all lose more

single-target than they gain in terms of AoE, and vice versa.

2.3.

#### Survival Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of "most
  
  disposable":
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    
    in others.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MzMzMjZbeAAAAAAAzYmZGbzYMjZYZMNDAAAwAAjllZGLYmZ8AjxAwM2AjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-ABCDEFGHIKKLZaeiIZiqq6yGXn3Xo4I-AAAA-BEIMQYcAJRZhpJ-
```

:::

### Survival Hunter   Basic Rotation

2.4.

#### Basic Rotation for Survival Hunter

The goal of Survival is chiefly to maximize your Focus generation and

spendage. That means never overcapping your Focus, always casting

[[spell:259489]] on cooldown as long as it will not Focus cap you,

and spending all this Focus on [[spell:186270]]s and

[[spell:259495]]s.

[[spell:259489]] also gives us two [[spell:260285]] stacks.

These stacks empower other abilities, so you get a natural "weaving" playstyle

with [[spell:259489]] generating both Focus and Tip stacks, and then

you spend that Focus and those Tip stacks on empowered Raptors and Bombs.

On top of this, we have [[spell:1261193]], an extremely powerful

mini-cooldown that we want to use as many times as possible, and on as many

targets as possible, in a fight. We always want to make sure we

[[spell:260285]] it as well, and that we fully channel it.

Thus, the basic priority list goes something like this:

1. [[spell:1250646]] on cooldown, and always with
   
       [[spell:260285]].
2. [[spell:1261193]] on cooldown, and always with
   
       [[spell:260285]].
3. [[spell:259489]] whenever we have 1 or fewer
   
       [[spell:260285]] stacks.
4. [[spell:259495]], always with [[spell:260285]]. It has two
   
       charges, so one charge can be held a little bit if there is AoE coming
   
       up.
5. [[spell:186270]], always with [[spell:260285]].

2.4.1.

##### Apex Talent: ![Raptor Swipe Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_hunter_raptorswipe.jpg>) Raptor Swipe

Your Apex Talents have no impact on how you play; they just increase your

damage passively and are best taken advantage of by doing the "baseline"

rotation as described above.

2.4.2.

##### Season 2 Tier Set

The Midnight Season 2 Tier Set has no impact on our rotation. The 2-set makes

[[spell:259388]] increase [[spell:259495]] damage by 10%, and the

4-set has each blast of [[spell:1261193]] extend [[spell:259388]] by 1

second, on top of increasing Mongoose Fury's effects by 10%. That is a large

[[spell:259495]] gain, but nothing changes in practice, since Bomb is

already used aggressively on cooldown.

### Survival Hunter   Defensive Spells

2.5.

#### Defensive Spells for Survival Hunter

[[spell:109304]] is your primary self-heal with a 1-minute cooldown. Use

this when you drop below 50% HP to help out your Healer!

[[spell:186265]] is your immunity. It can be used to completely

negate the damage and effects of most spells targeted on you. Use it if you are

assigned to, or in a pinch if you worry that an upcoming mechanic will kill you!

It is also a 30-50% damage reduction, though it is not so commonly used for

simple damage reduction purposes.

[[spell:264735]] is our most powerful defensive besides

Turtle, a 30-40% damage reduction with 2 charges on a 1.5-minute cooldown each.

Use it to reduce damage taken from hard-hitting mechanics. Optimal use of this

ability entails using it **proactively**, before heavy incoming damage.

[[spell:5384]] is a very unique Hunter ability. It can be used to drop

aggro and combat, and it can also be used to stop casts on you. Mobs will

usually stop casting mid-cast if you appear to be dead! With the

[[spell:459517]] Talent, it will also dispel all Poison and Disease

effects from you.

[Survival Hunter Midnight Spell Glossary](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)

### Survival Hunter   Best Pets

2.6.

#### Best Pets for Survival Hunter

The most important thing to say about Pets is that **they all deal the same

DPS**. The only difference is in utility and defensive capabilities!

First of all, you need to find out if you need to be using

[[spell:2825]]/[[spell:32182]] in your group. Only Hunters, Mages, Evokers,

and Shamans can use Bloodlust, so if there is no one else of those classes in

your group, then it is on you!

If you do need to [[spell:2825]], you need to use any **Ferocity**

Pet, since these come with the [[spell:264667]] Bloodlust ability. Use [this website](<https://www.wow-petopia.com/abilities.php>) to find a cool

Ferocity Pet for Lusting purposes!

If you **do not** need to Bloodlust, then the best Pet is a personal

choice: any [Tenacity Pet](<https://www.wow-petopia.com/specs.php>), or

the aforementioned Ferocity Pet. Tenacity Pets come with the

[[spell:388035]] defensive and 5% Max Health, but you lose out on the

4% Leech, which is better for prolonged self-sustain!

### Survival Hunter   Stat Priority

2.7.

#### Stat Priority for Survival Hunter

The general stat priority for a Survival Hunter is seen below.

For more information on what's presented on this page, check out our main 

[Stat Priority page](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>).

Mastery

Critical Strike

Haste

Versatility

### Blizzard   Combat Assistant

2.8.

#### Combat Assistant & One-Button Mode

The game offers the option of an in-game "Combat Assistant", which has two 

modes: a Rotation Helper that will suggest spells to cast next, and a 

"One-Button Mode", that automatically performs this rotation for you if you 

simply press one button repeatedly.

These tools can be worthwhile for beginners, as they provide a reasonable 

"minimum" level of performance. For Survival Hunter, using just 

the Rotation Helper is a ~2-8% DPS loss compared to playing perfectly (which 

almost nobody does). Using the one-button mode on top of it takes the total 

loss to ~21%.

Obviously, peak performance cannot be obtained using these tools, but it is 

something worth considering if you are happy to take the DPS losses above for 

the sake of ease of play. Do not let anyone in-game or on a forum or Discord 

tell you that there is something inherently wrong with using these tools! 

Blizzard created them for a reason, and the game is about having fun, whatever 

that means for you.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Removed Moonlight Chakram from the beginner priority list and clarified pet advice.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **29 Jan. 2024:** Updated the default M+ build to a No-CD Build.
- **15 Jan. 2024:** Updated for Patch 10.2.5
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **13 Jun. 2023:** Updated the Easy Mode rotation and builds to be easier to follow.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Survival Hunter in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Survival Hunter

Survival plays ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel for all content. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader has

marginally more priority-target damage, but Sentinel does more overall damage on

big pulls while also being tankier and easier to play. We think that trade is worth it

for almost everyone, and we provide Pack Leader builds below for those who prefer

the playstyle. One of the spec's great boons is that it loses very little single-target

to deal great AoE/cleave.

As a result, with the exception of literally **pure** single-target 

fights, Survival runs variants of its AoE build for all scenarios.

If you are on a raid fight where [[spell:1262409]]'s

[[spell:1261193]] cooldown reduction is not doing anything for you, then run

[[spell:1253053]] instead.

**Quick Start Import Codes:**

:::talents Survival Single-Target - Sentinel
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYmgtZMzMGzyAAAAAAwMmxMLmxYGzgx0MAAAADAmx2yMzsYMzMjZmBAzYZDGDjNDAA"
}
```
:::

:::talents Survival Raid AoE/Cleave - Sentinel
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYmgNjZmxwyAAAAAAwMmxMLmxYGzgx0MAAAADAmxyyMzswMzMjZmBAzYZDGjZmNDAA"
}
```
:::

:::talents Survival Mythic+ - Sentinel
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxYGLDgZGYbmZmZmxsNPAAAAAAgZMzMjtZMmxMsMmmBAAAYAgxyyMjFMzMegxYAYGbgxYmZzAAA"
}
```
:::

:::talents Survival Delves - Sentinel
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxYGLDgZGYbmZmZmxsNPAAAAAAgZMzMDGjZMzwYaAAAAAAGLLzMWwMzMzYMAMjNsMjxMzmBAAA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Sentinel

Single-Target

recommended

Raid AoE/Cleave

recommended

Mythic+

recommended

Delves

recommended

Pack Leader

Single-Target

Mythic+

Delves

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Single-Target Talents

This build is our best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel single-target build, used for most
raid encounters.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Raid AoE/Cleave Talent Build

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for raid bosses with AoE or
cleave. It drops the [[spell:389880]] package from our single-target build
and spends those points on [[spell:259388]] and [[spell:1272139]] instead
to gain a ton of cleave damage for only a small single-target loss. Most of the
raid has AoE or cleave of some kind, so this is the most commonly used build
throughout.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Mythic+ Talents

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for Mythic+, and other
AoE-focused content. It is
based on simulating the conditions found in real Mythic+ dungeons and seeing
not just what does the most DPS, but what actually clears the dungeon quicker
in a group. There are builds that do more AoE damage, but they all lose more
single-target than they gain in terms of AoE, and vice versa.

1.3.1.

##### Survival Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of most
  disposable:
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    in others.

### 天赋方案 0-3

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Delve Talents

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for [Delves](<https://www.icy-veins.com/wow/delves-guide>). It is
similar to our Mythic+ Talent build, but differs on the Class Tree picks to be
better equipped for solo play with a pet tanking.

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Single-Target Talents

This build is our best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader single-target build, used for
most raid encounters.

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Mythic+ Talents

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader build for Mythic+. It is
based on simulating the conditions found in real Mythic+ dungeons and seeing
not just what does the most DPS, but what actually clears the dungeon quicker
in a group. There are builds that do more AoE damage, but they all lose more
single-target than they gain in terms of AoE, and vice versa.

1.6.1.

##### Survival Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of most
  disposable:
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    in others.

### 天赋方案 1-2

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Delve Talents

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader build for [Delves](<https://www.icy-veins.com/wow/delves-guide>). It is
similar to our Mythic+ Talent build, but differs on the Class Tree picks to be
more suitable for solo play with a pet tanking.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGjZZAAAAAAYGzYmFzYMjZwYaGAAAgBAzYbZmZWMmZmxMzAgZssBjhxmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFHIJWYYaaceiikssw0268ADFFHLruG-ABDEFGIKKLYcceiKZiqqyy6S2GXn3nI-AAAA-BEIMQYcAJRZhpB-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYmFzYMjZwYaGAAAgBAzYZZmZWYmZmxMzAgZssBjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFHIJWYYaaceiikssw0268ADFFHLruG-BDEFGILYcceiIZiqqyy6im2GXn3Xo4I-AAAA-BEIMQYcAJRZhpB-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MzMzMjZbeAAAAAAAzYmZGbzYMjZYZMNDAAAwAAjllZGLYmZ8AjxAwM2AjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-ABCDEFGHIKKLZaeiIZiqq6yGXn3Xo4I-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MzMzMjZbeAAAAAAAzYmZGMGzYmhx0AAAAAAMWWmZsgZmZmxYAYGbYZGjZmNDA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIMMNNOPRRSTWWYaeffgiikoSVXD-ABCDEFGHIKKLZaeiIZiqq6yGXn3Xo4I-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWgNYGGawyMmZGzMLDAAAAAAzYGzsYGjZMDGTzAAAAMAYGLLzMzCmZmxMzAMzGsBjhxmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFHIJWYYaaceiikssw0268ADFFHLruG-ABDEFGIJKKLYcceiIZiqqyy6yGXn3nI-AAAA-ACEGIU04ARZhpJ-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWgFYGGawiZmZmZGLDAAAAAAzYmZGbzYMjZYZMNDAAAwAgZssMzYhZmhHYMGwMbAYMmZ2MAA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-BCDEFGHIJLYcceiIZiqq6im2GX3Xo4I-AAAA-ACEGIUw4ARZhpJ-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWgFYGGawiZmZmZGLDAAAAAAzYmZGMGzYmhx0AAAAAAmxyyMjFmZGzMGDYmNALzYMzsZAA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIMMNNOPRRSTWWYaeffgiikoSVXD-BCDEFGHIJLYcceiIZiqq6im2GX3Xo4I-AAAA-ACEGIUw4ARZhpJ-
```

:::

The builds listed above are popular recommendations,

covering various different loadouts suited to each style of endgame content.

Each Talent Build will have its own rotation, and can also be manipulated 

further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is the "borrowed power" system introduced in Midnight's

[Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers

some moderately strong customization options after a short questline.

Some of these bonuses affect your damage output, but there are also defensive

and mobility options to choose from.

Your Folio progress carries over into Season 2. Take these bonuses:

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279612]]. This one is the most
  
    flexible and may change as your gear's stat demands do, just like your Flask
  
    or Weapon Enchant. Mastery is a safe "never bad" pick.
- [[spell:1279614]]

3.

### Apex Talent: ![Raptor Swipe Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_hunter_raptorswipe.jpg>) Raptor Swipe

Midnight introduces new Apex Talents, unlocked between Level 80 and 90.

Survival gets:

1. [[spell:1259003]]
2. [[spell:1259017]]
3. [[spell:1259019]]

They cause every second [[spell:186270]] to turn itself into

[[spell:1259003]], dealing increased damage, and causing it to hit multiple

targets as well. Very simple and passive, yet very powerful.

4.

### Hero Talents for Survival Hunter

Available at level 71, Hero talents are mutually exclusive trees you can

choose to slightly alter gameplay and visuals. Survival Hunter can choose

between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel is our simplest Hero Talent, and it barely changes how the

spec plays. It regularly gives you 

[[spell:1253601]] procs when you spend [[spell:260285]], 

significantly buffing the damage of your next [[spell:259495]]. In 

addition, when you activate [[spell:1250646]], the Takedown button itself will 

turn into [[spell:1264902]], an ability that does heavy damage on use. 

We only get one use of it during Takedown, and it takes a while to do all of 

its damage, so cast it as early in [[spell:1250646]] as you can.

Defensively, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel gives us [[spell:450373]], which procs 

nearly constantly and offers a great deal of passive tankiness.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader has marginally more priority-target damage than

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel, at the cost of overall damage on big pulls.

Occasionally, your [[spell:259489]] will trigger a

Beast via [[spell:471876]]. These Beasts simply do damage, or

increase your damage done. In addition, your first [[spell:259489]]

after

[[spell:1250646]] will summon a [[spell:201430]], a line of pets that do heavy

AoE 

damage to all targets caught within. We detail its usage more on our Rotation 

page.

Defensively, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader gives us [[spell:472707]], which buffs 

the effectiveness of our [[spell:264735]]. Not great.

5.

### PvP Talents (War Mode)

**These picks are for open world PvE content with War Mode enabled, not for

actual PvP.**

War Mode offers several benefits for you in the open world.

- PvP talents enabled in the outdoor world.
- At least 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is

recommended to enable the feature to maximize your leveling and rewards at

maximum level. However, you will be flagged for open-world PvP, and the

possibility of being "ganked" while leveling or doing World Quests exists.

- [[spell:203235]] is a valuable speed increase for leveling and open
  
  world content.
- [[spell:212640]] is a potent out-of-combat heal that also clears
  
  lingering debuffs.
- [[spell:202746]] is useful for negating powerful casts from mobs and
  
  other players that you cannot otherwise stop.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **30 Sep. 2026:** The Sentinel Single-Target build now takes Wallop over Bloody Claws (+0.15%).
- **15 Sep. 2026:** Added a Raid AoE/Cleave build, which is now our recommendation for any raid boss with adds or a second target.
- **18 Aug. 2026:** Updated the Utility Talents for Raid builds.
- **17 Aug. 2026:** The Omnium Folio setup now takes Void-Tainted Shell over Self-Mending.
- **12 Aug. 2026:** Delve builds now take Emergency Salve over Wilderness Medicine.
- **11 Aug. 2026:** Updated Pack Leader builds. Single-Target swaps Shellshock for Twin Fangs, and Mythic+ moves a point from Sweeping Spear into Razor Edge.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Updated Omnium Folio Week 4 rune and Hero Talent guidance.
- **17 Jun. 2026:** Updated recommended week 1 Folio Rune based on real-world data trumping sims.
- **16 Jun. 2026:** Microscopic (+0.1%) M+ Build change.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **28 Apr. 2026:** Updated the utility talents for Pack Leader to choose Slicked Shoes over Masterful Call. Small Class Talent Utility pick changes for M+.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **25 Mar. 2026:** Added note on Sentinel bug and updated recommended Hero Talent/builds.
- **17 Mar. 2026:** Fix error in Sentinel M+ build.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **01 Mar. 2026:** Pack Leader Mythic+ Build update.
- **28 Feb. 2026:** Survival Single-Target Talent update.
- **26 Feb. 2026:** Updated Mythic+ Talent Recommendation.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **12 Feb. 2026:** Updated Hero Talent recommendation across the board.
- **11 Feb. 2026:** Updated note on Hero Talents for Mythic+. No actual recommendation change, just giving more context.
- **10 Feb. 2026:** Updated Talent Builds for the upcoming 12.0.1 changes.
- **04 Feb. 2026:** Small update to Sentinel M+ Build.
- **31 Jan. 2026:** Updated Mythic+ Build. Dummy testing suggests identical-ish AoE and slightly more single-target with a button removed from the rotation and a 1-minute cooldown profile that matches the single-target build.
- **21 Jan. 2026:** Sentinel M+ Build Update.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Sep. 2025:** Updated recommended M+ Hero Talent to Sentinel after simulation tool fixes.
- **31 Aug. 2025:** Re-organized M+ Talent Picks slightly.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **13 Nov. 2024:** Updated the Mythic+ Sentinel Build to account for Ruthless Marauder previously having been undersimming.
- **06 Nov. 2024:** Added M+ builds and added a note of a good Talent Swap for beginners.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **08 Oct. 2024:** Updated for October 8th Hotfixes.
- **29 Sep. 2024:** Added an alternative single-target build.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **27 Aug. 2024:** Updated the "short-term burst" AoE Build to be default for pre-season.
- **24 Aug. 2024:** Added a recommended Delves build.
- **22 Aug. 2024:** Updated for The War Within.
- **26 Jul. 2024:** Added Talent Builds for players using the Season 3 Tier Set, which is optimal.
- **25 Jul. 2024:** Updated the M+ Build in light of Bloody Claws not working in pre-patch as it does on Beta.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **12 May 2024:** Added Misdirection to the M+ Build by default.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **29 Jan. 2024:** Updated the default M+ build to a No-CD Build.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **28 Nov. 2023:** Updated the ST and Mythic+ Talent Builds.
- **12 Nov. 2023:** Added a T30 Mythic+ Build.
- **09 Nov. 2023:** Small change to the Mythic+ build, for more single-target.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Restructured the page and updated for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **23 Jun. 2023:** Updated the AoE and AoE No CD Builds in light of recent APL changes.
- **26 May 2023:** Added a Bombardier and Spearhead Build.
- **19 May 2023:** Updated the layout of the page.
- **13 May 2023:** Updated the recommended AoE/Mythic+ Talents.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated the recommended M+ build.
- **08 Jan. 2023:** Updated the recommendation status of Lunge, and re-checked Talents for correctness in light of recent buffs.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **29 Oct. 2022:** Updated the recommended low-target AoE Venthyr build further.
- **27 Oct. 2022:** Updated the recommended low-target AoE build and fixed an issue with the string.
- **26 Oct. 2022:** Added a Kyrian-based Talent Build that emphasizes strong burst, primarily for high-target Mythic+ keys.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Survival Hunter in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Survival Hunter Gameplay and Rotation Guide

Welcome to our Rotation page for Survival Hunters. On this
page, you will find everything you need to know about actually playing the spec
in Raiding and Mythic+ scenarios.

The rotation here, aside from the more concrete openers, is laid out in a
**conditional priority list**. Essentially, for every single spell that you
cast, you should cast the highest-priority spell you can, **for which the
conditions are met.** After the spell is cast, you should start over from the
top of the priority list, and repeat the process.

The buttons below can be used to select between curated **Single-Target**
and **AoE/Mythic+** loadouts. You can also use the switches below to add or
remove individual talents you may also be using.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader

Single Target

AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Passive Talents

[[spell:1272139]]

[[spell:1262409]]

### Single-Target Rotation

1.1.

#### Single-Target Opener for Survival Hunter

Ensure [[spell:257284]] is active on your primary target.

---

**适用条件：Pack Leader（启用）；Twin Fangs（未启用）。**

[[spell:259495]]

1s

Pull

[[spell:259489]]

[[item:241288]]

[[spell:1250646]]

[[spell:259489]]

[[spell:259495]]

[[spell:259495]]

[[spell:1261193]]

[[spell:186270]]

**适用条件：Pack Leader（启用）；Twin Fangs（启用）。**

[[spell:259495]]

1s

Pull

[[spell:1250646]]

[[item:241288]]

[[spell:259495]]

[[spell:259489]]

[[spell:1261193]]

[[spell:259495]]

[[spell:186270]]

[[spell:259489]]

[[spell:186270]]

**适用条件：Sentinel（启用）；Twin Fangs（未启用）。**

[[spell:259495]]

1s

Pull

[[spell:259489]]

[[item:241288]]

[[spell:1261193]]

[[spell:259489]]

[[spell:1250646]]

[[spell:259495]]

**适用条件：Sentinel（启用）；Twin Fangs（启用）。**

[[spell:259495]]

1s

Pull

[[spell:1261193]]

[[item:241288]]

[[spell:1250646]]

[[spell:259495]]

---

1. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:259495]] around 1 sec before combat begins.
2. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:259489]]
3. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** Use your Potion, on-use Trinket, Racials, etc.
4. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:1250646]]
5. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:259489]]
6. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:259495]]
7. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:259495]]
8. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:1261193]]
9. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:186270]]
10. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** Continue with the priority list as described below.
11. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:259495]] around 1 sec before combat begins.
12. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:1250646]], alongside your Potion, on-use Trinket, Racials, etc.
13. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:259495]]
14. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:259489]]
15. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:1261193]]
16. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:259495]]
17. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:186270]]
18. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:259489]]
19. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:186270]]
20. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** Continue with the priority list as described below.
21. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** [[spell:259495]] around 1 sec before combat begins.
22. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** [[spell:259489]]
23. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** Use your Potion, on-use Trinket, Racials, etc.
24. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** [[spell:1261193]]
25. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** [[spell:259489]]
26. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** [[spell:1250646]]
27. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** [[spell:259495]]
28. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** Continue with the priority list as described below.
29. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** [[spell:259495]] around 1 sec before combat begins.
30. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** [[spell:1261193]], alongside your Potion, on-use Trinket, Racials, etc.
31. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** [[spell:1250646]]
32. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** [[spell:259495]]
33. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** Continue with the priority list as described below.

1.2.

#### Single-Target Priority List for Survival Hunter

Below is the priority system that describes the optimal single-target rotation for Survival Hunter.

1.3.

#### Tip of the Spear

The golden rule of Survival Hunter is that every ability must be "Tipped" via [[spell:260285]], a buff granted by [[spell:259489]] which grants 2 stacks of it thanks to [[spell:1272154]]. The general flow of the spec is [[spell:259489]] > 2 Tipped abilities according to the priority list > repeat. Some abilities do not have to be Tipped, so follow the priority list below.

1. **适用条件：Pack Leader（启用）。** Cast [[spell:259489]] below 2 [[spell:260285]] stacks if [[spell:471876]] is ready.
2. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** Cast [[spell:259489]] below 2 [[spell:260285]] stacks if [[spell:1250646]] is about to come off cooldown.
3. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** Cast [[spell:1250646]] with at least 2 [[spell:260285]] stacks.
4. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** Cast [[spell:1250646]] with no [[spell:260285]] stacks.
5. **适用条件：Pack Leader（启用）；Lethal Calibration（未启用）。** Cast [[spell:259495]] on cooldown.
6. **适用条件：Lethal Calibration（启用）；Pack Leader（启用）。** Cast [[spell:259495]] if it is within 5 seconds of reaching 2 charges.
7. **适用条件：Pack Leader（启用）。** Cast [[spell:1261193]] on cooldown.
8. **适用条件：Pack Leader（启用）。** Cast [[spell:186270]]. You must have Tip if it is a [[spell:1259003]]. If not, it does not matter to Tip it. Every 2nd Raptor is a Swipe.
9. **适用条件：Pack Leader（启用）；Lethal Calibration（启用）。** Cast [[spell:259495]] on cooldown.
10. **适用条件：Pack Leader（启用）。** Cast [[spell:259489]] if [[spell:1250646]] is on cooldown.
11. **适用条件：Pack Leader（启用）。** Cast [[spell:1250646]].
12. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** Cast [[spell:259489]] if you have no [[spell:260285]] left.
13. **适用条件：Twin Fangs（启用）；Sentinel（启用）。** Cast [[spell:259489]] if you have no [[spell:260285]] left and [[spell:1250646]] is on cooldown.
14. **适用条件：Sentinel（启用）。** Cast [[spell:1261193]] on cooldown.
15. **适用条件：Sentinel（启用）。** Cast [[spell:259495]] if the target has [[spell:1253601]], or if it is within 4 seconds of reaching 2 charges.
16. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** Cast [[spell:259489]] below 2 [[spell:260285]] stacks if [[spell:1250646]] is about to come off cooldown.
17. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** Cast [[spell:1250646]] with at least 2 [[spell:260285]] stacks.
18. **适用条件：Twin Fangs（启用）；Sentinel（启用）。** Cast [[spell:1250646]] with no [[spell:260285]] stacks.
19. **适用条件：Sentinel（启用）。** Cast [[spell:1264902]].
20. **适用条件：Sentinel（启用）。** Cast [[spell:186270]]. Every 2nd Raptor is a [[spell:1259003]].
21. **适用条件：Sentinel（启用）。** Cast [[spell:259489]] as a filler, but prefer [[spell:1250646]] if available.
22. **适用条件：Sentinel（启用）。** Cast [[spell:259495]].
23. **适用条件：Sentinel（启用）。** Cast [[spell:1250646]].

### AoE Rotation

1.4.

#### AoE Opener for Survival Hunter

Ensure [[spell:257284]] is active on your primary target.

---

**适用条件：Pack Leader（启用）。**

**适用条件：Twin Fangs（启用）。**

[[spell:1250646]]

**适用条件：Twin Fangs（启用）。**

[[item:241288]]

**适用条件：Twin Fangs（启用）。**

[[spell:259495]]

[[spell:259489]]

**适用条件：Twin Fangs（未启用）。**

[[item:241288]]

**适用条件：Twin Fangs（未启用）。**

[[spell:1250646]]

**适用条件：Twin Fangs（未启用）。**

[[spell:259489]]

**适用条件：Twin Fangs（未启用）。**

[[spell:259495]]

[[spell:1261193]]

[[spell:259495]]

**适用条件：Twin Fangs（启用）。**

[[spell:259495]]

[[spell:186270]]

**适用条件：Twin Fangs（启用）。**

[[spell:259489]]

**适用条件：Sentinel（启用）。**

**适用条件：Twin Fangs（启用）。**

[[spell:1250646]]

**适用条件：Twin Fangs（启用）。**

[[item:241288]]

**适用条件：Twin Fangs（未启用）。**

[[spell:259489]]

**适用条件：Twin Fangs（未启用）。**

[[item:241288]]

[[spell:1261193]]

[[spell:259495]]

[[spell:259489]]

[[spell:259495]]

**适用条件：Twin Fangs（未启用）。**

[[spell:259489]]

**适用条件：Twin Fangs（未启用）。**

[[spell:1250646]]

**适用条件：Twin Fangs（启用）。**

[[spell:1264902]]

**适用条件：Twin Fangs（启用）。**

[[spell:259489]]

**适用条件：Twin Fangs（启用）。**

[[spell:259495]]

---

1. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:1250646]], alongside your Potion, on-use Trinket, Racials, etc.
2. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:259495]]
3. **适用条件：Pack Leader（启用）。** [[spell:259489]]
4. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** Use your Potion, on-use Trinket, Racials, etc.
5. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:1250646]]
6. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:259489]]
7. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** [[spell:259495]]
8. **适用条件：Pack Leader（启用）。** [[spell:1261193]]
9. **适用条件：Pack Leader（启用）。** [[spell:259495]]
10. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:259495]]
11. **适用条件：Pack Leader（启用）。** [[spell:186270]]
12. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** [[spell:259489]]
13. **适用条件：Pack Leader（启用）。** Continue with the priority list as described below.
14. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** [[spell:1250646]], alongside your Potion, on-use Trinket, Racials, etc.
15. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** [[spell:259489]]
16. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** Use your Potion, on-use Trinket, Racials, etc.
17. **适用条件：Sentinel（启用）。** [[spell:1261193]]
18. **适用条件：Sentinel（启用）。** [[spell:259495]]
19. **适用条件：Sentinel（启用）。** [[spell:259489]]
20. **适用条件：Sentinel（启用）。** [[spell:259495]]
21. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** [[spell:259489]]
22. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** [[spell:1250646]]
23. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** [[spell:1264902]]
24. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** [[spell:259489]]
25. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** [[spell:259495]]
26. **适用条件：Sentinel（启用）。** Continue with the priority list as described below.

1.5.

#### AoE Priority List for Survival Hunter

Below is the priority system that describes the optimal AoE rotation for Survival Hunter.

1.6.

#### Tip of the Spear

The golden rule of Survival Hunter is that every ability must be "Tipped" via [[spell:260285]], a buff granted by [[spell:259489]] which grants 2 stacks of it thanks to [[spell:1272154]]. The general flow of the spec is [[spell:259489]] > 2 Tipped abilities according to the priority list > repeat. Some abilities do not have to be Tipped, and those are explicitly noted below.

1. **适用条件：Pack Leader（启用）。** Cast [[spell:259489]] below 2 [[spell:260285]] stacks if [[spell:471876]] is ready.
2. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** Cast [[spell:259489]] below 2 [[spell:260285]] stacks if [[spell:1250646]] is about to come off cooldown.
3. **适用条件：Pack Leader（启用）；Twin Fangs（未启用）。** Cast [[spell:1250646]] with at least 2 [[spell:260285]] stacks.
4. **适用条件：Pack Leader（启用）；Twin Fangs（启用）。** Cast [[spell:1250646]] with no [[spell:260285]] stacks.
5. **适用条件：Pack Leader（启用）。** Cast [[spell:259495]] if it is about to reach 2 charges. No need to Tip it.
6. **适用条件：Pack Leader（启用）。** Cast [[spell:1261193]] on cooldown.
7. **适用条件：Pack Leader（启用）。** Cast [[spell:259495]] on cooldown.
8. **适用条件：Pack Leader（启用）。** Cast [[spell:186270]]. You must have Tip if it is a [[spell:1259003]]. If not, it does not matter to Tip it. Every 2nd Raptor is a Swipe.
9. **适用条件：Pack Leader（启用）。** Cast [[spell:259489]] if [[spell:1250646]] is on cooldown.
10. **适用条件：Pack Leader（启用）。** Cast [[spell:259495]] on cooldown. No need to Tip it, but this only comes up if you can cast nothing else.
11. **适用条件：Pack Leader（启用）。** Cast [[spell:1250646]].
12. **适用条件：Sentinel（启用）。** Cast [[spell:259489]] if you have no [[spell:260285]] left.
13. **适用条件：Sentinel（启用）。** Cast [[spell:1261193]] on cooldown.
14. **适用条件：Sentinel（启用）。** Cast [[spell:259495]], preferring targets with [[spell:1253601]].
15. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** Cast [[spell:259489]] below 2 [[spell:260285]] stacks if [[spell:1250646]] is about to come off cooldown.
16. **适用条件：Sentinel（启用）；Twin Fangs（未启用）。** Cast [[spell:1250646]] with at least 2 [[spell:260285]] stacks.
17. **适用条件：Sentinel（启用）；Twin Fangs（启用）。** Cast [[spell:1250646]] with no [[spell:260285]] stacks.
18. **适用条件：Sentinel（启用）。** Cast [[spell:1264902]].
19. **适用条件：Sentinel（启用）。** Cast [[spell:186270]]. You must have Tip if it is a [[spell:1259003]]. If not, it does not matter to Tip it. Every 2nd Raptor is a Swipe.
20. **适用条件：Sentinel（启用）。** Cast [[spell:259489]].

2.

### Midnight Season 2 Tier Set

The Midnight Season 2 Tier Set has no impact on our rotation. The 2-set makes
[[spell:259388]] increase [[spell:259495]] damage by 10%, and the
4-set has each blast of [[spell:1261193]] extend [[spell:259388]] by 1
second, on top of increasing Mongoose Fury's effects by 10%. That is a large
[[spell:259495]] gain, but nothing changes in practice, since Bomb is
already used aggressively on cooldown.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the
Survival Hunter kit, we have compiled a more detailed explanation on
individual parts of our rotation, from important rotational mechanics that you
need to pay attention to, to cooldowns and how to use them, so you can reach
your full potential when playing Survival Hunter.

### [[spell:259495]]

3.1.

#### Wildfire Bomb

[[spell:259495]] is a core ability for Survival. Its damage is split
into its "direct" damage, which is buffed by [[spell:260285]], but it also
leaves a 6-second DoT which is unaffected.

One of the most crucial things to understand about Bomb is how it targets.
You throw it **at a target**, and then the Bomb explodes once it reaches that
target. The Bomb explodes in a cone behind the target **and** a small radius
circle around the target. In other words, if the mob is tightly bunched with a
bunch of other mobs, then Bomb will hit them all, regardless of how you are
facing.

If, however, the targets are a little bit more spread out, then you will need
to rely on the cone behind the target, and "behind" in this case is relative to
your position. In other words, you are effectively throwing your Bomb
**through** your target, so that it will hit the ones behind it. Angling and
positioning your character appropriately relative to the targets you want to hit
is therefore essential to maximizing this ability, particularly in Mythic+.

### [[spell:1259019]] Apex Talents

3.2.

#### Raptor Swipe Apex Talents

[[spell:1259019]] makes our [[spell:186270]] button "upgrade" itself
to an AoE version of the same button every second cast, which also does
significantly increased single-target damage. This happens all on its own, and
does not impact our rotational priorities much.

4.

### Important Cooldowns for Survival Hunter

### [[spell:1250646]]

4.1.

#### Takedown

[[spell:1250646]] is Survival's primary cooldown. It is a relatively simple
1:30 cooldown that can be reduced to a 1-minute cooldown with 2 points of the
[[spell:424557]] Talent. It deals heavy damage on use, and then increases all
your damage by 20% for 8 sec, and doubles your auto-attack speed.

The most unorthodox thing about this cooldown is its extremely short
duration. In WoW, the vast majority of DPS cooldowns are 15-20 seconds long, but
Takedown only lasts 8 seconds. This means that if we want to pack heavy
damage-dealers into its duration, we do not have a lot of time to do so, which
informs our opener choices and occasionally Trinket choices (30-second on-use
trinkets are not so great, for example).

Note that 1 [[spell:260285]] stack is sufficient for all abilities
except [[spell:1250646]], which must be cast with 2 if you have no
[[spell:1272139]]. Takedown has 2 elements, the player portion and the pet
portion, and they do not happen simultaneously. If Tip is not active when the
pet hits 1 second later, it will not get the Tip buff. For this reason, without
Twin Fangs, Takedown **must** be cast with at least 2 Tip stacks. Always.

4.1.1.

##### Hero Talent Impacts of Takedown

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel, [[spell:1250646]]'s button will turn into
[[spell:1264902]] once pressed. This ability deals heavy damage, and can
even reduce the cooldown of [[spell:259495]] by 10 sec if
[[spell:1266069]] is chosen. We only get one use in our [[spell:1250646]],
but because it takes quite a long time to do all of its damage, we do not want
to leave it until the end of a burst window. If we do run
[[spell:1266069]], it is also important to dump our [[spell:259495]]s
before using it, so as not to waste the cooldown reduction.

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader, [[spell:1250646]] immediately procs
[[spell:471876]], causing your next [[spell:259489]] to
summon a Beast. This "stacks" with the naturally occurring, cooldown-based Howl
procs, and you do not need to worry about sending Howl procs before activating
[[spell:1250646]]. In addition, your first Kill Command inside [[spell:1250646]]
will also launch a [[spell:201430]]. This is a roughly 30 yards long "line" of
beasts that charge at your target, and it gets placed when you press the Kill
Command. It deals heavy damage to all enemies inside it over 7 sec.

Because this effect is placed the moment you cast your first
[[spell:259489]] in [[spell:1250646]] and does not move, and because
it is
a long line that originates from your character position, aiming and positioning
this line is essential, particularly in AoE situations.

You want to place the Stampede in such a way that it will cover as many
targets as possible, for as long as possible. Positioning your character so that
the line extends through not just where the mobs currently are, but if they are
moving, **where you think they might be going**, is essential to making
optimal use of Stampede.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **30 Aug. 2026:** Updated the Sentinel single-target priority for Boomstick and Wildfire Bomb, and its Twin Fangs opener, which now opens with Boomstick to build Mongoose Fury stacks prior to Takedown.
- **16 Aug. 2026:** Updated the Sentinel AoE opener, which now opens with Takedown when Twin Fangs is talented.
- **11 Aug. 2026:** Clarified Wildfire Bomb target selection in the Sentinel AoE priority.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Corrected Takedown's duration to 8 seconds and Stampede's length to 30 yards.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **21 May 2026:** Fixed issue where Twin Fangs rotation logic was the wrong way around.
- **28 Apr. 2026:** Added extra Wildfire Bomb conditions for AoE and single-target.
- **27 Apr. 2026:** Updated and clarified the wording on Raptor Strike/Swipe tipping.
- **23 Apr. 2026:** Opener updates.
- **21 Apr. 2026:** Expanded on preparation for Takedown windows. Opener update.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **22 Mar. 2026:** Updated Pack Leader Single-Target Opener.
- **18 Mar. 2026:** Updated Sentinel Single-Target Opener with Twin Fangs slightly.
- **17 Mar. 2026:** Sentinel Opener update.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **12 Feb. 2026:** Updated Pack Leader Single-Target Rotation significantly.
- **11 Feb. 2026:** Added Hatchet Toss mention to the Pack Leader AoE Rotation.
- **10 Feb. 2026:** Small rotational updates for the upcoming Patch 12.0.1 changes.
- **20 Jan. 2026:** AoE Rotation improvements.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **30 Mar. 2025:** Small opener update.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **16 Mar. 2025:** Removed outdated mention of Serpent Sting multidotting.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **23 Nov. 2024:** Small single-target opener clarifications and corrections.
- **20 Nov. 2024:** Added more detailed explanations of the "Why" of several rotational nuances.
- **18 Nov. 2024:** Expanded on the AoE rotation and added more detail.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **25 Oct. 2024:** Updated the AoE rotations, simplifying them in the process.
- **23 Oct. 2024:** Updated AoE Opener.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **02 Oct. 2024:** Added more specific Trinket usage information.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **26 Aug. 2024:** Small, various fixes, mainly to pure ST build opener.
- **22 Aug. 2024:** Updated for The War Within.
- **30 Jul. 2024:** Updated the rotations and openers with small optimizations, primarily to do with holding Explosive Shot for Spearhead/Coordinated Assault.
- **29 Jul. 2024:** Updated the single-target opener to apply Serpent Sting early on, for Outland Venom.
- **28 Jul. 2024:** Implemented rotational DPS optimizations from the Survival Hunter Discord.
- **25 Jul. 2024:** Updated and simplified the rotation.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **12 Nov. 2023:** Added missing Wildfire Bomb line to the ST rotation.
- **07 Nov. 2023:** Fixed an issue where Wildfire Bomb would not appear in the ST rotation with the AoE build.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **17 Jul. 2023:** Updated the AoE rotation and opener significantly in light of recent APL updates, and added on-use Trinkets to the rotation.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **29 Jun. 2023:** Updated the Death Chakram line in the single-target rotation.
- **16 Jun. 2023:** Significant rotational overhaul with new checkboxes, a new feature that lets you select checkbox presets, and a variety of changes to both the single-target and AoE rotations.
- **15 Jun. 2023:** Removed the top line of the AoE Rotation, thereby reducing the priority of maintaining the 4PC Debuff on AoE.
- **13 Jun. 2023:** Removed the FoTE Bloodseeker Macro as the bug was fixed and it is no longer needed.
- **03 Jun. 2023:** Updated the AoE opener slightly.
- **26 May 2023:** Updated the AoE opener significantly to better reflect the AoE rotation change.
- **25 May 2023:** Important AoE Rotation Update, and updated the default checkboxes, and added information about an important Fury of the Eagle Macro.
- **13 May 2023:** Small wording change in the 4PC Rotation Line.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Small rotational fixes.
- **11 Dec. 2022:** Updated Harpoon's role in the rotation.
- **11 Dec. 2022:** Rotational update for the Set Bonus.
- **30 Nov. 2022:** Updated mentions of Kill Command having 2 charges in the priority to "cap charges" to encompass both situations with and without Alpha Predator.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Survival Hunter in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Survival Hunter

Welcome to our Gear and BiS Page for Survival Hunter for

Midnight Season 2. Check this page to learn everything you need

to know about gearing a Survival Hunter, including the BiS Gear

from all sources, Raiding, and Mythic+, information on the best Trinkets, Tier

Sets, and much more.

The Midnight Expansion brought a major stat squish, reducing the stats and

numbers of virtually everything in the game, including Item Levels and the stats

on gear.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which

lets you

increase the item level of gear along tracks that relate to where you obtained the

item, with harder content dropping gear that can be upgraded to higher Item

Levels.

For more information, read up on our dedicated page on how the 

[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 

changed in the Midnight expansion.

### Overall

This list contains the best gear in every slot for Season 2 of Midnight, from all sources.

There are many different setups that perform within the margin of error. This one chooses as many Raid items as possible, since they are easier to obtain than hoping for the right Mythic+ item from your [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>). Mythic+ items are chosen when there is no equally strong Raid alternative. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Items Do I Use in the Catalyst?
The Catalyst now keeps the secondary stats and any passive effects of the item you Catalyze, so what you put in matters more than which slot you use to complete the set. Mastery is what you want most, then Critical Strike and Haste.

Do not hold the set bonus back over this. Two weeks without your 4-piece costs far more than slightly wrong secondaries, and you can Catalyze a better item later in the season.

These are the best items to Catalyze:

- Helmet: no need, the set piece drops straight off [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- Shoulders: [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Chest: [[item:271876@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Gloves: [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Legs: [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details FAQWhat to Get From The Great Vault?
Take the [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) almost every week. The exception is when the Vault offers the last thing you wanted from a boss or dungeon, because taking it there means you never have to bonus roll that source again.

A Voidcore bonus rolls one raid boss or one Mythic+ dungeon and gives you something you have not rolled from it before. Heroic raid bosses and Mythic+ give 1/6 Myth, Mythic raid bosses give 6/6 Myth, and late-raid bosses give 9/6.

Two things make this stronger than it looks. The item level is decided when you spend the Voidcore rather than when you take it, so you can sit on one until you have a Mythic boss worth rolling on. And gear you take out of the Vault stays in the bonus roll pool, so a piece you were going to replace anyway can cost you a roll later.

The bosses worth rolling on are listed under Nebulous Voidcores further down this page.

:::

:::details TCTwo-Handed and Dual Wield Weapons
Survival is not locked to either weapon type in Season 2. Our Overall and Raid lists use a two-handed weapon, and our Mythic+ BiS List uses dual-wield. The primary reason that 2H is better this Tier is the presence of very uniquely strong two-handed weapons such as [[item:268213]]. Without this factor, 2H and DW setups perform similarly.

Without that one weapon, the two setups sim within a fraction of a percent of each other in both raid and Mythic+, so equip the best weapons you have based on iLvl and Stats, rather than chase a particular type.

<table> <tr> <th>BiS List</th> <th>What we use</th> <th>Benefit over the other setup</th> </tr> <tr> <td>Overall and Raid</td> <td>Two-handed, [[item:268213]]</td> <td>0.9% better than Dual Wield</td> </tr> <tr> <td>Mythic+</td> <td>Dual wield, two [[item:275070]]</td> <td>0.2% better than 2-Handed</td> </tr> </table>

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This list contains the best gear in every slot for Season 2 of Midnight, from Midnight Season 2 Mythic+. This is aimed at people who do not intend to engage much with Raid content.

There are many different setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Items Do I Use in the Catalyst?
The Catalyst now keeps the secondary stats and any passive effects of the item you Catalyze, so what you put in matters more than which slot you use to complete the set. Mastery is what you want most, then Critical Strike and Haste.

Do not hold the set bonus back over this. Two weeks without your 4-piece costs far more than slightly wrong secondaries, and you can Catalyze a better item later in the season.

These are the best dungeon drops to Catalyze:

- Helmet: [[item:159374@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Shoulders: [[item:239049@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Chest: [[item:251233@JAACAAgNyA]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Gloves: [[item:160213@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Legs: [[item:159375@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend farming the following dungeons:

- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): BiS Neck, Ring and Trinket
- [The Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): BiS Cloak and Trinket
- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): BiS Weapon
- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): BiS Boots
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): BiS Ring

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271493@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271490@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271491@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271495@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Raid

This list contains the best gear in every slot for Season 2 of Midnight, from the Midnight Season 2 Raids. It is very similar to our Overall BiS List, since that is biased towards Raid Gear as well, but in this case, absolutely no Mythic+ items are included.

There are many different setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Items Do I Use in the Catalyst?
The Catalyst now keeps the secondary stats and any passive effects of the item you Catalyze, so what you put in matters more than which slot you use to complete the set. Mastery is what you want most, then Critical Strike and Haste.

Do not hold the set bonus back over this. Two weeks without your 4-piece costs far more than slightly wrong secondaries, and you can Catalyze a better item later in the season.

These are the best raid drops to Catalyze. A Mythic+ item can beat any of them if you run keys as well:

- Helmet: no need, the set piece drops straight off [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- Shoulders: [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Chest: [[item:271876@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Gloves: [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Legs: [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raid leader, or simply want to focus on the most important bosses and items, we have you covered!

- [[item:268213]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): BiS Weapon, paired with [[item:270173]] for the set bonus.
- [[item:268265]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS Neck, and Venomcursed. Most specs want it, so expect competition.
- [[item:270173]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): BiS Trinket.
- [[item:270175]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS Trinket.
- [[item:281215]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS Trinket for Mythic+.
- [[item:281238]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS Gloves.
- [[item:268252]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>): BiS Ring.
- [[item:281029]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS Ring.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Survival Hunter

As Survival, our optimal setup is [[item:270175]] paired

with [[item:270173]]. Use the Heart with

[[spell:1250646]] when possible, but do not hold it for more than 20

seconds to do so.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Survival Hunter Trinkets**
**Optimal -**

[[item:270175]]

+

[[item:270173]]

:::

There are quite a few other valuable trinkets out there, so make sure to

click on our ranking chart to see if they are worth equipping. Note that you do

not want to have more than 1 on-use Trinket. You can almost think of the

"On-Use" Trinkets ranked as being separate from the others.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Survival Hunter Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]: On-Use</li>&#10;<li>[[item:270173]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]: On-Use</li>&#10;<li>[[item:273797]]: On-Use</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159617]]: On-Use</li>&#10;<li>[[item:273796]]: On-Use</li>&#10;<li>[[item:281215]]: Best Guillotine alternative if you cannot get a 344 Guillotine.</li>&#10;<li>[[item:250225]]: On-Use</li>&#10;<li>[[item:270165]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:246304]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>E Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:241340]]</li>&#10;<li>[[item:270168]]: On-Use. Can outperform its raw sim on fights with damage amps.</li>&#10;<li>[[item:158374]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>F Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

- [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) is a new currency that can be used to "Bonus 
  
    Roll" on certain dungeons and items. Using it will **guarantee** a drop 
  
    from that source, but the item you get is random. However, you are protected 
  
    from repeats. Use this enough times on a boss or dungeon, and you are
  
    **guaranteed** your desired item.

You get them from [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) by rejecting the item rewards, which

needs three reward slots unlocked from any source (even Tier 1 Delves!). With

the launch of Patch 12.1.5, you also get one extra Voidcore for free from Orin

Straylight, who can be found next to the Catalyst in Silvermoon.

3.1.

#### Recommended Nebulous Voidcore Usage for Survival Hunter

Obviously, the straightforward answer to this question is to use the 

Voidcores on the best upgrade that you have not yet gotten. This is unique to 

your character, but we will offer a list of some of the most important items for 

Survival Hunter, with the goal being that you can just go down 

the list and chase the #1 thing you see that you do not already have.

Bonus Rolling for an item you may get from an upcoming raid boss can be a

bad idea, depending on how you value "power now" versus "power later".

Generally speaking, your best bet is to roll [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) on **Heroic**.

It has several high-impact BiS items, so even if you do not roll your absolute BiS right

away, you will still get good value out of your roll.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:271876]],
   
   [[item:268265]], and [[item:270175]]
2. [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) for [[item:268213]] and
   
   [[item:270173]]
3. [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) for [[item:281238]] and
   
   [[item:281029]]
4. At this point, it has been many weeks of the Season and your gear will 
   
   be all over the place. We recommend using 
   
   [Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>) 
   
   to sim your optimal bonus rolls.

:::

3.2.

#### Ascendant Venomstones

[[item:280562]] are a new upgrade currency that arrives with

Patch 12.1.5. Each upgrade costs 10, and they only work on your Weapon, your

Trinkets and your Neck, letting you upgrade those items up to 340 iLvl. Only

fully upgraded Hero Track or Myth Track items, or crafted items at maximum

quality, can be upgraded with them. Spending them follows a similar priority to

your Crests:

1. Your Weapon is the highest priority.
2. Your [[item:270175]].
3. Your other Trinket.
4. Your Neck.

Fill in with other Myth Track items that you do not use as often. The

exception is an item you do not expect to get at Myth Track any time soon. If

you are not killing Mythic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), it is fine to upgrade a Hero Track

[[item:270175]].

4.

### Best Crafted Items for Survival Hunter

You can have two Embellishments, which are special effects that come from

crafted gear. The armor pair is the better longer-term play, since it is your

actual BiS and a crafted Weapon gets replaced by a Mythic Track drop sooner or

later. Crafting the Weapon first is still a real option if you want the power in

week 1, and the Weapon is worth around 8% more damage than the Mythic+ Weapon

you are likely to start the season with.

- [[item:237847]] or [[item:245771]] with
  
    [[item:273060]], Crafted with
  
    [[item:245783]] for Haste/Mastery. Which exact weapon 
  
    you choose is purely down to flavor; they are identical.
- [[item:244581]] or [[item:244584]] with
  
    [[item:240167]], Crafted with
  
    [[item:245789]] for Crit/Mastery. Take the Belt if you
  
    are gaining Item Level on the Craft and the Bracers if you are losing it.
- The second armor piece, which is usually around week 4. If you crafted the
  
    Weapon first, you have most likely replaced it with
  
    [[item:268213]] or another Mythic Weapon by then, and the
  
    Embellishment slot it was using is free again for this piece.

Crafting [[item:244582]] is a good short-term armor

craft, and a permanent one if you are never going to kill [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

on Mythic for the 344 Legs.

:::details **Survival Hunter Crafting Slot Priority**
**Weapon → Neck/Rings → Everything Else → Cloak/Wrist**

:::

You should ideally sim the optimal stats to craft for your particular

character, but the safe defaults are Crit/Mastery with a

[[item:245789]] on the armor pieces and Haste/Mastery

with a [[item:245783]] on the Weapon.

For more information about crafting gear you can visit our

[Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Adding Sockets to Gear

Helmets, Belts and Bracers can drop with a socket, and you can also add one

yourself with [[item:275707]]. It costs six

[[item:258556]], the currency [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) gives you for

passing on its rewards. You get six of them directly as long as you have three

reward slots unlocked.

Save them for pieces you do not expect to replace, so Mythic items or your

two crafted slots, since a crafted Belt or Bracer cannot get a socket any other

way.

5.

### Crest Usage

You will be able to upgrade your items via Crests such as

[Myth Mistcrest](<https://www.wowhead.com/currency=3446>). Once you have upgraded a slot to a certain item level,

**upgrading other items of that slot to that item level is free**.

When you upgrade with Crests, you should think of it as upgrading

**slots** and not items.

Since Crests are a limited resource, you will want to obtain

the highest item-level possible **before** upgrading a given slot, as this

means you will spend fewer Crests on that slot in total. If you are at all

capable of doing a +10 Dungeon, for example, it would be a very bad idea to

upgrade an item from a +9 Dungeon, because you just wasted 20 Crests that could

have been saved by just farming the slot on a +10.

We see a ton of players, even at a high level, mess up their upgrade

priorities and upgrade prematurely. Getting this right will put you far ahead

of most players.

Below is the slot priority you should upgrade your items in. If you ever want

to deviate from this, you should have a very good reason.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Survival Hunter Crest Upgrade Priority**
**Weapon**

→

**Trinkets**

→

**Helmet/Chest/Legs**

→

**Shoulder/Gloves/Belt/Boots**

→

**Rings/Neck**

→

**Cloak/Bracer**

:::

Note that exceptions are possible, such as special items that have more Item

Level scaling than their slot would imply.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the

importance of simming yourself on Raidbots. This is because every character is

unique, and each gear piece you have access to can change what is best

right now for you.

While we do offer recommendations for gear and trinkets, these are not complete

replacements for simming yourself. The only way to truly optimize your character

to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **30 Sep. 2026:** Fixed the Chest tooltips showing two Venomcursed effects.
- **04 Sep. 2026:** Moved the Font of Venomous Rage to S Tier in the Trinket Rankings.
- **29 Aug. 2026:** Updated the Weapon enchant to Rite of the Hash'ey.
- **24 Aug. 2026:** Corrected the Missive for the crafted Weapon to the Thalassian Missive of the Feverflare.
- **24 Aug. 2026:** Updated the Weapon enchant to Berserker's Rage.
- **22 Aug. 2026:** Added a note on crafting Legs.
- **21 Aug. 2026:** Updated the crafted Bracers and Belt to use Arcanoweave Lining, as Adorned Fang was oversimming.
- **18 Aug. 2026:** Updated the Nebulous Voidcore bonus roll priorities.
- **17 Aug. 2026:** Updated the Trinket tier list, and corrected the note on Gebbo's Bottomless Bag.
- **16 Aug. 2026:** Reworked the crafting advice, corrected the Voracious Heart of Ula'tek and Gebbo's Bottomless Bag entries in the raid-items list, and added start of season Voidcore and Crest advice.
- **15 Aug. 2026:** Updated the Mythic+ BiS weapons to two Sharpened Lightwood Slashers from Altar of Fangs, and added a section on two-handed and dual wield weapons.
- **15 Aug. 2026:** Updated the Trinket tier list following the latest tuning.
- **14 Aug. 2026:** Updated the Raid BiS Gloves to the Catalyzed Grips of Swirling Fury from Nymrissa Wavecaller.
- **14 Aug. 2026:** Removed the note about Maze-roa, Warlord's Fury not being on the Survival loot table, as it has now been added.
- **14 Aug. 2026:** Updated the Nebulous Voidcore bonus roll priorities and noted that Maze-roa, Warlord's Fury is not currently on the Survival loot table.
- **12 Aug. 2026:** Added Catalyst and Great Vault FAQs and a socket section, fixed Catalyst drop locations, and updated sources of the Raid BiS Helm and Gloves.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Added Bracers gems and fixed BiS Boots rows.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **23 Apr. 2026:** Updated Crafting recommendations in preparation for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **08 Apr. 2026:** BiS List and Trinket Tier List update.
- **31 Mar. 2026:** BiS List Updates.
- **25 Mar. 2026:** Expanded on weapon crafting across Hero Talents. Updated Mythic+ Gear BiS List
- **17 Mar. 2026:** Updated for Midnight Season 1.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **04 Mar. 2026:** Updated Crafting recommendation for endgame.
- **26 Feb. 2026:** Added Pack Leader Weapons.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **12 Feb. 2026:** Added note on 2-Hand vs Dual Wielding.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **02 Sep. 2025:** Trinket Tier List and BiS updates.
- **16 Aug. 2025:** Updated Trinket Tier List for tuning.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **26 Jun. 2025:** Updated Titan Disc recommendation.
- **23 Jun. 2025:** Updated the Titan Disc recommendation based on the latest hotfixes.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **10 May 2025:** Updated the wording/Dinar recommendation status for House of Cards and Signet slightly.
- **09 May 2025:** Updated Corruption Enchants & Puzzling Cartel Chip Dinar section.
- **21 Apr. 2025:** Add list of Dinar-purchasable items.
- **29 Mar. 2025:** Updated the position of Eye of Kezan in the Mythic+ Trinket Tier List.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **14 Mar. 2025:** Updated Amorphous Relic placement after buffs.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Dec. 2024:** Updated for the Cyrce's Circlet now going to Item Level 658.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **02 Oct. 2024:** Updated the BiS Trinkets for pure single-target.
- **20 Sep. 2024:** Updated the Trinket Tier List and Best Trinkets after re-evaluations and simulation tools maturing.
- **13 Sep. 2024:** Added note about double-Dawnthread Lining not working and how to fix it.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **27 Aug. 2024:** Added a note about Crafted gear to the Pre-Season BiS List.
- **22 Aug. 2024:** Updated for The War Within.
- **25 Jul. 2024:** Updated the BiS Trinkets, Crafting List, BiS List, and more.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Survival Hunter. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Survival Hunter Stat Priority

The stat priority across all builds for Survival Hunter is as 

follows:

Mastery

Critical Strike

Haste

Versatility

Remember that the less you have of a stat relative to others, the stronger it

tends to become. Stat priorities are based on equalizing all stats and looking

at how powerfully stats scale from a set point, as well as looking at the

highest-simming gear setups for the spec and looking at what stat priority got

it there.

Note that Crit and Haste are close enough on Survival to be treated as

interchangeable, whichever Hero Talent you play. Crit is generally easier to find

on most gear. Worry more about maximizing

Mastery than about your Crit/Haste ratio.

2.

### In-Depth Stat Breakdown

**Agility** is your primary stat. It provides you with Attack Power, which

determines the damage your abilities do across the board.

**Mastery**, through [[spell:263135]], increases the damage of

you and your pet, and reduces your damage taken by a flat 3%. Its effect is

doubled while you are within 25 yards of your pet. Increased Mastery will

improve the damage, but not the damage reduction.

**Haste** increases you and your pet's attack speed and Focus

regeneration, reduces your Global Cooldown from 1.5 seconds to a minimum of

0.75 seconds, and reduces the cooldown on many of your abilities, including

[[spell:259489]].

:::details FAQIs There a Haste Cap for Survival Hunter?
Survival does not have any Haste caps or thresholds.

:::

**Critical Strike** increases your chance to critically hit with

all spells and abilities. Crits deal double damage by default, but several 

effects can increase your crit damage, and make crits even stronger.

**Versatility** increases all your damage and healing done, and decreases

all damage taken.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit past which it will begin to offer less increase per

point gained; these are known as the points of diminishing returns. Once you

have reached

these amounts, stats will become progressively less valuable and may fall behind

other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Stat Diminishing Returns values for Level 80.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for the March 25 hotfixes.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **21 Sep. 2024:** Updated Stat Priority.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Survival Hunter, based on your [stat priority](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should use a [[item:240983]] in one socket, and 

[[item:240898]] in every other socket. While there are other

options for

both your Thalassian gem as well as rare gems, these two will provide you with

the highest

DPS gains in all content types.

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchant</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Ring</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>Two-Handed: [[item:243733]].</li>&#10;<li>Dual-Wield: [[item:243733]] on both weapons.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

Consumables substantially increase the power of your character for a limited

time. Any

time you are challenging yourself with difficult content, it is advisable that

you buff

yourself with Flasks, Food, Potions, and Weapon Oils.

3.1.

#### Flask

The best flask is generally going to be

[[item:241322]]. That said, it is best to think of Flasks as just

another piece of gear that is easily swappable, and depending on your exact gear

situation, any of the 4 secondary stat flasks can be optimal. To really minmax

on this point, you would need to simulate it.

3.2.

#### Potions

There is only one DPS Potion worth using.

- [[item:241288]] is the default option, offering a huge amount
  
  of your highest secondary stat for 30 sec, to be synced with your cooldowns.
  
  Note that this Potion is sensitive to your best stat (Mastery) actually being
  
  your highest when you pop the Potion. If that is not the case at this point in
  
  your gearing process, use [[item:241308]] instead. It also benefits
  
  greatly from your lowest stat (usually Versatility) being very near-0, since
  
  that means you suffer none of the reduction.

Make sure to carry [[item:271883]] as well.

It has a 5-minute cooldown and heals most of your health; use it as a last

resort, preferring your personal defensives wherever possible.

3.3.

#### Food Buff

The best Food you can eat is from a

[[item:255846]] or [[item:255845]] feast. The best

non-feast food is [[item:242747]]. The "Hearty" part is important, as

this food persists through death, and we highly recommend grabbing

[Cooking](<https://www.icy-veins.com/wow/professions-cooking>) to easily make your own Hearty Food, as it cannot be

straightforwardly purchased on the Auction House.

3.4.

#### Augment Rune

The best Augment Rune in Midnight is

[[item:259085]], but it might be very expensive to use on every

pull or

every dungeon, so use it sparingly unless your wallet is deep.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **29 Aug. 2026:** Updated the Weapon enchant to Rite of the Hash'ey.
- **24 Aug. 2026:** Updated the Weapon enchant to Berserker's Rage.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Fixed enchant tooltip links and updated consumable notes.
- **16 Jun. 2026:** Clarified Weapon Enchant choice.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 Apr. 2026:** Updated Ring Enchant.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **27 Mar. 2026:** Added info on dual wield Enchants.
- **19 Mar. 2026:** Updated to recommend Leech Enchants over Avoidance.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **04 Mar. 2026:** Added information about some old Sharpening/Weightstones from The Burning Crusade that are optimal in Midnight.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **09 May 2025:** Updated Corruption Enchants section.
- **21 Apr. 2025:** Added Corruption Enchants information.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **07 Mar. 2025:** Updated Weapon Enchant.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **15 Nov. 2024:** Updated Weapon Enchant.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **05 Oct. 2024:** Expanded on Weapon Enchant choices.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **22 May 2023:** Updated the recommended Leg Enchant, as it was found that the Lambent Armor Kit does not provide Stamina as it was assumed.
- **12 May 2023:** Updated the recommended food and Leg enchant.
- **02 May 2023:** Updated the recommended Weapon Rune/Temporary Enchant.
- **01 May 2023:** Reviewed for Patch 10.1.
- **23 Mar. 2023:** Yet another update to the recommended Gemstones based on a slew of hotfixes.
- **23 Mar. 2023:** Updated the recommended Gemstones after sim updates, and the discovery of a new, powerful combination.
- **21 Mar. 2023:** Updated the Onyx Annulet Information in light of the March 21st buff.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated the recommended Phial.
- **11 Dec. 2022:** Updated the recommendation and description of the optimal Flasks/Phials.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Survival Hunter in World of Warcraft Patch 12.1.5.

1.

### Survival Hunter in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Hunter in

Mythic+ dungeons, including the best way to set up your character, how your

rotation may change, and tips and tricks for using your abilities in the most

optimal way.

Survival Hunter is a solid all-rounder in Mythic+, able to

deliver both solid AoE and single-target in one package, and without varying its

rotation too much. It has solid utility, and the best survivability (true to

its name!) of the Hunter specs.

If you are unfamiliar with Mythic+ and its associated general mechanics, you

can read more about it on our dedicated Mythic+ page below.

2.

### Best Mythic+ Talent Builds

Survival plays ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel for all content. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader has

marginally more priority-target damage, but Sentinel does more overall damage on

big pulls while being tankier and easier to play. We think that trade is worth it

for almost everyone, and we provide Pack Leader alternatives for those who prefer

the playstyle.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Mythic+ Talents

2.1.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Mythic+ Talent Build for Survival Hunter

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for Mythic+. It is

based on simulating the conditions found in real Mythic+ dungeons and seeing

not just what does the most DPS, but what actually clears the dungeon quicker

in a group. There are builds that do more AoE damage, but they all lose more

single-target than they gain in terms of AoE, and vice versa.

2.2.

#### Survival Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of most
  
  disposable:
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    
    in others.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MzMzMjZbeAAAAAAAzYmZGbzYMjZYZMNDAAAwAAjllZGLYmZ8AjxAwM2AjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-ABCDEFGHIKKLZaeiIZiqq6yGXn3Xo4I-AAAA-BEIMQYcAJRZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Mythic+ Talents

2.3.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Mythic+ Talent Build for Survival Hunter

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader build for Mythic+. It is

based on simulating the conditions found in real Mythic+ dungeons and seeing

not just what does the most DPS, but what actually clears the dungeon quicker

in a group. There are builds that do more AoE damage, but they all lose more

single-target than they gain in terms of AoE, and vice versa.

2.4.

#### Survival Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of most
  
  disposable:
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    
    in others.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWgFYGGawiZmZmZGLDAAAAAAzYmZGbzYMjZYZMNDAAAwAgZssMzYhZmhHYMGwMbAYMmZ2MAA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-BCDEFGHIJLYcceiIZiqq6im2GX3Xo4I-AAAA-ACEGIUw4ARZhpJ-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts

[[spell:187707]] is your "kick" and your most important bit of utility in

Mythic+, used to stop enemy casts for the benefit of the group and especially

the tank. It is **highly recommended** to use a Focus Kick macro for this.

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Muzzle
```

This macro will kick your focus target if you have one, mouseover if you have

no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a

**Focus Mouseover macro**.

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly, so that you

are always able to kick it on cooldown, or in coordination with the rest of your

group.

3.2.

#### Stunning and "Stops"

[[spell:19577]] is your second-most important utility and is your

single-target "stop" for negating casts that cannot be normally interrupted. We

recommend using this in the same way as your Muzzle, with the same macro

(with Intimidation swapped in for Muzzle, of course). With a Talent, it

can also be an AoE stop.

[[spell:109248]] can be used to save your tank in hectic moments by

helping them kite mobs and generate some range.

[[spell:187650]] can be used as an additional stop alongside

[[spell:19577]], but it has a slow travel time and you will need to be

close to land it before most stunnable casts are finished.

### Other Utility

3.3.

#### Other Utility

[[spell:5384]] can not only be used to drop aggro, but also negate

certain casts and channels on you. In some cases, these mechanics will simply

re-target someone else in the group, but occasionally the mechanic will be

entirely negated with huge benefits. If you notice a cast or effect on you, try

to [[spell:5384]] it! With [[spell:459517]] talented, it will also

remove all Poisons and Diseases on you.

[[spell:19801]] can dispel beneficial Enrage and Magic effects

from enemy targets, which is regularly useful, and our builds already take

[[spell:459983]] for it. In some dungeons, you may choose to change

your default talents to grab [[spell:109248]] or [[spell:199483]].

[[spell:187698]] can be used to aid your tank in kiting by slowing mobs. It

is good to reflexively throw down a Tar Trap if your Tank dies, as it gives

everyone else a better chance at kiting and surviving.

4.

### Dealing with Affixes

This section has Hunter-specific tips for dealing with the various affixes of

Mythic+.

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Survival Hunter

Use AoE Crowd Control tools like [[spell:19577]] on dense clusters of

Orbs to take out as many as possible. You can use [[spell:187650]] and

your interrupt for the remaining, singular ones.

### Affix: Voidbound

4.2.

#### Voidbound Affix Management for Survival Hunter

Nothing specific to say here. Use your solid target-swapping

capabilities to focus the Void Emissary down as quickly as possible.

### Affix: Pulsar

4.3.

#### Pulsar Affix Management for Survival Hunter

Pop [[spell:186257]] and dash around to grab as many orbs as

quickly as possible.

### Affix: Devour

4.4.

#### Devour Affix Management for Survival Hunter

[[spell:5384]]'s Poison/Disease dispel (via [[spell:459517]]) is

a source of the dispel type needed for removing [[spell:440313]]. You can also

[[spell:109304]] to heal it off, but that costs a GCD.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **11 Aug. 2026:** Updated the Pack Leader build, moving a point from Sweeping Spear into Razor Edge.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Clarified utility and affix notes.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **17 Mar. 2026:** Fix error in Sentinel M+ build.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **01 Mar. 2026:** Pack Leader Mythic+ Build update.
- **26 Feb. 2026:** Updated Mythic+ Talent Recommendation.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **12 Feb. 2026:** Updated Mythic+ Build Recommendation.
- **10 Feb. 2026:** Updated Talent Builds for the upcoming 12.0.1 changes.
- **04 Feb. 2026:** Small update to Sentinel M+ Build.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Sep. 2025:** Updated recommended M+ Hero Talent to Sentinel after simulation tool fixes.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **18 Mar. 2025:** Updated the recommended MDT Sim/Mythic+ Simulation Route Pastebin.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **13 Nov. 2024:** Updated the Mythic+ Sentinel Build to account for Ruthless Marauder previously having been undersimming.
- **06 Nov. 2024:** Added M+ builds and added a note of a good Talent Swap for beginners.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **27 Sep. 2024:** Updated Ara-Kara Tips.
- **13 Sep. 2024:** Updated and clarified some tips.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **12 May 2024:** Added Misdirection to the M+ Build by default.
- **11 May 2024:** Added section on how to survive the highest of keys with Tank Trinkets and Embellishments.
- **07 May 2024:** Reviewed for 10.2.7.
- **03 May 2024:** Added tip for Chargath in Neltharus.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **29 Jan. 2024:** Updated the default M+ build to a No-CD Build.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **18 Dec. 2023:** Added Mythic+ Dungeon Tips.
- **28 Nov. 2023:** Updated the Mythic+ Talent Build.
- **12 Nov. 2023:** Added a T30 Mythic+ Build.
- **09 Nov. 2023:** Small change to the Mythic+ build, for more single-target.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **23 Jun. 2023:** Updated the Mythic+ Builds in light of recent APL changes.
- **02 Jun. 2023:** Significant updates to the talent builds, both in terms of what is recommended for Fortified/Tyrannical, and the talent builds in themselves.
- **27 May 2023:** Added separate Fortified, Tyrannical, and Cooldown Builds for Survival Mythic+.
- **13 May 2023:** Updated the recommended AoE/Mythic+ Talents.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated the recommended M+ Build.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **29 Oct. 2022:** Updated the Venthyr Mythic+ Build Talents.
- **26 Oct. 2022:** Added a Kyrian build that is superior for heavy AoE keys.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Survival Hunter in World of Warcraft Patch 12.1.5.

1.

### Best Macros

1.1.

#### Generic Macros for Hunters

1.1.1.

##### TankMD AddOn + Macro

This automatically MD's your tank in the group with no need for targeting

or focusing or anything. Install the AddOn, set up the macro, and you are

golden.

1. Grab the [TankMD
   
   AddOn](<https://www.curseforge.com/wow/addons/tankmd>).
2. Set up this Macro:

#### TankMD Misdirection Macro

```wow-macro
#showtooltip Misdirection

/click TankMDButton1
```

1.1.2.

##### Focus Mouseover Macro

An essential macro for serious Mythic+. Sets your mouseover to be your

focus target and marks it with a Green marker (unless it is already marked with

something else), letting you kick it with the macros below.

#### Focus Mouseover Macro

```wow-macro
/focus [@mouseover,harm,exists,nodead][@target,harm,exists,nodead]

/tm [@mouseover,harm,exists,nodead][@target,harm,exists,nodead] 4
```

1.1.3.

##### "Auto Kick/Stun" Macro

This Macro will automatically use your Kick on a random, casting target

with no need for targeting or mouseover or focus. We like it for

lower/uncoordinated keys. See a cast? Hit the macro. The third macro does the

same concept but for [[spell:19577]].

#### Auto Kick Macro (Counter Shot)

```wow-macro
#showtooltip Counter Shot

/cast [@focus,exists,nodead,harm] Counter Shot

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast Counter Shot

/target focus

/clearfocus

/startattack
```

#### Auto Kick Macro (Muzzle)

```wow-macro
#showtooltip Muzzle

/cast [@focus,exists,nodead,harm] Muzzle

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast Muzzle

/target focus

/clearfocus

/startattack
```

#### Auto Stun Macro (Intimidation)

```wow-macro
#showtooltip 

/cast [@focus,exists,nodead,harm] Intimidation

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast Intimidation

/target focus

/clearfocus

/startattack
```

Note that it will prefer kicking your focus if you have one. If you want

it to prefer your mouseover, just swap out "focus" with "mouseover".

1.1.4.

##### Disengage StopCasting Macro

This macro will stop casts like [[spell:56641]] and force a

[[spell:781]], but it will not cancel channels like [[spell:257044]] or

[[spell:1261193]] that you can actually [[spell:781]] in the middle of.

#### Disengage StopCasting Macro

```wow-macro
#showtooltip Disengage

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/use Disengage
```

1.1.5.

##### Cursor Macros for Ground-Targeted Abilities

These macros skip the green target circle placement step of using

ground-targeted abilities. We use it for everything from [[spell:1543]] to Traps

to [[spell:109248]] to [[spell:260243]].

Just place your cursor where you want it to go.

#### Cursor Macro (Freezing Trap)

```wow-macro
#showtooltip

/use [@cursor]Freezing Trap
```

#### Cursor Macro (Tar Trap)

```wow-macro
#showtooltip

/use [@cursor]Tar Trap
```

#### Cursor Macro (Binding Shot)

```wow-macro
#showtooltip

/use [@cursor]Binding Shot
```

#### Cursor Macro (Volley)

```wow-macro
#showtooltip

/use [@cursor]Volley
```

#### Cursor Macro (Flare)

```wow-macro
#showtooltip

/use [@cursor]Flare
```

1.1.6.

##### Pet "Reset" Macro

This macro is useful when jumping off ledges where you really want your

pet to follow you. Petpassive and Petfollow can make the pet "snap" to you more

readily. The [[spell:1850]] line ensures your pet gets back to you as quickly as

possible.

#### Pet "Reset" Macro

```wow-macro
/petpassive

/petfollow

/use Dash
```

1.1.7.

##### Pet Taunt Macro

In Mythic+ it is sometimes useful to taunt powerful mobs right before

their tank busters which can help save your tank's life. You will want to use a

Beetle, Boar, Carapid (BM only), Core Hound (BM only), Mechanical, Scalehide,

Shale Beast (BM only), or Turtle for this as they have a 50% DR on a 1-min

CD.

#### Pet Taunt Macro

```wow-macro
#showtooltip

/use [@mouseover,exists,harm][@focus,exists,harm]Growl

/use Scale Shield

/use Harden Carapace

/use Bristle

/use Bulwark

/use Obsidian Skin

/use Defense Matrix

/use Solid Shell

/use Shell Shield
```

1.1.8.

##### Mouseover Tranq Shot

Simply Tranqs your mouseover enemy, or your target if there is no valid

mouseover.

#### Mouseover Tranq Shot

```wow-macro
#showtooltip

/use [@mouseover,exists,harm,nodead][]Tranquilizing Shot
```

1.1.9.

##### Aspect of the Turtle Cancelaura Macro

The default game lets you cancel Turtle by pressing it again but there is

a "grace" period built into this. This macro skips the grace period and lets you

activate and then cancel Turtle immediately. Do not use this if you are the

kind of person who spams Turtle, this macro requires you to be deliberate with

a single key press to activate/deactivate!

#### Aspect of the Turtle Cancelaura Macro

```wow-macro
#showtooltip Aspect of the Turtle

/stopcasting

/stopcasting

/use Aspect of the Turtle

/cancelaura Aspect of the Turtle
```

1.1.10.

##### Mouseover Multi-Shot

Mainly useful for Marksmanship, which wants to put [[spell:2643]] on a

target separate from its main target to activate [[spell:257621]] or to

spread its Marks around. It has no nochanneling entry, since Marksmanship

deliberately clips the end of [[spell:257044]] with [[spell:2643]].

#### Mouseover Multi-Shot

```wow-macro
#showtooltip Multi-Shot

/use [@mouseover,exists,harm,nodead][]Multi-Shot

/petattack

/petassist
```

1.2.

#### Survival Macros

1.2.1.

##### Auto Pet-Summon Kill Command Macro

This macro will summon/ress your pet if you do not have one summoned, and is

otherwise just a regular [[spell:259489]] macro. Set the Call Pet X

number

to whatever pet you default to. When we are Lusting in a group, we go in and

change

the macro to our Lust pet's number so that if we die in the key and hit KC, it

will summon the right pet. Takes the thinking out of it. Note that the ress part

is not 100% reliable if your pet unit is not actually present, which can happen if

you try to ress and then cancel the cast. So, you should still have

[[spell:982]] bound separately.

#### Auto Pet-Summon Kill Command Macro

```wow-macro
#showtooltip Kill Command

/petassist

/petattack

/cast [@pet,dead] Revive Pet;

/cast [@pet,noexists,mod:shift] Revive Pet; 

/cast [@pet,noexists] Call Pet 1;

/cast Kill Command
```

1.2.2.

##### Wildfire Bomb Mouseover Macro

[[spell:259495]] is both a cone behind your target and a circle around

it, but in spread AoE situations you may have to rely entirely on the cone and

mouseover Bombing is extremely potent here to ensure maximum coverage.

#### Wildfire Bomb Mouseover Macro

```wow-macro
#showtooltip Wildfire Bomb

/petattack

/use [@mouseover,harm,nodead,exists][]Wildfire Bomb
```

1.2.3.

##### Harpoon Mouseover Macro

For quick position changes to a particular target without necessarily

changing your DPS target. Also just feels very cool.

#### Harpoon Mouseover Macro

```wow-macro
#showtooltip

/use [@mouseover,exists,harm][]harpoon

/cancelaura Updraft
```

2.

### Best Addons

2.1.

#### Generic Addons for Hunters

Before you go downloading a bunch of different Addons, we recommend you set
up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many
Addons you may think you
cannot do without, are now available through the standard interface. Once you've
set up your UI, we
recommend thinking about which aspects or customization layers you would like to
add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of
Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional
Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and
reconfiguring your UI.

2.2.

#### User Interface

2.2.1.

##### EllesmereUI

[EllesmereUI](<https://www.curseforge.com/wow/addons/ellesmereui>)
is a complete replacement for the default User Interface.
It is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need: unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. EllesmereUI is
clean, easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the
best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same
customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a
great tool to help
you focus more on your own character, instead of having to worry about keeping
track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While some UI replacements
come with their own nameplates, those are often limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to
enlarge
and change color in certain circumstances, and it might help you keep track of
important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some
setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
an Addon developed by
[plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like
[Auctionator](<https://www.curseforge.com/wow/addons/auctionator>),
[Baganator](<https://www.curseforge.com/wow/addons/baganator>),
[Chattynator](<https://www.curseforge.com/wow/addons/chattynator>),
and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures,
and much more.
It is definitely worth checking out, especially if you end up having any issues
with Plater for
any reason.

2.5.

#### Damage Meters

2.5.1.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still
around
as the #1 Addon to customize damage and healing meters. While it may not offer
as many tracking
options as before due to the limits imposed by Blizzard, it is still around and
kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.6.

#### Specific Addons for Survival Hunters

Currently, we feel that there is no need for additional addons to play a

Survival Hunter to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **13 Jun. 2023:** Removed the FoTE Bloodseeker Macro as the bug was fixed and it is no longer needed.
- **25 May 2023:** Added a cancelaura Bloodseeker Macro for Fury of the Eagle.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
