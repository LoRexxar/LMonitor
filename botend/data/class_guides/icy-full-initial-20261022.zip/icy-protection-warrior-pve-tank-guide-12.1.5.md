## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Mwahi。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-guide>)
- [练级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)

## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本 防护 战士 攻略。在这里，你将学习如何在团队副本和大秘境中担任 防护 战士 坦克。我们涵盖了从基础到极致优化生存能力的全部内容。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

防护大秘境资源

[全新！顶级 防护 天赋构筑](<https://raider.io/specs/protection-warrior/talents>)

[顶尖防护大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warrior/protection>)

[防护大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warrior--protection>)

[流行的防护队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warrior--protection>)

1.

### 防护 战士 概述

防护 战士在承受大量物理伤害或需要高机动性的战斗中表现出色。他们所受的大部分伤害通过格挡来减免，使其承受的伤害平稳且可预测。此外，他们还提供大量实用功能，无论是控制还是团队增益。他们是一个强大、快节奏的全能坦克，无论在团队副本还是地下城中都是值得选择的职业。

请注意，本攻略侧重于 防护 战士特有的方面，通用的坦克策略不在其范围内。如果你想了解更多关于坦克职责以及如何提升自己，我们建议你阅读我们的 [坦克指南](<https://www.icy-veins.com/wow/tanking-guide>).

平庸，但恰到好处

防护 战士的伤害在明确的爆发窗口期打出，来源于

[[spell:107574]]

。我们拥有大量额外的进攻冷却技能，可以从天赋中选择来进一步增强这些窗口。除此之外，该专精还拥有不错的斩杀伤害。

不错，前提是战斗允许

虽然 防护 战士是坚固的坦克，能打出不错的伤害，但在某些团队副本战斗中我们仍有不足。我们最大的弱点——无法格挡的伤害加上持续的魔法伤害——在团队副本中可能会变得非常棘手。我们仍然可以应对这些战斗，但需要团队中治疗者的额外关注。

盾牌格挡大放异彩之处

防护 在大秘境中拥有出色的伤害表现，这得益于 [[spell:107574]] 和其他进攻冷却技能的高覆盖率。除了伤害部分，我们还可以使用各种防御手段来应对任何 incoming 伤害。

[[spell:2565]] 是减免物理伤害的明星技能，考虑到大秘境中大部分承受的伤害通常是物理伤害，我们在这方面表现出色。我们还拥有大量各种打断手段，包括眩晕甚至群体沉默。

样样都有一点

我们的大部分功能性来自眩晕：[[spell:46968]]、[[spell:107570]]，甚至 [[spell:385952]]。我们还有 [[spell:5246]] 的群体恐惧和 [[spell:386071]] 的群体沉默。在移动方面，我们有 [[spell:12323]] 为盟友提供快速爆发的移动速度。

虽然看起来有很多工具，但眩晕会受到递减效果的影响，而恐惧和沉默的冷却时间相当长。[[spell:6673]] 和 [[spell:97462]] 是我们提供的两个增益，它们也发挥着重要作用。

不错，但有个前提

[[spell:6544]]

,

[[spell:3411]]

是我们可以使用的两个移动工具。它们的冷却时间相当短，因此可以频繁使用。除此之外，我们还可以将

[[spell:100]]

和

[[spell:385952]]

也视为移动手段。它们的缺点是需要敌方目标才能使用，但在战场上快速移动方面非常出色。

如果你精通的话就非常棒

防护 的生存能力很强，因为 [[spell:2565]] 能应对大部分物理伤害，而且我们有大量工具来应对爆发性魔法伤害。

然而，我们的大部分防御冷却技能需要在 **之前** 伤害到来之前使用。这意味着你需要确切知道伤害何时发生，以及它是什么类型的伤害。然后 **接着** 使用相应的防御技能。

只要防御技能使用得当，我们的生存能力就很出色。但当我们无法恰当使用它们时，就会开始陷入困境。

1.

### 防护 战士 在 至暗之夜 中

### **12.1.5 补丁**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本为 防护 战士带来了一些更新，此外还有新内容。将有一个单Boss团队副本——基斯希克斯的解缚，以及一个迷宫地下堡——金多詹迷宫！除此之外，我们将在 [[item:280562]] 中获得一种新货币，它可以将我们的装备提升到更高的水平，所以请务必查看 [配装](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>) 页面。

[基斯希克斯的解缚团队副本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

[12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>) 作为至暗之夜第2赛季进程的延续，围绕乌拉特克和阿曼尼的故事最终带来了一个全新的单首领团队副本、升级装备等级的途径、多种追赶装备来源，以及无限量的雾玉用于升级装备。请务必查看我们的补丁中心，了解补丁12.1.5的所有新增或更新信息。

2.3.

#### 职业改动

防护战士在下述更新中获得了2项改动： [12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>)中获得了2项改动，两者都是增益。这些增益使得某些之前不被选择的天赋在特定场景下可以使用。请务必查看我们的循环和天赋页面以获得更好的了解。

- [[spell:163201]] 伤害提高30%。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像:
  
  
  
  
  - [[spell:429647]] 现在使 [[spell:163201]] 和 [[spell:6572]] 的怒气消耗降低10点。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_revenge.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 补丁12.1职业改动

防护 战士 在12.1中获得了相当多的改动。多个天赋被修改，导致其效果发生明显变化。似乎对我们流血伤害有所侧重，从天赋改动以及我们的新套装围绕它展开就可以看出。除此之外， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 都受到了重大改动，如下所述。

- [[spell:772]] 被替换为 [[spell:384277]]
- [[spell:1264330]] 现在还提高 [[spell:163201]] 的伤害
- [[spell:385704]] 现在提高所有流血伤害
- [[spell:383103]]、[[spell:384036]] 和 [[spell:190456]] 获得增强
- [[spell:228920]] 不再提高 [[spell:6343]] 和 [[spell:6572]] 的伤害，但现在造成50%的额外伤害并改为提高你的流血伤害
- [[spell:6572]] 的免费释放现在也可以由自动攻击触发
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主:
  
  
  
  
  - [[spell:435607]] 伤害提高40%
  - [[spell:436707]] 的伤害加成从30%降低到10%
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像:
  
  
  
  
  - [[spell:429636]] 不再缩短 [[spell:436358]] 的冷却时间
  - [[spell:429641]] 现在还提高 [[spell:163201]] 的伤害
  - [[spell:436358]] 冷却时间现在为30秒，而不是45秒
  - [[spell:429644]] 从20%增强到30%
  - [[spell:429647]] 现在使 [[spell:23922]] 额外产生4点怒气
  - [[spell:429636]] 现在使敌人造成的伤害降低20%，而不是10%

:::

### 至暗之夜改动概述

2.5.

#### 至暗之夜 中 防护 战士 的改动

虽然大多数其他职业都得到了更大的全面改版
[至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)中获得了更大的改动，但 防护 战士 基本保持不变。我们获得的最大变化来自天赋树的重新组织，以及一些熟悉天赋的修改。

下面是 防护 战士 获得的一些影响较大的改动的简短列表。

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵 获得了3个新天赋。
  
  
  
  
  ► **点击展开**
  
  
  
  
  2.5.1.
  
  
  
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主
  
  
  
  
  - [[spell:275336]] 取代了 [[spell:275336]]，现在仅对 山丘领主 可用。
  - [[spell:1270723]] 为我们的闪电打击提供少量伤害提升。
  - [[spell:1270724]] 提高我们的 [[spell:107574]] 覆盖率。
  
  
  
  
  2.5.2.
  
  
  
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像
  
  
  
  
  - [[spell:1270704]] 使 [[spell:436358]] 对所有目标施加 [[spell:1261060]]。
  - [[spell:1270709]] 提升你的各种流血效果。
  - [[spell:1270710]] 在施放 [[spell:436358]] 后为我们提供少量急速增益和 [[spell:23922]] 的提升。
- 职业和专精天赋被重新排列和修改。
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:355]] 持续时间现在为6秒，而不是3秒，并且其威胁值生成提高。
  - [[spell:275336]]已被移除，现在仅适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 作为 [[spell:275336]] 可用。
  - [[spell:1280961]] 和 [[spell:424742]] 是2个不错的新天赋。
  - [[spell:152278]] 现在需要20点怒气，而不是10点。
  - [[spell:376079]] 现在允许你跳到长矛的位置。
  - [[spell:228920]] 激活时现在使 [[spell:6343]] 和 [[spell:6572]] 的伤害提高50%。
  - [[spell:115767]] 现在是一个天赋，仅由 [[spell:163201]] 施加。
  - [[spell:12975]] 现在是一个被动技能，在使用 [[spell:871]] 时激活。
  - [[spell:12323]] 现在还为盟友提供移动速度。
  - [[spell:1271948]] 是一个新天赋，为我们提供远程打断能力。
  - [[spell:97462]] 现在在非团队副本中提供50%的生命值。
  - [[spell:384318]]、[[spell:391572]] 和 [[spell:384969]] 已被移除。
  - [[spell:202095]] 现在使最大生命值提高10%，并每消耗15点怒气治疗1%。

2.6.

#### 巅峰天赋

巅峰天赋是专精树中的新节点，共4个，旨在进一步增强你的核心技能。

- [[spell:1269311]] 使 [[spell:6343]] 强化你的下一次 [[spell:23922]]，使其在目标后方的锥形区域内造成额外伤害，并使 [[spell:23922]] 的伤害提高10%。
- [[spell:1269312]] 进一步提高力波和 [[spell:6343]] 的伤害。
- [[spell:1269313]] 在 [[spell:2565]] 激活时提高 [[spell:23922]] 的伤害和暴击几率，并使被方阵力波击中的敌人对你造成的伤害降低5%。

这是对巨龙时代第2赛季的回顾，当时我们的套装也有类似的效果。上述巅峰天赋相当无聊，并没有为我们提供真正的游戏玩法提升。[[spell:23922]] 和 [[spell:6343]] 都是循环技能，这意味着你甚至不需要考虑巅峰天赋。它只是在你玩这个职业时自动生效。

1.

### 防护 战士 基础指南

作为坦克，你的主要职责是在保护团队中较脆弱成员免受敌人攻击的同时保持存活。为此，你需要尽可能多地产生怒气，然后根据情况将其用于防御技能，如 [[spell:2565]]，或进攻技能，如 [[spell:6572]]。

如果你想更深入地了解 防护 战士 并确切理解它为何有效，你可以从查看我们的天赋页面开始。这将涵盖你需要了解的关于天赋的所有主要内容，以及何时选择它们。

防护 战士 的整个玩法基于产生和消耗怒气。这意味着你将拥有产生怒气的技能，例如 [[spell:23922]]，以及消耗该怒气的技能，例如 [[spell:190456]]。防护 战士 的进一步细分可以在下面的三个要点中找到。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_warcry.jpg>) **管理你的怒气**
  
  
  
  
  怒气是你用于施放技能的主要资源：[[spell:2565]]、[[spell:6572]] 和 [[spell:190456]]。尽可能多地产生怒气同时最小化浪费的怒气应该是你的主要目标之一。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_defend.jpg>) **使用你的防御技能**
  
  
  
  
  作为坦克，你的主要职责是让敌人以你为目标。为了帮助你抵御猛攻，你需要充分利用你的防御技能。[[spell:2565]]、[[spell:871]]、[[spell:1160]]、[[spell:23920]] 甚至 [[spell:190456]] 都能提升你的防御能力——只要确保轮换使用，不要一次性全部用掉！
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_shield_05.jpg>) **应对触发效果**
  
  
  
  
  防护 战士拥有许多不同的触发效果，需要及时应对。[[spell:384041]]、[[spell:6572]]、[[spell:29725]]，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主额外引入了[[spell:435607]]和[[spell:437118]]。幸运的是，所有这些只影响3个技能：[[spell:6572]]、[[spell:23922]]和[[spell:6343]]。

1.

### 如何为防护 战士配装

虽然我们总是建议你自己进行模拟以获得理想结果，但我们确实提供了一个专门的防护配装页面。我们目前涵盖了第2赛季装备的建议，以便在至暗之夜终局内容发布时有一个良好的开端。一旦你获得了一些装备，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对12.1.5进行更新和审核。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年10月4日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 将武器附魔替换为哈希伊仪式。
- **2026年10月4日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 将武器附魔替换为哈希伊仪式。
- **2026年10月2日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 更新了巨神兵团队副本配装。将坚如钉甲替换为大屠杀。
- **2026年9月10日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 在饰品列表中添加了嚎叫之核偶像和斯索拉克的凶猛。
- **2026年9月3日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 更新了饰品梯队列表。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 在毕业列表中添加了正确的催化属性。
- **2026年8月18日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 在AOE优先级中添加了盾墙。
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 修复了毕业列表中的腿部附魔。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 饰品调整更新。
- **2026年8月12日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 添加了防御天赋配装导出。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为每种场景添加了防御配装导出字符串。
- **2026年8月11日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 将巨神兵标记为单体目标推荐天赋树。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月26日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 添加了防御性大秘境配装的导入字符串。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月25日（本页）：** 添加了新的热修复信息。
- **2026年5月4日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 更新了斩杀在循环中的使用。
- **2026年5月4日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 更新了巨神兵进攻性团队副本天赋。
- **2026年5月4日（本页）：** 已用最新热修复进行更新。
- **2026年4月30日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 添加了高层防御配装导出。
- **2026年4月27日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 添加了太阳核心点火器。
- **2026年4月23日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 修复了在巨神兵循环下显示雷霆冲击的问题。
- **2026年4月23日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为了易用性，将山丘领主换回作为推荐的团队副本配装。
- **2026年4月22日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 明确了虚空核心的使用方法。
- **2026年4月21日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 在大秘境天赋中将鲜血传承替换为鲜血涌动
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月5日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 更新了山丘领主和巨神兵的单体目标配装。
- **2026年4月3日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 移除了最后一个巅峰天赋作为大秘境的灵活点。
- **2026年4月2日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 修改了山丘领主单体目标优先级。
- **2026年4月2日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 作为山丘领主，雷霆冲击的优先级高于盾牌猛击。
- **2026年3月28日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 明确了宝石选择。
- **2026年3月22日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 修改了单体目标起手式。
- **2026年3月17日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 明确了坚如钉甲的使用方法。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 阐明了浴血奋战与沉重回响之间的选择。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月16日（本页面）：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月13日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月3日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 更新了团队副本配装的措辞。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（本页）：** 已针对至暗之夜进行更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对12.0.1补丁进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对至暗之夜前夕进行审核和更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对至暗之夜前夕进行审核和更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对至暗之夜前夕进行审核和更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对至暗之夜前夕进行审核和更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对至暗之夜前夕进行审核和更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对12.0.1补丁进行更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对12.0.1补丁进行更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对至暗之夜前夕进行审核和更新。
- **2026年2月10日（本页面）：** 已针对至暗之夜前夕进行审核和更新。
- **2026年1月23日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 略微调整了天赋，以便更早获得进攻性技能。
- **2026年1月21日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 使大秘境配装更具机动性。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对至暗之夜前夕进行审核和更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对至暗之夜前夕进行审核和更新。
- **2026年1月19日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对至暗之夜前夕进行审核和更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（本页面）：** 已针对11.2.7补丁进行审核和更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对11.2.5补丁进行更新，添加了卡特尔筹码。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年8月18日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 在天赋选择中添加了重拳出击，以采取更具进攻性的方法。
- **2025年8月13日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 在应用坦克伤害降低后，从毕业列表中移除了恐怖麻袋。
- **2025年8月8日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 为山丘领主调整了大秘境天赋。
- **2025年8月5日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 更新了饰品列表。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月22日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 更新了DISC腰带推荐。
- **2025年6月20日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 热修后，将泰坦神装DISC腰带的推荐从充能箭矢改为致命连锁。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.1.7补丁进行更新。添加了关于辅助循环的信息。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对11.1.7补丁进行审核。添加了关于辅助循环的信息。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月18日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 在代币中添加了光明的奉献之书和即兴塞弗里姆起搏器。
- **2025年5月6日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 添加了关于副本小贴士的信息。
- **2025年4月25日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 更新了关于神秘卡特尔筹码的信息。
- **2025年4月25日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 添加了关于不屈和破坏者的说明。
- **2025年4月25日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 添加了关于不屈和破坏者的说明。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对11.1.5补丁进行审核和更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对11.1.5补丁进行审核。更新了巨神兵天赋树。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对11.1.5补丁进行审核。更新了巨神兵大秘境配装。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5版本进行审查。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-liberation-of-undermine-raid-guide>)):** 更新了加里维克斯部分并添加了小贴士。
- **2025年3月4日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 添加了山丘领主作为推荐的大秘境配装。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（本页面）：** 已针对11.1补丁进行更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月25日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 由于坦克职责倍率，更新了塞尔西的指环宝石。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对11.0.7补丁进行审核，并添加了关于塞尔西的指环的新部分。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对11.0.7补丁进行审核。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 为清晰起见，为天赋添加了推荐标签。已针对11.0.7补丁进行审核。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为清晰起见，为天赋添加了推荐标签。已针对11.0.7补丁进行审核。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（本页）：** 已针对11.0.7补丁进行审查。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 针对11.0.5补丁进行了审阅。
- **2024年9月20日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 调整后，将备用肉钩替换为疯狂女王的敕令作为毕业饰品。
- **2024年9月17日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 在饰品列表中添加了天空恐怖的腐蚀器官。
- **2024年9月17日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** 添加了关于安苏雷克女王的信息。
- **2024年9月13日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 在饰品列表中添加了丝链编织者。
- **2024年9月11日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** 为部分额外首领添加了地震回响作为默认选择。
- **2024年9月11日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 添加了关于姿态的部分。
- **2024年9月11日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 新增了关于法术格挡的章节。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 修复了天赋与输出循环不匹配的问题。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 更新了综合BiS列表。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 更新了食物信息，加入了副属性。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为天赋配置新增了关于浴火奋战和震颤回响的说明。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月30日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 在防御技能列表中加入了法术格挡。
- **2024年8月26日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 新增了地下堡天赋配置。
- **2024年8月23日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 在饰品列表中加入了奥维纳克斯的水银卵和虫群领主的权威。在饰品调整后更新了饰品列表。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月27日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 由于套装仍然可用，移除了勇士之矛天赋。
- **2024年7月27日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 由于套装仍然可用，移除了勇士之矛天赋。
- **2024年7月24日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/protection-warrior-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年7月1日（[地心之战](<https://www.icy-veins.com/wow/protection-warrior-the-war-within-pve-guide>)):** 根据最新的职业改动更新了核心改动和山丘领主章节。
- **2024年6月20日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 新增了关于无视痛苦使用的说明。
- **2024年6月20日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 新增了关于无视痛苦使用的说明。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/protection-warrior-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/protection-warrior-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月10日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 将攻城槌替换为坚韧迅捷。
- **2024年5月8日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 移除了“备选大秘境配置”。在配置中加入了坚韧迅捷。
- **2024年5月8日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 在所有配置中将攻城槌替换为坚韧迅捷。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 为10.2.7进行了复查。将沉重反击替换为乘胜追击。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为10.2.7进行了复查。在大秘境配置中将沉重反击替换为乘胜追击。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 为10.2.7进行了复查。新增了说明和使用乘胜追击的备选大秘境配置。
- **2024年5月7日（本页）：** 为10.2.7补丁进行了复查和更新。
- **2024年4月24日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 阐明了狂乱纵火者火把、源质口袋铁砧和灾难指环的使用方法。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 为第4赛季进行了复查和更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 为第4赛季进行了复查。在功能技能下新增了震荡怒吼章节。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 为第4赛季进行了审阅。
- **2024年3月18日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（本页）：** 针对10.2.6补丁进行了审查。
- **2024年1月22日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 通过加入进攻型天赋更新了AOE循环部分。
- **2024年1月22日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 更新了无视痛苦章节。
- **2024年1月22日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 更新了无边步履和无视痛苦技能。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年12月7日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 在大秘境饰品中将凋零黑暗之心替换为先知的龙鳞。
- **2023年11月30日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 将受折磨的远古之枝加入饰品推荐。
- **2023年11月23日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 更新了输出循环优先级。
- **2023年11月23日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 升级了大秘境装备列表中的项链。
- **2023年11月21日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 新增了关于推荐的美化制作位置的说明。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 从推荐美化中移除了孢子斗篷。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 为10.2补丁进行了复查和更新。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 为10.2补丁进行了复查和更新。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 为10.2版本进行了审查。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 为10.2补丁进行了复查和更新。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 为10.2补丁进行了复查和更新。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为10.2补丁进行了复查和更新。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 为10.2补丁进行了复查和更新。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 为10.2补丁进行了复查和更新。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年10月2日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 将冰霜奉献替换为飘渺奉献。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 为10.1.7补丁进行了复查和更新。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已为10.1.7版本审核。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已为10.1.7版本审核。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 为10.1.7补丁进行了复查和更新。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 为10.1.7补丁进行了复查和更新。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为10.1.7补丁进行了复查和更新。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已为10.1.7版本审核。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已为10.1.7版本审核。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年8月19日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 更新了无边步履和法术反射。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 为10.1.5补丁进行了复查和更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 为10.1.5补丁进行了复查，移除了仇恨插件推荐。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 为10.1.5补丁进行了复查，加入了嗡鸣符文作为选项。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年6月21日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 将霜纹护甲片作为可能的腿部附魔加入。
- **2023年6月21日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 更新了大秘境天赋配置。选择了野蛮活力。
- **2023年6月21日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 更新了大秘境天赋配置。选择了野蛮活力。
- **2023年6月21日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 更新了大秘境天赋配置。选择了野蛮活力。
- **2023年6月5日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 更新了团本天赋配置。将法术格挡作为默认天赋选择。
- **2023年6月5日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 更新了团本天赋配置。将法术格挡作为默认天赋选择。
- **2023年5月24日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 为饰品新增了大灾变时光漫游章节。
- **2023年5月16日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 新增了暗影腰带扣，腰部附魔。
- **2023年5月11日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 将达古尔的印记加入饰品章节。
- **2023年5月11日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 优先展示带有套装的天赋配置。
- **2023年5月11日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 优先展示带有套装的天赋配置。
- **2023年5月9日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 更新了原始宝石。
- **2023年5月9日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 更新了原始宝石。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（本页）：** 为10.1.0补丁进行了更新。
- **2023年4月28日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 为10.1.0补丁进行了更新。
- **2023年3月24日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 更新了原始宝石列表。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 更新了原始宝石列表。
- **2023年3月22日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 将嗡鸣的奥术宝石作为可行的宝石加入，并更新了玛瑙纪念戒指的使用场景。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 将嗡鸣的奥术宝石作为可行的宝石加入，并更新了玛瑙纪念戒指的使用场景。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 将雷霆领主替换为攻城槌，并为10.0.7补丁进行了复查。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/protection-warrior-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 新增了关于原始宝石的信息，并为10.0.7补丁进行了复查。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 新增了关于原始宝石的信息，并为10.0.7补丁进行了复查。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已针对10.0.7补丁进行审核。
- **2023年3月15日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 更新了天赋配置，默认选择攻城槌而非雷霆领主。
- **2023年3月15日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 更新了大秘境天赋配置，默认选择攻城槌而非雷霆领主。
- **2023年3月15日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 更新了大秘境天赋配置，默认选择攻城槌而非雷霆领主。
- **2023年2月27日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 在技能列表中加入了雷霆咆哮、盾牌冲锋。
- **2023年2月27日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 在起手技能中将雷霆咆哮的优先级上调。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-castle-nathria-raid-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[统御圣所页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sanctum-of-domination-raid-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2022年12月26日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 在饰品列表中加入了低语化身图腾。
- **2022年12月26日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 新增了更多急速宝石推荐。
- **2022年12月23日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 将一些化身宝库的饰品加入了值得注意的饰品列表。
- **2022年12月23日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 新增了关于攻城槌、法术格挡和赛季词缀的说明。
- **2022年12月23日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 新增了关于法术格挡的说明。
- **2022年12月21日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 更新了天赋模拟器选择顺序。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 更新了装备推荐，加入了套装和美化推荐。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 将智慧奉献武器附魔替换为更具进攻性的冰霜奉献。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 新增了关于套装输出循环变化的段落。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 在团本配置中将压倒性之怒替换为副手武器。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 在团本配置中将压倒性之怒替换为副手武器。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[托加斯特](<https://www.icy-veins.com/wow/protection-warrior-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-castle-nathria-raid-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[统御圣所页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sanctum-of-domination-raid-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/protection-warrior-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/protection-warrior-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/protection-warrior-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/protection-warrior-patch-9-2-changes-analysis>)):** 为9.2补丁的发布进行了复查。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/protection-warrior-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** 为9.1.5进行了更新。
- **2021年7月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** 移除了PTR相关内容。
- **2021年6月4日（[9.1 补丁分析](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** 新增了格里恩专属的传说物品信息。
- **2021年5月18日（[9.1 补丁分析](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** 新增了新传说之力的描述。
- **2021年4月27日（[9.1 补丁分析](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** 页面已创建。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年8月26日（[永恒宫殿页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-the-eternal-palace-raid-guide>)):** 新增了一些首领提示。更新了精华推荐。
- **2019年7月15日（[永恒宫殿页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-the-eternal-palace-raid-guide>)):** 新增了几个首领提示。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-crucible-of-storms-raid-guide>)):** 添加了首领提示。
- **2019年4月16日（[风暴熔渣页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-crucible-of-storms-raid-guide>)):** 页面已添加。
- **2019年3月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-battle-of-dazar-alor-raid-guide>)):** 增加了关于格罗尔的额外信息。
- **2019年2月6日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-battle-of-dazar-alor-raid-guide>)):** 为每个首领增加了提示。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** 针对8.1补丁进行了更新。
- **2018年9月29日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** 增加了关于维克提斯法术反射的说明。
- **2018年9月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** 为每个首领增加了提示。
- **2018年8月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** 已添加页面（目前为空）。

显示更多

显示更少

:::

## 练级

在本页中，你将找到我们为战士防护专精编写的逐级练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[战士练级指南](<https://www.icy-veins.com/wow/warrior-leveling-guide>).

1.

### 至暗之夜：战士防护练级指南

得益于作为坦克专精，战士防护在做任务时可以进行大规模拉怪并轻松存活下来。四处奔跑，尽可能多地给敌人上标记，然后将它们聚在一起击杀，可以快速完成任务。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>)练级提示
作为一名坦克，你应该在做任务的间隙排队进入地下城。完成地下城可以获得大量经验值，而且作为坦克，你的排队时间会比DPS专精更快。地下城中的敌人通常更强，提供的经验值也更多，而且它们使用的技能也比你在做任务时遇到的小怪更多。

这意味着在地下城中，你需要更加专注，并以更有策略的方式使用你的技能。这反过来会让你更好地了解职业，为终局内容做好准备。

:::

1.1.

#### 升级装备选择

在练级过程中，你应该始终选择物品等级最高的装备。这条规则唯一的例外是，如果你有一个戒指或项链，其物品等级略低，但拥有2项副属性而不是1项。

或者，你可以购买传家宝物品。这些物品会随你的等级提升而增强，意味着你在练级过程中不需要更换装备。如果你选择这种方式，请优先选择带有急速的物品。

1.2.

#### 至暗之夜升级实用消耗品

在每个新资料片开始时，每个人心中最关心的事情就是如何达到最高等级。对于至暗之夜，最高等级是90级。有各种物品可以提升你的练级速度和效率，让你充分利用游戏时间。

- [[item:132516]]——巨大的移动速度提升，在坐骑无法使用时也能生效，且比地面坐骑快得多。
- [[item:109076]]——让你从悬崖边滑翔出去，快速覆盖很远的距离。
- [[item:172063]]——在你击杀敌人时给你一个速度增益。
- [[item:168412]]——别忘了这件坐骑装备，它能让你的坐骑在地面上更快。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 防护 80级 至暗之夜 练级
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZMzMzMzY2MzYGjxMNMzwiZMzYGmZAAAAwyAwMGgBALLoxMAGYmNYmZGY2AgZGAAGAD"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZMzMzMzY2MzsMjxYmGmZYxMzMjZYmBAAAALDAzYAGYDWWMaMDgZDzsBmZmBzGAMzAAwAGD"
}
```
:::

:::details 来源计算器编码
```
#JB-JDLCneVEcRXOIvNNRRZBZ0pUqpBGE8NKJFC-CFEMNKLmIJPehOXiiw+O2kaRVGopCQG-AAAA-TAEY0wsgM4gQZQ-
```

:::

2.1.

#### 升级用战争模式天赋

以下是推荐用于练级以及单人/小型队伍PvE内容的PvP天赋。你可能会发现不同的PvP天赋更适合你的游戏风格。鼓励你进行尝试！

1. [[spell:199023]]能显著缩短[[spell:1160]]的冷却时间，配合[[spell:202743]]可带来更多的减伤和伤害输出。
2. [[spell:206572]]能提升机动性，并对路径上的目标造成中等伤害。
3. [[spell:199127]]通过更频繁的暴击，为盾牌猛击和毁灭打击提供近乎持续的伤害提升。
4.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–2：**从1级开始，你只有一个主动技能：[[spell:1464]]。

1. **等级 2 起：**尽可能使用[[spell:100]]发起战斗。
2. **等级 5–15：**每当敌人被击杀时，[[spell:34428]]就会激活。使用它来治疗自己。
3. **等级 16 起：**在需要时使用[[spell:202168]]治疗自己。
4. **等级 53 起：**施放[[spell:107574]]以产生少量怒气并大幅提升你的伤害。
5. **等级 16 起：**施放[[spell:1160]]以减少你受到的伤害，并增加你造成的伤害（当使用[[spell:202743]]天赋时）。
6. **等级 55 起：**施放[[spell:385952]]。
7. **等级 3–9：**施放[[spell:23922]]以造成大量伤害。
8. **等级 10 起：**施放[[spell:23922]]以产生怒气并造成伤害。
9. **等级 10 起：**施放[[spell:6343]]以产生怒气并造成范围伤害。
10. **等级 10 起：**当敌人生命值低于20%时，施放[[spell:163201]]。
11. **等级 10 起：**务必时刻保持自己和队友身上有[[spell:6673]]。
12. **等级 9–12：**如果你不需要将怒气用于主动减伤来保命，可以将怒气花在[[spell:1680]]上以伤害多个目标。
13. **等级 13 起：**如果你不需要将怒气用于主动减伤来保命，可以将怒气花在[[spell:6572]]上以伤害多个目标。
14. **等级 3–13：**将[[spell:1464]]作为填充技能施放。

3.1.

#### 主动减伤

- 在坦怪并承受大量物理伤害时，尽可能频繁地施放[[spell:2565]]。
- 将怒气花在[[spell:190456]]上，进一步平滑你承受的伤害。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 已针对12.0.1补丁进行更新。
- **2026年1月23日：** 略微调整了天赋，以便更早获得进攻性技能。
- **2026年1月19日：** 已针对至暗之夜前夕进行审核和更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 修复了天赋与输出循环不匹配的问题。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月10日：** 将攻城槌替换为坚韧迅捷。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月23日：** 更新了输出循环优先级。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 将雷霆领主替换为攻城槌，并为10.0.7补丁进行了复查。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月21日：** 更新了天赋模拟器选择顺序。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩战士防护，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，且不牺牲性能。

1.

### 战士防护基础

本页面面向刚接触游戏或该职业的玩家，他们不打算参与史诗难度团队副本，或者只是想要一种更直接的方式来游玩他们的专精，而不会被为实现最优游玩所需考虑的众多细节和主动技能所淹没。

防护系战士拥有出色的机动性和多样的工具组，在功能性和防御手段方面皆是如此。由于能够格挡攻击，防护系战士的承受伤害可预测且平稳，使其相对容易被治疗。

在整个战斗过程中，你的首要目标将是最大化怒气获取，然后将这些怒气用于你的主动减伤技能以保命。合理利用你的防御冷却技能和实用技能也是正确游玩的重要组成部分。以下是你在学习专精时可以参考的三个重点：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_warcry.jpg>) **管理你的怒气**
  
  
  
  
  怒气是你用于施放技能的主要资源：[[spell:2565]]、[[spell:6572]] 和 [[spell:190456]]。尽可能多地产生怒气同时最小化浪费的怒气应该是你的主要目标之一。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_defend.jpg>) **使用你的防御技能**
  
  
  
  
  作为坦克，你的主要职责是让敌人以你为目标。为了帮助你抵御猛攻，你需要充分利用你的防御技能。[[spell:2565]]、[[spell:871]]、[[spell:1160]]、[[spell:23920]] 甚至 [[spell:190456]] 都能提升你的防御能力——只要确保轮换使用，不要一次性全部用掉！
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_shield_05.jpg>) **应对触发效果**
  
  
  
  
  防护 战士拥有许多不同的触发效果，需要及时应对。[[spell:384041]]、[[spell:6572]]、[[spell:29725]]，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主额外引入了[[spell:435607]]和[[spell:437118]]。幸运的是，所有这些只影响3个技能：[[spell:6572]]、[[spell:23922]]和[[spell:6343]]。

1.

### 防护系战士在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主单体天赋

2.1.

#### 防护系战士的单体天赋

这套天赋是攻防兼备的良好组合，是一个对新手友好的全能好用的点法。

**请务必使用「复制」按钮，将配装方案直接导入到你的游戏中！**

:::talents 单体简单模式
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZGzMzMzMmNzMLzYMmphxwyMzMzgxMDAAAAWGAmxAMwGssY0YGAzGmZDmxMDmNAYmBAgZgxA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZGzMzMzMmNzMLzYMmphxwyMzMzgxMDAAAAWGAmxAMwGssY0YGAzGmZDmxMDmNAYmBAgZgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLPQRVemCEGYcdkPdMNRRtNWGEIJpp9BGC-CFMNEKLDIJPXw8+CdiikSVZltRWGo5A-AAAA-JQSU2AEUwAjDmF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 副本天赋

2.2.

#### 防护 战士的史诗钥石地下城与地下堡天赋

这是一套适用于任何AOE场景的可靠入门天赋，无论是地下城还是
[地下堡](<https://www.icy-veins.com/wow/delves-guide>).

**请务必使用「复制」按钮，将配装方案直接导入到你的游戏中！**

:::talents AOE简单模式
```json
{
  "code": "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsYmZZGjxMNmxwiZmZGzwMDAAAAWGAmxAMwGstY0YGAzSMzGMzMzwYBAmZAAYAjB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzYmZmZmxsYmZZGjxMNmxwiZmZGzwMDAAAAWGAmxAMwGstY0YGAzCmZDmZmZYsAAzMAAMgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJWGEIJpp9BGC-CFMNEKLmHIJPXw8+CdiikQVZltRWGoB-AAAA-JQSU0AEU4AjDmF-
```

:::

### 战士防护基础输出循环

2.3.

#### 防护 战士基础循环

作为一名战士防护，基础输出循环基于以下优先级。如前所述，这是一个 <em>优先级</em>列表。它并非技能施放的确切顺序，而是每次当你能够施放技能时，你应该从列表顶部开始，施放第一个可用的技能。

:::details 常见问题：我应该以防御还是进攻的方式游戏？
这是大多数人在玩坦克时会问的主要问题。基本答案是，如果你在开荒进度，或者你使用一个让自己在进攻端感到不自在的角色，你应该采取防御姿态。

当你开始感到得心应手时，你可以开始关注输出，并采用一种更混合的风格，在逐步提升输出的同时慢慢牺牲一些生存能力。

一旦你对战斗完全有把握，并且不会拖累你的团队，你就可以全力追求输出。这个阶段因人而异，取决于你的团队、你的角色、你的装备以及你的技术水平。

:::

我们最具玩法改变性的天赋组合是[[spell:107574]]和[[spell:275336]]。我们在输出循环页面中有专门针对这个组合的部分！

如果你的下一次施放会使你超出怒气上限，[[spell:190456]]的优先级将高于任何其他技能。否则，使用[[spell:190456]]来消耗多余的怒气，因为它不占用全局冷却。此外，确保在主动坦怪时始终开启[[spell:2565]]。

1. 卡CD施放[[spell:107574]]。
2. 卡CD施放[[spell:1160]]。
3. 如果点了天赋，卡CD施放[[spell:228920]]。
4. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵：好了就用[[spell:436358]]。
5. 如果点了天赋，卡CD施放[[spell:385952]]。
6. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主：一旦触发就使用[[spell:435607]]。
7. 卡CD施放[[spell:23922]]。
8. 卡CD施放[[spell:6343]]。
9. 如果你不需要怒气来保命，施放[[spell:163201]]。在AOE场景中不要使用它。
10. 如果你不需要怒气来保命，施放[[spell:6572]]。

面对多个目标时，使用上述优先级仍然会产生最多的怒气，从而让你能使用最多的主动减伤并获得最佳的生存能力。

作为额外的优先级，确保在进入战斗前用[[spell:6673]]为自己和队伍施加增益。

虽然上述内容简要说明了如何以及何时使用每个技能，但在各种法术之间还有更多具体的细节和互动。理解所有这些对于 **至关重要** ，作为一名战士防护而言。

2.3.1.

##### 巅峰天赋： ![Phalanx Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_1115_warrior_improvedparry.jpg>) 英武方阵

巅峰天赋能强化你的[[spell:23922]]和[[spell:6343]]，并在前方锥形区域提供额外伤害。额外伤害效果会在你施放雷霆一击后的下一次盾牌猛击时激活。这意味着 **巅峰天赋完全不会影响你的输出循环。** 我们本来就优先卡CD施放这两个技能，因为它们是怒气产生技能，所以只要你正确执行输出循环，你就能从巅峰天赋中受益。

2.3.2.

##### 第2赛季套装

第2赛季的套装迫使我们将更多注意力放在4件套提供的免费[[spell:6572]]施放上。一旦你有了4件套，未能施放免费的[[spell:6572]]将导致明显的伤害损失。

- [[spell:1296647]]
- [[spell:1296648]]

### 战士防护冷却技能与减伤

2.4.

#### 防护 战士的爆发技能与减伤

作为一名坦克，你的主要目标是获得敌人的仇恨并存活下来。为了帮助你实现这一目标，我们有各种工具可以帮助你减免伤害或从中恢复。正确使用这些技能至关重要，否则将导致死亡。

2.5.

#### 防护战士的主动减伤技能

你的输出循环只是为了给你产生怒气，然后你应该将这些怒气投入到你的主动减伤技能[[spell:2565]]和[[spell:190456]]中。

[[spell:2565]]是你的主要主动减伤技能。每当你在主动坦怪时都应使用，并尽可能保持其覆盖。使用它优先于使用[[spell:190456]]。当你不坦怪时，如果你即将达到2层充能（上限），通常应该消耗一层。即使在不坦怪时，盾牌格挡也能使[[spell:23922]]的伤害提高30%。

[[spell:190456]]应该 <em>在</em> [[spell:2565]]之外使用。盾牌格挡受限于其冷却时间，而无视苦痛仅受限于你可用的怒气数量。因此，一旦你开启了盾牌格挡并让其进入冷却，就将剩余的怒气花在无视苦痛上，同时确保留有足够的怒气在盾牌格挡冷却完毕后使用。如果你知道即将承受大量伤害，值得积攒怒气，以便在伤害生效前一刻施放无视苦痛，从而提高你存活下来的几率。

2.6.

#### 防护战士的爆发技能使用

作为一名战士防护，你可以通过天赋点出若干防御冷却技能。

- 在你即将承受大量伤害之前，应使用[[spell:871]]。它能降低 **全部** 在持续时间内使你受到的伤害降低40%。由于它持续时间相当长，你应该尽量在承受高额伤害的较长时间段内使用它。如果点出了 [[spell:12975]]，它还会使你的生命值提高30%，并治疗你等量的生命值。
- [[spell:1160]] 和 [[spell:202743]] 应该在战斗中尽可能多地使用以产生怒气，正如技能优先级中所述。然而，以下做法绝对值得
  <em>非</em> 以这种方式使用它，或者如果你在高伤害阶段需要另一个冷却技能，则将其留作备用。
- [[spell:23920]] 会将下一个对你施放的法术反射回施法者，并在5秒内（或直到反射一个法术）使你受到的魔法伤害降低25%。大多数造成魔法伤害的首领技能无法被反射。因此，法术反射的主要用途是减免魔法伤害，而非反射法术。
  
  
  
  
  提前了解那些魔法伤害的来源并相应地使用法术反射非常重要。你可以通过点出 [[spell:1235022]] 来进一步增强这个技能的效果。

2.6.1.

##### 进攻性冷却技能

你可能不会拥有全部这些技能，这取决于你选择的天赋。

- 卡着冷却时间施放 [[spell:107574]]。如果你玩的是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主，一旦你点出 [[spell:275336]]，[[spell:6343]] 就会在每个其他公共冷却时间后可用。请注意这一点，并确保继续遵循技能优先级。
  
  
  
  
  你可能会遇到不断在 [[spell:23922]] 和雷霆一击之间轮换的情况，因为雷霆一击会重置盾牌猛击。在这种情况下，你应该更加注意你的怒气条，以避免怒气溢出，并使用 [[spell:190456]] 或 [[spell:6572]] 来消耗一些怒气。
- [[spell:376079]]、[[spell:385952]] 和 [[spell:228920]] 都是我们可以通过天赋选择的各种进攻性冷却技能。通常它们的使用很直接，不需要任何特定的预先规划或站位。尽量卡着冷却时间施放它们，并在 [[spell:1160]] 和 [[spell:107574]] 期间施放，以最大化它们的伤害潜力。

### 防护 战士 属性优先级

2.7.

#### 防护 战士 的属性优先级

目前，你应该按以下顺序优先考虑次级属性。有关本页内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>).

装备等级

急速

暴击

全能

精通

**全能大致与暴击持平。全能为你提供持续的伤害减免，并且对魔法伤害也有效，但暴击在通过招架减免物理攻击方面表现出色，并且能更大幅度地提高造成的伤害。**

**一般来说，属性优先级只应在比较相同物品等级的装备时遵循。无论次级属性如何，都应该装备物品等级高于你当前装备的装备。**

### 暴风雪战斗助手

2.8.

#### 防护 战士 战斗助手

该 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 是 [11.1.7补丁](<https://www.icy-veins.com/wow/patch-11-1-7-guide>) 中引入的一项功能，简单来说，它会帮助你进行基础的进攻循环。要了解更多关于这个新功能的信息，我们建议查看我们的 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 指南。

:::details 常见问题我应该使用战斗助手吗？
它在可接受的水平上可用， **只要你穿插使用你的进攻和防御冷却技能**。它相当好地遵循了我们的基础输出循环优先级， **但如果你想充分发挥这个职业的潜力，我们不建议使用它。**

助手只会施放你的基础进攻技能，为了生存，你仍然需要自己使用你的进攻冷却技能和像 [[spell:2565]]、[[spell:190456]] 等防御技能。

:::

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月2日：** 作为山丘领主，雷霆冲击的优先级高于盾牌猛击。
- **2026年3月16日：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行审核和更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已针对11.1.7补丁进行审核。添加了关于辅助循环的信息。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月11日：** 新增了关于法术格挡的章节。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月27日：** 由于套装仍然可用，移除了勇士之矛天赋。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年6月20日：** 新增了关于无视痛苦使用的说明。
- **2024年5月8日：** 在所有配置中将攻城槌替换为坚韧迅捷。
- **2024年5月7日：** 为10.2.7进行了复查。新增了说明和使用乘胜追击的备选大秘境配置。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了复查和更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月21日：** 更新了大秘境天赋配置。选择了野蛮活力。
- **2023年6月5日：** 更新了团本天赋配置。将法术格挡作为默认天赋选择。
- **2023年5月11日：** 优先展示带有套装的天赋配置。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年3月15日：** 更新了大秘境天赋配置，默认选择攻城槌而非雷霆领主。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 在团本配置中将压倒性之怒替换为副手武器。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页，你将找到《魔兽世界》12.1.5补丁中 防护 战士 的最佳天赋。我们还提供了适用于不同内容（如团队副本或大秘境）的默认天赋构建。如果你开启了战争模式进行游戏，我们也涵盖了你的PvP天赋。

1.

### 防护 战士 的最佳 至暗之夜 天赋

在第2赛季，防护 战士 处于非常有利的地位。我们的两个英雄天赋都是可行的，可以在任何地方使用，而不会对整体表现造成太大影响。

- **纯单体目标 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵 目前在单体目标伤害输出方面领先。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 如果你喜欢那种玩法风格，山丘领主 也不遑多让。
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 在范围伤害输出上胜出。它提供的伤害类型非常适合大秘境等范围场景。话虽如此， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 在大秘境中使用 巨神兵 也不会对你造成任何显著的阻碍。

**快速开始导入代码：**

:::talents 单体目标 - 巨神兵
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGz0wYYZmZmZwYmBAAAALDAzYAgFzYYDGYGWoxMLMmxMDmNAAzMAgZgxA"
}
```
:::

:::talents 范围伤害 - 山丘领主
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDwAbw2iRjZAMLYmNYmZmhxCAMzAAwAGD"
}
```
:::

:::talents 地下堡 - 山丘领主
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzYmZmZmxsYmZZGjxMNmxwiZmZGzwMDAAAAWGAmxAMwGstY0YGAzCmZDmZmZYsAAzMAAMgxA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

山丘领主

团队副本

秘境+

推荐

巨神像

团队副本

推荐

秘境+

### 天赋方案 0-0

1.1.

#### 山丘领主 团队副本天赋

这个构建是进攻和防御天赋的良好结合，使其成为一个优秀的全能型团队副本构建。

[[spell:115767]]、[[spell:384063]] 和 [[spell:385840]] 可以被视为灵活点数，可以放置在其他地方以采取更偏防御的方案。对于会频繁对你进行普通攻击的首领，[[spell:385888]] 值得投入这个点数，否则不要点它。

在你可以用 [[spell:163201]] 持续顺劈2-3个目标的战斗中，可以使用 [[spell:156135]]。

:::details 常见问题选择浴血奋战还是沉重报复？
在团队副本中，你可以默认选择

[[spell:202603]]

。虽然

[[spell:203177]]

在急速较低时更好，但在团队副本中这并不那么重要，因为你不会100%的时间都在主动坦怪。

**如果你确实觉得需要更高的 [[spell:2565]] 覆盖率，仍然应该选择 [[spell:203177]]。**

:::

### 天赋方案 0-1

1.2.

#### 山丘领主 范围伤害天赋

以下构建应该作为标准大秘境和 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 构建的基础，因为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主.

从专精天赋树中，[[spell:385888]] 和 [[spell:385704]] 都可以自由调整位置。[[spell:1271948]] 可以替换为 [[spell:383082]] 以获得更多伤害输出。

:::details 常见问题选择浴血奋战还是沉重报复？
对于地下城等范围伤害内容，我们建议选择

[[spell:203177]]

，在急速较低时，因为你会需要额外的

[[spell:2565]]

覆盖率。随着你急速的提高，你的

[[spell:2565]]

冷却时间会缩短，因此你应该切换到

[[spell:202603]]

以获得其进攻能力。

:::

### 天赋方案 1-0

1.3.

#### 巨神兵 团队副本天赋

扎实的全能型 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵 团队副本构建，它提供了与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主.

不同的玩法。[[spell:384063]] 和 [[spell:385840]] 可以被视为灵活点数，可以放置在其他地方以采取更偏防御的方案。对于会频繁对你进行普通攻击的首领，[[spell:385888]] 值得投入这个点数，否则请将点数放在其他地方。

在你可以用 [[spell:163201]] 持续顺劈2-3个目标的战斗中，可以使用 [[spell:156135]]。

:::details 常见问题选择浴血奋战还是沉重报复？
在团队副本中，你可以默认选择

[[spell:202603]]

。虽然

[[spell:203177]]

在急速较低时更好，但在团队副本中这并不那么重要，因为你不会100%的时间都在主动坦怪。

**如果你确实觉得需要更高的 [[spell:2565]] 覆盖率，仍然应该选择 [[spell:203177]]。**

:::

### 天赋方案 1-1

1.4.

#### 巨神兵 范围伤害天赋

从专精天赋树中，[[spell:385888]] 和 [[spell:385704]] 都可以自由调整位置。一旦你对 [[spell:2565]] 的覆盖率感到满意，就可以将 [[spell:203177]] 替换为 [[spell:202603]] 以获得更多伤害输出。[[spell:1271948]] 可以替换为 [[spell:383082]] 以获得更多伤害输出。

:::details 常见问题选择浴血奋战还是沉重报复？
对于地下城等范围伤害内容，我们建议选择

[[spell:203177]]

在急速较低的前期，因为你会需要额外的

[[spell:2565]]

覆盖率。随着你急速的提高，你的

[[spell:2565]]

冷却时间会缩短，因此你应该切换到

[[spell:202603]]

以获得其进攻能力。

:::

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMjxYmGGDLzMzMDGzMAAAAYZAYGDwAbwyiRjZAMbYmNYGzMY2AgZGAAmBGD"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLPQRVemCEGYcdkPdMNRRtNWGEIJpp9BGC-CFMNEKLDIJPXw8+CB6AFFJlyKbjsMQD-AAAA-JQSU2AEUwAjDmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDwAbw2iRjZAMLYmNYmZmhxCAMzAAwAGD"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJWGEIJpp9BGC-CFMNEKLmIJPXw8+CdiikQVZltRWGoBA-AAAA-JQSU0AEU4AjDmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGz0wYYZmZmZwYmBAAAALDAzYAgFzYYDGYGWoxMLMmxMDmNAAzMAgZgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLPQRVemCEGYcdkPdMNRRtNWGEIJpp9BGC-CFMNEKLDIJPXw8+CB6AFFJlyajsMQjI-AAAA-AcgQphYhBTgwwC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDAsYGDLwAzwCNmZBmZmZYsAAYmBAMgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJGEIJ9FWqpBC-CFMNEKLmIJPXw8+CB4EFJhqyKbjsMQD-AAAA-AcgQphQhBTgwwC-
```

:::

### 天赋方案 0-0

如果想要更偏防御的构建，请尝试下面的导入内容。这个构建牺牲了 **大量**
的进攻价值以换取更多防御能力。

:::talents 防御型团队副本构建
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZGmZmZmxsZmZZGjxMNMGWmZmZGMmZAAAAwyMDwMGgB2glFjGzAY2wMbgxMDmNAYmBAgZgxA"
}
```
:::

### 天赋方案 0-1

下面是一个适用于大秘境的极端防御型构建示例。当你因为承受的伤害过高而对某些层数感到不适时，可以使用它。

:::talents 防御型大秘境构建
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzwMzMzMmFzMLzYMmpxMGWMzMzYGmZAAAAwyMDwMGgB2gtFjGzAYWwMbYYmZYsAAzMAAMgxA"
}
```
:::

### 天赋方案 1-0

如果想要更偏防御的构建，请尝试下面的导入内容。这个构建牺牲了 **大量** 的进攻价值。

:::talents 防御型团队副本构建
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZGmZmZmxsZmZZGjxMNMGWmZmZGMmZAAAAwyMDwMGAYxMG2gBmhFaMzCYMzgZDAwMDAYGYMA"
}
```
:::

### 天赋方案 1-1

下面是一个适用于大秘境的极端防御型构建示例。当你因为承受的伤害过高而对某些层数感到不适时，可以使用它。

:::talents 防御型大秘境构建
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzwMzMzMmFzMLzYMmpxMGWMzMzYGmZAAAAwyMDwMGAYxMGWgBmhFaMzCYmZGGLAAmZAADYMA"
}
```
:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

万卷全书是 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)中引入的一个成长系统，提供了一系列可以增强你角色的次要自定义选项。通过一个限时解锁的任务线解锁，万书提供了一系列符文，可以提供进攻、防御和功能性的增益效果。

以下是推荐的起手增益列表。你也可以尝试其他选项，因为你可以随时在它们之间切换。

- 第1周：[[spell:1279599]]
- 第2周：[[spell:1279603]]
- 第3周：[[spell:1287555]]
- 第4周：[[spell:1279609]]
- 第5周：[[spell:1279614]]

[[spell:1279610]] 和 [[spell:1279609]] 可以互相替换。

1.

### 巅峰天赋： ![Phalanx Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_1115_warrior_improvedparry.jpg>) 英武方阵

[[spell:1269313]] 增强了我们的核心循环技能 [[spell:6343]] 和 [[spell:23922]]，提高了它们造成的伤害。它还会使你在 [[spell:6343]] 之后施放的下一个 [[spell:23922]] 在前方锥形范围内造成额外伤害。

虽然巅峰天赋增强了我们的核心循环技能，但它们并没有提供任何有意义的玩法改变。只要正确地进行循环，你就能获得巅峰天赋的全部收益，从而带来整体伤害的提升。

需要注意的一点是，我们的巅峰天赋几乎是完全偏向进攻的。[[spell:1269311]] 确实会少量降低敌人对你造成的伤害，但除此之外，它完全是进攻性的。

1.

### 英雄天赋

防护 战士 在达到71级时，将可以访问两个额外的天赋树之一，称为英雄天赋。这两个英雄天赋是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵，根据你选择的不同，它们提供不同的玩法风格和优势。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 英雄天赋专注于增强你现有的能力。该天赋树的核心是将 [[spell:6343]] 变成一个更强大的 [[spell:435607]]。天赋本身的设计为我们提供了一个有趣的反馈循环，如下所述。

- [[spell:437118]] 使 [[spell:434969]] 能够触发 [[spell:23922]]
- [[spell:384041]] 能够触发 [[spell:23922]]
- [[spell:23922]] 能够触发 [[spell:435607]]
- [[spell:435607]] 能够通过 [[spell:437079]] 触发 [[spell:434969]]

如上表所示，整个天赋树在保持我们循环流畅性的同时，创造了一个正向的怒气反馈循环。更好的怒气经济是主要区别 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵 独树一帜。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵 的天赋树围绕着 [[spell:436358]] 以及强化你的流血效果、[[spell:6572]] 和 [[spell:23922]] 的伤害展开。虽然 [[spell:436358]] 不产生任何怒气，但它的伤害极高，并且能强化我们的其他技能。与重度依赖连按的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 相比，它的循环节奏不同，更加讲究条理。你需要在怒气的使用上多加思考，同时尽量最大化每一次 [[spell:436358]] 的施放。

1.

### PvP天赋（战争模式）

开启战争模式使你有资格参与开放世界PvP，但也会为你带来以下好处：

- 满级后的世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 授予你在开放世界中使用PvP天赋的权限。

鉴于开启战争模式对升级和PvE内容的好处，我们建议你启用此功能，以最大化你的升级过程和满级后的奖励。然而，你会使自己有资格参与开放世界PvP，在升级或做世界任务时存在被“偷袭”的可能性。

以下是练级和PVE内容推荐的PvP天赋。你可以选择一个通用PvP天赋和三个专精特定的天赋。

- [[spell:199023]] 使 [[spell:1160]] 的冷却时间缩短15秒，使其冷却时间变为30秒，并使敌人对所有目标造成的伤害降低，而不仅仅是对你。这使得 [[spell:1160]] 可以保持极高的覆盖率。
- [[spell:206572]] 使你向目标方向长距离高速冲锋。它不需要目标。它会对冲锋路径上的敌人造成伤害并将其击退。这个天赋提供的移动能力对于做任务或脱离危险情况非常有用。在移动方面，它几乎相当于多了一个 [[spell:6544]]。
- [[spell:213871]] 是帮助你降低盟友所受物理伤害的绝佳工具。
- [[spell:236077]] 是另一个你可以选择的非常强力的选项。它使你能够显著降低依赖武器伤害的职业的输出。

这些仅仅是推荐。根据你的游戏风格，你可能会发现其他PvP天赋更有用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5进行更新和审核。
- **2026年10月2日：** 更新了巨神兵团队副本配装。将坚如钉甲替换为大屠杀。
- **2026年8月12日：** 为每种场景添加了防御配装导出字符串。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月26日：** 添加了防御性大秘境配装的导入字符串。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年5月4日：** 更新了巨神兵进攻性团队副本天赋。
- **2026年4月30日：** 添加了高层防御配装导出。
- **2026年4月23日：** 为了易用性，将山丘领主换回作为推荐的团队副本配装。
- **2026年4月21日：** 在大秘境天赋中将鲜血传承替换为鲜血涌动
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月5日：** 更新了山丘领主和巨神兵的单体目标配装。
- **2026年4月3日：** 移除了最后一个巅峰天赋作为大秘境的灵活点。
- **2026 年 3 月 17 日：** 明确了坚如钉甲的使用方法。
- **2026年3月16日：** 阐明了浴血奋战与沉重回响之间的选择。
- **2026年3月13日：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年3月3日：** 更新了团队副本配装的措辞。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 已针对12.0.1补丁进行更新。
- **2026年1月21日：** 使大秘境配装更具机动性。
- **2026年1月19日：** 已针对至暗之夜前夕进行审核和更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月25日：** 添加了关于不屈和破坏者的说明。
- **2025年4月21日：** 已针对11.1.5补丁进行审核。更新了巨神兵大秘境配装。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 为清晰起见，为天赋添加了推荐标签。已针对11.0.7补丁进行审核。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 为天赋配置新增了关于浴火奋战和震颤回响的说明。
- **2024年8月26日：** 新增了地下堡天赋配置。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月27日：** 由于套装仍然可用，移除了勇士之矛天赋。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 为10.2.7进行了复查。在大秘境配置中将沉重反击替换为乘胜追击。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了复查和更新。
- **2023年9月4日：** 为10.1.7补丁进行了复查和更新。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月21日：** 更新了大秘境天赋配置。选择了野蛮活力。
- **2023年6月5日：** 更新了团本天赋配置。将法术格挡作为默认天赋选择。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年3月15日：** 更新了大秘境天赋配置，默认选择攻城槌而非雷霆领主。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月23日：** 新增了关于法术格挡的说明。
- **2022年12月11日：** 在团本配置中将压倒性之怒替换为副手武器。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何根据你所承受的伤害类型来优化你的 防护 战士 的循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以最大化你的生存能力和DPS。我们所有的内容均已更新至《魔兽世界》12.1.5补丁。

1.

### 防护 战士 游戏玩法与循环指南

欢迎来到我们的 防护 战士循环页面。在本页中，你将找到关于在团队副本和大秘境场景中实际操作该专精所需了解的一切。

在下方选择天赋和英雄天赋后，本指南中的循环将会相应更新。

:::details 常见问题：我应该以防御还是进攻的方式游戏？
这是大多数人在玩坦克时会问的主要问题。基本答案是，如果你在开荒进度，或者你使用一个让自己在进攻端感到不自在的角色，你应该采取防御姿态。

当你开始逐渐适应后，你应该开始更多地关注DPS，并采用更加混合的风格，在追求DPS的同时慢慢牺牲一些生存能力。

一旦你对战斗完全有把握，并且不会拖累你的团队，你就可以全力追求输出。这个阶段因人而异，取决于你的团队、你的角色、你的装备以及你的技术水平。

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主

单体目标

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

天赋选择

[[spell:107574]]

[[spell:385952]]

[[spell:202743]]

[[spell:376079]]

[[spell:228920]]

[[spell:1261060]]

[[spell:29725]]

[[spell:385704]]

[[spell:1271948]]

[[spell:456270]]

### 单体目标起手

**适用条件：Ravager（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/970854.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132337.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/136080.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/613534.webp>)

**适用条件：巨神像（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/136105.webp>)

**适用条件：山丘领主（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/460957.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132110.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/134951.webp>)

**适用条件：Booming Voice（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132366.webp>)

**适用条件：勇士之矛（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wowt/icons/6035322.webp>)

**适用条件：巨神像（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/5927618.webp>)

**适用条件：山丘领主（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/460957.webp>)

**适用条件：Shield Charge（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/4667427.webp>)

1.1.

#### 防护 战士 单体起手式

通常情况下，你应该在施放 [[spell:100]] 的同时使用 [[spell:355]]。

1. **适用条件：Ravager（启用）。** 施放 [[spell:228920]]。
2. 施放 [[spell:100]]。
3. 在冲锋时施放 [[spell:107574]]。
4. **适用条件：巨神像（启用）。** 施放 [[spell:6343]]。
5. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]。
6. 施放 [[spell:2565]]。
7. 施放 [[spell:23922]]。
8. **适用条件：Booming Voice（启用）。** 施放 [[spell:1160]]。
9. **适用条件：勇士之矛（启用）。** 施放 [[spell:376079]]。
10. **适用条件：巨神像（启用）。** 施放 [[spell:436358]]。
11. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]。
12. **适用条件：Shield Charge（启用）。** 施放[[spell:385952]]。

### 单体输出循环

1.2.

#### 防护 战士 单体循环

作为 防护 战士，单体循环基于以下优先级。如前所述，这是一个优先级。它并不是你应该施放技能的精确顺序，而是每次你能够施放技能时，你应该从列表顶部开始，施放你满足条件的第一个可用技能。这适用于此后所有的“循环”。

这并未考虑你的主动减伤技能的使用（我们将在后续章节中介绍这一重要话题）。主动减伤技能的使用通常要复杂得多，将其列入技能优先级中并不是最优做法。

总体目标是通过施放产怒技能尽可能多地生成怒气，以便将怒气用于主动减伤。

:::details 小技巧如何使用 [[spell:163201]]？
[[spell:163201]]

应该优先于

[[spell:6572]]

使用，只要目标的生命值达到该阈值。就优先级而言，当

[[spell:163201]]

时使用

[[spell:23922]]

和

[[spell:6343]]

均处于冷却中。

:::

1. **适用条件：天神下凡（启用）。** 卡CD施放[[spell:107574]]。
2. **适用条件：Booming Voice（启用）。** 卡CD施放[[spell:1160]]。
3. **适用条件：勇士之矛（启用）。** 施放 [[spell:376079]]。
4. **适用条件：Ravager（启用）。** 冷却完毕即施放 [[spell:228920]]。
5. **适用条件：巨神像（启用）。** 冷却完毕即施放 [[spell:436358]]。
6. **适用条件：Shield Charge（启用）。** 冷却完毕即施放 [[spell:385952]]。
7. **适用条件：山丘领主（启用）。** 如果有2层充能，则施放 [[spell:435607]]。
8. **适用条件：山丘领主（启用）。** 冷却完毕即施放 [[spell:23922]]。当你施放 [[spell:6343]]、[[spell:6572]] 或 [[spell:231830]] 时，它随时可能被重置，甚至通过带有 [[spell:236279]] 的近战攻击也能重置。同时留意 [[spell:437118]] 的触发，它会使你接下来的2次 [[spell:23922]] 没有冷却时间。
9. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]。
10. **适用条件：巨神像（启用）。** 冷却完毕即施放 [[spell:23922]]。当你施放 [[spell:6343]]、[[spell:6572]] 或 [[spell:231830]] 时，它随时可能被重置，甚至通过带有 [[spell:236279]] 的近战攻击也能重置。
11. 如果你不需要怒气来维持生存，则施放 [[spell:163201]]。
12. 如果 [[spell:1269311]] 未激活，则施放 [[spell:6343]]。
13. 如果它是免费的，则施放 [[spell:6572]]。
14. 卡CD施放[[spell:6343]]。
15. **适用条件：Javelineer（启用）。** 冷却完毕即使用 [[spell:384110]] / [[spell:64382]]，除非你需要留着它来破盾或打断施法。
16. 如果敌人生命值高于 [[spell:163201]] 的斩杀线且你不需要怒气维持生存，则施放 [[spell:6572]]。

始终记住，如果你的下一次施放会使怒气超过上限，无视苦痛将优先于任何其他技能。否则，使用无视苦痛来消耗多余的怒气，因为它不占用全局冷却。

如果你真的想要最大化你的伤害输出，你应该尝试将你伤害最高的技能与 [[spell:107574]] 和 [[spell:1160]] 的持续时间对齐。这能让你充分受益于这两个技能提供的增伤。但是，注意不要因为延迟太久而浪费任何施放机会！

### AoE起手

**适用条件：Ravager（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/970854.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132337.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/613534.webp>)

**适用条件：Snap Induction（启用）；山丘领主（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/460957.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132110.webp>)

**适用条件：Booming Voice（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132366.webp>)

**适用条件：巨神像（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/136105.webp>)

**适用条件：勇士之矛（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wowt/icons/6035322.webp>)

**适用条件：山丘领主（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/460957.webp>)

**适用条件：巨神像（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/5927618.webp>)

**适用条件：Shield Charge（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/4667427.webp>)

1.3.

#### 防护 战士 多目标起手式

这个AoE起手式优先考虑在多个敌人身上建立仇恨。

1. **适用条件：Ravager（启用）。** 施放 [[spell:228920]]。
2. 施放 [[spell:100]]。
3. **适用条件：天神下凡（启用）。** 在冲锋时施放 [[spell:107574]]。
4. **适用条件：Snap Induction（启用）。** [[spell:435607]]
5. **适用条件：Booming Voice（启用）。** 施放 [[spell:1160]]。
6. 施放 [[spell:2565]]。
7. **适用条件：巨神像（启用）。** 施放 [[spell:6343]]。
8. **适用条件：勇士之矛（启用）。** 施放 [[spell:376079]]。
9. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]。
10. **适用条件：巨神像（启用）。** 施放 [[spell:436358]]。
11. **适用条件：Shield Charge（启用）。** 施放[[spell:385952]]。

### AOE循环

1.4.

#### 防护 战士 多目标循环

面对多个目标时，如果采取防御性打法，技能优先级与单体优先级相同。它能最大化怒气生成，从而最大化生存能力。

特别是在地下城中，经常有新敌人需要建立仇恨，值得施放 [[spell:6343]]（如果雷霆一击不可用，则施放 [[spell:6572]]，即使它消耗怒气）来拉住这些敌人，而不是 [[spell:23922]]。拯救你的盟友远比一点怒气重要。

:::details 小技巧那 [[spell:156135]] 呢？
如果点出了

[[spell:156135]]

，你应该在AoE中使用

[[spell:163201]]

，而不是

[[spell:6572]]

，当面对1-3个敌人时。如果面对超过3个敌人，则使用

[[spell:6572]]

.

:::

1. **适用条件：天神下凡（启用）。** 卡CD施放[[spell:107574]]。
2. **适用条件：Booming Voice（启用）。** 卡CD施放[[spell:1160]]。
3. **适用条件：Ravager（启用）。** 冷却完毕即施放 [[spell:228920]]。
4. **适用条件：勇士之矛（启用）。** 冷却完毕即施放 [[spell:376079]]
5. **适用条件：Shield Charge（启用）。** 冷却完毕即施放 [[spell:385952]]。
6. **适用条件：山丘领主（启用）。** 如果 [[spell:1269311]] 已激活，则施放 [[spell:23922]]。
7. **适用条件：山丘领主（启用）。** 冷却完毕即施放 [[spell:435607]]
8. **适用条件：巨神像（启用）。** 冷却完毕即施放 [[spell:436358]]。
9. 卡CD施放[[spell:23922]]。
10. **适用条件：山丘领主（启用）。** 冷却完毕即使用 [[spell:6343]]。
11. **适用条件：巨神像（启用）。** 施放 [[spell:6572]] 以获取伤害，除非你需要额外的怒气，在这种情况下你应该优先使用 [[spell:6343]]。
12. **适用条件：巨神像（启用）。** 冷却完毕即施放 [[spell:6343]]。如果 [[spell:772]] 即将结束，它优先于 [[spell:6572]]。由于它提供的怒气，[[spell:6343]] 也不应让其冷却时间空转超过2个全局冷却。
13. **适用条件：山丘领主（启用）。** 施放 [[spell:6572]]。

记住，如果你的下一次施放会使怒气超过上限，[[spell:190456]] 将优先于任何其他技能。否则，使用 [[spell:190456]] 来消耗多余的怒气，因为它不占用全局冷却。

### 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主

1.5.

#### 作为 山丘领主 游玩

虽然在进行时循环不会发生显著变化 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 时循环并没有显著变化，但仍有一些事情需要记住。该英雄天赋几乎完全由各种触发效果和增益组成，需要正确应对才能从这棵天赋树中获得全部收益。下面你可以找到游玩 山丘领主 时的有用提示。

- [[spell:435607]] 最多可叠加2层；
- 在2个及以上目标的场景中，每当 [[spell:435607]] 触发时，它都应该是你的第一优先级；
- 多亏了 [[spell:437134]]，[[spell:107574]] 会为你提供2层 [[spell:435607]]，所以尽量在按下 天神下凡 之前用完你剩余的雷霆之怒；
- 在 [[spell:107574]] 激活期间，由于 [[spell:1270724]] 的存在，[[spell:435607]] 应该是你的第一优先级；
- [[spell:275336]] 大幅缩短了 [[spell:6343]] 的冷却时间，以至于你可以而且应该每隔一个全局冷却就使用一次；
- 留意 [[spell:437118]] 的触发，它会使你接下来的2次 [[spell:23922]] 没有冷却时间；
- [[spell:438597]] 需要点出 [[spell:3411]] 天赋；
- [[spell:436162]] 需要点出 [[spell:107570]] 天赋；
- 在使用 [[spell:456270]] 游玩时，确保不要连续使用 [[spell:107574]] 和 [[spell:1160]]，否则你会浪费一层 [[spell:435607]]。

### 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像

1.6.

#### 作为 巨神兵 游玩

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵 带来了一个新的主动技能：[[spell:436358]]。它的伤害极高，应尽可能频繁使用，最好与 [[spell:107574]] 和 [[spell:1160]] 配合使用。如果能对齐当然很好，但你应该 **非** 为了它们延迟一次 [[spell:436358]] 的施放，除非敌人在你能额外施放一次之前就死了。

- 冷却完毕即使用 [[spell:436358]]；
- [[spell:436358]] 是一个引导技能，所以在施放前确保自己站在没有敌人在身后的位置，或者确保自己没有站在任何有害的地面效果中；
- [[spell:436358]]使你免疫昏迷、击退和强制移动效果。如果需要，使用它来规避上述效果；
- [[spell:436358]]引导可以用移动技能打断，例如[[spell:6544]]；
- 确保用[[spell:436358]]命中尽可能多的敌人，以便通过[[spell:1270704]]为他们全部施加[[spell:115767]]；
- [[spell:440992]]和[[spell:429639]]需要点出[[spell:46968]]天赋；
- [[spell:6572]]的伤害高于[[spell:6343]]，这意味着为了最大化输出，如果生存不是问题，你多余的怒气应该投入到[[spell:6572]]而不是[[spell:190456]]；

1.

### 至暗之夜 第2赛季套装

我们当前的套装非常看重免费的[[spell:6572]]触发。如果你在5秒的增益窗口内未能打出[[spell:6572]]，你将错过4件套加成，这会对你的整体输出造成实质性打击。

- [[spell:1296647]]
- [[spell:1296648]]

1.

### 职业与专精机制详解

为了更好地解释防护战士套装的具体用法和收益，我们编写了关于循环各个部分的更详细说明，从你需要注意的重要循环机制，到冷却技能及其使用方式，以便你在玩防护战士时发挥全部潜力。

### 顶点天赋

3.1.

#### 巅峰天赋：英武方阵

防护战士可用的巅峰天赋有：

- [[spell:1269311]]：制造一道伤害冲击波，使用[[spell:6343]]后你的下一个[[spell:23922]]，同时提高[[spell:23922]]的伤害
- [[spell:1269312]]：使[[spell:6343]]和冲击波的伤害提高最多20%
- [[spell:1269313]]：提高[[spell:23922]]的伤害和暴击几率。还会降低被[[spell:1269311]]的冲击波击中的敌人对你造成的伤害。

这些天赋并未显著影响我们的玩法。[[spell:6343]]和[[spell:23922]]都是防护战士的核心技能，用于我们的核心循环中。这意味着我们可以完全获得天赋的收益，而无需过多思考。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主本就围绕[[spell:6343]]及其强化版本[[spell:435607]]展开，在可用时穿插使用[[spell:23922]]。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵更侧重于通过[[spell:6572]]而非[[spell:6343]]造成伤害。这意味着，你需要稍微多注意你的雷霆一击使用，因为
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵需要触发巅峰天赋，而不是无脑刷[[spell:6572]]。

虽然设计简单，但这些天赋提供的伤害提升相当不错，而且几乎不需要额外操作。

### 嘲讽与仇恨

3.2.

#### 嘲讽与仇恨

[[spell:355]]是你的单体嘲讽技能。施放嘲讽会在其持续时间内显著提高你的仇恨产生。如果你难以建立仇恨，在此窗口内尽可能多地造成伤害。使用嘲讽还会迫使敌人至少锁定你5秒。

:::details 一个嘲讽，两个嘲讽，三个嘲讽……
与只有一个嘲讽不同，防护战士最多可以拥有

**三个**

。第一个只是单体

[[spell:355]]

。很多人不知道，

[[spell:6544]]

施放时会重置

[[spell:355]]

的冷却时间，所以这算作第二个。第三个嘲讽是

[[spell:1161]]

，这是一个范围伤害技能，并且可以通过天赋进一步强化，使其同时具备打断和沉默效果

[[spell:386071]]

.

:::

### 风暴涌动和天神下凡进一步强化，使其也能打断并沉默

3.3.

#### 风暴涌动和天神下凡进一步强化，使其也能打断并沉默

本节仅适用于你使用了 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主英雄天赋树并搭配[[spell:275336]]，且假设你有[[spell:107574]]激活。

有了[[spell:275336]]，当你施放[[spell:107574]]时，你的技能优先级保持不变，但处理方式有所不同。

在[[spell:107574]]期间，[[spell:6343]]每隔一个公共冷却就可用。这意味着你将根据技能优先级在雷霆一击和另一个技能之间轮换。例如，如果你运气好，许多雷霆一击施放重置了[[spell:23922]]，你会发现自己在雷霆一击和盾牌猛击之间交替使用。

再举一个例子，你可能会有这样一个施放序列：[[spell:23922]]、[[spell:6343]]、[[spell:23922]]、[[spell:6343]]、[[spell:6572]]（免费）、[[spell:6343]]、[[spell:6572]]……

同样，你的技能优先级不变。[[spell:23922]]仍然优先于[[spell:6343]]。只需注意在[[spell:107574]]期间，雷霆一击的冷却时间大幅缩短，并据此调整。

另外，在[[spell:107574]]期间很容易怒气溢出，所以准备好将怒气倾泻到[[spell:190456]]/[[spell:6572]]上。

### 怒气获取

3.4.

#### 怒气获取

战士的主要资源是怒气。了解怒气如何产生非常重要，这样你才能有效地管理和使用它。

怒气的上限为100，默认为空。脱战时怒气每秒衰减1点。在战斗中，怒气不会衰减。

你主要通过两种方式产生怒气：被动和通过技能。

3.4.1.

##### 被动怒气获取

被动怒气获取有三个来源。

1. **2怒气** 每次自动攻击都会获得。注意这会随攻击速度缩放。例如，装备匕首并不是为了更好的怒气获取。
   
   
   
   
   - 更具体地说，你每次自动攻击产生1.75 * 武器速度 * 0.44怒气。单手武器速度为2.6，相当于每次自动攻击2怒气。
2. **3怒气** 每次敌人自动攻击命中你时获得。
   
   
   
   
   - 这有冷却时间。看起来大约是1秒，但确切的冷却时间目前尚不清楚。
3. [[spell:384361]]是一个天赋，使你的流血效果有15%几率为你提供5怒气。

闪避事件不产生怒气（即敌人招架/躲闪，或你招架/躲闪）。

因为自动攻击命中你时会产生怒气，所以在有多个敌人的地下城或战斗中，怒气获取往往要高得多。

3.4.2.

##### 技能产生的怒气

按怒气从多到少排序：

- [[spell:228920]]产生最多60怒气（如果每次都命中）。
- [[spell:1160]]产生20怒气（仅在有[[spell:202743]]时）。
- [[spell:376079]]产生10怒气。
- [[spell:385952]]产生20怒气，如果你同时拥有[[spell:386328]]则为40怒气。
- [[spell:100]]产生20怒气。
- [[spell:23922]]产生15怒气。
- [[spell:6343]]产生5怒气。

有些天赋可以进一步增加某些技能产生的怒气。查看我们的天赋页面以了解全部内容。

[防护战士天赋与构筑](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)

### 怒气管理

3.5.

#### 怒气管理

重要的是要明白你不必 <em>在获得怒气时就立刻</em> 花费它。囤积怒气以最大化怒气获取、生存能力或伤害，是玩防护战士的重要方面。

例如，如果你在战斗中试图最大化伤害并施放[[spell:6572]]来做到这一点，而战斗进行到有额外敌人加入的阶段，那么你会想要保留你的复仇施放，并将其用在那些额外的敌人身上。

再举一个例子，在[[spell:107574]]期间，你可能会获得一连串的[[spell:23922]]重置。立即利用这些重置，而不是通过施放复仇延迟一个公共冷却，将带来更多的怒气和更多消耗怒气技能的施放次数。你不会 <em>因为等待而</em>
损失复仇的施放次数，因为它受限于你可用的怒气总量。

然而，如果你怒气溢出，你确实会损失施放次数。这意味着你达到了100怒气的上限，之后产生的任何怒气都会浪费。

在单体目标上，你会产生相当数量的怒气，但除非你操作不当，否则很少会接近怒气上限。

然而，在多目标情况下，特别是当多个敌人自动攻击你时，正确的怒气管理对于避免溢出是必要的。

你应该照常遵循你的技能优先级，除非你遇到遵循它会导致浪费怒气的情况。在这些情况下，[[spell:6572]]和[[spell:190456]]成为你最高优先级的技能。

如果你即将怒气溢出且无视苦痛的吸收量很少或没有了，那么确保施放无视苦痛以防止溢出。如果你追求伤害或者你已经有无视苦痛了，就使用复仇。

通常，你仍然应该优先考虑[[spell:6343]]而非复仇，因为浪费5怒气微不足道，而由此获得的额外伤害是值得的。举个例子，假设你有96怒气。此时施放[[spell:23922]]会为你提供4怒气，而不是15怒气。平均而言，通过延迟一个公共冷却来使用产生怒气的技能以避免溢出，你会获得更多总体怒气。

有时会出现你无法用[[spell:6572]]足够快地消耗怒气的情况。在这些情况下，直接刷[[spell:190456]]，即使你的无视苦痛已满且你在浪费吸收量。这样做仍然可以让你从[[spell:152278]]和[[spell:202095]]中受益，这远比怒气溢出要好。

此外，随着你重复进行内容并获得更多不同战斗的经验，如果你知道通常在这种情况下你必须像上面所述那样“倾泻”怒气，你应该切换到DPS技能优先级（即优先使用高伤害技能而非[[spell:23922]]）。这样你造成更多伤害并产生略少的怒气，降低溢出风险并提高你的整体吞吐量。

### 格挡等级

3.6.

#### 格挡等级

你可能注意到盾牌上有一个“格挡”属性。角色面板有格挡等级，所有这些等级都来自盾牌上的格挡。所以如果一个盾牌有2000格挡，角色面板就会显示2000格挡。目前，你盾牌上的格挡量始终是盾牌护甲值的2.5倍。

格挡的减伤是根据你的总格挡计算的。它的计算方式与护甲的减伤方式相同：blockRating / (blockRating + k)。k值会根据你所进行内容的难度或类型而变化。

一般来说，更困难或更新的内容具有更高的k值，而更高的k值会导致更低的减伤。格挡减伤与护甲完全分开，拥有更多护甲不会影响它。

暴击格挡只是双倍减伤。例如，如果普通格挡提供40%减伤，暴击格挡将提供80%减伤。值得注意的是，就像护甲一样，格挡减伤有85%的上限。如果一个盾牌在普通格挡时提供50%减伤，那么使用该盾牌的暴击格挡也只会是85%。

这个系统极大地鼓励了盾牌的升级。获得一个好的盾牌是生存能力的显著提升，远超升级其他装备的同类提升。

1.

### 防护战士的主动减伤使用

你的循环是为了给你产生怒气，然后你应该将其投入到你的主动减伤技能中。作为一名防护战士，你有两个对生存至关重要的技能：[[spell:2565]]和[[spell:190456]]。

### 主动减伤

4.1.

#### 盾牌格挡

[[spell:2565]]是你的主要主动减伤技能。在绝大多数情况下，你承受的大部分伤害都是可格挡的。因此，尽可能保持盾牌格挡是平滑伤害并帮助你生存的关键。盾牌格挡随你承受的伤害缩放，因为它是按百分比减少伤害，而不是像[[spell:190456]]那样的固定数值。

理解以下内容之间的区别非常重要 <em>总</em>
[[spell:2565]]覆盖率和 <em>有效</em> 覆盖率之间的区别。你希望有尽可能多的有效盾牌格挡覆盖率。这意味着当你在坦一个实际会近战攻击你的目标时，盾牌格挡是激活的。

基本上，任何时候你在坦怪，你都应该尽可能保持[[spell:2565]]激活。然而，它仍然应该被明智地使用，就像你使用重要冷却技能一样。

:::details 常见问题：作为防护战士，我需要100%的盾牌格挡覆盖率吗？
在积极坦怪时保持

[[spell:2565]]

以减少受到的伤害应该是你的首要任务。话虽如此，盾牌格挡的总覆盖率和有效覆盖率之间存在显著差异。

有效覆盖率意味着你在积极承受近战打击时盾牌格挡是激活的。而总覆盖率还计算了你不一定会受到任何可格挡伤害的时间。

你应该始终力求尽可能高的

**有效**

[[spell:2565]]

正常运作时间，同时用防御性工具覆盖任何潜在的停机时间，例如

[[spell:871]]

.

:::

[[spell:2565]]具有以下属性。

- 使你在6秒内格挡所有对你造成的近战攻击。这些格挡可以是暴击格挡。
- 这些格挡提供的伤害减免由你的格挡属性决定。参见 [此处](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities#block-rating>).
- 激活期间，它使[[spell:23922]]的伤害提高30%。
- 它消耗30点怒气。
- 它有2层充能，16秒的充能时间（受急速影响缩短）。

**[[spell:2565]]是你的主要减伤技能。假设你正在承受可格挡的伤害（几乎总是如此），它的优先级高于[[spell:190456]]。**

使用[[spell:2565]]相当直接。如果你正在承受可格挡的伤害，你就应该使用盾牌格挡来减免它。关于从你的[[spell:2565]]使用中获得最大收益，有几点需要注意：

- [[spell:2565]]对所有近战攻击（即自动攻击/白字攻击）有效，但也有许多首领技能/机制同样可以被格挡。有时，你认为可以格挡的东西不能格挡，而你认为不能格挡的东西却可以。
  
  
  
  
  你只需要知道这些可格挡的机制是什么。这里的重点是，如果你 <em>知道</em> 某个高伤害技能可以格挡，那么你最好延迟盾牌格挡，让它的最后一段时间来格挡那个技能。
- 为了进一步获益，你可以将[[spell:2565]]与敌人的近战挥击时间对齐。大多数敌人的挥击间隔在1.5到2秒之间。如果你在一次近战攻击后立即施放盾牌格挡，你实际上损失了2秒的有效运作时间。
  
  
  
  
  有时，很难判断敌人何时真的在对你进行近战攻击，所以这一点不是特别重要，但如果做得好会很有益。
- 另外，注意敌人的法术施放/引导。如果首领即将花费5秒施放一个法术，你应该相应地延迟[[spell:2565]]。
- 与第一点类似，但如果你知道敌人即将造成更高的伤害，你也应该在这些时段延迟[[spell:2565]]。

如果你当前没有在坦怪，并且距离你再次坦怪还有相当长的时间，使用[[spell:2565]]来提高[[spell:23922]]的伤害。只要确保这样安排时机：当你即将再次坦怪时，你拥有接近2层的盾牌格挡充能，这样你就能最大化有效运作时间。

### 无视苦痛

4.2.

#### 无视苦痛

[[spell:190456]]按固定数值减免伤害，以目前的数值调整来看，它远弱于[[spell:2565]]。因此，它应该被用作
<em>在</em> 盾牌格挡的补充，而不是替代品。

[[spell:2565]]受限于其冷却时间，而[[spell:190456]]则仅仅受限于你可用的怒气数量。所以，一旦你开启了盾牌格挡并让其进入冷却，就将剩余的怒气花在无视苦痛上，同时确保留有足够的怒气在盾牌格挡冷却结束后使用。大体上，无视苦痛应该被用来进一步平滑你的伤害承受。

[[spell:190456]]具有以下属性：

- 它移除任何特定伤害事件的50%。也就是说，对于承受的任何伤害，其中50%由吸收盾承担，另外50%由你承担。
- 它的最大吸收量为你最大生命值的30%。
  
  
  
  
  - 这意味着吸收量确实可以叠加，只是叠加得不多。
  - 上限值由 <em>施放时</em>.
- 它的持续时间为12秒。
- 它消耗35点怒气。

不过，就像[[spell:2565]]一样，如果这样做有好处，它也可以并且应该被明智地使用。

- 如果你当前没有拉怪，而且承受的伤害很少或没有伤害，就不要把怒气花在[[spell:190456]]上。根据你不拉怪的时间长短，它会直接过期，浪费掉那些怒气。相反，尽量在重新开始拉怪之前使用一次无视苦痛。如果你 <em>是</em>
  在未担任坦克时承受伤害，请根据需要施放无视苦痛来协助治疗者。
- 虽然一般来说，你会想用[[spell:190456]]来平稳你的伤害承受，但在一次大的伤害尖峰之前积攒怒气并使用无视苦痛也非常重要，这样可以提高你在那次尖峰中存活下来的几率。

上述要点的例外情况是你接近怒气上限的时候。在这种情况下，你应该使用[[spell:190456]]来消耗怒气，即使这意味着无视苦痛的上限被超出。此外，如果你遇到极其罕见的情况，即有非常、 <em>非常</em> 少，或者根本没有，你当然会优先考虑[[spell:190456]]而不是[[spell:2565]]。

### 防御姿态与战斗姿态

4.3.

#### 防护 战士的姿态

所有战士根据其专精可以使用各种姿态。对于防护，这些姿态包括：[[spell:386208]]和[[spell:386164]]。这些是被动的、持续的增益效果，根据我们所处的姿态为我们提供各自的好处。

大体上，[[spell:386208]]姿态减少你受到的伤害，而[[spell:386164]]增加你造成的伤害。选择使用哪种姿态应视具体情况而定。如果伤害承受很高，那么你应该使用[[spell:386208]]来减少你受到的伤害，否则你应该处于[[spell:386164]]姿态。

你可以在战斗中轻松切换姿态，因此应根据哪种情况能带来最佳结果来决定。下面你可以找到一些关于何时使用哪种姿态的示例场景。

- [[spell:386208]]，减少受到的伤害16%：
  
  
  
  
  - 如果伤害承受很高则使用它
  - 如果你不熟悉伤害承受情况则使用它
  - 如果你正在承受不可格挡的伤害则使用它
- [[spell:386164]]，提高暴击几率3%：
  
  
  
  
  - 如果伤害承受不太重，为了造成更多伤害则使用它。

1.

### 防护 战士的重要冷却技能

### 防御性冷却技能

5.1.

#### 防护 战士的防御性冷却技能使用

作为一名防护 战士，你拥有若干防御性冷却技能。正确使用你的防御性冷却技能极其重要。你希望在进入战斗前规划好你的冷却技能，并尽可能最大化它们的使用。下面列出了你的各种防御性冷却技能以及它们应该如何使用。

5.1.1.

##### 盾墙

[[spell:871]]应该用于准备应对大量伤害爆发或在高伤害期间使用。它对不可格挡的伤害尤其有用。不建议在你的生命值突然降低时使用它，因为它无法帮你恢复生命值，但在你没有其他手段的情况下，如果它能提高你的生存几率，你就应该使用它。如果使用了[[spell:12975]]天赋，你也可以在未能预先使用它之后，使用[[spell:871]]来为自己治疗。 **只有在你没有其他办法活着离开战斗时才这样使用它，因为[[spell:871]]应该始终作为减伤工具而不是治疗工具使用。**

5.1.2.

##### 挫志怒吼

有了[[spell:202743]]，[[spell:1160]]应该卡着冷却时间使用，并且出于伤害目的。大多数时候，你会在合适的时机拥有它，帮助你平滑伤害。

当然，肯定会有这样的情况：如果你知道即将到来的是大量伤害，而你没有其他可用技能，你会想要延迟[[spell:1160]]的使用。

没有[[spell:202743]]时，就像使用普通防御性冷却技能一样使用它即可。

5.1.3.

##### 法术反射

[[spell:23920]]有两种不同的使用方式。要么用来反射施放在你身上的特定法术，要么作为魔法伤害减免冷却技能。首领施放的绝大多数法术都是 <em>非</em>
可反射的，当然，伤害减免部分仍然有效。

罕见地，某些首领技能是可反射的，在这些情况下，反射它们会极其强大，无论是在伤害减免方面还是对首领造成伤害方面。

大多数时候，你会将其用作魔法伤害减免工具。然而，在地下城和类似内容中，反射特别强大的法术是使用[[spell:23920]]的绝佳方式。

记住，当你反射一个法术时，你会失去法术反射增益效果，这意味着你也失去了伤害减免。如果你处于需要魔法伤害减免，但同时又有可反射的法术向你施放的情况，请注意这一点。

### 进攻性冷却技能

5.2.

#### 防护 战士的进攻性冷却技能使用

我们可以使用各种进攻性冷却技能，其中大多数需要点出天赋。下面是一个快速列表。

- 放大伤害：[[spell:107574]]
- 放大伤害：[[spell:1160]]，点出[[spell:202743]]天赋时
- 造成伤害：[[spell:385952]]
- 造成伤害：[[spell:376079]]
- 造成伤害：[[spell:228920]]
- 造成伤害：[[spell:436358]]，仅作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像

它们的使用方法其实很直接。当你激活了放大类技能时，使用你的伤害输出技能。这意味着当你激活了[[spell:107574]]或[[spell:1160]]（最好是两者都激活）时，你应该使用[[spell:385952]]、[[spell:228920]]和[[spell:436358]]。这确保你充分利用你的进攻能力。

[[spell:385952]]和[[spell:1160]]需要一些战斗知识才能用于进攻。它们都带有防御性部分，[[spell:385952]]提供[[spell:2565]]，而[[spell:1160]]减少敌人对你造成的伤害。作为一名坦克，你的首要任务是活下来，所以只有在你确定在它们的冷却持续时间内不需要它们的防御部分时，才将这些技能用于进攻。

:::details 一个敌人还是十个敌人..？
你可能会遇到这样的情况：你的伤害输出技能冷却好了，但你正在与单个敌人战斗。在这种情况下，要提前思考。如果你知道你即将与更多敌人战斗，那就把你的进攻性冷却技能留到那时候使用。

**确保不要将你的进攻性技能的使用延迟太久，否则你可能会在整场战斗中少用一次。**

:::

### 实用技能

5.3.

#### 防护 战士的实用技能

在本节中，我们将简要概述一些其他技能，它们经常被忽视，但正确使用时可以带来显著的收益。

5.3.1.

##### 英勇投掷

[[spell:57755]]造成的伤害很少，但能产生可观的威胁值。它没有消耗，也没有冷却时间。用它来对远处的敌人建立仇恨。另外，如果你因为某种原因无法回到近战范围而脱离了敌人的射程，你可以连续使用英雄投掷来造成一点点额外伤害。

5.3.2.

##### 碎裂投掷

[[spell:64382]]对敌人造成伤害，施法时间为1.5秒，冷却时间为3分钟。对吸收盾造成更多伤害，并移除任何魔法免疫。主要在PvP中有用，但如果敌人身上有吸收盾，在PvE中也能找到用途。点出[[spell:1271948]]天赋时还能沉默敌人。

5.3.3.

##### 破裂投掷

[[spell:384110]]将你的武器投向敌人，造成无视护甲的伤害，并且对吸收护盾造成额外伤害。类似于[[spell:64382]]，但冷却时间为45秒且没有施法时间。点出[[spell:1271948]]天赋时能沉默敌人。

5.3.4.

##### 援护

[[spell:3411]]是一个强大的防御性冷却技能，可以有多种用途。在团队副本中，它可以用于我们的副坦克以减少他们承受的伤害，而在大秘境中，它可以用于被定身效果锁定的队伍成员。

如果反应迅速，击退机制几乎可以完全被援护抵消。使用它通过施放在盟友身上快速移动到另一个区域，也许是为了躲避环境伤害，会非常有用。

5.3.5.

##### 英勇飞跃

[[spell:6544]]可以用来跳过地面效果或其他各种你通常需要绕路跑的机制。它并不是100%可靠的，因为有时当你跳过某个东西时，你可能仍然会受到伤害。

但大多数时候，你可以这样利用英雄飞跃。更简单地说，英雄飞跃非常适合进入位置或逃离危险机制。

[[spell:6544]]还会重置[[spell:355]]的剩余冷却时间。这意味着你可以轻松地跃向一个新刷新的小怪，并立即使用嘲讽来获取仇恨，即使你一秒钟前刚用过嘲讽。

5.3.6.

##### 震荡波

正确使用[[spell:46968]]可能极其重要，无论从控制还是生存的角度来看。它可以用来眩晕正在施法的敌人以打断他们，或者将敌人固定在原地。

但更重要的是，它可以在持续时间内完全阻止伤害。假设[[spell:2565]]结束了，而你没有其他主要防御性冷却技能可用了。对敌人使用震荡波（假设他们没有免疫）可以完全阻止他们的伤害。围绕你的主动减伤技能来把握它的使用时机可以防止死亡。

5.3.7.

##### 破胆怒吼

[[spell:5246]]的使用方式应与[[spell:46968]]相同；用于控制或生存目的。不过，你必须对这个技能更加小心。逃跑的敌人可能会跑进另一群敌人并引到它们，可能导致灭团。

5.3.8.

##### 集结呐喊

把握好[[spell:97462]]的时机可能是击杀与灭团之间的区别。它对你的团队来说是相当显著的生存能力提升，所以好好规划它的使用。

5.3.9.

##### 战斗怒吼

虽然实际上不在战斗中使用（除非是给刚刚复活的盟友上增益），但请确保在进入战斗前对你的队伍或你自己施放[[spell:6673]]。

5.3.10.

##### 狂暴之怒

[[spell:18499]]在合适的情况下是一个极好的技能。有不少敌人的技能会造成恐惧，能够完全阻止这些技能是一个巨大的优势。找出狂暴之怒可以在哪里使用，并利用这些情况。

5.3.11.

##### 拳击

许多玩家除非特别指示，否则根本不会使用他们的打断。打断敌人可以阻止可能致命的机制被放出。找出那些危险的机制并使用你的打断！

5.3.12.

##### 刺耳怒吼

[[spell:12323]]为你的盟友提供短暂的速度爆发，同时减慢你的敌人。如果在正确的时机使用，这会非常棒，例如在团队副本战斗中，团队经常需要从一个地方快速移动到另一个地方。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月18日：** 在AOE优先级中添加了盾墙。
- **2026年8月11日：** 将巨神兵标记为单体目标推荐天赋树。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月4日：** 更新了斩杀在循环中的使用。
- **2026年4月23日：** 修复了在巨神兵循环下显示雷霆冲击的问题。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年4月2日：** 修改了山丘领主单体目标优先级。
- **2026 年 3 月 22 日：** 修改了单体目标起手式。
- **2026年3月16日：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行审核和更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月18日：** 在天赋选择中添加了重拳出击，以采取更具进攻性的方法。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已针对11.1.7补丁进行更新。添加了关于辅助循环的信息。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月11日：** 添加了关于姿态的部分。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月30日：** 在防御技能列表中加入了法术格挡。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年6月20日：** 新增了关于无视痛苦使用的说明。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月22日：** 更新了无视痛苦章节。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了复查和更新。
- **2023年9月4日：** 为10.1.7补丁进行了复查和更新。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月27日：** 在起手技能中将雷霆咆哮的优先级上调。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 新增了关于套装输出循环变化的段落。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你可以找到《魔兽世界》12.1.5版本中防护 战士的最佳装备、饰品和毕业物品推荐。从制造品到如何使用你的纹章升级装备的建议，我们都为你准备好了！

1.

### 防护 战士毕业装备指南

你能找到的最佳装备来自每周大秘境宝箱（现在称为宏伟宝库）和史诗团队副本。除此之外，一旦你获得了必要的材料，你还可以下达制造订单。

虽然制定一份确定的毕业装备清单很难，但在某些情况下，特定的装备可以成为毕业装备。例如，一些饰品拥有极其强大的特殊效果，无论物品等级如何你都会想要获得它们。有时候，一些戒指的特殊效果比物品等级提升或特定副属性的收益更重要。

作为一般的经验法则， **任何物品等级的提升都是一次升级**。对于防护战士来说，所有副属性的价值都非常接近，你应该只在比较相同物品等级的装备时才看一件装备有哪些副属性。不仅如此，耐力和力量的提升也同样显著。

总而言之，如果你遇到一件物品等级更高的装备（或者它有插槽而你当前的装备没有），就装备上它。如果两件装备的物品等级相同，就根据属性优先级装备更好的那件。最后，要注意某些装备的物品等级并不 <em>非</em> 那么重要，比如特定的饰品、戒指和带有特殊效果的装备等。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

本列表包含至暗之夜第2赛季的毕业装备。毕业列表是在理想条件下生成的，因此为了获得最佳结果，请务必自己跑模拟。

:::details 常见问题我需要哪些套装部件？
由于现在催化一件物品会保留初始物品的属性并将其转化为套装，你可以选择想要哪件套装部位拥有哪种属性，这给了你更多的配装自由度。这意味着我们应优先获取带有特殊效果或优秀副属性的物品，然后将它们催化成套装部件。

- 头部：催化 [[item:281239]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 肩部：将[[item:239037]]催化自塞塔里斯神庙
- 手部：使用来自的常规套装物品 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>) 的常规套装物品，或从达诺拉克巢穴催化 [[item:251214]]
- 胸部：催化 [[item:268222]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿部：催化 [[item:271878]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271456@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:251214@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAIAAAj1QWNYYjX1A]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271455@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:268196@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

### 秘境+

以下列表包含仅在大秘境地下城中才能找到的装备。这并不意味着这些物品是大秘境的最佳选择，而是它们仅掉落自地下城而非其他地方。毕业装备清单是在理想环境下创建的，因此为了获得最佳效果，请务必自己进行模拟。

:::details 常见问题我需要哪些套装部件？
由于现在催化一件物品会保留初始物品的属性并将其转化为套装，你可以选择想要哪件套装部位拥有哪种属性，这给了你更多的配装自由度。这意味着我们应优先获取带有特殊效果或优秀副属性的物品，然后将它们催化成套装部件。

- 头部：将[[item:239050]]催化自诸王之眠
- 肩部：将[[item:239037]]催化自塞塔里斯神庙
- 手部：从达诺拉克巢穴催化 [[item:251214]]
- 胸部：将[[item:251193]]催化自夺目谷
- 腿部：将[[item:273776]]催化自毒牙祭坛

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)：掉落3件不错的物品，包括一面盾牌。
- [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：掉落2件物品，包括一件武器。
- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：还掉落3件很棒的物品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:251214@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>项链</th><td>[[item:251173@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>腰部</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271455@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>披风</th><td>[[item:239656@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div>由制造 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>脚部</th><td>[[item:273777@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271459@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250245@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:251195@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:251150@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span></div></td></tr></tbody></table>

### 团队副本

以下列表包含仅在团队副本中才能找到的装备。这并不意味着这些物品是团队副本的最佳选择，而是它们仅掉落自团队副本而非其他地方。毕业装备清单是在理想环境下创建的，因此为了获得最佳效果，请务必自己进行模拟。

:::details 常见问题我需要哪些套装部件？
由于现在催化一件物品会保留初始物品的属性并将其转化为套装，你可以选择想要哪件套装部位拥有哪种属性，这给了你更多的配装自由度。这意味着我们应优先获取带有特殊效果或优秀副属性的物品，然后将它们催化成套装部件。

- 头部：催化 [[item:281239]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 肩部：使用来自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- 手部：使用来自的常规套装物品 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- 胸部：催化 [[item:268222]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿部：催化 [[item:271878]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
各个团本中有很多优质物品。下面你可以找到一些你应该优先获取的物品。

- [[item:271878]]：掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)。同一个首领也掉落我们最好的项链和武器！
- [[item:268209]]：掉落自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)。或者，[[item:268202]] 掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:268265@JAAEAAgsSYgM]]：掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:281239]]：掉落自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)。同一个首领也掉落我们最好的戒指，[[item:281029]]。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271456@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAIAAAj1QWNYYjX1A]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271455@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:268196@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 饰品推荐 - 防护战士

饰品因其各种效果而成为游戏中较为独特的物品之一。它们可以帮助增强你的防御，或协助你造成更多伤害。无论你选择哪一种，你都可以在下方找到一份其他值得注意的饰品列表。 **数值调整仍在进行中，因此此列表将根据即将到来的变动而有所变化。**

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 防护战士 饰品排行
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>团队副本</th>&#10;<th>秘境+</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270175]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]</li>&#10;<li>&#10;&#10;&#10;[[item:281215]] - <span><em>点击查看详情</em></span>&#10;<span>地下城中可靠的被动饰品。它拥有高触发几率，同时还能从主动攻击新目标中获得额外价值。</span>&#10;</li>&#10;<li>[[item:270173]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:273795]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:281215]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:273795]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:270163]]</li>&#10;<li>[[item:270174]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250229]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:270163]]</li>&#10;<li>[[item:270174]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>&#10;&#10;&#10;[[item:158367]] - <span><em>点击查看详情</em></span>&#10;<span>造成大量伤害，值得进入S级，但拥有较长的引导时间。如果你在引导饰品期间施放任何法术，将会打断引导。你在引导期间也无法格挡，这意味着在大秘境中，除非你为它使用 [[spell:871]]，否则在任何相关层数下使用它都很可能会死亡。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>防御饰品</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270160]]</li>&#10;<li>[[item:159618]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270160]]</li>&#10;<li>[[item:159618]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

作为一般规则，你不会想装备两个使用型饰品，因为如果你使用其中一个，另一个也会进入30秒冷却。考虑到这一点，你应该使用两个被动饰品，或一个被动和一个使用型饰品。以下是一些饰品搭配的示例组合。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **示例组合 #1**
**使用型 -**

[[item:270175]]

**被动 -**

[[item:270173]]

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **示例组合 #2**
**被动 #1 -**

[[item:270173]]

**被动 #2-**

[[item:281215]]

:::

2.1.

#### 秘境+中的 米利克萨之牙

[[item:158367@JAAEAAgsSYgM]] 造成相当多的伤害，但缺点是拥有2.6秒的引导时间。问题在于，当你在引导饰品时，你将无法格挡受到的伤害。在团队副本中这通常不是问题，因为你并不是持续在坦怪。然而，在大秘境中你作为唯一坦克时，这会变得更加麻烦。在较低层数时你或许可以应付，但在伤害承受更明显的较高层数中，每次引导饰品时你都会有死亡风险，或者被迫在引导期间使用 [[spell:871]]。

因此，尽管该饰品拥有极高的理论伤害，但在实际地下城环境中使用它可能很冒险且往往不切实际。

1.

## 防护战士的其他值得注意的装备

在以下章节中，你可以找到一些额外值得注意的装备。为了更好地理解装备的副属性优先级，请查看下方的指南，其中每项属性都被分解成了易于理解的部分。

3.1.

### 盾牌

一面好盾牌是最重要的装备。盾牌升级提供的防御提升远大于其他部位的升级。

你可以从地下城、团队副本和宏伟宝库每周宝箱中获得高物品等级的盾牌。以下盾牌来自当前的地下城和团队副本。

<table>&#10;<tr>&#10;<th>物品</th>&#10;<th>来源</th>&#10;</tr>&#10;<tr>&#10;<td>[[item:268196]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:268262]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a>，位于 <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:251150]]</td>&#10;<td><strong>寒冬哨兵</strong>，位于 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:251196]]</td>&#10;<td><strong>兹欧凯特</strong>，位于 <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:159664]]</td>&#10;<td><a href="https://www.wowhead.com/npc=133389" rel="noopener noreferrer">加瓦兹特</a>，位于 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:193754@JAAIAAQkCYHKvbRLfA]]</td>&#10;<td><strong>克里亚卡与 厄克哈特·风脉</strong>，位于 <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></td>&#10;</tr>&#10;</table>

**无论副属性如何，都要使用你能获得的最高物品等级的盾牌。**

3.2.

### 武器

正如盾牌很重要一样，武器同样重要。它们提升我们的伤害输出，让我们能为团队表现做出更多贡献。以下你可以找到一份可靠的武器选择。

<table>&#10;<tr>&#10;<th>物品</th>&#10;<th>来源</th>&#10;</tr>&#10;<tr>&#10;<td>[[item:268209]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a>，位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:268202]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a>，位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:251195]]</td>&#10;<td><strong>兹欧凯特</strong>，位于 <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:251218]]</td>&#10;<td><strong>塔兹拉尔</strong>，位于 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:158373]] </td>&#10;<td><strong>塞塔里斯的化身</strong>，位于 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:268208]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a>，位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td>&#10;</tr>&#10;</table>

与盾牌一样，无论副属性如何，都要使用你拥有的最高物品等级的武器。

1.

## 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 是一种可以用于首领的额外拾取机会。每个首领都有一个特定的掉落列表，每次你获得一件带有 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)的物品后，它就会从该首领的后续额外拾取机会中移除。

[[item:268552]] 提升已完全升级的英雄和史诗难度装备的物品等级。它也可用于升级已完全制造的物品。它只能用于武器和饰品，因此并非所有装备都适用。

4.1.

### 防护战士的推荐虚无核心使用方式

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 的使用取决于你正在进行的内容。如果你知道之后会在史诗难度击杀同一个首领，就不要把它们浪费在英雄团队副本的首领身上。相反，如果你知道你只会打英雄团队副本，那么在那里使用虚空核心就完全合理。

![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**

1. [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 用于 [[item:268209]] 或 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 用于 [[item:268202]]
2. 史诗难度盾牌，如果你没有制造的盾牌
3. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 用于 [[item:271878]]
4. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 用于 [[item:268265]]

虽然列表中的所有战利品都来自团队副本，但在大秘境地下城中使用 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)
时，同样的物品部位逻辑也适用。如果你在10层以上的钥石后使用它们，你将获得一件史诗难度装备。

4.2.

### 防护战士的升腾虚无核心使用方式

由于 [[item:268552]] 只能用于武器、饰品和项链，因此优先级相当简单。

![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **升腾虚空核心优先级**

1. 升级你的武器
2. 升级你的饰品
3. 升级你的项链
4.

## 防护战士的最佳制造业物品

纹饰是可制造物品上的各种额外效果。这些可以是某些物品上的基础效果，也可以是制造物品时通过可选材料添加的其他效果。

提示纹饰部位逻辑

由于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 最后2个首领， [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 和 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 掉落344物品等级的物品，我们不想在这些首领掉落的部位上制造纹饰。因此，如果你打团队副本，你的纹饰应该放在 **脚部** 和
**护腕** 但如果你只玩大秘境，则将纹饰放在 **背部** 和 **护腕** 上。

虽然有多种纹饰选择，但你同时只能激活两个。以下是一些非常全面的纹饰建议。记得将 [[item:245786]] 作为你的默认属性组合。

![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **防护战士制造订单**

1. [[item:237839@JAAOAAgN1MWNi8ymlUZMAMiViA]]
2. [[item:237834@JAAKAAgIvYTNbWCYwYlI]]
3. 当你获得史诗难度升级武器后，将 [[item:237839@JAAOAAgN1MWNi8ymlUZMAMiViA]] 换成 [[item:237828@JAAOAAgN1MWNi8ymlUZMAMiViA]]，如果你不打团队副本则换成 [[item:239656@JAAOAAgN1MWNi8ymlUZMAMiViA]]。

先制造盾牌而不是武器也是一个可行的选择，无论哪种方式你都不会出错。

![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **防护战士美化**

- 将[[item:245876]]作为你最初的锻造选择，打在武器上。
- 将[[item:240167]]打在像护腕或鞋子（如果你打团本）/ 披风（如果你不打团本）这样的低预算装备部位上。
- 一旦你能获得一件史诗级升级武器，就把[[item:245876]]换成另一个[[item:240167]]。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

5.1.

### 为装备添加插槽

[[item:275707]]允许你为头盔、腰带和护腕打孔。如果你没有从宏伟宝库中选取一件物品，你将会获得代币。当你获得6个代币后，与宏伟宝库旁边的NPC对话，你就可以用这些代币兑换[[item:275707]]。

1.

## 纹章使用

要升级你的装备，你将使用纹章，纹章可以从游戏中的各种内容中获得。根据它们掉落的轨迹，可以用来升级装备。

由于每个升级等级需要更多的纹章，建议你在 **非** 前几周使用史诗纹章来升级你的装备 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)。一旦你决定升级，你可以在下面找到一份关于优先升级哪些物品的大致优先级列表。要找到最适合你角色的升级选项，请务必自行模拟。

![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **纹章升级优先级**
**武器** = **盾牌** ➜ **头盔/胸甲/腿甲** ➜ **饰品** ➜ **肩部/手套/腰带/靴子**

1.

## 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

## 更新日志

- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年10月4日：** 将武器附魔替换为哈希伊仪式。
- **2026年9月10日：** 在饰品列表中添加了嚎叫之核偶像和斯索拉克的凶猛。
- **2026年9月3日：** 更新了饰品梯队列表。
- **2026年8月24日：** 在毕业列表中添加了正确的催化属性。
- **2026年8月17日：** 修复了毕业列表中的腿部附魔。
- **2026年8月14日：** 饰品调整更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月27日：** 添加了太阳核心点火器。
- **2026年4月22日：** 明确了虚空核心的使用方法。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行审核和更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5补丁进行更新，添加了卡特尔筹码。
- **2025年8月13日：** 在应用坦克伤害降低后，从毕业列表中移除了恐怖麻袋。
- **2025年8月5日：** 更新了饰品列表。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月22日：** 更新了DISC腰带推荐。
- **2025年6月20日：** 热修后，将泰坦神装DISC腰带的推荐从充能箭矢改为致命连锁。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月18日：** 在代币中添加了光明的奉献之书和即兴塞弗里姆起搏器。
- **2025年4月25日：** 更新了关于神秘卡特尔筹码的信息。
- **2025年4月21日：** 已针对11.1.5补丁进行审核和更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月25日：** 由于坦克职责倍率，更新了塞尔西的指环宝石。
- **2024年12月15日：** 已针对11.0.7补丁进行审核，并添加了关于塞尔西的指环的新部分。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月20日：** 调整后，将备用肉钩替换为疯狂女王的敕令作为毕业饰品。
- **2024年9月17日：** 在饰品列表中添加了天空恐怖的腐蚀器官。
- **2024年9月13日：** 在饰品列表中添加了丝链编织者。
- **2024年9月9日：** 更新了综合BiS列表。
- **2024年8月23日：** 在饰品列表中加入了奥维纳克斯的水银卵和虫群领主的权威。在饰品调整后更新了饰品列表。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月24日：** 阐明了狂乱纵火者火把、源质口袋铁砧和灾难指环的使用方法。
- **2024年4月22日：** 为第4赛季进行了复查和更新。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年12月7日：** 在大秘境饰品中将凋零黑暗之心替换为先知的龙鳞。
- **2023年11月30日：** 将受折磨的远古之枝加入饰品推荐。
- **2023年11月23日：** 升级了大秘境装备列表中的项链。
- **2023年11月21日：** 新增了关于推荐的美化制作位置的说明。
- **2023年11月7日：** 从推荐美化中移除了孢子斗篷。
- **2023年11月6日：** 为10.2补丁进行了复查和更新。
- **2023年9月4日：** 为10.1.7补丁进行了复查和更新。
- **2023年7月10日：** 为10.1.5补丁进行了复查和更新。
- **2023年5月24日：** 为饰品新增了大灾变时光漫游章节。
- **2023年5月11日：** 将达古尔的印记加入饰品章节。
- **2023年5月9日：** 更新了原始宝石。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月24日：** 更新了原始宝石列表。
- **2023年3月22日：** 将嗡鸣的奥术宝石作为可行的宝石加入，并更新了玛瑙纪念戒指的使用场景。
- **2023年3月20日：** 新增了关于原始宝石的信息，并为10.0.7补丁进行了复查。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月26日：** 在饰品列表中加入了低语化身图腾。
- **2022年12月23日：** 将一些化身宝库的饰品加入了值得注意的饰品列表。
- **2022年12月11日：** 更新了装备推荐，加入了套装和美化推荐。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

## 属性优先级

在本页中，你将了解到你的 防护战士 的最佳属性优先级。我们首先列出属性优先级，然后深入解释这些属性如何与你的专精和游戏玩法相互作用。本内容已针对《魔兽世界》12.1.5版本更新。

1.

### 防护 战士 属性优先级

防护战士的一般属性优先级为：

装备等级

急速

暴击

全能

精通

**全能大致与暴击相等。全能为你提供恒定的伤害减免，并且对魔法伤害有效，而暴击则通过提高你的招架几率来出色地减轻物理攻击。它还比全能更大幅度地提高你造成的伤害。**

然而，所有副属性的数值都非常接近。虽然精通被认为是最差的副属性，但它绝不是一个“糟糕”的属性，其数值仍然与更好的属性非常接近。 **一般来说，属性优先级只应在比较相同物品等级的装备时遵循。一件物品等级比你当前所穿装备更高的装备，无论其副属性如何，都应该装备上。**

同样重要的是要理解，拥有
<em>更多</em> 属性比拥有“更好”的属性更重要。例如，如果你必须在20点暴击和10点急速之间做出选择，那么选择20点暴击会更好。

附魔和宝石通常也遵循属性优先级，因为你拥有的属性越多越好。然而，有些附魔不提供任何属性，而是提供其他有益效果。要看看它们中是否有值得使用的，请查看我们的 [附魔与宝石指南](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>).

:::details 常见问题：防护战士应该有多少急速？
在大多数情况下，并没有一个固定的 <em>任何</em> 属性是你应该拥有的。也没有特定的属性目标或你想要追求的特定属性分配。

人们很容易高估拥有“正确”副属性的重要性，而实际上，拥有更高数量的属性几乎总是胜过拥有“更好”的属性。拥有120点你最差的属性通常比拥有100点你最好的属性要好，因为它们之间的差距并不像许多人想象的那么大。

:::

1.

### 深入属性解析

下方你可以找到关于每项属性为 防护战士提供何种收益的详细说明。 **作为一名坦克，你的首要任务是生存，你应该据此来优化你的属性。** 如果你对职业很熟悉并且在生存方面没有问题，你可以开始着眼于优化更偏向输出的属性优先级。

**急速** 急速有几项作用。它减少公共冷却时间，提高你的攻击速度，并减少[[spell:23922]]、[[spell:6343]]的冷却时间，从而增加怒气产生和伤害。

但最重要的是，它减少了[[spell:2565]]的冷却时间。这让你对你的主动减伤有更强的控制力，并有助于平滑你承受的伤害。

:::details 更多信息更多信息
进一步阐述上述内容，增加的怒气产生会按你急速增加的比例增加你获得的[[spell:190456]]总量。X%的急速提升相当于一场战斗中X%更多的怒气，这相当于X%更多的无视苦痛。额外的怒气还有助于通过[[spell:152278]]进一步减少冷却时间。

:::

**全能** 全能增加你造成的所有伤害和治疗（包括[[spell:190456]]），并减少你受到的所有伤害。全能不需要运气，也不依赖于某种特定的玩法。它减少 <em>全部</em> 伤害，使其成为生存能力的可靠属性。

:::details 更多信息更多信息
与其他属性相比，它在魔法伤害密集的战斗中价值大大增加，在这些情况下它位列优先级第一。其他属性依赖于你能够格挡/招架攻击，或者需要攻击是物理伤害才能减少伤害。

:::

**精通** 精通（[[spell:76857]]）增加你的格挡几率、招架几率和你的攻击强度。它不仅增加你的总体伤害减免，增加的攻击强度还会增加你的[[spell:190456]]的数值。

**暴击** 暴击在大秘境中价值增加。这是因为它同时提供防御性（[[spell:161798]]）和进攻性（增加暴击几率）的收益。

:::details 更多信息更多信息
在地下城中承受的大部分伤害是近战伤害，这意味着随着暴击的提高，你可以更频繁地招架，从而减少承受的伤害。暴击还能提高你的总体伤害输出，帮助你更快地完成钥石。虽然它是一个很好的总体伤害减免属性，但它并不可靠，对其他任何类型的伤害都毫无作用。

:::

**力量** 力量增加你的攻击强度，从而增加你的[[spell:190456]]的数值。然而，它的主要价值来自于通过[[spell:71]]和各种其他天赋获得的护甲提升。

**护甲** 减少你受到的物理伤害。它是一个完全被动且稳定的属性，对生存能力相当不错。然而，它对伤害完全没有作用。

2.1.

#### 耐力

**耐力** 增加你的最大生命值。

:::details 更多信息更多信息
关于耐力有一个非常常见的误解，认为它只对“扛住秒杀”或类似情况有用。这肯定是其中的一部分，拥有足够的生命值来应对机制很重要，但这并不是全部。

简单来说，耐力的作用与伤害减免相同，即减少伤害对你的影响。耐力的缺点是，虽然它增加了你的总体生存能力，但你承受的伤害必须被治疗回来。

这就是为什么堆叠耐力可能是有害的。你会变成一个治疗“海绵”，让治疗者很难治疗你。这里的关键是，耐力是一个很好的属性，在进行比较时应考虑其价值。

:::

2.2.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审核。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你可以为你的 防护战士 获取的最佳宝石、附魔、药水、合剂和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你应该使用提供急速的宝石，因为那是我们最看重的副属性。使用[[item:240983]]，并在任何其他宝石插槽中填入[[item:240890]]。如果那些太贵了，请随意使用[[item:240893]]。

1.

### 最佳附魔和武器强化

[[item:243733]]应该是你的默认武器油，因为它为我们提供了2个我们最喜欢的属性。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>[[item:244029]]，可靠的替代品。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头盔</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>肩部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244643]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

除了上面提到的附魔，我们还可以使用合剂、食物增益和药水来进一步增强我们的能力。这些不是永久性的，一两个小时后需要重新使用，所以在长时间游戏前请确保准备多个。

3.1.

#### 合剂

[[item:241326]]和[[item:241325]]都是极好的选择。哪一个最适合你取决于你当前的属性分配，也就是说，如果你的装备上已经有大量的暴击，你可能会选择急速合剂，反之亦然。

3.2.

#### 药水

[[item:241308]]是任何情况下的最佳药水。[[item:241288]]只略逊一筹，所以如果你无法获得[[item:241308]]，可以将其作为替代品。

:::details 狂乱放纵药水呢？
[[item:241292]]

实际上为你提供的主属性比

[[item:241308]]

为你提供更多的主属性。话虽如此，它也有一个缺点，即会在你脚下召唤虚空区域。当你站在这些区域中时，它们会使你沉默。因此，

[[item:241308]]

将是更稳定的药水，但

[[item:241292]]

是

**理论上**

如果你能避开虚空区域，它会更好。

:::

[[item:271883]]应该用作战斗中的治疗药水。

3.3.

#### 食物增益

[[item:255846]]或[[item:242273]]应该在可用时用作你的食物。[[item:242274]]和[[item:242275]]是你的两种替代食物增益。与药水和合剂类似，最好的选择取决于你当前的属性分配。一般来说，选择其中任何一个都不会错。

3.4.

#### 强化符文

[[item:259085]]为你提供持续一小时或直到你死亡的临时主属性增益。虽然昂贵，但它们确实能提高你的伤害输出，因此，如果金币不是问题，应该使用它们。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年10月4日：** 将武器附魔替换为哈希伊仪式。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月28日：** 明确了宝石选择。
- **2026年3月16日：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行审核和更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 更新了食物信息，加入了副属性。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了复查和更新。
- **2023年10月2日：** 将冰霜奉献替换为飘渺奉献。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 为10.1.5补丁进行了复查，加入了嗡鸣符文作为选项。
- **2023年6月21日：** 将霜纹护甲片作为可能的腿部附魔加入。
- **2023年5月16日：** 新增了暗影腰带扣，腰部附魔。
- **2023年5月9日：** 更新了原始宝石。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月24日：** 更新了原始宝石列表。
- **2023年3月22日：** 将嗡鸣的奥术宝石作为可行的宝石加入，并更新了玛瑙纪念戒指的使用场景。
- **2023年3月20日：** 新增了关于原始宝石的信息，并为10.0.7补丁进行了复查。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月26日：** 新增了更多急速宝石推荐。
- **2022年12月11日：** 将智慧奉献武器附魔替换为更具进攻性的冰霜奉献。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本攻略中，你将找到在《魔兽世界》12.1.5版本中使用你的 防护战士 挑战秘境+地下城的技巧和建议。

1.

### 防护战士在 至暗之夜第2赛季的秘境+

防护战士虽然不是 <em>最佳</em> 的大秘境选择（因为他们的控制导向的实用性），但在正确操作时拥有非常不错的生存能力和可靠的伤害输出。最难的部分是学习使用哪些冷却技能，以及何时使用。

有些技能可以用[[spell:2565]]格挡，而另一些则不能。有些技能可以用[[spell:23920]]反弹回去对敌人造成巨大伤害，而另一些则不能。所有这些知识都来自于游玩各个地下城并亲自积累经验！

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

1.

### 最佳大秘境天赋配置

我们的大秘境天赋树提供了良好的生存能力和进攻能力。有关具体天赋以及何时使用的更多信息，请参考配装与天赋页面。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主目前是秘境+中更好的全面选择。这并不意味着 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵就不好；它只是需要在进攻和防御技能使用之间进行更精细的平衡。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主天赋构建

2.1.

#### 山丘领主天赋

:::details 常见问题关于更高层数的钥石呢？
[[spell:385888]]

也可以被舍弃

[[spell:12975]]

，但这在大多数情况下都是多余的。

:::talents 防御型大秘境构建
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzwMzMzMmFzMLzYMmpxMGWMzMzYGmZAAAAwyMDwMGgB2gtFjGzAYWwMbgZmZYsAAzMAAMgxA"
}
```
:::

:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDwAbw2iRjZAMLYmNYmZmhxCAMzAAwAGD"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJWGEIJpp9BGC-CFMNEKLmIJPXw8+CdiikQVZltRWGoBA-AAAA-JQSU0AEU4AjDmF-
```

:::

### 备选 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵 天赋构建

2.2.

#### 巨神兵 天赋

:::details 常见问题关于更高层数的钥石呢？
以下你可以找到

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像

防御型构建。

[[spell:385888]]

也可以被舍弃

[[spell:12975]]

，但这在大多数情况下都是多余的。如果你决定不点

[[spell:385888]]

，那么你也可以选择不点

[[spell:385840]]

作为

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像

以获得一个额外的免费点数。

:::talents 防御型大秘境构建
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzwMzMzMmFzMLzYMmpxMGWMzMzYGmZAAAAwyMDwMGAYxMGWgBmhFaMzCYmZGGLAAmZAADYMA"
}
```
:::

:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDAsYGDLwAzwCNmZBmZmZYsAAYmBAMgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJGEIJ9FWqpBC-CFMNEKLmIJPXw8+CB4EFJhqyKbjsMQD-AAAA-AcgQphQhBTgwwC-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和阻止

3.1.

#### 打断、昏迷和阻止

[[spell:6552]] 是我们的主要打断技能。作为坦克，我们会承受地下城中大部分的伤害，虽然凭借 [[spell:2565]] 我们可以相当轻松地应对物理伤害，但魔法伤害才是更棘手的地方。有效地使用 [[spell:6552]] 来打断各种危险的施法，将大大降低我们承受的伤害并提高生存几率。

[[spell:386071]] 允许你沉默多个敌人，同时嘲讽它们全部。虽然从纸面上看这似乎是一个很棒的技能，但它有长达75秒的冷却时间，并且需要实际打断施法才能使沉默生效。在你面对多个致命施法者，或者需要帮助聚怪的情况下，它确实有潜在用途。

[[spell:384110]] 和 [[spell:64382]] 在点出 [[spell:1271948]] 后都提供沉默效果。[[spell:384110]] 应该是默认选择，因为它的冷却时间只有45秒，这意味着我们拥有一个真正的远程打断技能可用！

[[spell:5246]] 主要用作打断，因为它提供的迷惑效果很容易被伤害打破。你也可以用它来进行控场，对一群敌人使用后，将特定的敌人从那群敌人中拉出来集火。

[[spell:46968]] 是你的范围击晕技能。用它来延迟或取消危险的技能，或者作为生存工具，在你的防御技能处于冷却时击晕敌人。[[spell:275339]] 有助于大幅降低此技能的冷却时间，并且可以通过 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵 天赋如 [[spell:429639]] 和 [[spell:440992]] 进一步强化。

[[spell:107570]] 是另一个强大的单体击晕技能。当你只需要击晕一个敌人时，使用它代替 [[spell:46968]]，以防止触发击晕递减。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 拥有 [[spell:436162]] 天赋，这将使它额外命中2个敌人。

[[spell:385952]] 主要应为了其进攻部分而卡CD使用，但值得记住的是，施放时它也会击晕你的主要目标4秒。

[[spell:376079]] 允许你将被矛击中的敌人拴在矛上，然后跳跃到矛的位置造成一些额外伤害。与 [[spell:385952]] 一样，你主要应该卡CD进攻性地使用它。在某些情况下你可能会考虑延迟你的矛，比如出现锁定仇恨的敌人，或者敌人四处跳跃时。在这种情况下，使用 [[spell:376079]] 来拴住这些敌人可能对整个团队的表现更有益。

### 其他功能

3.2.

#### 其他功能

[[spell:23920]] 主要用于魔法伤害减免。然而在大秘境中，许多法术可以被反射回施法者。有些法术伤害非常高，如果可以反射，你可以对敌人造成大量伤害。此外，有时你可以将原本会施加在你身上的减益效果施加给敌人。

[[spell:97462]] 可以在承受大量伤害的阶段用来拯救队友，或者只是帮助减轻治疗者的压力。它有相当长的3分钟冷却时间，所以一定要不要浪费它。

[[spell:18499]] 使我们免疫 恐惧、闷棍和瘫痪效果。这可以在施法生效前先发制人地使用，或者在你已经受到影响后做出反应。你可以进一步点出 [[spell:384100]]，它允许你移除12码内小队成员身上的 恐惧 效果。或者你可以点 [[spell:1271925]]，它使 [[spell:18499]] 也能移除所有移动受限效果。

[[spell:3411]] 是一个极其强大的工具，如果有适用的场景的话。防止你的队友受到伤害，比如说，被锁定仇恨的敌人攻击，是帮助你团队的好方法。这个技能因为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主天赋，[[spell:438597]]。这会使 援护的目标也获得一个魔法吸收护盾，可用于为需要的盟友提供额外的防御。

[[spell:64382]] 在某些地下城中可能有特殊用途，那里的敌人要么拥有魔法免疫要么拥有吸收效果。请记住它有施法时间，意味着你不应在主动坦怪时使用它。同时注意会被 [[spell:1271948]] 沉默。

[[spell:384110]]与[[spell:64382]]类似，对吸收效果造成额外伤害。虽然它不能移除魔法免疫，但冷却时间要短得多，因此在特定情况下是更值得考虑的选择。它还会使用[[spell:1271948]]进行沉默。

[[spell:12323]]使你附近的敌人减速70%，同时使你的盟友移动速度提高30%。这在帮助团队规避机制，或只是加快从一波敌人到另一波敌人的推进速度时非常有用。

1.

### 应对词缀

### 词缀：升腾

4.1.

#### 防护 战士的傲慢词缀管理

周期性生成需要打断或控制的宝珠。应对此词缀的手段包括：

- [[spell:6552]]
- [[spell:386071]]
- [[spell:107570]]
- [[spell:385952]]
- [[spell:46968]]
- [[spell:5246]]

### 词缀：脉冲星

4.2.

#### 防护 战士的脉冲词缀应对

周期性生成与玩家相连的宝珠。你需要走进另一名玩家的宝珠，同时也要有人走进你的宝珠才能消除它。

### 词缀：吞噬

4.3.

#### 防护 战士 的吞噬词缀应对

在玩家身上施加一个需要驱散或治疗移除的吸收效果。作为战士，我们无法驱散，但可以通过使用[[spell:202168]]治疗自己来协助治疗者。

### 词缀：虚缚

4.4.

#### 防护 战士 的虚缚词缀应对策略

生成一个新的小怪，它会给其他敌人提供增益。尽快切换到这个小怪，并确保将其作为高优先级目标击杀。由于虚空大使只有1点生命值，你可以在它生成后立即开始施放[[spell:163201]]，因为它能造成大量伤害。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月12日：** 添加了防御天赋配装导出。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行审核和更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月8日：** 为山丘领主调整了大秘境天赋。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月6日：** 添加了关于副本小贴士的信息。
- **2025年4月25日：** 添加了关于不屈和破坏者的说明。
- **2025年4月21日：** 已针对11.1.5补丁进行审核。更新了巨神兵天赋树。
- **2025年3月4日：** 添加了山丘领主作为推荐的大秘境配装。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 为清晰起见，为天赋添加了推荐标签。已针对11.0.7补丁进行审核。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年5月8日：** 移除了“备选大秘境配置”。在配置中加入了坚韧迅捷。
- **2024年5月7日：** 为10.2.7进行了复查。将沉重反击替换为乘胜追击。
- **2024年4月22日：** 为第4赛季进行了复查。在功能技能下新增了震荡怒吼章节。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月22日：** 通过加入进攻型天赋更新了AOE循环部分。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了复查和更新。
- **2023年9月4日：** 为10.1.7补丁进行了复查和更新。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月21日：** 更新了大秘境天赋配置。选择了野蛮活力。
- **2023年5月11日：** 优先展示带有套装的天赋配置。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年3月15日：** 更新了天赋配置，默认选择攻城槌而非雷霆领主。
- **2023年2月27日：** 在技能列表中加入了雷霆咆哮、盾牌冲锋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月23日：** 新增了关于攻城槌、法术格挡和赛季词缀的说明。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到许多有用的宏和插件，让你在魔兽世界12.1.5补丁中使用防护战士时更加轻松。

1.

### 最佳宏

欢迎来到我们的插件与宏页面。在这里，我们将介绍一些实用的插件，帮助你通过信息更丰富的界面提升游戏体验，同时提供一些常用的防护战士宏。你可以通过点击每个独立代码块上的“复制”按钮来导入这些内容。

1.1.

#### 战士通用宏

#### 鼠标悬停打断宏

```wow-macro
#showtooltip 拳击
/cast [@mouseover,harm,nodead] 拳击; 拳击
```

这个宏允许你对鼠标悬停目标施放[[spell:6552]]，如果鼠标悬停目标无效，则对当前目标施放。

#### 姿态切换宏

```wow-macro
#showtooltip
/cast [stance:2]!防御姿态;!战斗姿态
```

这个宏让你可以在[[spell:386208]]和[[spell:386164]]之间切换，而无需为它们设置两个独立的键位。

1.2.

#### 防护战士专用宏

#### 盾牌猛击与无视苦痛宏

```wow-macro
#showtooltip
/cast 无视苦痛
/cast 盾牌猛击
```

用这个宏代替你常规的[[spell:190456]]按钮，以减少错过[[spell:23922]]重置的机会。

#### 鼠标悬停英勇投掷宏

```wow-macro
#showtooltip 英勇投掷
/cast [@mouseover,harm,nodead] 英勇投掷; 英勇投掷
```

此宏允许你对鼠标悬停目标使用[[spell:57755]]，如果鼠标悬停目标无效，则对当前目标使用。

#### 鼠标悬停嘲讽宏

```wow-macro
#showtooltip 嘲讽
/cast [@mouseover,harm,nodead] 嘲讽; 嘲讽
```

此宏允许你对鼠标悬停目标[[spell:355]]，如果鼠标悬停目标无效，则对当前目标使用。

#### 援护/冲锋宏

```wow-macro
#showtooltip 冲锋
/cast [target=mouseover,help,exists,nodead]援护;援护
/cast [target=target,harm,exists,nodead]冲锋;冲锋
```

此宏允许你[[spell:3411]]你的鼠标悬停盟友目标，或者如果当前目标是敌人，则[[spell:100]]你的当前目标。

1.

### 最佳插件

拥有一个功能齐全且清晰易读的界面是游戏中极其重要的一点，但许多人却忽视了这一点。什么样的界面算是好界面因人而异，但至少它应该以清晰直接的方式呈现所有重要信息。那些重要信息是什么则取决于你的职责和你正在参与的内容类型，但随着时间的推移，你会弄清楚哪些信息是你需要显示的，哪些是不需要的。

请注意，本节仅涵盖PvE内容（如地下城和团队副本）的推荐设置。诸如背包插件、任务插件等“生活质量”类插件不在讨论范围内。

大多数可靠的界面都包含以下内容：

- 居中的动作条，用于监控重要的触发效果或你的所有动作条，将循环输出信息移到屏幕中央附近会非常有益。
- 居中的单位框体，即玩家框体和目标框体。
- 首领报警插件，例如Deadly Boss Mods或BigWigs。
- 虽然这一点对某些职责更为重要，但监控其他成员的打断技能、外部减伤技能等的可用性。

再说一次，好界面是主观的。如果你是那种只做开放世界内容的玩家，那么一个更简洁的界面可能更适合你。花时间去创建一个适合 <em>你</em> 的界面是非常值得的。以上仅是建议。

话虽如此，如果你不确定从何入手，将重要信息围绕你的角色居中放置，并确保你的各种插件和界面元素不会重叠，这是一个很好的准则。

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

看看在不使用任何额外插件的情况下你能走多远甚至可能是值得的，也许你甚至会喜欢不必在每个补丁上花费数小时更新和重新配置你的界面。许多插件仍在开发中，或者专门旨在为至暗之夜上线时提供所有选项，因此你的一些最爱可能还不可用。

2.1.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.2.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.2.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.2.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.2.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.3.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.3.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对至暗之夜第1赛季发布进行更新和审核。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行审核和更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为10.1.5补丁进行了复查，移除了仇恨插件推荐。
- **2023年4月28日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
