## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5补丁火焰 法师攻略。在这里，你将学习如何在团队副本和大秘境地下城中扮演火焰 法师：从最基础的内容到最大化你的伤害输出。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

火焰 大秘境资源

[全新！顶级 火焰 天赋构筑](<https://raider.io/specs/fire-mage/talents>)

[顶级 火焰 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/mage/fire>)

[火焰 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=mage--fire>)

[热门 火焰 小队配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=mage--fire>)

1.

### 火焰法师概览

火焰专精在各种类型的战斗中都能出色地打出爆发和持续伤害。火焰可以在目标密集时顺劈，以牺牲极少的单体伤害为代价换取总体伤害提升。只要敌人站位密集，它也拥有打出大量AoE伤害的能力。与所有法师专精一样，火焰拥有高机动性，非常适合完成特定的战斗任务和引导机制。凭借[[spell:1953]]或[[spell:212653]]、[[spell:195283]]和[[spell:2948]]，高移动性战斗对火焰的总体输出影响极小。

出色的伤害类型——受制于数值调整

火焰法师拥有出色的伤害类型，既有爆发伤害也有斩杀阶段的DPS，这两种都是备受重视的伤害类型。它甚至可以免费获得顺劈伤害，同时还能对密集的敌人打出扎实的AoE DPS。目前的数值调整略有限制，但赛季初期通常会有多个调整补丁，可以显著改变这一状况。

尚可——非常适合用来学习战斗

火焰拥有强大的团队副本能力组合，生存能力尚可，伤害类型良好，机动性也不错。它甚至带来团队增益（

[[spell:1459]]

）。目前数值调整下的DPS偏低，在某些（史诗）团队副本战斗中，你非常依赖治疗者来存活。火焰几乎可以在移动中打出全部DPS，且循环相对简单，让你能专注于战斗机制，是学习战斗的绝佳专精。

尚可的伤害——出色的实用功能

火焰在大秘境/地下城中打出尚可的整体DPS，同时还拥有多层AoE打断能力，并以

[[spell:1459]]

和

[[spell:80353]]

的形式为小队提供重要的增益和实用功能，为任何小队带来出色的实用价值。它在防御端可能比较吃力，非常依赖治疗者来保命（比大多数职业更甚），但通过充分的准备可以部分缓解。

出色的实用功能，尤其在小型队伍中

火焰法师拥有强大的实用功能，比如其团队增益

[[spell:1459]]

，或至关重要的

[[spell:80353]]

，一些控制技能如

[[spell:31661]]

，通过

[[spell:475]]

移除负面效果，以及通过

[[spell:30449]]

移除敌人增益效果。这些实用功能大多（除奥术智力外）其他职业也能提供，因此在团队副本中实用价值不算特别高，但在大秘境中这些实用功能非常出色。

良好的防御能力，但高度依赖几个强力冷却技能，这些技能可能很快用尽

作为一名火焰法师，你拥有几个强力的防御工具。

[[spell:235313]]

是一个冷却时间短的强力防御工具，适用于低到中等伤害，而

[[spell:342245]]

则非常适合通过预先使用在大型伤害技能后快速回血。此外，

[[spell:45438]]

或

[[spell:414659]]

（互斥）在应对高伤害技能时极其强大，但冷却时间很长。最后，

[[spell:86949]]

为火焰提供了一个免死技能，在学习新内容时尤其有用。总体而言，火焰的生存能力高度依赖于敌人机制的时机，因为它几乎没有被动减伤，导致在某些战斗中防御能力极强，但在其他战斗中防御技能很快耗尽。

极高机动性

火焰拥有游戏中最好的即时机动性之一，这得益于它能够使用双层

[[spell:212653]]

或

[[spell:1953]]

，甚至可以通过某些天赋选项重置一次充能。因此，它通常几乎可以立即到达首领战中的任何位置。你甚至可以获得以

[[spell:382293]]

形式出现的类似冲刺的选项。其机动性的唯一缺点是持续移动速度，因为它所有的机动性都是爆发式的。火焰也可以在移动中打出大部分循环，而无法移动的部分可以通过

[[spell:212653]]

.

1.

### 火焰法师在至暗之夜中的表现

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本是第二赛季的季中更新。它增加了两个新的终局内容：一个全新的单Boss团队副本——基希克斯的解放，以及金多詹迷宫——一个全新的巨型地下堡， [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。请查看下面两者的指南！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

除了新的团队副本和迷宫之外，该补丁还通过 [[item:280562]] 带来了物品等级升级等内容。请查看我们的 12.1.5 补丁中心以获取完整概述。

2.3.

#### 职业改动

12.1.5补丁未对火焰法师做出任何改动。新团队副本和迷宫带来了新物品，所以请务必查看我们的
[配装](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>) 页面，其中还介绍了[[item:280562]]如何升级你的现有装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_firestarter.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1职业改动 隐藏12.1职业改动
火焰进入第二赛季时处境大不相同。最引人注目的是在[[spell:190319]]之外的大量伤害增益，使燃烧之外的时间更有意义。此外，新的套装将大量循环围绕[[spell:269650]]构建，并且 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒在[[spell:448601]]和[[spell:449293]]方面有一些改动。

2.3.1.

##### 伤害数值调整

- 所有火焰技能伤害提高12%。
- [[spell:11366]]和[[spell:2120]]的伤害在此基础上再提高15%。

总的来说，这是火焰在至暗之夜中获得的迄今为止最大的一次增强。

2.3.2.

##### 第2赛季套装

第二赛季带来了一套新的套装：

- [[spell:1296583]]：[[spell:269650]]使[[spell:11366]]和[[spell:2120]]必定暴击。
- [[spell:1296584]]：[[spell:269650]]使[[spell:11366]]和[[spell:2120]]的施法时间缩短20%，并使炽热涌动的伤害加成提高20%。

[[spell:269650]]的持续时间也从15秒增加到20秒，为你如何使用它提供了更多灵活性。这套新套装实际上将炽热涌动构筑锁定为唯一可行的终局构筑，将火焰的身份与炽热涌动玩法绑定在一起。如果你喜欢这种玩法那很好，但这并不是每个人都喜欢的玩法风格。

2.3.3.

##### 顶点天赋

[[spell:1257343]]的伤害类型发生了变化：

- [[spell:1257343]]现在提供2%的火焰伤害，持续8秒（原为4%，持续12秒）。
- [[spell:1257349]]：火焰伤害提高至5%/10%（原为3%/6%）。
- [[spell:1257348]]：在[[spell:190319]]期间触发的几率略有降低。

这将部分力量从连续触发（通常只在[[spell:190319]]期间）转移到非燃烧阶段，进一步提高了火焰在燃烧之外相对于燃烧期间的伤害。

2.3.4.

##### 日怒改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒是机制改动所在。球体生成和[[spell:449293]]的工作方式都发生了变化：

- [[spell:448601]]的基础生成量从25%降低到12%，[[spell:449596]]不再将上限提高到5个球体。相反，它将12%的生成量加回来（总共24%），并使每个球体额外提供1%的法术伤害。
- [[spell:449412]]现在每个球体延长[[spell:190319]]0.8秒（原为0.4秒），最多延长2.4秒（原为2秒）。由于你回到了三个球体的上限，三个球体即可达到最大延长效果。
- [[spell:1260272]]已被重新设计。当你的奥术凤凰到期时，它不再提供[[spell:1236231]]，取而代之的是，凤凰施放的每个法术都会提供一层[[spell:449293]]，而Exceptional法术则提供两层。
- [[spell:449293]]的10层上限已被移除。消耗[[spell:195283]]生成它的方式与之前相同。
- [[spell:449619]]不再在[[spell:190319]]期间使[[spell:449293]]的生成量翻倍。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火在12.1中未收到任何改动。

2.3.5.

##### 防御与功能

总体而言，火焰在12.1中变得更结实了一些，但整体防御类型变化不大。最重要的是，火焰获得了第二个[[spell:235313]]充能，这对应对相对较低但更频繁的伤害帮助很大。展开下方部分查看完整的防御和实用功能改动。

:::details **点击查看所有防御和功能性改动**
- [[spell:321708]]现在提供额外一个[[spell:235313]]充能，但不再使炽炎屏障的反击伤害提高200%。后一部分通常对PvE目的无关紧要。
- 新天赋：[[spell:1297073]]——使你受到的范围攻击伤害降低4%。
- [[spell:1244090]]仍然恢复你50%的生命值，但立即给予20%，其余30%在6秒内恢复。
- [[spell:2139]]现在在你对未在施法的目标使用时有独特的未命中视觉和音效。打断本身未变。

:::

套装和日怒的改动都调整了天赋并改变了你使用[[spell:269650]]的方式，所以请务必查看我们的
[天赋](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>),
[循环](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>) 和
[配装](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>) 页面了解详情。

:::

:::details 显示第2赛季热修隐藏第2赛季热修
2.3.6.

##### 9月1日热修复

补丁上线两周、赛季开始一周后，火焰收到了一些小幅增强： **所有伤害提高3%。**

任何增强都是受欢迎的，但3%并不能真正有意义地弥补火焰与顶级专精之间的差距。它确实有助于巩固其中游专精的地位，使其在除极高端史诗团队副本和最高层数大秘境之外的所有内容中都可用。

2.3.7.

##### 9月22/23日热修复

在9月22日（美服）/23日（欧服）的每周重置中，火焰收到了一些小幅增强，主要集中在提升其大秘境表现：

- [[spell:153561]]的持续伤害提高100%。在PvP中无效。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火：[[spell:1248014]]增强为使[[spell:2120]]伤害提高15%，原为10%。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒：[[spell:451035]]增强为使[[spell:2120]]伤害提高6%，原为3%。

这些增强在单体上大约提升1%的DPS，在多目标上提升3-5%的DPS，具体取决于目标数量。

这些增强不改变我们关于最佳天赋或最佳英雄天赋选择的推荐。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜中火焰法师的改动

至暗之夜已经到来，火焰法师收到了一次重大重做，同时影响了法师职业树和火焰专精本身。火焰的核心身份保持不变，通过连续暴击触发[[spell:195283]]，但节奏和爆发类型发生了显著变化。火焰现在是一个更偏向爆发的专精，[[spell:190319]]成为一个强大得多且更有意义的冷却技能，但燃烧的覆盖率显著降低，而燃烧之外的伤害更依赖于寻找暴击。此外，火焰现在需要监控的增益和减益效果也显著减少。

2.4.1.

##### 顶点天赋

至暗之夜引入了一种新型天赋，称为巅峰天赋。它出现在天赋树的底部，共有四个等级。它的功能与其他天赋类似，像往常一样消耗天赋点。

对于火焰，我们可以得到以下巅峰天赋：

- [[spell:1257343]]：消耗[[spell:195283]]时，有几率使你获得一层炽热涌动，提高你的火焰伤害。多层效果可以叠加。
- [[spell:1257349]]：获得炽热涌动时，每点使你的[[spell:319836]]冷却时间缩短2.5秒，共2点。
- [[spell:1257348]]：[[spell:190319]]大幅提高获得炽热涌动的几率，减少每次触发炽热涌动的层数。同时使炽热涌动将燃烧延长1秒。

该巅峰天赋是强力的伤害提升，尤其是在[[spell:190319]]期间，进一步巩固了燃烧作为极强冷却技能的地位。仅额外伤害就非常可观，而[[spell:319836]]冷却时间的缩短也让燃烧的节奏感觉非常紧凑。

2.4.2.

##### 英雄天赋改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

已进行简化以减少增益监控。该天赋树现在注重视觉吸引力，同时强化火焰的核心技能，并触发额外的冰霜法术造成额外伤害。

:::details **点击展开**
- 火焰/冰霜精通增益已被完全移除。
- [[spell:153561]]进一步巩固了作为霜火强力技能的地位。例如，[[spell:431178]]使其在提供[[spell:431176]]的同时，还保留了[[spell:431095]]使其额外发射一个[[spell:153595]]的原有功能。
- 新天赋：[[spell:1262843]]——施放[[spell:11366]]时，有几率发射一道[[spell:199786]]。
- 许多不同的天赋都能同时增强你的火焰法术和触发的冰霜法术，例如[[spell:1262845]]使[[spell:153595]]和[[spell:199786]]施加[[spell:12846]]，[[spell:1262844]]提高所有霜火法术的点燃效果，[[spell:1248014]]提高冰霜法术的暴击伤害，等等。

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒

已移除所有此前需要监控和围绕其运作的增益，同时保留了召唤凤凰造成高爆发伤害的核心幻想。

:::details **点击展开**
- [[spell:451035]]现在改为被动提高[[spell:11366]]和[[spell:2120]]的伤害，而不再是触发机制。
- 新[[spell:1260272]]天赋——当你的奥术凤凰消散时，提供次级时间扭曲（10秒内提高20%急速）。
- 新[[spell:1260673]]天赋——[[spell:133]]有几率召唤一个[[spell:449569]]，其落地时会缩短[[spell:319836]]的冷却时间。
- [[spell:449349]]已被重做——使[[spell:269650]]造成更高伤害，并使[[spell:153561]]触发火焰异常。

:::

2.4.3.

##### 核心输出循环改动

最大的变化是节奏的转变，尤其是在[[spell:190319]]之外。你需要施放更多[[spell:133]]来寻找[[spell:195283]]和[[spell:48107]]的触发。这是由于移除了许多保证暴击的来源，并大幅降低了燃烧的覆盖率：

- [[spell:257541]]及所有相关天赋已被移除。
- [[spell:383886]]已被移除。
- [[spell:383860]]已被移除。

作为补偿，[[spell:133]]现在拥有明显更快的施法时间（基础1.8秒，原为2.3秒），使得燃烧之外的循环感觉相当快，尽管保证触发减少了。此外，新增了以[[spell:269650]]形式出现的新触发，使[[spell:195283]]有几率让你下一个硬读条的[[spell:11366]]或[[spell:2120]]造成大幅提升的伤害。

2.4.4.

##### 点燃与顺劈改动

[[spell:12846]]已被重做：当你施放[[spell:319836]]时，它不再自动扩散到附近目标，且基础效果降低。不过，你可以通过[[spell:1254756]]和[[spell:383489]]等天赋重新获得点燃扩散（以及更多），使顺劈构筑成为真正的取舍而非免费伤害。

此外，整个[[spell:450716]]/[[spell:44457]]系列天赋已被移除。不过这些天赋完全是被动的，而且几乎从来没人点，所以这并不会实质改变循环。

2.4.5.

##### 其他改动

- 法师的防御技能已整合并简化：
  
  
  
  
  ►
  **点击展开**
  
  
  
  
  - [[spell:235313]]现在是你的主要防御技能。在点满所有相关天赋后，它现在提供更高的吸收量（最大生命值的30%）、伤害减免，并为你恢复所吸收伤害15%的生命值。它的公共冷却时间也更短，使你能更快回到输出节奏。
  - [[spell:110959]]和[[spell:55342]]不再降低受到的伤害——它们现在是纯粹的功能性法术。
  - [[spell:414660]]已被移除。
  - [[spell:1244090]]已加入，使你能在生命值降低后自我治疗，代价是对[[spell:342245]]的部分手动控制。操控时间通常主要用于应对高爆发伤害，但通过时间调整，它在因持续性伤害导致生命值偏低时也能用于自我恢复。
- 法师的机动性略有降低，现在需要做出一些取舍：
  
  
  
  
  ►
  **点击展开**
  
  
  
  
  - [[spell:212653]]现在基础只有1层充能（原为2层）和30秒冷却时间（原为25秒）。你可以找回失去的充能层，但现在这需要在[[spell:1270829]]和额外充能层之间取舍。
  - [[spell:1953]]现在可以通过天赋强化：[[spell:1244031]]提供额外充能层，[[spell:1244340]]缩短其冷却时间。
  - [[spell:108839]]已被移除。
- 各种功能性天赋已被削弱或改为抉择节点：
  
  
  
  
  ►
  **点击展开**
  
  
  
  
  - [[spell:382440]]已被完全移除。
  - [[spell:157981]]已从基础技能中移除（仅能通过日怒天赋获取，但非常依赖情境）。
  - [[spell:157997]]和[[spell:120]]现在互斥。
  - [[spell:383121]]和[[spell:113724]]现在互斥。
  - [[spell:2139]]现在打断持续7秒（原为5秒）。

1.

### 火焰法师基础玩法

火焰 法师的核心思路是通过连续触发暴击来触发[[spell:195283]]。实现这一点的主要方式是通过[[spell:319836]]将[[spell:48107]]转化为热力迸发。你的大部分时间都将用于施放[[spell:133]]，并通过火焰冲击将该技能产生的暴击转化为热力迸发，然后将其用于[[spell:11366]]。

火焰法师是游戏中少数拥有可在其他施法期间施放技能的职业之一。[[spell:319836]]是你在其他法术施放期间主要施放的法术，但火焰的主要输出冷却技能[[spell:190319]]也可以在其他法术施放期间施放。

[[spell:190319]]是火焰的主要输出冷却技能，它使你的所有法术必定暴击，从而在短时间内造成大量[[spell:195283]]，带来一波强力爆发。关于该专精核心机制的进一步说明可在下方列表中找到。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_fireball.jpg>) **避免浪费火焰冲击**
  
  
  
  
  [[spell:319836]]极其重要，因为它必定暴击，且可以在施放其他法术时施放。浪费这些充能会导致[[spell:195283]]数量大幅减少，进而造成巨大伤害损失。请务必熟练掌握在填充法术期间施放它，以将[[spell:48107]]转化为[[spell:195283]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_hotstreak.jpg>) **管理热力迸发和炽热连击触发**
  
  
  
  
  这与第一点息息相关：你几乎所有的伤害都来自使用[[spell:195283]]触发，所以绝不要通过覆盖浪费它们，并确保你所有的[[spell:48107]]都通过保证暴击的方式（如[[spell:319836]]或[[spell:2948]]（斩杀阶段））转化为[[spell:195283]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_soulburn.jpg>) **移动时始终施法**
  
  
  
  
  作为一名火焰法师，你拥有移动时始终能施放法术的特权。你最常施放的技能之一是瞬发的，即拥有[[spell:195283]]的[[spell:11366]]。围绕这一点规划你的走位非常重要。不过，即使你没有炽热连击且需要移动，你也可以使用[[spell:212653]]快速位移，或使用可在移动中施放的[[spell:2948]]。作为一名火焰，你真的没有任何理由不施法 <em>东西</em> 在移动时。

1.

### 如何为火焰法师配装

虽然我们始终建议你自行模拟以获得理想结果，但我们确实提供了专门的火焰配装页面。我们目前涵盖了第二赛季装备的推荐，以便在至暗之夜终局内容发布时有一个良好的开端。在你获取了一些装备后，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 为催化物品列表添加了掉落位置。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为12.1.5补丁更新（新增团队副本和迷宫链接，火焰无改动），将12.1补丁和第二赛季的在线修正移入下拉菜单，并移除了第一赛季的改动。
- **2026年10月9日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了毕业装备以显示升腾毒石的升级物品等级，并添加了升腾毒石升级指南，以及添加了基斯希克斯掉落。
- **2026年9月19日（本页）：** 新增了9月22/23日每周重置调整的增益。
- **2026年9月3日（本页面）：** 根据史诗进度和早期大秘境冲层更新了强度评估部分。
- **2026年9月1日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了一些额外ID，以确保其正确显示剧毒诅咒效果的提示信息，并更新了项链的最佳装备信息。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 在制造物品的提示信息中添加了制造属性，并将最佳装饰列表与下方的制造优先级对齐。
- **2026年8月29日（本页）：** 新增了第2周的增益。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已更正为正确的团队副本名称。
- **2026年8月23日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了整体最佳装备列表以包含猎人的仪式石，并更新了制造优先级，以更清晰地解释双手武器与副手制造的利弊。
- **2026 年 8 月 17 日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 更新了最佳药水。
- **2026年8月15日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了前期制造内容，使用猎人的仪式石。
- **2026年8月10日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 更新了12.1/第二赛季的最佳天赋，并更新了最佳天赋的循环信息。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 更新了12.1改动的法术信息。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 更新了12.1改动的最佳天赋、循环和套装奖励。同时新增了关于学习火焰三大核心原则的新章节。
- **2026年8月10日（本页）：** 新增了12.1补丁和第二赛季的改动，包括新的套装，并将第一赛季的改动整合为一个下拉菜单。
- **2026年6月17日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 根据补丁后更新的理论计算更新了毕业列表和最佳饰品。
- **2026年6月15日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 根据新的孢子融合装备更新了毕业列表和饰品推荐。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 添加了关于万世卷册的部分。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 添加了12.0.7的改动。
- **2026年5月23日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 因5月26/27日的增益，略微更新了最佳装备和饰品排名。
- **2026年5月23日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 根据5月26/27日的调整，略微更新了英雄天赋对比。
- **2026年5月22日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 略微更新了流星的使用方式，并移除了霜火不使用炎爆术的循环，因为其DPS收益极小甚至没有。
- **2026年4月24日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 调整了一些功能性天赋，使其成为更常见的默认选择。
- **2026年4月24日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 调整了一些功能性天赋，使其成为更常见的默认选择。
- **2026年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 修正了一个小错误
- **2026年4月21日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 修正了一个小错误
- **2026年4月20日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 新增了幽邃虚空核心和升腾虚空核心部分，并根据武器/饰品的新物品等级上限更新了最佳装备列表。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 更新了功能部分的布局，并为打断和功能添加了一些额外的说明。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 新增说明：火焰在12.0.5中未获得任何改动。
- **2026年4月4日（本页面）：** 根据最新的调整和史诗难度数据更新了可行性部分。
- **2026 年 3 月 31 日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 将无常能量熔炉饰品添加到饰品层级列表中。
- **2026年3月24日（本页）：** 移除了关于史诗钥石周即将到来的改动的章节，因为火焰在史诗钥石周开始时未获得任何改动。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 移除了茶的提及，因为它在副本中不起作用。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 因饰品调整补丁更新了饰品优先级。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 添加了一些关于传家宝装备和一般练级建议的有用链接，并添加了关于练级时使用哪些传家宝的部分。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 将赛季前毕业装备列表替换为3个不同的第1赛季毕业装备列表（总体、团本、大秘境），更新了第1赛季的制造信息，添加了第1赛季饰品天梯榜。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 更新了燃烧宏以默认包含所有相关种族技能/饰品栏位，并新增了关于看不到炽热连击触发以及流星/烈焰风暴宏和使用方法的常见问题解答。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 根据最新的理论研究发现更新了最佳消耗品。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜第1赛季更新：更新了最佳天赋、灵活天赋，添加了赛季词缀等。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 新增了第一赛季开始时的套装章节，并新增了烈焰风暴使用方法和烈焰风暴宏的常见问题解答。同时将霜火设为默认循环，并因调整改动为霜火新增了不使用炎爆术的循环。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 更新了推荐天赋构筑以区分史诗钥石地下城每周低保与冲层，并根据调整改动更新了最佳构筑。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 新增了第一赛季开始时的套装章节，并更新了天赋说明，指出主天赋页面上有略微更好的构筑。
- **2026年3月16日（本页面）：** 增加了第1赛季的改动+新内容，并更新了第1赛季开始时的表现。
- **2026年3月9日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 修复了指向 解除诅咒 的鼠标悬停宏。
- **2026年3月3日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 将最佳戒指附魔更新为鹰眼之眼。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 加入了80级天赋树，以便在开始至暗之夜练级时轻松导入。
- **2026年3月2日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了烈焰风暴的目标数量说明，提供更多背景信息。
- **2026年3月1日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 在食物部分添加了茶类及其移动速度加成。
- **2026年2月27日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了霜火循环，提供更多关于灼烧的背景信息。
- **2026年2月27日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 更新了霜火天赋，使其不使用灼烧，因为用灼烧代替霜火冲击会造成相当可观的DPS损失。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据最新的计算更新了烈焰风暴的AOE循环阈值。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（本页）：** 为至暗之夜改动更新（巅峰天赋、可行性）
- **2026年2月10日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 为12.0.1天赋树改动更新了天赋树。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据最新的最佳天赋更新了默认选择的天赋，并更新了循环以改进烈焰风暴的使用。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 为12.0.1天赋树改动更新了天赋树。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 为12.0.1天赋树改动更新了天赋树。
- **2026年2月10日（本页面）：** 再次略微更新了可行性以反映整体表现。
- **2026年1月23日（本页）：** 根据正式服数据更新了可行性部分。
- **2026年1月22日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 根据最新的理论研究更新了日怒天赋树。
- **2026年1月22日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 根据最新的理论研究更新了日怒天赋树。
- **2026年1月21日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据最新发现将默认循环复选框更新为设置为 日怒，并为两个英雄专精都添加了AOE和单体的完整配装。
- **2026年1月21日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 略微优化了日怒天赋树，并根据最新优化将推荐天赋树改为日怒。
- **2026年1月21日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 略微优化了日怒天赋树，并根据最新优化将推荐天赋树改为日怒。
- **2026年1月19日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 已针对至暗之夜前夕进行审查。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（本页）：** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 将优劣势更新为更具信息量的格式 + 为11.2.7进行了更新。
- **2025年10月5日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 为11.2.5更新了物品等级（涡轮加速物品等级），添加了谜之帮派章节，并针对无限徽记更新了制造推荐。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月9日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 略微更新了标准团队副本天赋中的防御天赋。
- **2025年9月5日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 更新了套装说明，解释本页无论有无套装均可良好使用。
- **2025年8月16日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 根据饰品调整和新发现更新了最佳饰品。
- **2025年8月15日（本页）：** 根据PTR调整后的数据和实际游戏活动更新了可行性章节。
- **2025年8月5日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 在饰品列表中添加了更多饰品，并略微更新了大秘境毕业装备。
- **2025 年 8 月 4 日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 针对11.2进行了审阅。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 针对11.2.0更新了毕业列表、饰品推荐、制作顺序，添加了Reshii章节
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已针对11.2.0进行更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 更新了11.2的最佳构筑，新增了第三赛季实用法术部分。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据11.2版本的改动，更新了单体和AoE的最优输出循环，并添加了套装循环改动章节。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 为11.2.0更新了所有天赋配置，并根据改动更新了推荐天赋。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 根据11.2.0的改动更新了法术。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 根据11.2的改动和套装奖励，更新了最佳循环、天赋和英雄天赋。
- **2025年8月4日（本页面）：** 新增了11.2版本信息，并移除了一些旧版本改动。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已更新关于随重置而来的改动的DISC腰带信息。
- **2025年6月17日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 略微更新了持久信息保障容器腰带的信息，以显示不同加成的百分比收益。
- **2025年6月17日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据最新更新的数据，更新了战斗助手的伤害增益/损失。
- **2025年6月17日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 根据最新更新的数据，更新了战斗助手的伤害增益/损失。
- **2025年6月15日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 已为 11.1.7 进行审查。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 添加了持久信息保密容器腰带信息和最佳奖励，并为新腰带更新了毕业列表。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 添加了战斗助手信息和提示。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 添加了战斗助手信息和提示。更详细地阐明了属性。
- **2025年6月15日（本页）：** 添加了11.1.7补丁信息。
- **2025年5月20日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了谜之卡特尔筹码部分以提供更多背景信息，并移除了对神经突触增强器的引用。
- **2025年5月15日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 将物品等级更新为涡轮增压物品等级，更新了推荐饰品并提供了更多背景信息和选项，更新了财团芯片并提供了更多背景信息和不同的路线推荐。
- **2025年4月27日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 用最新信息更新了谜之卡特皮尔代币部分。
- **2025年4月21日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 已针对11.1.5进行审查。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已更新至11.1.5版本。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 添加了赝品经销商芯片部分。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 添加了腐蚀附魔章节。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 将默认单体循环更新为霜火。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 在最新的霜火加强后，将推荐的单体目标天赋更新为霜火。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 添加了关于霜火天赋构筑更强但更难操作的说明。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月30日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 为TOP+酿酒师添加了警告，请勿点出「 Lessons in Deblitation 」天赋。
- **2025年3月22日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 移除了起手打断提示，因为它们无法被迷惑打断。
- **2025年3月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 移除了不需要的章节。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 根据操控时间治疗改动，更新了操控时间在应对治疗吸收时的使用说明。
- **2025年3月15日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了制作顺序，通过清晰区分首次制作和后续制作使其更有条理。
- **2025年3月14日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 为所有地下城添加了提示。
- **2025年3月13日（[解放安德迈页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 添加了加里维克斯的提示，并根据实际击杀更新了一些首领提示。
- **2025年3月10日（本页）：** 根据第1周的表现更新了可行性章节。
- **2025年3月4日（[解放安德迈页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 修复了齿轮大师不正确的天赋树
- **2025年3月3日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 删除了不再相关的旧段落，并修正了一个错别字。
- **2025年3月1日（[解放安德迈页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 基于测试服添加了提示。
- **2025年2月25日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 增加了霜火毕业装备，并根据最新的数值调整和理论计算优化更新了饰品。
- **2025年2月25日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 新增了最佳霜火天赋。
- **2025年2月24日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 针对11.1.0进行了审查。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 为11.1的改动更新了天赋和输出循环。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了第2赛季/11.1版本的毕业装备，根据新的毕业物品更新了制造推荐，根据新饰品更新了饰品推荐。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 根据11.1的改动更新了最佳天赋，并针对新的词缀更新了词缀提示。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 为11.1的更改进行了更新：新的默认配置设置为日怒，由于更改更新了新的最佳循环，添加了一个不太复杂的基础循环。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 更新了11.1版本的最佳天赋：新的推荐天赋树设为日怒，并根据11.1的改动更新了最优天赋树。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已为11.1更新：针对11.1的改动和套装奖励，更新了最优输出循环、属性、天赋和英雄天赋。
- **2025年2月24日（本页面）：** 增加了11.1版本最重要的改动概述，更新了11.1版本的可行性，进一步精简了页面内容以聚焦于攻略中最重要的方面。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 在增强后更新了Cyrce的指环建议，并在它变得更好后更新了毕业装备以包含它。
- **2024年12月15日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 为11.0.7进行了审阅。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 添加了Cyrce's Circlet章节。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 更新了页面布局，将不同的AoE天赋分成了各自的章节，并添加了推荐标签，以便更快地发现最佳配置。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 为11.0.7补丁增加了说明，并更新了11.0.7版本的可行性。
- **2024年11月26日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 针对最新的增益更新了天赋。
- **2024年11月26日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新循环，将 霜火 作为默认选择，因为增强后它现在优于 日怒。
- **2024年11月26日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 根据增益更新了最佳天赋：切换到以SKB为基础的霜火作为最佳构筑。也更新了AOE构筑。
- **2024年11月26日（本页）：** 新增了关于赛季中期加强及其对攻略影响的章节。更新了加强后的可行性评估。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 针对11.0.5版本改动更新了天赋。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 更新了天赋并将可行的天赋拆分为3种不同的天赋方案。还添加了地下城特定技巧。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 根据11.0.5的改动更新了天赋。将AOE天赋拆分为3套不同的配装。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已针对11.0.5的改动更新天赋。
- **2024年10月21日（本页）：** 新增11.0.5版本改动及其对攻略的影响。更新了可行性章节。
- **2024年10月2日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 更新了烈焰风暴与灼烧的取舍选择，进一步强调烈焰风暴能带来更高的总DPS。
- **2024年10月2日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 更新了烈焰风暴与灼烧的取舍选择，进一步强调烈焰风暴能带来更高的总DPS。
- **2024年9月24日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 修正了副手制造错误关联的专业。
- **2024年9月24日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 由于最新的增强使得烈焰冲击更加可行，现已添加基于烈焰冲击的AOE配装
- **2024年9月24日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了AoE输出循环，加入了基于烈焰风暴的循环，因为最近的增益使它变得更加可行。
- **2024年9月24日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 由于最新的增强使得烈焰冲击更加可行，现已添加基于烈焰冲击的AOE配装
- **2024年9月21日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 更新了属性权重的描述，更清楚地解释了使用最优装备（Top Gear）模拟更好。
- **2024年9月20日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 为多个首领添加了更多提示，为各个首领添加了精确的冷却使用说明，并为安苏雷克女王添加了冷却大纲。
- **2024年9月16日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 为新的毕业装备配置更新了制造建议。
- **2024年9月14日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋，用强化灼烧替代灼烧以在不牺牲任何有意义的范围伤害的情况下获得更多首领伤害，并将火焰之怒替换为熔岩狂怒，适用于所有构筑，因为在大多数场景下伤害略高。
- **2024年9月14日（本页面）：** 在最新增强后更新了可行性部分。
- **2024年9月11日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 新增了武器消耗品（油）。
- **2024年9月9日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 从不同来源添加了3份毕业列表：团队副本、大秘境、综合。添加了饰品梯队列表。从制造文本中移除了免责声明。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 添加了狡诈亵渎宝石作为替代宝石。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 移除了赛季前天赋，并更新了AOE天赋，不再花费2点在仅增加0.1% DPS却以单体DPS为代价的AOE天赋上。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 在bug修复后删除了关于“点燃未来”的bug提及。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 更新了第1赛季的强度评估部分。
- **2024年9月3日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了专业制作建议和毕业装备列表。
- **2024年9月2日（本页）：** 基于进一步的增强以及烈焰风暴相比最初预期的出色表现，更新了可行性部分。
- **2024年8月29日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 更新了AOE配装的说明，使其更清晰。
- **2024年8月28日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 修复了一个错别字。
- **2024年8月28日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 修正了一个错别字。
- **2024年8月28日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 更新了一些法术说明。
- **2024年8月27日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了关于更新后的装饰的制作建议，并更新了毕业列表。
- **2024年8月24日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 添加了地下堡天赋树。
- **2024年8月21日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月30日（[外观](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** 页面已添加。
- **2024年7月30日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 修正了整体毕业列表中缺少4件套的问题。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/fire-mage-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月18日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/fire-mage-mists-of-pandaria-remix-guide>)):** 修复了一个导致html错误的拼写错误
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/fire-mage-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/fire-mage-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月12日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 对输出循环进行了小幅更新。
- **2024年5月10日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了单独的套装部分，以指向正确的套装。
- **2024年5月10日（本页面）：** 更新了强度评估部分。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 为第4赛季更新了最佳装备：更新了毕业列表、套装描述、专业制造建议等。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 添加了新的第4赛季头盔附魔，以及药水的小幅改进。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 根据第4赛季的改动更新了最佳天赋。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据第4赛季的新套装更新了输出循环。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 根据第4赛季的套装改动更新了最佳天赋。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 因新的套装，更新了第4赛季的最佳天赋。
- **2024年4月22日（本页）：** 添加了第4赛季的变动，并更新了第4赛季的可行性部分。
- **2024年3月23日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 将燃烧循环拆分为两个独立部分，一部分是进入燃烧，一部分是燃烧期间，以提高可读性。此外还简化了起手描述。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已更新至10.2.6版本，将默认插件更新为更符合当今团本和大秘境环境的插件组合。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 为10.2.6补丁进行了更新，将不同的大秘境配置拆分到单独的方框中，这样它们占用的空间更少，也更容易查看。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.6版本更新，将火焰加速器添加为默认勾选的循环复选框，并添加了在燃烧期间使用火球术的行。同时清理了一些拼写错误。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已针对10.2.6补丁进行更新，将火焰加速器设为默认节点，取代了阿莱克丝塔萨的狂怒
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 已针对10.2.6补丁进行审核。
- **2024年3月9日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 略微更新了推荐的史诗钥石地下城天赋，并添加了更多关于选择点燃流与烈焰风暴流的信息。
- **2024年3月9日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 略微更新了推荐的烈焰风暴天赋，并添加了更多关于在点燃与烈焰风暴流派之间选择的信息。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 将10.2的变更替换为（缺失的）10.2.5变更。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2023年12月16日（本页）：** 根据12月19日的增益更新了可行性部分。
- **2023年11月24日（本页）：** 根据正式服数据更新了可行性部分。
- **2023年11月19日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 由于发现的优化，更新了复选框以默认启用奥妮克希亚的 狂怒，使 AF 成为默认天赋树的一部分。
- **2023年11月19日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 更新天赋树，默认选择Alexstrasza的狂怒，因为发现了优化点。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 由于孢子披风削弱，更新了毕业装备和纹章。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 为10.2更新了全部3个毕业和装备列表，添加了第31赛季套装部分，并根据新的专业制造物品等级更新了专业制造建议。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 移除了与玛瑙印记戒指相关的部分，因为它现在落后太多而不予考虑。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 根据10.2的改动更新了推荐属性。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 更新了10.2版本的天赋。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了10.2版本中新的最佳天赋方案和新套装的循环。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 由于10.2的改动，更新了推荐天赋。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 由于10.2补丁的改动，更新了推荐天赋和属性。
- **2023年11月6日（本页）：** 添加了包含10.2改动的章节，移除了旧版本补丁的改动，为10.2更新了可行性章节。
- **2023年10月1日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 更新了食物增益建议。
- **2023年9月26日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更改了布局。
- **2023年9月7日（本页）：** 更新了可行性部分，添加了更多细节。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 添加了3种不同的毕业配装。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 更改了天赋布局，使其更易于浏览。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 添加了10.1.7指南变动。
- **2023年8月9日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 将宝石建议从精通改为急速+全能。
- **2023年8月9日（本页）：** 根据最新的削弱更新了可行性。
- **2023年8月1日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 更新了灼烧之痛和爆击天赋的选择，而非陨石。
- **2023年7月15日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 由于炎爆术的削弱，更新了 AOE 炎爆术循环。
- **2023年7月15日（本页）：** 更新了削弱后的可用性。
- **2023年7月14日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据最新的优化更新了AOE烈焰风暴循环。
- **2023年7月14日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 添加了活体炸弹不应在单目标上使用的声明。
- **2023年7月11日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 为新的天赋树更新了升级天赋树。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了重做后的火焰毕业装备，并增加了永恒黎明副本装备章节。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对10.1.5的火焰重做进行审核，无需更改。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 根据10.1.5的火焰法师重做以及原初宝石的削弱进行了更新。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 更新了10.1.5版本火焰法师重做后的属性建议。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 更新了10.1.5版火焰重做后的天赋推荐、输出循环和实用性说明。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了10.1.5版本火焰法师重做的循环。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 在火焰重做后，为10.1.5版本更新了推荐天赋。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 更新了10.1.5版本 火焰 法师 重做的所有法术和天赋
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 为10.1.5版本火焰重做更新了天赋和循环。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年6月12日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 修复了天赋导入字符串。
- **2023年5月25日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 添加了时光漫游部分。
- **2023年5月22日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 更新了腿部附魔建议。
- **2023年5月8日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 根据改进的模拟和进一步的理论计算更新了饰品建议。
- **2023年5月6日（本页面）：** 根据影响专精平衡的物品热修更新了可行性部分。
- **2023年5月3日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 添加了关于推荐天赋基于拥有2件套和4件套的说明。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了毕业装备、制造建议、装饰，并将勇气描述替换为新的纹章系统，根据新的10.1装备更新了玛瑙印记戒指部分。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 根据10.1新装备更新了奥术指环建议。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 根据 10.1 的改动更新了推荐属性。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 根据新的最优天赋更新了天赋，并移除了关于烈焰风暴构建的提及，因为它现在落后太多不值得考虑，同时移除了关于雷鸣的提及。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据新的套装效果和新的最优天赋更新了输出循环。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 根据10.1的改动更新了推荐天赋，并清理了一些建议。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 清理了一些描述，使其更清晰。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 针对10.1套装加成更新了建议的天赋和输出循环。
- **2023年5月1日（本页）：** 添加了 10.1 变更，添加了一个部分指出为 10.1 制作的指南主要变更，并为 10.1 调整更新了可行性部分。
- **2023年4月28日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 添加了一个通用WeakAuras包，包含所有专精所需的全部WeakAuras。
- **2023年3月25日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 根据在线修复更新了Onyx戒指建议。
- **2023年3月25日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 根据热修复更新了原始石宝石建议。
- **2023年3月22日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 更新了最佳装备以包含昂赛恩戒指，因为发现了新的宝石组合。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 由于 Desirious Blood Stone（渴血之石）的组合非常强大，更新了始源之石的宝石建议。
- **2023年3月21日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 根据晦暗粉彩石在正式服务器上是奥术而非暗影，更新了原始石宝石建议。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/fire-mage-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 添加了玛瑙禁锢戒指信息并针对10.0.7补丁进行了审阅。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 添加了原初之石宝石建议，并针对10.0.7补丁进行了审核。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 为10.0.7补丁进行了审查，并将精通调整至全能之上。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已针对10.0.7补丁进行审阅并提供了一些小的措辞调整。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 重写了输出循环的部分内容，使其更易于理解，并将灼烧之魂/炎爆术独立成一个章节。为10.0.7补丁进行了审查。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 添加了通往附魔和宝石页面的链接，用于原始宝石。
- **2023年2月16日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 移除了旧备注。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 根据更新后的理论计算更新了毕业装备建议。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 针对10.0.5的增益更新了可行性部分。
- **2023年1月13日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 添加了腿部附魔。
- **2023年1月3日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 将变换了力量加入输出循环。
- **2022年12月17日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 由于青铜护手的改动，更新了制造装备信息。
- **2022 年 12 月 14 日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 添加了武器灌注建议。
- **2022年12月13日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 根据最新的理论计算知识进一步更新了制造装备信息。
- **2022年12月13日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 更新了药水建议。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已针对第1赛季更新，包括专业制造装备、大秘境装备和团本装备。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 根据进一步的理论计算更新了饰品推荐，并为打造装备添加了更多信息。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 更新了药水建议。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 根据更好的模拟结果更新了宝石建议。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 添加了解释因套装而导致的输出循环变化的章节。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新范围伤害循环，更清晰地解释当你没有点出烈焰打击/焰道时的范围伤害循环。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月30日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 从循环中移除了烈焰风暴一行，因为它不再值得使用也不再点天赋。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 将天赋建议拆分为暗夜精灵和非暗夜精灵部分。
- **2022年10月24日（[升级](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/fire-mage-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/fire-mage-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/fire-mage-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[装备页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[属性页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[统御圣所页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[大秘境页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[循环页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[天赋页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[法术页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（本页）：** 已为巨龙时代前夕更新。
- **2022 年 1 月 26 日（[9.2版本分析](<https://www.icy-veins.com/wow/fire-mage-patch-9-2-changes-analysis>)):** 更新了套装部分以反映其受到的削弱。
- **2022 年 1 月 22 日（[9.2版本分析](<https://www.icy-veins.com/wow/fire-mage-patch-9-2-changes-analysis>)):** 已更新至9.2补丁。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/fire-mage-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/fire-mage-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/fire-mage-patch-9-1-changes-analysis>)):** 已针对9.1补丁团队副本发布进行更新。
- **2021年4月25日（[9.1 补丁分析](<https://www.icy-veins.com/wow/fire-mage-patch-9-1-changes-analysis>)):** 页面创建。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-crucible-of-storms-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2019年7月18日（[永恒宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** 新增了阿扎莎的技巧。
- **2019年7月16日（[永恒宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** 移除了免责声明。
- **2019年7月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** 为除艾萨拉之外的每个首领添加了提示，更新了天赋推荐，并将精华推荐分为2个类别。
- **2019年7月10日（[永恒宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** 添加了初始天赋推荐。
- **2019年7月7日（[永恒宫殿页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月12日（[风暴熔渣页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-crucible-of-storms-raid-guide>)):** 添加了更多提示。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019 年 2 月 3 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了财富战利品的提示。
- **2019年1月30日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 已针对吉安娜昏迷热修复进行更新。
- **2019年1月28日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了更多吉安娜信息和建议。
- **2019年1月23日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 修复了一个包含奥术 法师信息的章节。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为 火焰 法师添加了达萨罗之战攻略。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年10月29日（[奥杜尔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** 移除了塔罗克上点燃的潜在用法。
- **2018年8月30日（[奥杜尔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** 为奥杜尔添加了天赋建议和Boss指南。
- **2018年8月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** 暂时添加了火焰法师首领逐个页面（空白）。

显示更多

显示更少

:::

## 练级

在本页，你将找到我们的 火焰 法师 逐级升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[法师升级指南](<https://www.icy-veins.com/wow/mage-leveling-guide>).

1.

### 火焰法师在至暗之夜的练级指南

火焰 法师 在户外内容中相对强势，当你能够在 [[spell:190319]] 期间进行大规模拉怪并快速击杀所有敌人时。然而，如果敌人分散开来就会很吃力，因为 火焰 需要一段时间才能开始正常输出伤害，而且 火焰 不太擅长频繁切换目标。不幸的是，这些缺点同样适用于地下城，因为升级地下城通常节奏很快，敌人会迅速死亡。因此，最佳的升级方式通常就是简单地做任务。

1.1.

#### 升级装备选择

升级时，始终选择物品等级最高的战利品。这条规则唯一的例外是，如果你有一个物品等级稍低的戒指或项链，但它有两个副属性而不是一个。

使用传家宝物品时，我们通常建议直接使用2个[[item:122361]]。它提供了有用的续航能力，让你能够连续拉怪，并且在升级过程中无需担心更换饰品。

对于其他传家宝，我建议全部使用急速装备。在多件急速装备之间选择时，全能是一个稳妥的第二属性。

1.2.

#### 至暗之夜中实用的升级消耗品

在本节中，我们将重点介绍一些在至暗之夜中升级时有用的消耗品。这些将主要侧重于速度。包括你的移动速度，当然也包括你实际的DPS。

- [[item:223653]] — 靴子速度附魔。需要等级70。
- [[item:223800]] — 披风速度附魔。需要等级70。
- [[item:223725]] — 护腕速度附魔。需要等级70。
- [[item:225592]] — 提供大量速度。需要等级75。
- [[item:172063]] 或 [[item:133576]] —— 较旧的速度增益，如果它们便宜得多或者你恰好有之前版本剩下的，可能会有用。这些大多需要 55 级。

1.

### 升级天赋

在下方，你可以看到推荐的练级天赋配置以及练级时选择天赋的顺序。

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 火焰80级至暗之夜升级
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAMjFDzYmFbzMjMzYAAAYAAzMTWYGAgNzMjtxMzM2AAAAAwmZGzAAAjZMzYmZmZBAzMwgxgZAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAMjFDzYmFbzMjMzMDAAADAYmZaWWWmBAYzMzYbMzMjNAAAAAsZmxMAAwYGzMmZmZWAwMDMGjBzwYA"
}
```
:::

:::details 来源计算器编码
```
#:A-VSLLidjiAawdMxy6CLbaD5rwDFECaQAj5TV-CABkbMdwMW0UQK5omuqSSiKmlBJC6MA-AAAA-DSEAGaYWUMcARB-
```

:::

2.1.

#### 升级用战争模式天赋

在本节中，我们将对最适合升级以及进行单人/小队PVE内容的PVP天赋进行排名。

1. [[spell:390428]]为你提供显著的伤害增益。在开放世界内容中，降低的生命值通常不是问题。
2. [[spell:353082]]会放置一个相对较大的圆圈，烧灼走进圆圈外围的敌人，造成可观伤害。
3. [[spell:203286]]是一个伤害非常高的法术，尤其对高生命值敌人而言，它将大幅增加你对高生命值敌人（如世界首领或稀有怪）的伤害。
4.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

1. **等级 8 起：**确保你始终保持[[spell:1459]]。请记住，如果你死了，你必须重新施放它。否则每小时施放一次即可。
2. **等级 49 起：**在你即将进行大规模拉怪或首领战时施放[[spell:80353]]。请记住，即使冷却时间是5分钟，你也只能每10分钟获得一次增益效果。
3. **等级 75 起：**在[[spell:383860]]期间施放[[spell:11366]]。（在点了[[spell:449619]]天赋时，[[spell:190319]]结束后你获得的触发效果。
4. **等级 2–9：**卡冷却时间使用[[spell:319836]]。
5. **等级 39 起：**每当它就绪时就使用[[spell:153561]]。如果[[spell:190319]]即将就绪，将流星延迟到燃烧时再使用，并在燃烧期间使用它。
6. **等级 15 起：**当[[spell:190319]]冷却完毕且你至少有几层[[spell:319836]]充能时施放它。
7. **等级 10–20：**当你拥有[[spell:195283]]时，施放[[spell:11366]]。
8. **等级 21 起：**在与1-3个目标战斗时，当你拥有[[spell:195283]]时施放[[spell:11366]]。
9. **等级 25 起：**当你拥有 [[spell:195283]] 并且在与4个或更多目标战斗时，施放 [[spell:2120]]。
10. **等级 13 起：**当你拥有[[spell:48107]]时施放[[spell:319836]]以获得[[spell:195283]]。
11. **等级 33 起：**当目标生命值低于30%时，将[[spell:2948]]作为填充技能施放。
12. **等级 10 起：**使用 [[spell:133]] 作为填充技能。
13.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 添加了一些关于传家宝装备和一般练级建议的有用链接，并添加了关于练级时使用哪些传家宝的部分。
- **2026年3月2日：** 加入了80级天赋树，以便在开始至暗之夜练级时轻松导入。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已更新至11.1.5版本。
- **2025 年 2 月 24 日：** 为11.1的改动更新了天赋和输出循环。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5版本改动更新了天赋。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月12日：** 对输出循环进行了小幅更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023 年 7 月 11 日：** 为新的天赋树更新了升级天赋树。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月30日：** 从循环中移除了烈焰风暴一行，因为它不再值得使用也不再点天赋。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在此页面上，我们解释如何在《魔兽世界》12.1.5补丁中轻松游玩火焰法师，使用最简单的循环、天赋树、属性优先级、装备配置等，而不牺牲性能。

1.

### 火焰法师基础

本节面向刚接触游戏或该职业的玩家，他们无意参与史诗难度团队副本，或只是希望以更直接的方式进行专精输出，而不会被最优输出所需的众多优先级和主动技能所淹没。

火焰是一个全面均衡的专精，主要依赖于提前规划爆发窗口。一般来说，它对按键绑定的要求并不高，不过短时间内执行大量操作可能会让新手感到不知所措。在本节中，我们将重点介绍一种配置方案，它在不过度牺牲整体伤害输出的前提下，最大限度地减少所需的按键数量和反应能力。学习该专精时需要遵循的三条快速规则是：

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_fireball.jpg>) **避免浪费火焰冲击**
  
  
  
  
  [[spell:319836]]极其重要，因为它必定暴击，且可以在施放其他法术时施放。浪费这些充能会导致[[spell:195283]]数量大幅减少，进而造成巨大伤害损失。请务必熟练掌握在填充法术期间施放它，以将[[spell:48107]]转化为[[spell:195283]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_hotstreak.jpg>) **管理热力迸发和炽热连击触发**
  
  
  
  
  这与第一点息息相关：你几乎所有的伤害都来自使用[[spell:195283]]触发，所以绝不要通过覆盖浪费它们，并确保你所有的[[spell:48107]]都通过保证暴击的方式（如[[spell:319836]]或[[spell:2948]]（斩杀阶段））转化为[[spell:195283]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_soulburn.jpg>) **移动时始终施法**
  
  
  
  
  作为一名火焰法师，你拥有移动时始终能施放法术的特权。你最常施放的技能之一是瞬发的，即拥有[[spell:195283]]的[[spell:11366]]。围绕这一点规划你的走位非常重要。不过，即使你没有炽热连击且需要移动，你也可以使用[[spell:212653]]快速位移，或使用可在移动中施放的[[spell:2948]]。作为一名火焰，你真的没有任何理由不施法 <em>东西</em> 在移动时。

1.

### 至暗之夜 中 火焰 法师 新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒团队副本天赋

2.1.

#### 法师 新手团本天赋 火焰

这个配装是你在单体目标情况下（如团队副本战斗）的最佳起点。这个配装的一个巨大好处是，它也是你可以在范围伤害情况下使用的相同配装，意味着你只需要学习一套天赋即可应对所有情况。

下面的构建没有选择[[spell:457735]]，这样你就无需追踪这个额外的触发，同时为这种降低的复杂度只牺牲了很少的DPS。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAAbmZMzAAgZMmZmZMzsMAMzAMGwMMGA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRx7DUo4QAJ5GEE-CdIBCw02MUWYs4KRoqu8ATSceimGKeA-AAAA-DQko0IUY4IDwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒地下城天赋

2.2.

#### 火焰 法师新手副本天赋

大秘境天赋与团本天赋非常相似，因为输出天赋完全相同。这是因为在AoE和单体场景中打出最优伤害都不需要切换天赋。

这套天赋确实替换了一些功能型法术，为你提供对大秘境非常有用的工具，例如多个打断和驱散技能。

你可以通过下面的"复制导出字符串"按钮，轻松地将下方的天赋树导入游戏中。

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAAAmZmmltlZAA2MzM2mZmZmHYDAAAAAbmZMzAAgZMmZmZMzsAgZGMjxAmhxA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFNhlxd0EVFJRx7DUo4QQJJJ-CdIBCw02MUWYs4KRoquATSceimGKe0A-AAAA-DQko0IUY4IDwwC-
```

:::

### 火焰 法师基础输出循环

2.3.

#### 新手 火焰 法师 输出循环

我们的目标是使用我们的强力输出冷却技能[[spell:190319]]，并尽可能多地打出暴击和瞬发施法的[[spell:11366]]。下面，我们介绍一个简化的循环来实现这一目标：

1. 将你的第一个 [[spell:190319]] 延迟到目标生命值低于 90% 时使用。（由于 [[spell:205026]]）
2. 当目标生命值低于90%后，一旦可用就使用[[spell:190319]]。
3. 在 [[spell:383860]] 激活期间，施放 [[spell:11366]]。
4. 在 [[spell:190319]] 期间施放 [[spell:153561]]。它也会在燃烧之间可用，但为了简化操作，我建议只在燃烧期间使用它。
5. 在[[spell:190319]]期间，使用[[spell:319836]]和[[spell:11366]]来产生[[spell:48107]]和[[spell:195283]]。当你的火焰冲击充能耗尽时，使用[[spell:2948]]。
6. 当你拥有[[spell:195283]]时，施放[[spell:11366]]。
7. 当你拥有 [[spell:269650]] 时，硬读条（即非瞬发施放）施放 [[spell:11366]]。
8. 当你拥有 [[spell:48107]] 时，施放 [[spell:319836]] 来获得 [[spell:195283]]。记住：你可以在施放其他法术的同时施放 火焰 冲击，所以你应该在它触发时在 [[spell:133]]/[[spell:2948]] 期间施放它，这样你就可以立即用 [[spell:11366]] 接上之前的施放。
9. 如果目标生命值低于30%，使用[[spell:2948]]作为填充法术来触发[[spell:48107]] / [[spell:195283]]。
10. 当目标生命值高于30%时，将[[spell:133]]作为填充技能来产生[[spell:48107]] / [[spell:195283]]。

2.4.

#### AOE循环

在目标少于4个的情况下，你应该坚持使用单目标循环。

面对4个或更多目标时，你遵循单目标输出循环，但有一个关键改变：将[[spell:195283]]和[[spell:269650]]的触发效果用在[[spell:2120]]上，而不是[[spell:11366]]。就是这样！

2.4.1.

##### 巅峰天赋： ![Fired Up Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_incinerate.jpg>) 焚烧殆尽

火焰 拥有以下巅峰天赋：

- [[spell:1257343]]：消耗[[spell:195283]]时，有几率使你获得一层炽热涌动，提高你的火焰伤害。多层效果可以叠加。
- [[spell:1257349]]：获得炽热涌动时，每点使你的[[spell:319836]]冷却时间缩短2.5秒，共2点。
- [[spell:1257348]]：[[spell:190319]]大幅提高获得炽热涌动的几率，减少每次触发炽热涌动的层数。同时使炽热涌动将燃烧延长1秒。

火焰的顶点天赋为两个英雄专精都提供了大量伤害，几乎总是会被点出。Fired Up是一个新的触发效果，每当触发时会提供大量额外伤害，这是一个非常不错的被动加成。然而，更有影响力的是触发时带来的巨大的5秒[[spell:319836]]冷却时间缩短，这发生得相当频繁，尤其是在[[spell:190319]]期间。

这个 [[spell:319836]] 冷却缩减使得你在 [[spell:190319]] 期间几乎不会用完 火焰 冲击充能，通常只会在燃烧即将结束时才用完。这使得你可以在燃烧的几乎整个持续时间内将 [[spell:11366]] 链接到 火焰 冲击，而无需穿插任何其他法术。

所有这些额外的[[spell:319836]]充能确实导致了一种奇怪的奢侈“问题”，即它相对降低了[[spell:269650]]的价值，因为在[[spell:190319]]期间硬读[[spell:11366]]有超出火焰 Blast充能上限的风险，使得在燃烧期间很难硬读。因此，你通常最终不得不将硬读推迟到燃烧结束之后。

2.4.2.

##### 第2赛季套装

我们第2赛季的套装为：

- [[spell:1296583]]：[[spell:269650]]使[[spell:11366]]和[[spell:2120]]必定暴击。
- [[spell:1296584]]：[[spell:269650]]使[[spell:11366]]和[[spell:2120]]的施法时间缩短20%，并使炽热涌动的伤害加成提高20%。

这套套装完全围绕[[spell:269650]]，这使得它几乎是所有天赋方案的必备天赋。

套装非常强大，你应该在任何可能的物品等级下都尝试获得它，因为它不仅大大增加了你的DPS，还通过加快[[spell:269650]]的硬读速度使输出循环更容易，减少了因需要移动而被打断的空间。

### 火焰法师属性优先级

2.5.

#### 火焰 法师属性优先级

对于单体和范围输出，你都应该按照以下顺序优先考虑属性。有关本页呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>).

智力

急速

精通

全能

暴击

我们建议你优先考虑物品等级而非特定属性，因为它们的价值都很接近，而且会根据你当前拥有的装备大幅波动。

### 暴风雪战斗助手

2.6.

#### 火焰法师战斗助手

11.1.7补丁引入了两个与战斗相关的新功能：辅助高亮和单键助手。有关如何启用这些功能及其所有细节的完整概述，请查看我们的
[战斗助手页面](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>).

辅助高亮循环是一个相对不错的循环，因此遵循它是学习循环的好方法，但你会损失相当一部分伤害，与遵循本页循环相比大约损失10-20%。请注意，火焰的独特之处在于它可以在使用其他法术的同时施放法术，例如[[spell:319836]]。因此，仅仅看到下一个法术有时是不够的，因为你还需要知道在当前法术期间究竟何时施放它。鉴于此，我强烈建议你在使用辅助高亮时也阅读基础循环，以便了解何时施放被高亮的法术。

单键助手对于 火焰 来说不幸存在一些问题，导致其伤害比本页面上的循环低约 30-40%。施加的公共冷却惩罚对于 火焰 来说是一个大问题，因为 火焰 依赖于同时排队施放某些法术（例如 [[spell:133]] 接 [[spell:11366]]），而单键助手不允许你这样做。此外，火焰 拥有非常多的瞬发法术，这些法术同样受到公共冷却惩罚的影响，导致使用单键助手时造成约 30-40% 的伤害损失。

单键辅助可能很有用，特别是当你刚开始学习这个专精，或者在学习新的Boss机制时，因为它可以让你完全专注于Boss机制而不是输出循环。然而，如果你想最大化你的伤害，我建议你遵循高亮输出循环，或者本页上的输出循环，因为单键输出循环会损失30-40%的伤害。

请注意，无论是单键循环还是辅助高亮循环，都不会施放/高亮[[spell:190319]]、种族冷却技能或饰品等物品，因此你必须手动使用这些。

2.7.

#### 作为 法师 使用战斗助手的技巧 火焰

- 确保按冷却时间使用 [[spell:190319]]，因为战斗助手不会使用/高亮它。
- 在[[spell:190319]]期间使用你的饰品、药水、种族冷却技能（如[[spell:26297]]）或其他使用型冷却技能。
- 如果使用一键助手，请确保频繁按下按钮，因为 [[spell:319836]] 可以在施放其他法术的同时施放，所以你需要按下按钮两次来施放 火焰 冲击和其后的法术。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 更新了12.1改动的最佳天赋、循环和套装奖励。同时新增了关于学习火焰三大核心原则的新章节。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 新增了第一赛季开始时的套装章节，并更新了天赋说明，指出主天赋页面上有略微更好的构筑。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为12.0.1天赋树改动更新了天赋树。
- **2026年1月22日：** 根据最新的理论研究更新了日怒天赋树。
- **2026年1月21日：** 略微优化了日怒天赋树，并根据最新优化将推荐天赋树改为日怒。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月5日：** 更新了套装说明，解释本页无论有无套装均可良好使用。
- **2025年8月4日：** 根据11.2的改动和套装奖励，更新了最佳循环、天赋和英雄天赋。
- **2025年6月17日：** 根据最新更新的数据，更新了战斗助手的伤害增益/损失。
- **2025年6月15日：** 添加了战斗助手信息和提示。更详细地阐明了属性。
- **2025年4月21日：** 添加了关于霜火天赋构筑更强但更难操作的说明。
- **2025 年 2 月 24 日：** 已为11.1更新：针对11.1的改动和套装奖励，更新了最优输出循环、属性、天赋和英雄天赋。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5的改动更新天赋。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 因新的套装，更新了第4赛季的最佳天赋。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 由于10.2补丁的改动，更新了推荐天赋和属性。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为10.1.5版本火焰重做更新了天赋和循环。
- **2023年5月1日：** 针对10.1套装加成更新了建议的天赋和输出循环。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到《魔兽世界》12.1.5补丁中火焰法师的最佳天赋。我们还为各种内容（如团队副本或大秘境）提供了默认天赋构建。如果你开启了战争模式游玩，我们也为你准备了PvP天赋。

1.

### 至暗之夜 中 火焰 法师 的最佳天赋

对于第2赛季， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒看起来是在范围伤害和单体伤害场景中都是最强的英雄天赋树。它的伤害输出就是比
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火，没有任何缺点。

- **团队副本 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒明显领先于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火在团队副本中，无需为此牺牲任何机动性或重要的防御技能，使其成为首选。
- **大秘境 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒在大秘境场景中凭借更高的AOE伤害大幅领先，同时其单体伤害也高于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火.

由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒 simply does more DPS than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火 in all content without having to give up anything in return, there is no real reason to play a build other than 日怒, unless you greatly prefer ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火在视觉或主题上。

**快速开始导入代码：**

:::talents 火焰团队副本 - 日怒
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAAbmZMzAAgZMmZmZMzsMAMzAMGwMMGA"
}
```
:::

:::talents 火焰 大秘境 - 日怒
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAAAmZmmltlZAA2MzM2mZmZGbAAAAAYzMjZGAAMjxMzMjZmlBgZGMjxAmhxA"
}
```
:::

:::talents 火焰地下堡 - 日怒
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAAAmZmmltlZAA2MzM2mZmZGbAAAAAYzMjZGAAMjxMzMjZmlBgZGMjxAmhxA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

日怒

团本天赋

推荐

秘境+

每周大秘境钥匙

高层大秘境

地下堡与开放世界

霜火

团本天赋

秘境+

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒团队副本天赋

标准 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒火焰团队副本构筑。它不仅拥有最佳的单目标DPS，如果战斗需要，它还能在不进行任何更换的情况下进行AOE输出。

如果你需要驱散诅咒，你可以将[[spell:110959]]和[[spell:382293]]换成其他功能性节点，例如[[spell:475]]，或者如果需要，换成[[spell:1270865]]以获得更多打断。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒大秘境天赋

标准 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒 火焰 大秘境配装。它在AOE DPS和单体DPS方面都是最佳的，无需牺牲其中任何一方，使其成为任何大秘境内容的不二之选。

如果你在特定副本中不需要，可以随意替换掉任何功能型天赋，例如[[spell:475]]或[[spell:1270865]]。如果你需要更多移动速度，[[spell:110959]]换成[[spell:382293]]是一个不错的选择。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒地下堡天赋

这套构筑专注于使 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 尽可能流畅的体验。它专注于最大化你的生存和风筝能力，通过专精于更多的机动性和控制，同时只放弃极少的DPS。该配置也非常适合户外内容。

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火团队副本天赋

标准 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火 火焰 团本构建。这是一个非常灵活的团本构建，因为它同时适用于单体伤害和AoE伤害，无需更换天赋，使你能够使用单一构建应对所有首领，无论其目标数量如何。可惜的是，其伤害无法与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒.

如果你需要驱散诅咒，你可以将[[spell:110959]]和[[spell:382293]]换成其他功能性节点，例如[[spell:475]]，或者如果需要，换成[[spell:1270865]]以获得更多打断。

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火大秘境天赋

标准 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火 火焰 大秘境配装。在大秘境中表现出色，因为它在单体和AOE DPS方面都是最佳的 霜火 配装，两者都不妥协。遗憾的是它无法跟上 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒的数据。

如果你在特定的地下城中不需要像 [[spell:475]] 或 [[spell:1270865]] 这样的实用天赋，可以随意替换掉。如果你需要更多的移动速度，从 [[spell:110959]] 换到 [[spell:382293]] 会是不错的选择。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAAbmZMzAAgZMmZmZMzsMAMzAMGwMMGA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRx7DUo4QAJ5GEE-CdIBCw02MUWYs4KRoqu8ATSceimGKeA-AAAA-DQko0IUY4IDwwC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAAAmZmmltlZAA2MzM2mZmZGbAAAAAYzMjZGAAMjxMzMjZmlBgZGMjxAmhxA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFNhlxd0EVFJRx7DUo4QQJJJ-CdIBCw02MUWYs4KRoqu8ATSceimGKeA-AAAA-DQko0IUY4IDwwC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMzMAAAGAwMz0sssMDAwmZmx2YmZGLAAAAAYzMjZGAAMmhxMzMzsNAMzAMGDmhBA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFNhltxZkkEFAJRRz7DMQo4A-CdJBCw02MUWYs4KRouyy8ATScgiEHKC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAmZZGzMLzCAAAYxMDbzMzMjNAAAAAsZmxMDAAmZYmxMzMzCwMDIMGDmhxA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRx7DUo4QAJ5GEE-CdIBCw02MUWY4KRoquATScemKeklBJC-AAAA-SgEgZR4QhBAhyA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAMLzYmZZWAAAALmZYbmZmZsBAAAAgNzMmZAAwMDzMmZmZWAmZANjxYwMMGA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRBU4QAJ5Up5XhH-CdIBCw02MUWY4KRoquATScemKeklBJC-AAAA-SgEgZR4QhBAhyA-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并提供了一些轻微的性能增强自定义选项。其中一些加成会影响你的伤害输出，而另一些则更偏向防御性质。

你可以自由更换它们，不会受到任何惩罚，所以尽管按照自己的喜好进行尝试吧！以下是我列出的默认推荐：

- 要点 1：[[spell:1279596]]
- 第2点：组队时使用 [[spell:1279604]]，单人时使用 [[spell:1279603]]
- 要点3：[[spell:1287555]]
- 第4点：[[spell:1279610]]
- 第 5 点：[[spell:1279616]]

1.

### 巅峰天赋： ![Fired Up Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_incinerate.jpg>) 焚烧殆尽

火焰 拥有以下巅峰天赋：

- [[spell:1257343]]：消耗[[spell:195283]]时，有几率使你获得一层炽热涌动，提高你的火焰伤害。多层效果可以叠加。
- [[spell:1257349]]：获得炽热涌动时，每点使你的[[spell:319836]]冷却时间缩短2.5秒，共2点。
- [[spell:1257348]]：[[spell:190319]]大幅提高获得炽热涌动的几率，减少每次触发炽热涌动的层数。同时使炽热涌动将燃烧延长1秒。

火焰的顶点天赋为两个英雄专精都提供了大量伤害，几乎总是会被点出。Fired Up是一个新的触发效果，每当触发时会提供大量额外伤害，这是一个非常不错的被动加成。然而，更有影响力的是触发时带来的巨大的5秒[[spell:319836]]冷却时间缩短，这发生得相当频繁，尤其是在[[spell:190319]]期间。

这个 [[spell:319836]] 冷却缩减使得你在 [[spell:190319]] 期间几乎不会用完 火焰 冲击充能，通常只会在燃烧即将结束时才用完。这使得你可以在燃烧的几乎整个持续时间内将 [[spell:11366]] 链接到 火焰 冲击，而无需穿插任何其他法术。

所有这些额外的[[spell:319836]]充能确实导致了一种奇怪的奢侈“问题”，即它相对降低了[[spell:269650]]的价值，因为在[[spell:190319]]期间硬读[[spell:11366]]有超出火焰 Blast充能上限的风险，使得在燃烧期间很难硬读。因此，你通常最终不得不将硬读推迟到燃烧结束之后。

1.

### 火焰 法师 英雄天赋

火焰可以使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火英雄天赋树。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒在大多数情况下都更胜一筹，使其成为大多数内容的首选，因为它能在不牺牲实用性或生存能力等其他方面的情况下提供这额外的伤害输出。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒主要专注于加快你的输出循环，并在[[spell:190319]]期间召唤一只奥术凤凰伴随你，它会施放自己的法术提供伤害和一些辅助效果。从玩法上讲，日怒通过提供几个减少[[spell:319836]]冷却时间的来源或额外的急速来稍微加快你的输出循环，但主要的循环变化来自[[spell:449619]]，它会在燃烧结束时为你提供[[spell:383860]]。在过热高温激活期间，你可以连续使用瞬发的[[spell:11366]]或[[spell:2120]]，在燃烧结束后提供另一个类似燃烧的小型爆发。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火完全专注于通过发射一堆额外的冰霜法术来增强你的伤害，例如[[spell:199786]]和[[spell:153595]]。在游戏玩法上，霜火用[[spell:431044]]替换了你的[[spell:133]]，由于施法时间更短，这使你的输出循环稍微快一些，但除此之外的玩法与火球术相同。主要的输出循环变化来自[[spell:431176]]，它使你的下一个霜火之箭成为一个伤害很高的瞬发法术，并且还造成范围伤害。

1.

### PvP天赋（战争模式）

自争霸艾泽拉斯以来，可以启用“战争模式”。启用战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于开启战争模式在升级和PvE内容中的好处，建议开启该功能以最大化你的升级速度和满级后的奖励。然而，这样做会开启PvP战斗，在升级或进行世界任务时存在被对立阵营成员攻击的可能性。

在本章节中，我们将对战争模式天赋在升级和户外内容中的表现进行排名。

1. [[spell:390428]]为你提供显著的伤害增益。在开放世界内容中，降低的生命值通常不是问题。
2. [[spell:353082]]会放置一个相对较大的圆圈，烧灼走进圆圈外围的敌人，造成可观伤害。
3. [[spell:203286]]是一个伤害非常高的法术，尤其对高生命值敌人而言，它将大幅增加你对高生命值敌人（如世界首领或稀有怪）的伤害。
4.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 添加了关于万世卷册的部分。
- **2026年5月23日：** 根据5月26/27日的调整，略微更新了英雄天赋对比。
- **2026年4月24日：** 调整了一些功能性天赋，使其成为更常见的默认选择。
- **2026年4月21日：** 修正了一个小错误
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 更新了推荐天赋构筑以区分史诗钥石地下城每周低保与冲层，并根据调整改动更新了最佳构筑。
- **2026年2月27日：** 更新了霜火天赋，使其不使用灼烧，因为用灼烧代替霜火冲击会造成相当可观的DPS损失。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为12.0.1天赋树改动更新了天赋树。
- **2026年1月22日：** 根据最新的理论研究更新了日怒天赋树。
- **2026年1月21日：** 略微优化了日怒天赋树，并根据最新优化将推荐天赋树改为日怒。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月9日：** 略微更新了标准团队副本天赋中的防御天赋。
- **2025年8月4日：** 为11.2.0更新了所有天赋配置，并根据改动更新了推荐天赋。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 在最新的霜火加强后，将推荐的单体目标天赋更新为霜火。
- **2025年2月25日：** 新增了最佳霜火天赋。
- **2025 年 2 月 24 日：** 更新了11.1版本的最佳天赋：新的推荐天赋树设为日怒，并根据11.1的改动更新了最优天赋树。
- **2024年12月15日：** 更新了页面布局，将不同的AoE天赋分成了各自的章节，并添加了推荐标签，以便更快地发现最佳配置。
- **2024年11月26日：** 根据增益更新了最佳天赋：切换到以SKB为基础的霜火作为最佳构筑。也更新了AOE构筑。
- **2024年10月21日：** 根据11.0.5的改动更新了天赋。将AOE天赋拆分为3套不同的配装。
- **2024年10月2日：** 更新了烈焰风暴与灼烧的取舍选择，进一步强调烈焰风暴能带来更高的总DPS。
- **2024年9月24日：** 由于最新的增强使得烈焰冲击更加可行，现已添加基于烈焰冲击的AOE配装
- **2024年9月14日：** 更新了大秘境天赋，用强化灼烧替代灼烧以在不牺牲任何有意义的范围伤害的情况下获得更多首领伤害，并将火焰之怒替换为熔岩狂怒，适用于所有构筑，因为在大多数场景下伤害略高。
- **2024年9月9日：** 移除了赛季前天赋，并更新了AOE天赋，不再花费2点在仅增加0.1% DPS却以单体DPS为代价的AOE天赋上。
- **2024年8月29日：** 更新了AOE配装的说明，使其更清晰。
- **2024年8月28日：** 修正了一个错别字。
- **2024年8月24日：** 添加了地下堡天赋树。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 根据第4赛季的套装改动更新了最佳天赋。
- **2024年3月19日：** 已针对10.2.6补丁进行更新，将火焰加速器设为默认节点，取代了阿莱克丝塔萨的狂怒
- **2024年3月9日：** 略微更新了推荐的烈焰风暴天赋，并添加了更多关于在点燃与烈焰风暴流派之间选择的信息。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月19日：** 更新天赋树，默认选择Alexstrasza的狂怒，因为发现了优化点。
- **2023年11月6日：** 由于10.2的改动，更新了推荐天赋。
- **2023年9月4日：** 更改了天赋布局，使其更易于浏览。
- **2023年7月14日：** 添加了活体炸弹不应在单目标上使用的声明。
- **2023年7月10日：** 在火焰重做后，为10.1.5版本更新了推荐天赋。
- **2023年5月3日：** 添加了关于推荐天赋基于拥有2件套和4件套的说明。
- **2023年5月1日：** 根据10.1的改动更新了推荐天赋，并清理了一些建议。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年2月16日：** 移除了旧备注。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 将天赋建议拆分为暗夜精灵和非暗夜精灵部分。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面，你将学习如何在单目标和多目标情况下优化你的火焰法师的输出循环。我们还提供了关于冷却技能、触发效果等方面的进阶章节，以最大化你的DPS。我们的所有内容均针对《魔兽世界》12.1.5补丁进行了更新。

1.

### 火焰法师玩法与循环指南

欢迎来到我们的火焰法师循环页面。在这个页面上，你将找到关于在团队副本和大秘境场景中实际游玩该专精所需了解的一切信息。

<em>注意：目前无论选择哪种英雄天赋预设，单体目标和AoE所选择的天赋都没有差异。
</em>

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

单体目标

群体伤害

主动天赋

被动天赋

[[spell:153561]]

[[spell:2948]]

[[spell:205026]]

[[spell:416719]]

[[spell:269650]]

[[spell:416094]]

[[spell:457735]]

[[spell:1271177]]

### 单体输出循环

1.1.

#### 单体目标循环

火焰 输出循环遵循优先级系统。下面我们列出这个优先级系统。你应该从上到下阅读，然后执行第一个满足所有条件的操作。

火焰的输出循环有两个明显的阶段：一个[[spell:190319]]阶段，你会连续打出大量暴击以获得极高的爆发DPS；以及一个非燃烧阶段，其DPS显著降低，但能让你过渡到下一个阶段。

**适用条件：日怒（启用）；Scorch（未启用）。** <em>注意：使用一个 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 不点 [[spell:2948]] 的 日怒 构建只有在你对战斗非常熟悉，并且预计因移动损失的输出非常有限时才推荐。在几乎所有情况下，我都强烈建议点出灼烧。</em>

**适用条件：霜火（启用）；Scorch（启用）。** <em>注意：[[spell:2948]]在几乎所有情况下都比施放[[spell:431044]]更差，即使目标生命值低于30%，所以它纯粹被当作位移工具使用，因为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火.</em>

1.2.

#### 燃烧优先级列表

[[spell:190319]]是一个强大的冷却技能，它使你的所有法术必定暴击。目标是尽可能接近冷却完毕就使用它，同时确保与其他任何增加伤害的冷却技能一起使用，比如饰品和种族技能。

由于所有法术必定暴击，你将循环使用瞬发的[[spell:11366]]和热力迸发的生成技能，例如[[spell:319836]]。

1. **适用条件：Meteor（启用）；Burnout（未启用）。** 在[[spell:190319]]期间的任意时刻施放[[spell:153561]]，并确保它在燃烧结束前落地。
2. **适用条件：Meteor（启用）；Burnout（启用）。** 在 [[spell:190319]] 的最后8秒内的任何时间点施放 [[spell:153561]]，但要确保它在燃烧结束前落地。在实践中，这意味着在燃烧剩余2到8秒之间的任何时间点施放它。
3. 当你拥有[[spell:195283]]时，施放[[spell:11366]]。
4. **适用条件：Pyroclasm（启用）。** 当你拥有[[spell:269650]]且[[spell:190319]]剩余至少3秒时，硬读施放[[spell:11366]]。如果你的[[spell:319836]]层数已满或接近满，即使会失去炎爆术触发效果，也不要硬读施放炎爆术。确保火焰冲击层数不溢出，比失去炎爆术触发效果更重要。
5. **适用条件：Heat Shimmer（启用）。** 当你有[[spell:457735]]且没有[[spell:195283]]时，施放[[spell:2948]]。
6. 施放 [[spell:319836]] 将 [[spell:48107]] 转化为 [[spell:195283]]。
7. **适用条件：霜火（启用）。** 施放[[spell:431044]]以在没有[[spell:319836]]时生成[[spell:195283]] / [[spell:48107]]。
8. **适用条件：灼烧（启用）；日怒（启用）。** 在没有[[spell:319836]]时，施放[[spell:2948]]来产生[[spell:195283]] / [[spell:48107]]。
9. **适用条件：日怒（启用）；Scorch（未启用）。** 使用[[spell:133]]作为填充技能。

**适用条件：日怒（启用）。**

在

[[spell:190319]]

结束时，你将获得

[[spell:383860]]

.

:::details 在[[spell:383860]]激活期间，施放[[spell:11366]]。- <em>点击获取进阶技巧</em>
在高热期间，如果你拥有

[[spell:48107]]

，用它来转换

[[spell:319836]]

变成

[[spell:195283]]

。虽然过热保证暴击，但你仍然需要通过火焰冲击将炽热转化为热力迸发，因为热力迸发能大幅提升

[[spell:12846]]

由炎爆术施加。

:::

请看下面的序列，作为[[spell:190319]]循环的示例。注意：[[spell:1257349]]会影响你能坚持使用[[spell:319836]]作为[[spell:195283]]/[[spell:48107]]生成器的时间长短，这极大地影响了实际战斗中序列的具体形态：

**适用条件：日怒（启用）。**

[[spell:11366]]

[[spell:190319]]

[[spell:319836]]

[[spell:11366]]

[[spell:108853]]

[[spell:11366]]

[[spell:319836]]

[[spell:11366]]

[[spell:153561]]

[[spell:2948]]

[[spell:11366]]

[[spell:319836]]

[[spell:11366]]

[[spell:11366]]

[[spell:383860]]

[[spell:11366]]

**适用条件：霜火（启用）。**

[[spell:11366]]

[[spell:190319]]

[[spell:319836]]

[[spell:11366]]

[[spell:108853]]

[[spell:11366]]

[[spell:319836]]

[[spell:11366]]

[[spell:153561]]

[[spell:319836]]

[[spell:11366]]

[[spell:431044]]

[[spell:431044]]

[[spell:11366]]

[[spell:11366]]

1.3.

#### 优先级列表（燃烧之外）

1. **适用条件：Firestarter（启用）。** 当你使用[[spell:205026]]时，将你的第一个[[spell:190319]]延迟到目标生命值低于90%时使用。
2. 冷却就绪时施放 [[spell:190319]]，然后进入上面的燃烧优先级列表。在读条法术即将结束时施放燃烧。-  <em>点击查看硬读条优先级</em>
   
   
   
   
   - **适用条件：Pyroclasm（启用）。** [[spell:11366]]配合[[spell:269650]]
   - **适用条件：灼烧（启用）。** [[spell:2948]]（当目标生命值低于30%时）
   - **适用条件：霜火（未启用）。** [[spell:133]]
   - **适用条件：霜火（启用）。** [[spell:431044]]
3. **适用条件：Meteor（启用）；Blast Zone（启用）。** 一旦可用立即施放[[spell:153561]]。如果你不得不延迟超过10秒，则跳过这次使用，并将流星留给燃烧。
4. **适用条件：霜火（启用）。** 当你拥有[[spell:195283]]时施放[[spell:11366]]。在非瞬发的[[spell:431044]]之后施放它，以便它们同时命中。参见 [炎爆术衔接章节](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities#pyrochaining>) 了解具体原因。
5. **适用条件：日怒（启用）；Scorch（未启用）。** 当你有[[spell:195283]]时施放[[spell:11366]]。在施放完一个[[spell:133]]之后施放它，这样它们会同时命中。参见 [炎爆术衔接章节](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities#pyrochaining>) 了解具体原因。
6. **适用条件：灼烧（启用）；日怒（启用）。** 当你拥有[[spell:195283]]时施放[[spell:11366]]。在一次[[spell:133]]（或斩杀阶段的[[spell:2948]]）施放后立即施放，使两者同时命中。参见 [炎爆术衔接章节](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities#pyrochaining>) 了解具体原因。
7. **适用条件：Pyroclasm（启用）。** 当[[spell:269650]]触发时，读条施放[[spell:11366]]。
8. **适用条件：Heat Shimmer（启用）；日怒（启用）。** 如果你触发了[[spell:457735]]，且当前没有[[spell:195283]]，则施放[[spell:2948]]。
9. 施放 [[spell:319836]] 将 [[spell:48107]] 转化为 [[spell:195283]]。
10. **适用条件：灼烧（启用）；日怒（启用）。** 当目标生命值低于 30% 时，使用 [[spell:2948]] 作为填充技能来生成 [[spell:195283]] / [[spell:48107]]。
11. **适用条件：霜火（启用）。** 使用[[spell:431044]]作为填充技能来产生[[spell:195283]] / [[spell:48107]]。
12. **适用条件：日怒（启用）。** 施放[[spell:133]]作为填充技能来产生[[spell:195283]]/[[spell:48107]]。
13. **适用条件：霜火（启用）；Scorch（启用）。** 在移动中无法施放[[spell:431044]]时，使用[[spell:2948]]作为填充法术。

### AOE循环

1.4.

#### AoE循环

火焰范围输出循环遵循优先级系统。下面列出了这个优先级系统。你应该从上到下阅读，然后执行第一个所有条件都满足的动作。

火焰的输出循环有两个明显的阶段：一个[[spell:190319]]阶段，你会连续打出大量暴击以获得极高的爆发DPS；以及一个非燃烧阶段，其DPS显著降低，但能让你过渡到下一个阶段。

在AoE场景中，输出循环大体相同，但有一个非常关键的区别：你施放[[spell:2120]]而不是[[spell:11366]]。

1.5.

#### 用烈焰风暴替换炎爆术的目标数量

**适用条件：Fuel the 火焰（未启用）。** 注意：你应该始终点出[[spell:416094]]，以使施放[[spell:2120]]变得值得。

**适用条件：霜火（启用）。** 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火中，你只在特定目标数量下将[[spell:11366]]替换为[[spell:2120]]：

**适用条件：日怒（启用）。** 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 对于日怒，你只在特定的目标数量下才用[[spell:2120]]替换[[spell:11366]]：

1. 如果你想最大化对某个高优先级目标的伤害，无论目标数量多少，你都应该坚持使用[[spell:11366]]而不是[[spell:2120]]。
2. **适用条件：Firestarter（启用）。** 当目标生命值高于90%且点了[[spell:205026]]时：绝不要使用[[spell:2120]]
3. **适用条件：日怒（启用）。** [[spell:190319]]期间及非期间：4个或更多目标
4. **适用条件：霜火（启用）。** [[spell:190319]]期间及非期间：4个或更多目标
5. **适用条件：霜火（未启用）。** 只替换[[spell:11366]]，绝不要用[[spell:2120]]替换[[spell:133]]的施法！
6. **适用条件：霜火（启用）。** 只替换 [[spell:11366]]，绝不要用 [[spell:2120]] 替换 [[spell:431044]] 的施放！

这导致了以下完整的优先级列表：

1.6.

#### 燃烧优先级列表

[[spell:190319]]是一个强大的冷却技能，它使你的所有法术必定暴击。目标是尽可能接近冷却完毕就使用它，同时确保与其他任何增加伤害的冷却技能一起使用，比如饰品和种族技能。

由于所有法术都是必定暴击的，你将循环使用瞬发的 [[spell:2120]] 和热力迸发积攒技能，如 [[spell:319836]]。

1. **适用条件：Meteor（启用）；Burnout（启用）。** 在 [[spell:190319]] 的最后8秒内的任何时间点施放 [[spell:153561]]，但要确保它在燃烧结束前落地。在实践中，这意味着在燃烧剩余2到8秒之间的任何时间点施放它。
2. **适用条件：Meteor（启用）；Burnout（未启用）。** 在[[spell:190319]]期间的任意时刻施放[[spell:153561]]，并确保它在燃烧结束前落地。
3. 当你拥有 [[spell:195283]] 时施放 [[spell:2120]]。
4. **适用条件：Pyroclasm（启用）。** 当你拥有[[spell:269650]]且[[spell:190319]]至少还有3秒时，硬读施放[[spell:2120]]。如果你的[[spell:319836]]层数已满或接近满，即使会失去Pyroclasm的触发，也不要硬读施放烈焰风暴。避免溢出火焰冲击的层数比失去Pyroclasm的触发更重要。
5. **适用条件：Heat Shimmer（启用）。** 当你有[[spell:457735]]且没有[[spell:195283]]时，施放[[spell:2948]]。
6. 施放 [[spell:319836]] 将 [[spell:48107]] 转化为 [[spell:195283]]。
7. **适用条件：灼烧（启用）；日怒（启用）。** 使用 [[spell:2948]] 作为填充技能来生成 [[spell:195283]] / [[spell:48107]]。
8. **适用条件：霜火（启用）。** 在没有[[spell:319836]]时，施放[[spell:431044]]作为填充技能来产生[[spell:195283]]/[[spell:48107]]。
9. **适用条件：日怒（启用）；Scorch（未启用）。** 在没有[[spell:319836]]时，使用[[spell:133]]作为填充技能来产生[[spell:195283]] / [[spell:48107]]。

**适用条件：日怒（启用）。**

在

[[spell:190319]]

结束时，你将获得

[[spell:383860]]

.

:::details 在[[spell:383860]]激活期间，施放[[spell:2120]]。 - <em>点击获取进阶技巧</em>
在高热期间，如果你拥有

[[spell:48107]]

，用它来转换

[[spell:319836]]

变成

[[spell:195283]]

。虽然过热保证暴击，但你仍然需要通过火焰冲击将炽热转化为热力迸发，因为热力迸发能大幅提升

[[spell:12846]]

由烈焰风暴施加。

:::

请看下面的序列，作为[[spell:190319]]循环的示例。注意：[[spell:1257349]]会影响你能坚持使用[[spell:319836]]作为[[spell:195283]]/[[spell:48107]]生成器的时间长短，这极大地影响了实际战斗中序列的具体形态：

**适用条件：日怒（启用）。**

[[spell:2120]]

[[spell:190319]]

[[spell:319836]]

[[spell:2120]]

[[spell:108853]]

[[spell:2120]]

[[spell:319836]]

[[spell:2120]]

[[spell:153561]]

[[spell:2948]]

[[spell:2120]]

[[spell:319836]]

[[spell:2120]]

[[spell:2120]]

[[spell:383860]]

[[spell:2120]]

[[spell:2120]]

[[spell:2120]]

[[spell:2120]]

**适用条件：霜火（启用）。**

[[spell:11366]]

[[spell:190319]]

[[spell:319836]]

[[spell:11366]]

[[spell:108853]]

[[spell:11366]]

[[spell:319836]]

[[spell:11366]]

[[spell:153561]]

[[spell:319836]]

[[spell:11366]]

[[spell:431044]]

[[spell:431044]]

[[spell:11366]]

[[spell:11366]]

1.7.

#### 优先级列表（燃烧之外）

1. **适用条件：Firestarter（启用）。** 当你使用 [[spell:205026]] 时，将你的第一个 [[spell:190319]] 延迟到目标生命值低于 90% 时使用。另外，当目标生命值高于 90% 时，绝对不要施放 [[spell:2120]]。
2. 冷却就绪时施放 [[spell:190319]]，然后进入上面的燃烧优先级列表。在读条法术即将结束时施放燃烧。-  <em>点击查看硬读条优先级</em>
   
   
   
   
   - **适用条件：Pyroclasm（启用）。** 用[[spell:269650]]施放[[spell:2120]]
   - **适用条件：灼烧（启用）。** [[spell:2948]]（当目标生命值低于30%时）
   - **适用条件：霜火（未启用）。** [[spell:133]]
   - **适用条件：霜火（启用）。** [[spell:431044]]
3. **适用条件：Meteor（启用）；Blast Zone（启用）。** 一旦可用立即施放[[spell:153561]]。如果你不得不延迟超过10秒，则跳过这次使用，并将流星留给燃烧。
4. 当你拥有 [[spell:195283]] 时施放 [[spell:2120]]。
5. **适用条件：Pyroclasm（启用）。** 当[[spell:269650]]触发时，硬读条施放[[spell:2120]]。
6. **适用条件：Scorch（启用）；Heat Shimmer（启用）。** 如果你触发了[[spell:457735]]，且当前没有[[spell:195283]]，则施放[[spell:2948]]。
7. 施放 [[spell:319836]] 将 [[spell:48107]] 转化为 [[spell:195283]]。
8. **适用条件：灼烧（启用）；日怒（启用）。** 当目标生命值低于 30% 时，使用 [[spell:2948]] 作为填充技能来生成 [[spell:195283]] / [[spell:48107]]。
9. **适用条件：霜火（启用）。** 使用[[spell:431044]]作为填充技能来产生[[spell:195283]] / [[spell:48107]]。
10. **适用条件：日怒（启用）。** 施放[[spell:133]]作为填充技能来产生[[spell:195283]]/[[spell:48107]]。

:::details 常见问题：我应该使用定点的[[spell:2120]]还是区域指向的烈焰风暴？
对大多数玩家来说，自动选中目标的选项将是最佳选择。它释放了你的鼠标和注意力，让你能专注于游戏的其他部分。然而，由于它是以你正在攻击的怪物为中心的，你会发现有些情况下它会漏掉怪物群中的一些怪物。通过练习，你应该能够使用区域选中（通过下面的@cursor宏）版本多挤出一点伤害输出。两种都试试，看你更喜欢哪种。

:::

这个宏会在你的光标位置施放 [[spell:2120]]，而无需先显示一个目标选择圈。这仅在你选择了手动施放烈焰风暴天赋（而非指定目标的烈焰风暴天赋）时有效。

#### 光标火焰冲击

```wow-macro
#showtooltip 烈焰风暴
/cast [@cursor] 烈焰风暴;
```

1.

### 至暗之夜 第2赛季套装

第2赛季套装完全围绕[[spell:269650]]展开。2件套效果使[[spell:11366]]和[[spell:2120]]必定暴击，使得在燃烧之外消耗火焰冲撞触发效果变得更有价值；而4件套效果则进一步提高火焰冲撞的伤害加成，并缩短炎爆术和烈焰风暴的硬读条施法时间，使消耗触发效果变得更加容易和迅速。

我们第2赛季的套装为：

- [[spell:1296583]]：[[spell:269650]]使[[spell:11366]]和[[spell:2120]]必定暴击。
- [[spell:1296584]]：[[spell:269650]]使[[spell:11366]]和[[spell:2120]]的施法时间缩短20%，并使炽热涌动的伤害加成提高20%。

1.

### 职业与专精机制详解

为了更好地解释火焰法师技能机制的具体用法和优势，我们编写了一份关于输出循环各个部分的详细说明，从你需要注意的重要循环机制，到冷却技能及其使用方法，以便你在游玩火焰法师时能够发挥出全部潜力。

### 高效连环暴击

3.1.

#### 高效连环暴击

尽可能高效地制造暴击对于掌握火焰专精至关重要。这个专精的设计就是以暴击为主，因此不难理解为什么学会打出正确的连招以形成暴击链是重中之重。

每当你触发[[spell:48107]]时，你应该使用[[spell:319836]]将其转化为[[spell:195283]]。通常情况下，你会想要施放一个[[spell:133]]，并在你的火球术施法结束时立即将你的炽热连击用于[[spell:11366]]。这两个法术将同时命中，如果两者都暴击，就有机会立即获得后续的炽热连击。如果只有一个法术暴击，热力迸发会触发，你可以立即火焰冲击并重复此过程。

有一个0.2秒的宽限期，如果两个法术同时命中且只有一个暴击，[[spell:48107]]不会被取消。这个宽限窗口就是为什么始终将火球术接炎爆术施放如此关键，因为通常情况下，如果只有一个暴击而另一个没有，你将失去热力迸发。但如果你同时施放两个，如果只有一个暴击，你就能保留你的热力迸发。

这被称为“炎爆钓鱼”或“炎爆连招”，是制造大型暴击链的最佳方式。此规则的例外是在[[spell:190319]]期间，所有法术都会暴击，让你能够连出各种连招，这些连招在上面的输出循环部分有更详细的介绍。

### 燃尽

3.2.

#### 燃尽

[[spell:1271177]]是一个基石天赋，当[[spell:190319]]结束时，会使你所有激活的[[spell:12846]]爆炸，造成其剩余伤害的75%。这种爆炸纯粹是额外伤害，它不会移除你现有的任何点燃效果。

燃尽极大地增加了你的爆发伤害，尤其是对于存活时间短的敌人，因为它让你即使在敌人没有存活到点燃完整持续时间的情况下，仍然能从点燃中获得大量收益。

由于点燃有10秒的持续时间，并且有一些关于如何刷新的复杂规则，我们想要做的是确保在燃烧结束时，我们拥有尽可能高的点燃伤害，因为它会取用燃烧结束时你活跃的点燃并将其引爆，而不是燃烧期间施加的所有点燃伤害。

实际的游戏影响非常小：在[[spell:190319]]期间，你将[[spell:153561]]延迟到燃烧剩余8秒或更少时施放。其他一切都会自然地调整，使得你的[[spell:12846]]在燃烧结束时会非常大，而无需做出任何循环上的改变。

### 顶点天赋

3.3.

#### 火焰 法师的巅峰天赋

火焰 拥有以下巅峰天赋：

- [[spell:1257343]]：消耗[[spell:195283]]时，有几率使你获得一层炽热涌动，提高你的火焰伤害。多层效果可以叠加。
- [[spell:1257349]]：获得炽热涌动时，每点使你的[[spell:319836]]冷却时间缩短2.5秒，共2点。
- [[spell:1257348]]：[[spell:190319]]大幅提高获得炽热涌动的几率，减少每次触发炽热涌动的层数。同时使炽热涌动将燃烧延长1秒。

火焰的顶点天赋为两个英雄专精都提供了大量伤害，几乎总是会被点出。Fired Up是一个新的触发效果，每当触发时会提供大量额外伤害，这是一个非常不错的被动加成。然而，更有影响力的是触发时带来的巨大的5秒[[spell:319836]]冷却时间缩短，这发生得相当频繁，尤其是在[[spell:190319]]期间。

这个 [[spell:319836]] 冷却缩减使得你在 [[spell:190319]] 期间几乎不会用完 火焰 冲击充能，通常只会在燃烧即将结束时才用完。这使得你可以在燃烧的几乎整个持续时间内将 [[spell:11366]] 链接到 火焰 冲击，而无需穿插任何其他法术。

所有这些额外的[[spell:319836]]充能确实导致了一种奇怪的奢侈“问题”，即它相对降低了[[spell:269650]]的价值，因为在[[spell:190319]]期间硬读[[spell:11366]]有超出火焰 Blast充能上限的风险，使得在燃烧期间很难硬读。因此，你通常最终不得不将硬读推迟到燃烧结束之后。

### 炽热之核的使用

3.4.

#### 炽热之核的使用

[[spell:269650]] 是一个关键触发效果。当它触发时，你的下一个非瞬发的 [[spell:11366]] 或 [[spell:2120]] 将造成大幅提高的伤害。配合第2赛季2件套，它们还必定暴击。乍一看，这是一个非常简单的触发：你只需硬读炎爆术，它就会造成显著更高的伤害。然而，我们可以做一些小细节来挤出额外的DPS。

由于2件套奖励必定暴击，而且你在[[spell:190319]]期间通常有很多[[spell:319836]]层数，所以一般要确保在进入燃烧时没有任何[[spell:269650]]触发效果处于激活状态。这意味着你要确保在进入燃烧之前消耗掉所有触发效果。

然而，这并不意味着你完全忽略燃烧期间的触发。如果它在燃烧期间本身触发，你确实想要使用它，只要不超过 [[spell:319836]] 充能上限。

在实践中，这很容易应对：

- 在[[spell:190319]]之外：当[[spell:269650]]触发时，立即硬读[[spell:11366]] / [[spell:2120]]。
- 如果[[spell:190319]]已就绪，并且你触发了[[spell:269650]]：硬读条施放[[spell:11366]] / [[spell:2120]]，然后在读条结束时立即使用燃烧。
- 在[[spell:190319]]期间：仅当你拥有1层或0层[[spell:319836]]充能时才消耗[[spell:269650]]触发，以避免层数溢出。

1.

### 火焰法师的重要冷却技能

### 燃烧

4.1.

#### 燃烧

[[spell:190319]]是火焰的主要DPS冷却技能，在点出[[spell:155148]]后每分钟可用一次。它保证你的所有法术必定暴击，并根据天赋提供各种其他增益，如额外精通或直接更多伤害。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒，它还会在燃烧期间为你提供一个 奥术 凤凰，并在燃烧结束后提供各种其他好处。

由于火焰完全依赖于暴击来产生[[spell:195283]]，这显然是一个巨大的伤害增益，并且在燃烧激活期间会让你的循环节奏非常快。

通常，你会希望在燃烧可用时立即使用，但在某些情况下延迟使用可能更有利，例如你的团队即将使用[[spell:80353]]或类似效果，或者一个需要高DPS的重要团队机制即将到来，或者出现额外目标等。然而，由于燃烧只有1分钟的冷却时间，延迟使用通常不是个好主意，因为如果你延迟太久，很可能会损失一次额外的使用机会。

### 流星

4.2.

#### 流星

[[spell:153561]]在点出[[spell:416719]]天赋后是一个30秒冷却时间的技能，伤害很高，并根据天赋和英雄天赋激活各种其他增益效果，例如触发[[spell:431176]]
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 作为霜火，或提供[[spell:269650]]作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒.

陨石和[[spell:190319]]的时机非常紧凑，因为陨石有30秒冷却时间而燃烧有一分钟，这意味着你可以在两次燃烧使用之间恰好施放一次陨石。由于时机如此接近，你必须在陨石冷却完毕后立即使用，以确保你不需要跳过一次使用或延迟燃烧，这两种情况都很糟糕。

如果不点出 [[spell:416719]]，[[spell:153561]] 的时机安排会变得简单得多，因为你无法再在 [[spell:190319]] 之间插入任何额外的流星，所以你只需在燃烧期间使用它，而在燃烧之外完全不使用它。

### 时间扭曲

4.3.

#### 时间扭曲

[[spell:80353]]是一项能为100码范围内的整个小队或团队提供30%急速、持续40秒增益的技能。该增益与[[spell:2825]]和[[spell:32182]]等多个其他法术共享。这些法术都会在所有团队成员身上施加一个减益效果，使其在10分钟内无法再次获得该效果，因此你无法从多个来源多次获得相同的增益。

由于时间扭曲作用于整个团队，通常由团队或小队领袖决定何时使用，以优化整个团队的使用效果，而不是只在对你个人使用最佳时才使用。然而，如果没有指定时间，或者你所在的野团在战术方面没有真正的领导，通常的安全做法是在战斗开始后立即使用时间扭曲，这样在所有人都准备好所有输出冷却技能时它就已生效。当然，请确保只有在开怪后的整个40秒增益持续时间内敌人都保持活跃时才这样做，因为在某些战斗中，首领可能会在战斗早期进入非活动状态或进行某种阶段转换。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月22日：** 略微更新了流星的使用方式，并移除了霜火不使用炎爆术的循环，因为其DPS收益极小甚至没有。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 新增了第一赛季开始时的套装章节，并新增了烈焰风暴使用方法和烈焰风暴宏的常见问题解答。同时将霜火设为默认循环，并因调整改动为霜火新增了不使用炎爆术的循环。
- **2026年3月2日：** 更新了烈焰风暴的目标数量说明，提供更多背景信息。
- **2026年2月27日：** 更新了霜火循环，提供更多关于灼烧的背景信息。
- **2026年2月26日：** 根据最新的计算更新了烈焰风暴的AOE循环阈值。
- **2026年2月10日：** 根据最新的最佳天赋更新了默认选择的天赋，并更新了循环以改进烈焰风暴的使用。
- **2026年1月21日：** 根据最新发现将默认循环复选框更新为设置为 日怒，并为两个英雄专精都添加了AOE和单体的完整配装。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 根据11.2版本的改动，更新了单体和AoE的最优输出循环，并添加了套装循环改动章节。
- **2025年6月17日：** 根据最新更新的数据，更新了战斗助手的伤害增益/损失。
- **2025年6月15日：** 添加了战斗助手信息和提示。
- **2025年4月21日：** 将默认单体循环更新为霜火。
- **2025 年 2 月 24 日：** 为11.1的更改进行了更新：新的默认配置设置为日怒，由于更改更新了新的最佳循环，添加了一个不太复杂的基础循环。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年11月26日：** 更新循环，将 霜火 作为默认选择，因为增强后它现在优于 日怒。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月24日：** 更新了AoE输出循环，加入了基于烈焰风暴的循环，因为最近的增益使它变得更加可行。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月28日：** 修复了一个错别字。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月10日：** 更新了单独的套装部分，以指向正确的套装。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 根据第4赛季的新套装更新了输出循环。
- **2024年3月23日：** 将燃烧循环拆分为两个独立部分，一部分是进入燃烧，一部分是燃烧期间，以提高可读性。此外还简化了起手描述。
- **2024年3月19日：** 已针对10.2.6版本更新，将火焰加速器添加为默认勾选的循环复选框，并添加了在燃烧期间使用火球术的行。同时清理了一些拼写错误。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月19日：** 由于发现的优化，更新了复选框以默认启用奥妮克希亚的 狂怒，使 AF 成为默认天赋树的一部分。
- **2023年11月6日：** 更新了10.2版本中新的最佳天赋方案和新套装的循环。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月15日：** 由于炎爆术的削弱，更新了 AOE 炎爆术循环。
- **2023年7月14日：** 根据最新的优化更新了AOE烈焰风暴循环。
- **2023年7月10日：** 更新了10.1.5版本火焰法师重做的循环。
- **2023年5月1日：** 根据新的套装效果和新的最优天赋更新了输出循环。
- **2023年3月20日：** 重写了输出循环的部分内容，使其更易于理解，并将灼烧之魂/炎爆术独立成一个章节。为10.0.7补丁进行了审查。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月3日：** 将变换了力量加入输出循环。
- **2022年12月11日：** 更新范围伤害循环，更清晰地解释当你没有点出烈焰打击/焰道时的范围伤害循环。
- **2022年12月11日：** 添加了解释因套装而导致的输出循环变化的章节。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页，你将找到魔兽世界12.1.5中你的火焰 法师的最佳装备、饰品和毕业装备推荐。从制造装备到如何使用你的纹章升级装备的建议，我们一应俱全！

1.

### 火焰 法师毕业装备指南

欢迎来到我们的火焰 法师装备页面。本节将涵盖正确装备角色所需了解的一切。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含来自所有渠道的 法师 火焰 最高 DPS 配置。对于单个部位，往往有多件物品的 DPS 非常接近甚至完全相同，尤其是当你只是在不同部位之间调整副属性时。因此，你应将下面的列表仅作为一套毕业装备大致样貌的参考，而不要据此立即做出装备选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

<em>在几个部位中，我列出了来自大秘境的物品，这些物品只能从 [大宝库](<https://www.icy-veins.com/wow/great-vault-guide>)。通常这些物品只有在史诗难度掉落等级下才是最佳选择，而不是在英雄难度掉落等级的变体中。如果你无法获得史诗难度掉落等级的物品，通常使用物品等级更高的装备比最佳选择的装备更好。</em>

:::details 常见问题我需要哪些套装部件？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

会保留物品的物品等级、属性和任何特殊奖励，因此你催化5个部位中的哪4个并不重要。从下方列出的5个部位中，任选你已经拥有的4个：

- 头部 — [[item:271874]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 护肩——来自的[[item:268241]] [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- 胸部 — 来自[[item:273785]] [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 手部 — 来自[[item:268243]] [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿部 — [[item:268236]]，来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)

注意：无论用什么方式获得 4 件套都比在正确的（催化出来的）部位上获得要重要得多，所以永远优先考虑获得 4 件套而不是正确的部位。

:::

:::details 常见问题我应该从大宝库中选择哪些物品？
通常，你应该通过模拟来专注于选择对你提升最大的装备。

[最佳装备](<https://www.raidbots.com/simbot/topgear>)

。不过，总体上也有一些物品非常有价值，如果你看到它们，几乎总是值得拾取的：

- [[item:271092]]：大幅领先的毕业武器，极其稀有且所有施法者都想要，所以如果它出现在你的英雄难度或史诗难度大秘境奖励库中，请务必拾取。
- 以下列出的任何9/6神话轨迹装备：它们对于火焰法师以及通常所有其他布甲职业来说都是毕业装备，因此非常难以通过其他方式获得。
- [[item:273796]]：毕业饰品，仅能从宏伟宝库中以史诗难度掉落获取。

:::

:::details 常见问题：为什么没有Kith'ix的装备？
基斯希克斯的装备及其咒语不如来自尤拉特克和盘绕祭坛的其他咒语物品强大，而且这些物品上较差的属性使它们比下面列出的最佳装备选择略逊一筹。不过，差距非常小，所以根据你自己的装备情况，它们也可能是升级！为了确定，你应该自己对它们进行模拟。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271565@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240893]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271563@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273796@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240916]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAMAAwt1ENMMYzy1glIcYD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含使用可刷取装备的最高DPS配置 **来自** 第2赛季史诗钥石地下城。这包括套装部件和2件美化物品，因为它们很重要，尽管它们在技术上并非来自史诗钥石地下城，因为它们可以通过 [大宝库](<https://www.icy-veins.com/wow/great-vault-guide>) / [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) / 制造。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

会保留物品的物品等级、属性和任何特殊奖励，因此你催化5个部位中的哪4个并不重要。从下方列出的5个部位中，任选你已经拥有的4个：

- 头部 — 来自的[[item:251232]] [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 肩部 — 来自[[item:239045]] [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 胸部——来自的[[item:251147]] [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 手套 — 来自的[[item:251129]] [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 腿部 — 来自[[item:193750@JAAIAAQkCYHKvbRLfA]] [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)

注意：无论用什么方式获得 4 件套都比在正确的（催化出来的）部位上获得要重要得多，所以永远优先考虑获得 4 件套而不是正确的部位。

:::

:::details 提示我应该刷哪些地下城？
有几个特别出色的地下城，因为其中有特定物品掉落，使得它们成为非常值得刷的地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：掉落最佳的使用型饰品（[[item:273796@JAACAAgNyA]]），以及非团队副本最佳武器。
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：掉落强力的颈部、手部和脚部装备，甚至还会掉落一些相当不错的饰品，使其成为一个掉落有用物品概率非常高的地下城。
- [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：掉落两件非常强力的被动饰品，包括最佳的非团队副本饰品，同时还掉落一件出色的披风和多件其他有用装备。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271564@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271565@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAAEAAgNygjM]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:239649@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>护肩</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271563@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:251137@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273796@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240916]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:250214@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAAEAAgNygjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:159667@JAAEAAgNygjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含最高DPS配置，仅使用 **来自** 剧毒深渊团队副本。这包括2件美化装备，因为它们很重要。

此列表绝不能替代 **模拟你自己**。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

会保留物品的物品等级、属性和任何特殊加成，所以你催化5个栏位中的哪4个并不重要。在团队副本中，唯一可获得的胸甲是

[[item:271567@JAACAAgNyA]]

（来自

[Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)

），它是一件套装物品，所以你总是会选择那一件。然后，从下面列表中你可选的4件物品中任选3件进行转化：

- 头部 — [[item:271874]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 护肩——来自的[[item:268241]] [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- 手部 — 来自[[item:268243]] [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿部 — [[item:268236]]，来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)

注意：无论用什么方式获得 4 件套都比在正确的（催化出来的）部位上获得要重要得多，所以永远优先考虑获得 4 件套而不是正确的部位。

:::

:::details 提示哪些团队副本装备最重要？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:271092@JAACAAAG2A]]：凭借其更高的物品等级和次要效果，以较大优势成为最佳武器。
- [[item:271874@JAAEAAAG2YhN]]：凭借其更高的物品等级和毒咒效果，成为遥遥领先的最佳头盔。
- [[item:270164@JAACAAgNyA]]：最好的被动饰品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271565@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240893]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271563@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270170@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240916]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAMAAwt1ENMMYzy1glIcYD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 第2赛季 火焰 法师 饰品推荐

火焰 有大量饰品可供选择。通常，你会想要使用一个强力的主动使用饰品与 [[spell:190319]] 配合，然后将一个强力的被动饰品作为你的第二个饰品。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **火焰 法师饰品**
**使用型 -**

[[item:273796]]

，或者，另外

[[item:270170]]

（稍弱）

**被动 -**

[[item:270164]]

，或者，另外

[[item:250214]]

（稍弱）

:::

还有不少其他有价值的饰品，所以请务必点击我们的排名图表，看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击此处查看火焰法师饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796]] — 最佳主动使用饰品</li>&#10;<li>[[item:270164]] — 最佳被动饰品</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]] — 强力被动饰品</li>&#10;<li>[[item:270170]]——在单体目标上是强大的主动使用饰品，但在范围伤害中价值会降低。</li>&#10;<li>[[item:250214]]——强力被动饰品</li>&#10;<li>[[item:270167]] — 强力被动饰品</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169]] — 数值上相当强力的主动饰品，但需要监控增益效果</li>&#10;<li>[[item:250259]] — 在单目标中是强大的被动饰品，在AoE中价值降低</li>&#10;<li>[[item:250224]] — 相当强力的被动饰品</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:273794]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:158368]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可用于保证从特定首领或地下城获得物品。每次使用时，你保证从该首领或地下城获得一件物品，然后该物品会从可能的物品池中移除。然后下次使用时，你保证获得剩余物品中的任何一件，这意味着你将在几次使用内获得你想要的该首领或地下城的物品。

随着12.1.5补丁的上线，你还将从处免费获得一个额外的虚空核心。
**奥琳·微光** 在银月城，紧邻转化器。

此外，12.1.5版本带来了（回归的）[[item:280562]]，它允许你提升一件已完全升级的第2赛季英雄、史诗或制造的武器、饰品或项链的物品等级。

注意：史诗难度 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 和 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 装备无法再升级，因为它们已经超过了正常的物品等级上限。

3.1.

#### 火焰 法师推荐的虚无核心使用建议

你追求的最佳物品完全取决于你目前已获得的物品以及你正在攻略的内容。例如，如果你尚未在史诗难度击败某个特定首领，但预计很快就会击败，就不应该将虚空核心用在该首领的英雄难度掉落上。下面我列出了一个通用的虚空核心物品优先级列表，但为了获得最适合你自己角色的最佳结果，你应该使用
[Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 史诗或英雄难度[[item:271092]]——最佳武器，凭借其更高的物品等级和加成效果，优势巨大。 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
   还会掉落多件其他强力物品，使其成为一个非常有价值的额外掉落首领。
2. 史诗难度[[item:271874]]——最佳头盔，因为其物品等级更高且带有剧毒诅咒加成效果。
3. 任何神话级追踪武器 — 它们都无法超越[[item:271092]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)的简斯拉泽，灵魂之牙，但如果你不打算或不期望击杀英雄难度的尤拉泰克，从其他途径获取一件神话级武器就很重要，尤其是如果你没有制作过一件的话。
4. 来自更高物品等级的装备 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)，特别是[[item:268243]]。
5. 剩余的毕业装备列表物品

:::

3.2.

#### 晋升毒液石

你希望以这样的方式使用你的[[item:280562]]，以便从每一块消耗的毒液石中获得最多的能量：

1. 主手武器 / 双手武器
2. 主动使用型饰品
3. 被动饰品
4. 副手
5. 项链

在几乎所有情况下，你只会想在神话难度装备上使用Venomstones，除非你不期望在同一部位获得神话难度装备，或者你没有其他东西可以花费Venomstones。

一个例外是[[item:271092]]：如果你拥有英雄难度的该武器，且不太可能获得史诗难度版本，那么升级它是一个很好的选择，因为其特效使它优于任何史诗品质武器，尤其是通过毒石升级到340物品等级后。

1.

### 火焰法师最佳制造物品

**制作什么高度取决于你自己的个人目标、你正在玩的内容以及你迄今为止获得的物品。**
我们强烈建议你使用Raidbots上的droptimizer自行运行模拟，以确定你个人最佳的制造选择。

下面我们列出了最佳的制造纹章物品，但 **请务必查看下方的制作顺序以获取更多背景信息，因为最佳美化物品并不总是最适合首先制作的！**

- [[item:245769@JAAMAAwt1ENMMYzy1glIcYD]]与[[item:273060]]
- [[item:239648@JAAMAAwt1ENMMYDYwglIcYD]]搭配[[item:240167]]

4.1.

#### 火焰火焰法师的制造订单

由于在赛季初期，你的制造物品能力会受到时间限制，我们强烈建议获取一个 **武器** 尽早获取，除非你能在其他地方可靠地获得。一旦你有了不错的武器，接下来就制作你的另一件附魔装备，然后制作你还没有高品质版本的装备。

下面的优先级列表可能有点令人困惑，但归根结底是这样的：你想要一件带有[[item:273060]]的装备和一件带有[[item:240167]]的装备。猎人的仪式石只能装备在武器上，而[[item:271092]]非常强大，所以如果你能获得简斯拉泽，灵魂之牙（或一件史诗品质的武器），你会想把武器纹章放在副手上，否则，你只需要坚持使用一把双手制造武器。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **火焰法师制造装备优先级**
1. [[item:245770]] 和 [[item:273060]]：尽早制作武器能提供巨大的战力提升。如果你预计会获得英雄级（或更高）的 [[item:271092]]，则应跳过此步骤。
2. 如果你跳过了上面的步骤，使用[[item:273060]]来制造[[item:245769@JAAMAAwt1ENMMYzy1glIcYD]]
3. [[item:239648@JAAMAAwt1ENMMYDYwglIcYD]] 配合 [[item:240167]]：也可以制作任何其他部位，关键是在一件装备上获得奥纹内衬，并替换一件低物品等级的装备。护腕是毕业选择，但你之后反正可以重新制作。
4. 任何你尚未获得神话级的物品。
5. 在可能的情况下，你会想要用 [[item:271092]]（英雄或更高难度）替换专业制造的 [[item:245770]]，然后用 [[item:273060]] 制造 [[item:245769@JAAMAAwt1ENMMYzy1glIcYD]]。如果你不打英雄难度，你会想要坚持使用专业制造的法杖 [[item:245770]] 搭配 猎人的仪式石。如果你不打英雄难度但运气好在宝库中找到一件神话品质的武器，你应该改用那件武器，并用 猎人的仪式石制造副手。

:::

有关如何制造你自己装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于纹章每周获取量有限，而且升级不同物品所花费的纹章数量相同，你应该优先将纹章用在那些你短期内不打算更换的物品上，或是能带来最大收益的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **火焰 法师 龙纹升级优先级**
**武器（选择法杖以节省纹章）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

这个顺序由升级这些部位所获得的强度决定。当然，升级哪个最好会很大程度上受到你拾取了什么的影响，因为如果你拾取了这些部位更高物品等级的装备，你就可以完全避免使用纹章，所以确保不要盲目遵循提供的升级顺序！

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为催化物品列表添加了掉落位置。
- **2026年10月9日：** 更新了毕业装备以显示升腾毒石的升级物品等级，并添加了升腾毒石升级指南，以及添加了基斯希克斯掉落。
- **2026年9月1日：** 更新了一些额外ID，以确保其正确显示剧毒诅咒效果的提示信息，并更新了项链的最佳装备信息。
- **2026年8月31日：** 在制造物品的提示信息中添加了制造属性，并将最佳装饰列表与下方的制造优先级对齐。
- **2026年8月24日：** 已更正为正确的团队副本名称。
- **2026年8月23日：** 更新了整体最佳装备列表以包含猎人的仪式石，并更新了制造优先级，以更清晰地解释双手武器与副手制造的利弊。
- **2026年8月15日：** 更新了前期制造内容，使用猎人的仪式石。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月17日：** 根据补丁后更新的理论计算更新了毕业列表和最佳饰品。
- **2026年6月15日：** 根据新的孢子融合装备更新了毕业列表和饰品推荐。
- **2026年5月23日：** 因5月26/27日的增益，略微更新了最佳装备和饰品排名。
- **2026年4月20日：** 新增了幽邃虚空核心和升腾虚空核心部分，并根据武器/饰品的新物品等级上限更新了最佳装备列表。
- **2026年3月31日：** 将无常能量熔炉饰品添加到饰品层级列表中。
- **2026 年 3 月 17 日：** 因饰品调整补丁更新了饰品优先级。
- **2026年3月16日：** 将赛季前毕业装备列表替换为3个不同的第1赛季毕业装备列表（总体、团本、大秘境），更新了第1赛季的制造信息，添加了第1赛季饰品天梯榜。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5更新了物品等级（涡轮加速物品等级），添加了谜之帮派章节，并针对无限徽记更新了制造推荐。
- **2025年8月16日：** 根据饰品调整和新发现更新了最佳饰品。
- **2025年8月5日：** 在饰品列表中添加了更多饰品，并略微更新了大秘境毕业装备。
- **2025年8月4日：** 针对11.2.0更新了毕业列表、饰品推荐、制作顺序，添加了Reshii章节
- **2025年6月24日：** 已更新关于随重置而来的改动的DISC腰带信息。
- **2025年6月17日：** 略微更新了持久信息保障容器腰带的信息，以显示不同加成的百分比收益。
- **2025年6月15日：** 添加了持久信息保密容器腰带信息和最佳奖励，并为新腰带更新了毕业列表。
- **2025年5月20日：** 更新了谜之卡特尔筹码部分以提供更多背景信息，并移除了对神经突触增强器的引用。
- **2025年5月15日：** 将物品等级更新为涡轮增压物品等级，更新了推荐饰品并提供了更多背景信息和选项，更新了财团芯片并提供了更多背景信息和不同的路线推荐。
- **2025年4月27日：** 用最新信息更新了谜之卡特皮尔代币部分。
- **2025年4月21日：** 添加了赝品经销商芯片部分。
- **2025年3月15日：** 更新了制作顺序，通过清晰区分首次制作和后续制作使其更有条理。
- **2025年2月25日：** 增加了霜火毕业装备，并根据最新的数值调整和理论计算优化更新了饰品。
- **2025 年 2 月 24 日：** 更新了第2赛季/11.1版本的毕业装备，根据新的毕业物品更新了制造推荐，根据新饰品更新了饰品推荐。
- **2024年12月17日：** 在增强后更新了Cyrce的指环建议，并在它变得更好后更新了毕业装备以包含它。
- **2024年12月15日：** 添加了Cyrce's Circlet章节。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月24日：** 修正了副手制造错误关联的专业。
- **2024年9月16日：** 为新的毕业装备配置更新了制造建议。
- **2024年9月9日：** 从不同来源添加了3份毕业列表：团队副本、大秘境、综合。添加了饰品梯队列表。从制造文本中移除了免责声明。
- **2024年9月3日：** 更新了专业制作建议和毕业装备列表。
- **2024年8月27日：** 更新了关于更新后的装饰的制作建议，并更新了毕业列表。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月30日：** 修正了整体毕业列表中缺少4件套的问题。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季更新了最佳装备：更新了毕业列表、套装描述、专业制造建议等。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月7日：** 由于孢子披风削弱，更新了毕业装备和纹章。
- **2023年11月6日：** 为10.2更新了全部3个毕业和装备列表，添加了第31赛季套装部分，并根据新的专业制造物品等级更新了专业制造建议。
- **2023年9月26日：** 更改了布局。
- **2023年9月4日：** 添加了3种不同的毕业配装。
- **2023年7月10日：** 更新了重做后的火焰毕业装备，并增加了永恒黎明副本装备章节。
- **2023年5月25日：** 添加了时光漫游部分。
- **2023年5月8日：** 根据改进的模拟和进一步的理论计算更新了饰品建议。
- **2023年5月1日：** 更新了毕业装备、制造建议、装饰，并将勇气描述替换为新的纹章系统，根据新的10.1装备更新了玛瑙印记戒指部分。
- **2023年3月25日：** 根据在线修复更新了Onyx戒指建议。
- **2023年3月22日：** 更新了最佳装备以包含昂赛恩戒指，因为发现了新的宝石组合。
- **2023年3月20日：** 添加了玛瑙禁锢戒指信息并针对10.0.7补丁进行了审阅。
- **2023年1月24日：** 根据更新后的理论计算更新了毕业装备建议。
- **2022年12月17日：** 由于青铜护手的改动，更新了制造装备信息。
- **2022年12月13日：** 根据最新的理论计算知识进一步更新了制造装备信息。
- **2022年12月11日：** 根据进一步的理论计算更新了饰品推荐，并为打造装备添加了更多信息。
- **2022年12月11日：** 已针对第1赛季更新，包括专业制造装备、大秘境装备和团本装备。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的火焰法师的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法相互作用。我们的内容已针对魔兽世界12.1.5补丁进行更新。

1.

### 火焰法师属性优先级

在单体和范围伤害中，你应按以下优先级堆叠属性：

智力

急速

精通

全能

暴击

**所有次要属性（非智力）的价值都非常接近，尽管它们在列表中的排序如此，暴击除外，它通常是最差的。**
我们鼓励玩家尽可能自己进行模拟，以根据你当前的属性分布确定应该追求哪些属性，因为这可能会根据你当前的数值而变化。这是因为某一项属性的匮乏往往会导致其相对其他属性的价值升高，直到你达到一个“均衡”值。因此， **我们强烈建议使用 [Raidbots 最佳装备](<https://www.raidbots.com/simbot/topgear>)**
来处理你的装备需求（参见我们的 [Raidbots指南](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)).

1.

### 深入属性解析

**智力** 是你的主属性。它为你提供法术强度，增加你法术的伤害。

**暴击** 提高你的暴击几率，这反过来增加你获得[[spell:195283]]的几率。

:::details 常见问题玩火焰 法师需要最低暴击等级吗？
由于触发

[[spell:48107]]

/

[[spell:195283]]

需要暴击属性，许多人认为要玩好火焰需要很高的暴击率。然而，你并不需要任何特定的暴击值就能让火焰变得强大。由于像

[[spell:390218]]

这样的被动天赋，当你在未暴击时会提供大量可叠加的暴击等级

[[spell:133]]

,

[[spell:319836]]

必定暴击，

[[spell:2948]]

在敌人生命值低于30%时必定暴击，以及各种其他提升暴击的天赋，即使在暴击等级非常低的情况下，你也能很好地使用火焰。在许多情况下，暴击实际上是最差的属性，因为火焰能获得大量必定暴击的效果。

:::

**精通**通过[[spell:12846]]，增加你的[[spell:12846]]持续伤害效果的伤害。

**急速** 影响你法术的施法速度。它还影响[[spell:319836]]的冷却时间和[[spell:153561]]的下落速度。

:::details 常见问题火焰法师有急速上限吗？
火焰法师的急速没有阈值或上限。然而，所有属性都有递减收益，获取更多属性会降低其价值，因此通常进行一些平衡是很有价值的。

:::

**全能** 是纯粹的造成伤害提升和承受伤害降低。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月3日：** 删除了不再相关的旧段落，并修正了一个错别字。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月21日：** 更新了属性权重的描述，更清楚地解释了使用最优装备（Top Gear）模拟更好。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 根据10.2的改动更新了推荐属性。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 更新了10.1.5版本火焰法师重做后的属性建议。
- **2023年5月1日：** 根据 10.1 的改动更新了推荐属性。
- **2023年3月20日：** 为10.0.7补丁进行了审查，并将精通调整至全能之上。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的火焰法师可以获取的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

有史诗和稀有宝石两种，史诗宝石明显更强。然而，你只能装备一颗史诗宝石，因此其余插槽需要用稀有宝石填满。

有两种史诗宝石，根据情况不同，其中一种可能为最佳选择。如果你有5个或更多宝石插槽，[[item:240967]]是最佳的史诗宝石。然而，如果你的插槽少于5个，请使用[[item:240983]]。

**稀有宝石的强度都非常接近，最好的一颗会根据你具体的属性分配而变化。**
如果你有5个或更多宝石插槽，因此使用[[item:240967]]，你应该每种颜色各使用一个。否则，你可以使用任何模拟结果最好的宝石，或作为安全默认选择使用[[item:240893]]。详情请参阅下方列表。

- 史诗：
  
  
  
  
  - 拥有5个或更多插槽时：[[item:240967]]
  - 少于5个插槽时：[[item:240983]]
- 稀有品质，5个或更多插槽：
  
  
  
  
  - 1x [[item:240893]]
  - 1x [[item:240916]]
  - 1x [[item:240900]]
  - 1x [[item:240906]]
  - 其余插槽[[item:240893]]
- 稀有品质且少于5个插槽：所有插槽使用[[item:240893]]

<em>我们强烈建议使用 [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 来模拟你角色的理想宝石和附魔，因为它们可能与我们的一般推荐不同。</em>

1.

### 最佳附魔和武器强化

你应该在所有内容中使用[[item:243733]]。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头盔（非伤害）</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>肩部（非伤害）</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>[[item:243957]] </td>&#10;</tr>&#10;<tr>&#10;<td>脚部（非伤害属性）</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>[[item:244029]] </td>&#10;</tr>&#10;</table>

并非所有附魔都提供伤害，例如头部、肩部和脚部。你可以在这些插槽中选择速度、闪避或汲取。火焰已经拥有良好的机动性，但更多的速度永远不会有害，特别是它允许你在瞬发施放的[[spell:11366]]或[[spell:2948]]施放期间移动更远的距离，让你可以将机动性法术留到真正需要的时候使用。然而，闪避附魔也是这些插槽的一个绝佳选择，可以简单地减少你从各种敌人技能中受到的伤害。我通常不建议在组队内容中使用汲取附魔，但在单人内容中它可能相当不错。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

在第2赛季中，你应该使用[[item:241325]]。

3.2.

#### 药水

[[item:241308]] 是所有内容中最佳的输出药水，而 [[item:271883]] 是我们首选的治疗药水。

3.3.

#### 食物增益

[[item:255845]]，或者如果你在进行经常死亡的内容（如开荒团队副本首领），则使用[[spell:1278895]]。

3.4.

#### 强化符文

强化符文通常相当昂贵，尤其是在早期，但使用时确实能提供约1%的伤害输出提升，因此在进行高难度内容时可能起到决定性作用。[[item:259085]]是目前唯一可用的强化符文。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月17日：** 更新了最佳药水。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 移除了茶的提及，因为它在副本中不起作用。
- **2026年3月16日：** 根据最新的理论研究发现更新了最佳消耗品。
- **2026年3月3日：** 将最佳戒指附魔更新为鹰眼之眼。
- **2026年3月1日：** 在食物部分添加了茶类及其移动速度加成。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2.0进行更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 添加了腐蚀附魔章节。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月11日：** 新增了武器消耗品（油）。
- **2024年9月9日：** 添加了狡诈亵渎宝石作为替代宝石。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 添加了新的第4赛季头盔附魔，以及药水的小幅改进。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 移除了与玛瑙印记戒指相关的部分，因为它现在落后太多而不予考虑。
- **2023年10月1日：** 更新了食物增益建议。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月9日：** 将宝石建议从精通改为急速+全能。
- **2023年7月10日：** 根据10.1.5的火焰法师重做以及原初宝石的削弱进行了更新。
- **2023年5月22日：** 更新了腿部附魔建议。
- **2023年5月1日：** 根据10.1新装备更新了奥术指环建议。
- **2023年3月25日：** 根据热修复更新了原始石宝石建议。
- **2023年3月22日：** 由于 Desirious Blood Stone（渴血之石）的组合非常强大，更新了始源之石的宝石建议。
- **2023年3月21日：** 根据晦暗粉彩石在正式服务器上是奥术而非暗影，更新了原始石宝石建议。
- **2023年3月20日：** 添加了原初之石宝石建议，并针对10.0.7补丁进行了审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月13日：** 添加了腿部附魔。
- **2022年12月14日：** 添加了武器灌注建议。
- **2022年12月13日：** 更新了药水建议。
- **2022年12月11日：** 根据更好的模拟结果更新了宝石建议。
- **2022年12月11日：** 更新了药水建议。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本攻略中，你将找到在《魔兽世界》12.1.5补丁中使用你的火焰法师挑战大秘境地下城的技巧和建议。

1.

### 火焰法师在至暗之夜第2赛季大秘境中的表现

火焰法师长期以来一直被认为是大秘境中的强力专精。它不仅拥有出色的伤害输出能力，在进行范围伤害时通常无需牺牲太多甚至完全不牺牲单体伤害，还具备极强的实用性和生存能力，使其成为任何大秘境队伍都非常渴望带上的专精。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

火焰在大秘境中通常有两种主要玩法：一种是基于[[spell:2120]]的范围伤害玩法，其中你消耗[[spell:195283]]的主要技能是烈焰风暴；另一种是基于顺劈的玩法，其中你的炽热连击会用于施放[[spell:11366]]。两种构筑通常都可行，烈焰风暴变体的总体DPS更高，而顺劈构筑的单体和优先目标DPS更高。

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火大秘境天赋

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火大秘境天赋

该构筑可以通过根据怪物群简单切换输出循环，同时打出优先目标DPS和最大范围伤害DPS。请查看 [优先目标DPS与范围伤害DPS部分](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips#prio-vs-aoe>) 以获取更多信息。

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAmZZGzMLzCAAAYxMDbzMzMjNAAAAAsZmxMDAAmZYmxMzMzCwMDIjxYwMMGA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRBU4QAJ5k5XxmH-CdIBCw02MUWY4KRoquATScemKeklBJC-AAAA-SgEgZR4QhBAhyA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒大秘境天赋

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒大秘境天赋

标准的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒火焰大秘境构筑。它在单体和范围伤害DPS方面都表现出色且不偏废任何一方，使其在所有类型的地下城中都非常灵活。

该构筑可以通过根据怪物群简单切换输出循环，同时打出优先目标DPS和最大范围伤害DPS。请查看 [优先目标DPS与范围伤害DPS部分](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips#prio-vs-aoe>) 以获取更多信息。

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAAbmZMzAAgZMmZmZMzsMAMzAjxAmhxA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFNhlxd0EVFJR5DUo4QAJ5mH-CdIBCw02MUWYs4KRoqu8ATSceimGKeA-AAAA-DQko0IUY4IDwwC-
```

:::

### 灵活天赋 / 副本专属天赋

2.3.

#### 灵活天赋 / 副本专属天赋

根据地下城不同，天赋方面有很大的灵活性。法师职业树拥有大量实用技能，根据地下城的不同，这些技能可能非常有用，也可能完全没用，这让你可以根据需要在这些实用法术或防御天赋之间进行切换。

- 根据个人喜好在[[spell:1244090]]或[[spell:1244087]]之间切换。时光重组是一个非常简单的被动治疗，当你血量低时触发，而时空漫步如果你擅长主动使用[[spell:342245]]则更好。
- 根据是否需要跳过小怪，切换 [[spell:414664]] 的学习与取消。
- 根据你是否需要解除任何诅咒来决定是否专精[[spell:475]]。
- 根据是否需要移除任何敌人增益效果，切换[[spell:30449]]的使用。
- 根据你正在攻略的地下城是否需要 [[spell:45438]] 的免疫效果，切换 [[spell:414659]]（及通往它的节点）的学习与取消。
- 如果你从上面列出的任何节点中退出专精，你可以使用这些点来专精以下一个或多个：
  
  
  
  
  - [[spell:1270827]]：如果你经常需要对同一目标连续驱散多次，但又不想为此牺牲太多公共冷却时间，这个天赋很有用。
  - [[spell:1270847]]：如果你经常需要同时驱散自己和另一个人，但不需要驱散其他人，这很有用。通常只有当队伍中有第二个诅咒驱散者时才推荐。在 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>) 周，快速驱散自己和另一个人。
  - [[spell:386763]]：如果你需要风筝敌方怪物群。
  - [[spell:382293]]：用于速通内容。
  - [[spell:210476]]：如果你需要更高的移动速度加成或想在全潜行队伍中跳过敌人，可以与 [[spell:382293]] 搭配使用。

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断

[[spell:2139]]是我们大多数情况下的首选打断技能。它不仅会打断一个法术，还会根据天赋使敌人在7-8秒内无法施放同系法术。

为了避免不得不切换目标，我强烈建议使用鼠标悬停或焦点目标宏。下面的宏会打断你的焦点或鼠标悬停目标（如果你有的话），或者在你没有的情况下打断你当前的目标。

#### 鼠标悬停反制

```wow-macro
#showtooltip
/cast [target=mouseover,exists] 法术反制; 法术反制
```

#### 焦点打断

```wow-macro
#showtooltip
/cast [target=focus,exists] 法术反制; 法术反制
```

3.2.

#### 眩晕与"打断"

[[spell:157980]]和[[spell:31661]]是对敌人进行范围打断的主要方法。你只能选择其中一个，选择哪一个取决于情况。它们通常都能打断敌人的施法，但与[[spell:2139]]不同的是，它们无法阻止敌人立即重新施放相同或不同的法术。

一般来说，新星更容易使用，因为它可以在不靠近敌人的情况下使用，但两者都是不错的选择。

此外，[[spell:118]]、[[spell:113724]] 和 [[spell:383121]] 也可以用来打断敌人（如果点了天赋），但在大多数情况下敌人会立即重新开始施法，所以这只应作为最后的手段。变形术还有一个缺点，就是会治疗敌人。

### 其他功能

3.3.

#### 其他功能

[[spell:1459]] 为全队提供智力加成，提高你自己和其他施法者的 DPS，以及治疗者的治疗量。

[[spell:80353]]对于任何大秘境队伍来说都是一个关键的冷却技能。每10分钟它就能为队伍提供一个巨大的急速增益。

[[spell:475]]在某些地下城中可用于驱散诅咒。它也应该被用来驱散 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)
如果它是一个生效的词缀。

[[spell:30449]]可用于移除敌人身上的魔法增益效果并转而施加给你。尽管在许多情况下，出于平衡原因这些增益实际上并不会转移给你，因此它主要作为进攻性驱散使用。

[[spell:110959]]可以用来完全脱离仇恨，同时它有时还能完全取消某些减益效果、对你施放的定向法术或取消各种机制。

[[spell:386828]]允许你移除定身/减速效果。它通过完全移除造成减速的减益来实现，这意味着它有时可以用来完全移除危险的减益，如果这些减益同时也施加减速的话。

[[spell:414664]] 偶尔可用于跳过某些怪群。

1.

### 大秘境深度输出循环提示

以下列出了一些特定的大秘境技巧，一旦你已经熟悉了我们循环页面中的常规循环，这些技巧可以进一步提升你的游戏水平。

4.1.

#### 选择优先目标DPS还是最大范围伤害DPS

使用推荐的天赋构筑，你在大秘境中想要打出何种类型的伤害拥有很大的灵活性。归根结底，这取决于你将[[spell:11366]]还是[[spell:2120]]作为你的[[spell:195283]]和[[spell:269650]]消耗技能。炎爆术能提供显著更高的优先目标DPS，而烈焰风暴则能造成显著更高的范围伤害DPS。幸运的是，你可以自由切换使用哪一个，无需更改天赋，从而可以根据怪物群进行选择。

通常这个选择相当明显：如果怪物群中有一个目标存活时间过长会非常危险，你就直接使用[[spell:11366]]作为你的[[spell:195283]]/[[spell:269650]]消耗技能；但如果情况并非如此，你就改用[[spell:2120]]作为消耗技能。

1.

### 应对词缀

至暗之夜 第2赛季有四个轮换的 词缀 需要主动应对，称为萨拉塔斯的交易。这些每周轮换，同一时间只有一个处于激活状态。大多数其他大秘境词缀，如残暴或强韧，只是为钥石添加一个被动效果，而这四个例外是以萨拉塔斯为主题：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将出现三波需要被打断或驱散的宝珠。你有多种方式来处理它们：如果它们聚集在一起，用 [[spell:157980]] 进行 AOE 打断，用 [[spell:2139]] 进行单体打断，用 [[spell:30449]] 处理剩余的。由于法术偷取没有冷却时间（除非点出 [[spell:1270827]]），理论上你可以清除所有宝珠，但这会花费大量时间。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：生成一个虚空大使敌人，需要快速将其击杀。它死亡后，你会获得一个强力的技能冷却和全能增益。注意：如果它生成在你已经点燃的敌人附近，你可以将[[spell:12846]]扩散到该目标上，从而为这个小怪提供大量免费伤害。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：宝珠会在玩家周围生成并环绕他们旋转。你有15秒的时间吸收所有这些宝珠来为你的小队提供增益。只需跑过去吸收它们即可。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有小队成员都会受到一个治疗吸收效果的影响。你可以用[[spell:475]]移除这些效果。[[spell:1270847]]对于快速驱散你自己和另一名玩家非常有用。如果你的治疗者资源耗尽，治疗药水或治疗石也能很好地发挥作用。

当你成功应对这些词缀时，它们会授予你一个增益效果，不同词缀效果不同。这些效果通常相当强大，但玩家们并没有真正围绕它们进行规划。然而，正确应对它们非常重要，因为失败会给敌人带来增益，这可能很快导致队伍灭团。

注意：这些词缀在进行史诗钥石等级12或以上的地下城时会消失（正面和负面效果均消失），取而代之的是死亡会使计时器减少15秒。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 更新了12.1/第二赛季的最佳天赋，并更新了最佳天赋的循环信息。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月24日：** 调整了一些功能性天赋，使其成为更常见的默认选择。
- **2026年4月21日：** 修正了一个小错误
- **2026年4月20日：** 更新了功能部分的布局，并为打断和功能添加了一些额外的说明。
- **2026年3月16日：** 已针对至暗之夜第1赛季更新：更新了最佳天赋、灵活天赋，添加了赛季词缀等。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为12.0.1天赋树改动更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 更新了11.2的最佳构筑，新增了第三赛季实用法术部分。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月30日：** 为TOP+酿酒师添加了警告，请勿点出「 Lessons in Deblitation 」天赋。
- **2025年3月22日：** 移除了起手打断提示，因为它们无法被迷惑打断。
- **2025年3月14日：** 为所有地下城添加了提示。
- **2025 年 2 月 24 日：** 根据11.1的改动更新了最佳天赋，并针对新的词缀更新了词缀提示。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年11月26日：** 针对最新的增益更新了天赋。
- **2024年10月21日：** 更新了天赋并将可行的天赋拆分为3种不同的天赋方案。还添加了地下城特定技巧。
- **2024年10月2日：** 更新了烈焰风暴与灼烧的取舍选择，进一步强调烈焰风暴能带来更高的总DPS。
- **2024年9月24日：** 由于最新的增强使得烈焰冲击更加可行，现已添加基于烈焰冲击的AOE配装
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 根据第4赛季的改动更新了最佳天赋。
- **2024年3月19日：** 为10.2.6补丁进行了更新，将不同的大秘境配置拆分到单独的方框中，这样它们占用的空间更少，也更容易查看。
- **2024年3月9日：** 略微更新了推荐的史诗钥石地下城天赋，并添加了更多关于选择点燃流与烈焰风暴流的信息。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 更新了10.2版本的天赋。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月1日：** 更新了灼烧之痛和爆击天赋的选择，而非陨石。
- **2023年7月10日：** 更新了10.1.5版火焰重做后的天赋推荐、输出循环和实用性说明。
- **2023年6月12日：** 修复了天赋导入字符串。
- **2023年5月1日：** 根据新的最优天赋更新了天赋，并移除了关于烈焰风暴构建的提及，因为它现在落后太多不值得考虑，同时移除了关于雷鸣的提及。
- **2023年3月20日：** 已针对10.0.7补丁进行审阅并提供了一些小的措辞调整。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到大量实用的宏和插件，以便在《魔兽世界》12.1.5补丁中使用你的火焰法师时让游戏更加轻松。

1.

### 最佳宏

下面列出的是针对法师，特别是火焰法师的一系列实用宏，其中一些适用于所有三个专精，而另一些则仅在你使用火焰法师时才有用。

1.1.

#### 火焰专属宏

1.1.1.

##### 一键燃烧

#### 一键燃烧

```wow-macro
#showtooltip 燃烧
/cast 先祖召唤
/cast 狂暴
/cast 血性狂怒
/cast 燃烧
/use 13
/use 14
/use 16
```

这将同时施放[[spell:190319]]和你的任意饰品栏位。此外，它还会激活提升DPS的种族技能，如[[spell:26297]]或[[spell:33697]]。请注意，你可以在施放其他法术时使用燃烧，因此你必须持续按下宏，直到施法结束后才能激活饰品和种族技能。

1.1.2.

##### 光标处施放烈焰风暴

#### 光标火焰冲击

```wow-macro
#showtooltip 烈焰风暴
/cast [@cursor] 烈焰风暴;
```

这个宏会在你的光标位置施放 [[spell:2120]]，而无需先显示一个目标选择圈。这仅在你选择了手动施放烈焰风暴天赋（而非指定目标的烈焰风暴天赋）时有效。

:::details 常见问题：我应该使用单体目标的[[spell:2120]]还是区域目标的烈焰风暴？
对于大多数玩家来说，自动选择目标的选项是最好的选择。它能释放你的光标和注意力，让你专注于游戏的其他方面。然而，由于它是以你正在攻击的目标怪为中心的，你会发现有些情况下它会漏掉怪群中的一些怪。通过练习，你应该能够使用区域目标（通过 @cursor 宏）版本多挤出一点 DPS。两种都试试，看看你更喜欢哪一种。

:::

1.1.3.

##### 光标处施放流星

#### 光标流星

```wow-macro
#showtooltip 流星
/cast [@cursor] 流星;
```

这将在你的光标位置施放[[spell:153561]]，而不是先显示一个目标圈。

:::details 常见问题我可以对我的目标而不是光标施放[[spell:153561]]吗？
很遗憾不行。无法制作一个宏来对

[[spell:153561]]

你的目标施放，而且游戏本体也没有这个功能。上面显示的 @cursor 宏是最好的解决方案。

:::

1.2.

#### 法师通用宏

1.2.1.

##### 打断闪现

#### 瞬发闪现

```wow-macro
#showtooltip
/stopcasting
/cast 闪现术
```

按下[[spell:1953]]现在会取消你当前的法术施放并使你立即闪现。注意，这不应该与[[spell:212653]]一起使用，因为它会不必要地取消你当前的施法，也不应该在你施放某个法术时使用，如果你可以等待完成施法再需要闪现的话

1.2.2.

##### 一键格挡

#### 一键 寒冰屏障

```wow-macro
#showtooltip
/stopcasting
/cancelaura 寒冰屏障
/cast 寒冰屏障
```

取消你当前的施法并立即进入 [[spell:45438]]。再次按下 寒冰屏障 会取消该效果。如果你习惯狂按技能键，不推荐使用。

1.2.3.

##### 格挡取消

#### 取消光环寒冰屏障

```wow-macro
/cancelaura 寒冰屏障
```

如果你是狂按按钮的玩家，可以将其放在单独的快捷键上作为你的[[spell:45438]]，让你能够提前取消你的寒冰屏障。

1.2.4.

##### 操控时间 取消

#### 取消光环 操控时间

```wow-macro
/cancelaura 操控时间
```

你可以使用上面的宏来取消 [[spell:342245]]，如果你不想被传送回最初施放 操控时间 时的位置/生命值。

1.2.5.

##### 鼠标悬停驱散

#### 鼠标悬停解除诅咒

```wow-macro
#showtooltip
/cast [target=mouseover,exists] 解除诅咒; 解除诅咒
```

这将解除你鼠标悬停的任何单位身上的诅咒。你可以将解除诅咒替换为你想在鼠标悬停时施放的任何其他法术，比如[[spell:30449]]。如果你没有鼠标悬停目标，它将对你的当前目标施放，或者如果你既没有悬停目标也没有选中目标，则对你自己施放。

1.

### 最佳插件

:::details 常见问题为什么我看不到我的[[spell:195283]]触发效果？
在设置菜单中，调整"法术警报不透明度"（使用搜索功能找到它）。此外，如果你更喜欢用图标来追踪，你可以为

[[spell:195283]]

在暴风雪冷却管理器中启用追踪，它会同时追踪炽热连击和

[[spell:48107]]

.

:::

2.1.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) 是对默认用户界面的完整替代。它包含了你正常发挥所需的几乎所有功能：动作条、单位框体、冷却计时器、触发提示等。

2.1.1.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) 是一个有用的插件，可以让你追踪其他团队成员的冷却时间，并为你提供大量其他有用的团队信息。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 更新了燃烧宏以默认包含所有相关种族技能/饰品栏位，并新增了关于看不到炽热连击触发以及流星/烈焰风暴宏和使用方法的常见问题解答。
- **2026年3月9日：** 修复了指向 解除诅咒 的鼠标悬停宏。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已更新至10.2.6版本，将默认插件更新为更符合当今团本和大秘境环境的插件组合。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5的火焰重做进行审核，无需更改。
- **2023年4月28日：** 添加了一个通用WeakAuras包，包含所有专精所需的全部WeakAuras。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
