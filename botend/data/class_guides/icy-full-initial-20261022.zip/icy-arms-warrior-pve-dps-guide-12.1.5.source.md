## 专精概览

Welcome to our Arms Warrior guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as an Arms Warrior in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Arms Mythic+ Resources

[NEW! Top Arms Talent Builds](<https://raider.io/specs/arms-warrior/talents>)

[Top Arms Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warrior/arms>)

[Arms Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warrior--arms>)

[Popular Arms Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warrior--arms>)

1.

### Arms Warrior Overview

Arms Warriors are very straightforward damage dealers which revolve
around frequent short cooldown burst damage windows with [[spell:167105]].
Their greatest strength comes in the form of a versatile toolkit, offering
single target, multi-target cleave, and even a limited physical damage immunity,
though with the drawbacks of limited burst multi-target, mediocre self-sustain,
and other inherent limitations of melee range.

Strong

Arms Warriors have a versatile toolkit, featuring varied single, two-target,
and heavy multi-target capabilities. They are quite strong going into Midnight
Season 2, particiularly in Mythic+.

Viable

Arms Warriors performing well in raid, especially on fights that feature a
secondary target or intermittent groups of adds. The penultimate encounter of
the Venomous Abyss in particular is extremely well suited for Arms' two-target
capabilities, making the specialization a go-to for the new raid.

Even on encounters they do not excel on, [[spell:6673]] ensures that
at least one Warrior will still be brought in most raid groups.

Exceptional

Arms Warriors are extremely strong in Mythic+, due to strong prority
damage, moderate funnel, and sustained multitarget. While physical damage
dealing group comps are quite restrictive, this is quite possibly the closest
Arms has been to meta in several expansions.

Many Minor Effects

Warriors have historically had a very difficult time with utility, having
access to several effects which are wholly unnecessary in the vast majority of
modern content. [[spell:384100]], [[spell:64382]],
[[spell:384110]], [[spell:376079]], and [[spell:12323]] are
all seemingly useful effects, but their mechanics are so under-represented in
modern content that they rarely, if ever, get used.

However, Warriors have seen a few improvements in Midnight. [[spell:97462]]
has been buffed in small group content, no longer being as concerned with
diminishing returns means stuns can be used more liberally, and the addition
of a ranged silence provides circumstantial value.

Strong Pre-emptive Survivability

Arms Warriors have above average survivability, by way of several short
defensive and healing cooldowns, which can be used independently to cover
several effects or layered to significantly reduce the threat of large
attacks.

[[spell:23920]] can immune several effects outright and
[[spell:386208]] is possibly the most reliable source of damage
reduction in the entire game. However, the caveat is that Warrior survivability
is very pre-emptive by nature. [[spell:118038]] gets a special mention
for its ability to parry most melee attacks, which can sometimes be used to
tank for a short period of time.

This requires players to have a keen awareness and very little room for
recovery from errors that true immunity or cheat death classes would survive.

Burst Movement on Cooldown

Between [[spell:6544]], [[spell:100]], and [[spell:3411]], Warriors
have very good mobility, so long as there is an appropriate path or target.

2.

### Arms Warrior in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 contains two new pieces of endgame content in the Unbinding of 
Kith'ix raid encounter and an expanded Mega-Delve: the Labyrinth of Kindo'jan! 
Both of these activities contain new challenges, achievements, and rewards, 
which you may learn more about on our dedicated pages.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Class Changes

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) acts as an escalation to the progression of Season 2 in
Midnight, with the story surrounding Ula'tek and the Amani culminating in a new one-boss
raid, access to ascended item levels, multiple sources of catch up gear,
and access to an infinite number of Mistcrests to upgrade it. Make sure to check out our
patch hub for all the information on what is new, or has been updated with Patch 12.1.5.

2.3.

#### Class Changes

There are no Arms Warrior changes in Patch 12.1.5, though our [gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>) has been updated with new 
recommendations from the Unbinding of Kith'ix raid and guidance on using 
[[item:280562]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_cleave.jpg>) Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Class Changes

There were extensive Arms Warrior changes in Season 2, which aimed to 
rebalance and streamline the gameplay, standardize the variable cooldown 
of Demolish to better align with Colossus Smash, makie Ravager a more potent 
single target ability, and reduce the emphasis on Cleave in favor of more 
damage from Overpower and Reap the Storm.

[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Warrior**

<em>Developers' notes: Rend is an iconic and core Warrior ability with 
    a different relationship to each spec. Our approach to Rend in Midnight 
    hasn't worked out as we hoped, so we're making changes to how each spec 
    applies and interacts with Rend in Curse of Ula'tek.</em>

- **Class**
  
  
  - The [[spell:772]] ability is now exclusive to Arms, has returned 
            to being a single-target ability, and its Rage cost is reduced to 10. 
            Cleave will apply Rend to all targets if the Warrior knows Rend.
  - [[spell:6343]] no longer innately applies Rend if known.
  - [[spell:1271948]] has a new icon.

- **Hero Talents**
  
  
  <em>Developers' notes: Demolish's variable cooldown has proven to be 
      more frustrating than interesting, so we're changing it to align closely 
      with Colossus Smash, enabling Arms Colossus Warriors to coordinate their 
      use for maximum devastation.</em>
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus: [[spell:429644]] has been updated – 
            Damage prevented by each use of Ignore Pain increased by 30% (was 20%).
  - [[spell:429636]] has been updated – Enemies damaged 
    		by Demolish deal 20% reduced damage to you for 10 seconds (was 10%) and 
            no longer reduces the cooldown of Demolish.
  - [[spell:436358]] cooldown reduced to 30 seconds (was 45 seconds).
  - [[spell:429641]] increases the damage of Overpower and 
            Execute (was Overpower only).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer: [[spell:444767]] has been updated – 
    		Chance to trigger a Slayer's strike increased to 25% (was 15%).
  - [[item:212361]] grants 20% damage and 20% critical strike 
            damage to your next Overpower (was 10% for both).

- **Arms**
  
  
  <em>Developers' notes: Arms’ AOE damage profile is dominated by Cleave, 
      and we’d like to spread the damage across more abilities. We’re updating 
      Dreadnaught to be purely AOE damage which will allow us to tune it solely 
      for AOE. This should help Arms’ AOE rotation not feel so dominated by 
      Cleave and help give Slayer better options for AOE.</em>
  
  
  
  
  - [[spell:1261051]] has been redesigned – Colossus Smash 
        immediately grants 1 use of Sudden Death.
  - Ravager damage increased by 50%.
  - Ravager no longer increases Cleave and Whirlwind damage while active. Ravager now causes all enemies it damages to take 50% increased damage from your Bleeds for 12 seconds.
  - Ravager's duration is no longer reduced by Haste.
  - Bloodletting has been updated – Your abilities have a 5% increased chance to critically strike targets affected by Rend. If you know Rend, Mortal Strike inflicts Rend on targets below 35% health. Deep Wounds lasts 33% longer.
  - Broad Strokes has been updated – Colossus Smash now grants 6 stacks of Sweeping Strikes on use.
  - Dreadnaught has been updated – Dreadnaught damage increased by 100% and no longer damages your Overpower target.
  - Melee auto-attack damage increased by 100%.
  - Cleave damage reduced by 10%.
  - Execute damage reduced by 15%.
  - Ignore Pain absorb increased by 25%.
  - Sweeping Strikes now displays the number of active Sweeping Strikes charges.
  - Powerful Momentum now increases Sweeping Strikes chain damage by 20% (was 25%).
  - Midnight Season 1 2-set bonus now increases Colossus Smash damage by 3% (was 5%).
  - Several talents have changed locations in the talent tree.
  - Improved Sweeping Strikes has been removed.

:::

### Midnight   Changes Overview

2.5.

#### Midnight Changes Overview

Although the core gameplay remains very familiar, Arms Warriors have 
undergone significant changes in Midnight, reworking or removing and replacing 
several talents entirely. Below is a general overview of the most impactful 
changes and how they affect gameplay going into the new expansion.

2.6.

#### Hero Talent Changes

Each Hero gains three new talents by level 90, though they are fairly 
straightforward, with no significant change in play style. The most notable 
update is for Slayer, with [[spell:444775]] now having an updated chance 
to proc per ability cast and triggering from [[spell:29725]].

2.7.

#### Rotational Changes

With the exception of a few new talented effects, the general gameplay 
remains very similar to The War Within.

- Rage generation has been reduced, which can result in more downtime
      and a greater emphasis on having a Shaman in the party to provide [[spell:462854]].
- Arms' Mastery has been changed to no longer interact with Deep Wounds,
      simply increasing damage while using a two-handed weapon.
- [[spell:184783]] now has a consistent chance to proc from all
      rotational abilities, including [[spell:29725]]. This results in
      slightly less, but overall more consistent Overpower procs.
- The removal of [[spell:200875]] has simplified Execute conditions,
      no longer requiring any complicated tracking or delaying the use of Sudden Death.
- [[spell:260708]] now operates on a charge system, resulting in
      less waste when using abilities that cannot be cleaved.

2.8.

#### Apex Talent: Master of Warfare

A new four-point node of specialization-specific Apex talents is now 
available. [[spell:1269314]] is an active proc replacing Slam with 
Heroic Strike, which applies a powerful damage enhancing buff. While it 
largely takes the place of regular casts of Slam, it will also be periodically 
weaved into the single target Execute phase, though the ability will always be 
used automatically in multi-target through [[spell:202316]].

- The first point is a proc which causes [[spell:1269383]] to replace 
  Slam, giving it a much higher priority and triggering a small armor 
  penetration buff. While this buff stacks, each has its own duration, resulting 
  in the buff constantly stacking and decaying, making it easy to treat 
  passively and ignore.
- The second and third points further enhances the Master of Warfare buff, 
  though has no rotational impact, since all of those abilities continue to be 
  used in the same manner.
- The final point causes Heroic Strike to apply a separate buff, increasing 
  the magnitude of Colossus Smash, which can be quite strong, given such a high 
  uptime on the ability.

2.9.

#### Survivability Changes

Warriors have seen several small improvements to their self-healing and
survivability, though the removal of WeakAura tracking made
[[spell:23920]] harder to use effectively.

- [[spell:1271926]] increases incoming healing.
- [[spell:29838]] now heals twice as much when below 35% health.
- [[spell:1280961]] significantly increases the value of
      [[spell:386208]], making it an extremely strong mini-cooldown.

2.10.

#### Utility Changes

Although no major new effects or abilities, Warriors have seen a few
improvements to their group utility in the new expansion.

- [[spell:97462]] now provides a larger bonus in small group content.
- Enemies no longer becomes immune after several stuns in PvE content,
      allowing them to be used more liberally.
- [[spell:1271948]] now causes [[spell:384110]] to serve as a
      ranged silence, albeit on a long cooldown.
- [[spell:12323]] now grants allies a short movement speed buff,
      which is not particularly important for countering mechanics, but useful
      for reducing downtime between pulls.

3.

### Basics of Arms Warrior Gameplay

Arms Warrior is a very straightforward and relatively simple spec which
generates almost all of its resources passively through auto-attacks, while
spending them with various active abilities. Predicting this flow of resources
and keeping track of important ability cooldowns is important to ensure that
you neither find yourself Rage starved and unable to use [[spell:12294]]
on cooldown or overcapping [[spell:7384]] charges.

Arms Warrior gameplay can best be described using the three key concepts below.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_charge.jpg>) **Avoid Downtime**  
  
    Arms generates the majority of its Rage from auto-attacks, so reducing the 
    amount of time spent chasing, running out mechanics, or otherwise not 
    hitting a target is critical to maximizing performance.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_savageblow.jpg>) **Keep Abilities on Cooldown**  
  
    Arms spends resources in small amounts, but the cooldown of abilities sets 
    the pace of the rotation. Keeping [[spell:167105]], 
    [[spell:12294]], and [[spell:7384]] on cooldown is crucial to 
    maintaining high damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_racial_bloodrage.jpg>) **Avoid Wasting Rage**  
  
    Unlike most resources, Rage starts from zero and decays while out of combat. 
    Using it effectively and efficiently will help maintain the rotation and 
    eliminate downtime spent waiting for more resources, both in combat and by 
    reducing the amount of time spent moving from one combat to another.

4.

### How to Gear Up as a Arms Warrior

While we always recommend simming yourself for ideal results, we do provide a
dedicated Arms gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated gear recommendations for Patch 12.1.5 and added new section with guidance for Venomstones.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated recommended weapon enchant and potion description to acknowledge odd statistical situations.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **25 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Added additional Slayer talent build.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated leveling build for Patch 12.1.
- **10 Aug. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated all gearing recommendations for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated gems, weapon enchant, and healing potion for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated build recommendations for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated build recommendations for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated class changes for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated with Sporefused Gear in Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated with Omnium Folio powers in Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **27 May 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Fix incorrect talent string.
- **23 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated alternative mythic+ build and multiple build descriptions.
- **22 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Added multitarget raid talent build.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **06 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Added disclaimer to Potion of Recklessness.
- **06 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Adjusted description of Battle Shout.
- **06 Apr. 2026 (this page):** Updated changelog.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Added Level 80 starting point build.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Added section on upgrading items using crests.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Midnight launch.
- **26 Feb. 2026 (this page):** Updated for Midnight launch.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated leveling build for Patch 12.0.1.
- **10 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated builds for Patch 12.0.1.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Added new FAQ section for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Added FAQ sections for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Added new Strengths & Weaknesses widget for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Added Dinar, updated recommended trinkets, and increased item levels for Turbo Boost.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Added Patch 11.2.5 changes.
- **06 Sep. 2025 (this page):** Added hotfix notes.
- **25 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Added temporary enhancements and expanded notes on weapon enchants.
- **10 Aug. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Added Sudden Death helper WeakAura.
- **10 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Clarified explanation regarding talent choices.
- **10 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated to account rotational changes in Season 3.
- **10 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Adjusted stat priority to better match other pages.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **20 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Changed Titan DISC Belt recommendation from Charged Bolts to Critical Chain after hotfix.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Added healing with Recouperate in Patch 11.1.7.
- **15 Jun. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Added Titan DISC Belt for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Added Combat Assistant Section for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Added Combat Assistant Section for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Added Patch 11.1.7 changes.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated gear lists, added Dinar purchase priority.
- **12 May 2025 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Minor update to Corruption section acknowledging Echoing Void as an alternative.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Added Patch 11.1.5 Cartel Chip recommendations.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Added Patch 11.1.5 Corruption recommendations.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** Added Wrecking Throw tip for Gallywix.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Separated rotations into toggled image frames.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Added Patch 11.1.5 class changes.
- **17 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Fixed broken Cyrce's Circlet link and added gems to embed.
- **17 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** More tips, talent tweaks, and Gallywix information.
- **02 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** Updated with raid tips and talent builds.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **16 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated Cyrce's Circlet to account for item level increasing hotfixes.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Added Cyrce's Circlet and validated for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Tagged recommended builds and validated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Tagged recommended talent builds and updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Simplified rotation and validated information for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated changes in Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Added brief section detailing upcoming Timewalking and Anniversary raid trinkets.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** Updated various tips and talent recommendations for The Silken Court.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated dungeon affix recommendations.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Added overview of Patch 11.0.5 changes.
- **03 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** More tips and new talent recommendations for The Silken Court.
- **23 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** Queen Ansurek tips and suggestions.
- **23 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Minor single target and execute rotation updates.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Updated for The War Within Season 1 launch.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for The War Within Season 1 launch.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** Page created.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for The War Within Season 1 launch.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Additional note regarding toggles.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for The War Within Season 1 launch.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **26 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Added Delve build, minor talent updates.
- **22 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Fixed error with Colossus toggle.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 (this page):** Updated for The War Within Pre-Season Launch.
- **26 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Update mainhand enchant.
- **26 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Note drop in the value of Haste, following In for the Kill buffs.
- **26 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Minor clarification for Skullsplitter.
- **26 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Minor build updates.
- **26 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Minor updates.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/arms-warrior-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/arms-warrior-mists-of-pandaria-remix-guide>)):** Page added.
- **12 May 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated talent build and spell priorities.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated with new gear and bullion recommendations for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated rotation for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Minor update to introduction.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated with new builds for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated with new talent and rotation recommendations for Season 4.
- **22 Apr. 2024 (this page):** Updated with new tier set changes for Season 4.
- **25 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Minor adjustments to leveling tree, updated for Patch 10.2.6.
- **19 Mar. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Removed old weak auras, added new ones, and reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Expanded crafting recommendations and reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Minor update to recommended talents and reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Expanded recommended talent updates and reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Feb. 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Feb. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Feb. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Feb. 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **16 Jan. 2024 (this page):** Correct errant link to Fury pages.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **14 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Added Fyr'alath to overall BiS list (good luck).
- **14 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Added section emphasizing proper use of Fyr'alath.
- **14 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Minor updates clarifying recommended talents in selection tool.
- **14 Jan. 2024 (this page):** Overview of changes in Patch 10.2.5.
- **08 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated with new gear sets accounting for Sporecloak nerf.
- **08 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Correct error hiding low priority filler in Execute rotation.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2 and season 3.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for T31 builds and rotations in preparation for Season 3.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated talent builds for Patch 10.2 and Season 3 tier sets.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Reviewed for Patch 10.1.7.
- **12 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Minor formatting updates.
- **12 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Minor formatting updates.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5, to include Dawn of the Infinite gear.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.5, including alternate Skullsplitter build.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Minor updates for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated with no class changes for Patch 10.1.5.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.1
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated Onyx Annulet gem recommendations.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated Onyx Annulet gem recommendations.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.1
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7 with better default checkboxes.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.1
- **01 May 2023 (this page):** Updated for Patch 10.0.7.
- **04 Apr. 2023 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Swap to new by-level talent calculator format.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/arms-warrior-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated with Onyx Annulet information for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated with Onyx Annulet information for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **27 Feb. 2023 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Fixed misnaming of Bladestorm.
- **15 Feb. 2023 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated leveling build and talent choices by level.
- **02 Feb. 2023 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Removed erroneous Fury reference.
- **02 Feb. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated Bladestorm talent build.
- **02 Feb. 2023 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation tool.
- **02 Feb. 2023 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated talent builds.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated build for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated builds for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Talent build updated for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Fix talent selector formatting.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **18 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Update Fervor of Battle use and description.
- **18 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Update Fervor of Battle use and description.
- **18 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Update Fervor of Battle use and description.
- **09 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Corrected Overpower's position in the rotation.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/arms-warrior-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/arms-warrior-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/arms-warrior-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/arms-warrior-patch-9-2-changes-analysis>)):** Page reviewed and approved for Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/arms-warrior-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/arms-warrior-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/arms-warrior-patch-9-1-changes-analysis>)):** Removed PTR references.
- **19 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/arms-warrior-patch-9-1-changes-analysis>)):** Page created with preliminary Patch 9.1 information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **29 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-the-eternal-palace-raid-guide>)):** More tips, no longer recommending Worldvein Resonance.
- **13 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-the-eternal-palace-raid-guide>)):** More tips added, especially for Azshara; several Essence recommendations changed.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **05 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-crucible-of-storms-raid-guide>)):** Updated Uu'nat talents.
- **09 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-crucible-of-storms-raid-guide>)):** Added additional Mythic difficulty tips.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **12 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated tips for Jaina.
- **22 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added new tips.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** Guide was created.
- **18 Jan. 2019 ([Uldir page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** Updated for Season 2.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** Reviewed and up to date for Patch 8.1.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** Updated for Uldir release.
- **13 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** Page added (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Arms Warrior leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Warrior leveling guide](<https://www.icy-veins.com/wow/warrior-leveling-guide>).

1.

### Arms Warrior Leveling Guide for Midnight

Arms Warrior is very straightforward while leveling, 
starting off with only [[spell:260708]], but not gaining more 
worthwhile multi-target tools until around level 30.

Past that point, Warriors start to become quite competent, regularly pulling
several mobs together and cleaving them down without fear, thanks to
[[spell:118038]] mitigating damage and [[spell:34428]] to heal back
up. By rotating several different cooldowns, Arms Warriors will eventually
chain from pull to pull with little to no downtime.

Always initiate combat with [[spell:100]] when able, using
[[spell:57755]] or [[spell:6544]] to pull more as desired. When
facing several targets, use [[spell:260708]], [[spell:845]],
[[spell:7384]], and [[spell:772]] if they are expected to live long
enough for the bleed to tick out.

In between those abilities, or when there are only one or two targets left,
use [[spell:12294]] and [[spell:163201]] to kill off priority targets.
Cooldowns such as [[spell:167105]] and [[spell:227847]] can be used
liberally, but are not often needed. So try to save them for bigger packs
or harder targets.

The [[spell:1231418]] ability can be used to 
quickly regain health between combat, without the need to carry level
appropriate food around, since it always restores 50% of maximum health.

1.1.

#### Leveling Gear Options

When leveling up, equipping the highest item level pieces of gear is 
generally ideal. The major exceptions to this rule are some trinkets and Rings
or Necklaces featuring two secondary stats instead of just one.

When using Heirloom items, we recommend using those with Critical Strike
and Haste, as they will slightly improve Rage economy while leveling.

1.2.

#### Useful Leveling Consumables for Midnight

At the start of every new expansion, the one thing in everyone's mind would be how to reach
the maximum level. For Midnight, the max level is 90. There are various items
to boost your leveling speed and efficiency, allowing you to make the best
out of your playtime.

- [[item:132516]] — Massive movement speed boost that works when
  Mounts do not, and much faster than ground mounts.
- [[item:109076]] — Lets you glide off of ledges and cover vast
  distances quickly.
- [[item:172063]] — Gives you a speed buff when you kill
  enemies.
- [[item:168412]] — Do not forget this Mount Equipment to
  make your mounts faster on the ground.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have an
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Arms Midnight Leveling Build
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzMzYGAAAghpBzYmZbZmZmZYYmBAAAAwYzMwEAbmxwCMwMsRjBLAzgZbGmtZ2GMzAAmZYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzMzYGAAAghpBzYmZbZmZmZYYmBAAAAwYzMwEAbmxwCMwMsRjBLAzgZbGmtZ2GMzAAmZYA"
}
```
:::

:::details 来源计算器编码
```
#HB-DJPIBlFOakzqYEFJJNZw1cu0EAYECCED7TB-CDFBAEGQYA78Yx1NJMcpSRBK7ryTKlI-AAAA-UMECOIM0wsAEZB-
```

:::

2.1.

#### War Mode Talents for Leveling

The following PvP talents are recommended for
leveling and doing solo / small group PvE content. You may find that different
PvP talents work better for you depending on your playstyle. Experimentation is
encouraged!

1. [[spell:198817]] adds a separate off-global cooldown buff, which
   increases the overall damage of [[spell:12294]].
2. [[spell:213915]] boosts the value of [[spell:23920]], providing
   both more offensive and defensive value in exchange for a slightly longer
   cooldown.
3. [[spell:206572]] grants extra mobility, which is always useful while 
   leveling.

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider
to select your level, and watch as the leveling rotation grows with each
level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 2 起：**Cast [[spell:100]] to initiate combat
   whenever possible.
2. **等级 10 起：**Cast [[spell:260708]] to hit a second
   target with single-target attacks.
3. **等级 69 起：**Cast [[spell:228920]] against groups of enemies
   or individual strong targets.
4. **等级 33 起：**Cast [[spell:772]] to apply Rend to more than three targets, only if they will survive the majority of the debuff duration.
5. **等级 5 起：**Cast [[spell:34428]] for free damage and healing after killing an enemy.
6. **等级 3–10：**Cast [[spell:23922]] to deal damage, if still using a shield.
7. **等级 25 起：**Cast [[spell:167105]] to deal increased damage
   against the primary target.
8. **等级 71 起：**Cast [[spell:436358]] on cooldown for a high burst multi-target damage.
9. **等级 11 起：**Cast [[spell:12294]] as the primary damage dealing ability.
10. **等级 10 起：**Cast [[spell:163201]] whenever possible.
11. **等级 13–14：**Cast [[spell:7384]] as a free filler.
12. **等级 15 起：**Cast [[spell:7384]] as a free filler and to
    increase the damage of [[spell:12294]] or [[spell:845]].
13. **等级 1–8：**Cast [[spell:1464]] to deal damage to a single target.
14. **等级 9–30：**Cast [[spell:1464]] to deal damage to a single target or [[spell:1680]] against multiple.
15. **等级 31 起：**Cast [[spell:1464]] to deal damage to a single target or [[spell:845]] against multiple.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated leveling build for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **02 Mar. 2026:** Added Level 80 starting point build.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated leveling build for Patch 12.0.1.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added healing with Recouperate in Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **12 May 2024:** Updated talent build and spell priorities.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **25 Mar. 2024:** Minor adjustments to leveling tree, updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **04 Apr. 2023:** Swap to new by-level talent calculator format.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **15 Feb. 2023:** Updated leveling build and talent choices by level.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Arms Warrior in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Arms Warrior

Welcome to our Easy Mode Page! This section is intended for players who are new
to the game or class, have no intentions of raiding Mythic difficulty, and want a
straightforward rundown of how the specialization plays without the overwhelming
priority details needed for optimal play.

Arms is a straightforward damage dealer that focuses on big hits and bleeds.
While the base rotation is not very complicated, talents can add extra attacks
or replacement abilities in order to allow customization, though it also means
more play styles to learn. The build showcased here is a simple yet effective
play style good for all types of game content and is meant to help new
players learn the fundamentals of Arms.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_charge.jpg>) **Avoid Downtime**  
  
    Arms generates the majority of its Rage from auto-attacks, so reducing the 
    amount of time spent chasing, running out mechanics, or otherwise not 
    hitting a target is critical to maximizing performance.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_savageblow.jpg>) **Keep Abilities on Cooldown**  
  
    Arms spends resources in small amounts, but the cooldown of abilities sets 
    the pace of the rotation. Keeping [[spell:167105]], 
    [[spell:12294]], and [[spell:7384]] on cooldown is crucial to 
    maintaining high damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_racial_bloodrage.jpg>) **Avoid Wasting Rage**  
  
    Unlike most resources, Rage starts from zero and decays while out of combat. 
    Using it effectively and efficiently will help maintain the rotation and 
    eliminate downtime spent waiting for more resources, both in combat and by 
    reducing the amount of time spent moving from one combat to another.

In Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer is generally the best hero spec after the 
initial leveling, making it the preferred choice in most content. In addition 
to strong priority damage, it has the advantage of giving up very little of 
that single target performance when taking multi-target talents.

2.

### Beginner's Guide to Arms Warrior in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer   Single-Target Talents

2.1.

#### Beginner Single-Target Talents for Arms Warrior

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

The single-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer raid build also provides a surprising
amount of multi-target capability through [[spell:260708]] and [[spell:227847]],
allowing it to cover most raid encounters with smaller amounts of adds.

2.2.

#### Flexible Talents

Without the need for stuns, virtually all desirable talents are already taken, so there is not much need for swaps outside of specific circumstance:

- [[spell:384110]] can be taken in place of [[spell:1271925]] or [[spell:12323]] any time there are shielded targets.
- [[spell:1280961]] has amazing defensive potential as long as Defensive Stance is actively used, though its offensive benefit is lackluster at best.
- If facing two targets with any degree of frequency, swap [[spell:1261048]] for [[spell:1261049]] and [[spell:845]] for [[spell:1261050]].

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmZzMzMzgxMDAAAAgZWmZAhxyyALgBMDTgZwGYmx2YbglZWGgZGAMDDA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPThLPDIMWGFZlpxRWSSEAQBCCDz7DE-CDFGOQCISYceqqAFG20xTRBSy0E1nYE-AAAA-HIcg0AEQQhhCzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer   Dungeon Talents

2.3.

#### Beginner Dungeon Talents for Arms Warrior

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

The Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer build brings exceptional multi-target damage 
with [[spell:7384]] and [[spell:444775]], while giving up very little 
single target.

2.4.

#### Flexible Talents

While the specialization tree is fairly static, the class tree has a lot of room for customization:

- [[spell:384110]] can be taken in place of [[spell:1271926]] any time there are shielded targets. Taking [[spell:1271948]] instead of [[spell:1280961]] may also be worthwhile, trading some defensive benefit for a ranged interrupt.
- [[spell:1280961]] has amazing defensive potential as long as Defensive Stance is actively used, though its offensive benefit is lackluster at best.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTgZwGYmhhBzyMbDwMDAmhBA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlnBEGLjiqsy04kkoEBAUggww8+AB-CDFGQCIASYceqqs4AHGu0IZaiqj3nIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### Arms Warrior   Basic Rotation

2.5.

#### Beginner Arms Warrior DPS Rotation

The simplified rotation outlined below encompasses both single and multiple
target situations using our suggested talents. While the Arms playstyle is
relatively straightforward, remember that Slam is only used to consume Heroic 
Strike procs once Execute becomes available.

- Cast [[spell:260708]] whenever there is more than one target.
- Cast [[spell:845]] or [[spell:772]] to apply or refresh the Rend debuff when less than 4 seconds are remaining.
- Cast [[spell:107574]] on cooldown whenever enemies will live long enough to benefit from the full duration.
- Cast [[spell:167105]] on cooldown, aligned with other cooldowns as much as possible.
- Cast [[spell:227847]] during Colossus Smash.
- Cast [[spell:845]] on cooldown against multiple targets.
- Cast [[spell:1269383]] whenever available.
- Cast [[spell:163201]] whenever it is available.
- Cast [[spell:12294]] on cooldown.
- Cast [[spell:7384]] on cooldown.
- Cast [[spell:163201]] or [[spell:1464]] when nothing else is available.

All builds focus on the same principle of spending Rage to trigger 
[[spell:184783]], while taking advantage of the various procs within the 
Arms rotation. Remember that the majority of Rage is generated through 
auto-attacks, so ensuring high uptime on the target is crucial to maintaining 
the rotation, but care should be taken to ensure you do not overspend.

2.5.1.

##### Apex Talent: ![Master of Warfare Icon](<https://static.icy-veins.com/images/wow/large_icons/misc_legionfall_warrior.jpg>) Master of Warfare

The Arms Warrior apex talent, [[spell:1269314]], is an active proc 
which increases the value of Slam and applies a damage enhancing buff. While it 
largely takes the place of regular casts of Slam, it will also be periodically 
weaved into the single target Execute phase, though the ability will always be 
used automatically in multi-target through [[spell:202316]].

- The first point is a proc which causes [[spell:1269383]] to replace 
  Slam, giving it a much higher priority and triggering a small armor 
  penetration buff. While this buff stacks, each has its own duration, resulting 
  in the buff constantly stacking and decaying, making it easy to treat 
  passively and ignore.
- The second and third points further enhances the Master of Warfare buff, 
  though has no rotational impact, since all of those abilities continue to be 
  used in the same manner.
- The final point causes Heroic Strike to apply a separate buff, increasing 
  the magnitude of Colossus Smash, which can be quite strong, given such a high 
  uptime on the ability.

2.5.2.

##### Season 2 Tier Set

The new Midnight Season 2 tier set bonuses greatly enhance [[spell:1464]] 
and [[spell:1269383]], while also passively increasing other rotational 
abilities. Slam gets automatically cast by [[spell:202316]] when facing 
multiple targets and the stacking builds itself up while waiting Slam or 
Heroic Strike to be used, so the set plays pretty passively in most cases.

- [[spell:1296643]] - Mortal Strike and Execute damage 
  increased by 10% and when you Slam a target, Slam also deals (100% of Attack 
  Power) damage to enemies within 8 yds of it. Deals reduced damage beyond 5 
  targets.
- [[spell:1296644]] - Overpower damage increased by 15%. 
  Mortal Strike and Overpower increase the damage of your next Slam by 20%, 
  stacking up to 5 times.

### Arms Warrior   Defensive Spells

2.6.

#### Defensive Spells for Arms Warrior

Arms Warriors have several defensive abilities that can be used
individually or layered for stronger damage mitigation. Although lacking any
true immunity or cheat death, this can make them very capable of surviving
predictable incoming damage.

- [[spell:118038]] is the main defensive cooldown, reducing damage and
  parrying most front-facing melee attacks. It can also be used to great effect
  in combination with a well-timed [[spell:355]] or [[spell:3411]] to take
  pressure off of other players.
- [[spell:23920]] is a very powerful tool that not only reduces
  incoming magic damage, but can deflect or even reflect spells entirely. While
  not all spells will be reflected to deal damage to the attacker, simply
  deflecting their application can significantly reduce damage, if not
  trivialize many dangerous abilities outright.
- [[spell:386208]] is one of the most reliable cooldowns in the
  game, featuring an extremely short 3-second cooldown, though mitigated by the
  associated reduction in damage. While this makes it somewhat unpopular, smart 
  use of the ability can dramatically increase survivability.
- [[spell:190456]] no longer has a Rage cost, but now has a slightly 
  longer cooldown and is on the GCD. It layers very well with other defensive 
  cooldowns before incoming damage.
- [[spell:202168]] is a powerful on-demand heal on a short cooldown 
  that resets when an enemy is killed. This makes it regularly available and an
  important reactionary tool that should be used regularly.
- [[spell:29838]], [[spell:382549]], and [[spell:383103]] are
  extra healing effects that trigger passively and do not need to be
  micromanaged.

### Arms Warrior   Stat Priority

2.7.

#### Stat Priority for Arms Warrior

The general stat priority for a Arms Warrior is seen
below. This is very much a rough guideline and is designed for players who do
not wish to sim their character. If you are simming your character, please
disregard this stat priority completely and follow your sim!
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>).

Item Level

Critical Strike

Haste

Mastery

Versatility

Critical Strikes more than double all damage dealt and increase Rage
generation from auto-attacks, which reduces downtime in the rotation.
Mastery increases damage taken by enemies, while Haste compresses the rotation,
increasing auto-attack speed and reducing the time between ability casts.
Finally, Versatility is a static damage increase, which also reduces damage
taken by half the amount.

### Blizzard   Combat Assistant

2.8.

#### Combat Assistant for Arms Warrior

[Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>), added in Patch 11.1.7, is comprised of two
options meant to help players with combat rotations and gameplay.

The first is Assisted Highlight, which recommends the next rotational
ability that players should use, in order to help them learn how to better
play their specialization. While not a perfectly min-maxed rotation, it is
perfectly serviceable, losing an average of around 5% compared to more
complicated manual ones. However, it does not attempt to recommend offensive
cooldowns, defensives, utility abilities, or other off-GCD abilities such as
[[spell:100]], so players must be mindful to use these on their own.

The second option is the Single-Button Assistant, which is a new button
placed on the action bar which automatically cycles through each ability in
the rotation when pressed. Using the same rotation as the Assisted Highlight,
it is serviceable, though an additional 25% penalty is placed on the global
cooldown to keep this from being an easily competitive option. This results in a
roughly ~20-25% loss in performance. Therefore, it is only recommended for
brand new players, players in trivial content, or those who are otherwise
unable to keep up with regular gameplay.

In both cases, using cooldowns such as [[spell:107574]] and
[[spell:260708]] can be as easy as macroing them to the
Single-Button Assistant or a common ability like [[spell:167105]],
though players may also opt to continue using them  manually, as described in 
the rotation section.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Aug. 2025:** Adjusted stat priority to better match other pages.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added Combat Assistant Section for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Simplified rotation and validated information for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **26 Jul. 2024:** Minor updates.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated with new talent and rotation recommendations for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1
- **24 Jan. 2023:** Talent build updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Update Fervor of Battle use and description.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Arms Warrior in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Arms Warrior

Arms is enjoying one of its most powerful seasons in Mythic+ in Season 2, being 
one of the stronger damage dealers outside of specific meta comps. Arms unfortunately
only excels in a couple of raid encounters, but still remains above average 
overall.

- **Single Target -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer continues to be significantly 
    ahead in single-target and most raid encounters.
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer has risen to be the main multi-target 
    damage dealing hero tree choice. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus can still offer higher 
    multi-target burst, but it loses much more single-target value in the 
    process.

**Quick Start Import Codes:**

:::talents Arms Single-Target - Slayer
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmZzMzMzgxMDAAAAgZWmZAhxyyALgBMDTgZwGYmx2YbglZWGgZGAMDDA"
}
```
:::

:::talents Arms Multi-Target - Slayer
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZgJMW2GYBMgZYCZGsBmZsN2GYZmtBYmBAzwA"
}
```
:::

:::talents Arms Dungeons & Delves - Slayer
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTgZwGYmhhBzyMbDwMDAmhBA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Slayer

Single-Target Raid

recommended

Raid Multitarget

recommended

Mythic+ & Delves

recommended

Colossus

Multi-Target Raid

Mythic+ & Delves

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Single-Target Raid Talents

This single-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer raid build also provides a surprising
amount of multi-target capability through [[spell:260708]] and [[spell:227847]],
allowing it to cover most raid encounters with smaller numbers of adds.

1.2.

#### Flexible Talents

Without the need for stuns, virtually all desirable talents are already
taken, so there is not much need for swaps outside of specific circumstances:

- [[spell:384110]] can be taken in place of [[spell:1271925]] or
  [[spell:12323]] any time there are shielded targets.
- [[spell:1280961]] has amazing defensive potential as long as
  Defensive Stance is actively used, though its offensive benefit is lackluster
  at best.
- If facing two targets with any degree of frequency, swap
  [[spell:1261048]] for [[spell:1261049]] and [[spell:845]] for
  [[spell:1261050]].

### 天赋方案 0-1

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Mythic+ Dungeon Talents for Arms Warrior

Dungeons can encourage a mix of AoE and Single-Target talents, though they
are typically trash heavy, with single target bosses making up a smaller
percentage of the overall damage done.

The Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer build brings exceptional multi-target damage
with [[spell:7384]] and [[spell:444775]], while giving up very little
single target.

1.4.

#### Flexible Talents

While the specialization tree is fairly static, the class tree has a lot of room for customization:

- [[spell:1244088]] and [[spell:382260]] are useful for getting around
  a bit quicker, though neither are strictly required, while
  [[spell:1271926]] and [[spell:29838]] add fairly little that can
  always be forgone. [[spell:382767]] is a very good flex talent, since
  Arms rarely reaches max resources anyway.
- [[spell:384110]] can also be taken any time there are shielded adds,
  or combined with [[spell:1271948]] to create a ranged interrupt, though this
  requires giving up some defensive value from [[spell:1280961]].
- [[spell:1280961]] has amazing defensive potential as long as
  Defensive Stance is actively used, though its offensive benefit is lackluster
  at best.

### 天赋方案 0-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Mythic+ Dungeon Talents for Arms Warrior

Dungeons can encourage a mix of AoE and Single-Target talents, though they
are typically trash heavy, with single target bosses making up a smaller
percentage of the overall damage done.

The Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer build brings exceptional multi-target damage
with [[spell:7384]] and [[spell:444775]], while giving up very little
single target.

1.6.

#### Flexible Talents

While the specialization tree is fairly static, the class tree has a lot of room for customization:

- [[spell:1244088]] and [[spell:382260]] are useful for getting around
  a bit quicker, though neither are strictly required, while
  [[spell:1271926]] and [[spell:29838]] add fairly little that can
  always be forgone. [[spell:382767]] is a very good flex talent, since
  Arms rarely reaches max resources anyway.
- [[spell:384110]] can also be taken any time there are shielded adds,
  or combined with [[spell:1271948]] to create a ranged interrupt, though this
  requires giving up some defensive value from [[spell:1280961]].
- [[spell:1280961]] has amazing defensive potential as long as
  Defensive Stance is actively used, though its offensive benefit is lackluster
  at best.

### 天赋方案 1-0

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus Multi-Target Raid Talents

This multi-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus raid build provides high multi-target
capability through [[spell:845]] and [[spell:436358]], allowing it to
sustain damage on raid encounters with large or frequent waves of adds.

1.8.

#### Flexible Talents

Without the need for stuns, virtually all desirable talents are already taken, so there
is not much need for swaps outside of specific circumstances:

- [[spell:1271925]] has limited use cases in most PvE content, but can be taken in place
  of [[spell:384110]], [[spell:12323]], [[spell:382260]], or [[spell:1244088]], as desired.
- [[spell:1280961]] has amazing defensive potential as long as Defensive Stance is
  actively used, though its offensive benefit is lackluster at best.

### 天赋方案 1-1

1.9.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus Mythic+ Dungeon Talents for Arms Warrior

Dungeons can encourage a mix of AoE and Single-Target talents, though they
are typically trash heavy, with single target bosses making up a smaller
percentage of the overall damage done.

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus brings very high multi-target damage through the
use of [[spell:845]] and [[spell:12294]] greatly reducing the cooldown
on [[spell:436358]], though its single target boss damage is very lackluster
and [[spell:163201]] is rarely used.

1.10.

#### Flexible Talents

While the specialization tree is fairly static, the class tree has a lot of room for
customization:

- [[spell:1244088]] and [[spell:382260]] are useful for getting around a bit
  quicker, easily swapped with [[spell:1271926]] or [[spell:382767]] since
  Arms rarely reaches max resources.
- [[spell:1271925]] has limited use cases in most PvE content, but can be swapped
  with [[spell:5246]] or [[spell:12323]] in the few cases it becomes
  relevant.
- [[spell:1280961]] has amazing defensive potential as long as Defensive Stance is
  actively used, though its offensive benefit is lackluster at best. [[spell:382764]]
  is typically the best drop in heavy multi-target content, though this also necessitates
  taking [[spell:1243660]] instead of [[spell:1271948]].

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmZzMzMzgxMDAAAAgZWmZAhxyyALgBMDTgZwGYmx2YbglZWGgZGAMDDA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPThLPDIMWGFZlpxRWSSEAQBCCDz7DE-CDFGOQCISYceqqAFG20xTRBSy0E1nYE-AAAA-HIcg0AEQQhhCzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZgJMW2GYBMgZYCMD2AzM2GbDsMz2AMzAgZYA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPThLPDIMYEFZpxRWSKTEAQBCCDz7DE-CDFGOQCISYceqqsAHGu0IZaiqj3nIUE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTgZwGYmhhBzyMbDwMDAmhBA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlnBEGLjiqsy04kkoEBAUggww8+AB-CDFGQCIASYceqqs4AHGu0IZaiqj3nIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzwYGAAAghphZYmZzMzMzgxMDAAAAgZ2mZgJAWMjhNYgZYjGDWAzM2GbzwsNz2gZGAgZYA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPThLPDIKWGFZlpxRWSSEAQBCCDz7DE-CDFGQCIASYceqqs4AHG21T60E1nIUUG-AAAA-AcgUphYhBTgwwC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzMzYGAAAghphxYmZzMzMzYmxMDAAAAgxmZgJAWMjhNYgZYjGDWAzMM2mhZbmtBzMAAGGA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlBEGLjiqsy04ILJRJCAoABhh59BC-CDFGQCIASYceqqs4AHGu01TRBSKV2nI-AAAA-AcgUphYhBTgwwC-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), which offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend the following bonuses, though they can be swapped at any time, 
so feel free to experiment with other options or simulated recommendations for 
your own gearing.

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279612]]
- [[spell:1279616]]

3.

### Apex Talent: ![Master of Warfare Icon](<https://static.icy-veins.com/images/wow/large_icons/misc_legionfall_warrior.jpg>) Master of Warfare

The Arms Warrior apex talent, [[spell:1269314]], is an active proc 
which increases the value of Slam and buffs other rotational abilities. While 
it largely takes the place of regular casts of Slam, it will also be 
periodically weaved into the single target Execute phase. In multi-target, 
however, the ability will always be used passively with 
[[spell:202316]].

- The first point is a proc which causes [[spell:1269383]] to replace 
  Slam, giving it a much higher priority and triggering a small armor 
  penetration buff. While this buff stacks, each has its own duration, resulting 
  in the buff constantly stacking and decaying, making it easy to treat 
  passively and ignore.
- The second and third points further enhances the Master of Warfare buff, 
  though has no rotational impact, since all of those abilities continue to be 
  used in the same manner.
- The final point causes Heroic Strike to apply a separate buff, increasing 
  the magnitude of Colossus Smash, which can be quite strong, given such a high 
  uptime on the ability.

4.

### Hero Talents

Arms Warriors have a choice between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus, each with their own 
strengths and focus, though generally very similar builds and gameplay.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer is focused on [[spell:163201]] and [[spell:227847]], with the main 
gameplay difference being increased [[spell:29725]] procs and a stronger 
Execute phase. It tends to be the better choice for raiding and single target 
encounters, though is currently enjoying a renewed focus in Mythic+ as well.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus is focused on [[spell:12294]], Bleeds, and [[spell:436358]], 
represented through increased Mortal Strike usage and a unique form of 
cooldown reduction for its signature ability. It tends to be better against 
multiple targets than single, and is used more frequently in Mythic+ instead of 
raid encounters.

5.

### PvP Talents (War Mode)

Since Battle for Azeroth, players have the option to go into "War Mode,"
allowing them to participate in PvP combat with other players. Enabling War
Mode provides the following benefits:

- PvP talents enabled in the outdoor world
- 10% increase in World Quest rewards at maximum level
- 10% more experience gained while leveling
- Earn Conquest Points, which can reward gear every week

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

1. [[spell:198817]] adds a separate off-global cooldown buff, which
   increases the overall damage of [[spell:12294]].
2. [[spell:213915]] boosts the value of [[spell:23920]], providing
   both more offensive and defensive value in exchange for a slightly longer
   cooldown.
3. [[spell:206572]] grants extra mobility, which is always useful while 
   leveling.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Aug. 2026:** Added additional Slayer talent build.
- **10 Aug. 2026:** Updated build recommendations for Patch 12.1.
- **15 Jun. 2026:** Updated with Omnium Folio powers in Patch 12.0.7.
- **27 May 2026:** Fix incorrect talent string.
- **23 Apr. 2026:** Updated alternative mythic+ build and multiple build descriptions.
- **22 Apr. 2026:** Added multitarget raid talent build.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated builds for Patch 12.0.1.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Tagged recommended talent builds and updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1 launch.
- **26 Aug. 2024:** Added Delve build, minor talent updates.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **26 Jul. 2024:** Minor build updates.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated with new builds for Season 4.
- **19 Mar. 2024:** Expanded recommended talent updates and reviewed for Patch 10.2.6.
- **15 Feb. 2024:** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **14 Jan. 2024:** Minor updates clarifying recommended talents in selection tool.
- **06 Nov. 2023:** Updated talent builds for Patch 10.2 and Season 3 tier sets.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **12 Jul. 2023:** Minor formatting updates.
- **10 Jul. 2023:** Minor updates for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1
- **02 Feb. 2023:** Updated talent builds.
- **24 Jan. 2023:** Updated builds for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Update Fervor of Battle use and description.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Arms Warrior in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Arms Warrior Gameplay and Rotation Guide

The Arms rotation is a conditional priority list, which can change
depending on talent choice. Use the checkboxes below to make the appropriate
customizations and make sure that [[spell:386164]] is always toggled on!
Note that the same toggles are used for both the single and multi-target
rotations.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Multitarget

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus

Single Target

Multitarget

Talent Selection

[[spell:107574]]

[[spell:845]]

[[spell:227847]]

[[spell:1261060]]

[[spell:444774]]

[[spell:316440]]

[[spell:228920]]

### Single Target Opener

[[spell:100]]

**适用条件：Colossus（启用）。**

[[spell:12294]]

**适用条件：Cleave（启用）。**

[[spell:845]]

**适用条件：Cleave（未启用）。**

[[spell:772]]

**适用条件：Colossus（启用）；Ravager（启用）。**

[[spell:228920]]

**适用条件：Avatar（启用）。**

[[spell:107574]]

[[spell:167105]]

**适用条件：Slayer（启用）；Bladestorm（启用）。**

[[spell:227847]]

[[spell:1269383]]

[[spell:12294]]

**适用条件：Colossus（启用）。**

[[spell:436358]]

[[spell:7384]]

**适用条件：Colossus（启用）。**

[[spell:12294]]

**适用条件：Slayer（启用）。**

[[spell:163201]]

[[spell:29725]]

[[spell:7384]]

[[spell:12294]]

1.1.

#### Single Target Opener for Arms Warrior

Always open with [[spell:100]] when able.

1. **适用条件：Colossus（启用）。** Cast [[spell:12294]]
2. **适用条件：Cleave（启用）。** Cast [[spell:845]] to apply Rend
3. **适用条件：Cleave（未启用）。** Cast [[spell:772]] to apply Rend
4. **适用条件：Colossus（启用）；Ravager（启用）。** Cast [[spell:228920]] just before Colossus Smash
5. **适用条件：Avatar（启用）。** Cast [[spell:107574]]
6. Cast [[spell:167105]]
7. **适用条件：Slayer（启用）；Bladestorm（启用）。** Cast [[spell:227847]]
8. Cast [[spell:1269383]]
9. Cast [[spell:12294]]
10. **适用条件：Colossus（启用）。** Cast [[spell:436358]]
11. Cast [[spell:7384]]
12. **适用条件：Colossus（启用）。** Cast [[spell:12294]]
13. **适用条件：Slayer（启用）。** Cast [[spell:163201]] with [[spell:29725]]
14. Cast [[spell:7384]]
15. Cast [[spell:12294]]

Proceed with the normal priority below.

### Single Target Rotation

1.2.

#### Single Target Rotation for Arms Warrior

The Arms Warrior rotation is a priority list, in which each time an ability is cast, the user should start back at the top of the list, establishing a hierarchy of importance.

:::details Tier Set and the Rotation
The Season 2 tier set enhances Slam and Heroic Strike with a stacking damage buff and AoE proc, while buffing rotational abilities: Mortal Strike, Overpower, and Execute. Although the tier sets buffs the damage of Slam, it does not need to be tracked or explicitly used at five stacks.

- [[spell:1296643]]
- [[spell:1296644]]

:::

The general goal of the rotation is to fill as many global cooldowns as possible by making use of procs to help avoid either overcapping or becoming starved of Rage.

1. **适用条件：Colossus（启用）。** Cast [[spell:12294]]
2. **适用条件：Cleave（未启用）。** Cast [[spell:772]] to apply or refresh Rend, when less than 10 seconds remaining and Colossus Smash ready to use
3. **适用条件：Cleave（启用）。** Cast [[spell:845]] to apply or refresh Rend, when less than 10 seconds remaining and Colossus Smash ready to use
4. **适用条件：Ravager（启用）。** Cast [[spell:228920]] just before Colossus Smash
5. **适用条件：Avatar（启用）。** Cast [[spell:107574]] on cooldown
6. Cast [[spell:167105]] on cooldown
7. **适用条件：Colossus（启用）。** Cast [[spell:436358]] during [[spell:167105]]
8. **适用条件：Colossus（启用）。** Cast [[spell:1269383]]
9. Cast [[spell:163201]] with two stacks of [[spell:29725]]
10. **适用条件：Slayer（启用）。** Cast [[spell:163201]] if Bladestorm is off cooldown and [[spell:444769]] has less than 3 stacks, to apply its damage buff
11. **适用条件：Bladestorm（启用）。** Cast [[spell:227847]] during Colossus Smash
12. **适用条件：Slayer（启用）。** Cast [[spell:1269383]]
13. **适用条件：Slayer（启用）；Opportunist（启用）。** Cast [[spell:7384]] with two stacks of [[spell:444774]]
14. Cast [[spell:12294]]
15. Cast [[spell:163201]] with [[spell:29725]]
16. Cast [[spell:7384]]
17. **适用条件：Cleave（启用）。** Cast [[spell:845]] to refresh Rend with less than 5 seconds remaining
18. **适用条件：Cleave（未启用）。** Cast [[spell:772]] to refresh Rend with less than 5 seconds remaining
19. Cast [[spell:1464]]

1.3.

#### Execute Rotation

Upon the target reaching 35%, switch to the Execute rotation.

1. **适用条件：Ravager（启用）。** Cast [[spell:228920]] just before Colossus Smash
2. **适用条件：Avatar（启用）。** Cast [[spell:107574]] on cooldown
3. Cast [[spell:167105]] on cooldown
4. Cast [[spell:1269383]]
5. **适用条件：Colossus（启用）。** Cast [[spell:436358]] during [[spell:167105]]
6. **适用条件：Colossus（启用）。** Cast [[spell:12294]]
7. **适用条件：Bladestorm（启用）。** Cast [[spell:227847]] during Colossus Smash
8. **适用条件：Slayer（启用）。** Cast [[spell:12294]] with less than 3 seconds remaining on Rend or the [[spell:444773]] buff active
9. **适用条件：Slayer（启用）；Opportunist（启用）。** Cast [[spell:7384]] with two stacks of [[spell:444774]]
10. **适用条件：Slayer（启用）；Deep Wounds（启用）。** Cast [[spell:163201]] with [[spell:29725]] or more than 40 Rage
11. **适用条件：Colossus（启用）；Deep Wounds（启用）。** Cast [[spell:163201]] with [[spell:29725]] or more than 75 Rage
12. Cast [[spell:7384]]
13. **适用条件：Deep Wounds（启用）。** Cast [[spell:163201]]
14. **适用条件：Deep Wounds（未启用）。** Cast [[spell:1464]]

### Multitarget Opener

[[spell:260708]]

[[spell:100]]

**适用条件：Cleave（启用）；Slayer（启用）。**

[[spell:845]]

**适用条件：Ravager（启用）；Colossus（启用）。**

[[spell:228920]]

**适用条件：Avatar（启用）。**

[[spell:107574]]

[[spell:167105]]

**适用条件：Bladestorm（启用）；Slayer（启用）。**

[[spell:227847]]

[[spell:845]]

**适用条件：Colossus（启用）。**

[[spell:845]]

**适用条件：Colossus（启用）。**

[[spell:845]]

**适用条件：Colossus（启用）。**

[[spell:12294]]

**适用条件：Colossus（启用）。**

[[spell:436358]]

**适用条件：Colossus（启用）。**

[[spell:845]]

[[spell:7384]]

**适用条件：Slayer（启用）。**

[[spell:163201]]

[[spell:845]]

1.4.

#### Multitarget Opener for Arms Warrior

[[spell:260708]] can be precast before entering combat, otherwise use on cooldown whenever there are multiple targets

Always open with [[spell:100]] when able.

1. **适用条件：Cleave（启用）；Slayer（启用）。** Cast [[spell:845]]
2. **适用条件：Ravager（启用）；Colossus（启用）。** Cast [[spell:228920]]
3. **适用条件：Avatar（启用）。** Cast [[spell:107574]]
4. Cast [[spell:167105]]
5. **适用条件：Bladestorm（启用）；Slayer（启用）。** Cast [[spell:227847]]
6. Cast [[spell:845]]
7. **适用条件：Colossus（启用）。** Continue casting [[spell:845]] with [[spell:1261056]]
8. **适用条件：Colossus（启用）。** Continue casting [[spell:845]] with [[spell:1261056]]
9. **适用条件：Colossus（启用）。** Cast [[spell:12294]]
10. **适用条件：Colossus（启用）。** Cast [[spell:436358]]
11. **适用条件：Colossus（启用）。** Cast [[spell:845]]
12. Cast [[spell:7384]]
13. **适用条件：Slayer（启用）。** Cast [[spell:163201]]
14. Cast [[spell:845]]
15. Proceed with the normal multitarget priority.

### Multitarget Rotation

1.5.

#### Multitarget Rotation for Arms Warrior

Against multiple targets, Arms Warriors will make heavy use of [[spell:845]], while [[spell:260708]] will allow the rest of their abilities to hit a second target. Due to this focus, there is no dedicated Execute phase when facing multiple targets.

:::details Tier Set and the Rotation
The Season 2 tier set enhances Slam and Heroic Strike with a stacking damage buff and AoE proc, while buffing rotational abilities: Mortal Strike, Overpower, and Execute. Because the effects can triggered by

[[spell:202316]]

, the set is largely passive.

- [[spell:1296643]]
- [[spell:1296644]]

:::

Cleave is the main ability when facing 3+ targets, automatically casting [[spell:1464]] or [[spell:1269383]], and also triggers several powerful talented effects. Slayer will also focus on using Execute with Sudden Death as much as possible, while Colossus will use Mortal Strike to help buff Demolish.

1. Cast [[spell:260708]] on cooldown
2. **适用条件：Slayer（启用）；Cleave（启用）。** Cast [[spell:845]] early to apply to Rend
3. **适用条件：Ravager（启用）；Colossus（启用）。** Cast [[spell:228920]] just before Colossus Smash
4. **适用条件：Avatar（启用）。** Cast [[spell:107574]] with or just before Colossus Smash
5. Cast [[spell:167105]]
6. **适用条件：Slayer（启用）。** Cast [[spell:845]] with 3 stacks of [[spell:334779]]
7. **适用条件：Bladestorm（启用）。** Cast [[spell:227847]]
8. **适用条件：Slayer（启用）。** Cast [[spell:163201]] with 2 stacks of [[spell:29725]]
9. Cast [[spell:845]]
10. **适用条件：Colossus（启用）。** Cast [[spell:12294]] with less than 10 stacks of [[spell:429634]]
11. **适用条件：Colossus（启用）。** Cast [[spell:436358]]
12. **适用条件：Slayer（启用）。** Cast [[spell:7384]] with 2 charges available
13. **适用条件：Slayer（启用）。** Cast [[spell:163201]] with [[spell:29725]]
14. Cast [[spell:7384]]
15. **适用条件：Slayer（启用）。** Cast [[spell:163201]]
16. Cast [[spell:12294]]
17. **适用条件：Colossus（启用）。** Cast [[spell:163201]] with Sudden Death
18. Cast [[spell:1464]]

### Playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer

1.6.

#### Playing as a Slayer

Slayer revolves around [[spell:29725]] and [[spell:227847]], though it is still important to use Mortal Strike and Cleave regularly.

- Consuming [[spell:29725]] reduces the cooldown of [[spell:227847]] based on the number of [[spell:445584]] stacks.
- [[spell:29725]] can stack twice, so it does not need to be used immediately, but should not be delayed unnecessarily to avoid overcapping.
- [[spell:227847]] triggers multiple talents, making it better to use early in [[spell:167105]], to maximize the overlap of buffing effects.
- [[spell:107570]] can be cast during Bladestorm for an extremely minor amount of extra damage, any time the stun is not needed.

### Playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus

1.7.

#### Playing as a Colossus

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus focuses on [[spell:436358]] instead of Bladestorm, though it fills the same gameplay role. Its cooldown is no longer dynamically reduced, though it will generally line up Colossus Smash, and the two should be used together as much as possible.

- [[spell:436358]] triggers several talented effects, making it better to use with Colossus Smash, rather than strictly on cooldown.
- [[spell:436358]] is a channeled effect that severely reduces movement speed, so proper positioning is key. Most off-GCD abilities, including [[spell:100]], [[spell:3411]], [[spell:6544]], [[spell:118038]], and [[spell:23920]] can all be used during the channel to help reduce damage or reposition as needed.
- [[spell:436358]] provides immunity to most stuns, knockbacks, and forced movement effects, though it should not be delayed for them unless absolutely necessary.

2.

### Midnight Season 2 Tier Set

The new Midnight Season 2 tier set bonuses enhance Slam and Heroic Strike 
with a stacking damage buff and AoE proc, while buffing rotational abilities: 
Mortal Strike, Overpower, and Execute. Although the tier sets buffs the damage 
of Slam, it does not need to be tracked or explicitly used at five stacks, and 
can simply be treated as a passive benefit.

- [[spell:1296643]] - Mortal Strike and Execute damage 
  increased by 10% and when you Slam a target, Slam also deals (100% of Attack 
  Power) damage to enemies within 8 yds of it. Deals reduced damage beyond 5 
  targets.
- [[spell:1296644]] - Overpower damage increased by 15%. 
  Mortal Strike and Overpower increase the damage of your next Slam by 20%, 
  stacking up to 5 times.

3.

### Class and Spec Mechanics Explained

In order to better explain the specifics of Arms Warrior mechanics, we have 
compiled a more detailed explanation on individual parts of our rotation, from 
important rotational mechanics that you need to pay attention to, to cooldowns 
and how to use them, so you can reach your full potential.

### Managing Rage

3.1.

#### Managing Rage

Arms biggest and most important gameplay concept is managing its primary 
resource, especially after being significantly reduced in Midnight. Nearly 
every ability Arms uses spends Rage, with the majority generated through 
auto-attack swings, resulting in two separate cadences that do not always sync 
up. Although in most cases this is not something you should need to think 
about, it is very important to recognize when high or dry streaks can occur, 
and attempt to avoid them, since skipping an extra cast of Slam is less 
important than missing a Mortal Strike.

Note that [[spell:462854]] grants extra auto-attack swings which also 
generate Rage, so always having a Shaman in the group is highly preferred, 
though less pronounced when playing Slayer.

### Maximizing Uptime

3.2.

#### Maximizing Uptime

Applicable to most classes, though particularly relevant to Arms Warriors, 
due to the reliance on auto-attacking for both Rage generation and damage. Any 
time spent off target is lost damage, with minimal means to recoup lost 
resources, unlike energy-based classes which will continue regenerating their 
resource up to its cap.

Due to the high mobility innate to the Warrior class, 
it is possible to play around boss mechanics and minimize downtime. If the 
boss is casting an area effect which requires players to run a certain 
distance away, a Warrior can instead continue attacking until the last few 
seconds, [[spell:6544]] away and immediately [[spell:100]] back 
as soon as the danger has passed.

Although Arms can have free global cooldowns due to a lack of Rage, 
planning for and ensuring you fill as many abilities as possible 
during the [[spell:167105]] debuff is paramount to maximizing Arms 
Warrior damage. When outside of those burst windows, its better to let Rage 
accrue, and only spend it so long as it will not keep you from casting a 
follow on [[spell:12294]].

### Cycle Charging

3.3.

#### Cycle Charging

A small optimization can be made by moving out of range of the target and
using [[spell:100]] to generate extra Rage during your rotation. Care
should be taken to do this between auto-attack swings when
[[spell:167105]] is not active. [[spell:6544]] can also be
used to create enough room to Charge for bosses with large hitboxes, which is
sometimes more specifically referred to as Heroic Charge.

### Using the Apex Talent

3.4.

#### Using the Apex Talent

[[spell:1269383]] has a higher priority than normal [[spell:1464]] 
casts, most particularly because it is used during the Execute rotation. 
However, because [[spell:1269314]] stacks have individual durations, 
there is no particular need or advantage to track it, making the buff easy to 
treat passively.

[[spell:1269307]] differs in that it stacks like a normal buff, 
however it is consumed as soon as [[spell:167105]] is cast, also making 
it a fairly passive buff. While players will average 2-3 stacks per cycle, the 
buff stacks up to 5 to ensure that lucky procs do not go to waste.

4.

### Important Cooldowns for Arms Warrior

### [[spell:167105]]

4.1.

#### Colossus Smash

The main cooldown for Arms Warriors provides a moderate burst window, not 
as large as many classes but very frequent due to the constant cooldown 
reduction of [[spell:152278]]. Almost always best to use strictly on 
cooldown, it can be circumstantially delayed for groups of adds or to align 
with other important damage phases, though care should be taken to recognize 
that its actual cooldown is a lot shorter than implied.

### [[spell:107574]]

4.2.

#### Avatar

Now also reduced by [[spell:152278]] to help keep it aligned with 
Colossus Smash, Avatar has lost all of its follow-on talents and much of its 
power, becoming a fairly minor cooldown with no inherent gameplay benefits.

### [[spell:227847]]

4.3.

#### Bladestorm

The signature Slayer ability is not the high-burst powerhouse it used to 
be, but continues to provide a reasonable amount of damage, with its single 
target value increased by [[spell:386628]]. One of the few abilities that 
does not spend rage, auto-attacks continue to hit during the channel, making 
it a pseudo-generator.

Keep in mind that the automatic Mortal Strikes caused by Unhinged can also 
trigger their own effects, such as [[spell:184783]] or 
[[spell:444775]].

Despite three stacks of [[spell:444769]] causing the button to glow, 
this is not an indicator of when Bladestorm should be used. It should almost 
always be used either on cooldown, or timed with groups of adds.

### [[spell:228920]]

4.4.

#### Ravager

The Colossus counterpart to Bladestorm, Ravager actually serves an entirely 
different role, being a predominantly multitarget ability whose minor damage 
is offset by the large buff to Cleave. Keeping it aligned with Colossus Smash 
can be difficult since Ravager is no longer affected by any form of cooldown 
reduction, but the two should be used together as much as possible to take 
advantage of [[spell:1261056]].

### [[spell:436358]]

4.5.

#### Demolish

The actual counterpart to Bladestorm, Demolish is used in almost the same 
way as both a single and multitarget cooldown. It has its own distinct form of 
cooldown reduction which does not always align with others, so keeping a 
careful eye on the various cooldown timers is paramount to maximizing its 
damage.

### [[spell:384110]]

4.6.

#### Wrecking Throw

While not a major cooldown per se, Wrecking Throw deals a surprisingly high 
amount of damage, making it a competent ranged filler that also silences 
enemies while [[spell:1271948]] is talented. However, its true power comes 
into play when facing targets with absorb shields, gaining a 500% damage 
multiplier to become the strongest single attack in the entire Warrior kit. In 
such situations, it should be used quickly, second only to Colossus Smash, in 
order to ensure it hits the target to quickly strip its shield.

4.7.

#### Defensive Abilities

Arms' primary survivability tool is [[spell:118038]], which is
exceptionally useful for immuning direct physical damage and can even be used
to tank raid bosses for a short time. [[spell:386208]] and
[[spell:190456]] can be used for more mitigation when expecting more
frequent spike damage, though be mindful that both come at a small cost of
damage output, while [[spell:202168]] and [[spell:29838]] can 
help heal damage back up instead. Finally, [[spell:23920]] is an 
extremely useful tool for mitigating or outright immuning many sources of 
magical damage.

The [Targeted 
Spells](<https://www.curseforge.com/wow/addons/targetedspells>) addon is very helpful in knowing when an enemy spell is being cast 
on you, though it cannot tell what that spell is or whether it is reflectable, 
so players will need to learn to identify them on their own.

Warriors also have access to [[spell:97462]], one of the few
defensive group cooldowns in the game. It is typically used to help the group
survive key encounter mechanics rather than as a personal cooldown. Keep in
mind that it is on the global cooldown, so be ready to use it when needed.

4.8.

#### Group Buffs

Warriors also bring [[spell:6673]], increasing all party and raid
members Attack Power by 5%, which should be applied before combat begins. Note 
that this buff only applies to melee attackers and Hunters, with no bonus for 
casting specializations.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **06 Apr. 2026:** Adjusted description of Battle Shout.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Aug. 2025:** Updated to account rotational changes in Season 3.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added Combat Assistant Section for Patch 11.1.7.
- **21 Apr. 2025:** Separated rotations into toggled image frames.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **23 Sep. 2024:** Minor single target and execute rotation updates.
- **09 Sep. 2024:** Additional note regarding toggles.
- **22 Aug. 2024:** Fixed error with Colossus toggle.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **26 Jul. 2024:** Minor clarification for Skullsplitter.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Feb. 2024:** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **14 Jan. 2024:** Added section emphasizing proper use of Fyr'alath.
- **08 Nov. 2023:** Correct error hiding low priority filler in Execute rotation.
- **06 Nov. 2023:** Updated for T31 builds and rotations in preparation for Season 3.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.0.7 with better default checkboxes.
- **27 Feb. 2023:** Fixed misnaming of Bladestorm.
- **02 Feb. 2023:** Updated rotation tool.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Fix talent selector formatting.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Update Fervor of Battle use and description.
- **09 Nov. 2022:** Corrected Overpower's position in the rotation.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Arms Warrior in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Arms Warrior

Welcome to our Arms Warrior Gear and BiS Page for
Midnight Season 2. Check this page to learn everything you need
to know about gearing a Arms Warrior, including the BiS Gear
from all sources, Raiding and Mythic+, information on the best Trinkets, Tier
Sets, or take a look at the [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) to learn more about new 
expansion features.

Generally speaking, item level is the best indicator of power, with higher 
item level pieces of gear almost always being stronger than ones which are 
slightly better itemized. However, trinkets can be an exception, due to their
varied special effects.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Arms Warrior. Keep in mind that there are some alternatives with similar stat distributions that perform similarly. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

Non-embellished crafted items are not as strong as their fully upgraded counterparts, but can make very strong filler pieces.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, it no longer matters which tier pieces Arms Warriors prioritize, since catalyzed tier pieces now inherit the original item stats and bonuses, making them identical and rendering the idea of "offpieces" obsolete. Players will still have more control over their gearing, though tokens with default stats still continue to drop from bosses as normal.

- Catalyst Helm: [[item:281239@JAACAAgNyA]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Catalyst Shoulders: [[item:239037@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Catalyst Chest: [[item:268222@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

That said, completing bonuses is much more important than optimizing itemization, so do not put any emphasis on holding out for better pieces.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271878@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Chest</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This list contains best gear specifically available from dungeons for Arms Warrior. Keep in mind that there are some alternatives with similar stat distributions, as well as several very competitive catalyst pieces that can be obtained from any dungeon. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

Non-embellished crafted items are not as strong as their fully upgraded counterparts, but can make very strong filler pieces.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, it no longer matters which tier pieces Arms Warriors prioritize, since catalyzed tier pieces now inherit the original item stats and bonuses, making them identical and rendering the idea of "offpieces" obsolete. Players will still have more control over their gearing, though tokens with default stats still continue to drop from bosses as normal.

- Catalyst Helm: [[item:251229@JAACAAgNyA]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Catalyst Shoulder: [[item:239037@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Catalyst Chest: [[item:251151@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Catalyst Hands: [[item:251214@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Catalyst Legs: [[item:273776@JAACAAgNyA]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

That said, completing bonuses is much more important than optimizing itemization, so do not put any emphasis on holding out for better pieces, so all five options are presented.

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): Contains the most pieces, including the best weapon.
- [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>): Also has several pieces, making it a more effective farm.
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): Has a very good ring, which provides important stats.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:273781@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Waist</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271455@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271459@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:250229@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273782@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the best gear specifically available from raids for Arms Warrior. Keep in mind that there are some alternatives with similar stat distributions that perform similarly. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

Non-embellished crafted items are not as strong as their fully upgraded counterparts, but can make very strong filler pieces.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, it no longer matters which tier pieces Arms Warriors prioritize, since catalyzed tier pieces now inherit the original item stats and bonuses, making them identical and rendering the idea of "offpieces" obsolete. Players will still have more control over their gearing, though tokens with default stats still continue to drop from bosses as normal.

- Catalyst Helm: [[item:281239@JAACAAgNyA]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Catalyst Chest: [[item:268222@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Catalyst Legs: [[item:271878@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

That said, completing bonuses is much more important than optimizing itemization, so do not put any emphasis on holding out for better pieces.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271444@JAACAAgNyA]]&#10;&#10;<div><span>BoE Trash Drop</span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271455@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Chest</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Arms Warrior

There are several trinkets available in Season 2, though 
there are very few on-use trinkets this season, with the majority being random 
damage or stat buffs, which have little gameplay value and do not benefit from 
class effects such as [[spell:107574]] or [[spell:167105]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Arms Warrior Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Both Heroes</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270175]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:250259]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:193762@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:270163]]</li>&#10;<li>[[item:273795]]</li>&#10;<li>[[item:158367]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Patch 12.1 continues the bonus roll system, allowing players to earn a 
Nebulous Voidcore bonus roll in lieu of taking an item from the Great Vault. 
With the launch of Patch 12.1.5, players will also be able to purchase an 
additional Voidcore from **Orin Straylight** near the Catalyst in Silvermoon 
each week, giving them two opportunities to earn bonus loot.

**[Nebulous Voidcores](<https://www.wowhead.com/currency=3418>)** can be spent after finishing a dungeon or 
defeating a raid boss, granting you a random item from that specific loot 
table. Each item can only be bonus rolled once in each difficulty or dungeon, 
working as a knock-out list to deterministically obtain items.

4.

### Recommended Nebulous Voidcores Bonus Rolls

From the beginning of Patch 12.1, players can acquire voidcore bonus rolls 
in lieu of taking an item from Great Vault, though they will not be otherwise 
obtainable on a weekly basis until eight weeks into the season, around the 
time Patch 12.1.5 is expected to arrive. These are powerful resources, well 
worth prioritizing and using if the items in the vault are not as good. 
Ultimately this is a gamble, so players will need to evaluate whether the gear 
in their vault is better than the chance of bonus rolling the item they want 
from the specific boss or dungeon loot table.

Bonus rolled loot is awarded as if it came from the Great Vault, so Heroic 
difficulty raid boss loot will be awarded at 1/6 on the Myth track, while 
Mythic raid boss loot will be awarded at its maximum upgrade level, 
potentially saving a great deal of crests.

4.1.

#### Recommended Nebulous Voidcore Usage for Arms Warrior

There are two primary ways of using [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) bonus rolls, 
depending on the needs of the player. Ideally, they should be spent on 
Mythic+10 dungeons and Mythic raid bosses to maximize the reward, but keep in 
mind that Mythic raid bosses can only be defeated once per week, while Mythic+ 
dungeons may be repeated in order to stockpile and then use several bonus 
rolls until the desired item is obtained. As of Patch 12.1, only one 
[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) is consumed regardless of whether it is used on a 
raid boss or in a Mythic+ dungeon.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Myth-track weapons, specifically [[item:268213]] or 
   [[item:280799]].
2. Myth-track trinkets, particularly [[item:270173]] and 
   [[item:270175]].
3. Items with extra budget or cantrip effects, such as 
   [[item:268265]], [[item:271878]], and 
   [[item:281029]].
4. Any high budget, rare, or otherwise replacement for a low item level piece 
   of gear.

:::

4.2.

#### Ascendant Venomstones

[[item:280562]] can be used to upgrade an already maximum 
upgraded Heroic, Myth, or equivalent Crafted weapon, trinket, or necklace. 
Heroic gear is upgraded to 328 item level, Crafted pieces to 338, and Mythic 
ones to 340 item level.

1. Weapons are always the highest priority for Warriors.
2. Trinkets are second, as their special effects often provide more power 
     than raw stats.
3. Necklaces should be upgraded last.

Because only these three types of items can be upgraded, highly progressed 
Arms Warriors are in a unique position of not actually needing Venomstones if 
they have already acquired 344 item level pieces from Mythic Coiled Altar and 
Ula'tek. However, most players have not yet reached that point and Venomstones 
are infinitely farmable, so they do not need to be hoarded for the best items. 
They can and should be used to upgrade whatever piece of gear you are 
currently wearing.

5.

### Best Crafted Items for Arms Warrior

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose 
the exact secondary stats you want.

Due to the difficulty of getting a high item level weapon early, crafting a 
weapon can be a good first choice for Arms Warriors, though it has the 
potential to be wasteful if not also intending to play Fury, particularly in 
this season with a high-value cantrip weapon. Ultimately, bracers and boots 
are the best crafts, as they take up the lowest budget slots and free up the 
much more important weapon slot.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Arms Crafted Gear Priority**
- [[item:237834]] with [[item:240167]]
- [[item:237828]] with [[item:240167]]
- Fill out remaining gear slots as needed

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

5.1.

#### Best Embellishments for Arms Warrior

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

As there is a lot of competition for Embellishments, you will have to pick
and choose the two strongest ones for your overall DPS output. Most of them provide
very similar DPS benefits, even if the effects are entirely different. The two best
choices for this are:

- If using a crafted weapon: [[item:245876]] on Weapon and [[item:240167]] on bracers.
- Otherwise for Raid and Mythic+: [[item:240167]] on both bracers and boots.

It is recommended to sim yourself to find out what works best, and consider 
any potential spec swaps that may be made in the near future.

5.2.

#### Adding Sockets to Gear

Instead of picking an item from the Great Vault each week, players can opt 
to take tokens instead, six of which can be exchanged for a 
[[item:275707]], a consumable which adds a single socket to 
Helmets, Bracers, or Belts that do not already have one. This makes it a good 
way of finishing gear which you do not intend to replace.

6.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Arms Warrior Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

These are not the only items worth upgrading, of course. They simply offer
the highest DPS gain early into the tier when your upgrade currency is limited.
Note that exceptions are possible, such as special cantrip items that have 
additional effects unique to that piece of gear.

7.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated gear recommendations for Patch 12.1.5 and added new section with guidance for Venomstones.
- **10 Aug. 2026:** Updated all gearing recommendations for Patch 12.1.
- **15 Jun. 2026:** Updated with Sporefused Gear in Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Added section on upgrading items using crests.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Added new FAQ section for Patch 11.2.7.
- **05 Oct. 2025:** Added Dinar, updated recommended trinkets, and increased item levels for Turbo Boost.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **20 Jun. 2025:** Changed Titan DISC Belt recommendation from Charged Bolts to Critical Chain after hotfix.
- **15 Jun. 2025:** Added Titan DISC Belt for Patch 11.1.7.
- **12 May 2025:** Updated gear lists, added Dinar purchase priority.
- **21 Apr. 2025:** Added Patch 11.1.5 Cartel Chip recommendations.
- **17 Mar. 2025:** Fixed broken Cyrce's Circlet link and added gems to embed.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **16 Dec. 2024:** Updated Cyrce's Circlet to account for item level increasing hotfixes.
- **15 Dec. 2024:** Added Cyrce's Circlet and validated for Patch 11.0.7.
- **21 Oct. 2024:** Added brief section detailing upcoming Timewalking and Anniversary raid trinkets.
- **09 Sep. 2024:** Updated for The War Within Season 1 launch.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated with new gear and bullion recommendations for Season 4.
- **19 Mar. 2024:** Expanded crafting recommendations and reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **14 Jan. 2024:** Added Fyr'alath to overall BiS list (good luck).
- **08 Nov. 2023:** Updated with new gear sets accounting for Sporecloak nerf.
- **06 Nov. 2023:** Updated for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5, to include Dawn of the Infinite gear.
- **01 May 2023:** Updated Onyx Annulet gem recommendations.
- **20 Mar. 2023:** Updated with Onyx Annulet information for Patch 10.0.7.
- **02 Feb. 2023:** Removed erroneous Fury reference.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Arms Warrior. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Arms Warrior Stat Priority

Both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Arms Warriors primarily value 
item level for Strength, followed by Critical Strike and Haste first, then 
Mastery or Versatility. The value of these stats will fluctuate, dropping as 
more is obtained, so it is not uncommon to gear into a lot of Critical Strike 
and Haste, then gem or enchant for more Mastery or Versatility. By the time 
you have reached moderate gear levels, the stat priority for an Arms Warrior 
should be:

Item Level

Critical Strike

Haste

Mastery

Versatility

At the highest level of gear, these stats will shift due to diminishing 
returns on the most stacked stats, generally resulting in all four having very 
similar weights, though there is a point where you simply cannot get more of 
one stat without giving up a large portion of another. This is why traditional 
stat weights compared to one point of strength are a difficult tool to 
utilize, and it is recommended that players regularly sim their own gear 
upgrades instead.

2.

### In-Depth Stat Breakdown

Strength is your primary stat, found on plate armor, weapons, and trinkets. 
It provides Attack Power, which contributes to the damage of all abilities and
auto-attacks.

Critical Strikes normally double the damage of attacks and abilities, as 
well as increasing the Rage generated by auto-attack swings by 10%. Thanks to 
[[spell:383430]] and various other talents though, the damage of crits can be 
increased beyond the normal +100% multiplier.

Haste compresses the rotation, reducing the time between the auto-attack
swings, the global cooldown, and the cooldown of the rotational abilities
[[spell:12294]], [[spell:7384]], and
[[spell:845]], as well as the speed at which [[spell:227847]], 
[[spell:772]], and [[spell:115767]] deal damage.

:::details FAQIs There a Haste Cap for Arms Warriors?
Technically no, as even above 100%, Haste still continues to reduce the
cooldown of rotational abilities and increase the frequency of auto-attacks.

However, there are several breakpoints at which its value will change.
This is difficult to calculate, due to the inconsistent nature of buffs like

[[spell:248621]]

. Thankfully, Haste remains a strong stat for Arms, due to
fitting more global cooldowns inside of its various damage buffs and greater
returns on

[[spell:152278]]

.

:::

Mastery increases the damage taken debuff [[spell:115767]], which is
applied and maintained by using [[spell:12294]],
[[spell:167105]], [[spell:227847]], [[spell:262161]],
[[spell:845]], and [[spell:228920]]. This typically had lower value in 
multi-target, but has increased thanks to the ease of using [[spell:845]] to 
maintain the debuff.

Versatility provides a flat increase to damage dealt and reduces damage taken
by half as much. Direct damage trinkets, cantrip items, and other outside 
sources of damage tend value versatility more, due to typically not scaling with 
attack power.

2.1.

#### Racial Bonuses for Arms Warrior

:::details Click for Bloodmallet Simulations
Loading...

For the complete simulation results, check out [Bloodmallet.com](<https://bloodmallet.com/index.html#warrior_arms>)

:::

Racial bonuses tend to have a minimal impact on Arms performance.
Anything within 1% is typically considered trivial and a small enough margin that 
our recommendation is to simply play what you enjoy the most.

2.2.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

:::details FAQHow Do Diminishing Returns Work?
Intended to smooth out the value of secondary stats and reduce the
propensity for stacking a single one, the amount of secondary stats required
to convert to 1% is reduced at various points. This is calculated by rating,
rather than raw percentage. So it does not include class buffs like

[[spell:248621]]

or

[[spell:2825]]

, though it will affect trinkets
and other effects which add a flat number.

In practice, this is not something most players need to keep track of,
as the best secondaries tend to remain valuable even beyond the point of
diminishing. It simply reduces the gap between them to ensure that a wider
variety of gear is useful.

:::

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Added FAQ sections for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **26 Jul. 2024:** Note drop in the value of Haste, following In for the Kill buffs.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Arms Warrior, based on your [stat priority](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Best Gems, Enchants, Food, and Flasks for Arms Warrior

2.

### Recommended Gems

Of the unique-equipped Diamonds, the [[item:240967]] can 
be slightly stronger when using gems of multiple colors, though this can be 
difficult to juggle during early gearing when sockets are limited. The 
[[item:240983]] may therefore be a simpler option.

Critical Strike and Haste are generally the best stats for Arms 
Warriors, so [[item:240906]] or 
[[item:240890]] should be filled into every other slot. When 
using multiple colors to increase the Powerful Diamond bonus, use one Garnet, 
Peridot, and Amethyst, but avoid the Lapsis, since Versatility is not highly 
valued.

3.

### Best Enchants and Weapon Augments

In addition to enchants, players can also apply temporary augments to their 
weapons, two-hour long buffs that increase their damage or statistics. While 
they last through death, these bonuses are not permanent and must be 
reapplied. [[item:243733]] should be used for more secondary 
stats.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243963]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;<li></li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244643]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Several enchants present a choice between prioritizing Leech, Speed, or 
Avoidance enchantments, which largely comes down to personal preference, as 
all three provide only minor and largely interchangeable benefits.

4.

### Optimal Consumables

- Best Flask: [[item:241325]] or [[item:241326]]
- Best Combat Potion: [[item:241288]] is the best combat potion, though
          it requires very careful allocation of stats to ensure Critical Strike is highest
          and Versatility is minimized, making [[item:241308]] or [[item:271886]] 
  		much simpler to use.
- Best Healing Potion: [[item:271883]] should be used for healing.
- Best Foods: [[item:255846]] is the best feast. Personal food such as
          [[item:242275]] provides the same offensive benefit, but lacks bonus stamina.
- Augment Rune: [[item:259085]] is the best and only augment
          rune currently available in Midnight.

4.1.

#### Augment Rune

The [[item:259085]] is the best and only augment rune currently available
in Midnight.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated recommended weapon enchant and potion description to acknowledge odd statistical situations.
- **10 Aug. 2026:** Updated gems, weapon enchant, and healing potion for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **06 Apr. 2026:** Added disclaimer to Potion of Recklessness.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **25 Aug. 2025:** Added temporary enhancements and expanded notes on weapon enchants.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **12 May 2025:** Minor update to Corruption section acknowledging Echoing Void as an alternative.
- **21 Apr. 2025:** Added Patch 11.1.5 Corruption recommendations.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **26 Jul. 2024:** Update mainhand enchant.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated Onyx Annulet gem recommendations.
- **20 Mar. 2023:** Updated with Onyx Annulet information for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Arms Warrior in World of Warcraft Patch 12.1.5.

1.

### Arms Warrior in Mythic+ in Midnight Season 2

Arms Warriors in Mythic+ are sustained damage dealers that rely on high 
uptime and frequent cooldowns to put out a steady amount of damage, rather 
than short high periods of burst. Though the gameplay is very active, it is 
also very sensitive to downtime, as every second separated away from their 
targets reduces their potential output. For this reason, a good Arms Warrior 
should always be thinking several steps ahead, anticipating which mechanics 
are about to happen, how enemies are going to be moved, when they are going to 
be defeated, and whether a new pack is about to be pulled, in order to ensure 
they stay ahead of the game.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

2.

### Best Mythic+ Talent Builds

Because of the emphasis on multitarget damage, Colossus and Slayer use most 
of the same class and specialization talents in Mythic+ dungeon, and their 
choices do not change based on dungeon or key level either. This means the 
difference between them largely comes down to their hero talents, with 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer currently pulling ahead for the first time in several 
seasons.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Mythic+ Build

2.1.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Mythic+ Talents for Arms Warrior in Midnight

Slayer has made considerable gains in Midnight Season 2, greatly increasing 
the frequency of Sudden Death and resulting [[spell:444775]] procs, while 
also making [[spell:262150]] much more potent. Combined with its already 
greater single-target damage, this has made it the go-to hero tree.

The Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer build brings exceptional multi-target damage 
with [[spell:7384]] and [[spell:444775]], while giving up very little 
single target.

2.2.

#### Flexible Talents

While the specialization tree is fairly static, the class tree has a lot of room for customization:

- [[spell:384110]] can be taken in place of [[spell:1271926]] any time there are shielded targets. Taking [[spell:1271948]] instead of [[spell:1280961]] may also be worthwhile, trading some defensive benefit for a ranged interrupt.
- [[spell:1280961]] has amazing defensive potential as long as Defensive Stance is actively used, though its offensive benefit is lackluster at best.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTgZwGYmhhBzyMbDwMDAmhBA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlnBEGLjiqsy04kkoEBAUggww8+AB-CDFGQCIASYceqqs4AHGu0IZaiqj3nIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus Mythic+ Build

2.3.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus Mythic+ Talents for Arms Warrior in Midnight

Colossus continues to provide very strong multi-target damage through 
[[spell:436358]], Cleave, and enhanced bleeds, though it lacks priority damage 
and its capability to funnel has been significantly reduced. Still, it features 
slightly better crowd control and an extra source of passive healing that 
kicks in at low health.

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus brings very high multi-target damage through the 
use of [[spell:845]] and [[spell:12294]] greatly reducing the cooldown 
on [[spell:436358]], though its single target boss damage is very lackluster 
and [[spell:163201]] is rarely used.

2.4.

#### Flexible Talents

While the specialization tree is fairly static, the class tree has a lot of 
room for customization:

- [[spell:1244088]] and [[spell:382260]] are useful for getting around 
  a bit quicker, easily swapped with [[spell:1271926]] or 
  [[spell:382767]] since Arms rarely reaches max resources.
- [[spell:1271925]] has limited use cases in most PvE content, but can be 
  swapped with [[spell:5246]] or [[spell:12323]] in the few 
  cases it becomes relevant.
- [[spell:1280961]] has amazing defensive potential as long as 
  Defensive Stance is actively used, though its offensive benefit is lackluster 
  at best. [[spell:382764]] is typically the best drop in heavy 
  multi-target content, though this also necessitates taking 
  [[spell:1243660]] instead of [[spell:1271948]].

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmxsMzMzYGAAAghphxYmZzMzMzYmxMDAAAAgxmZgJLAbmxwCMwMsRjBLgZGGGjZzsNYmBAYGGA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlnBEGLjiqsy04kkoEBAUggww8+AB-CDFGOQCASYceqqsuoxBOMURZBq7nUKR-AAAA-AegUphQhBTgwwC-*
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns, Stops, and Slows

3.1.

#### Interrupts

[[spell:6552]] is the Warrior version of kick, frequently used in Mythic+
to stop enemy casts for the benefit of the group and especially the tank.
Because it is sometimes necessary to interrupt targets other than the one you
are actively attacking, it is **highly recommended** to use a focus or
mouseover macro.

Slayer has the unique ability to use Pummel during [[spell:227847]],
which normally cannot be done.

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Pummel
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your primary target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

Not technically an interrupt, [[spell:23920]] is an incredibly
powerful personal tool, which can deflect or reflect the damage and negative
effect of many enemy spells, but only when they are cast on the Warrior.

[[spell:384110]] also provides a ranged silence when 
paired with [[spell:1271948]]!

3.2.

#### Stuns, "Stops", and Slows

[[spell:107570]] and [[spell:46968]] are single and multi-target stuns,
often called "stops" due to their use in stopping enemy actions. Easier to
talent into than the past; these are core talents in any Mythic+ build.

[[spell:5246]] is another AoE stop, fearing targets instead
of stunning them. This has several limitations, causing targets to run away
and potentially call allies, some targets being immune to the
condition outright, and competing with Piercing Howl. Because
of this, the talent is not always taken in Mythic+ builds, but can be added as
desired.

[[spell:12323]] can be used as AoE slows, though this is not 
something that is regularly needed in most content. [[spell:1715]] is the 
non-talented, single-target alternative, which is typically enough to cover 
any slowing needs. Piercing Howl also provides a minor speed buff to allies, 
though its long cooldown renders it incredibly niche.

### Other Utility

3.3.

#### Other Utility

[[spell:6673]] increases the damage output of all melee classes and
Hunters by 5% and should always be active.

[[spell:97462]] is a group-wide defensive cooldown, useful in helping
yourself or allies survive incoming damage. Its effect is also increased by 
50% in non-raid content!

[[spell:18499]] and [[spell:384100]] removes fear and
disorient effects, which are not very common in the modern game. The shout
version applies to allies but suffers several limitations: requiring an extra
talent point, having a very limited range that often misses casters, and only
able to be used reactively after the fear effect has been applied rather than
pre-emptively immuning it. As a result, it is rarely taken, though the new 
[[spell:1271925]] talent can be situationally useful for removing deadly 
debuffs that also have slowing effects.

4.

### Dealing with Affixes

Unlike most classes, Warriors have very few specialized tricks to handle
various mechanics, being mainly focused on personal damage and defense. Most
of the tips and tricks for Warriors constitute negating or returning incoming
spell damage using [[spell:23920]].

The [Targeted 
Spells](<https://www.curseforge.com/wow/addons/targetedspells>) addon is very helpful in knowing when an enemy spell is being cast 
on you, though it cannot tell what that spell is or whether it is reflectable, 
so players will need to learn to identify them on their own.

4.1.

#### Affixes

Season 2 of Midnight only has four significant Affixes that offer any kind
of counterplay, called Xal'ataths Bargains. These rotate every week, with only
one of them being active at a time. Many of the Mythic+ affixes, like Fortified or
Tyrannical, simply add a passive effect to the keystone, with these four exceptions
that are seasonally themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. [[spell:46968]] works great here, though 
  [[spell:5246]] can also be used in a pinch.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn with a 
  shield that needs to b e focus-targeted, making it a perfect target for 
  [[spell:384110]] with [[spell:1271948]].
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and circle
  around them. You have 15 seconds to soak all of these to buff your group. Using
  [[spell:12323]] will help the party get to these faster, though be wary 
  of running circles around one another!
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb, which also reduces movement speed, allowing the entire effect 
  to be immediately removed with [[spell:1271925]]. Otherwise, 
  [[spell:202168]], health potions, or Healthstones can be used to help 
  clear the absorb.

Each of the affixes provides a different set of beneficial effects once it is dealt
with, and while they are very powerful, they are not something you play around
in a specific way. The most important part is to not let any of them buff the enemy
trash or bosses.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated build recommendations for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Aug. 2025:** Clarified explanation regarding talent choices.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Tagged recommended builds and validated for Patch 11.0.7.
- **21 Oct. 2024:** Updated dungeon affix recommendations.
- **09 Sep. 2024:** Updated for The War Within Season 1 launch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Minor update to introduction.
- **22 Apr. 2024:** Updated rotation for Season 4.
- **19 Mar. 2024:** Minor update to recommended talents and reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2 and season 3.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **12 Jul. 2023:** Minor formatting updates.
- **10 Jul. 2023:** Updated for Patch 10.1.5, including alternate Skullsplitter build.
- **01 May 2023:** Reviewed for Patch 10.1
- **02 Feb. 2023:** Updated Bladestorm talent build.
- **24 Jan. 2023:** Updated build for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Arms Warrior in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Warriors typically do not need many macros to play effectively, although 
a few can be very nice quality-of-life improvements, such as automating targeting 
reticules and eliminating excess keystrokes.

With the talent loadouts system creating individual action bars for each 
set, there is much less need for macros that switch abilities depending on 
which is talented at the time. That said, [known:######] conditionals will 
allow this, using a talented spell name or ID to determine which ability is 
shown.

Abilities which directly replace one another, like Victory Rush and 
Impending Victory, will continue to work regardless of which ability is named 
in the macro.

1.1.

#### Generic Macros for Warriors

#### Colossus Smash and Avatar

```wow-macro
#showtooltip
/cast Avatar
/cast Colossus Smash
```

This simple macro will use [[spell:107574]] and [[spell:167105]] 
simultaneously, though it can be combined with any other on-GCD ability 
instead. Remember that multiple on-GCD abilities cannot be combined without 
very explicit logic though.

#### Pummel Macro

```wow-macro
#showtooltip Pummel
/cast [@focus, harm, exists][@target] Pummel
```

This macro uses [[spell:6552]] against your focus target, if you have
one, or against your current target if you have no focus target.

#### Switch Between Bladestorm and Ravager

```wow-macro
#showtooltip
/cast [@player, known:Ravager] Ravager; [known:Bladestorm] Bladestorm
```

This will switch between [[spell:227847]] and [[spell:228920]], 
depending on which is talented at the time.

#### Automatic Heroic Leap

```wow-macro
#showtooltip Heroic Leap
/cast [@cursor] Heroic Leap
```

This will cast [[spell:6544]] where ever your cursor is located,
without waiting for the targeting circle.

#### Heroic Leap Spam

```wow-macro
#showtooltip Heroic Leap
/cast !Heroic Leap
```

This allows you to spam the [[spell:6544]] button, without clearing 
the ground-targeting circle.

#### Charge and Victory Rush

```wow-macro
#showtooltip
/cast Charge
/cast Victory Rush
/cancelaura Bladestorm
```

Because Charge is off the Global Cooldown, Victory Rush or any other melee
ability can be used on the same keybind. When outside of melee range, Charge
will be cast instead. This macro will also cancel Bladestorm to ensure the 
player is not prevented from moving quickly.

#### Stance Swap

```wow-macro
#showtooltip
/cast [stance:2]!Defensive Stance;[known:386164]!Battle Stance;[known:386196]!Berserker Stance
```

This allows you to swap between [[spell:386164]] and 
[[spell:386208]] using the same keybind.

1.2.

#### Specific Macros for Arms Warriors

#### With Colossus Smash

```wow-macro
#showtooltip Colossus Smash
/use Colossus Smash
/use Blood Fury
/use Berserking
/use 13
/use 14
```

This macro uses off-global cooldown racial abilities and any equipped
trinkets alongside [[spell:167105]].

2.

### Best Addons

2.1.

#### Generic Addons for Warriors

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and maybe you will even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.4.4.

##### Omen Threat Meter

[Omen Threat Meter](<https://www.curseforge.com/wow/addons/omen-threat-meter>)
is the most popular addon for displaying the current threat levels on your
target. We recommend you to use it to avoid taking aggro when the tank is still building
up threat on an enemy.

2.5.

#### Specific Addons for Arms Warriors

Currently, we do not feel that there are any additional addons needed to 
play an Arms Warrior to its full potential, though there is a wide selection 
of user interface addons to help create a better layout for frames, action 
bars, and more.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Feb. 2024:** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
