## 专精概览

Welcome to our Brewmaster Monk guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to tank as a Brewmaster Monk in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your survivability.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Brewmaster Mythic+ Resources

[NEW! Top Brewmaster Talent Builds](<https://raider.io/specs/brewmaster-monk/talents>)

[Top Brewmaster Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/monk/brewmaster>)

[Brewmaster Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=monk--brewmaster>)

[Popular Brewmaster Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=monk--brewmaster>)

1.

### Brewmaster Monk Overview

[Brewmaster Monk](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-guide>) tanks are drunken brawlers capable of surviving all
but the most deadly amounts of damage, turning the bulk of it into a
unique damage-over-time effect known as [[spell:115069]] that can be removed
with their other abilities. By smoothing it out or dodging it entirely, this way
of taking damage makes Brewmaster an incredibly desirable specialization for
both progression raiding and dungeons. On top of this, a Brewmaster offers
considerable utility and is <em>incredibly</em> mobile, all the while delivering
potent bursts of damage.

Note: the following guide will detail parts of tanking that are unique to
Brewmaster Monks rather than a general tanking strategy. If you are new to the
role of tanking in general, it is recommended to look into our
[tanking guide](<https://www.icy-veins.com/wow/tanking-guide>) first.

Consistently Good, Seldom the Best

Brewmaster Monk is a somewhat different tank specialization when it comes to
damage output. It is rarely able to be the very best, but also tends to avoid
being the worst, usually ending up comfortably in the middle when tuning isn't out
of line.

Where it has an advantage, however, is in its ability to often push for
more damage in moments where other tanks may have to sacrifice it for defensive power
instead. This can help nudge its often average potential to something more exceptional, but
this advantage is quickly lost when defense is no longer needed by any tank for a
piece of content.

With that being said, [[spell:322109]] deserves special mention
as an exceptional ability for world content in particular, even if its power in raiding
or Mythic+ is usually more limited.

The Gold Standard of Progression

When it comes to a progression environment like raiding, Brewmaster Monks are often
unparalleled among tanks, featuring consistent damage and defensive power thanks
to their [[spell:115069]] passive working to mitigate hits you may not even be
prepared for yet.

Compared to others that may need to have something active to survive, this
slight advantage adds up quickly, but it does have some weaknesses too. In particular,
whenever a healing reduction or ability that bypasses mitigation is present, a
Brewmaster is likely to suffer more than other tanks. There may also be encounters
whose strategies favor another tank's toolkit over a Brewmaster's, such as making
use of an immunity or grip effect.

Capable, but Under-Represented

Although rarely seen as "meta", Brewmaster Monk is generally just as capable as other tanks
when it comes to completing Mythic+ content. Indeed, you will often see them among
the highest key levels completed, though they rarely offer anything outstanding
for the job. Make no mistake, Brewmasters still bring many helpful tools for the content,
including [[spell:115078]], [[spell:218164]], and even [[spell:115315]];
they just are not as unique or flashy. Instead, their popularity is determined by the
weaknesses of other tank specializations.

Perhaps the most noteworthy difference in Mythic+ with a Brewmaster is slightly
encouraging more Physical damage-dealers in the party due to the natural synergy
offered by [[spell:8647]].

A Little Bit of Everything

Brewmasters bring a large amount of <em>potential</em> utility to any content they
are a part of. This includes a dispel for ![Poison](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-poison.png>)Poison and ![Disease](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-disease.png>)Disease
effects with [[spell:218164]], snare/root removal with [[spell:116841]],
both a crowd control and optional ![Enrage](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-enrage.png>)Enrage removal with [[spell:115078]],
and an AoE stun/knockback with [[spell:119381]]/[[spell:116844]]. Apart from these,
they are also masters of enemy management, being able to taunt entire groups with
the help of [[spell:115315]]. And, all of this is in
addition to a "mandatory" raid buff with the [[spell:8647]] passive effect.

Unfortunately, most of this toolbox of utility is either shared across the entire
 Monk
class, generic enough to have overlap with many other specializations, or does not
see much use, especially in raid environments. Still, you at least have
the option to contribute with lots of different utility in most situations.

Durable, but Not Invincible

Brewmaster Monks are often the benchmark of survivability, especially in raiding.

While they usually require more total healing to offset the passive damage taken over
time from [[spell:115069]], this often allows for more resource-efficient triage.
In addition, Brewmasters take full advantage of the attention with the [[spell:216519]]
effect which applies to both self-healing and healing from others, including absorbs!

When that is still not enough, there are also two defensive cooldowns available
to mitigate things further: [[spell:1241059]] (or its alternate form
of [[spell:322507]]) and [[spell:388917]]. All of this combines
to make a tank that is capable of surviving the most lethal hits, but one also
prone to a slow death over time when ignored for too long.

Unmatched

If you are seeking the most mobile tanking experience available, look no further
than Brewmaster Monk.

Between their iconic [[spell:109132]] ability
(along with the [[spell:449582]] talent to enable temporary waterwalking, avoid fall damage,
and an additional dash), frequent speed boosts with [[spell:116841]]/[[spell:1263346]],
and even teleporting back to a set point with [[spell:101643]], no tank can truly
compete with all that a Brewmaster can do. Plus, the Roll ability is not on the global
cooldown, making it available at a moment's notice. Likewise, you can often react
quickly to any knockback effects with a quick use of Transcendence in mid-air,
or potentially counter with a dash from Lighter Than Air!

Best of all for Brewmasters, none of their mobility tools are a part of your
damage or defensive rotations, allowing you to exclusively treat them as the mobility tools they are.

2.

### Brewmaster Monk in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) continues the story of the [Coiled Isle](<https://www.icy-veins.com/wow/the-coiled-isle-guide>) by introducing
a new raid: the [Unbinding of Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>). [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) is its sole encounter,
dropping new armor that interacts with "venomcursed" gear from the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>),
along with one new trinket for each role.

For solo-minded players, there is also the [Labyrinth of Kindo'jan](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>), a new
"Megadelve" that can act as a great source of Hero track gear. Not to mention, there
is an opportunity to get a limited number of Myth-track pieces in the exact armor slot you
need. If you did not play at the start of Season 2, now is a great time to catch up!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) acts as an escalation to the progression of season 2 in
Midnight, with access to ascended item levels, multiple sources of catch up gear,
and access to an infinite number of Mistcrests to upgrade it.

2.3.

#### Class Changes

While [Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) does not have any substantial changes for Brewmaster Monks
apart from a bugfix to the [[spell:434774]] talent, things haven't stayed
entirely the same for the specialization. Thanks to the release of [[item:280562]]s,
fully upgraded Hero and Myth track pieces in certain slots can be brought to new
Ascended item levels of up to **340**. This creates some shakeups in
[gearing](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>), so be sure to check out
our updated best in slot lists!

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_monk_explodingkeg.jpg>) Click for Previous Season 2 Changes
:::details Show October 6th Class TuningHide October 6th Class Tuning
[Class Tuning — October 6th](<https://us.forums.blizzard.com/en/wow/t/incoming-class-tuning-october-6/2370266>)

**Brewmaster**

- Developers’ notes: We’re finding Brewmasters’ death rates in dungeons is
    higher than we’d like, so we’re adjusting some rotational sources of damage
    reduction to help improve baseline durability.
- Quick Sip now purifies 8% of current Stagger amount each time you gain 3
    seconds of Stagger duration (was 5%).
- Pretense of Instability grants 10% dodge for 8 seconds after drinking a Brew (was 5 seconds).

The changes from this round of tuning are fairly subtle, but not insignificant
in their potential impact. They won't be easily seen on a meter, but [[spell:388505]]'s
additional [[spell:115069]] reduction in particular will result in a lot less damage
taken in more dangerous scenarios. [[spell:393516]]'s uptime, meanwhile,
is already fairly high for a Brewmaster getting consistent cooldown reduction and
brew usage, but this will better cover those small gaps where it may briefly drop
in high-intensity moments when your resources are low overall.

:::

:::details Show August 25th Class TuningHide August 25th Class Tuning
[Class Tuning — August 25th](<https://us.forums.blizzard.com/en/wow/t/class-tuning-incoming-%E2%80%93-august-25/2339812>)

**Brewmaster**

- Developers’ note: We’re adjusting the absorption of Celestial Brew and
    Celestial Infusion to improve its impact as a defensive option and to help
    address pain points players are experiencing in some encounters.
- All damage increased by 3%.
- Celestial Brew and Celestial Infusion absorb value increased by 20%.

With this tuning, Brewmasters received a bump to both their damage and their
defense. Although this sounds like a simple 3% damage increase, it is slightly
less in reality due to only applying to a Brewmaster's <em>abilities</em>. Thus,
any gear effects such as the seasonal set bonus or trinkets are not impacted.
Still, any improvement is appreciated.

Defensively, this latest buff to the absorb value of [[spell:322507]] and
[[spell:1241059]] now pushes the abilities to being **200% stronger**
than they were last season, though bear in mind their cooldowns were also doubled
in season 2. Brewmasters will certainly feel these shields now!

:::

:::details Show Patch 12.1 Class TuningHide Patch 12.1 Class Tuning
[Patch 12.1](<https://www.icy-veins.com/wow/midnight-patch-12-1-guide>) was a fairly quiet one for Brewmasters compared to the recent
trend of larger changes it had received on a fairly consistent basis. Although there
were a number of tuning adjustments made to its self-healing abilities in particular,
this was a result of a sweeping shift to player health and enemy damage output and
was intended to offset it in a net-neutral way. In other words, although talents like
[[spell:1262659]] appeared to have had their healing buffed by 25% (being increased
from 40 to 50%), enemy damage was also been increased by 25%.

There was one major Brewmaster-specific change to speak of, however: [[spell:1241059]]
and [[spell:322507]] had their cooldowns doubled,
resulting in a 90-second cooldown for each in exchange for absorbing 150% more damage.
While this made them feel more impactful defensively, it also somewhat
reduced the frequency of triggering the apex talent of [[spell:1265141]].
This also resulted in a slight reduction in healing from [[spell:1265145]].
However, the main gameplay of Brewmaster remained otherwise unchanged. If anything,
the [[spell:115399]] talent became a more appealing option to try.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Summary

Moving into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), a core theme of class
design has been in simplifying aspects of a specialization that have unnecessarily
complex interactions "just because" rather than being satisfying to play. For
Brewmaster Monk, this means reworking the available Hero Talent trees of
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony to be more consistent, communicating
[[spell:115069]] more clearly, and slight ability pruning. The broad extent of these
changes can be found below, though don't be alarmed if you were a fan of Brewmaster
already: its core gameplay remains the same.

2.5.

#### Apex Talents and Extra Talent Points

One of the major changes in Midnight's class design comes as players reach
the new level cap of 90, unlocking additional talent points in all available trees.
Not only does this create more potential build flexibility, but starting from Level 81 every
specialization also unlocks a new **Apex Talent**, transforming a key
part of gameplay. For Brewmaster Monk, this Apex Talent is called **Bring Me Another**
and has three main parts which revolve around the [[spell:121253]] ability:

1. [[spell:1265129]] — Using an ability with Brew in its name has a
   chance to generate an Empty Barrel (max 1). When you next cast [[spell:121253]],
   your Empty Barrel will also be thrown at your target to deal bonus damage and can ricochet
   to up to three additional enemies. These bounces will **not** occur in single-target.
2. [[spell:1265138]] — Increase all Physical
   damage dealt by 10/20%. In addition, the cooldown of [[spell:121253]] is reset
   and the Energy cost of its next cast reduced by 50/100% whenever you generate an Empty Barrel.
3. [[spell:1265141]] — Whenever you cast [[spell:388917]] or
   [[spell:322507]]/[[spell:1241059]], you and up to
   2 nearby allies gain a [[spell:1265145]], along with an Empty Barrel
   for yourself. Upon taking damage, Refreshing Drink is consumed to trigger a substantial
   heal-over-time effect. The damage of Empty Barrels is also increased by 100%.

:::details Midnight Hero Talent Adjustments
2.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Hero Talents have been largely redesigned from the
ground up on Brewmaster Monk. Most importantly, [[spell:450615]] are no
longer triggered after spending a specific amount of Energy, instead occurring
after every cast of [[spell:121253]]. In addition, your auto attacks now generate
[[spell:451021]]s rather than dealing damage in general, with the number of
charges being roughly identical between dual-wield and two-handed weapons. Beyond
this, all interactions involving [[spell:387184]] are now tied to
[[spell:132578]] instead and [[spell:1272821]] now rewards
you for casting [[spell:115181]] while this cooldown is active. Overall,
these changes have made ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Brewmasters capable of dealing much
more consistent damage.

On top of reworking its mechanics, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan tree has also
received additional talent nodes that will all be unlocked by the time you reach
the level cap in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>):

- [[spell:1262612]] — [[spell:450615]]
    deal additional Nature damage to nearby enemies. This is largely identical to the
    former "Shadow" effect of [[spell:1272821]], but present at all times.
- [[spell:1272844]] — Reduces the cooldown of
    [[spell:109132]]; choice node with [[spell:1272849]]. Replacement for [[spell:450984]].
- [[spell:1272849]] — Gain temporary bonus movement speed
    when entering combat; choice node with [[spell:1272844]]. Replacement for
    [[spell:450985]].
- [[spell:1262603]] — Activating [[spell:132578]]
    instantly grants 10 [[spell:451021]]s that immediately trigger on your
    next attack.
- [[spell:1262610]] — [[spell:451021]]
    generation is increased, and additional [[spell:450615]] are triggered
    with every [[spell:115181]] cast during [[spell:132578]].

2.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony

In comparison to its counterpart, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony talents have
seen less drastic changes. Its gameplay loop still revolves around
building and spending vitality, activating
[[spell:322507]] or [[spell:1241059]] to do so. Where a key difference
now lies is in the [[spell:450529]] capstone. Rather than universally amping
all of your ability damage on any target affected by [[spell:450763]],
this talent now automatically spends vitality
to empower every cast of [[spell:121253]] with bonus damage while increasing
the generation of all other spells to compensate. As a result, it is now more
difficult to "cap" out and waste the resource, and you will not be punished as
severely for choosing to not cast Celestial Brew/Infusion in low-damage areas just
for bonus DPS.

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony tree, like its ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan alternative,
also brings new talent nodes in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>):

- [[spell:1270958]] — Casting
    [[spell:322507]] or [[spell:1241059]] causes your next two
    casts of [[spell:100780]] or [[spell:116670]] to deal bonus Nature damage
    split among nearby enemies as well as a small amount of healing to nearby allies.
- [[spell:1271048]] — Casting
    [[spell:121253]] causes your next cast of [[spell:100780]] or [[spell:116670]]
    to trigger a Harmonic Surge.
- [[spell:1271105]] — Empowers your
    [[spell:196736]] and [[spell:418359]] talents:
  
  - [[spell:196736]]'s bonus damage to [[spell:100780]] is further
      increased, along with the bonus Brew cooldown of [[spell:121253]] when either
      are comboed.
  - [[spell:418359]] deals increased Nature damage and grants additional
      cooldown reduction to Brew abilities.

:::

:::details Stagger and Mitigation in Midnight
2.8.

#### Stagger and Mitigation in Midnight

One of the main difficulties in learning Brewmaster Monk as a new player has
often been trying to figure out the [[spell:115069]] passive and all of the
talents that interact with it. Many have come with bonus effects that seemingly
encourage you to take additional damage, or quietly reduce its danger to you without
being clearly visible. No longer. In [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), any time
your Stagger gets reduced by an effect, such as [[spell:119582]], a combat
text pop-up will occur to tell you exactly how much it was. This should hopefully
make the smaller, but consistent reductions from talents like [[spell:388505]]
more obvious and let players feel visually rewarded for proper play.

Speaking of [[spell:119582]], the ability now also glows at more appropriate
times and will additionally <em>Purify</em> a minimum amount of [[spell:115069]].
Whereas previously it would only highlight in [[spell:124273]], in
[Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) it will also briefly glow whenever you have entered a period of
"<em>Elevated Stagger</em>". This occurs whenever you have suffered a large hit that causes
your Stagger level to jump, even if it was low beforehand. These two enhancements
combine to better teach players how to properly use the ability as mitigation,
with the [[spell:196737]] talent now also providing partial cooldown refunds
for successfully reacting to <em>Elevated Stagger</em>.

Finally, most talents that once provided different benefits based on your
current [[spell:115069]] level have been adjusted to instead offer consistent
effects. Now, rather than [[spell:383994]] buffing [[spell:115181]]
by smaller amounts in only [[spell:124275]], it will instead offer its maximum
bonus at all times. The one remaining exception among a Brewmaster's talents is
[[spell:383714]], which varies in its Mastery bonus. Still, these
changes and improved Stagger guidance should combine for a better Brewmaster
experience across all types of content.

:::

:::details Ability Pruning
2.9.

#### Midnight Brewmaster Ability Pruning

Brewmaster Monk has long had a reputation of requiring many different keybinds
to appropriately handle its plethora of abilities. [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) is making
a concerted effort to address this concern by removing a number of active
abilities for the specialization. These include the following:

- [[spell:107428]] and its supporting talents
- [[spell:387184]]; many supporting talents are also removed, with some
    interactions transitioning to [[spell:132578]]
- [[spell:324312]]
- [[spell:122278]]
- [[spell:1243287]]; ![Magic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-magic.png>)Magic dispelling and redirection effect is
    now an optional passive enhancement to [[spell:388917]]

Overall, this should create a more intuitive damage rotation for Brewmaster players,
as many have felt [[spell:107428]] to be disconnected from other abilities
or defensive goals. Although the loss of two defensive abilities is unfortunate,
this has also happened to most tank specializations and can make for easier
decision making in an emergency (ie: just press [[spell:388917]] rather than
choosing between it, [[spell:122278]], and [[spell:1243287]]). If you were
once overwhelmed by keybinds when learning the specialization, give it another
try in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) and see how you feel!

:::

3.

### Basics of Playing a Brewmaster Monk

Being a tank specialization, your main job is to stay alive at all times
and to ensure that enemies are not attacking your other group members.
Brewmaster Monks accomplish the first task by delaying a portion of all
damage taken with the help of their [[spell:115069]] passive, improving its power
with the help of [[spell:322120]] and negating some of that delayed damage with
[[spell:119582]] or other effects. In addition, plenty of potential damage
is dodged <em>entirely</em> with the help of their Mastery,
[[spell:117906]].

As for keeping the attention of enemies, a Brewmaster Monk converts their Energy
into abilities such as [[spell:121253]], [[spell:100780]], and
[[spell:322729]] that both deal damage and help improve the
power of [[spell:115069]]. Woven into this relationship of dealing damage
to reduce damage taken are several abilities with no cost that work with
other parts of the kit, such as [[spell:100784]], allowing them to dodge more
attacks, [[spell:115181]] setting enemies hit by Keg Smash on fire, or
<em>instantly killing</em> most enemies with [[spell:322109]]!

Condensing the specialization further, Brewmaster can be described using the
bullet list below.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_shuffle.jpg>) **Stay Shuffling**  
  
    Your most important buff when playing Brewmaster is [[spell:322120]]. This
    empowers your [[spell:115069]] passive to keep you safe from damage feeling "spikey".
    By pressing [[spell:121253]] and especially [[spell:100784]] on cooldown, you
    will maintain it with ease.
- ![](<https://static.icy-veins.com/images/wow/large_icons/achievement_brewery_2.jpg>) **Be Energy Efficient**  
  
    A Brewmaster has three main abilities that cost Energy: [[spell:121253]],
    [[spell:100780]], and [[spell:322729]]. You will always want
    to have enough Energy to keep casting Keg Smash on cooldown, spending further Energy
    on Tiger Palm when your "free" abilities like [[spell:100784]] and [[spell:115181]]
    are on cooldown. Spinning Crane Kick is only used as a gathering tool and will not be used even
    in AoE combat.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_beer_06.jpg>) **Stagger your Brew Usage**  
  
  [[spell:119582]] helps reduce the damage taken by your [[spell:115069]]
    passive. Good times to use it are when the button is glowing, or when you are
    about to reach 2 charges. You can also use [[spell:1241059]] to further
    smooth out your damage taken. Both of these abilities have their cooldowns reduced
    by [[spell:121253]] and [[spell:100780]].

4.

### How to Gear Up as a Brewmaster Monk

While we always recommend simming yourself for ideal results, we do provide a
dedicated Brewmaster gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated BiS lists with Unbinding of Kit'hix Gear; added Ascendant Venomstone recommendations as part of Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Added Patch 12.1.5 discussion.
- **25 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Further trinket ranking adjustments due to recent class tuning and simulation optimizations; removed "pre-season" vault recommendation.
- **25 Aug. 2026 (this page):** Added Class tuning for the weekly reset of August 25th.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Adjusted trinket rankings and great vault selection guidance to reflect recent hotfixes and tuning.
- **15 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Adjusted recommended potion and flask to reflect recent hotfixes.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Adjusted consumables and other wording for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated BiS lists, trinkets, and recommended embellishments for Patch 12.1/Midnight Season 2.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Added a new Stagger bar addon recommendation, and adjusted Wago description.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Added new health potion recommendation as part of Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Added dropdown describing specific benefits of Versatility; stat priority reviewed for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Standard build adjusted; utility talent cheatsheet updated for Season 2 dungeons.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Modified timelines and rotation guidance for Season 2 and its set bonus; adjusted formatting to limit text to more important information.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Updated standard raid, weekly Mythic+, and high-key Mythic+ builds for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Spells adjusted to reflect tuning as part of Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Small adjustments to recommended talents as part of Patch 12.1; added core tenets of the specialization.
- **10 Aug. 2026 (this page):** Spec ratings adjusted; replaced Midnight Season 1 discussion with Season 2 and its relevant changes.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated BiS lists with Sporefall gear; adjusted recommended crafted gear for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added timeline graphics for single-target and AoE openers.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Added Rune Recommendations for Patch 12.0.7's Omnium Folio.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated Midnight Season 1 discussion with Patch 12.0.7 changes.
- **19 May 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Swapped Hero Talent choice on high key build; further talent swap discussion added.
- **19 May 2026 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Moved choice talent discussion to talent section; merged FAQ blocks.
- **19 May 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Revised Hero Talent selection on high key build.
- **19 May 2026 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Adjusted stat priority display and combat assistant discussion.
- **03 May 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated flex/niche talent discussion, revised sample high key build.
- **03 May 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Adjusted sample high key/defensive Mythic+ build string and notes.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added discussion of Nebulous and Ascendant Voidcores in Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added discussion of available external cooldowns alongside Fortifying Brew in its respective section.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Added High Key/Defensive Mythic+ build; adjusted Offensive raid build Hero Talent choice.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated Midnight Season 1 discussion with Patch 12.0.5 tuning.
- **06 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added further world trinkets to gear discussion.
- **06 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Added defensive node discussion to advanced/high key build.
- **06 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Adjusted AoE priority for Shado Pan Brewmasters while Invoke Niuzao is active and added further explanation to the cooldown's discussion.
- **06 Apr. 2026 (this page):** Updated Midnight Season 1 discussion with most recent tuning pass.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Slightly revised leveling order to incorporate Counterstrike over Tranquil Spirit; included further leveling resources, along with Heirloom guidance.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added Midnight Season 1 recommendations; revised formatting of sections.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Slightly adjusted certain enchant recommendations; added discussion of tea items to food consumables.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Added stat rating conversion values.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Adjusted recommended talent builds and flex/niche talent discussion for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added tier set bonus explanation for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Made minor talent adjustments for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Added Season 1 set bonus discussion.
- **16 Mar. 2026 (this page):** Added Midnight Season 1 discussion.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Added useful leveling consumables for Midnight; adjusted leveling path for Leveling to 90.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated with Pre-season recommendations for Midnight's launch.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Added click to copy functionality to all macros for Midnight launch.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Gems, Enchants, and Consumables updated with Midnight items.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Updated Offensive stat priority for Midnight Launch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Rotation Priorities updated to include Apex Talent for Midnight launch; talent choices reduced to remove clutter.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated with Midnight launch tuning and Apex ability.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Talent Trees and rotation updated for Midnight launch.
- **26 Feb. 2026 (this page):** Updated for Midnight launch.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **23 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Slightly adjusted Puzzling Cartel Chip recommendations.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **15 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added further noteworthy offensive trinkets to their respective sections.
- **12 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Revised trinket recommendations due to updated simulation data.
- **12 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated recommended talent builds based on latest simulation data.
- **12 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Adjusted single-target rotation priority to reflect latest simulation data; revised preset buttons to match modified talent recommendations.
- **12 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Build recommendations adjusted based on updated simulation data.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Leveling talent pathing overhauled for Patch 11.2.0 tree updates.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.0.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Healing Potion and enchantments updated for Patch 11.2.0.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 11.2.0.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Adjusted recommended talent builds and flex/niche talent discussion based on Patch 11.2.0 talent adjustments; added per-dungeon utility talent cheat sheet.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Revised rotation presets and talent selections for Patch 11.2.0.; combined Dragonfire Brew and Charred Passions into one "Breath of Fire" option; added Season 3 tier set bonus discussion.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated with new and adjusted talents for Patch 11.2.0.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Talent builds and rotation updated for Patch 11.2.0.
- **04 Aug. 2025 (this page):** Updated with a summary of Patch 11.2.0 Brewmaster changes; Season 2 discussions have been relocated, and Season 1's, deprecated.
- **23 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Adjusted DISC belt recommendations based on recent tuning.
- **17 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Adjusted talent build to account for Combat Assistant enforcing Blackout Combo; rephrased Combat Assistant discussion due to hotfixing.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Updated for Patch 11.1.7; switched Dragonfire Brew for Charred Passions.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added discussion of the DISC belt of Patch 11.1.7; embellishment recommendations adjusted.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added discussion of the Combat Rotation Assistant in Patch 11.1.7 and its viability for a Brewmaster.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Switched Dragonfire Brew for Charred Passions on world and defensive raiding talent builds.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Added discussion of the Combat Rotation Assistant in Patch 11.1.7 and its viability for a Brewmaster.
- **15 Jun. 2025 (this page):** Added discussion of Patch 11.1.7 changes.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Puzzling Cartel Chip recommendations adjusted based on purchase requirements.
- **12 May 2025 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Corruption recommendations updated based on latest simulations.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Puzzling Cartel Chip purchase recommendations added for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Corruption Enchant recommendations added for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Added discussion of Patch 11.1.5 changes.
- **23 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Best damage trinket adjusted due to recent tuning hotfixes; added Sigil of Algari Concordance discussion.
- **23 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Added mention of the Magnificent Jeweler's Setting for additional sockets on jewelry.
- **23 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-liberation-of-undermine-raid-guide>)):** Talent recommendation adjusted for Cauldron of carnage; clarified Stagger's role against "unmitigated" damage mechanics; added a Monk-related warning for Stix Bunkjunker.
- **23 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Individual dungeon tips added for all bosses and important trash, as well as suggested utility talents.
- **23 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Adjusted Chi Burst's priority for Master of Harmony Players; added extra guidance on Charred Passions with the Season 2 4-piece bonus.
- **17 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-liberation-of-undermine-raid-guide>)):** Boss tips adjusted for all encounters based on progression data; added Gallywix tips.
- **11 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Reworded 4pc interaction with Shadowboxing Treads due to bugfixes.
- **01 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Cyrce's Circlet recommendations adjusted as of latest post-hotfix sims.
- **01 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-liberation-of-undermine-raid-guide>)):** Boss tips updated for all encounters, minus Gallywix.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Page reviewed for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Page reviewed for Patch 11.1.0
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Updated tier set bonus explanations for The War Within Season 2, alongside minor rotational notes for optimizing Blackout Combo.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Builds updated for The War Within Season 2; standard Mythic+ build switched to Master of Harmony.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Clarified the behavior of Veteran's Eye; reviewed for Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Slightly modified suggested talent build to include Lighter Than Air.
- **24 Feb. 2025 (this page):** Updated with discussion of Patch 11.1.0 changes; formatting adjusted.
- **20 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Gear, trinket, and crafting recommendations updated for Season 2 of The War Within.
- **20 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Page reviewed for Patch 11.1.
- **20 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Page reviewed for Patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-liberation-of-undermine-raid-guide>)):** Guide added.
- **20 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Cyrce's Circlet citrine guidance adjusted based on further tuning and updated simulations.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added Cyrce's Circlet citrine recommendations; page reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Added clarification on recommended builds.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Ability priority further simplified.
- **15 Dec. 2024 (this page):** Added discussion of Patch 11.0.7 changes.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added Befouler's Syringe to list of unique weapons.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Build descriptions adjusted to reflect the interchangeable nature of Hero Talents; dungeon tips adjusted; added Voidbound affix advice.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added advanced section detailing Wisdom of the Wall gameplay for Shado Pan Brewmasters.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Wording adjustments made to reflect the more interchangeable nature of choosing Hero Talents.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Hero Talent values adjusted to reflect tuning as of Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Formatting updated; beginner talent build adjusted, defaulting to Weapons of Order.
- **21 Oct. 2024 (this page):** Added discussion of Patch 11.0.5 changes.
- **28 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-nerub-ar-palace-raid-guide>)):** Queen Ansurek tips added; talent builds modified.
- **28 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Added specific talent/gameplay tips for all Season 1 dungeons.
- **28 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Slight tweaks made to Mythic+ and Open World/Delve builds.
- **13 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Embellishment crafting slot choices adjusted and further explained; trinkets adjusted ahead of upcoming tuning; recommended tier offpiece shifted.
- **10 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Embellishment recommendations adjusted with latest simulation findings.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Gear, trinket, and crafting recommendations updated for Season 1 of The War Within.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Consumables adjusted based on recent simulations for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Adjusted preset talent selections; updated tier set gameplay considerations; added discussion of Sal'salabim's Strength vs Scalding for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Mythic+ build split into Standard and Advanced talent guidelines; other builds updated based on Season 1 simulations.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **25 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Delves build playstyle guidelines updated.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Added Hero Talent pathing recommendations, along with playstyle pointers.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated with Pre-Season and Season 1 BiS gear for The War Within
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Macros adjusted for The War Within launch.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** The War Within consumables added for launch.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Added mention of Hero Talent stat priorities; expanded further on Haste's effects.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added Hero Talent support to rotations; added section detailing when to use either set of Hero Talents.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Talent builds updated for The War Within release to include Hero Talent recommendations.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Added Hero Talents for The War Within launch.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Added Hero talent discussion; updated recommended talent build for The War Within launch.
- **21 Aug. 2024 (this page):** Updated for The War Within launch with additional tanking changes and Hero Talent discussion.
- **25 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Adjusted an AoE rotation line with Charred Passions and Rushing Jade Wind talented for further clarity.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/brewmaster-monk-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/brewmaster-monk-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/brewmaster-monk-mists-of-pandaria-remix-guide>)):** Page added.
- **14 May 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Adjusted for consistency with MoP Remix Leveling.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Added Patch 10.2.7 tuning notes.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Page reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Gear lists updated with Dragonflight Season 4 recommendations; added Antique Bronze Bullion purchase recommendations; created additional tables for unique weapons and trinkets.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Page reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Page reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Page reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Flex talent examples updated for Dragonflight Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Simplified Talent Selection table to account for talents that are taken regardless of build; removed now-unnecessary information for Dragonflight Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Page reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Page reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Page reviewed for Dragonflight Season 4.
- **22 Apr. 2024 (this page):** Recent changes and viability updated for Dragonflight Season 4; slight adjustment to strengths/weaknesses.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Page reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Offensive raid trinket order revised; page reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Added a macro for Bonedust Brew behavior; page reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Page reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Page reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Page reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Revised rotation basics to emphasize thinking in 4-second chunks; page reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Raiding talent builds separated into defensive and offensive options; Invoke Niuzao build removed due to limited applications; page reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Page reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Added additional rotational guidance; page reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Page reviewed for Patch 10.2.6.
- **19 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Reorganized flex talents based on likelihood of use; added separate entry for utilizing Dragonfire Brew instead of Charred Passions.
- **19 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Elaborated further on Dragonfire Brew vs Charred Passions with the Amirdrassil Set Bonuses.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Page reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Page reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Page reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Page reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Page reviewed for Patch 10.2.5
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Page reviewed for Patch 10.2.5; listed specific dungeons where Detox should be talented; added link to FAQ regarding talenting Press the Advantage.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Page reviewed for Patch 10.2.5
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Page reviewed for Patch 10.2.5
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Page reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Page reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Recent changes updated for Patch 10.2.5.
- **10 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Slight gear adjustments based on recent hotfixes and simulation optimizations, particularly regarding trinkets.
- **10 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Added mention of additional behaviors related to Mastery.
- **10 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added buttons to quickly select talents based on recommended builds; slightly adjusted rotations for specific talent setups based on recent simulation optimizations; further clarified Press the Advantage and Blackout Combo behaviors, among other abilities.
- **10 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Slight talent adjustments to the Generic and Invoke Niuzao builds; wording cleanup on certain talent descriptions.
- **10 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Added additional clarification for certain abilities; standardized terminology across effects.
- **10 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Added a suggestion to try out Weapons of Order; swapped recommended talented class cooldowns.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Page reviewed for Patch 10.2.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Adjusted with new recommended Dungeon/Raid gear and Trinkets for Dragonflight Season 3; adjusted unique weapon discussion; added an explanation of Amirdrassil set bonus effects.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Page reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Added new Helm enchant; adjusted healing potion and phial recommendations for Patch 10.2; specified Shocking Disclosure primarily being a cheap choice.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Offensive stat priority slightly readjusted for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Wordings adjusted in preparation for Dragonflight Season 3; added mention of the Staggering Strikes talent for lower keystone levels.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Revised Walk with the Ox Checkbox to also include Call to Arms; added further discussion of Improved Invoke Niuzao and sample opening ability sequences; page sections reformatted for reduced visual clutter.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Added an additional talent build focusing on Improved Invoke Niuzao, the Black Ox for Patch 10.2; included discussion of Escape from Reality as a niche talent choice.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Reworded the usage of Spinning Crane Kick with Press the Advantage talented.
- **06 Nov. 2023 (this page):** Recent changes and viability updated for Patch 10.2.
- **10 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added an additional rotation line in single-target with Press the Advantage; adjusted Rushing Jade Wind maintenance and Chi Wave priorities.
- **10 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Added an additional talent build for Legacy Content/maximizing movement speed.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Page reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Page reformatted for Patch 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Page reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Recommended Single-target potion altered for Patch 10.1.7; Frozen Devotion recommendation removed due to cheaper enchantment prices.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Page reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Default Mythic+ talent build slightly revised; flex talents reorganized; utility usage tips reformatted.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added disclaimer to Exploding Keg in single-target with Blackout Combo talented; slightly revised AoE priority for Rising Sun Kick.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Page formatting adjusted; Open-World and Mythic+ talent recommendations slightly adjusted.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Added Zen Pilgrimage for comprehensive purposes.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Adjusted one talent recommendation for more beginner-focused content.
- **04 Sep. 2023 (this page):** Reformatted recent changes section as part of Patch 10.1.7.
- **12 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Mentioned the possibility of a higher item level Borrowed Time; rings reordered for better clarity.
- **12 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Added additional guidance on talent swapping decisions.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Recommended leveling build revised based on new talents in Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added Dawn of the Infinite gear; rings adjusted.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Page reviewed for Patch 10.1.5
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Added a note about Onyx Annulet no longer being the best choice at higher item levels in Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Offensive stat priority slightly adjusted for 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Adjusted default Mythic+ build due to new talents in Patch 10.1.5; added further notes on talents to consider swapping into as necessary.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Rotation adjusted to reflect new talents and possibilities; added a section detailing advanced usage of Press the Advantage.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Default build adjusted to reflect new Patch 10.1.5 talents; additional talent notes added for possible choices.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Added new Yu'lon's Grace, Dance of the Wind, and Press the Advantage talents.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Recommended build and stats updated due to new talents in Patch 10.1.5.
- **10 Jul. 2023 (this page):** Summarized Patch 10.1.5 changes.
- **02 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Bountiful Brew usage advice adjusted based on a recent hotfix.
- **02 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Slightly adjusted the wording of Weapons of Order to reflect a recent hotfix.
- **02 Jun. 2023 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated Bountiful Brew and Weapons of Order descriptions based on recent hotfixes.
- **24 May 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added mention of Firelands Timewalking trinkets and a recent Weapons of Order hotfix.
- **10 May 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated special weapon discussion due to updated simulations; offensive trinkets slightly revised.
- **03 May 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Embellishment/crafted gear priority modified; recommended tier slot "offpiece" changed based on recent simulations.
- **03 May 2023 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Weapon enchants updated with specific target counts; single-target potion recommendation changed.
- **03 May 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Slight rotation priority adjustment based on the specific talent combination of Charred Passions and Blackout Combo.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Incendiary Breath removed; replaced by Alpha Tiger and Eerie Fermentation.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Adjusted with new recommended Dungeon/Raid gear and Trinkets for Dragonflight Season 2; added sections on unique weapon effects and upgrade priorities.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Added mention of the Draconic Phial Cauldron in Patch 10.1; removed infrequently-used Primordial Stones.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Added Song of Chi-Ji to utility list; discussion of new gear upgrade system.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added discussion of the Aberrus 4-piece bonus slightly changing talent choices.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Added Song of Chi-Ji as a new niche talent; Incendiary Breath honor talent removed.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Added new Song of Chi-Ji talent.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Page reviewed for Patch 10.1. No changes necessary due to no Brewmaster Monk updates.
- **01 May 2023 (this page):** Summarized Patch 10.1 changes; updated discussion of viability; added section highlighting most recent guide updates for Patch 10.1.
- **14 Apr. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Slightly adjusted recommended default Mythic+ talent build.
- **14 Apr. 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Slightly adjusted priority of Breath of Fire for specific talent builds.
- **01 Apr. 2023 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Primordial Stone recommendations modified with tuning now finalized.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/brewmaster-monk-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Updated with new 10.0.5 talent trees.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated talent trees with new 10.0.5 talent choices.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Expanded notes on Blackout Combo usage to account for greater selection potential in Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Talent trees adjusted based on 10.0.5 talent changes; added notes on Blackout Combo as a potential talent decision.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Added the new Spirit of the Ox Talent, along with other adjustments as part of Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Talents adjusted to account for changes in Patch 10.0.5.
- **24 Jan. 2023 (this page):** Summarized 10.0.5 changes; strengths/weaknesses slightly adjusted.
- **12 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Added additional information on embellishments; adjusted dungeon trinket recommendations.
- **12 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Slightly adjusted Consumable recommendations; adjusted Chest Enchants.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Dungeon gear revised and recommended raid gear added; trinkets substantially expanded for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Recommended build slightly adjusted based on recent theorycrafting; added table mentioning when to consider alternate talents.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Added a section regarding the Vault of the Incarnates Tier Set bonuses; general wording adjustments.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Sections describing when to choose certain rotation-altering talents have been adjusted based on recent theorycrafting.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Adjusted general build to focus on world content and entry-level Mythic+/Raiding. See their respective guide sections for more tailored builds.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Build and talent recommendations slightly adjusted based on recent developments regarding Charred Passions, Dragonfire Brew, Special Delivery, and Rushing Jade Wind.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Updated for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Updated for leveling to 70 in Dragonflight.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/brewmaster-monk-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/brewmaster-monk-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/brewmaster-monk-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/brewmaster-monk-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **18 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/brewmaster-monk-patch-9-2-changes-analysis>)):** Updated for the launch of Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/brewmaster-monk-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/brewmaster-monk-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **02 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/brewmaster-monk-patch-9-1-changes-analysis>)):** Adjusted page formatting and wording for live release of Patch 9.1.
- **20 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/brewmaster-monk-patch-9-1-changes-analysis>)):** Added new Legendary Powers and a preliminary analysis of them.
- **17 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/brewmaster-monk-patch-9-1-changes-analysis>)):** Page created with initial information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **14 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-the-eternal-palace-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-the-eternal-palace-raid-guide>)):** Page created.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-crucible-of-storms-raid-guide>)):** Page created.
- **11 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-battle-of-dazar-alor-raid-guide>)):** Removed mention of stacking damage bug on Jaina.
- **28 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-battle-of-dazar-alor-raid-guide>)):** Updated significantly for Mythic.
- **31 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-battle-of-dazar-alor-raid-guide>)):** Added some Mythic details.
- **24 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-battle-of-dazar-alor-raid-guide>)):** Extensive updates to Mekkatorque, minor updates to other bosses.
- **20 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-battle-of-dazar-alor-raid-guide>)):** Page created.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **16 Oct. 2018 ([Uldir page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-uldir-raid-guide>)):** Added Mythic strategies for every boss other than G'huun, minor improvements and tips elsewhere.
- **19 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-uldir-raid-guide>)):** Altered Mythic tips.
- **11 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-uldir-raid-guide>)):** Updated after week one, and added early Mythic tips.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-uldir-raid-guide>)):** Extensive rework for Uldir launch.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-uldir-raid-guide>)):** Added more content.
- **13 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-uldir-raid-guide>)):** Updated for Battle for Azeroth launch.
- **23 Jul. 2018 ([Uldir page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-uldir-raid-guide>)):** Updated some talents and Legendary recommendations.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Brewmaster Monk leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Monk leveling guide](<https://www.icy-veins.com/wow/monk-leveling-guide>).

1.

### Brewmaster Monk Leveling Guide for Midnight

As a tank specialization, Brewmaster Monks excel at gathering
up large numbers of enemies and dealing large amounts of AoE damage as they easily
survive the onslaught of attacks with the help of [[spell:115069]]. This makes
them ideal for questing both solo or with a friend in particular, as they are able to rapidly
move between groups of foes, keeping attention with skills like
[[spell:116847]] and [[spell:121253]], while their partner takes care of
defeating them. If you are questing solo, this can still be done, but it may
take a little longer due to your relatively low damage output. If you are concerned
about needing a healer during leveling, the [[spell:1231418]] ability can be used
to repeatedly heal yourself out of combat and recover after a large pull.

Brewmaster Monk is also an excellent choice for gaining
experience through dungeon queues and quests. Tank players are always in high
demand, resulting in nearly instant queue times. Fortunately, due to leveling quests
increasing in level as you do, this means you can repeatedly join queues while
traveling to and from questing areas without any disruptions to your overall
experience gain!

1.1.

#### Leveling Gear Options

During leveling, item level is even more important than normal on your
Brewmaster. You should always pick the item with a higher level, with the
possible exceptions of jewelry and trinkets. For these slots, you may wish to
select the item that is providing more Critical Strike or Versatility. On
trinkets, you have the opportunity to experiment with various effects, so pick
whatever you desire if it is reasonably close to your item level.

If using Heirloom items, we recommend using those with Critical Strike in particular,
as this will improve both your damage and your defense; ultimately anything with Agility
will work though!

1.2.

#### Useful Leveling Consumables for Midnight

There are a number of <em>optional</em> consumables that can be gathered and used
to help speed up your leveling. There is no need to go overboard on hoarding too
many, as you will only need to level each character once, and many of the items
listed here quickly become less enticing once you have reached max level and enter
tougher content.

To be as prepared as possible, look to acquire at least some of the following
items and enchants.

- [[item:191348]] (Level 61+) — This is a tradeable consumable from the [Dragonflight](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  expansion that increases your speed stat for 30 minutes, which will also persist
  through death. For players that already have high item level gear or heirlooms, leveling is
  frequently about traveling quickly rather than defeating enemies any faster than
  they already can.
- [[item:225592]] (Level 75+) — A food item from [The War Within](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>),
  this tradeable dish similarly grants a bonus to movement speed for an hour,
  but is lost on death.
- [[item:242299]] (Level 80+) — A new consumable in Midnight, this
  and other teas gives a "Relaxed" buff rather than "Well Fed", allowing you to
  have both at once. However, these teas only work outside of instances. Consume
  this or another tea for an additional movement speed bonus for an hour that is
  similarly lost on death.
- [[item:223653]]/[[item:223683]]/[[item:223725]]/[[item:223800]] (Level 70+) —
  These four enchants are a smaller source of movement speed than other consumables, but if
  you will be wearing the same pieces of armor throughout leveling their
  effects can add up over time.
- [[item:132516]] — One of the more unusual consumables, this tradeable item from
  Legion Engineering allows you to move faster than ground
  mount speed for a long duration and even enables movement over water, but breaks upon
  taking damage and cannot be activated while in combat. If in an area where you
  cannot mount, consider it your fastest movement tool.
- [[item:154168]]/[[item:154169]] — Though
  it is rare to need them, these two tradeable consumables from Battle for Azeroth can
  be paired together to grant you underwater breathing and greatly increased swim
  speed that is faster than an aquatic mount.
- [[item:109076]] — Although you are able to eventually negate fall damage
  with the help of [[spell:449582]], this consumable allows you to also
  travel through the air from great heights if you are unable to mount. Consider
  pairing one with a [[item:122124]] or [[item:104299]]!

2.

### Leveling Talents

Talents are additional effects and abilities that can give you access
to more tools in your spellbook. They are unlocked on a regular basis as you
level.

**等级 10 起：**Your talent setup should be as follows with each
talent point as you unlock them. Note that these recommendations may differ from
what is shown in our main guide for a maximum-level player.

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Brewmaster Level 80 Midnight Leveling
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZZzYGzwyM2MmZMAAAAAAALLgYmBmhBzgZmZwshZMzywymltZbGzGAAsMLTLz2AAAAADbgZGw0YADAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZZzYGzwyM2MmZMAAAAAAALLgYmBmhBzgZmZGzsNMjZWGW2ssNbzY2AAglZZaZ2mZZAAAAMsBmZATjBMAgB"
}
```
:::

:::details 来源计算器编码
```
#ME-vLKWXJQPtXtppJIUNNbKGglNQXHn4zTTvRQ-YXIkDEYdMsQLlDpKKnojQdf8AzEuoy5L-AAAA-WYaOECAQowoSCE-DHF
```

:::

2.1.

#### War Mode Talents for Leveling

If you are willing to utilize War Mode, the
following PvP talents are recommended during leveling or for other open-world
content. There may be times when you would like to use other options and are
encouraged to experiment! PvP talents can be freely changed at any time.

Your first PvP talent slot will unlock at Level
20, your second at Level 30, and the final at Level 40.

- [[spell:202335]] will allow you to
  frequently increase the damage of your [[spell:121253]] and also allow it to
  stun everything it hits. It can also be used in a macro to make it effectively
  a passive benefit.
- [[spell:232876]] acts as a stronger version
  of the [[spell:450622]] talent, allowing you to remove all snare effects every
  time you cast [[spell:119582]], [[spell:322507]]/[[spell:1241059]],
  or [[spell:109132]]. With leveling involving a lot of moving around, it is all the
  more important to be able to travel at full speed without any number of enemy
  debuffs hindering you.
- [[spell:205147]] will passively give you
  additional movement speed and magic damage reduction no matter how little [[spell:115069]]
  you have.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 5–8：**(Optional): Tag an enemy with
   [[spell:117952]] to have it move toward you, provided you
   immediately cancel the ability after casting.
2. **等级 9–25：**(Optional): Use [[spell:115546]]
   to force an enemy to run to you or briefly "tag" them with
   [[spell:117952]], provided you immediately cancel its cast
   afterward.
3. **等级 26–87：**(Optional): Use [[spell:115546]]
   to force an enemy to run to you (at high speed if [[spell:328670]] is talented)
   or briefly "tag" them with [[spell:117952]], provided you
   immediately cancel its cast afterward.
4. **等级 88 起：**(Optional): Use [[spell:115546]]
   to force an enemy to run to you or briefly "tag" them with
   [[spell:117952]], provided you immediately cancel its cast
   afterward. If you are using [[spell:115315]], place it near multiple
   enemies to get all of their attention at once.
5. **等级 17 起：**Use [[spell:116847]] before directly
   engaging your targets. If [[spell:196730]] is talented instead, you will
   passively deal damage from using "Brew" abilities.
6. **等级 10 起：**(Optional): Use [[spell:322109]]
   to instantly kill the target if it is usable. Recommended for tougher enemies or
   for quest bosses.
7. **等级 11 起：**Cast [[spell:121253]] as your opening ability
   when entering combat and on cooldown
   afterward**等级 84 起：**. This includes any resets of the ability
   from your Apex talent of
   [[spell:1265138]]**等级 26 起：**. If you have
   talented into [[spell:450391]] instead of [[spell:123986]], this will also
   cause it to activate.
8. **等级 2 起：**Cast [[spell:100784]] whenever it is
   available.
9. **等级 29 起：**Cast [[spell:115181]] on enemies hit
   by [[spell:121253]] and reduce the damage they deal to you**等级 31 起：**. Since
   the cooldown will reset every time you cast Keg Smash, you can wait to press it
   if more important abilities like [[spell:100784]] are available instead.
10. **等级 55 起：**Throw [[spell:325153]] at your enemies to
    deal a massive burst of damage**等级 59 起：**. If talented instead
    of [[spell:1262017]], you can also reactivate the ability to trigger
    [[spell:1262329]] for additional damage.
11. **等级 26 起：**Cast [[spell:123986]], if talented, on cooldown
    to deal more damage and heal yourself.
12. **等级 17 起：**Refresh your [[spell:116847]].
13. **等级 2–6：**Cast [[spell:100780]] as a filler, but
    do not go below 40 Energy.
14. **等级 7 起：**Cast [[spell:100780]] as a filler if
    fighting one target, but do not go below 40 Energy.**等级 51 起：** With
    [[spell:196736]] talented, you will always want to spend its buff on this ability.
15. **等级 7 起：**Cast [[spell:101546]] as a filler
    if fighting multiple targets, but do not go below 40 Energy. **等级 51 起：** With
    [[spell:196736]] talented, you will only use this ability to assist in gathering
    enemies.
16. **等级 8–42：**Cast [[spell:322101]] as necessary to offset
    your damage taken.
17. **等级 43 起：**Cast [[spell:322101]] if you are in need of
    healing and to gather your Healing Spheres from [[spell:124502]]/[[spell:400629]].
18. **等级 20 起：**In an emergency, you may instantly cast
    [[spell:116670]] once per cast of [[spell:121253]] due to [[spell:388812]].
    This is largely to be used for convenience during leveling.

**等级 13 起：**3.1.

#### **等级 13 起：**Active Mitigation

- **等级 13 起：**Maintain [[spell:322120]] by continuing to
  cast [[spell:100784]] and
  [[spell:121253]] on cooldown to smooth out your damage taken.
- **等级 19 起：**Cast [[spell:119582]] largely on cooldown when
  actively fighting an enemy and suffering damage from [[spell:115069]], but save one
  charge for emergencies.
- **等级 27 起：**Cast [[spell:1241059]], mostly on cooldown,
  to shield yourself against some incoming damage.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Adjusted consumables and other wording for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Slightly revised leveling order to incorporate Counterstrike over Tranquil Spirit; included further leveling resources, along with Heirloom guidance.
- **26 Feb. 2026:** Added useful leveling consumables for Midnight; adjusted leveling path for Leveling to 90.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Leveling talent pathing overhauled for Patch 11.2.0 tree updates.
- **15 Jun. 2025:** Updated for Patch 11.1.7; switched Dragonfire Brew for Charred Passions.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Page reviewed for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Added Hero Talent pathing recommendations, along with playstyle pointers.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **14 May 2024:** Adjusted for consistency with MoP Remix Leveling.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Page reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Page reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Page reviewed for Patch 10.2.
- **04 Sep. 2023:** Page reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Recommended leveling build revised based on new talents in Patch 10.1.5.
- **01 May 2023:** Incendiary Breath removed; replaced by Alpha Tiger and Eerie Fermentation.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated with new 10.0.5 talent trees.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for leveling to 70 in Dragonflight.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Brewmaster Monk in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Brewmaster Monk

This section is intended for players who are new to the game or Monk
class, have no intentions of raiding ![Mythic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-mythic.png>)Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for more optimal play. While it also assumes that your gearing is fairly
minimal, your set bonus effects may be considered. However, they are entirely passive
and will not meaningfully alter your rotation or talent choices.

Brewmaster Monks are some of the sturdiest brawlers out there, capable of
shrugging off even the deadliest attacks with ease while offering plenty of
options for mobility and defense. With the help of [[spell:115069]], there is
next to nothing that can outright kill you in one hit, which makes for a
more predictable damage intake to heal.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_shuffle.jpg>) **Stay Shuffling**  
  
    Your most important buff when playing Brewmaster is [[spell:322120]]. This
    empowers your [[spell:115069]] passive to keep you safe from damage feeling "spikey".
    By pressing [[spell:121253]] and especially [[spell:100784]] on cooldown, you
    will maintain it with ease.
- ![](<https://static.icy-veins.com/images/wow/large_icons/achievement_brewery_2.jpg>) **Be Energy Efficient**  
  
    A Brewmaster has three main abilities that cost Energy: [[spell:121253]],
    [[spell:100780]], and [[spell:322729]]. You will always want
    to have enough Energy to keep casting Keg Smash on cooldown, spending further Energy
    on Tiger Palm when your "free" abilities like [[spell:100784]] and [[spell:115181]]
    are on cooldown. Spinning Crane Kick is only used as a gathering tool and will not be used even
    in AoE combat.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_beer_06.jpg>) **Stagger your Brew Usage**  
  
  [[spell:119582]] helps reduce the damage taken by your [[spell:115069]]
    passive. Good times to use it are when the button is glowing, or when you are
    about to reach 2 charges. You can also use [[spell:1241059]] to further
    smooth out your damage taken. Both of these abilities have their cooldowns reduced
    by [[spell:121253]] and [[spell:100780]].

2.

### Beginner's Guide to Brewmaster Monk in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony   Single-Target/Raid Talents

2.1.

#### Beginner Single-Target Talents for Brewmaster Monk

Below is a "default" talent tree containing many of the most standard and
common talent choices for you to select in beginner-level content while having
the flexibility to adjust a few points as necessary for different scenarios.
If you desire an even more simplified experience, then it is recommended to switch
the choice node of [[spell:196736]] at the bottom of the
specialization tree to [[spell:418359]]. Remember that you can easily
import the talent tree below into the game with the "Export Talents" button!

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZZzYGzwyM2MmZMAAAAAAALLYEzMwMMYGMzMzwsNmZMzyDwymltZbYWAAglZZaZ2mZZAAAAmhFwMDYaMgBAMA"
}
```
:::

:::details 来源计算器编码
```
#ME-LQWXvAKPbraFLgIZKTTLMNQXnn4xyzTOVWT-YBCOuIhYhOswhUKtjnKKQZ4017L4yjqJ-AAAA-EIUY8QZhpJQCAE-
```

:::

2.2.

#### Beginner Single-Target Hero Talents for Brewmaster Monk

Brewmasters have access to two unique sets of Hero Talents, with the
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan tree focusing on delivering bursts of [[spell:450615]]
and the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony tree revolving around building and spending
<em>vitality</em> as an [[spell:450508]]. Fortunately, these talents are
almost entirely passive, allowing you to easily switch between them without any
major impact on your general gameplay.

With that being said, we recommend making use of the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony
talents in single-target as a beginner due to how they help with empowering your defensive abilities.
You can certainly still try the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan talents instead if you would
like to, and you may even find them helpful for their more passive style of defense.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan   Mythic+/AoE Talents

2.3.

#### Beginner AoE and Mythic+ Talents for Brewmaster Monk

Brewmaster Monk is a somewhat unique specialization in that there
are few, if any changes to be made in your talent selection when fighting in
single-target or AoE. The most noteworthy talents to mention are [[spell:123986]], which
becomes better than [[spell:450391]] against two or more targets, and the inclusion
of [[spell:1262017]] to further enhance your AoE damage with every use of
[[spell:325153]]. Otherwise, your talent switching will be based
around matters of both personal preference and whatever utilities you require
for the content you are taking on. This also includes your Hero Talents, where
the passive AoE damage of [[spell:1262612]] on the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan
can make for an easier time in managing threat. Of course, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony
talents also include a similar option in [[spell:451024]]; feel free
to experiment!

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZZzYGPwYWmxmxMjBAAAAAAYZBjYmBmhBzgZmZGmtxMjxywymltZbGzCAAsBAAAmtZpZmZWYYDgZGmGDYAAD"
}
```
:::

:::details 来源计算器编码
```
#ME-LQWXvAKPbraHLgIZKTTLMNQXnn4xyzTOWWT-YBCOouINsAxhULtoKdHhyAGu8oe28ljH-AAAA-FGUYcgoYhpJYCA-
```

:::

2.4.

#### Beginner AoE Hero Talents for Brewmaster Monk

Brewmasters have access to two unique sets of Hero Talents, with the
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan tree focusing on delivering bursts of [[spell:450615]]
and the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony tree revolving around building and spending
<em>vitality</em> as an [[spell:450508]]. Fortunately, these talents are
almost entirely passive, allowing you to easily switch between them without any
major impact on your general gameplay.

In AoE, we recommend making use of the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan
talents as a beginner specifically due to how they passively grant AoE
damage, defense, and enhance your most important damaging abilities. You can certainly still try the
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony talents instead if you would like to, and you may even
find them helpful for reinforcing how to play defensively.

### Brewmaster Monk   Basic Rotation

2.5.

#### Basic Rotation for Brewmaster Monk

When performing the Brewmaster rotation, it may be helpful to think in terms of
[[spell:100784]]'s cooldown. It will **always** be 4 seconds, and your
global cooldown will **always** be exactly one second. This means you will often
be using your abilities in sequences of
Blackout Kick>ability1>ability2>ability3>Blackout Kick. By breaking
things down to only four abilities at a time, you may have an easier time
following the flow of being a Brewmaster.

1. Throw [[spell:121253]] when available. It will also turn into free casts
    of [[spell:1265133]] by using "Brew" abilities thanks to your Apex Talent:
    [[spell:1265129]].
2. Use [[spell:100784]] on cooldown.
3. Cast [[spell:115181]] when you can; its cooldown will be fully reset every
    time you use [[spell:121253]]!
4. Activate [[spell:132578]] when fighting for a long time.
5. Cast [[spell:123986]] when talented and available.
6. Throw [[spell:325153]] when available. Afterward, when [[spell:1262329]]
    is talented, you can reactivate the ability to trigger bonus damage.
7. Use [[spell:100780]] when there is no other ability available. If fighting
    multiple targets, you will **still** use Tiger Palm instead of [[spell:322729]].
8. Cast [[spell:322101]] if you are dropping in health. You can also instantly
    cast [[spell:116670]] for healing once every time you use [[spell:121253]], thanks
    to [[spell:388812]]. Do **not** try to cast Vivify if it is not buffed by the talent.
9. Activate [[spell:388917]] when in an emergency situation.

You should make sure not to spend so much Energy on [[spell:322729]]
or [[spell:100780]] that you cannot cast [[spell:121253]] when it is available.
Following these steps will make sure you do as much damage as you can and have
enough Brews to maintain a solid defense.

2.6.

#### Apex Talents for Brewmaster Monk

All specializations have access to a unique 4-part effect in Midnight known as their
Apex Talent. For Brewmasters, this Apex Talent is called **Bring Me Another**,
and it works to passively empower the [[spell:121253]] ability. By using your defensive
abilities of [[spell:119582]], [[spell:1241059]], and [[spell:388917]],
your Keg Smash will often have its cooldown reset and replaced with the [[spell:1265133]]
ability. This ability has no Energy cost and deals a large amount of bonus damage,
while also providing you with a heal in the form of [[spell:1265145]]. Aim
to use these triggers of Empty Barrel as soon as you can!

2.7.

#### Season 2 Tier Set Bonus for Brewmaster Monk

As you obtain gear in Season 2 of Midnight, you may gradually encounter
tier pieces that unlock unique bonuses to your specialization when two or four
pieces of them are equipped. For Brewmasters, this includes damage buffs to your
[[spell:121253]] and other Physical abilities, as well as additional Fire damage
whenever it is thrown. However, these bonuses do **not** change your rotation
in any way, nor do they adjust your priority of abilities. Simply enjoy the free damage!

### Brewmaster Monk   Mitigation and Defensive Spells

2.8.

#### Brewmaster Mitigation: Shuffle and Brew Usage

When playing a Brewmaster Monk, it is very important to always
have the [[spell:322120]] buff present. This results in your damage taken being
spread out over a longer period of time due to how it improves your [[spell:115069]]
passive. You gain time on Shuffle by casting [[spell:121253]], [[spell:100784]],
and [[spell:322729]]. If you are using the default UI, you can
easily monitor the time left on your Shuffle by looking at the icon outlined in purple:

![Brewmaster UI Elements](<https://static.icy-veins.com/images/wow/classes/monk/brewmaster-shuffle-stagger-ui-element.jpg>)

Next, you make use of [[spell:119582]] to get rid of damage you have
[[spell:115069]]ed. The level of Stagger on the default UI is shown above
and outlined in red. The more the bar is filled, the more damage you are
taking. Remember, though, it is equally important to maintain uptime on
[[spell:322120]] so that your damage taken stays smooth as you purify what you
can.

In addition to [[spell:322120]] and [[spell:119582]], you also can use
the [[spell:1241059]] ability to absorb a large amount of damage taken
for a decent length of time.

2.9.

#### Defensive Spells for Brewmaster Monk

In addition to the basic mitigation tools above, Brewmasters have access to one
main defensive cooldown through talents. It is the following:

- [[spell:388917]] — Your "biggest" cooldown; this temporarily
  increases your health and reduces all damage taken. You can further customize it
  to enhance its strength or lower its baseline cooldown, and your rotation will also
  grant cooldown reduction to it and your other "Brew" abilities!

### Brewmaster Monk   Stat Priority

2.10.

#### Stat Priority for Brewmaster Monk

When gearing a Brewmaster Monk, you should prioritize item
level above all else, as Agility, Armor, and Stamina are very valuable. Do not
bother to drop item levels to avoid a piece that has Haste.
For more information on what's presented on this page, check out our main
[Stat Priority page](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>).

Item Level

Critical Strike

Versatility

Mastery

Haste

While the stat priority for Brewmasters is normally the same for both the Beginner
Mode page and our full guide, there can be minor differences depending on if you
desire to be more offensive or defensive as a tank. If you want to see the full
explanation of the stat priority, as well as the absolute top choices for what
you want to prioritize, head to our full stats page.

### Blizzard   Combat Assistant

2.11.

#### Combat Rotation Assistant for Brewmaster Monk

If you would like a more convenient option when first gaining the feel for the
Brewmaster Monk rotation, there is also a [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) available from
the spellbook. This assistant can perform a simplified version of the damage rotation
and only requires you to use a single keybind. However, making use of this assistant
comes at the cost of an increased cooldown between abilities on every press.

Fortunately, this penalty is not too great a cost to your overall damage, and can
likely still be a net improvement if you are inexperienced with a "fully manual"
playstyle. This can especially help with handling the [[spell:196736]] talent
for you!

Note, however, that even with this assistant's help, you **must** still use
your defensive abilities manually, as well as your key offensive cooldown of
[[spell:132578]].

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Small adjustments to recommended talents as part of Patch 12.1; added core tenets of the specialization.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **19 May 2026:** Adjusted stat priority display and combat assistant discussion.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Added Season 1 set bonus discussion.
- **26 Feb. 2026:** Talent Trees and rotation updated for Midnight launch.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Talent builds and rotation updated for Patch 11.2.0.
- **17 Jun. 2025:** Adjusted talent build to account for Combat Assistant enforcing Blackout Combo; rephrased Combat Assistant discussion due to hotfixing.
- **15 Jun. 2025:** Added discussion of the Combat Rotation Assistant in Patch 11.1.7 and its viability for a Brewmaster.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Slightly modified suggested talent build to include Lighter Than Air.
- **15 Dec. 2024:** Ability priority further simplified.
- **21 Oct. 2024:** Formatting updated; beginner talent build adjusted, defaulting to Weapons of Order.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Added Hero talent discussion; updated recommended talent build for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Added additional rotational guidance; page reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Page reviewed for Patch 10.2.5.
- **10 Nov. 2023:** Added a suggestion to try out Weapons of Order; swapped recommended talented class cooldowns.
- **06 Nov. 2023:** Reworded the usage of Spinning Crane Kick with Press the Advantage talented.
- **04 Sep. 2023:** Adjusted one talent recommendation for more beginner-focused content.
- **10 Jul. 2023:** Recommended build and stats updated due to new talents in Patch 10.1.5.
- **01 May 2023:** Page reviewed for Patch 10.1. No changes necessary due to no Brewmaster Monk updates.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Talents adjusted to account for changes in Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Brewmaster Monk in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Brewmaster Monk

Brewmaster Monk is a specialization that offers a fairly
firm foundational set of talents across all builds. You will rarely be picking up or
dropping core components of your overall rotation, instead using your talent points
to flexibly adjust your available cooldowns or defensive needs to match the content
being run. Make no mistake, there are still plenty of points available to move around;
you just get the benefit of your gameplay staying fairly consistent no matter what
it is you are doing.

With that in mind, there are a few starting builds you can begin at for the
main activities of Midnight, modifying a few talents here or there as needed.
These are the following:

- **Raiding (Defensive)** — In raid environments, you will generally
    want to be more defensive and optimize for single-target damage while opting
    out of certain utilities. The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony Hero Talents are best
    for this, though regular add spawns favor a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Brewmaster
    seeking to "pad".
- **Mythic+ (Standard)** — Mythic+ dungeons are where you will need to
    be the most flexible with your talents, switching your damage focus between AoE
    and priority-target based on the group or dungeon, along with your defensive
    choices. Here, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan talents excel, though ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony
    is just as effective and gains value at higher key levels. Ultimately, you have
    a lot of personal preference.
- **Delves/Open World** — The standard content of Midnight rarely
    requires a tank to focus much on their defense, allowing you to opt into more
    damage. Due to this, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony Hero Talents are most useful
    for their single-target focus.

Brewmasters are somewhat rare among specializations in that their Hero Talents
tend to be fairly interchangeable across all content. Both are completely passive
and have plenty of helpful effects for both damage and defense. What really
separates them is in the way you engage with each. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan
Brewmasters emphasize dealing damage in bursts revolving around the [[spell:132578]]
cooldown while gaining lasting damage reduction after dodging attacks. A
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony Brewmaster, meanwhile, will deal more consistent amounts
of damage that are focused on a single foe while buffing the normal defensive abilities
of [[spell:119582]] and [[spell:1241059]]/Brew in your rotation.
You are free to use whichever you enjoy more, knowing that both are viable and have
seen play in the toughest content available!

**Quick Start Import Codes:**

:::talents Brewmaster Raiding (Defensive) - Master of Harmony
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGPwYWM2mxMDAAAAAAALLYEmBmhxmZMmZmZMzywMmZZYZzy2sNMLAAwysMtMbzsMAAAAzwGYmBMNGAAwA"
}
```
:::

:::talents Brewmaster Mythic+ (Standard) - Shado Pan
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMLbGDzwyM2MmZMAAAAAAALLgYmBmhBzgZmZGzsNMjZWGW2stNbzYWAAgNAAAwsNLNzMzGDbAMzw0YADAYA"
}
```
:::

:::talents Brewmaster Delves/Open World - Master of Harmony
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZZzYGzwyM2MmZMAAAAAAALLgYmBmhBzgZmZGzsNMjZWGW2ssNbzYWAAglZZaZ2mZZAAAAMsBmZATjBMAgB"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Master of Harmony

Defensive Raid Build

recommended

Mythic+

high-keys

Delves/Open World

Shado-Pan

Offensive Raid Build

advanced

Mythic+

weekly-keys

Legacy Content

### 天赋方案 0-0

1.1.

#### Default/Defensive Raiding Talents

The following build is focused on your performance within raid encounters. As
such, it does not opt into utility that is rarely seen within a raid or can be
covered by another player instead. Although it opts into some additional defensive
talents, it also aims for a slightly more simple rotation. Depending on
an encounter's needs, you may still need to switch between [[spell:1241059]]
and [[spell:322507]] or consider dropping [[spell:1241097]]. If you would
like to be even more defensive, remove [[spell:1262329]] and [[spell:383994]]
for [[spell:196737]], [[spell:455139]], or even [[spell:455068]],
though be warned that this will come with some fairly significant damage losses.

As for Hero Talents, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony tree's second charge of
[[spell:1241059]] and strong single-target performance make it well-tailored
to raid environments in particular. Plus, your [[spell:119582]] will also
<em>purify</em> more [[spell:115069]] with each cast, and [[spell:451024]]
still enables extra cleave damage in suitable encounters.

### 天赋方案 0-1

1.2.

#### High-Key Mythic+ Talents

As you grow more comfortable playing a Brewmaster Monk in Mythic+ and reach higher
key levels, this build can be switched to for more skill-based defensive potential
at the cost of some damage. This is primarily through dropping [[spell:1241097]],
relying once again on careful use of [[spell:322101]] healing. While it also opts
into [[spell:115399]], you can instead make use of [[spell:280515]]
for effectively equal passive defense at the expense of less on-demand power. At
these higher key levels, you will also start
talenting into [[spell:1241136]], [[spell:196737]], [[spell:386937]], or even
[[spell:393357]] and [[spell:455139]], frequently dropping
[[spell:1262017]]/[[spell:1262329]], [[spell:387219]], [[spell:325153]],
or even [[spell:196730]] to do so.

Beyond these choices, this build also opts to instead play with the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony
hero talents under the assumption that you will need to focus more on single and
priority-target damage in high keystones. Be aware that it has a more strict
positioning requirement due to the narrow cleaving effect of [[spell:451024]],
and you will be punished for poor use of [[spell:100784]] and [[spell:196736]].
If you instead wish to optimize for large AoE pulls or an easier experience, the
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Hero Talents will still work just fine due to the uncapped and reliable AoE of
[[spell:1262612]] as well as your empowered [[spell:132578]].
Remember, at the highest keystone levels **either Hero Talent can excel**.

### 天赋方案 0-2

1.3.

#### Delves/Open-World Talents

While optimizing talents on a contextual basis is the <em>highly</em>
recommended method of setting up your build, the talent tree listed
below will work well for **general purposes** such as [Delves](<https://www.icy-veins.com/wow/delves-guide>),
world content, and entry-level dungeons and raids. It is still highly recommended
to switch to a more specialized build if engaging in something specific.

When making use of this build in [Delves](<https://www.icy-veins.com/wow/delves-guide>) in particular, it is
recommended to take advantage of the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony Hero Talents specifically
due to the massive buffs it provides to [[spell:100780]] to decimate a priority target.
You may still use the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan talents instead, of course!

### 天赋方案 1-0

1.4.

#### Advanced/Offensive Raiding Talents

Once you are appropriately comfortable with your playstyle as a Brewmaster Monk,
consider switching to this set of talents to fully maximize your damage potential
across encounter types. Be aware that it will ask of you to make use of [[spell:115399]]
and properly-timed casts of [[spell:132578]] in particular, while
sacrificing some defensive power by giving up [[spell:393357]]. It will
also expect you to make effective use of [[spell:322101]] due to not having
[[spell:1241097]]. Beyond these differences, this build is still focused
primarily on raiding, and it will similarly not have all of your available
utility selected. In fact, you may end up dropping further options, such as
[[spell:450448]], in favor of acquiring the positioning improvements of
[[spell:328670]]. If this build's choices seem too daunting, you can
even opt for somewhere in between it and our Default raiding talents by
dropping [[spell:1262017]] and picking up [[spell:1262659]], [[spell:455068]],
or [[spell:196737]] in particular.

For Hero Talents, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan tree offers near-identical damage potential
in single-target moments while gaining a noteworthy edge in AoE. As most encounters
in the raids of Midnight Season 2 contain multiple targets, this Hero Talent choice
will usually result in more damage overall. However, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony
talents generally continue to provide better defensive flexibility if you are
still progressing through a fight. Be ready to switch between both as necessary!

### 天赋方案 1-1

1.5.

#### Standard Mythic+ Talents

Dungeons feature a lot more talent flexibility due to the variety of scenarios
you will encounter. Due to the wider variety of utility and AoE needs,
this build opts into [[spell:325153]]'s follow-up talent of [[spell:1262017]].
However, it also defaults to [[spell:1241097]] along with [[spell:115399]]
to create additional bursts of defense for a more convenient healing experience.

Although this build features the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Hero Talents, you
can easily switch to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony instead. By comparison, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan's
total damage output at lower target counts—3 or less—will be worse in exchange for
more convenient AoE through [[spell:1262612]] and more frequent
access to [[spell:132578]]. Defensively, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan's
[[spell:450992]] is also noticeably potent in AoE tanking.

### 天赋方案 1-2

1.6.

#### Legacy Content/Movement Speed Talents

Highlighting the unique amount of flexibility available through
talent trees, the following build is intended for <em>trivial</em> content that
you wish to get through as quickly as possible, such as old raids or previous
expansion features. It makes use of talents that are otherwise not taken during
your time in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), though you should further complement it
with other legacy speed-boosting effects such as a [[item:191348]],
 [[item:225592]], and [[item:242299]].

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGPwYWM2mxMDAAAAAAALLYEmBmhxmZMmZmZMzywMmZZYZzy2sNMLAAwysMtMbzsMAAAAzwGYmBMNGAAwA"
}
```
:::

:::details 来源计算器编码
```
#ME-LQWXvKPsstn2WJgALTTLMVNQXnozTOzRwqe-YBCPuIhYhOswh0JtjnKNQZ4017Lo5iKF-AAAA-EIUY8YhpJAgSCE-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGGzyMPw2wMjBAAAAAAYZBEzMwMM2MDmZmZY2GzMmZZYZ7B22mthZBAAWmlplZbmlBAAAwwGYmBMNGAAwA"
}
```
:::

:::details 来源计算器编码
```
#ME-LQWXvKPbrYZbLIZqammWoaaguOPxjlnncAm-YBCPuIZhOswh0JtjnNQc769d5JzWEIiK-AAAA-EIosw0kA5oIAgR-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZZzYGzwyM2MmZMAAAAAAALLgYmBmhBzgZmZGzsNMjZWGW2ssNbzYWAAglZZaZ2mZZAAAAMsBmZATjBMAgB"
}
```
:::

:::details 来源计算器编码
```
#ME-vLKWXJQPtXtppJIUNNbKGglNQXHn4zTTvRQ-YXIkCEYdMsQLlDpKKojQd9AzEuoey57D-AAAA-WYaOEUCAQowYCE-DHF
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMbbGDzYWmxGmZAAAAAAAYZBjYmBmhBzYMzMzYmlhZMWGW2stNmxsAAAbAAAgZbWamZmFzwGAzMMNGwAAG"
}
```
:::

:::details 来源计算器编码
```
#ME-LQWXvKPsstjTm2WJgALTTLMNQXnozTOTvRQ-YBCPuI5QqF6wCFlGtjnQZ421D0c5RNEA-AAAA-HUIswE0QRyBQDC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMLbGDzwyM2MmZMAAAAAAALLgYmBmhBzgZmZGzsNMjZWGW2stNbzYWAAgNAAAwsNLNzMzGDbAMzw0YADAYA"
}
```
:::

:::details 来源计算器编码
```
#ME-LQWXvKPbrYZbLIZKTTLUNNQXn4zTuRPwYAT-YBCOuIZhOswhUKtjnKKQZ4217LY4yjKA-AAAA-HUIsw0EEAx4QZC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMLbGzYGWmxGmZMAAAAAAAWgJmZgZMjFzgZmZGzYYmZmFssZbbMjZDAA2AAAAz2s0MzMbmhNAmZYaMgBAMA"
}
```
:::

:::details 来源计算器编码
```
#ME-LQWXvAFKPbraHLIZqSmmWoaqUXHK35ppH4I-YBCOuIDg4QqF6wCFFtjnQZ421DM0c5RF-AAAA-FGUYcgochJJYDA-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have its own rotation, and can also be manipulated
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

A new feature introduced in [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>) and around for the
remainder of [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), the Omnium Folio acts as a passive source of player
power by harnessing Runes representing the various schools of magic. Over
the course of a short questline, more Runes become available to select by gathering
[[item:276216]], impacting both your damage and healing.

While you are able to switch between your unlocked Runes at any time while out
of combat, the following are our general recommendations for Brewmaster Monks.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_mining_miningspecializations_overloded.jpg>) **Omnium Folio Runes**
1. [[spell:1279599]]
2. [[spell:1279603]]
3. [[spell:1287555]]
4. [[spell:1279613]]
5. [[spell:1279614]]

:::

Due to the relatively small contribution these provide to your character's overall
strength, feel free to experiment with a setup that feels right for your needs; in
particular, your fourth rune will likely shift between [[spell:1279609]],
[[spell:1279612]], or [[spell:1279613]] depending on
if Critical Strike, Mastery, or Versatility is your lowest secondary stat.

3.

### Apex Talent: ![Bring Me Another Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_monk_bringmeanother.jpg>) Bring Me Another

One of the key new developments for all specializations in Midnight is the
introduction of **Apex Talents**. These are new, isolated talent nodes accessible from
the specialization tree beginning at Level 81, and you can spend up to four points
on them to gain a series of effects with increasing strength. However, you must
spend all three earlier points if you want the effect of the fourth; it is
sequential. Alternatively, you can make use of these four additional points
elsewhere in your specialization tree for greater build flexibility.
The choice is yours!

The Apex Talent for Brewmaster Monks is called **Bring Me Another**, and focuses
on empowering your [[spell:121253]] spell when you make use of your "Brew" abilities. As
you continue to invest points in it, you will also unlock substantial Energy savings,
improved Physical damage, and even a consistent source of extra healing for both
you and up to two nearby allies! These four versions of the talent are below.

1. [[spell:1265129]] — Using an ability with Brew in its name has a
   chance to generate an Empty Barrel (max 1). When you next cast [[spell:121253]],
   your Empty Barrel will also be thrown at your target to deal bonus damage and can ricochet
   to up to three additional enemies. These bounces will **not** occur in single-target.
2. [[spell:1265138]] — Increase all Physical
   damage dealt by 10/20%. In addition, the cooldown of [[spell:121253]] is reset
   and the Energy cost of its next cast reduced by 50/100% whenever you generate an Empty Barrel.
3. [[spell:1265141]] — Whenever you cast [[spell:388917]] or
   [[spell:322507]]/[[spell:1241059]], you and up to
   two nearby allies gain a [[spell:1265145]], along with an Empty Barrel
   for yourself. Upon taking damage, Refreshing Drink is consumed to trigger a substantial
   heal-over-time effect. The damage of Empty Barrels is also increased by 100%.

For the most part, **Bring Me Another** is entirely passive in how it is
used, but it also is a key element that ties your entire rotation together as a
Brewmaster. In particular, the cooldown and Energy cost reductions to [[spell:121253]]
add up to a substantial amount of casts over time. Where a Brewmaster may have
opted into a talent like [[spell:116847]] before to fill in the "empty" space
of the rotation rather than waiting around or spending extra Energy, these bonus
casts from the middle points of [[spell:1265138]] can now fill the same
role while also dealing a lot more damage! Finally, the guaranteed Empty Barrels
from [[spell:1265141]]'s final point means that you will fully invest
into this talent at all times, especially when the only alternative talents in the
specialization tree are (mostly) weaker defensive ones.

4.

### Choice Talent Cases

Brewmasters have access to more choice nodes among their talent trees than many
specializations. While most of them have an ultimately small effect on your total
damage or defensive breakdown, changing multiple at once can create large swings
in the Brewmaster playstyle despite mostly being passive in nature. Some of the
most important choices are broken down below, and their individual use-cases.

### [[spell:196730]] or [[spell:116847]]

4.1.

#### When to Use Special Delivery or Rushing Jade Wind

Despite being a very early choice node in the Brewmaster specialization tree,
your decision between [[spell:196730]] and [[spell:116847]] will
make a large difference in the pacing and feel of your rotation. Indeed, this node
represents a very real choice, where one option is sometimes better than the
other depending on how well you can use either of them and how many targets are being fought.

[[spell:196730]] acts as a "simpler" option between these two talents,
being a passive damage increase that also offers a hefty 50% snare to targets that
are hit by all of the falling kegs. It is also somewhat unique among AoE damage
sources in that it does not deal reduced damage until hitting a massive **20**
targets or more. The main thing to bear in mind when using this talent, however,
is that you may have more "empty" moments in the rotation where you will need to
not press any abilities while waiting to restore Energy. In addition, there may
be times when a crowd-controlled enemy is accidentally freed by a stray falling
keg.

[[spell:116847]], meanwhile, is the much more "active" option of the
two talents, requiring you to press its button very frequently in the rotation.
However, in exchange, it provides a useful amount of passive damage and Threat,
particularly in the opening moments of a pull; note that compared to [[spell:196730]],
this talent instead begins dealing reduced damage beyond **5** targets. It is
also uniquely powerful with effects that trigger from dealing damage, as each of
its hits may count as activators.

Overall, this makes the choice between [[spell:196730]] and [[spell:116847]]
rather complicated. If you are having a hard time managing your rotation or just
want to deal damage without any fuss, then [[spell:196730]] will usually be better,
though you will have to be more careful about managing
your Energy. On the other hand, the continuous AoE threat of Rushing Jade Wind
can still be an advantage, especially in open-world content or areas where you
are concerned about Threat. You will not be able to activate it very often with
all of the free Empty Barrels created by [[spell:1265138]]. Still, feel
free to experiment and use which of the two you prefer, based on your own comfort level!

### [[spell:322507]] or [[spell:1241059]]

4.2.

#### When to Use Celestial Brew or Celestial Infusion

Brewmaster Monks are one of the more unique tank specializations in that they
have a lot of customization in their mitigation abilities. In particular, you
are given the choice between two very similar spells in [[spell:322507]]
and [[spell:1241059]]. Both of them have times where one is better than
the other, and this is also often linked to whether or not you are using the
[[spell:1241097]] talent (with its use-case [discussed earlier](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents?area=self_healing#nr>)).

[[spell:322507]] is a fairly traditional defensive tool that generates a
large, damage-absorbing shield for up to 8 seconds or until it has reached its
damage cap. This shield is often large enough to handle many dangerous mechanics
on its own without you needing to commit an extra defensive cooldown. However, it
comes with the downside of "wasting" a lot of the passive healing a Brewmaster
often receives. Any time, for example, where you reach full health with the absorb
still present, then all of the mitigation effects against damage are tied to that
one absorb and you become vulnerable when it expires. If your healers were giving
you less attention because of this, they may now be playing catch up as your health
unexpectedly starts to rapidly fall again.

[[spell:1241059]] is an alternate choice that is meant to help address
this potential problem. While its shield size and cooldown are the same as
[[spell:322507]], this ability lasts for up to 16 seconds instead, but will
only absorb a portion of the damage you receive at while it is active. To look at
it another way, rather than the "100% damage reduction" of Celestial Brew's absorb,
you instead have "20% damage reduction" for a longer time. By spreading out this
mitigation, you end up being easier to heal by allowing more passive sources to
continue to help offset the damage you take compared to the "all or nothing" approach
of absorbing everything for a short moment. Although the amount absorbed from any
given hit will be smaller, you still have [[spell:115069]] and other mitigating
abilities to fill in the gap and not be in serious danger from single, massive hits.

With all of this in mind, which defensive talent is better? For most players,
**[[spell:1241059]] will be the better default choice in the majority
of content**, especially in combination with [[spell:1241097]]. Using it
inefficiently will not create as many opportunities for mistakes as poor usage of
[[spell:322507]] might, but there is still a limit to its relative strength.
If you are contending with overwhelming sources of single spikes of damage, or
will be punished for losing any health at all, then Celestial Brew could be just
what you need instead. Moments where it may be more useful than Infusion are also
likely to be times for you to consider dropping [[spell:1241097]] and opting
for more traditional Healing Sphere behavior with [[spell:322101]] as well.

### [[spell:383994]] or [[spell:386965]]

4.3.

#### When to Use Dragonfire Brew or Charred Passions

Continuing the trend of many choice talent nodes representing genuine decisions,
both [[spell:386965]] and [[spell:383994]] are each viable talents
where one may be superior over the other in certain circumstances.

[[spell:383994]] again acts as the "passive" option between the two,
minimally impacting the rotation. The unique strength of this talent, likewise,
comes from its damage not being reduced until hitting **20** targets or more.
This makes the talent very powerful at all target counts while still remaining
competitive in specifically single-target scenarios.

[[spell:386965]], on the other hand, makes a larger impact on your
rotation as a Brewmaster. More specifically, it further emphasizes the use of
[[spell:100784]] on cooldown, regardless of target count. In addition, due
to standard recommendation of [[spell:383697]], its effect will
almost always be active due to the low cooldown of [[spell:121253]] resulting in
always being able to cast another [[spell:115181]] before the
Charred Passions buff expires. However, this does result in a rotation where you
are heavily punished for failing to reliably press Blackout Kick.

What the distinction between these two talents boils down to is primarily
one of comfort with Brewmaster Monk's complex rotation. Due to the
overall damage gap being small when both choices are played optimally, you
can certainly get away with using [[spell:383994]] at all times if you
wish, and will likely gain more damage in AoE. [[spell:386965]], meanwhile,
acts as a choice to help gain every possible bit of damage-dealing you can in single-target
while punishing you more heavily for failing to press [[spell:100784]] on
cooldown. As such, **you may generally choose whichever of the two you prefer,** with one exception...

4.4.

#### Charred Passions and Scalding Brew

If you have talented into [[spell:383698]] rather than [[spell:383697]],
then you are no longer able to maintain the debuff from [[spell:115181]]
at all times. This would also result in Scalding Brew losing value by not always
having [[spell:121253]] cast on enemies suffering from the Breath of Fire DoT.
Fortunately, [[spell:386965]] refreshes this debuff when it is active
and you are casting [[spell:100784]] or [[spell:322729]].
However, this means that you **must** select Charred Passions rather than
[[spell:383994]] if you have opted into Scalding Brew!

5.

### Hero Talents

In [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), Brewmaster Monks also have access to two unique
Hero Talent trees to supplement gameplay with unique themes that let you
really stand out from others. For Brewmasters, these Hero Talent trees are the
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan, which is all about unleashing unrelenting bursts of
damage on your foes, and becoming a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony by balancing damage
and defense. Both are great for embracing the fantasy of playing a Monk, but you
also need a reason to consider each of them.

5.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Hero Talents excel at providing burst AoE damage and
passive defense. Whether this is through the numerous [[spell:450615]] triggered
with every cast of [[spell:121253]] (dealing further AoE damage with [[spell:1262612]]),
or empowering [[spell:132578]] with [[spell:1272821]], there
is plenty of power available. Tying it all together, a Brewmaster even gains
passive damage resistance when dodging due to [[spell:450992]]. Due to
this playstyle, this tree is often tailored to the larger pulls of Mythic+,
though it can still remain viable in smaller target counts, too.

5.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony

A ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony Brewmaster still has access to some bonus AoE
damage through [[spell:451024]], but mainly plays around generating
vitality from all of their damage and
healing. This is then spent when triggering [[spell:322507]] or [[spell:1241059]]
to deal bonus damage for a short time. In addition, these Hero Talents offer a
second charge of these abilities while also increasing the strength of [[spell:119582]]!
Finally, with the help of [[spell:1271105]] and [[spell:1270958]], this
set of Hero Talents pushes a Brewmaster's single-target damage to its highest level,
making it an excellent overall choice for progression raiding.

6.

### PvP Talents (War Mode)

PvP talents are PvP-centric options that activate out in the world
when you enable War Mode in the talent pane or when participating in instanced
PvP content. If you are comfortable with being flagged for PvP, some offer great
benefits to questing.

You are permitted to choose three talents from the PvP Talents list. Here is
a recommendation of those most helpful for questing.

- [[spell:202335]] is an active ability that is off the global cooldown.
  When used, it increases the damage of your next [[spell:121253]] by 50% and stuns
  enemies for 3 seconds. Note that its cooldown does not begin until this buff has
  been consumed. This is great for larger packs but requires a keybind, which
  is not useful in Raids and Dungeons. Fortunately, as it is off the global cooldown,
  it can be cast at the same time as Keg Smash with the help of a [macro](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-macros-addons>)
  if you want to passively benefit from it.
- [[spell:410346]] causes your [[spell:119582]] to also deal split damage
  to enemies around you based on 20% of how much damage you have Purified. While
  this is often a small amount of damage due to low [[spell:115069]] amounts in world
  content, it is entirely passive and does not require any special planning.
- [[spell:202107]] allows you to use [[spell:388917]] more
  frequently without reducing its strength as your most powerful defensive
  cooldown.
- [[spell:205147]], while not offering a strong benefit most of the
  time, will allow you to gain increased movement speed and a little extra defense
  against magic attacks while questing. Magic damage from players or NPCs is
  normally a little more dangerous to a Brewmaster.
- [[spell:353361]] acts as a form of stun protection, providing you with
  temporary damage reduction while stunned. However, its amount decreases with
  every second you are stunned, completely depleting after only three seconds.
- [[spell:207025]] is also worth mentioning. It causes your
  [[spell:115546]] to increase the damage a target takes by 3%. However, this
  amount can increase all the way to 15% bonus damage for every unique player
  that attacks the target. While this is not very useful while completely solo, if
  you are taking on elites with other people who happen to be in the zone or
  questing in a group, it can be worth taking. Be careful using this on world
  Bosses — they will still attack you when you Provoke them!

For most situations, a solid combo is [[spell:202335]],
[[spell:205147]], and [[spell:202107]], as
these provide largely-passive benefits while increasing your damage-dealing
and defensive potential.

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated standard raid, weekly Mythic+, and high-key Mythic+ builds for Patch 12.1.
- **15 Jun. 2026:** Added Rune Recommendations for Patch 12.0.7's Omnium Folio.
- **19 May 2026:** Revised Hero Talent selection on high key build.
- **03 May 2026:** Adjusted sample high key/defensive Mythic+ build string and notes.
- **20 Apr. 2026:** Added High Key/Defensive Mythic+ build; adjusted Offensive raid build Hero Talent choice.
- **16 Mar. 2026:** Made minor talent adjustments for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **12 Aug. 2025:** Build recommendations adjusted based on updated simulation data.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Switched Dragonfire Brew for Charred Passions on world and defensive raiding talent builds.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Builds updated for The War Within Season 2; standard Mythic+ build switched to Master of Harmony.
- **15 Dec. 2024:** Added clarification on recommended builds.
- **21 Oct. 2024:** Wording adjustments made to reflect the more interchangeable nature of choosing Hero Talents.
- **28 Sep. 2024:** Slight tweaks made to Mythic+ and Open World/Delve builds.
- **09 Sep. 2024:** Mythic+ build split into Standard and Advanced talent guidelines; other builds updated based on Season 1 simulations.
- **25 Aug. 2024:** Delves build playstyle guidelines updated.
- **21 Aug. 2024:** Talent builds updated for The War Within release to include Hero Talent recommendations.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Raiding talent builds separated into defensive and offensive options; Invoke Niuzao build removed due to limited applications; page reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Page reviewed for Patch 10.2.5
- **10 Nov. 2023:** Slight talent adjustments to the Generic and Invoke Niuzao builds; wording cleanup on certain talent descriptions.
- **06 Nov. 2023:** Added an additional talent build focusing on Improved Invoke Niuzao, the Black Ox for Patch 10.2; included discussion of Escape from Reality as a niche talent choice.
- **10 Sep. 2023:** Added an additional talent build for Legacy Content/maximizing movement speed.
- **04 Sep. 2023:** Page formatting adjusted; Open-World and Mythic+ talent recommendations slightly adjusted.
- **10 Jul. 2023:** Default build adjusted to reflect new Patch 10.1.5 talents; additional talent notes added for possible choices.
- **02 Jun. 2023:** Slightly adjusted the wording of Weapons of Order to reflect a recent hotfix.
- **01 May 2023:** Added Song of Chi-Ji as a new niche talent; Incendiary Breath honor talent removed.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Talent trees adjusted based on 10.0.5 talent changes; added notes on Blackout Combo as a potential talent decision.
- **11 Dec. 2022:** Build and talent recommendations slightly adjusted based on recent developments regarding Charred Passions, Dragonfire Brew, Special Delivery, and Rushing Jade Wind.
- **11 Dec. 2022:** Adjusted general build to focus on world content and entry-level Mythic+/Raiding. See their respective guide sections for more tailored builds.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Brewmaster Monk, depending on the type of damage you will be tanking.
We also have advanced sections about cooldowns, procs, etc. in order to maximize your
survivability and DPS. All our content is updated for World of Warcraft Patch
12.1.5.

1.

### Brewmaster Monk Gameplay and Rotation Guide

Welcome to the Rotation section of our Brewmaster Monk guide.
The rotation for Brewmaster Monk is based on a priority system. This means you are not
using abilities in a strict <em>sequence</em>. Instead, you use whichever ability is
highest on the list, that is currently available to use.

Your best way to think of how to handle this larger priority is to build your
gameplay around the use of [[spell:100784]]. This ability has a 4-second cooldown
which is <em>not</em> reduced by your Haste. Due to <em>always</em> having a global
cooldown of 1 second between abilities, this means you will only be planning for three
other abilities between each cast of Blackout Kick. Even if the priority lists
below seem daunting, **stick to this core idea of breaking things down into
Blackout+3**, and you will be well on your way to success!

Finally, the priorities below will not account for your active mitigation abilities
(which we discuss in depth in a
[dedicated section](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities?area=stagger#stagger>)) or your survival
cooldowns (also discussed
[separately](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-rotation-cooldowns-abilities#cooldowns>)).

:::details FAQIs It Better to Play Defensively or Offensively as a Tank?
If you are new to playing a [Brewmaster Monk](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-guide>), or are beginning to
progress on a boss in organized raiding, you should definitely focus more on being
defensive while you are learning everything you need to do. The first and
foremost job of a tank player is to stay alive! Luckily, your basic rotation will
provide you with defensive buffs while also dealing damage.

As you become more comfortable and learn what you are capable of, it may be
useful to focus on dealing more damage to defeat things more quickly. If something dies
faster, then it will not be alive as long to try to kill you! The hard part is
figuring out what defensive benefits you can afford to give up as you pursue
higher DPS. Notably as well, the impact of improving your own damage contribution during
a fight or key's progression is often small compared to a DPS player's. Ultimately,
this answer **will** change depending on the group you are playing with and even your healer.
Some choices you can make when deciding to provide more damage as a
[Brewmaster Monk](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-guide>), starting with the smallest defensive losses are:

1. Optimize your [stat priority](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>) for the Offensive variant, often by reducing
   Versatility. This includes [gems, enchants, and consumables.](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gems-enchants-consumables>)
2. Adjust your [talent build](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-spec-builds-talents>) for more damage
   by opting into some additional offensive choices over defensive ones. This may influence parts of your rotation.
3. Use one or more [DPS trinkets](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#trinkets>) instead of tank-oriented trinkets. This is
   often the largest DPS gain you can achieve while also being the easiest
   to switch between defense and offense, but tends to be the most all-or-nothing in
   impact.

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony

Defensive Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

High Key

Delves/Open World

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan

Offensive Raid

Standard Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:116847]]

[[spell:123986]]

[[spell:115399]]

[[spell:386965]]

[[spell:196736]]

[[spell:418359]]

### Single-Target Rotation

1.1.

#### Brewmaster Monk Single-Target Opener

When you are first entering a fight and have access to every one of your cooldowns, you will initially need to focus on establishing [[spell:322120]] to bolster your defenses before continuing the main priority  below. A sample single-target "opener" can be described as follows:

**适用条件：Charred Passions（未启用）。**

[[spell:115181]]

3s

**适用条件：Charred Passions（启用）。**

[[spell:115181]]

3s

**适用条件：Rushing Jade Wind（启用）；Chi Burst（启用）。**

[[spell:116847]]

2s

**适用条件：Rushing Jade Wind（启用）；Chi Burst（未启用）。**

[[spell:116847]]

1s

**适用条件：Chi Burst（启用）。**

[[spell:123986]]

1s

Pull

[[spell:121253]]

[[item:241308]]

[[spell:100784]]

[[spell:115181]]

**适用条件：Blackout Combo（启用）；Press the Advantage（未启用）。**

[[spell:100780]]

[[spell:325153]]

[[spell:132578]]

[[spell:121253]]

[[spell:100784]]

[[spell:132578]]

[[spell:325153]]

1. **适用条件：Charred Passions（未启用）。** Use [[spell:115181]] 3-10 seconds before
   combat to gain [[spell:1301477]] from your [[spell:1296617]].
2. **适用条件：Charred Passions（启用）。** Use [[spell:115181]] 3 seconds before
   combat to gain [[spell:386965]] and trigger [[spell:1301477]] from your [[spell:1296617]].
3. **适用条件：Chi Burst（启用）；Rushing Jade Wind（启用）。** Activate [[spell:116847]] 2 seconds before combat.
4. **适用条件：Rushing Jade Wind（启用）；Chi Burst（未启用）。** Activate [[spell:116847]] 1 second before combat.
5. **适用条件：Chi Burst（启用）。** Use [[spell:123986]] 1 second before combat and start
   moving toward your target. You can also use your first combat potion here before
   starting the cast.
6. **适用条件：Chi Burst（启用）。** Use [[spell:121253]] while moving to your target, and optionally cast [[spell:115546]]
   if you are meant to be their initial tank.
7. **适用条件：Chi Burst（未启用）。** Use [[spell:121253]] while moving to your target, and optionally cast [[spell:115546]]
   if you are meant to be their initial tank. You can also use
   your first combat potion here.
8. Use [[spell:100784]].
9. **适用条件：Charred Passions（启用）。** Use [[spell:115181]] to gain or refresh
   [[spell:386965]].
10. **适用条件：Charred Passions（未启用）。** Use [[spell:115181]].
11. **适用条件：Blackout Combo（启用）；Press the Advantage（未启用）。** Use [[spell:100780]].
12. Use [[spell:325153]]. You may instead activate [[spell:132578]].
13. Use [[spell:121253]].
14. Use [[spell:100784]].
15. Activate [[spell:132578]]. Depending on earlier, you may instead
    cast [[spell:325153]].
16. Follow the main single-target priority below.

1.2.

#### Brewmaster Monk Single-Target Rotation

1. **适用条件：Black Ox Brew（启用）。** Activate [[spell:115399]] —
   it is off the global cooldown — if you can avoid wasting its resources.
2. Use [[spell:322109]] on an enemy if it is enabled.
3. **适用条件：Blackout Combo（启用）。** Use [[spell:100784]] to trigger [[spell:196736]].
4. **适用条件：Blackout Combo（未启用）。** Use [[spell:100784]].
5. **适用条件：Master of Harmony（启用）。** (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony) Cast [[spell:123986]].
6. **适用条件：Shado-Pan（启用）。** **Only** if not needed for defense, activate
   [[spell:322507]]/[[spell:1241059]] to
   gain an Empty Barrel from [[spell:1265141]].
7. **适用条件：Master of Harmony（启用）。** Even if only taking minimal damage, activate
   [[spell:322507]]/[[spell:1241059]] if at two charges of the ability or your vitality
   is nearly full to trigger [[spell:1270958]] and gain an Empty Barrel from [[spell:1265141]].
8. Trigger [[spell:132578]]. Do **not** do so unless you will be in
   combat for at least 25 seconds.
9. **适用条件：Master of Harmony（启用）；Blackout Combo（启用）。** Consume your [[spell:196736]] buff with
   [[spell:100780]], also spending all charges of
   [[spell:1271048]].
10. **适用条件：Blackout Combo（启用）；Shado-Pan（启用）。** Consume your [[spell:196736]] buff with
    [[spell:100780]].
11. **适用条件：Shado-Pan（启用）；Chi Burst（未启用）。** Use a charge of [[spell:121253]]
    or an active Empty Barrel from [[spell:1265129]], which
    will also trigger [[spell:450615]]. This will even trigger [[spell:450391]].
12. **适用条件：Shado-Pan（启用）；Chi Burst（启用）。** Use a charge of [[spell:121253]]
    or an active Empty Barrel from [[spell:1265129]], which
    will also trigger [[spell:450615]].
13. **适用条件：Master of Harmony（启用）；Chi Burst（未启用）。** Use [[spell:121253]] if there is an active Empty Barrel
      from [[spell:1265138]], which will trigger [[spell:1271048]] and also drain
      some vitality to deal bonus
    damage. This will even trigger [[spell:450391]].
14. **适用条件：Master of Harmony（启用）；Chi Burst（启用）。** Use [[spell:121253]] if there is an active Empty Barrel
      from [[spell:1265138]], which will trigger [[spell:1271048]] and also drain
      some vitality to deal bonus
    damage.
15. **适用条件：Charred Passions（启用）。** Use [[spell:115181]] to gain or refresh the [[spell:386965]] buff.
16. **适用条件：Charred Passions（未启用）。** Use [[spell:115181]].
17. **适用条件：Rushing Jade Wind（启用）。** Throw [[spell:325153]] at your target, with [[spell:116847]] ideally active beforehand. This will reset the
    cooldown of one charge of [[spell:121253]]; remember to also recast the ability when [[spell:1262329]] is talented, with the same priority.
18. **适用条件：Rushing Jade Wind（未启用）。** Throw [[spell:325153]] at your target. This will reset the cooldown of one charge of [[spell:121253]]; remember to also recast the ability when [[spell:1262329]] is talented, with the same priority.
19. **适用条件：Shado-Pan（启用）；Chi Burst（启用）。** (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan) Cast [[spell:123986]].
20. Use a charge of [[spell:121253]].
21. **适用条件：Rushing Jade Wind（未启用）。** Use a spare charge of [[spell:119582]] if you are taking **very little**
    damage for additional [[spell:196730]] procs and a
    chance to trigger [[spell:1265129]].
22. **适用条件：Rushing Jade Wind（启用）。** Use a spare charge of [[spell:119582]] if you are taking **very little**
    damage for a chance to trigger [[spell:1265129]].
23. **适用条件：Rushing Jade Wind（启用）。** Reactivate [[spell:116847]].
24. **适用条件：Charred Passions（启用）。** Use [[spell:100780]] if there is nothing
    else to do, **even if the [[spell:386965]] buff is
    present**. Make sure you will still have enough Energy for your next [[spell:121253]].
25. **适用条件：Charred Passions（未启用）。** Use [[spell:100780]] if there is nothing
    else to do. Make sure you will still have enough Energy for your next [[spell:121253]].
26. **适用条件：Press the Advantage（启用）。** Use
    [[spell:322729]] if there is nothing else to do, but make sure you will
    still have enough Energy for your next [[spell:121253]]. Do not use more than once in a row, as this prevents you from gaining stacks of [[spell:418359]].

It is absolutely imperative that you have enough Energy to cast [[spell:121253]] on cooldown, as this is a large source of damage and the main source of both cooldown reduction for your Brew-based abilities and [[spell:322120]] to empower your [[spell:115069]].

:::details TCOptimizing Your Tier Set Bonuses
The bonus Physical damage of [[spell:1301410]]'s debuff on enemies from the 4-piece bonus only refreshes its duration and does not stack when casting [[spell:121253]] in quick succession. This means you want to theoretically space out your Keg Smash casts by 4 seconds at a time when possible for a **small** damage increase (allowing a second cast of Keg Smash to benefit from this debuff). However, you must still aim to keep at least one charge of the ability on cooldown at all times, such as when you successfully trigger [[spell:1265129]] or have cast [[spell:325153]].

In addition, due to the [[spell:1301477]] buff occurring whenever you cast [[spell:115181]], you will want to do so before starting every pull to immediately empower your opening cast of [[spell:121253]].

:::

### AoE Rotation

1.3.

#### Brewmaster Monk AoE Opener

Against multiple targets, it is especially important to establish [[spell:322120]] to bolster your defenses before continuing the main priority below. On the other hand, if pulling multiple groups of enemies at a time, you may need to optionally include a cast or two of [[spell:322729]] as you are moving around to gather them before following the "proper" opener. Fortunately, Spinning Crane Kick also applies Shuffle! Otherwise, a sample multi-target "opener" without any Spinning Crane Kick casts can be described as follows:

**适用条件：Charred Passions（未启用）。**

[[spell:115181]]

3s

**适用条件：Charred Passions（启用）。**

[[spell:115181]]

3s

**适用条件：Rushing Jade Wind（启用）；Chi Burst（启用）。**

[[spell:116847]]

2s

**适用条件：Rushing Jade Wind（启用）；Chi Burst（未启用）。**

[[spell:116847]]

1s

**适用条件：Chi Burst（启用）。**

[[spell:123986]]

1s

Pull

[[spell:121253]]

[[item:241308]]

[[spell:100784]]

[[spell:115181]]

**适用条件：Blackout Combo（启用）；Press the Advantage（未启用）。**

[[spell:100780]]

[[spell:325153]]

[[spell:132578]]

[[spell:121253]]

[[spell:100784]]

[[spell:132578]]

[[spell:325153]]

1. **适用条件：Charred Passions（未启用）。** Use [[spell:115181]] 3-10 seconds before
   combat to gain [[spell:1301477]] from your 2-piece set bonus.
2. **适用条件：Charred Passions（启用）。** (Optional) Use [[spell:115181]] 3 seconds before
   combat to gain [[spell:386965]].
3. **适用条件：Rushing Jade Wind（启用）；Chi Burst（启用）。** Activate [[spell:116847]] 2 seconds before combat.
4. **适用条件：Rushing Jade Wind（启用）；Chi Burst（未启用）。** Activate [[spell:116847]] 1 second before combat.
5. **适用条件：Chi Burst（启用）。** Use [[spell:123986]] 1 second before combat and start
   moving toward your target. You can also use your first combat potion here before
   starting the cast.
6. **适用条件：Chi Burst（启用）。** Use [[spell:121253]] while moving to your target, and optionally cast [[spell:115546]]
   if you are meant to be their initial tank.
7. **适用条件：Chi Burst（未启用）。** Use [[spell:121253]] while moving to your target, and optionally cast [[spell:115546]]
   if you are meant to be their initial tank. You can also use
   your first combat potion here.
8. Use [[spell:100784]].
9. **适用条件：Charred Passions（启用）。** Use [[spell:115181]] to gain or refresh
   [[spell:386965]].
10. **适用条件：Charred Passions（未启用）。** Use [[spell:115181]].
11. **适用条件：Blackout Combo（启用）；Press the Advantage（未启用）。** Use [[spell:100780]].
12. Use [[spell:325153]]. You may instead activate [[spell:132578]].
13. Use [[spell:121253]].
14. Use [[spell:100784]].
15. Activate [[spell:132578]]. Depending on earlier, you may instead
    cast [[spell:325153]].
16. Follow the main AoE priority below.

1.4.

#### Brewmaster Monk AoE Rotation

**适用条件：Master of Harmony（启用）。** Brewmaster Monk is a somewhat unique specialization in that your rotation will mostly stay the same whether you are in single-target or multi-target combat; for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony players this is especially true, as [[spell:451024]] will handle much of your AoE damage thanks to the raw strength of your [[spell:100780]]s. As a reminder, this rotational priority is most helpful when you are in the middle of combat and need to decide what ability to use as your next choice. When entering combat, consider following the sample opening ability sequence above first before utilizing this priority system.

**适用条件：Shado-Pan（启用）。** Brewmaster Monk is a somewhat unique specialization in that your rotation will mostly stay the same whether you are in single-target or multi-target combat; for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan players the main difference will be a slightly higher priority on  [[spell:121253]], though this will shift into heavily focusing on it and [[spell:115181]] during [[spell:132578]]. As a reminder, this rotational priority is most helpful when you are in the middle of combat and need to decide what ability to use as your next choice. When entering combat, consider following the sample opening ability sequence above first before utilizing this priority system.

1. **适用条件：Black Ox Brew（启用）。** Activate [[spell:115399]] —
   it is off the global cooldown — if you can avoid wasting its resources.
2. Use [[spell:322109]] on an enemy if it is enabled.
3. **适用条件：Shado-Pan（启用）。** Trigger [[spell:132578]]. Do **not** do so unless you will be in
   combat for at least 25 seconds.
4. **适用条件：Shado-Pan（启用）。** **While [[spell:132578]] is active**, cast [[spell:115181]]
   to trigger [[spell:1272821]].
5. **适用条件：Shado-Pan（启用）。** **While [[spell:132578]] is active**, cast [[spell:121253]] to
   reset the cooldown of [[spell:115181]].
6. **适用条件：Blackout Combo（启用）。** Use [[spell:100784]] to trigger [[spell:196736]].
7. **适用条件：Blackout Combo（未启用）。** Use [[spell:100784]].
8. **适用条件：Master of Harmony（启用）。** (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony) Cast [[spell:123986]].
9. **适用条件：Shado-Pan（启用）。** **Only** if not needed for defense, activate
   [[spell:322507]]/[[spell:1241059]] to
   gain an Empty Barrel from [[spell:1265141]].
10. **适用条件：Master of Harmony（启用）。** Even if only taking minimal damage, activate
    [[spell:322507]]/[[spell:1241059]] if at two charges of the ability or your vitality
    is nearly full to trigger [[spell:1270958]] and gain an Empty Barrel from [[spell:1265141]].
11. **适用条件：Master of Harmony（启用）。** Trigger [[spell:132578]]. Do **not** do so unless you will be in
    combat for at least 25 seconds.
12. **适用条件：Master of Harmony（启用）；Blackout Combo（启用）。** Even in AoE, consume your [[spell:196736]] buff with
    [[spell:100780]], also spending all charges of
    [[spell:1271048]].
13. **适用条件：Blackout Combo（启用）；Shado-Pan（启用）。** Consume your [[spell:196736]] buff with
    [[spell:100780]].
14. **适用条件：Shado-Pan（启用）；Chi Burst（未启用）。** Use a charge of [[spell:121253]]
    or an active Empty Barrel from [[spell:1265129]], which
    will also trigger [[spell:450615]]. This will even trigger [[spell:450391]].
15. **适用条件：Shado-Pan（启用）；Chi Burst（启用）。** Use a charge of [[spell:121253]]
    or an active Empty Barrel from [[spell:1265129]], which
    will also trigger [[spell:450615]].
16. **适用条件：Master of Harmony（启用）；Chi Burst（未启用）。** Use [[spell:121253]] if there is an active Empty Barrel
      from [[spell:1265138]], which will trigger [[spell:1271048]] and also drain
      some vitality to deal bonus
    damage. This will even trigger [[spell:450391]].
17. **适用条件：Master of Harmony（启用）；Chi Burst（启用）。** Use [[spell:121253]] if there is an active Empty Barrel
      from [[spell:1265138]], which will trigger [[spell:1271048]] and also drain
      some vitality to deal bonus
    damage.
18. **适用条件：Charred Passions（启用）。** Use [[spell:115181]] to gain or refresh the [[spell:386965]] buff.
19. **适用条件：Charred Passions（未启用）。** Use [[spell:115181]].
20. **适用条件：Shado-Pan（启用）；Chi Burst（启用）。** (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan) Cast [[spell:123986]].
21. **适用条件：Rushing Jade Wind（启用）。** Throw [[spell:325153]] at your target, with [[spell:116847]] ideally active beforehand. This will reset the
    cooldown of one charge of [[spell:121253]]; remember to also recast the ability when [[spell:1262329]] is talented, with the same priority.
22. **适用条件：Rushing Jade Wind（未启用）。** Throw [[spell:325153]] at your target. This will reset the cooldown of one charge of [[spell:121253]]; remember to also recast the ability when [[spell:1262329]] is talented, with the same priority.
23. Use a charge of [[spell:121253]].
24. **适用条件：Rushing Jade Wind（未启用）。** Use a spare charge of [[spell:119582]] if you are taking **very little**
    damage for additional [[spell:196730]] procs and a
    chance to trigger [[spell:1265129]].
25. **适用条件：Rushing Jade Wind（启用）。** Use a spare charge of [[spell:119582]] if you are taking **very little**
    damage for a chance to trigger [[spell:1265129]].
26. **适用条件：Rushing Jade Wind（启用）。** Reactivate [[spell:116847]].
27. **适用条件：Charred Passions（启用）。** Use [[spell:100780]] if there is nothing
    else to do, **even if the [[spell:386965]] buff is
    present**. Make sure you will still have enough Energy for your next [[spell:121253]].
28. **适用条件：Charred Passions（未启用）。** Use [[spell:100780]] if there is nothing
    else to do. Make sure you will still have enough Energy for your next [[spell:121253]].
29. **适用条件：Press the Advantage（启用）。** Use [[spell:322729]], but make sure you will have enough Energy available by the time [[spell:121253]] is available. Do not use more than once in a row unless fighting 3+ enemies, as this prevents you from gaining stacks of [[spell:418359]].

**适用条件：Blackout Combo（启用）。**

:::details TipsWhy Don't I Use Spinning Crane Kick in AoE?
Although

[[spell:322729]]

deals enough AoE damage to normally justify using it over

[[spell:100780]]

, its defensive benefits are nonexistent, and you are already spending your Energy on

[[spell:196736]]

-empowered

[[spell:100780]]

s. This means you will only use the ability occasionally when gathering enemies in AoE rather than rotationally.

:::

**适用条件：Press the Advantage（启用）。**

:::details TipsWhy Don't I Use Spinning Crane Kick in AoE?
Although

[[spell:322729]]

deals enough AoE damage to normally justify using it over

[[spell:100780]]

, its defensive benefits are
nonexistent. While you will have to use it instead of Tiger Palm if talented into

[[spell:418359]]

, doing so will also cause you to gain stacks of Press the Advantage more slowly due to pausing your auto attack timer during its channel. This means you will only use the ability occasionally when gathering enemies in AoE.

:::

:::details TCOptimizing Your Tier Set Bonuses
The bonus Physical damage of [[spell:1301410]]'s debuff on enemies from the 4-piece bonus only refreshes its duration and does not stack when casting [[spell:121253]] in quick succession. This means you want to theoretically space out your Keg Smash casts by 4 seconds at a time when possible for a **small** damage increase (allowing a second cast of Keg Smash to benefit from this debuff). However, you must still aim to keep at least one charge of the ability on cooldown at all times, such as when you successfully trigger [[spell:1265129]] or have cast [[spell:325153]].

In addition, due to the [[spell:1301477]] buff occurring whenever you cast [[spell:115181]], you will want to do so before starting every pull to immediately empower your opening cast of [[spell:121253]].

:::

### Assisted Highlight & Single-Button Assistant

1.5.

#### Brewmaster Monk Single-Button Rotation Assistant

Brewmaster Monks, along with every other specialization, has access to a [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) in their spellbook, which can perform a simplified version of the damage rotation all on a single keybind. In exchange, any time this assistant is used, your global cooldown will be increased by 25% for that ability—in other words, using it will cause a global cooldown of 1.25 seconds rather than the default of 1 second on a Brewmaster. The abilities that this assistant will attempt to use for you in roughly their priority are the following:

- [[spell:322109]]
- [[spell:100784]]
- [[spell:121253]]
- [[spell:123986]]
- [[spell:100780]]
- [[spell:115181]]
- [[spell:325153]]
- [[spell:116847]]
- [[spell:322729]]

Note that this list does not include any defensive abilities or [[spell:132578]]. If you are making use of the assistant, do not forget to still use them, or both your damage and tanking ability will suffer tremendously!

1.6.

#### Can I Use the Rotation Assistant to Play Effectively as a Brewmaster Monk?

In an ideal implementation, you actually can get away with having the highlight assistant handle the bulk of your damage rotation on a Brewmaster. So long as you still manage your cooldowns effectively and properly handle your defenses, using the **highlight** assistant will result in only a very minor damage loss over a "full manual" approach. This makes it an excellent choice when proceeding to the more complex playstyles of the advanced talent builds available.

All the same, you should think of the assistant as a training tool rather than a full replacement. If you opt for the **single-button** assistant instead, you will face a much more significant loss in damage despite performing the rotation "correctly". Consider focusing on improving other parts of your gameplay as a Brewmaster while making use of the highlight assistant to gain the confidence to eventually perform without it!

2.

### Midnight Season 2 Tier Set Bonus for Brewmaster Monk

Season 2 of Midnight features a new set of Monk-themed gear to collect, known
as the Guile of the Monkey King set. Pieces of this armor can be earned from bosses
in the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) raid, alongside any of the nine slots in the weekly
[Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), and can also gradually be made at the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)
as a catchup system. This armor, when enough pieces of it are worn, unlocks two
special bonuses for Brewmasters:

- [[spell:1296617]] — [[spell:115181]] ignites
  your next [[spell:121253]], causing it to explode on contact, dealing additional
  Flamestrike damage to its primary target and reduced damage to additional targets.
- [[spell:1296618]] — Ignited [[spell:121253]]es
  cause enemies struck to take 8% increased damage from your Physical abilities, and
  leave a patch of flames on the ground, dealing Fire damage each second for 5 sec.

2.1.

#### Set Bonuses Explained

On the surface, this season's set bonuses for Brewmaster seem fairly simple
and passive. Each cast of [[spell:115181]] will apply the [[spell:1301477]]
buff for 12 seconds and be automatically consumed with every [[spell:121253]]
to shower your enemies in [[spell:1301619]]. This will also leave patches of
fire on the ground to set your foes [[spell:1301418]], leaving them
[[spell:1301410]] and more vulnerable to your Physical damage for the
next 5 seconds. Simply line up a [[spell:100784]] and [[spell:100780]]
afterward to enjoy the increased lethality, all while gaining a little extra
healing courtesy of [[spell:1262659]]!

![Brewmaster 12.1 Aflame Visual Effect](<https://static.icy-veins.com/images/wow/classes/monk/brewmaster-12-1-4pc-vfx.jpg>)

:::details TCMaximizing the 2- and 4-Piece Bonuses
There are a couple of ways here to slightly adjust your rotation for
even greater power. To start, you will now want to cast [[spell:115181]]
before entering combat to turn your first [[spell:121253]] of each pull into a
[[spell:1301477]] and kickstart your threat. Beyond this, there is a more subtle
adjustment to be made revolving around [[spell:1301410]]. While each
fire patch of [[spell:1301418]] has its own, separate 5-second duration,
[[spell:1301410]]'s debuff will only be refreshed when casting Keg Smash on an already-affected
enemy and **does not combine its time**. Since Keg Smash deals Physical damage itself,
this means you are incentivized to space out your Keg Smash usage by up to 4 seconds
to maximize [[spell:1301410]]'s uptime while still buffing all of your hard-hitting Physical
abilities. This is further complicated whenever you generate a charge of the ability
from [[spell:1265129]] or [[spell:325153]].

Ultimately, what this all means is that **when you won't cap on [[spell:121253]]
charges or have to spend [[spell:196736]] on it**, you should ideally
refresh applications of [[spell:1301410]] when they have one second
remaining. Some of the difference in damage from a good Brewmaster versus a great
one will come down to the uptime of this debuff, but it is just one of many ways
to express skill. There is only a **small** gain in playing this way versus
ignoring the bonuses entirely.

:::

3.

### Class and Spec Mechanics Explained

As a tank specialization, Brewmaster Monk has both offensive and defensive portions
of its kit to consider, and many of its mechanics or abilities play into each.
To this end, some of your most important mechanics, especially regarding how you
are able to mitigate damage and make use of certain pieces of utility, are covered
below.

### Stagger and Mitigation

3.1.

#### Stagger and Active Mitigation Explained for Brewmaster Monk

Brewmaster Monks rely on a specific passive effect (<em>[[spell:115069]]</em>) to smooth
out the damage they take throughout fights. This is a somewhat complex
ability and is explained in-depth in the sections that follow.

3.2.

#### Stagger

In addition to dodging and parrying attacks, Brewmaster Monks have an
additional means of mitigating the damage that they take, called
[[spell:115069]]. This is a key element in your survivability as a tank, so it
is important to understand it correctly.

[[spell:115069]] causes all attacks made against you to have their damage
split into two portions:

- An **instant** portion will immediately deal its damage to you in the
  moment of the attack.
- A **[[spell:115069]]ed** portion, which does its damage to you every
  0.5 seconds for 10 seconds (or 15 seconds with [[spell:280515]] talented).

The amount of Physical damage [[spell:115069]]ed is based on your Agility,
and 58% of that amount applies to ![Magic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-magic.png>)Magical attacks, including any
other DoT effects. While you are Staggering
damage, you will have one of three debuffs to represent how intense its DoT is:
[[spell:124275]] (green), [[spell:124274]] (yellow), and
[[spell:124273]] (red). If you are in Heavy Stagger, then that means you
are taking at least 60% of your Maximum Health as damage over its duration.
However, you are likely to regularly exceed this amount in some forms
of content.

Beyond that, the division between the instant and [[spell:115069]]ed portions of
damage your damage taken depends on other factors, namely
whether or not you have the [[spell:196737]] talent — which
increases the Staggered portion — and whether or not you have
[[spell:322120]] or [[spell:388917]] with the special [[spell:322960]]
talent active. There is also the [[spell:1241136]] talent, which further increases
your Stagger based on your current health when struck, and the [[spell:280515]] talent,
which increases the duration of the Stagger DoT by 5 seconds, slightly reducing the amount of
damage dealt to you during each 0.5-second tick.

As you might have already noticed, [[spell:115069]] does not <em>by itself</em>
provide any form of damage reduction, mitigation, or avoidance. This is where
[[spell:119582]] comes into play. Purifying Brew has 2 charges with a
20-second recharge time, and using it instantly <em>Purifies</em> 50% of the Staggered
damage (the damage you are due to take over the next 10/15 seconds). The ability's icon
will also glow whenever you are in "elevated Stagger", which is any time your
Stagger is the highest level it has been in the past 10 seconds or after a large
spike.

:::details Example Stagger Damage Breakdown
A simple example of how [[spell:115069]] mitigates damage, assuming a Physical Stagger percentage of 40%, is as follows:

1. An attack of 1,000 Physical damage is performed against you.
2. 600 damage is dealt to you instantly.
3. A [[spell:115069]] DoT is applied to you, which deals 400 damage over 10 seconds
   — essentially, 20 damage every 0.5 seconds.
   
   - With the [[spell:280515]] talent, this is instead 13 damage every 0.5 seconds
     over 15 seconds!
4. You cast [[spell:119582]] after 5 seconds, removing 50% of the
   [[spell:115069]] DoT's 200 remaining damage: 100.
5. After 10 seconds, you have sustained 600 instant damage and 300 in
   [[spell:115069]]ed damage, for a total of 900. You avoided 100 damage of the
   original hit with the help of [[spell:119582]]!
   
   - If you had cast [[spell:119582]] after only 1 second, you would have
     instead avoided 180 damage of the hit or even 187 with the [[spell:280515]]
     talent. **Using Purifying Brew closer to the original hit will result in more
     mitigation!****适用条件：Master of Harmony（启用）。**  In addition, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony
     players have access to an even stronger [[spell:119582]] with the
     [[spell:451036]] passive, resulting in an <em>extra</em> 36 damage avoided here.

:::

:::details TCStagger Enhancements
Beyond this basic loop of [[spell:115069]] and [[spell:119582]],
there are a number of additional effects that interact with how much damage you
can delay, along with how to reduce that amount. The most important of these
abilities is a passive called [[spell:322120]]. This buff increases
the amount of damage you Stagger, and you are given 5 and 3 seconds of it when you
[[spell:121253]] or [[spell:100784]], respectively, along with up to 4 seconds
when casting [[spell:322729]]. Shuffle can be
extended until it reaches 15 seconds. Note, however, that Shuffle has no impact
on "old" damage you have already Staggered, instead affecting <em>new</em>
damage you take while the buff is active.

In a similar vein, the [[spell:455068]] talent also works to increase the
amount of damage you [[spell:115069]], but in a much more limited manner. Rather
than being a buff that is easily maintained like [[spell:322120]], this talent
instead builds up charges from casting [[spell:119582]]. These charges are
then consumed against sufficiently large hits based on your **current** Health
to buff your Stagger against **those hits only**. As a result, this talent
gives you extra defense when you need it the most!

[[spell:322120]] and [[spell:455068]] are not the only effects that reward
you for actively making use of your other abilities when it comes to [[spell:115069]].
There are further effects that can be used to additionally remove some of your
delayed damage, such as the [[spell:387625]], [[spell:393357]],
and [[spell:388505]] talents, or even heal you for a portion of the damage with
[[spell:383700]]. These talents exist alongside options
that provide you with benefits for reaching ever-higher levels of Stagger
as well, such as [[spell:383714]].

There is one more talented ability choice that indirectly works with your
[[spell:115069]]: [[spell:322507]] and [[spell:1241059]]. Each of these
abilities generates a shield to absorb damage for some period of time. While your
Stagger will take priority and reduce the damage first, any amount that remains
can be blocked by these shields instead, with them <em>also</em> absorbing the
damage your Stagger DoT would deal. Use them often to make yourself easier to
heal!

Finally, it is important to remember that the recharge time of [[spell:119582]] —
along with the remaining cooldowns of [[spell:322507]]/[[spell:1241059]] and
[[spell:388917]] — are reduced by **1** second each time you use
[[spell:100780]] and by **3** seconds each time you use [[spell:121253]].

:::

:::details TipsManaging Shuffle, Purifying Brew, and Celestial Brew/Celestial Infusion
The hardest part of playing a Brewmaster Monk is remembering to maintain 100%
uptime on [[spell:322120]] while trying to find the best time to make use of
[[spell:119582]] and [[spell:322507]]/[[spell:1241059]]. The latter two abilities have
extremely valuable effects, but they have long initial cooldown periods between
uses; however, as you continue to perform your rotation, their cooldowns will be substantially
reduced. As such, you have to find an appropriate time to use them without letting the
abilities sit off-cooldown and waste the cooldown reduction effects your
rotation is naturally providing.

Fortunately, [[spell:322120]] is not too hard to keep up, nor is the decision on which
Brew to use and when too complicated. So long as you are following the
Single-Target or AoE priorities above, you should generate
plenty of Shuffle time. As for your usage of [[spell:119582]],
there is a fairly simple set of rules to follow:

- Do not have both charges of [[spell:119582]] off-cooldown.
  **适用条件：Master of Harmony（启用）。**  This also includes [[spell:322507]]/Infusion
  for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony players due to their [[spell:450892]]
  passive.
- Keep one charge available for an emergency to use in "Elevated Stagger" (shown by the
  ability glowing and meaning you have taken a major increase in Stagger).
- Use a charge as the second charge is about to come off cooldown.

You may notice that this set of rules more or less involves you pretending
that the ability has only one charge instead of two. This is intentional due to
how frequently [[spell:119582]] will be available during your standard rotation.
What this also means is that there may be times when you end up having to purify
in only [[spell:124275]] or [[spell:124274]] rather than heavy, and
<em>that is okay</em> so long as you still have that second charge ready for a
sudden spike of damage.

:::

### Self-Healing

3.3.

#### Self-Healing As a Brewmaster Monk

A Brewmaster's chief source of healing lies in Healing Spheres that are
generated through the talents of [[spell:124502]] and [[spell:400629]].
Their behavior may be further modified by the [[spell:1241097]] talent.
Understanding how they are created and consumed will greatly benefit your survival.

3.4.

#### Gift of the Ox Behavior

Although [[spell:124502]] claims to offer a chance to summon a Healing
Sphere when taking damage, it actually follows a consistent set of rules. One of
these spheres will spawn for every 100% of your maximum Health you have taken as
damage before accounting for absorbs (including damage delayed from [[spell:115069]]).
These Healing Spheres will persist on the ground until you either walk
over them or they time out after 30 seconds and automatically provide you with
their healing. There can only be up to 5 active Spheres at a time. Any further
spawns beyond that will cause the least-recent Sphere to heal you and be
consumed.

If you can predict when you will take higher than usual damage, you can save
up some Spheres around you and use them all when you need the extra
healing.

Since they can sometimes be hard to spot, [[spell:124502]] Healing Spheres can
also be gathered using your [[spell:322101]] ability. Expel Harm costs 15
Energy and will immediately heal you for a small baseline amount, plus the value
of all of your existing Spheres, along with dealing damage to an enemy equal to
10% of the amount healed. In addition, your [[spell:322729]]
will slowly draw them toward your position while it is being channeled.

Your Healing Spheres are precious, and you should try to save up at least 3
of them before you either pick them up or use [[spell:322101]]. With this said, you
should only use the Spheres when you are dropping low on Health or need to get
topped off before a dangerous hit occurs.

3.5.

#### Using Niuzao's Resolve

[[spell:1241097]] offers a significant shift in your defensive playstyle
in a Brewmaster by changing your Healing Spheres from both [[spell:124502]]
and [[spell:400629]] to become a heal-over-time effect rather than being
instant healing. This works similarly to a [Guardian Druid](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-guide>)'s [[spell:192081]]
ability, where every consumed Sphere has its own timer, but stacks up to five times
as one buff. In addition, every time this HoT effect ticks, its healing is increased by up to 80%
depending on your missing health. This healing increase has no breakpoints, meaning
that if you are at 50% health the increase will be 40%, and so on. Due to this
behavior, the "passive" healing from these talents that helps offset [[spell:115069]]
damage and regular enemy attacks turns into more of a steady stream rather than
bursts, which aims to keep your health at a certain level—though it will never
be full.

There is, however, a key downside to this talent regarding the usefulness of
the [[spell:322101]] ability. As your "oldest" Healing Spheres are automatically
consumed once you have reached the cap of five active spawns at once, any use of
Expel Harm will immediately remove some of the steady healing from
[[spell:1241097]] and instead attempt to maximize your buff stacks. However,
because this healing is still a HoT effect, doing so is unlikely to instantly save
you in an emergency. In addition, while the [[spell:387276]] talent
normally has a hidden effect of also increasing the healing of Spheres that Expel Harm
consumes, this does **not** apply to Niuzao's Resolve since it would be
"double dipping".

What this all means when talenting [[spell:1241097]] is that you are
essentially giving up some agency in saving yourself in an emergency, but usually
with **significantly** wasted healing in the process, in exchange for a smoother
experience of receiving healing overall. For most players and content out there,
this method will result in greater success while remaining less skill-intensive.
Once in harder content such as Mythic raids or higher keystone levels of Mythic+,
an experienced Brewmaster will likely prefer the extra agency of traditional Healing
Spheres and more frequent [[spell:322101]] usage. Ultimately, you should try out
both styles of self-healing and see what your own preference is.

### Apex Talent: Bring Me Another

3.6.

#### Brewmaster Monk Apex Talent: Bring Me Another Explained

Brewmaster Monk's Apex Talent is called **Bring Me Another**, and focuses
on empowering your [[spell:121253]] spell when you make use of your "Brew" abilities.
By investing further points into it, you will also unlock a helpful way to fill the rotation,
improved Physical damage, and even a consistent source of extra healing for both
you and up to two nearby allies! The four versions of the talent are as follows:

1. [[spell:1265129]] — Using an ability with Brew in its name (or [[spell:1241059]]) has a
   chance to generate an Empty Barrel (max 1). When you next cast [[spell:121253]],
   your Empty Barrel will also be thrown at your target to deal bonus damage and can ricochet
   to up to three additional enemies. These bounces will **not** occur in single-target.
2. [[spell:1265138]] — Increase all Physical
   damage dealt by 10/20%. In addition, the cooldown of [[spell:121253]] is reset
   and the Energy cost of its next cast reduced by 50/100% whenever you generate an Empty Barrel.
3. [[spell:1265141]] — Whenever you cast [[spell:388917]] or
   [[spell:322507]]/[[spell:1241059]], you and up to
   2 nearby allies gain a [[spell:1265145]], along with an Empty Barrel
   for yourself. Upon taking damage, Refreshing Drink is consumed to trigger a substantial
   heal-over-time effect. The damage of Empty Barrels is also increased by 100%.

For the most part, **Bring Me Another** is entirely passive in how it is
used, but it also is a key element that ties your entire rotation together as a
Brewmaster. In particular, the cooldown and Energy cost reductions to [[spell:121253]]
add up to a substantial amount of casts over time. Where a Brewmaster may have
opted into a talent like [[spell:116847]] before to fill in the "empty" space
of the rotation rather than waiting around or spending extra Energy, these bonus
casts from the middle points of [[spell:1265138]] can now fill the same
role while also dealing a lot more damage!

However, there is one key downside to be aware of in that you can only hold
**1** Empty Barrel at a time. This can cause moments of "wasted" triggers by
gaining one guaranteed Empty Barrel from a cast of [[spell:1241059]]
(thanks to the final point of [[spell:1265141]]) and another random trigger
from casting [[spell:119582]] around the same time. These moments will be
rare, but as a result you will want to prioritize spending your (free) Empty Barrel
as soon as possible by casting [[spell:121253]] regardless of Hero Talent choice.

### Taunting

3.7.

#### Provoke

[[spell:115546]] is your single-target taunt, forcing an enemy to attack you
for up to 6 seconds at a time. Be aware that multiple taunt effects within
a short period can result in your target gradually becoming immune to its
effects! In addition, if you have taken the [[spell:115315]] talent,
you can also cast Provoke on your statue to force all enemies within 8 yards of
it to attack you. This constitutes a sort of AoE taunt. It is worth noting that
taunting a target while talented into [[spell:328670]] also increases
its movement speed by 50% for six seconds, which is useful when you have to
quickly change the positioning of an enemy. However, it can also be dangerous
when you are trying to keep an enemy from attacking you, but you need to maintain your
Threat against it.

### Mobility

3.8.

#### Brewmaster Monk Mobility

Brewmaster Monk is one of the most mobile specializations in the game, featuring
no less than 4 abilities devoted to it in some way. However, two of them,
[[spell:109132]] and [[spell:101643]], are more unique than others.

3.9.

#### Roll

[[spell:109132]] is an ability that allows you to quickly move 15 yards in
front of you. It is a useful mobility ability, which you should use
extensively for quickly traversing short distances. Here are a few facts about
Roll:

- Roll has no resource cost and no cooldown. It is based on a charge
  system.
  
  - It has a baseline maximum of 2 charges, and these charges have a 20-second recharge
    time.
  - The [[spell:115173]] talent grants an additional charge and
    reduces recharge time to 15 seconds.
  - The [[spell:449582]] talent adds 2 seconds to the recharge time, but
    allows you to temporarily dash forward once per Roll by double-jumping shortly
    afterward. You are also able to run across water while its buff is present!
- Roll is off the global cooldown, but while you are rolling, you are unable
  to use any other ability.
- Roll will always send you in the direction that your character is
  currently moving (including backward). If your character is stationary, Roll
  will send you in the direction your character is facing.
- You cannot roll through objects or obstacles. If you encounter an
  obstacle, your Roll is ended prematurely.
- Your movement speed while rolling is greater than while running, so
  rolling off a cliff will push you further than if you were just running and
  jumping.

3.10.

#### Transcendence

[[spell:101643]] allows you to place a copy of yourself at your current
location for up to 15 minutes. If you then use [[spell:119996]], you
will instantly switch places with your copy's location. This can be useful in a
wide range of situations, typically those where you know you will have to
return to a certain location after moving away from it. It can also be
used to save you from most knockback effects that would otherwise send you flying
off of an edge, even if you need to resort to placing your spirit in mid-air!

[[spell:101643]] can also be used to reset most raid encounters. If
placed outside the room before engaging the boss, you can taunt the boss and use
[[spell:119996]]. Should the boss follow you outside of its
encounter area, it will despawn. This can save your raid a substantial amount of
time and gold in a progression environment. As such, if Transcendence is not
being used already in an encounter, this unique behavior can be very desirable.

### Blackout Combo

3.11.

#### Properly Using Blackout Combo

[[spell:196736]] empowers some of your main rotational abilities and,
therefore, changes your priority somewhat. However, it can initially be a tricky
talent to properly incorporate into your playstyle and optimize its effectiveness.
Most importantly, you must continue to prioritize casting [[spell:100784]]
on cooldown to maximize the amount of abilities empowered.

If you are feeling up to the challenge, then the main thing that needs to be
noted is that almost every [[spell:196736]] buff from casting [[spell:100784]]
should be consumed by a [[spell:100780]] due to how reliable this damage buff is
and the number of other empowerments that stack with it, such as
[[spell:389942]]**适用条件：Master of Harmony（启用）。** , [[spell:1271105]],
 and [[spell:383785]]. While comboing [[spell:121253]] may seem helpful for
additional cooldown reduction of your "Brew" abilities, in reality you would have
to spend over 6 combos on the ability to gain even a single full charge of
[[spell:119582]]! At most, this should be done when you are in desperate need
of a charge that is only a few seconds away, instead. If you are regularly consuming
your Blackout Combos on Keg Smash, then this talent will
**rapidly** drop in value.

With [[spell:121253]] and [[spell:100780]] taking up such a large portion of your
rotation already, a key to performing well with this talent is to remember that
[[spell:196736]] does **not** have an interaction with all your remaining
abilities, allowing them to be effective "gap-fillers" that can safely be used as
necessary while still maximizing your casts of [[spell:100784]] to enable further combos.
**A key part of properly utilizing Blackout Combo is often delaying consuming
the Combo's buff and instead using these other abilities.** Depending on what
abilities are coming off cooldown, do not forget this behavior!

4.

### Important Cooldowns for Brewmaster Monk

### [[spell:325153]]

4.1.

#### Exploding Keg

[[spell:325153]] is a Brewmaster's shortest offensive cooldown, though
it also has slight defensive benefits. Once per minute, it can be thrown
to deal some of the largest burst damage available to the specialization, making
it a great choice early in a pull when enemies may be at risk of dropping threat
and attacking someone else. Plus, the reset of [[spell:121253]]'s cooldown enables
follow-up for even more AoE damage! Once it has been thrown, the ability's built-in
defensive bonuses come into play, causing enemy melee attacks to only deal 1 damage
for a few seconds. Unfortunately, this is less effective than it sounds, as it
only applies to auto attack damage, not abilities. On top of that, any auto attacks
that would apply some form of debuff will still be allowed to; you are not automatically
safe just by blinding your enemies with a flaming barrel.

While the reliable immediate Fire damage and ability to reset [[spell:121253]] already
make [[spell:325153]] a helpful cooldown, that is not where the damage ends.
Any enemies debuffed to deal reduced damage to you will also suffer bonus bits
of Fire damage when hit by **any** ability of yours. This includes every tick
of damage from [[spell:322729]], [[spell:116847]],
or even a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Brewmaster's [[spell:450615]]. What this means is
that, in theory, there is room for short bursts of extra damage with every Exploding
Keg; in practice, what is the actual best thing to do?

Unfortunately, while it may seem thrilling to try to follow each cast of
[[spell:325153]] with multiple casts of [[spell:322729]],
these small hits of extra Fire damage do **not** make up for choosing to use
stronger abilities instead, **usually resulting in a damage loss**. There are
occasional exceptions to this, such as incredibly large pulls or if fighting
enemies that are going to be defeated within only a global or two. Still, rather
than aiming for damage this way, focus instead on trying to have [[spell:116847]]
active beforehand if you have it talented, and just continue your normal rotation.
When playing as a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan, aim to also cast [[spell:121253]] during
the damage window to trigger [[spell:450615]], and don't forget that this
same Keg Smash can also trigger the [[spell:1262017]] talent. Finally, you can
also make use of the [[spell:1262329]] talent for a final set of
damage-efficient hits.

### [[spell:132578]]

4.2.

#### Invoke Niuzao, the Black Ox

[[spell:132578]] is a hybrid cooldown that offers both significant
offensive and defensive benefits while active. Although the transfer of [[spell:115069]]
to the celestial is noteworthy mitigation in some areas, you should instead aim to
trigger this ability more or less on cooldown. Then, while active, you are encouraged
to utilize [[spell:100784]] to trigger as many casts of [[spell:227291]]
as possible to deal massive damage while also healing Niuzao when casting [[spell:119582]]
with the power of [[spell:144606]] to offset <em>his</em> damage taken from your Stagger.
Finally, if you have opted into [[spell:322740]], you
may cast one [[spell:454523]] per summon by reactivating the cooldown
to knock nearby enemies into the air for added disruption.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan players are further empowered
by this celestial, with the ability to trigger additional sets of [[spell:450615]]
whenever [[spell:115181]] is cast while he is active. Depending on what abilities
are available during the 25-second duration of [[spell:132578]],
you may find your rotation devolving into a period of only cycling between [[spell:121253]]
and [[spell:115181]], forcing additional resets of Keg Smash's cooldown through
[[spell:1265138]] by consuming [[spell:119582]], [[spell:1241059]],
or even [[spell:115399]] and [[spell:388917]]. This will provide a significant
boost in AoE damage during the cooldown, but could result in you having no defensive
resources left when it expires.

In addition to altering the priority while [[spell:132578]] is
active, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan talent [[spell:450989]] naturally reduces
the cooldown of Niuzao to 95 seconds, substantially increasing the number of casts
available in a fight!

### [[spell:322109]]

4.3.

#### Touch of Death

[[spell:322109]] offers a fairly unique way to execute a target, but the
damage it deals can vary wildly due to the restrictions on when you are allowed
to use it. Ordinarily, this ability can only be activated if your target's current
Health is lower than your current maximum Health. In other words, you can potentially
deal hundreds of thousands of damage in an instant if you time this ability well,
bypassing tons of combat time against weaker enemies in particular. Alternatively,
with the [[spell:322113]] talent, you can instead use this ability
on any target that has reached 15% of its maximum Health, dealing 35% of your own
maximum Health as damage. However, even with this talent, there is still a way
to deal the "full" amount of damage this ability can offer.

When facing an enemy with plenty of Health, you can instead wait for them to
reach a point that is less than your current maximum Health, and **triple** the
damage your [[spell:322109]] will do to them. Furthermore, any temporary
Stamina buffs, such as a Priest's [[spell:21562]] or your own
[[spell:388917]] will increase this threshold. Of course, when
trying to use this technique against enemies suffering millions of damage per
second, it can be difficult to perform this "sniping" technique, in which case
it may be wiser to just utilize [[spell:322113]]'s more forgiving
conditions.

If you are willing to take a chance, you can create a substantial increase
in your overall damage by "sniping" with [[spell:322109]] in this way.
However, if you are not comfortable with this approach, do not feel forced to try it
and instead take the more guaranteed damage of [[spell:322113]].

### [[spell:388917]]

4.4.

#### Fortifying Brew

A Brewmaster's most powerful cooldown that's strictly defensive in nature,
[[spell:388917]] temporarily increases your health while simultaneously
reducing all damage you receive for a long duration. It can be further enhanced
with [[spell:388814]] or [[spell:322960]] to increase
the health and damage reduction or your [[spell:115069]], respectively. With
such on-demand defense, it must be balanced by having a hefty baseline cooldown of
**6** minutes.

For most specializations, 6 minutes would be a dealbreaker. On a Brewmaster Monk,
not so much. This is because [[spell:388917]] has "Brew" in its name, which
means that the cooldown reduction effects of both [[spell:121253]] and [[spell:100780]]
work on it. As such, during continuous combat, you are able to cut its recharge
time in **half**. From there, if you still need it even more frequently, then
its baseline cooldown can be reduced to **4** minutes with the [[spell:388813]]
talent, though you must give up access to [[spell:388814]] in the process.

When this ability is actually only a 2-3 cooldown, it is now much more flexible
for your defensive needs. While you should try to use it <em>before</em> suffering
a large hit and dropping dangerously low in health, the bonus health it provides
does grant you some leeway compared to other defensive abilities. Plus, if you
do not need the defensive benefits whatsoever, its health bonus can be used as a
way to buff the damage of [[spell:322109]]. Using it at all is better than
having it sit around because of your concern about its long cooldown.

:::details TipsExternal Cooldowns
You're likely used to using

[[spell:119582]]

,

[[spell:1241059]]

, and

[[spell:388917]]

when you need them, but there are other cooldowns
available to you in a dungeon or raid setting: external ones from healers! If
you are about to take a lot of damage from either a boss mechanic or
accidentally letting your

[[spell:322120]]

drop, call for a specific external
if you can! Healers will not always know the best time and may provide you with
multiple at once if you just ask for help in general. This advice is mostly for
those who play with a microphone and are comfortable using it, but it may often
still be worthwhile asking a healer beforehand to use a cooldown at a certain point
in a fight. A list of these externals are:

- [Restoration Druid](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-guide>): [[spell:102342]] (low-cooldown damage reduction)
- [Mistweaver Monk](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-guide>): [[spell:116849]] (large absorb and increase in healing
  received)
- Paladin: [[spell:6940]] (damage reduction; also harms the
  Paladin)
- [Discipline Priest](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-guide>): [[spell:33206]] (strong damage reduction)
- [Holy Priest](<https://www.icy-veins.com/wow/holy-priest-pve-healing-guide>): [[spell:47788]] (saves you from damage that would have
  killed you, and increases healing received)
- [Preservation Evoker](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>): [[spell:357170]] (essentially, a weaker form
  of [[spell:115069]], but often providing more defense against ![Magic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-magic.png>)Magic damage
  than Stagger alone would have)

:::

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Modified timelines and rotation guidance for Season 2 and its set bonus; adjusted formatting to limit text to more important information.
- **15 Jun. 2026:** Added timeline graphics for single-target and AoE openers.
- **19 May 2026:** Moved choice talent discussion to talent section; merged FAQ blocks.
- **20 Apr. 2026:** Added discussion of available external cooldowns alongside Fortifying Brew in its respective section.
- **06 Apr. 2026:** Adjusted AoE priority for Shado Pan Brewmasters while Invoke Niuzao is active and added further explanation to the cooldown's discussion.
- **16 Mar. 2026:** Added tier set bonus explanation for Midnight Season 1.
- **26 Feb. 2026:** Rotation Priorities updated to include Apex Talent for Midnight launch; talent choices reduced to remove clutter.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **12 Aug. 2025:** Adjusted single-target rotation priority to reflect latest simulation data; revised preset buttons to match modified talent recommendations.
- **04 Aug. 2025:** Revised rotation presets and talent selections for Patch 11.2.0.; combined Dragonfire Brew and Charred Passions into one "Breath of Fire" option; added Season 3 tier set bonus discussion.
- **15 Jun. 2025:** Added discussion of the Combat Rotation Assistant in Patch 11.1.7 and its viability for a Brewmaster.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **23 Mar. 2025:** Adjusted Chi Burst's priority for Master of Harmony Players; added extra guidance on Charred Passions with the Season 2 4-piece bonus.
- **11 Mar. 2025:** Reworded 4pc interaction with Shadowboxing Treads due to bugfixes.
- **24 Feb. 2025:** Updated tier set bonus explanations for The War Within Season 2, alongside minor rotational notes for optimizing Blackout Combo.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Added advanced section detailing Wisdom of the Wall gameplay for Shado Pan Brewmasters.
- **09 Sep. 2024:** Adjusted preset talent selections; updated tier set gameplay considerations; added discussion of Sal'salabim's Strength vs Scalding for The War Within Season 1.
- **21 Aug. 2024:** Added Hero Talent support to rotations; added section detailing when to use either set of Hero Talents.
- **25 Jul. 2024:** Adjusted an AoE rotation line with Charred Passions and Rushing Jade Wind talented for further clarity.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Simplified Talent Selection table to account for talents that are taken regardless of build; removed now-unnecessary information for Dragonflight Season 4.
- **19 Mar. 2024:** Revised rotation basics to emphasize thinking in 4-second chunks; page reviewed for Patch 10.2.6.
- **19 Jan. 2024:** Elaborated further on Dragonfire Brew vs Charred Passions with the Amirdrassil Set Bonuses.
- **15 Jan. 2024:** Page reviewed for Patch 10.2.5
- **10 Nov. 2023:** Added buttons to quickly select talents based on recommended builds; slightly adjusted rotations for specific talent setups based on recent simulation optimizations; further clarified Press the Advantage and Blackout Combo behaviors, among other abilities.
- **06 Nov. 2023:** Revised Walk with the Ox Checkbox to also include Call to Arms; added further discussion of Improved Invoke Niuzao and sample opening ability sequences; page sections reformatted for reduced visual clutter.
- **10 Sep. 2023:** Added an additional rotation line in single-target with Press the Advantage; adjusted Rushing Jade Wind maintenance and Chi Wave priorities.
- **04 Sep. 2023:** Added disclaimer to Exploding Keg in single-target with Blackout Combo talented; slightly revised AoE priority for Rising Sun Kick.
- **10 Jul. 2023:** Rotation adjusted to reflect new talents and possibilities; added a section detailing advanced usage of Press the Advantage.
- **02 Jun. 2023:** Bountiful Brew usage advice adjusted based on a recent hotfix.
- **03 May 2023:** Slight rotation priority adjustment based on the specific talent combination of Charred Passions and Blackout Combo.
- **01 May 2023:** Added discussion of the Aberrus 4-piece bonus slightly changing talent choices.
- **14 Apr. 2023:** Slightly adjusted priority of Breath of Fire for specific talent builds.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Expanded notes on Blackout Combo usage to account for greater selection potential in Patch 10.0.5.
- **11 Dec. 2022:** Sections describing when to choose certain rotation-altering talents have been adjusted based on recent theorycrafting.
- **11 Dec. 2022:** Added a section regarding the Vault of the Incarnates Tier Set bonuses; general wording adjustments.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Brewmaster Monk in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Brewmaster Monk

When first reaching Level 90 in Midnight, you will likely have plenty of low-level
gear from questing equipped. Your initial item upgrades will largely
come from further exploring the world and participating in [Delves](<https://www.icy-veins.com/wow/delves-guide>) or
Normal dungeons. Although the bulk of your ideal pieces of gear will come from selecting items
within the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) every week, raiding the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) on
![Mythic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-mythic.png>)Mythic, completing higher keys in Mythic+, or even acquiring items crafted by
[Professions](<https://www.icy-veins.com/wow/professions>) using the [Crafting Orders](<https://www.icy-veins.com/wow/professions-crafting-orders-and-recrafting>) system and
[[item:274476]], not all of this content will be feasible for everyone.

Fortunately, gearing as a Brewmaster is generally simple for most item slots:
use the highest item-level gear you can get while trying to limit unnecessary
Haste. However, even an item that is 5 item levels higher with Haste will often
still be an upgrade, so do not go out of your way to avoid the stat entirely. Rings
are sometimes a different matter, as they do not contain Agility or Armor. However,
unless you are trying to maximize your damage output, you can still safely equip a ring
with a higher item level, no matter what its stats are.

Once you've acquired it, upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use
the Crest system which lets you increase the item level of gear along tracks that
relate to where you obtained the item, which harder content dropping gear that
can be upgraded to higher Item Levels. For more information, read up on our dedicated
page on how the [gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has
changed in the Midnight expansion.

### Overall

This list contains the best loot for a Brewmaster Monk that is available from the Midnight Season 2 Mythic+ Dungeon Pool, the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) raid, and recommended crafted gear. If you are purely striving for the absolute best options including perfectly Catalyzed items, no matter the odds of obtaining everything, this is it; you certainly **do not** need to acquire every item here to complete all available content. this list also assumes every item is at its highest possible item level of **334** (or 331/340/344 for crafted/ascended/elevated items).

:::details FAQWhich Tier Set Pieces Do I Want For Best-In-Slot?
Season 2 of Midnight features a new set of Monk-themed gear to collect, known as the Guile of the Monkey King set. Pieces of this armor can be earned from bosses in the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) raid, alongside any of the nine slots in the weekly [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), and can also gradually be made at the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) as a catchup system.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) inheriting the secondary stats and special effects of the original item, players now have massive flexibility in acquiring tier pieces with ideal stats **in all five** slots. assuming that you are **both** raiding and running Mythic+ as necessary, catalyze the following gear:

- **Helm** — [[item:193751@JAAIAAQkCYHKvbRLfA]] ([Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>))
- **Shoulders** — [[item:273774]] ([Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>))
- **Chest** — [[item:251226]] ([Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>))
- **Gloves** — [[item:193758@JAAIAAQkCYHKvbRLfA]] ([Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>))
- **Legs** — [[item:268225]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) (if obtained at 344) or "original" stats ([[item:270919]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>))

:::

:::details FAQWhat Do I Pick From the Great Vault?
The [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) has up to nine slots of items you can choose from every week, based on what content you have done on your character. This also impacts the item levels of each slot, with ![Mythic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-mythic.png>)Mythic raid bosses awarding fully upgraded Myth track gear! However, this wide variety of potential item levels also makes it hard to provide blanket recommendations. In addition, players may instead select either a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) or Tokens of Merit that can be exchanged for a [[item:275707]]. The power of these alternatives should not be underestimated, even if they may feel a bit "boring" in comparison.

Although you should always simulate your options in a given vault's rewards (including the value of an extra socket on pieces you'll keep for the rest of the season), here is a basic priority to follow on selecting rewards:

1. If you will be fully clearing the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) raid on at least **![Heroic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-heroic.png>)Heroic**, select a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) to bonus roll items from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>). Do so until you have obtained at least a Myth-track [[item:270175]], [[item:270168]], and/or [[item:268215]]. Craft a [[item:237847@JAAKAAwt1ENMMYzWiscN]] to use until you have obtained the weapon.
2. Choose the highest reward track items that can complete your tier set, ideally those that match our Catalyst recommendations for Brewmasters. Pay close attention to the Helm, Glove, and Leg slots, where there are many viable options at 334.
3. Select the highest item level pieces with minimal Haste, those from the best-in-slot lists below, or additional [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s/[[item:275707]]s depending on your character's goals.

:::

:::details FAQShould I Dual-Wield or Use a Two-Handed Weapon?
In Midnight's second season, your best choice for a weapon is to use a **2h** over dual-wielding for a <em>slight</em> damage advantage. However, the best-in-slot dual-wield choices ([[item:268209]] and [[item:268206]]) can offer similar performance, particularly in lower target counts. Equip whichever BiS setup you acquire first, defaulting to a two-handed option when you are choosing between gear of the same item level.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271519@JAAEAAgNyMlK]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271520@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAG2wYNTpC]]&#10;&#10;<div>[[item:240983]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAAEAAAG2MlK]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271517@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271518@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:272240@JAACAAgNyA]]&#10;&#10;<div><span>[[item:285065]]</span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271522@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251513@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">Jewelcrafting</a> (<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#loa" rel="noopener noreferrer">see note</a>)</span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAMAAwt1ENMMYzUqslIOSD]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a> (<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#bandolier" rel="noopener noreferrer">see note</a>)</span></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268215@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This table exclusively contains loot from the Midnight Season 2 Mythic+ Dungeon pool, alongside crafted embellishments. These pieces can be "farmed" without any limits, so long as you have access to a keystone for the dungeon in question. However, they will not be obtainable at their highest item level unless obtained from the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>). This means the items here may not always be your absolute best-in-slot choices.

For pieces of your Tier Set in particular, you will be reliant on either the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) or [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) to acquire them. If making use of the Catalyst, you may use any relevant Mythic+ item to create the tier item.

:::details FAQWhich Tier Set Pieces Do I Want From Mythic+?
With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) inheriting the secondary stats and special effects of the original item, players now have massive flexibility in acquiring tier pieces with ideal stats **in all five** slots. Assuming that you are **only** obtaining gear from Mythic+, catalyze the following gear:

- **Helm** — [[item:193751@JAAIAAQkCYHKvbRLfA]] ([Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>))
- **Shoulders** — [[item:273774]] ([Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>))
- **Chest** — [[item:251226]] ([Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>))
- **Gloves** — [[item:193758@JAAIAAQkCYHKvbRLfA]] ([Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>))
- **Legs** — [[item:159329]] ([Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>))

:::

:::details TipsWhich Dungeons Should I Farm?
The following dungeons contain the highest proportion of desirable loot for a Brewmaster:

- [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): Although it contains a limited number of "bis" items, this dungeon does still hold a massive amount of "good enough" alternatives, including weapons, and three slots to potentially catalyze early on.
- [The Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): An ideal belt and weapon for non-Mythic raiders can be found here, in addition to a viable ring and near-bis legs.
- [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>): Two ideal pieces to catalyze come from this dungeon ([[item:193751@JAAIAAQkCYHKvbRLfA]] and [[item:193758@JAAIAAQkCYHKvbRLfA]]).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271519@JAAEAAgNyMlK]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271520@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:251189@JAAEAAgNyMlK]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271517@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271518@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:159304@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271522@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251513@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">Jewelcrafting</a> (<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#loa" rel="noopener noreferrer">see note</a>)</span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250245@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAMAAwt1ENMMYzUqslIOSD]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a> (<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#bandolier" rel="noopener noreferrer">see note</a>)</span></div></td></tr><tr><th>Trinket</th><td>[[item:158374@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251192@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This table exclusively contains loot from the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) and [Unbinding of Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) raids, alongside crafted embellishments. Although this loot is potentially easier to acquire, particularly for pieces of your Tier Set in their "original" stats, you will only have one chance to obtain gear per boss on each difficulty every week. In addition, there may be alternative items that are obtained elsewhere as part of your overall best-in-slot gear. However, these are the items to look for from just the raids.

:::details FAQWhich Tier Set Pieces Do I Want From Raid?
With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) inheriting the secondary stats and special effects of the original item, players now have massive flexibility in acquiring tier pieces with ideal stats **in all five** slots. Assuming that you are **only** obtaining gear from the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) and the [Unbinding of Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>), catalyze the following gear:

- **Helm** — [[item:271875]] (Only at 344; [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>))
- **Shoulders** — [[item:268246]] ([Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>))
- **Chest** — [[item:281236]] ([Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>))
- **Gloves** — [[item:268234]] ([Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>))
- **Legs** — [[item:268225]] (Only at 344; [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), otherwise "Original" stats from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>))

:::

:::details TipsWhich Raid Drops Are Most Important To Brewmaster?
The following items are the ones you should seek out first; some of them may be highly contested by other specializations, particularly in offensive trinkets:

- [[item:268215]]: This weapon drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), the final boss of the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>), and is your BiS piece. Only a few specializations can equip it, allowing you to potentially avoid crafting a weapon. What's more, when bonus rolled on Heroic with a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>), this item will drop in its Myth-track variant; on Mythic, it will instead be "elevated" with an additional 10 item levels.
- [[item:268265]]: This necklace from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) is unique in many ways, being purely statted with Critical Strike, a second socket, and two cantrip effects that further empower your player. It is far and away the best accessory available to you.
- [[item:270175]]: A potent on-use trinket from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) that not only provides static Critical Strike, but also on-demand Agility and raw Physical damage. This choice was truly made for a Brewmaster.
- [[item:281215]]: A recent addition in [Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>), this trinket from the [Unbinding of Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) one-boss raid may not have an elevated Mythic item level or especially strong performance in single-target, but quickly grows to monstrous potential in AoE and when enhanced with [[item:280562]]s to 340.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271519@JAAGAAAG2chNTpC]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271520@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAG2wYNTpC]]&#10;&#10;<div>[[item:240983]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAAEAAAG2MlK]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271517@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271518@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271522@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251513@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">Jewelcrafting</a> (<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#loa" rel="noopener noreferrer">see note</a>)</span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAMAAwt1ENMMYzUqslIOSD]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a> (<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#bandolier" rel="noopener noreferrer">see note</a>)</span></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268215@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Brewmaster Monk

Trinkets are a gear slot that can provide shifting value across different
areas of content. They are also the easiest piece to alter how offensive or
defensive-minded you wish to be. Because of this, you should keep many of the
trinkets you obtain and be ready to swap them out when the situation
calls for it. If you are only interested in the absolute best general choices,
then look to collect the damage/hybrid and defensive choices below.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Brewmaster Monk Best Trinkets**
**Damage/Hybrid -**

[[item:270175]]

,

[[item:281215]]

, or

[[item:250245]]

**Defense -**

[[item:270160]]

or

[[item:159617]]

:::

[Bloodmallet](<https://bloodmallet.com/>) can also be used to see a
comprehensive grouping of all available trinkets for Brewmaster Monks organized
by their damage capabilities. If the source of the trinket is not listed on
mouseover, then it only appears from world quests or events and will be
difficult to acquire.

Finally, note that the items are listed in order of their approximate strength, bearing
in mind the item level or upgrade tracks players can obtain them at.
If a trinket is not discussed here, then it is **not** worth seeking out or holding
onto over higher item level alternatives.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Brewmaster Monk Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th></th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270175]] - <span><em>Why?</em></span>&#10;<span>With static Critical Strike, on-demand Agility every 90 seconds,&#10;         bonus Physical damage that interacts with your tier set and the <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp"/> Shado-Pan</span>&#10;         talents, <strong>and</strong> an increased item level on Mythic, this trinket has&#10;         absolutely everything you would want as a Brewmaster. Seek it out, even on Heroic.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270168]] - <span><em>Why?</em></span>&#10;<span>Its 4-minute cooldown is hefty, and you are unable to dodge&#10;         attacks during its channel, but the damage output of this trinket is particularly&#10;         exceptional in single-target. It is your strongest option for burst damage,&#10;         especially at its Mythic item level of 344.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215]] - <span><em>Why?</em></span>&#10;<span>A new addition midway through Season 2, this trinket features both&#10;         static Agility and a <strong>very</strong> generous 20 procs per minute chance&#10;         to grant a stacking Critical Strike buff (Devastating Power),&#10;         with each stack having its own 15-second duration. What takes this trinket&#10;         from only decent to exceptional is in its secondary bonus to immediately&#10;         gain 3 additional stacks of the Critical Strike bonus whenever a new target&#10;         is damaged on a 5-second cooldown. This results in a trinket that will&#10;         dominate any time new enemies are engaged, which occurs in most raid encounters&#10;         along with the entirety of a Mythic+ dungeon run!</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250245]] - <span><em>Why?</em></span>&#10;<span>Although this is a tank trinket, its damage is surprisingly potent while&#10;           also providing a helpful stream of healing at a rate of 3ppm. In spite of&#10;           splitting its damage among enemies, the total amount dealt per proc also&#10;           increases, making it an incredibly passive, "hybrid" option for AoE.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270173]] - <span><em>Why?</em></span>&#10;<span>While it may be part of a set effect with [[item:268209]], this&#10;           trinket's baseline 3ppm effect is strong enough on its own to be a valuable&#10;           pickup. The extra item level on Mythic certainly helps, too, as does its&#10;           Physical damage being enhanced by both your tier set and the <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp"/> Shado-Pan</span>&#10;           Hero Talents.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:159617]] - <span><em>Why?</em></span>&#10;<span>Perhaps your most useful on-use trinket if not able to receive&#10;           "elevated" 344 options, this item provides a large burst of Versatility&#10;           when you need for 20 seconds every 2 minutes. This lines up nicely with&#10;           [[spell:132578]], but only for <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp"/> Master of Harmony</span> Brewmasters.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:158374]] - <span><em>Why?</em></span>&#10;<span>Still just as strong as it was in Battle for Azeroth, this trinket&#10;           builds roughly 20 charges per minute and unleashes Nature damage&#10;           with every 12 accumulated. By also including a chaining effect, it remains&#10;           potent across a variety of target counts while being an option that&#10;           is easy enough to obtain from Mythic+.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250215]] - <span><em>Why?</em></span>&#10;<span>This trinket is incredible for <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp"/> Shado-Pan</span> players&#10;           in particular, as its 90-second on-use cooldown for bonus Critical Strike&#10;           lines up nicely with the reduced cooldown on [[spell:132578]]&#10;           available to this set of Hero Talents. However, <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp"/> Master of Harmony</span>&#10;           users will still find it quite potent.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164]] - <span><em>Why?</em></span>&#10;<span>This trinket can trigger one of seven different effects at a rate of 3ppm:<ul>&#10;<li>[[spell:1292299]] — 12-second ramping Critical Strike and self-bleed;</li>&#10;<li>[[spell:1292300]] — Versatility buff, decaying with every ability used;</li>&#10;<li>[[spell:1306870]] — 12-second Mastery buff, decaying over time;</li>&#10;<li>[[spell:1308012]] — 12-second Haste and Speed buff;</li>&#10;<li>[[spell:1308014]] — 12-second stat <em>reduction</em> to all secondaries;</li>&#10;<li>[[spell:1308013]] — 12-second buff to <em>all</em> secondary stats</li>&#10;</ul>&#10;           Even though there is a "dud" effect, all of these buffs are excellent and scale&#10;           well into all target counts. It is easily among your best options for&#10;           trinkets that can't reach the "elevated" item level of 344.</span>&#10;</li>&#10;<li>[[item:250228]]</li>&#10;<li>&#10;&#10;&#10;[[item:270166]] - <span><em>Why?</em></span>&#10;<span>By offering benefits to its damage (triggering roughly once per minute)&#10;           against only a single target and also against multiple, this trinket&#10;           is a convenient universal and passive option for damage.</span>&#10;</li>&#10;<li>[[item:250259]]</li>&#10;<li>&#10;&#10;&#10;[[item:250214]] - <span><em>Why?</em></span>&#10;<span>While this trinket does provide a useful amount of Mastery, remember&#10;         that you must be able to stand in its light beam to gain its full benefit;&#10;         this may not always be feasible in the middle of combat.</span>&#10;</li>&#10;<li>[[item:248583]] (Crit)</li>&#10;<li>&#10;&#10;&#10;[[item:270165]] - <span><em>Why?</em></span>&#10;<span>You may be wondering how a trinket with Haste can be placed so highly.&#10;         This is largely because of the stat's potential to scale with your AoE&#10;         damage in particular, while also triggering more applications of your&#10;         4-set bonus by helping to reduce the cooldown of [[spell:121253]]. And,&#10;         with a generous proc rate of 6 per minute, you will frequently trigger&#10;         the 20% bonus effect as well!</span>&#10;</li>&#10;<li>[[item:270160]]</li>&#10;<li>[[item:265657]]</li>&#10;<li>&#10;&#10;&#10;[[item:280617]] - <span><em>Why?</em></span>&#10;<span>One of the more unique trinkets available, this item is actually&#10;         a bit of a raid healing cooldown in disguise when players are able&#10;         to stand with a tank during a dangerous burst of damage. Every 3 minutes,&#10;         you may create a zone on the ground to absorb all damage taken for the next&#10;         10 seconds, up to a large cap. However, other players can benefit from&#10;         this effect by redirecting a portion of <em>their</em> damage taken to&#10;         <em>you</em> while the barrier is still active. Due to [[spell:115069]]&#10;         taking priority in mitigating an initial hit, a Brewmaster can help allies&#10;         for an extended period of time against massive damage this way, though it&#10;         is rather underwhelming if used exclusively as a tank trinket. It may&#10;         even see use in Season <strong>3</strong> raid progression as a result.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:251785]]</li>&#10;<li>[[item:159618]]</li>&#10;<li>[[item:274493]]</li>&#10;<li>[[item:250225]]</li>&#10;<li>&#10;&#10;&#10;[[item:193757@JAAIAAQkCYHKvbRLfA]] - <span><em>Why?</em></span>&#10;<span>Much of this trinket's value depends on how you take advantage of the&#10;         ability to "train" the whelp it spawns over the course of a week. By doing&#10;         so, you can have it properly prioritize one of the following effects approximately&#10;         once per minute:<ul>&#10;<li>[[spell:389839]] — single-target damage;</li>&#10;<li>[[spell:390234]] — AoE damage;</li>&#10;<li>[[spell:389820]] — 12-second Haste buff;</li>&#10;<li>[[spell:383813]] — 12-second Critical Strike buff;</li>&#10;<li>[[spell:390896]] — single-target heal;</li>&#10;<li>[[spell:389818]] — AoE heal.</li>&#10;</ul>&#10;         Training it for the AoE damage effect in particular is ideal. More&#10;         information on training can be found <a href="https://www.wowhead.com/item=193757/ruby-whelp-shell" rel="noopener noreferrer">here</a>.</span>&#10;</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:250243]]</li>&#10;<li>[[item:251792]]</li>&#10;<li>[[item:250244]]</li>&#10;<li>&#10;&#10;&#10;[[item:246307]] - <span><em>Why?</em></span>&#10;<span>While this trinket can only be obtained at a static item level and will&#10;         quickly be outscaled by "worse" alternatives, it is enhanced if paired&#10;       with a crafted weapon featuring a matching embellishment ([[item:245873]]).</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:241340]] - <span><em>Why?</em></span>&#10;<span>This trinket is surprisingly strong for having an effect similar to&#10;         alchemist stones of every prior expansion. However, in Midnight this item&#10;         counts as an embellished piece of gear, making it difficult to justify.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274498]]</li>&#10;<li>[[item:251790]]</li>&#10;<li>[[item:251783]]</li>&#10;<li>[[item:246306]]</li>&#10;<li>[[item:274499]]</li>&#10;<li>[[item:274497]]</li>&#10;<li>[[item:270174]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274496]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:264694]]</li>&#10;<li>[[item:246305]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Midnight Season 2 includes some familiar systems to players, albeit in a new way:
bonus rolls. With the help of the weekly [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), you may choose an alternate
way to obtain a guaranteed item from a given dungeon or boss loot pool
at Hero or Myth track when completing the relevant keystone or encounter. To do so,
you must unlock at least three slots in your vault, gaining the option to select
a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) as your reward. Alternatively, one may be purchased each
week with [Voidlight Marl](<https://www.wowhead.com/currency=3316>), [Veteran Mistcrest](<https://www.wowhead.com/currency=3443>)s, or gold, up to an
ever-increasing cap. Each roll will use one of this currency,
and can include "very rare" drops when used after a raid encounter. In addition,
any items you have already received this way will be removed from future rolls,
eventually depleting the entire loot table!

For more information on how to acquire these items, be sure to check out our dedicated
guide below.

3.1.

#### Recommended Nebulous Voidcore Usage for Brewmaster Monk

Due to the wide variety of loot a player may have been offered over time by the
[Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) in particular, it is difficult to provide simple recommendations
for where to spend one's [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s. However, due to these voidcores
rolling against the entire loot table of a dungeon or raid encounter, some locations
are a more effective use than others for your most convenient power gains. In
particular, items from the **Heroic** [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) and [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
encounters will be obtained as Myth-track items when rolled!

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Nebulous Voidcore (Bonus Roll) Priority**
1. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) ([[item:268215]]/[[item:270175]])
2. [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) ([[item:270173]]/[[item:268225]]/[[item:268256]])
   [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>) (convenient items and pieces for the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>))
   Remaining BiS List items

:::

3.2.

#### Ascendant Venomstone Priority

When it comes to [[item:280562]]s, your options to use them on are
much more limited, as they may only be applied to **weapons, trinkets, and necklaces** that are
**Hero or Myth track** (including crafted ones). Naturally, this means you should
aim to save them for your best-in-slot options on the lists above, which you can
fortunately obtain eventually with the help of the [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s
earnable each week. However, be aware that players capable of receiving item level
344 gear in these slots from the final Mythic encounters of the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
**cannot** upgrade them further. With that in mind, prioritize upgrading your
items in the following order when applicable:

1. Weapon (Myth 2h)
2. Weapon (1h mainhand or crafted 2h)
3. Trinket 1 ([[item:281215]])
4. Weapon (1h offhand or crafted)
5. Trinket 2 ([[item:270173]]/[[item:270175]])

4.

### Best Crafted Items for Brewmaster Monk

When gearing, you have the option to utilize profession gear to a greater
extent than ever before, including the ability to create powerful items at
an item level of up to 331. However, acquiring items of suitable strength is
limited by a unique reagent known as a [[item:274476]], which must be obtained
from a variety of endgame content. Over time, you can utilize entire sets
of crafted gear if you are willing to create them (with or without the help of
the [Crafting Orders](<https://www.icy-veins.com/wow/professions-crafting-orders-and-recrafting>) system), but be warned that you **cannot** convert
crafted gear into tier pieces at the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>).

In addition to having customizable secondary stats,
there are a variety of powerful optional effects that are either innately
present on crafted gear or can be manually added with extra reagents. These
bonuses are known as **embellishments**, and you may have up to two effects
present on equipped crafted gear at a time.

4.1.

#### Ideal Gear to Craft

:::details ![](<https://static.icy-veins.com/images/wow/classes/shaman/alert.webp>) **Crafting Disclaimer**
Due to the unique ability to roll a Myth-track Best-in-slot polearm featuring a bonus
  effect from

**Heroic**

[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

with a

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)

,
  some Brewmasters may opt to

**ignore**

the common first-choice craft of
  a weapon. This should only be done if able to immediately acquire the

[[item:268215]]

from a single roll; otherwise, stick to
  first crafting a weapon, replacing it when a Myth-track Bardiche is eventually
  obtained.

:::

Due to the flexibility of crafted gear, such as the ability to specify your
secondary stats along with your potential embellishment, you have many options
available for gear to be created depending on items you have been able to
obtain from other content sources. In general, however,
some items are more likely to be useful for all Brewmaster Monks,
which are listed below for convenience. For any items where you are able to
customize their secondaries, we recommend using a [[item:245792]]
to select **Critical Strike+Versatility**.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_green.jpg>) **Brewmaster Crafting Order**
**(Optional) ([[item:237847@JAAKAAwt1ENMMYzWiscN]])**

➜

**[[item:251513@JAAGAAwt1ENMMYD]]**

➜

**[[item:244576@JAAKAAwt1ENMMYzWi4IN]]**

OR

[[item:244569@JAAKAAwt1ENMMYzWi4IN]]

➜

**Optional Crafts**

:::

**Crafting Order Full Notes:**

- Weapons, such as [[item:237847]] or [[item:237839]] - <em>Why?</em>
  Made by [Blacksmiths](<https://www.icy-veins.com/wow/professions-blacksmithing>), crafted
  weapons can provide your biggest damage gain of the season.
  Depending on your goals for a character, crafting a weapon may even make
  sense as your first choice and can still feature a useful embellishment
  ([[item:273060]]). If crafted, you will eventually remove this effect
  by recrafting with a [[item:248130]] in favor of embellishing a different slot.
- The [[item:251513@JAAGAAwt1ENMMYD]] - <em>Why?</em>
  Made by [Jewelcrafters](<https://www.icy-veins.com/wow/professions-jewelcrafting>), this ring comes pre-crafted with
  Critical Strike and Mastery, along with a unique embellishment effect that triggers
  roughly twice per minute and offers you a random Loa's empowerment based on your
  currently socketed gem colors:
  
  - Default (always available regardless of gems) — [[spell:1252524]] — 15-second
    Agility buff.
  - Garnet (Critical Strike) —
    [[spell:1257183]] — For 16 seconds, gain a ramping Critical Strike buff.
  - Amethyst (Mastery) — [[spell:1252814]] —
    Deal Physical damage to your primary target.
  - Lapis (Versatility) — [[spell:1252817]] —
    Deal Fire damage in an 8-yard AoE.
  - Peridot (Haste) — [[spell:1252818]] —
    15-second Haste and Speed buff.
  
  
  All of these effects are helpful to a Brewmaster, though you are unlikely to socket
  any Peridot gems. The Lapis,
  meanwhile, tends to provide the largest damage gain, though you do not need to optimize your gems
  for these effects. Follow our regular gemming guide for Brewmaster instead.
- [[item:244576@JAAKAAwt1ENMMYzWi4IN]] or
  [[item:244569@JAAKAAwt1ENMMYzWi4IN]] featuring a
  [[item:251490]] - <em>Why?</em>
  Made by [Leatherworkers](<https://www.icy-veins.com/wow/professions-leatherworking>),
  crafted armor is an easy way to acquire a large amount of your preferred
  secondary stats while also nearly matching the strength of the absolute best-in-slot
  choices available for the season. These crafted pieces can also access an embellishment
  that doubles the effects of your [[item:251513]]: a [[item:251490]].
  Consider this pair your best general set of embellishments for the season.
- Crafted Armor - <em>Why?</em>
  Made through [Leatherworking](<https://www.icy-veins.com/wow/professions-leatherworking>) and [Tailoring](<https://www.icy-veins.com/wow/professions-tailoring>), any armor piece can be crafted
  with your preferred secondary stats. Although their item level will be slightly
  lower, many pieces can remain competitive with their best-in-slot alternatives and
  can even contain the [[item:251490]] embellishment instead
  if necessary.
- Engineer-crafted Armor, such as [[item:244748]] or [[item:244772]] - <em>Why?</em>
  Although these items are made by [Engineers](<https://www.icy-veins.com/wow/professions-engineering>), they can both be
  worn by players without the profession and uniquely feature only <em>one</em> secondary
  stat instead of two. They can also be embellished with some quality of life enhancements
  that do **not** count toward the normal cap of two, but can only be used in outdoor
  content. Consider making one of these pieces with either [[item:255844]],
  [[item:248133]], or [[item:248136]].

5.

### Crest Usage

[Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>)'s second season includes currencies called
**Mistcrests**, obtainable from practically all forms of content in the
game. They can be used to upgrade gear up to Item Level **334**, which is
Mythic Raid Item Level. They can also upgrade Crafted Gear up to **331** as well.

Given the near-universal nature of gear upgrades, it
can be difficult to figure out what items you should invest your limited amounts
of Mistcrests in each week. As the decision will ultimately be based
on what items you <em>have</em> been able to obtain, listed below are some guidelines
and "wishlist" items to upgrade as soon as possible:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_121_crest_myth.jpg>) **Brewmaster Monk Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated BiS lists with Unbinding of Kit'hix Gear; added Ascendant Venomstone recommendations as part of Patch 12.1.5.
- **25 Aug. 2026:** Further trinket ranking adjustments due to recent class tuning and simulation optimizations; removed "pre-season" vault recommendation.
- **15 Aug. 2026:** Adjusted trinket rankings and great vault selection guidance to reflect recent hotfixes and tuning.
- **10 Aug. 2026:** Updated BiS lists, trinkets, and recommended embellishments for Patch 12.1/Midnight Season 2.
- **15 Jun. 2026:** Updated BiS lists with Sporefall gear; adjusted recommended crafted gear for Patch 12.0.7.
- **20 Apr. 2026:** Added discussion of Nebulous and Ascendant Voidcores in Patch 12.0.5.
- **06 Apr. 2026:** Added further world trinkets to gear discussion.
- **16 Mar. 2026:** Added Midnight Season 1 recommendations; revised formatting of sections.
- **26 Feb. 2026:** Updated with Pre-season recommendations for Midnight's launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **23 Oct. 2025:** Slightly adjusted Puzzling Cartel Chip recommendations.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **15 Aug. 2025:** Added further noteworthy offensive trinkets to their respective sections.
- **12 Aug. 2025:** Revised trinket recommendations due to updated simulation data.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **23 Jun. 2025:** Adjusted DISC belt recommendations based on recent tuning.
- **15 Jun. 2025:** Added discussion of the DISC belt of Patch 11.1.7; embellishment recommendations adjusted.
- **12 May 2025:** Puzzling Cartel Chip recommendations adjusted based on purchase requirements.
- **21 Apr. 2025:** Puzzling Cartel Chip purchase recommendations added for Patch 11.1.5.
- **23 Mar. 2025:** Best damage trinket adjusted due to recent tuning hotfixes; added Sigil of Algari Concordance discussion.
- **01 Mar. 2025:** Cyrce's Circlet recommendations adjusted as of latest post-hotfix sims.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **20 Feb. 2025:** Gear, trinket, and crafting recommendations updated for Season 2 of The War Within.
- **20 Dec. 2024:** Cyrce's Circlet citrine guidance adjusted based on further tuning and updated simulations.
- **15 Dec. 2024:** Added Cyrce's Circlet citrine recommendations; page reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Added Befouler's Syringe to list of unique weapons.
- **13 Sep. 2024:** Embellishment crafting slot choices adjusted and further explained; trinkets adjusted ahead of upcoming tuning; recommended tier offpiece shifted.
- **10 Sep. 2024:** Embellishment recommendations adjusted with latest simulation findings.
- **09 Sep. 2024:** Gear, trinket, and crafting recommendations updated for Season 1 of The War Within.
- **21 Aug. 2024:** Updated with Pre-Season and Season 1 BiS gear for The War Within
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Gear lists updated with Dragonflight Season 4 recommendations; added Antique Bronze Bullion purchase recommendations; created additional tables for unique weapons and trinkets.
- **19 Mar. 2024:** Offensive raid trinket order revised; page reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Page reviewed for Patch 10.2.5.
- **10 Nov. 2023:** Slight gear adjustments based on recent hotfixes and simulation optimizations, particularly regarding trinkets.
- **06 Nov. 2023:** Adjusted with new recommended Dungeon/Raid gear and Trinkets for Dragonflight Season 3; adjusted unique weapon discussion; added an explanation of Amirdrassil set bonus effects.
- **04 Sep. 2023:** Page reformatted for Patch 10.1.7.
- **12 Jul. 2023:** Mentioned the possibility of a higher item level Borrowed Time; rings reordered for better clarity.
- **10 Jul. 2023:** Added Dawn of the Infinite gear; rings adjusted.
- **24 May 2023:** Added mention of Firelands Timewalking trinkets and a recent Weapons of Order hotfix.
- **10 May 2023:** Updated special weapon discussion due to updated simulations; offensive trinkets slightly revised.
- **03 May 2023:** Embellishment/crafted gear priority modified; recommended tier slot "offpiece" changed based on recent simulations.
- **01 May 2023:** Adjusted with new recommended Dungeon/Raid gear and Trinkets for Dragonflight Season 2; added sections on unique weapon effects and upgrade priorities.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **12 Jan. 2023:** Added additional information on embellishments; adjusted dungeon trinket recommendations.
- **11 Dec. 2022:** Dungeon gear revised and recommended raid gear added; trinkets substantially expanded for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Brewmaster Monk. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Brewmaster Monk Stat Priority

As a Brewmaster Monk, your stat priority stays simple for
whatever you want to do. This includes whether you are playing as a
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Brewmaster, or a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony. Regardless of your
choice, the following stat priorities will not change with your Hero Talents!

The stat priority below is specifically for playing defensively.

Item Level

Critical Strike

Versatility

Mastery

Haste

Brewmaster stats are fairly close in defensive value. For this reason, you
should wear the highest item-level gear you have available. Having <em>more</em>
stats will often be more useful than having <em>"better"</em> stats for your
defense. Jewelry slots are the main exception, as they do not have Agility or
Armor on them. For these slots, you should focus on whatever provides the least
amount of Haste when optimizing for defense.

If you're trying to push damage and surviving is less of an issue, the following
altered stat priority will be what you want to follow.

Item Level

Critical Strike

Mastery

Versatility

Haste

2.

### In-Depth Stat Breakdown

**Critical Strike** — 46 rating = 1%: increases your chance to deal double damage or healing
on most of your spells.

:::details Show Additional InteractionsHide Additional Interactions
- Thanks to [[spell:216519]], Critical Strike also gives you an
  increased chance for any healing received to heal for an additional 70%, and even
  increases the size of all friendly absorbs on you — such as [[spell:1241059]] or
  [[spell:17]] — by 70% of your Critical Strike chance.
- The [[spell:450988]] talent for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Brewmasters increases
  the generation of [[spell:451021]]s when achieving auto attack critical hits.
- The [[spell:387046]] talent benefits from Critical Strikes with
  [[spell:100784]].

:::

**Haste** — 44 rating = 1%: improves your Energy regeneration rate, lets you auto attack
faster, and reduces the cooldown of some abilities. Although this stat normally
reduces your global cooldown as well, Brewmaster and other specializations that use
Energy as a resource <em>always</em> have a global cooldown of 1 second regardless of Haste.

:::details Show Haste-Reduced AbilitiesHide Haste-Reduced Abilities
- [[spell:121253]]; 14.3% Haste creates a 7-second cooldown, and 33.3% Haste a 6-second one.
- [[spell:119582]]
- [[spell:116847]] (cooldown <em>and</em> duration)
- [[spell:450615]] (faster auto attacks)

:::

**Versatility** — 54 rating = 1%: enhances **all** damage and healing
you perform and reduces all damage you take.

:::details Show When Versatility Is UsefulHide When Versatility Is Useful
While you will always need more Versatility rating on gear for each percentage than
another stat, its universal effects can still be helpful at times:

- All trinket and gear effect damage/healing is increased by Versatility. A
  greater proportion of these in your breakdown will give the stat an extra offensive edge.
- If fighting enemies that primarily deal Magic damage or whose attacks cannot be
  dodged, Versatility becomes a noteworthy source of defense.
- PvP content includes separate bonuses to your total Versatility, making it the
  most desirable stat there.

:::

**Mastery** — 46 rating = 1%: [[spell:117906]] grants
you a stacking buff that increases your chance to dodge every time you are attacked
or cast [[spell:100784]] until you successfully dodge an attack; Mastery also
passively increases your Attack Power.

:::details Show Mastery MechanicsHide Mastery Mechanics
- Brewmasters start with 7.4% Dodge Chance and 8% increased Attack Power from Mastery.
- Your Dodge Chance can exceed 100%, though there is no benefit from doing so.
- Enemy <em>abilities</em> usually cannot be dodged, but auto attacks are frequently
  your largest source of damage taken.
- Attack Power only increases the damage and healing of your abilities, and does
  <em>not</em> include trinkets or gear effects.

:::

**Agility** — 1 rating = 1 Attack Power: increases your ability strength,
dodge chance, [[spell:115069]] percentage, and even your self-healing. This is your
most important stat.

**Stamina** — 1 rating = 20 Health: improves your maximum health, providing
you with greater survivability in general. Nearly every piece of gear you equip
will include some amount of Stamina, making it a stat that is passively increased
with item level.

:::details Brewmasters and StaminaBrewmasters and Stamina
Brewmasters naturally have low Health compared to other tank specializations.
However, more Stamina will increase the damage of your [[spell:322109]] since
it is based on your max Health.

:::

**Armor** is a stat you will acquire from most of your
gear by default, with higher item-level pieces offering more. It has strong
defensive value, but only works to reduce the damage received from
<em>Physical</em> attacks.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

Note that any effects which grant **percentages** of stats, such as
[[spell:2825]]/[[spell:32182]] or a Brewmaster's own [[spell:383714]],
do not contribute to these points of diminishing returns.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Added dropdown describing specific benefits of Versatility; stat priority reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Added stat rating conversion values.
- **26 Feb. 2026:** Updated Offensive stat priority for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.0.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **20 Feb. 2025:** Page reviewed for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Added mention of Hero Talent stat priorities; expanded further on Haste's effects.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Page reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Page reviewed for Patch 10.2.5
- **10 Nov. 2023:** Added mention of additional behaviors related to Mastery.
- **06 Nov. 2023:** Offensive stat priority slightly readjusted for Patch 10.2.
- **04 Sep. 2023:** Page reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Offensive stat priority slightly adjusted for 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Brewmaster Monk, based on your [stat priority](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should aim for a balance of Critical Strike and Versatility in
your gems ([[item:240910]]/[[item:240914]]), but will
also want to include one [[item:240983]].
While you may be tempted to instead opt for a [[item:240967]] along with
one of each "color" of gem, this is unlikely to be an improvement.

As all jewelry in Midnight comes with one socket automatically, you should always
have at least a diamond and two gems placed in your gear, with further sockets
being added through random drops or by using a [[item:275707]] obtained
through the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>).

2.

### Best Enchants and Weapon Augments

Beyond the permanent options below, there exists a small variety of temporary
weapon enchants, applying a short-term buff to your weapon that is not removed on
death. Throughout [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), you will want to apply a
[[item:243733]] to your weapons to passively increase your Critical Strike and Haste.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td><strong>Weapons</strong></td>&#10;<td>[[item:244029]]</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Helm</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;<li>[[item:243981]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Shoulders</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;<li>[[item:243963]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Chest</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;<li>[[item:243974]]<br/> (slightly less Agility, but with additional Speed)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Legs</strong></td>&#10;<td>[[item:244641]]</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Boots</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;<li>[[item:244009]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Rings</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]] (Damage)</li>&#10;<li>[[item:244017]] (Defense)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

As a Brewmaster Monk, stats are so close together for defensive value
that you are largely free to use any other enchants on rings if you prefer them over
the largely damage-based effect of Eyes of the Eagle.

Meanwhile, for weapon enchants, [[item:244029]] is the
preferred choice for most content, though individual secondary stat effects such as
[[item:244000]] remain similarly competitive. When dual-wielding,
both weapons can be given weapon enchants, whether identical or different; then, if
using two of the same weapon enchant, their proc rate will stay the same, but the
effect's strength will be doubled!

3.

### Optimal Consumables

Consumables substantially increase the power of your character for a limited time. Any
time you are challenging yourself with difficult content, it is advisable that you buff
yourself with Flasks, Food, Potions, and Weapon Oils.

3.1.

#### Flask

In Midnight, your flask choice is based on which secondary stat you desire.
[[item:241320]] should be used in most situations, providing
Versatility as a generally useful stat for both damage and defense. However, the
[[item:241326]] can be just as effective or slightly better for
damage if you have plenty of Versatility already or low Critical Strike by comparison.
Remember, you may obtain any flasks of your choice with access to a
[[item:241319]], so long as the Alchemist placing it knows the recipe.

3.2.

#### Potions

[[item:271886]] is your general recommended potion, which provides bonus
Versatility that ramps up over 30 seconds. Due to this, aim to make use of any
on-use damage effects during the last six seconds of its duration!
Although you can instead use a [[item:241292]]
to gain even more Agility, this has the risk of spawning silencing puddles of
[[spell:1237157]] beneath you over its duration. Only consider using it if it will
not be harmful to enemy positioning. Finally, a [[item:241288]]
may be best in strictly single-target if your gear has maximized Critical Strike
and you are using a potent damage trinket such as [[item:270168]].

3.3.

#### Healing Potions

[[item:271883]] acts as your healing potion, being
an improvement over the weaker [[item:241305]]. Each use will
incur a 5-minute cooldown, but multiple can be consumed in an extended boss
fight.

In addition, a Warlock's [[item:5512]] does not share a cooldown with
other healing consumables. Remember to use it as well if you are holding one!

3.4.

#### Food Buff

If available, [[item:255845]]/[[item:255846]]
is your food of choice for some additional Agility in a dungeon or raid group; there
are also personal food items offering the same effect, such as
[[item:242275]]/[[item:255847]]. Otherwise, there are a number
of food items both as feasts and personal consumables that increase your
highest secondary stat, such as [[item:242273]] or [[item:242274]].
If Agility food items are not available, use the cheapest of these alternatives.

In addition, you are able create a "hearty" version of most food items by
combining multiple copies of a dish together, such as the
[[spell:1278895]]. These dishes are defined by having
their buffs **maintained on death**, making them especially useful for a
dungeon or progression-raiding.

3.5.

#### Augment Rune

While expensive, [[item:259085]]s can also be used for a
small amount of extra Agility. Consider keeping a few on hand for times when
you need to eke out every bit of possible damage.

3.6.

#### Optional Consumables

If you find yourself in need of a [[spell:2825]]-effect, drums are a
useful tool to provide a similar, but weaker, form of the buff. At Level 90, the
only drums that can be used are [[item:244639]].

[Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) also features a battle-resurrection item in the form
of [[item:269586]]. While you cannot dodge attacks during
the cast time of this short-range item, it represents
an otherwise indispensable piece of utility if your group does not already
have a class featuring a combat res. Make sure to purchase higher-ranked versions
to remove the chance of failure!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **15 Aug. 2026:** Adjusted recommended potion and flask to reflect recent hotfixes.
- **10 Aug. 2026:** Added new health potion recommendation as part of Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Slightly adjusted certain enchant recommendations; added discussion of tea items to food consumables.
- **26 Feb. 2026:** Gems, Enchants, and Consumables updated with Midnight items.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Healing Potion and enchantments updated for Patch 11.2.0.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **12 May 2025:** Corruption recommendations updated based on latest simulations.
- **21 Apr. 2025:** Corruption Enchant recommendations added for Patch 11.1.5.
- **23 Mar. 2025:** Added mention of the Magnificent Jeweler's Setting for additional sockets on jewelry.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **20 Feb. 2025:** Page reviewed for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Consumables adjusted based on recent simulations for The War Within Season 1.
- **21 Aug. 2024:** The War Within consumables added for launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Page reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Page reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Added new Helm enchant; adjusted healing potion and phial recommendations for Patch 10.2; specified Shocking Disclosure primarily being a cheap choice.
- **04 Sep. 2023:** Recommended Single-target potion altered for Patch 10.1.7; Frozen Devotion recommendation removed due to cheaper enchantment prices.
- **10 Jul. 2023:** Added a note about Onyx Annulet no longer being the best choice at higher item levels in Patch 10.1.5.
- **03 May 2023:** Weapon enchants updated with specific target counts; single-target potion recommendation changed.
- **01 May 2023:** Added mention of the Draconic Phial Cauldron in Patch 10.1; removed infrequently-used Primordial Stones.
- **01 Apr. 2023:** Primordial Stone recommendations modified with tuning now finalized.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **12 Jan. 2023:** Slightly adjusted Consumable recommendations; adjusted Chest Enchants.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Brewmaster Monk in World of Warcraft Patch 12.1.5.

1.

### Brewmaster Monk in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Brewmaster
in Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Brewmaster is a somewhat popular choice for Mythic+, with decent damage, an
excellent ability to kite in a pinch, and strong natural sturdiness. While their
group utility is mostly limited to an AoE stun, a 5% Physical damage buff, and
passive movement speed, Brewmasters also bring a crowd-control ability,
![Poison](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-poison.png>)Poison/![Disease](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-disease.png>)Disease dispel, soothe effect for ![Enrage](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-enrage.png>)Enrages, and
the option to talent into multiple abilities that affect enemy positioning.

2.

### Best Mythic+ Talent Builds

In Mythic+, you have two main builds to decide between as a Brewmaster
Monk. For most players, our Standard build is more than sufficient
to tackle keystones at any weekly level. However, for those in more organized groups
that feature massive, coordinated pulls, our Advanced build may
be more appropriate. Regardless of your choice, you have additional talent variety
to consider based on a number of factors; these "flex" talents
[are highlighted further below](<https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips#flex>).

Standard Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan
High Key/Defensive Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony

### Standard Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan

This Standard Mythic+ is somewhat similar to a raiding one, though with a bit
more investment into AoE and priority-target damage. As a result, you will be
building into [[spell:325153]] and including one or both of its followup
talents of [[spell:1262017]] and [[spell:1262329]]. However, it also still
defaults to [[spell:1241097]] for a more convenient healing experience, though
it does also run [[spell:115399]] by default for additional bursts of defense.

Although this build features the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Hero Talents, you
can easily switch to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony instead. By comparison, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan's
overall damage output at lower target counts—3 or less—will be worse in exchange for
more convenient AoE through [[spell:1262612]] and more frequent
access to [[spell:132578]]. Defensively, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan's
[[spell:450992]] is also noticeably potent in AoE tanking.

Remember that you can easily import the talent tree below into the game with
the "Export Talents" button:

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAwMLbGDzwyM2MmZMAAAAAAALLgYmBmhBzgZmZGzsNMjZWGW2stNbzYWAAgNAAAwsNLNzMzGDbAMzw0YADAYA"
}
```
:::

:::details 来源计算器编码
```
#ME-LQWXvKPbrYZbLIZKTTLUNNQXn4zTuRPwYAT-YBCOuIZhOswhUKtjnKKQZ4217LY4yjKA-AAAA-HUIsw0EEAx4QZC-
```

:::

### High Key/Defensive Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony

As you grow more comfortable playing a Brewmaster Monk in Mythic+ and reach higher
key levels, this build can be switched to for more skill-based defensive potential
at the cost of some damage. This is primarily through dropping [[spell:1241097]],
relying once again on careful use of [[spell:322101]] healing. While it also opts
into [[spell:115399]], you can instead make use of [[spell:280515]]
for effectively equal passive defense at the expense of less on-demand power. At
these higher key levels, you will also start
talenting into [[spell:1241136]], [[spell:196737]], [[spell:386937]], or even
[[spell:393357]] and [[spell:455139]], frequently dropping
[[spell:1262017]]/[[spell:1262329]], [[spell:387219]], [[spell:325153]],
or even [[spell:196730]] to do so.

Beyond these choices, this build also opts to instead play with the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony
hero talents under the assumption that you will need to focus more on single and
priority-target damage in high keystones. Be aware that it has a more strict
positioning requirement due to the narrow cleaving effect of [[spell:451024]],
and you will be punished for poor use of [[spell:100784]] and [[spell:196736]].
If you instead wish to optimize for large AoE pulls or an easier experience, the
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Hero Talents will still work just fine due to the uncapped and reliable AoE of
[[spell:1262612]] as well as your empowered [[spell:132578]].
Remember, at the highest keystone levels **either Hero Talent can excel**.

:::talents 天赋构筑
```json
{
  "code": "CwQAAAAAAAAAAAAAAAAAAAAAAAAAAgZbzYGGzyMPw2wMjBAAAAAAYZBEzMwMM2MDmZmZY2GzMmZZYZ7B22mthZBAAWmlplZbmlBAAAwwGYmBMNGAAwA"
}
```
:::

:::details 来源计算器编码
```
#ME-LQWXvKPbrYZbLIZqammWoaaguOPxjlnncAm-YBCPuIZhOswh0JtjnNQc769d5JzWEIiK-AAAA-EIosw0kA5oIAgR-
```

:::

3.

### Mythic+ Talent Flexibility for Brewmaster Monk

Due to the wildly different styles of pull sizes, enemy types, and even your
own group of players in a given Mythic+ dungeon, there are a number of
additional talent choices separate from the builds shown above to
consider at times. Use the sections below to understand these alternatives and help
determine when you may wish to switch a point or two around.

### Common Talent Swaps

3.1.

#### Flexible Mythic+ Talents for Brewmaster Monk

<table>&#10;<tr>&#10;<th>Talent Choice</th>&#10;<th>When to Consider</th>&#10;</tr>&#10;<tr>&#10;<td>[[spell:115450]]</td>&#10;<td>If the dungeon you are running features a dangerous <img alt="Poison" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-poison.png" title="Poison"/>Poison or&#10;<img alt="Disease" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-disease.png" title="Disease"/>Disease effect, such as <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a>, <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a>,&#10;<a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a>, <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a>, <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a>, <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a>,&#10;or <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a>, <strong>it is essential</strong> for&#10;you to talent this ability. With the additional class tree points available at Level 90,&#10;you can also opt to simply keep this talented by default, particularly in Season 2&#10;of Midnight.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:450432]]</td>&#10;<td>Similarly to [[spell:115450]], if the dungeon you are running features a dangerous&#10;<img alt="Enrage" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-enrage.png" title="Enrage"/>Enrage effect, such as <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a>, <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a>,&#10;<a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a>, or <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a>, <strong>it is essential</strong> for you to talent this ability. With&#10;the additional class tree points available at Level 90, you can also opt to simply keep&#10;this talented by default.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:115315]]</td>&#10;<td>When a dungeon contains multiple spread out pulls chained together, it can be difficult&#10;to establish threat on every enemy with your limited amount of AoE damage. When&#10;this is likely, consider using [[spell:115315]] in combination with&#10;[[spell:115546]] to taunt every nearby enemy at once, or to initially gather a&#10;group before your defenses are ready.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:383695]]/[[spell:1263346]]</td>&#10;<td>One of this pair of talents is mandatory for pathing into [[spell:124502]].&#10;Although [[spell:1263346]] provides <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp"/> Shado-Pan</span> players with&#10;increased [[spell:450615]] generation, both choices provide comparable amounts&#10;of damage in lower target counts regardless of Hero Talent choice. <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp"/> Master of Harmony</span>&#10;players may prefer [[spell:383695]] for the slight AoE damage buff&#10;that occurs through [[spell:451024]], but the passive movement speed&#10;from Swift as a Coursing River should not be underestimated.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:322507]]/removing [[spell:1241097]]</td>&#10;<td>While the default choices of [[spell:1241059]] and [[spell:1241097]]&#10;result in a larger amount of mitigation and healing across a dungeon, there may be&#10;moments when you are in need of "burst" defense/healing rather than the continuous&#10;stream normally provided by them. In particular, if you are in a position where you feel&#10;[[spell:322101]] is regularly needed to survive or you prefer more personal&#10;control over your health, such as in higher key levels, then removing Niuzao's Resolve&#10;to regain instant healing from your healing spheres can prove useful.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1241136]]/[[spell:393357]]</td>&#10;<td>These talents are your biggest optional defensive gains. Switch&#10;into them as necessary, noting that [[spell:1241136]] is likely to provide the&#10;biggest benefit for a single talent point. [[spell:393357]]'s power, meanwhile,&#10;quickly grows at the absolute highest key levels.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:196737]]/[[spell:386937]]</td>&#10;<td>These two talents follow similar themes in their defensive power, either&#10;rewarding you with a refund to part of [[spell:119582]]'s cooldown or&#10;a smaller amount of reduction to <em>all</em> Brews with successful dodges. Both&#10;have their place in Mythic+ and are hard to decide between, with neither being&#10;substantially better than the other. Instead, consider focusing more on taking&#10;[[spell:386937]] in dungeons with larger trash pulls and [[spell:196737]]&#10;in those with more targeted bursts of tank damage.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:115399]]/[[spell:280515]]</td>&#10;<td>[[spell:115399]] is a talent that is naturally suited for Mythic+&#10;environments where there can be "downtime" as you travel between packs of&#10;enemies and it can also provide a second burst of [[spell:119582]]&#10;and [[spell:322507]]/[[spell:1241059]] casts during a particularly&#10;hectic pull. However, if you are not activating it more or less on cooldown, it is often less&#10;helpful than the passive choice of [[spell:280515]]. Bob and Weave also&#10;grows in power as you enter incredibly high keystone levels with consistently&#10;dangerous damage.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:387219]]</td>&#10;<td>This talent is noteworthy for being a source of "free" additional damage as you&#10;perform your basic rotation. With that being said, it also has no defensive benefits&#10;and no mandatory pathing to other talents. Due to this, it is easy to remove one&#10;or both of its points for more defensive options when entering more difficult&#10;keystone levels.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1262017]]/[[spell:1262329]]</td>&#10;<td>Both of these talents are difficult to budget talent points for when in need&#10;of defense, though they do provide helpful damage increases. [[spell:1262329]],&#10;in particular, is also deceptively strong for your hardiness by providing 15&#10;seconds of cooldown reduction to all Brew abilities every minute. Don't drop it&#10;until you absolutely have to, whereas [[spell:1262017]] is perhaps your first&#10;talent to discard when necessary.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:132578]]/[[spell:1263245]]</td>&#10;<td>These two talents effectively act as a pair where you will never select just&#10;one. For <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp"/> Shado-Pan</span> players, you <strong>must</strong> select them due to their&#10;interaction with [[spell:1272821]]. However, <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp"/> Master of Harmony</span>&#10;players may sometimes opt out of them at extremely high keystone levels for two&#10;stronger defensive points instead.</td>&#10;</tr>&#10;</table>

### Niche Talents

3.2.

#### Niche Mythic+ Talents for Brewmaster Monk

For the sake of mentioning the rare times these talents may be useful,
the following table includes the remaining options available to you
as a Brewmaster Monk. Be aware that you will **very rarely** need
to switch to these talents, if ever. However, be on the lookout for these
rare opportunities across the many dungeons in a Mythic+ season.

<table>&#10;<tr>&#10;<th>Talent</th>&#10;<th>Usage Tips</th>&#10;</tr>&#10;<tr>&#10;<td>[[spell:328670]]</td>&#10;<td>This enhancement to [[spell:115546]] is unique among taunt effects&#10;due to the movement speed increase it temporarily gives the Provoked enemy.&#10;You can use this to reposition a threat that rapidly needs to move from one&#10;location to another, like avoiding a damage-reduction area on the ground.&#10;Be mindful of the speed boost, however. If you need to Provoke an enemy&#10;you are trying to run away from, they could easily catch up to you!</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:450595]]</td>&#10;<td>You generally have enough mobility as a Brewmaster to easily kite away&#10;from enemies as necessary (discussed further in a <a href="https://www.icy-veins.com/wow/brewmaster-monk-pve-tank-mythic-plus-tips?area=area_12#kiting" rel="noopener noreferrer">&#10;separate section below</a>). However, with this talent, you can make use of a&#10;pre-placed [[spell:101643]] to greatly extend how long you can do so.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:389579]]</td>&#10;<td>While this talent appears to promise exceptional healing power when you need it,&#10;it only applies to a <strong>very</strong> small amount of Brewmaster abilities such as&#10;[[spell:123986]], [[spell:450391]], and [[spell:1270958]]. All the same,&#10;you may have a point to spare for its small gain when [[spell:115315]]&#10;or [[spell:157411]] in particular are unnecessary.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:450622]]</td>&#10;<td>Although you can already remove snares with [[spell:116841]], this&#10;talent may enable you to remove a dangerous effect from an ally while still&#10;taking care of yourself with a well-timed [[spell:109132]]. Remember, however,&#10;that this talent <strong>cannot</strong> remove roots.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:455139]]</td>&#10;<td>While this talent does have its place in a defensively-minded Brewmaster's&#10;kit, it is difficult to budget a point for and requires you to be in the absolute&#10;highest keystone levels to be beneficial. Consider it your among last priorities&#10;when optimizing for defense.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:387625]]</td>&#10;<td>If you are playing in sufficiently low key levels to not frequently reach&#10;heavy amounts of [[spell:115069]]— such as +10 and below — consider&#10;using [[spell:387625]] rather than [[spell:388505]] to gain&#10;a more efficient source of Stagger reduction.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:454484]]</td>&#10;<td>If in a sufficiently high keystone level where autoattacks from a single enemy&#10;or boss are especially dangerous, this talent has a small moment to be useful.&#10;You are otherwise going to regularly exceed 100% dodge chance against multiple&#10;enemies, wasting the potential of [[spell:117906]] while this is&#10;talented.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:325093]]</td>&#10;<td>In general, you will rarely, if ever, make use of [[spell:325093]]&#10;over [[spell:383714]]. However, there may occasionally be bosses in the high&#10;keystones where the extra baseline cooldown reduction is helpful for having&#10;[[spell:322507]]/[[spell:1241059]] against specific mechanics.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:455068]]</td>&#10;<td>Provided your damage intake's high enough to regularly consume its charges,&#10;[[spell:455068]] represents a strong source of defense when you need it the most&#10;against especially dangerous foes. However, it is rarely necessary outside of the&#10;highest key levels.</td>&#10;</tr>&#10;</table>

4.

### Utility Kit and Abilities

### Interrupts, Stuns, Stops

4.1.

#### Interrupts

[[spell:116705]] is your "kick" and your most important bit of utility in
Mythic+, used to stop enemy casts for the benefit of yourself and the rest of
the group. It is **highly recommended** to use a Focus Kick macro for this.

#### Mouseover Interrupt and Focus Macro

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Spear Hand Strike
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

#### Set Focus Macro

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

4.2.

#### Stunning and "Stops"

[[spell:119381]] is your AoE stun effect as a Monk. With it, you
can delay or negate dangerous abilities cast by enemies, or you can use it to
survive a dangerous pull for a little while longer while you build up your
defenses. Remember that certain enemies, such as mini-bosses, may be **immune**
to its effects and other stuns in general!

[[spell:115078]] is a versatile crowd control ability that temporarily
removes an enemy from the fight, it is best to cast it before you pull a group
of enemies so that the effect will not be broken by a random bit of damage. In
addition, you can use Paralysis as an extra interrupt effect in a pinch.

If your enemies are able to be knocked around, then [[spell:116844]] represents
another form of disruption, bouncing them out of the summoned ring.
Ring of Peace has a lot of possibilities for its application and is remarkably
versatile: you can disrupt patrolling enemies, interrupt an enemy's cast, or keep
a fixated enemy away from its target, among other uses.

Finally, Brewmaster has access to the [[spell:227363]]
talent, which allows summons of Niuzao to trigger one [[spell:454523]]
per activation that knocks up all nearby enemies. While it is less effective than
silencing casters, it can prove useful anywhere that [[spell:116844]]
is already considered as an extra piece of enemy disruption.

### Other Utility

4.3.

#### Other Utility

[[spell:117952]] can be a useful tool for pulling a faraway
group of enemies by casting it on one of them; just remember to immediately cancel
Crackling Jade Lightning's channel by moving or performing another action!
Bear in mind that it will hardly generate any threat.

[[spell:109132]], [[spell:449582]], and [[spell:116841]] can all be
used fairly often in a dungeon and are excellent options for repositioning
yourself or making a quick escape from danger. Tiger's Lust, in particular,
can often **remove debuffs** that deal damage over time or other negative
effects if the debuff **also** snares or roots the victim! Lighter Than Air,
meanwhile, can be used to negate fall damage or even briefly enable waterwalking
in the rare moments when it may be helpful.

The [[spell:157411]] aura works to provide you and any allies within 10
yards with extra movement speed. In Mythic+, where there is only one healer
and the group tends to stay close to the tank, you can provide your entire
group with this buff at nearly all times!

### Kiting

4.4.

#### Notes on Kiting

When running a Mythic+ dungeon, there may be times when the damage you or the
rest of the group is taking becomes too intense for the healer to manage. During
these moments, you can utilize kiting to help reduce your damage
taken. This can provide precious time for your healer to restore some extra
missing health or for you to get more of your defensive resources back.

There is no solid guideline for when in a dungeon; you may need to practice
kiting as a Brewmaster Monk. Still, you must not forget it is an
available option commonly seen in Mythic+ compared to a raiding environment.
Fortunately, all the mobility available to Brewmaster Monks makes kiting reasonably
simple. You could choose to [[spell:119381]] a group of enemies and [[spell:109132]]
away afterward, throwing a [[spell:121253]] to slow them down while you play
keep-away. Or, you could place a [[spell:101643]] beforehand and quickly
teleport to it later with [[spell:119996]]. With the use of
talents like [[spell:115315]] and [[spell:116844]], the only thing
stopping you as a Brewmaster from kiting endlessly is your ability to maintain
threat on what is trying to reach you.

5.

### Dungeon Tips and Tricks for Brewmaster Monk for Midnight Season 2

6.

### Dungeon-Specific Tips

This section has Brewmaster-specific tips and tricks for all dungeons' bosses and mobs,
that may not seem obvious at first!

### Talent Cheat Sheet

For a quick guide of which talents to use, check the dungeon and affixes
in the table below and see the list of suggested utility talents you should
make sure you work into your build. Note that in the case of [[spell:116841]],
which is always run regardless, this tool means to point out dungeons where there
are additional root or snare mechanics you can remove or negate with it.

<table>&#10;<tr>&#10;<th colspan="2">Dungeons</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></td>&#10;</tr>&#10;</table>

Based on the selections above, you should run the following talents:

![Detox not Talented](<https://static.icy-veins.com/images/wow/classes/monk/detox.jpg>)**适用条件：Ruby Life Pools（启用）。**

![Detox Talented](<https://static.icy-veins.com/images/wow/classes/monk/detox.jpg>)**适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Temple of Sethraliss（启用）；The Blinding Vale（启用）；Voidscar Arena（启用）。**

![Pressure Points not Talented](<https://static.icy-veins.com/images/wow/classes/monk/pressure_points.jpg>)**适用条件：Altar of Fangs（启用）；Ruby Life Pools（启用）；Temple of Sethraliss（启用）；The Blinding Vale（启用）。**

![Pressure Points Talented](<https://static.icy-veins.com/images/wow/classes/monk/pressure_points.jpg>)**适用条件：Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Voidscar Arena（启用）。**

![No special Tiger's Lust usage](<https://static.icy-veins.com/images/wow/classes/monk/tigers_lust.jpg>)**适用条件：Murder Row（启用）；Temple of Sethraliss（启用）。**

![Special Tiger's Lust usage present](<https://static.icy-veins.com/images/wow/classes/monk/tigers_lust.jpg>)**适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；The Blinding Vale（启用）；Voidscar Arena（启用）。**

- **适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Temple of Sethraliss（启用）；The Blinding Vale（启用）；Voidscar Arena（启用）。** [[spell:218164]]
- **适用条件：Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Voidscar Arena（启用）。** [[spell:450432]]
- **适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；The Blinding Vale（启用）；Voidscar Arena（启用）。** There are noteworthy snares or roots for [[spell:116841]] to remove.

7.

### Dealing with Affixes

This section has Brewmaster-specific tips for dealing with the various affixes
of Mythic+.

### Affix: Ascendant

7.1.

#### Ascendant Affix Management for Brewmaster Monk

Brewmasters have a large number of abilities on hand that can counter the
[[spell:403766]] casts from the orbs this affix generates. Among these
are your [[spell:116705]], [[spell:115078]],
and even [[spell:116844]] or [[spell:119381]]. However, you may want to
avoid overcommitting resources to stopping this affix in favor of still having them
available for the traditional trash pulls of a dungeon; choose your tools carefully.

### Affix: Voidbound

7.2.

#### Voidbound Affix Management for Brewmaster Monk

Void Emissaries spawned when this affix triggers only have 1 HP, with their
health otherwise being an absorb. This means that your [[spell:322109]] can
instantly be used on them, dealing its full amount of damage and significantly
negating their danger. With the frequency of these spawns, you will be able to
cast Touch of Death on most. This does mean you will not have access to
the ability for "regular" moments of the dungeon
.

### Affix: Pulsar

7.3.

#### Pulsar Affix Management for Brewmaster Monk

You are **unable** to gather the [[spell:1216858]] orbiting your character
on your own. It **must** be walked into by another player. In addition, these
Pulsars will always orbit clockwise; take advantage of this and your own mobility
to quickly gather another player's Pulsar that is in melee range to avoid disrupting
enemy positioning too much.

### Affix: Devour

7.4.

#### Devour Affix Management for Brewmaster Monk

[[spell:440313]]'s absorb can be removed after receiving 53% of your
maximum health in healing, or instantly with either [[spell:115450]] or [[spell:116841]].
If you have talented into [[spell:388812]] as well, consider dispelling yourself—
due to tanks having more health to heal through otherwise— and using an
instant cast of [[spell:116670]] or Tiger's Lust to help out another player if there are not
enough dispels to go around.

Alternatively, if you are the only player taking significant damage, your healer
will already be passively counteracting [[spell:440313]] by keeping you alive.
In these moments, consider using your [[spell:115450]] on another player instead.

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Standard build adjusted; utility talent cheatsheet updated for Season 2 dungeons.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **19 May 2026:** Swapped Hero Talent choice on high key build; further talent swap discussion added.
- **03 May 2026:** Updated flex/niche talent discussion, revised sample high key build.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **06 Apr. 2026:** Added defensive node discussion to advanced/high key build.
- **16 Mar. 2026:** Adjusted recommended talent builds and flex/niche talent discussion for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **12 Aug. 2025:** Updated recommended talent builds based on latest simulation data.
- **04 Aug. 2025:** Adjusted recommended talent builds and flex/niche talent discussion based on Patch 11.2.0 talent adjustments; added per-dungeon utility talent cheat sheet.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **23 Mar. 2025:** Individual dungeon tips added for all bosses and important trash, as well as suggested utility talents.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Build descriptions adjusted to reflect the interchangeable nature of Hero Talents; dungeon tips adjusted; added Voidbound affix advice.
- **28 Sep. 2024:** Added specific talent/gameplay tips for all Season 1 dungeons.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Flex talent examples updated for Dragonflight Season 4.
- **19 Mar. 2024:** Page reviewed for Patch 10.2.6.
- **19 Jan. 2024:** Reorganized flex talents based on likelihood of use; added separate entry for utilizing Dragonfire Brew instead of Charred Passions.
- **15 Jan. 2024:** Page reviewed for Patch 10.2.5; listed specific dungeons where Detox should be talented; added link to FAQ regarding talenting Press the Advantage.
- **06 Nov. 2023:** Wordings adjusted in preparation for Dragonflight Season 3; added mention of the Staggering Strikes talent for lower keystone levels.
- **04 Sep. 2023:** Default Mythic+ talent build slightly revised; flex talents reorganized; utility usage tips reformatted.
- **12 Jul. 2023:** Added additional guidance on talent swapping decisions.
- **10 Jul. 2023:** Adjusted default Mythic+ build due to new talents in Patch 10.1.5; added further notes on talents to consider swapping into as necessary.
- **01 May 2023:** Added Song of Chi-Ji to utility list; discussion of new gear upgrade system.
- **14 Apr. 2023:** Slightly adjusted recommended default Mythic+ talent build.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated talent trees with new 10.0.5 talent choices.
- **11 Dec. 2022:** Recommended build slightly adjusted based on recent theorycrafting; added table mentioning when to consider alternate talents.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Brewmaster Monk in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Brewmaster Monk macros.

1.1.

#### Generic Macros for Monks

#### Detox Mouseover Macro

```wow-macro
#showtooltip Detox
/cast [@mouseover,help,nodead] Detox;Detox
```

Using this macro will cast [[spell:218164]] on your mouseover
target, if they are a friendly player and they are not dead. Otherwise, it
will cast Detox on your current target.

#### Mouseover Interrupt and Focus Macro

```wow-macro
#showtooltip Spear Hand Strike
/cast [@mouseover,harm,nodead][@focus,exists,harm,nodead] Spear Hand Strike
```

This macro allows you to cast [[spell:116705]] on your mouseover
target, whatever enemy you currently have on focus, or on your current target
if neither of these conditions apply.

#### Mouseover Tiger's Lust Macro

```wow-macro
#showtooltip Tiger's Lust
#showtooltip Tiger's Lust
/cast [@mouseover,help,nodead] Tiger's Lust;Tiger's Lust
```

Similarly to the [[spell:116705]] macro above, this one allows you to
cast [[spell:116841]] on your mouseover target if it exists. Otherwise
it will cast the ability on yourself as it normally would.

1.2.

#### Specific Macros for Brewmaster Monks

#### All-in-One Taunt Macro

```wow-macro
#showtooltip Provoke
/cast [nomod,@mouseover,harm,nodead] Provoke
/cast [nomod] Provoke
/targetexact [mod:alt] Black Ox Statue
/cast [mod:alt] Provoke
/targetlasttarget [mod:alt,exists]
```

This macro allows you to use your [[spell:115546]] ability in a variety of
ways. First, it will taunt whatever you are mousing over, if anything.
Otherwise, it will taunt your current target. If you use the modifier key
— in this case, alt — it will taunt your (talented) Black Ox Statue
if it is out and then return you to your previous target. Be warned that this
macro will not always work correctly if a Black Ox Statue from another player
is present, as there is no way to have a macro know which statue is yours.

If you prefer a different modifier button, replace "alt" with "shift" or
"ctrl".

#### Buff Cancelaura Macro

```wow-macro
/cancelaura Blessing of Protection
```

This macro is very useful to have, as it allows you to cancel a
[[spell:1022]] that may have been cast on you. This is important
because while you are under the effect of Blessing of Protection, enemies will
not attack you and will instead attack the next person on their threat list, such
as a DPS. You may also wish to add a variety of heal-over-time or other defensive
buffs supplied by other players to this macro if you are in a scenario where
you intend to be defeated, such as when countering a specific raid mechanic. To do
so, simply write additional lines beginning with /cancelaura followed by the name
of the buff.

#### Shared Celestial Brew/Infusion

```wow-macro
#showtooltip
/cast [known:Celestial Brew] Celestial Brew
/cast [known:Celestial Infusion] Celestial Infusion
```

Most players will **not** need this macro, which automatically switches
between casting [[spell:322507]] and [[spell:1241059]] based
on which of the two you currently have talented. The default UI of Midnight will
already do this for players, however those that make use of separate addons to
modify action bar behavior will likely need to replicate it with the above macro.
Otherwise, you may find yourself unable to cast a key mitigation ability from simply
switching talents around!

#### Passive Double Barrel

```wow-macro
#showtooltip Keg Smash
/cast Double Barrel
/cast Keg Smash
```

This macro will automatically make use of the [[spell:202335]] PvP
Talent if you have it selected and cast it at the same time as your [[spell:121253]]
whenever the ability is off-cooldown. It will still work even if you do not have
this PvP Talent selected and is useful if you would just like to benefit from
its passive damage increase and stun effect every 45 seconds while out in the
world.

2.

### Best Addons

2.1.

#### Generic Addons for Monks

2.2.

#### Sensei's Class Resource Bar

While the default UI can handle tracking your [[spell:115069]] passive for
most entry-level content in the game, you may eventually want a more specialized
choice for harder content where you will regularly exceed 100% of your health
in Staggered damage. To that end,
[Sensei's Class Resource Bar](<https://addons.wago.io/addons/sensei-class-resource-bar>)
is an excellent choice for customizing not only your resources as a Brewmaster,
but as any Monk specialization.

2.3.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) is a complete replacement of the default
User Interface. It comes with almost everything you need to perform properly:
action bars, unit frames, cooldown timers, proc displays, etc.

2.3.1.

##### Boss Mods: Deadly Boss Mods or Bigwigs

Boss mods are addons that warn you about boss abilities and give you
live advice on how to handle some mechanics. We strongly recommend you to
get one such addon. At Icy Veins, we mostly use
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>),
the most popular boss mod. A good alternative is
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

2.3.2.

##### GTFO

[GTFO](<https://www.curseforge.com/wow/addons/gtfo>) is a lightweight
addon that notifies you when you are standing in harmful effects or when you
are making other such mistakes. It is very useful, even if your boss mod is
already alerting you of such things.

2.3.3.

##### Grid and GridClickSets (Optional)

ElvUI comes with decent raid frames. The only real reason for using
[Grid](<https://www.curseforge.com/wow/addons/grid>) and
[GridClickSets](<https://www.curseforge.com/wow/addons/gridclicksets>)
is if you want to be able to decurse raid or party members by right
clicking their frame in the raid of party frame. If you choose to go with
Grid, then you might want to also use
[GridStatusRaidDebuff](<https://www.curseforge.com/wow/addons/plexusstatusraiddebuff>).

2.4.

#### Finding Further Addons: Wago.io

Although you will not be able to make use of WeakAuras in Midnight,
[Wago.io](<https://wago.io>) remains an excellent source of both default
UI and cooldown manager player configurations. Check their
[Brewmaster Monk section](<https://uipacks.wago.io/search?query=&game_version=retail&categories%5B%5D=33&access=&sort=popularity>)
and see if something suits your needs.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Added a new Stagger bar addon recommendation, and adjusted Wago description.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Added click to copy functionality to all macros for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.0.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Page reviewed for Patch 11.1.0
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Macros adjusted for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Added a macro for Bonedust Brew behavior; page reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Page reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Page reviewed for Patch 10.2.
- **04 Sep. 2023:** Page reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Page reviewed for Patch 10.1.5
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
