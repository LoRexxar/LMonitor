## 专精概览

Welcome to our Protection Warrior guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to tank as a Protection Warrior in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your survivability.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Protection Mythic+ Resources

[NEW! Top Protection Talent Builds](<https://raider.io/specs/protection-warrior/talents>)

[Top Protection Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warrior/protection>)

[Protection Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warrior--protection>)

[Popular Protection Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warrior--protection>)

1.

### Protection Warrior Overview

Protection Warriors excel in fights with high amounts of physical damage or
where mobility is needed. Much of the damage they take is mitigated through
blocking, making their damage intake smooth and predictable. Additionally, they
provide a healthy amount of utility, whether it be crowd control or raid buffs.
They are a formidable, fast paced, all-around tank making them a worthy choice in both raids
and dungeons.

Note that this guide focuses on aspects that are specific to Protection
Warriors and general tanking strategies are beyond its scope. If you wish to
know more about the tanking role and what you can do to improve, we recommend
that you read our [Tanking Guide](<https://www.icy-veins.com/wow/tanking-guide>).

Mediocrity, in a Good Way

Protection Warriors damage is done in distinct burst windows from

[[spell:107574]]

. We have a lot
of additional offensive cooldowns which we can take from Talents that enhance these windows even
further. On top of that, this spec has decent execute damage.

Decent If the Encounter Allows It

While Protection Warriors are sturdy tanks, dealing decent damage, we do fall short in some Raid encounters.
Our biggest weakness — un-blockable damage mixed with constant magic damage —
can become painfully relevant in Raids. We can still manage these encounters,
but will need additional attention from the healers in the Raid.

Where Shield Block Shines

Protection has a great damage profile for Mythic+ due to the high up-time of [[spell:107574]] and
other offensive cooldowns. On top of the damage part, we also have access to various defensive tools
to deal with any incoming damage.

[[spell:2565]] is the shining star in mitigating physical damage, and
considering that majority of Mythic+ damage intake is usually physical, we excel at it.
We also have access to a lot of various stops with stuns and even a AoE silence.

Little Bit of Everything

Majority of our utility comes from stuns: [[spell:46968]], [[spell:107570]], and even [[spell:385952]].
We also have a AoE fear with [[spell:5246]] and a AoE silence in [[spell:386071]].
For movement, we bring [[spell:12323]] for a quick burst of speed for our allies.

While it seems like a lot of tools, the stuns are subjective to diminishing returns and the fear and silence
have a fairly long cooldown. [[spell:6673]] and [[spell:97462]] are two of the buffs that we bring,
which also play a big role.

Decent, But There's a Catch

[[spell:6544]]

,

[[spell:3411]]

are the two mobility tools we have access to. These have a fairly low
cooldown, so they can be used frequently. In addition to them, we can rank

[[spell:100]]

and

[[spell:385952]]

as mobility as well. They do come with the caveat of needing a enemy target to be used, but are great for getting
around the battlefield fast.

Great If You're Knowledgeable

Protection's survivability is great, as [[spell:2565]] deals with most physical damage, and we have plenty of
tools to deal with bursty magic damage.

However, most of our defensive cooldowns need to be used **before** the
damage comes in. This means that you need to know exactly when the damage is
happening, and what type of damage it is. And **then** use the appropriate defensive.

As long as defensives are used at the right time, we have great survivability.
But when we cannot use them adequately, we will start struggling.

2.

### Protection Warrior in Midnight

### **Patch 12.1.5**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 brings a few updates for Protection Warriors in addition to new content.
There will be a new one boss Raid, The Unbinding of Kith'ix, and a Labyrinth Delve, Labyrinth of Kindo'jan!
In addition to that, we will have access to a new currency in [[item:280562]], which boosts our
gear to even higher levels, so be sure to check out the [Gear](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>) page.

[The Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) acts as an escalation to the progression of Season 2 in
Midnight, with the story surrounding Ula'tek and the Amani culminating in a new one-boss
raid, access to ascended item levels, multiple sources of catch up gear,
and access to an infinite number of Mistcrests to upgrade it. Make sure to check out our
patch hub for all the information on what is new, or has been updated with Patch 12.1.5.

2.3.

#### Class Changes

Protection Warrior received 2 changes in [Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>), both of which are buffs.
These buffs allow certain talents, which were not picked previously, to be played in specific scenarios.
Be sure to take a look at our Rotation and Talents page to get a better overview.

- [[spell:163201]] damage increased by 30%.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus:
  
  - [[spell:429647]] now reduces the Rage cost of [[spell:163201]] and [[spell:6572]] by 10.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_revenge.jpg>) Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Class Changes

Protection Warrior received a fair share of changes in 12.1. Various talents were modified, leading
to noticeable changes in what they do. There seems to be a slight emphasis on our bleed damage, seeing how
the talent changes and also our new Tier set revolves around it. Outside of that, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane
both got hit with significant changes, outlined below.

- [[spell:772]] got replaced with [[spell:384277]]
- [[spell:1264330]] now also increases [[spell:163201]] damage
- [[spell:385704]] now increases all bleed damage
- [[spell:383103]], [[spell:384036]] and [[spell:190456]] got buffed
- [[spell:228920]] no longer increases [[spell:6343]] and [[spell:6572]] damage, but now deals
  50% more damage and increases the damage of your bleeds instead
- [[spell:6572]] free cast can now also be procced from auto-attacks
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane:
  
  - [[spell:435607]] damage got increased by 40%
  - [[spell:436707]] damage bonus got reduced from 30% to 10%
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus:
  
  - [[spell:429636]] no longer reduces the cooldown of [[spell:436358]]
  - [[spell:429641]] now also increases the damage of [[spell:163201]]
  - [[spell:436358]] now has a cooldown of 30 seconds instead of 45
  - [[spell:429644]] got buffed from 20% to 30%
  - [[spell:429647]] now causes [[spell:23922]] to generate 4 additional rage
  - [[spell:429636]] reduces enemies damage dealt now by 20% instead of 10%

:::

### Midnight   Changes Overview

2.5.

#### Midnight Changes for Protection Warrior

While most other classes have gotten a bigger overhaul with
[Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), Protection Warrior remains roughly the same.
The biggest changes we get are from our Talent trees getting re-organized,
and a few familiar talents being modified.

Below there is a short list of some of the more impactful changes that
Protection Warrior received.

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus received 3 new talents.  
  
  
   ► **Click to expand**
  
  
  2.5.1. 
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane
  
  
  
  
  - [[spell:275336]], replaces [[spell:275336]] and is now only available for Mountain Thane.
  - [[spell:1270723]] provides a slight damage boost to our lightning strikes.
  - [[spell:1270724]] increases our [[spell:107574]] uptime.
  
  
  
  
  
  2.5.2. 
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus
  
  
  
  
  - [[spell:1270704]] causes [[spell:436358]] to put [[spell:1261060]] on all targets.
  - [[spell:1270709]] boosts your various bleeds.
  - [[spell:1270710]] gives us a small Haste buff and a boost to our [[spell:23922]] after casting
    			[[spell:436358]].
- Class and Specialization talents got re-arranged and modified.  
  
  
   ► **Click to expand**
  
  
  - [[spell:355]] duration now lasts for 6 seconds instead of 3 and its threat generation has increased.
  - [[spell:275336]] has been removed and is only available for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane as [[spell:275336]].
  - [[spell:1280961]] and [[spell:424742]] are 2 new decent talents.
  - [[spell:152278]] now requires 20 Rage instead of 10.
  - [[spell:376079]] now allows you to leap to the spears location.
  - [[spell:228920]] now increases the damage of [[spell:6343]] and [[spell:6572]] by 50%
    			while active.
  - [[spell:115767]] is now a talent and is applied only by [[spell:163201]].
  - [[spell:12975]] is now a passive which activates when using [[spell:871]].
  - [[spell:12323]] now also grants movement speed to allies.
  - [[spell:1271948]] is a new talent which grants us a ranged interrupt.
  - [[spell:97462]] now grants 50% more health when not in raid.
  - [[spell:384318]], [[spell:391572]] and [[spell:384969]] have been removed.
  - [[spell:202095]] now increases max health by 10%, and heals 1% for each 15 Rage spent.

2.6.

#### Apex Talents

Apex talents are new nodes, 4 in total, in the specialization tree, which are supposed to
further enhance your core abilities.

- [[spell:1269311]] causes [[spell:6343]] to buff your next [[spell:23922]]
  to also deal additional damage in a cone behind your target and also increases the damage of
  [[spell:23922]] by 10%.
- [[spell:1269312]] further increases the damage of the wave of force and [[spell:6343]].
- [[spell:1269313]] just buffs the damage and Critical Strike chance of [[spell:23922]] while
  [[spell:2565]] is active and reduces the damage enemies hit by Phalanx's wave of force
  deal to you by 5%.

This is a throw back to Season 2 of the Dragonflight expansion, where we had a similar effect from our tier set.
The mentioned Apex talents are fairly boring and provide no real gameplay enhancements for us.
[[spell:23922]] and [[spell:6343]] are both rotational abilities, meaning that you will not
even have to think about the Apex talents. It just works while you are playing the class.

3.

### Basic Guidance for Protection Warrior

As a tank, your main job is to stay alive while keeping the enemies off of
your squishier raid/party members. To do so, you will try to generate as much
Rage as possible and then use it, depending on the situation, on either defensives,
like [[spell:2565]], or offensive abilities, like [[spell:6572]].

If you want to go more in-depth about Protection Warrior and
understand exactly what makes it work, you can start by looking at our
Talents page. This will go over all the main things you need to know about 
the talents and when to choose them.

Protection Warrior's whole playstyle is based on generating and
spending Rage. This means that you will have abilities that generate Rage,
such as [[spell:23922]], and abilities that will use that Rage, for example,
[[spell:190456]]. A further breakdown of Protection Warrior can be found in the 
three bullet points below.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_warcry.jpg>) **Manage your Rage**  
  
  	Rage is your main resource which is used to cast abilities: [[spell:2565]], 
  	[[spell:6572]] and [[spell:190456]]. Generating as much Rage as possible 
  	while minimizing the Rage wasted should be one of your main goals.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_defend.jpg>) **Use your Defensives**  
  
    As a tank, your main job is to keep the enemies targeting you. 
    To help you survive the onslaught, you need to make full use of 
    your defensive abilities. [[spell:2565]], [[spell:871]], 
    [[spell:1160]], [[spell:23920]] and even 
    [[spell:190456]] all boos your defensive capabilities - just 
    be sure to rotate them and not use them all at once!
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_shield_05.jpg>) **React to Procs**  
  
    Protection Warrior has a lot of various procs, which need to 
    be reacted to. [[spell:384041]], [[spell:6572]], 
    [[spell:29725]], while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane
  brings in additionally [[spell:435607]] and [[spell:437118]]. 
  Luckily, all of these affect only 3 abilities, [[spell:6572]], 
  [[spell:23922]] and [[spell:6343]].

4.

### How to Gear Up as a Protection Warrior

While we always recommend simming yourself for ideal results, we do provide a
dedicated Protection gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated and reviewed for 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **04 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Replaced weapon enchant with Rite of the Hash'ey.
- **04 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Replaced weapon enchant with Rite of the Hash'ey.
- **02 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated Colossus raiding build. Swapped Tough as Nails for Massacre.
- **10 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Idol of the Howling Nexus and Sszorak's Ferocity to trinket list.
- **03 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated the trinket tier list.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added proper catalyzed stats to BiS list.
- **18 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Added Phalanx into AoE priority.
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Fixed BiS list Leg enchants.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Trinket tuning updates.
- **12 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Added defensive talent build exports.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Added defensive build export strings for each scenario.
- **11 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Marked Colossus as the single-target recommended tree.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **26 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Added import strings for defensive Mythic+ builds.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **25 May 2026 (this page):** Added new hotfixe information.
- **04 May 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated Execute usage in rotation.
- **04 May 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated Colossus offensive raid talents.
- **04 May 2026 (this page):** Updated with the most recent hotfixes.
- **30 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Added defensive higher key build exports.
- **27 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Solar Core Igniter.
- **23 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Fixed a issue showing Thunder Blast under Colossus rotation.
- **23 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Swapped Mountain Thane back as recommended Raiding build for ease of use.
- **22 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Specified Voidcore usage.
- **21 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Swapped Bloodborne for Bloodsurge in Mythic+ talents
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **05 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated single-target builds for Mountain Thane and Colossus.
- **03 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Removed last Apex Talent as a flex point for Mythic+.
- **02 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Modified Mountain Thane single-target priority.
- **02 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Thunder Blast higher priority than Shield Slam as Mountain Thane.
- **28 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Specified gems.
- **22 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Modified single-target opener.
- **17 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Clarified Tough as Nails usage.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated and reviewed for Midnight Season 1 launch.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated and reviewed for Midnight Season 1 launch.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Updated and reviewed for Midnight Season 1 launch.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated and reviewed for Midnight Season 1 launch.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Updated and reviewed for Midnight Season 1 launch.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated and reviewed for Midnight Season 1 launch.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated and reviewed for Midnight Season 1 launch.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Clarified the choice between Into the Fray and Heavy Repercussions.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated and reviewed for Midnight Season 1 launch.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated and reviewed for Midnight Season 1 launch.
- **16 Mar. 2026 (this page):** Updated and reviewed for Midnight Season 1 launch.
- **13 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated and reviewed for Midnight Season 1 launch.
- **03 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated wording for Raid builds.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated for Midnight.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Midnight.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Updated for Midnight.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Midnight.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Updated for Midnight.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Midnight.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated for Midnight.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for Midnight.
- **26 Feb. 2026 (this page):** Updated for Midnight.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated for Patch 12.0.1.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed and updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed and updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed and updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed and updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed and updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.1.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated for Patch 12.0.1.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed and updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Reviewed and updated for Midnight Pre-Patch.
- **23 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Modified talents slightly to get earlier access to offensive abilities.
- **21 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Made Mythic+ builds more mobile.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed and updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed and updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed and updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.5, added Cartel Chips.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **18 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Added Heavy Handed to the talent choices for a more offensive approach.
- **13 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Removed Terror Sack from BiS list after tank damage reduction was applied.
- **08 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Adjusted Mythic+ talents for Mountain Thane.
- **05 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated Trinket list.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **22 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated DISC belt recommendations.
- **20 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Changed Titan DISC Belt recommendation from Charged Bolts to Critical Chain after hotfix.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7. Added information about Assisted Rotation.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 11.1.7. Added information about Assisted Rotation.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **18 May 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Tome of Light's Devotion and Improvised Seaforium Pacemaker to Dinars.
- **06 May 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Added information about Dungeon tips.
- **25 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated information about Puzzling Cartel Chips.
- **25 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Added a note about Indomitable and Ravager.
- **25 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Added a note about Indomitable and Ravager.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed and updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.1.5. Updated Colossus talent tree.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.1.5. Updated Colossus Mythic+ build.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Reviewed for Patch 11.1.5.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-liberation-of-undermine-raid-guide>)):** Updated the Gallywix section with tips.
- **04 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Added Mountain Thane as the suggested Mythic+ build.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for Patch 11.1.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-liberation-of-undermine-raid-guide>)):** Guide added.
- **25 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated the Cyrce's Circlet gems due to the tank role multiplier.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 11.0.7 and added a new section about Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Revewied for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Added recommended tag for talents for clarity. Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Added recommended tag for talent clarity. Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Reviewed for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Reviewed for Patch 11.0.5.
- **20 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Replaced Spare Meat Hook with Mad Queen's Mandate as the BiS trinket after tuning.
- **17 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Skyterror's Corrosive Organ to the trinket list.
- **17 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** Added information about Queen Ansurek.
- **13 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Silken Chain Weaver into trinket list.
- **11 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** Added Seismic Reverberation as the default choice for some additional bosses.
- **11 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Added a section about Stances.
- **11 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Added a section about Spell Block.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Resolved issue with Talents and Rotations having a mis-match.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated the Overall BiS list.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated food to include secondary stats.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Added notes about Fight Through the Flame and Seismic Reverberation for talent builds.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **30 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Added Spell Block to the defensives list.
- **26 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Added Delves Talent build.
- **23 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Ovi'nax's Mercurial Egg and Swarmlord's Authority into the trinket list. Updated trinket list after trinket tuning.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **27 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Removed Champion's Spear talents due to tier set still being available.
- **27 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Removed Champion's Spear talents due to tier set still being available.
- **24 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/protection-warrior-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **01 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/protection-warrior-the-war-within-pve-guide>)):** Updated the Core Changes and Mountain Thane section with the latest class changes.
- **20 Jun. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Added note about Ignore Pain usage.
- **20 Jun. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Added note about Ignore Pain usage.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/protection-warrior-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/protection-warrior-mists-of-pandaria-remix-guide>)):** Page added.
- **10 May 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Replaced Battering Ram with Enduring Alacrity.
- **08 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Removed "Alternative Mythic+ build". Added Enduring Alacrity into the builds.
- **08 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Replaced Battering Ram with Enduring Alacrity in all builds.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for 10.2.7. Replaced Heavy Repercussions with Into the Fray.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for 10.2.7. Replaced Heavy Repercussions with Into the Fray for the Mythic+ build.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for 10.2.7. Added note and alternative Mythic+ build with Into the Fray.
- **07 May 2024 (this page):** Reviewed and updated for Patch 10.2.7.
- **24 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Clarified Manic Grieftorch, Elementium Pocket Anvil and Cataclysmic Signet Brand usage.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed and updated for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Season 4. Added Disrupting Shout section under Utility.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Reviewed for Season 4.
- **18 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **22 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated the AoE rotation part by adding offensive Talents.
- **22 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated the Ignore Pain section.
- **22 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated the Vanguard and Ignore Pain abilities.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **07 Dec. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Replaced Withering Heart of Darkness with Prophetic Stonescales under Mythic+ trinkets.
- **30 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Branch of the Tormented Ancient as a trinket suggestion.
- **23 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated Rotation priority.
- **23 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Upgraded the Mythic+ gear list Neck.
- **21 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added mention of advised Embellishment crafting slots.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Removed Sporecloack from suggested embellishments.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed and updated for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed and updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed and updated for Patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed and updated for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed and updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed and updated for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed and updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **02 Oct. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Replaced Frozen Devotion with Wafting Devotion.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed and updated for Patch 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed and updated for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed and updated for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed and updated for Patch 10.1.7.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **19 Aug. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated Vanguard and Spell Reflection.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed and updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 10.1.5, removed Threat addon suggestions.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5, added Buzzing Rune as a option.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **21 Jun. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Added Frosted Armor Kit as a possible leg enchant.
- **21 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated Mythic+ talent build. Took Brutal Vitality.
- **21 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated Mythic+ talent build. Took Brutal Vitality.
- **21 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated Mythic+ talent build. Took Brutal Vitality.
- **05 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated the raid talent build. Took Spell Block as a default talent.
- **05 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated the raid talent build. Took Spell Block as a default talent.
- **24 May 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Cataclysm Timewalking section for trinkets.
- **16 May 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Added Shadowed Belt Clasp, waist enchant.
- **11 May 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Mark of Dargul into the trinket section.
- **11 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Prioritised showing talent build with tier.
- **11 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Prioritised showing talent build with tier.
- **09 May 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated Primordial Gem stones.
- **09 May 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated Primordial Gem stones.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for Patch 10.1.0.
- **01 May 2023 (this page):** Updated for Patch 10.1.0.
- **28 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Updated for Patch 10.1.0.
- **24 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated the Primordial Stone list.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated the Primordial Stone list.
- **22 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Humming Arcane Stone as a viable gem and updated the Onyx Annulet use cases.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Added Humming Arcane Stone as a viable gem and updated the Onyx Annulet use cases.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Swapped Thunderlord for Battering Ram and reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/protection-warrior-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added information about Primordial Stone Gems and reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Added information about Primordial Stone Gems and reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Reviewed for Patch 10.0.7.
- **15 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated the talent build to default Battering Ram over Thunderlord.
- **15 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated the Mythic+ talent build to default Battering Ram over Thunderlord.
- **15 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated the Mythic+ talent build to default Battering Ram over Thunderlord.
- **27 Feb. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Added Thunderous Roar, Shield Charge to ability list.
- **27 Feb. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Moved Thunderous Roar up in priority for openers.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([Castle Nathria page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-castle-nathria-raid-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sanctum-of-domination-raid-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **26 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added Whispering Incarnate Icon to the trinkets list.
- **26 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Added additional Haste gem suggestions.
- **23 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Added some Vault of the Incarnate trinkets to the noteworthy trinket list.
- **23 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Added notes about Battering Ram, Spell Block and the seasonal affix.
- **23 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Added notes about Spell Block.
- **21 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated talent calculator pick order.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated the gear suggestion, added tier set and embellishment suggestions.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Replaced Sophic Devotion weapon enchant with a more offensive Frozen Devotion.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Added tier set rotational changes paragraph.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Replaced Overwhelming Rage with Sidearm for the Raiding build.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Replaced Overwhelming Rage with Sidearm for the Raiding build.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([Torghast](<https://www.icy-veins.com/wow/protection-warrior-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-castle-nathria-raid-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/protection-warrior-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/protection-warrior-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/protection-warrior-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/protection-warrior-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/protection-warrior-patch-9-2-changes-analysis>)):** Reviewed for the release of Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/protection-warrior-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** Updated for 9.1.5.
- **17 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** Removed PTR references.
- **04 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** Added Kyrian-specific Legendary information.
- **18 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** Added descriptions of new Legendary Powers.
- **27 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/protection-warrior-patch-9-1-changes-analysis>)):** Page created.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **26 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-the-eternal-palace-raid-guide>)):** Added a few more boss tips. Updated Essence suggestions.
- **15 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-the-eternal-palace-raid-guide>)):** Added several boss tips.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-the-eternal-palace-raid-guide>)):** Page added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **14 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-crucible-of-storms-raid-guide>)):** Added boss tips.
- **16 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-crucible-of-storms-raid-guide>)):** Page added.
- **25 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-battle-of-dazar-alor-raid-guide>)):** Added additional information for Grong.
- **06 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-battle-of-dazar-alor-raid-guide>)):** Added tips for each boss.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** Updated for Patch 8.1.
- **29 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** Added note about Spell Reflection on Vectis.
- **10 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** Added tips for each boss.
- **13 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-uldir-raid-guide>)):** Page added (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Protection Warrior leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Warrior leveling guide](<https://www.icy-veins.com/wow/warrior-leveling-guide>).

1.

### Protection Warrior Leveling Guide for Midnight

Thanks to being a tank specialization, Protection Warrior can do
big pulls while questing and survive them without issues. Running around and tagging
as many enemies as possible before grouping them up and killing them
will lead to fast quest completions.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>)Leveling Tips
As a tank, you should queue for dungeons between questing. Completing
dungeons gives a hefty amount of experience, and as a tank you will have
quicker queue times than DPS specializations. Enemies you fight in dungeons
are generally stronger, granting more experience, and they also use more abilities
than the mobs you meet while questing.

This means that while inside a dungeon, you need to pay more attention and use
your abilities in a more thoughtful way than you would otherwise. This, in turn,
leads to you learning the class a lot better, preparing you for the end-game content.

:::

1.1.

#### Leveling Gear Options

While leveling up, you should always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level but 2 secondary stats on it
instead of 1.

Alternatively, you can purchase Heirloom items. These scale with your level,
meaning you will not need to replace your gear while leveling. If you choose this
option, prioritize items that have Haste.

1.2.

#### Useful Leveling Consumables for Midnight

At the start of every new expansion, the one thing in everyone's mind would be how to reach
the maximum level. For Midnight, the max level is 90. There are various items
to boost your leveling speed and efficiency, allowing you to make the best
out of your playtime.

- [[item:132516]] — Massive movement speed boost that works when
  Mounts do not, and much faster than ground mounts.
- [[item:109076]] — Lets you glide off of ledges and cover vast
  distances quickly.
- [[item:172063]] — Gives you a speed buff when you kill
  enemies.
- [[item:168412]] — Do not forget this Mount Equipment to
  make your mounts faster on the ground.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Protection Level 80 Midnight Leveling
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZMzMzMzY2MzYGjxMNMzwiZMzYGmZAAAAwyAwMGgBALLoxMAGYmNYmZGY2AgZGAAGAD"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZMzMzMzY2MzsMjxYmGmZYxMzMjZYmBAAAALDAzYAGYDWWMaMDgZDzsBmZmBzGAMzAAwAGD"
}
```
:::

:::details 来源计算器编码
```
#JB-JDLCneVEcRXOIvNNRRZBZ0pUqpBGE8NKJFC-CFEMNKLmIJPehOXiiw+O2kaRVGopCQG-AAAA-TAEY0wsgM4gQZQ-
```

:::

2.1.

#### War Mode Talents for Leveling

The following PvP talents are recommended for
leveling and doing solo / small group PvE content. You may find that different
PvP talents work better for you, depending on your playstyle. Experimentation is
encouraged!

1. [[spell:199023]] significantly reduces
   the cooldown of [[spell:1160]], allowing for more damage
   reduction and damage output in conjunction with [[spell:202743]].
2. [[spell:206572]] improves mobility and
   inflicts moderate damage to targets along your path.
3. [[spell:199127]] provides a near-constant increase to Shield Slam and Devastate damage through more frequent
   critical strikes.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–2：**Starting at Level 1, you only have one active ability:
[[spell:1464]].

1. **等级 2 起：**Cast [[spell:100]] to initiate combat
   whenever possible.
2. **等级 5–15：**[[spell:34428]] activates whenever an
   enemy is killed. Use it to heal yourself.
3. **等级 16 起：**Use [[spell:202168]] to heal yourself
   when needed.
4. **等级 53 起：**Cast [[spell:107574]] to generate a bit of Rage
   and greatly increase your damage.
5. **等级 16 起：**Cast [[spell:1160]] to reduce the
   damage you take, and increase the damage you deal (when using the
   [[spell:202743]] talent).
6. **等级 55 起：**Cast [[spell:385952]].
7. **等级 3–9：**Cast [[spell:23922]] to deal a lot of damage.
8. **等级 10 起：**Cast [[spell:23922]] to generate Rage and
   deal damage.
9. **等级 10 起：**Cast [[spell:6343]] to generate Rage
   and deal AoE damage.
10. **等级 10 起：**Cast [[spell:163201]] when enemies are
    below 20% health.
11. **等级 10 起：**Be sure to keep [[spell:6673]] up on yourself and your
    allies at all times.
12. **等级 9–12：**Spend Rage on [[spell:1680]] to damage
    multiple targets if you do not need to spend it on your active mitigation to
    survive.
13. **等级 13 起：**Spend Rage on [[spell:6572]] to damage
    multiple targets if you do not need to spend it on your active mitigation to
    survive.
14. **等级 3–13：**Cast [[spell:1464]] as your filler
    spell.

3.1.

#### Active Mitigation

- Cast [[spell:2565]] as much as
   possible when tanking something and taking heavy physical damage.
- Further smooth out your damage intake by spending
   Rage on [[spell:190456]].

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated and reviewed for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Updated for Patch 12.0.1.
- **23 Jan. 2026:** Modified talents slightly to get earlier access to offensive abilities.
- **19 Jan. 2026:** Reviewed and updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Resolved issue with Talents and Rotations having a mis-match.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **10 May 2024:** Replaced Battering Ram with Enduring Alacrity.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **23 Nov. 2023:** Updated Rotation priority.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Swapped Thunderlord for Battering Ram and reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **21 Dec. 2022:** Updated talent calculator pick order.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Protection Warrior in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Protection Warrior

This page is intended for players who are new to the game or class, have no
intentions of raiding Mythic difficulty, or simply want a more straightforward
way to play their specialization without being overwhelmed by the numerous
subtleties and active abilities that need to be taken into consideration for
optimal play.

Protection Warrior has great mobility and a diverse toolkit, both in terms
of utility and defensive options. Due to their ability to block attacks,
Protection Warriors have a predictable and smooth damage intake, making them
relatively easy to heal.

Your primary goal throughout fights will be to maximize your Rage generation
and then use this Rage on your active mitigation abilities in order to keep
yourself alive. Making good use of your defensive cooldowns and utility is also
an integral part of proper play. Below you can find three points to help guide your
focus when learning the spec:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_warcry.jpg>) **Manage your Rage**  
  
  	Rage is your main resource which is used to cast abilities: [[spell:2565]], 
  	[[spell:6572]] and [[spell:190456]]. Generating as much Rage as possible 
  	while minimizing the Rage wasted should be one of your main goals.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_defend.jpg>) **Use your Defensives**  
  
    As a tank, your main job is to keep the enemies targeting you. 
    To help you survive the onslaught, you need to make full use of 
    your defensive abilities. [[spell:2565]], [[spell:871]], 
    [[spell:1160]], [[spell:23920]] and even 
    [[spell:190456]] all boos your defensive capabilities - just 
    be sure to rotate them and not use them all at once!
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_shield_05.jpg>) **React to Procs**  
  
    Protection Warrior has a lot of various procs, which need to 
    be reacted to. [[spell:384041]], [[spell:6572]], 
    [[spell:29725]], while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane
  brings in additionally [[spell:435607]] and [[spell:437118]]. 
  Luckily, all of these affect only 3 abilities, [[spell:6572]], 
  [[spell:23922]] and [[spell:6343]].

2.

### Beginner's Guide to Protection Warrior in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane   Single-Target Talents

2.1.

#### Single-Target Talents for Protection Warrior

This build is a decent combination of offensive and defensive talents, making
it a good all-around beginner friendly build.

**Be sure to make use of the 'Copy' button to import the build directly into your game!**

:::talents Single Target Easy Mode
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZGzMzMzMmNzMLzYMmphxwyMzMzgxMDAAAAWGAmxAMwGssY0YGAzGmZDmxMDmNAYmBAgZgxA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZGzMzMzMmNzMLzYMmphxwyMzMzgxMDAAAAWGAmxAMwGssY0YGAzGmZDmxMDmNAYmBAgZgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLPQRVemCEGYcdkPdMNRRtNWGEIJpp9BGC-CFMNEKLDIJPXw8+CdiikSVZltRWGo5A-AAAA-JQSU2AEUwAjDmF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane   Dungeon Talents

2.2.

#### Mythic+ and Delve Talents for Protection Warrior

This is a solid starter build for any AoE scenario, be it dungeons or
[Delves](<https://www.icy-veins.com/wow/delves-guide>).

**Be sure to make use of the 'Copy' button to import the build directly into your game!**

:::talents AoE Easy Mode
```json
{
  "code": "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsYmZZGjxMNmxwiZmZGzwMDAAAAWGAmxAMwGstY0YGAzSMzGMzMzwYBAmZAAYAjB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzYmZmZmxsYmZZGjxMNmxwiZmZGzwMDAAAAWGAmxAMwGstY0YGAzCmZDmZmZYsAAzMAAMgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJWGEIJpp9BGC-CFMNEKLmHIJPXw8+CdiikQVZltRWGoB-AAAA-JQSU0AEU4AjDmF-
```

:::

### Protection Warrior   Basic Rotation

2.3.

#### Basic Rotation for Protection Warrior

The basic rotation as a Protection Warrior is based on the following
priority. As said, this is a <em>priority</em>. It is not the exact sequence in
which abilities should be cast, but rather, each time you are able to cast an
ability, you should start at the top of the list and cast the first available
ability.

:::details FAQShould I Play Defensively or Offensively?
This is the main question most people will ask with tanking. The basic answer
is that if you are doing progression or are on a character you do not feel
comfortable playing offensively with, you should play defensively.

As you start to get comfortable, you can begin looking at DPS and play a
more mixed style, where you progressively push DPS while slowly giving up survivability.

Once you feel completely comfortable with the encounter and you will not hold
your raid back, you can then go for DPS. This point is different for every
person, as it depends on your group, your character, your gear, and your skill
level.

:::

Our most gameplay-changing talent combination is [[spell:107574]] and
[[spell:275336]]. There is a separate section in our rotation page 
for this combo altogether!

[[spell:190456]] will take priority over any other ability if your
next cast would put you past your maximum Rage. Otherwise use [[spell:190456]]
to dump any excessive Rage, as it is off the global cooldown. In addition,
ensure that you always have [[spell:2565]] up when actively tanking.

1. Cast [[spell:107574]] on cooldown.
2. Cast [[spell:1160]] on cooldown.
3. Cast [[spell:228920]] on cooldown, if talented.
4. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus: Cast [[spell:436358]] on cooldown.
5. Cast [[spell:385952]] on cooldown, if talented.
6. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane: Cast [[spell:435607]] whenever it procs.
7. Cast [[spell:23922]] on cooldown.
8. Cast [[spell:6343]] on cooldown.
9. Cast [[spell:163201]] if you do not need Rage for survivability. Do not use it in AoE.
10. Cast [[spell:6572]], if you do not need Rage for survivability.

Against multiple targets, using the above priority will still generate the
most Rage, thus allowing for the most active mitigation usage and best
survivability.

As an additional priority, make sure you are buffing yourself and your group
with [[spell:6673]] before entering combat.

While the above briefly explains how and when to use each ability, there are
a lot more specific things and interactions going on between various spells.
Understanding all of these is **crucial** as a Protection Warrior.

2.3.1.

##### Apex Talent: ![Phalanx Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_1115_warrior_improvedparry.jpg>) Phalanx

Apex talents enhance your [[spell:23922]], [[spell:6343]] and also provide
some extra damage in a frontal cone. The extra damage effect is activated with your
next Shield Slam, after casting Thunder Clap. This means, that **Apex talents do not
affect your rotation at all.** We are already prioritizing casting both of these
abilities on cooldown due to them being Rage generators, so as long as you do the rotation
correctly, you will benefit from the Apex talents.

2.3.2.

##### Season 2 Tier Set

The Season 2 tier set forces us to put more focus
on our free [[spell:6572]] casts with the 4 piece. Once you have the 4 piece,
failing to cast the free [[spell:6572]] will result in a noticeable damage loss.

- [[spell:1296647]]
- [[spell:1296648]]

### Protection Warrior   Cooldowns and Mitigation

2.4.

#### Cooldowns and Mitigation for Protection Warrior

As a tank, your main goal is to get threat of the enemies and
stay alive. To help you achieve this, we have various tools that will
help you mitigate damage or recover from it. Using these abilities
correctly is crucial, as failing to do so will result in death.

2.5.

#### Active Mitigation Abilities for Protection Warriors

Your rotation is only there to generate Rage for you, which you should then
invest into your active mitigation abilities, [[spell:2565]], and
[[spell:190456]].

[[spell:2565]] is your primary active mitigation ability. It should
be used anytime you are actively tanking an enemy and should be kept up as much
as possible. Using this takes priority over using [[spell:190456]]. While
you are not tanking, you should generally spend a charge if you are about to be
at 2 charges (which is the max). Even when not tanking, Shield Block increases
[[spell:23922]]'s damage by 30%.

[[spell:190456]] should be used <em>in addition</em> to
[[spell:2565]]. While Shield Block is limited by its cooldown, Ignore
Pain is simply limited by the amount of Rage you have available. As such, once
you have Shield Block up and on cooldown, spend your remaining Rage on Ignore
Pain, making sure you save enough Rage to use Shield Block once it comes off
cooldown. If you know a large amount of damage is incoming, it is worth pooling
your Rage in order to cast Ignore Pain right before the damage goes out,
increasing the likelihood that you survive.

2.6.

#### Cooldown Usage for Protection Warriors

As a Protection Warrior, you have a number of defensive cooldowns that you can
pick up via talents.

- [[spell:871]] should be used before you receive a large amount of
  damage. It decreases **all** the damage you take by 40% for its duration.
  Since it lasts for a reasonably long time, you should try to use it for
  longer periods of high damage intake. If talented into [[spell:12975]],
  it will also increase your health by 30%, healing you for the same amount.
- [[spell:1160]] together with [[spell:202743]] should be
  used as many times as possible during the encounter for Rage generation
  purposes as stated in the ability priority. However, it is absolutely worth
  <em>not</em> using it in that way and saving it instead if you need another
  cooldown for a period of high damage.
- [[spell:23920]] reflects the next spell cast against you back
  to the attacker and reduces magic damage taken by 25% for 5 seconds (or until
  a spell is reflected). Most magic damage boss abilities cannot be reflected. As
  such, the primary use of Spell Reflection is for mitigating magical damage
  rather than reflecting spells.
  
  
  
  
  It is important to know beforehand where that
  magic damage is and use Spell Reflection accordingly. You can further enhance
  the strength of this ability by taking [[spell:1235022]].

2.6.1.

##### Offensive Cooldowns

You might not have all of them, depending on which talents you choose to run.

- Cast [[spell:107574]] on cooldown. If you are playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane,
  [[spell:6343]] is available every other global cooldown as soon as you talent into [[spell:275336]].
  Just be aware of this and make sure to continue to follow the ability priority.
  
  
  
  
  You may have streaks where you constantly rotate between
  [[spell:23922]] and Thunder Clap due to Thunder Clap resetting Shield Slam.
  In such cases, you should pay more attention to your Rage bar to avoid going
  over the maximum and using [[spell:190456]] or [[spell:6572]] to spend
  some of that Rage.
- [[spell:376079]], [[spell:385952]] and [[spell:228920]] are all various
  offensive cooldowns that we can opt into via talents. Generally, they are straightforward and
  do not need any specific pre-planning or positioning. Try to cast them on cooldown and during the
  [[spell:1160]] and [[spell:107574]] windows to maximize their
  damage potential.

### Protection Warrior   Stat Priority

2.7.

#### Stat Priority for Protection Warrior

Currently, you want to prioritize secondary stats as follows.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>).

Item Level

Haste

Critical Strike

Versatility

Mastery

**Versatility is roughly equal to Critical Strike. Versatility provides you
constant damage reduction and also works against magic damage, but Critical Strike
excels in mitigating physical attacks through Parry, and increases damage dealt by
a bigger margin.**

**Generally speaking, the stat priority should only be followed when
comparing gear of the same item level. A piece of gear with a higher item level
than what you currently have should be equipped regardless of its secondary
stats.**

### Blizzard   Combat Assistant

2.8.

#### Combat Assistant for Protection Warrior

The [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) is a feature introduced in [Patch 11.1.7](<https://www.icy-veins.com/wow/patch-11-1-7-guide>) which, simply
put, helps you with your basic offensive rotation. To learn more about this new feature,
we recommend taking a look at our [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) guide.

:::details FAQShould I Use the Combat Assistant?
It is usable on an acceptable level, **as long as you weave in your
offensive and defensive cooldowns**. It follows our basic DPS rotational
priorities quite well, **but if you want to get the most out of the class,
we recommend against using it.**

The assistant only casts your basic offensive abilities, and you will
still need to use your offensive cooldowns and defensive abilities
like [[spell:2565]], [[spell:190456]], and others by yourself in order to survive.

:::

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **02 Apr. 2026:** Thunder Blast higher priority than Shield Slam as Mountain Thane.
- **16 Mar. 2026:** Updated and reviewed for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Reviewed and updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7. Added information about Assisted Rotation.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **11 Sep. 2024:** Added a section about Spell Block.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **27 Jul. 2024:** Removed Champion's Spear talents due to tier set still being available.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **20 Jun. 2024:** Added note about Ignore Pain usage.
- **08 May 2024:** Replaced Battering Ram with Enduring Alacrity in all builds.
- **07 May 2024:** Reviewed for 10.2.7. Added note and alternative Mythic+ build with Into the Fray.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed and updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **21 Jun. 2023:** Updated Mythic+ talent build. Took Brutal Vitality.
- **05 Jun. 2023:** Updated the raid talent build. Took Spell Block as a default talent.
- **11 May 2023:** Prioritised showing talent build with tier.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **15 Mar. 2023:** Updated the Mythic+ talent build to default Battering Ram over Thunderlord.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Replaced Overwhelming Rage with Sidearm for the Raiding build.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Protection Warrior in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Protection Warrior

For Season 2, Protection Warrior is in a great position. Both our Hero
Talents are viable and can be played everywhere, without hindering the overall performance
by too much.

- **Pure Single-Target -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus is currently leading in single-target damage
    output. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane is not too far behind, if you fancy that playstyle.
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane takes the win in AoE damage output. The damage profile
    it provides is excellent for AoE scenarios like Mythic+. That said, playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus
    in keys will not hinder you in any significant way.

**Quick Start Import Codes:**

:::talents Single-Target - Colossus
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGz0wYYZmZmZwYmBAAAALDAzYAgFzYYDGYGWoxMLMmxMDmNAAzMAgZgxA"
}
```
:::

:::talents AoE - Mountain Thane
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDwAbw2iRjZAMLYmNYmZmhxCAMzAAwAGD"
}
```
:::

:::talents Delves - Mountain Thane
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzYmZmZmxsYmZZGjxMNmxwiZmZGzwMDAAAAWGAmxAMwGstY0YGAzCmZDmZmZYsAAzMAAMgxA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Mountain Thane

Raid

Mythic+

recommended

Colossus

Raid

recommended

Mythic+

### 天赋方案 0-0

1.1.

#### Mountain Thane Raid Talents

This build is a decent combination of offensive and defensive talents, making
it a good all-around raid build.

[[spell:115767]], [[spell:384063]] and [[spell:385840]]
can be treated as flex points and placed elsewhere for a more defensive approach.
[[spell:385888]] is worth the point on bosses which auto-attack you a lot,
otherwise, do not take it.

[[spell:156135]] can be used on fights where you can consistently cleave on 2-3 targets with
[[spell:163201]].

:::details FAQInto the Fray or Heavy Repercussions?
For Raiding, you can default into

[[spell:202603]]

. While

[[spell:203177]]

is
better on lower Haste levels, it does not matter as much in Raiding due to you not actively
tanking 100% of the time.

**If you do feel you need more [[spell:2565]] up-time,
[[spell:203177]] should still be picked.**

:::

### 天赋方案 0-1

1.2.

#### Mountain Thane AoE Talents

The below build should be the basis of a standard Mythic+ and [Delves](<https://www.icy-veins.com/wow/delves-guide>) build as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane.

From the Specialization tree, [[spell:385888]] and [[spell:385704]] can both be
moved around freely. [[spell:1271948]] can be replaced with [[spell:383082]] for more damage
output.

:::details FAQInto the Fray or Heavy Repercussions?
For AoE content like dungeons, we advise to pick

[[spell:203177]]

with lower haste levels, as you will want the extra

[[spell:2565]]

up-time.
As your Haste increases, the cooldown of your

[[spell:2565]]

decreases, as
such, you should swap into

[[spell:202603]]

for its offensive capabilities.

:::

### 天赋方案 1-0

1.3.

#### Colossus Raid Talents

Solid all-around ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus raiding build, which offers
an alternative gameplay to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane.

[[spell:384063]], and [[spell:385840]]
can be treated as flex points and placed elsewhere for a more defensive approach.
[[spell:385888]] is worth the point on bosses which auto-attack you a lot,
otherwise place the point elsewhere.

[[spell:156135]] can be used on fights where you can consistently cleave on 2-3 targets with
[[spell:163201]].

:::details FAQInto the Fray or Heavy Repercussions?
For Raiding, you can default into

[[spell:202603]]

. While

[[spell:203177]]

is
better on lower Haste levels, it does not matter as much in Raiding due to you not actively
tanking 100% of the time.

**If you do feel you need more [[spell:2565]] up-time,
[[spell:203177]] should still be picked.**

:::

### 天赋方案 1-1

1.4.

#### Colossus AoE Talents

From the Specialization tree, [[spell:385888]] and [[spell:385704]] can both be
moved around freely. [[spell:203177]] can be swapped for [[spell:202603]] for more damage output
as soon as you feel comfortable with the [[spell:2565]] uptime. [[spell:1271948]] can be replaced
with [[spell:383082]] for more damage output.

:::details FAQInto the Fray or Heavy Repercussions?
For AoE content like dungeons, we advise to pick

[[spell:203177]]

early on
with lower haste levels, as you will want the extra

[[spell:2565]]

up-time.
As your Haste increases, the cooldown of your

[[spell:2565]]

decreases, as
such, you should swap into

[[spell:202603]]

for its offensive capabilities.

:::

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMjxYmGGDLzMzMDGzMAAAAYZAYGDwAbwyiRjZAMbYmNYGzMY2AgZGAAmBGD"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLPQRVemCEGYcdkPdMNRRtNWGEIJpp9BGC-CFMNEKLDIJPXw8+CB6AFFJlyKbjsMQD-AAAA-JQSU2AEUwAjDmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDwAbw2iRjZAMLYmNYmZmhxCAMzAAwAGD"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJWGEIJpp9BGC-CFMNEKLmIJPXw8+CdiikQVZltRWGoBA-AAAA-JQSU0AEU4AjDmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA02AAAzMDzMzMzMzmxsMMGz0wYYZmZmZwYmBAAAALDAzYAgFzYYDGYGWoxMLMmxMDmNAAzMAgZgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLPQRVemCEGYcdkPdMNRRtNWGEIJpp9BGC-CFMNEKLDIJPXw8+CB6AFFJlyajsMQjI-AAAA-AcgQphYhBTgwwC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDAsYGDLwAzwCNmZBmZmZYsAAYmBAMgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJGEIJ9FWqpBC-CFMNEKLmIJPXw8+CB4EFJhqyKbjsMQD-AAAA-AcgQphQhBTgwwC-
```

:::

### 天赋方案 0-0

For a more defensive build, try the export below. This build sacrifices **a lot**
of offensive value for more defensives.

:::talents Defensive Raid Build
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZGmZmZmxsZmZZGjxMNMGWmZmZGMmZAAAAwyMDwMGgB2glFjGzAY2wMbgxMDmNAYmBAgZgxA"
}
```
:::

### 天赋方案 0-1

Below is an example of an extremely defensive build for Mythic+. This can be used for
key levels you feel uncomfortable with due to high damage intake.

:::talents Defensive Mythic+ Build
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzwMzMzMmFzMLzYMmpxMGWMzMzYGmZAAAAwyMDwMGgB2gtFjGzAYWwMbYYmZYsAAzMAAMgxA"
}
```
:::

### 天赋方案 1-0

For a more defensive build, try the export below. This build sacrifices **a
lot** of offensive value.

:::talents Defensive Raid Build
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAmZGmZmZmxsZmZZGjxMNMGWmZmZGMmZAAAAwyMDwMGAYxMG2gBmhFaMzCYMzgZDAwMDAYGYMA"
}
```
:::

### 天赋方案 1-1

Below is an example of an extremely defensive build for Mythic+. This can be used for
key levels you feel uncomfortable with due to high damage intake.

:::talents Defensive Mythic+ Build
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzwMzMzMmFzMLzYMmpxMGWMzMzYGmZAAAAwyMDwMGAYxMGWgBmhFaMzCYmZGGLAAmZAADYMA"
}
```
:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a progression system introduced in [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), offering a range of minor customization options
that can enhance your character. Unlocked through a timegated questline, the Folio provides a selection of runes
that grant offensive, defensive, and utility-focused bonuses.

Below is a list of recommended bonuses to begin with. You can play around with
other options as well, as you can switch between them freely.

- Week 1:[[spell:1279599]]
- Week 2:[[spell:1279603]]
- Week 3:[[spell:1287555]]
- Week 4:[[spell:1279609]]
- Week 5:[[spell:1279614]]

[[spell:1279610]] and [[spell:1279609]] are interchangable with eachother.

3.

### Apex Talent: ![Phalanx Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_1115_warrior_improvedparry.jpg>) Phalanx

[[spell:1269313]] enhances our core rotational abilities, [[spell:6343]] and [[spell:23922]],
increasing their damage done. It also causes your next [[spell:23922]] that is cast after [[spell:6343]]
to deal additional damage in a frontal cone.

While the Apex talents enhance our core rotational abilities, they do not
provide any meaningful gameplay changes. Just by playing the rotation correctly,
you will gain the full benefit of the Apex talents, leading to a overall damage
increase.

One thing to note is that our Apex talent are pretty much fully offensive oriented.
The [[spell:1269311]] does reduce the enemies damage dealt to you by a small amount, but
outside of this, its all offensive.

4.

### Hero Talents

Protection Warrior, upon reaching Level 71, will gain access to one of two extra talent trees called 
Hero Talents. These two Hero Talents are ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus, both offering 
different playstyles and strengths depending on which you pick.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane Hero Talents focus on amplifying your already existing
abilities. The core of the tree is turning [[spell:6343]] into a much more powerful [[spell:435607]].
The design of the talents themselves gives us a fun feedback loop that is described below.

- [[spell:437118]] allows [[spell:434969]] to proc [[spell:23922]]
- [[spell:384041]] can proc [[spell:23922]]
- [[spell:23922]] can proc [[spell:435607]]
- [[spell:435607]] can proc [[spell:434969]] through [[spell:437079]]

As shown in the list above, the whole tree creates a positive 
Rage feedback loop while maintaining our rotational fluidness.
The better Rage economy is what mainly sets ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane
and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus apart.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus tree revolves around [[spell:436358]] and amplifying the damage of your bleeds,
[[spell:6572]] and [[spell:23922]]. While Demolish does not provide any Rage generation, it
hits like a truck and enhances our other abilities. It has a different, more methodical flow
than the spam heavy ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane. You need to put slightly more thought into where
to spend the Rage you generate while also trying to maximize each and every cast of [[spell:436358]].

5.

### PvP Talents (War Mode)

Opting into War Mode makes you eligible for open-world PvP but also grants
you the following benefits:

- World Quests at maximum level have 10% increased rewards.
- You gain 10% increased experience while leveling.
- Grants you the use of PvP talents in the open-world.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended that you enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself eligible for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

Below are the recommended PvP talents for leveling and PvE content. You are
able to choose one general PvP talent and three spec-specific talents.

- [[spell:199023]] reduces the cooldown of
  [[spell:1160]] by 15 seconds, bringing its cooldown to 30
  seconds, and causes enemies to deal reduced damage to all targets, not just you.
  This allows for extremely high uptime on Demoralizing Shout.
- [[spell:206572]] causes you to charge a long distance at high speed
  in the targeted direction. It does not require a target. It deals damage and
  knocks back any enemies that are hit by the charge. The movement that this
  talent provides is extremely useful for questing or getting out of dangerous
  situations. It is almost like having another [[spell:6544]] in terms of
  movement.
- [[spell:213871]] is a great tool to help you reduce the Physical
  damage dealt to your allies.
- [[spell:236077]] is another extremely strong option you can take. This allows
  you to significantly reduce the damage output of classes that rely on weapon
  damage.

These are simply recommendations. You may find other PvP talents more useful
depending on your playstyle.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated and reviewed for 12.1.5.
- **02 Oct. 2026:** Updated Colossus raiding build. Swapped Tough as Nails for Massacre.
- **12 Aug. 2026:** Added defensive build export strings for each scenario.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **26 Jun. 2026:** Added import strings for defensive Mythic+ builds.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **04 May 2026:** Updated Colossus offensive raid talents.
- **30 Apr. 2026:** Added defensive higher key build exports.
- **23 Apr. 2026:** Swapped Mountain Thane back as recommended Raiding build for ease of use.
- **21 Apr. 2026:** Swapped Bloodborne for Bloodsurge in Mythic+ talents
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **05 Apr. 2026:** Updated single-target builds for Mountain Thane and Colossus.
- **03 Apr. 2026:** Removed last Apex Talent as a flex point for Mythic+.
- **17 Mar. 2026:** Clarified Tough as Nails usage.
- **16 Mar. 2026:** Clarified the choice between Into the Fray and Heavy Repercussions.
- **13 Mar. 2026:** Updated and reviewed for Midnight Season 1 launch.
- **03 Mar. 2026:** Updated wording for Raid builds.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Updated for Patch 12.0.1.
- **21 Jan. 2026:** Made Mythic+ builds more mobile.
- **19 Jan. 2026:** Reviewed and updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **25 Apr. 2025:** Added a note about Indomitable and Ravager.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5. Updated Colossus Mythic+ build.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Added recommended tag for talent clarity. Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Added notes about Fight Through the Flame and Seismic Reverberation for talent builds.
- **26 Aug. 2024:** Added Delves Talent build.
- **21 Aug. 2024:** Updated for The War Within.
- **27 Jul. 2024:** Removed Champion's Spear talents due to tier set still being available.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7. Replaced Heavy Repercussions with Into the Fray for the Mythic+ build.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed and updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed and updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **21 Jun. 2023:** Updated Mythic+ talent build. Took Brutal Vitality.
- **05 Jun. 2023:** Updated the raid talent build. Took Spell Block as a default talent.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **15 Mar. 2023:** Updated the Mythic+ talent build to default Battering Ram over Thunderlord.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **23 Dec. 2022:** Added notes about Spell Block.
- **11 Dec. 2022:** Replaced Overwhelming Rage with Sidearm for the Raiding build.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Protection Warrior, depending on the type of damage you will be tanking.
We also have advanced sections about cooldowns, procs, etc. in order to maximize your
survivability and DPS. All our content is updated for World of Warcraft Patch
12.1.5.

1.

### Protection Warrior Gameplay and Rotation Guide

Welcome to our Rotation page for Protection Warriors. On this page, you will
find everything you need to know about actually playing the spec in Raiding
and Mythic+ scenarios.

By selecting talents and Hero Talents below, the rotations in this guide will
update accordingly.

:::details FAQShould I Play Defensively or Offensively?
This is the main question most people will ask with tanking. The basic answer
is that if you are doing progression or are on a character you do not feel
comfortable playing offensively with, you should play defensively.

As you start to get comfortable, you should start looking at DPS a
bit more and play a more mixed style, where you start pushing DPS
while slowly giving up survivability.

Once you feel completely comfortable with the encounter and you will not hold
your raid back, you can then go for DPS. This point is different for every
person, as it depends on your group, your character, your gear, and your skill
level.

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane

Single Target

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

Talent Selection

[[spell:107574]]

[[spell:385952]]

[[spell:202743]]

[[spell:376079]]

[[spell:228920]]

[[spell:1261060]]

[[spell:29725]]

[[spell:385704]]

[[spell:1271948]]

[[spell:456270]]

### Single-Target Opener

**适用条件：Ravager（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/970854.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132337.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/136080.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/613534.webp>)

**适用条件：Colossus（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/136105.webp>)

**适用条件：Mountain Thane（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/460957.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132110.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/134951.webp>)

**适用条件：Booming Voice（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132366.webp>)

**适用条件：Champion's Spear（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wowt/icons/6035322.webp>)

**适用条件：Colossus（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/5927618.webp>)

**适用条件：Mountain Thane（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/460957.webp>)

**适用条件：Shield Charge（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/4667427.webp>)

1.1.

#### Single-Target Opener for Protection Warrior

Generally, you will want to [[spell:355]] as you cast [[spell:100]].

1. **适用条件：Ravager（启用）。** Cast [[spell:228920]].
2. Cast [[spell:100]].
3. Cast [[spell:107574]] as you Charge.
4. **适用条件：Colossus（启用）。** Cast [[spell:6343]].
5. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]].
6. Cast [[spell:2565]].
7. Cast [[spell:23922]].
8. **适用条件：Booming Voice（启用）。** Cast [[spell:1160]].
9. **适用条件：Champion's Spear（启用）。** Cast [[spell:376079]].
10. **适用条件：Colossus（启用）。** Cast [[spell:436358]].
11. **适用条件：Mountain Thane（启用）。** Cast  [[spell:435607]].
12. **适用条件：Shield Charge（启用）。** Cast [[spell:385952]].

### Single-Target Rotation

1.2.

#### Single-Target Rotation for Protection Warrior

The single-target rotation as a Protection Warrior is based on the following priority. As said, this is a priority. It is not the exact sequence in which abilities should be cast, but rather, each time you are able to cast an ability, you should start at the top of the list and cast the first available ability for which you meet the criteria. This applies to all 'rotations' hereafter.

This does not take into account the usage of your active mitigation abilities (we cover this important topic in a subsequent section). Active mitigation usage is generally much more nuanced, and it would not be optimal to list them within an ability priority.

The overall goal is to generate as much Rage as possible by casting Rage-generating abilities so that Rage can then be spent on active mitigation.

:::details TipsHow to use [[spell:163201]]?
[[spell:163201]]

should be used over

[[spell:6572]]

as soon as the targets hits the health threshold.
When it comes to priority, use

[[spell:163201]]

when

[[spell:23922]]

and

[[spell:6343]]

are both on cooldown.

:::

1. **适用条件：Avatar（启用）。** Cast [[spell:107574]] on cooldown.
2. **适用条件：Booming Voice（启用）。** Cast [[spell:1160]] on cooldown.
3. **适用条件：Champion's Spear（启用）。** Cast [[spell:376079]].
4. **适用条件：Ravager（启用）。** Cast [[spell:228920]] on cooldown.
5. **适用条件：Colossus（启用）。** Cast [[spell:436358]] on cooldown.
6. **适用条件：Shield Charge（启用）。** Cast [[spell:385952]] on cooldown.
7. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]] if at 2 stacks.
8. **适用条件：Mountain Thane（启用）。** Cast [[spell:23922]] on cooldown. It can be reset anytime you cast [[spell:6343]], [[spell:6572]] or [[spell:231830]] and even through melees with [[spell:236279]]. Also watch out for [[spell:437118]] procs,which make your next 2 [[spell:23922]] have no cooldown.
9. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]].
10. **适用条件：Colossus（启用）。** Cast [[spell:23922]] on cooldown. It can be reset anytime you cast [[spell:6343]], [[spell:6572]] or [[spell:231830]]. and even through melees with [[spell:236279]].
11. Cast [[spell:163201]], if you do not need Rage for survivability.
12. Cast [[spell:6343]] if [[spell:1269311]] is not up.
13. Cast [[spell:6572]] if it is free.
14. Cast [[spell:6343]] on cooldown.
15. **适用条件：Javelineer（启用）。** [[spell:384110]] / [[spell:64382]] on cooldown, unless you need it for the shield break or silence.
16. Cast [[spell:6572]]  if the enemy is above the [[spell:163201]] health threshold and you do not need Rage for survivability.

Always keep in mind that Ignore Pain will take priority over any other ability if your next cast would put you past your maximum Rage. Otherwise use Ignore Pain to dump any excessive Rage, as it is off the global cooldown.

If you really want to min-max your damage output, you should try to sync up your hardest-hitting abilities with [[spell:107574]] and [[spell:1160]] windows. This allows you to fully benefit from the increased damage these two provide. However, be careful not to waste any casts by delaying them too long!

### AoE Opener

**适用条件：Ravager（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/970854.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132337.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/613534.webp>)

**适用条件：Snap Induction（启用）；Mountain Thane（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/460957.webp>)

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132110.webp>)

**适用条件：Booming Voice（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/132366.webp>)

**适用条件：Colossus（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/136105.webp>)

**适用条件：Champion's Spear（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wowt/icons/6035322.webp>)

**适用条件：Mountain Thane（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/460957.webp>)

**适用条件：Colossus（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/5927618.webp>)

**适用条件：Shield Charge（启用）。**

![](<https://static.icy-veins.com/wp/static/icydb/wow/icons/4667427.webp>)

1.3.

#### Multi-Target Opener for Protection Warrior

This AoE opener prioritizes gaining Threat on multiple enemies.

1. **适用条件：Ravager（启用）。** Cast [[spell:228920]].
2. Cast [[spell:100]].
3. **适用条件：Avatar（启用）。** Cast [[spell:107574]] as you Charge.
4. **适用条件：Snap Induction（启用）。** [[spell:435607]]
5. **适用条件：Booming Voice（启用）。** Cast [[spell:1160]].
6. Cast [[spell:2565]].
7. **适用条件：Colossus（启用）。** Cast [[spell:6343]].
8. **适用条件：Champion's Spear（启用）。** Cast [[spell:376079]].
9. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]].
10. **适用条件：Colossus（启用）。** Cast [[spell:436358]].
11. **适用条件：Shield Charge（启用）。** Cast [[spell:385952]].

### AoE Rotation

1.4.

#### Multi-Target Rotation for Protection Warrior

Against multiple targets, when playing defensively, the ability priority is the same as the single-target priority. It maximizes Rage generation and, therefore, survivability.

In dungeons in particular, where there are often new enemies to gain aggro on, it is worth casting [[spell:6343]] (or [[spell:6572]] if Thunder Clap is not available, even if it costs Rage) over [[spell:23922]] in order to pick up those enemies. Saving your allies is far more important than a bit of Rage.

:::details TipsWhat about [[spell:156135]]?
If running with

[[spell:156135]]

, you should use

[[spell:163201]]

in AoE over

[[spell:6572]]

when fighting 1-3 enemies. If facing more than 3 enemies, use

[[spell:6572]]

.

:::

1. **适用条件：Avatar（启用）。** Cast [[spell:107574]] on cooldown.
2. **适用条件：Booming Voice（启用）。** Cast [[spell:1160]] on cooldown.
3. **适用条件：Ravager（启用）。** Cast [[spell:228920]] on cooldown.
4. **适用条件：Champion's Spear（启用）。** Cast [[spell:376079]] on cooldown
5. **适用条件：Shield Charge（启用）。** Cast [[spell:385952]] on cooldown.
6. **适用条件：Mountain Thane（启用）。** Cast [[spell:23922]], if [[spell:1269311]] is up.
7. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]] on cooldown
8. **适用条件：Colossus（启用）。** Cast [[spell:436358]] on cooldown.
9. Cast [[spell:23922]] on cooldown.
10. **适用条件：Mountain Thane（启用）。** [[spell:6343]] on cooldown.
11. **适用条件：Colossus（启用）。** Cast [[spell:6572]] for the damage unless you need the extra Rage, in which case you should prioritize [[spell:6343]].
12. **适用条件：Colossus（启用）。** Cast [[spell:6343]] on cooldown. It takes priority over [[spell:6572]], if [[spell:772]] is about to fall off. [[spell:6343]] should also not be kept off cooldown for longer than 2 globals maximum due to the Rage it provides.
13. **适用条件：Mountain Thane（启用）。** Cast [[spell:6572]].

Keep in mind that [[spell:190456]] will take priority over any other ability if your next cast would put you past your maximum Rage. Otherwise use [[spell:190456]] to dump any excessive Rage, as it is off the global cooldown.

### Playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane

1.5.

#### Playing as Mountain Thane

While the rotation does not change significantly when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane, there are still some things to keep in mind. The Hero Talent is almost fully compromised of various procs and buffs, which need to be responded to properly in order to get the full benefit from this tree. Below, you can find helpful notes for when playing Mountain Thane.

- [[spell:435607]] can stack up to 2 times;
- [[spell:435607]] should be your number one priority every time it procs in 2+ target scenarios;
- [[spell:107574]] grants you 2 stacks of [[spell:435607]] thanks to [[spell:437134]], so try to use all your remaining Thunder Blasts before pressing Avatar;
- With [[spell:107574]] up, [[spell:435607]] should be your number one priority due to [[spell:1270724]];
- [[spell:275336]] reduces the cooldown of [[spell:6343]] significantly to the point you can, and should, use it every other global cooldown;
- Watch out for [[spell:437118]] procs, as it makes your next 2 [[spell:23922]]s have no cooldown;
- [[spell:438597]] requires [[spell:3411]] to be talented;
- [[spell:436162]] requires [[spell:107570]] to be talented;
- When playing with [[spell:456270]], be sure not use [[spell:107574]] and [[spell:1160]] back to back, as you will waste one stack of [[spell:435607]].

### Playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus

1.6.

#### Playing as Colossus

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus brings a new active ability to the table, [[spell:436358]]. This hits extremely hard and should be used as often as possible, ideally together with [[spell:107574]] and [[spell:1160]]. If it lines up, great, but you should **not** delay a cast of [[spell:436358]] for them unless the enemy dies before you would get an additional cast in.

- [[spell:436358]] should be used on cooldown;
- [[spell:436358]] is a channel, so be sure to position yourself in a way that no enemies are behind you before casting it, or that you are not standing in any harmful ground effects;
- [[spell:436358]] makes you immune to stuns, knockbacks, and forced movement effects. Use it to avoid the mentioned effects if needed;
- [[spell:436358]] channel can be interrupted with movement abilities, such as [[spell:6544]];
- Be sure to hit as many enemies as possible with [[spell:436358]] to apply [[spell:115767]] to all of them via [[spell:1270704]];
- [[spell:440992]] and [[spell:429639]] require [[spell:46968]] to be talented;
- [[spell:6572]] hits harder than [[spell:6343]], this means that for maximum damage output, your extra Rage should go into [[spell:6572]] instead of [[spell:190456]], if survivability is not a issue;

2.

### Midnight Season 2 Tier Set

Our current Tier Set puts heavy emphasis on the free [[spell:6572]] procs.
If you fail to hit [[spell:6572]] in the 5 second buff window, you will miss out on the
4 piece bonus, putting a real dent in your overall damage output.

- [[spell:1296647]]
- [[spell:1296648]]

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Protection Warrior
kit, we have compiled a more detailed explanation on individual parts of our rotation, from
important rotational mechanics that you need to pay attention to, to cooldowns and how to use them, so you can
reach your full potential when playing Protection Warrior.

### Apex Talent

3.1.

#### Apex Talent: Phalanx

The Apex Talents available for Protection Warrior are:

- [[spell:1269311]]: Creates a wave of force dealing damage, with your next [[spell:23922]]
  after using [[spell:6343]] while also increasing the damage of [[spell:23922]]
- [[spell:1269312]]: Increases the damage of [[spell:6343]] and the wave of force by up to
  20%
- [[spell:1269313]]: Increases the damage and critical strike chance of [[spell:23922]].
  Also reduces enemies damage dealt to you after they have been hit by the wave of force from [[spell:1269311]].

These talents do not significantly affect how we play the game. [[spell:6343]] and [[spell:23922]] are
both staple abilities of Protection Warrior, which are used in our core rotation. This means
that we get the full benefit of the talents without having to really think about it.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane is already focused around [[spell:6343]] and its enhance version,
[[spell:435607]], weaving in [[spell:23922]]s whenever it is available. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus
is more focused on dealing damage through [[spell:6572]] rather than [[spell:6343]].
This means, that you do need to pay slightly more attention to your Thunder Clap usage as
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus to trigger the Apex talents, instead of just spamming [[spell:6572]].

While simple by design, the damage increase these talents provide is fairly
decent, and it comes at pretty much no additional effort.

### Taunting and Threat

3.2.

#### Taunting and Threat

[[spell:355]] is your single-target taunt ability. Casting Taunt
significantly increases your threat generation for its duration. If you are
having trouble building Threat, deal as much damage as possible in this
window. Using Taunt also forces the enemy to fixate on you for a minimum of
5 seconds.

:::details One Taunt, Two Taunt, Three Taunt...
Instead of having just one Taunt, Protection Warriors can have up to

**three**

.
First one is just single target

[[spell:355]]

. Many people do not know,
that

[[spell:6544]]

resets the cooldown of

[[spell:355]]

when cast, so
this counts as a second one.
Third taunt is

[[spell:1161]]

, which is AoE and can be further
enhanced to also be a interrupt and silence with the talent

[[spell:386071]]

.

:::

### Storm Surge and Avatar

3.3.

#### Storm Surge and Avatar

This section only applies if you are using the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane hero tree with
[[spell:275336]] and assumes you have [[spell:107574]] active.

With [[spell:275336]], when you cast [[spell:107574]], your
ability priority stays the same, but you have to approach it differently.

During [[spell:107574]], [[spell:6343]] is available every other
global cooldown. This means that you will be rotating between Thunder Clap and
another ability based on the ability priority. For example, if you get lucky and
many of your Thunder Clap casts reset [[spell:23922]], you will find
yourself alternating between Thunder Clap and Shield Slam.

As another example, you might have a cast sequence that looks like this:
[[spell:23922]], [[spell:6343]], [[spell:23922]],
[[spell:6343]], [[spell:6572]] (free), [[spell:6343]],
[[spell:6572]]...

Again, your ability priority does not change. [[spell:23922]] is still
above [[spell:6343]]. Just be aware that during [[spell:107574]],
Thunder Clap has a significantly reduced cooldown and adjust accordingly.

Also, it is very easy to Rage cap during [[spell:107574]], so be ready to
dump Rage into [[spell:190456]] / [[spell:6572]].

### Rage Generation

3.4.

#### Rage Generation

Warrior's primary resource is Rage. It is important that you understand how
Rage is generated so you can effectively manage and use it.

Rage has a maximum capacity of 100 and is empty by default. Rage decays at a
rate of 1 per second when out of combat. In combat, Rage does not decay.

You generate Rage in two main ways: passively and through abilities.

3.4.1.

##### Passive Rage Generation

There are three sources of passive Rage generation.

1. **2 Rage** is gained every time you auto-attack. Note that this
   scales with attack speed. Equipping daggers, for example, is not for better
   Rage generation.
   
   - More specifically, you generate 1.75 *
     weaponSpeed * 0.44 Rage per auto-attack. 1-handed weapons are 2.6
     speed, which equates to 2 Rage per auto-attack.
2. **3 Rage** is gained every time an enemy auto-attack hits you.
   
   - There is a cooldown on this. It seems to be around 1 second, but the
     exact cooldown is unknown at the moment.
3. [[spell:384361]] is a talent that grants your bleed effects a 15%
   chance to grant you 5 Rage.

Rage is not gained from avoidance events (that is, if the enemy
parries/dodges or if you parry/dodge).

Because Rage is gained when an auto-attack hits you, Rage generation
tends to be much higher in dungeons or encounters with multiple enemies.

3.4.2.

##### Rage from Abilities

In order of most Rage to least:

- [[spell:228920]] generates up to 60 Rage (if it hits every time).
- [[spell:1160]] generates 20 Rage (only with
  [[spell:202743]]).
- [[spell:376079]] generates 10 Rage.
- [[spell:385952]] generates 20 Rage, 40 if you also have [[spell:386328]].
- [[spell:100]] generates 20 Rage.
- [[spell:23922]] generates 15 Rage.
- [[spell:6343]] generates 5 Rage.

There are some talents that further increase the Rage generated by some
abilities. Take a look at our Talents page to get to know them
all.

[Protection Warrior Talents and Builds](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-spec-builds-talents>)

### Rage Management

3.5.

#### Rage Management

It is important to understand that you do not <em>have</em> to spend Rage as
soon as you get it. Pooling your Rage in order to maximize Rage generation,
survivability, or damage is an important aspect of playing Protection Warrior.

For example, if you are in a fight and trying to maximize damage and are
casting [[spell:6572]] to do so, and you reach a part of the fight where
additional enemies join, then you will want to save your Rage/Revenge cast and
cast it on those additional enemies.

As another example, during [[spell:107574]], you may get a long streak
of [[spell:23922]] resets. Capitalizing on those resets immediately, rather
than delaying them by a global cooldown by casting Revenge, will result in
more Rage and more casts of Rage-spending abilities. You do not <em>lose</em>
casts of Revenge by waiting since it is limited by the total amount of Rage
you have available.

You can lose casts, however, if you cap out on Rage. This means you hit the max of
100 Rage and any further Rage generation is lost.

On single-target, you will generate a decent amount of Rage, but you will
rarely ever get close to capping out on Rage unless you are playing incorrectly.

On multi-target, however, specifically when you have multiple enemies
auto-attacking you, is where proper Rage management is necessary to avoid
capping.

You should follow your ability priority as usual unless you hit a point where
following it would result in wasting Rage. In those situations, [[spell:6572]]
and [[spell:190456]] become your highest priority abilities.

If you are about to cap out on Rage and have very little or no
Ignore Pain absorb left, then make sure to cast Ignore Pain to stop
yourself from capping. If you are going for damage or you already
have Ignore Pain up, use Revenge.

Generally, you should still prioritize [[spell:6343]] above Revenge,
as wasting 5 Rage is minimal, and the extra damage gained from doing so
is worth it. As an example, say you are at 96 Rage. Casting
[[spell:23922]] at that point would provide you with 4
Rage, not 15. On average, you will gain more overall Rage by delaying
Rage-generating abilities by a global cooldown to avoid capping.

Sometimes, there are situations where you are unable to burn Rage quickly
enough with [[spell:6572]]. In these cases, simply spam [[spell:190456]],
even if your Ignore Pain is capped and you are wasting absorb. Doing so still
allows you to benefit from [[spell:152278]] and [[spell:202095]],
which is far better than capping Rage.

Additionally, as you repeat content and gain more experience with different
encounters, you should switch to a DPS ability priority (that is,
prioritize higher damage abilities over [[spell:23922]]) if you know that
normally, in that situation, you will have to "dump" Rage as outlined above. That
way, you deal more damage and generate slightly less Rage, reducing your risk of
capping and increasing your overall throughput.

### Block Rating

3.6.

#### Block Rating

You may notice that there is a "Block" stat on shields. The character sheet
has Block rating, and all of that rating comes from the Block on shields. So if
a shield has 2000 Block, the character sheet will show 2000 Block. Currently,
the amount of Block on your Shield is always 2.5 times the amount of Armor on
your Shield.

The damage reduction from blocking is calculated based on your total Block.
It is calculated in the same way damage reduction for Armor is: blockRating / (blockRating + k). The k value changes
depending on the difficulty or type of content you are doing.

Generally speaking, more difficult or newer content has a higher k value, and a higher k
value results in lower damage reduction. Block damage reduction is entirely
separate from Armor, and having more Armor does not affect it.

Critical blocks are simply double the damage reduction. For example, if a
regular block provided 40% damage reduction, a critical block would provide 80%
damage reduction. It is worth noting that just like Armor, there is a cap of 85%
on the damage reduction from Block. If a shield were to provide a 50% damage
reduction on normal blocks, critical blocks with that Shield would only be
85%.

This system incentivizes Shield upgrades heavily. Getting a good shield is a
significant increase in survivability, way more than a similar upgrade to
another piece of gear would be.

4.

### Active Mitigation Usage for Protection Warrior

Your rotation is there to generate Rage for you, which you should then invest
in your active mitigation abilities. As a Protection Warrior, you have two
abilities that are essential to staying alive: [[spell:2565]] and
[[spell:190456]].

### Active Mitigation

4.1.

#### Shield Block

[[spell:2565]] is your primary active mitigation ability. In the
vast majority of situations, most of the damage you will take is blockable. As
such, keeping Shield Block up as much as possible is key to smoothing out damage
and helping you survive. Shield Block scales with the damage you are taking
since it is a percent reduction to damage rather than a flat amount like
[[spell:190456]] is.

It is important to understand the difference between <em>overall</em>
[[spell:2565]] uptime and <em>effective</em> uptime. You want to have
as much effective Shield Block uptime as possible. All that means is having
Shield Block up when you are tanking something that actually melees you.

Essentially, anytime you are tanking something, you should be keeping
[[spell:2565]] up as much as possible. It should still, however, be
used intelligently, much like you would use major cooldowns.

:::details FAQDo I Need 100% Shield Block Uptime as Protection Warrior?
Maintaining

[[spell:2565]]

while actively tanking to reduce incoming damage
should be your top priority. That said, there is a significant difference in the
overall uptime of Shield Block, and effective uptime.

Effective uptime means that you have Shield Block up, while actively
taking melee hits. Whereas overall uptime also counts the time when you
are not necessarily taking any blockable damage.

You should always aim to have as high as possible

**effective**

[[spell:2565]]

uptime, while covering any potential downtime with defensive tools like

[[spell:871]]

.

:::

[[spell:2565]] has the following properties.

- Causes you to block all melee attacks made against you for 6 seconds. These
  blocks can be critical blocks.
- The damage reduction provided by these blocks is determined by your
  Block stat. See [here](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-rotation-cooldowns-abilities#block-rating>).
- It increases [[spell:23922]] damage by 30% while active.
- It costs 30 Rage.
- It has 2 charges with a 16-second recharge time (reduced by Haste).

**[[spell:2565]] is your primary mitigation ability. It takes priority
over [[spell:190456]], assuming you are taking blockable damage
(which is almost always).**

Using [[spell:2565]] is fairly straightforward. If you are taking
blockable damage, you should be using Shield Block to reduce it.
There are a few things to look out for in regards to getting the maximum out of
your [[spell:2565]] usage:

- [[spell:2565]] works against all melee attacks (as in,
  auto-attacks/white hits), but there are also many boss abilities/mechanics
  that are blockable as well. Sometimes, things that you would expect to be
  blockable are not, and things that you would not expect to be blockable are.
  
  
  
  
  You simply have to know what these blockable mechanics are. The
  point here is that if you <em>do</em> know a higher damage ability is
  blockable, you are much better off delaying Shield Block so that the last
  bit of its duration blocks that ability.
- For further benefit, you can time [[spell:2565]] with the
  enemy's melee swings. Most enemies have a swing timer between 1.5 and 2
  seconds. If you cast Shield Block right after a melee, you essentially just
  lost 2 seconds of effective uptime.
  
  
  
  
  Sometimes, it can be difficult to tell when an enemy is actually melee
  attacking you, so this point is not super important, but it can be beneficial
  if done properly.
- Also, be aware of the enemy's spell casts/channels. If the boss is about
  to spend 5 seconds casting a spell, you should delay [[spell:2565]]
  accordingly.
- Similar to the first point, but if you know an enemy is about to deal
  increased damage, you should delay [[spell:2565]] for those periods
  as well.

If you are not currently tanking, and there is a good amount of time before
you do tank again, use [[spell:2565]] to increase
[[spell:23922]]'s damage. Just be sure to time it in such a way that as
you are about to tank again; you have close to 2 charges of Shield Block, so you
can maximize effective uptime.

### Ignore Pain

4.2.

#### Ignore Pain

[[spell:190456]] reduces damage by a flat amount and, with its current
tuning, is much weaker than [[spell:2565]]. As such, it should be used
<em>in addition</em> to Shield Block, not in place of it.

[[spell:2565]] is limited by its cooldown, where
[[spell:190456]] is simply limited by the amount of Rage you have
available. So, once you have Shield Block up and on cooldown, spend your
remaining Rage on Ignore Pain, making sure you save enough Rage to use Shield
Block once it comes off cooldown. More or less, Ignore Pain should be used to
further smooth out your damage intake.

[[spell:190456]] has the following properties:

- It removes 50% of any particular damage event. That is, for any damage
  taken, 50% of that damage is dealt to the absorb, and the other 50% is dealt to
  you.
- It has a maximum absorb size of 30% of your maximum HP.
  
  - This means the absorb does stack, just not very much.
  - The cap size is determined <em>on cast</em>.
- It has a duration of 12 seconds.
- It costs 35 Rage.

Just like [[spell:2565]] though, it can and should be used
intelligently if doing so provides a benefit.

- If you are not tanking and are taking very little or no damage, do not
  use your Rage on [[spell:190456]]. Depending on how long you are not
  tanking for, it will simply expire, wasting that Rage. Instead, try to cast
  an Ignore Pain right before you start tanking again. If you <em>are</em>
  taking damage while not tanking, cast Ignore Pain as needed to help out your
  healers.
- While generally speaking, you will want to use [[spell:190456]] to
  smooth out your damage intake, it can also be very important to pool your
  Rage and cast Ignore Pain right before a large spike of damage, increasing
  the chance that you survive that spike.

The exception to the points above would be when you are close to Rage
capping. In such situations, you should use [[spell:190456]] to spend
Rage even if it means going over the Ignore Pain cap.
Additionally, if you are ever in the extremely rare situation where there is
very, <em>very</em> little blockable damage, or none at all, you will, of course,
want to prioritize [[spell:190456]] over [[spell:2565]].

### Defensive and Battle Stance

4.3.

#### Stances for Protection Warrior

All warriors have access to various Stances depending on their specialization.
For Protection, these stances include: [[spell:386208]] and [[spell:386164]].
These are passive, constant buffs which provide us with individual benefits depending on
which one we are in.

Broadly speaking, [[spell:386208]] stance reduces your damage taken, while
[[spell:386164]] increases your damage done. Choosing which stance to use should be
done case-by-case. If the damage intake is high, then you should use [[spell:386208]]
to reduce the damage you take, otherwise you should be in [[spell:386164]].

You can easily swap between the stances mid-combat, so doing so depending
on the situation which nets you the best outcome. Below you can find some
example scenarios on when to use which stance.

- [[spell:386208]], reduces damage taken by 16%:
  
  
  - Use it if the damage intake is high
  - Use it if you are unfamiliar with the damage intake
  - Use it if you are taking non-blockable damage
- [[spell:386164]], increases Critical Strike chance by 3%:
  
  
  - Use it if the damage intake is not too heavy to deal more damage.

5.

### Important Cooldowns for Protection Warrior

### Defensive Cooldowns

5.1.

#### Defensive Cooldown Usage for Protection Warrior

As a Protection Warrior, you have a number of defensive cooldowns. Using your
defensive cooldowns properly is extremely important. You want to plan out your
cooldowns before going into an encounter and maximize their usage as much as
possible. Outlined below are your various defensive cooldowns and how they
should be used.

5.1.1.

##### Shield Wall

[[spell:871]] should be used to prepare for a large damage spike or
during periods of high damage. This is especially useful against non-blockable
damage. It is not recommended to use it if your health suddenly drops low, as
it does nothing to get your health back up, but in situations where you have
nothing else, you want to use it if it increases your chance to survive. If
using the [[spell:12975]] talent, you can also use [[spell:871]]
to heal yourself up after failing to use it preemptively. **Only use
it this way if there is no other way you are going to be getting out of
the fight alive, as [[spell:871]] should ALWAYS be used as a mitigation
tool rather than a healing tool.**

5.1.2.

##### Demoralizing Shout

With [[spell:202743]], [[spell:1160]] should be used
on cooldown and for damage purposes. More often than not, you will have it up at
a good time, helping you smooth out damage.

Now, there are definitely situations where you will want to delay the usage
of [[spell:1160]] if you know there is heavy damage upcoming and
you do not have anything else available.

Without [[spell:202743]], simply use it as you would a normal
defensive cooldown.

5.1.3.

##### Spell Reflection

[[spell:23920]] can be used in two different ways. Either as a way
to reflect a specific spell cast at you or as a magic damage reduction
cooldown. The vast majority of spells cast by bosses are <em>not</em>
reflectable, but the damage reduction portion still works, of course.

Rarely, some boss abilities are reflectable, and in these cases, reflecting them can be
extremely powerful, both in terms of damage reduction and dealing damage to the
boss.

Most of the time, you will be using it as a magic damage-reduction tool.
However, in dungeons and similar content, reflecting particularly powerful
spells is a great use of [[spell:23920]].

Remember that when you reflect a spell, you lose the Spell Reflection
buff, meaning you lose the damage reduction as well. Be mindful of this if
you are in a situation where you need the magic damage reduction, but there
are also reflectable spells being cast at you.

### Offensive Cooldowns

5.2.

#### Offensive Cooldown Usage for Protection Warrior

We have access to various offensive cooldowns, most of them need to be talented.
Below is a quick list of them.

- Amplifies damage: [[spell:107574]]
- Amplifies damage: [[spell:1160]], with [[spell:202743]] talented
- Deals damage: [[spell:385952]]
- Deals damage: [[spell:376079]]
- Deals damage: [[spell:228920]]
- Deals damage: [[spell:436358]], only as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus

The usage of all of them is really straight forward.
Use your damage dealing abilities when you have your amplifying abilities active.
This means that you should use [[spell:385952]], [[spell:228920]] and [[spell:436358]]
when you have either [[spell:107574]] or [[spell:1160]] (ideally both) active. This ensures
that you are taking the most out of your offensive capabilities.

[[spell:385952]] and [[spell:1160]] need some encounter knowledge in order to use offensively.
Both of them have a defensive part to them, [[spell:385952]] grants [[spell:2565]], and [[spell:1160]]
reduces enemies damage dealt to you. As a Tank, your first job is to stay alive, so only use these abilities offensively
if you know that you do not require the defensive parts of them during their cooldown duration.

:::details One Enemy or Ten Enemies..?
You might find yourself in a scenario where your damage dealing abilities are off cooldown,
but you are fighting a single enemy. In this case, think ahead. If you know that you are about
to fight a lot more enemies, then save your offensive cooldowns for that time instead.

**Be sure
not to delay the usage of your offensive abilities for too long, as you might lose a cast
of them over the encounter.**

:::

### Utility

5.3.

#### Utility for Protection Warrior

In this section, we will give a short overview to some other abilities,
which often get overlooked, but can lead to a significant gain when used correctly.

5.3.1.

##### Heroic Throw

[[spell:57755]] deals little damage but generates a decent amount of
Threat. It has no cost and no cooldown. Use it to gain aggro on distant enemies.
Also, if you are ever out of range of an enemy and cannot get back into melee
range for whatever reason, you can spam Heroic Throw for a tiny bit of extra
damage.

5.3.2.

##### Shattering Throw

[[spell:64382]] deals damage to enemies with a 1.5s cast time and
3-minute CD. Deals a lot more damage to absorbs and removes any magical
immunity. Mostly useful in PvP, but they can also find uses in PvE if the enemy
has an absorb on them. Also silences the enemy with [[spell:1271948]] talented.

5.3.3.

##### Wrecking Throw

[[spell:384110]] throws your weapon at enemies, dealing damage which
ignores armor and deals also increased damage to absorb shields. Similar to
[[spell:64382]], but has a 45 second cooldown and no cast time.
Silences enemies with [[spell:1271948]] talented.

5.3.4.

##### Intervene

[[spell:3411]] is a strong defensive CD that can have a variety of uses.
In Raiding, it can be used on our co-tank to reduce their incoming damage, while
in Mythic+, it can be used on party members that have fixate effects on them.

Knockback mechanics can be almost entirely negated by Intervene if reacted
to quickly. Using it to move quickly to another area by casting it on an
ally, perhaps to get out of environmental damage, can be extremely useful.

5.3.5.

##### Heroic Leap

[[spell:6544]] can be used to jump over ground effects or other
various mechanics that you would normally have to run around. It is not 100%
consistent in that sometimes, when you jump over something, you might still take
the damage.

But more often than not, you can use Heroic Leap to your advantage in
this way. More simply, Heroic Leap is great for getting into position or out of
dangerous mechanics.

[[spell:6544]] also resets the remaining cooldown on
[[spell:355]]. This means that you can easily Leap toward a new add that
spawned and immediately use Taunt to grab aggro even if you had used Taunt a
second ago.

5.3.6.

##### Shockwave

Proper use of [[spell:46968]] can be extremely important, both from a
crowd control perspective and a survivability perspective. It can be
used to stun enemies that are casting to interrupt those or to keep enemies in
place.

But more importantly, it can be used to completely stop damage
for its duration. Say [[spell:2565]] runs out, and you have no major
defensive cooldowns left to use. Using Shockwave on enemies (assuming they are
not immune) completely stops their damage. Timing its usage around your active
mitigation can prevent deaths.

5.3.7.

##### Intimidating Shout

[[spell:5246]] should be used in the same way
[[spell:46968]] is used; for crowd control purposes or survivability
purposes. You do have to be more careful with this ability, though. The enemies
that flee can run into another pack of enemies and pull them, possibly resulting
in a wipe.

5.3.8.

##### Rallying Cry

Timing [[spell:97462]] well can be the difference between a kill and
a wipe. It is a fairly significant survivability increase for your group, so
plan its usage well.

5.3.9.

##### Battle Shout

While not actually used in combat (unless to give the buff to a recently
resurrected ally), make sure you cast [[spell:6673]] on your group or
yourself before entering combat.

5.3.10.

##### Berserker Rage

[[spell:18499]] is a fantastic ability in the right situations.
There is a fair share of enemy abilities that fear, and being able to completely
stop those is a huge advantage. Identify where Berserker Rage can be used and
take advantage of those situations.

5.3.11.

##### Pummel

Many players simply do not use their kick unless specifically instructed to.
Interrupting enemies can stop potentially deadly mechanics from going out.
Identify those dangerous mechanics and use your kick!

5.3.12.

##### Piercing Howl

[[spell:12323]] provides a short burst of speed to your allies while slowing your enemies.
This can be great if used at the right time, such as during Raid encounters,
where often the raid needs to move from one place to another quickly.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **18 Aug. 2026:** Added Phalanx into AoE priority.
- **11 Aug. 2026:** Marked Colossus as the single-target recommended tree.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **04 May 2026:** Updated Execute usage in rotation.
- **23 Apr. 2026:** Fixed a issue showing Thunder Blast under Colossus rotation.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **02 Apr. 2026:** Modified Mountain Thane single-target priority.
- **22 Mar. 2026:** Modified single-target opener.
- **16 Mar. 2026:** Updated and reviewed for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Reviewed and updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **18 Aug. 2025:** Added Heavy Handed to the talent choices for a more offensive approach.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7. Added information about Assisted Rotation.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **11 Sep. 2024:** Added a section about Stances.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **30 Aug. 2024:** Added Spell Block to the defensives list.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **20 Jun. 2024:** Added note about Ignore Pain usage.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **22 Jan. 2024:** Updated the Ignore Pain section.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed and updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed and updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **27 Feb. 2023:** Moved Thunderous Roar up in priority for openers.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Added tier set rotational changes paragraph.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Protection Warrior in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Protection Warrior

The best gear you can find will come from the Weekly Mythic+ chest, now
known as the Great Vault, and from Mythic Raiding. In addition to these, you
can also place crafting orders once you have the necessary pieces.

While a definitive BiS list is hard to create, there are cases
where specific gear can be best in slot. For example, some trinkets have
extremely powerful special effects, and you will want to seek them
out regardless of the item level. Sometimes, some rings have special
effects that outweigh item level increases or the benefit of specific
secondary stats.

As a general rule of thumb, **any increase in item level is an upgrade**. For
Protection Warriors, the value of all the secondary stats is close enough
together that you should only look at what secondary stats a piece has if you
are comparing across the same item level. Not only that, but Stamina and Strength
increases are significant as well.

All in all, if you come across gear that is an item-level upgrade (or has a
socket and your current piece does not), equip it. If two pieces of equipment
are the same item level, equip the best piece according to the stat priority.
Finally, be aware of gear where the item level does <em>not</em> matter as
much, which is the case for specific trinkets, rings, and gear with special effects, etc.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the Best in Slot Gear for Season 2 of Midnight. BiS lists are created in a vacuum, so for the best result, always sim yourself.

:::details FAQWhich Tier Set Pieces Do I Want?
As catalysing an item now keeps the stats of the initial item and converts it into tier, you can choose which stats you want on which tier pieces, giving you more gearing freedom. This means we want to prioritise acquiring items with cantrip effects or good secondary stats, and catalyse them into tier pieces.

- Helm: Catalyse [[item:281239]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Shoulders: Catalyse [[item:239037]] from Temple of Sethraliss
- Hands: Use the regular tier item from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>) or Catalyse [[item:251214]] from Den of Danolrakk
- Chest: Catalyse [[item:268222]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: Catalyse [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271456@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:251214@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAIAAAj1QWNYYjX1A]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271455@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268196@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

### Mythic+

The below list consists of gear, which is only found in Mythic+ dungeons. This does not mean that these items are the best for Mythic+, but that they just drop from dungeons instead of anywhere else. BiS lists are created in a vacuum, so for the best result, always sim yourself.

:::details FAQWhich Tier Set Pieces Do I Want?
As catalysing an item now keeps the stats of the initial item and converts it into tier, you can choose which stats you want on which tier pieces, giving you more gearing freedom. This means we want to prioritise acquiring items with cantrip effects or good secondary stats, and catalyse them into tier pieces.

- Helm: Catalyse [[item:239050]] from King's Rest
- Shoulders: Catalyse [[item:239037]] from Temple of Sethraliss
- Hands: Catalyse [[item:251214]] from Den of Danolrakk
- Chest: Catalyse [[item:251193]] from The Blinding Vale
- Legs: Catalyse [[item:273776]] from Altar of Fangs

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>): Drops 3 decent items, including a shield.
- [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Drops 2 items, including a weapon.
- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): Drops also 3 great items.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:251214@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Neck</th><td>[[item:251173@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Waist</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271455@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:239656@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div>Crafted by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Feet</th><td>[[item:273777@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271459@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250245@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251195@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251150@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span></div></td></tr></tbody></table>

### Raid

The below list consists of gear that is only found in the Raids. Raid. This does not mean that these items are the best for Raiding, but that they just drop from there instead of anywhere else. BiS lists are created in a vacuum, so for the best result, always sim yourself.

:::details FAQWhich Tier Set Pieces Do I Want?
As catalysing an item now keeps the stats of the initial item and converts it into tier, you can choose which stats you want on which tier pieces, giving you more gearing freedom. This means we want to prioritise acquiring items with cantrip effects or good secondary stats, and catalyse them into tier pieces.

- Helm: Catalyse [[item:281239]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Shoulders: Use the regular tier item from [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- Hands: Use the regular tier item from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- Chest: Catalyse [[item:268222]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: Catalyse [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
There are a lot of good items from the various raids. Below you can find a few which you should prioritize first.

- [[item:271878]]: Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>). The same boss also drops our best Neck and Weapon!
- [[item:268209]]: Drops from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>). Alternatively, [[item:268202]] drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:268265@JAAEAAgsSYgM]]: Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:281239]]: Drops from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>). The same boss also drops our best ring, [[item:281029]].

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271456@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAIAAAj1QWNYYjX1A]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271455@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-warrior-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268196@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Protection Warrior

Trinkets are some of the more unique items in the game due to their various
effects. They can either help bolster your defenses or assist in dishing out
even more damage. Regardless of which you will choose, below you can find a list
of other noteworthy trinkets for us. **There is still number tuning on-going, so
this list will be volatile depending on the changes to come.**

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Protection Warrior Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Raid</th>&#10;<th>Mythic+</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270175]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]</li>&#10;<li>&#10;&#10;&#10;[[item:281215]] - <span><em>Click for Details</em></span>&#10;<span>Solid passive trinket for dungeons. It has a high proc rate while also gaining value from actively attacking new targets.</span>&#10;</li>&#10;<li>[[item:270173]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:273795]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:281215]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:273795]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:270163]]</li>&#10;<li>[[item:270174]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250229]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:270163]]</li>&#10;<li>[[item:270174]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>&#10;&#10;&#10;[[item:158367]] - <span><em>Click for Details</em></span>&#10;<span>Deals a lot of damage, worthy of being in S tier, but comes with a hefty channel time. If you cast anything while channeling the trinket, it will cancel the channel.&#10;		   You also cannot block while channeling, meaning that in Mythic+ you will more than likely die when using it at any relevant key level unless you use&#10;		   [[spell:871]] for it.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>Defensive trinkets</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270160]]</li>&#10;<li>[[item:159618]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270160]]</li>&#10;<li>[[item:159618]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

As a general rule, you do not want to have two on-use trinkets, since if you use one, the other one will
also get a 30 second cooldown. Considering this, you should aim to use either two passive trinkets, or one
passive and one on-use. Few example combinations of trinkets can be found below.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Example Combo #1**
**On-Use -**

[[item:270175]]

**Passive -**

[[item:270173]]

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Example Combo #2**
**Passive #1 -**

[[item:270173]]

**Passive #2-**

[[item:281215]]

:::

2.1.

#### Merektha's Fang in Mythic+

[[item:158367@JAAEAAgsSYgM]] deals quite a lot of damage, but it has the downside of a 2.6-second channel time. 
The issue here is that while you are channeling the trinket, you will not be able to block incoming damage.
In raids this is usually not a dealbreaker, since you are not tanking constantly. However, it 
becomes more problematic in Mythic+ where you are the only tank. You can get away with it on lower keys,
but in higher keys where the damage intake is more noticeable, you will be at risk of dying every time
you channel the trinket, or are forced to use [[spell:871]] for the duration of the channel.

Because of this, although the trinket has great theoretical damage, it can be risky and often impractical 
to use in real dungeon situations.

3. 

## Other Noteworthy Gear for Protection Warrior

In the following sections, you can find some additional noteworthy gear. To better understand the
secondary stat prioritization for gear, look at the guide below, where each of the stats is broken
down into bite-sized pieces.

3.1. 

### Shields

A good shield is the most important piece of gear. Shield upgrades provide a
much larger defensive boost than upgrades to other slots.

You can acquire high item-level shields from dungeons, raids, and the Great
Vault weekly chest. The following shields are available from current
dungeons and raids.

<table>&#10;<tr>&#10;<th>Item</th>&#10;<th>Source</th>&#10;</tr>&#10;<tr>&#10;<td>[[item:268196]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:268262]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a>, in <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:251150]]</td>&#10;<td><strong>Sentinel of Winter</strong>, in <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:251196]]</td>&#10;<td><strong>Ziekket</strong>, in <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:159664]]</td>&#10;<td><a href="https://www.wowhead.com/npc=133389" rel="noopener noreferrer">Galvazzt</a>, in <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:193754@JAAIAAQkCYHKvbRLfA]]</td>&#10;<td><strong>Kryakka and Erkhart Stormvein</strong>, in <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></td>&#10;</tr>&#10;</table>

**Use the highest item level shield you can, regardless of its secondary
stats.**

3.2. 

### Weapons

Just as shields are important, so are weapons. They increase our damage
output, allowing us to provide more to the group's performance. Below, you can
find a solid selection of weapons.

<table>&#10;<tr>&#10;<th>Item</th>&#10;<th>Source</th>&#10;</tr>&#10;<tr>&#10;<td>[[item:268209]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a>, in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:268202]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a>, in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:251195]]</td>&#10;<td><strong>Ziekket</strong>, in <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:251218]]</td>&#10;<td><strong>Taz'Rah</strong>, in <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:158373]] </td>&#10;<td><strong>Avatar of Sethraliss</strong>, in <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;</tr>&#10;<tr>&#10;<td>[[item:268208]]</td>&#10;<td><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a>, in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td>&#10;</tr>&#10;</table>

As with shields, use the highest item level weapon you have, regardless of the
secondary stats.

4. 

## Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) is a Bonus Roll which can be used on bosses. Every boss has a
  specific loot table, and each time you get a item with [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>), it gets removed from
  any further bonus rolls on that boss.

[[item:268552]] increases the item level of fully upgraded Heroic and Mythic track gear. It can also be used to upgrade
fully Crafted items. This can only be used on weapons and trinkets, so not all gear is applicable.

4.1. 

### Recommended Nebulous Voidcore Usage for Protection Warrior

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) usage is dependant on the content you are doing. You do not want
to waste them on Heroic Raid bosses if you know you will be killing the same boss on Mythic
difficuly down the road. Opposed to that, if you know that you will be only raiding Heroic,
then using the Voidcores there makes perfect sense.

![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**

1. [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) for [[item:268209]] or [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:268202]]
2. Mythic Track Shield, if you do not have a crafted one
3. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:271878]]
4. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:268265]]

While all the loot in the list is from Raids, the same item slot logic follows when using [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)
in Mythic+ dungeons instead. If you use them after a Keystone 10+, you will obtain a Mythic track gear piece.

4.2. 

### Ascendant Voidcore Usage for Protection Warrior

As [[item:268552]] can only be used on weapons, trinkets and neck, the priority is fairly simple.

![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Ascendant Voidcore Priority**

1. Upgrade your Weapon
2. Upgrade your Trinkets
3. Upgrade your Necklace

5. 

## Best Crafted Items for Protection Warrior

Embellishments are various additional effects on craftable items. These can be
either baseline effects on certain items or other effects that can be added by
optional reagents when crafting an item.

TipsEmbellishment Piece Logic

Since [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) last 2 bosses, [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) and [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) drop items at 344 item level, we do not
want to craft Embellishments on pieces that these bosses drop. As such, if you Raid, your embellishments should go on **Feet** and
**Bracers** but if you only play Mythic+, put embellishments on **Back** and **Bracers** instead.

While there are multiple embellishment options, you can have only two active at
any time. Below you can find suggestions for the embellishments which are a great all-around option.
Remember to use [[item:245786]] as your default stat combination.

![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Protection Warrior Crafting Order**

1. [[item:237839@JAAOAAgN1MWNi8ymlUZMAMiViA]]
2. [[item:237834@JAAKAAgIvYTNbWCYwYlI]]
3. Swap the [[item:237839@JAAOAAgN1MWNi8ymlUZMAMiViA]]
   	for [[item:237828@JAAOAAgN1MWNi8ymlUZMAMiViA]], or for [[item:239656@JAAOAAgN1MWNi8ymlUZMAMiViA]] if you do not Raid once you get
   	access to a Mythic upgraded weapon.

Crafting a shield first instead of a weapon is also a valid option, you will not go wrong either way.

![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Protection Warrior Embellishments**

- [[item:245876]] on a weapon as your initial craft.
- [[item:240167]] on a low budget armor slot like Wrists or Feet (if you Raid) / Back (if you don't raid).
- Swap the [[item:245876]] to another [[item:240167]] once you get access to a Mythic upgraded weapon.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

5.1. 

### Adding Sockets to Gear

[[item:275707]] allows you to add sockets to Helmets, Belts and Bracers. If you do not
pick an item from your Great Vault, you will get tokens instead. Once you get 6 tokens, talk to the NPC next to the Great Vault
and you can trade the tokens in for [[item:275707]].

6. 

## Crest Usage

To upgrade your gear, you will use Crests, obtainable from various forms
of content in the game. They can be used to upgrade gear depending on which
track they drop in.

Since you need more Crests per upgrade level, it would be advisable to **not** upgrade
your gear with Mythic crests in the first couple of weeks of [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
Once you do decide to upgrade, below you can find a list of rough priority on which items to
upgrade first. For the best upgrade option for your character, be sure to sim yourself.

![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Crest Upgrade Priority**
**Weapon** = **Shield** ➜ **Helmet/Chest/Legs** ➜ **Trinkets** ➜ **Shoulders/Gloves/Belt/Boots**

7. 

## Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

8. 

## Changelog

- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **04 Oct. 2026:** Replaced weapon enchant with Rite of the Hash'ey.
- **10 Sep. 2026:** Added Idol of the Howling Nexus and Sszorak's Ferocity to trinket list.
- **03 Sep. 2026:** Updated the trinket tier list.
- **24 Aug. 2026:** Added proper catalyzed stats to BiS list.
- **17 Aug. 2026:** Fixed BiS list Leg enchants.
- **14 Aug. 2026:** Trinket tuning updates.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **27 Apr. 2026:** Added Solar Core Igniter.
- **22 Apr. 2026:** Specified Voidcore usage.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated and reviewed for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Reviewed and updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5, added Cartel Chips.
- **13 Aug. 2025:** Removed Terror Sack from BiS list after tank damage reduction was applied.
- **05 Aug. 2025:** Updated Trinket list.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **22 Jun. 2025:** Updated DISC belt recommendations.
- **20 Jun. 2025:** Changed Titan DISC Belt recommendation from Charged Bolts to Critical Chain after hotfix.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **18 May 2025:** Added Tome of Light's Devotion and Improvised Seaforium Pacemaker to Dinars.
- **25 Apr. 2025:** Updated information about Puzzling Cartel Chips.
- **21 Apr. 2025:** Reviewed and updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **25 Dec. 2024:** Updated the Cyrce's Circlet gems due to the tank role multiplier.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7 and added a new section about Cyrce's Circlet.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **20 Sep. 2024:** Replaced Spare Meat Hook with Mad Queen's Mandate as the BiS trinket after tuning.
- **17 Sep. 2024:** Added Skyterror's Corrosive Organ to the trinket list.
- **13 Sep. 2024:** Added Silken Chain Weaver into trinket list.
- **09 Sep. 2024:** Updated the Overall BiS list.
- **23 Aug. 2024:** Added Ovi'nax's Mercurial Egg and Swarmlord's Authority into the trinket list. Updated trinket list after trinket tuning.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **24 Apr. 2024:** Clarified Manic Grieftorch, Elementium Pocket Anvil and Cataclysmic Signet Brand usage.
- **22 Apr. 2024:** Reviewed and updated for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **07 Dec. 2023:** Replaced Withering Heart of Darkness with Prophetic Stonescales under Mythic+ trinkets.
- **30 Nov. 2023:** Added Branch of the Tormented Ancient as a trinket suggestion.
- **23 Nov. 2023:** Upgraded the Mythic+ gear list Neck.
- **21 Nov. 2023:** Added mention of advised Embellishment crafting slots.
- **07 Nov. 2023:** Removed Sporecloack from suggested embellishments.
- **06 Nov. 2023:** Reviewed and updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed and updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed and updated for Patch 10.1.5.
- **24 May 2023:** Added Cataclysm Timewalking section for trinkets.
- **11 May 2023:** Added Mark of Dargul into the trinket section.
- **09 May 2023:** Updated Primordial Gem stones.
- **01 May 2023:** Updated for Patch 10.1.0.
- **24 Mar. 2023:** Updated the Primordial Stone list.
- **22 Mar. 2023:** Added Humming Arcane Stone as a viable gem and updated the Onyx Annulet use cases.
- **20 Mar. 2023:** Added information about Primordial Stone Gems and reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **26 Dec. 2022:** Added Whispering Incarnate Icon to the trinkets list.
- **23 Dec. 2022:** Added some Vault of the Incarnate trinkets to the noteworthy trinket list.
- **11 Dec. 2022:** Updated the gear suggestion, added tier set and embellishment suggestions.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less


## 属性优先级

On this page, you will find out the optimal stat priority for your Protection Warrior. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Protection Warrior Stat Priority

The general stat priority for Protection Warriors is:

Item Level

Haste

Critical Strike

Versatility

Mastery

**Versatility is roughly equal to Critical Strike. Versatility provides you
constant damage reduction and works against magic damage, while Critical strike
excels in mitigating physical attacks by boosting your chance to parry. It also
increases your damage dealt by a bigger margin than Versatility.**

However, the value of all secondary stats is very close together. While Mastery
is considered the worst secondary stat, it is by no means a "bad" stat, still being
very close in value to the better stats. **Generally speaking, the stat priority
should only be followed when comparing gear of the same item level. A piece of
gear with a higher item level than what you are currently wearing should be equipped
regardless of its secondary stats.**

In the same vein it is also important to understand that having
<em>more</em> stats is better than having "better" stats. For example, if you
had to choose between 20 Critical Strike or 10 Haste, you are better off with 20
Critical Strike.

Enchanting and Gemming generally also follows the Stat priority, since the
more stats you have the better. There are some enchants, however, that do not
provide any stats, but other beneficial effects. To see if any of them are worth
using, take a look at our [Enchants & Gems guide](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-gems-enchants-consumables>).

:::details FAQHow Much Haste Should Protection Warriors Have?
For the most part, there is no set "amount" of <em>any</em> stat that you
should have. Nor are there stat goals or a particular distribution of stats that
you want to go for.

It is very common for people to overestimate the importance
of having the "right" secondaries, when in reality, having a higher quantity of
stats will almost always beat having "better" stats. Having 120 of your worst
stat is often better than having 100 of your best stat, since the differences
are not as big as many people think.

:::

2.

### In-Depth Stat Breakdown

Below, you can find a detailed explanation of what each of the stats provides for
Protection Warriors. **As a tank, your main priority is to survive, and
you should optimize your stats as such.** If you are comfortable with the class
and have no issues surviving, you can start looking to optimize for a more
DPS-oriented stat priority.

**Haste** does a few things. It reduces the global cooldown, increases
your attack speed, and reduces the cooldown on [[spell:23922]],
[[spell:6343]], resulting in increased Rage generation and damage.

But most importantly, it reduces the cooldown of [[spell:2565]].
This gives you much more control over your active mitigation and helps
smooth out your damage intake.

:::details Additional InformationAdditional Information
To expand on the above, the increased Rage generation increases the total
amount of [[spell:190456]] you get proportionally to the amount your Haste
is increased by. An X% Haste increase equates to X% more Rage over the course of
a fight, which equates to X% more Ignore Pain. The extra Rage also contributes
to further cooldown reduction via [[spell:152278]].

:::

**Versatility** increases all your damage and healing done (including
[[spell:190456]]), and decreases all damage taken. Versatility does not
require luck or rely on playing a certain way. It reduces <em>all</em> damage,
making it a solid stat for survivability.

:::details Additional InformationAdditional Information
Compared to other stats, it has greatly increased value on magic damage heavy
fights, and is first in the priority in those situations. Other stats rely on
you being able to block/parry attacks, or require the attack to be Physical
damage for them to reduce damage.

:::

**Mastery** ([[spell:76857]]) increases your chance to block,
your chance to critically block, and your Attack Power. Not only does it
increase your overall damage reduction, the increased attack power also
increases the size of your [[spell:190456]].

**Critical Strike** increases in value for Mythic+. This is because
it provides both defensive ([[spell:161798]]) and offensive
(increased critical strike chance) benefits.

:::details Additional InformationAdditional Information
The majority of the damage taken in dungeons is melee, meaning that with
higher Critical Strike, you can parry more often, reducing the incoming damage.
Critical Strikes also increase your overall damage output, helping you
complete the key faster. While it is a good stat for overall damage
reduction, it is also unreliable and does nothing against any other type of damage.

:::

**Strength** increases your Attack Power, which increases the size of your
[[spell:190456]]. However, its main value comes from the Armor increase
you get via [[spell:71]] and various other talents.

**Armor** reduces Physical damage taken. It is a completely passive and
consistent stat, making it quite good for survivability. It does absolutely
nothing for damage, however.

2.1.

#### Stamina

**Staming** increases your maximum health.

:::details Additional InformationAdditional Information
There is a very common misconception about Stamina in that it is only useful
for "surviving one shots" or something similar. That is definitely part of it,
and having enough health to survive mechanics is important, but it is not the
whole story.

Simply put, Stamina does the same thing as damage reduction does,
that is, it reduces the impact damage has on you. The disadvantage Stamina has
is that, while it increases your overall survivability, the damage you take has
to be healed up.

This is why stacking Stamina can be detrimental. You become a
healing "sponge", making it difficult for healers to heal you. The point here is
that Stamina is a good stat, and its value should be taken into consideration
when making comparisons.

:::

2.2.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated and reviewed for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Revewied for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Protection Warrior, based on your [stat priority](<https://www.icy-veins.com/wow/protection-warrior-pve-tank-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should aim to use gems that provide you with Haste, as that is our
most valued secondary stat. Use [[item:240983]], and fill
any other gem slots with [[item:240890]]. If those are too expensive,
feel free to use [[item:240893]].

2.

### Best Enchants and Weapon Augments

[[item:243733]] should be your default weapon Oil as it provides us with
2 of our favourite stats.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>[[item:244029]], solid alternative.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helmet</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244643]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

In addition to the enchants mentioned above, we can also use
flasks, food buffs, and potions to enhance our abilities even further.
These are not permanent and need to be re-applied after an hour or two, so be
sure to get multiple before a longer gaming session.

3.1.

#### Flask

[[item:241326]] and [[item:241325]] are both excellent choices.
Which exact one is best for you depends on your current stat distribution, i.e. if you have
a lot of Crit on gear already, you may choose the Haste flask instead, and vice versa.

3.2.

#### Potions

[[item:241308]] is your best potion in every scenario.
[[item:241288]] is only slightly behind, so it can be used as an alternative
if you do not have access to [[item:241308]].

:::details Draught of Rampant Abandon?
[[item:241292]]

actually provides more main stat to you than

[[item:241308]]

.
That said, it comes with a downside of also summoning void zones under your feet. These zones will
silence you when you stand in them. As such,

[[item:241308]]

will be the more consistent
potion, but

[[item:241292]]

is

**theoretically**

better if you can avoid the void zones.

:::

[[item:271883]] should be used as the healing potion in combat.

3.3.

#### Food Buff

[[item:255846]] or [[item:242273]] should be used as your food
when available. [[item:242274]] and [[item:242275]] are your two alternative
food buffs. Similarly to potions and flasks, the best one depends on your current stat
distribution. Generally speaking, you will not go wrong with either of them.

3.4.

#### Augment Rune

[[item:259085]] provides you with a temporary primary stat
buff that lasts for an hour, or until you die. While expensive, they do add
to your damage output and as such, should be used if gold is not a issue.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **04 Oct. 2026:** Replaced weapon enchant with Rite of the Hash'ey.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **28 Mar. 2026:** Specified gems.
- **16 Mar. 2026:** Updated and reviewed for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Reviewed and updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated food to include secondary stats.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed and updated for Patch 10.2.
- **02 Oct. 2023:** Replaced Frozen Devotion with Wafting Devotion.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5, added Buzzing Rune as a option.
- **21 Jun. 2023:** Added Frosted Armor Kit as a possible leg enchant.
- **16 May 2023:** Added Shadowed Belt Clasp, waist enchant.
- **09 May 2023:** Updated Primordial Gem stones.
- **01 May 2023:** Updated for Patch 10.1.0.
- **24 Mar. 2023:** Updated the Primordial Stone list.
- **22 Mar. 2023:** Added Humming Arcane Stone as a viable gem and updated the Onyx Annulet use cases.
- **20 Mar. 2023:** Added information about Primordial Stone Gems and reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **26 Dec. 2022:** Added additional Haste gem suggestions.
- **11 Dec. 2022:** Replaced Sophic Devotion weapon enchant with a more offensive Frozen Devotion.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Protection Warrior in World of Warcraft Patch 12.1.5.

1.

### Protection Warrior in Mythic+ in Midnight Season 2

Protection Warriors, while not the <em>best</em> in Mythic+ due to their
stun-oriented utility, have very decent survivability and solid damage output
when played correctly. The hardest part is learning which cooldowns to use, and when.

Some abilities are blockable with [[spell:2565]], while others are not. Some
abilities can be reflected back to deal massive damage to the enemies with [[spell:23920]],
while others cannot. All of this knowledge comes by playing the various dungeons and gaining
the experience yourself!

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

2.

### Best Mythic+ Talent Builds

Our Mythic+ trees provide a good amount of survivability and offensive capabilities.
Refer to the Builds and Talents page for more information about specific talents and when to use them.
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane is currently the better all-around choice for Mythic+.
This does not mean that ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus is bad by any means; it simply requires a finer
balancing act between offensive and defensive ability usage.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane Talent Build

2.1.

#### Mountain Thane Talents

:::details FAQWhat About Higher Keys?
[[spell:385888]]

can also be dropped for

[[spell:12975]]

, but this is overkill in most scenarios.

:::talents Defensive Mythic+ Build
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzwMzMzMmFzMLzYMmpxMGWMzMzYGmZAAAAwyMDwMGgB2gtFjGzAYWwMbgZmZYsAAzMAAMgxA"
}
```
:::

:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDwAbw2iRjZAMLYmNYmZmhxCAMzAAwAGD"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJWGEIJpp9BGC-CFMNEKLmIJPXw8+CdiikQVZltRWGoBA-AAAA-JQSU0AEU4AjDmF-
```

:::

### Alternative ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus Talent Build

2.2.

#### Colossus Talents

:::details FAQWhat About Higher Keys?
Below you can find the

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus

defensive build.

[[spell:385888]]

can also be dropped
for

[[spell:12975]]

, but this is overkill in most scenarios. If you decide not to take

[[spell:385888]]

,
then you can also opt out of

[[spell:385840]]

as

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus

for an additional free point.

:::talents Defensive Mythic+ Build
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAAkBAAGzwMzMzMmFzMLzYMmpxMGWMzMzYGmZAAAAwyMDwMGAYxMGWgBmhFaMzCYmZGGLAAmZAADYMA"
}
```
:::

:::

:::talents 天赋构筑
```json
{
  "code": "CkEAAAAAAAAAAAAAAAAAAAAAA0yAAAjZYmZmZGziZmlZMGz0YGDLmZmZMDzMAAAAYZAYGDAsYGDLwAzwCNmZBmZmZYsAAYmBAMgxA"
}
```
:::

:::details 来源计算器编码
```
#JB-DJLQRVeCEGIcdkOdMNRRdtZJGEIJ9FWqpBC-CFMNEKLmIJPXw8+CB4EFJhqyKbjsMQD-AAAA-AcgQphQhBTgwwC-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns, and Stops

3.1.

#### Interrupts, Stuns, and Stops

[[spell:6552]] is our main interrupt ability. As tanks, we will take the blunt
force of the overall damage intake in dungeons, and while we can deal with the physical
damage intake fairly easily thanks to [[spell:2565]], the magic damage is where
it can get trickier. Using [[spell:6552]] effectively to interrupt various dangerous casts
will help lower our damage intake greatly and increase our chances of survival.

[[spell:386071]] allows you to silence multiple enemies while also
Taunting all of them. While on paper, it seems like a great ability, it has a hefty 75
second cooldown and needs to actually interrupt the cast in order for the silence
to take effect. It does have potential uses in situations where you are facing
multiple deadly casters, or need help grouping packs.

[[spell:384110]] or [[spell:64382]] both also provide a silence effect
when talented into [[spell:1271948]]. [[spell:384110]] should be the default
choise as it has a 45 second cooldown, meaning that have an actual ranged
kick at our disposal!

[[spell:5246]] is primarily used as an interrupt because
the disorient it provides is easily broken by damage. You can also use it as
crowd control by using it on a group of enemies and pulling a specific enemy
out of that group to focus it down.

[[spell:46968]] is your AoE stun. Use it to delay or cancel
dangerous abilities, or use it as a survivability tool to stun enemies when
your defenses are down. [[spell:275339]] helps lower the cooldown of
this significantly, and it can be further enhanced by ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) Colossus
talents like [[spell:429639]] and [[spell:440992]].

[[spell:107570]] acts as another strong single-target stun. Use it
instead of [[spell:46968]] when you only need to stun one enemy in order
to prevent stun DR from kicking in. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane has the [[spell:436162]]
talent, which will make this also hit 2 additional enemies.

[[spell:385952]] should mainly be used on cooldown for the offensive part,
but it is worth remembering that it also stuns your primary target for 4 seconds
when cast.

[[spell:376079]] allows you to tether enemies hit by the spear to it and then leap to
the spears location for some additional damage. As with [[spell:385952]], you
should mainly use this on cooldown, offensively. Some types of situations where you might
consider delaying your spear are when fixates come up, or enemies jump around. In such cases, using
[[spell:376079]] for the purpose of tethering these enemies might be more beneficial
for the overall group performance.

### Other Utility

3.2.

#### Other Utility

[[spell:23920]] is primarily used for the magic damage
reduction. In Mythic+, however, many spells can be reflected back to
the caster. There are some spells that hit very hard, and
if reflectable, you can deal a lot of damage to the enemy.
Additionally, sometimes you can apply debuffs to the enemy that
normally would have been applied had you been hit by the spell.

[[spell:97462]] can be used to save teammates during heavy damage intake
phases, or to just help ease the pressure off your healer. It has a fairly
long 3-minute cooldown, so be sure not to waste it.

[[spell:18499]] makes us immune to Fear, Sap, and Incapacitate effects.
This can be used pre-emptively before the cast goes off or reactively when
you are already under the effect. You can further pick up [[spell:384100]],
which allows you to remove Fear effects also from your party members within 12 yards.
Alternatively you can take [[spell:1271925]], which allows [[spell:18499]] to also
remove all movement speed-impairing effects.

[[spell:3411]] is an extremely potent tool if there is a use case for it.
Preventing your party member from taking damage from, let's say, a fixating enemy
is a great way to help your group. This ability is made even better thanks to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane talent,
[[spell:438597]]. This causes the Intervene target to also gain a magic absorb shield,
which can be used as an extra defensive on allies who need it.

[[spell:64382]] may have niche uses in some dungeons where
the enemies either have a magical immunity or an absorb. Just remember that
it has a cast time, meaning that you do not want to use it while actively
tanking enemies. Also silences with [[spell:1271948]].

[[spell:384110]], similarly to [[spell:64382]] deals
bonus damage to absorbs. While it does not remove magical immunities, it
does have a much shorter cooldown, making it a more compelling choice
should the situation arise. Also silences with [[spell:1271948]].

[[spell:12323]] slows enemies near you by 70% while also increasing your
allies movement speed by 30%. This can be great to help your team avoid mechanics,
or just speed up the run from one enemy pack to another.

4.

### Dealing with Affixes

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Protection Warrior

Periodically spawns orbs that need to be interrupted or crowd-controlled.
Tools to deal with this affix include:

- [[spell:6552]]
- [[spell:386071]]
- [[spell:107570]]
- [[spell:385952]]
- [[spell:46968]]
- [[spell:5246]]

### Affix: Pulsar

4.2.

#### Pulsar Affix Management for Protection Warrior

Periodically spawns orbs, connected to players. You need to walk
into another players orb, and someone needs to walk into your orb to
get rid of it.

### Affix: Devour

4.3.

#### Devour Affix Management for Protection Warrior

Places an absorb on players which needs to be dispelled or healed through.
As Warriors, we cannot dispel, but we can assist our healer by healing ourselves
with [[spell:202168]].

### Affix: Voidbound

4.4.

#### Voidbound Affix Management for Protection Warrior

Spawns a new add, which buffs others. Just swap to this add as soon
as possible, and be sure to kill it off as a high priority.
As the Void Emissary has 1 health, you can start casting [[spell:163201]]
as soon as it spawns since it deals a massive amount of damage.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **12 Aug. 2026:** Added defensive talent build exports.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated and reviewed for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Reviewed and updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **08 Aug. 2025:** Adjusted Mythic+ talents for Mountain Thane.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **06 May 2025:** Added information about Dungeon tips.
- **25 Apr. 2025:** Added a note about Indomitable and Ravager.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5. Updated Colossus talent tree.
- **04 Mar. 2025:** Added Mountain Thane as the suggested Mythic+ build.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Added recommended tag for talents for clarity. Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **08 May 2024:** Removed "Alternative Mythic+ build". Added Enduring Alacrity into the builds.
- **07 May 2024:** Reviewed for 10.2.7. Replaced Heavy Repercussions with Into the Fray.
- **22 Apr. 2024:** Reviewed for Season 4. Added Disrupting Shout section under Utility.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **22 Jan. 2024:** Updated the AoE rotation part by adding offensive Talents.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed and updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed and updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **21 Jun. 2023:** Updated Mythic+ talent build. Took Brutal Vitality.
- **11 May 2023:** Prioritised showing talent build with tier.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **15 Mar. 2023:** Updated the talent build to default Battering Ram over Thunderlord.
- **27 Feb. 2023:** Added Thunderous Roar, Shield Charge to ability list.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **23 Dec. 2022:** Added notes about Battering Ram, Spell Block and the seasonal affix.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Protection Warrior in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Protection Warrior macros. You can import
these by simply clicking the "Copy" button on each individual block.

1.1.

#### Generic Macros for Warriors

#### Mouseover Interrupt Macro

```wow-macro
#showtooltip Pummel
/cast [@mouseover,harm,nodead] Pummel; Pummel
```

This macro allows you to cast [[spell:6552]] on your mouseover
target or on your current target if your mouseover target is not valid.

#### Stance Toggle Macro

```wow-macro
#showtooltip
/cast [stance:2]!Defensive Stance;!Battle Stance
```

This macro lets you swap between [[spell:386208]]
and [[spell:386164]] without having to have two separate
keybinds for them.

1.2.

#### Specific Macros for Protection Warriors

#### Shield Slam and Ignore Pain Macro

```wow-macro
#showtooltip
/cast Ignore Pain
/cast Shield Slam
```

Use this instead of your regular [[spell:190456]] button, to reduce the
chances of you missing a [[spell:23922]] reset.

#### Mouseover Heroic Throw Macro

```wow-macro
#showtooltip Heroic Throw
/cast [@mouseover,harm,nodead] Heroic Throw; Heroic Throw
```

This macro allows you to use [[spell:57755]] on your mouseover
target or on your current target if the mouseover target is not valid.

#### Mouseover Taunt Macro

```wow-macro
#showtooltip Taunt
/cast [@mouseover,harm,nodead] Taunt; Taunt
```

This macro allows you to [[spell:355]] your mouseover target or
your current target if the mouseover target is not valid.

#### Intervene/Charge Macros

```wow-macro
#showtooltip Charge
/cast [target=mouseover,help,exists,nodead]Intervene;Intervene
/cast [target=target,harm,exists,nodead]Charge;Charge
```

This macro allows you to [[spell:3411]] your mouseover target ally, or
[[spell:100]] your current target if it is a enemy.

2.

### Best Addons

Having a functional and readable interface is an extremely important aspect
of the game that many overlook. What defines a good interface is subjective, but
at the very least, it should present any and all important information in a clear
and direct way. What that important information is varies depending on your role
and the kind of content you are doing, but over time, you will figure out what
information you need and do not need to display.

Note that this section only goes over what is recommended for PvE content,
such as dungeons and raids. "Quality of Life" add-ons, such as bag add-ons,
quest add-ons, etc, are not discussed here.

Most solid interfaces have the following:

- Centered action bars for tracking important procs or all of your action bars, moving rotational
  information close to the center of your screen can be extremely beneficial.
- Centered unit frames. That is, the player frame and target frame.
- A boss mod, such as Deadly Boss Mods or BigWigs.
- While this pertains to some roles more than others, tracking the
  availability of things like other players' interrupts, external cooldowns,
  etc.

Again, a good interface is subjective. If you are the kind of player who only
does open-world content, then a more minimal interface may be better for you.
Spending the time to create an interface that works for <em>you</em> is more
than worth it. The above are simply suggestions.

That being said, if you are not sure where to start, centering important
information around your character and making sure that your various
add-ons and interface elements do not overlap is a good guideline to follow.

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and maybe you will even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.1.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.2.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.2.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.2.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.2.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.3.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.3.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated and reviewed for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Reviewed and updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5, removed Threat addon suggestions.
- **28 Apr. 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
