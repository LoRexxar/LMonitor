## 专精概览

欢迎来到我们的魔兽世界 12.1.5 补丁 恢复 萨满祭司 指南。在这里，你将学习如何在团队副本和大秘境中担任 恢复 萨满祭司 进行治疗。我们涵盖了从基础到最大化输出的极限优化技巧的所有内容。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

恢复大秘境资源

[全新！顶级恢复天赋构筑](<https://raider.io/specs/restoration-shaman/talents>)

[顶级恢复大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/shaman/restoration>)

[恢复大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=shaman--restoration>)

[热门恢复队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=shaman--restoration>)

1.

### 恢复 萨满祭司 概述

[恢复 萨满祭司](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-guide>) 是一个极其灵活的专精，在治疗站位集中的团队时表现出色。他们还拥有各种独特的工具来应对原本致命的伤害涌入，例如 [[spell:98008]]，以及许多实用功能选项，例如 [[spell:57994]] 中唯一的治疗者打断，或 [[spell:192063]] 提供的爆发性移动能力。

为了正确地担任治疗角色，你需要的不仅仅是职业专属信息。为了更好地了解治疗的总体情况，我们建议你阅读我们的 [治疗指南](<https://www.icy-veins.com/wow/healing-guide>).

站位集中随机数治疗专家

恢复 萨满祭司 拥有强大的治疗冷却技能，包括独特的

[[spell:98008]]

它可以在附近的玩家之间重新分配生命值。

[[spell:73920]]

在第2赛季中扮演着治疗的核心角色，这得益于增益效果和新的套装奖励，该奖励会在你的治疗目标身上随机生成一次雨，这使得良好的随机数和团队站位集中对于高治疗吞吐量非常重要。

[[spell:378270]]

和

[[spell:1267016]]

触发也是治疗中重要的随机因素，使得 恢复 能够根据运气做出最好或最弱的治疗。

多面手治疗者

恢复 萨满祭司 是团本的不错选择，凭借其多才多艺的英雄天赋，可以轻松在单体治疗和团队治疗之间切换。他们还拥有强大的独特工具，例如

[[spell:98008]]

以及个人战斗复活技能

[[spell:20608]]

这两者在应对困难的团队机制或团队副本开荒期间都特别有用。他们还带来最好的团队增益之一，

[[spell:462854]]

，确保你在任何团队中都至少想要一名 萨满祭司。

近战小队副本之星

恢复 萨满在大秘境中表现非常出色，因为他们是唯一拥有打断技能的治疗者，

[[spell:57994]]

并且拥有大量的控制技能，有助于减轻副本中危险部分的压力。当不需要承受大量治疗压力来应对

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知

先祖和

[[spell:378443]]

。他们的主要弱点是，他们对持续性范围伤害的治疗输出潜力只是平均水平，并且严重依赖于所有人站位集中在

[[spell:73920]]

内，但这个弱点可以通过加入近战为主的团队轻易克服，这些团队往往也最看重

[[spell:462854]]

时，他们也能打出不错的伤害！

应对一切的法术

治疗萨满拥有也许是所有治疗者中最强大的功能性技能组合，拥有他们强大的团队增益

[[spell:462854]]

和独特的冷却技能

[[spell:98008]]

，但他们也可以用

[[spell:20608]]

并移除其团队中大部分类型的减益效果，使用

[[spell:383016]]

,

[[spell:383013]]

，以及

[[spell:8143]]

移除队友身上的大部分负面效果，或用

[[spell:370]]

。这使他们能够独自为几乎所有功能性问题提供解决方案。

出色的生存被动技能

萨满的第一道防线是由

[[spell:381689]]

和

[[spell:207401]]

提供的额外生命值，因为他们的主动防御技能并不特别强大，而且往往冷却时间很长。

[[spell:108271]]

和

[[spell:198103]]

使用

[[spell:1279819]]

无论怎样都是很好的防御选择。

[[spell:20608]]

虽然强大，但也与一个非常长的冷却时间绑定，且不会在开怪时重置。最后，

[[spell:355630]]

很少成为关键因素，但每当你能从中获得完整收益时，它会极其强大。

多样的机动性工具

恢复萨满祭司拥有不错的机动性，但过度依赖

[[spell:79206]]

来在高移动性战斗中执行以施法为主的团队治疗循环，而这反过来又依赖于队伍中有唤魔师使用

[[spell:374968]]

来重置其冷却时间。对于其他移动需求，你需要保留

[[spell:61295]]

或

[[spell:73685]]

以便在移动中使用。如果在移动中施法不可行，那么

[[spell:192063]]

,

[[spell:58875]]

，以及

[[spell:2645]]

是快速到达你需要去的地方的可行方式，其中狂风图腾在打破击退效果方面尤为突出，而灵魂行者之赐则可以解除减速和定身效果。最后，

[[spell:192077]]

可以让整个队伍移动得更快，你还可以将其升级为更短的冷却时间或带有解除减速效果的版本！

1.

### 恢复 萨满祭司在至暗之夜中的改动

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

补丁12.1.5中恢复 萨满祭司没有任何改动，但它引入了一个新的团队副本首领基斯希克斯，以及一种全新且令人兴奋的 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)：Kindo'jan迷宫！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

补丁12.1.5中恢复 萨满祭司没有任何改动，但你可以在我们的页面上找到更新后的推荐 [装备](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)
页面上找到关于新团队副本新装备掉落以及如何花费你的[[item:280562]]的更新建议。

2.3.

#### 职业改动

遗憾的是，恢复 萨满祭司在补丁12.1.5中没有收到任何改动。不过，我们已经更新了我们的 [装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>) 关于 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 装备的新信息，以及关于如何花费你的第一个[[item:280562]]的建议。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritlink.jpg>)点击查看上赛季第二赛季的改动
2.4.

#### 12.1版本改动

一个全新的大型补丁意味着有海量新内容可供探索！除了新的PvE和PvP终局内容外，还有一个新区域可供发现，其中包含新的稀有怪和宝藏可供猎取，并且还添加了多种新的房屋和幻化物品。暴风雪还对现有系统进行了大量更新，并添加了更多生活质量改进，例如在默认冷却管理器中更好地追踪物品冷却时间和治疗者增益效果的选项。

2.5.

#### 第2赛季职业改动

恢复 萨满祭司的核心设计在第2赛季中保持不变，但[[spell:73920]]和[[spell:61295]]获得了大幅增强，加上新的[[spell:1312843]]天赋和新的套装，这将改变天赋构建和循环优先级。总体而言，恢复在它本已强势的大秘境中看起来会成为更强的治疗者，如果首领机制适合它的优势，它很可能是RWF团队副本竞速赛中的黑马之一！

因此，请务必查看新的 [天赋](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)
推荐，调整后的 [输出循环](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)
优先级以及新的 [装备](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>) 推荐！

你将在下面找到补丁12.1的职业和专精改动完整列表。

[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**恢复 萨满祭司**

<em>开发者笔记：我们正在调整若干天赋，并对恢复 萨满祭司进行一些平衡调整，以改进几个表现不佳的天赋或回报感不足的互动效果。我们还在增强先知先知的治疗链能力，以提升他们的治疗能力。</em>

- **职业**
  
  
  
  
  - [[spell:462477]]治疗量提高25%
  - [[spell:114052]]现在为所有三个专精更换了新图标。
- **英雄天赋**
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖的[[spell:188443]]现在最多命中5个目标（原为3个）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖的[[spell:51505]]现在还会使伤害提高一个等同于你暴击几率的百分比。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖的[[spell:1064]]现在最多弹跳到5个目标（原为3个），每次弹跳降低10%治疗量（原为30%），弹跳距离提高到20码（原为15码）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖的[[spell:1064]]治疗量提高50%。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司：[[spell:445032]]现在使[[spell:444995]]的治疗量提高10%（原为25%）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司：[[spell:444995]]现在使[[spell:73920]]的效果提高10%（原为20%）。
- **恢复**
  
  
  
  
  - 新天赋：[[spell:1312843]] – [[spell:5394]]和[[spell:1267016]]在施放时会使你当前激活的[[spell:61295]]的持续时间延长3秒。
  - [[spell:77472]]治疗量提高10%。
  - [[spell:73685]]治疗量提高100%。
  - [[spell:73920]]治疗量提高20%，现在最多治疗其区域内6个目标（原为5个）。
  - [[spell:73920]]现在拥有12秒冷却时间和18秒持续时间。在一个治疗之雨已经激活时再次施放将使前一个消失。此冷却时间改动不影响图腾祭司英雄天赋的[[spell:444995]]的治疗之雨。
  - [[spell:61295]]直接治疗量提高25%，周期性治疗量提高100%。
  - [[spell:378443]]伤害提高50%，但现在每2秒造成一次伤害（原为每1秒）。
  - 至暗之夜第1赛季2件套效果已更新：[[spell:73685]]的直接治疗量提高50%（原为100%）。
  - [[spell:1271104]]现在为生命释放的治疗增益提供加算的+20%，而不是乘算提升。
  - [[spell:404015]]现在还会使[[spell:1064]]的法力值消耗降低15%。
  - [[spell:381946]]在天赋树中的位置已上移。
  - [[spell:1252841]]已被移除。

:::

### 至暗之夜改动概述

2.6.

#### 恢复 萨满祭司在至暗之夜中的改动

至暗之夜改动的总体目标是降低治疗者的爆发治疗能力和循环复杂度，这对于恢复萨满祭司来说尤其如此，他们本已是上手最简单的专精之一，而在至暗之夜中，他们几乎一半的可用主动技能按钮都被移除，几乎所有法术的临时增益效果也被移除，这使他们现在或许是游戏中最简单的治疗者。

- 以下是最重要的 **专精天赋树的核心改动**.
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:157153]]、[[spell:198838]]、[[spell:207399]]和[[spell:197995]]已被移除。 **这些都是高影响力的技能，通常需要良好的时机和技巧才能优化使用。**
  - [[spell:157154]]、[[spell:236501]]、[[spell:200071]]、[[spell:404522]]、[[spell:462375]]、[[spell:1217525]]和[[spell:404019]]也被移除。 **其中一些增益效果曾是恢复的核心，它们的效果现在将被融入它们所影响的法术中。[[spell:1064]]在至暗之夜中拥有25%的额外弹跳范围和20%更快的施法时间，而[[spell:77472]]的基础施法速度也快了20%。**
  - [[spell:73685]]经过重新设计，拥有更长的冷却时间和更高的治疗量作为补偿，还有一个新的施法时间缩减效果和一个能进一步提升其治疗量的支持天赋。
  - [[spell:8004]]被[[spell:77472]]取代，现在可以受益于之前与它配合的效果，例如[[spell:337974]]。新天赋[[spell:1253090]]还使其暴击率提高12%。
  - [[spell:114052]]现在与[[spell:108280]]同处一个抉择节点，之前与升腾配合的天赋现在也对治疗之潮图腾生效，例如[[spell:462440]]和[[spell:462443]]。
  - [[spell:114052]]本身经过重新设计：激活期间[[spell:77472]]必定暴击并以50%的效果命中第二个盟友，[[spell:1064]]额外命中3个目标且每次弹跳只降低10%的治疗量。
  - 该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司英雄天赋[[spell:445035]]已更名为[[spell:445035]]，在原有使[[spell:5394]]治疗量翻倍的效果基础上，还会使[[spell:108280]]的治疗量提高25%。 **结合上面列出的升腾改动，其设计意图是让 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司偏向使用治疗之潮图腾，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知则偏向[[spell:114052]]。**
  - [[spell:73920]]现在持续18秒，但同时拥有18秒的基础冷却时间。这将使非![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司构建也更愿意施放它，但没有[[spell:108287]]来移动它， **18秒往往会导致在玩家在其持续时间和冷却时间结束前离开时损失治疗量。**
  - [[spell:207778]]不再为命中的盟友提供10%的生命值提升，但它现在可以被[[spell:1253014]]和[[spell:1252882]]天赋强化，这些天赋显著增强了它的治疗潜力。
- 该 **萨满祭司职业树也有多项重要改动**.
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:1217622]]和[[spell:462477]]现在在职业树中是一个抉择节点，而不是恢复专精节点。
  - [[spell:51490]]现在只有元素可以学习，恢复不再可用，降低了他们的控制能力。
  - [[spell:108270]]和[[spell:108285]]已被移除，并被被动技能[[spell:1270375]]和[[spell:1270350]]取代。
    **这移除了冷却时间长但效果相对较弱的主动技能。**
  - [[spell:382215]]被改为在[[spell:2645]]形态下提供额外移动速度的基础上，提供一个固定移动速度加成。
  - [[spell:265046]]、[[spell:381689]]和[[spell:382215]]现在是2点天赋，而不是单点提供相同效果。
  - [[spell:57994]]现在拥有30秒冷却时间而非12秒，但恢复 萨满祭司也是至暗之夜中唯一仍拥有打断技能的治疗者，并且其法术封锁持续4秒而非2秒。
  - [[spell:355630]]被转化为[[spell:355630]]，现在当[[spell:57994]]打断敌人时使受到的所有法术伤害降低15%，而不再与被打断法术的学派绑定，但不再叠加且持续时间减少6秒。

他们大部分独特功能仍然保留，尤其是依赖职业树的部分，这应该使恢复萨满祭司保持为5人小队的最佳治疗者之一，尽管失去了[[spell:51490]]。

2.7.

#### 英雄天赋改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知获得了额外天赋：[[spell:1270446]]、[[spell:1270447]]和[[spell:1270450]]。[[spell:443451]]在至暗之夜中也使[[spell:61295]]的冷却时间缩短2秒而非3秒。这些新天赋很强大，使先知成为出色的单体治疗者。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司也获得了额外天赋：[[spell:1260644]]、[[spell:1263288]]和[[spell:1260874]]。这些进一步支持[[spell:5394]]和[[spell:108280]]的治疗，这是该天赋树的一个主要主题。

2.8.

#### 顶峰天赋：风暴之流图腾

恢复萨满祭司的顶峰天赋是[[spell:1267016]]、两点天赋[[spell:1267093]]以及最终天赋[[spell:1267120]]。作为一个整体，这些顶峰天赋使[[spell:61295]]有小几率触发一个非常强大的[[spell:5394]]版本，在你完全解锁该天赋后可以不消耗常规治疗之泉图腾充能而施放。[[spell:378081]]（或[[spell:443454]]）在使用时也会触发。

触发效果最多可保持激活60秒并可叠加两次，让你有充足的时间等待最佳使用时机，尽管你通常应该在常规[[spell:5394]]的两个充能都就绪之前使用，以避免浪费潜在的使用次数。

2.9.

#### 循环要点

随着许多治疗技能被精简，你大部分时间将循环施放[[spell:73685]]、[[spell:61295]]、[[spell:5394]]和[[spell:73920]]，并在其余时间使用[[spell:77472]]进行单体治疗或[[spell:1064]]进行群体治疗。

2.10.

#### 冷却调整

[[spell:98008]]以及[[spell:108280]]或[[spell:114052]]之一仍将用于应对高伤害阶段，但你将不再能同时使用两者，因为它们现在彼此处于一个抉择节点。

[[spell:462440]]和[[spell:462443]]过去支持升腾，现在也对治疗之潮图腾生效，但[[spell:378270]]仍然只与升腾绑定，这使它在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司中因新的[[spell:445035]]和[[spell:1260874]]天赋提升[[spell:108280]]的表现而略显逊色。

1.

### 恢复 萨满祭司游戏基础

恢复 萨满祭司和任何治疗者一样，关键在于战略性地使用你的技能。你不会使用固定的循环，而是利用你灵活的法术组合来适应并克服游戏中出现的各种情况。

像[[spell:61295]]、[[spell:73685]]和[[spell:73920]]这样的冷却技能非常高效，因此在一整场战斗中尽可能多地使用它们非常重要。同时，像[[spell:77472]]和[[spell:1064]]这样的技能可以在任何需要的时候插入使用，只要你还有法力值。恢复可以进一步归纳为以下三条主要原则。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_unleashweapon_life.jpg>) **保持循环技能的冷却时间运转**
  
  
  
  
  作为恢复 萨满祭司，你的大部分治疗来自像[[spell:73920]]、[[spell:5394]]和[[spell:61295]]这样的短冷却技能。这些技能应该尽可能保持冷却时间运转，尽管其中许多也拥有充能系统，你可以让它们保持冷却同时保留大部分充能以备大量伤害到来时使用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritlink.jpg>) **规划主要冷却技能**
  
  
  
  
  [[spell:98008]]、[[spell:108280]]和[[spell:114052]]是你的主要冷却技能，可以让你在承受大量伤害时拯救团队。由于大多数首领战和地下城都有造成大量伤害的特定技能，通常最好保留这些冷却技能来应对它们，并与队伍中的其他治疗者协调使用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_watershield.jpg>) **法力值管理**
  
  
  
  
  由于[[spell:1064]]消耗高且没有冷却时间，当你专注于群体治疗时，你的法力值池会消耗得相当快，尤其是在长时间的战斗中。因此，你需要确保控制节奏，在低伤害期间穿插大量[[spell:77472]]和DPS技能，以使你的法力值能够支撑整场战斗。

1.

### 如何为 恢复 萨满祭司 获取装备

虽然我们始终建议您自行模拟以获得理想结果，但我们确实提供了一个专门的 恢复 配装页面。我们目前涵盖了第二赛季装备的推荐，以便在 至暗之夜 终局内容发布时有一个良好的开端。一旦您获得了一些装备，您就需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026 年 9 月 2 日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 更改了装备和代币兑换建议，以适应属性变更。
- **2026年9月1日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 更新了每个第二赛季地下城的推荐功能性天赋速查表。
- **2026年8月26日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 根据最新的装备属性变更进行了更新。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 针对 至暗之夜 第二赛季上线进行了审查。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年8月10日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 针对 至暗之夜 第二赛季上线进行了审查。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年8月10日（本页）：** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026 年 6 月 30 日（本页）：** 添加了关于最新 4% 治疗增益热修的信息。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 随着 12.0.7 补丁的发布，将孢子融合装备添加到了毕业列表中。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 由于我们的法力经济大幅改善，上调了急速的价值评估。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 随着 12.0.7 补丁的发布，添加了万用大全章节。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月19日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 更新了虚空核心建议、新的毕业表格格式和饰品建议。
- **2026年5月19日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 添加了药水建议章节。
- **2026年5月19日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 将大秘境天赋建议更新为 图腾祭司。
- **2026年5月19日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 将大秘境天赋建议更新为 图腾祭司 并更新了说明文字。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月1日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 在许多饰品获得大幅增强后，调整了饰品建议。
- **2026年3月30日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 更新了枪靴取消宏。
- **2026年3月30日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 更新了常规装备、装饰和饰品建议。
- **2026年3月30日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 添加了更多关于收益递减和属性优先级的信息。
- **2026年3月30日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 更新了功能性速查表。
- **2026年3月30日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 根据新的天赋建议调整了输出循环。
- **2026年3月30日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 更新为当前主流天赋。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 热修后的饰品梯队调整。
- **2026年3月17日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 更新了针对较长战斗的最新模拟信息。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月16日（本页面）：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 添加了一个用于80级升级的快速导入字符串。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（本页）：** 已为至暗之夜的发布进行更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 12.0.1 补丁更新和建议调整。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 12.0.1 补丁更新和天赋建议调整。
- **2026年2月10日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 12.0.1 补丁更新和输出循环建议调整。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 12.0.1 补丁更新和建议调整。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 添加了怒涛之浪，移除了低语之浪。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 12.0.1 补丁更新和天赋建议调整。
- **2026年2月10日（本页面）：** 添加了 12.0.1 补丁章节。
- **2026年1月27日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 根据补丁前团本的最佳实践，更新了 先知 团本输出循环。
- **2026年1月27日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 根据补丁前团本的最佳实践，更新了 先知 团本天赋构建。
- **2026年1月24日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 修正了 图腾祭司 团本天赋中的笔误。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（本页）：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 为11.2.7补丁更新。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 为11.2.7补丁更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 为11.2.7补丁更新。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 为11.2.7补丁更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 已针对11.2.7版本更新，将优势与劣势改版为表现评估。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 在削弱后更新了迪斯科腰带，并添加了谜之卡特尔芯片章节。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 针对 11.2.5 补丁进行了更新，添加了关于军团再临重制版和涡轮加速的新章节。
- **2025年9月7日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 在上线已过去足够时间后，针对第三赛季进行了更新，假设拥有套装效果。
- **2025年8月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 添加了拥有和没有新套装加成时的推荐标签。
- **2025 年 8 月 10 日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 对低语之浪的属性优先级进行了小幅调整。
- **2025 年 8 月 10 日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 添加了更多关于使用低语之浪时目标选择的信息。
- **2025 年 8 月 10 日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 现在为团本推荐低语之浪天赋。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 更新了第三赛季装备和新建议。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 针对第三赛季进行了更新，添加了新的治疗药水和强化符文。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 针对第三赛季进行了更新，并为新的低语之浪天赋构建调整了属性。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 重做了属性优先级，并针对第三赛季进行了审查。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 更新为第三赛季的新格式，包括新套装对输出循环的影响分析。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 针对第三赛季进行了更新，假设没有套装效果。
- **2025年8月4日（本页面）：** 针对第三赛季进行了更新，包含变更和新的雷希披风。
- **2025年6月16日（本页）：** 添加了关于新战斗助手功能的信息。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 添加了关于新“DISC”腰带的新部分。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 添加了关于新战斗助手功能的信息。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 添加了关于新战斗助手功能的信息。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 添加了关于新战斗助手功能的信息。
- **2025年6月15日（本页）：** 已用11.1.7版本信息更新。
- **2025年5月28日（本页）：** 更新了 先知 增强热修和第一印象。
- **2025年5月13日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 根据顶尖冲层玩家，重做了 先知 大秘境天赋。
- **2025年4月29日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 添加了更多关于即将到来的卡特尔芯片装备获取的信息。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 更新了 11.5 补丁的变更。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 添加了腐蚀附魔信息。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 针对 11.5 补丁进行了更新。
- **2025年3月23日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 更新了装备列表和瑟尔西头冠的宝石建议。
- **2025年3月23日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 新的功能性速查表图片，包含根须图腾和更清晰的标示。
- **2025年3月23日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 针对当前第二赛季环境更新了天赋。
- **2025年3月18日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** 清理了加里维克斯章节。
- **2025年3月3日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** 小规模清理。
- **2025年3月3日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 小规模清理。
- **2025年3月2日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** 新增了所有首领的提示。
- **2025年3月2日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 添加了所有地下城的功能性速查表图片和提示。
- **2025年3月2日（本页）：** 移除了旧的变更记录。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 更新了 11.1 补丁的变更。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 更新了 11.1 补丁的新装备。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 更新了 11.1 补丁的变更。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 更新了 11.1 补丁的变更。
- **2025年2月24日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** 初步整理了安德迈首领建议。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 更新了 11.1 补丁的变更。
- **2025年2月24日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 更新了 11.1 补丁的变更。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 更新了 11.1 补丁的变更。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 更新了 11.1 补丁的变更。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 更新了 11.1 补丁的变更。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 更新了 11.1 补丁的变更。
- **2025年2月24日（本页面）：** 更新了 11.1 补丁的变更。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 更新了关于瑟尔西头冠宝石优化的首次计算结果。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 更新了 11.0.7 补丁关于瑟尔西头冠的信息。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 审查了属性优先级并更新了解释。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** 更新了奥维娜克斯构建，并为安苏雷克添加了一个新构建。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 添加了推荐构建，并对天赋建议进行了小幅调整以简化操作。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 更新了更易遵循的输出循环和天赋建议。
- **2024年12月15日（本页）：** 更新了 11.0.7 补丁信息。
- **2024年10月24日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** 对奥维娜克斯推荐天赋进行了轻微调整。
- **2024年10月24日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 调整了推荐的大秘境天赋构建。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 针对 11.0.5 补丁和新的天赋树进行了更新。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** 针对 11.0.5 补丁进行了更新，添加了奥维娜克斯的新建议天赋和时机。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 针对 11.0.5 补丁进行了更新，添加了每个地下城天赋调整的新章节。
- **2024年10月21日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 针对 11.0.5 补丁进行了更新，为 先知 激流 构建添加了新的输出循环提示和新天赋。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 针对 11.0.5 补丁和新的天赋树进行了更新。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 针对 11.0.5 补丁和净化毒药图腾的削弱进行了更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 针对 11.0.5 补丁和新天赋进行了更新。
- **2024年10月21日（本页）：** 更新了 11.0.5 补丁的变更和第一印象。
- **2024年10月6日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** 为大多数首领添加了提示。
- **2024年10月6日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 调整了团本天赋，并修正了天赋详情部分的笔误。
- **2024年9月15日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 添加了关于武器油的说明。
- **2024年9月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 添加了 先知 治疗链 团本构建，并重做了地下堡构建。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 移除了赛季前装备列表，并添加了关于早期制作双手武器以节省纹章的说明。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 添加了应对新大秘境词缀的提示。
- **2024年9月9日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月29日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 添加了先祖追踪弱光环。
- **2024年8月27日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 根据近期调整更新了装饰和制造装备建议。
- **2024年8月25日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 根据首次全面模拟更新了更多饰品排名。
- **2024年8月25日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 根据首次全面模拟更新了更多饰品排名。
- **2024年8月25日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 根据首次全面模拟更新了更多饰品排名。
- **2024年8月25日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 根据首次全面模拟更新了更多饰品排名。
- **2024年8月24日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 新增了地下堡推荐构建。
- **2024年8月23日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已更新S1地下城、团队副本和饰品毕业装备表格。
- **2024年8月23日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 为《地心之战》添加了更多WeakAuras。
- **2024年8月23日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已更新递减收益属性表格和团队副本与大秘境的属性优先级。
- **2024年8月23日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已添加第1赛季大秘境功能表。
- **2024年8月23日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 添加了更多S1饰品。
- **2024年8月23日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 添加了更多易用的饰品。
- **2024年8月22日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已为《地心之战》上线进行更新。
- **2024年8月21日（本页）：** 已为《地心之战》上线进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/restoration-shaman-mists-of-pandaria-remix-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已为《地心之战》前夕补丁和新套装奖励进行更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年7月22日（[地心之战](<https://www.icy-veins.com/wow/restoration-shaman-the-war-within-pve-guide>)):** 大规模更新以反映当前测试服状态。
- **2024年7月22日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年6月18日（[地心之战](<https://www.icy-veins.com/wow/restoration-shaman-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月17日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/restoration-shaman-mists-of-pandaria-remix-guide>)):** 根据正式上线的数值调整更新了推荐宝石。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/restoration-shaman-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月11日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 更新了推荐天赋。
- **2024年5月11日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 更新了推荐天赋。
- **2024年5月11日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 更新了推荐天赋。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已更新大秘境功能图表。
- **2024年4月26日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 根据最新数据进一步更新。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已根据第4赛季更新了新装备、饰品和装饰。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 为第4赛季进行了更新。
- **2024年4月22日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 为第4赛季进行了更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 为第4赛季进行了更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 为第4赛季进行了更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 为第4赛季进行了更新。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月25日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月18日（本页）：** 针对10.2.6补丁进行了审查。
- **2024年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 修正了风剪说明中的笔误。
- **2024年1月20日（本页）：** 添加了即将到来的1月23日热修增强内容。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023 年 11 月 27 日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 添加了永恒黎明中每件掉落物品所在的翼区信息。
- **2023年11月24日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 更新并添加了每个副本功能用途的大图点击版本。
- **2023年11月15日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 添加了关于如何为每个副本配置功能天赋的图片。
- **2023年11月9日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 多处笔误修正。
- **2023年11月9日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 笔误修正。
- **2023年11月9日（本页）：** 多处笔误修正。
- **2023年11月8日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 在波动孢子斗篷削弱后更新了装饰推荐。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已根据10.2版本更新了新装备、饰品和装饰。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 为10.2版本进行了审查。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 添加了关于10.2版本中新套装下急速何时有用的信息。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 为10.2补丁添加了新的天赋构建和新的赛季信息。
- **2023年11月6日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已更新10.2补丁的新饰品。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2版本进行更新
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已更新10.2补丁的新天赋构建，并在天赋描述中加入了升腾的削弱说明。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 10.2补丁削弱后对升腾描述的小幅调整。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已更新10.2补丁的新天赋和饰品。
- **2023年11月6日（本页）：** 添加了10.2补丁的改动和评论，以及整体修订。
- **2023年10月6日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2补丁和新的套装加成进行更新。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已针对10.1.7版本环境进行更新，并为毕业装备模块添加了标签页。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已更新为基于标签页的格式。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 已为10.1.7版本审核。
- **2023年7月31日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已根据当前第2赛季地下城环境调整天赋。
- **2023年7月31日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 重做了指南中展示多套天赋树的方式。
- **2023年7月31日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已根据最近的在线修正更新升腾半径翻倍的信息。
- **2023年7月31日（本页）：** 已根据最近的在线修正更新5%治疗量加成和升腾增益的信息。
- **2023年7月19日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 针对回响泰尔斯通削弱的调整。
- **2023年7月11日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 进一步调整饰品列表。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 将10.1.5补丁的饰品添加到列表中，并回顾了新地下城中可获得的装备。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 解释了熔玉印章的削弱及其作为一枚不错但并非顶级戒指的新定位。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年6月13日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 澄清了升腾和引导不应同时使用。
- **2023年6月13日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 将推荐的团本天赋改为使用根深蒂固的元素，并进行了多处文本更新。
- **2023年6月13日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 澄清了升腾和引导不应同时使用。
- **2023年6月13日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 澄清了升腾和引导不应同时使用。
- **2023年6月6日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 添加了雷鸣之爪作为应对缠绕的手段。
- **2023年5月10日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 添加了新的腰带附魔：暗影之扣。
- **2023年5月9日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对5月9日的堕落之怒错误修复进行调整。
- **2023年5月5日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 在孢子恩赐附魔削弱72%以及堕落之怒处于BUG状态后，调整了推荐。
- **2023年5月5日（本页）：** 小幅修改文本，以反映孢子恩赐附魔削弱72%。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 第二赛季升级系统总结，更新了美化推荐，并添加了一些饰品。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 添加了孢子恩赐附魔、堕落之怒药剂和阴险的魔鬼蛋。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 针对巨龙时代第二赛季（10.1.0版本）更新了新天赋、词缀和提示。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 添加了关于新套装以及它如何改变输出循环的信息。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 第二赛季天赋更新以及新套装的游戏玩法变化。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 更新了大地之握的新持续时间、爆裂词缀的移除以及10.1.0版本的其他更改。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 更改了巨龙时代第二赛季的推荐天赋和饰品。
- **2023年5月1日（本页）：** 更新了关于10.1.0版本中细微更改的评论。
- **2023年4月30日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 为10.1补丁进行了复查。
- **2023年4月30日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 添加了巨龙时代第二赛季饰品。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 进一步更新了玛瑙指环。
- **2023年3月23日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 在玛瑙指环获得多次宝石增益使其值得使用后进行了更新。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 在玛瑙指环获得多次宝石增益使其值得使用后进行了更新。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 更新了10.0.7版本的天赋和输出循环。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/restoration-shaman-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 添加了关于新玛瑙指环戒指的信息。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 添加了两个额外的WA字符串以支持10.0.7的新游戏风格。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 为10.0.7版本更新了玛瑙指环。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 为10.0.7版本更新了天赋。
- **2023年3月20日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 更新了10.0.7版本的饰品。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 更新了10.0.7版本的输出循环，并在插件指南页面添加了WA链接。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 为10.0.7版本更新了天赋。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 更新了10.0.7版本的新法术和天赋。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 更新了10.0.7版本的天赋和输出循环。
- **2023年3月20日（本页）：** 更新了10.0.7补丁中关于萨满祭司天赋树重做的看法。
- **2023年3月10日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 现在云涌图腾是默认推荐。
- **2023年3月10日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 提高了酸雨的使用优先级。
- **2023年3月10日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 添加了技能连招信息图。
- **2023年3月10日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 在10.0.7补丁前进行了进一步更新。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 已根据10.0.5版本的增强进行了更新。
- **2022年12月21日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 重做了饰品推荐和团队副本毕业装备建议。
- **2022年12月13日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 添加了美化推荐和原始仪式外壳。
- **2022年12月13日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 更改了天赋构筑以包含酸雨。
- **2022年12月13日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 添加了原始仪式外壳。
- **2022年12月13日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 为大秘境和团队副本进一步调整了天赋。
- **2022年12月13日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 添加了原始仪式外壳。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月30日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 添加了来自裁缝法术线程的腿部附魔。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[传说物品](<https://www.icy-veins.com/wow/restoration-shaman-best-legendaries-shadowlands>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/restoration-shaman-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/restoration-shaman-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/restoration-shaman-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年8月2日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 重做了第4赛季的饰品。
- **2022年5月31日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对 9.2.5 补丁审核本页面。
- **2022年3月23日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 重做了当前版本环境下输出的属性优先级。
- **2022年3月7日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 添加了更多输出饰品。
- **2022年3月2日（[9.2版本分析](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-2-changes-analysis>)):** 添加了关于维佩尔传说削弱热修的信息。
- **2022年2月22日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 为输出目的添加了更多传说和饰品信息。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-2-changes-analysis>)):** 本页已审核并批准用于9.2补丁。
- **2022年2月21日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 本页已审核并批准用于9.2补丁。
- **2022年1月25日（[9.2版本分析](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-2-changes-analysis>)):** 已根据最新的测试服改动进行更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** 已根据9.1.5补丁的发布更新了页面。
- **2021年8月27日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 重做了饰品列表。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** 为史诗团本和盟约橙装发布周更新。
- **2021年6月29日（[9.1 补丁分析](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** 为9.1版本发布更新了页面。
- **2021年6月29日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 增加了盟约专属橙装的相关考量。
- **2021年6月13日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 大幅调整了橙装优先级。
- **2021年5月12日（[9.1 补丁分析](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** 添加了新橙装和PvP天赋信息。
- **2021年4月28日（[9.1 补丁分析](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** 页面创建，包含初步测试信息。
- **2021年3月9日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 微调了输出循环，以应对9.0.5版本中熔岩爆裂的削弱和闪电链的增强。
- **2020年12月22日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 添加了关于暗影国度输出饰品的说明及示例。
- **2020年12月5日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 添加了有助于输出循环的WeakAuras字符串。
- **2020年11月24日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 页面已针对暗影国度上线进行更新。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年10月12日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 已针对暗影国度前夕版本进行更新。
- **2020年1月21日（[DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** 添加了萨满祭司 恢复的输出指南。
- **2020年1月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-the-eternal-palace-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2019年8月14日 ([永恒宫殿页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-the-eternal-palace-raid-guide>)):** 加入了最终史诗首领的提示。
- **2019年7月20日（[永恒宫殿页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-the-eternal-palace-raid-guide>)):** 在击杀前四个首领后，加入了史诗首领提示。
- **2019年7月7日（[永恒宫殿页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月11日（[风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** 移除了关于PTR测试的提及，因为该攻略现已针对正式服100%完成。
- **2019年5月6日 ([风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** 加入了击杀视频后的史诗恩佐斯的子嗣推荐。
- **2019年4月27日 ([风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** 在正式服击杀后，加入了史诗忏悔者议会推荐。
- **2019年4月20日 ([风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** 加入了一条推荐：如果回响的施法即将完成，可使用战栗图腾。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年4月9日 ([达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 加入了关于战栗图腾可暂时驱散拉斯塔哈首领处心灵控制图腾的提及。
- **2019年3月16日 ([达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 更改了吉安娜史诗难度的推荐天赋，并在文本中加入了说明。
- **2019年3月14日 ([达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 移除了关于喷涌之魂与升腾组合的提及，因为该组合在8.1.5补丁中已不再有效。
- **2019年3月2日 ([达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 加入了新的吉安娜史诗难度提示。
- **2019年2月7日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 修正了一些错别字，并更新了风暴之墙封锁战和吉安娜史诗难度战斗的提示。
- **2019年2月5日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 调整了一些推荐，并根据正式服经验加入了额外内容。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** 在达萨罗之战中加入了恢复萨满祭司的逐首领攻略。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年10月10日 ([奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 修正了一些小错别字和天赋问题，并为史诗格罗恩加入了额外提示。
- **2018年10月8日 ([奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 根据我们完整的史诗难度开荒经验，更新了天赋和首领信息。
- **2018年9月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 添加了颤栗图腾首领信息和其他提示。
- **2018年9月2日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 添加了天赋速查表。
- **2018年8月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 更新了一些天赋推荐。
- **2018年8月7日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 更新了MOTHER、祖尔和Mythrax的推荐。
- **2018年8月5日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 为恢复萨满添加了初步的奥杜尔指南。
- **2018年7月28日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** 为准备争霸艾泽拉斯移除了军团再临内容。

显示更多

显示更少

:::

## 练级

在本页，你将找到我们的恢复萨满祭司逐级升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[萨满祭司练级指南](<https://www.icy-veins.com/wow/shaman-leveling-guide>).

1.

### 恢复萨满祭司在至暗之夜的练级指南

作为一名治疗者，恢复萨满祭司在单人练级时比输出或坦克专精要慢，建议通过地下城查找队列组队进行，或作为队伍的一部分在世界上刷特定敌人获取经验。

:::details 常见问题：我可以作为恢复练级吗？
你可以，但实在没有充分的理由这样做。任何天赋构建的玩法都与它们所模仿的专精相同，但伤害要低得多。如果你选择仍然以恢复练级，请确保尽量避免任何带有精通属性的装备，任何带有伤害触发或使用效果的饰品在击败更强的敌人时会有所帮助。

:::

:::details 常见问题：恢复萨满的最佳种族是什么？
联盟玩家的最佳种族是矮人（

[[spell:20594]]

和

[[spell:59224]]

），而部落玩家在PVE中应选择牛头人（

[[spell:154743]]

），在PVP中选择兽人（

[[spell:20573]]

）用于PvP。

:::

:::details 常见问题：赞达拉恢复萨满的最佳洛阿是什么？
由

[[spell:292361]]

提供的暴击增益目前是最佳选择。

:::

你仍然应该通过[[spell:378443]]、[[spell:188443]]和你的单体伤害法术贡献尽可能多的输出，因为练级时的治疗需求通常很低。

1.1.

#### 升级装备选择

升级时，你应该始终选择物品等级最高的装备。这条规则唯一的例外是，如果你的戒指或项链物品等级略低，但拥有两项副属性而不是一项。

总体而言，在购买传家宝装备用于升级时，我们建议选择急速属性尽可能高的传家宝装备。高急速能大幅提升输出，并且让输出循环的手感更好。

急速在快速为周围怪物挂上标记方面也很有用。一瞬间的差别就可能决定是你成功标记了怪物，还是被其他玩家抢走。

1.2.

#### 至暗之夜中实用的升级消耗品

有几种可购买的消耗品可以帮助你提高练级速度。

- 理想情况下，你应该在升级过程中保持合剂增益效果。[[item:191348]]（61级起）需要频繁补充，但提供移动速度，对于升级来说通常比战斗属性更有用。如果你更喜欢战斗属性，我们推荐[[item:212277]]，该物品71级起可用。
- 食物增益的效果不如合剂，不过[[item:225592]]（需要75级）是个例外，它提供大量移动速度。否则，可以尝试[[item:172063]]或[[item:133576]]，因为它们在击杀敌人后也会为你提供移动速度。
- 治疗药水能帮助你减少空闲时间，让你在更激进地战斗的同时减少自我治疗的需求。请使用与等级相符的药水，例如71级起的[[item:244835]]。
- [[item:60854]]玩具可用于从附近的尸体上拾取战利品。
- [[item:109076]]对于从高处覆盖很长距离非常有用。
- [[item:132516]]是一种工程学物品，可让你的移动速度提高200%，持续25秒。这会让你几乎和飞行坐骑一样快。我们建议你携带大量这些，并在旅行距离超过约250码时使用它们。

只要枪鞋处于激活状态，你就无法停止移动。使用这个宏两次会取消该增益，让你能够停下来。

#### 枪靴取消宏

```wow-macro
#showtooltip
/use 火枪鞋
/cancelaura 火枪鞋
```

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 恢复 80级 至暗之夜 升级
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzMzMzYmhBjFYAAzCTgxCDwsNzY0stMzwMzgFzMzYglBAAAYGAMzgZgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzMzMzYmhxiZWgBMgZhJwYhBY2mZMa2WmZ2MzMLsYmZGDmlBAAAYGAMzgZwM"
}
```
:::

:::details 来源计算器编码
```
#IE-EPUOTKLFqxNMstF0WZ6J1hx7gRqaTRJQLkQB-FMLHGEC4UOniMgUiCiILBrB1y56C45B-AAAA-OEYoQMohZBRoAA-BEI
```

:::

2.1.

#### 升级用战争模式天赋

在本节中，我们将为升级和进行单人/小队PvE内容排序最佳的PvP天赋。以下是通用PvP天赋和恢复萨满祭司专属PvE天赋的排名。

1. [[spell:204331]]在较短的冷却时间内，能在相当长的持续时间内复制并反射你受到的伤害。在承受高伤害的区域中使用时效果非常强，可以对周围目标造成一些额外伤害，并将你的生命值转化为额外的输出。
2. **等级 30 起：**[[spell:290250]]使[[spell:73920]]变为瞬发、消耗更低且效果更强。这与[[spell:378443]]有极佳的协同效果，同时也与[[spell:204331]]配合良好，因为它能提供大量治疗，让你在怪物自杀式攻击时充当坦克。
3. **等级 40 起：**每次使用[[spell:378081]]时，[[spell:460697]]会在短时间内显著提高附近盟友法术的暴击效果。它适合单人游玩，如果你与他人一起进行户外内容则效果更佳。

**等级 20 起：**其他天赋各有其独特用途，但在升级时通用性不如上述天赋。

1.

### 升级循环

为了在练级和学习专精时保持简单，使用滑块选择你的等级，观察练级循环随着每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–9：**从1级开始，你只有一个主要伤害技能：[[spell:188196]]。这将在10级时改变，届时你选择恢复作为专精并解锁其他技能。在此之前，使用[[spell:188196]]击杀目标，并在3级解锁[[spell:188389]]后加以利用，9级解锁[[spell:192106]]后也应使用。

1. **等级 10–11：**保持自身激活[[spell:192106]]
2. **等级 12–15：**保持自身激活[[spell:52127]]
3. **等级 16 起：**保持自身激活[[spell:52127]]，并在自身和坦克身上保持[[spell:974]]
4. 对3个或更多能够存活至其持续时间结束的敌人施放[[spell:73920]]（配合[[spell:378443]]）
5. 若不存在[[spell:188389]]效果则施加
6. **等级 11 起：**每当可用时施放[[spell:51505]]
7. 对两个或更多目标施放[[spell:188443]]
8. 在单目标时作为填充技能施放[[spell:188196]]

**等级 15 起：**从15级开始，你可以通过游戏内的组队查找器排队进入地下城。在恢复专精时，你应该尽可能多地这样做，因为这是在熟悉治疗技能的同时高效升级的方式。为了深入了解如何使用这套技能，尤其是在更高等级时，请查看我们的 [循环页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)，但我们在下方添加了一个总结：

1. **等级 71–73：**使用 [[spell:73685]]，使其进入冷却，以召唤先祖
2. **等级 74 起：**使用 [[spell:73685]] 和 [[spell:443454]]，使其进入冷却，以召唤先祖
3. 尽可能使用 [[spell:61295]] 和 [[spell:5394]]
4. 如果队伍中有多名成员受伤且站位集中，使用 [[spell:1064]]
5. 对受伤的盟友使用 [[spell:77472]]
6. 如果不需要治疗，就使用你的输出循环（上文已详述）
7.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月30日：** 更新了枪靴取消宏。
- **2026年3月16日：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年3月2日：** 添加了一个用于80级升级的快速导入字符串。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 12.0.1 补丁更新和建议调整。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 更新了 11.5 补丁的变更。
- **2025 年 2 月 24 日：** 更新了 11.1 补丁的变更。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对 11.0.5 补丁和新的天赋树进行了更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为《地心之战》上线进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月11日：** 更新了推荐天赋。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月25日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 更新了10.0.7版本的天赋和输出循环。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将介绍如何在《魔兽世界》12.1.5 补丁中轻松游玩 恢复萨满祭司，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能。

1.

### 恢复萨满祭司基础

本节面向刚接触游戏或该职业的玩家，他们无意参与史诗难度团队副本，或只是希望以更直接的方式进行专精输出，而不会被最优输出所需的众多优先级和主动技能所淹没。

恢复萨满祭司是一个治疗专精，擅长应对团队伤害和爆发性的单体治疗。他们拥有多种冷却技能可供调用，能够适应任何情况。在本节中，我们将重点介绍一种在减少按键数量的同时，仍能提供灵活而强大的治疗能力的配置方案。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_unleashweapon_life.jpg>) **保持循环技能的冷却时间运转**
  
  
  
  
  作为恢复 萨满祭司，你的大部分治疗来自像[[spell:73920]]、[[spell:5394]]和[[spell:61295]]这样的短冷却技能。这些技能应该尽可能保持冷却时间运转，尽管其中许多也拥有充能系统，你可以让它们保持冷却同时保留大部分充能以备大量伤害到来时使用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritlink.jpg>) **规划主要冷却技能**
  
  
  
  
  [[spell:98008]]、[[spell:108280]]和[[spell:114052]]是你的主要冷却技能，可以让你在承受大量伤害时拯救团队。由于大多数首领战和地下城都有造成大量伤害的特定技能，通常最好保留这些冷却技能来应对它们，并与队伍中的其他治疗者协调使用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_watershield.jpg>) **法力值管理**
  
  
  
  
  由于[[spell:1064]]消耗高且没有冷却时间，当你专注于群体治疗时，你的法力值池会消耗得相当快，尤其是在长时间的战斗中。因此，你需要确保控制节奏，在低伤害期间穿插大量[[spell:77472]]和DPS技能，以使你的法力值能够支撑整场战斗。

在第二赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司获得了强力增益，但由于其拥有高额的被动治疗，图腾祭司很可能是最容易上手的选择，即使你在日常操作中没有按出最理想的按键，也能表现出色。

1.

### 《至暗之夜》中 恢复萨满祭司新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司新手天赋

2.1.

#### 恢复萨满祭司新手天赋

这些选择兼顾了易用性和原始强度，并且 **适用于所有类型的内容**。虽然不同的天赋在熟练运用时可能带来更高的收益，但同样的天赋在经验不足的玩家手中往往会导致治疗损失。

下面推荐的天赋旨在提供一种配置，它对不熟悉或犯错的惩罚极小，需要按下的按键或需要监控的增益和技能都最少，并且 **包含了最常用的功能性技能**。萨满祭司尤其依赖使用 **针对特定战斗的天赋** 来选择功能型天赋，你应该根据需要更换天赋，例如，点出 [[spell:8143]] 来应对 恐惧效果。

游玩时请务必使用“导出天赋”按钮来导入我们的构建！

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsBbwMW0YbAMDsZGmBbjZmpZbZmhZMbsMzMzYwsMAAAwMzgZGAYwM"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCVWqttx1NM0IVhp10qnHJaaxBCDwSGZq-FMcDHQqJQoIRtt9VGYIBCDEo56C1ZyC-AAAA-Jgko0AMowgxRmF-
```

:::

### 恢复萨满祭司基础循环

2.2.

#### 恢复萨满祭司基础循环

1. 保持自身激活[[spell:52127]]，并在自身和坦克身上保持[[spell:974]]
2. 将[[spell:5394]]用作应急治疗，或在你达到最大层数时使用，特别是当它升级为[[spell:1267016]]时
3. 如果其作用范围内人数较少，使用[[spell:444995]]并用[[spell:108287]]移动它
4. 卡着冷却使用[[spell:61295]]
5. 如果需要团队治疗，对受伤的队友使用[[spell:1064]]
6. 用[[spell:77472]]治疗受伤最重的单个玩家
7. 如果没有人处于危险之中，就进行输出以更快地击杀首领

2.3.

#### 治疗冷却技能

治疗冷却技能旨在让你为团队提供大量的爆发性治疗或生存能力。作为交换，它们通常每3分钟只能使用一次。下面简要描述了上述天赋构建中所选的每个冷却技能及其基本适用性，以便你了解何时使用它们效果最佳。

当团队承受的伤害很高但均匀分布在整个团队时，应使用[[spell:108280]]。它能在一段时间内提供大范围的分散治疗，并且可以在移动时使用，这使你能够在处理战斗机制或施放其他治疗法术的同时使用它。一旦你命中5个或更多目标，它将始终发挥其最大治疗效果。

[[spell:98008]]提供伤害减免，并且每秒重新分配图腾内成员的生命值，使图腾内所有人的生命值百分比保持相等。当有盟友在其他健康的盟友附近承受致命伤害时，这个冷却技能效果最佳，并且通常 **与伤害减免**
团队或个人冷却技能以及免疫效果配合使用，因为免疫的玩家不会受到任何机制伤害，但仍然可以通过图腾的效果为稳定团队做出贡献。

2.3.1.

##### 巅峰天赋： ![Stormstream Totem Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_manatidetotem.jpg>) 风暴涌流图腾

恢复萨满祭司的顶峰天赋是[[spell:1267016]]、两点天赋[[spell:1267093]]以及最终天赋[[spell:1267120]]。作为一个整体，这些顶峰天赋使[[spell:61295]]有小几率触发一个非常强大的[[spell:5394]]版本，在你完全解锁该天赋后可以不消耗常规治疗之泉图腾充能而施放。[[spell:378081]]（或[[spell:443454]]）在使用时也会触发。

触发效果最多可保持激活60秒并可叠加两次，让你有充足的时间等待最佳使用时机，尽管你通常应该在常规[[spell:5394]]的两个充能都就绪之前使用，以避免浪费潜在的使用次数。

2.3.2.

##### 第2赛季套装

以下是《至暗之夜》中 恢复萨满祭司的 S2 套装奖励。在奖励说明之后，你会看到一段简短的说明/点评，这是 <em>以斜体显示</em>.

- 2件套奖励 — [[spell:77472]]和[[spell:1064]]有几率在其目标位置制造一个持续8秒的[[spell:73920]]。 <em>这些额外的治疗之雨会受益于你的天赋，并能触发诸如[[spell:383222]]和[[spell:462425]]等天赋，但无法用[[spell:108287]]移动，这使得它们的实际治疗量取决于是否落在玩家聚集处。</em>
- 4件套奖励 — 每1秒，[[spell:73920]]内的一名盟友获得一个水之护盾，吸收伤害，持续10秒。 <em>吸收效果在困难的战斗中往往总能发挥全部价值，而且由于2件套奖励带来的额外治疗之雨，你在大多数情况下都能从这个奖励中获得良好的收益。</em>

总的来说，这是另一个简单但强力的套装奖励，其 2 件套效果带有很多随机性。在群体治疗场景中，这种随机性会被最小化，而 恢复在这些场景中本来就表现最佳，这使得本套装的 恢复萨满祭司治疗潜力在很大程度上取决于首领机制的设计。

### 恢复萨满祭司属性优先级

2.4.

#### 恢复萨满祭司属性优先级

目前，你希望按以下顺序优先考虑属性。有关本页所呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>).

装备等级

暴击

全能

急速

精通

虽然我们提供属性偏好列表，但将装备换成更高 **物品等级**
的装备——以及它们的 **更高的智力** /总属性——通常应该比使用属性更好但物品等级较低的装备带来更大的提升。这条规则的例外是带有重要第三属性的装备，例如 **吸血**，除非物品等级差距在7级或以上，否则这些装备仍应优先于没有这些属性的其他装备。

### 暴风雪战斗助手

2.5.

#### 我应该使用战斗助手功能吗？

对于 恢复萨满祭司，在目标数量不超过两个时，循环将在 [[spell:188389]]、[[spell:51505]] 和 [[spell:188196]] 之间交替使用；如果能命中三个或更多目标，则只需连续使用 [[spell:188443]]。

对于那些可能被 恢复繁多的按键所淹没的新手玩家来说，这是一个很棒的功能，因为它可以解放多个输出按键，同时在不需要治疗时仍能提供相当不错的伤害输出。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 12.0.1 补丁更新和天赋建议调整。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月7日：** 在上线已过去足够时间后，针对第三赛季进行了更新，假设拥有套装效果。
- **2025年8月4日：** 针对第三赛季进行了更新，假设没有套装效果。
- **2025年6月15日：** 添加了关于新战斗助手功能的信息。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 更新了 11.1 补丁的变更。
- **2024年12月15日：** 更新了更易遵循的输出循环和天赋建议。
- **2024年10月21日：** 针对 11.0.5 补丁和新天赋进行了更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月25日：** 根据首次全面模拟更新了更多饰品排名。
- **2024年8月23日：** 添加了更多易用的饰品。
- **2024年8月21日：** 已为《地心之战》上线进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月11日：** 更新了推荐天赋。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新10.2补丁的新天赋和饰品。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月31日：** 已根据最近的在线修正更新升腾半径翻倍的信息。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月13日：** 澄清了升腾和引导不应同时使用。
- **2023年5月1日：** 更改了巨龙时代第二赛季的推荐天赋和饰品。
- **2023年3月20日：** 更新了10.0.7版本的天赋和输出循环。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月13日：** 添加了原始仪式外壳。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到《魔兽世界》12.1.5 补丁中你的 恢复萨满祭司的最佳天赋。我们还为不同类型的活动（如团队副本或大秘境）提供了默认天赋方案。如果你开启了战争模式进行游戏，我们也为你准备了 PvP 天赋。

1.

### 至暗之夜 恢复 萨满祭司最佳天赋

在当前的环境中，两个英雄天赋树都是可行的，其中 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 推荐使用图腾祭司，因为它对移动频繁的战斗更加宽容。它拥有更多的瞬发法术，并且能够通过[[spell:108287]]频繁地重新放置[[spell:444995]]。图腾祭司还能通过[[spell:467306]]获得大量免费的[[spell:1064]]施放机会，使其在大多数情况下能比先知进行更多的群体治疗，代价是单体治疗能力较弱。

这并不是说 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知并非不可行，尤其是当你仍在使用第一赛季的全套套装加成时，该加成提升的是[[spell:73685]]而非[[spell:73920]]，使其对先知更为有利。第二赛季中先祖群体治疗得到了大幅加强，[[spell:61295]]也是如此，这两者都是先知玩法的核心，使其比以前强大得多，如果你喜欢非常主动的玩法风格，非常值得一试。

另外，请务必根据特定首领战或地下城的需要调整这些天赋构建，因为萨满祭司职业天赋树中充满了诸如[[spell:8143]]之类的小众天赋，它们通常没用，但偶尔会变得不可或缺。

**快速开始导入代码：**

:::talents 恢复地下城 - 图腾祭司
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsstMmZmZmZGjZMsBbwMW0YbAMDshxMMLzMGNLLzMbmxsxixMjhlZZAAAAzMYmBgxgZA"
}
```
:::

:::talents 恢复团队副本 - 图腾祭司
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsBbwMW0YbAMDsZGmBbjZmpZbZmhZMbsMzMzYwsMAAAwMzgZGAYwM"
}
```
:::

:::talents 恢复地下堡 - 先知
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzMzMzYmhxiZWgBMgZhJwYhBY2mZMa2WmZ2MzMLsYmZGDmlBAAAYGAMzgZwM"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

图腾祭司

团队副本

推荐

秘境+

推荐

先知

团队副本

秘境+

地下堡

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司团本天赋

虽然这些是基线推荐天赋，但请随意切换到不同的功能性天赋，以适应你的团队配置和逐个首领的需求。

虽然[[spell:108280]]与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司搭配效果不错，但由于[[spell:445035]]的新附加效果以及新的[[spell:1260874]]天赋，[[spell:114052]]拥有更高的治疗潜力，并在激活时能提供极高的单体治疗，而治疗之潮图腾是一个纯粹的团队治疗冷却技能，使其成为一个更灵活的选择。

由于[[spell:378270]]带来的更高[[spell:114052]]覆盖率，与[[spell:16196]]有着极佳的协同作用，因为每次施放都能保证两次[[spell:77472]]暴击，而[[spell:462443]]使施放速度更快。其替代天赋[[spell:462440]]在有2分钟团队伤害的战斗中是一个强力的替换选择，但由于你的升腾覆盖率很大程度上基于随机触发，其他情况下则较差。

[[spell:1064]] 及其辅助天赋与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司英雄天赋配合良好，因为每次使用[[spell:5394]]时，你都能通过[[spell:467306]]免费施放许多，而由于新的[[spell:1260644]]天赋，其冷却时间缩短了。

最后，我们跳过[[spell:462488]]，选择[[spell:61295]]天赋，如[[spell:382194]]、[[spell:1312843]]和[[spell:381946]]。它们更容易使用，且相比完美使用倾泻并不会造成显著的治疗损失。虽然倾泻在第二赛季套装加成下有很大潜力，但这只有在你的触发的[[spell:73920]]在正确的时间落在正确的位置时才能实现。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司大秘境天赋

虽然这些是基线推荐天赋，但请随意切换到不同的功能性天赋，以适应你的队伍组合、目标地下城和当前每周词缀。

这些天赋的基本思路是为你提供高的基础治疗和实用性，包括选择[[spell:378443]]来获得额外的被动伤害输出。[[spell:207401]]也是一个很好的天赋选择，可以减少爆发伤害对队友的影响。

[[spell:108280]]与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司有很好的协同作用，得益于[[spell:445035]]和[[spell:1260874]]英雄天赋的附加效果，它能瞬间治疗大量生命值，并且在激活期间允许你使用法术进行伤害输出或治疗，使其在当前版本中比[[spell:114052]]更强。

[[spell:1064]] 及其辅助天赋与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司英雄天赋配合良好，因为每次使用[[spell:5394]]时，你都能通过[[spell:467306]]免费施放许多，而由于[[spell:1260644]]天赋，其冷却时间缩短了。

最后，新的[[spell:1312843]]与多个[[spell:61295]]配套天赋一起选择，以便你能够持续地让队伍中的每个人都受到你的激流持续治疗覆盖。

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知团队副本天赋

虽然这些是基线推荐天赋，但请随意切换到不同的功能性天赋，以适应你的团队配置和逐个首领的需求。

先知拥有强大的读条治疗能力，这得益于[[spell:443447]]和[[spell:1270447]]，这弥补了其被动治疗低于图腾祭司以及[[spell:73920]]较弱的缺点。

由于[[spell:378270]]带来的更高[[spell:114052]]覆盖率，与[[spell:16196]]有着极佳的协同作用，因为每次施放都能保证两次[[spell:77472]]暴击，而[[spell:462443]]使施放速度更快。

[[spell:462443]]和[[spell:462440]]之间的选择取决于你正在挑战的首领的治疗冷却计划是否需要你比3分钟更频繁地使用升腾，但默认情况下卓越与我们同样点出的[[spell:378270]]有更好的协同作用。

最后，我们跳过[[spell:462488]]，选择[[spell:61295]]天赋，如[[spell:382194]]、[[spell:1312843]]和[[spell:381946]]，因为它们与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知天赋有更好的协同作用，而且倾泻在与[[spell:73920]]配合使用时的治疗量远低于与[[spell:444995]]配合使用。

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 大秘境天赋

虽然这些是基线推荐天赋，但请随意切换到不同的功能性天赋，以适应你的队伍组合、目标地下城和当前每周词缀。

这些天赋的核心思路是为你提供较高的基础治疗量和实用性，包括选择[[spell:378443]]以获得额外的被动伤害输出，这与[[spell:73920]]为先知带来的生活质量提升以及第2赛季套装加成相得益彰。[[spell:207401]]也是一个极佳的天赋选择，可以降低爆发性伤害对队友的影响。

[[spell:462443]]与[[spell:462440]]之间的选择取决于你规划的大秘境路线是否需要你比每3分钟更频繁地使用升腾，但默认情况下，卓越与我们同样点出的[[spell:378270]]有更好的协同效果。

[[spell:73685]] 可以让一位先祖几乎永久存在，是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知流派中的必点天赋，由于拥有更强的[[spell:77472]]施放（配合[[spell:443447]]和[[spell:1270447]]），这些流派通常拥有更好的群体治疗和单体治疗能力。

最后，由于[[spell:61295]]的持续治疗效果在第2赛季得到了大幅加强，尽可能让尽可能多的队友保持其高覆盖率将变得非常重要，这使得[[spell:382039]]不如[[spell:382732]]理想。

### 天赋方案 1-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知单刷地下堡天赋

虽然这些是基线推荐天赋，但请随意切换到不同的功能性天赋，以适应你正在进入的 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 地下洞穴的类型及其特定挑战。

虽然 恢复 在清怪方面并不算特别快 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)时总体速度并不算特别快，但它有一个优势，即能够在清理过程中通过[[spell:77472]]强大的自我治疗以及多个在仅治疗自己时效果出奇地好的冷却技能，毫不费力地保持自身健康，或许还能照顾少数几个盟友，比如你的 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 宠物。

对于高端玩家而言，换用[[spell:462477]]实际上非常强力，因为在人数很少的小队环境中[[spell:974]]是治疗的主要来源，因此这个天赋能从低目标数量的护盾刷新中获得很大收益。它也更容易通过新的[[spell:1270350]]来刷新，该技能会在你刷新[[spell:52127]]时刷新你的所有护盾和增益效果。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsBbwMW0YbAMDsZGmBbjZmpZbZmhZMbsMzMzYwsMAAAwMzgZGAYwM"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCVWqttx1NM0IVhp10qnHJaaxBCDwSGZq-FMcDHQqJQoIRtt9VGYIBCDEo56C1ZyC-AAAA-Jgko0AMowgxRmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsstMmZmZmZGjZMsBbwMW0YbAMDshxMMLzMGNLLzMbmxsxixMjhlZZAAAAzMYmBgxgZA"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCUWox1NM0IVhp10qnHJaxBDwSBAjgqSkC-FMDHRIQIR9FYACDsZaprLzMJC45xC1B-AAAA-Jgko0AMowgxRmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMMWMzGMgBMbMBGLmhZw2YmZa2WmZ2MjZjlZmZGDmlBAAAGzAgZGYwM"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCVWqttx1NM0IVhp10qnHZaxBCDwSGZQVB-FMcDHQKQoIRtt9VGYIBCDEo56C1ZyKD-AAAA-aYWIEKUOGYMEBA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZmltlxMzMzMzYMjxiZWgBMgZhJwYhZMDzyMjRzyyMzmZMbsYMz8ADLzyAAAAMDAmZYMYG"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCUWox1NM0IVhp10qnHZxBDwSBAjgSk+pC-FMDHRIQIR9FYACDsZaprLzMJ65xC1hD-AAAA-GcgohRIABgxShC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzMzMzYmhxiZWgBMgZhJwYhBY2mZMa2WmZ2MzMLsYmZGDmlBAAAYGAMzgZwM"
}
```
:::

:::details 来源计算器编码
```
#IE-EPUOTKLFqxNMstF0WZ6J1hx7gRqaTRJQLkQB-FMLHGEC4UOniMgUiCiILBrB1y56C45B-AAAA-OEYoQMohZBRoAA-BEI
```

:::

上面列出的构建是热门推荐，涵盖了适合各种终局内容风格的不同天赋配置。每个天赋构建都会有其自己的循环，并且还可以针对特定类型的内容进行进一步调整，以更好地惠及你的团队。

1.

### 全知典籍

万法大全是至暗之夜中引入的一项新机制， [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)
，它提供了一些小的提升，随着你完成一系列任务而解锁。有些奖励提高治疗输出，而另一些则是防御性的。

我们推荐以下选择。你不会被锁定在任何选项上，可以随时自由切换，所以不要担心犯错，尽情尝试吧！

- 节点1：[[spell:1279599]]
- 节点 2：[[spell:1279603]]
- 节点3：[[spell:1287555]]
- 节点 4：[[spell:1279609]]
- 节点5：[[spell:1279614]]

这套构筑的核心思路是让来自[[spell:1279599]]的瞬发智能治疗尽可能强大，因为这是该体系中最具影响力的治疗手段，并通过[[spell:1279609]]获得暴击，以借助[[spell:16196]]进一步提升我们的治疗能力和法力续航。

1.

### 恢复 萨满祭司 天赋 - 风暴涌流图腾

恢复萨满祭司的顶峰天赋是[[spell:1267016]]、两点天赋[[spell:1267093]]以及最终天赋[[spell:1267120]]。作为一个整体，这些顶峰天赋使[[spell:61295]]有小几率触发一个非常强大的[[spell:5394]]版本，在你完全解锁该天赋后可以不消耗常规治疗之泉图腾充能而施放。[[spell:378081]]（或[[spell:443454]]）在使用时也会触发。

触发效果最多可保持激活60秒并可叠加两次，让你有充足的时间等待最佳使用时机，尽管你通常应该在常规[[spell:5394]]的两个充能都就绪之前使用，以避免浪费潜在的使用次数。

1.

### 恢复 萨满祭司 英雄天赋

当玩家在任意专精下达到71级时，将解锁两棵独特的英雄天赋树之一。恢复 萨满祭司可以在以下两者之间选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知的核心玩法围绕召唤 **先祖**，主要通过[[spell:467646]]和[[spell:443454]]实现。这些是友方NPC，在激活期间会根据你使用的法术进行治疗或造成伤害，使这棵天赋树成为一个全面而扎实的选择，能够放大你的爆发治疗潜力。诸如[[spell:443447]]和[[spell:1270447]]等英雄天赋还使先知的基础法术强于图腾祭司的基础法术。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司的核心玩法围绕使用 **图腾**，并解锁[[spell:444995]]，它将[[spell:73920]]替换为持续时间更长的瞬发法术，且可以通过[[spell:108287]]移动。这节省了大量施法时间，尤其是与[[spell:467306]]以及使用输出型图腾时的免费[[spell:1064]]配合时。这些天赋极大地简化了操作，代价是将你的输出潜力更加绑定在[[spell:73920]]的小范围内。

1.

### PvP天赋（战争模式）

开启战争模式可获得以下好处：

- 可在野外使用的PvP天赋。
- 满级时世界任务奖励提高15%。
- 升级时获得的经验值提高15%。
- 能够在野外获得征服点数，每周可兑换强力装备。

考虑到开启战争模式对练级和PvE内容的好处，建议开启此功能，以最大化你的练级效率和满级后的奖励。但你会因此暴露于开放世界PvP中，在练级或做世界任务时存在被“偷袭”的可能。

在本节中，我们将解释PvP天赋，并根据其在练级和单人/小队PvE内容中的实用性进行排名。

1. [[spell:204331]]能在较短的冷却时间内复制并反射你所承受的伤害，持续时间相当可观。当处于高伤害区域时，这会非常强大，能对周围目标造成一些额外伤害，并将你的生命值转化为额外伤害。
2. [[spell:290250]]使[[spell:73920]]变为瞬发、消耗更低且效果更强。这与[[spell:378443]]以及[[spell:204331]]有很好的协同效应，因为它能提供大量治疗，让你在怪物自杀式攻击时能够抗住它们。
3. 每次使用[[spell:378081]]时，[[spell:460697]]会在短时间内显著提高附近盟友法术的暴击效果。它适合单人游玩，如果你与他人一起进行户外内容则效果更佳。

其余天赋各有其特定用途，但在开启战争模式的PvE情境中并非普遍实用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年6月15日：** 随着 12.0.7 补丁的发布，添加了万用大全章节。
- **2026年5月19日：** 将大秘境天赋建议更新为 图腾祭司 并更新了说明文字。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月30日：** 更新为当前主流天赋。
- **2026年3月16日：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 12.0.1 补丁更新和建议调整。
- **2026年1月27日：** 根据补丁前团本的最佳实践，更新了 先知 团本天赋构建。
- **2026年1月24日：** 修正了 图腾祭司 团本天赋中的笔误。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月15日：** 添加了拥有和没有新套装加成时的推荐标签。
- **2025年8月10日：** 现在为团本推荐低语之浪天赋。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月13日：** 根据顶尖冲层玩家，重做了 先知 大秘境天赋。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月23日：** 针对当前第二赛季环境更新了天赋。
- **2025 年 2 月 24 日：** 更新了 11.1 补丁的变更。
- **2024年12月15日：** 添加了推荐构建，并对天赋建议进行了小幅调整以简化操作。
- **2024年10月24日：** 调整了推荐的大秘境天赋构建。
- **2024年10月21日：** 针对 11.0.5 补丁和新的天赋树进行了更新。
- **2024年10月6日：** 调整了团本天赋，并修正了天赋详情部分的笔误。
- **2024年9月15日：** 添加了 先知 治疗链 团本构建，并重做了地下堡构建。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月24日：** 新增了地下堡推荐构建。
- **2024年8月21日：** 已为《地心之战》上线进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁和新套装奖励进行更新。
- **2024年5月11日：** 更新了推荐天赋。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新10.2补丁的新天赋构建，并在天赋描述中加入了升腾的削弱说明。
- **2023年9月4日：** 已更新为基于标签页的格式。
- **2023年7月31日：** 重做了指南中展示多套天赋树的方式。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月13日：** 将推荐的团本天赋改为使用根深蒂固的元素，并进行了多处文本更新。
- **2023年5月1日：** 第二赛季天赋更新以及新套装的游戏玩法变化。
- **2023年3月20日：** 为10.0.7版本更新了天赋。
- **2023年3月10日：** 在10.0.7补丁前进行了进一步更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月13日：** 为大秘境和团队副本进一步调整了天赋。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何根据团队承受的伤害类型来优化恢复 萨满祭司的输出循环。我们还有关于冷却时间、触发效果等方面的进阶内容，以最大化你的治疗输出和法力效率。我们的所有内容均已针对《魔兽世界》12.1.5版本补丁更新。

1.

### 恢复 萨满祭司玩法与循环指南

欢迎来到我们的恢复萨满循环页面。在本页中，你将找到在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

1.

### 恢复 萨满祭司开怪前清单

- 对自己使用[[spell:52127]]
- 对坦克和自己使用[[spell:974]]

<em>视情况而定：如果战斗一开始就承受高额伤害，在开怪前施放[[spell:73920]]并尽可能多地施放[[spell:61295]]。</em>

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知

团队副本

秘境+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司

团队副本

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

秘境+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:73920]]

[[spell:443454]]

[[spell:444995]]

[[spell:73685]]

[[spell:382039]]

[[spell:382309]]

2.1.

#### 治疗玩法优先级

1. **适用条件：先祖觉醒（启用）。** 在紧急治疗时或达到最大层数时使用[[spell:5394]] / [[spell:1267016]]
2. **适用条件：先祖觉醒（未启用）。** 在紧急治疗时、达到最大层数时，或处于[[spell:114052]]效果期间使用[[spell:5394]] / [[spell:1267016]]
3. **适用条件：先祖迅捷（启用）。** 施放[[spell:73685]]和[[spell:443454]]以召唤先祖、触发[[spell:1267016]]，并为你的下一次施法获得治疗增益
4. **适用条件：生命释放（启用）；先祖迅捷（未启用）。** 施放[[spell:73685]]以获得下一次施法的治疗增益
5. **适用条件：涌动图腾（启用）。** 卡冷却施放[[spell:378081]]以触发[[spell:1267016]]，并优先将其用于[[spell:1064]]
6. **适用条件：治疗之雨（启用）；涌动图腾（未启用）。** 如果多名友方单位会在其持续期间内大部分时间站在其中，使用[[spell:73920]]
7. **适用条件：涌动图腾（启用）。** 将[[spell:444995]]放置在能命中尽可能多的友方和敌方单位的位置，并根据需要使用[[spell:108287]]移动它
8. 卡着冷却使用[[spell:61295]]
9. **适用条件：潮汐奔涌（启用）。** 如果需要群体治疗，对带有[[spell:61295]]（为了[[spell:382039]]）的受伤友方单位使用[[spell:1064]]
10. **适用条件：潮汐奔涌（未启用）。** 如果需要团队治疗，对受伤的队友使用[[spell:1064]]
11. 用[[spell:77472]]治疗受伤最重的单个玩家
12. 如果无人处于危险之中，则进行输出以加快战斗进程
13.

### 至暗之夜 第2赛季套装

以下是《至暗之夜》中 恢复萨满祭司的 S2 套装奖励。在奖励说明之后，你会看到一段简短的说明/点评，这是 <em>以斜体显示</em>.

- 2件套奖励 — [[spell:77472]]和[[spell:1064]]有几率在其目标位置制造一个持续8秒的[[spell:73920]]。 <em>这些额外的治疗之雨会受益于你的天赋，并能触发诸如[[spell:383222]]和[[spell:462425]]等天赋，但无法用[[spell:108287]]移动，这使得它们的实际治疗量取决于是否落在玩家聚集处。</em>
- 4件套奖励 — 每1秒，[[spell:73920]]内的一名盟友获得一个水之护盾，吸收伤害，持续10秒。 <em>吸收效果在困难的战斗中往往总能发挥全部价值，而且由于2件套奖励带来的额外治疗之雨，你在大多数情况下都能从这个奖励中获得良好的收益。</em>

总的来说，这是另一个简单但强力的套装奖励，其 2 件套效果带有很多随机性。在群体治疗场景中，这种随机性会被最小化，而 恢复在这些场景中本来就表现最佳，这使得本套装的 恢复萨满祭司治疗潜力在很大程度上取决于首领机制的设计。

1.

### 职业与专精机制详解

本节将深入探讨关键的专精机制，如法力、我们的精通、移动管理，以及深入研究我们的功能性技能选项。

:::details 常见问题：大地之盾与治疗链如何互动？
[[spell:974]]

并不会使整个

[[spell:1064]]

在对其带有大地之盾的目标施放时提高20%。只有第一跳会获得提升，这适用于所有与大地之盾的其他互动；只有其目标会获得治疗提升，且仅在大地之盾激活期间生效。

:::

### 法力值管理

4.1.

#### 法力值管理

与所有治疗职业一样，法力值管理是这个专精的核心。明智地选择你的法术和时机非常重要，以确保法力值能够支撑到战斗结束，尤其是在开荒团队副本的环境中。理想情况下，你应该努力在整个战斗过程中将你的法力值池大致保持在与敌人生命值相同的百分比。这可以确保你在战斗后期既有足够的法力值可用，又能在战斗结束时法力值接近0%，从而不浪费其任何潜在的治疗量。

使用日志工具来分析你在一场战斗中法力值的消耗（或浪费）情况，可以是提升你法力值管理的绝佳方法。在这方面没有人是完美的，练习是成功的关键。即使是这个专精的老手，也需要一些时间来熟悉每一场战斗，以及了解他们在法力值池的使用上可以多么激进，同时仍能保留足够的储备来支撑整场战斗。

### 精通详情

4.2.

#### 精通：深度治疗

[[spell:77226]]是你作为恢复萨满祭司的精通。它使你的治疗在低生命值目标身上效果更强。当你治疗一个满生命值的目标时，你不会获得额外的治疗效果。当你治疗一个生命值为0%（1点生命值）的目标时，你将获得精通的全部收益。

你的精通在很大程度上影响着你作为一名恢复萨满祭司的玩法。

- 在团队治疗时，你应比任何其他类型的治疗者都更多地关注低生命值的目标，因为你拥有最高效的治疗手段来治疗他们
- 在单体治疗时，你的精通影响较小，因为你应该优先照顾你的指定目标，而不能自由选择低生命值的目标。通过了解你的指定目标将承受多少伤害，你可以优化你的治疗以从精通中获益

### 移动管理

4.3.

#### 移动管理

正确地移动/使用移动技能对于最大化你在躲避战斗机制的同时可用于治疗/输出的时间至关重要。不幸的是，很难解释如何在战斗中移动和调整位置，但作为一名治疗者，你应该尽可能遵循一些基本原则。

- 将自己定位在团队的中心位置，以便最好地接触到所有目标
- [[spell:2645]]可以让你轻松躲避机制，即使在被减速时也是如此，因为它会阻止你的移动速度被降低到100%以下
- 当你必须移动时，利用你的瞬发法术和图腾。如果没有可用的，使用[[spell:2645]]来更快地到达目的地
- [[spell:192063]] 可以帮助你应对击退机制以跨越宽阔的间隙，以及在需要紧急移动时使用
- 关注机制计时器并提前站好位置，以避免后续移动
- 如果有时间，采用碎步走的方式在较长时间内到达你的目标位置。每次使用瞬发技能时，在公共冷却时间锁定期间走几步

许多玩家在战斗中会无意识地移动，尽管这并无必要。例如，有时首领或小怪会被坦克拉走几码，虽然你仍在施法范围内，但你会下意识地跟随移动，浪费了公共冷却时间。有意识地让自己的移动“安静”下来，将不必要的移动减到最少。观察这一点的最佳方式是录制你的团队副本视频，然后回看自己的操作。大多数玩家都会对自己浪费的移动量感到惊讶。当你被迫移动时，利用上面的技巧，让你的路径尽可能直接果断。

[[spell:79206]] 应在需要大量移动且治疗输出令人担忧的时期使用。它也可以用来让你在继续治疗团队的同时重新调整位置。

### 功能性技能详解

4.4.

#### 恢复萨满的功能性技能详解

恢复萨满以他们带来的大量 **功能性技能**
——对自己或团队的非治疗增益——而闻名。要充分利用这些工具为团队带来好处并不总是显而易见，而且通常它们会被纳入你公会的整体副本战术中使用。

4.5.

#### 嗜血 / 英勇

[[spell:2825]] 和 [[spell:32182]] 让你的团队在长时间内获得更高的伤害/治疗输出，这对于击破团队首领的软狂暴和硬狂暴，以及成功应对史诗钥石地下城/PvP 情况至关重要。通常，这个法术会在首领战斗/地下城首领开场时施放，此时队友拥有他们的输出冷却技能，但根据战斗的具体情况可能会有所变化。

4.6.

#### 狂风图腾

如果你的团队需要移动速度加成来执行战斗机制，[[spell:192077]] 是一个很好的帮手，每2分钟提供一次显著的全团速度提升。由于图腾的速度增益只持续5秒，而图腾本身持续15秒；因此在速度增益消失后回到图腾处，可以从单个图腾获得多次速度提升。

4.7.

#### 土元素

[[spell:198103]] 召唤一个拥有极高生命值的元素，为你嘲讽并坦住非首领敌人很长时间。最好在战斗中用来提高你的输出，或作为紧急手段减轻团队坦克的压力。在 元素 激活时，你也可以用 [[spell:1279819]] 用其坦怪能力换取15%的生命值加成，使其成为一个个人防御技能。

4.8.

#### 星界转移

[[spell:108271]] 让你能够存活/无视通常无法应对的机制，应在你觉得接下来几秒内可能会死亡时使用，最好在你还有大量剩余生命值时使用。

4.9.

#### 战栗图腾

[[spell:8143]] 让你能够快速从自己或团队成员身上移除 恐惧/睡眠/魅惑效果，前提是你要在被控制之前施放它。它的PvE实用性取决于战斗机制，并且它并不能移除你遇到的所有类型的 恐惧/睡眠/魅惑效果，但在PvP中几乎总是有用的。

4.10.

#### 电能图腾

[[spell:192058]] 让你能够随意击晕一组敌人，使你的团队能够在他们造成更多伤害/治疗之前将其消灭。

4.11.

#### 陷地图腾 / 缚地图腾

[[spell:51485]] 和 [[spell:2484]] 让你能够定身/减速一个区域内的敌人。每当你的团队需要控制强大的敌人（以及在PvP中）时，这非常有用，但归根结底，其具体用途取决于你所应对的战斗机制。

4.12.

#### 妖术

[[spell:51514]] 让你能够长时间控制一个人形或野兽目标。在PvP和地下城中很方便，但在团队副本中用处有限。

4.13.

#### 净化灵魂

[[spell:77130]] 让你能够 驱散魔法（在点出天赋时还能驱散诅咒）效果，这对于成功完成地下城和团队副本往往至关重要。根据敌方阵容，它在PvP中也有很大的用处。请注意，如果你驱散的目标刚刚被另一位治疗完全驱散过，你会浪费法力值。

4.14.

#### 风剪 / 净化

恢复萨满是承担打断和驱散任务的理想人选，因为他们是唯一拥有 **远程** 踢。尽可能利用[[spell:57994]]，但如果是在高额伤害来袭期间，则应避免因此影响团队治疗。[[spell:370]]在需要驱散的战斗中也很棒，但请记住这会消耗法力值，所以如果资源紧张，可以考虑让一名DPS来承担这项任务。

### 先知先知

4.15.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知先知

当游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 使用[[spell:467646]]时，你可以召唤先知先知NPC在短时间内协助你，使用[[spell:73685]]和[[spell:443454]]。

这些先知会施放模仿你所施放的法术，但通常不会受益于或与你的天赋互动：

- [[spell:77472]]施放会使先知也施放治疗波治疗波，这能提供可观的单体治疗
- [[spell:61295]]激流和[[spell:73685]]生命释放会使先知施放治疗之涌治疗之涌，这也是一个单体治疗法术
- [[spell:1064]]治疗链、[[spell:73920]]治疗之雨、[[spell:5394]]治疗之泉图腾和[[spell:108280]]治疗之潮图腾会使先知施放治疗链治疗链
- [[spell:188443]]闪电链会使先知对你的目标施放闪电链，而单体伤害法术则会使先知施放[[spell:51505]]熔岩爆裂

1.

### 恢复恢复萨满祭司萨满祭司的重要冷却技能

正确使用冷却时间是玩治疗专精时最重要的事情之一，而治疗冷却时间的安排往往是决定一个团队成功（或毁灭）的关键因素。熟悉你的冷却时间组合并了解每种情况何时适用，是你成功的关键。

对于 恢复 萨满祭司，良好使用你的短冷却时间也非常重要。虽然[[spell:5394]]足够简单无需进一步说明，但[[spell:378081]]、[[spell:73685]]以及新的巅峰天赋[[spell:1267016]]的效果和最佳使用方式将在下文详细介绍。

### [[spell:98008]]

5.1.

#### 灵魂链接图腾

[[spell:98008]]是《魔兽世界》中最独特、最灵活的冷却时间之一。每秒，图腾作用范围内队伍成员的生命值都会重新分配，使所有目标拥有相同比例的最大生命值。它还为作用范围内的玩家提供15%的伤害减免，并在效果开始后不久通过[[spell:462384]]进行大量治疗。你可以使用灵魂链接图腾将单个目标承受的大量伤害分摊给队伍中的所有人，使其不再构成威胁。或者在高伤害技能击中队伍前，立即确保每个人都有高生命值。如果你再加上[[spell:196718]]，还可以进一步将队伍承受的伤害降低20%，且不涉及任何随机性。最后，由于灵魂链接图腾确保只要至少有一人受伤，效果范围内的所有人都会受到伤害，这使得治疗者能够仅使用范围治疗法术就快速高效地治疗整个队伍。

### [[spell:108280]]

5.2.

#### 治疗之潮图腾

[[spell:108280]]与[[spell:114052]]处于抉择节点，适合由 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司玩家使用，因为该天赋树中有提升其性能的英雄天赋，例如[[spell:445035]]和[[spell:1260874]]。由于它是一个图腾，你可以使用它并立即自由移动或施放其他法术，无需像其他治疗者的团队冷却时间那样进行引导或站立不动。治疗之潮图腾为40码范围内的所有盟友恢复固定量的生命值，治疗的盟友越少，单次治疗量越大，只要你有至少5名盟友在范围内，就始终能获得最大治疗量。由于它是升腾的替代选择，现在还能从[[spell:462440]]和[[spell:462443]]中受益。

### [[spell:114052]]

5.3.

#### 升腾

[[spell:114052]]与[[spell:108280]]处于抉择节点，是一个强大的治疗量冷却时间，其运作方式与[[spell:108280]]完全不同，适合由 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知玩家使用，因为它们与[[spell:108280]]缺乏协同效应。在升腾激活期间，[[spell:77472]]必定暴击并以50%的效果额外治疗一名盟友，而[[spell:1064]]则会额外跳向3个目标且每次跳跃仅降低10%的治疗量，使这两个法术都更加有效。只要你有准备地进入升腾状态或快速对[[spell:378270]]的触发做出反应，升腾提供的潜在额外治疗量非常强大。

### [[spell:378081]]

5.4.

#### 自然迅捷

[[spell:378081]]每分钟为你提供一次无需法力的瞬发施法和一次[[spell:1267016]]触发。使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司时，这通常用于免费的[[spell:1064]]，但 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知通过[[spell:443454]]将其升级为一个半冷却时间版本，强化瞬发法术并召唤一个先祖，使其成为一个需要卡冷却时间使用的重要法术。

### [[spell:73685]]

5.5.

#### 生命释放

[[spell:73685]]使用后可强化你下一次[[spell:77472]]、[[spell:61295]]或[[spell:1064]]的治疗量。由于它还会降低受影响法术的施法时间，你通常应该将其用在治疗链或治疗波上，因为激流是瞬发的。[[spell:1271104]]进一步增强了释放的力量，使其直接治疗更有影响力。

### [[spell:1267016]]

5.6.

#### 巅峰天赋：风暴奔流图腾

恢复萨满祭司的顶峰天赋是[[spell:1267016]]、两点天赋[[spell:1267093]]以及最终天赋[[spell:1267120]]。作为一个整体，这些顶峰天赋使[[spell:61295]]有小几率触发一个非常强大的[[spell:5394]]版本，在你完全解锁该天赋后可以不消耗常规治疗之泉图腾充能而施放。[[spell:378081]]（或[[spell:443454]]）在使用时也会触发。

触发效果最多可保持激活60秒并可叠加两次，让你有充足的时间等待最佳使用时机，尽管你通常应该在常规[[spell:5394]]的两个充能都就绪之前使用，以避免浪费潜在的使用次数。

1.

### 恢复恢复萨满祭司萨满祭司 DPS

很多时候，造成伤害而非治疗可能更有利，尤其是在承受的伤害较低且你想恢复法力值的时期。[[spell:188196]]无需消耗，让你在法力值恢复的同时帮助推进一些重要时机或协助处理高优先级目标。萨满祭司也是一个装备精良的职业，可以通过瞬发的[[spell:188389]]和[[spell:77756]]触发来协助造成伤害，而对治疗时间的消耗极小。

在下面的专门页面中了解更多关于此主题的信息！

[恢复恢复萨满祭司萨满祭司 DPS指南](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月30日：** 根据新的天赋建议调整了输出循环。
- **2026年3月16日：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 12.0.1 补丁更新和输出循环建议调整。
- **2026年1月27日：** 根据补丁前团本的最佳实践，更新了 先知 团本输出循环。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月10日：** 添加了更多关于使用低语之浪时目标选择的信息。
- **2025年8月4日：** 更新为第三赛季的新格式，包括新套装对输出循环的影响分析。
- **2025年6月15日：** 添加了关于新战斗助手功能的信息。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 更新了 11.1 补丁的变更。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对 11.0.5 补丁进行了更新，为 先知 激流 构建添加了新的输出循环提示和新天赋。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为《地心之战》上线进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年10月6日：** 已针对10.2补丁和新的套装加成进行更新。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月13日：** 澄清了升腾和引导不应同时使用。
- **2023年5月1日：** 添加了关于新套装以及它如何改变输出循环的信息。
- **2023年3月20日：** 更新了10.0.7版本的输出循环，并在插件指南页面添加了WA链接。
- **2023年3月10日：** 添加了技能连招信息图。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到《魔兽世界》12.1.5版本中恢复恢复萨满祭司萨满祭司的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们都为你准备好了！

1.

### 恢复恢复萨满祭司萨满祭司毕业装备指南

欢迎来到我们的恢复恢复萨满祭司萨满祭司装备与毕业页面，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)。查看本页，了解关于为恢复恢复萨满祭司萨满祭司配装的一切信息，包括来自所有来源的毕业装备、团队副本和大秘境、最佳饰品、套装等更多信息。

在至暗之夜中， **所有物品等级都被压缩了**，这意味着所有物品及其物品等级的数值都被大幅降低，使得所有数值可以在资料片和未来内容中再次增长，而不会变得过大而难以理解。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

一如既往，优先选择吸血/闪避装备和你拥有的最高物品等级装备，无论其副属性分布如何。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，你催化获得的装备会保留其原有属性和小特效，使得诸如

[[item:268230@JAACAAgNyA]]

之类的装备非常适合作为套装部件，也消除了选择属性优于套装的散件的逻辑。因此，我们建议催化以下暴击属性为主的装备部件：

- 头盔：[[item:268230@JAACAAgNyA]]
- 肩膀：[[item:251131@JAACAAgNyA]]
- 胸甲：[[item:158355@JAACAAgNyA]]
- 手套：[[item:251165@JAACAAgNyA]]
- 腿部：[[item:159375@JAACAAgNyA]]

:::

:::details 常见问题解答：双手武器可行吗？
虽然使用盾牌通常更好，因为有护甲加成，并且在PvP中或玩

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司

时肯定是必需的，因为

[[spell:445033]]

远比

[[spell:445032]]

强，在第2赛季中，你可以在PvE中玩

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知

.

:::

**时使用双手武器。虽然在赛季初期通常更倾向于制造双手武器，但本赛季是个例外，因为可以轻松地用英雄难度的乌拉特克金币换取神话难度的[[item:271092@JAACAAgNyA]]，而且[[spell:445033]]也很强。** 下面的列表假设的是赛季末期的情况，催化次数、纹章和制造用火花都是无限的。

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 头部来自 <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 手套来自 <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAwo2ghNXQD]]&#10;&#10;<div>[[item:240968]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268216@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></div></td></tr><tr><th>护肩</th><td>[[item:271481@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 肩膀来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268248@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></div></td></tr><tr><th>脚部</th><td>[[item:244577@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271486@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 胸甲来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:251196@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含 **只能** 在至暗之夜大秘境地下城中可获得的物品。一如既往，优先选择吸血/闪避装备和你拥有的最高物品等级装备，无论其副属性分布如何。

:::details 常见问题解答：我需要哪些套装部件（仅地下城掉落）？
在至暗之夜第2赛季中，你催化获得的装备会保留其原有属性和小特效，使得高暴击的随机装备非常适合作为套装部件，也消除了选择属性优于套装的散件的逻辑。因此，如果你只能获得地下城装备，我们建议催化以下暴击属性为主的装备部件：

- 头盔：[[item:159374@JAACAAgNyA]]
- 肩膀：[[item:251131@JAACAAgNyA]]
- 胸甲：[[item:158355@JAACAAgNyA]]
- 手套：[[item:251165@JAACAAgNyA]]
- 腿部：[[item:159375@JAACAAgNyA]]

:::

:::details 提示我应该刷哪些地下城？
我们建议你刷以下地下城：

- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)，因为这里掉落多件毕业装备，例如[[item:251131@JAACAAgNyA]]、[[item:251136@JAACAAgNyA]]、[[item:251132@JAACAAgNyA]]，以及第二好的饰品[[item:250215@JAACAAgNyA]]。 [夺目谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>) 也非常不错，有[[item:251165@JAACAAgNyA]]、[[item:251196@JAACAAgNyA]]和[[item:250214@JAACAAgNyA]]等物品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 头部来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 手套来自 <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>项链</th><td>[[item:273781@JAACAAAOyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>腰部</th><td>[[item:251155@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>护肩</th><td>[[item:271481@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 肩膀来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:244577@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271486@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 胸甲来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:193757@JAAKAAQkCYHKvbRLfgjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273780@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:251196@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含 **只能** 来自当前团队副本的物品。一如既往，优先选择吸血/闪避装备和你拥有的最高物品等级装备，无论其副属性分布如何。

:::details 常见问题解答：我需要哪些套装部件（仅团队副本掉落）？
在至暗之夜第2赛季中，你催化获得的装备会保留其原有属性和小特效，使得诸如

[[item:268230@JAACAAgNyA]]

非常适合作为套装部件，也消除了选择属性优于套装的散件的逻辑。因此，如果你只能获得团队副本装备，我们建议催化以下暴击属性为主的装备部件：

- 头盔：[[item:268230@JAACAAgNyA]]
- 肩膀：[[item:268231@JAACAAAG2A]]
- 胸甲：[[item:268223@JAACAAgNyA]]
- 手套：[[item:268238@JAACAAgNyA]]
- 腿部：使用来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>) 的代币，因为默认版本拥有最佳属性组合

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团长提交一份高优先级装备列表，或只是想专注于最重要的首领和装备，我们已为你准备好！

- [[item:268265@JAAGAAwo2ghNXQD]]：一件属性极高的项链，除了精通以外大部分属性对我们都很有用，是恢复恢复萨满祭司萨满祭司的必备之选。
- [[item:271092@JAACAAgNyA]]：本赛季最好的武器。不幸的是它提供的是急速而非暴击，但你的暴击需求将由其他 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 部件来满足，所以这里有一些急速也是受欢迎的。
- [[item:281215@JAACAAAOyA]]：本赛季最好的饰品，提供大量被动暴击加成，前提是你能造成伤害来激活它，通常通过[[spell:378443]]或[[spell:188389]]。
- [[item:270164@JAACAAgNyA]]：另一个非常强大的被动饰品，尽管偶尔会有几率给你一个负面减益效果。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 头部来自 <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 手套来自 <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAwo2ghNXQD]]&#10;&#10;<div>[[item:240968]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268216@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></div></td></tr><tr><th>护肩</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 肩膀来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268248@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></div></td></tr><tr><th>脚部</th><td>[[item:244577@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271486@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 胸甲来自 <a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268196@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 恢复恢复萨满祭司萨满祭司饰品推荐

这些通常是可用的最强主动使用和被动饰品，
**被动饰品更受青睐** ，因为易于使用：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **恢复恢复萨满祭司萨满祭司饰品**
**使用型 -**

[[item:270162@JAACAAgNyA]]

和

[[item:250215@JAACAAgNyA]]

**被动 -**

[[item:270167@JAACAAgNyA]]

,

[[item:270164@JAACAAgNyA]]

，以及

[[item:193757@JAAKAAQkCYHKvbRLfYjM]]

:::

下面我们将提供一个可用饰品的大致梯队列表。这可以帮助你快速决定哪些饰品值得刷取，或者你想对什么物品需求。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看恢复恢复萨满祭司萨满祭司饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>一个极好的饰品，提供大量暴击，但需要造成伤害才能触发，这主要来自[[spell:378443]]和[[spell:188389]]。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAgNyA]] - <span><em>点击查看详情</em></span>&#10;<span>一个强大的被动饰品，偶尔会让你失去属性而非获得属性，但总体而言其效果大多是正面且强大的，覆盖率很高。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270162@JAACAAgNyA]] - <span><em>点击查看详情</em></span>&#10;<span>到目前为止，这是本赛季治疗者最好的饰品，尤其是如果你有队友死亡，那会让你能更频繁地使用它！</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270167@JAACAAgNyA]] - <span><em>点击查看详情</em></span>&#10;<span>这是一个强大的被动饰品，周期性地提供大量智力，如果你能将治疗冷却时间与其达到最大层数的时期同步，它将非常强大。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270169]] - <span><em>点击查看详情</em></span>&#10;<span>这个饰品会主动叠加智力减益效果，直到你使用它，届时你会获得大量智力提升，这非常适合真正增强你的爆发治疗潜力，代价是爆发窗口之间的威力降低。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:193757@JAAKAAQkCYHKvbRLfYjM]] - <span><em>点击查看详情</em></span>&#10;<span>该饰品可以通过在独自一人且脱离战斗时对自己使用来进行训练，从而为你提供随机触发的额外暴击，在这种情况下它是一个强力的属性加成饰品，类似于[[item:270167]]。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAgNyA]] - <span><em>点击查看详情</em></span>&#10;<span>一个简单的饰品，使用后提供暴击，你应该稍微延迟使用以对齐2分钟的[[spell:114052]]升腾，或者按冷却使用以完美对齐3分钟版本。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:248583]] - <span><em>点击查看详情</em></span>&#10;<span>一个非常强大的地下堡饰品，你可以通过在地图坐标52.15 80.74处的祖尔'Aman区域对其进行配置，以提供可靠的暴击触发。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:251792]] - <span><em>点击查看详情</em></span>&#10;<span>一个非常出色的饰品，无法通过史诗钥石获得，但早期使用非常值得，即使你是队伍中唯一拥有它的玩家。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:250214]] - <span><em>点击查看详情</em></span>&#10;<span>虽然如果你能站在它偶尔提供的精通光束中会特别好，但它的大部分收益是被动的，使你可以仅凭属性就使用它。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:273796]] - <span><em>点击查看详情</em></span>&#10;<span>使用此饰品可让你在2分钟冷却时间内获得一个持续15秒的强大随机属性增益，这非常适合与2分钟的[[spell:114052]]配合使用。不幸的是，它也会在效果结束后让你在15秒内损失少量属性，这使它更像是一个爆发型治疗饰品。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250255]] - <span><em>点击查看详情</em></span>&#10;<span>一个强大的大秘境饰品，用于救急的主动使用。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250254]] - <span><em>点击查看详情</em></span>&#10;<span>一个强大的大秘境饰品，用于救急的主动使用，尽管它的效果可能需要一段时间才能激活，因为它取决于你对其使用的目标生命值降低。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:250248]] - <span><em>点击查看详情</em></span>&#10;<span>相当不错，且像[[item:250214]]一样大部分收益是被动的，但由于它提供的是固定治疗效果而非你的治疗精通潜在乘数，因此威力稍弱一些。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:273649]] - <span><em>点击查看详情</em></span>&#10;<span>此饰品每2分钟提供一次主动使用的急速爆发，因此是2分钟[[spell:114052]]的完美搭档。</span>&#10;</li>&#10;<li>[[item:241291]]</li>&#10;<li>[[item:251788]]</li>&#10;<li>[[item:251789]]</li>&#10;<li>任何其他未提及的饰品都等于此级别或更差。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 用于从特定Boss或地下城获取物品，让你获得一个来自特定掉落位置的保底掉落。你仍然在该位置可用的掉落池中进行掷骰，但下次你在该难度下该位置/Boss使用虚空核心时，你将获得之前没有获得的物品之一。

**奥琳·微光** 站在银月城催化剂旁边的NPC将在补丁12.1.5上线后每周免费赠送你一个额外的虚空核心。

3.1.

#### 恢复 萨满祭司的推荐虚空核心使用方法

你想要追求哪件物品，很大程度上取决于你已经通过 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 和其他高端渠道获得的物品，或者你是否打算在史诗难度下击败关键首领，因为你不想在可能通过更高难度路线快速获得的物品上浪费虚空核心。优先顺序如下：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 英雄难度 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 以恢复专精拾取，直到你获得[[item:271092@JAACAAgNyA]]（以及可能的[[item:268265@JAAGAAwo2ghNXQD]]）。
2. 史诗难度 [盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>) 作为恢复也只包含有用的物品，除了[[item:268203]]之外，希望你能避开它。
3. 史诗难度 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 用于[[item:281215@JAACAAAOyA]]。
4. 之后就用金币换取你缺少的毕业物品，通常以增强专精拾取，在 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) 和 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>) 中完成你的毕业物品收集！

:::

3.2.

#### 晋升毒液石

使用[[item:280562]]升级物品遵循与使用纹章类似的优先级列表：

1. 武器
2. 饰品
3. 项链

请注意，这些物品最高只能升级到物品等级344。如果你使用的是特殊物品，例如毒咒物品或最后2个史诗首领掉落的物品，它们无法用毒石进一步升级。当然，这也取决于你是否拥有史诗路线的物品。你应该优先考虑这些，但无论何时，武器都应保持为你的首要升级目标。

1.

### 恢复 萨满祭司的最佳制造物品

强化是特殊效果，要么默认存在于制造装备上，要么可以在制造过程中添加到制造装备上。一个角色可以同时 **装备两个** 任何时候装备的美化。

你可以在以下链接查看完整的镶边模拟数据： [QuestionablyEpic Live](<https://questionablyepic.com/live/>)查看完整的美化模拟，但我们基本上推荐制作以下装备：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **恢复 制造装备优先级**
- [[item:237831@JAAKAAwt1ENMMYzWiAGM]] 搭配 [[item:240167]]，如果你没有史诗难度掉落的盾牌
- 否则，使用 [[item:244584@JAAKAAwt1ENMMYzWiAGM]] 搭配 [[item:240167]]
- [[item:244577@JAAKAAwt1ENMMYzWiAGM]] 搭配 [[item:240167]]
- 任何你尚未获得神话级的物品。

:::

[[item:240167]] 是一种灵活的美化，可以用于任何制造护甲部件，触发时为你和附近的一名队友提供强大的增益。

由于它无法制作在武器上，赛季后期新起的小号可能会先制作一把 [[item:245770@JAAKAAwt1ENMMYzWiscN]] 搭配 [[item:273060]]，以在达到满级后快速获得巨大的战力提升。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 为装备添加插槽

你可以使用从大宝库商人处选择货币奖励时获得的 [[item:275707]] 消耗品，为头盔、腰带和护腕添加插槽。

1.

### 纹章使用

你通常应该优先升级你的武器，其次是饰品，然后是任何吸血/闪避装备，或是你短期内不会更换的装备，亦或是属性分配较高的装备，例如头盔或腿部。例如以下都是很好的选择：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **恢复萨满祭司纹章升级优先级**
**武器 / 副手**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

1.

### 评估升级

在本页面和我们指南的其他地方，我们经常提到在 QE Live 上进行自我模拟的重要性。这是因为每个角色都是独一无二的，你能获得的每件装备都可能改变你现在最适合的装备搭配。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年9月2日：** 更改了装备和代币兑换建议，以适应属性变更。
- **2026年8月26日：** 根据最新的装备属性变更进行了更新。
- **2026年8月10日：** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年6月15日：** 随着 12.0.7 补丁的发布，将孢子融合装备添加到了毕业列表中。
- **2026年5月19日：** 更新了虚空核心建议、新的毕业表格格式和饰品建议。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月1日：** 在许多饰品获得大幅增强后，调整了饰品建议。
- **2026年3月30日：** 更新了常规装备、装饰和饰品建议。
- **2026 年 3 月 17 日：** 热修后的饰品梯队调整。
- **2026年3月16日：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 在削弱后更新了迪斯科腰带，并添加了谜之卡特尔芯片章节。
- **2025年8月4日：** 更新了第三赛季装备和新建议。
- **2025年6月15日：** 添加了关于新“DISC”腰带的新部分。
- **2025年4月29日：** 添加了更多关于即将到来的卡特尔芯片装备获取的信息。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月23日：** 更新了装备列表和瑟尔西头冠的宝石建议。
- **2025 年 2 月 24 日：** 更新了 11.1 补丁的新装备。
- **2024年12月17日：** 更新了关于瑟尔西头冠宝石优化的首次计算结果。
- **2024年12月15日：** 更新了 11.0.7 补丁关于瑟尔西头冠的信息。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 移除了赛季前装备列表，并添加了关于早期制作双手武器以节省纹章的说明。
- **2024年8月27日：** 根据近期调整更新了装饰和制造装备建议。
- **2024年8月25日：** 根据首次全面模拟更新了更多饰品排名。
- **2024年8月23日：** 已更新S1地下城、团队副本和饰品毕业装备表格。
- **2024年8月21日：** 已为《地心之战》上线进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月26日：** 根据最新数据进一步更新。
- **2024年4月22日：** 已根据第4赛季更新了新装备、饰品和装饰。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月27日：** 添加了永恒黎明中每件掉落物品所在的翼区信息。
- **2023年11月9日：** 多处笔误修正。
- **2023年11月8日：** 在波动孢子斗篷削弱后更新了装饰推荐。
- **2023年11月6日：** 已根据10.2版本更新了新装备、饰品和装饰。
- **2023年9月4日：** 已针对10.1.7版本环境进行更新，并为毕业装备模块添加了标签页。
- **2023年7月19日：** 针对回响泰尔斯通削弱的调整。
- **2023 年 7 月 11 日：** 进一步调整饰品列表。
- **2023年7月10日：** 将10.1.5补丁的饰品添加到列表中，并回顾了新地下城中可获得的装备。
- **2023年5月1日：** 第二赛季升级系统总结，更新了美化推荐，并添加了一些饰品。
- **2023年3月23日：** 在玛瑙指环获得多次宝石增益使其值得使用后进行了更新。
- **2023年3月20日：** 添加了关于新玛瑙指环戒指的信息。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月21日：** 重做了饰品推荐和团队副本毕业装备建议。
- **2022年12月13日：** 添加了美化推荐和原始仪式外壳。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页中，你将找到你的 恢复萨满祭司的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法互动。我们的内容已针对魔兽世界 12.1.5 补丁更新。

1.

### 恢复萨满祭司属性优先级

这套属性优先级在大多数场景下都能让你表现出色：

装备等级

暴击

全能

急速

精通

急速在大秘境和短时间的团队副本战斗中尤为强大。你不想完全堆叠急速的主要原因是更快的施法会导致你的法力值消耗更快，而在这些环境中这个问题不太令人担忧。

**精通** 在进行困难内容时特别有价值，因为玩家更有可能生命值降至较低水平，例如 **史诗团本开荒和评级PvP**。在这类内容中，它几乎可以被视为与暴击持平。

你的配装首要任务是使用你最高 **装备等级**
装等的装备。这些装备带有大量智力，按每一点计算能最好地提升你的法术效果。

话虽如此，会有少数情况装等提升并非真正的提升。插槽通常价值几个装等，前2-3件装备上的吸血也值几个装等，闪避也可以值得你降低整体装等去追求，但仅限于你会承受危险范围伤害的战斗中。

在治疗 **高层大秘境**时，全能的减伤效果非常重要，它使你能够在通常无法存活的最高层数大秘境中生存下来，并普遍减轻了在高伤害期间自我治疗的压力。

1.

### 深入属性解析

**智力** 是你的主要属性。你应该在所有升级中寻找此属性。它为你提供法术强度，从而增强你的治疗效果。

**暴击** 提升你的治疗吞吐量，并通过 [[spell:16196]] 提供一定的法力回复加成。作为纯治疗吞吐量，它是最强的属性之一，因为它成长性良好并能提升你几乎所有的治疗法术，同时还能提升 [[spell:51505]] 的暴击伤害，因为当目标身上有 [[spell:188389]] 时它是必定暴击的。

**全能** 是直接的吞吐量提升，同时也降低你受到的伤害。它能提升你几乎所有的技能，但在纯吞吐量方面成长性不如暴击。这被它的减伤部分以及比暴击更好的DPS成长性所平衡，使两者在强度上接近。在PvP中，由于其防御属性，它在所有情况下通常是最佳属性。

**急速** 降低你法术的施法时间和全局冷却时间的持续时间。急速还会使你的持续治疗和持续伤害效果跳得更快，以及提高你治疗图腾的跳动频率。 **当法力值不是问题时，急速是最佳的吞吐量属性** 并且由于其出色的成长性，在造成伤害时始终是极好的属性。然而，在需要停止施放治疗法术以节省法力的持久战中，拥有更强力的法术能让你获得更多收益，因为你无法充分利用你现有的急速。

:::details 常见问题：恢复萨满有急速上限吗？
没有急速上限。除了提高你的潜在吞吐量外，它还让你的循环感觉更流畅、响应更快。然而，增加的吞吐量是以法力值为代价的。

:::

**精通**，由 [[spell:77226]] 代表，允许你在治疗低生命值队友时恢复更多生命。它起始数值很高但成长性不佳，这往往导致它随着装等提升表现变差。尽管如此，在队友治疗时很可能处于低生命值的困难内容中它仍有很好的价值，我们建议在史诗团本开荒、高层大秘境和评级PvP中将其视为与顶级属性同等重要。

**吸血** 允许你被动地为自己恢复相当于你施放的每个法术治疗量或伤害量一定百分比的生命值。由于会伤害全队的敌方机制非常普遍，它最终能造成大量的 <em>免费</em> 治疗，否则这些治疗需要由你自己或队伍中其他治疗者消耗法力值来覆盖。

**闪避**的具体强度取决于战斗机制，但在极高层数大秘境中面对极端伤害技能时，它往往是生死存亡的决定因素。它所防止的伤害在团队副本环境中也非常有用。

**急速** 略微提高你的角色移动速度。在躲避首领机制或与队伍重新调整站位时可能有用，但不如其他属性明显。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对 至暗之夜 第二赛季上线进行了审查。
- **2026年6月15日：** 由于我们的法力经济大幅改善，上调了急速的价值评估。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月30日：** 添加了更多关于收益递减和属性优先级的信息。
- **2026 年 3 月 17 日：** 更新了针对较长战斗的最新模拟信息。
- **2026年3月16日：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月10日：** 对低语之浪的属性优先级进行了小幅调整。
- **2025年8月4日：** 针对第三赛季进行了更新，并为新的低语之浪天赋构建调整了属性。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 更新了 11.1 补丁的变更。
- **2024年12月15日：** 审查了属性优先级并更新了解释。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月23日：** 已更新递减收益属性表格和团队副本与大秘境的属性优先级。
- **2024年8月21日：** 已为《地心之战》上线进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 添加了关于10.2版本中新套装下急速何时有用的信息。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的 恢复萨满祭司可以获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你始终应该拥有一颗 **钻石** 宝石，最好是最高 **品质**
[[item:240983]]，如果这是你唯一的宝石插槽，或者一旦你有4个以上可用插槽时使用 [[item:240968]] 以获得其最大收益。在切换到最大法力值钻石时，确保在其他插槽中每种宝石至少有一颗以最大化法力值获取效果，最好是 [[item:240910]]、[[item:240914]]、[[item:240890]] 和 [[item:240898]] 各一颗。

1.

### 最佳附魔和武器强化

[[item:243733]] 是最好的临时武器油，但你通常会使用 [[spell:382021]] 天赋代替。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240155]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244003]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

你通常应该在团队副本中使用 [[item:241326]]，因为暴击是所有天赋构建都青睐的属性，而在大秘境中则换用 [[item:241320]] 以获得其防御性收益。

3.2.

#### 药水

[[item:241308]] 是你最佳的战斗药水选择，应在团队高伤害期间配合主要冷却技能使用。你也可以从炼金师提供的 [[item:241285]] 中获得 [[item:245898]]。

[[item:271883]] 是当前最好的治疗药水，应在紧急情况下或你没有时间自我治疗时使用。它不与战斗药水共享冷却时间，且使用药水有5分钟冷却时间，允许你在持久战斗中使用多瓶。

虽然法力值恢复药水确实存在，但与 [[item:241308]] 相比价值非常低，因此在几乎所有场景下都不值得使用。你可能想在手边备上一组以备绝对紧急情况，但通常更好的做法是直接在冷却技能期间使用属性药水。

3.3.

#### 食物增益

你应该尽可能食用 [[item:255845]] 或 [[item:255846]] 宴席，但在单人和小队场景中也可以使用 [[item:242275]]。

所有食物的丰盛版本都可以通过 [烹饪](<https://www.icy-veins.com/wow/professions-cooking>) 专业通过组合5到10份普通食物来制作，食用后即使中途死亡也能提供整整一小时的增益效果。

3.4.

#### 强化符文

[[item:259085]] 提供可观的智力加成，来源众多，包括各种专业的NPC制作订单。

由于它们相对于提供的属性来说往往非常昂贵，只在高风险情况下使用它们！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月19日：** 添加了药水建议章节。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对第三赛季进行了更新，添加了新的治疗药水和强化符文。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 添加了腐蚀附魔信息。
- **2025 年 2 月 24 日：** 更新了 11.1 补丁的变更。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月15日：** 添加了关于武器油的说明。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为《地心之战》上线进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 解释了熔玉印章的削弱及其作为一枚不错但并非顶级戒指的新定位。
- **2023年5月10日：** 添加了新的腰带附魔：暗影之扣。
- **2023年5月9日：** 已针对5月9日的堕落之怒错误修复进行调整。
- **2023年5月5日：** 在孢子恩赐附魔削弱72%以及堕落之怒处于BUG状态后，调整了推荐。
- **2023年5月1日：** 添加了孢子恩赐附魔、堕落之怒药剂和阴险的魔鬼蛋。
- **2023年3月24日：** 进一步更新了玛瑙指环。
- **2023年3月23日：** 在玛瑙指环获得多次宝石增益使其值得使用后进行了更新。
- **2023年3月20日：** 为10.0.7版本更新了玛瑙指环。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月30日：** 添加了来自裁缝法术线程的腿部附魔。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在魔兽世界 12.1.5 补丁中使用你的 恢复萨满祭司 攻克大秘境地下城的提示和建议。

1.

### 恢复萨满祭司在至暗之夜第2赛季中的大秘境

大秘境地下城，尤其是高层，是魔兽世界中除史诗团本外最高水平的竞技PvE内容。作为团队的治疗者，他们的生存掌握在你手中。幸运的是，恢复萨满祭司非常擅长在意外伤害中进行治疗并从失误中恢复。

如果你不熟悉大秘境及其相关的一般机制，你可以在下面我们专门的大秘境页面上了解更多信息。你也可以在我们的层级列表页面上了解更多关于大秘境环境的内容。

1.

### 最佳大秘境天赋配置

地下城天赋应包含 [[spell:192058]] 和 [[spell:57994]] 等控制技能，以及 [[spell:378443]] 提供的免费伤害。 **对于高层大秘境** 还建议点出 [[spell:207401]] 的生命值提升，因为它在小队中拥有很高的覆盖率，是在更高层数下防止被秒杀的好方法，但在打每周低保层数时不需要。

由于 恢复萨满拥有许多情境性天赋，请确保根据地下城调整你的通用天赋树，以包含情境性功能，例如针对恐惧的 [[spell:8143]]，[[spell:383016]]（诅咒驱散）和 [[spell:383013]]（中毒驱散），[[spell:51514]]、[[spell:378075]] 和 [[spell:462820]] 用于解除定身/减速效果，甚至 [[spell:260878]] 用于针对秒杀机制的额外减伤！

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 恢复萨满祭司大秘境天赋构建

虽然这些是基线推荐天赋，但请随意切换到不同的功能性天赋，以适应你的队伍组合、目标地下城和当前每周词缀。

这些天赋的基本思路是为你提供高的基础治疗和实用性，包括选择[[spell:378443]]来获得额外的被动伤害输出。[[spell:207401]]也是一个很好的天赋选择，可以减少爆发伤害对队友的影响。

[[spell:108280]]与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司有很好的协同作用，得益于[[spell:445035]]和[[spell:1260874]]英雄天赋的附加效果，它能瞬间治疗大量生命值，并且在激活期间允许你使用法术进行伤害输出或治疗，使其在当前版本中比[[spell:114052]]更强。

[[spell:1064]] 及其辅助天赋与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司英雄天赋配合良好，因为每次使用[[spell:5394]]时，你都能通过[[spell:467306]]免费施放许多，而由于[[spell:1260644]]天赋，其冷却时间缩短了。

最后，选择新的 [[spell:1312843]] 并搭配多个 [[spell:61295]] 辅助天赋，以便你能够始终让你队伍中的每个人都拥有 激流 持续治疗效果。

**请务必使用"导出天赋"按钮将此构建直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsstMmZmZmZGjZMsBbwMW0YbAMDshxMMLzMGNLLzMbmxsxixMjhlZZAAAAzMYmBgxgZA"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCUWox1NM0IVhp10qnHJaxBDwSBAjgqSkC-FMDHRIQIR9FYACDsZaprLzMJC45xC1B-AAAA-Jgko0AMowgxRmF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 恢复萨满祭司大秘境天赋构建

虽然这些是基线推荐天赋，但请随意切换到不同的功能性天赋，以适应你的队伍组合、目标地下城和当前每周词缀。

这些天赋的核心思路是为你提供较高的基础治疗量和实用性，包括选择[[spell:378443]]以获得额外的被动伤害输出，这与[[spell:73920]]为先知带来的生活质量提升以及第2赛季套装加成相得益彰。[[spell:207401]]也是一个极佳的天赋选择，可以降低爆发性伤害对队友的影响。

[[spell:462443]] 和 [[spell:462440]] 之间的选择取决于你规划的大秘境路线是否需要你比每3分钟更频繁地使用升腾，但默认情况下，卓越与我们也点出的 [[spell:378270]] 有更好的协同效应。

[[spell:73685]] 可以让一位先祖几乎永久存在，是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知流派中的必点天赋，由于拥有更强的[[spell:77472]]施放（配合[[spell:443447]]和[[spell:1270447]]），这些流派通常拥有更好的群体治疗和单体治疗能力。

最后，由于[[spell:61295]]的持续治疗效果在第2赛季得到了大幅加强，尽可能让尽可能多的队友保持其高覆盖率将变得非常重要，这使得[[spell:382039]]不如[[spell:382732]]理想。

**请务必使用"导出天赋"按钮将此构建直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZmltlxMzMzMzYMjxiZWgBMgZhJwYhZMDzyMjRzyyMzmZMbsYMz8ADLzyAAAAMDAmZYMYG"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCUWox1NM0IVhp10qnHZxBDwSBAjgSk+pC-FMDHRIQIR9FYACDsZaprLzMJ65xC1hD-AAAA-GcgohRIABgxShC-
```

:::

### 大秘境功能天赋详情

2.3.

#### 恢复萨满祭司大秘境功能天赋详情

恢复萨满祭司通过治疗、伤害和其他额外效果为队伍提供支持，例如驱散和控制，详情如下：

- [[spell:77130]] 在8秒冷却时间内移除友方目标身上所有魔法效果（点出天赋后还包括诅咒）。这通常能让被净化的队友在原本致命的情况下存活，并且通常会降低该队友承受的伤害
- [[spell:370]] 移除敌人目标身上的一个增益魔法效果。这在大秘境中非常有用，因为有很多敌人拥有非常强大的魔法增益效果，我们可以立即移除
- [[spell:57994]] 是治疗者唯一的打断技能，在30秒冷却时间内阻止被中断的法术系别施法4秒。由于可打断的敌人施法往往是你在大秘境中会面对的最危险的技能之一，你应该尽可能多地打断敌人，优先处理最危险的施法/近战队友难以打断的远程敌人
- [[spell:192058]] 允许你放置一个最远30码外的图腾，放置2秒后爆炸，在16码直径范围内眩晕一群敌人3秒，冷却时间1分钟。面对危险的怪物群时，3秒很容易成为胜负的关键
- [[spell:51485]] 和 [[spell:2484]] 允许你定身/减速区域内的敌人。每当你的队伍需要控制强大的敌人时，这都非常有用
- [[spell:8143]] 在你脚下放置一个图腾，定期移除30码内盟友身上的恐惧、魅惑和睡眠效果。持续10秒，冷却时间1分钟。每当敌人对你的队伍施放恐惧、魅惑或睡眠效果时，应使用此技能
- [[spell:51514]] 使一个非首领的人形或野兽敌人瘫痪1分钟。这让你可以在一波怪物前禁用特别强大的敌人。
- [[spell:198103]] 召唤一个拥有大量生命值和良好非首领坦克能力的元素——它的嘲讽对首领无效——持续1分钟，冷却时间5分钟。它可用于小幅提升DPS，或作为能够牵制危险非首领敌人的紧急冷却技能。它也可以被转化为强大的个人防御技能，因为配合 [[spell:1279819]] 它能为你提供15%的额外最大生命值

1.

### 地下城天赋切换速查表

为了快速参考你的可选 恢复 功能天赋的额外用途，请使用下方工具选择一个地下城。下方会突出显示相关的选择以及它们用于应对的内容。

<table>&#10;<tr>&#10;<th colspan="2" style="text-align: center">地下城</th>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></td>&#10;</tr>&#10;</table>

基于以上选择，你应该使用以下职业天赋：

- **适用条件：毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；塞塔里斯神庙（启用）。** [[spell:383016]]
- **适用条件：诸王之眠（启用）；塞塔里斯神庙（启用）。** [[spell:51485]]
- **适用条件：毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；红玉新生法池（启用）。** [[spell:462820]]
- **适用条件：毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；密谋小径（启用）；塞塔里斯神庙（启用）；Blinding Vale（启用）；虚空之痕竞技场（启用）。** [[spell:383013]]
- **适用条件：纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）；塞塔里斯神庙（启用）；Blinding Vale（启用）。** [[spell:370]]
- **适用条件：纳洛拉克的洞穴（启用）；Blinding Vale（启用）。** [[spell:58875]]
- **适用条件：毒牙祭坛（启用）；纳洛拉克的洞穴（启用）。** [[spell:378075]]
- **适用条件：密谋小径（启用）。** [[spell:8143]]
- **适用条件：毒牙祭坛（启用）。**
  
  
  
  
  - 使用[[spell:383013]]驱散[[spell:1307567]]
    **乌拉特克的选民**。请注意，如果可能的话，你应该并且可以打断这个施法。
  - 使用 [[spell:192077]] 配合 [[spell:462820]] 移除由其施加的 [[spell:1294569]] **双牙劫掠者**。你也可以使用 [[spell:378075]] 或 [[spell:58875]] 将其从自己身上移除。
  - 使用 [[spell:383016]] 驱散 **诅咒之骨** debuff，这些debuff来自散布在地下城中的骨堆，会在短时间内增加敌人承受的伤害。
- **适用条件：纳洛拉克的洞穴（启用）。**
  
  
  
  
  - 使用 [[spell:58875]] 摆脱由其施加的 [[spell:1241463]]
    **天神下凡之决心**.
  - 使用 [[spell:383016]] 驱散由...造成的 [[spell:1238801]] **饥饿之灵**'s **饥荒雕像**.
  - 在期间使用 [[spell:383013]] 移除 [[spell:1234846]] **囤宝狂人** 首领战斗中。
  - 使用 [[spell:370]] 移除其使用的 [[spell:1297696]] **低语大地看守者**。请注意，如果可能的话，你应该并且可以打断这个施法。
  - 使用 [[spell:192077]] 配合 [[spell:462820]] 驱散由其施加的 [[spell:1309919]] **严寒槌手**。请注意，如果可能的话，你应该并且可以打断这个施法。你也可以使用 [[spell:378075]] 或 [[spell:58875]] 将其从自己身上移除。
- **适用条件：诸王之眠（启用）。**
  
  
  
  
  - 使用 [[spell:370]] 移除由其造成的“精神控制”效果 [[spell:270920]] **瓦希女王** 在 **殓尸者姆沁巴**.
  - 使用 [[spell:370]] 移除其施放的 [[spell:270901]]
    **总管姆巴拉** 在 **殓尸者姆沁巴**.
  - 使用 [[spell:51485]] 定身并减速 **活化金币** 这样它们在期间就不会到达首领 **黄金风蛇** 首领战斗中。
  - 使用 [[spell:383016]] 驱散由...施放的 [[spell:269972]]
    **暗影之裔巫医** 以及其施放的 [[spell:270492]] **幽灵妖术 妖术 牧师**。注意，这两个都是你应该在可能时打断的施法。
- **适用条件：密谋小径（启用）。**
  
  
  
  
  - 使用 [[spell:383016]] 驱散由...施放的 [[spell:1217973]] **堕落的 术士**
  - 在与的首场首领战中使用 [[spell:383013]] 移除 [[spell:474515]] **赞恩·刃悲**
  - 使用 [[spell:8143]] 移除其引导的 [[spell:1201554]]
    **魅惑萨亚德**.
- **适用条件：红玉新生法池（启用）。**
  
  
  
  
  - 你可以使用 [[spell:370]] 从身上移除 [[spell:373973]] **Primalist Flamedancer** 以终结它们，或从 [[spell:391031]] 中移除
    **原始雷云**.
  - 如有必要，可使用 [[spell:192077]] 配合 [[spell:462820]] 来移除由...施加的若干层 [[spell:373803]] **灌能雏龙** 以防止 [[spell:373593]] 的发生。
- **适用条件：塞塔里斯神庙（启用）。**
  
  
  
  
  - 用 [[spell:370]] 驱散 [[spell:1310739]] **躁动的云雾**
    在第三个首领前发现的敌人身上。
  - [[spell:51485]] 可用于防止 **Faithless Tormentor** 在 **塞塔里斯的化身** 最终首领战斗。
  - 使用 [[spell:383013]] 移除由...造成的 [[spell:267027]] **Venomous Ophidian** 在第二场首领战期间 **米利克萨**。请注意，在可能的情况下，这应该改为打断。
  - 使用 [[spell:383016]] 驱散由...施加的 [[spell:1293307]] **无信者看护者**。请注意，在可能的情况下，这应该改为打断。
- **适用条件：Blinding Vale（启用）。**
  
  
  
  
  - 在第二场首领战中使用 [[spell:58875]] 移除 [[spell:1236658]] **圣光猎手伊库兹**.
  - 使用 [[spell:383013]] 移除由...造成的 [[spell:1250937]]
    **土豆蟾蜍女族长**.
  - 用 [[spell:370]] 驱散来自...的 [[spell:1238581]] **尖刺甲虫**.
- **适用条件：虚空之痕竞技场（启用）。**
  
  
  
  
  - 在第二场首领战中使用 [[spell:383013]] 移除 [[spell:1226120]] **阿特洛苏斯**.

1.

### 应对词缀

本节包含针对当前大秘境地下城各种词缀的 萨满祭司 专属应对技巧。

在达到12层及以上大秘境后，确保不要随意使用 [[spell:20608]]，因为死亡惩罚大幅增加至15秒，多次死亡将受到严重惩罚！

### 词缀：升腾

4.1.

#### 恢复萨满祭司的主宰者词缀应对

萨满拥有许多应对该词缀的工具：

- [[spell:57994]]
- [[spell:370]]
- [[spell:192058]]，如果点出 [[spell:265046]] 则可更频繁地使用

### 词缀：脉冲星

4.2.

#### 恢复萨满祭司的脉冲星词缀应对

位移工具非常适合帮助吸收队伍的 [[spell:1216858]]：

- [[spell:192077]] 来帮助你的整个团队分担它们
- [[spell:79206]] 这样你就能持续施法并从 [[spell:192088]] 获得移动速度
- [[spell:192063]] 或 [[spell:58875]]
- [[spell:2645]] 尤其是配合 [[spell:378075]]。如果你真的需要，[[spell:382215]] 可以让你跑得更快

### 词缀：虚缚

4.3.

#### 恢复 萨满祭司 的虚空词缀应对

虽然你在应对虚空词缀方面的作用有限，但请务必 [[spell:188389]] 并在 虚空大使 激活期间优先对其造成伤害！

### 词缀：吞噬

4.4.

#### 恢复 萨满祭司 的吞噬词缀应对

[[spell:383013]] 会自行移除所有 [[spell:440313]] 减益效果，如果需要，你可以用 [[spell:108285]] 获得第二个。

或者，你也可以直接用治疗扛过这个减益效果，因为它并非治疗吸收效果，目标在受影响期间你仍然可以完全治疗他们，剩余的减益效果可以由你的 [[spell:51886]] 轻松移除。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月1日：** 更新了每个第二赛季地下城的推荐功能性天赋速查表。
- **2026年8月10日：** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月19日：** 将大秘境天赋建议更新为 图腾祭司。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月30日：** 更新了功能性速查表。
- **2026年3月16日：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 12.0.1 补丁更新和天赋建议调整。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月23日：** 新的功能性速查表图片，包含根须图腾和更清晰的标示。
- **2025年3月3日：** 小规模清理。
- **2025 年 3 月 2 日：** 添加了所有地下城的功能性速查表图片和提示。
- **2025 年 2 月 24 日：** 更新了 11.1 补丁的变更。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对 11.0.5 补丁进行了更新，添加了每个地下城天赋调整的新章节。
- **2024年9月9日：** 添加了应对新大秘境词缀的提示。
- **2024年8月25日：** 根据首次全面模拟更新了更多饰品排名。
- **2024年8月23日：** 已添加第1赛季大秘境功能表。
- **2024年8月22日：** 已为《地心之战》上线进行更新。
- **2024年7月22日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年5月1日：** 已更新大秘境功能图表。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年2月10日：** 修正了风剪说明中的笔误。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月24日：** 更新并添加了每个副本功能用途的大图点击版本。
- **2023年11月15日：** 添加了关于如何为每个副本配置功能天赋的图片。
- **2023年11月9日：** 笔误修正。
- **2023年11月6日：** 为10.2补丁添加了新的天赋构建和新的赛季信息。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月31日：** 已根据当前第2赛季地下城环境调整天赋。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月6日：** 添加了雷鸣之爪作为应对缠绕的手段。
- **2023年5月1日：** 针对巨龙时代第二赛季（10.1.0版本）更新了新天赋、词缀和提示。
- **2023年3月20日：** 为10.0.7版本更新了天赋。
- **2023年3月10日：** 现在云涌图腾是默认推荐。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月13日：** 更改了天赋构筑以包含酸雨。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页面中，你将找到许多有用的宏和插件，让你在魔兽世界12.1.5版本中游玩你的 恢复 萨满祭司 时更加轻松。

1.

### 最佳宏

欢迎来到我们的插件和宏页面。在这里，我们将介绍一些实用的插件，帮助你通过更丰富的界面信息提升游戏体验，同时提供一些常用的 恢复 萨满祭司 宏。你只需点击每个代码块上的"复制"按钮即可导入它们。

1.1.

#### 动态鼠标悬停宏

这种宏可以根据你的鼠标指针是否悬停在友方目标上来施放不同的法术，当你需要减少治疗和输出所用的按键总数时，这会很有帮助。

#### 动态鼠标悬停宏

```wow-macro
#showtooltip
/cast [@mouseover,nodead,help] 治疗链; 烈焰震击
```

1.2.

#### 简单鼠标悬停宏

对于你所有的直接治疗法术（[[spell:77472]]、[[spell:8004]]、[[spell:61295]] 和 [[spell:1064]]），我们建议你使用类似这样的鼠标悬停宏：

#### 简单鼠标悬停宏

```wow-macro
#showtooltip
/cast [@mouseover] 治疗波
```

1.3.

#### 天赋条件宏

你也可以制作根据所选天赋施放不同法术的宏：

#### 天赋条件宏

```wow-macro
#showtooltip
/cast [known:生命释放] 生命释放; 治疗之泉图腾
```

有了这个宏，即使你临时调整天赋，也总能把相关法术放在最好的按键位置上。

1.4.

#### 治疗之雨 鼠标指向施放

这个宏会将 治疗之雨 直接放置在你的鼠标指针位置，而不是弹出绿色的目标选取圈。

#### 治疗之雨 鼠标指向施放宏

```wow-macro
#showtooltip
/cast [@cursor] 治疗之雨
```

1.5.

#### 风剪

#### 焦点打断

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] 风剪
```

这个宏会停止你当前的施法，并对你的焦点目标施放[[spell:57994]]（如果焦点目标存在），否则会对你的目标施放。

1.6.

#### 净化术

#### 焦点驱散

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] 净化术
```

这个宏会停止你当前的施法，并对你的焦点目标施放[[spell:370]]（如果焦点目标存在），否则会对你的目标施放。

1.7.

#### 狂风图腾

有两种选择可用，允许你立即在脚下施放[[spell:192077]]：

在脚下施放狂奔

#showtooltip /stopcasting /cast [@player] 狂风图腾

或者在你当前光标位置施放：

在光标处施放狂奔

#showtooltip /stopcasting /cast [@cursor] 狂风图腾

这些宏省去了一次点击，让你能比平时更快地激活图腾，从而快速获得移动速度加成。

1.

## 最佳插件

常见问题：我应该使用哪种团队框架？

Ellesmere UI 提供易于自定义的团队框架且性能良好，是目前推荐的方案。另外，随着 至暗之夜 的界面改动，使用默认界面变得前所未有地可行，尤其是当你使用 Harreks Advanced Raid Frames 来启用更好的持续治疗自定义功能时。

2.1.

### 替代团队框架

对于治疗者来说，团队框架是一个非常个人的选择。虽然 [Ellesmere UI](<https://www.curseforge.com/wow/addons/ellesmereui>)
是目前的最佳选择，但使用默认界面也同样可行，尤其是与以下插件搭配使用时 [Harreks高级团队框架](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>)
来进行持续治疗自定义。

2.2.

### 团队增益与消耗品追踪

使用类似以下的插件 [Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
和/或 [Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) 来按场次为重要的敌人技能和你自己的治疗冷却时间启用音频警告。你也可以用它们在开怪前追踪团队的消耗品和增益状态，以及创建、分发或接收书面团队笔记，这些笔记通常包含你所面对的首领的重要分配安排。

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.3.

### Ellesmere UI

[Ellesmere UI](<https://www.curseforge.com/wow/addons/ellesmereui>)
是默认用户界面的完全替代品，你经常会发现世界上最好的玩家都在使用它，因为它易于自定义且性能良好。它已经配备了几乎所有你需要的东西：单位框架、团队框架、增益和减益效果等等。你可以通过直观的图形界面轻松解锁、配置和拖动所有组件，让你的游戏界面完全按照你想要的样子呈现。

2.4.

### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.4.1.

#### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.4.2.

#### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.4.3.

#### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.5.

### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.5.1.

#### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.5.2.

#### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.6.

### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是一个用于自定义伤害和治疗统计面板的不错选择。虽然由于 暴风雪 施加的限制，它可能不再提供以前那么多的追踪选项，但它仍然存在并活跃着，帮助你自定义 暴风雪 的伤害、治疗和其他数据面板。

1.

## 更新日志

- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对 至暗之夜 第二赛季上线进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第一赛季上线进行了更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月29日：** 添加了先祖追踪弱光环。
- **2024年8月23日：** 为《地心之战》添加了更多WeakAuras。
- **2024年8月21日：** 已为《地心之战》上线进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月18日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年4月30日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 添加了两个额外的WA字符串以支持10.0.7的新游戏风格。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少
