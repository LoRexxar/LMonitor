## 专精概览

Welcome to our Enhancement Shaman guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as an Enhancement Shaman in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Enhancement Mythic+ Resources

[NEW! Top Enhancement Talent Builds](<https://raider.io/specs/enhancement-shaman/talents>)

[Top Enhancement Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/shaman/enhancement>)

[Enhancement Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=shaman--enhancement>)

[Popular Enhancement Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=shaman--enhancement>)

1.

### Enhancement Shaman Overview

Enhancement is the melee specialization for Shaman, with a heavy emphasis on
both Physical attacks and Elemental spells, weaving both together in a fast-paced
"battle-mage" combat style using a variety of enhancing effects.

The gameplay is built around juggling ability cooldowns and proc management,
centering on a unique pseudo-resource in [[spell:187880]] to fuel spell
casts. It excels in cleave scenarios, with a variety of build options available
for both hero trees. Lastly, as a Shaman, it provides both [[spell:2825]] and
the [[spell:462854]] group buff.

2.

### Enhancement Shaman Performance Breakdown

Like with any spec, Enhancement has some strengths and weaknesses. Below we've
evaluated it based on some key categories, covering its performance in endgame
content:

**Flexible Damage Delivery**

In Season 2 of Midnight, Enhancement still retains a versatile toolset when it
comes to damage. It has to sacrifice very little single-target to enable AoE,
while also bringing cleave for free in all situations. It also comes with very
strong cooldown windows for burst, though its flexibility when it comes to timers
is limited. It still doesn't shine especially bright in any specific scenario,
but the ability to contribute to almost any encounter style makes it a good
all-round pick in most compositions.

**Strong Burst & Cleave**

With the dominant Hero Talent switching to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer in Season 2,
it still retains extremely good cleave - something very relevant in The Venomous
Abyss. It was also far less impacted by cooldown nerfs than most specs, meaning
damage dealt during [[spell:114051]] is extremely high. Its ability
to deliver explosive front-loaded burst while also having constant cleave available
for most of the encounters that require it makes it a solid melee pick for
Season 2. Its biggest downside though is its huge swings in RNG due to [[spell:384352]]
procs, which hurts its potential in particular on the final two encounters.

**Good Burst and Flexible Damage**

Similar to Raid situations, Enhancement brings a very flexible suite of damage
profiles in one package in Mythic+. While ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer is somewhat
reliant on its [[spell:114051]] for <em>reliable</em> burst, the
consistent cleave provided by its base toolkit alongside [[spell:384352]] and
[[spell:454009]] procs gives it the opportunity to shine even when timers don't
line up - provided you have some RNG. The Season 2 tier set also adds in some
extra priority damage, lifting up one of its weaker aspects in Midnight.
This alongside its tuning positioned around being a specialist at mid-level target
counts gives it a solid place.

**Some Flexible Tools**

Midnight significantly reduced Enhancement's access to control tools, limiting
one of its previously best features with nothing to replace it. Season 2 does
nothing to really improve this, though the increased volume of Poison effects does
raise the value of [[spell:383013]]. It still brings a good variety
of nice-to-have tools, but most are also covered by other specializations in a more
convenient way. It does, however, still bring one of the strongest group buffs,
[[spell:462854]], alongside being a source of [[spell:2825]].

**Decent Passive Defense**

Defensively, Enhancement is quite robust when it comes to passive defense, but
can stumble if active tools are required. Through [[spell:381689]],
[[spell:381650]], and an emergency heal with [[spell:30884]],
baseline survival is high against most standard mechanics. Active tools on the other
hand have much longer cooldowns compared to the field, and while [[spell:108271]]
is very potent, the 1m30s cooldown can be a limitation in higher end content.
[[spell:198103]] provides a backup every 3 minutes, but isn't reliable
considering the lengthy cooldown. Lastly, it does have some passive self-healing with
[[spell:1217622]] making [[spell:974]] permanent, and active
options through [[spell:384143]] casts, making it fairly resilient
to rot damage.

**High Mobility**

Enhancement's movement toolkit remains extremely versatile in Midnight, allowing
it to keep up with the fast pace in melee. [[spell:196884]] helps it stick to
its target, while [[spell:58875]] provides root clears and a sprint and is a
regular pickup - though [[spell:192063]] is an option for knockback cancelling.
[[spell:2645]] is also always available, suppressing slows while active and
giving it the extra boost to get out of most situations, once you're used to
shifting in and out.

3.

### Enhancement Shaman in Midnight

### **Season 2**   Changes

3.1.

#### Midnight Patch 12.1.5 Content Guides

While Patch 12.1.5 brings no significant changes to Enhancement itself, it did
recently receive hotfixes to increase its damage across the board. It also
features new endgame PvE content for you to dive into. Raid groups can take on
[Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) in a new single encounter instance to claim powerful loot, while
[Delves](<https://www.icy-veins.com/wow/delves-guide>) introduce the first Mega-Delve Labyrinth for you to explore! Make
sure to check out information on both new additions below.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

3.2.

#### Patch 12.1.5 Changes

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) acts as an escalation to the progression of Season 2 in
Midnight, with the story surrounding Ula'tek and the Amani culminating in a new one-boss
raid, access to ascended item levels, multiple sources of catch up gear,
and access to an infinite number of Mistcrests to upgrade it. Make sure to check out our
patch hub for all the information on what is new, or has been updated with Patch 12.1.5.

3.3.

#### Class Changes

Very little has changed for Enhancement going into Patch 12.1.5; however, a small
bugfix alongside damage tuning applied right before the patch is nice to see:

[12.1.5 Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24304162>)

**Enhancement Shaman**

- Fixed an issue where [[spell:384411]] could stop generating
  	  [[spell:187880]] when [[spell:384352]] triggers overlap.

**6th October Class Tuning**

<em>Developers’ notes: We’re aiming to increase Enhancement Shaman’s
	  throughput all around as they have been underperforming this season, while
	  additionally increasing Lava Lash’s contribution to its overall breakdown.</em>

- All ability and auto-attack damage increased by 4%. Does not affect PvP combat.
- [[spell:60103]] damage increased by 35%. Does not affect PvP combat.

The bugfix is only relevant for situations where [[spell:384352]] procs overlap,
but is nice to remove some of the downsides when this happens. That said, it does
little to alleviate how much of a problem this lack of control has, nor mitigate
the downsides of badly timed activations.

The aura buffs on the other hand are good, if a little late. The buff to [[spell:60103]]
does bring ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic a little out of the hole it's found itself in, but
it still remains a weaker choice in all situations when compared to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer.
Despite its significant buff, it also doesn't have any impact on the rotation
priority.

3.4.

#### Midnight Season 2 Content Guides

Midnight Season 2 is still ongoing, with challenging raid bosses to defeat in
The Venomous Abyss, dungeons to conquer in Mythic+, and rivals to defeat in PvP.
We have dedicated hubs for each linked below!

[Season 2 Raid](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

[Season 2 Mythic+](<https://www.icy-veins.com/wow/midnight-mythic-season-2-guide>)

[Season 2 PvP](<https://www.icy-veins.com/wow/midnight-pvp-season-2-guide>)

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_stormstrike.jpg>) Click for Previous Season 2 Changes
3.5.

#### Patch 12.1 Enhancement Changes

While Season 2 brought some fairly significant changes to many specializations,
Enhancement instead had some more targeted tuning to shift around its damage
profile:

[Curse of Ula'tek Development Notes](<https://us.forums.blizzard.com/en/wow/t/midnight-curse-of-ulatek-ptr-development-notes/2317811>)

**Enhancement Shaman**

<em>Developers’ notes: We’re happy with Enhancement Shaman’s gameplay going
	into Curse of Ula’tek. Our goal with these changes is to preserve that
	gameplay while improving performance outside of cooldown windows, where damage
	can feel weak. Strong interactions between Windfury procs and Maelstrom Weapon
	generation were making it difficult for the downtime between cooldowns to
	breathe.</em>

- [[spell:974]], [[spell:5394]] and [[spell:8004]]
  	  healing increased by 25%.
  
  - <em>Note: this is to offset the increase to players' base health in 12.1.</em>
- [[spell:188196]] & [[spell:188443]] damage increased by 20%.
- [[spell:17364]] & [[spell:60103]] damage increased by 15%.
- Melee auto-attack damage increased by 15%.
- [[spell:384352]] now increases the chance for [[spell:33757]]
  	  to trigger by 50% (down from 100%).
- **Stormbringer**
  
  - [[spell:454009]] primary target damage reduced by 10%.
  - [[spell:454009]] secondary target damage reduced by 30%.
- **Totemic**
  
  - [[spell:444995]] Tremor damage reduced by 15%.
  - [[spell:445025]] Surging Bolt damage reduced by 10%.
- **18th August –** All damage increased by 5%.

These changes, alongside the new Tier Set introduced, push further in the
direction of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer in Season 2. Although some power was taken out
of [[spell:454009]], the power gained elsewhere is higher, and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer's
cooldown potency was reduced less than its counterpart. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic is still
capable of performing, but its explosive [[spell:444995]] windows were hurt
more than the consistent damage was improved, causing it to fall slightly
behind.

All in all though, these changes are a net buff, and we'll be stronger heading
into Season 2 as a whole compared to the start of Midnight. When combined with
some of the powerful new gear on offer, and a <em>much</em> better Tier Set than
Season 1, we'll be starting from a good spot, especially with the added 5% aura
buff that came with the start of the season.

:::

### Midnight   Changes Overview

3.6.

#### Enhancement Shaman Changes in Midnight

Midnight brought with it an enormous overhaul to Enhancement, significantly
changing its gameplay and resource economy. These changes make things less hectic,
providing a clearer goal within the rotation, but should feel familiar to anyone
who has played Enhancement in recent years. A clearer emphasis has been placed on
melee strikes, and linking [[spell:187880]] management to different
effects outside of just damage. Since this impacts every aspect of the playstyle,
changes are broken down into sections below.

3.6.1.

##### Rotational Changes

Midnight presents one of the biggest shake-ups to modern Enhancement in a long
time. The biggest change of note is a stronger link between melee strikes and
[[spell:187880]] using [[spell:1250364]], providing cooldown reduction.
Additionally, [[spell:187874]] now triggers its buff effect <em>regardless
of how many targets are hit</em>, bringing it into single-target as well. Some
fillers have been removed (namely [[spell:196840]] and [[spell:342240]]),
and [[spell:470057]] is now an active button instead of a proc. Our cooldown
suite has also seen significant changes, providing some alternative
timers depending on the situation.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_ancestralawakening.jpg>) Click for notes on Cooldown Changes
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_ironmaidens_swirlingvortex.jpg>) **Doom Winds**  
  
    This has seen the biggest changes, now benefiting from [[spell:384411]] and [[spell:384444]] when active. Duration is also increased by the latter to 10 seconds when taken, and has been removed from the GCD. However, bonus [[spell:33757]] chance has been reduced to 200%.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_elementaldevastation.jpg>) **Ascendance / Deeply Rooted Elements**  
  
    No longer deals damage on cast, but otherwise functions the same, now <em>replacing</em> [[spell:384352]]. Whenever [[spell:114051]] is triggered, Doom Winds is also cast for free. With the active choice node taken, also grants a 0.5% chance per [[spell:187880]] spent to trigger Doom Winds.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_feralspirit.jpg>) **Feral Spirit**  
  
    Is now a passive talent, and spawns one Nature wolf whenever you trigger [[spell:384352]], or a Fire wolf when you cast [[spell:197214]]. These provide 5% Physical and 5% Elemental damage increase for their respective school, lasting for 8 seconds.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_shaman_primordialwave.jpg>) **Primordial Wave**  
  
    Has been removed, with its effects (such as [[spell:1218047]]) instead being placed into [[spell:197214]] casts, which has moved to the bottom of the talent tree.

:::

Some tree shuffling has also been done, alongside some new talents to round
out the gameplay. [[spell:210853]] is now finally a single point for
guaranteed [[spell:187880]] generation, [[spell:319930]] is easier to
access, and [[spell:1262635]] is now the source of Maelstrom Weapon
refunds. [[spell:289874]] has been moved from the PvP tree as well, causing
all strikes to also trigger [[spell:188443]] when used, giving us a smoother
transition into cleave situations.

3.6.2.

##### Enhancement Apex Talent - Storm Unleashed

The new class feature in Midnight is Apex Talents, powerful 4-step talent nodes
that provide compounding benefits when taken. For Enhancement, [[spell:1262713]]
adds significant benefits to [[spell:187874]] casts, giving it a stronger
presence in the rotation:

- [[spell:1262713]] – each [[spell:187880]] spent has a 2%
    chance to cause your next [[spell:187874]] cast to ignore its cooldown.
    Additionally, the weapon enhancement buff can now overlap.
- [[spell:1262761]] – has two points, increasing the damage of
    [[spell:187880]] spending abilities by 7.5%, and weapon imbuement damage
    by 10% per point.
- [[spell:1252373]] – causes [[spell:187874]] to leave
    behind a static pool on the ground, dealing 100% of the initial damage dealt
    over 2 seconds. Additionally, the weapon enhancement buff increases auto-attack
    speed by 15% per stack.

The node is quite front-loaded with the first point, adding an extra proc to
react to, and elevating the value of [[spell:187874]] in the rotation. With
the added benefit of the weapon buff overlapping, it means refreshing the effect
is no longer wasting any damage, and makes gameplay a little smoother as well.

3.6.3.

##### Hero Talent Changes

As Hero Talents are a key component to Enhancement's playstyle, they saw some
of the largest changes moving into Midnight. They are now closer together in terms
of playstyle, but both are still distinct.

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) **Stormbringer Changes -** <em>Click for Details</em>
  
  
  - [[spell:454009]] now has a 2% chance to trigger per [[spell:187880]]
    	  spent.
  - [[spell:455129]] no longer deals damage, and has a 1.1 RPPM chance
    	  of triggering [[spell:454009]].
  - [[spell:454026]] now summons a wolf for 12 seconds when [[spell:384352]]
    	  is triggered, rather than on [[spell:454009]] casts.
  - [[spell:470532]] now only triggers from [[spell:188443]].
  - **Three new talents:** [[spell:1264762]], [[spell:1264691]] and
    	  [[spell:1264688]].
  
  
  
    Between the two trees, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer saw the most mechanical changes,
    and comes out the other side a bit worse for wear. [[spell:454009]] is now
    random, triggering on a percent chance when [[spell:187880]]
    is spent. [[spell:455129]] has also been changed to an RPPM proc, so
    while the rate of Tempest triggers is similar, they're
    much less predictable. Lastly, [[spell:454026]] instead summons a
    [[spell:51533]] wolf when [[spell:384352]] is activated.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) **Totemic Changes -** <em>Click for Details</em>
  
  
  - [[spell:444995]] now has a 1-minute cooldown, and lasts for 25 seconds.
  - [[spell:453406]] (triggered by [[spell:445024]]) now doubles
    	  the damage of your next [[spell:197214]] cast, and spawns a Searing Totem.
  - [[spell:467306]] now triggers a [[spell:458147]] on any
    	  [[spell:60103]] or [[spell:470057]] cast.
  - **Three new talents:** [[spell:1260644]], [[spell:1263288]] and
    	  [[spell:1260874]].
  
  
  
    In comparison, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic saw clear improvements in Midnight, with a
    direction that maps on well to other new talent updates. [[spell:444995]]
    is now positioned more as a cooldown, lining up with the [[spell:384352]]
    changes for powerful 1-minute bursts of damage. The biggest standout is the new
    talent - [[spell:1260644]] - allowing for extremely long streaks of
    [[spell:201900]] uptime. This also positions proper [[spell:187880]]
    management back into its rotation, which has been sorely missing in The War
    Within.

The result is that they keep the same distinction in preferred strike (either
[[spell:17364]] or [[spell:60103]]), while now <em>both</em> having a reason
to care about [[spell:187880]].

3.6.4.

##### Utility & Defense

Unfortunately, while the rotational changes are good, the same can't be said for
our Defense and Utility. We've lost [[spell:108270]] as an active tool,
and both [[spell:198103]]'s cooldown and duration were reduced (to 3 minutes
and 30 seconds respectively), all while removing damage reduction from
[[spell:1279819]]. We do now have permanent [[spell:974]] via
[[spell:1217622]], though self-healing isn't as potent as before.
[[spell:384149]] has had the previous PvP talent [[spell:410673]]
folded in though, reducing the cost of self-healing, and both [[spell:381689]]
and [[spell:381650]] have been buffed for more passive defense.

In the utility department, we retain the suite of niche options, but have lost
a lot of control. [[spell:381819]] (when longer double stuns are
needed), [[spell:51490]] and [[spell:378779]] are all gone, while
[[spell:197214]] no longer incapacitates targets. This severely
limits our control options, something we were previously very good at.

4.

### Basics of Enhancement Shaman Gameplay

Enhancement gameplay revolves around several loops that are often all happening
at once, creating a fast-paced gameplay experience. This is still present in Midnight,
with three general rules it follows:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_stormstrike.jpg>)  **Keep Rotational Abilities on Cooldown as Much as Possible**  
  
  [[spell:187874]] should be cast when available. [[spell:17364]] and
  [[spell:60103]] work with your [[spell:187880]] management due
  to [[spell:1250364]]. Keep these on cooldown as much as possible.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_maelstromweapon.jpg>)  **Manage Your Maelstrom Weapon Stacks**  
  
  [[spell:187880]] makes [[spell:188196]] and [[spell:188443]]
  instant when 5 or more stacks are consumed. This provides CDR through
  [[spell:1250364]]. Your goal is to avoid waste by staying below 10 stacks,
  using it to reset the cooldown of [[spell:17364]] and [[spell:60103]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_callstorm.jpg>)  **React to Each Build's Key Procs**  
  
  This adds variance to combat, and requires quick decision making. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic
  needs to react to, and extend [[spell:201900]] through [[spell:1260644]],
  while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer needs to handle [[spell:454009]] procs.

While Midnight has made the spec easier to grasp, there's still a fairly steep
learning curve when getting comfortable with the flow of Enhancement. It tends to
require understanding all of the different aspects as a whole, so when learning
each component it can feel like something's a little off. Once you have some muscle
memory built up and a feel for the flow though, it's both very rewarding and unique
when compared to many specializations.

5.

### How to Gear Up as a Enhancement Shaman

While we always recommend simming yourself for ideal results, we do provide a
dedicated Enhancement gearing page. We currently cover recommendations for
Season 2 gear to start off on the right foot when stepping into endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate
consumables, gems, and enchants to go with those new items.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5, added advanced tips for Potion otpimizing.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated to account for significant gearing changes following Season start.
- **24 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Expanded Flask and Potion section for more advanced Season 2 choices.
- **24 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Adjusted Critical Strike to be on par with Mastery for Stormbringer, and lowered Haste.
- **24 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Adjusted Folio to mention fourth rune is used to adjust lacking secondaries.
- **19 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Added disclaimer regarding uncertain gear recommendations due to Aqirbane Reliquary hotfixes.
- **19 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Switched ST import code to Supercharge due to the amount of cleave in Season 2 raids.
- **19 Aug. 2026 (this page):** Included hotfixes for Season 2 start.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7 with Sporefall gear.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7 with Omnium Folio recommendations.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **04 May 2026 (this page):** Updated for 5th May Class Tuning.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **07 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Added note regarding Catalyst Unbound in early crafting FAQ.
- **07 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Noted that recent tuning did not affect build recommendations.
- **07 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Small update to Stormbringer raid builds to adjust for higher cleave needs.
- **07 Apr. 2026 (this page):** Updated for 7th April class tuning. No changes to recommended builds.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Added note about Heirlooms in Midnight.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1 release.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Season 1 - added Teas and additional Consumables for Mythic+.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for release of Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Season 1 release.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for release of Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for release of Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for release of Midnight Season 1.
- **02 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Small update to reflect trinket tuning.
- **02 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Adjusted Flask recommendations due to stat changes.
- **02 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Update to Totemic stats due to Overcharge being dropped.
- **02 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Small adjustment to Totemic builds.
- **02 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Small update to recommended Talents.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Midnight release.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Midnight release and Pre-season.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Updated for Midnight release.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Midnight release.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Midnight release.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight release.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Midnight release.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Midnight release.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Midnight release.
- **26 Feb. 2026 (this page):** Updated for Midnight release.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for new Class Tree talent gates.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Changed build recommendation to Totemic.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Small rotational updates and shift to Totemic as Mythic+ recommendation.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Changed Mythic+ and AoE recommendation to Totemic.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Changed AoE build recommendation to Totemic, and adjusted rotation tips.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7. Small tweaks to Rotation breakdowns.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5 with Cartel Chip recommendations.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **04 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated to emphasize recommendations are with the new Tier Set.
- **28 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Added in Season 3 Talent Swap Cheat Sheet.
- **16 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated Trinket Tier List to account for tuning.
- **12 Aug. 2025 (this page):** Updated to include Season 3 Hotfix buffs.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated to account for D.I.S.C. hotfixes.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7 D.I.S.C. belt and adjusted BiS list slightly for double Gallywix weapon.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Confirmed Dinar recommendations for Turbo Boost release.
- **12 May 2025 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated following Corruption tuning.
- **12 May 2025 (this page):** Added note to highlight updated Cartel Chip and Corruption recommendations.
- **28 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Added dungeon tips.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.1.5 and added Cartel Chips section.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5, emphasized how close both trees are with recent Stormbringer buffs.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5, adjusted recommendations to highlight how close both trees are.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Shifted single target recommendation back to Stormbringer following buffs.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **16 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Shifted Totemic tree to pick up more single target comfort.
- **16 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Adjusted recommendations to more firmly be on Totemic.
- **16 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated with more universal Totemic Mythic+ talent set. Changed recommendation to Totemic across the board.
- **16 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Changed single target recommendation to Totemic.
- **15 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Updated with more relevant live info and Gallywix tips.
- **04 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Adjusted Cyrce's Circlet recommendation downward.
- **04 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Added Authority of the Depths for single target.
- **04 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Updated to account for March 4th Flowing Spirits hotfix.
- **04 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Cleaned up recommended builds to account for Flowing Spirits nerf and Season launch.
- **04 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added Witch Doctor's Ancestry back to recommendations and rotation tool.
- **04 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Adjusted all talent builds to switch away from Flowing Spirits.
- **04 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated to account for March 4th Flowing Spirits hotfix.
- **04 Mar. 2025 (this page):** Updated to account for March 4th Flowing Spirits hotfix.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated to highlight strength of new ring following hotfixes.
- **17 Dec. 2024 (this page):** Updated to highlight strength of new ring following hotfixes.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7 for Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.7, added recommendation flags.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.0.7, added recommended flags.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7, added a more detailed Thorim's Invocation section.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.7 with recommendation flags on key builds.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 11.0.7 with significantly condensed rotation section.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7
- **05 Nov. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Added Hand of Justice into single target recommendations.
- **05 Nov. 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Added Weakauras Section.
- **05 Nov. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Updated with appropriate Patch 11.0.5 talent builds for Stormbringer and Totemic.
- **05 Nov. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated with Stormbringer vs. Totemic builds, and added in gameplay tips section.
- **05 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Significant priority list updates closer to more recent 11.0.5 knowledge.
- **05 Nov. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Significant changes to recommended loadouts based on more tested 11.0.5 builds post-launch.
- **05 Nov. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated with more recent Patch 11.0.5 information.
- **05 Nov. 2024 (this page):** Updated to include more recent info alongside the number of post-11.0.5 hotfixes.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.5
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.5, will require future updates following release.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5, will require future updates following release.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** First pass update for Patch 11.0.5. Will be updated as more live data comes in.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.5, will require future updates following release.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Patch 11.0.5 rework.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 11.0.5, will need future updates following patch release.
- **21 Oct. 2024 (this page):** Updated with notes on significant 11.0.5 changes.
- **30 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Updated with appropriate builds and more recent tips for all bosses.
- **23 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for most recent hotfixes and Storm build switch.
- **23 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for most recent hotfixes and Storm build switch.
- **23 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for most recent hotfixes and Storm build switch.
- **23 Sep. 2024 (this page):** Updated for most recent hotfixes and Storm build switch.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated with Season 1 BiS lists.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Season 1 BiS lists.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Page added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for War Within Season 1 release.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Elemental Blast and Tempest hotfixes along with new Storm loadouts.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Elemental Blast and Tempest hotfixes along with new Storm loadouts.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Elemental Blast and Tempest hotfixes.
- **09 Sep. 2024 (this page):** Added note regarding tier set hotfix & undocumented change.
- **03 Sep. 2024 (this page):** Updated for Hotfix changes.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/enhancement-shaman-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/enhancement-shaman-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/enhancement-shaman-mists-of-pandaria-remix-guide>)):** Page added.
- **13 May 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Format adjustment to move slider closer to rotation.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Season 4 and Awakened gear release.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **21 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6, added note regarding Ember of Nullification.
- **21 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6, condensed insights section.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6, switched recommended build to standard Elementalist.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 10.2.5, no changes necessary.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5, added note regarding Rageheart.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5, added Earth Elemental cancel method.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5, shifted to recommendations for higher gear levels.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5, no changes necessary.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5, touched up some sections and added defensive trinkets as options.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2, slight structure changes but content remains accurate.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed and touched up for Patch 10.2.5 and mid-season updates.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Patch 10.2.5 spell school changes.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5, build remains the same.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **09 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Restructured and updated for Patch 10.2.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated to remove Sporecloak recommendation, switched Dracothyst/Shadowflame.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Patch 10.2 talent changes.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.2, no changes necessary.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated link to Mythic+ hub.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2 and restructured the rotation tool.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Patch 10.2 talent changes.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Restructured for Patch 10.1.7, information remains the same.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Some restructuring for Patch 10.1.7, added in Infurious Boots of Reprieve as a crafting option.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Restructured cooldown section, but no content changes needed for 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.7, small restructuring and added Elementalist Funnel.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **20 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Rewritten to include rotation advice.
- **20 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Added Sporecloak to crafts for high Mythic+.
- **20 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Added note about Sporecloak to gear section for key pushing.
- **14 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added build loadout buttons to switches for easier rotation display.
- **13 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Cleaned up AoE rotation section with improvements for Storm.
- **12 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Increased value for Accelerating Sandglass due to patch release update.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5 adding Dawn of the Infinite gear and cleaning up Crafting section.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.1.5 to strongly recommend against Annulet.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Patch 10.1.5 with small note about soft Haste breakpoint.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.5 with shift to Storm Cleave for Storm builds.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5 to remove 4-piece use from Storm and highlight Stormstrike over spenders.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.5 and updated Storm Cleave in recommendations.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Patch 10.1.5 changes.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **25 May 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Added section on Cataclysm Timewalking.
- **10 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated to add an even simpler build for beginners that remains competitive.
- **09 May 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated to adjust for trinket changes.
- **09 May 2023 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated to include Primordial Wave in Elementalist single target.
- **09 May 2023 (this page):** Updated to highlight boss tips additions and gear changes.
- **04 May 2023 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Tweaks to rotation tool, added warnings to false talent combinations.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1 and Season 2 release with new gear recommendations.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.1 and new consumables.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for 10.1 with adjusted notes about Storm build and Haste for Elementalist.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1 and new Season 2 builds, alongside initial Tier set opener.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Overhauled for Patch 10.1 updates, with Storm builds, rotation tool updates, T30 bonuses and added sections.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Fully updated for Patch 10.1 with revised new builds. Physical builds converted to Storm.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Patch 10.1 changes.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Patch 10.1 with a more beginner friendly build, and revised starter rotation.
- **01 May 2023 (this page):** Updated for Patch 10.1 changes, added new highlight sections and expected performance.
- **29 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.1, no changes necessary.
- **24 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Primordial Gemstones hotfixes.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Primordial Stones hotfixes.
- **22 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Patch 10.0.7.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated to account for Primordial Stones buff.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/enhancement-shaman-best-legendaries-shadowlands>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.0.7 with Onyx Annulet recommendations.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Added more commonly used macros, and reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed and added small improvements for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed and updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for new Patch 10.0.7 class tree.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7 changes.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and improved rotation tool to align closer to current gameplay.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed and Updated for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Updated for Patch 10.0.5.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added Tier Set section.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/enhancement-shaman-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/enhancement-shaman-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/enhancement-shaman-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/enhancement-shaman-patch-9-2-changes-analysis>)):** Cleaned up for Patch 9.2 release.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/enhancement-shaman-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/enhancement-shaman-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **17 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/enhancement-shaman-patch-9-1-changes-analysis>)):** Page created with initial information.
- **13 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **25 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-the-eternal-palace-raid-guide>)):** Updated for all bosses.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **01 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-crucible-of-storms-raid-guide>)):** Updated with notes for each boss.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **28 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added Enhancement Shaman tips for Battle of Dazar'alor.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-uldir-raid-guide>)):** Preliminary update for Uldir launch week.
- **11 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-uldir-raid-guide>)):** Page created in preparation for the eventual Uldir release.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Enhancement Shaman leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Shaman leveling guide](<https://www.icy-veins.com/wow/shaman-leveling-guide>).

1.

### Enhancement Shaman Leveling Guide for Midnight

Welcome to our Enhancement Shaman Leveling Guide for
Midnight! This will help you in your journey to max level,
covering talents and abilities you should know about.

Enhancement Shaman is very flexible when leveling, being suited to
questing due to its extremely high mobility and ability to handle large pulls, using
its self-healing to stay healthy. With big, versatile cooldowns such as
[[spell:2825]] and [[spell:198103]], it also has no problem dealing
with particularly dangerous elites either. It picks up AoE tools very early,
suiting it well to dungeons as early as level 15, though you may find your queues
go faster if you do so as Restoration to heal instead.

1.1.

#### Leveling Gear Options

When leveling up, you should always choose the piece of loot with the highest
item level. You will often be replacing these gear pieces very quickly, so just
equip whatever comes to you without worrying about secondary stats.

Heirloom items can be purchased for your alts, increasing in item-level as you
level up. If you have access to these, generally aim for a mix of Haste and
Versatility. These will smooth out the rotation, and provide more durability when
pulling groups of enemies.

1.2.

#### Useful Leveling Consumables for Midnight

If you're looking for that extra boost to get through Midnight leveling and
catch up to endgame, there's a handful of items and enchants that can help speed
things up.

- [[item:191348]] — A Phial from [Dragonflight](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  which persists through death, giving bonus Speed for 30 minutes. If you're already
  geared, it's often about moving between pulls rather than a bit more damage.
- [[item:225592]] — A food item from [The War Within](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>),
  grants a large boost to Speed for 1 hour.
- [[item:213746]] — If your gear has sockets, switch
  to this Algari Diamond for extra speed.
- [[item:223653]] / [[item:223683]] / [[item:223725]] / [[item:223800]] —
  Switch all of your armor enchants over to extra Speed effects if you were previously
  using Avoidance or Leech.
- [[item:132516]] — A tried and true pickup for leveling, these are always
  nice to have to get through areas where you can't mount, and even work across water.
  These <em>can't</em> be activated while in combat though, and are cancelled when
  taking damage.
- [[item:154168]] / [[item:154169]] — These
  consumables from Battle for Azeroth help with sections that involve going
  underwater - though in Midnight's zones that doesn't happen very often.
- [[item:109076]] — These can mitigate fall damage if you end up
  getting dismounted or need to get down from somewhere high, so are great for
  emergencies.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point allocation of the below 
tree once you start gaining levels in Midnight.

:::talents Enhancement Leveling - Level 80 Starting Talents
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMDjZmZmZmhZmZAAAAAAAAAsBgZMsBgZANYBgZZGzYssMDMzswiZmZYsMmBAYGGzMMCMzgBDA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMDjZmZmZmhZmZAAAAAAAAA2AsYGDbwGMDDNYBgZZGzYssMDMzswiZmZGjlxMAAzwYmhZCMzgBjB"
}
```
:::

:::details 来源计算器编码
```
#HE-DBQaUEppxdptIbbqEkprjiggxCUARSmjeep-CDZBOEXWQHNcRMgdVAjYSLPKKJheibB-AAAA-OIOEoYI0wsAApI-
```

:::

2.1.

#### War Mode Talents for Leveling

If you are willing to take the risk and
utilize War Mode, the following PvP talents are recommended during leveling
or for other open-world content. There may be times when you would like
to use other options and are encouraged to experiment! PvP talents can
be freely changed at any time.

Your first PvP talent slot will unlock at Level
20, your second at Level 30, and the final at Level 40.

- **Level 20:** [[spell:204331]] lets you pull
  aggressively and deal the damage back to enemies, using your own Health
  as a resource!
- **Level 30:** [[spell:409293]] is a good option as an
  extra movement and opening burst tool, and can also be used as emergency survival.
- **Level 40**: [[spell:305483]] grants an extra
  stun against dangerous enemies, and a little extra damage while channelling. There's
  not a lot of good options early on though so might as well pick this up while we
  wait to gain access to [[spell:193876]] at Level 48.
- **Level 48+:** [[spell:193876]] unlocks when we
  gain [[spell:2825]] at 48, and reduces its cooldown to a mere minute, giving us
  a much more frequent burst window.

3.

### Leveling Rotation

To help with understanding what changes as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 71 起：**After reaching level 71 and unlocking Hero Talents, we
recommend playing with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer to gain access to [[spell:454009]].
The import code above will provide you with a build ready to get started with
Midnight content.

3.1.

#### Key Concepts

As you level and populate the talent tree, Enhancement will progressively have
more unique mechanics outside of its rotation to bear in mind. This section will
grow alongside the slider with each level.

- **Remember to Recuperate!** - Whenever you're low on health between pulls,
  you can use the [[spell:1231418]] ability available to all classes to
  quickly recover.
- **等级 1–9：****Reach Level 10 First** - Due to Enhancement only
  being unlocked as a talent specialization at Level 10, you should use the
  abilities provided to you in the intro quests until you are presented with the
  option.
- **等级 10 起：****Understand Maelstrom Weapon** - It's important to
  learn early that you should only ever commit to casting spells when at 5 stacks
  of [[spell:187880]] or above, making them instant. Stacks are spent on
  [[spell:188196]] in single-target, and [[spell:188443]] in AoE.
- **等级 13–18：****Always be Imbued!** - A core part of the
  Enhancement toolkit are weapon imbues. Make sure to have [[spell:318038]]
  applied at all times.
- **等级 19–59：****Always be Imbued!** - A core part of the
  Enhancement toolkit are weapon imbues. Make sure to have [[spell:318038]]
  and [[spell:33757]] applied at all times. These spells will naturally
  cast onto the appropriate weapon in your main and off-hand.
- **等级 60 起：****Always be Imbued!** - A core part of the
  Enhancement toolkit are weapon imbues. Make sure to have [[spell:318038]]
  and [[spell:33757]] applied at all times. [[spell:192106]] will
  automatically apply these through [[spell:1270350]].
- **等级 16 起：****Don't forget Buffs!** - Keep yourself buffed with
  [[spell:462854]] for the additional Mastery and auto-attack procs. Remember to
  recast this every 60 minutes, or if you enter a dungeon with new party members.
- **等级 10–17：****Use your Shield** - Make sure to keep
  [[spell:192106]] active at all times for the extra [[spell:187880]]
  and damage when being struck.
- **等级 18–59：****Use your Shields** - Make sure to keep
  [[spell:192106]] active at all times for the extra [[spell:187880]]
  and damage when being struck. Also, thanks to [[spell:383010]], you can
  keep [[spell:974]] active at the same time for additional healing.
- **等级 60 起：****Use your Shields** - Make sure to keep
  [[spell:192106]] active at all times for the extra [[spell:187880]]
  and damage when being struck. [[spell:1270350]] will also apply
  [[spell:974]], which is permanent via [[spell:1217622]]. Refresh
  this every hour.

3.2.

#### Dynamic Priority List

Below is a sample priority list to keep track of which abilities to press.

1. **等级 1–30：**Cast [[spell:188389]] when engaging enemies.
2. **等级 31 起：**Cast [[spell:470057]] when engaging enemies.
3. **等级 71 起：**Cast [[spell:454009]] with charges available and 10 [[spell:187880]].
4. **等级 55 起：**Cast [[spell:384352]] on cooldown, ideally against elites and large groups of enemies.
5. **等级 10–44：**Cast [[spell:188196]] if at 5+ stacks of [[spell:187880]]. Switch to [[spell:188443]] in AoE.
6. **等级 45 起：**Cast [[spell:188196]] if at 10 stacks of [[spell:187880]]. Switch to [[spell:188443]] in AoE.
7. **等级 1–9：**Cast [[spell:73899]].
8. **等级 15–80：**Cast [[spell:187874]] on cooldown.
9. **等级 81 起：**Cast [[spell:187874]] on cooldown. Remember to react to [[spell:1262713]] procs!
10. **等级 10 起：**Cast [[spell:17364]].
11. **等级 13 起：**Cast [[spell:60103]].
12. **等级 31 起：**Cast [[spell:470057]].
13. **等级 10 起：**Cast [[spell:188196]] / [[spell:188443]] if at 5+ stacks of [[spell:187880]].

**等级 10 起：**3.3.

#### **等级 10 起：**Survival Tools

**等级 10 起：**Enhancement also has tools to survive different situations
through a variety of spells and effects:

- **等级 10 起：**We can use our [[spell:187880]] stacks
   to generate [[spell:384143]] stacks, which make [[spell:8004]]
   instant. If you're in danger, spend these to stay healthy.
- **等级 32 起：**[[spell:198103]] is your own personal pocket tank
   for emergencies, and will taunt nearby enemies to take the pressure off. This
   lasts for 30 seconds, making it great for dangerous elites. <em>Avoid</em> taking
   [[spell:1279819]] when solo to keep this effect.
- **等级 16–17：**[[spell:974]] gives us passive healing,
   and even boosts Self-healing while maintained. The [[spell:187880]]
   gained from having [[spell:192106]] active is generally more useful.
- **等级 18–57：**[[spell:974]] gives us passive healing,
   and even boosts self-healing while maintained.
- **等级 58 起：**[[spell:974]] gives us passive healing,
   and even boosts self-healing while maintained, and doesn't lose charges anymore in
   Midnight thanks to [[spell:1217622]].
- **等级 10 起：**[[spell:20608]] lets us get straight back up if you
   ever die but has a lengthy 30-minute cooldown. If you ever go a bit overboard, use this to get
   back right to where you started without needing to run back. Just be careful - you spawn with
   low Health, so if enemies are nearby, it might be worth walking instead.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Added note about Heirlooms in Midnight.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for new Class Tree talent gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **13 May 2024:** Format adjustment to move slider closer to rotation.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, no changes necessary.
- **06 Nov. 2023:** Updated for Patch 10.2 talent changes.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **20 Jul. 2023:** Rewritten to include rotation advice.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **22 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Enhancement Shaman in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Enhancement Shaman

Welcome to our Easy Mode Page! This section is intended for players who are new
to the game or class, have no intentions of raiding Mythic difficulty, and want a
straightforward rundown of how the specialization plays without the overwhelming
priority details needed for optimal play.

Enhancement has one rule above all else - **always be pressing something**.
It's a spec with a lot of moving parts, even after Midnight's simplification.
It always has something to fill up time, so the only thing worse than the wrong
button is no button at all. Three quick rules to follow when learning the spec are:

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_maelstromweapon.jpg>) **Manage your Maelstrom Weapon**  
  
    Enhancement's resource is [[spell:187880]], which is spent on
    [[spell:188196]] & [[spell:188443]]. These become instant at 5
    or more stacks. It has a cap of 10, so avoid waste.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_stormstrike.jpg>) **Cycle Ability Cooldowns**  
   Enhancement has multiple melee strikes that are restricted by cooldown. Keep
    your [[spell:17364]], [[spell:60103]] and [[spell:187874]] on cooldown,
    weaving [[spell:187880]] spenders at high stacks.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_callstorm.jpg>) **React to Procs**  
  
    Each Hero Tree has a proc to react to. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic has
    [[spell:201900]], while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer has [[spell:454009]].
    Both also have [[spell:1262713]] resets on [[spell:187874]] to
    keep your eye out for.

The best approach to learning Enhancement is to take it one step at a time,
rather than trying to learn everything at once. Each aspect in isolation follows
quite simple rules, but the difficulty lies in marrying them all together during
fast-paced combat.

In Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer has the edge in all scenarios, making it
the preferred choice regardless of content. It also has the advantage of playing
the same build in both single-target and AoE, giving it a one-size-fits-all
playstyle.

2.

### Beginner's Guide to Midnight Enhancement Shaman

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer   Raid Build

2.1.

#### Beginner Raid Talents for Enhancement Shaman

In Raids and single-target in Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer takes the lead
due to its stronger burst and potent cleave baked into the toolkit. It has a heavy
focus on your [[spell:187880]] resource usage, and uses
[[spell:17364]] as its main melee ability.

It takes [[spell:114051]] as its cooldown, providing extremely
high burst every 2 minutes.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents Enhancement Single Target - Stormbringer
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogBbs88YB1uOjUU-COXWDZEBQVgYdFARcMNjPiKKJLblC9A-AAAA-Aego0QsgBTgwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer   Dungeon & Delve Build

2.2.

#### Beginner Dungeon Talents for Enhancement Shaman

Much like in single-target, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer has firmly pulled ahead in
AoE and dungeon situations. It makes use of [[spell:289874]], [[spell:188443]]
and [[spell:454009]] to deal additional damage through [[spell:455123]],
and performs especially well at lower target counts.

It has extremely strong and reliable burst every two minutes with [[spell:114051]],
and unreliable burst through [[spell:384352]] and [[spell:454009]] procs that
need to be reacted to.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents Enhancement AoE - Stormbringer
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2gFYGGawCAzyMmxYZxYjZmtxyMzMzYswMAAzwYmhRgZGMYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZMWYGAgZYMzwIwMDGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFoAzzrsrzYBK1KROB-CDEOXZBFNRVWYdgjAMQShLPeKKbT4EB-AAAA-OUaIawIMsEAEpA-
```

:::

### Single-Target & AoE   Rotation Breakdown

2.3.

#### Beginner Enhancement Shaman DPS Rotation

Before entering combat, always remember to apply the following effects.

- **Apply Shield & Imbues**  
  
  [[spell:1270350]] applies both Shields and Weapon
    Imbues via [[spell:192106]].
- **Cast Group Buffs**  
  
    Use [[spell:462854]] to buff you and your party with Mastery and auto-attack procs.  
  
    Cast [[spell:974]] on your tank, as [[spell:383010]] allows for two.

2.4.

#### Single Target Breakdown

In single-target, Enhancement needs to manage its resources correctly to remain
GCD locked, while avoiding [[spell:187880]] waste as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer.
It also has a number of procs to react to:

- **Spend your Maelstrom Weapon**  
  
  [[spell:187880]] is spent at **10** stacks on either
  [[spell:454009]] with a proc, or [[spell:188196]].  
  
  Can be used at lower stacks for [[spell:1250364]] CDR on [[spell:17364]].
- **Use Rotational Abilities**  
  
  Cast [[spell:470057]] on cooldown <em>always</em>, and [[spell:187874]] when available.  
  
  <em>Rotation Priority –</em> [[spell:470057]] ➜ [[spell:187874]] ➜ [[spell:17364]] ➜ [[spell:60103]].
- **Maximize your Cooldowns**  
  
  [[spell:114051]] should be used every two minutes.  
  
  During Ascendance, cast [[spell:187874]] when available, otherwise [[spell:115356]].
- **React to Procs**  
  
  As Stormbringer, you have three procs – [[spell:454009]], [[spell:1262713]] & [[spell:1262635]].  
  
  <em>Tempest</em> – replaces [[spell:188196]], spend with 10 stacks.  
  
  <em>Storm Unleashed</em> – resets [[spell:187874]], use ASAP.  
  
  <em>Thunder Capacitor</em> – refunds [[spell:187880]] for back-to-back spenders.

When trying to learn Enhancement's rotation principles, it can be a lot to take
in at once. We recommend learning things in stages, in the following order:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_improvedstormstrike.jpg>) **Enhancement Single-Target**
**Melee Strike Juggling**

➜

**[[spell:187880]] Management**

➜

**Cooldown Usage**

:::

2.5.

#### AoE Breakdown

In AoE, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer plays almost exactly the same, with a higher
focus on [[spell:187880]] efficiency due to additional resources:

- **Spend your Maelstrom Weapon**  
  
  [[spell:187880]] is spent on [[spell:188443]] in AoE. Spend
  at **10** stacks.  
  
  [[spell:454009]] procs should always be spent as a priority with **10** stacks.
- **Use Rotational Abilities Effectively**  
  
  [[spell:470057]] is <em>top priority always</em> with the 2-piece:  
  
  <em>Ability Priority –</em> [[spell:470057]] ➜ [[spell:187874]] ➜ [[spell:17364]] ➜ [[spell:60103]].
- **Maximize Your Cooldowns**  
  
  [[spell:114051]] is used every 2 minutes, ideally on dangerous pulls.  
  
  While active, cast [[spell:187874]] whenever available, and otherwise [[spell:115356]].

Enhancement can be a little overwhelming in AoE due to how much is going on.
It can be easy to get lost in what to do, so we'd recommend focusing on things in
chunks, ideally in the following order:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_improvedstormstrike.jpg>) **Enhancement AoE**
**Learn Single-Target**

➜

**Optimize [[spell:187880]] Management**

➜

**Burst Cooldown Windows**

:::

If you feel comfortable with these more basic breakdowns and are looking for
a deeper understanding, you can check our Rotation Page, which covers decision
making at a deeper level:

[Enhancement Shaman Rotation Page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)

2.5.1.

##### Apex Talent: ![Storm Unleashed Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_shaman_stormunleashed.jpg>) Storm Unleashed

All recommended builds on this page play with four points in the Apex Talent,
[[spell:1262713]]. This is simply an extra proc to watch out for - whenever
it triggers, try to spend it on [[spell:187874]] quickly. Since the buff
overlaps thanks to the first point, you don't lose out on anything by refreshing
the effect early.

2.5.2.

##### Season 2 Tier Set

Enhancement's Season 2 Tier Set, the **Ophidian Oracle's Prophecy**,
provides the following two bonuses:

- [[spell:1296627]] – [[spell:470057]] causes
  	your primary target to erupt in a [[spell:333974]] every 2 sec for 6 sec.
      Fire Nova deals 200% increased damage to the primary target of your
  	Voltaic Blaze.
- [[spell:1296628]] – [[spell:333974]] reduces the
  	cooldown of [[spell:187874]] by 2 sec, and increases the damage of your
  	next Crash Lightning by 8%, stacking up to 5 times.

Both of these bonuses are quite complicated in how they work, but in practice
they only change a couple of things. [[spell:470057]] is now placed at the top
of your rotational priority, and extra importance is added to keeping [[spell:187874]]
on cooldown. These heavily incentivize picking up [[spell:333974]], and
all four points in the Apex Talent, [[spell:1262713]].

### Survival Tools &   **Defensive Spells**

2.6.

#### Defensive Spells for Enhancement Shaman

Enhancement has infrequent active defensives in its toolkit, but each of them
can be quite potent when they're available. This means you need to be a little
more careful when engaging in combat.

**[[spell:108271]] -** provides 40% damage reduction for 12 seconds on
a 1.5-minute cooldown (using [[spell:381647]]). This is Enhancement's
strongest defensive tool, and while it has a longer cooldown than most
defensives, it provides a lot of safety while active.

**[[spell:198103]] -** grants 15% maximum health for 30 seconds, on
a 3-minute cooldown. This is a "backup" cooldown when you cannot use
[[spell:108271]], and can cover longer periods of damage. [[spell:1279819]]
is important to avoid it taunting enemies and dying, though this can be dropped when
solo to provide a personal tank.

**[[spell:260878]] -** provides up to a 20% damage reduction after
remaining in [[spell:2645]] for an extended period. This is a last resort
defensive tool if you have nothing else available, as we cannot deal any damage
while shapeshifted.

**[[spell:384143]] -** when spending [[spell:187880]],
it provides an equal number of stacks of a separate buff. This will apply the same
effect to your [[spell:8004]] or [[spell:1064]], allowing you to weave
in some self-healing if needed. This is a less painful DPS loss than previous
iterations (though is equally less potent), and it's almost always available in a
pinch.

**[[spell:974]] -** grants a modest amount of healing over the
course of an encounter. [[spell:1217622]] is strongly recommended here
to keep it permanent, alongside [[spell:383010]] so you can maintain
[[spell:192106]]. This can also be applied to a second ally for a small
amount of off-healing.

**[[spell:355630]] -** provides powerful damage reduction after successfully
interrupting a spell, giving us an extra incentive to do so if there is
a lot of damage happening.

### Gearing &   **Stat Priority**

2.7.

#### Stat Priority for Enhancement Shaman

The most versatile Enhancement stat priority that will cover both builds on
offer here is as follows. For more information on what's presented on this page,
check out our main [Stat Priority
page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>).

Item Level

Critical Strike

Mastery

Haste

Versatility

2.8.

#### Gearing an Enhancement Shaman

When it comes to gearing in Season 2 in Midnight, you want to
prioritize your Tier Set as quickly as possible, and crafting a weapon is a quick
way to gain a lot of power right out of the gate. Due to how many different
options are available when it comes to gearing a character, it's best to
jump over to our main [Gearing page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)
for a more comprehensive breakdown on things to chase.

### Blizzard   Rotation Assistant

2.9.

#### Blizzard Rotation Assist for Enhancement Shaman

Added during The War Within, this has slowly improved, and is a bit better in
Midnight. With Midnight simplifying some of the more complex Enhancement mechanics,
this is a more reasonable jumping off point if you're looking to learn the spec.
It comes in two versions - an action bar highlight based off a curated Blizzard
priority, or a single keybind that automatically presses that button (though, with
a 25% GCD penalty between casts when used).

It does, however, come at a performance loss, and some extra limitations.
Most importantly, the tool will **not** use [[spell:114051]]
(when taken), any racial bonuses or on-use trinkets - these all need to be cast
manually by you if you use it. This also extends to movement, defensive and crowd
control abilities.

While the tool is definitely better in Midnight, it does still require manual
input to make use of it. Both Hero Trees now work similarly, but since ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic
<em>doesn't</em> take [[spell:114051]], it fares better as it can
make use of its full toolkit without manual assistance. When used this way, it
acts as a good learning tool when trying to get to grips with the spec, or if you
want to take it easy during some slower content.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for release of Midnight Season 1.
- **02 Mar. 2026:** Small update to recommended Talents.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Changed AoE build recommendation to Totemic, and adjusted rotation tips.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7. Small tweaks to Rotation breakdowns.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Sep. 2025:** Updated to emphasize recommendations are with the new Tier Set.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **21 Apr. 2025:** Shifted single target recommendation back to Stormbringer following buffs.
- **16 Mar. 2025:** Changed single target recommendation to Totemic.
- **04 Mar. 2025:** Updated to account for March 4th Flowing Spirits hotfix.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7 with significantly condensed rotation section.
- **05 Nov. 2024:** Updated with more recent Patch 11.0.5 information.
- **21 Oct. 2024:** Updated for Patch 11.0.5, will need future updates following patch release.
- **23 Sep. 2024:** Updated for most recent hotfixes and Storm build switch.
- **09 Sep. 2024:** Updated for Elemental Blast and Tempest hotfixes.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, switched recommended build to standard Elementalist.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, build remains the same.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **10 May 2023:** Updated to add an even simpler build for beginners that remains competitive.
- **01 May 2023:** Updated for Patch 10.1 with a more beginner friendly build, and revised starter rotation.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Enhancement Shaman in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Enhancement Shaman

Throughout Midnight, Enhancement saw some significant changes to its talent tree, with
a more slimline set of options to suit its Hero Trees. It often allows for very
flexible damage profiles, and there's <em>significant</em> overlap in key talents
for both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic. Current recommendations
for Season 2 are as follows:

- **Raid -** **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer** provides stronger single-target,
    burst and cleave, suiting it well to encounters in The Venomous Abyss. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic
    can keep up in single-target, but falls behind in cleave and has a busier
    rotation with the new Tier Set.
- **Mythic+ -** **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer** firmly pulls ahead in Season
    2, dealing higher damage at almost all target counts aside from mass AoE. It
    also has an easier time integrating the Tier Set into its rotation.

Due to the ongoing tuning in Season 2 paired with the addition of the
current Tier Set, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer established a clear lead in all content,
and continues to hold onto it. While it has a stricter 2-minute burst timer (and a
lot more RNG), its damage profile flexibility makes it the clear pick for both
Raids and Mythic+. As The Venomous Abyss requires an extremely high amount of cleave,
the damage advantage it has at low-to-mid target counts only pushes it further
ahead of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, despite hotfixes aimed at bringing them closer. Below,
we have some import codes if you want to jump straight in-game:

**Quick Start Import Codes:**

:::talents Raid / Single Target - Stormbringer
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
}
```
:::

:::talents AoE / Mythic+ - Stormbringer
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2gFYGGawCAzyMmxYZxYjZmtxyMzMzYswMAAzwYmhRgZGMYMA"
}
```
:::

:::talents Delves - Totemic
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMjZmZmZmZmZmZGzAAAAAAAAAALwGMjFN2GAzA2AYWmxMGLLzAzMGLmZmZMWYGAADMGzMxMDAMGA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Stormbringer

Raid/Single-Target

recommended

Mythic+/AoE

recommended

Delves

Totemic

Raid/Single-Target

Mythic+/AoE

Delves

recommended

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer Raid Talents

Currently ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer is the strongest pick available in single-target,
  bringing exceptional 2-minute burst while having flexible cleave tools for raid
  encounters. With the addition of the new Season 2 Tier Set, it's firmly the
  **recommended choice**.

**Note** – in <em>pure single-target encounters</em> **after**
  acquiring the new 4-piece, play [[spell:455088]] instead of [[spell:455110]].

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer Mythic+ Talents

In AoE, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer provides consistent damage at 5-6 targets, with
  explosive burst during [[spell:114051]] and [[spell:384352]]
  procs. While it has some RNG components like [[spell:454009]], its tuning puts
  it ahead in almost all relevant encounter styles in Season 2 dungeons, making
  it the **recommended choice**:

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer Delve Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer is well suited to [Delves](<https://www.icy-veins.com/wow/delves-guide>), with the ability to
   pool damage around key moments. It has some incredibly powerful burst,
   but its unpredictability can sometimes cause issues. Its massive
   [[spell:187880]] generation can fuel [[spell:384143]]
   stacks for additional free healing, so is capable of handling itself well.

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic Raid Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic has fallen slightly behind in Season 2, largely due to the
  extra GCD strain caused by the new 4-piece. While it can still do well, especially
  on fights built around 1-minute burst, it's overshadowed by the alternative
  currently.

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic Mythic+ Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic remains a very good 1-minute burst build, capable of dealing
  heavy damage at higher target counts. Its tuning unfortunately holds it back
  going into Season 2, seeing more nerfs than its counterpart without much to keep
  it even in dungeon environments:

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic Delve Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic is extremely well suited to Delves, being able to deploy
   huge AoE burst whenever needed due to its short cooldowns. It also transitions
   between target counts with no real difficulty, flowing well throughout each
   delve. As such, it's the **recommended choice**.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogBbs88YB1uOjUU-COXWDZEBQVgYdFARcMNjPiKKJLblC9A-AAAA-Aego0QsgBTgwwC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZMWYGAgZYMzwIwMDGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFoAzzrsrzYBK1KROB-CDEOXZBFNRVWYdgjAMQShLPeKKbT4EB-AAAA-OUaIawIMsEAEpA-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwGMDDNYBgZZGzYssMDMzsNWMzMzYswMAAzwYmhZCMzgBjB"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogxzrsrzYBaalIq-CDEOXZBFNRVWYdgjAMQShLPeKKbF5SA-AAAA-OUaIawIMsEAEpI-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzMzMzMzMzMzMzYGAAAAAAAAAsAbwMW0YbAMDYDgZZGzMjllZgZmNWmZmZYYMDAgBYMzEzMAwYA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogBbsEdB1uuzUjD-CDEHOXZBGGINRVWdAMQSaiLPUKKJFT-AAAA-Jgko0AIowgxRmF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzMjZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZAbAMLzYGjlFjNmZ2GLz8AzMDWGzAAAMGzImZAGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRrFoAzzbsEdB1uuTjKROB-CDEHOXZBGGNWjAMQRVgPSaiKKLUJFT-AAAA-Jgko0AIowgxRmF-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMjZmZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZAbAMLzYGjllZgZGjFzMzMGLMDAAwYMzEzMADGDA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogpqrzzTU5pxC0U-CDEHOXZBGGINRWAMQgPSaiKKLUJVjT-AAAA-Jgko0AIowgxRmF-
```

:::

### 天赋方案 0-0

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer focuses heavily on [[spell:187880]] generation,
  so takes all cycling talents to maximize [[spell:454009]] procs. There's
  limited choice within the tree, so pathing is geared towards [[spell:17364]]
  as your main melee generator. With the new Tier Set, both [[spell:470057]]
  and [[spell:333974]] are important pickups, as well as all four points in the Apex
  Talent, [[spell:1262713]], to take advantage of the 4-piece. Finally, it
  takes both the [[spell:1262635]] leaf for Maelstrom Weapon
  resets, and [[spell:114051]] to trigger [[spell:1264688]].
  Additional notes are:

- In Season 2, the additional GCD requirements of the Tier Set mean that
  	[[spell:455110]] leads to extra waste, so [[spell:455088]] is a worthwhile
  	swap in <em>pure single-target</em>. This changes in cleave, as the tree becomes
  	more prone to running dry on resources.
- In the centre, [[spell:334046]] is <em>technically</em> the best in
  	single-target, but due to [[spell:289874]], [[spell:334308]]
  	is almost as good. Therefore, we recommend the latter due to its superior
  	cleave potential.
- For Raids, most utility picks are unnecessary, but in The Venomous Abyss having
  	[[spell:192058]] for certain fights is useful. Additionally, due to the
  	large boss arenas, [[spell:192077]], [[spell:462820]], [[spell:382201]]
  	and [[spell:108287]] are all extremely valuable to provide extra
  	raid movement.

### 天赋方案 0-1

In AoE the goal of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer is to generate and spend as much
  [[spell:187880]] as possible to fish for [[spell:454009]]. The only
  major change from single-target builds is [[spell:334308]], which is
  locked rather than being optional. Season 2 also locks in both [[spell:333974]]
  for the 2-piece, and all four points in the Apex Talent, [[spell:1262713]],
  due to the synergy with the 4-piece. Some additional notes are:

- On the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer Hero Tree, [[spell:455110]] is uncontested
  	as the go-to pick, helping to cycle through [[spell:454009]]	faster. Other
  	choice nodes are up to preference, depending on your utility and
  	defense needs.
- While previously [[spell:1218047]] was desirable as a mid-range cooldown,
  	the new 4-piece solidifies four points in [[spell:1262713]], so the
  	bottom of the tree has no alternate choices.
- The class tree allows for full investment into [[spell:192058]] for up
  	to a 25-second cooldown reduction, giving some amount of extra CC potential in
  	Mythic+. Other utility like [[spell:51886]], [[spell:370]] and
  	[[spell:383013]] can be slotted in on a dungeon-per-dungeon basis.

### 天赋方案 1-0

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic focuses heavily on [[spell:60103]], building out any talent
  that leans into this to maximize both [[spell:201900]] and [[spell:445035]].
  At the bottom, it needs [[spell:197214]] to activate the final
  [[spell:445024]] mote. It also avoids [[spell:114051]],
  so it can maintain the sync between [[spell:384352]] and [[spell:444995]].
  Finally, it picks up all four points in [[spell:1262713]] to cement
  [[spell:187874]] as a core part of the rotation. Some additional notes
  are:

- In the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic Hero Tree you should <em>always</em> pick [[spell:455590]]
  	due to [[spell:445035]]. Since there's no [[spell:114051]]
  	taken, [[spell:445029]] is always used, and [[spell:445033]]
  	is the most flexible final choice node - providing better AoE while bringing
  	the same single-target power.
- While the new 2-piece references [[spell:333974]], ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic doesn't
  	<em>need</em> it to activate the effect, so avoids investing a point in it.
  	Instead, it switches to [[spell:1251026]] to take advantage of the massive
  	amount of Crit available on Season 2 gear.
- While not strictly for performance, Totem-related talents on the class tree
  	make managing [[spell:444995]] easier. In particular, [[spell:382201]]
  	for the additional range and [[spell:108287]] for easier repositioning
  	when needed.

### 天赋方案 1-1

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic builds almost exactly the same in AoE, with the only change
  being a switch to [[spell:334308]] to further improve [[spell:188443]]
  and [[spell:289874]] damage. It still grabs [[spell:197214]] through
  [[spell:1218047]] for its 30-second burst, and takes all four points in
  the [[spell:1262713]] Apex Talent to add more punch to [[spell:187874]]
  casts. Some additional notes are:

- In the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic Hero Tree you should <em>always</em> pick [[spell:455590]]
  	due to [[spell:445035]]. On the central choice, [[spell:445029]]
  	is taken since it doesn't use [[spell:114051]], and
  	[[spell:445033]] provides the most AoE potential on the final
  	node.
- Season 2 locks in [[spell:333974]] in the middle of the tree, as the new
  	2-piece effect provides high priority damage when it procs. [[spell:334046]]
  	and [[spell:1251026]] can be chosen based on preference.
- The class tree allows for full investment into [[spell:192058]] for up
  	to a 30-second cooldown reduction, giving some amount of extra CC potential in
  	Mythic+. Other utility like [[spell:51886]] and [[spell:383013]]
  	can be slotted in on a dungeon-per-dungeon basis.

The builds listed above are recommendations based on strength and popularity,
covering each area of content in endgame PvE. Each build has its own rotation to
execute, with unique aspects to master, with their own tricks up their sleeve to
assist your group in different encounters.

2.

### Omnium Folio

Introduced in [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), the Omnium Folio is a player power system
that provides a small number of performance boosting effects, unlocked through a
series of quests. These bonuses aren't related to any gear pieces, and are
always active on your character. Some provide additional damage, while others
grant some healing and extra defensive tools.

Below, we've listed recommendations on each of the five Runes, unlocked as you
complete the Folio quest chain:

- **Rune 1 -** [[spell:1279599]]
- **Rune 2 -** [[spell:1279603]]
- **Rune 3 -** [[spell:1287555]]
- **Rune 4 -** [[spell:1279610]]
- **Rune 5 -** [[spell:1279614]]

It's worth noting that the difference between most of these effects is very
minor. The fourth stat boosting Rune, however, can shift around depending on your
gear, so it's a good place to balance out stats if you're lacking any. Haste, Mastery,
and Critical Strike are all roughly even, and the best pick of the three is usually
the stat you have the least of on your current gear setup.

3.

### Apex Talent: ![Storm Unleashed Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_shaman_stormunleashed.jpg>) Storm Unleashed

The Enhancement Apex Talent, [[spell:1262713]], focuses on [[spell:187874]],
while also providing extra bonuses to core parts of the toolkit. These
lean heavily into making it a rotational pillar for both Hero Trees. All four
points are taken by <em>most</em> builds, providing good single-target and AoE
benefits:

- [[spell:1262713]] - Grants each stack of [[spell:187880]]
    spent a 2% chance to cause your next [[spell:187874]] cast to ignore its
    cooldown. Additionally, the Crash Lightning weapon enhancement buff can
    now stack and overlap.
- [[spell:1262761]] - Increases the damage dealt by
    [[spell:187880]] spenders by 7.5%, and weapon imbue damage by 10% per
    point.
- [[spell:1252373]] - Causes [[spell:187874]]
    to also create a static pool, dealing an additional 100% of the
    initial cast's damage over 2 seconds. Additionally, the weapon enhancement buff
    grants 15% increased auto-attack speed per stack.

Even just the first point solidifies [[spell:187874]] as a core part of
the rotation at all target counts, adding an extra proc to react to. Since it allows
for the effect to overlap, it means it's hard to waste the procs by refreshing.
The only real way to misplay it is to not press Crash Lightning at all. The
follow-up points are largely passive increases - though they improve things that
we use so frequently that there's a lot of value in each point.

4.

### Enhancement Shaman Hero Talents

Enhancement has two distinct Hero Talent choices available that, as covered in
the above sections, drastically alter your build choices and gameplay loop
depending on your selection.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer

This tree grants access to [[spell:454009]], a powerful proc that empowers
your next [[spell:188196]]. This can happen randomly when spending [[spell:187880]],
converting it into a huge AoE burst tool. Additionally, this Hero Talent provides the following:

- [[spell:1264688]] causes [[spell:114051]] to trigger
    [[spell:454009]] on activation, making it the cooldown of choice.
- [[spell:455123]] applies a debuff to targets hit with your spenders,
    converting a portion of damage dealt into extra damage. This allows it to deal
    additional priority damage to key targets when active.

This orients ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer strongly around our resource gameplay,
rewarding good management and cycling with explosive burst. It's able to leverage
a variety of tools to cleave without any single-target loss, but can be prone to bad
RNG streaks.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic

Conversely, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic focuses strongly on [[spell:60103]] through
the [[spell:201900]] effect, while also granting access to a new cooldown,
[[spell:444995]]. This pulses AoE damage while active, and also links into a
number of different abilities for bonus effects.

- [[spell:445035]] causes [[spell:60103]] to also trigger [[spell:197214]]
    while [[spell:201900]] is active, which through [[spell:455590]] also causes
    your [[spell:444995]] to pulse.
- [[spell:445025]] also causes your [[spell:444995]] to deal
    additional damage whenever you cast a [[spell:187880]] spender, amplifying
    future damage it deals until it expires.

This adds an extra cooldown that aligns with [[spell:384352]] into the Enhancement
toolkit. When paired with other options on the tree, it gives it some potent options
to deal with 30-second and 1-minute burst timers, while dealing strong priority
damage without any sacrifices to cleave or AoE.

5.

### PvP Talents (War Mode)

"War Mode" is an optional feature that enables open-world PvP encounters that
confer some benefits when active:

- Grants access to PvP talents in the open world.
- 10% increase in World Quest rewards at max level.
- 10% more experience gained while leveling.
- Earn Conquest Points which can reward gear every week.

With the benefits of War Mode for leveling and PvE content, it is an optional
way to maximize your leveling speed and reward potential. However, you will open
yourself up to open-world PvP, so be aware of hostile enemy players who could
interfere with you; this is a risk you will have to decide on your own if you want
to take.

Generally, these selections are made to optimize your ability to kill enemies
faster, increasing your pace when moving through content.

- [[spell:193876]] allows for more liberal [[spell:2825]] /
  [[spell:32182]] usage without having to worry about the 10-minute
  lockout. Great for solo and duo content.
- [[spell:409293]] gives you an emergency escape if you get into
  trouble with a 2-minute cooldown, and also deals massive Physical
  damage when you emerge from the ground.
- [[spell:204331]] copies the damage you take and repeats
  it onto the enemy that dealt it, allowing you to return the favour against
  dangerous enemies!

[[spell:355580]], [[spell:356736]], [[spell:206642]], and
[[spell:204336]] have very limited PvE uses, being more focused on
in-combat control. While these are very strong for some situations, they are much
more suited to PvP engagements, and as such, are not recommended for efficient
enemy killing.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **24 Aug. 2026:** Adjusted Folio to mention fourth rune is used to adjust lacking secondaries.
- **19 Aug. 2026:** Switched ST import code to Supercharge due to the amount of cleave in Season 2 raids.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Omnium Folio recommendations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **07 Apr. 2026:** Small update to Stormbringer raid builds to adjust for higher cleave needs.
- **16 Mar. 2026:** Updated for release of Midnight Season 1.
- **02 Mar. 2026:** Small adjustment to Totemic builds.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Changed Mythic+ and AoE recommendation to Totemic.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5, adjusted recommendations to highlight how close both trees are.
- **16 Mar. 2025:** Updated with more universal Totemic Mythic+ talent set. Changed recommendation to Totemic across the board.
- **04 Mar. 2025:** Adjusted all talent builds to switch away from Flowing Spirits.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7 with recommendation flags on key builds.
- **05 Nov. 2024:** Significant changes to recommended loadouts based on more tested 11.0.5 builds post-launch.
- **21 Oct. 2024:** Updated for Patch 11.0.5, will require future updates following release.
- **23 Sep. 2024:** Updated for most recent hotfixes and Storm build switch.
- **09 Sep. 2024:** Updated for Elemental Blast and Tempest hotfixes along with new Storm loadouts.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Updated for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed and touched up for Patch 10.2.5 and mid-season updates.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, small restructuring and added Elementalist Funnel.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5 and updated Storm Cleave in recommendations.
- **09 May 2023:** Updated to include Primordial Wave in Elementalist single target.
- **01 May 2023:** Fully updated for Patch 10.1 with revised new builds. Physical builds converted to Storm.
- **20 Mar. 2023:** Reviewed and updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Enhancement Shaman in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Enhancement Shaman Gameplay and Rotation Guide

Welcome to our Rotation page for Enhancement Shaman! On this page,
you will find everything you need to know about actually playing the spec in
Raiding and Mythic+ scenarios.

As Enhancement has two distinct Hero Talents that play differently with
different specialities, below are some quick-start recommendations for which to
use when jumping into Midnight:

- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer -** provides powerful burst every 2 minutes, is
  	particularly strong at 5-6 targets, and is the go-to pick in Season 2.
  	**Recommended in all content**.
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic -** provides solid single-target and mass AoE, operating
  	on a 1-minute burst timer. Slightly weaker in Season 2, and falls behind in
  	most content.

In Season 2, Enhancement has firmly landed on ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer at the
top of the ladder in endgame content, and we recommend using it at all times. While
some effort has recently been made to bring ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic closer, it's far
less flexible than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer, which brings ample cleave and potent
burst every two minutes.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer

Raid / Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+ / AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic

Raid / Single Target

Mythic+ / AoE

Active Talents

Passive Talents

[[spell:114051]]

[[spell:378270]]

[[spell:197214]]

[[spell:1218047]]

[[item:271886]]

[[item:241288]]

[[spell:333974]]

[[spell:334046]]

[[spell:382042]]

### Single Target

1.1.

#### Enhancement Shaman Single Target Rotation

Enhancement Shaman functions around a priority list system, cycling different abilities to keep them on cooldown, and generating [[spell:187880]] stacks. Stacks are then spent on powerful spells, granting cooldown reduction through [[spell:1250364]]. It can take some time to build up muscle memory and get a feel for the flow, but with careful planning around resources it can be very rewarding.

---

1. **适用条件：Totemic（启用）。** Cast [[spell:470057]] if [[spell:188389]] isn't active
2. **适用条件：Totemic（启用）。** Cast [[spell:444995]]
3. **适用条件：Totemic（启用）；Sundering（启用）。** 
   Cast [[spell:197214]] - <em>Click for Notes</em>
   
   
   - Aim to sync up every other cast with [[spell:444995]].
4. **适用条件：Totemic（启用）。** Cast [[spell:60103]] with [[spell:201900]] or [[spell:453405]] active
5. **适用条件：Totemic（启用）。** 
   Cast [[spell:470057]] - <em>Click for Notes</em>
   
   
   - With the 2-piece this should be kept on cooldown whenever possible
6. **适用条件：Totemic（启用）；Ascendance（未启用）；Deeply Rooted Elements（未启用）。** Cast [[spell:384352]]
7. **适用条件：Totemic（启用）；Primordial Storm（启用）。**  Cast [[spell:1218047]] with **10** [[spell:187880]] stacks - <em>Click for Notes</em>
   
   
   - If the buff is about to expire, this can be cast at **5+** stacks instead.
8. **适用条件：Stormbringer（启用）；Primordial Storm（启用）。** Cast [[spell:1218047]] with **10 [[spell:187880]]** stacks
9. **适用条件：Stormbringer（启用）；Ascendance（启用）；Surging Elements（启用）；Sundering（启用）。** 
   Cast [[spell:197214]] - <em>Click for Notes</em>
   
   
   - Aim to align this with [[spell:114051]]
10. **适用条件：Stormbringer（启用）。** 
    Cast [[spell:470057]] - <em>Click for Notes</em>
    
    
    - With the 2-piece this should be kept on cooldown whenever possible
11. **适用条件：Stormbringer（启用）；Surging Elements（启用）；Ascendance（未启用）。** Cast [[spell:197214]]
12. Cast [[spell:187874]]
13. **适用条件：Ascendance（启用）。** Cast [[spell:114051]]
14. **适用条件：Ascendance（启用）。** Cast [[spell:115356]] during [[spell:114051]]
15. **适用条件：Deeply Rooted Elements（启用）。** Cast [[spell:115356]] during [[spell:114051]]
16. **适用条件：Deeply Rooted Elements（未启用）。** Cast [[spell:17364]] during [[spell:384352]]
17. **适用条件：Totemic（启用）。** 
    Cast [[spell:188196]] with **10** [[spell:187880]] stacks - <em>Click for Notes</em>
    
    
    - This can be used as low as **5+** if [[spell:1250364]] will reset [[spell:60103]] cooldown.
18. **适用条件：Stormbringer（启用）。** Cast [[spell:454009]] / [[spell:188196]] with **10** [[spell:187880]] stacks
19. **适用条件：Stormbringer（启用）。** Cast [[spell:17364]]
20. **适用条件：Stormbringer（启用）；Sundering（启用）；Surging Elements（未启用）。** Cast [[spell:197214]]
21. Cast [[spell:60103]]
22. **适用条件：Totemic（启用）。** Cast [[spell:17364]]
23. Cast [[spell:188196]] with **5+** [[spell:187880]] stacks

---

**适用条件：Stormbringer（启用）。** Enhancement has an ebb and flow that you will slowly get used to, as the "feel" of [[spell:187880]] generation alongside your ability cooldowns has a rhythm. [[spell:1250364]] adds in dynamic cooldown reduction from spenders, giving a nice feedback loop to resource management. Each Hero Tree also has key procs to react to, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer having [[spell:454009]] and [[spell:1262635]] procs to handle.

**适用条件：Totemic（启用）。** Enhancement has an ebb and flow that you will slowly get used to, as the "feel" of [[spell:187880]] generation alongside your ability cooldowns follows a rhythm. New to Midnight, [[spell:1250364]] adds in dynamic cooldown reduction from spenders, giving a nice feedback loop to resource management. Each Hero Tree also has key procs to react to, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic leaning heavily into [[spell:201900]], extending it via [[spell:1260644]].

1.2.

#### Single Target Rotation Notes & Tips

**适用条件：Stormbringer（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer, based on your selections in the tool above:

- **适用条件：Stormbringer（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer
  aims to cycle [[spell:187880]] for [[spell:454009]]. Try to spend it with **10** stacks. Otherwise, cast [[spell:188196]], also at 10 stacks.
- **适用条件：Stormbringer（启用）。** [[spell:470057]] should be cast on cooldown to take advantage of the new 2-piece. Similarly, [[spell:187874]] should cast whenever available. [[spell:17364]] is your main filler ability, with [[spell:60103]] as your last resort to generate.
- **适用条件：Stormbringer（启用）；Ascendance（未启用）；Deeply Rooted Elements（未启用）。** Whenever you cast
  [[spell:384352]], aim to have 1-2 charges of [[spell:17364]] and [[spell:187874]]
  available. Fill every GCD with these to trigger [[spell:384444]], ideally
  getting enough [[spell:1250364]] CDR to chain cast them.
- **适用条件：Stormbringer（启用）；Ascendance（启用）。** Have [[spell:187874]] active before [[spell:114051]], and cast [[spell:187874]] <em>whenever it resets</em>, filling every other GCD with [[spell:115356]]. Cast [[spell:470057]] as it becomes available during the window.
- **适用条件：Stormbringer（启用）；Ascendance（启用）。** During [[spell:384352]] procs, cast as many [[spell:187874]] / [[spell:17364]] as possible.
- **适用条件：Stormbringer（启用）；Deeply Rooted Elements（启用）。** Whenever [[spell:378270]] triggers, Cast [[spell:187874]] if available, and otherwise [[spell:115356]] every GCD. [[spell:384352]] lasts slightly longer, so remember to keep casting [[spell:17364]] until it expires.

**适用条件：Totemic（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, based on your selections in the tool above:

- **适用条件：Totemic（启用）；Ascendance（未启用）；Deeply Rooted Elements（未启用）。** As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, [[spell:444995]] should be cast as close to every minute as possible. [[spell:197214]] should come first to trigger [[spell:382042]] and the Earth Mote, followed by [[spell:60103]] to start [[spell:201900]]. Finally, use [[spell:384352]] to extend the window with [[spell:384444]] procs, weaving [[spell:60103]] every other GCD.
- **适用条件：Totemic（启用）；Ascendance（启用）。** As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, [[spell:444995]] should be cast as close to every minute as possible. Begin your [[spell:201900]] window with [[spell:60103]], followed by [[spell:197214]] to trigger the Earth Mote. Finally, Cast [[spell:114051]] to extend it with [[spell:384444]], weaving [[spell:60103]] every other GCD.
- **适用条件：Totemic（启用）；Deeply Rooted Elements（启用）。** As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, [[spell:444995]] should be cast as close to every minute as possible. Begin your [[spell:201900]] window with [[spell:60103]], followed by [[spell:197214]] to trigger the Earth Mote. Finally, use one [[spell:187880]] spender to trigger [[spell:453409]]. Unfortunately, [[spell:378270]] has no reliable window to consistently extend through [[spell:1260644]].
- **适用条件：Totemic（启用）。** [[spell:60103]] is your strike of choice, cast as often as possible. During [[spell:201900]], this is every <em>third</em> GCD. If you follow with a [[spell:187880]] spender, [[spell:1250364]] makes it available every <em>second</em>.
- **适用条件：Totemic（启用）。** Outside of [[spell:201900]], [[spell:470057]] is your top priority due to the 2-piece, followed by [[spell:187874]] whenever available. [[spell:17364]] is your backup filler.
- **适用条件：Totemic（启用）。** [[spell:187880]] spenders should be used at **10** stacks, or to reset with [[spell:1250364]].

---

**适用条件：Totemic（启用）。**

:::details FAQShould I "Hard Cast" Maelstrom Spenders?
Never. The practice of "Hard Casting" involves using spenders below 5

[[spell:187880]]

stacks (incurring a cast time). This both makes them inefficient by not leveraging the damage bonus, and resets the swing timer, leading to even more waste. If you're doing this regularly, it's a big contributor to performance losses.

:::

:::details FAQShould I use Earth Elemental as a DPS Cooldown?
Generally, no. Even with full uptime for the entire minute, it does far less damage than even your weakest abilities. It's much better to use it as a survival tool for the health bonus , or saved as an emergency tool if not using

[[spell:1279819]]

.

:::

:::details FAQShould I care about Maelstrom Weapon waste?
Yes. When playing

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic

, your

[[spell:187880]]

spenders are key to extending your

[[spell:201900]]

window via

[[spell:1260644]]

. You should always be trying to do spend as much as possible between

[[spell:60103]]

casts. It's also useful for accessing

[[spell:60103]]

outside of this via

[[spell:1250364]]

, if spending will allow you to cast it within the next GCD.

:::

**适用条件：Stormbringer（启用）。**

:::details FAQShould I "Hard Cast" Maelstrom Spenders?
Never. The practice of "Hard Casting" involves using spenders below 5

[[spell:187880]]

stacks (incurring a cast time). This both makes them inefficient by not leveraging the damage bonus, and resets the swing timer, leading to even more waste. If you're doing this regularly, it's a big contributor to performance losses.

:::

:::details FAQShould I use Earth Elemental as a DPS Cooldown?
Generally, no. Even with full uptime for the entire minute, it does far less damage than even your weakest abilities. It's much better to use it as a survival tool for the health bonus , or saved as an emergency tool if not using

[[spell:1279819]]

.

:::

:::details FAQShould I care about Maelstrom Weapon waste?
Yes. As

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer

, cycling efficiently to reach

[[spell:454009]]

is very important, so you should avoid going above 10 stacks as much as possible. It's also very important to leverage

[[spell:1250364]]

to avoid downtime. Some waste is inevitable however, due to the flood of resources during

[[spell:384411]]

and the high priority of

[[spell:470057]]

.

:::

### AoE

1.3.

#### Enhancement Shaman AoE Rotation

Enhancement AoE is a fair bit simpler in Midnight, with less moving parts. It still maintains a few buttons it actively uses though, and each Hero Talent has its own quirks in multi-target combat. Through both [[spell:187874]] and [[spell:289874]], it follows similar goals to its single-target counterpart.

---

1. **适用条件：Totemic（启用）。** Cast [[spell:470057]] if [[spell:188389]] isn't currently active
2. **适用条件：Totemic（启用）。** Cast [[spell:444995]]
3. **适用条件：Totemic（启用）；Sundering（启用）。** Cast [[spell:197214]]
4. **适用条件：Stormbringer（启用）。** 
   Cast [[spell:470057]] - <em>Click for Notes</em>
   
   
   - With the 2-piece this should be kept on cooldown whenever possible
5. **适用条件：Sundering（启用）；Stormbringer（启用）；Surging Elements（启用）。** Cast [[spell:197214]]
6. **适用条件：Ascendance（启用）。** Cast [[spell:114051]]
7. **适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。** Cast [[spell:384352]]
8. **适用条件：Totemic（启用）。** Cast [[spell:60103]] if [[spell:201900]] or [[spell:453405]] is active
9. **适用条件：Totemic（启用）。** 
   Cast [[spell:470057]] - <em>Click for Notes</em>
   
   
   - With the 2-piece this should be kept on cooldown whenever possible
10. **适用条件：Primordial Storm（启用）。** Cast [[spell:1218047]] with **10** [[spell:187880]] stacks
11. Cast [[spell:187874]]
12. **适用条件：Ascendance（启用）。** Cast [[spell:115356]] during [[spell:114051]]
13. **适用条件：Deeply Rooted Elements（启用）。** Cast [[spell:115356]] during [[spell:114051]]
14. **适用条件：Deeply Rooted Elements（未启用）。** Cast [[spell:17364]] during [[spell:384352]]
15. **适用条件：Stormbringer（启用）。** Cast [[spell:454009]] when available with **10** [[spell:187880]] stacks
16. **适用条件：Stormbringer（启用）。** Cast [[spell:188443]] otherwise with **9+** [[spell:187880]] stacks
17. **适用条件：Totemic（启用）。** Cast [[spell:188443]] with **10** [[spell:187880]] stacks
18. **适用条件：Stormbringer（启用）。** Cast [[spell:17364]]
19. **适用条件：Totemic（启用）。** Cast [[spell:60103]]
20. **适用条件：Stormbringer（启用）；Sundering（启用）。** Cast [[spell:197214]]
21. **适用条件：Stormbringer（启用）。** Cast [[spell:60103]]
22. **适用条件：Totemic（启用）。** Cast [[spell:17364]]
23. Cast [[spell:188443]] with **5+** [[spell:187880]] stacks

---

**适用条件：Totemic（启用）。** The Enhancement AoE priority is very similar to single-target, with most abilities sporting built-in cleave in Midnight. [[spell:187874]] becomes even more important for its direct damage with [[spell:1262713]], while both it and [[spell:289874]] allows [[spell:17364]] and [[spell:60103]] to transition to multi-target seamlessly. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic still has a heavy focus on its [[spell:444995]] burst, and prioritizes extending [[spell:201900]] to capitalize upon [[spell:445035]] as much as possible.

**适用条件：Stormbringer（启用）。** The Enhancement AoE priority is very similar to single-target, with most abilities sporting built-in cleave in Midnight. [[spell:187874]] becomes even more important for its direct damage with [[spell:1262713]], while both it and [[spell:289874]] allows [[spell:17364]] and [[spell:60103]] to transition to multi-target seamlessly. Even moreso than in single-target, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer really wants to cycle [[spell:187880]] efficiently to reach explosive [[spell:454009]] procs.

1.4.

#### AoE Rotation Notes & Tips

**适用条件：Stormbringer（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer, based on your selections in the tool above:

- **适用条件：Stormbringer（启用）；Ascendance（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer cycles [[spell:187880]] <em>aggressively</em>. This is spent as a priority on [[spell:454009]] (aiming to use it with **10** stacks), and otherwise on [[spell:188443]] with **9+** stacks. During [[spell:467263]] or [[spell:384352]] procs, use [[spell:187874]] / [[spell:115356]] to spend with [[spell:384444]].
- **适用条件：Stormbringer（启用）；Deeply Rooted Elements（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer cycles [[spell:187880]] <em>aggressively</em>. This is spent as a priority on [[spell:454009]] (aiming to use it with **10** stacks), and otherwise on [[spell:188443]] with **9+** stacks. During [[spell:467263]] procs,  use [[spell:187874]] / [[spell:115356]] to spend with [[spell:384444]].
- **适用条件：Stormbringer（启用）；Deeply Rooted Elements（未启用）；Ascendance（未启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer cycles [[spell:187880]] <em>aggressively</em>. This is spent as a priority on [[spell:454009]] (aiming to use it with **10** stacks), and otherwise on [[spell:188443]] with **9+** stacks. During [[spell:384352]], use [[spell:187874]] / [[spell:115356]] to spend with [[spell:384444]].
- **适用条件：Stormbringer（启用）。** [[spell:470057]] should be cast on cooldown to make use of the new 2-piece. [[spell:187874]] should also be cast whenever available, reacting to [[spell:1262713]] procs. After that, [[spell:17364]] is your go-to strike, using it to apply [[spell:210689]] via [[spell:289874]]. [[spell:60103]] is your last resort filler.

**适用条件：Totemic（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, based on your selections in the tool above:

- **适用条件：Totemic（启用）；Ascendance（未启用）；Deeply Rooted Elements（未启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic should cast [[spell:444995]] every minute, followed by [[spell:197214]] to trigger [[spell:453406]]. Follow with [[spell:384352]], then begin [[spell:201900]] straight after, leveraging the double cast from [[spell:1260874]] for burst.
- **适用条件：Totemic（启用）；Ascendance（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic should cast [[spell:444995]] every minute, followed by [[spell:197214]] to trigger [[spell:453406]]. Follow with [[spell:114051]], then begin [[spell:201900]] straight after, leveraging the double cast from [[spell:1260874]] for burst.
- **适用条件：Totemic（启用）；Deeply Rooted Elements（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic should cast [[spell:444995]] every minute, followed by [[spell:197214]] to trigger [[spell:453406]]. Follow up by starting your [[spell:201900]] window, since [[spell:378270]] has no on-demand cooldowns to sync up.
- **适用条件：Totemic（启用）。** [[spell:60103]] is cast on cooldown during [[spell:201900]] to trigger [[spell:445035]]. Cast [[spell:470057]] on cooldown to activate your 2-piece, and use [[spell:187874]] whenever it's available. [[spell:17364]] is your backup generator.
- **适用条件：Totemic（启用）。** [[spell:187880]] spenders are used to activate [[spell:1260644]] and [[spell:1250364]].
  Spend to extend [[spell:201900]], or lower the cooldown of [[spell:60103]] while it's active. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic spends at **10** stacks.

---

:::details FAQWhat Target Count do I Switch to Chain Lightning?
Regardless of which Hero Tree being played, you should generally switch over to

[[spell:188443]]

the moment there's a second target.

:::

:::details FAQShould I "Hard Cast" Maelstrom Spenders?
Never. The practice of "Hard Casting" involves using spenders below 5

[[spell:187880]]

stacks (incurring a cast time). This both makes them inefficient by not leveraging the damage bonus, and resets the swing timer leading to even more waste. If you're doing this regularly, it's a big contributor to performance losses.

:::

:::details FAQShould I use Earth Elemental as a DPS Cooldown?
Generally, no. Even with full uptime for the entire minute, it does far less damage than even your weakest abilities. It's much better to use it as a survival tool for the health bonus , or saved as an emergency tool if not using

[[spell:1279819]]

.

:::

### ST Opener

1.5.

#### Enhancement Shaman Single Target Opener

**适用条件：Totemic（启用）。** The Enhancement opener is quite fast in Midnight, getting into cooldowns early. With ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic chosen, there's a more precise sequence to get the most out of your first [[spell:444995]].

**适用条件：Stormbringer（启用）。** The Enhancement opener is quite fast in Midnight, getting into cooldowns early. With ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer chosen, you want to get all your buffs set up and immediately start cycling [[spell:187880]].

![](<https://static.icy-veins.com/images/common/button-icons/important.png>) Potions can be switched in the expandable Active Talents tab above

---

**适用条件：Totemic（启用）。**

[[spell:187874]]

1s

**适用条件：Potion of Recklessness（启用）。**

[[item:241288]]

Pre

Pull

**适用条件：Potion of Recklessness（启用）。**

[[spell:470057]]

**适用条件：Liquid Luster（启用）。**

**适用条件：Liquid Luster（启用）。**

[[spell:470057]]

**适用条件：Liquid Luster（启用）。**

[[item:271886]]

[[spell:444995]]

[[item:270175]]

**适用条件：Sundering（启用）。**

[[spell:197214]]

[[spell:60103]]

**适用条件：Sundering（启用）；Primordial Storm（启用）。**

**适用条件：Sundering（启用）；Primordial Storm（启用）。**

[[spell:1218047]]

**适用条件：Sundering（启用）；Primordial Storm（启用）。**

[[spell:384352]]

**适用条件：Sundering（未启用）。**

[[spell:187874]]

**适用条件：Sundering（未启用）。**

[[spell:384352]]

[[spell:60103]]

[[spell:187874]]

**适用条件：Stormbringer（启用）。**

**适用条件：Liquid Luster（启用）。**

[[item:271886]]

12s

[[spell:187874]]

1s

**适用条件：Potion of Recklessness（启用）。**

[[item:241288]]

Pre

Pull

[[spell:470057]]

**适用条件：Sundering（启用）；Surging Elements（启用）。**

[[spell:197214]]

**适用条件：Deeply Rooted Elements（启用）。**

[[spell:187874]]

**适用条件：Deeply Rooted Elements（启用）。**

[[spell:17364]]

**适用条件：Deeply Rooted Elements（未启用）。**

[[spell:17364]]

**适用条件：Ascendance（启用）。**

**适用条件：Ascendance（启用）。**

[[spell:114051]]

**适用条件：Ascendance（启用）。**

[[item:270175]]

**适用条件：Primordial Storm（启用）；Sundering（启用）。**

[[spell:1218047]]

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

[[spell:1218047]]

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

[[spell:384352]]

**适用条件：Ascendance（启用）。**

**适用条件：Ascendance（启用）。**

[[spell:115356]]

[[spell:187874]]

**适用条件：Ascendance（启用）。**

[[spell:470057]]

---

1. **适用条件：Liquid Luster（启用）；Stormbringer（启用）。** Pre-pot [[item:271886]] 12 seconds before the pull
   
   - This allows it to ramp before your opening [[spell:467263]]
2. Pre-cast [[spell:187874]]
   
   - Avoid hitting anything early!
3. **适用条件：Potion of Recklessness（启用）。** Pre-pot [[item:241288]]
   
   - Pre-potting avoids stat procs switching it away from Mastery or Critical Strike
4. **适用条件：Totemic（未启用）。** Cast [[spell:470057]] on the way into melee
5. **适用条件：Totemic（启用）；Potion of Recklessness（启用）。** Cast [[spell:470057]] on the way into melee
6. **适用条件：Liquid Luster（启用）；Totemic（启用）。** Cast [[spell:470057]] on the way into melee
   
   - Use [[item:271886]] at the same time
7. **适用条件：Stormbringer（启用）。** Cast [[spell:17364]] once for [[spell:187880]]
8. **适用条件：Totemic（启用）。** Cast [[spell:444995]]
   
   - Use on-use trinkets such as [[item:270175]]
   - Use any Racial buffs
9. **适用条件：Totemic（启用）；Sundering（启用）。** Cast [[spell:197214]]
10. **适用条件：Totemic（启用）。** Cast [[spell:60103]] to trigger [[spell:201900]]
11. **适用条件：Totemic（启用）；Primordial Storm（启用）。** Cast [[spell:384352]] and immediately [[spell:1218047]]
12. **适用条件：Totemic（启用）；Primordial Storm（未启用）。** Cast [[spell:384352]] into [[spell:187874]]
13. **适用条件：Totemic（启用）。** Cast [[spell:60103]]
14. **适用条件：Totemic（启用）；Primordial Storm（启用）。** Cast [[spell:187874]]
15. **适用条件：Stormbringer（启用）；Sundering（启用）；Surging Elements（启用）。** Cast [[spell:197214]] to trigger [[spell:382042]]
16. **适用条件：Stormbringer（启用）；Lashing Flames（启用）。** Cast [[spell:60103]] to apply [[spell:334046]]
17. **适用条件：Stormbringer（启用）；Ascendance（启用）。** Cast [[spell:114051]]
    
    - Use on-use trinkets such as [[item:270175]]
    - Use any Racial buffs
18. **适用条件：Stormbringer（启用）；Ascendance（未启用）；Deeply Rooted Elements（未启用）。** Cast [[spell:384352]]
    
    - Use on-use trinkets such as [[item:270175]]
    - Use any Racial buffs
19. **适用条件：Stormbringer（启用）；Ascendance（启用）。** Cast [[spell:187874]] whenever available
20. **适用条件：Stormbringer（启用）；Ascendance（启用）。** Cast [[spell:115356]] every GCD possible otherwise
21. **适用条件：Stormbringer（启用）；Ascendance（启用）。** Cast [[spell:470057]] as soon as its cooldown expires
22. **适用条件：Stormbringer（启用）；Primordial Storm（启用）。** Cast [[spell:1218047]] with **10** [[spell:187880]] before it expires
23. Continue with normal ability priority.

---

**适用条件：Stormbringer（启用）。** Thankfully, the Midnight opener is much simpler than previous iterations, especially when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer. Your goal is to get any low value buffs rolling before entering into [[spell:114051]], so you can focus on triggering [[spell:384444]] as much as possible.

**适用条件：Totemic（启用）。** Thankfully, the Midnight opener is a bit simpler than previously for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, though there is still an emphasis on sequencing your first [[spell:444995]] correctly. The main goal is to spend all of your [[spell:445024]] motes effectively, and begin extending [[spell:201900]] through [[spell:1260644]].

- **适用条件：Potion of Recklessness（启用）。** When using [[item:241288]], you <em>need</em> to ensure it grants Critical Strike or Mastery with your current gear.
- **适用条件：Liquid Luster（启用）。** [[item:271886]] is used 12 seconds before the pull to ramp it before [[spell:114051]].

### AoE Opener

1.6.

#### Enhancement Shaman AoE Opener

**适用条件：Stormbringer（启用）。** Much like in single-target, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer opener aims to get your buffs set up as quickly as possible so you can start cycling [[spell:187880]].

**适用条件：Totemic（启用）。** In AoE, the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic opener is similar, but it has slightly different sequencing to push the most damage possible out of your [[spell:445024]] motes.

![](<https://static.icy-veins.com/images/common/button-icons/important.png>) Potions can be switched in the expandable Active Talents tab above

---

**适用条件：Totemic（启用）。**

**适用条件：Potion of Recklessness（启用）。**

[[item:241288]]

Pre

Pull

**适用条件：Potion of Recklessness（启用）。**

[[spell:470057]]

**适用条件：Liquid Luster（启用）。**

**适用条件：Liquid Luster（启用）。**

[[spell:470057]]

**适用条件：Liquid Luster（启用）。**

[[item:271886]]

[[spell:444995]]

[[item:270175]]

**适用条件：Sundering（启用）。**

[[spell:197214]]

[[spell:187874]]

[[spell:384352]]

[[spell:60103]]

**适用条件：Primordial Storm（启用）。**

[[spell:1218047]]

**适用条件：Primordial Storm（启用）。**

[[spell:60103]]

**适用条件：Stormbringer（启用）。**

**适用条件：Potion of Recklessness（启用）。**

[[spell:187874]]

1s

**适用条件：Potion of Recklessness（启用）。**

[[item:241288]]

Pre

Pull

**适用条件：Liquid Luster（启用）。**

**适用条件：Liquid Luster（启用）。**

[[spell:187874]]

**适用条件：Liquid Luster（启用）。**

[[item:271886]]

[[spell:470057]]

**适用条件：Sundering（启用）；Surging Elements（启用）。**

[[spell:197214]]

**适用条件：Deeply Rooted Elements（启用）。**

[[spell:187874]]

**适用条件：Deeply Rooted Elements（启用）。**

[[spell:17364]]

**适用条件：Deeply Rooted Elements（未启用）。**

[[spell:17364]]

**适用条件：Ascendance（启用）。**

**适用条件：Ascendance（启用）。**

[[spell:114051]]

**适用条件：Ascendance（启用）。**

[[item:270175]]

**适用条件：Primordial Storm（启用）；Sundering（启用）。**

[[spell:1218047]]

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

[[spell:1218047]]

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

[[spell:384352]]

**适用条件：Ascendance（启用）。**

**适用条件：Ascendance（启用）。**

[[spell:115356]]

[[spell:187874]]

**适用条件：Ascendance（启用）。**

[[spell:470057]]

---

1. **适用条件：Stormbringer（启用）；Potion of Recklessness（启用）。** Pre-cast [[spell:187874]]
   
   - Avoid hitting anything early!
2. **适用条件：Potion of Recklessness（启用）。** Pre-pot [[item:241288]]
   
   - Pre-potting avoids stat procs switching it away from Mastery or Critical Strike
3. **适用条件：Liquid Luster（启用）；Stormbringer（启用）。** Cast [[spell:187874]] as soon as you reach melee
   
   - Use [[item:271886]] as the pull starts
4. **适用条件：Potion of Recklessness（启用）；Totemic（启用）。** Cast [[spell:470057]] on the way into melee
5. **适用条件：Potion of Recklessness（启用）；Stormbringer（启用）。** Cast [[spell:470057]] on the way into melee
6. **适用条件：Liquid Luster（启用）；Totemic（启用）。** Cast [[spell:470057]] on the way into melee
   
   - Use [[item:271886]] as the pull starts
7. **适用条件：Stormbringer（启用）。** Cast [[spell:17364]] once for starting [[spell:187880]]
8. **适用条件：Totemic（启用）。** Cast [[spell:444995]]
   
   - Use on-use trinkets such as [[item:270175]]
   - Use any Racial buffs
9. **适用条件：Totemic（启用）；Sundering（启用）。** Cast [[spell:197214]]
10. **适用条件：Totemic（启用）。** Cast [[spell:384352]] and immediately [[spell:187874]]
11. **适用条件：Totemic（启用）。** Cast [[spell:60103]] to trigger [[spell:201900]]
12. **适用条件：Totemic（启用）；Primordial Storm（启用）。** Cast [[spell:1218047]]
13. **适用条件：Totemic（启用）；Primordial Storm（启用）。** Cast [[spell:60103]]
14. **适用条件：Stormbringer（启用）；Surging Elements（启用）；Sundering（启用）。** Cast [[spell:197214]] to trigger [[spell:382042]]
15. **适用条件：Stormbringer（启用）；Ascendance（启用）。** Cast [[spell:114051]]
    
    - Use on-use trinkets such as [[item:270175]]
    - Use any Racial buffs
16. **适用条件：Stormbringer（启用）；Ascendance（未启用）；Deeply Rooted Elements（未启用）。** Cast [[spell:384352]]
    
    - Use on-use trinkets such as [[item:270175]]
    - Use any Racial buffs
17. **适用条件：Stormbringer（启用）；Primordial Storm（启用）。** Cast [[spell:1218047]] with **10** [[spell:187880]]
18. **适用条件：Stormbringer（启用）；Ascendance（启用）。** Cast [[spell:187874]] if [[spell:333974]] resets it, or whenever available
19. **适用条件：Stormbringer（启用）；Deeply Rooted Elements（启用）。** Cast [[spell:187874]]
20. **适用条件：Stormbringer（启用）；Ascendance（未启用）。** Cast [[spell:17364]] twice
21. **适用条件：Stormbringer（启用）；Ascendance（启用）。** Cast [[spell:115356]] every GCD otherwise
22. **适用条件：Stormbringer（启用）；Ascendance（启用）。** Cast [[spell:470057]] as soon as its cooldown expires
23. Continue with normal ability priority.

---

**适用条件：Totemic（启用）。** While the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic opener does get you into cooldowns very quickly, to get the most out of it the sequencing needs to be precise. In particular, having [[spell:384352]] active for your double [[spell:60103]] from [[spell:1260874]] leads to a huge amount of damage from your imbuements. While pre-casting [[spell:470057]] gives a chance for [[spell:333974]] to proc a reset on [[spell:187874]], it needs access to it during the opening sequence, so can't pre-cast.

**适用条件：Stormbringer（启用）。** Much like in single-target, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer follows the simple rule of getting into burst as soon as possible, so it can begin cycling [[spell:187880]] to reach [[spell:454009]]. With the Season 2 Tier Set, it's possible for your opening [[spell:470057]] to fully reset [[spell:187874]]'s cooldown, so pre-casting it to gamble on the free stack is worth it.

- **适用条件：Potion of Recklessness（启用）。** With [[item:241288]], you <em>need</em> to make sure it triggers either Critical Strike or Mastery with your current gear.

2.

### Midnight Season 2 Tier Set

Season 2 of Midnight introduces the **Ophidian Oracle's Prophecy**, available
from different endgame content. This provides the following bonuses:

- [[spell:1296627]] – [[spell:470057]] causes
  	your target to erupt in a [[spell:333974]] every 2 sec for 6 sec.
      Fire Nova deals 200% increased damage to the primary target of your
  	Voltaic Blaze.
- [[spell:1296628]] – [[spell:333974]] reduces the
  	cooldown of [[spell:187874]] by 2 sec, and increases the damage of your
  	next Crash Lightning by 8%, stacking up to 5 times.

There are a lot of moving parts to how the set works, but the most important
takeaway is that it puts [[spell:470057]] at the top of your rotational
priority once you have the 2-piece. The 4-piece also adds extra GCD requirements
to keep [[spell:187874]] on cooldown, due to the additional CDR. The way
these effects currently work is:

- The 2-piece triggers a <em>single</em> [[spell:333974]] pulse from your
    target every two seconds from the [[spell:1299975]] effect.
- The damage vulnerability to your [[spell:333974]] applies to
    <em>all</em> pulses that hit your target if the Fire Nova talent itself procs
    in AoE.
- If [[spell:333974]] does proc in AoE, the 4-piece provides CDR <em>per nova
    triggered</em>, meaning that it can fully reset [[spell:187874]]'s
    cooldown.

These bonuses are exceptionally strong compared to our weaker Season 1 bonus,
providing a boost to our single-target, cleave and even priority damage in AoE.
Completing the set should be your first gearing priority in Season 2, and you
should make the swap as soon as you unlock the 2-piece.

2.1.

#### Enhancement Shaman Mechanics Breakdown

In the below sections, we'll be covering the finer details of specific
  mechanics that drive Enhancement's gameplay loop. While some things have been
  simplified in Midnight, there are still a lot of underlying mechanics for each of
  our major cooldowns, rotational abilities, and procs. This is a more advanced
  section, aiming to help you get a better understanding of the <em>why</em>
  behind button presses.

3.

### Enhancement Mechanics Explained

### Maelstrom Weapon   Management

3.1.

#### Maelstrom Weapon Details

[[spell:187880]] management is crucial if you intend to play
Enhancement at a competitive level. This has a 20% chance to trigger from any
melee hit, and stacks up to 5 times (or up to 10 with [[spell:384143]]).
Each stack reduces the cast time of your next [[spell:188196]] / [[spell:188443]]
cast by 20%, and also increases the damage of affected spells by 20%. At 5 stacks,
these abilities become instant. Only 5 stacks can be consumed at a time, but this
increases to 10 with [[spell:384149]] taken.

- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer** builds aim to spend at **9+**, but depending
    on the situation may spend lower, usually to fish for [[spell:1262635]]
    and [[spell:455110]] procs if they run out of generators.
  
  - During [[spell:114051]], [[spell:115356]] and [[spell:187874]]
    	will naturally spend all of your available [[spell:187880]] every
    	cast due to [[spell:384444]]. This is <em>always</em> more
    	valuable than spending manually, both for the damage the ability itself deals,
    	and	the extra resources it generates by saving that GCD.
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic** aims to spend at **10** stacks, but this can be
    lower if it means you'll extend [[spell:201900]] via [[spell:1260644]]
    long enough to squeeze in another [[spell:60103]].
  
  - During [[spell:384352]], both [[spell:17364]] and [[spell:187874]]
    	will automatically spend [[spell:187880]] with each cast via
    	[[spell:384444]]. This often means weaving these between
    	[[spell:60103]] casts, extending a long [[spell:201900]] window, and
    	utilizing [[spell:1250364]] CDR.

While it is tempting to cast these spells as soon as you hit 5 stacks, you
should train yourself to make use of the 10-stack limit granted by
[[spell:384143]]. If you are not at risk of overcapping your
[[spell:187880]] stacks, then it makes more sense to focus on keeping
your other abilities on cooldown.

3.1.1.

##### Elemental Tempo

Added in Midnight, [[spell:1250364]] provides cooldown reduction to <em>both</em>
[[spell:17364]] and [[spell:60103]] whenever you spend [[spell:187880]].
This provides 0.3 seconds off per stack spent, and bridges gaps between GCDs if
you're running out of available buttons. This works well with [[spell:1260644]]
for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, bringing a 1➜2➜1 ability cycle when spending in between.

3.1.2.

##### Thunder Capacitor

[[spell:1262635]] provides a 20% chance to refund all [[spell:187880]]
spent on [[spell:188196]] and [[spell:188443]]. These procs often
require some reaction speed to catch them before you hit your planned button, but
this means spending at lower stacks can sometimes be worth it to fish for a refund.
This is especially useful if you're running out of rotational buttons to use, and
need [[spell:1250364]] CDR.

### Crash Lightning   Mechanics

3.2.

#### Crash Lightning Explained

[[spell:187874]] looks simple on the surface, but has a few less obvious
components. In Midnight, it's a core aspect of Enhancement gameplay in
<em>all</em> situations, and is even the focus of our Apex Talent -
[[spell:1262713]], covered in the next tab. Due to that, there are some
things to understand:

- The [[spell:187874]] buff is triggered for 12 seconds when <em>cast</em>.
  It **does not matter** if you hit anything.
- While active, [[spell:17364]] and [[spell:60103]] will trigger a
  **separate** damage splash event, <em>also</em> called Crash
  Lightning, that splits between up to 5 enemies.
- **All [[spell:187874]] damage**, both active and splash, can trigger
  [[spell:187880]].
- The **initial cast** of [[spell:187874]] can trigger individual
  [[spell:33757]] events on targets hit.

The above means that you should aim to be casting [[spell:187874]] <em>on
cooldown</em>. The benefits of bonus damage on our core strikes, while providing
extra resource generation, turn it into a maintenance effect. This is especially
true in AoE: although no bonus damage is gained from hitting extra targets
because it splits, each hit <em>does</em> trigger extra events that can generate
[[spell:187880]]. Finally, in Midnight this also triggers
[[spell:384444]] during either [[spell:384352]] or
[[spell:114051]].

3.2.1.

##### Converging Storms and Stormwell

[[spell:384363]] causes each target hit by the initial
[[spell:187874]] cast to increase the damage of your next
[[spell:17364]] cast by 25% per target hit, stacking up to 6 (for a maximum
of 150%). This activates even on a single-target, and is a modest boost to funnel
for builds that can fit it in.

[[spell:1264762]] is a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer-only talent, adding additional
value when cast against exclusively one target. This causes [[spell:187874]]
to **guarantee** that it procs [[spell:33757]] on your target if it hits
no other enemies. This is considered an independent proc, so your cast can technically
trigger it twice.

### Storm Unleashed   Apex Talent

3.3.

#### Enhancement Shaman Apex Talent – Storm Unleashed

The Enhancement Apex Talent, [[spell:1262713]], is mostly centered around
[[spell:187874]]. This brings it more clearly into a core part of the
rotation, having strong benefits for both single-target and AoE situations.
While a lot of it is passive, the things it does affect are used extensively,
regardless of the build played:

- [[spell:1262713]] **first point –** grants each stack of
    [[spell:187880]] spent a 2% chance to cause your next [[spell:187874]]
    cast to ignore its cooldown. Additionally, the Crash Lightning weapon enhancement
    buff can now stack and overlap.
- [[spell:1262761]] **second and third points –** increases the damage
    dealt by [[spell:187880]] spenders by 7.5%, and weapon imbue damage by 10%
    per point.
- [[spell:1252373]] **fourth point –** causes [[spell:187874]]
    to also create a static pool, dealing an additional 100% of the
    initial cast's damage over 2 seconds. Additionally, the weapon enhancement buff
    grants 15% increased auto-attack speed per stack.

The resets happen frequently throughout combat, with roughly one in five 10-stack
[[spell:187880]] spenders triggering the effect (using a deck-of-cards
proc system) on average. These procs <em>can</em> be pooled up, allowing you to
fire off multiple [[spell:187874]] casts in succession, while also stacking
up weapon enhancement overlaps.

These overlaps cause the effect to amplify the damage dealt by each splash. This
bonus is dealt <em>all at once</em> rather than additional individual procs, meaning
the bonus [[spell:187880]] it can generate remains static. The attack speed
buff provided by the fourth point <em>does also</em> stack up when the buff
overlaps.

### **Weapon Imbues**   & Group Buffs

3.4.

#### Enhancement Weapon Imbuements

Your Weapon Imbues should **always** be active, as they confer a strong
benefit. Some notes on each are:

- **[[spell:33757]] -** only applied to the **Main-Hand**, these
  additional strikes are considered special attacks and, as such, can generate
  [[spell:187880]].
- **[[spell:318038]] -** only applied to the **Off-Hand**, this
  causes <em>all</em> weapon attacks to trigger an additional hit of fire damage,
  and doubles the damage your [[spell:60103]] deals while active.

With [[spell:1270350]] taken, this will also automatically apply
both imbuements to the appropriate weapon when casting [[spell:192106]].
This happens all at once with no extra GCD cost.

3.5.

#### Elemental Shields

You can have one Elemental Shield active at a time, or two with [[spell:383010]]
taken. [[spell:192106]] is the primary choice here due to the bonus Agility
provided by [[spell:1270350]].

[[spell:383010]] should be strongly considered to allow you to have
[[spell:974]] active at the same time. This should also be paired
with [[spell:1217622]], allowing for permanent uptime and extra self-healing.
Additionally, this lets you keep it up on another party member - usually
your tank.

3.6.

#### Skyfury

[[spell:462854]], granted by any Shaman, provides a flat increase to Mastery
rating to all Party and Raid members. It also has additional benefits for
melee characters, providing a 20% chance to proc an additional auto-attack
each swing, with a 0.5-second internal cooldown per player. This does not
trigger from missed attacks, and can miss itself. These extra attacks count as
regular auto-attacks, meaning they proc all on-hit effects, but they **do not**
affect Hunter auto-shots, pets, or guardians.

3.7.

#### Enhancement Shaman Major Cooldowns

Throughout the talent tree, there are a few different cooldown options that
provide burst in different ways. Below, we'll be covering each of them, how they
impact the rotation, and how to use them.

4.

### Important Cooldowns for Enhancement Shaman

### Doom Winds

4.1.

#### Doom Winds

[[spell:384352]] is a 1-minute cooldown, off-GCD ability that grants 50%
increased chance to trigger [[spell:33757]] for 8 seconds, and pulses
Stormstrike (Nature/Physical) damage around you. New in Midnight, this inherits
<em>both</em> the [[spell:384411]] and [[spell:384444]]
effects. This generates up to 2 [[spell:187880]] per second, and
causes [[spell:17364]] / [[spell:187874]] to discharge spenders when
used. Additionally, Thorim's Invocation increases its duration by 2 seconds
when taken.

This is also <em>replaced</em> by either [[spell:114051]] or
[[spell:378270]] if taken, so serves as a lower point cost cooldown
option. It's extremely well suited to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, providing an option that
syncs up with each [[spell:444995]] cast to allow you to extend
[[spell:201900]] consistently.

4.1.1.

##### Thorim's Invocation Details

[[spell:384444]] causes [[spell:17364]] and [[spell:187874]]
casts while active to discharge a [[spell:187880]] spender, consuming all
of your current stacks. This has some extra details that might not be as clear
from the tooltip alone, and has a few interactions to be aware of, regardless of
which cooldown you pick. It has two priming states - [[spell:188196]] and
[[spell:188443]] - and can be switched dynamically by some abilities,
particularly in AoE scenarios:

- Any [[spell:188196]] and [[spell:188443]] cast will set
  [[spell:384444]] manually to the respective spell. This
  switch is **not** triggered by [[spell:289874]].
- Make sure **before** each [[spell:384352]] / [[spell:114051]]
  cast you are primed to the correct spell:
  
  - **Single Target -** [[spell:188196]]
  - **AoE -** [[spell:188443]]
- [[spell:454009]] is <em>dynamic</em>, meaning the number of targets hit
  dictates priming. If it hits only one target, it sets to [[spell:188196]],
  while if it hits two or more it changes to [[spell:188443]].
  
  - [[spell:384444]] will **always** consume [[spell:454009]] if
    possible, regardless of priming.
- [[spell:1218047]] is <em>dynamic</em>, and will prime you to whichever
  of the two spells it casts at the end of its sequence. This is decided by the number
  of targets hit by the initial 3 strikes.

### Ascendance

4.2.

#### Ascendance

[[spell:114051]] <em>replaces</em> [[spell:384352]] when taken,
and instead has a 2-minute cooldown. This is **on** the GCD, but also triggers
Doom Winds for free when activated (with a 10-second duration). It lasts
for 15 seconds, inherits both [[spell:384411]] and [[spell:384444]],
and while active, your [[spell:17364]] and auto-attacks are converted to
[[spell:115356]] and [[spell:114089]]. These both have a 30-yard range, ignore
all armor, and Windstrike has a 60% reduced cooldown.

This provides a very consistent way to repeatedly trigger [[spell:384444]],
weaving in [[spell:187874]] between casts. Additionally, it provides a
0.5% chance to trigger [[spell:384352]] per [[spell:187880]] spent when
[[spell:114051]] is <em>not</em> active.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer additionally activates [[spell:454009]] when cast,
making it the preferred cooldown option at the bottom of the tree.

4.2.1.

##### Deeply Rooted Elements

Also replaces [[spell:384352]] when taken, instead providing a 0.6% chance per
[[spell:187880]] spent to trigger <em>both</em> [[spell:114051]]
and Doom Winds, lasting 8 and 10 seconds respectively. This is significantly
less predictable, but can provide explosive burst provided RNG is on your side.
This isn't currently a worthwhile option in Midnight, but may change in
the future.

### Sundering

4.3.

#### Sundering

[[spell:197214]] deals heavy Flamestrike damage to all targets in a line in
front of you, with a 30-second cooldown. When playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, this
also consumes the [[spell:453406]] mote following each [[spell:444995]]
cast, dealing increased damage and spawning a Searing Totem. Its place is as a
mid-range burst tool, especially with follow-up talents in AoE.

4.3.1.

##### Surging Elements

[[spell:382042]] provides 15% Haste for 12 seconds whenever you cast
[[spell:197214]]. Additionally, it causes Sundering to generate 5 stacks
of [[spell:187880]] when used. Note that [[spell:445035]] <em>does not</em>
trigger the Haste boost or generate bonus Maelstrom when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic.

4.3.2.

##### Primordial Storm

[[spell:1218047]] is a combo skill follow-up available after casting
[[spell:197214]]. When cast, this triggers a 4-step attack that always
happens in the same order:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_ascendance.jpg>) **Primordial Storm Order**
**Fire strike**

➜

**Frost strike**

➜

**Lightning strike**

➜

**empowered [[spell:187880]]
spender**

:::

The first 3 strikes are considered **Main-Hand** strikes, and hit in
AoE, meaning they each individually trigger weapon imbues on targets hit.
Lastly, this also consumes [[spell:187880]] to amplify the damage of
**all** hits. The spender chosen is decided by how many targets are hit by the
strikes - [[spell:188196]] is the default, switching to [[spell:188443]]
if two or more targets are hit. This <em>does not</em> become available after triggering
[[spell:197214]] via [[spell:445035]].

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Small rotational updates and shift to Totemic as Mythic+ recommendation.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **16 Mar. 2025:** Adjusted recommendations to more firmly be on Totemic.
- **04 Mar. 2025:** Added Witch Doctor's Ancestry back to recommendations and rotation tool.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7, added a more detailed Thorim's Invocation section.
- **05 Nov. 2024:** Significant priority list updates closer to more recent 11.0.5 knowledge.
- **21 Oct. 2024:** First pass update for Patch 11.0.5. Will be updated as more live data comes in.
- **23 Sep. 2024:** Updated for most recent hotfixes and Storm build switch.
- **09 Sep. 2024:** Updated for Elemental Blast and Tempest hotfixes along with new Storm loadouts.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6, condensed insights section.
- **15 Jan. 2024:** Reviewed for Patch 10.2, slight structure changes but content remains accurate.
- **06 Nov. 2023:** Updated for Patch 10.2 and restructured the rotation tool.
- **04 Sep. 2023:** Restructured cooldown section, but no content changes needed for 10.1.7.
- **14 Jul. 2023:** Added build loadout buttons to switches for easier rotation display.
- **13 Jul. 2023:** Cleaned up AoE rotation section with improvements for Storm.
- **10 Jul. 2023:** Updated for Patch 10.1.5 to remove 4-piece use from Storm and highlight Stormstrike over spenders.
- **04 May 2023:** Tweaks to rotation tool, added warnings to false talent combinations.
- **01 May 2023:** Overhauled for Patch 10.1 updates, with Storm builds, rotation tool updates, T30 bonuses and added sections.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and improved rotation tool to align closer to current gameplay.
- **11 Dec. 2022:** Added Tier Set section.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Enhancement Shaman in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Enhancement Shaman

Welcome to our Gear and BiS Page for Enhancement Shaman for Midnight! 
Check this page to learn everything you need to know about gearing an
Enhancement Shaman, including the BiS Gear from all sources, Raiding,
and Mythic+, information on the best Trinkets, Tier Sets, and much more.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system, allowing
you to increase the item level of gear along tracks relating to the level of
content it was obtained from. Harder content drops gear on higher level tracks, thus
reaching higher Item Levels. For more information, read up on our dedicated page
on how the [gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works in
Midnight.

The 12.1.5 update brings with it the release of [[item:280562]],
allowing 334 Weapons, Trinkets, and Necklaces to be upgraded all the way to 340
item level. Additionally, it brings the new boss Kith'ix, which drops powerful
new loot, with some big pick-ups on offer for Enhancement.

:::details ![](<https://static.icy-veins.com/images/wow/tools/recommended.png>) **Patch 12.1.5 Gearset Notice**
Kith'ix introduces multiple new cantrip items that are worth equipping, meaning
some slots need to be adjusted to fit into the stat budget. Bear that in mind when
looking at catalyst pieces linked below.

:::

### Overall

The list below contains gear from <em>all possible endgame sources</em>, including Raids, Mythic+, Crafting, Delves and The Great Vault. It aims to provide the absolute best possible setup, but bear in mind that each **individual** item may not be the strongest in your particular gear setup. Tier pieces have the drop locations of ideal Catalyst pieces listed if they're stronger than the standard version.

Note that in Season 2, gearing is quite complicated. We want Critical Strike to be <em>just above</em> Mastery for [[item:241288]], and then get Mastery and Haste as close as possible underneath it.

:::details FAQWhich Items Do I Use in the Catalyst?
In Midnight Season 2, the Catalyst now **retains the secondary stats and cantrips** of <em>any</em> item you convert. Therefore, it doesn't matter which slots you use to activate your set bonus, and instead what matters is the items you input.

The absolute best pieces currently available to Catalyze in each slot are:

- **Helm –** [[item:271483@JAACAAgNyA]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- **Shoulders –** [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Chest –** [[item:271876@JAAEAAAG2YhN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **Gloves –** [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Legs –** [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

Similar to Season 1, your <em>number one priority</em> is to acquire the 4-piece bonus through any means to unlock **Catalyst Unbound** for Season 2.

:::

:::details FAQAre There Any High Priority Great Vault or Voidcore Items to Look Out For?
Any of the cantrip items available in Season 2 raids are extremely valuable, even if they aren't at item level 344 from Mythic. The following items are strongly worth considering even from a Heroic Vault, and are even worth using Voidcores on to obtain if you don't expect to progress Mythic quickly:

1. [[item:268209@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
2. [[item:270175@JAACAAAG2A]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
3. [[item:270173@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271876@JAAEAAAG2YhN]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281238@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

All three new [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) items are also quite strong, making it a good Voidcore candidate. Items in this pool are strong enough that if you <em>aren't</em> killing any Mythic bosses for higher vault rewards, you always have the option to pick up a Voidcore from your Great Vault if none of these show up.

:::

:::details FAQDo I put my Highest Item Level Weapon in the Main or Off-Hand?
Enhancement

**always**

puts its highest item-level weapon in the

**Main-Hand**

regardless of your Hero Tree choice. While

[[spell:60103]]

only scales with your Off-Hand and some builds use it extensively,

<em>everything else</em>

gains more from your Main-Hand scaling.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271484@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240900]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271482@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271486@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237850@JAAMAAwt1ENMMYzy1klIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Mythic+

The gearset below contains the best items available from Mythic+, using gear only available from dungeons in the Season 2 pool, alongside your ideal Tier Set catalyst locations and Crafted items for Embellishments. Note that this is a list of the <em>best items available</em> from Mythic+ dungeons, **not** a strict list of what you should be using in Mythic+ content.

:::details FAQWhich Items Do I Use in the Catalyst?
In Midnight Season 2, the Catalyst now **retains the secondary stats and cantrips** of <em>any</em> item you convert. Therefore, it doesn't matter which slots you use to activate your set bonus, and instead what matters is the items you input.

The best **Dungeon only** pieces to Catalyze in each slot are:

- **Helm –** [[item:251220@JAACAAgNyA]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **Shoulders –** [[item:239049@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **Chest –** [[item:273789@JAACAAgNyA]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- **Gloves –** [[item:193752@JAAKAAQkCYHKvbRLfYjM]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- **Legs –** [[item:159375@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

Similar to Season 1, your <em>number one priority</em> is to acquire the 4-piece bonus through any means to unlock **Catalyst Unbound** for Season 2.

:::

:::details TipsWhich Dungeons Should I Farm?
All of Enhancement's strongest pieces are sourced from Raids in Season 2, but there are some worthwhile alternatives to hunt while you wait to get hold of them:

1. [[item:273796@JAACAAgNyA]] - [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
2. [[item:273792@JAACAAgNyA]] - [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
3. [[item:251220@JAACAAgNyA]] - [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
4. [[item:252258@JAACAAgNyA]] - [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:251155@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271481@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271486@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251224@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237850@JAAMAAwt1ENMMYzy1klIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Raid

The gearset below is your **raid** Best-in-Slot list, using gear from **only** raid drops, as well as ideal Tier Set pieces (or items to use in the Catalyst) and crafted items to activate Embellishment effects. Note that this is a list of the <em>best items available</em> within the Raid, **not** a strict list of what you should be using inside the raid.

:::details FAQWhich Items Do I Use in the Catalyst?
In Midnight Season 2, the Catalyst now **retains the secondary stats and cantrips** of <em>any</em> item you convert. Therefore, it doesn't matter which slots you use to activate your set bonus, and instead what matters is the items you input.

The best **Raid only** pieces to Catalyze in each slot are:

- **Helm –** [[item:271483@JAACAAgNyA]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- **Shoulders –** [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Chest –** [[item:271876@JAAEAAAG2YhN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **Gloves –** [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Legs –** [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

Similar to Season 1, your <em>number one priority</em> is to acquire the 4-piece bonus through any means to unlock **Catalyst Unbound** for Season 2.

:::

:::details TipsWhat Are My Top Items To Chase?
Enhancement has some extremely high value cantrip picks available in Season 2 raids, weighted heavily toward the final two bosses of The Venomous Abyss. Nearly all of these items are worth obtaining due to their increased item level, but some are particularly strong:

1. [[item:268209@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
2. [[item:270175@JAACAAAG2A]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
3. [[item:270173@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271876@JAAEAAAG2YhN]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281238@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

It's worth noting that all three new [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) items are strong. Gloves are always used, although [[item:281029@JAACAAgNyA]] requires some gearing around. Lastly, [[item:281215@JAACAAAOyA]] is more suited to AoE in your trinket slot, but most importantly there are no misses on the loot table.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271484@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240900]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271482@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271486@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237850@JAAMAAwt1ENMMYzy1klIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Enhancement Shaman

Enhancement ideally wants to get one on-use trinket to pair with the strong
cooldowns used by each respective Hero Tree - [[spell:444995]] or
[[spell:114051]] - alongside a passive trinket.

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Trinkets to Hunt in Midnight**
**On-Use –**

[[item:270175@JAACAAAG2A]]

**Passive –**

[[item:270173@JAACAAAG2A]]

or

[[item:281215@JAACAAAOyA]]

:::

You can click below to open a ranking chart for other trinkets, in case you've
picked something else up and are looking to check how it stacks up.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Enhancement Season 2 Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270175@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   This is by far the best on-use option available in Season 2, despite&#10;		   being on an awkward 1m30s cooldown. No other option comes close in&#10;		   power, so this is one of your big chase items. Always hold it to line&#10;		   up with your [[spell:114051]] or [[spell:444995]]&#10;		   window.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270173@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   A stock-standard direct damage trinket, but gets stronger when paired&#10;		   with the cantrip weapon, [[item:268209@JAACAAAG2A]].&#10;		   This has fewer uses in AoE content, but for single-target and especially&#10;		   cleave within the raid it's the strongest passive option available.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   New in Patch 12.1.5, this is <em>the strongest</em> passive AoE trinket,&#10;		   and can even compete with Guillotine Technique if enough targets are&#10;		   present. Falls slightly behind in 1-2 target situations especially, but&#10;		   absolutely worth getting hold of for Mythic+.</p>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:273796@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Definitely not as strong as Voracious Heart, but a good alternative if&#10;		   you're in need of an on-use. When using it and [[item:241288]]&#10;		   together, make sure to pot <em>before</em> activating this to avoid&#10;		   increasing the wrong stat.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270165@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Provides extremely frequent bulk Haste, which makes up for the fact that&#10;		   we can't really stack it above Critical Strike in Season 2 and prefer&#10;		   temporary procs instead. Great to use if you can't get hold of one of&#10;		   the S Tier passive options.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Triggers a variety of different stat boosting effects, and different&#10;		   buffs can overlap. While it does have a negative proc in the pool, it's&#10;		   the best passive stat option available, making it a good pick for AoE&#10;		   heavy encounters and dungeons.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250225@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Try to always use this on a target that will live long enough for you&#10;		   to stack up the Crit buff, otherwise most of its value is lost.</p>&#10;</li>&#10;<li>[[item:250228@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159617@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Hold to line up with [[spell:114051]] / [[spell:444995]]&#10;		   depending on build. When using [[item:241288]], make sure&#10;		   to pot <em>before</em> using your trinket to avoid setting it to Crit.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   While this is tuned well and Mastery is desirable, staying within the&#10;		   zone of the proc is extremely restrictive, especially in Season 2. Due&#10;		   to both the large arenas in raid encounters and the hectic movement in&#10;		   dungeons, your mileage may vary in reality when using it.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:248583@JAACAAAMyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Go to the Jan'alai altar in Zul'Aman to set this to <strong>Mastery</strong>.</p>&#10;</li>&#10;<li>[[item:251792@JAACAAAMyA]]</li>&#10;<li>[[item:270166@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>Click for Details</em></span>&#10;<span>&#10;		   This deals an <em>extremely</em> large amount of burst damage to your&#10;		   primary target when used, alongside some bonus AoE. While it struggles&#10;		   against other options due to it being a channel with a long cooldown,&#10;		   its unique potential to be useful to deal with key enemies means it&#10;		   might be worth looking at in certain edge cases in Season 2.</span>&#10;</li>&#10;<li>[[item:265657@JAACAAAMyA]]</li>&#10;<li>[[item:250259@JAACAAAOyA]]</li>&#10;<li>[[item:274493@JAACAAAMyA]]</li>&#10;<li>[[item:158374@JAACAAAOyA]]</li>&#10;<li>[[item:251785@JAACAAAMyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:273797@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>&#10;		   Hold to line up with [[spell:114051]] / [[spell:444995]]&#10;		   depending on build.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274496@JAACAAAMyA]]</li>&#10;<li>[[item:274497@JAACAAAMyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:246304@JAAIAAwt1ENMMYDH2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>Crafted Trinket Details</em></span>&#10;<span>&#10;		   While these trinket options aren't <em>bad</em>, Embellishments are&#10;		   stronger in Season 2 compared to before. That means the opportunity cost&#10;		   of using them is too high, and they've fallen even further behind than&#10;		   they already were.</span>&#10;</li>&#10;<li>[[item:246305@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246306@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246307@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:241340@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:251784@JAACAAAMyA]]</li>&#10;<li>[[item:251783@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores and Ascendant Venomstones

Season 2 brings forward the bonus roll system introduced in Season 1,
providing a way to target big ticket items:

**[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s** can be spent after completing endgame
dungeons or defeating raid bosses, granting you an item at random from its
respective loot table. Once an item has been received through Voidcore rolls,
it cannot appear again. In Season 2, **one** Voidcore is used to roll on
dungeon loot <em>or</em> individual raid bosses, granting loot equivalent to
the item level you'd receive from a weekly Great Vault reward.

One can be acquired each week from **Orin Straylight** next to the Catalyst,
following the release of Patch 12.1.5. Additionally, one can be selected from The
Great Vault instead of an item, provided you unlocked three total rewards.

3.1.

#### Recommended Nebulous Voidcore Usage for Enhancement Shaman

Which item you should target is strongly influenced by what pieces you already
have access to, items available through the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), and what bosses
you have currently killed. While they are now more freely available following the
addition of weekly rewards in Patch 12.1.5, taking one from The Vault should be
treated as a <em>consolation prize</em> in the event that nothing better appears.

When it comes to <em>where</em> you should use Voidcore rolls when you do pick
one up however, the answer is quite simple:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Season 2 Voidcore Uses**
1. **Ula'tek** (Heroic/Mythic)
   
   - [[item:270175@JAACAAAG2A]]
   - [[item:268265@JAAGAAAG2MqNTpC]]
   - [[item:271876@JAAEAAAG2YhN]]
2. **The Coiled Altar** (Heroic/Mythic)
   
   - [[item:268209@JAACAAAG2A]]
   - [[item:270173@JAACAAAG2A]]
3. **Kith'ix** (Heroic/Mythic)
   
   - [[item:281238@JAAEAAgNyEuN]]
   - [[item:281029@JAACAAgNyA]]
   - [[item:281215@JAACAAAOyA]]

:::

:::details FAQWhen Should I Consider Voidcores From The Great Vault?
Now that the season has progressed and Voidcores are more freely available,
recommendations are more concrete. Although you now have access to more rolls, it's
still worth keeping in mind things that may make it less appealing to pick one
up:

- If you have yet to unlock your 4-piece bonus, acquiring that takes priority.
- If a key chase item from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) or [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
    is offered, pick that up.
- Look out for individual key items offered from early Mythic boss kills (such
    as a weapon from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>) or a trinket from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)),
    as they're offered at 6/6 Myth, saving crests and skipping the need to bonus
    roll for something useful.

The main thing to consider is that, while Bonus Rolls shrink the pool of things
that can be obtained on subsequent rolls (raising the chance of acquiring
chase items), getting the item you want out of the gate as a drop or from the vault
may avoid the need to invest additional Voidcores.

:::

3.2.

#### Ascendant Venomstones

Following the release of Patch 12.1.5, you can now acquire [[item:280562]],
allowing you to upgrade specific item slots all the way up to item level 340 (or
338 for crafted pieces). Using these follows a similar priority to your crest
usage:

1. **Main-Hand Weapon** first, always.
2. **On-Use Trinket** second, ideally [[item:270175@JAACAAgNyA]].
3. **Passive Trinket** third.
4. **Off-Hand Weapon** fourth.
5. **Necklace** last.

You also want to prioritize Myth track items over Hero track pieces, unless you
don't expect to acquire a Myth track variant of the piece you're upgrading. The
exception to this is one of the most difficult items to obtain from Ula'tek
in The Venomous Abyss - [[item:270175@JAACAAgNyA]]. As this
is our strongest on-use option by far, it's worth the investment even on a lower
track.

4.

### Best Crafted Items for Enhancement Shaman

Crafted gear provides one of the easiest ways to pick up high value items in a
season, allowing you to target key pieces to fill out your gearset. With the
release of Season 2, each craft requires two [[item:274476]].

Unless secondary stats are already assigned by the item, you should use
[[item:245783]] for Haste and Mastery. Depending on your
gear's stat balance, sims may offer different results - always follow
your own character's results when optimizing.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_green.jpg>) **Enhancement Crafting Order**
**[[item:237850@JAAMAAwt1ENMMYzy1klIcYD]]**

➜

**[[item:244584@JAAKAAwt1ENMMYDYwklI]]**

➜

**Optional Crafts**

:::

- Craft a **weapon first**, as it has the biggest impact early. It doesn't
  matter if you craft an Axe, Mace or Fist Weapon, but **make sure your choice
  comes with Agility**. With the newly added [[item:273060]], this
  lasts into endgame gear setups, swapping over to your Off-Hand when you get
  upgrades.
- Craft an **off-piece second** - we recommend [[item:244584@JAAKAAwt1ENMMYDYwklI]]
  in the Wrist slot. Attach [[item:240167]] as your second embellishment.
- Following this, craft items based on gaps in your current gear.

:::details FAQAre the New Embellishments in Season 2 Good?
**Some of them**. In the lead-up to the release of Season 2 many were reduced
in power, and this hasn't changed in Patch 12.1.5:

- [[item:273060]] serves as a better [[item:245876]],
    making it the best weapon Embellishment, and our current go-to pick.
- [[item:273069]] provides a stacking Haste proc. This is <em>very</em>
    close in value to [[item:240167]], but enough behind that it can't
    be justified considering the latter also buffs allies.
- [[item:273066]] was hit by <em>enormous</em> nerfs, so even despite
    the higher value of Critical Strike this season, it just can't compete with other
    options.
- [[item:270899]] also saw huge reductions, so isn't worth considering
    either.

:::

Once you have your two main Embellishment crafts, you should have a solid setup.
Your priority when optimizing your gear further should be toward crafting high item-level
pieces to cover holes in your gear. A good candidate is a ring, as while
there are unique strong options available, they're often <em>extremely</em>
contested.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will
have limited access to upgrade crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can
be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) to higher item levels. Crests are
limited to 100 per week, and upgrades cost 20 crests regardless of the slot. Due
to that, you should prioritize your usage of these on items you don't plan on
replacing any time soon, or specific slots that offer larger stat benefits:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_121_crest_myth.jpg>) **Enhancement Shaman Crest Upgrade Priority**
**Weapon (Main-Hand)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

These are not the only items worth upgrading, of course. They simply offer
the highest DPS gain early into the tier when your upgrade currency is limited.
Note that exceptions are possible, such as special cantrip items that have
additional procs attached to them, for example [[item:268265@JAAGAAAG2MqNTpC]].

5.1.

#### Adding Sockets to Gear

While all Rings and Necklaces come with one socket by default, three additional
sockets can be acquired on the Helmet, Belt and Bracer slots as a bonus when they
drop. These can also be added manually using the [[item:275707]]
consumable, which can be purchased using 6 [[item:258556]], the pity
currency from The Great Vault.

When using these, it's always best to put them on pieces you don't expect to
ever replace. This means Mythic items, or any crafted pieces in these slots, since
they can't have them added in any other way. Due to them being a very limited
currency, if you have these, it's best to plan long term before using any.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **24 Aug. 2026:** Updated to account for significant gearing changes following Season start.
- **19 Aug. 2026:** Added disclaimer regarding uncertain gear recommendations due to Aqirbane Reliquary hotfixes.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Sporefall gear.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **07 Apr. 2026:** Added note regarding Catalyst Unbound in early crafting FAQ.
- **16 Mar. 2026:** Updated for Midnight Season 1 release.
- **02 Mar. 2026:** Small update to reflect trinket tuning.
- **26 Feb. 2026:** Updated for Midnight release and Pre-season.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5 with Cartel Chip recommendations.
- **16 Aug. 2025:** Updated Trinket Tier List to account for tuning.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **24 Jun. 2025:** Updated to account for D.I.S.C. hotfixes.
- **15 Jun. 2025:** Updated for Patch 11.1.7 D.I.S.C. belt and adjusted BiS list slightly for double Gallywix weapon.
- **12 May 2025:** Confirmed Dinar recommendations for Turbo Boost release.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5 and added Cartel Chips section.
- **04 Mar. 2025:** Adjusted Cyrce's Circlet recommendation downward.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Dec. 2024:** Updated to highlight strength of new ring following hotfixes.
- **15 Dec. 2024:** Updated for Patch 11.0.7 for Cyrce's Circlet.
- **05 Nov. 2024:** Added Hand of Justice into single target recommendations.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated with Season 1 BiS lists.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4 and Awakened gear release.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, added note regarding Rageheart.
- **07 Nov. 2023:** Updated to remove Sporecloak recommendation, switched Dracothyst/Shadowflame.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Restructured for Patch 10.1.7, information remains the same.
- **20 Jul. 2023:** Added Sporecloak to crafts for high Mythic+.
- **12 Jul. 2023:** Increased value for Accelerating Sandglass due to patch release update.
- **10 Jul. 2023:** Updated for Patch 10.1.5 adding Dawn of the Infinite gear and cleaning up Crafting section.
- **25 May 2023:** Added section on Cataclysm Timewalking.
- **09 May 2023:** Updated to adjust for trinket changes.
- **01 May 2023:** Updated for Patch 10.1 and Season 2 release with new gear recommendations.
- **24 Mar. 2023:** Updated for Primordial Gemstones hotfixes.
- **20 Mar. 2023:** Updated for Patch 10.0.7 with Onyx Annulet recommendations.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Enhancement Shaman. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Enhancement Shaman Stat Priority

Welcome to our Stat Priority page for Enhancement Shaman in
Midnight! Here we'll quickly be going over the stats you should
aim for on gear, alongside any special considerations depending on your build.

Enhancement has two different Hero Talents, each with a slightly different
preference for each stat. Generally, you can get away with using the
same gearset for both of them without losing much, but optimizing each gearset
does follow different rules:

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer Stat Priority

Currently, when playing in **either** single-target or AoE, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer
builds have the following stat priority:

Item Level

Critical Strike

Mastery

Haste

Versatility

In Midnight, Agility is much more valuable following the stat squish. This means
that most of your gearing decisions are driven by item level, and this trend
continues in Season 2.

Following Season 2 release changes, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer has converged on
three stats competing with each other. Ideally, you want to aim for Critical Strike
as the highest stat on your character sheet to power up [[spell:1251026]].

Both Mastery and Haste are right behind it, and your goal is to keep all three
extremely close to each other as you optimize your gearset. Haste increases the
pace of the rotation significantly, and Mastery compounds the scaling on your Nature
damage spells, so all three are important.

Versatility is generally something to avoid, but it's not the end of the world
if some pieces have it on.

:::details TipsAdvanced Notes on Optimized Gearsets and Potion of Recklessness
In Season 2, gearing is <em>much</em> more complicated for Enhancement due to its
switch over to [[item:241288]] when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer.
You want your potion to always trigger Critical Strike (or failing that, Mastery),
as [[spell:1251026]] offsets some of the loss from diminishing returns. We use
it as a **pre-pot**, so the only thing that matters is our static character
sheet. Your ideal goal is:

- Get Critical Strike just above all other stats.
- Get as much Haste and Mastery as possible <em>without</em> going over your Crit.
- Adjust any stat procs and the Folio to Mastery and Haste.

This means your Flask choice can be used to adjust your values as needed, and
your Folio will often be either Haste or Mastery - in-combat procs don't matter
once we've got Recklessness to activate correctly. This can be hard to achieve, but
results in much more consistent opening burst.

Additionally, this matters less if you're using mid-combat potions outside of
[[spell:2825]] - in this situation a Haste pot isn't nearly as negative as usual.
These are all extreme optimizations made to gear in Season 2, but do make a big
difference when it comes to ideal gearsets.

:::

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic Stat Priority

Currently, when playing in **either** single-target or AoE, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic
builds have the following stat priority:

Item Level

Mastery

Haste

Critical Strike

Versatility

In Midnight, Agility is much more valuable following the stat squish. This means
that most of your gearing decisions are driven by item level, and this trend
continues in Season 2.

Due to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic sourcing a large amount of damage from [[spell:33757]]
and magic abilities, Mastery is consistently the strongest stat available, and is
preferred to stack. You also always want this to be your highest stat to make sure
[[item:241288]] triggers Mastery.

Haste is right behind it, so usually you keep these two in balance, as it increases
[[spell:187880]] generation to fuel [[spell:1260644]]. Critical
Strike falls to third, but still keeps close thanks to the added scaling of both
[[spell:445033]] and [[spell:1251026]], though it doesn't gain quite
as much from it as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer does.

Versatility is ideally avoided as it's firmly weaker than the other three, but
its fine if you have no alternatives in your current gear setup.

In optimized gearsets, [[item:241288]] is the chosen combat pot –
when using this you need to **ensure** it triggers Mastery. It's far less
complicated than the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer gearing puzzle, but if you can't
consistently achieve this, then instead use a different potion.

2.

### In-Depth Stat Breakdown

As an Enhancement Shaman, **Agility** is your primary stat,
which should be present on all Mail gear you wear, alongside your weapons.
Individual stats provide the following benefits:

- **Agility** provides you with Attack Power, which increases the damage of
  all of your melee abilities. Enhancement also converts this to Spell Power,
  increasing both spell damage and healing power.
- **Critical Strike** increases the chance for your attacks and abilities
  to critically strike, dealing double damage.
    
  
  - Certain talents (e.g. [[spell:1251026]]) increase this bonus damage
    	above the base 200% multiplier.
  - Also increases the chance to trigger the [[spell:382888]] effect from
    	abilities.
- **Haste** increases the speed of your melee auto-attacks, increasing the
  frequency of Imbue procs and [[spell:187880]] stack generation. Additionally:
    
  
  - Increases the tick rate of both [[spell:188389]] and [[spell:444995]].
  - Reduces your Global Cooldown to a minimum of 0.75 seconds.
  - Reduces the cooldown of your [[spell:17364]], [[spell:60103]],
    	and [[spell:187874]] abilities.
- **Mastery** ([[spell:77223]]) increases all Fire, Frost,
  and Nature damage dealt. Additionally:
    
  
  - Increases the chance to proc [[spell:201845]] and [[spell:33757]],
    	scaling at a much smaller rate. The converted chance can be increased by 150%
    	via the [[spell:392352]] talent.
- **Versatility** increases all damage and healing you do (including trinkets
  and proc effects) by a flat amount. Additionally, reduces all damage you take by
  half of that amount.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where it will begin to offer less increase per point
gained, known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5, added advanced tips for Potion otpimizing.
- **24 Aug. 2026:** Adjusted Critical Strike to be on par with Mastery for Stormbringer, and lowered Haste.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Season 1 release.
- **02 Mar. 2026:** Update to Totemic stats due to Overcharge being dropped.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, no changes necessary.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated for Patch 10.1.5 with small note about soft Haste breakpoint.
- **01 May 2023:** Updated for 10.1 with adjusted notes about Storm build and Haste for Elementalist.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Enhancement Shaman, based on your [stat priority](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

The recommended choices for all content are:

- Use [[item:240983]] in your first socket.
  
  - Use [[item:240900]] in other sockets.
- With **5+ Sockets**, switch to [[item:240967]].
  
  - Use one of each color to maximize the bonus - [[item:240900]],
      [[item:240892]], [[item:240908]], and [[item:240917]].

Depending on your stat balance, you will likely find that sockets are the best
place to adjust your secondaries. Since Mastery, Haste, and Critical Strike
are all competitive, we recommend simming your character to see which stat is worth
prioritizing in your gem slots.

2.

### Best Enchants and Weapon Augments

Unfortunately, due to the Enhancement imbue system, we have no access
to the additional weapon rune consumables. This is because
[[spell:33757]] and [[spell:318038]] overwrite
them, so save some money and don't worry about these!

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td><strong>Main Hand</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Off Hand</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Helm</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Shoulders</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Chest</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Legs</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Boots</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Rings</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Due to the way [[item:243957]] multiplies Critical
Strikes, it outclasses all of the raw stat enchants by a good margin, so is always
used.

Helm, Shoulder and Boot enchants are up to personal preference as they have no
direct impact on performance, but we recommend Avoidance picks on all slots for
the extra survivability.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

In Season 2, Flask picks aren't as simple for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer – they're
instead used to balance out secondaries:

- [[item:241326]] – if your Haste or Mastery is higher than Critical Strike.
- [[item:241325]] – if it won't put Haste above Critical Strike.
- [[item:241322]] – if you can't use Haste, and won't put Mastery above Critical Strike.

Your goal as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer is to keep Critical Strike as your highest
secondary stat, while keeping Haste and Mastery right behind it. That means your
flask is used to "fix" the stat that you're currently out of balance with, and this
changes depending on your current gear setup.

When playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic this is much easier: simply use [[item:241322]]
at all times.

You can also obtain a flask of your choice from [[item:241319]],
provided by Alchemists.

3.2.

#### Potions

In Season 2, potions are also much more complicated, and there are three different
options with different use cases:

- [[item:241288]] – Pre-pot if it will trigger Critical Strike or Mastery.
- [[item:271886]] – Pre-pot if you cannot adjust Recklessness appropriately.
- [[item:241308]] – if you want a simpler on-demand potion.

Since your current gear can <em>severely</em> impact the effectiveness of
[[item:241288]], both other options are now very relevant, and have
different rotational considerations when using them. You can check our
[Rotation page](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)
for an explanation on using each.

You can also obtain fleeting versions of each of these potions from a
[[item:241285]] provided by Alchemists.

A note on [[item:241292]] is that, while it's technically
stronger, the void zones it spawns pacify you. It only takes 1-2 GCDs inside this
to wipe out the extra value, so using the potion isn't generally worth it unless
you're extremely comfortable with the downside.

[[item:271883]] is the current best healing potion.
Using this has a 5-minute cooldown, but multiple can be consumed in an extended boss
fight should it go on long enough. Additionally, Warlock's
[[item:5512]]s do not share a cooldown with other healing consumables.
Remember to use it as well if you are holding one!

3.3.

#### Food Buff

Agility remains the strongest stat in Season 2, so you should be
eating a [[item:255845]] or other primary stat Feast if possible. If
this isn't provided by your group, stick to [[item:242275]] personal food instead.

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s
to increase your primary stat. Bear in mind that Augment Runes are expensive and
disappear on death, so use them wisely!

3.5.

#### Other Consumables

Alongside standard buff consumables, there are a handful of other items worth
keeping hold of - especially in Mythic+:

- [[item:188152]] — allows you to auto-interact with nearby Warlock [[spell:111771]]s.
- [[item:269586]] — can be used as a combat resurrection on your target,
  and <em>does not</em> require Engineering. This is especially useful since we can
  always use [[spell:20608]] to get back up ourselves.
- [[item:241303]] — Midnight's invisibility potion, which can
  be used to skip certain trash pulls in Mythic+. Bear in mind this <em>does</em>
  share a cooldown with your offensive potion of choice.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **24 Aug. 2026:** Expanded Flask and Potion section for more advanced Season 2 choices.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Season 1 - added Teas and additional Consumables for Mythic+.
- **02 Mar. 2026:** Adjusted Flask recommendations due to stat changes.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **12 May 2025:** Updated following Corruption tuning.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **04 Mar. 2025:** Added Authority of the Depths for single target.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5
- **09 Sep. 2024:** Updated for Season 1 BiS lists.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, shifted to recommendations for higher gear levels.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated for Patch 10.1.5 to strongly recommend against Annulet.
- **01 May 2023:** Updated for Patch 10.1 and new consumables.
- **24 Mar. 2023:** Updated for Primordial Stones hotfixes.
- **22 Mar. 2023:** Updated to account for Primordial Stones buff.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Enhancement Shaman in World of Warcraft Patch 12.1.5.

1.

### Enhancement Shaman in Mythic+ in Midnight Season 2

In this guide, we will cover how to get the most out of your Enhancement
Shaman in Mythic+ dungeons, including the best way to build your
character's talents out, any rotational changes that you need to know, and tips
and tricks to excel in each dungeon.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our dedicated Mythic+ page below. You can also find
out more about the Mythic+ Meta on our Tier List page.

Enhancement in Season 2 has quietly remained a solid pick in Mythic+, and while
its flexibility is reduced from the previous season, it can hold its own at most
key levels. Although it's not a stand-out meta performer, it's consistently powerful at
all target counts, and brings potent burst every two minutes when playing
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer. The built-in volatility holds it back slightly, but good
play can somewhat mitigate its impact. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic, on the other hand,
struggles significantly in the current Mythic+ landscape, and while its 1-minute
burst timer is strong, even with tuning over the season it still can't keep up.

2.

### Best Mythic+ Talent Builds

Both Enhancement Hero Trees have the same markers that build a solid
Mythic+ playstyle, but Season 2 cements ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer as the tree to
pick solely due to tuning. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic is functional, but its numbers
fall behind.

### **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer**    Recommended Build

2.1.

#### Best Enhancement Mythic+ Build - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer builds focus heavily on [[spell:187880]] cycling,
aiming to spend as often and efficiently as possible to reach [[spell:454009]]
procs. Its regular spender, [[spell:188443]], also deals good damage
constantly at lower target counts, improved greatly through [[spell:210689]]s
applied with [[spell:455123]]. These are maintained with full uptime,
thanks to their application via [[spell:289874]], which makes up for some
of the priority damage lost by the [[spell:187874]] damage split.

Its burst is focused inside its 2-minute cooldown, [[spell:114051]],
generating a massive surge of resources that it spends with [[spell:384444]].
This is accompanied by random [[spell:384352]] triggered when cycling resources,
though their inconsistency is an acquired taste.

2.1.1.

##### Talent Swap Options

Talent swaps for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer are extremely limited, as the build
already picks up almost every appealing option available on the tree. A few quick
notes:

- While the [[spell:1218047]] talent leaf was useful in Season 1, the
  new 4-piece locks in the final point in [[spell:1252373]]. Similarly,
  [[spell:333974]] is a locked pick to take advantage of the 2-piece.
- While our control options are still a bit more limited in the Midnight tree,
  we'd strongly recommend always taking both points in [[spell:265046]]. Other
  specific use case talents like [[spell:370]], [[spell:383013]], and
  [[spell:51886]] should be moved around on a dungeon-by-dungeon basis.

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents AoE / Mythic+ - Stormbringer
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2gFYGGawCAzyMmxYZxYjZmtxyMzMzYswMAAzwYmhRgZGMYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZMWYGAgZYMzwIwMDGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFoAzzrsrzYBK1KROB-CDEOXZBFNRVWYdgjAMQShLPeKKbT4EB-AAAA-OUaIawIMsEAEpA-
```

:::

### **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic**    Alternative Build

2.2.

#### Enhancement Mythic+ Alternative Build - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic

While its power is much more muted in Season 2, it still has a toolkit that's
well suited to Mythic+. The combination of [[spell:444995]] and [[spell:384352]]
providing potent burst every minute is valuable, and with [[spell:197214]]
and [[spell:1218047]] it always has <em>something</em> for every pull. The
loss of priority damage due to the [[spell:187874]] split though, <em>and</em>
the generally weaker throughput outside of cooldowns, really limits its ceiling in
Season 2. This is, unfortunately, only compounded by the GCD strain put on the
tree by the effects of the current 4-piece.

2.2.1.

##### Talent Swap Options

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic has a relatively focused build - especially with the new Tier
Set considered - so swaps are limited:

- There's one point floating in the middle of the tree, and with the amount of
    Crit present on Season 2 gear, it's <em>generally</em> best spent on [[spell:1251026]],
    though [[spell:334046]] is also an option here.
- On the class tree, we strongly recommend picking up both points in [[spell:265046]]
    to reduce [[spell:192058]] down to 40 seconds. Both of these points are
    flexible though - and can be switched around for key utility when needed depending
    on the dungeon.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic has fewer flexible points to move around, as both
    [[spell:108287]] and [[spell:382201]] provide useful quality-of-life
    improvements. These can be dropped if you need to go above and beyond your standard
    utility needs however, or desperately need more self-healing from [[spell:337974]].

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Mythic+ - Totemic
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzMjZmZmZmZmZGzAAAAAAAAAALwGMjFN2GAzA2AYWmxMGLLGbMzsNWm5BmZGsMmBAAYMmRMzAMYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzMjZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZAbAMLzYGjlFjNmZ2GLz8AzMDWGzAAAMGzImZAGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRrFoAzzbsEdB1uuTjKROB-CDEHOXZBGGNWjAMQRVgPSaiKKLUJFT-AAAA-Jgko0AIowgxRmF-
```

:::

3.

### Dungeon Talent Swap Cheat Sheet

For a quick reference of extra uses for your optional Enhancement utility
	talents, use the tool below to select a dungeon. Underneath, relevant picks will
	be highlighted alongside what they're used to counter.

<table>&#10;<tr>&#10;<th colspan="2">Dungeons</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></td>&#10;</tr>&#10;</table>

Based on the selection above, the following class talents have additional uses:

![Cleanse Spirit Not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/decurse.jpg>)**适用条件：Den of Nalorakk（未启用）；King's Rest（未启用）；Murder Row（未启用）；Temple of Sethraliss（未启用）。**

![Cleanse Spirit Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/decurse.jpg>)**适用条件：Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Temple of Sethraliss（启用）。**

‌

![Purge not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/purge.jpg>)**适用条件：Den of Nalorakk（未启用）；King's Rest（未启用）；Murder Row（未启用）；Ruby Life Pools（未启用）。**

![Purge Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/purge.jpg>)**适用条件：Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Ruby Life Pools（启用）。**

‌

![Spirit Walk not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/spirit_walk.jpg>)**适用条件：Altar of Fangs（未启用）；Blinding Vale（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Ruby Life Pools（未启用）；Voidscar Arena（未启用）。**

![Spirit Walk Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/spirit_walk.jpg>)**适用条件：Altar of Fangs（启用）；Blinding Vale（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；Voidscar Arena（启用）。**

‌

![Tremor Totem not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/tremor.jpg>)**适用条件：King's Rest（未启用）；Voidscar Arena（未启用）。**

![Tremor Totem Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/tremor.jpg>)**适用条件：King's Rest（启用）；Voidscar Arena（启用）。**

‌

![Poison Cleansing Not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/pct.jpg>)**适用条件：Altar of Fangs（未启用）；Blinding Vale（未启用）；Den of Nalorakk（未启用）；Murder Row（未启用）；King's Rest（未启用）；Temple of Sethraliss（未启用）；Voidscar Arena（未启用）。**

![Poison Cleansing Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/pct.jpg>)**适用条件：Altar of Fangs（启用）；Blinding Vale（启用）；Den of Nalorakk（启用）；Murder Row（启用）；King's Rest（启用）；Temple of Sethraliss（启用）；Voidscar Arena（启用）。**

- **适用条件：Altar of Fangs（启用）。** [[spell:58875]] & [[spell:462820]] uses:
  	  
  
  - Clears [[spell:1296069]] in the **Rav'i** boss encounter.
  - Clears [[spell:1310974]] from **The Writhing Coil**.
  - Clears [[spell:1294569]] from **Twinfang Harrowers**.
- **适用条件：Altar of Fangs（启用）。** [[spell:383013]] uses:
  	  
  
  - Dispels [[spell:1307571]] from **High Evolutionists**.
  - Dispels [[spell:1307567]] from **Ula'tek's Chosen**.
- **适用条件：Blinding Vale（启用）。** [[spell:58875]] & [[spell:462820]] uses:
  	  
  
  - Clears [[spell:1238084]] from **Lashers** if you're hit in melee.
- **适用条件：Blinding Vale（启用）。** [[spell:383013]] uses:
  	  
  
  - Dispels [[spell:1250937]] from **Potatoad Matriarch**.
- **适用条件：Den of Nalorakk（启用）。** [[spell:51886]] uses:
  	  
  
  - Dispels [[spell:1238760]] applied by effigies summoned by **Spirits of Hunter**.
- **适用条件：Den of Nalorakk（启用）。** [[spell:370]] uses:
  	  
  
  - Dispels [[spell:1297696]] from **Earthwhisper Tenders**.
- **适用条件：Den of Nalorakk（启用）。** [[spell:58875]] & [[spell:462820]] uses:
  	  
  
  - Clears [[spell:1309919]] from **Frigid Maulers**.
  - **[[spell:58875]] only -** Clears [[spell:1241463]] from **Avatar of Determination**.
  - **[[spell:58875]] only -** Clears [[spell:1263590]] from failed **Rimeshatter** soaks.
- **适用条件：Den of Nalorakk（启用）。** [[spell:383013]] uses:
  	  
  
  - Dispels [[spell:1234233]] during **The Hoardmonger** boss fight.
- **适用条件：King's Rest（启用）。** [[spell:51886]] uses:
  	  
  
  - Dispels [[spell:269972]] cast by **Risen Hexers**.
  - Dispels [[spell:270492]] cast by **Phantom Hex Priests**.
- **适用条件：King's Rest（启用）。** [[spell:370]] uses:
  	  
  
  - Dispels [[spell:269935]] active on **Minions of Zul**.
  - Dispels [[spell:1296671]] applied by **Guard Captain Atu**.
  - Dispels [[spell:270901]] from **Seneschal M'bara**.
- **适用条件：King's Rest（启用）。** [[spell:58875]] & [[spell:462820]] uses:
  	  
  
  - Clears [[spell:1294815]] from **Risen Hexers**.
  - Clears [[spell:106823]] applied by **Queen Patlaa**.
  - Clears [[spell:271563]] applied by **Embalming Fluids**.
  - Clears [[spell:12548]] applied by **Spectral Shaman**.
- **适用条件：King's Rest（启用）。** [[spell:8143]] uses:
  	  
  
  - Dispels [[spell:273434]] cast by **Minions of Zul** if they reach their target.
  - Dispels [[spell:269369]] cast by **Reban** during the **Dazar** boss fight.
- **适用条件：King's Rest（启用）。** [[spell:383013]] uses:
  	  
  
  - Dispels [[spell:106823]] from **Queen Patlaa**.
  - Dispels [[spell:271563]] from **Embalming Fluids**.
  - Dispels [[spell:267273]] cast during **The Council of Tribes** boss fight.
- **适用条件：Murder Row（启用）。** [[spell:51886]] uses:
  	  
  
  - Dispels [[spell:1217973]] applied by **Corrupted Warlocks**.
- **适用条件：Murder Row（启用）。** [[spell:370]] uses:
  	  
  
  - Dispels [[spell:1229433]] applied by **Felonious Mages**.
- **适用条件：Murder Row（启用）。** [[spell:383013]] uses:
  	  
  
  - Dispels [[spell:474515]] applied by **Street Sneaks**.
  - Dispels [[spell:1222795]] during the **Zaen Bladesorrow** boss fight.
- **适用条件：Ruby Life Pools（启用）。** [[spell:370]] uses:
  	  
  
  - Dispels [[spell:373973]] applied by **Ashseer Flamelashers** at low health.
  - Dispels [[spell:391031]] active on **Primal Thunderclouds**.
- **适用条件：Ruby Life Pools（启用）。** [[spell:58875]] & [[spell:462820]] uses:
  	  
  
  - Clears [[spell:373803]] from **Infused Whelps** if you're hit in melee.
- **适用条件：Temple of Sethraliss（启用）。** [[spell:51886]] uses:
  	  
  
  - Dispels [[spell:1293307]] cast by **Faithless Subjugators**.
- **适用条件：Temple of Sethraliss（启用）。** [[spell:383013]] uses:
  	  
  
  - Dispels [[spell:1308100]] applied by **Shrouded Fangs**.
  - Dispels [[spell:1308148]] applied by **Poisonous Vipers**.
  - Dispels [[spell:267027]] during the **Merektha** boss fight.
- **适用条件：Voidscar Arena（启用）。** [[spell:58875]] & [[spell:462820]] uses:
  	  
  
  - Clears [[spell:1263982]] stacks in the **Charonus** boss encounter.
  - Clears [[spell:1249621]] from **Angry Krolusks**.
- **适用条件：Voidscar Arena（启用）。** [[spell:8143]] uses:
  	  
  
  - Dispels [[spell:1233398]] if a cast from a **Killvore Screamer** goes off.
- **适用条件：Voidscar Arena（启用）。** [[spell:383013]] uses:
  	  
  
  - Dispels [[spell:1289265]] cast by **Agitated Voidscythes**.
  - Dispels [[spell:1226120]] during the **Atroxus** boss fight.

4.

### Utility Kit and Abilities

This section covers key talents and abilities Enhancement has access to that
can be leveraged in Mythic+ situations.

### Crowd Control

4.1.

#### Interrupts and Crowd Control

Enhancement has a few tools at its disposal to stop enemy casts. Due to their
different use cases, we've broken them down into single-target and AoE options.

4.1.1.

##### Single Target Crowd Control

- **[[spell:57994]] -** your interrupt, and one of the best available to
  any class. Being both ranged and having such a low cooldown is a huge advantage,
  allowing you to disrupt targets much more often than usual. You should be the
  one aggressively going after enemy casts; allow other classes with longer
  interrupt cooldowns to handle less frequent threats, or to save them for
  emergencies. Coordinate this with your group before starting the dungeon.
- **[[spell:51514]] -** your hard-CC, allowing you to lock down a dangerous enemy
  for one minute before a pull starts. Bear in mind damage can break this effect, so
  your tank will need to pull them away. This can also be used as a last resort in
  combat to interrupt a cast, but the time needed often makes it hard to land
  properly. Also, while crowd controlled, mobs **will still aggro** to you and
  other party members, so cannot be used to skip like some other tools.

4.1.2.

##### Area of Effect Crowd Control

- **[[spell:192058]] -** your AoE stun tool to lock down a pack for
  3 seconds. This tends to be extra useful on larger pulls, to allow the
  tank to grab threat and stabilize before enemies begin casting. It also has extra
  ways to reduce its cooldown below the baseline 1-minute:
  
  
  - [[spell:265046]] reduces the cooldown by 10 seconds per point, for a
      total of 20 seconds.
  - [[spell:381867]] reduces the cooldown by an additional 5 seconds.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic has [[spell:445027]], reducing it by 5 seconds when
      it successfully stuns any target.
  
  
  Always remember, the 2-second wind-up time requires you to be much more
  aware of when enemies are <em>about</em> to cast, as using it reactively is usually
  too late.
- **[[spell:2484]]** <em>(with [[spell:51485]])</em> - summons
  a totem that roots enemies for 8 seconds, keeping them in place, and slowing them
  after it expires. For certain mechanics this can be extremely useful.

### Defense & Off-healing

4.2.

#### Defensive and Off-Healing Tools

Due to being a hybrid class, Shaman has access to a few tools that help keep
both you and your group alive. Its defensive options are available less frequently
than many other classes, but it comes with quite a lot of passive defense. This
means it often requires a bit more planning to navigate frequent lethal attacks
when playing Enhancement. We've separated these abilities into two categories:

4.2.1.

##### Defense

Staying alive is extremely important in Mythic+, and often, you may find
yourself responsible for your own life if the healer is busy putting fires out
elsewhere. The key tools we have to deal with bad situations are:

- **[[spell:108271]] -** your personal defensive for a 40% damage reduction,
  always paired with [[spell:381647]] for cooldown reduction. Used to survive
  otherwise lethal mechanics.
- **[[spell:198103]] -** has a 3-minute cooldown and lasts 30 seconds,
  taunting nearby enemies to take some pressure off the tank. Generally though, we
  play with [[spell:1279819]], which removes the taunt effect in exchange for
  a 15% maximum health increase while it's active.
- **[[spell:355630]] -** reduces all magic damage taken by 15% for 12 seconds
  following a successful [[spell:57994]] interrupt. This is extremely potent
  considering our lack of tools elsewhere, and strongly encourages you to interrupt
  as often as possible.
- **[[spell:260878]] -** stacks up while in [[spell:2645]], providing
  up to 20% damage reduction. This prevents you from dealing damage, but with no
  cooldown, it's always there as a backup.
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer -** also has access to [[spell:454027]]
  for 3% damage reduction via [[spell:192106]].
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic -** triggers [[spell:445031]] every 30 seconds with
  an active totem, for a very small absorb shield.

Enhancement is relatively durable passively in Midnight, but if an encounter
requires active defense at key moments, it can struggle if they're too frequent.
Being aware of when lethal damage is coming, and having a plan to counter it is an
important skill to use - just as important as knowing when you <em>don't</em> need
it and can assist your healer by self-healing instead.

4.2.2.

##### Off-healing

While healing is not your primary role, we do have some tools to help the
party in deadly situations. Spending [[spell:187880]] triggers stacks of
a different buff - [[spell:384143]]. These stacks confer the
same benefits of Maelstrom Weapon to your next [[spell:8004]] and
[[spell:1064]], which can be used to sustain yourself or spot-heal party
members. In addition to that, there are a few smaller tools available:

- [[spell:5394]] is a very niche optional choice, which provides a
  small amount of spot healing. [[spell:462368]] also grants a little
  bit of damage reduction, but is very unreliable.
- [[spell:974]] and [[spell:383010]] give us some passive healing
  when taking damage. It's highly recommended to pair this with [[spell:1217622]].
  This also allows you to apply Earth Shield to a second player (usually
  your tank) at the start of a run as well.
- [[spell:337974]] is often taken as well to improve our self-healing
  with [[spell:8004]], though it's a little costly to reach it on the talent
  tree if extra utility is needed.

Being proactive with healing tools is an effective skill to learn as an
Enhancement Shaman. While it's not completely your responsibility, you should
be aware of when the party is unstable so you can keep at least yourself
healthy.

[[spell:454372]] for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer does also provide a bit
more potency to your [[spell:8004]], provided you're cycling [[spell:454009]]
efficiently. Bear in mind though, this costs the passive damage reduction from
[[spell:454027]] when taken.

### Other Utility

4.3.

#### Other Enhancement Utility

Alongside the more traditional tools for Mythic+, Shaman has some class-specific
extras.

4.3.1.

##### Offensive / Defensive Dispels

Enhancement comes with quite a few different dispel tools for different
situations. These are all present on the class tree, which is also very flexible,
so you can tailor your loadout to the dungeon. Options are:

- [[spell:370]] — offensive dispel
- [[spell:51886]] — allied Curse dispel
- [[spell:383013]] — group-wide Poison dispel
- [[spell:8143]] — group-wide Fear dispel
- [[spell:462820]] — group-wide Snare removal

Being able to switch between so many choices (or all at once) often means you
have a bespoke tool available for each dungeon. Remember to swap to the appropriate
picks and use them!

4.3.2.

##### Other Utility

**[[spell:462854]] -** your group buff, providing bonus Mastery and granting
party members' melee auto-attacks a 20% chance to strike an additional time. This is
one of the more potent (and universal) buffs that all specs like having, so it
makes Shaman desirable.

**[[spell:2825]] / [[spell:32182]] -** every group wants at least one
of these effects, shared with [[spell:80353]] / [[spell:390386]] / [[spell:264667]].
Coordinate with your group for the best time to use it every 10 minutes.

**[[spell:192077]] -** party-wide movement tool, lasting up to 20
seconds with refreshes. Good for moving between pulls or avoiding mechanics, and
with [[spell:462820]] has the added benefit of being an AoE snare removal.

**[[spell:20608]] -** allows you to resurrect after dying, including
during combat, ignoring the battle-res counter. This is especially helpful if you
get caught by a lethal mechanic without defensives available.

**[[spell:198103]] -** an emergency tool, useful if the tank either
dies or is struggling to handle a pack. This only taunts if you <em>haven't</em>
taken [[spell:1279819]], and no build should skip this as it's an important
defensive tool we rely on. It also rarely moves due to some problematic AI, so you
may need to cancel it if it's stuck in a bad place.

**[[spell:381930]] -** can help your healer with some additional Mana
regeneration over the course of a dungeon, and can be picked up easily on the class
tree. With its low value, paired with the utility it competes with for the same
points, it can be hard to fit in Mythic+ setups.

5.

### Dealing with Affixes

This section contains quick tips to deal with each of the weekly Xalatath-themed
affixes in Mythic+ Season 2.

### Affix: Ascendant

5.1.

#### Ascendant Affix Management for Enhancement Shaman

**Xalatath's Bargain: Ascendant** will periodically spawn a number of orbs in
waves that need to be crowd-controlled in some way, before they complete a cast.
Each orb successfully stopped provides the group bonus Haste, so it is a high
priority to deal with.

Enhancement only has [[spell:192058]] available as an AoE stop to deal
with these, which may mean it's best to hold off on using it too aggressively in
these weeks. Any stragglers can also be destroyed with [[spell:57994]] off the
GCD if they're about to go off, or manually [[spell:370]]d from a distance.

### Affix: Voidbound

5.2.

#### Voidbound Affix Management for Enhancement Shaman

**Xalatath's Bargain: Voidbound** will periodically summon a large Void
Emissary that will begin to cast [[spell:462508]]. This enemy **must** be
killed before the cast completes to stop it, otherwise it provides significant
damage reduction to nearby enemies. If successfully stopped, the group is granted
a large amount of Versatility and cooldown reduction.

This needs to be killed off quickly. Ideally, have short, bursty effects ready
to go for these spawns. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic has [[spell:197214]], but since
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer is a little unpredictable, make sure you target swap
quickly to help the group.

### Affix: Pulsar

5.3.

#### Pulsar Affix Management for Enhancement Shaman

**Xalatath's Bargain: Pulsar** spawns an orb that orbits each player, which
needs to be soaked by a separate player before they expire. Each orb will grant
the party 4% Mastery and 2% Leech, stacking, with a 30-second duration. Unsoaked
orbs will increase nearby enemies' damage done, and reduce their damage taken.

Enhancement has no specific utility to deal with this, instead you need to be
aware of your positioning both to make sure other players can soak up the orb
circling you, and so you can catch orbs from nearby players.

### Affix: Devour

5.4.

#### Devour Affix Management for Enhancement Shaman

**Xalatath's Bargain: Devour** applies a debuff to each party member which
must be either dispelled or healed off (though bear in mind this <em>does not</em>
absorb incoming heals). Each debuff dispelled provides the group with maximum
health and Critical Strike, stacking, for 30 seconds. Any debuffs <em>not</em>
cleared will heal nearby enemies a large amount.

On these weeks, we'd particularly recommend picking up [[spell:51886]] and
[[spell:383013]] to assist your healer. [[spell:378075]] and
[[spell:462820]] will also clear this in Midnight, as a small slow was added to
the debuff. If you find the group struggling to clear the debuffs and these tools
aren't available, [[spell:384143]] heals can be substituted to assist.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **07 Apr. 2026:** Noted that recent tuning did not affect build recommendations.
- **16 Mar. 2026:** Updated for release of Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Changed build recommendation to Totemic.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **28 Aug. 2025:** Added in Season 3 Talent Swap Cheat Sheet.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **28 Apr. 2025:** Added dungeon tips.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5, emphasized how close both trees are with recent Stormbringer buffs.
- **16 Mar. 2025:** Shifted Totemic tree to pick up more single target comfort.
- **04 Mar. 2025:** Cleaned up recommended builds to account for Flowing Spirits nerf and Season launch.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, added recommended flags.
- **05 Nov. 2024:** Updated with Stormbringer vs. Totemic builds, and added in gameplay tips section.
- **21 Oct. 2024:** Updated for Patch 11.0.5, will require future updates following release.
- **09 Sep. 2024:** Updated for War Within Season 1 release.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6, added note regarding Ember of Nullification.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, touched up some sections and added defensive trinkets as options.
- **09 Nov. 2023:** Restructured and updated for Patch 10.2.
- **06 Nov. 2023:** Updated link to Mythic+ hub.
- **04 Sep. 2023:** Some restructuring for Patch 10.1.7, added in Infurious Boots of Reprieve as a crafting option.
- **20 Jul. 2023:** Added note about Sporecloak to gear section for key pushing.
- **10 Jul. 2023:** Updated for Patch 10.1.5 with shift to Storm Cleave for Storm builds.
- **01 May 2023:** Updated for Patch 10.1 and new Season 2 builds, alongside initial Tier set opener.
- **20 Mar. 2023:** Reviewed and added small improvements for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Enhancement Shaman in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Enhancement Shaman macros.

2.

### Enhancement Shaman Macros

Macros are accessible through the /macro command in-game, and allow you to
create small scripts that will be executed when you press a keybind. These are
very useful for combining multiple actions into one, so a common example is
combining off-GCD trinkets with cooldowns within one press.

Below are some Enhancement specific options that help to make executing
some important mechanics smoother.

2.1.

#### Focus Cast Macros

We have several spells that can benefit from using a focus
target, allowing you to still focus on your primary target with damaging attacks.
Replace the Wind Shear in the macro below with any desired spell name:

#### Focus Interrupt

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] Wind Shear
```

Good spells to use this with are [[spell:51886]], [[spell:51514]],
[[spell:370]] and [[spell:57994]].

2.2.

#### Mouseover Macros

Similarly, mousing over a target and casting a spell without moving
from your main target can be beneficial, especially with specific talent
builds. Replace the Cleanse Spirit in the macro below with the spell name:

#### Mouseover Dispel

```wow-macro
#showtooltip
/stopcasting
/cast [target=mouseover] Cleanse Spirit
```

This has other uses if targets are more dynamic, removing an input
needed to target someone. [[spell:51886]] benefits from this, especially
when using raid/party frames.

2.3.

#### Self-Cast Healing Surge

This will always prioritize yourself when casting [[spell:8004]]
for reliable self-healing:

#### Self-Cast Healing Surge

```wow-macro
#showtooltip
/stopcasting
/cast [@player] Healing Surge
```

2.4.

#### Totem Placement Macros

For any totem with a targeting circle, two macro options are
available to drop it quicker. The first drops it immediately at your feet
(replace the Surging Totem in the following macros with your desired totem name).
This is **especially** useful when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic:

#### At Player Totem Drop

```wow-macro
#showtooltip
/cast [@player] Surging Totem
```

Or at your current cursor location:

#### At Cursor Totem Drop

```wow-macro
#showtooltip
/cast [@cursor] Surging Totem
```

This can be used for [[spell:192077]], [[spell:51485]]
or even [[spell:108287]].

2.5.

#### Totemic Projection on Cooldown Macro

To efficiently move our totems around with us, you can macro
[[spell:108287]] into a rotational ability thanks to it being off the
Global Cooldown. A common ability to tie it to is [[spell:17364]], but any
button can be used with the following macro:

#### Automatic Totemic Projection

```wow-macro
#showtooltip
/cast [@player] Totemic Projection
/cast Stormstrike
```

This does have some downsides for utility totems, and gives you less direct
control over where you place things as [[spell:108287]] will always be
on cooldown. This is more of a niche option for those who simply don't want to
bother dealing with dragging [[spell:444995]] around.

2.5.1.

##### Surging Totem Relocate

Alternatively, you can use the following macro when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic,
which repeatedly use the relocate feature built into [[spell:444995]], without
needing to waste the cooldown of [[spell:108287]]:

#### Surging Totem Relocate

```wow-macro
#showtooltip Lava Lash
/cast Lava Lash
/cast Surging Totem
```

You can replace [[spell:60103]] with [[spell:17364]], or macro it to both
to make sure it stays nearby.

3.

### Best Addons

As Midnight comes with a significant shake-up to what addons are able to do,
this section will slowly be populated as more robust addons are developed over
the course of the first season.

3.1.

#### General Addons for Shaman

Most of your UI needs can be met with some effort using the new Blizzard UI
options in Midnight, but if you're looking for some extra customization, below are
some popular choices.

3.1.1.

##### Boss Mods: Deadly Boss Mods or Bigwigs

Boss mods are addons that warn you about boss abilities and give you
live advice on how to handle some mechanics. We strongly recommend you to
get one such addon. At Icy Veins, we mostly use
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>),
the most popular boss mod. A good alternative is
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

3.2.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) is a complete replacement of the default
User Interface. It comes with almost everything you need to perform properly:
action bars, unit frames, cooldown timers, proc displays, etc.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **05 Nov. 2024:** Added Weakauras Section.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, added Earth Elemental cancel method.
- **06 Nov. 2023:** Reviewed for Patch 10.2, no changes necessary.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5, no changes necessary.
- **29 Apr. 2023:** Reviewed for Patch 10.1, no changes necessary.
- **20 Mar. 2023:** Added more commonly used macros, and reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
