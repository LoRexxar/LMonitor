## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Wordup。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-guide>)
- [练级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)

## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本 增强 萨满祭司 攻略。在这里，你将学习如何在团队副本和大秘境中扮演 增强 萨满祭司：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

增强 大秘境资源

[NEW! Top 增强 天赋构建](<https://raider.io/specs/enhancement-shaman/talents>)

[顶尖 增强 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/shaman/enhancement>)

[增强 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=shaman--enhancement>)

[热门 增强 队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=shaman--enhancement>)

1.

### 增强 萨满祭司 概览

增强 是 萨满祭司 的近战专精，同时强调物理攻击和 元素 法术，使用各种强化效果，将两者结合在快节奏的“战斗法师”战斗风格中。

其玩法围绕着管理技能冷却和触发效果展开，以独特的伪资源 [[spell:187880]] 为核心来驱动法术施放。它在顺劈场景中表现出色，两个英雄天赋树都有多种构建选择。最后，作为 萨满祭司，它提供 [[spell:2825]] 和团队增益 [[spell:462854]]。

1.

### 增强 萨满祭司 表现分析

与任何专精一样，增强 有其优势和劣势。下面我们将根据一些关键类别对其在终局内容中的表现进行评估：

**灵活的输出方式**

在 至暗之夜 第2赛季中，增强 在伤害方面仍然保持着多样的工具组合。它只需牺牲极少的单体伤害即可实现AoE能力，同时在所有场景中都能免费带来顺劈效果。它还拥有非常强大的爆发冷却窗口，尽管在时间轴方面的灵活性有限。它在任何特定场景中都没有特别耀眼的表现，但几乎能应对任何战斗风格的能力使其在大多数阵容中都是一个不错的选择。

**强大的爆发与顺劈**

随着主流英雄天赋转向 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 在第2赛季中，它仍然保持着极好的顺劈能力——这在 The Venomous Abyss 中非常重要。它受到的冷却削弱影响也远小于大多数专精，这意味着在 [[spell:114051]] 期间造成的伤害极高。它能够在爆发期提供爆炸性的前置伤害，同时在大多数需要顺劈的战斗中持续提供顺劈输出，这使它成为第2赛季一个可靠的近战选择。但它最大的缺点是由于 [[spell:384352]] 触发导致的巨大随机性波动，这尤其影响了它在最后两场战斗中的潜力。

**良好的爆发与灵活的输出**

与团队副本情况类似，增强 在大秘境中以一套非常灵活的伤害模式呈现。虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 在一定程度上依赖其 [[spell:114051]] 进行 <em>可靠的</em> 爆发，但其基础工具组提供的稳定顺劈，加上 [[spell:384352]] 和 [[spell:454009]] 的触发效果，使其即使在时间轴不匹配时也有机会大放异彩——前提是你有一些运气。第2赛季的套装还增加了一些额外的优先目标伤害，提升了它在 至暗之夜 中较弱的一个方面。加上其围绕中等目标数量专家定位的调整，使其拥有稳固的地位。

**一些灵活的工具**

至暗之夜 大幅减少了 增强 获得控制工具的途径，限制了它以前最好的特性之一，而且没有任何替代品。第2赛季并没有真正改善这一点，不过毒素效果的增加确实提升了 [[spell:383013]] 的价值。它仍然带来各种不错的辅助工具，但大多数也被其他专精以更方便的方式覆盖了。不过，它仍然提供最强的团队增益之一 [[spell:462854]]，同时也是 [[spell:2825]] 的来源。

**尚可的被动防御**

在防御方面，增强 在被动防御方面相当稳健，但在需要主动工具时可能会力不从心。通过 [[spell:381689]]、[[spell:381650]] 以及 [[spell:30884]] 的紧急治疗，面对大多数标准机制时基础生存能力很高。另一方面，主动工具的冷却时间相比其他专精要长得多，虽然 [[spell:108271]] 非常强大，但1分30秒的冷却在高端内容中可能成为限制。[[spell:198103]] 每3分钟提供一次备用，但由于冷却时间过长并不可靠。最后，它确实有一些被动自我治疗，[[spell:1217622]] 使 [[spell:974]] 常驻，以及通过 [[spell:384143]] 施放提供的主动选项，使其对持续性伤害有相当的韧性。

**高机动性**

增强 的移动工具组在 至暗之夜 中仍然极其灵活，使其能够在近战中跟上快节奏。[[spell:196884]] 帮助它黏住目标，而 [[spell:58875]] 提供解除定身和冲刺效果，是常规选择——不过 [[spell:192063]] 是取消击退的选项。[[spell:2645]] 也始终可用，激活时抑制减速效果，并提供额外的加速帮助你脱离大多数场景，只要你习惯了切换形态进出。

1.

### 增强 萨满祭司 在 至暗之夜 中

### **第2赛季**   改动

3.1.

#### 至暗之夜 12.1.5版本内容指南

虽然12.1.5补丁对 增强 本身没有带来重大改动，但它最近确实收到了一系列热修复，全面提升了他的伤害。此外，补丁还带来了全新的终局PvE内容供你深入体验。团队副本可以挑战
[Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 这一全新的单体首领战，以获取强大的战利品，同时
[地下堡](<https://www.icy-veins.com/wow/delves-guide>) 推出了首个超级大秘境迷宫供你探索！请务必查看下方关于这两项新增内容的详细信息。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

3.2.

#### 12.1.5版本改动

[12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>) 作为至暗之夜第2赛季进程的延续，围绕乌拉特克和阿曼尼的故事最终带来了一个全新的单首领团队副本、升级装备等级的途径、多种追赶装备来源，以及无限量的雾玉用于升级装备。请务必查看我们的补丁中心，了解补丁12.1.5的所有新增或更新信息。

3.3.

#### 职业改动

在12.1.5补丁中，增强 几乎没有什么变化；不过，补丁上线前刚刚实装的一个小bug修复和伤害调整还是值得一看的：

[12.1.5内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24304162>)

**增强 萨满祭司**

- 修复了一个在 [[spell:384352]] 触发重叠时，[[spell:384411]] 可能会停止产生 [[spell:187880]] 的问题。

**10月6日职业调整**

<em>开发者说明：我们正致力于全面提升 增强 萨满祭司 的输出能力，因为他在本赛季表现不佳，同时也会提升熔岩猛击在整体伤害构成中的占比。</em>

- 所有技能和自动攻击伤害提高4%。不影响PvP战斗。
- [[spell:60103]]伤害提高35%。不影响PvP战斗。

该错误修复仅与[[spell:384352]]触发效果重叠的情况相关，但能消除这种情况发生时的一些负面影响，仍是不错的改进。话虽如此，它并未能显著缓解这种缺乏控制所带来的问题，也无法减轻时机不当的激活所造成的负面效果。

另一方面，光环增益效果是好的，虽然有些迟了。对[[spell:60103]]的增强确实让 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 稍微摆脱了目前的困境，但与……相比，在所有情况下仍然是较弱的选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者相比，在所有情况下它仍然是较弱的选择。尽管获得了大幅增强，但它对输出循环优先级也没有任何影响。

3.4.

#### 至暗之夜第2赛季内容指南

至暗之夜第2赛季仍在进行中，有充满挑战的团队副本首领等待在剧毒深渊中击败，有史诗+地下城等待征服，还有PvP中的对手等待击败。我们在下方为每个内容提供了专属页面！

[第2赛季团队副本](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

[第2赛季史诗+](<https://www.icy-veins.com/wow/midnight-mythic-season-2-guide>)

[第2赛季PvP](<https://www.icy-veins.com/wow/midnight-pvp-season-2-guide>)

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_stormstrike.jpg>) 点击查看上赛季第二赛季的改动
3.5.

#### 12.1补丁增强改动

虽然第2赛季为许多专精带来了相当重大的改动，但增强则进行了一些更具针对性的调整，以改变其伤害分布：

[乌拉特克的诅咒开发笔记](<https://us.forums.blizzard.com/en/wow/t/midnight-curse-of-ulatek-ptr-development-notes/2317811>)

**增强 萨满祭司**

<em>开发者笔记：我们对增强萨满祭司在进入乌拉特克的诅咒时的游戏体验感到满意。我们进行这些改动的目标是在改善技能冷却窗口之外伤害感觉疲软的表现的同时，保留这种游戏体验。风怒触发效果与漩涡武器生成之间的强力联动，使得技能冷却之间的空档期难以喘息。</em>

- [[spell:974]]、[[spell:5394]]和[[spell:8004]]治疗量提高25%。
  
  
  
  
  - <em>注意：这是为了抵消12.1版本中玩家基础生命值的提升。</em>
- [[spell:188196]]和[[spell:188443]]伤害提高20%。
- [[spell:17364]]和[[spell:60103]]伤害提高15%。
- 近战自动攻击伤害提高15%。
- [[spell:384352]]现在使[[spell:33757]]的触发几率提高50%（从100%降低）。
- **风暴使者**
  
  
  
  
  - [[spell:454009]]主目标伤害降低10%。
  - [[spell:454009]]次要目标伤害降低30%。
- **图腾祭司**
  
  
  
  
  - [[spell:444995]]震荡伤害降低15%。
  - [[spell:445025]]涌动闪电伤害降低10%。
- **8月18日 –** 所有伤害提高5%。

这些改动，连同推出的新套装，进一步推动了 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者在第2赛季中的发展方向。虽然部分强度从[[spell:454009]]中被移除，但在其他方面获得的强度更高，而且 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者的冷却技能强度降低幅度小于其对应专精。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司仍然能够发挥作用，但其爆发性的[[spell:444995]]窗口受到的削弱大于其稳定伤害的提升，导致它略微落后。

总而言之，这些改动是净增强，进入第2赛季后我们的整体实力将比至暗之夜开季时更强。结合一些强大的新装备，以及一个 <em>好得多的</em> 第2赛季套装，我们将从一个良好的起点开始，尤其是随着赛季开始新增的5%光环增益。

:::

### 至暗之夜改动概述

3.6.

#### 增强萨满祭司在至暗之夜中的改动

至暗之夜对增强进行了大规模的重做，显著改变了其游戏体验和资源循环。这些改动让事情不再那么混乱，在输出循环中提供了更清晰的目标，但对近年来玩过增强的玩家来说应该会感到熟悉。改动更加强调近战打击，并将[[spell:187880]]管理与单纯的伤害之外的不同效果联系起来。由于这影响了该玩法的方方面面，下面将改动分为几个部分进行解析。

3.6.1.

##### 输出循环变化

至暗之夜对现代增强进行了长期以来最大的变革之一。最值得注意的改变是通过[[spell:1250364]]在近战打击与[[spell:187880]]之间建立了更强的联系，提供冷却缩减。此外，[[spell:187874]]现在会触发其增益效果 <em>无论命中多少个目标</em>，使其也适用于单目标。一些填充技能已被移除（即[[spell:196840]]和[[spell:342240]]），[[spell:470057]]现在是一个主动按钮而不是触发效果。我们的冷却技能组合也经历了重大改动，根据情况提供了一些替代计时方式。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_ancestralawakening.jpg>) 点击查看冷却技能改动说明
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_ironmaidens_swirlingvortex.jpg>) **毁灭之风**
  
  
  
  
  这是改动最大的部分，激活时现在可以受益于[[spell:384411]]和[[spell:384444]]。持续时间也被后者延长至10秒（点出该天赋时），并且已从GCD中移除。但是，额外的[[spell:33757]]几率已降低至200%。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_elementaldevastation.jpg>) **升腾 / 根深蒂固的元素**
  
  
  
  
  不再在施放时造成伤害，但其他功能保持不变，现在 <em>取代</em> [[spell:384352]]。每当[[spell:114051]]被触发时，也会免费施放毁灭之风。选择主动抉择点时，每消耗一点[[spell:187880]]还会提供0.5%的几率触发毁灭之风。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_feralspirit.jpg>) **野性狼魂**
  
  
  
  
  现在是一个被动天赋，每当你触发[[spell:384352]]时会召唤一只自然之狼，或在你施放[[spell:197214]]时召唤一只火焰之狼。它们分别为其对应系别提供5%物理伤害和5%元素伤害加成，持续8秒。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_shaman_primordialwave.jpg>) **始源之潮**
  
  
  
  
  已被移除，其效果（例如[[spell:1218047]]）改为放入[[spell:197214]]的施放中，而该技能已移至天赋树底部。

:::

天赋树也进行了一些调整，并加入了一些新天赋来完善游戏体验。[[spell:210853]]现在终于只需一点即可保证生成[[spell:187880]]，[[spell:319930]]更容易获取，[[spell:1262635]]现在是漩涡武器返还的来源。[[spell:289874]]也已从PvP天赋树中移出，使所有打击在使用时也能触发[[spell:188443]]，让我们在面对顺劈情况时能更平滑地过渡。

3.6.2.

##### 增强巅峰天赋 - 风暴释放

至暗之夜中的新职业特色是巅峰天赋，强大的4层天赋节点，点出后提供叠加收益。对于增强，[[spell:1262713]]为[[spell:187874]]的施放增加了显著的收益，使其在输出循环中占据更重要的地位：

- [[spell:1262713]] – 每消耗一点[[spell:187880]]有2%的几率使你的下一次[[spell:187874]]施放无视其冷却时间。此外，武器强化增益效果现在可以叠加。
- [[spell:1262761]] – 有两点，每点使消耗[[spell:187880]]的技能伤害提高7.5%，武器强化伤害提高10%。
- [[spell:1252373]] – 使[[spell:187874]]在地面上留下一个静态区域，在2秒内造成等同于初始伤害100%的伤害。此外，武器强化增益效果每层使自动攻击速度提高15%。

该节点的第一点收益相当高，增加了一个额外的触发效果来应对，并提升了[[spell:187874]]在输出循环中的价值。加上武器增益效果可以叠加的好处，这意味着刷新该效果不再浪费任何伤害，也让游戏体验更流畅一些。

3.6.3.

##### 英雄天赋改动

由于英雄天赋是增强玩法的关键组成部分，它们在进入至暗之夜时经历了一些最大的改动。它们在玩法上现在更加接近，但两者仍然各有特色。

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) **风暴使者改动 -** <em>点击查看详情</em>
  
  
  
  
  - [[spell:454009]]现在每消耗一点[[spell:187880]]有2%的几率触发。
  - [[spell:455129]]不再造成伤害，并有1.1 RPPM的几率触发[[spell:454009]]。
  - [[spell:454026]]现在在[[spell:384352]]触发时召唤一只持续12秒的狼，而不是在[[spell:454009]]施放时。
  - [[spell:470532]]现在仅从[[spell:188443]]触发。
  - **三个新天赋：** [[spell:1264762]]、[[spell:1264691]]和[[spell:1264688]]。
    
    
    
    
    在两棵天赋树之间， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者经历了最多的机制改动，结果反而有些受损。[[spell:454009]]现在是随机的，在消耗[[spell:187880]]时按百分比几率触发。[[spell:455129]]也已改为RPPM触发，因此虽然风暴触发的频率相似，但要可预测得多。最后，[[spell:454026]]改为在激活[[spell:384352]]时召唤一只[[spell:51533]]之狼。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) **图腾祭司改动 -** <em>点击查看详情</em>
  
  
  
  
  - [[spell:444995]]现在有1分钟冷却时间，持续25秒。
  - [[spell:453406]]（由[[spell:445024]]触发）现在使你的下一次[[spell:197214]]施放伤害翻倍，并召唤一个灼热图腾。
  - [[spell:467306]]现在在任何[[spell:60103]]或[[spell:470057]]施放时触发一个[[spell:458147]]。
  - **三个新天赋：** [[spell:1260644]]、[[spell:1263288]]和[[spell:1260874]]。
    
    
    
    
    相比之下， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司在至暗之夜中获得了明显的改进，其方向与其他新的天赋更新很好地契合。[[spell:444995]]现在更多地被定位为一个冷却技能，与[[spell:384352]]的改动配合，提供强大的1分钟爆发伤害。最突出的是新天赋——[[spell:1260644]]——允许极长时间的[[spell:201900]]持续时间。这也让恰当的[[spell:187880]]管理重新回到其输出循环中，而这在《地心之战》中一直严重缺失。

结果是它们在偏好打击（无论是[[spell:17364]]还是[[spell:60103]]）上保持了同样的区别，同时现在 <em>同时</em> 有了关注[[spell:187880]]的理由。

3.6.4.

##### 功能性与防御

不幸的是，虽然输出循环的改动很好，但我们的防御和功能性方面就未必了。我们失去了作为主动工具的[[spell:108270]]，[[spell:198103]]的冷却时间和持续时间都被缩短（分别为3分钟和30秒），同时还从[[spell:1279819]]中移除了减伤效果。不过我们现在通过[[spell:1217622]]拥有了永久的[[spell:974]]，尽管自我治疗不如以前强力。[[spell:384149]]已将之前的PvP天赋[[spell:410673]]整合进来，降低了自我治疗的消耗，[[spell:381689]]和[[spell:381650]]也都得到了增强，提供更多被动防御。

在功能性方面，我们保留了各种小众选项，但失去了大量控制能力。[[spell:381819]]（当需要更长的双重昏迷时）、[[spell:51490]]和[[spell:378779]]都已移除，[[spell:197214]]也不再使目标瘫痪。这严重限制了我们的控制选项，而控制曾是我们非常擅长的领域。

1.

### 增强萨满祭司玩法基础

增强的玩法围绕着几个通常同时进行的循环展开，创造出快节奏的游戏体验。这在至暗之夜中仍然存在，遵循三条总体规则：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_stormstrike.jpg>) **尽可能保持输出循环技能处于冷却状态**
  
  
  
  
  [[spell:187874]]应在可用时施放。[[spell:17364]]和[[spell:60103]]通过[[spell:1250364]]与你的[[spell:187880]]管理协同工作。尽可能保持这些技能的冷却。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_maelstromweapon.jpg>) **管理你的漩涡武器层数**
  
  
  
  
  [[spell:187880]]在消耗5层或更多层数时，使[[spell:188196]]和[[spell:188443]]变为瞬发。这通过[[spell:1250364]]提供冷却缩减。你的目标是通过保持在10层以下来避免浪费，并用它来重置[[spell:17364]]和[[spell:60103]]的冷却时间。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_callstorm.jpg>) **对每个构建的关键触发效果做出反应**
  
  
  
  
  这为战斗增加了变化性，需要快速的决策。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司需要对[[spell:201900]]做出反应，并通过[[spell:1260644]]延长其持续时间，同时 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者需要处理[[spell:454009]]的触发效果。

虽然至暗之夜让该专精更容易上手，但在熟悉增强的节奏时，仍然有相当陡峭的学习曲线。它往往需要将所有不同的方面作为一个整体来理解，所以在学习每个组成部分时可能会感觉有些不对劲。不过一旦你建立起一些肌肉记忆并掌握了节奏，与许多专精相比，它既非常有成就感又非常独特。

1.

### 如何为增强萨满祭司配装

虽然我们始终建议你通过模拟来获得最佳结果，但我们确实提供了专门的增强配装页面。我们目前涵盖了第2赛季装备的推荐，让你在进入终局至暗之夜内容时有一个良好的开端。在获取一些装备后，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 为12.1.5补丁进行了审查，添加了药水优化的进阶技巧。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已更新以纳入赛季开始后的重大配装改动。
- **2026年8月24日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 扩展了合剂和药水部分，提供更多进阶的第2赛季选择。
- **2026年8月24日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 调整了暴击等级，使其对风暴使者与精通持平，并降低了急速。
- **2026年8月24日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 调整了手册内容，提到第四个符文用于弥补不足的副属性。
- **2026年8月19日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 由于阿希尔班圣匣在线修正，添加了关于装备推荐不确定性的免责声明。
- **2026年8月19日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 由于第2赛季团队副本中有大量顺劈场景，将单体导入代码切换为超载。
- **2026年8月19日（本页）：** 包含了第2赛季开始的热修复。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已根据12.0.7补丁使用孢子坠落装备进行更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已根据12.0.7补丁使用全知卷册推荐进行更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月4日（本页）：** 已更新至5月5日的职业调整。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月7日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 在早期制作FAQ中添加了关于无界催化剂的说明。
- **2026年4月7日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 指出近期的调整并未影响构建推荐。
- **2026年4月7日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 对风暴使者团队副本构建进行了小幅更新，以适应更高的顺劈需求。
- **2026年4月7日（本页面）：** 根据4月7日职业平衡性调整进行更新。推荐天赋构建无变化。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 添加了关于至暗之夜中传家宝的说明。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 根据 至暗之夜 第一赛季发布进行更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已为第1赛季更新——为大秘境增加了茶饮和额外的消耗品。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为第1赛季发布进行更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月16日（本页面）：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月2日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 小幅更新以反映饰品调整。
- **2026年3月2日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 因属性变更调整了药剂推荐。
- **2026年3月2日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 由于放弃了过载，更新了 图腾祭司 的属性。
- **2026年3月2日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 对 图腾祭司 构建进行了小幅调整。
- **2026年3月2日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 对推荐天赋进行了小幅更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 根据 至暗之夜 发布和季前赛进行更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（本页）：** 已为至暗之夜的发布进行更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 将构建推荐更改为 图腾祭司。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 对输出循环进行了小幅更新，并将 图腾祭司 作为大秘境推荐。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 将大秘境和AOE推荐更改为 图腾祭司。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 将AOE构建推荐更改为 图腾祭司，并调整了输出循环提示。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 为11.2.7补丁更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 为11.2.7补丁更新。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 为11.2.7补丁更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 为11.2.7补丁更新。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 针对11.2.7版本进行了审查。对输出循环分解进行了小幅调整。
- **2025年11月30日（本页面）：** 已为11.2.7版本进行更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为11.2.5版本更新，并加入了卡特尔代币推荐。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已更新以强调推荐是基于新套装的。
- **2025年8月28日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 添加了第三赛季天赋切换速查表。
- **2025年8月16日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 更新了饰品梯级榜以纳入调整。
- **2025年8月12日（本页）：** 更新以包含第三赛季的在线修正增益。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已更新以纳入D.I.S.C.的热修。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为11.1.7版本更新，加入D.I.S.C.腰带，并为双加里维克斯武器微调了毕业列表。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 为11.1.7补丁更新。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 为11.1.7补丁更新。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月12日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为涡轮加速发布确认迪纳尔推荐。
- **2025年5月12日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已根据腐蚀调整进行更新。
- **2025年5月12日（本页）：** 添加了说明以突出更新后的卡特尔代币和腐蚀推荐。
- **2025年4月28日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 添加了副本提示。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已针对11.1.5版本进行审查，并添加了卡特尔代币部分。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 针对11.1.5版本进行了审查，强调了近期 风暴使者 增强后两个天赋树的接近程度。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 针对11.1.5版本进行了审查，调整了推荐以突出两个天赋树的接近程度。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 在增强后，将单体目标推荐转回 风暴使者。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 将 图腾祭司 天赋树转向以获得更多的单体目标舒适度。
- **2025年3月16日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 调整推荐以更坚定地采用 图腾祭司。
- **2025年3月16日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 更新为更具通用性的 图腾祭司 大秘境天赋配置。将所有推荐更改为 图腾祭司。
- **2025年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 将单体目标推荐更改为 图腾祭司。
- **2025年3月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了更多相关的正式服信息和加里维克斯提示。
- **2025年3月4日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 下调了塞尔瑟斯的王冠推荐。
- **2025年3月4日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 为单体目标添加了深渊之威。
- **2025年3月4日（[解放安德迈页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 更新以纳入3月4日的激涌之灵在线修正。
- **2025年3月4日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 清理了推荐构建，以纳入激涌之灵削弱和赛季发布。
- **2025年3月4日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 将巫医之祖重新加入推荐和输出循环工具。
- **2025年3月4日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 调整了所有天赋构建，以弃用激涌之灵。
- **2025年3月4日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 更新以纳入3月4日的激涌之灵在线修正。
- **2025年3月4日（本页）：** 更新以纳入3月4日的激涌之灵在线修正。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已更新以突出热修后新戒指的强度。
- **2024年12月17日（本页）：** 已更新以突出热修后新戒指的强度。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为11.0.7版本更新，加入希尔赛的项圈。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.7版本进行了审查，添加了推荐标记。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 针对11.0.7版本进行了审查，添加了推荐标记。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.7版本进行了更新，添加了更详细的 托里姆 的祈求部分。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 针对11.0.7版本进行了更新，在关键构建上添加了推荐标记。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 针对11.0.7版本进行了更新，大幅精简了输出循环部分。
- **2024年12月15日（本页）：** 针对11.0.7版本进行了更新。
- **2024年11月5日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 将正义之手加入单体目标推荐。
- **2024年11月5日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 添加了Weakauras部分。
- **2024年11月5日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 更新为适合 风暴使者 和 图腾祭司 的11.0.5版本天赋构建。
- **2024年11月5日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 更新为 风暴使者 与 图腾祭司 的对比构建，并添加了游戏玩法提示部分。
- **2024年11月5日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 根据更近期的11.0.5版本认知，对优先级列表进行了重大更新。
- **2024年11月5日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 基于发布后更多经过测试的11.0.5版本构建，对推荐配装进行了重大更改。
- **2024年11月5日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 更新为更近期的11.0.5版本信息。
- **2024年11月5日（本页）：** 更新以纳入更近期的信息以及11.0.5版本后的多次在线修正。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 针对11.0.5版本进行了更新。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.5版本进行了更新，发布后将需要进一步更新。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 针对11.0.5版本进行了更新，发布后将需要进一步更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 11.0.5版本的初步更新。随着更多正式服数据的获取将进行更新。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 针对11.0.5版本进行了更新，发布后将需要进一步更新。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 针对11.0.5版本的改动进行了更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 针对11.0.5版本进行了更新，补丁发布后将需要进一步更新。
- **2024年10月21日（本页）：** 更新了关于11.0.5版本重大变更的说明。
- **2024年9月30日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 已更新为所有Boss配上了合适的配装和更新的提示。
- **2024年9月23日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已根据最新的热修复和风暴天赋切换进行更新。
- **2024年9月23日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已根据最新的热修复和风暴天赋切换进行更新。
- **2024年9月23日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已根据最新的热修复和风暴天赋切换进行更新。
- **2024年9月23日（本页）：** 已根据最新的热修复和风暴天赋切换进行更新。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已更新第1赛季毕业列表。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 针对第一赛季毕业配装列表进行了更新。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 页面已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已为地心之战第1赛季的发布进行更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 针对 元素 爆裂和风暴之怒的在线修正以及新的风暴配装进行了更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 针对 元素 爆裂和风暴之怒的在线修正以及新的风暴配装进行了更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 针对 元素 爆裂和风暴之怒的在线修正进行了更新。
- **2024年9月9日（本页）：** 添加了关于套装在线修正及未记录更改的说明。
- **2024年9月3日（本页）：** 针对在线修正变更进行了更新。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/enhancement-shaman-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/enhancement-shaman-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/enhancement-shaman-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月13日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 格式调整，将滑块移近循环部分。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已更新至10.2.7。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为第4赛季和觉醒装备的发布进行更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 为第4赛季进行了更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 为第4赛季进行了更新。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月21日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 针对10.2.6版本进行了审查，添加了关于湮灭余烬的说明。
- **2024年3月21日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6版本进行了审查，精简了洞察部分。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 针对10.2.6版本进行了审查，将推荐构建切换为标准元素使徒。
- **2024年3月19日（本页面）：** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对10.2.5版本进行审查，无需更改。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 针对10.2.5版本进行了审查，添加了关于狂心的说明。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 针对10.2.5版本进行了审查，添加了大地 元素 取消方法。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 针对10.2.5版本进行了审查，转向了针对更高装备等级的推荐。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对10.2.5版本进行审查，无需更改。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 针对10.2.5版本进行了审查，润色了一些部分并将防御性饰品作为选项添加。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2版本进行了审查，结构有轻微变动但内容依然准确。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 针对10.2.5版本和赛季中期更新进行了审查和润色。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 针对10.2.5版本的法术学派变更进行了更新。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 针对10.2.5版本进行了审查，构建保持不变。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2023年11月9日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已为10.2版本重构并更新。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 更新以移除孢子斗篷推荐，切换了幻晶/暗影烈焰。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已为10.2版本天赋变动进行更新。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对10.2补丁进行审阅，无需更改。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已更新大秘境中心的链接。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为10.2版本更新，并重构了循环工具。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已为10.2版本天赋变动进行更新。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为10.1.7版本重构，信息保持不变。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 为10.1.7补丁进行了一些结构调整，将慰藉之炽怒靴作为一项制造选项加入。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 重构了冷却技能章节，但10.1.7版本无需内容更改。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已针对10.1.7补丁进行审阅，进行了小幅结构调整并加入了元素汇聚。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年7月20日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已重写以包含循环手法建议。
- **2023年7月20日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 为高层大秘境加入了孢子披风的制造选项。
- **2023年7月20日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 在装备章节中为冲层加入了关于孢子披风的说明。
- **2023年7月14日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 在切换按钮上加入了配装方案按钮，以便更轻松地展示循环手法。
- **2023年7月13日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 清理了AOE循环章节，并对风暴相关部分进行了改进。
- **2023年7月12日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 由于补丁发布更新，提升了加速沙漏的价值。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新，加入了永恒黎明装备并整理了制造章节。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审阅，无需更改。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行更新，强烈建议不要使用永恒印记。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行更新，加入了关于软急速阈值的小提示。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已针对10.1.5补丁进行更新，风暴流派改为使用风暴顺劈。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新，移除了风暴流派中四件套的使用，并强调优先使用风暴打击而非消耗技能。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已针对10.1.5补丁进行审阅，并在推荐中更新了风暴顺劈。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已针对10.1.5补丁的更改进行更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月25日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 添加了关于大灾变时光漫游的部分。
- **2023年5月10日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已更新以加入一套更简单但仍具竞争力的新手配装。
- **2023年5月9日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已更新以调整饰品的更改。
- **2023年5月9日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已更新以在元素汇聚单体输出中加入原始浪潮。
- **2023年5月9日（本页）：** 更新以突出显示首领提示的新增内容和装备变更。
- **2023年5月4日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 对循环工具进行了微调，为错误的天赋组合添加了警告。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为10.1版本和第2赛季的发布更新，加入新的装备推荐。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已更新至10.1补丁及新增消耗品。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已更新至10.1，调整了关于风暴流派和元素使急速的说明。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已更新至10.1补丁及第2赛季新流派，以及初始套装起手手法。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 针对10.1补丁更新进行了全面改版，包含风暴流派、循环工具更新、T30套装奖励及新增章节。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已全面更新至10.1补丁并修订了新流派。物理流派已转换为风暴流派。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已更新至10.1补丁的变更内容。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已更新至10.1补丁，加入了更便于新手的流派，并修订了新手循环。
- **2023年5月1日（本页）：** 已根据10.1补丁改动更新，添加了新的亮点部分和预期表现。
- **2023年4月29日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已根据10.1补丁审查，无需更改。
- **2023年3月24日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已根据原始宝石的在线修复更新。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已根据原始宝石的在线修复更新。
- **2023年3月22日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已为10.0.7补丁更新。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已更新以纳入原始石的增益效果。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/enhancement-shaman-best-legendaries-shadowlands>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已根据10.0.7补丁更新，包含熔炉指环推荐。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 添加了更多常用宏，并针对10.0.7补丁进行了审阅。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已审阅并为10.0.7补丁添加了小幅改进。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已根据10.0.7补丁审查并更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已更新至全新的10.0.7补丁职业天赋树。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已更新至10.0.7补丁的变更内容。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已审阅并改进循环工具，使其更贴近当前游戏实际。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已审阅并更新至10.0.5补丁。
- **2023年1月24日（本页）：** 已更新至10.0.5补丁。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 添加了套装章节。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/enhancement-shaman-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/enhancement-shaman-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/enhancement-shaman-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/enhancement-shaman-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/enhancement-shaman-patch-9-2-changes-analysis>)):** 已为9.2版本发布进行了清理。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/enhancement-shaman-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/enhancement-shaman-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年5月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/enhancement-shaman-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2020年10月13日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月25日（[永恒宫殿页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-the-eternal-palace-raid-guide>)):** 已更新至所有首领。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月1日（[风暴熔渣页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-crucible-of-storms-raid-guide>)):** 已更新每个首领的说明。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年1月28日（[达萨罗之战页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为达萨罗之战添加了 增强萨满祭司 提示。
- **2018年9月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-uldir-raid-guide>)):** 为奥杜尔开放周进行了初步更新。
- **2018年8月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-uldir-raid-guide>)):** 已创建页面，为奥杜尔的最终发布做准备。

显示更多

显示更少

:::

## 练级

在本页中，您将找到我们的 增强萨满祭司 逐级练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[萨满祭司练级指南](<https://www.icy-veins.com/wow/shaman-leveling-guide>).

1.

### 增强萨满祭司 练级指南：至暗之夜

欢迎来到我们的 增强萨满祭司 至暗之夜 练级指南！这将在您升至满级的旅程中为您提供帮助，涵盖您应该了解的天赋和技能。

增强萨满祭司 在练级时非常灵活，凭借极高的机动性和处理大量拉怪的能力，配合自我治疗保持健康，非常适合做任务。凭借[[spell:2825]]和[[spell:198103]]等强大而多用的冷却技能，应对特别危险的精英怪也毫无问题。它很早就能获得群体伤害手段，非常适合在15级就开始地下城之旅，不过如果您以恢复身份治疗，排队可能会更快。

1.1.

#### 升级装备选择

升级时，您应始终选择物品等级最高的装备。这些装备通常很快就会被替换，所以只要捡到什么就穿什么，不必担心次要属性。

传家宝物品可以为您的小号购买，其物品等级会随您升级而提高。如果您拥有这些物品，通常追求急速与全能的搭配。这将使循环更加平滑，并在拉一群敌人时提供更多生存能力。

1.2.

#### 至暗之夜升级实用消耗品

如果你想获得额外助力来度过至暗之夜的练级过程并追赶满级内容，有一些物品和附魔可以帮助你加快进度。

- [[item:191348]] —— 一瓶药水，来自 [巨龙时代](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  死亡后依然存在，提供30分钟的移动速度加成。如果你装备已经不错，重点往往在于各波怪物之间的移动速度，而不是多一点伤害。
- [[item:225592]] —— 一种食物，来自 [地心之战](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)，可在1小时内大幅提升移动速度。
- [[item:213746]] — 如果您的装备有插槽，请换上这颗艾吉拉利钻石以获得额外速度。
- [[item:223653]] / [[item:223683]] / [[item:223725]] / [[item:223800]] —— 如果你之前使用的是闪避或吸血附魔，请将所有护甲附魔换成额外的移动速度效果。
- [[item:132516]] —— 练级时经久不衰的选择，在无法骑马的区域总能派上用场，甚至在水面上也能使用。这些 <em>无法</em> 在战斗中激活，并且在受到伤害时会被取消。
- [[item:154168]] / [[item:154169]] — 这些来自争霸艾泽拉斯的消耗品有助于应对需要在水下进行的环节——尽管在至暗之夜的区域中这种情况并不常见。
- [[item:109076]] — 如果您意外从坐骑上摔落或需要从高处下来，这些物品可以减轻坠落伤害，因此非常适合紧急情况使用。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 增强 练级 - 80级起始天赋
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMDjZmZmZmhZmZAAAAAAAAAsBgZMsBgZANYBgZZGzYssMDMzswiZmZYsMmBAYGGzMMCMzgBDA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMDjZmZmZmhZmZAAAAAAAAA2AsYGDbwGMDDNYBgZZGzYssMDMzswiZmZGjlxMAAzwYmhZCMzgBjB"
}
```
:::

:::details 来源计算器编码
```
#HE-DBQaUEppxdptIbbqEkprjiggxCUARSmjeep-CDZBOEXWQHNcRMgdVAjYSLPKKJheibB-AAAA-OIOEoYI0wsAApI-
```

:::

2.1.

#### 升级用战争模式天赋

如果你愿意承担风险并使用战争模式，以下PvP天赋推荐在练级期间或其他开放世界内容中使用。有时你可能想使用其他选择，我们鼓励你尝试！PvP天赋可以随时自由更改。

您的第一个PvP天赋栏将在20级解锁，第二个在30级，最后一个在40级。

- **20级：** [[spell:204331]] 让您可以激进地拉怪并将伤害回馈给敌人，以您自己的生命值作为资源！
- **30级：** [[spell:409293]] 是一个不错的额外移动和起手爆发手段，也可用作紧急生存技能。
- **40级**：[[spell:305483]] 对危险的敌人提供额外的眩晕效果，并在引导期间提供少量额外伤害。不过早期没有太多好选择，所以在等待48级解锁[[spell:193876]]期间，不妨先点出这个。
- **48级及以上：** [[spell:193876]] 在48级获得[[spell:2825]]时解锁，并将其冷却时间缩短至仅1分钟，使我们拥有更频繁的爆发窗口。

1.

### 升级循环

为了帮助你了解升级和天赋树进程中的变化，请使用下方的滑块选择你当前的等级。每次升级时，将滑块移动，本节内容也会随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 71 起：**达到71级并解锁英雄天赋后，我们建议使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 以解锁 [[spell:454009]]。上方的导入代码将为您提供一套可以立即开始至暗之夜内容的流派。

3.1.

#### 核心概念

随着您升级并填充天赋树，增强 将逐渐在循环之外拥有更多需要留意的独特机制。本章节将随滑块随每个等级一同扩展。

- **记得恢复！** - 每当你在波次之间生命值较低时，可以使用所有职业都有的[[spell:1231418]]技能来快速恢复。
- **等级 1–9：****先升到10级** - 由于增强仅在10级作为天赋专精解锁，在您看到该选项之前，应使用新手任务中提供的技能。
- **等级 10 起：****理解漩涡武器** - 重要的是要尽早学会，只有在拥有5层或更多[[spell:187880]]使其变为瞬发时才应施放法术。单体时消耗层数用于[[spell:188196]]，群体伤害时用于[[spell:188443]]。
- **等级 13–18：****时刻保持附魔！** - 增强工具箱的核心部分是武器附魔。请确保始终附有[[spell:318038]]。
- **等级 19–59：****时刻保持附魔！** - 增强工具箱的核心部分是武器附魔。请确保始终附有[[spell:318038]]和[[spell:33757]]。这些法术会自动施加到您主手和副手的相应武器上。
- **等级 60 起：****时刻保持附魔！** - 增强工具箱的核心部分是武器附魔。请确保始终附有[[spell:318038]]和[[spell:33757]]。[[spell:192106]]将通过[[spell:1270350]]自动施加这些效果。
- **等级 16 起：****别忘了增益！** - 使用[[spell:462854]]保持增益状态，以获得额外的精通和自动攻击触发。记得每60分钟重新施放一次，或者在有新队友加入地下城时重新施放。
- **等级 10–17：****使用你的护盾** - 请确保始终激活[[spell:192106]]，以在受到攻击时获得额外的[[spell:187880]]和伤害。
- **等级 18–59：****使用你的护盾** - 请确保始终激活[[spell:192106]]，以在受到攻击时获得额外的[[spell:187880]]和伤害。此外，多亏了[[spell:383010]]，您可以同时保持[[spell:974]]激活以获得额外治疗。
- **等级 60 起：****使用你的护盾** - 请确保始终激活[[spell:192106]]，以在受到攻击时获得额外的[[spell:187880]]和伤害。[[spell:1270350]]也会施加[[spell:974]]，通过[[spell:1217622]]该效果是永久的。每小时刷新一次。

3.2.

#### 动态优先级列表

以下是用于追踪该使用哪些技能的优先级列表示例。

1. **等级 1–30：**接敌时施放[[spell:188389]]。
2. **等级 31 起：**接敌时施放[[spell:470057]]。
3. **等级 71 起：**在有充能且拥有10层[[spell:187880]]时施放[[spell:454009]]。
4. **等级 55 起：**冷却完毕即施放[[spell:384352]]，理想情况下用于精英怪和大群敌人。
5. **等级 10–44：**如果拥有5层及以上[[spell:187880]]，施放[[spell:188196]]。群体伤害时切换为[[spell:188443]]。
6. **等级 45 起：**如果拥有10层[[spell:187880]]，施放[[spell:188196]]。群体伤害时切换为[[spell:188443]]。
7. **等级 1–9：**施放[[spell:73899]]。
8. **等级 15–80：**冷却完毕即施放[[spell:187874]]。
9. **等级 81 起：**冷却完毕即施放[[spell:187874]]。记得对[[spell:1262713]]的触发做出反应！
10. **等级 10 起：**施放[[spell:17364]]。
11. **等级 13 起：**施放[[spell:60103]]。
12. **等级 31 起：**施放[[spell:470057]]。
13. **等级 10 起：**如果拥有5层及以上[[spell:187880]]，施放[[spell:188196]] / [[spell:188443]]。

**等级 10 起：**3.3.

#### **等级 10 起：**生存工具

**等级 10 起：**增强 还拥有通过各种法术和效果在不同情况下生存的手段：

- **等级 10 起：**我们可以使用[[spell:187880]]层数来产生[[spell:384143]]层数，这将使[[spell:8004]]变为瞬发。如果您处于危险之中，消耗这些层数来保持健康。
- **等级 32 起：**[[spell:198103]] 是您紧急情况下的私人随身坦克，会嘲讽附近的敌人以减轻压力。该效果持续30秒，非常适合应对危险的精英怪。 <em>避免</em> 在单人时选择[[spell:1279819]]，以保留该效果。
- **等级 16–17：**[[spell:974]]为我们提供被动治疗，维持期间甚至能提升自我治疗。通过保持[[spell:192106]]激活获得的[[spell:187880]]通常更有用。
- **等级 18–57：**[[spell:974]]为我们提供被动治疗，维持期间甚至能提升自我治疗。
- **等级 58 起：**[[spell:974]]为我们提供被动治疗，维持期间甚至能提升自我治疗，而且在至暗之夜中由于[[spell:1217622]]，不再损失层数。
- **等级 10 起：**[[spell:20608]] 让我们可以在死亡后直接原地复活，但冷却时间长达30分钟。如果您不小心玩得太过火，可以使用它直接回到出发地点，无需跑尸。只是要小心——复活时生命值很低，所以如果附近有敌人，步行返回可能更划算。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 添加了关于至暗之夜中传家宝的说明。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月13日：** 格式调整，将滑块移近循环部分。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，无需更改。
- **2023年11月6日：** 已为10.2版本天赋变动进行更新。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月20日：** 已重写以包含循环手法建议。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月22日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩增强萨满祭司，使用最简单的循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 增强萨满祭司 基础知识

欢迎来到我们的简易模式页面！本部分面向刚接触游戏或职业的玩家，他们没有参与史诗难度团队副本的打算，只想了解该专精的简明玩法，而不需要最优玩法所需的大量优先级细节。

增强 有一条凌驾于一切之上的规则—— **永远在按技能**。即使在至暗之夜简化之后，这仍是一个有很多运作部件的专精。它总有东西可以填补时间，所以唯一比按错键更糟的就是什么都不按。学习该专精时要遵循的三条快速规则是：

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_maelstromweapon.jpg>) **管理你的漩涡武器**
  
  
  
  
  增强的资源是[[spell:187880]]，用于[[spell:188196]]和[[spell:188443]]。达到5层或更多时变为瞬发。其上限为10层，因此避免浪费。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_stormstrike.jpg>) **循环使用技能冷却**  
  
  增强有多个受冷却时间限制的近战打击。让您的[[spell:17364]]、[[spell:60103]]和[[spell:187874]]保持冷却，并在高层数时穿插使用[[spell:187880]]消耗技能。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_callstorm.jpg>) **应对触发效果**
  
  
  
  
  每个英雄天赋树都有一个需要做出反应的触发效果。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司拥有[[spell:201900]]，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者拥有[[spell:454009]]。两者也都有在[[spell:187874]]上重置[[spell:1262713]]的效果需要留意。

学习增强的最佳方法是循序渐进，而不是试图一次性学会所有内容。每个方面单独来看都遵循相当简单的规则，但难点在于如何在快节奏的战斗中将它们全部结合起来。

在第2赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者在所有场景中都占优势，使其成为无论何种内容的首选。它还拥有在单体和群体伤害中使用相同流派的优势，使其拥有一种通用的玩法风格。

1.

### 至暗之夜 增强萨满祭司 新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 团本流派

2.1.

#### 增强萨满祭司 新手团本天赋

在第2赛季的团本和单体战斗中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 领先，凭借其更强的爆发和内置于工具箱中的强力顺劈能力。它高度侧重于您对[[spell:187880]]资源的使用，并将[[spell:17364]]作为主要近战技能。

它以[[spell:114051]]为冷却时间，每2分钟提供极高的爆发伤害。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 增强单体目标 - 风暴使者
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogBbs88YB1uOjUU-COXWDZEBQVgYdFARcMNjPiKKJLblC9A-AAAA-Aego0QsgBTgwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者地下城与宝库配装

2.2.

#### 增强萨满祭司新手地下城天赋

与单体目标非常相似， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者在AoE和地下城环境中已牢牢占据领先地位。它利用[[spell:289874]]、[[spell:188443]]和[[spell:454009]]，通过[[spell:455123]]造成额外伤害，并且在目标数量较少时表现尤为出色。

它每两分钟通过[[spell:114051]]拥有极强且稳定的爆发能力，同时还有通过[[spell:384352]]和[[spell:454009]]触发的不稳定爆发，需要及时应对。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 增强AoE - 风暴使者
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2gFYGGawCAzyMmxYZxYjZmtxyMzMzYswMAAzwYmhRgZGMYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZMWYGAgZYMzwIwMDGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFoAzzrsrzYBK1KROB-CDEOXZBFNRVWYdgjAMQShLPeKKbT4EB-AAAA-OUaIawIMsEAEpA-
```

:::

### 单体与范围输出循环详解

2.3.

#### 新手增强萨满祭司输出循环

在进入战斗之前，务必记得施加以下效果。

- **施加护盾与武器附魔**
  
  
  
  
  [[spell:1270350]]通过[[spell:192106]]施加护盾和武器附魔。
- **施放团队增益**
  
  
  
  
  使用[[spell:462854]]为你和你的队伍提供精通和自动攻击触发效果。
  
  
  
  
  对你的坦克施放[[spell:974]]，因为[[spell:383010]]允许施放两个。

2.4.

#### 单体输出详解

在单体目标中，增强需要正确管理其资源以保持技能公共冷却时间满载，同时避免浪费[[spell:187880]]，因为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者。它还有一些需要应对的触发效果：

- **消耗你的漩涡武器**
  
  
  
  
  [[spell:187880]]在 **10** 层时消耗，使用带有触发效果的[[spell:454009]]或[[spell:188196]]。
  
  
  
  
  可在较低层数使用以获得[[spell:1250364]]对[[spell:17364]]的冷却缩减。
- **使用循环技能**
  
  
  
  
  冷却好就施放[[spell:470057]] <em>总是</em>，并在可用时使用[[spell:187874]]。
  
  
  
  
  <em>循环优先级 -</em> [[spell:470057]] ➜ [[spell:187874]] ➜ [[spell:17364]] ➜ [[spell:60103]].
- **最大化你的冷却技能**
  
  
  
  
  [[spell:114051]]应每两分钟使用一次。
  
  
  
  
  在升腾期间，可用时施放[[spell:187874]]，否则施放[[spell:115356]]。
- **应对触发效果**
  
  
  
  
  作为风暴使者，你有三个触发效果 - [[spell:454009]]、[[spell:1262713]]和[[spell:1262635]]。
  
  
  
  
  <em>风暴</em> – 替代[[spell:188196]]，在10层时消耗。
  
  
  
  
  <em>风暴释放</em> – 重置[[spell:187874]]，尽快使用。
  
  
  
  
  <em>雷电容器</em> – 返还[[spell:187880]]以实现连续消耗。

在尝试学习增强的循环原理时，一次性掌握可能会很困难。我们建议分阶段学习，顺序如下：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_improvedstormstrike.jpg>) **增强单体目标**
**近战技能交替**

➜

**[[spell:187880]]管理**

➜

**冷却技能使用**

:::

2.5.

#### 范围输出详解

在AoE中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者的玩法几乎完全相同，但由于额外资源，更注重[[spell:187880]]的效率：

- **消耗你的漩涡武器**
  
  
  
  
  [[spell:187880]]在AoE中用于[[spell:188443]]。在 **10** 层。
  
  
  
  
  层时消耗。[[spell:454009]]触发效果应始终优先消耗，使用 **10** 层。
- **有效使用循环技能**
  
  
  
  
  [[spell:470057]]是 <em>始终的最高优先级</em> 拥有2件套时：
  
  
  
  
  <em>技能优先级 -</em> [[spell:470057]] ➜ [[spell:187874]] ➜ [[spell:17364]] ➜ [[spell:60103]].
- **最大化你的冷却技能**
  
  
  
  
  [[spell:114051]]每2分钟使用一次，最好在危险的拉怪中使用。
  
  
  
  
  激活期间，可用时施放[[spell:187874]]，否则施放[[spell:115356]]。

增强在AoE中可能有点令人不知所措，因为同时发生的事情太多。很容易迷失方向，所以我们建议分阶段专注于不同方面，最好按以下顺序：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_improvedstormstrike.jpg>) **增强AoE**
**学习单体目标**

➜

**优化[[spell:187880]]管理**

➜

**爆发冷却时间窗口**

:::

如果你对这些更基础的分解感到满意，并希望获得更深入的理解，可以查看我们的循环页面，其中更深入地涵盖了决策制定：

[增强萨满祭司循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)

2.5.1.

##### 巅峰天赋： ![Storm Unleashed Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_shaman_stormunleashed.jpg>) 风暴释放

本页上所有推荐的配装都在顶峰天赋[[spell:1262713]]中投入四点。这只是需要留意的额外触发效果 - 每当它触发时，尝试尽快将其用于[[spell:187874]]。由于第一点使增益效果可以重叠，提前刷新效果不会造成任何损失。

2.5.2.

##### 第2赛季套装

增强的第2赛季套装， **蛇形神谕者的预言**，提供以下两个加成：

- [[spell:1296627]] – [[spell:470057]]使你的主要目标每2秒喷发出一次[[spell:333974]]，持续6秒。火焰新星对你的电光烈焰的主要目标造成提高200%的伤害。
- [[spell:1296628]] – [[spell:333974]]使[[spell:187874]]的冷却时间缩短2秒，并使你下一次毁灭闪电的伤害提高8%，最多可叠加5次。

这两个加成的运作机制相当复杂，但实际上它们只改变了几件事。[[spell:470057]]现在被置于你的循环优先级顶部，并且额外强调保持[[spell:187874]]的冷却循环。这些都强烈鼓励你选择[[spell:333974]]，以及在顶峰天赋[[spell:1262713]]中投入全部四点。

### 生存工具与   **防御法术**

2.6.

#### 增强萨满祭司防御法术

增强的技能库中主动防御技能使用频率不高，但每一个在可用时都相当强大。这意味着你在参与战斗时需要更加小心。

**[[spell:108271]] -** 提供40%的伤害减免，持续12秒，冷却时间为1.5分钟（使用[[spell:381647]]）。这是增强最强的防御工具，虽然冷却时间比大多数防御技能长，但在激活期间能提供大量安全保障。

**[[spell:198103]] -** [[spell:108271]]提供持续30秒的最大生命值15%加成，冷却时间为3分钟。这是一个在你无法使用[[spell:108271]]时的“备用”冷却技能，并且可以覆盖更长时间的伤害。[[spell:1279819]]对于避免它嘲讽敌人并死亡很重要，不过在单刷时可以放弃使用它来提供一个个人坦克。

**[[spell:260878]] -** 在长时间处于[[spell:2645]]中后，可提供最高20%的伤害减免。这是在你没有其他可用手段时的最后防御手段，因为我们在变形状态下无法造成任何伤害。

**[[spell:384143]] -** 在消耗[[spell:187880]]时，它会提供相同层数的另一个增益效果。这会对你的[[spell:8004]]或[[spell:1064]]施加相同的效果，让你在需要时穿插一些自我治疗。与之前的版本相比，这种DPS损失带来的痛苦更小（尽管效果同样更弱），而且在危急时刻几乎总是可用的。

**[[spell:974]] -** 在一场战斗过程中提供适量的治疗。这里强烈推荐[[spell:1217622]]使其永久生效，同时搭配[[spell:383010]]，这样你就能维持[[spell:192106]]。这也可以对第二个盟友施加，提供少量的副治疗。

**[[spell:355630]] -** 在成功打断法术后提供强大的伤害减免，如果正在承受大量伤害，这给了我们额外的动力去这样做。

### 装备选择与   **属性优先级**

2.7.

#### 增强萨满祭司属性优先级

最通用的增强属性优先级可以覆盖这里提供的两种流派，如下所示。有关本页呈现内容的更多信息，请查看我们的主 [属性优先级页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>).

装备等级

暴击

精通

急速

全能

2.8.

#### 增强萨满祭司配装

在至暗之夜第二赛季配装时，你希望尽快优先获取你的套装，而打造武器是开局就能获得大量提升的快捷方式。由于配装角色时有如此多的不同选择，最好跳转到我们的主 [装备页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot>)
以获取关于需要追求哪些装备的更全面解析。

### 暴风雪循环助手

2.9.

#### 暴风雪针对增强萨满祭司的循环助手

该功能在地心之战期间加入，已逐步改进，在至暗之夜中表现稍好一些。随着至暗之夜简化了一些较为复杂的增强机制，如果你想要学习该专精，这是一个更合理的起点。它有两个版本——一个基于精选暴风雪优先级的动作条高亮，或一个自动按下该按钮的单键绑定（不过，使用时每次施放之间会有25%的公共冷却惩罚）。

然而，它会带来性能损失和一些额外的限制。最重要的是，该工具将 **非** 使用[[spell:114051]]（当点出时）、任何种族加成或使用型饰品——如果你使用它，这些都需要你手动施放。这也适用于移动、防御和控制技能。

虽然该工具在至暗之夜中确实更好，但它仍然需要手动输入才能使用。两个英雄天赋树现在的工作方式类似，但由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司
<em>不</em> 点出[[spell:114051]]，它的表现会更好，因为它可以无需手动协助即可使用其全部工具。以这种方式使用时，当你试图掌握该专精时，它是一个很好的学习工具，或者如果你想在一些较慢的内容中放松一下时使用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月2日：** 对推荐天赋进行了小幅更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 将AOE构建推荐更改为 图腾祭司，并调整了输出循环提示。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7版本进行了审查。对输出循环分解进行了小幅调整。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月4日：** 已更新以强调推荐是基于新套装的。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年4月21日：** 在增强后，将单体目标推荐转回 风暴使者。
- **2025年3月16日：** 将单体目标推荐更改为 图腾祭司。
- **2025年3月4日：** 更新以纳入3月4日的激涌之灵在线修正。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 针对11.0.7版本进行了更新，大幅精简了输出循环部分。
- **2024年11月5日：** 更新为更近期的11.0.5版本信息。
- **2024年10月21日：** 针对11.0.5版本进行了更新，补丁发布后将需要进一步更新。
- **2024年9月23日：** 已根据最新的热修复和风暴天赋切换进行更新。
- **2024年9月9日：** 针对 元素 爆裂和风暴之怒的在线修正进行了更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6版本进行了审查，将推荐构建切换为标准元素使徒。
- **2024年1月15日：** 针对10.2.5版本进行了审查，构建保持不变。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月10日：** 已更新以加入一套更简单但仍具竞争力的新手配装。
- **2023年5月1日：** 已更新至10.1补丁，加入了更便于新手的流派，并修订了新手循环。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已审阅并更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页，你将找到魔兽世界12.1.5版本中你的增强萨满祭司的最佳天赋。我们还为团队副本或大秘境等不同类型的内容提供了默认天赋构建。如果你开启了战争模式，我们也为你准备了PvP天赋。

1.

### 至暗之夜中增强萨满祭司的最佳天赋

在至暗之夜整个过程中，增强的天赋树经历了一些重大变化，选项更加精简以适配其英雄天赋树。它通常允许非常灵活的伤害输出模式，而且存在 <em>显著的</em> 两种流派关键天赋的重叠， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司。第二赛季的当前推荐如下：

- **团队副本 -** **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者** 提供更强的单体目标、爆发和顺劈伤害，非常适合毒液深渊中的战斗。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司在单体目标上能跟上，但在顺劈上落后，并且在新套装下循环更忙。
- **大秘境 -** **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者** 在第二赛季中稳稳占据领先地位，在几乎所有目标数量下（大规模群体AOE除外）都能造成更高的伤害。此外，它也更容易将套装效果融入输出循环中。

由于第二赛季持续的数值调整，再加上当前套装的加入， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者在所有内容中都确立了明显的领先优势，并继续保持。虽然其2分钟爆发节奏更严格（且随机性更大），但其伤害模式的灵活性使其成为团本和大秘境的明确首选。由于剧毒深渊需要极高量的顺劈伤害，它在低至中等目标数量下的伤害优势使其进一步领先于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 尽管有热修试图缩小差距，图腾祭司仍然更强。下面，如果你想要直接进入游戏，我们提供了一些导入代码：

**快速开始导入代码：**

:::talents 团本/单体目标 - 风暴使者
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
}
```
:::

:::talents 群体AOE/大秘境 - 风暴使者
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2gFYGGawCAzyMmxYZxYjZmtxyMzMzYswMAAzwYmhRgZGMYMA"
}
```
:::

:::talents 地下堡 - 图腾祭司
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMjZmZmZmZmZmZGzAAAAAAAAAALwGMjFN2GAzA2AYWmxMGLLzAzMGLmZmZMWYGAADMGzMxMDAMGA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

风暴使者

团队副本/单体目标

推荐

大秘境/群体伤害

推荐

地下堡

图腾祭司

团队副本/单体目标

大秘境/群体伤害

地下堡

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者团本天赋

当前 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者是单体目标下最强的选择，拥有出色的2分钟爆发，同时具备灵活的顺劈工具应对团本战斗。随着第二赛季新套装的加入，它稳稳成为
**推荐选择**.

**注意** ——在 <em>纯单体目标战斗中</em> **掌握**
获得新的4件套后，使用[[spell:455088]]代替[[spell:455110]]。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者大秘境天赋

在AoE中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者在5-6个目标时提供稳定的伤害，并在[[spell:114051]]和[[spell:384352]]触发期间拥有爆发性伤害。虽然它有一些随机性因素，比如[[spell:454009]]，但其数值调整使其在第二赛季地下城几乎所有相关战斗场景中都处于领先地位，使其成为 **推荐选择**:

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者地下堡天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者非常适合 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)，能够在关键时刻积攒伤害。它拥有极其强大的爆发力，但其不可预测性有时会带来问题。其大量的[[spell:187880]]生成可以为[[spell:384143]]层数提供支持，从而获得额外的免费治疗，因此自保能力很强。

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司团本天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司在第二赛季中略有落后，主要是因为新4件套带来的额外GCD压力。虽然它仍然表现不错，尤其是在围绕1分钟爆发构建的战斗中，但目前被另一种选择所掩盖。

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司大秘境天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司仍然是一个非常好的1分钟爆发流派，能够在较高目标数量下造成大量伤害。不幸的是，其数值调整使其在第二赛季中受限，与同类相比遭到了更多削弱，而在地下城环境中缺乏足够的手段来保持竞争力：

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司地下堡天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司非常适合地下堡，凭借其短冷却时间，能够在需要时释放巨大的AOE爆发。它在不同目标数量之间的转换也没有任何困难，在每个地下堡中都能流畅发挥。因此，它是 **推荐选择**.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzMjllZgZmNWmZmZYYMDAwMMmZMzEYmBDGDA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogBbs88YB1uOjUU-COXWDZEBQVgYdFARcMNjPiKKJLblC9A-AAAA-Aego0QsgBTgwwC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZMWYGAgZYMzwIwMDGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFoAzzrsrzYBK1KROB-CDEOXZBFNRVWYdgjAMQShLPeKKbT4EB-AAAA-OUaIawIMsEAEpA-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwGMDDNYBgZZGzYssMDMzsNWMzMzYswMAAzwYmhZCMzgBjB"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogxzrsrzYBaalIq-CDEOXZBFNRVWYdgjAMQShLPeKKbF5SA-AAAA-OUaIawIMsEAEpI-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzMzMzMzMzMzMzYGAAAAAAAAAsAbwMW0YbAMDYDgZZGzMjllZgZmNWmZmZYYMDAgBYMzEzMAwYA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogBbsEdB1uuzUjD-CDEHOXZBGGINRVWdAMQSaiLPUKKJFT-AAAA-Jgko0AIowgxRmF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzMjZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZAbAMLzYGjlFjNmZ2GLz8AzMDWGzAAAMGzImZAGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRrFoAzzbsEdB1uuTjKROB-CDEHOXZBGGNWjAMQRVgPSaiKKLUJFT-AAAA-Jgko0AIowgxRmF-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMjZmZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZAbAMLzYGjllZgZGjFzMzMGLMDAAwYMzEzMADGDA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFogpqrzzTU5pxC0U-CDEHOXZBGGINRWAMQgPSaiKKLUJVjT-AAAA-Jgko0AIowgxRmF-
```

:::

### 天赋方案 0-0

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者高度专注于[[spell:187880]]的生成，因此会选择所有循环类天赋以最大化[[spell:454009]]的触发。天赋树中的选择有限，因此路线规划以[[spell:17364]]作为主要的近战产生手段。有了新套装，[[spell:470057]]和[[spell:333974]]都是重要的选择，以及顶点天赋[[spell:1262713]]的全部四点，以充分利用4件套效果。最后，它同时选择了[[spell:1262635]]叶节点来重置漩涡武器，以及[[spell:114051]]来触发[[spell:1264688]]。其他注意事项包括：

- 在第二赛季中，套装带来的额外GCD需求意味着[[spell:455110]]会导致额外的浪费，因此[[spell:455088]]是一个值得在 <em>纯单体目标</em>中替换的选择。这在顺劈场景中有所变化，因为天赋树更容易出现资源枯竭的情况。
- 在中间区域，[[spell:334046]]是 <em>技术上</em> 在单体目标中最强，但由于[[spell:289874]]，[[spell:334308]]几乎同样出色。因此，我们推荐后者，因为它具有更优秀的顺劈潜力。
- 对于团队副本，大多数功能性天赋选择都是不必要的，但在剧毒深渊中，拥有[[spell:192058]]在某些战斗中很有用。此外，由于首领场地很大，[[spell:192077]]、[[spell:462820]]、[[spell:382201]]和[[spell:108287]]对于提供额外的团队移动能力都极具价值。

### 天赋方案 0-1

在AOE中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者的目标是尽可能生成并消耗大量[[spell:187880]]以触发[[spell:454009]]。与单体目标构筑相比，唯一的主要变化是[[spell:334308]]，它从可选变为必点。第2赛季同样锁定了用于2件套效果的[[spell:333974]]，以及巅峰天赋[[spell:1262713]]的全部四点，这是由于它与4件套的协同作用。一些额外说明如下：

- 在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 在风暴使者英雄天赋中，[[spell:455110]]是无可争议的首选，有助于更快地循环使用[[spell:454009]]。其他选择节点取决于个人偏好，取决于你的功能性和防御需求。
- 虽然之前[[spell:1218047]]作为中程冷却技能很受欢迎，但新的4件套效果巩固了[[spell:1262713]]的四点投入，因此天赋树底部没有其他选择。
- 职业天赋树允许完全投入[[spell:192058]]，使其冷却时间最多减少25秒，在大秘境中提供一定程度的额外控制潜力。其他功能性天赋如[[spell:51886]]、[[spell:370]]和[[spell:383013]]可以根据每个副本的情况进行搭配。

### 天赋方案 1-0

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司非常注重[[spell:60103]]，投入任何倾向于此的天赋以最大化[[spell:201900]]和[[spell:445035]]。在底部，它需要[[spell:197214]]来激活最后一个[[spell:445024]]精魄。它还避免了[[spell:114051]]，以便保持[[spell:384352]]和[[spell:444995]]之间的同步。最后，它投入了[[spell:1262713]]的全部四点，以巩固[[spell:187874]]作为输出循环的核心部分。一些额外说明如下：

- 在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 在图腾祭司英雄天赋中，你应该 <em>总是</em> 选择[[spell:455590]]，因为[[spell:445035]]。由于没有点出[[spell:114051]]，所以始终使用[[spell:445029]]，而[[spell:445033]]是最灵活的最终选择节点——在提供更好AOE伤害的同时带来相同的单体目标强度。
- 虽然新的2件套效果提到了[[spell:333974]]， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司并不
  <em>需要</em> 它来激活效果，因此避免在其上投入一点。相反，它转而选择[[spell:1251026]]，以利用第2赛季装备上大量的暴击属性。
- 虽然严格来说不是为了性能，但职业天赋树上的图腾相关天赋使管理[[spell:444995]]变得更加容易。特别是[[spell:382201]]提供额外的范围，以及[[spell:108287]]在需要时更容易重新定位。

### 天赋方案 1-1

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司的AOE构筑几乎完全相同，唯一的变化是切换到[[spell:334308]]以进一步提升[[spell:188443]]和[[spell:289874]]的伤害。它仍然通过[[spell:197214]]到[[spell:1218047]]来获得其30秒的爆发期，并在[[spell:1262713]]巅峰天赋中投入全部四点，以增强[[spell:187874]]施放的威力。一些额外说明如下：

- 在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 在图腾祭司英雄天赋中，你应该 <em>总是</em> 选择[[spell:455590]]，因为[[spell:445035]]。在中间的选择节点，由于不使用[[spell:114051]]，所以选择[[spell:445029]]，而[[spell:445033]]在最终节点上提供最大的AOE潜力。
- 第2赛季锁定了天赋树中间的[[spell:333974]]，因为新的2件套效果在触发时提供高优先级伤害。[[spell:334046]]和[[spell:1251026]]可以根据个人偏好选择。
- 职业天赋树允许完全投入[[spell:192058]]，使其冷却时间最多减少30秒，在大秘境中提供一定程度的额外控制潜力。其他功能性天赋如[[spell:51886]]和[[spell:383013]]可以根据每个副本的情况进行搭配。

以上列出的构筑是基于强度和流行度的推荐，涵盖了终局PvE的每个内容领域。每个构筑都有自己需要执行的输出循环、需要掌握的独特方面，以及各自的技巧来在不同的战斗中协助你的团队。

1.

### 全知典籍

在 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)中引入，万灵卷册是一个玩家强度系统，通过一系列任务解锁少量的性能增强效果。这些加成与任何装备无关，并且始终在你的角色身上生效。有些提供额外伤害，而另一些则提供一些治疗和额外的防御手段。

下面，我们列出了在完成典籍任务链时解锁的五个符文的推荐：

- **符文1 -** [[spell:1279599]]
- **符文2 -** [[spell:1279603]]
- **符文3 -** [[spell:1287555]]
- **符文4 -** [[spell:1279610]]
- **符文5 -** [[spell:1279614]]

值得注意的是，这些效果之间的差异非常小。然而，第四个属性增强符文会根据你的装备而变化，因此它是平衡属性的好地方，如果你缺少任何属性的话。急速、精通和暴击大致相当，三者中最好的选择通常是当前装备配置中你拥有最少的那个属性。

1.

### 巅峰天赋： ![Storm Unleashed Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_shaman_stormunleashed.jpg>) 风暴释放

增强的巅峰天赋[[spell:1262713]]专注于[[spell:187874]]，同时也为核心技能提供额外加成。这些天赋极大地推动其成为两个英雄天赋的核心输出支柱。以下构筑投入了全部四点： <em>大多数</em> 提供良好的单体目标和AOE收益：

- [[spell:1262713]] - 每消耗一层[[spell:187880]]，有2%的几率使你的下一次[[spell:187874]]施放无视其冷却时间。此外，毁灭闪电的武器强化增益效果现在可以叠加并重叠。
- [[spell:1262761]] - 每点使[[spell:187880]]消耗技能造成的伤害提高7.5%，武器附魔伤害提高10%。
- [[spell:1252373]] - 使[[spell:187874]]同时产生一个静态区域，在2秒内造成相当于初始施放伤害100%的额外伤害。此外，武器强化增益效果每层提供15%的自动攻击速度加成。

即使只是第一点，也巩固了[[spell:187874]]作为所有目标数量下输出循环的核心部分，增加了一个需要应对的额外触发效果。由于它允许效果重叠，这意味着通过刷新很难浪费触发。唯一真正的失误方式是完全不施放毁灭闪电。后续的点数主要是被动提升——但由于我们使用得非常频繁，每一点都有很大的价值。

1.

### 增强萨满祭司英雄天赋

增强有两个截然不同的英雄天赋选择，如上文各节所述，你的选择会极大改变你的配装选择和输出循环。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者

该天赋树可让你获得[[spell:454009]]，这是一个强大的触发效果，能强化你的下一个[[spell:188196]]。在消耗[[spell:187880]]时可能随机触发，将其转化为强大的范围爆发工具。此外，该英雄天赋还提供以下效果：

- [[spell:1264688]]使[[spell:114051]]在激活时触发[[spell:454009]]，使其成为首选的冷却技能。
- [[spell:455123]]会对你的消耗技能命中的目标施加减益效果，将一部分造成的伤害转化为额外伤害。这使其在激活期间能对关键目标造成额外的集火伤害。

这使得 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者围绕我们的资源玩法展开，奖励良好的资源管理和循环，带来爆发性的伤害输出。它能利用多种工具进行顺劈而不损失单体伤害，但可能容易受到糟糕的随机性影响。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司

相反， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司通过[[spell:201900]]效果重点强化[[spell:60103]]，同时还能获得一个新的冷却技能[[spell:444995]]。该技能激活时会脉冲范围伤害，并与多种不同技能联动产生额外效果。

- [[spell:445035]]使[[spell:60103]]在[[spell:201900]]激活时也能触发[[spell:197214]]，并通过[[spell:455590]]使你的[[spell:444995]]产生脉冲效果。
- [[spell:445025]]还会使你的[[spell:444995]]在你施放任何[[spell:187880]]消耗技能时造成额外伤害，放大其在持续时间内造成的后续伤害。

这为增强的技能组合增加了一个与[[spell:384352]]对齐的额外冷却技能。当与天赋树上的其他选项搭配使用时，它提供了一些强大的选项来应对30秒和1分钟的爆发时间轴，同时在不牺牲顺劈或范围伤害的情况下造成强力的集火伤害。

1.

### PvP天赋（战争模式）

「战争模式」是一个可选功能，启用后可开启开放世界的PvP遭遇，并在激活时提供一些好处：

- 在开放世界中获得使用PvP天赋的权限。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可以获得装备奖励。

考虑到战争模式在练级和PvE内容中的好处，它是最大化你练级速度和奖励潜力的一种可选方式。然而，你将使自己暴露在开放世界的PvP中，因此要注意可能干扰你的敌对玩家；这是一个你需要自己决定是否要承担的风险。

通常，这些选择是为了优化你更快击杀敌人的能力，提高你在内容推进中的速度。

- [[spell:193876]]允许更自由地使用[[spell:2825]]/[[spell:32182]]，而不必担心10分钟的冷却锁定。非常适合单人和双人内容。
- [[spell:409293]]提供2分钟冷却的紧急逃生手段，当你陷入麻烦时可以使用，并且在从地下冒出时造成大量物理伤害。
- [[spell:204331]]复制你受到的伤害并反弹给造成伤害的敌人，让你可以对危险的敌人以牙还牙！

[[spell:355580]]、[[spell:356736]]、[[spell:206642]]和[[spell:204336]]在PvE中的用途非常有限，更侧重于战斗中的控制。虽然这些技能在某些情况下非常强大，但它们更适合PvP战斗，因此不推荐用于高效击杀敌人。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月24日：** 调整了手册内容，提到第四个符文用于弥补不足的副属性。
- **2026年8月19日：** 由于第2赛季团队副本中有大量顺劈场景，将单体导入代码切换为超载。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已根据12.0.7补丁使用全知卷册推荐进行更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月7日：** 对风暴使者团队副本构建进行了小幅更新，以适应更高的顺劈需求。
- **2026年3月16日：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月2日：** 对 图腾祭司 构建进行了小幅调整。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 将大秘境和AOE推荐更改为 图腾祭司。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 针对11.1.5版本进行了审查，调整了推荐以突出两个天赋树的接近程度。
- **2025年3月16日：** 更新为更具通用性的 图腾祭司 大秘境天赋配置。将所有推荐更改为 图腾祭司。
- **2025年3月4日：** 调整了所有天赋构建，以弃用激涌之灵。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 针对11.0.7版本进行了更新，在关键构建上添加了推荐标记。
- **2024年11月5日：** 基于发布后更多经过测试的11.0.5版本构建，对推荐配装进行了重大更改。
- **2024年10月21日：** 针对11.0.5版本进行了更新，发布后将需要进一步更新。
- **2024年9月23日：** 已根据最新的热修复和风暴天赋切换进行更新。
- **2024年9月9日：** 针对 元素 爆裂和风暴之怒的在线修正以及新的风暴配装进行了更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已更新至10.2.7。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 针对10.2.5版本和赛季中期更新进行了审查和润色。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7补丁进行审阅，进行了小幅结构调整并加入了元素汇聚。
- **2023年7月10日：** 已针对10.1.5补丁进行审阅，并在推荐中更新了风暴顺劈。
- **2023年5月9日：** 已更新以在元素汇聚单体输出中加入原始浪潮。
- **2023年5月1日：** 已全面更新至10.1补丁并修订了新流派。物理流派已转换为风暴流派。
- **2023年3月20日：** 已根据10.0.7补丁审查并更新。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何在单体和多目标情况下优化你的增强萨满祭司的输出循环。我们还提供了关于冷却技能、触发效果等方面的进阶内容，以最大化你的DPS。我们的所有内容均已针对魔兽世界12.1.5版本更新。

1.

### 增强萨满祭司玩法与循环指南

欢迎来到我们的增强萨满祭司循环页面！在本页中，你将找到在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

由于增强有两个玩法和专精方向截然不同的英雄天赋，以下是进入至暗之夜时使用哪个天赋的快速入门建议：

- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 -** 每2分钟提供强大的爆发，在5-6个目标时特别强大，是第二赛季的首选。
  **推荐用于所有内容**.
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 -** 提供扎实的单体目标和大规模AOE能力，以1分钟爆发为时间轴。在第二赛季中略弱，在大多数内容中落后。

在第二赛季中，增强已牢牢占据 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者在终局内容天梯的顶端，我们建议始终使用它。虽然最近已做出一些努力来缩小 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司的差距，但它远不如 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者灵活，后者每两分钟提供充足的顺劈伤害和强力爆发。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者

团队副本 / 单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

大秘境 / AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司

团队副本 / 单体目标

大秘境 / AoE

主动天赋

被动天赋

[[spell:114051]]

[[spell:378270]]

[[spell:197214]]

[[spell:1218047]]

[[item:271886]]

[[item:241288]]

[[spell:333974]]

[[spell:334046]]

[[spell:382042]]

### 单体目标

1.1.

#### 增强萨满祭司单体输出循环

增强萨满祭司围绕优先级列表系统运作，循环使用不同技能使其进入冷却，并生成[[spell:187880]]层数。然后将层数消耗在强大的法术上，通过[[spell:1250364]]获得冷却缩减。建立肌肉记忆并掌握节奏可能需要一些时间，但通过仔细规划资源可以获得非常丰厚的回报。

---

1. **适用条件：图腾祭司（启用）。** 如果[[spell:188389]]未激活，则施放[[spell:470057]]
2. **适用条件：图腾祭司（启用）。** 施放 [[spell:444995]]
3. **适用条件：图腾祭司（启用）；Sundering（启用）。**
   施放 [[spell:197214]] - <em>点击查看说明</em>
   
   
   
   
   - 目标是让每第二次施放与 [[spell:444995]] 同步。
4. **适用条件：图腾祭司（启用）。** 在 [[spell:201900]] 或 [[spell:453405]] 激活时施放 [[spell:60103]]
5. **适用条件：图腾祭司（启用）。**
   施放 [[spell:470057]] - <em>点击查看说明</em>
   
   
   
   
   - 拥有2件套效果时，应尽可能保持该技能处于冷却状态
6. **适用条件：图腾祭司（启用）；升腾（未启用）；根深蒂固的元素（未启用）。** 施放 [[spell:384352]]
7. **适用条件：图腾祭司（启用）；始源风暴（启用）。**  施放 [[spell:1218047]]，需要 **10** 层 [[spell:187880]] - <em>点击查看说明</em>
   
   
   
   
   - 如果增益即将过期，可以在 **5+** 层时施放。
8. **适用条件：风暴使者（启用）；始源风暴（启用）。** 施放 [[spell:1218047]]，需要 **10 [[spell:187880]]** 层
9. **适用条件：风暴使者（启用）；升腾（启用）；涌动元素（启用）；碎裂（启用）。**
   施放 [[spell:197214]] - <em>点击查看说明</em>
   
   
   
   
   - 尽量将其与 [[spell:114051]] 对齐
10. **适用条件：风暴使者（启用）。**
    施放 [[spell:470057]] - <em>点击查看说明</em>
    
    
    
    
    - 拥有2件套效果时，应尽可能保持该技能处于冷却状态
11. **适用条件：风暴使者（启用）；涌动元素（启用）；升腾（未启用）。** 施放 [[spell:197214]]
12. 施放 [[spell:187874]]
13. **适用条件：升腾（启用）。** 施放 [[spell:114051]]
14. **适用条件：升腾（启用）。** 在 [[spell:114051]] 期间施放 [[spell:115356]]
15. **适用条件：根深蒂固的元素（启用）。** 在 [[spell:114051]] 期间施放 [[spell:115356]]
16. **适用条件：根深蒂固的元素（未启用）。** 在 [[spell:384352]] 期间施放 [[spell:17364]]
17. **适用条件：图腾祭司（启用）。**
    施放 [[spell:188196]]，需要 **10** 层 [[spell:187880]] - <em>点击查看说明</em>
    
    
    
    
    - 可以低至 **5+** 如果 [[spell:1250364]] 将重置 [[spell:60103]] 的冷却时间。
18. **适用条件：风暴使者（启用）。** 施放 [[spell:454009]] / [[spell:188196]]，需要 **10** 层 [[spell:187880]]
19. **适用条件：风暴使者（启用）。** 施放 [[spell:17364]]
20. **适用条件：风暴使者（启用）；碎裂（启用）；涌动元素（未启用）。** 施放 [[spell:197214]]
21. 施放 [[spell:60103]]
22. **适用条件：图腾祭司（启用）。** 施放 [[spell:17364]]
23. 施放 [[spell:188196]]，需要 **5+** 层 [[spell:187880]]

---

**适用条件：风暴使者（启用）。** 增强 的节奏有起有伏，你会慢慢习惯，因为 [[spell:187880]] 的生成与你的技能冷却之间有一种韵律感。[[spell:1250364]] 增加了来自消耗技能的动态冷却缩减，为资源管理提供了良好的反馈循环。每个英雄天赋树也有需要应对的关键触发效果，其中 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 需要处理 [[spell:454009]] 和 [[spell:1262635]] 的触发效果。

**适用条件：图腾祭司（启用）。** 增强 的节奏有起有伏，你会慢慢习惯，因为 [[spell:187880]] 的生成与你的技能冷却之间有一种韵律感。[[spell:1250364]] 是 至暗之夜 的新内容，它增加了来自消耗技能的动态冷却缩减，为资源管理提供了良好的反馈循环。每个英雄天赋树也有需要应对的关键触发效果，其中 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 大量依赖 [[spell:201900]]，并通过 [[spell:1260644]] 延长其持续时间。

1.2.

#### 单体输出循环说明与技巧

**适用条件：风暴使者（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者，根据你在上方工具中的选择：

- **适用条件：风暴使者（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 旨在循环使用 [[spell:187880]] 来获得 [[spell:454009]]。尽量在 **10** 层时消耗它。否则，施放 [[spell:188196]]，同样在10层时。
- **适用条件：风暴使者（启用）。** [[spell:470057]] 应该在冷却好时就施放，以利用新的2件套效果。同样，[[spell:187874]] 只要可用就应施放。[[spell:17364]] 是你的主要填充技能，[[spell:60103]] 是你最后生成手段。
- **适用条件：风暴使者（启用）；升腾（未启用）；根深蒂固的元素（未启用）。** 每当你施放 [[spell:384352]] 时，确保有1-2层 [[spell:17364]] 和 [[spell:187874]] 可用。用这些技能填充每一个GCD来触发 [[spell:384444]]，理想情况下获得足够的 [[spell:1250364]] 冷却缩减来连续施放它们。
- **适用条件：风暴使者（启用）；升腾（启用）。** 在 [[spell:114051]] 之前激活 [[spell:187874]]，并施放 [[spell:187874]] <em>每当它重置时</em>，用 [[spell:115356]] 填充其他所有GCD。在窗口期内，每当 [[spell:470057]] 可用时就施放。
- **适用条件：风暴使者（启用）；升腾（启用）。** 在 [[spell:384352]] 触发期间，尽可能多地施放 [[spell:187874]] / [[spell:17364]]。
- **适用条件：风暴使者（启用）；根深蒂固的元素（启用）。** 每当 [[spell:378270]] 触发时，如果可用则施放 [[spell:187874]]，否则每个GCD施放 [[spell:115356]]。[[spell:384352]] 持续时间稍长，所以记得持续施放 [[spell:17364]] 直到其过期。

**适用条件：图腾祭司（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司，根据你在上方工具中的选择：

- **适用条件：图腾祭司（启用）；升腾（未启用）；根深蒂固的元素（未启用）。** 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司，[[spell:444995]] 应该尽可能接近每分钟施放一次。[[spell:197214]] 应该先施放以触发 [[spell:382042]] 和大地之精，然后是 [[spell:60103]] 来启动 [[spell:201900]]。最后，使用 [[spell:384352]] 通过 [[spell:384444]] 触发效果来延长窗口期，每隔一个GCD穿插 [[spell:60103]]。
- **适用条件：图腾祭司（启用）；升腾（启用）。** 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司，[[spell:444995]] 应该尽可能接近每分钟施放一次。用 [[spell:60103]] 开始你的 [[spell:201900]] 窗口期，然后是 [[spell:197214]] 来触发大地之精。最后，施放 [[spell:114051]] 通过 [[spell:384444]] 来延长它，每隔一个GCD穿插 [[spell:60103]]。
- **适用条件：图腾祭司（启用）；根深蒂固的元素（启用）。** 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司，[[spell:444995]] 应该尽可能接近每分钟施放一次。用 [[spell:60103]] 开始你的 [[spell:201900]] 窗口期，然后是 [[spell:197214]] 来触发大地之精。最后，使用一个 [[spell:187880]] 消耗技能来触发 [[spell:453409]]。不幸的是，[[spell:378270]] 没有可靠的窗口期来通过 [[spell:1260644]] 持续延长。
- **适用条件：图腾祭司（启用）。** [[spell:60103]] 是你首选的打击技能，尽可能频繁施放。在 [[spell:201900]] 期间，这是每 <em>三</em> 个GCD。如果你随后使用 [[spell:187880]] 消耗技能，[[spell:1250364]] 使其每 <em>秒可用一次</em>.
- **适用条件：图腾祭司（启用）。** 在 [[spell:201900]] 之外，由于2件套效果，[[spell:470057]] 是你的最高优先级，其次是可用时的 [[spell:187874]]。[[spell:17364]] 是你的备选填充技能。
- **适用条件：图腾祭司（启用）。** [[spell:187880]] 消耗技能应在 **10** 层时使用，或用 [[spell:1250364]] 重置。

---

**适用条件：图腾祭司（启用）。**

:::details 常见问题：我应该“读条施放”漩涡武器消耗技能吗？
永远不要。“读条施放”是指在漩涡武器层数低于5时使用消耗技能

[[spell:187880]]

层时使用消耗技能（会产生施法时间）。这既无法利用伤害加成导致效率低下，还会重置攻击计时器，造成更多浪费。如果你经常这样做，这是导致性能损失的重要原因。

:::

:::details 常见问题：我应该将大地 元素 用作DPS冷却技能吗？
通常不需要。即使在整个一分钟内都保持满覆盖率，它的伤害也远低于你最弱的技能。将其用作生存工具以获得生命值加成要好得多，或者在不使用时留作应急手段

[[spell:1279819]]

.

:::

:::details 常见问题：我应该在意漩涡武器的浪费吗？
是的。在游玩

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司

时，你的

[[spell:187880]]

消耗技能是通过

[[spell:201900]]

延长你的窗口期的关键。

[[spell:1260644]]

。你应该始终尽量在

[[spell:60103]]

施放之间尽可能多地消耗资源。这对于在此之外通过

[[spell:60103]]

访问

[[spell:1250364]]

也很有用，如果消耗资源能让你在下一个GCD内施放它的话。

:::

**适用条件：风暴使者（启用）。**

:::details 常见问题：我应该“读条施放”漩涡武器消耗技能吗？
永远不要。“读条施放”是指在漩涡武器层数低于5时使用消耗技能

[[spell:187880]]

层时使用消耗技能（会产生施法时间）。这既无法利用伤害加成导致效率低下，还会重置攻击计时器，造成更多浪费。如果你经常这样做，这是导致性能损失的重要原因。

:::

:::details 常见问题：我应该将大地 元素 用作DPS冷却技能吗？
通常不需要。即使在整个一分钟内都保持满覆盖率，它的伤害也远低于你最弱的技能。将其用作生存工具以获得生命值加成要好得多，或者在不使用时留作应急手段

[[spell:1279819]]

.

:::

:::details 常见问题：我应该在意漩涡武器的浪费吗？
是的。作为

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者

，高效循环以达到

[[spell:454009]]

非常重要，因此你应尽量避免叠层超过10层。同时，充分利用

[[spell:1250364]]

以避免停机时间。然而，由于期间资源的大量涌入，一些浪费是不可避免的

[[spell:384411]]

期间的资源洪流以及

[[spell:470057]]

.

:::

### 群体伤害

1.3.

#### 增强萨满祭司AoE循环

增强的AoE输出在至暗之夜中要简单得多，变动的环节更少。但它仍然会主动使用几个技能，并且每个英雄天赋在多目标战斗中都有自己的特色。通过[[spell:187874]]和[[spell:289874]]，它遵循着与单体输出类似的目标。

---

1. **适用条件：图腾祭司（启用）。** 如果[[spell:188389]]当前未激活，则施放[[spell:470057]]
2. **适用条件：图腾祭司（启用）。** 施放 [[spell:444995]]
3. **适用条件：图腾祭司（启用）；Sundering（启用）。** 施放 [[spell:197214]]
4. **适用条件：风暴使者（启用）。**
   施放 [[spell:470057]] - <em>点击查看说明</em>
   
   
   
   
   - 拥有2件套效果时，应尽可能保持该技能处于冷却状态
5. **适用条件：Sundering（启用）；风暴使者（启用）；Surging Elements（启用）。** 施放 [[spell:197214]]
6. **适用条件：升腾（启用）。** 施放 [[spell:114051]]
7. **适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。** 施放 [[spell:384352]]
8. **适用条件：图腾祭司（启用）。** 如果[[spell:201900]]或[[spell:453405]]处于激活状态，则施放[[spell:60103]]
9. **适用条件：图腾祭司（启用）。**
   施放 [[spell:470057]] - <em>点击查看说明</em>
   
   
   
   
   - 拥有2件套效果时，应尽可能保持该技能处于冷却状态
10. **适用条件：Primordial Storm（启用）。** 施放 [[spell:1218047]]，需要 **10** 层 [[spell:187880]]
11. 施放 [[spell:187874]]
12. **适用条件：升腾（启用）。** 在 [[spell:114051]] 期间施放 [[spell:115356]]
13. **适用条件：根深蒂固的元素（启用）。** 在 [[spell:114051]] 期间施放 [[spell:115356]]
14. **适用条件：根深蒂固的元素（未启用）。** 在 [[spell:384352]] 期间施放 [[spell:17364]]
15. **适用条件：风暴使者（启用）。** 在可用时施放[[spell:454009]]，配合 **10** 层 [[spell:187880]]
16. **适用条件：风暴使者（启用）。** 否则施放[[spell:188443]]，配合 **9+** 层 [[spell:187880]]
17. **适用条件：图腾祭司（启用）。** 施放[[spell:188443]]，配合 **10** 层 [[spell:187880]]
18. **适用条件：风暴使者（启用）。** 施放 [[spell:17364]]
19. **适用条件：图腾祭司（启用）。** 施放 [[spell:60103]]
20. **适用条件：风暴使者（启用）；Sundering（启用）。** 施放 [[spell:197214]]
21. **适用条件：风暴使者（启用）。** 施放 [[spell:60103]]
22. **适用条件：图腾祭司（启用）。** 施放 [[spell:17364]]
23. 施放[[spell:188443]]，配合 **5+** 层 [[spell:187880]]

---

**适用条件：图腾祭司（启用）。** 增强的AoE优先级与单体非常相似，在至暗之夜中大多数技能都带有内置的顺劈效果。[[spell:187874]]配合[[spell:1262713]]时，其直接伤害变得更加重要，而它和[[spell:289874]]都允许[[spell:17364]]和[[spell:60103]]无缝切换到多目标输出。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司仍然非常侧重于其[[spell:444995]]爆发，并优先延长[[spell:201900]]的持续时间，以尽可能地利用[[spell:445035]]。

**适用条件：风暴使者（启用）。** 增强的AoE优先级与单体非常相似，在至暗之夜中大多数技能都带有内置的顺劈效果。[[spell:187874]]配合[[spell:1262713]]时，其直接伤害变得更加重要，而它和[[spell:289874]]都允许[[spell:17364]]和[[spell:60103]]无缝切换到多目标输出。与单体相比更是如此， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者非常需要高效地循环[[spell:187880]]，以触发爆炸性的[[spell:454009]]。

1.4.

#### AoE循环说明与提示

**适用条件：风暴使者（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者，根据你在上方工具中的选择：

- **适用条件：风暴使者（启用）；升腾（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者循环[[spell:187880]] <em>积极地</em>。这将优先用于 [[spell:454009]]（目标是在拥有 **10** 层），否则使用[[spell:188443]]配合 **9+** 层。在[[spell:467263]]或[[spell:384352]]触发期间，使用[[spell:187874]] / [[spell:115356]]配合[[spell:384444]]来消耗它们。
- **适用条件：风暴使者（启用）；根深蒂固的元素（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者循环[[spell:187880]] <em>积极地</em>。这将优先用于 [[spell:454009]]（目标是在拥有 **10** 层），否则使用[[spell:188443]]配合 **9+** 层。在 [[spell:467263]] 触发期间，使用 [[spell:187874]] / [[spell:115356]] 配合 [[spell:384444]] 消耗。
- **适用条件：风暴使者（启用）；Deeply Rooted Elements（未启用）；升腾（未启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者循环[[spell:187880]] <em>积极地</em>。这将优先用于 [[spell:454009]]（目标是在拥有 **10** 层），否则使用[[spell:188443]]配合 **9+** 层。在 [[spell:384352]] 期间，使用 [[spell:187874]] / [[spell:115356]] 配合 [[spell:384444]] 消耗。
- **适用条件：风暴使者（启用）。** [[spell:470057]] 应该卡冷却使用，以充分利用新的两件套效果。[[spell:187874]] 也应在可用时立即使用，以响应 [[spell:1262713]] 的触发。之后，[[spell:17364]] 是你的主要攻击手段，用它通过 [[spell:289874]] 来施加 [[spell:210689]]。[[spell:60103]] 是你最后的填充技能。

**适用条件：图腾祭司（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司，根据你在上方工具中的选择：

- **适用条件：图腾祭司（启用）；升腾（未启用）；根深蒂固的元素（未启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 应每分钟施放一次 [[spell:444995]]，然后接上 [[spell:197214]] 来触发 [[spell:453406]]。接着使用 [[spell:384352]]，然后立即开始 [[spell:201900]]，利用 [[spell:1260874]] 的双重施放进行爆发。
- **适用条件：图腾祭司（启用）；升腾（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 应每分钟施放一次 [[spell:444995]]，然后接上 [[spell:197214]] 来触发 [[spell:453406]]。接着使用 [[spell:114051]]，然后立即开始 [[spell:201900]]，利用 [[spell:1260874]] 的双重施放进行爆发。
- **适用条件：图腾祭司（启用）；根深蒂固的元素（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 应每分钟施放一次 [[spell:444995]]，然后接上 [[spell:197214]] 来触发 [[spell:453406]]。随后立即开始你的 [[spell:201900]] 窗口，因为 [[spell:378270]] 没有可主动同步的冷却时间。
- **适用条件：图腾祭司（启用）。** 在 [[spell:201900]] 期间卡冷却使用 [[spell:60103]] 来触发 [[spell:445035]]。卡冷却使用 [[spell:470057]] 来激活你的两件套效果，并在 [[spell:187874]] 可用时使用。[[spell:17364]] 是你的备用能量产生技能。
- **适用条件：图腾祭司（启用）。** 使用 [[spell:187880]] 消耗技能来激活 [[spell:1260644]] 和 [[spell:1250364]]。消耗以延长 [[spell:201900]]，或在 [[spell:60103]] 激活期间降低其冷却时间。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 在 **10** 层。

---

:::details 常见问题：在多少目标时切换到闪电链？
无论你使用哪个英雄天赋，通常都应该切换到

[[spell:188443]]

一旦出现第二个目标时。

:::

:::details 常见问题：我应该“读条施放”漩涡武器消耗技能吗？
永远不要。“读条施放”是指在漩涡武器层数低于5时使用消耗技能

[[spell:187880]]

层（会带来施法时间）。这既因为没有利用伤害加成而降低了效率，又会重置挥击计时器，造成更多浪费。如果你经常这样做，这是导致性能损失的一大原因。

:::

:::details 常见问题：我应该将大地 元素 用作DPS冷却技能吗？
通常不需要。即使在整个一分钟内都保持满覆盖率，它的伤害也远低于你最弱的技能。将其用作生存工具以获得生命值加成要好得多，或者在不使用时留作应急手段

[[spell:1279819]]

.

:::

### 单体起手

1.5.

#### 增强 萨满祭司单体起手

**适用条件：图腾祭司（启用）。** 在至暗之夜中，增强的起手相当快，很早就进入冷却技能的使用。配合 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 选择图腾祭司后，有一套更精确的循环来最大化利用你的第一个[[spell:444995]]。

**适用条件：风暴使者（启用）。** 在至暗之夜中，增强的起手相当快，很早就进入冷却技能的使用。配合 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 选择风暴使者后，你需要先开启所有增益效果，然后立即开始循环施放[[spell:187880]]。

![](<https://static.icy-veins.com/images/common/button-icons/important.png>) 药水可以在上方可展开的“当前天赋”标签页中更换

---

**适用条件：图腾祭司（启用）。**

[[spell:187874]]

1s

**适用条件：鲁莽药水（启用）。**

[[item:241288]]

战斗前

拉怪

**适用条件：鲁莽药水（启用）。**

[[spell:470057]]

**适用条件：Liquid Luster（启用）。**

**适用条件：Liquid Luster（启用）。**

[[spell:470057]]

**适用条件：Liquid Luster（启用）。**

[[item:271886]]

[[spell:444995]]

[[item:270175]]

**适用条件：碎地猛击（启用）。**

[[spell:197214]]

[[spell:60103]]

**适用条件：碎地猛击（启用）；原始风暴（启用）。**

**适用条件：碎地猛击（启用）；原始风暴（启用）。**

[[spell:1218047]]

**适用条件：碎地猛击（启用）；原始风暴（启用）。**

[[spell:384352]]

**适用条件：碎地猛击（未启用）。**

[[spell:187874]]

**适用条件：碎地猛击（未启用）。**

[[spell:384352]]

[[spell:60103]]

[[spell:187874]]

**适用条件：风暴使者（启用）。**

**适用条件：Liquid Luster（启用）。**

[[item:271886]]

12s

[[spell:187874]]

1s

**适用条件：鲁莽药水（启用）。**

[[item:241288]]

战斗前

拉怪

[[spell:470057]]

**适用条件：碎地猛击（启用）；涌动元素（启用）。**

[[spell:197214]]

**适用条件：根深蒂固的元素（启用）。**

[[spell:187874]]

**适用条件：根深蒂固的元素（启用）。**

[[spell:17364]]

**适用条件：根深蒂固的元素（未启用）。**

[[spell:17364]]

**适用条件：升腾（启用）。**

**适用条件：升腾（启用）。**

[[spell:114051]]

**适用条件：升腾（启用）。**

[[item:270175]]

**适用条件：原始风暴（启用）；碎地猛击（启用）。**

[[spell:1218047]]

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

[[spell:1218047]]

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

[[spell:384352]]

**适用条件：升腾（启用）。**

**适用条件：升腾（启用）。**

[[spell:115356]]

[[spell:187874]]

**适用条件：升腾（启用）。**

[[spell:470057]]

---

1. **适用条件：Liquid Luster（启用）；风暴使者（启用）。** 开怪前12秒预用药水 [[item:271886]]
   
   
   
   
   - 这使它能在你的起手 [[spell:467263]] 之前开始叠加
2. 预读 [[spell:187874]]
   
   
   
   
   - 避免提前命中任何目标！
3. **适用条件：鲁莽药水（启用）。** 预用药水 [[item:241288]]
   
   
   
   
   - 预用药水可以避免属性触发将其从精通或暴击上转移
4. **适用条件：图腾祭司（未启用）。** 在进入近战范围时施放 [[spell:470057]]
5. **适用条件：图腾祭司（启用）；鲁莽药水（启用）。** 在进入近战范围时施放 [[spell:470057]]
6. **适用条件：Liquid Luster（启用）；图腾祭司（启用）。** 在进入近战范围时施放 [[spell:470057]]
   
   
   
   
   - 同时使用 [[item:271886]]
7. **适用条件：风暴使者（启用）。** 施放一次 [[spell:17364]] 以获得 [[spell:187880]]
8. **适用条件：图腾祭司（启用）。** 施放 [[spell:444995]]
   
   
   
   
   - 使用主动饰品，例如[[item:270175]]
   - 使用任何种族增益
9. **适用条件：图腾祭司（启用）；Sundering（启用）。** 施放 [[spell:197214]]
10. **适用条件：图腾祭司（启用）。** 施放 [[spell:60103]] 来触发 [[spell:201900]]
11. **适用条件：图腾祭司（启用）；始源风暴（启用）。** 施放 [[spell:384352]] 并立即 [[spell:1218047]]
12. **适用条件：图腾祭司（启用）；原始风暴（未启用）。** 施放 [[spell:384352]] 接上 [[spell:187874]]
13. **适用条件：图腾祭司（启用）。** 施放 [[spell:60103]]
14. **适用条件：图腾祭司（启用）；始源风暴（启用）。** 施放 [[spell:187874]]
15. **适用条件：风暴使者（启用）；碎地猛击（启用）；涌动元素（启用）。** 施放 [[spell:197214]] 来触发 [[spell:382042]]
16. **适用条件：风暴使者（启用）；Lashing Flames（启用）。** 施放 [[spell:60103]] 来施加 [[spell:334046]]
17. **适用条件：风暴使者（启用）；升腾（启用）。** 施放 [[spell:114051]]
    
    
    
    
    - 使用主动饰品，例如[[item:270175]]
    - 使用任何种族增益
18. **适用条件：风暴使者（启用）；升腾（未启用）；根深蒂固的元素（未启用）。** 施放 [[spell:384352]]
    
    
    
    
    - 使用主动饰品，例如[[item:270175]]
    - 使用任何种族增益
19. **适用条件：风暴使者（启用）；升腾（启用）。** 在可用时施放 [[spell:187874]]
20. **适用条件：风暴使者（启用）；升腾（启用）。** 否则在每一个可用的GCD都施放 [[spell:115356]]
21. **适用条件：风暴使者（启用）；升腾（启用）。** 冷却一结束就施放 [[spell:470057]]
22. **适用条件：风暴使者（启用）；始源风暴（启用）。** 施放 [[spell:1218047]]，需要 **10** 在它过期前使用 [[spell:187880]]
23. 继续按照正常的技能优先级。

---

**适用条件：风暴使者（启用）。** 值得庆幸的是，至暗之夜的起手比之前的版本要简单得多，尤其是在使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者。你的目标是在进入[[spell:114051]]之前先让所有低价值增益效果启动，这样你就能专注于尽可能多地触发[[spell:384444]]。

**适用条件：图腾祭司（启用）。** 值得庆幸的是，至暗之夜的起手比以前对 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司，不过仍然需要注重正确安排你的第一个[[spell:444995]]的释放顺序。主要目标是有效地消耗掉你所有的[[spell:445024]]微粒，并开始通过[[spell:1260644]]来延长[[spell:201900]]。

- **适用条件：鲁莽药水（启用）。** 使用 [[item:241288]] 时，你 <em>需要</em> 以确保它根据你当前的装备提供暴击或精通。
- **适用条件：Liquid Luster（启用）。** [[item:271886]] 在开怪前12秒使用，以便在 [[spell:114051]] 之前叠加。

### AoE起手

1.6.

#### 增强萨满祭司 AoE起手

**适用条件：风暴使者（启用）。** 与单体战斗非常相似， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者起手的目标是尽快将你的增益效果铺好，这样你就可以开始循环释放[[spell:187880]]。

**适用条件：图腾祭司（启用）。** 在AoE中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司起手与之类似，但它的技能顺序略有不同，目的是从你的[[spell:445024]]微粒中压榨出尽可能多的伤害。

![](<https://static.icy-veins.com/images/common/button-icons/important.png>) 药水可以在上方可展开的“当前天赋”标签页中更换

---

**适用条件：图腾祭司（启用）。**

**适用条件：鲁莽药水（启用）。**

[[item:241288]]

战斗前

拉怪

**适用条件：鲁莽药水（启用）。**

[[spell:470057]]

**适用条件：Liquid Luster（启用）。**

**适用条件：Liquid Luster（启用）。**

[[spell:470057]]

**适用条件：Liquid Luster（启用）。**

[[item:271886]]

[[spell:444995]]

[[item:270175]]

**适用条件：碎地猛击（启用）。**

[[spell:197214]]

[[spell:187874]]

[[spell:384352]]

[[spell:60103]]

**适用条件：Primordial Storm（启用）。**

[[spell:1218047]]

**适用条件：Primordial Storm（启用）。**

[[spell:60103]]

**适用条件：风暴使者（启用）。**

**适用条件：鲁莽药水（启用）。**

[[spell:187874]]

1s

**适用条件：鲁莽药水（启用）。**

[[item:241288]]

战斗前

拉怪

**适用条件：Liquid Luster（启用）。**

**适用条件：Liquid Luster（启用）。**

[[spell:187874]]

**适用条件：Liquid Luster（启用）。**

[[item:271886]]

[[spell:470057]]

**适用条件：碎地猛击（启用）；涌动元素（启用）。**

[[spell:197214]]

**适用条件：根深蒂固的元素（启用）。**

[[spell:187874]]

**适用条件：根深蒂固的元素（启用）。**

[[spell:17364]]

**适用条件：根深蒂固的元素（未启用）。**

[[spell:17364]]

**适用条件：升腾（启用）。**

**适用条件：升腾（启用）。**

[[spell:114051]]

**适用条件：升腾（启用）。**

[[item:270175]]

**适用条件：原始风暴（启用）；碎地猛击（启用）。**

[[spell:1218047]]

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

[[spell:1218047]]

**适用条件：Ascendance（未启用）；Deeply Rooted Elements（未启用）。**

[[spell:384352]]

**适用条件：升腾（启用）。**

**适用条件：升腾（启用）。**

[[spell:115356]]

[[spell:187874]]

**适用条件：升腾（启用）。**

[[spell:470057]]

---

1. **适用条件：风暴使者（启用）；鲁莽药水（启用）。** 预读 [[spell:187874]]
   
   
   
   
   - 避免提前命中任何目标！
2. **适用条件：鲁莽药水（启用）。** 预用药水 [[item:241288]]
   
   
   
   
   - 预用药水可以避免属性触发将其从精通或暴击上转移
3. **适用条件：Liquid Luster（启用）；风暴使者（启用）。** 一进入近战范围就施放 [[spell:187874]]
   
   
   
   
   - 在开怪时使用 [[item:271886]]
4. **适用条件：鲁莽药水（启用）；图腾祭司（启用）。** 在进入近战范围时施放 [[spell:470057]]
5. **适用条件：鲁莽药水（启用）；风暴使者（启用）。** 在进入近战范围时施放 [[spell:470057]]
6. **适用条件：Liquid Luster（启用）；图腾祭司（启用）。** 在进入近战范围时施放 [[spell:470057]]
   
   
   
   
   - 在开怪时使用 [[item:271886]]
7. **适用条件：风暴使者（启用）。** 施放一次 [[spell:17364]] 来开始 [[spell:187880]]
8. **适用条件：图腾祭司（启用）。** 施放 [[spell:444995]]
   
   
   
   
   - 使用主动饰品，例如[[item:270175]]
   - 使用任何种族增益
9. **适用条件：图腾祭司（启用）；Sundering（启用）。** 施放 [[spell:197214]]
10. **适用条件：图腾祭司（启用）。** 施放 [[spell:384352]] 并立即 [[spell:187874]]
11. **适用条件：图腾祭司（启用）。** 施放 [[spell:60103]] 来触发 [[spell:201900]]
12. **适用条件：图腾祭司（启用）；始源风暴（启用）。** 施放 [[spell:1218047]]
13. **适用条件：图腾祭司（启用）；始源风暴（启用）。** 施放 [[spell:60103]]
14. **适用条件：风暴使者（启用）；涌动元素（启用）；碎地猛击（启用）。** 施放 [[spell:197214]] 来触发 [[spell:382042]]
15. **适用条件：风暴使者（启用）；升腾（启用）。** 施放 [[spell:114051]]
    
    
    
    
    - 使用主动饰品，例如[[item:270175]]
    - 使用任何种族增益
16. **适用条件：风暴使者（启用）；升腾（未启用）；根深蒂固的元素（未启用）。** 施放 [[spell:384352]]
    
    
    
    
    - 使用主动饰品，例如[[item:270175]]
    - 使用任何种族增益
17. **适用条件：风暴使者（启用）；始源风暴（启用）。** 施放 [[spell:1218047]]，需要 **10** [[spell:187880]]
18. **适用条件：风暴使者（启用）；升腾（启用）。** 如果 [[spell:333974]] 重置了它，或者在可用时施放 [[spell:187874]]
19. **适用条件：风暴使者（启用）；根深蒂固的元素（启用）。** 施放 [[spell:187874]]
20. **适用条件：风暴使者（启用）；升腾（未启用）。** 施放两次 [[spell:17364]]
21. **适用条件：风暴使者（启用）；升腾（启用）。** 否则在每个GCD都施放 [[spell:115356]]
22. **适用条件：风暴使者（启用）；升腾（启用）。** 冷却一结束就施放 [[spell:470057]]
23. 继续按照正常的技能优先级。

---

**适用条件：图腾祭司（启用）。** 虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司起手确实能让你非常快地进入冷却技能循环，但为了从中获得最大收益，技能顺序必须精确。特别是，让你的[[spell:384352]]在你通过[[spell:1260874]]施放的双重[[spell:60103]]期间保持激活，会让你的强化效果造成巨量伤害。虽然预读[[spell:470057]]有几率让[[spell:333974]]触发并重置[[spell:187874]]，但它需要在起手序列中就能使用，所以不能预读。

**适用条件：风暴使者（启用）。** 与单体目标非常相似， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者遵循尽可能快地进入爆发期的简单原则，这样它就可以开始循环释放[[spell:187880]]以达到[[spell:454009]]。凭借第2赛季套装，你起手的[[spell:470057]]有可能完全重置[[spell:187874]]的冷却时间，所以为了赌那层免费的充能而预读它是值得的。

- **适用条件：鲁莽药水（启用）。** 使用 [[item:241288]] 时，你 <em>需要</em> 以确保它根据你当前的装备触发暴击或精通。

1.

### 至暗之夜 第2赛季套装

至暗之夜第2赛季引入了 **蛇形神谕者的预言**，可在不同的终局内容中获得。它提供以下加成：

- [[spell:1296627]] – [[spell:470057]] 使你的目标每2秒喷发一次 [[spell:333974]]，持续6秒。火焰新星对你火山炽焰的主要目标造成提高200%的伤害。
- [[spell:1296628]] – [[spell:333974]]使[[spell:187874]]的冷却时间缩短2秒，并使你下一次毁灭闪电的伤害提高8%，最多可叠加5次。

这套装备的运作机制有很多细节，但最重要的结论是，一旦你拥有两件套，它就将 [[spell:470057]] 提升到你的循环优先级顶端。四件套还额外增加了GCD需求，因为额外的冷却缩减，需要保持 [[spell:187874]] 处于冷却状态。这些效果目前的工作方式如下：

- 两件套触发一个 <em>单次</em> [[spell:333974]] 脉冲，每两秒从你的目标身上由 [[spell:1299975]] 效果产生。
- 对你 [[spell:333974]] 的易伤效果适用于
  <em>全部</em> 在AoE中，如果 火焰新星天赋本身触发，则适用于击中你目标的脉冲。
- 如果 [[spell:333974]] 在AoE中触发，四件套提供冷却缩减 <em>每触发一次新星</em>，意味着它可以完全重置 [[spell:187874]] 的冷却时间。

与我们较弱的第一赛季套装相比，这些加成异常强大，为我们提供了单体、顺劈甚至AoE优先级伤害的提升。在第二赛季，集齐套装应该是你的首要配装目标，并且一旦解锁两件套就应该立即更换。

2.1.

#### 增强萨满祭司机制详解

在接下来的章节中，我们将深入探讨驱动增强玩法循环的具体机制的细节。虽然一些内容在至暗之夜中得到了简化，但我们的主要冷却技能、循环技能和触发效果背后仍然有很多底层机制。这是一个更进阶的章节，旨在帮助你更好地理解 <em>为什么</em>
按键背后的内容。

1.

### 增强机制详解

### 漩涡武器管理

3.1.

#### 漩涡武器详解

如果你打算在竞技水平上使用增强，[[spell:187880]]的管理至关重要。它在任何近战命中时有20%的几率触发，最多可叠加5层（有[[spell:384143]]时最多10层）。每层使你下一个[[spell:188196]] / [[spell:188443]]的施法时间缩短20%，并使受影响的法术伤害提高20%。达到5层时，这些技能变为瞬发。一次只能消耗5层，但点了[[spell:384149]]后可提升至10层。

- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者** 的构筑旨在在 **9+**层时消耗，但根据情况可能在更低层数消耗，通常是为了在资源生成器耗尽时尝试触发[[spell:1262635]]和[[spell:455110]]。
  
  
  
  
  - 在[[spell:114051]]期间，由于[[spell:384444]]，[[spell:115356]]和[[spell:187874]]每次施放都会自然消耗你所有可用的[[spell:187880]]。这 <em>总是</em> 比手动消耗更有价值，既因为该技能本身造成的伤害，也因为节省了这个GCD从而产生的额外资源。
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司** 旨在在 **10** 层时消耗，但如果这样做意味着你可以通过[[spell:1260644]]延长[[spell:201900]]足够长的时间以挤出另一次[[spell:60103]]，那么层数可以更低。
  
  
  
  
  - 在[[spell:384352]]期间，[[spell:17364]]和[[spell:187874]]都会通过[[spell:384444]]在每次施放时自动消耗[[spell:187880]]。这通常意味着在[[spell:60103]]施放之间穿插这些技能，延长一个长时间的[[spell:201900]]窗口，并利用[[spell:1250364]]的冷却缩减。

虽然在达到5层时就想施放这些法术很诱人，但你应该训练自己利用[[spell:384143]]提供的10层上限。如果你的[[spell:187880]]层数没有溢出风险，那么专注于保持其他技能处于冷却中会更有意义。

3.1.1.

##### 元素节奏

在至暗之夜中加入，[[spell:1250364]]为 <em>同时</em>
[[spell:17364]]和[[spell:60103]]提供冷却缩减，每当你消耗[[spell:187880]]时触发。每消耗一层提供0.3秒的冷却缩减，并在你可用技能不足时填补GCD之间的空隙。这与[[spell:1260644]]配合得很好，用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司，在消耗之间形成1➜2➜1的技能循环。

3.1.2.

##### 雷电容器

[[spell:1262635]]提供20%的几率返还施放[[spell:188196]]和[[spell:188443]]所消耗的全部[[spell:187880]]。这些触发通常需要一定的反应速度，在你按下预定按键之前捕捉它们，但这意味着在更低层数消耗有时值得尝试以博取返还。如果你的循环技能快用完了，并且需要[[spell:1250364]]的冷却缩减，这一点尤其有用。

### 毁灭闪电机制

3.2.

#### 毁灭闪电详解

[[spell:187874]]表面上看起来很简单，但有几个不太明显的组成部分。在至暗之夜中，它是增强在
<em>全部</em> 情况下的核心玩法，甚至是我们巅峰天赋——[[spell:1262713]]的焦点，将在下一个标签页中介绍。因此，有一些事情需要了解：

- [[spell:187874]]增益会被触发并持续12秒，触发条件是 <em>施放</em>时触发，持续12秒。它 **无关紧要** 是否命中任何目标。
- 在激活期间，[[spell:17364]]和[[spell:60103]]会触发一次
  **独立的** 伤害溅射事件， <em>也</em> 被称为毁灭闪电，在最多5个敌人之间分摊。
- **所有[[spell:187874]]伤害**，无论是主动的还是溅射的，都可以触发[[spell:187880]]。
- 该 **初始施放** [[spell:187874]]可以在命中的目标上触发独立的[[spell:33757]]事件。

上述内容意味着你应该致力于施放[[spell:187874]] <em>卡着冷却</em>。核心打击技能获得额外伤害的益处，虽然能提供额外的资源生成，但也使其变成了一种需要维护的效果。在AOE中尤其如此：虽然因为伤害会分摊，攻击额外的目标不会带来额外的伤害加成，但每一次命中 <em>确实</em> 都会触发额外事件，可以生成[[spell:187880]]。最后，在至暗之夜中，这还会在[[spell:384352]]或[[spell:114051]]期间触发[[spell:384444]]。

3.2.1.

##### 聚风暴与风暴井

[[spell:384363]]使初始[[spell:187874]]施放命中的每个目标使你下一个[[spell:17364]]的伤害提高25%/目标，最多叠加6层（最高150%）。即使在单体目标下也能激活，对于能容纳它的构筑来说是不错的单体增益。

[[spell:1264762]]是一个 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者专属天赋，当只对一个目标施放时提供额外价值。这使[[spell:187874]] **保证** 如果未命中其他敌人，则在你的目标上触发[[spell:33757]]。这被视为独立触发，因此你的施放在技术上可以触发它两次。

### 风暴释放巅峰天赋

3.3.

#### 增强 萨满祭司巅峰天赋——风暴释放

增强巅峰天赋[[spell:1262713]]主要围绕[[spell:187874]]。这使其更明确地成为循环的核心部分，对单体和AOE情况都有强大好处。虽然大部分是被动的，但它影响的内容在无论使用哪种构筑的情况下都被广泛使用：

- [[spell:1262713]] **第一点 –** 使每消耗一层[[spell:187880]]有2%的几率使你下一个[[spell:187874]]的施放无视其冷却时间。此外，毁灭闪电武器附魔增益现在可以叠加并重叠。
- [[spell:1262761]] **第二和第三点 –** 每点使[[spell:187880]]消耗者的伤害提高7.5%，武器附魔伤害提高10%。
- [[spell:1252373]] **第四点 –** 使[[spell:187874]]还会创造一个静态池，在2秒内造成相当于初始施放伤害100%的额外伤害。此外，武器附魔增益每层提供15%的攻击速度加成。

重置在战斗中频繁发生，平均每5次10层[[spell:187880]]消耗中约有一次会触发该效果（使用卡牌系统触发机制）。这些触发 <em>能</em> 可以囤积，让你能够连续施放多次[[spell:187874]]，同时叠加武器附魔的重叠效果。

这些重叠使该效果放大每次溅射造成的伤害。这个加成 <em>一次性</em> 结算，而不是额外的独立触发，意味着它能生成的额外[[spell:187880]]保持不变。第四点提供的攻击速度增益 <em>确实也会</em> 在增益重叠时叠加。

### **武器附魔**   与团队增益

3.4.

#### 增强武器附魔

你的武器附魔应该 **总是** 保持激活，因为它们提供强大的好处。以下是关于每个附魔的一些说明：

- **[[spell:33757]] -** 仅应用于 **主手**，这些额外打击被视为特殊攻击，因此可以生成[[spell:187880]]。
- **[[spell:318038]] -** 仅应用于 **副手**，这使 <em>全部</em> 武器攻击触发一次额外的火焰伤害，并在激活期间使你的[[spell:60103]]伤害翻倍。

点了[[spell:1270350]]后，在施放[[spell:192106]]时也会自动将两种附魔应用到相应的武器上。这一次性完成，不消耗额外的GCD。

3.5.

#### 元素之盾

你一次只能激活一个元素护盾，或者在点出[[spell:383010]]后可以同时激活两个。这里首选[[spell:192106]]，因为它能通过[[spell:1270350]]提供额外的敏捷加成。

应该强烈考虑[[spell:383010]]，以允许你同时拥有[[spell:974]]激活。这也应该与[[spell:1217622]]搭配使用，实现永久持续和额外的自我治疗。此外，这让你可以在另一个团队成员——通常是坦克身上保持它。

3.6.

#### 天怒

[[spell:462854]]由任何萨满祭司提供，为所有小队和团队成员提供固定的精通等级加成。它对近战角色还有额外好处，提供20%的几率在每次挥击时触发一次额外的自动攻击，每个玩家有0.5秒的内置冷却。这不会从未命中攻击触发，自身也可能未命中。这些额外攻击算作普通自动攻击，意味着它们触发所有命中效果，但它们 **不会**
不影响猎人的自动射击、宠物或守护者。

3.7.

#### 增强 萨满祭司主要冷却技能

在整个天赋树中，有几个不同的冷却选项，以不同方式提供爆发。下面我们将介绍每一个，它们如何影响循环，以及如何使用它们。

1.

### 增强 萨满祭司的重要冷却技能

### 毁灭之风

4.1.

#### 毁灭之风

[[spell:384352]]是一个1分钟冷却、脱离GCD的技能，提供8秒内触发[[spell:33757]]的几率提高50%，并对你周围脉冲风暴打击（自然/物理）伤害。在至暗之夜中新增，它继承
<em>同时</em> [[spell:384411]]和[[spell:384444]]效果。这每秒生成最多2个[[spell:187880]]，并在使用时使[[spell:17364]] / [[spell:187874]]释放消耗者。此外，点了托里姆的祈唤后，其持续时间增加2秒。

这也是 <em>被</em> [[spell:114051]]或[[spell:378270]]（如果点了）替代的，因此作为一个低点数消耗的冷却选项。它非常适合 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司，提供一个与每次[[spell:444995]]施放同步的选项，让你能够持续延长[[spell:201900]]。

4.1.1.

##### 托里姆的祈唤详情

[[spell:384444]]使激活期间的[[spell:17364]]和[[spell:187874]]施放释放一个[[spell:187880]]消耗者，消耗你当前所有层数。这有一些从提示文本中可能不太清楚的额外细节，以及一些需要注意的交互，无论你选择哪个冷却技能。它有两个预备状态——[[spell:188196]]和[[spell:188443]]——并且可以被某些技能动态切换，特别是在AOE场景中：

- 任何[[spell:188196]]和[[spell:188443]]的施放都会手动将[[spell:384444]]设置为相应的法术。这个切换 **非** 由[[spell:289874]]触发。
- 确保 **之前** 每次[[spell:384352]] / [[spell:114051]]施放时，你都预备到正确的法术：
  
  
  
  
  - **单体目标 -** [[spell:188196]]
  - **AoE -** [[spell:188443]]
- [[spell:454009]]是 <em>动态的</em>，意味着命中的目标数量决定预备。如果只命中一个目标，它设置为[[spell:188196]]，如果命中两个或更多则更改为[[spell:188443]]。
  
  
  
  
  - [[spell:384444]]会 **总是** 在可能的情况下消耗[[spell:454009]]，无论预备状态如何。
- [[spell:1218047]]是 <em>动态的</em>动态的，并会在其序列结束时预备到它施放的两个法术之一。这由初始3次打击命中的目标数量决定。

### 升腾

4.2.

#### 升腾

[[spell:114051]] <em>替代</em> [[spell:384352]]（如果点了），改为2分钟冷却。它 **在** 不占用GCD，且激活时免费触发毁灭之风（持续10秒）。它持续15秒，继承[[spell:384411]]和[[spell:384444]]，激活期间，你的[[spell:17364]]和自动攻击被转换为[[spell:115356]]和[[spell:114089]]。这两者都有30码范围，无视所有护甲，风怒打击的冷却时间减少60%。

这提供了一种非常稳定的方式来反复触发[[spell:384444]]，在施放之间穿插[[spell:187874]]。此外，当[[spell:114051]]激活时，每消耗一层[[spell:187880]]提供0.5%的几率触发[[spell:384352]]。 <em>非</em> 激活。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者在施放时还会额外激活[[spell:454009]]，使其成为天赋树底部的首选冷却技能选项。

4.2.1.

##### 根深蒂固的元素

同时，在点出该天赋后，它会替换[[spell:384352]]，改为每次消耗[[spell:187880]]时有0.6%的几率触发 <em>同时</em> [[spell:114051]]和毁灭之风，持续时间分别为8秒和10秒。这种触发方式的可预测性要低得多，但如果运气站在你这边，可以提供爆发性的伤害。这在当前的至暗之夜中并不是一个值得选择的选项，但未来可能会有所改变。

### 裂地术

4.3.

#### 裂地术

[[spell:197214]]对前方直线上的所有目标造成大量烈焰打击伤害，冷却时间为30秒。当以 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司身份游玩时，它还会在每次施放[[spell:444995]]后消耗其产生的[[spell:453406]]微粒，造成更高的伤害并召唤一个灼热图腾。它的定位是一个中距离的爆发工具，尤其是在点出后续的范围伤害天赋时。

4.3.1.

##### 元素涌动

每当施放[[spell:197214]]时，[[spell:382042]]会提供持续12秒的15%急速。此外，它还会使裂地术在使用时产生5层[[spell:187880]]。请注意，[[spell:445035]] <em>不会</em>
不会触发急速加成或在游玩时产生额外的漩涡值 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司.

4.3.2.

##### 始源风暴

[[spell:1218047]]是施放[[spell:197214]]后可用的连招技能后续。施放时，它会触发一段4步攻击，且攻击顺序始终相同：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_ascendance.jpg>) **始源风暴顺序**
**火焰打击**

➜

**冰霜打击**

➜

**闪电打击**

➜

**强化的[[spell:187880]]消耗技能**

:::

前3次打击被视为 **主手** 打击，并且造成范围伤害，这意味着它们会各自单独对命中的目标触发武器附魔效果。最后，它还会消耗[[spell:187880]]来强化
**全部** 的伤害。所选择的消耗技能取决于打击命中了多少个目标——默认为[[spell:188196]]，如果命中两个或更多目标，则切换为[[spell:188443]]。此 <em>不会</em> 在通过[[spell:445035]]触发[[spell:197214]]后变得可用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为第1赛季发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 对输出循环进行了小幅更新，并将 图腾祭司 作为大秘境推荐。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月16日：** 调整推荐以更坚定地采用 图腾祭司。
- **2025年3月4日：** 将巫医之祖重新加入推荐和输出循环工具。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 针对11.0.7版本进行了更新，添加了更详细的 托里姆 的祈求部分。
- **2024年11月5日：** 根据更近期的11.0.5版本认知，对优先级列表进行了重大更新。
- **2024年10月21日：** 11.0.5版本的初步更新。随着更多正式服数据的获取将进行更新。
- **2024年9月23日：** 已根据最新的热修复和风暴天赋切换进行更新。
- **2024年9月9日：** 针对 元素 爆裂和风暴之怒的在线修正以及新的风暴配装进行了更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月21日：** 针对10.2.6版本进行了审查，精简了洞察部分。
- **2024年1月15日：** 针对10.2版本进行了审查，结构有轻微变动但内容依然准确。
- **2023年11月6日：** 已为10.2版本更新，并重构了循环工具。
- **2023年9月4日：** 重构了冷却技能章节，但10.1.7版本无需内容更改。
- **2023年7月14日：** 在切换按钮上加入了配装方案按钮，以便更轻松地展示循环手法。
- **2023年7月13日：** 清理了AOE循环章节，并对风暴相关部分进行了改进。
- **2023年7月10日：** 已针对10.1.5补丁进行更新，移除了风暴流派中四件套的使用，并强调优先使用风暴打击而非消耗技能。
- **2023年5月4日：** 对循环工具进行了微调，为错误的天赋组合添加了警告。
- **2023年5月1日：** 针对10.1补丁更新进行了全面改版，包含风暴流派、循环工具更新、T30套装奖励及新增章节。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已审阅并改进循环工具，使其更贴近当前游戏实际。
- **2022年12月11日：** 添加了套装章节。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到魔兽世界12.1.5版本中你的增强萨满祭司的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们一应俱全！

1.

### 增强萨满祭司毕业装备指南

欢迎来到我们的至暗之夜增强萨满祭司装备与毕业页面！查看此页面，了解关于为增强萨满祭司配装所需的一切信息，包括来自所有来源（团队副本和大秘境）的毕业装备、关于最佳饰品、套装等的信息。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，允许你沿着与获取内容难度相关的轨道提升装备物品等级。更难的内容会掉落更高等级轨道的装备，从而达到更高的物品等级。欲了解更多信息，请阅读我们关于纹章如何运作的专属页面。 [配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 在至暗之夜中的运作方式。

12.1.5更新带来了[[item:280562]]的发布，允许334物品等级的武器、饰品和项链一直升级到340物品等级。此外，它还带来了新首领基斯希克斯，掉落强大的新战利品，为增强提供了一些非常不错的提升。

:::details ![](<https://static.icy-veins.com/images/wow/tools/recommended.png>) **12.1.5版本配装注意事项**
基斯希克斯引入了多个值得装备的新咒术物品，这意味着一些部位需要调整以适应属性预算。在查看下方链接的催化剂装备时请牢记这一点。

:::

### 总体

以下列表包含来自 <em>所有可能的终局内容来源</em>的装备，包括团本、大秘境、制造、地下宝库和大宝库。它旨在提供绝对最佳的配置，但请记住，每个 **单件** 装备在你特定的配装中可能并非最强。套装件如果比标准版本更强，则会列出理想转化器部件的掉落位置。

请注意，在第二赛季中，配装相当复杂。我们希望暴击保持在 <em>略高于</em> 精通之上（对于使用[[item:241288]]），然后尽可能让精通和急速紧随其后。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

目前每个部位可供转化的最佳物品为：

- **头盔 –** [[item:271483@JAACAAgNyA]]，来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- **肩膀 –** [[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **胸甲 –** [[item:271876@JAAEAAAG2YhN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **手套 –** [[item:281238@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **腿部 –** [[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 常见问题：有哪些需要留意的高优先级大宝库或虚空核心物品吗？
第2赛季团本中提供的任何特殊效果物品都极具价值，即使它们不是来自史诗难度的344物品等级。以下物品即使来自英雄难度宝库也强烈值得考虑，如果你不打算快速推进史诗难度，甚至值得使用虚空核心来获取：

1. [[item:268209@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
2. [[item:270175@JAACAAAG2A]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
3. [[item:270173@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271876@JAAEAAAG2YhN]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281238@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

所有三件新的 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 物品也非常强力，是很好的虚空核心候选。该池中的物品足够强大，以至于如果你 <em>没有</em> 击杀任何史诗首领以获得更高的宝库奖励，如果这些物品都没有出现，你总是可以选择从大宝库中获取一个虚空核心。

:::

:::details 常见问题：我应该把物品等级最高的武器放在主手还是副手？
增强

**总是**

通常会将物品等级最高的武器放在

**主手**

中，无论你选择哪个英雄天赋。虽然

[[spell:60103]]

只与你的副手武器联动，且有些流派会大量依赖它，

<em>其他所有流派</em>

从主手武器的联动中获益更多。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271484@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240900]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>护肩</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271482@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271486@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237850@JAAMAAwt1ENMMYzy1klIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 秘境+

以下套装包含来自大秘境的最佳物品，仅使用第2赛季副本池中的装备，以及你理想的套装转化器位置和用于装饰效果的制造物品。请注意，这是 <em>可获得的最佳物品</em> 来自大秘境地下城的 **非** 并非你在大秘境内容中应使用的严格列表。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

最佳 **仅限地下城** 的各部位转化件为：

- **头盔 –** [[item:251220@JAACAAgNyA]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **肩膀 –** [[item:239049@JAACAAgNyA]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **胸甲 –** [[item:273789@JAACAAgNyA]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- **手套 –** [[item:193752@JAAKAAQkCYHKvbRLfYjM]]，来自 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- **腿部 –** [[item:159375@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 提示我应该刷哪些地下城？
增强在第二赛季中最强大的装备均来自团队副本，但在你等待获取它们的过程中，也有一些值得追求的替代品：

1. [[item:273796@JAACAAgNyA]] - [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
2. [[item:273792@JAACAAgNyA]] - [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
3. [[item:251220@JAACAAgNyA]] - [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
4. [[item:252258@JAACAAgNyA]] - [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:251155@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>护肩</th><td>[[item:271481@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271486@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:251224@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237850@JAAMAAwt1ENMMYzy1klIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 团队副本

以下套装是你的 **团本** 毕业列表，使用来自 **只能** 团本掉落的装备，以及理想的套装件（或用于转化器的物品）和用于激活装饰效果的制造物品。请注意，这是 <em>可获得的最佳物品</em> 团本内部的 **非** 并非你在团本内部应使用的严格列表。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

最佳 **仅限团本** 的各部位转化件为：

- **头盔 –** [[item:271483@JAACAAgNyA]]，来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- **肩膀 –** [[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **胸甲 –** [[item:271876@JAAEAAAG2YhN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **手套 –** [[item:281238@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **腿部 –** [[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 小贴士：我最应该追求哪些物品？
增强在第二赛季的团队副本中有一些价值极高的咒术装备，主要集中在剧毒深渊的最后两个首领。由于这些物品的物品等级更高，几乎所有都值得获取，但其中一些尤为强大：

1. [[item:268209@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
2. [[item:270175@JAACAAAG2A]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
3. [[item:270173@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271876@JAAEAAAG2YhN]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281238@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

值得一提的是，所有三个新的 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 物品都很强。手套总是有用的，尽管[[item:281029@JAACAAgNyA]]需要围绕它进行一些配装调整。最后，[[item:281215@JAACAAAOyA]]更适合放在饰品位用于范围伤害战斗，但最重要的是它的掉落表中没有废品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271484@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240900]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>护肩</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271482@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271486@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237850@JAAMAAwt1ENMMYzy1klIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 增强萨满祭司饰品推荐

增强理想情况下需要一个主动使用饰品来配合每个英雄天赋所使用的强力冷却技能——[[spell:444995]]或[[spell:114051]]——再搭配一个被动饰品。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **在至暗之夜中值得追求的饰品**
**主动使用 –**

[[item:270175@JAACAAAG2A]]

**被动 –**

[[item:270173@JAACAAAG2A]]

或

[[item:281215@JAACAAAOyA]]

:::

你可以点击下方打开其他饰品的排名图表，以防你捡到了别的东西并想看看它与其他饰品相比如何。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看增强第二赛季饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270175@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   尽管冷却时间是尴尬的1分30秒，但这绝对是第二赛季中最好的主动使用饰品选项。没有其他选项在威力上能与之相比，所以这是你的重点追求目标之一。务必留着它，与你的[[spell:114051]]或[[spell:444995]]窗口对齐使用。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270173@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   一个标准的直接伤害饰品，但与咒术武器[[item:268209@JAACAAAG2A]]搭配时会变得更强。在范围伤害内容中用处较少，但在单体目标尤其是团队副本中的顺劈战斗中，它是最强的被动选项。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   在12.1.5补丁中新增，这是 <em>最强的</em> 被动范围伤害饰品，如果目标数量足够多，甚至可以与断头台技巧抗衡。在1-2个目标的情况下会稍逊一筹，但绝对值得为大秘境获取。</p>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:273796@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   虽然肯定不如贪婪之心强，但如果你需要一个主动使用饰品，它是一个不错的替代品。使用它和[[item:241288]]时，请确保 <em>之前</em> 在激活此饰品前喝药水，以避免增加错误的属性。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270165@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   提供极高频率的大量急速，这弥补了我们在第二赛季中无法真正将急速堆到暴击之上的事实，因为我们更倾向于临时触发效果。如果你无法获得S级的被动选项，这是一个很好的选择。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   触发各种不同的属性增强效果，且不同的增益可以叠加。虽然它的触发池中确实有一个负面效果，但它是可用的最佳被动属性饰品，使其成为范围伤害密集型战斗和副本的不错选择。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250225@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   尽量始终对一个存活时间足够长的目标使用它，以便叠加暴击增益，否则它的大部分价值都会流失。</p>&#10;</li>&#10;<li>[[item:250228@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159617@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   根据流派留着与[[spell:114051]]/[[spell:444995]]对齐使用。使用[[item:241288]]时，请确保 <em>之前</em> 使用你的饰品以避免将其设置为暴击。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   虽然这个饰品的数值调校得不错，精通也很理想，但留在触发区域内非常受限，尤其是在第二赛季。由于团队副本战斗场地较大且地下城中移动频繁，实际使用时效果可能因人而异。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:248583@JAACAAAMyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   前往 祖尔'Aman 中的 Jan'alai 祭坛，将其设置为 <strong>精通</strong>.</p>&#10;</li>&#10;<li>[[item:251792@JAACAAAMyA]]</li>&#10;<li>[[item:270166@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>点击查看详情</em></span>&#10;<span>&#10;		   这会造成一个 <em>极</em> 大量的爆发伤害到你的主要目标上，同时附带一些额外的群体伤害。虽然由于它是引导技能且冷却时间长，在与其他选项竞争时有些吃力，但它在处理关键敌人方面的独特潜力意味着在第二赛季的某些边缘情况下值得一看。</span>&#10;</li>&#10;<li>[[item:265657@JAACAAAMyA]]</li>&#10;<li>[[item:250259@JAACAAAOyA]]</li>&#10;<li>[[item:274493@JAACAAAMyA]]</li>&#10;<li>[[item:158374@JAACAAAOyA]]</li>&#10;<li>[[item:251785@JAACAAAMyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:273797@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<span>&#10;		   根据流派留着与[[spell:114051]]/[[spell:444995]]对齐使用。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274496@JAACAAAMyA]]</li>&#10;<li>[[item:274497@JAACAAAMyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:246304@JAAIAAwt1ENMMYDH2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>制造饰品详情</em></span>&#10;<span>&#10;		   虽然这些饰品选项并不 <em>差</em>，但第二赛季的装饰比以前更强了。这意味着使用它们的机会成本太高，它们比原本就已经落后的地位更加落后了。</span>&#10;</li>&#10;<li>[[item:246305@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246306@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246307@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:241340@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:251784@JAACAAAMyA]]</li>&#10;<li>[[item:251783@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚无核心与升腾毒石

第二赛季沿用了第一赛季推出的额外奖励骰系统，提供了一种获取重要装备的途径：

**[混沌虚空核心](<https://www.wowhead.com/currency=3418>)s** 可在完成终局地下城或击败团队副本首领后使用，从相应的掉落表中随机获得一件物品。一旦通过虚无核心骰获得过某件物品，它就不会再次出现。在第二赛季， **单** 虚无核心用于对地下城掉落进行掷骰 <em>或</em> 单个团队副本首领，获得相当于你每周宏伟宝库奖励装等的掉落。

每周可从 **奥琳·微光** 获得一个，该物品位于催化剂旁边，随12.1.5补丁发布后开放。此外，如果你解锁了总共三个奖励，也可以从宏伟宝库中选择一个虚无核心而非一件物品。

3.1.

#### 增强萨满祭司推荐的虚空核心用法

你应该优先获取哪件物品，很大程度上取决于你已经拥有的装备、可通过 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)获得的物品，以及你目前已击杀的首领。虽然随着12.1.5补丁加入每周奖励，它们现在更容易获得，但从宏伟宝库中拿一个应被视为 <em>安慰奖</em> ，在没有更好选择的情况下。

关于 <em>以及</em> 当你确实拿到一个虚无核心后，应该在哪里使用它，答案很简单：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **第二赛季虚无核心用途**
1. **乌拉特克** （英雄/史诗）
   
   
   
   
   - [[item:270175@JAACAAAG2A]]
   - [[item:268265@JAAGAAAG2MqNTpC]]
   - [[item:271876@JAAEAAAG2YhN]]
2. **盘卷祭坛** （英雄/史诗）
   
   
   
   
   - [[item:268209@JAACAAAG2A]]
   - [[item:270173@JAACAAAG2A]]
3. **Kith'ix** （英雄/史诗）
   
   
   
   
   - [[item:281238@JAAEAAgNyEuN]]
   - [[item:281029@JAACAAgNyA]]
   - [[item:281215@JAACAAAOyA]]

:::

:::details 常见问题：我何时应该考虑从宏伟宝库中选择虚无核心？
随着赛季推进，虚无核心更容易获得，推荐也更加具体。虽然你现在拥有更多掷骰机会，但仍需记住一些可能让你觉得拿一个不太划算的情况：

- 如果你尚未解锁你的四件套效果，获取它应优先考虑。
- 如果 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 或 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
  中的关键追求装备被提供，就选它。
- 留意早期史诗难度首领击杀掉落的关键单品（例如来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>) 的武器，或来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)的饰品），因为它们以6/6史诗难度提供，可以节省纹章并省去为有用物品进行额外掷骰的需求。

主要需要考虑的是，虽然额外奖励骰会缩小后续掷骰可获得的物品池（提高获得追求装备的几率），但一开始就从掉落或宝库中获得你想要的物品，可能可以避免投入额外的虚无核心。

:::

3.2.

#### 晋升毒液石

随着12.1.5补丁发布，你现在可以获取 [[item:280562]]，允许你将特定装备栏位一直升级到装等340（制造装备为338）。使用这些的优先级与你的纹章使用类似：

1. **主手武器** 始终优先。
2. **主动使用型饰品** 其次，理想情况下是 [[item:270175@JAACAAgNyA]]。
3. **被动饰品** 第三。
4. **副手武器** 第四位。
5. **项链** 最后。

你还希望优先升级神话级装备而非英雄级装备，除非你不打算获得你正在升级的装备的神话级版本。例外是 乌拉特克 在剧毒深渊中最难获得的装备之一——[[item:270175@JAACAAgNyA]]。由于它是我们目前最强的主动使用型饰品，即使在较低级别的装备上也值得投资。

1.

### 增强萨满祭司最佳制造物品

制造装备提供了在赛季中获取高价值物品最简单的方式之一，让你能够定向获取关键装备来完善你的配装。随着第二赛季发布，每次制造需要两个 [[item:274476]]。

除非物品已经固定了副属性，否则你应该使用[[item:245783]]来选择急速和精通。根据你装备的属性平衡，模拟结果可能会有所不同——在优化时请始终遵循你自己角色的模拟结果。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_green.jpg>) **增强制造订单**
**[[item:237850@JAAMAAwt1ENMMYzy1klIcYD]]**

➜

**[[item:244584@JAAKAAwt1ENMMYDYwklI]]**

➜

**可选制造**

:::

- 首先制造一把 **武器**，因为它在前期影响最大。制造斧头、锤子还是拳套都无所谓，但 **请确保你的选择带有敏捷属性**。凭借新加入的[[item:273060]]，它可以一直用到终局配装，当你获得升级时再将其换到副手。
- 其次制造一件 **散件** ——我们推荐腕部的[[item:244584@JAAKAAwt1ENMMYDYwklI]]。将[[item:240167]]作为你的第二个纹章装饰附着。
- 之后，根据你当前装备的空缺来制造物品。

:::details 常见问题：第二赛季的新装饰好吗？
**有些**。在第二赛季发布前，许多装饰被削弱了，这在12.1.5补丁中并未改变：

- [[item:273060]] 是 [[item:245876]] 的更好替代品，使其成为最佳武器装饰，也是我们目前的首选。
- [[item:273069]] 提供可叠加的急速触发。这 <em>非常</em>
  价值接近[[item:240167]]，但差距足够大，考虑到后者还能增益队友，因此无法证明其合理性。
- [[item:273066]] 遭到了 <em>巨大的</em> 削弱，所以即使本赛季暴击的价值更高，它也无法与其他选项竞争。
- [[item:270899]] 也遭受了大幅削弱，因此也不值得考虑。

:::

一旦你完成了两个主要的纹章装饰制造，你就拥有了扎实的配装基础。在进一步优化装备时，你的优先级应该是制造高物品等级的装备来填补配装中的空缺。一个好的候选是戒指，因为虽然有强力的唯一性选项，但它们通常 <em>极</em>
竞争激烈。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

1.

### 纹章使用

赛季初期，或者如果你刚开始玩一个副角色，你获得升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 以提升装等）的机会有限。纹章每周上限为100个，升级无论哪个栏位都花费20个纹章。因此，你应该优先将这些纹章用在你短期内不打算更换的物品上，或者能提供更大属性收益的特定栏位：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_121_crest_myth.jpg>) **增强萨满祭司纹章升级优先级**
**武器（主手）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些不是唯一值得升级的物品。它们只是在赛季初期、你的升级货币有限时能提供最高DPS收益的物品。注意例外情况是可能的，例如附带额外触发的特殊咒术物品，比如 [[item:268265@JAAGAAAG2MqNTpC]]。

5.1.

#### 为装备添加插槽

虽然所有戒指和项链默认带有一个插槽，但头盔、腰带和护腕栏位在掉落时作为奖励可以获得三个额外插槽。这些也可以使用 [[item:275707]] 消耗品手动添加，该消耗品可以用6个 [[item:258556]] 购买，这是宏伟宝库的保底货币。

使用这些时，最好将它们用在你预计永远不会替换的装备上。这意味着史诗级物品，或这些栏位中的任何制造装备，因为它们无法通过其他方式添加插槽。由于它们是非常有限的货币，如果你拥有这些，最好在使用前做好长期规划。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月24日：** 已更新以纳入赛季开始后的重大配装改动。
- **2026年8月19日：** 由于阿希尔班圣匣在线修正，添加了关于装备推荐不确定性的免责声明。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已根据12.0.7补丁使用孢子坠落装备进行更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月7日：** 在早期制作FAQ中添加了关于无界催化剂的说明。
- **2026年3月16日：** 根据 至暗之夜 第一赛季发布进行更新。
- **2026年3月2日：** 小幅更新以反映饰品调整。
- **2026年2月26日：** 根据 至暗之夜 发布和季前赛进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已为11.2.5版本更新，并加入了卡特尔代币推荐。
- **2025年8月16日：** 更新了饰品梯级榜以纳入调整。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月24日：** 已更新以纳入D.I.S.C.的热修。
- **2025年6月15日：** 已为11.1.7版本更新，加入D.I.S.C.腰带，并为双加里维克斯武器微调了毕业列表。
- **2025年5月12日：** 已为涡轮加速发布确认迪纳尔推荐。
- **2025年4月21日：** 已针对11.1.5版本进行审查，并添加了卡特尔代币部分。
- **2025年3月4日：** 下调了塞尔瑟斯的王冠推荐。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月17日：** 已更新以突出热修后新戒指的强度。
- **2024年12月15日：** 已为11.0.7版本更新，加入希尔赛的项圈。
- **2024年11月5日：** 将正义之手加入单体目标推荐。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已更新第1赛季毕业列表。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为第4赛季和觉醒装备的发布进行更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 针对10.2.5版本进行了审查，添加了关于狂心的说明。
- **2023年11月7日：** 更新以移除孢子斗篷推荐，切换了幻晶/暗影烈焰。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已为10.1.7版本重构，信息保持不变。
- **2023年7月20日：** 为高层大秘境加入了孢子披风的制造选项。
- **2023年7月12日：** 由于补丁发布更新，提升了加速沙漏的价值。
- **2023年7月10日：** 已针对10.1.5补丁进行更新，加入了永恒黎明装备并整理了制造章节。
- **2023年5月25日：** 添加了关于大灾变时光漫游的部分。
- **2023年5月9日：** 已更新以调整饰品的更改。
- **2023年5月1日：** 已为10.1版本和第2赛季的发布更新，加入新的装备推荐。
- **2023年3月24日：** 已根据原始宝石的在线修复更新。
- **2023年3月20日：** 已根据10.0.7补丁更新，包含熔炉指环推荐。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页中，你将找到你的增强萨满祭司的最佳属性优先级。我们首先介绍属性优先级，然后深入探讨属性如何与你的专精和游戏玩法互动的更复杂解释。我们的内容已针对魔兽世界12.1.5补丁更新。

1.

### 增强萨满祭司属性优先级

欢迎来到我们的至暗之夜增强萨满祭司属性优先级页面！在这里，我们将快速介绍你应该在装备上追求的属性，以及根据你的流派可能需要的任何特殊考虑。

增强有两个不同的英雄天赋，每个天赋对各项属性的偏好略有不同。通常情况下，你可以为两者使用同一套装备而不会损失太多，但优化每套配装确实遵循不同的规则：

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者属性优先级

目前，在游玩时 **无论是** 单体还是范围伤害， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者流派的属性优先级如下：

装备等级

暴击

精通

急速

全能

在至暗之夜中，属性压缩后敏捷的价值变得高得多。这意味着你的大多数配装决策都是由物品等级驱动的，这一趋势在第二赛季中仍在继续。

根据第二赛季发布后的改动， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 的属性在三项属性之间相互竞争。理想情况下，你应该以暴击作为角色面板上最高的属性，来强化 [[spell:1251026]]。

精通和急速紧随其后，你的目标是在优化装备时让这三项属性尽可能接近。急速显著加快输出循环的节奏，而精通则叠加你自然伤害法术的加成，所以三者都很重要。

全能通常是要避免的属性，但如果部分装备带有它也无伤大雅。

:::details 提示：关于优化装备搭配和 鲁莽药水 的进阶说明
在第2赛季，配装 <em>好得多的</em> 对 增强 来说更为复杂，因为游玩时切换到了 [[item:241288]] ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者。你希望药水始终触发暴击（若不行则触发精通），因为 [[spell:1251026]] 能抵消部分收益递减带来的损失。我们将其用作 **起手药水**，所以唯一重要的是我们静态的角色面板。你的理想目标是：

- 让暴击刚好高于所有其他属性。
- 尽可能堆高急速和精通， <em>活跃的情况下</em> 但不要超过你的暴击。
- 将所有属性触发效果和手册调整为急速与精通。

这意味着你可以根据需要使用合剂来调整数值，而你的手册通常会选择急速或精通——一旦我们让 鲁莽 正确触发，战斗中的属性触发就不重要了。这很难达成，但能带来更稳定的起手爆发。

此外，如果你在 [[spell:2825]] 之外使用战斗中段的药水，这一点就没那么重要——在这种情况下，急速药水的负面影响远不如平时那么大。这些都是第2赛季中针对装备的极端优化，但在追求理想装备搭配时确实能带来很大差异。

:::

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 属性优先级

目前，在游玩时 **无论是** 单体还是范围伤害， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 构筑的属性优先级如下：

装备等级

精通

急速

暴击

全能

在至暗之夜中，属性压缩后敏捷的价值变得高得多。这意味着你的大多数配装决策都是由物品等级驱动的，这一趋势在第二赛季中仍在继续。

由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 的大量伤害来源于 [[spell:33757]] 和魔法技能，精通始终是最强的可堆叠属性，因此优先堆叠。你也始终希望精通是你最高的属性，以确保 [[item:241288]] 触发精通。

急速紧随其后，所以通常你让这两者保持平衡，因为它能增加 [[spell:187880]] 的生成来驱动 [[spell:1260644]]。暴击降至第三位，但由于 [[spell:445033]] 和 [[spell:1251026]] 的额外加成，它仍然保持接近，尽管它从中获得的收益不如 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 那么多。

全能理想情况下应避免，因为它明显弱于其他三项属性，但如果你当前的装备搭配没有其他选择，有全能也可以。

在优化的装备搭配中，[[item:241288]] 是选用的战斗药水——使用时你需要 **确保** 它会触发精通。这比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 的配装难题要简单得多，但如果你无法稳定达成，那就改用其他药水。

1.

### 深入属性解析

作为一名 增强 萨满祭司， **敏捷** 是你的主属性，应出现在你穿着的所有锁甲装备上，以及你的武器上。各项属性提供以下收益：

- **敏捷** 为你提供攻击强度，提高你所有近战技能的伤害。增强 还会将其转化为法术强度，同时提高法术伤害和治疗强度。
- **暴击** 提高你的攻击和技能造成暴击的几率，造成双倍伤害。
  
  
  
  
  - 某些天赋（例如 [[spell:1251026]]）会将此加成伤害提高到超过基础的200%倍率。
  - 同时提高技能触发 [[spell:382888]] 效果的几率。
- **急速** 提高你的近战自动攻击速度，增加附魔触发和 [[spell:187880]] 层数生成的频率。此外：
  
  
  
  
  - 提高 [[spell:188389]] 和 [[spell:444995]] 的跳动频率。
  - 将你的全局冷却时间缩短至最低0.75秒。
  - 缩短你的 [[spell:17364]]、[[spell:60103]] 和 [[spell:187874]] 技能的冷却时间。
- **精通** ([[spell:77223]]) 提高你造成的所有 火焰、冰霜 和自然伤害。此外：
  
  
  
  
  - 提高触发 [[spell:201845]] 和 [[spell:33757]] 的几率，但缩放幅度小得多。通过 [[spell:392352]] 天赋，转化后的几率可提高150%。
- **全能** 以固定数值提高你造成的所有伤害和治疗（包括饰品和触发效果）。此外，将你受到的所有伤害降低该数值的一半。

2.1.

#### 属性递减收益

每种属性都有一个收益递减点，超过该点后每点属性带来的提升会减少。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为12.1.5补丁进行了审查，添加了药水优化的进阶技巧。
- **2026年8月24日：** 调整了暴击等级，使其对风暴使者与精通持平，并降低了急速。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对第1赛季发布进行审查。
- **2026年3月2日：** 由于放弃了过载，更新了 图腾祭司 的属性。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，无需更改。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行更新，加入了关于软急速阈值的小提示。
- **2023年5月1日：** 已更新至10.1，调整了关于风暴流派和元素使急速的说明。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页，我们列出了你的 增强 萨满祭司 能获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

所有内容的推荐选择为：

- 在你的第一个插槽中使用[[item:240983]]。
  
  
  
  
  - 在其他插槽中使用[[item:240900]]。
- 由于 **5个及以上插槽**，切换为[[item:240967]]。
  
  
  
  
  - 每种颜色使用一颗以最大化加成——[[item:240900]]、[[item:240892]]、[[item:240908]] 和 [[item:240917]]。

根据你的属性平衡，你可能会发现插槽是调整副属性的最佳位置。由于精通、急速和暴击都具有竞争力，我们建议对你的角色进行模拟，看看在插槽中优先选择哪个属性最值得。

1.

### 最佳附魔和武器强化

不幸的是，由于 增强 的附魔系统，我们无法使用额外的武器符文消耗品。这是因为 [[spell:33757]] 和 [[spell:318038]] 会覆盖它们，所以省点钱，别操心这些了！

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td><strong>主手</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>副手</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>头部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>护肩</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>胸部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>腿部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>靴子</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>戒指</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

由于 [[item:243957]] 对暴击的乘算方式，它大幅优于所有纯属性附魔，因此始终使用它。

头盔、肩膀和靴子的附魔取决于个人喜好，因为它们对性能没有直接影响，但我们建议所有插槽都选择闪避附魔以获得额外的生存能力。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

在第2赛季，合剂的选择对 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 来说不再那么简单——它们反而被用来平衡副属性：

- [[item:241326]] —— 如果你的急速或精通高于暴击。
- [[item:241325]] —— 如果它不会让急速超过暴击。
- [[item:241322]] —— 如果你不能使用急速，且它不会让精通超过暴击。

作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者，你的目标是让暴击保持为最高的副属性，同时让急速和精通紧随其后。这意味着你的合剂用于“修复”你当前失衡的属性，这会根据你当前的装备搭配而变化。

当游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 时这要简单得多：始终使用 [[item:241322]]。

你也可以从炼金术士提供的 [[item:241319]] 获得你选择的合剂。

3.2.

#### 药水

在第2赛季，药水也复杂得多，有三种不同的选项适用于不同场景：

- [[item:241288]] —— 如果它会触发暴击或精通，则作为起手药水。
- [[item:271886]] —— 如果你无法适当调整 鲁莽，则作为起手药水。
- [[item:241308]] —— 如果你想要一个更简单的即时药水。

由于你当前的装备可能会 <em>严重</em> 影响 [[item:241288]] 的效果，另外两个选项现在也非常相关，并且在使用它们时有不同的循环考量。你可以查看我们的
[循环页面](<https://www.icy-veins.com/wow/enhancement-shaman-pve-dps-rotation-cooldowns-abilities>)
来了解每种药水的使用说明。

你也可以从炼金术士提供的 [[item:241285]] 获得这些药水的短暂版本。

关于 [[item:241292]] 的一点说明是，虽然它在技术上更强，但它生成的虚空区域会使你虚弱。在里面只需1-2个全局冷却就能抵消额外收益，所以除非你对这个缺点非常适应，否则通常不值得使用这个药水。

[[item:271883]]是目前最好的治疗药水。使用后有5分钟冷却时间，但如果首领战持续足够长，可以消耗多个。此外，术士的[[item:5512]]与其他治疗消耗品不共享冷却时间。如果你持有一个，记得也要使用它！

3.3.

#### 食物增益

敏捷在第2赛季仍然是最强的属性，所以如果可能的话，你应该吃[[item:255845]]或其他主属性大餐。如果团队没有提供，就改用[[item:242275]]个人食物。

3.4.

#### 强化符文

此外，如果经济允许，你应该使用 [[item:259085]] 来提高你的主属性。请记住强化符文价格昂贵且死亡时消失，所以明智使用！

3.5.

#### 其他消耗品

除了标准的增益消耗品外，还有少数其他物品值得保留——尤其是在大秘境中：

- [[item:188152]]——让你自动与附近的术士[[spell:111771]]互动。
- [[item:269586]] —— 可以对你的目标用作战斗复活，并且 <em>不会</em> 需要工程学。这尤其有用，因为我们总是可以用 [[spell:20608]] 让自己复活。
- [[item:241303]]——至暗之夜的隐身药水，可用于在大秘境中跳过某些小怪战斗。请注意，这 <em>确实</em>
  与你选择的进攻性药水共享冷却时间。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月24日：** 扩展了合剂和药水部分，提供更多进阶的第2赛季选择。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为第1赛季更新——为大秘境增加了茶饮和额外的消耗品。
- **2026年3月2日：** 因属性变更调整了药剂推荐。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月12日：** 已根据腐蚀调整进行更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月4日：** 为单体目标添加了深渊之威。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5版本进行了更新。
- **2024年9月9日：** 针对第一赛季毕业配装列表进行了更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 针对10.2.5版本进行了审查，转向了针对更高装备等级的推荐。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行更新，强烈建议不要使用永恒印记。
- **2023年5月1日：** 已更新至10.1补丁及新增消耗品。
- **2023年3月24日：** 已根据原始宝石的在线修复更新。
- **2023年3月22日：** 已更新以纳入原始石的增益效果。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的 增强 萨满祭司 攻克大秘境地下城的技巧和建议。

1.

### 增强 萨满祭司 在 至暗之夜 第2赛季的大秘境

在本指南中，我们将介绍如何在大秘境地下城中充分发挥你的 增强 萨满祭司 的实力，包括构建角色天赋的最佳方式、你需要了解的任何循环变化，以及在每个地下城中表现出色的技巧和窍门。

如果你不熟悉大秘境及其相关的一般机制，你可以在下面我们专门的大秘境页面上了解更多信息。你也可以在我们的层级列表页面上了解更多关于大秘境环境的内容。

增强 在第2赛季中悄然保持着大秘境的稳固选择，虽然其灵活性较上赛季有所下降，但在大多数钥石等级下仍能独当一面。虽然它不是突出的主流表现者，但在所有目标数量下都持续强大，并且在游玩
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 时每两分钟带来强力爆发。内置的波动性使其略有拖累，但良好的操作可以部分减轻其影响。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 另一方面，图腾祭司 在当前的大秘境环境中举步维艰，虽然其1分钟的爆发周期很强，但即使经过整个赛季的调整，它仍然无法跟上。

1.

### 最佳大秘境天赋配置

两个 增强 英雄天赋树都具备构建扎实大秘境玩法的相同标志，但第2赛季确立了 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 是仅因数值调整而应选择的天赋树。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 可用，但其数值落后。

### **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者**    推荐构筑

2.1.

#### 最佳 增强 大秘境构筑 - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 构筑非常注重 [[spell:187880]] 循环，旨在尽可能频繁且高效地消耗以触发 [[spell:454009]]。其常规消耗技能 [[spell:188443]] 在较低目标数量下也能持续造成不错的伤害，通过 [[spell:455123]] 施加的 [[spell:210689]] 得到极大提升。这些通过 [[spell:289874]] 施加，可保持全程覆盖，弥补了 [[spell:187874]] 伤害分摊损失的部分优先目标伤害。

其爆发集中在其2分钟冷却技能 [[spell:114051]] 中，产生大量资源并通过 [[spell:384444]] 消耗。伴随而来的是循环资源时随机触发的 [[spell:384352]]，不过其不稳定性需要适应。

2.1.1.

##### 天赋更换选项

关于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 的天赋替换极为有限，因为该构筑已经选择了天赋树上几乎所有有吸引力的选项。几点简要说明：

- 虽然 [[spell:1218047]] 天赋叶子在第1赛季很有用，但新的4件套锁定了 [[spell:1252373]] 的最后一点。同样，[[spell:333974]] 是为了利用2件套而锁定的选择。
- 虽然我们在至暗之夜天赋树中的控制选项仍然有些有限，但我们强烈建议始终点出[[spell:265046]]的两点。其他特定用途的天赋，如[[spell:370]]、[[spell:383013]]和[[spell:51886]]，应根据每个副本逐一进行调整。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 群体AOE/大秘境 - 风暴使者
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2gFYGGawCAzyMmxYZxYjZmtxyMzMzYswMAAzwYmhRgZGMYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbwCMDDNYBgZZGzYssYsxMz2YZmZmZMWYGAgZYMzwIwMDGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRTDsFoAzzrsrzYBK1KROB-CDEOXZBFNRVWYdgjAMQShLPeKKbT4EB-AAAA-OUaIawIMsEAEpA-
```

:::

### **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司**    备选构筑

2.2.

#### 增强 大秘境备选构筑 - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司

虽然其在第2赛季的力量大幅减弱，但它仍然拥有非常适合大秘境的工具组。[[spell:444995]] 和 [[spell:384352]] 每分钟提供强力爆发的组合很有价值，而有了 [[spell:197214]] 和 [[spell:1218047]]，它总是拥有 <em>东西</em> 用于每一波。然而，由于 [[spell:187874]] 分摊导致的优先目标伤害损失， <em>和</em>
以及冷却之外普遍较弱的持续输出，确实限制了它在第2赛季的上限。不幸的是，当前4件套效果给天赋树带来的全局冷却压力只会加剧这一问题。

2.2.1.

##### 天赋更换选项

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司的构筑相对固定——尤其是考虑到新套装——所以调整空间有限：

- 天赋树中间有一个浮动点数，考虑到第2赛季装备上大量的暴击属性，它 <em>通常</em> 最好投入到[[spell:1251026]]中，不过[[spell:334046]]也是一个选择。
- 在职业天赋树上，我们强烈建议点出[[spell:265046]]的两点，以将[[spell:192058]]的冷却时间缩短至40秒。不过这两点都很灵活——可以根据副本需要随时切换以提供关键的功能性效果。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司可调整的灵活点数较少，因为[[spell:108287]]和[[spell:382201]]都能提供有用的便利性改进。不过，如果你需要超越标准的功能性需求，或者迫切需要从[[spell:337974]]获得更多的自我治疗，可以放弃这些点数。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 大秘境 - 图腾祭司
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzMjZmZmZmZmZGzAAAAAAAAAALwGMjFN2GAzA2AYWmxMGLLGbMzsNWm5BmZGsMmBAAYMmRMzAMYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcQAAAAAAAAAAAAAAAAAAAAAAMzMzMjZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZAbAMLzYGjlFjNmZ2GLz8AzMDWGzAAAMGzImZAGMGA"
}
```
:::

:::details 来源计算器编码
```
#HE-BGQaiky24MFEUMdRrFoAzzbsEdB1uuTjKROB-CDEHOXZBGGNWjAMQRVgPSaiKKLUJFT-AAAA-Jgko0AIowgxRmF-
```

:::

1.

### 地下城天赋切换速查表

若想快速查阅你的可选 增强 效能天赋的额外用途，请使用下方工具选择一个地下城。下方将高亮显示相关选择，以及它们所针对的机制。

<table>&#10;<tr>&#10;<th colspan="2">地下城</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></td>&#10;</tr>&#10;</table>

根据上述选择，以下职业天赋有额外用途：

![Cleanse Spirit Not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/decurse.jpg>)**适用条件：纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；密谋小径（未启用）；塞塔里斯神庙（未启用）。**

![Cleanse Spirit Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/decurse.jpg>)**适用条件：纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；塞塔里斯神庙（启用）。**

‌

![Purge not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/purge.jpg>)**适用条件：纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；密谋小径（未启用）；红玉新生法池（未启用）。**

![Purge Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/purge.jpg>)**适用条件：纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；红玉新生法池（启用）。**

‌

![Spirit Walk not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/spirit_walk.jpg>)**适用条件：毒牙祭坛（未启用）；Blinding Vale（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；红玉新生法池（未启用）；虚空之痕竞技场（未启用）。**

![Spirit Walk Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/spirit_walk.jpg>)**适用条件：毒牙祭坛（启用）；Blinding Vale（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）；虚空之痕竞技场（启用）。**

‌

![Tremor Totem not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/tremor.jpg>)**适用条件：诸王之眠（未启用）；虚空之痕竞技场（未启用）。**

![Tremor Totem Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/tremor.jpg>)**适用条件：诸王之眠（启用）；虚空之痕竞技场（启用）。**

‌

![Poison Cleansing Not Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/pct.jpg>)**适用条件：毒牙祭坛（未启用）；Blinding Vale（未启用）；纳洛拉克的洞穴（未启用）；密谋小径（未启用）；诸王之眠（未启用）；塞塔里斯神庙（未启用）；虚空之痕竞技场（未启用）。**

![Poison Cleansing Talented](<https://static.icy-veins.com/images/wow/classes/shaman/icons/pct.jpg>)**适用条件：毒牙祭坛（启用）；Blinding Vale（启用）；纳洛拉克的洞穴（启用）；密谋小径（启用）；诸王之眠（启用）；塞塔里斯神庙（启用）；虚空之痕竞技场（启用）。**

- **适用条件：毒牙祭坛（启用）。** [[spell:58875]] 与 [[spell:462820]] 的用途：
  
  
  
  
  - 清除 [[spell:1296069]]，在 **拉维** 首领战斗中。
  - 从 [[spell:1310974]] 中清除 **扭缠盘蛇**.
  - 从 [[spell:1294569]] 中清除 **双牙折磨者**.
- **适用条件：毒牙祭坛（启用）。** [[spell:383013]] 的用途：
  
  
  
  
  - 驱散 [[spell:1307571]]，来自 **高级进化者**.
  - 驱散 [[spell:1307567]]，来自 **乌拉特克的选民**.
- **适用条件：Blinding Vale（启用）。** [[spell:58875]] 与 [[spell:462820]] 的用途：
  
  
  
  
  - 从 [[spell:1238084]] 中清除 **鞭笞者** 如果你在近战中被击中。
- **适用条件：Blinding Vale（启用）。** [[spell:383013]] 的用途：
  
  
  
  
  - 驱散 [[spell:1250937]]，来自 **土豆蟾蜍女族长**.
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:51886]] 的用途：
  
  
  
  
  - 驱散由召唤的雕像施加的 [[spell:1238760]] **猎人之魂**.
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:370]] 的用途：
  
  
  
  
  - 驱散 [[spell:1297696]]，来源： **地语看护者**.
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:58875]] 与 [[spell:462820]] 的用途：
  
  
  
  
  - 从 [[spell:1309919]] 中清除 **严寒殴斗者**.
  - **仅限 [[spell:58875]] -** 从 [[spell:1241463]] 中清除 **天神下凡之决心**.
  - **仅限 [[spell:58875]] -** 从失败的 [[spell:1263590]] 中清除 **碎霜** 站位中清除。
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:383013]] 的用途：
  
  
  
  
  - 在 [[spell:1234233]] 期间驱散 **囤宝狂人** 首领战中。
- **适用条件：诸王之眠（启用）。** [[spell:51886]] 的用途：
  
  
  
  
  - 驱散 [[spell:269972]]，由施放 **复生巫师**.
  - 驱散 [[spell:270492]]，由施放 **幻影妖术牧师**.
- **适用条件：诸王之眠（启用）。** [[spell:370]] 的用途：
  
  
  
  
  - 驱散 [[spell:269935]] 的激活效果，来源： **祖尔的爪牙**.
  - 驱散 [[spell:1296671]] 的施加效果，来源： **卫队长阿图**.
  - 驱散 [[spell:270901]]，来源： **总管姆巴拉**.
- **适用条件：诸王之眠（启用）。** [[spell:58875]] 与 [[spell:462820]] 的用途：
  
  
  
  
  - 从 [[spell:1294815]] 中清除 **复生巫师**.
  - 清除由施加的 [[spell:106823]] **帕特拉女王**.
  - 清除由施加的 [[spell:271563]] **防腐液**.
  - 清除由施加的 [[spell:12548]] **幽灵萨满祭司**.
- **适用条件：诸王之眠（启用）。** [[spell:8143]] 的用途：
  
  
  
  
  - 驱散 [[spell:273434]] 的施放，来源： **祖尔的爪牙** 如果它们成功击中目标。
  - 驱散 [[spell:269369]] 的施放，来源： **莱班** 在 **达萨** 首领战中。
- **适用条件：诸王之眠（启用）。** [[spell:383013]] 的用途：
  
  
  
  
  - 驱散 [[spell:106823]]，来自 **帕特拉女王**.
  - 驱散 [[spell:271563]]，来自 **防腐液**.
  - 在 [[spell:267273]] 期间驱散 **部族议会** 首领战中。
- **适用条件：密谋小径（启用）。** [[spell:51886]] 的用途：
  
  
  
  
  - 驱散由施加的 [[spell:1217973]] **被腐化的术士**.
- **适用条件：密谋小径（启用）。** [[spell:370]] 的用途：
  
  
  
  
  - 驱散 [[spell:1229433]] 的施加效果，来源： **恶棍法师**.
- **适用条件：密谋小径（启用）。** [[spell:383013]] 的用途：
  
  
  
  
  - 驱散由施加的 [[spell:474515]] **街头潜行者**.
  - 在 [[spell:1222795]] 期间驱散 **赞恩·刃悲** 首领战中。
- **适用条件：红玉新生法池（启用）。** [[spell:370]] 的用途：
  
  
  
  
  - 驱散 [[spell:373973]] 的施加效果，来源： **灰烬先知燃鞭者** 在低血量时。
  - 驱散 [[spell:391031]] 的激活效果，来源： **原始雷云**.
- **适用条件：红玉新生法池（启用）。** [[spell:58875]] 与 [[spell:462820]] 的用途：
  
  
  
  
  - 从 [[spell:373803]] 中清除 **灌能雏龙** 如果你在近战中被击中。
- **适用条件：塞塔里斯神庙（启用）。** [[spell:51886]] 的用途：
  
  
  
  
  - 驱散 [[spell:1293307]]，由施放 **背信的征服者**.
- **适用条件：塞塔里斯神庙（启用）。** [[spell:383013]] 的用途：
  
  
  
  
  - 驱散由施加的 [[spell:1308100]] **蔽影尖牙**.
  - 驱散由施加的 [[spell:1308148]] **剧毒蝰蛇**.
  - 在 [[spell:267027]] 期间驱散 **米利克萨** 首领战中。
- **适用条件：虚空之痕竞技场（启用）。** [[spell:58875]] 与 [[spell:462820]] 的用途：
  
  
  
  
  - 在 [[spell:1263982]] 层数中清除 **煞戎努斯** 首领战斗中。
  - 从 [[spell:1249621]] 中清除 **愤怒的克洛斯克**.
- **适用条件：虚空之痕竞技场（启用）。** [[spell:8143]] 的用途：
  
  
  
  
  - 驱散[[spell:1233398]]，如果来自 **杀戮尖啸者** 的施法完成。
- **适用条件：虚空之痕竞技场（启用）。** [[spell:383013]] 的用途：
  
  
  
  
  - 驱散 [[spell:1289265]]，由施放 **暴躁的虚空镰**.
  - 在 [[spell:1226120]] 期间驱散 **阿特洛苏斯** 首领战中。

1.

### 功能技能与能力

本节介绍了 增强 在大秘境中可以利用的关键天赋和技能。

### 控制

4.1.

#### 打断与控制

增强 拥有几种打断敌方施法的工具。由于其使用场景不同，我们将它们分为单体和范围两种选项。

4.1.1.

##### 单体控制

- **[[spell:57994]] -** 你的打断技能，也是所有职业中最好的打断技能之一。既是远程又拥有如此短的冷却时间是一个巨大的优势，让你能够比平常更频繁地打断目标。你应该主动去打断敌方的施法；让打断冷却时间更长的职业去处理较少出现的威胁，或留作紧急情况使用。在开始地下城之前，请与你的队伍协调好这一点。
- **[[spell:51514]] -** 你的硬控制技能，让你在拉怪开始前锁定一个危险的敌人一分钟。请注意伤害会打破这个效果，所以你的坦克需要将他们拉走。这也可以作为战斗中的最后手段来打断施法，但所需的时间通常使其很难正确命中。此外，在被控制时，小怪 **仍然会将你** 和队友视为仇恨目标，因此不能像其他一些工具那样用来跳怪。

4.1.2.

##### 范围群体控制

- **[[spell:192058]] -** 你的范围眩晕工具，锁定一群敌人3秒。这在大型拉怪中通常特别有用，让坦克在敌人开始施法前建立仇恨并稳定局面。它还有额外的方式将冷却时间降至基础的1分钟以下：
  
  
  
  
  - [[spell:265046]] 每点减少10秒冷却时间，共计减少20秒。
  - [[spell:381867]] 额外减少5秒冷却时间。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 拥有 [[spell:445027]]，当成功眩晕任何目标时减少5秒冷却时间。
  
  
  
  
  请始终记住，2秒的起手时间要求你必须更加注意敌人何时 <em>即将</em> 施法，因为反应式使用通常为时已晚。
- **[[spell:2484]]** <em>（配合 [[spell:51485]]）</em> - 召唤一个图腾将敌人定身8秒，使其无法移动，并在效果结束后减速。对于某些机制来说这可能非常有用。

### 防御与辅助治疗

4.2.

#### 防御和辅助治疗工具

作为一个混合职业，萨满祭司 拥有一些可以帮助你和你的队伍存活的工具。其防御选项的可用频率低于许多其他职业，但它拥有相当多的被动防御。这意味着在游玩 增强 时，应对频繁的致命攻击往往需要更多的规划。我们将这些技能分为两类：

4.2.1.

##### 防御

在大秘境中存活极其重要，而且往往当治疗者忙于在别处救火时，你可能需要为自己的生命负责。我们应对糟糕局面的关键工具包括：

- **[[spell:108271]] -** 你的个人防御技能，提供40%的伤害减免，始终配合 [[spell:381647]] 以降低冷却时间。用于在原本致命的机制中存活。
- **[[spell:198103]] -** 冷却时间为3分钟，持续30秒，嘲讽附近的敌人以减轻坦克的压力。不过通常我们使用 [[spell:1279819]]，它移除嘲讽效果，作为交换在激活期间提供15%的最大生命值加成。
- **[[spell:355630]] -** 在成功使用 [[spell:57994]] 打断后，12秒内将你受到的所有魔法伤害降低15%。考虑到我们在其他方面缺乏工具，这极其强大，并强烈鼓励你尽可能频繁地打断。
- **[[spell:260878]] -** 在 [[spell:2645]] 期间叠加，提供最高20%的伤害减免。这会阻止你造成伤害，但由于没有冷却时间，它始终可以作为备用手段。
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 -** 还拥有 [[spell:454027]]，通过 [[spell:192106]] 提供3%的伤害减免。
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 -** 在有激活的图腾时，每30秒触发 [[spell:445031]]，提供一个非常小的吸收护盾。

增强 在 至暗之夜 中被动生存能力相对较强，但如果一场战斗需要在关键时刻进行主动防御，当这种情况过于频繁时可能会力不从心。了解致命伤害何时到来，并制定应对计划是一项重要的技能——与知道何时 <em>不需要</em> 使用它同样重要，你可以通过自我治疗来协助你的治疗者。

4.2.2.

##### 辅助治疗

虽然治疗不是你的主要职责，但我们在危急情况下确实有一些工具来帮助队伍。消耗 [[spell:187880]] 会触发一种不同的增益效果的层数 - [[spell:384143]]。这些层数会将漩涡武器的相同收益赋予你的下一个 [[spell:8004]] 和 [[spell:1064]]，可用于自我维持或为队友进行应急治疗。除此之外，还有一些较小的工具可用：

- [[spell:5394]] 是一个非常小众的可选选择，提供少量的应急治疗。[[spell:462368]] 也提供少量的伤害减免，但非常不可靠。
- [[spell:974]] 和 [[spell:383010]] 在受到伤害时为我们提供一些被动治疗。强烈建议将其与 [[spell:1217622]] 搭配使用。这也让你可以在副本开始时为第二名玩家（通常是你的坦克）施加大地之盾。
- [[spell:337974]] 也经常被选取，以通过 [[spell:8004]] 提升我们的自我治疗能力，不过如果需要额外的效能，在天赋树上点到它会有一些成本。

作为 增强 萨满祭司，主动使用治疗工具是一项有效的技能。虽然这不完全是你的责任，但你应该注意队伍何时不稳定，以便至少让自己保持健康。

[[spell:454372]] 用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 确实也能为你的 [[spell:8004]] 提供更多效果，前提是你能高效地循环使用 [[spell:454009]]。但请注意，这会牺牲从 [[spell:454027]] 获得的被动伤害减免。

### 其他功能

4.3.

#### 其他 增强 效能

除了大秘境中更传统的工具外，萨满祭司 还有一些职业专属的额外工具。

4.3.1.

##### 进攻性/防御性驱散

增强 拥有不少针对不同情况的驱散工具。这些都位于职业天赋树上，而职业天赋树也非常灵活，因此你可以根据地下城调整你的配置。选项包括：

- [[spell:370]] — 进攻性驱散
- [[spell:51886]] — 盟友诅咒驱散
- [[spell:383013]] — 全队中毒驱散
- [[spell:8143]] — 全队 恐惧 驱散
- [[spell:462820]] — 全队定身移除

能够在这么多选项之间切换（或全部同时使用）通常意味着你可以为每个地下城准备专属的工具。记得换上合适的选择并使用它们！

4.3.2.

##### 其他功能

**[[spell:462854]] -** 你的团队增益，提供额外的精通，并使队伍成员的近战自动攻击有20%的几率额外攻击一次。这是所有专精都希望拥有的更强大（也更通用）的增益之一，因此这让 萨满祭司 变得令人向往。

**[[spell:2825]] / [[spell:32182]] -** 每个队伍都希望至少拥有这些效果之一，与 [[spell:80353]] / [[spell:390386]] / [[spell:264667]] 共享。与你的队伍协调，确定每10分钟最佳的使用时机。

**[[spell:192077]] -** 全队移动工具，配合刷新可持续长达20秒。适合在拉怪之间移动或躲避机制，并且配合 [[spell:462820]] 还有全范围移除定身效果的额外好处。

**[[spell:20608]] -** 允许你在死亡后复活，包括在战斗中，无视战复计数。如果你在没有可用防御技能的情况下被致命机制命中，这尤其有帮助。

**[[spell:198103]] -** 一个应急工具，在坦克死亡或难以处理一群怪时很有用。只有在你 <em>没有</em>
点出 [[spell:1279819]] 时才会嘲讽，任何配置都不应跳过这个天赋，因为它是我们依赖的重要防御工具。由于一些有问题的AI，它也很少移动，所以如果它卡在糟糕的位置，你可能需要取消它。

**[[spell:381930]] -** 可以在整个地下城过程中为你的治疗者提供一些额外的法力回复，并且可以在职业天赋树上轻松点出。由于其价值较低，加上在相同点数上竞争的其他效能工具，在大秘境配置中很难将其纳入。

1.

### 应对词缀

本节包含应对大秘境第2赛季每周萨拉塔斯主题词缀的快速提示。

### 词缀：升腾

5.1.

#### 增强 萨满祭司 的升华词缀管理

**萨拉塔斯的交易：升腾** 会定期生成一波波的光球，需要以某种方式对其进行群体控制，阻止它们完成施法。每成功阻止一个光球，团队就会获得急速加成，因此处理它们是高度优先事项。

增强 只有 [[spell:192058]] 可用作范围打断来应对这些，这意味着在这些周最好不要太激进地使用它。任何漏网之鱼也可以在它们即将完成施法时，用不在公共冷却时间内的 [[spell:57994]] 摧毁，或者从远处手动 [[spell:370]]。

### 词缀：虚缚

5.2.

#### 增强 萨满祭司 的虚空之缚词缀管理

**萨拉塔斯的交易：虚缚** 会周期性地召唤一个大型的虚空大使，它将开始施放[[spell:462508]]。这个敌人 **必须** 在施法完成前被击杀以阻止它，否则它会为附近的敌人提供显著的减伤。如果成功阻止，队伍将获得大量的全能和冷却缩减。

这需要快速击杀。理想情况下，准备好短时间、高爆发的效果来应对这些刷新。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司 拥有 [[spell:197214]]，但由于
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 有点不可预测，请确保你快速切换目标以帮助队伍。

### 词缀：脉冲星

5.3.

#### 增强 萨满祭司 的脉冲星词缀管理

**萨拉塔斯的交易：脉冲星** 会生成一个围绕每个玩家旋转的光球，需要由另一名玩家在光球消失前分担。每个光球将为队伍提供4%精通和2%吸血，可叠加，持续30秒。未被分担的光球会增加附近敌人的伤害输出，并降低他们受到的伤害。

增强 没有特定的效能来应对这个，相反你需要注意自己的站位，既要确保其他玩家能吸收绕着你转的光球，又要能够接住附近玩家的光球。

### 词缀：吞噬

5.4.

#### 增强萨满祭司吞噬词缀应对

**萨拉塔斯的交易：吞噬** 会对每名小队成员施加一个减益效果，该效果必须被驱散或通过治疗清除（但请记住 <em>不会</em>
吸收即将到来的治疗）。每驱散一个减益效果都会为队伍提供最大生命值和暴击，可叠加，持续30秒。任何被 <em>非</em>
清除的减益效果都会为附近的敌人恢复大量生命值。

在这些周目中，我们特别推荐使用 [[spell:51886]] 和 [[spell:383013]] 来辅助你的治疗者。[[spell:378075]] 和 [[spell:462820]] 在 至暗之夜 中也能清除该效果，因为该减益新增了一个轻微减速效果。如果你发现团队难以清除这些减益且这些工具不可用，可以使用 [[spell:384143]] 的治疗来辅助。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月7日：** 指出近期的调整并未影响构建推荐。
- **2026年3月16日：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 将构建推荐更改为 图腾祭司。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月28日：** 添加了第三赛季天赋切换速查表。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月28日：** 添加了副本提示。
- **2025年4月21日：** 针对11.1.5版本进行了审查，强调了近期 风暴使者 增强后两个天赋树的接近程度。
- **2025年3月16日：** 将 图腾祭司 天赋树转向以获得更多的单体目标舒适度。
- **2025年3月4日：** 清理了推荐构建，以纳入激涌之灵削弱和赛季发布。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 针对11.0.7版本进行了审查，添加了推荐标记。
- **2024年11月5日：** 更新为 风暴使者 与 图腾祭司 的对比构建，并添加了游戏玩法提示部分。
- **2024年10月21日：** 针对11.0.5版本进行了更新，发布后将需要进一步更新。
- **2024年9月9日：** 已为地心之战第1赛季的发布进行更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月21日：** 针对10.2.6版本进行了审查，添加了关于湮灭余烬的说明。
- **2024年1月15日：** 针对10.2.5版本进行了审查，润色了一些部分并将防御性饰品作为选项添加。
- **2023年11月9日：** 已为10.2版本重构并更新。
- **2023年11月6日：** 已更新大秘境中心的链接。
- **2023年9月4日：** 为10.1.7补丁进行了一些结构调整，将慰藉之炽怒靴作为一项制造选项加入。
- **2023年7月20日：** 在装备章节中为冲层加入了关于孢子披风的说明。
- **2023年7月10日：** 已针对10.1.5补丁进行更新，风暴流派改为使用风暴顺劈。
- **2023年5月1日：** 已更新至10.1补丁及第2赛季新流派，以及初始套装起手手法。
- **2023年3月20日：** 已审阅并为10.0.7补丁添加了小幅改进。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一些实用的宏和插件，以便在魔兽世界 12.1.5 补丁中使用你的 增强 萨满祭司 时更加轻松。

1.

### 最佳宏

欢迎来到我们的插件和宏页面。在这里，我们将介绍一些有用的插件，你可以通过更具信息量的界面来提升游戏体验，同时提供一些常用的 增强 萨满祭司 宏。

1.

### 增强 萨满祭司 宏

宏命令可以通过游戏内的/macro命令访问，允许你创建在按下快捷键时执行的小型脚本。这对于将多个动作组合在一起非常有用，一个常见的例子是将不占用GCD的饰品与冷却技能组合在一次按键中使用。

以下是一些 增强 专属选项，有助于更顺畅地执行一些重要的机制。

2.1.

#### 焦点目标施法宏

我们有几个法术可以从使用焦点目标中受益，让你在对主要目标进行伤害攻击的同时仍能专注于它。将下面宏中的风剪替换为你想要的法术名称：

#### 焦点打断

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] 风剪
```

适合与此配合使用的法术包括 [[spell:51886]]、[[spell:51514]]、[[spell:370]] 和 [[spell:57994]]。

2.2.

#### 鼠标悬停宏

类似地，将鼠标悬停在目标上并施放法术而不从你的主要目标上移开也是有益的，尤其是在使用特定天赋构建时。将下面宏中的净化灵体替换为法术名称：

#### 鼠标指向驱散

```wow-macro
#showtooltip
/stopcasting
/cast [target=mouseover] 净化灵魂
```

如果目标更加动态，这还有其他用途，省去了选择目标的操作。[[spell:51886]] 从中受益，尤其是在使用团队/小队框架时。

2.3.

#### 自我施放 治疗之涌

这将始终优先对自己施放 [[spell:8004]]，以实现可靠的自我治疗：

#### 自我施放 治疗之涌

```wow-macro
#showtooltip
/stopcasting
/cast [@player] 治疗之涌
```

2.4.

#### 图腾放置宏

对于任何带有目标圈的图腾，有两种宏选项可以更快地放下它。第一种会立即在你脚下放下（将以下宏中的涌动图腾替换为你想要的图腾名称）。这在 **尤其是** 时很有用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司:

#### 在玩家处放下图腾

```wow-macro
#showtooltip
/cast [@player] 涌动图腾
```

或者在你当前光标位置施放：

#### 在光标处放下图腾

```wow-macro
#showtooltip
/cast [@cursor] 涌动图腾
```

这可用于 [[spell:192077]]、[[spell:51485]] 甚至 [[spell:108287]]。

2.5.

#### ⟳ 图腾投射 宏

为了高效地随身移动我们的图腾，由于 [[spell:108287]] 不占用全局冷却时间，你可以将其绑定到一个轮转技能中。一个常见的绑定技能是 [[spell:17364]]，但任何按钮都可以使用以下宏：

#### 自动 图腾投射

```wow-macro
#showtooltip
/cast [@player] 图腾投射
/cast 风暴打击
```

这对功能性图腾有一些缺点，并且让你对放置位置的直接控制减少，因为 [[spell:108287]] 将始终处于冷却状态。这更像是一个冷门选项，适合那些根本不想费心拖动 [[spell:444995]] 的人。

2.5.1.

##### 涌动图腾重新定位

或者，你可以在游玩时使用以下宏 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) 图腾祭司，它会反复使用 [[spell:444995]] 内置的重新定位功能，而无需浪费 [[spell:108287]] 的冷却时间：

#### 涌动图腾重新定位

```wow-macro
#showtooltip 熔岩猛击
/cast 熔岩猛击
/cast 涌动图腾
```

你可以将 [[spell:60103]] 替换为 [[spell:17364]]，或者将两者都绑定到宏中，以确保它留在附近。

1.

### 最佳插件

随着 至暗之夜 对插件功能带来了重大变革，本节将在第一个赛季期间随着更强大的插件的开发而逐步完善。

3.1.

#### 萨满祭司 通用插件

你的大部分界面需求可以通过至暗之夜中新的暴风雪界面选项在一定程度上得到满足，但如果你想要一些额外的自定义，以下是一些热门选择。

3.1.1.

##### 首领模块插件：Deadly Boss Mods 或 Bigwigs

首领模块插件会警告你首领的技能，并就如何处理某些机制提供实时建议。我们强烈建议你安装这样一个插件。在Icy Veins，我们主要使用
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>)，这是最受欢迎的首领模块插件。一个不错的替代选择是
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

3.2.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) 是对默认用户界面的完整替代。它包含了你正常发挥所需的几乎所有功能：动作条、单位框体、冷却计时器、触发提示等。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 已针对第1赛季发布进行审查。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年11月5日：** 添加了Weakauras部分。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 针对10.2.5版本进行了审查，添加了大地 元素 取消方法。
- **2023年11月6日：** 已针对10.2补丁进行审阅，无需更改。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行审阅，无需更改。
- **2023年4月29日：** 已根据10.1补丁审查，无需更改。
- **2023年3月20日：** 添加了更多常用宏，并针对10.0.7补丁进行了审阅。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
