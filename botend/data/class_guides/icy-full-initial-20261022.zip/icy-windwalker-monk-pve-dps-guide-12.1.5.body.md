## 专精概览

欢迎来到我们的 踏风 武僧 指南，适用于魔兽世界 12.1.5 版本补丁。在这里，你将学习如何在团队副本和大秘境中扮演 踏风 武僧：从最基础到最大化你的 DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

踏风大秘境资源

[全新！顶级 踏风 天赋构筑](<https://raider.io/specs/windwalker-monk/talents>)

[顶级 踏风 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/monk/windwalker>)

[踏风大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=monk--windwalker>)

[热门 踏风 队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=monk--windwalker>)

1.

### 踏风 武僧 概述

踏风专精是一个近战输出专精，专注于使用能量，将其转化为真气，并使用真气来造成伤害。踏风是一个机动性极强的专精，曾在团队副本、大秘境和 PvP 的最高水平中占据一席之地，尽管很少同时在多个领域都处于顶尖位置。

Dependable Damage

踏风的伤害输出模式会根据你选择的英雄天赋而改变。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派

带来更稳定且具备强大AOE伤害能力的伤害构成，而

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师

则更侧重于爆发伤害和低目标数的顺劈。这提供了一些不错的灵活性，由于两者的原始DPS输出相当有竞争力，两个选项在不同情况下都非常有用。

Reliable Raider

踏风的伤害输出模式和高机动性使其非常适合团队副本。踏风可以灵活调整以适应不同的冷却周期，并在单体和 AoE 情况之间轻松切换。虽然通常不是最高 DPS 的专精，但 踏风的输出应该足够强大，值得在所有团队副本难度中带上。踏风的主要缺点是缺乏应对持续伤害的减伤手段，以及缺乏免疫或其他在团队副本中有用的功能性技能。

Strong but Squishy

12.1版本带来了一种向更侧重AOE的游戏风格的转变，最大化利用

[[spell:101546]]

在单体、顺劈和 AoE 情况下。这可能使 踏风成为游戏中最强的 AoE 伤害专精之一。然而，生存能力方面持续的挣扎可能使其无法完全达到最高大秘境的“主流”水平。

Non-Unique Utility

踏风在功能性方面已经挣扎了一段时间。从表面上看，

[[spell:116844]]

是游戏中最好的区域封锁法术之一，

[[spell:119381]]

是一个可靠的群体眩晕，

[[spell:115078]]

可以作为激怒驱散或长期控制，该专精可以通过

[[spell:115450]]

驱散中毒和疾病效果，并且它还带有

[[spell:8647]]

。然而，这些工具中的大多数适用于所有武僧，而不仅仅是 踏风。这使得很难仅“为了”功能性而带上 踏风，除非它能提供与之匹配的 DPS，或者另外两个 武僧专精表现更差。

依赖防御

踏风只有 2 个防御技能，包括

[[spell:1243287]]

已被转化为一个功能，作为

[[spell:388917]]

的一部分，而不是作为独立的防御技能。

[[spell:388917]]

和

[[spell:122470]]

可以轮换使用以帮助减轻大型伤害攻击。踏风还拥有近乎无与伦比的机动性，使其能够比大多数其他专精更好地脱离危险情况。踏风在防御性冷却技能之外缺乏自我治疗和伤害减免，即使在 12.1 版本中对此进行了增强，这也使其评分无法更高。

卓越的机动性

很难找到一个专精或职业能比 踏风 移动得更快、更远。多次充能的

[[spell:109132]]

，结合

[[spell:449582]]

,

[[spell:116841]]

，以及

[[spell:101545]]

，让 踏风 在战场上移动得比几乎任何人都好。

[[spell:101643]]

还使 踏风 能够瞬间回到某个位置以躲避某些机制，或者 simply 回去继续输出伤害。

1.

### 踏风 武僧 在 至暗之夜

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5 版本补丁除了来自的额外装备外，没有对 踏风 武僧 进行任何有意义的改动 [Kith'ix](<https://www.wowhead.com/npc=267861>) 和提升物品等级的毒液核心带来的额外装备。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

补丁的主要重点是2个新的终局内容，一个面向团队副本，一个面向 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。请务必查看关于新的基斯提克斯团队副本战斗的信息，以及令人兴奋的全新迷宫巨型地下堡！

2.3.

#### 职业改动

踏风在12.1.5补丁中没有改动。但是，我们关于总体和团本装备推荐的内容将会有改动
[装备](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>) 页面。我们还提供了一份高价值物品清单，供你决定如何花费你的第一批[[item:280562]]。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/monk_ability_fistoffury.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 12.1版本改动

第2赛季终于到来，伴随着将于8月18日推出的全新PvE和PvP终局内容。暴风雪对开放世界、玩家界面和现有系统发布了大量改动。

2.5.

#### 职业改动

踏风从12.0.7到12.1进行了许多职业改动。虽然其中大多数对 <em>如何</em> 该专精的玩法产生重大影响，但它确实将一些伤害转移到了不同的来源，并从单体转移到了群体。它还将 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师相比之前在至暗之夜中的表现处于强得多的位置。

- 近战自动攻击伤害提高30%。
- [[spell:1272694]]伤害降低30%。
- [[spell:100784]]伤害提高50%。
- [[spell:100780]]伤害提高200%。
- [[spell:451823]]伤害提高30%。
- [[spell:1272678]]现在在[[spell:1249625]]期间使伤害提高5%（原为10%）。
- [[spell:1261703]]提高5%/10%的暴击伤害（从10%/20%下调）。
- [[spell:116670]]治疗量提高25%。
- [[spell:1266719]]治疗量提高25%。
- [[spell:322101]]治疗量提高25%。
- [[spell:443028]]伤害降低25%。
- [[spell:442743]]使[[spell:113656]]和[[spell:101546]]的伤害提高30%（原为10%）。
- [[spell:121817]]提高5%耐力。
- [[spell:388664]]从3%伤害减免提高到7%伤害减免。
- [[spell:101546]]增强38%。
- [[spell:152175]]增强30%。
- [[spell:392979]]增强95%。

:::

2.6.

#### 至暗之夜中踏风 武僧的改动

在至暗之夜中，踏风武僧有大量改动，既有专精本身的改动，也有整个武僧职业的改动。这些改动的主要目的是削减过多的增益和机制——这些增益和机制你可以监控但基本会忽略——并将伤害移回基础技能中。

由于这些改动，许多技能被精简或重新设计，我们在下面列出了影响最大的改动，重点说明它们如何影响你的常规游戏体验，与你可能已经习惯的踏风版本相比有何不同。不过请放心，输出循环的游戏流程仍然与踏风多年来所依赖的流程非常相似，因此即使你在长时间休息后带着至暗之夜回归游戏，也不会感到迷茫！

2.6.1.

##### 顶峰天赋：猛虎之眼酒

:::details
[[spell:1261703]]是新的巅峰天赋节点，是对踏风原始伤害冷却技能的致敬，尽管主要只是名字上的致敬。正如技能说明所示，在战斗中你会积累层数，然后在施放[[spell:1249625]]时消耗这些层数来提高你的暴击几率。在非战斗状态下，它会非常快地重新叠满至10层，或者如果你已经处于10层或以上，它会保持层数。

通常你不需要围绕这个增益来打，因为你应该自然地足够频繁地使用[[spell:1249625]]，而不需要担心20层的上限。这个增益影响你思考方式的主要方式是，它降低了连续使用[[spell:1249625]]两次充能的动力，因为第二次使用时层数会非常少。大多数时候，将它们分开使用是合理的选择，但有时你仍然会想连续使用它们。这个天赋可以在更极端的极限优化情况之外被点出并忽略，这些情况可能会随着时间的推移被研究出来。

在第一个天赋点之后，其他三个是被动伤害提升，不会改变任何东西。

:::

2.6.2.

##### 英雄天赋改动

:::details
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师与《地心之战》基本相同，只是增加了[[spell:123904]]作为你需要按下的一个按钮，以便你随后能按[[spell:443028]]。激活[[spell:443294]]也被加入到[[spell:1249625]]中，而不是[[spell:433082]]，这需要一些时间来适应。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派也基本保持不变，但其英雄天赋树的大部分内容已被简化。踏风不再需要追踪你消耗了多少能量来最大化你的[[spell:450615]]，[[spell:1272821]]已被简化，提供可观AoE伤害的暗影增益已被移至与[[spell:1262612]]一起的独立天赋节点。

:::

2.6.3.

##### 循环要点

在大多数情况下，核心玩法和优先级变化很小，设计重点在于削减多余内容而非改变已有内容。因此，总体玩法和按键操作与巨龙时代基本相同，只是需要追踪或忽略的增益效果更少了。

2.6.4.

##### 冷却调整

:::details
踏风最大的改动是[[spell:137639]]被替换为[[spell:1249625]]，[[spell:123904]]被严格移入了 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师天赋树中，[[spell:388661]]提供的大量急速增益已被移除。

[[spell:1249625]]的功能几乎与[[spell:451463]]完全相同，只是它现在是一个你可以使用的冷却技能。因为它有两层充能和可变的冷却时间——可以是60、70、80或90秒——[[spell:1249625]]在你使用冷却技能的频率上提供了极大的灵活性。[[spell:1249625]]可以轻松地在1分钟、90秒、2分钟和3分钟的冷却使用之间切换，只需对天赋进行微调。然而，由于失去了像[[spell:388661]]这样的东西，踏风缺乏了许多人在《地心之战》中习惯的爆发能力。这在大多数专精中是新的常态，但一开始会非常不同。

:::

2.6.5.

##### AOE伤害输出

:::details
随着至暗之夜的改动，踏风的大部分AoE伤害被压缩到[[spell:113656]]和[[spell:433082]]中。[[spell:101546]]与其他技能相比非常弱，即使在AoE中也很少使用。因此，踏风在AoE中可能会相当弱，即使与《地心之战》相比也是如此。

:::

1.

### 武僧踏风基础玩法

踏风 武僧是一个需要同时管理资源和带冷却技能的专精。对我们来说，首要任务是使用[[spell:100780]]将能量转化为真气，以供[[spell:107428]]和[[spell:113656]]等技能使用，同时尽可能减少延迟，并且不要让能量或真气溢出。

踏风获得的资源天然会超过这两个技能所能消耗的量，因此我们需要学会在循环中合理地穿插足够的[[spell:100784]]，以避免真气溢出，但又不能穿插过多，导致你没有足够的真气在[[spell:107428]]和[[spell:113656]]冷却完毕时立即施放。

踏风 武僧的精通[[spell:115636]]要求我们提前做好准备并思考后续几步，因为我们要避免连续使用[[spell:100784]]或[[spell:100780]]，而是要尝试巧妙地将它们穿插在其他技能之间，以获得最大伤害。

为了简化内容，你可以使用这三个主要思路，将踏风 武僧浓缩成更容易理解的内容。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_healthsphere.jpg>)**管理能量和真气**
  
  
  
  
  资源通常是限制你能使用哪些技能以及何时使用的最大因素。你需要确保有足够的真气来施放像[[spell:107428]]和[[spell:113656]]这样伤害最高的技能，同时通过[[spell:100784]]和[[spell:101546]]有策略地消耗多余真气。在整个过程中，你都要避免连续重复使用同一个技能，以便持续从踏风的精通和[[spell:196740]]中获益。
- ![](<https://static.icy-veins.com/images/wow/large_icons/monk_ability_fistoffury.jpg>) **保持技能冷却**
  
  
  
  
  踏风伤害最高的技能都带有冷却时间，限制了你使用它们的频率。你要抓住一切机会使用它们，因此确保在它们冷却完毕时有足够的资源来施放至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_roundhousekick.jpg>) **应对触发效果**
  
  
  
  
  踏风有多个触发效果，可以让你额外施放某些技能。快速对这些触发做出反应，并将它们足够好地穿插到你的操作中，使你仍然能够管理资源并在技能可用时使用它们，正是让踏风每次战斗不完全相同的关键。

1.

### 作为武僧踏风如何提升装备

虽然我们始终建议你通过模拟来获得最佳结果，但我们确实提供了专门的踏风配装页面。我们目前涵盖了第二赛季装备的推荐，帮助你在终局至暗之夜内容发布时有一个良好的开端。在你获取了一些装备后，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已针对12.1.5补丁更新，添加了升腾虚空石部分和Kithix装备。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 针对至暗之夜 12.1.5补丁更新，踏风无变动，新增了新内容的链接。
- **2026年8月25日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 更新了武器附魔建议，将树苗饰品下调至B级。
- **2026年8月25日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔建议。
- **2026年8月25日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 更新了优先级，添加了关于天界通道和至高踩踏的说明。
- **2026年8月11日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 针对至暗之夜 12.1补丁更新，重做了天赋构建。
- **2026年8月11日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已针对12.1补丁更新，新的装备列表和更新的制造与硬币信息。
- **2026年8月11日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 针对至暗之夜 12.1补丁进行审查，无需更改。
- **2026年8月11日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已针对12.1补丁更新，调整为新的治疗药水。
- **2026年8月11日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 针对至暗之夜 12.1补丁进行审查，明确了属性优先级。
- **2026年8月11日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 针对至暗之夜第二赛季更新，更新了天赋构建。
- **2026年8月11日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 针对至暗之夜第二赛季更新，更新了第二赛季套装的输出循环和优先级。
- **2026年8月11日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 针对至暗之夜第二赛季更新，更新了天赋构建。
- **2026年8月11日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 针对至暗之夜 12.1补丁进行审查，无需更改。
- **2026年8月11日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 针对至暗之夜 12.1补丁进行审查和更新。
- **2026年8月11日（本页）：** 针对至暗之夜 12.1补丁更新，新增了补丁改动，移除了S1相关内容。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新，将项链/戒指/腰带添加到总体和团队副本最佳装备列表。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7补丁审查和更新，添加了起手式时间线。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新，添加了关于万法全书的信息。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新和审查。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 添加了制作洛阿戒指的额外选项。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 针对至暗之夜第一赛季进行审查，新增了WDP/SotW不取消宏。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 针对至暗之夜第一赛季进行审查，新增了关于血棘茶的说明。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 针对至暗之夜第一赛季进行审查，将急速移到暴击之上。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 针对至暗之夜第一赛季更新，幸运的是几乎不需要改动
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 更新了优先级和起手式，添加了更多关于选择的细节。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 针对至暗之夜第一赛季进行审查。无需更改。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 针对至暗之夜第一赛季进行审查，无需更改。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 已为至暗之夜第1赛季更新。新增了关于3月17日调整的内容。
- **2026年3月12日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已为至暗之夜第1赛季更新了新内容和结构。
- **2026年3月12日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为 至暗之夜 第1赛季进行了审阅，添加了关于套装的说明。
- **2026年3月12日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月4日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 将美化推荐更新为暗月印记：狩猎。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 为 至暗之夜 发布进行了审阅和更新。将升级内容扩展至90级。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为 至暗之夜 发布进行了审阅和更新，所有装备列表均为全新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为 至暗之夜 发布进行了审阅，添加了“爆发”宏，并更新为新格式。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为 至暗之夜 发布进行了更新，所有附魔和消耗品均为全新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为 至暗之夜 进行了审阅和更新，移除了关于前置补丁的提及。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已为至暗之夜发布更新，采用全新的输出循环格式，并新增了天命者天赋板块。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已为至暗之夜发布更新，新增天赋构建方案和格式。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已为至暗之夜更新，新增猛虎之眼酒天命者天赋。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已为至暗之夜发布更新，新增天命者天赋说明。
- **2026年2月26日（本页）：** 已为至暗之夜发布更新。更新了性能预估并新增了天命者天赋信息。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已为至暗之夜前夕更新并进行了审查，更新了升级天赋和路线。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已为至暗之夜前夕更新并进行了审查，几乎无需改动。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已为至暗之夜前夕进行了审查，将不打断宏更新为较新版本。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已为至暗之夜前夕更新，调整了附魔和宝石推荐。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已为至暗之夜前夕更新并进行了审查，调整了属性优先级。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已为至暗之夜前夕进行了审查，移除了S3相关提及，天赋变更通过包含文件完成。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已为12.0.1从PTR转为正式服更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已为12.0.1从PTR转为正式服更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已为至暗之夜前夕更新并进行了审查，新增了新法术，移除了旧法术。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已为至暗之夜前夕更新并进行了审查，所需改动出乎意料地少。
- **2026年2月10日（本页面）：** 已为至暗之夜前夕更新，采用新格式，并针对新资料片的所有改动进行了更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已为至暗之夜前夕更新并进行了审查，主要是格式变更和新增板块。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已为至暗之夜前夕更新并进行了审查，新增了英雄天赋板块，无需其他改动。
- **2025年12月13日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 修复了升级滑块。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已为11.2.7进行了审查，新增了关于属性上限的常见问题解答。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已为11.2.7进行了审查，新增了几条常见问题解答。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 已为11.2.7补丁更新，将优势与劣势调整为新格式，并新增了指向至暗之夜页面的链接。
- **2025年10月14日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 修正了关于真气（SEF）使用的错别字。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 针对11.2.5进行了审阅，无需更改。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已更新至11.2.5补丁，新增了关于谜之财团筹码的章节，并扩展了装备升级章节。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 针对11.2.5进行了审阅，无需更改。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 针对11.2.5进行了审阅，无需更改。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 针对11.2.5进行了审阅，无需更改。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.5进行了审阅，无需更改。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 针对11.2.5进行了审阅，无需更改。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 针对11.2.5进行了审阅，无需更改。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 针对11.2.5进行了审阅，无需更改
- **2025年10月5日（本页）：** 已更新至11.2.5补丁，新增了关于军团再临混搭模式和加速助推的信息。
- **2025年9月7日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 移除了关于“简单”选择没有套装的说明。无需其他更改。
- **2025年8月21日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 修复了图像块导致天赋和实用技能显示混乱的问题。
- **2025年8月16日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 根据第一周的平衡性调整更新了饰品排名。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 针对11.2补丁进行了审阅，无需实质性更改，但我敢肯定天赋树会出问题。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已更新至11.2补丁，新增了关于莱希裹布的章节，并为第3赛季更新了装备和饰品列表。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 针对11.2补丁进行了审阅，无需实质性更改。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已更新至11.2，新增了新的治疗药水。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 针对11.2补丁进行了审阅，无需更改。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了审阅，无需实质性更改，秘境+提示已注释掉，并将天赋构建拆分开来，尽管它们是相同的。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已更新至11.2，极少更改，全部通过包含项完成。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了审阅，目前无需实质性更改。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 针对11.2补丁进行了审阅，无需实质性更改。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已更新至11.2补丁，无实质性更改。
- **2025年8月4日（本页面）：** 已更新至11.2补丁，新增了关于专精最小化改动的章节。
- **2025年7月1日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 再次修正了升级路线，恢复了英雄天赋顺序。
- **2025年6月22日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 根据戒律牧腰带的平衡性调整进行了更新。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 针对11.1.7补丁进行了审阅，目前没有损坏，因此无需更改。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 针对11.1.7版本更新，新增了关于暗影戒律腰带的章节。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 针对11.1.7版本更新，新增了关于循环辅助的章节。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 针对11.1.7版本更新，新增了关于循环辅助的信息。
- **2025年6月15日（本页）：** 针对11.1.7版本更新，新增了关于循环辅助和暗影戒律腰带的章节。
- **2025年5月22日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 再次更新腐蚀推荐，因为回响虚空效果不佳。
- **2025年5月18日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 更新了腐蚀推荐。
- **2025年5月10日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 完成/重做了迪纳尔章节。
- **2025年4月27日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 新增了大秘境提示。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 针对11.1.5版本进行了审查，删除了“恭喜”章节，我敢肯定升级顺序会因为某些原因出问题。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 针对11.1.5版本进行了更新和审查，在迪纳尔章节中加入了贾斯托戒指，并取消了迪纳尔章节的注释(?）。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 针对11.1.5版本更新，新增了腐蚀章节，以防我们何时能获得它。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 针对11.1.5版本进行了审查，无需更改。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-liberation-of-undermine-raid-guide>)):** 针对11.1.5版本进行了审查，无需更改。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 针对11.1.5版本进行了审查和更新，无需更改。大秘境提示稍后跟进。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 针对11.1.5版本进行了审查，无需更改。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 针对11.1.5版本进行了审查，无需更改。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 针对11.1.5版本进行了更新和审查，为天赋新增了includes。
- **2025年4月21日（本页）：** 针对11.1.5版本更新，无需重大更改，引用了4月14日对踏风的改动。
- **2025年3月24日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 针对饰品调整更新了饰品和毕业列表。
- **2025年3月24日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 针对3月25日的调整改动进行了更新，在天赋配置中加入了额外的天赋选择。
- **2025年3月17日（[解放安德迈页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-liberation-of-undermine-raid-guide>)):** 新增了加里维克斯和其他提示，调整了天赋推荐以支持顺劈。
- **2025年3月16日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 新增了制作流程图。
- **2025年3月6日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 更新了头环宝石推荐。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 针对11.1版本更新，更改了戒指附魔。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 针对11.1版本更新，更改了属性优先级。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为11.1版本更新，暂时注释掉了副本提示，将湮灭换成了脉冲，提供了踏风和天神御身两套天赋配置
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为11.1版本更新，添加了关于引导之风和天神之御窗口的循环信息。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为11.1版本更新，添加了引导之风天赋信息。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为11.1版本更新，添加了切风腿并更改了风之舞。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为11.1版本更新，更新了属性优先级。
- **2025年2月24日（本页面）：** 为11.1版本更新，添加了变更内容并移除了旧章节。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月22日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为每个副本添加了大秘境提示。
- **2024年10月22日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（本页）：** 添加了11.0.5的改动。
- **2024年10月10日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 修复了一个过时的强化符文章节。
- **2024年10月9日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 审查并更新了饰品推荐。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为地心之战第1赛季更新，添加了美化推荐。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月27日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 添加了地下堡天赋配置。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 为地心之战上线审查并更新，进行了细微的格式调整。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为地心之战上线审查并更新，进行了全面重做。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为地心之战上线审查并更新，进行了细微的文字修改。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为地心之战上线审查并更新，更新了所有推荐内容。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为地心之战上线审查并更新，无需更改。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为地心之战上线审查并更新，更改了"包含内容"。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为地心之战上线审查并更新，更改了"包含内容"。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为地心之战上线审查并更新，添加了英雄天赋。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为地心之战上线审查并更新，进行了细微的文字修改。
- **2024年8月21日（本页）：** 为地心之战上线审查并更新，进行了细微的文字修改。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/windwalker-monk-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 为地心之战前夕更新了新的升级路线。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年7月23日（本页面）：** 已更新至地心之战前夕补丁
- **2024年7月17日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/windwalker-monk-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/windwalker-monk-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已更新至10.2.7。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为第4赛季进行了审查，更新了毕业装备列表、套装信息，并添加了铸币相关内容。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为第4赛季进行了审查，无需更改。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了审查，无需更改。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为第4赛季进行了审查，无需更改。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了审查，无需更改。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了审查，移除了关于第3赛季套装奖励的信息。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为第4赛季进行了审查，无需更改。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为第4赛季进行了审查，无需更改。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为第4赛季进行了审查，无需更改。
- **2024年4月22日（本页）：** 为第4赛季进行了审查，添加了关于如何使用铸币的信息。
- **2024年3月28日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 修复了天赋树链接
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为10.2.6补丁进行了审查，无需更改。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为10.2.6补丁进行了审查，无需更改。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为10.2.6补丁进行了审查，无需更改。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为10.2.6补丁进行了审查，无需更改。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为10.2.6补丁进行了审查，无需更改。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为10.2.6补丁进行了审查，无需更改。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为10.2.6补丁进行了审查，无需更改。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为10.2.6补丁进行了审查，无需更改。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为10.2.6补丁进行了审查，无需更改。
- **2024年3月19日（本页面）：** 为10.2.6补丁进行了审查，无需更改。
- **2024年2月14日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 将蓝色丝绒内衬换入最佳装饰推荐中。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年11月30日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 更新了毕业装备列表
- **2023年11月19日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 修复了借用时间武器的链接问题。
- **2023年11月11日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已针对孢子披风削弱进行更新，装饰推荐已重新制作。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为10.2补丁进行了更新和审查，更新了套装信息、毕业装备列表和装饰推荐。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为10.2补丁进行了更新和审查，无需更改。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为10.2补丁进行了更新和审查，更新了附魔推荐。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为10.2补丁进行了更新和审查，更新了天赋推荐。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为10.2补丁进行了更新和审查，更新了天赋推荐。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为10.2补丁进行了更新和审查，更新了优先级和套装信息。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为10.2补丁进行了更新和审查，更新了天赋推荐。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为10.2补丁进行了更新和审查，更新了天赋推荐。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为10.2补丁进行了更新和审查，更新了天赋字符串
- **2023年11月6日（本页）：** 为10.2补丁进行了更新和审查，更改了“可行性”。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已更新至10.1.7并采用新格式。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年9月1日（[传说物品](<https://www.icy-veins.com/wow/windwalker-monk-best-legendaries-shadowlands>)):** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为10.1.5补丁进行了更新和审查，添加了关于永恒黎明地下城中唯一物品的信息。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年7月10日（本页）：** 为10.1.5补丁进行了更新和审查，添加了关于10.1.5改动的信息。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为10.1补丁进行了审查和更新，格式更改、更新了毕业装备搭配等。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为10.1补丁进行了审查和更新，移动了原初之石部分并添加了暗影烈焰附魔。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为10.1补丁进行了审查，无需更改。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为10.1补丁进行了审查和更新，移除了风暴之拥。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为10.1补丁进行了更新，将旭日东升踢在优先级中上移。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为10.1补丁进行了审查，目前无需更改。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为10.1补丁进行了审查，无需更改。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已根据10.1补丁审查，无需更改。
- **2023年5月1日（本页）：** 已更新至10.1，添加了必要的新H1章节。
- **2023年4月30日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为10.1补丁进行了更新和审查，无需更改。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/windwalker-monk-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为10.0.7补丁进行了审查，添加了原初之石部分。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 为10.0.7补丁进行了审查，添加了专精改动部分。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已更新至巨龙时代第1赛季，添加了来自化身巨龙牢窟的装备。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已更新至巨龙时代第1赛季，添加了关于化身巨龙牢窟套装奖励的说明。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已更新至巨龙时代上线，添加了初始地下城装备。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已更新至巨龙时代上线，添加了风暴之拥信息，移除了暗影国度相关内容。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已更新至巨龙时代上线，移除了暗影国度相关内容。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已更新至巨龙时代上线，添加了单体和范围天赋。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已更新至巨龙时代上线，移除了暗影国度相关内容。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/windwalker-monk-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/windwalker-monk-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/windwalker-monk-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/windwalker-monk-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/windwalker-monk-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年6月28日（[9.1 补丁分析](<https://www.icy-veins.com/wow/windwalker-monk-patch-9-1-changes-analysis>)):** 添加了关于新传说装备和盟约推荐的信息。
- **2021年5月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/windwalker-monk-patch-9-1-changes-analysis>)):** 页面已创建。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-the-eternal-palace-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2019年7月22日（[永恒宫殿页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-the-eternal-palace-raid-guide>)):** 更新了部分首领战天赋和提示。
- **2019年7月16日（[永恒宫殿页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-the-eternal-palace-raid-guide>)):** 更新攻略以提及畸变体的存在。
- **2019年7月10日（[永恒宫殿页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月17日（[风暴熔渣页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-crucible-of-storms-raid-guide>)):** 攻略已更新，添加了更多提示。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年9月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** 添加了内容。

显示更多

显示更少

:::

## 练级

在本页中，您将找到我们的逐级踏风武僧练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[武僧练级指南](<https://www.icy-veins.com/wow/monk-leveling-guide>).

1.

### 武僧踏风在至暗之夜的练级指南

踏风通常被认为是魔兽世界中最好的练级专精之一。近乎无与伦比的机动性、充足的控制技能以及[[spell:322109]]这个（通常）可以秒杀敌人的法术相结合，使得踏风练级非常轻松。

踏风武僧能够将大量目标聚拢，用[[spell:119381]]击晕他们，然后用范围伤害将其消灭。或者你也可以简单地专注于单个目标，并使用像[[spell:122470]]这样的法术将伤害转移回该目标。许多人发现，与其他专精相比，踏风练级是一个灵活且轻松的过程。

1.1.

#### 升级装备选择

练级时，始终选择物品等级最高的装备。此规则的唯一例外是如果你有一个戒指或项链，它的物品等级略低，但拥有两个副属性而不是一个。

使用传家宝装备时，我们推荐使用带有暴击和急速的装备，因为它们会在练级过程中略微改善游戏体验。

1.2.

#### 至暗之夜升级实用消耗品

特别是在至暗之夜资料片中从80级升到90级时，除了下文提到的“常规”PvE消耗品外，还有很多消耗品可以帮助缓解这一过程。

- [[item:132516]]——巨大的移动速度提升，在坐骑无法使用时也能生效，且比地面坐骑快得多。
- [[item:109076]]——让你从悬崖边滑翔出去，快速覆盖很远的距离。
- [[item:168412]]——别忘了这件坐骑装备，它能让你的坐骑在地面上更快。
- [[item:172063]] — 一种食物，能提供惊人的移动速度加成。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 踏风 80级 至暗之夜练级
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzMD2GGYmZ2mZGAAAAAAAAAAAYZYEmxywAmxwMjBzGmBLzEAwmZ2mZgxMAA2AAmlmZmZBYYgZAwYxMgBA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzMDYMGmZmtZmBAAAAAAAAAAAWGGhZYYAzYYmZmhZbYGsMTAAbmZbMjxYGAAbAwsMLNzMzCwAYmBgxyMDYAD"
}
```
:::

:::details 来源计算器编码
```
#NE-pJNTIzvoSZYYAuYPNE4hCz4W9lkcs12GnGI-pMoSAATBCERex4qaSldNo1q7TJcV0hE-AAAA-HoIBRow4YhpJAA-*
```

:::

2.1.

#### 升级用战争模式天赋

在本节中，我们将对最适合练级以及进行单人/小队PvE内容的PvP天赋进行排名。以下是踏风武僧专属PvE天赋的排名。

1. [[spell:287503]]在你在目标之间移动时提供少量爆发伤害，非常有用。
2. [[spell:342928]]对于生存能力和额外伤害非常有用。
3. [[spell:287681]]是一个非常强大的PvP天赋，使拉取大群敌人变得更加容易。
4.

### 升级循环

为了在练级和学习专精时保持简单，使用滑块选择你的等级，观察练级循环随着每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

踏风武僧的输出循环基于优先级系统。一旦列表中可用的最高优先级技能就绪就立即使用。此列表假设你可以使用许多天赋，所以只需移除你没有的天赋即可。它也是为范围拉怪设置的，因为踏风非常擅长这样做。

1. **等级 10 起：**[[spell:322109]]
2. **等级 29 起：**[[spell:152175]]
3. **等级 29 起：**[[spell:392983]]
4. **等级 11 起：**[[spell:113656]]
5. **等级 11 起：**[[spell:107428]]
6. **等级 2 起：**[[spell:100784]]
7. **等级 7 起：**[[spell:101546]]
8. **等级 1 起：**[[spell:100780]]
9.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 针对至暗之夜 12.1补丁更新，重做了天赋构建。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对 至暗之夜 第一赛季进行审阅和更新。
- **2026年2月26日：** 为 至暗之夜 发布进行了审阅和更新。将升级内容扩展至90级。
- **2026年2月10日：** 已为至暗之夜前夕更新并进行了审查，更新了升级天赋和路线。
- **2025年12月13日：** 修复了升级滑块。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 针对11.2.5进行了审阅，无需更改。
- **2025年8月4日：** 针对11.2补丁进行了审阅，无需实质性更改，但我敢肯定天赋树会出问题。
- **2025年7月1日：** 再次修正了升级路线，恢复了英雄天赋顺序。
- **2025年6月15日：** 针对11.1.7补丁进行了审阅，目前没有损坏，因此无需更改。
- **2025年4月21日：** 针对11.1.5版本进行了审查，删除了“恭喜”章节，我敢肯定升级顺序会因为某些原因出问题。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战上线审查并更新，进行了细微的格式调整。
- **2024年7月23日：** 为地心之战前夕更新了新的升级路线。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在魔兽世界12.1.5补丁中轻松游玩踏风武僧，使用最简单的输出循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 武僧踏风基础

本页面面向刚接触游戏或该职业的玩家，他们没有进行史诗难度团队副本的打算，或者只是想要一种更直接的方式来游玩自己的专精，而不会被大量需要考虑的细节和主动技能所淹没。

踏风武僧是一个近战输出专精，在各种情况下都可行，能提供强大的单体和范围伤害，并且输出循环流畅、相对容易执行。

在整个战斗过程中，你需要管理能量和真气这两种资源，以便尽可能多地使用技能。你必须确保不要让这两种资源溢出浪费，同时也要保留足够的资源以便立即使用你的技能，因为延迟使用某些技能可能会让你损失可观的DPS。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_healthsphere.jpg>)
  **管理能量和真气**
  
  
  
  
  资源通常是限制你能使用哪些技能以及何时使用的最大因素。你需要确保有足够的真气来施放像[[spell:107428]]和[[spell:113656]]这样伤害最高的技能，同时通过[[spell:100784]]和[[spell:101546]]有策略地消耗多余真气。在整个过程中，你都要避免连续重复使用同一个技能，以便持续从踏风的精通和[[spell:196740]]中获益。
- ![](<https://static.icy-veins.com/images/wow/large_icons/monk_ability_fistoffury.jpg>) **保持技能冷却**  
  
  踏风伤害最高的技能都带有冷却时间，限制了你使用它们的频率。你要抓住一切机会使用它们，因此确保在它们冷却完毕时有足够的资源来施放至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_roundhousekick.jpg>) **应对触发效果**
  
  
  
  
  踏风有多个触发效果，可以让你额外施放某些技能。快速对这些触发做出反应，并将它们足够好地穿插到你的操作中，使你仍然能够管理资源并在技能可用时使用它们，正是让踏风每次战斗不完全相同的关键。

1.

### 至暗之夜中武僧踏风新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派单体天赋

2.1.

#### 武僧踏风新手单体天赋

此构筑非常适合新手在纯单体场景中使用。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AgZZWamZmFAMwMDAjlBwA+A"
}
```
:::

:::details 来源计算器编码
```
#NE-GHIJNTpuzSZnQRZBMchh5ZGU9Fkks12G3oG-pBCEMNToAAScmnRVv8WCxST3HYIZbiCS-AAA-FGUYcgoYhpJQCA-*
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派范围天赋

2.2.

#### 武僧踏风新手大秘境与地下堡天赋

这是我们为新手在范围场景中推荐的构筑。它在团本中的范围战斗以及大秘境和地下堡中都表现出色。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMYMYbmZ2mxAAAAAAAAAAAALDzEmhhBMjhZmZGmthZYWmJAgFzsNGGzMDAgNAYWmlmZmZBYYgZGAYZMgBM"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzEIMSZnQRdhBMchh5ZGU9Fkks12G3oG-pBCEMoAASTcmnRUVvy8C1ST3XI5arhC-AAAA-FGUYcgoYhpJQCA-*
```

:::

### 武僧踏风基础输出循环

2.3.

#### 单体输出循环

单体武僧踏风输出循环基于优先级系统。

1. [[spell:322109]]
2. [[spell:152175]]
3. [[spell:392983]]
4. [[spell:113656]]
5. [[spell:467307]]
6. [[spell:107428]]
7. [[spell:100784]]
8. [[spell:100780]]

2.4.

#### AOE循环

面对多个敌人时，输出循环同样基于优先级系统。

1. [[spell:322109]]
2. [[spell:152175]]
3. [[spell:392983]]
4. [[spell:113656]]
5. [[spell:467307]]
6. [[spell:107428]]
7. [[spell:100784]]
8. [[spell:101546]]
9. [[spell:100780]]

2.4.1.

##### 巅峰天赋： ![Tigereye Brew Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_tigereyebrandy.jpg>) 猛虎之眼

[[spell:1261703]]是新的巅峰天赋节点，是对踏风原始伤害冷却技能的致敬，尽管主要只是名字上的致敬。正如技能说明所示，在战斗中你会积累层数，然后在施放[[spell:1249625]]时消耗这些层数来提高你的暴击几率。在非战斗状态下，它会非常快地重新叠满至10层，或者如果你已经处于10层或以上，它会保持层数。

通常你不需要围绕这个增益来打，因为你应该会自然地足够频繁地使用[[spell:1249625]]，以至于不需要担心20层的上限。这个增益影响你思维方式的主要方式是，它降低了连续使用[[spell:1249625]]两次充能的诱惑，因为第二次使用将只有很少的层数。大多数时候，将它们分开使用是合理的选择，但有时你仍然会想要连续使用它们。这个天赋可以在更极端的极限压榨情况下之外取用并忽略，这些情况可能会随着时间的推移而被研究出来。

2.4.2.

##### 第2赛季套装

踏风第2赛季套装奖励：[[spell:1296621]]和[[spell:1297033]]非常强大，会让你想在[[spell:113656]]之后使用[[spell:101546]]。

### 武僧踏风防御技能

2.5.

#### 武僧踏风防御技能

[[spell:122470]]是唯一的基础防御技能。由于伤害会被转移回你的目标，它经常被用作进攻技能。然而，在你确定自己可以舒适地将其用于进攻之前，始终建议你只将其用于防御。在很多情况下，将其用于防御与用于进攻非常相似。

[[spell:388917]]激活时，减少你受到的所有来源的伤害，同时增加你的最大生命值。

### 武僧踏风属性优先级

2.6.

#### 至暗之夜中武僧踏风的属性优先级

武僧踏风的一般属性优先级如下所示。这在很大程度上是一个粗略的指南，专为不希望对自己的角色进行模拟的玩家设计。如果你正在模拟你的角色，请完全忽略此属性优先级并遵循你的模拟结果！有关本页呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>).

敏捷

急速

暴击

精通

全能

### 暴风雪战斗循环助手

2.7.

#### 武僧踏风战斗循环助手

如果你在初次上手武僧踏风输出循环时想要一个更便捷的选择，还有一个 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 可以从法术书中获得。此助手可以执行简化版本的伤害输出循环，只需要你使用一个按键。然而，使用此助手的代价是每次按下技能之间的冷却时间增加。这在模拟中会导致15-30%的DPS损失，但如果你对“全手动”玩法不熟悉，这可能仍然是一个净提升。

但请注意，即使有这个助手的帮助，你 **必须** 仍然需要手动使用你的防御技能，以及你的关键进攻性冷却技能[[spell:123904]]。

遗憾的是，上述对战斗助手的乐观描述假设它能正常工作。不幸的是，目前该助手无法在像[[spell:113656]]这样的引导技能期间暂停。这意味着建议你使用以下宏作为按钮，而不是仅仅将法术书中的按钮拖到你的动作条上。

```wow-macro
#showtooltip
/stopmacro [channeling]
/cast Single-Button Assistant
```

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 针对至暗之夜 12.1补丁进行审查和更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月12日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已为至暗之夜发布更新，新增天命者天赋说明。
- **2026年2月10日：** 已为至暗之夜前夕更新并进行了审查，所需改动出乎意料地少。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 针对11.2.5进行了审阅，无需更改
- **2025年9月7日：** 移除了关于“简单”选择没有套装的说明。无需其他更改。
- **2025年8月4日：** 已更新至11.2补丁，无实质性更改。
- **2025年6月15日：** 针对11.1.7版本更新，新增了关于循环辅助的信息。
- **2025年4月21日：** 针对11.1.5版本进行了更新和审查，为天赋新增了includes。
- **2025 年 2 月 24 日：** 为11.1版本更新，更新了属性优先级。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 为地心之战上线审查并更新，进行了细微的文字修改。
- **2024年7月23日：** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审查，无需更改。
- **2024年3月28日：** 修复了天赋树链接
- **2024年3月19日：** 为10.2.6补丁进行了审查，无需更改。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了更新和审查，更新了天赋字符串
- **2023年9月4日：** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年7月10日：** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年5月1日：** 已根据10.1补丁审查，无需更改。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到魔兽世界12.1.5补丁中你的踏风武僧的最佳天赋。我们还提供了适用于团队副本或大秘境等不同类型内容的默认天赋构建。如果你开启了战争模式，我们也为你提供了PvP天赋推荐。

1.

### 至暗之夜中踏风武僧最佳天赋

在第2赛季中，得益于最近的一些改动，踏风终于比以前有了更多的天赋变化。现在的主要区别取决于你使用的是哪套英雄天赋。

- **单体目标 -** 两套英雄天赋非常相似，通常建议选择你用起来最顺手的那一套。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派的上限可能略低，但操作明显更简单，容错率也更高。
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师的上限略高，但使用难度明显更大，且失误的惩罚也更重。
- **AoE -** 与单体目标类似，两套英雄天赋的强度非常接近，玩家的个人表现和手感可以决定两者之间的差异。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 对于新手玩家，或者在缺乏周密规划的野队中游玩，影踪派应该是更稳妥的选择。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 在那些会提前规划以最大化所有人表现的队伍中，比如高层或MDI类赛事，天神御师最有机会大放异彩。

在纯单体目标场景中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派领先于
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师，同时还能造成可观的顺劈伤害，或者可以轻松切换到几个更偏向顺劈的天赋。因此，我们推荐在本团本的所有首领战中使用它。在AOE战斗中，
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派凭借其更灵活的冷却时间、更简单的输出循环以及AOE伤害而领先。

**快速开始导入代码：**

:::talents 踏风团队副本 - 影踪派
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GmhlZGbzAAAAAAAAAAAAsMMCzwwAmZGmZmZY2GmhZZmAAWMz2MjZmZmBAwGAMLzSzMzsAgBmZAYsMAGwFA"
}
```
:::

:::talents 踏风大秘境 - 天神御师
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYEmhhBMjhZmZGmNMDzyMBAswsxMmZmZAAsYmlZZMBAAmZGAzAMWGDYmZ2M"
}
```
:::

:::talents 踏风地下堡 - 天神御师
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYEmhhBMjhZmZGmNMDzyMBAswsxMmZmZAAsYmlZZMBAAmZGAzAMWGDYmZ2M"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

影踪派

团队副本

推荐

秘境+

每周大秘境钥匙

地下堡

天神御师

团队副本

进阶

秘境+

高层大秘境

地下堡

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派团队副本天赋

这套 **目标** 构建非常直接，这里完全忽略了顺劈和AOE。许多团队战斗要么完全是单体目标，要么以单体目标为主。在很多情况下，即使战斗中有像小怪刷新这样的AOE环节，如果那些小怪刷新不是特别重要或危险，使用单体构建也可能是最优选择。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派大秘境天赋

**秘境+** 构建的优化目标是尽可能快地完成大秘境地下城。 **野外与地下堡** 构建通常是此构建的变体，因为这些玩法同样包含相当比例的单体和AOE，两者都应当进行优化。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派地下堡天赋

**[地下堡](<https://www.icy-veins.com/wow/delves-guide>)** 构建的伤害类型通常与大秘境相同，因此天赋构建也相同。

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师团队副本天赋

**单体目标** 构建非常直接。它们尽可能对单个目标造成最大伤害。这里完全忽略了顺劈和AOE。许多团队战斗要么完全是单体目标，要么以单体目标为主。在很多情况下，即使战斗中有像小怪刷新这样的AOE环节，如果那些小怪刷新不是特别重要或危险，使用单体构建也可能是最优选择，即使在这样的战斗中也是如此。

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师大秘境天赋

**秘境+** 构建的优化目标是尽可能快地完成大秘境地下城。 **野外与地下堡** 构建通常是此构建的变体，因为这些玩法同样包含相当比例的单体和AOE，两者都应当进行优化

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师地下堡天赋

**[地下堡](<https://www.icy-veins.com/wow/delves-guide>)** 构建的伤害类型通常与大秘境相同，因此天赋构建也相同。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GmhlZGbzAAAAAAAAAAAAsMMCzwwAmZGmZmZY2GmhZZmAAWMz2MjZmZmBAwGAMLzSzMzsAgBmZAYsMAGwFA"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTUpzIMSZnQRZdBMchh5ZGU9Fkks12G3oG-pBCEMNToAAScmnRVv8WCxST3HY4IZrRCS-AA-FGUYcgoYhpJQCA-*
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYAMGbzMz2MAAAAAAAAAAAALDzEmhhBMjhZmZGmNMDzyMBAsYmtZmxMzMDAgNAYWmlmZmZBgZgZGAYZMgBM"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzEIMSZnQRdhBMchh5ZGU9lkct12G3oG-pBCEMoAASTcimnORUVv8CSWC1ST3XYL-AAAA-FGUYcgoYhpJQCA-*
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYAMGbzMz2MAAAAAAAAAAAALDzEmhhBMjhZmZGmNMDzyMBAsYmtZmxMzMDAgNAYWmlmZmZBgZgZGAYZMgBM"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzEIMSZnQRdhBMchh5ZGU9lkct12G3oG-pBCEMoAASTcimnORUVv8CSWC1ST3XYL-AAAA-FGUYcgoYhpJQCA-*
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GmhlZmZbGAAAAAAAAAAAglhRYGGGwMzwMzMDz2wMMLzEAwiZ2mZMjZmBAwiZWmlxEAAADgZAGLDgZmZxFA"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTUpzIMSZnQRZdBMchh5ZGU9Fkks12G3oG-pBCEMNToAAScmnRUVv8CxST3HY4IZrRCS-AA-EMQowIRZhpBQAC-*
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYEmhhBMjhZmZGmNMDzyMBAswsxMmZmZAAsYmlZZMBAAmZGAzAMWGDYmZ2M"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzIMoouwDSZnYBEchh5Zu2qabj7LJp2I-pBCEMoAASTimnORUVv8WaAxSTXI5KbL-AAAA-EMQowIRZhpJQAC-*
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYEmhhBMjhZmZGmNMDzyMBAswsxMmZmZAAsYmlZZMBAAmZGAzAMWGDYmZ2M"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzIMoouwDSZnYBEchh5Zu2qabj7LJp2I-pBCEMoAASTimnORUVv8WaAxSTXI5KbL-AAAA-EMQowIRZhpJQAC-*
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

万卷全书是至暗之夜中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

我们建议你选择以下增益，但由于你可以随时在它们之间自由切换，如果你觉得推荐的选项收益不够，可以自行尝试其他选项：

- 第1行：[[spell:1279599]]适用于所有内容
- 第2行：[[spell:1279604]]
- 第3行：[[spell:1287555]]
- 第4行：[[spell:1279609]]作为默认选择，其他选项最好对自己的角色进行模拟
- 第5行：[[spell:1279614]]

1.

### 巅峰天赋： ![Tigereye Brew Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_tigereyebrandy.jpg>) 猛虎之眼

至暗之夜引入了新的巅峰天赋，在80级至90级之间解锁。踏风武僧拥有：

1. [[spell:1261703]]
2. [[spell:1261844]]
3. [[spell:1261849]]

[[spell:1261703]]是新的巅峰天赋节点，是对踏风原始伤害冷却技能的致敬，尽管主要只是名字上的致敬。正如技能说明所示，在战斗中你会积累层数，然后在施放[[spell:1249625]]时消耗这些层数来提高你的暴击几率。在非战斗状态下，它会非常快地重新叠满至10层，或者如果你已经处于10层或以上，它会保持层数。

通常你不需要围绕这个增益来打，因为你应该自然地足够频繁地使用[[spell:1249625]]，而不需要担心20层的上限。这个增益影响你思考方式的主要方式是，它降低了连续使用[[spell:1249625]]两次充能的动力，因为第二次使用时层数会非常少。大多数时候，将它们分开使用是合理的选择，但有时你仍然会想连续使用它们。这个天赋可以在更极端的极限优化情况之外被点出并忽略，这些情况可能会随着时间的推移被研究出来。

在第一个天赋点之后，其他三个是被动伤害提升，不会改变任何东西。

1.

### 英雄天赋

踏风可以在两种截然不同的英雄天赋选择中做出抉择：
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师。它们在71级可用，且互斥。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派可以被描述为“基础”踏风，不需要担心任何额外的按键或机制。这个英雄天赋树的重点在于增强踏风所拥有的基础技能组合的威力。

该天赋树确实增加了[[spell:450615]]这一伤害来源，当你施放像[[spell:113656]]或[[spell:107428]]这样的技能，以及在[[spell:1249625]]期间的[[spell:101546]]时，会造成额外的伤害打击。这些伤害通过[[spell:1262612]]进一步增强为AOE伤害，成为一个相当可观的额外伤害来源。

这个英雄天赋树推荐给新手，因为其中的天赋或[[spell:450615]]都不会改变专精的玩法。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师大量借鉴了武僧和踏风的背景设定，借助至尊天神的协助来提供额外的力量。这个英雄天赋树带来了熟悉的技能[[spell:123904]]和[[spell:443028]]，通常被认为明显更复杂，且与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派.

作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师围绕管理[[spell:443294]]的窗口期展开，这些窗口在使用[[spell:1249625]]、[[spell:443028]]、[[spell:392983]]或[[spell:152175]]时产生。这些增益窗口极大地提升了专精的输出速度，包括更快的[[spell:113656]]引导以及技能冷却时间的大幅缩短。学会如何平衡和管理这些增益窗口，对于最大化 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师并让人认为它既更复杂又更快 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派.

1.

### PvP天赋（战争模式）

战争模式为你在开放世界中提供了多项好处。

- 户外世界中启用的PvP天赋。
- 在最高等级时，世界任务奖励至少提高 10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于启用战争模式对升级和PvE内容的好处，建议启用该功能以最大化你的升级效率和满级后的奖励。然而，你将使自己成为开放世界PvP的目标，并且在升级或进行世界任务时存在被“偷袭”的可能性。

在本节中，我们将为升级以及进行单人/小队PvE内容推荐最佳PvP天赋。以下是踏风武僧所有PvP天赋的排名

1. [[spell:357633]]为你和受[[spell:157411]]影响的盟友提供一个效果，使他们每30秒有一次机会免疫减速和定身效果。
2. [[spell:342928]]使[[spell:322101]]的治疗量翻倍，并在使用时提供额外的真气。
3. [[spell:201769]]将你的[[spell:116095]]射程增加到10码。
4. [[spell:287503]]在你用[[spell:100780]]攻击新目标时为你提供30%急速。每个目标每30秒可触发一次。
5. [[spell:233759]]为你提供一个额外的法术，阻止你的目标使用他们的武器6秒。
6. [[spell:287681]]使[[spell:113656]]对所有命中的目标造成全额伤害，并使其移动速度降低90%。此外，在引导期间，它还为你提供100%招架几率。
7. [[spell:201372]]使[[spell:101545]]路径上的盟友移动速度提高30%。这同样适用于你自己。它还会使翔龙在天的冷却时间增加10秒。
8. 如果你用[[spell:450432]]击杀了一名玩家，它会将[[spell:322109]]的冷却时间缩短60秒。
9. [[spell:247483]]在你消耗3点真气时产生虎眼酒层数。使用这些层数会使你的攻击无视护甲，但每层会在2秒内造成略低的伤害。

[[spell:287681]]、[[spell:342928]]和[[spell:287503]]是在进行PvE内容时最能让你受益的三个天赋。它们为你提供续航能力以及生存能力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 针对至暗之夜第二赛季更新，更新了天赋构建。
- **2026年6月15日：** 已针对12.0.7补丁更新，添加了关于万法全书的信息。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对至暗之夜第一赛季进行审查。无需更改。
- **2026年2月26日：** 已为至暗之夜发布更新，新增天赋构建方案和格式。
- **2026年2月10日：** 已为12.0.1从PTR转为正式服更新。
- **2026年1月19日：** 已为至暗之夜前夕更新并进行了审查，新增了英雄天赋板块，无需其他改动。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 针对11.2.5进行了审阅，无需更改。
- **2025年8月4日：** 针对11.2补丁进行了审阅，目前无需实质性更改。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 针对11.1.5版本进行了审查，无需更改。
- **2025年3月24日：** 针对3月25日的调整改动进行了更新，在天赋配置中加入了额外的天赋选择。
- **2025 年 2 月 24 日：** 为11.1版本更新，添加了引导之风天赋信息。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月27日：** 添加了地下堡天赋配置。
- **2024年8月21日：** 为地心之战上线审查并更新，更改了"包含内容"。
- **2024年7月23日：** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审查，无需更改。
- **2024年3月19日：** 为10.2.6补丁进行了审查，无需更改。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了更新和审查，更新了天赋推荐。
- **2023年9月4日：** 已更新至10.1.7并采用新格式。
- **2023年7月10日：** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年5月1日：** 为10.1补丁进行了审查，目前无需更改。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已更新至巨龙时代上线，添加了单体和范围天赋。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面中，你将学习如何在单体和多目标场景中优化你的踏风武僧的输出循环。我们还提供了关于冷却时间、触发效果等方面的进阶章节，以帮助你最大化你的DPS。我们所有的内容均针对魔兽世界12.1.5补丁进行了更新。

1.

### 踏风武僧玩法与输出循环指南

欢迎来到我们的踏风武僧输出循环页面。在本页面中，你将找到关于在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

以下各部分分别讲解不同环境下的输出循环。点击方框可切换到所需场景。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

多目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师

单体目标

多目标

主动天赋

被动天赋

[[spell:392983]]

[[spell:152175]]

[[spell:433082]]

[[spell:1250042]]

[[spell:451524]]

[[spell:325201]]

[[spell:1250566]]

[[spell:1249832]]

[[spell:392982]]

### 踏风武僧单体目标优先级

踏风武僧围绕优先级列表进行输出，而非固定的输出循环。遵循这个优先级列表，你将根据强度顺序专注于协调技能冷却、资源和[[spell:115636]]。这意味着在每个GCD中，我们从列表顶部到底部依次检查，只要当前价值最高的技能与上一个技能不同，就按下该按钮。

**适用条件：影踪派（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派将大部分伤害均匀地分布在大多数技能中，依赖于稳定的压制力。随着至暗之夜的改动， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派的主要功能变化在于你不再需要追踪已消耗的能量或额外的增益，因此优先级的执行更加一致和流畅。

**适用条件：天神御师（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师专注于管理[[spell:123904]]和[[spell:443028]]的额外技能，以及[[spell:443294]]增益的效果。这个增益极大地加快了你的技能冷却恢复速度，并加快了你引导[[spell:113656]]的速度，以便在冷却窗口内尽可能多地倾泻伤害。

---

1. **适用条件：影踪派（启用）。** 在宽限期内施放[[spell:152175]]
2. **适用条件：天神御师（启用）。** 在宽限期内施放[[spell:152175]]，且[[spell:123904]]的冷却时间长于10秒
3. 如果真气不足，或[[spell:1249625]]即将结束，或正在引导[[spell:443028]]，则施放[[spell:1272694]]
4. 如果[[spell:152175]]或[[spell:392983]]没有激活的[[spell:443294]]，则使用[[spell:443028]]。在下一个GCD取消。
5. **适用条件：天神御师（启用）。** 如果[[spell:443294]]剩余时间少于1秒，则施放[[spell:113656]]。
6. 满足以下条件时施放[[spell:100780]]：真气少于4点，[[spell:116768]]少于2层，能量即将溢出，且不在[[spell:1249625]]期间
7. **适用条件：天神御师（启用）。** 施放[[spell:443028]]
8. **适用条件：天神御师（启用）。** 施放[[spell:123904]]
9. 施放[[spell:113656]]
10. **适用条件：Whirling Dragon Punch（启用）；影踪派（启用）。** 施放[[spell:152175]]
11. **适用条件：Strike of the Windlord（启用）。** 施放[[spell:392983]]
12. **适用条件：Whirling Dragon Punch（启用）；天神御师（启用）。** 如果[[spell:123904]]的冷却时间长于10秒，则施放[[spell:152175]]
13. 如果真气不足以施放[[spell:113656]]，则施放[[spell:100784]]
14. **适用条件：Rushing Wind Kick（启用）。** 施放[[spell:1250566]]
15. **适用条件：Dance of 赤精（启用）；Revolving Whirl（启用）。** 在拥有[[spell:286585]]和第2赛季4件套效果[[spell:1297033]]时施放[[spell:101546]]
16. 在拥有[[spell:2825]]且没有[[spell:325201]]时施放[[spell:107428]]
17. **适用条件：天神御师（启用）。** 在拥有第2赛季4件套效果[[spell:1297033]]时施放[[spell:101546]]
18. 施放[[spell:107428]]
19. 拥有2层[[spell:116768]]时施放[[spell:100784]]
20. 在[[spell:116768]]或[[spell:1249625]]激活时施放[[spell:100784]]
21. **适用条件：影踪派（启用）。** 在拥有[[spell:1249625]]且真气多于4点时施放[[spell:101546]]
22. **适用条件：Dance of 赤精（启用）；Revolving Whirl（启用）。** 在拥有[[spell:1249625]]且触发[[spell:325201]]时施放[[spell:101546]]
23. 施放[[spell:322109]]
24. 如果上述任一条件可用且你的真气不足，则施放[[spell:100780]]
25. 拥有1层[[spell:116768]]时施放[[spell:100784]]
26. **适用条件：Dance of 赤精（启用）；Revolving Whirl（启用）。** 触发[[spell:325201]]时施放[[spell:101546]]
27. **适用条件：Slicing Winds（启用）。** 施放 [[spell:433082]]
28. 施放 [[spell:100780]]，但不要溢出真气
29. 施放 [[spell:100784]]

### 踏风 武僧多目标优先级

踏风 武僧围绕优先级列表运作，而非固定的循环。按照这个优先级列表，你需要根据威力顺序来兼顾技能冷却和资源。这意味着每个GCD我们从列表顶部到底部依次检查，只要不是重复上一个技能，就按下当前价值最高的技能。

**适用条件：影踪派（启用）。** 转为AoE的情况对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派来说相当简单，只需对优先级做极小的调整。大部分AoE伤害的提升来自[[spell:1262612]]，因为它会对你周围的所有敌人溅射自然伤害。

**适用条件：天神御师（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师在转为AoE伤害时变化很小，因为大部分伤害来自[[spell:113656]]的额外施放，而这些额外施放来自[[spell:443294]]带来的冷却缩减。

---

此多目标优先级需要至少2个目标。

1. **适用条件：天神御师（启用）。** 如果[[spell:443294]]剩余时间少于1秒，则施放[[spell:113656]]。
2. **适用条件：Whirling Dragon Punch（启用）；影踪派（启用）。** 施放[[spell:152175]]
3. **适用条件：Whirling Dragon Punch（启用）；天神御师（启用）。** 如果[[spell:123904]]的冷却时间长于10秒，则施放[[spell:152175]]
4. 如果真气不足，或[[spell:1249625]]即将结束，或正在引导[[spell:443028]]，则施放[[spell:1272694]]
5. 如果[[spell:152175]]或[[spell:392983]]没有激活的[[spell:443294]]，则使用[[spell:443028]]。在下一个GCD取消。
6. 如果真气不足以施放[[spell:113656]]，则施放[[spell:100780]]
7. 施放[[spell:113656]]
8. 在拥有第2赛季4件套效果[[spell:1297033]]时施放[[spell:101546]]
9. 满足以下条件时施放[[spell:100780]]：真气少于4点，[[spell:116768]]少于2层，能量即将溢出，且不在[[spell:1249625]]期间
10. 施放[[spell:107428]]以启用[[spell:152175]]
11. **适用条件：Rushing Wind Kick（启用）。** 在[[spell:1297033]]未激活时施放[[spell:1250566]]
12. **适用条件：天神御师（启用）。** 在[[spell:443294]]激活且没有[[spell:1297033]]时施放[[spell:107428]]
13. **适用条件：影踪派（启用）。** 在[[spell:1249625]]激活且至少有5个目标时施放[[spell:101546]]
14. 在[[spell:1297033]]未激活且没有[[spell:2825]]或[[spell:1249625]]时施放[[spell:107428]]
15. **适用条件：Obsidian Spiral（启用）。** 在[[spell:1249625]]期间施放[[spell:100784]]，并让[[spell:107428]]保持冷却
16. 施放[[spell:101546]]
17. 带有[[spell:116768]]时施放[[spell:100784]]
18. 如果上述任一条件可用且你的真气不足，则施放[[spell:100780]]
19. **适用条件：Shadowboxing Treads（启用）。** 施放 [[spell:100784]]
20. 施放[[spell:107428]]
21. **适用条件：Shadowboxing Treads（未启用）。** 施放 [[spell:100784]]

### 踏风 武僧起手式

**适用条件：天神御师（启用）；Slicing Winds（启用）。**

[[spell:433082]]

[[spell:100780]]

[[item:193701@JAAIAAQkCYHKvbRLfA]]

**适用条件：天神御师（启用）。**

[[spell:123904]]

[[spell:1249625]]

[[spell:1249625]]

[[spell:1272694]]

**适用条件：天神御师（启用）；Strike of the Windlord（启用）。**

[[spell:392983]]

[[spell:113656]]

[[spell:107428]]

[[spell:113656]]

**适用条件：Whirling Dragon Punch（启用）。**

[[spell:152175]]

**适用条件：影踪派（启用）；Strike of the Windlord（启用）。**

[[spell:392983]]

**适用条件：影踪派（启用）；Slicing Winds（启用）。**

[[spell:433082]]

**适用条件：影踪派（启用）。** 该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派起手式的目标是尽快让像[[spell:113656]]和[[spell:107428]]这样的强力技能进入冷却，以便你能更频繁地使用它们。通常来说，这个起手式比一般的起手式更贴近优先级。

**适用条件：天神御师（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师执行一套非常固定的技能序列，其长度通常处于大多数起手式的中间水平。这个起手式的目标是最大化[[spell:443294]]的持续时间，同时尽可能频繁地使用威力最大的技能。

**适用条件：天神御师（启用）。** 这个起手式同时也是一份指南，告诉你如何在每次这些冷却技能可用时最大化其效果，基本上每次你使用[[spell:123904]]和[[spell:443028]]时都应遵循。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师起手式比踏风通常所用的更长、更有规划，但由于不同的重叠机制，这是最小化浪费、最大化潜力所必需的。

与任何起手式一样，对于踏风，如果你开怪时拥有超过正常量的真气，那么你可以根据需要省略一次[[spell:100780]]。

---

**适用条件：影踪派（启用）。** **这个起手式在单体和AoE中是一样的。**

**适用条件：天神御师（启用）。** **这个起手式在单体和AoE中是一样的。**

1. **适用条件：天神御师（启用）；Slicing Winds（启用）。** 开战前预读[[spell:433082]]
2. 施放[[spell:100780]]
3. **适用条件：天神御师（启用）。** 施放[[spell:123904]]
4. 配合药水、种族技能和饰品施放[[spell:1249625]]（属性增益要在[[spell:1249625]]之前使用，以增益[[spell:1272694]]）
5. **适用条件：天神御师（启用）；Strike of the Windlord（启用）。** 施放[[spell:392983]]
6. 施放[[spell:113656]]
7. 施放[[spell:107428]]
8. 如果[[spell:107428]]重置了其冷却时间，则施放[[spell:113656]]
9. **适用条件：Whirling Dragon Punch（启用）。** 施放[[spell:152175]]
10. **适用条件：影踪派（启用）；Strike of the Windlord（启用）。** 施放[[spell:392983]]
11. **适用条件：影踪派（启用）；Slicing Winds（启用）。** 施放 [[spell:433082]]
12. 继续按正常优先级执行。

**适用条件：天神御师（启用）。** 确保不要过早施放你的[[spell:443028]]，以免你从它获得的[[spell:443294]]增益与你从[[spell:392983]]或[[spell:152175]]获得的增益重叠。延迟[[spell:443028]]问题不大，因为你很可能在第一层效果消失后立即打出[[spell:1249625]]的第二层充能。

1.

### 至暗之夜 第2赛季套装

踏风的第2赛季套装加成：[[spell:1296621]]和[[spell:1297033]]非常强大，应尽快获取。在循环方面，一旦你获得了4件套效果，你需要确保在施放完[[spell:113656]]之后、施放[[spell:107428]]之前使用[[spell:101546]]，只要目标数量超过1个。

1.

### 职业与专精机制详解

为了更好地解释踏风 武僧技能体系的具体用法和优势，我们整理了一份关于循环各部分的更详细说明，从你需要注意的重要循环机制，到冷却技能及其使用方法，以便你在游玩踏风时充分发挥潜力。

### 管理能量和真气

3.1.

#### 管理能量和真气

除了大型急速冷却技能外，踏风的伤害受限于我们能产生和消耗多少资源。这意味着停留在能量上限或产生超出你可容纳上限的真气，通常会导致伤害潜力的损失。你的重点是平衡有足够的真气用于消耗技能，并且刚好使用足够次数的[[spell:100784]]以防止真气溢出，但又不能使用过多，以免在更大的消耗技能可用时没有所需真气。

在主要冷却技能期间，由于GCD和真气消耗技能的冷却时间，你通常会拥有超出你能使用的能量和真气，这使得避免溢出的影响较小，但仍需注意。

### 保持技能冷却

3.2.

#### 保持技能冷却

由于我们的大多数真气消耗技能都有各自的冷却时间，因此重要的是减少这些高伤害技能处于冷却完毕却未被使用的时间。不可避免地会出现重叠情况，你必须根据优先级列表来选择按哪个技能。游玩踏风的关键部分在于意识到这种情况即将到来，并努力为你需要执行的操作储备足够的真气。

### 应对触发效果

3.3.

#### 应对触发效果

踏风有几个需要管理以最大化伤害潜力的触发效果。主要是[[spell:325201]]和[[spell:100784]]。这两个都可以叠加到2层，所以你不需要立即使用它们。然而，你需要避免冒着过度叠加的风险，因为那会损失伤害潜力。这些触发效果可以在帮助你平衡资源的同时，仍然从[[spell:115636]]中获益方面发挥重要作用。它们也可能打乱你的计划，所以能够智能而迅速地做出反应很重要。

1.

### 踏风 武僧的重要冷却技能

### [[spell:1249625]]

4.1.

#### 乾元之巅

[[spell:1249625]]在没有[[spell:1261703]]的巅峰天赋加持下不会提供任何直接的伤害提升。然而，它会将你所有真气消耗技能的消耗降低1点，并将[[spell:100784]]提供的冷却缩减额外增加一秒。当你按下这个技能时，它会重置[[spell:107428]]的冷却时间，并立即为你提供额外的2点真气。

在[[spell:1249625]]激活期间，[[spell:100784]]变为免费，因此它是你的主要填充技能，以便尽快让[[spell:107428]]和[[spell:113656]]脱离冷却。这也意味着如果你也过于频繁地使用[[spell:100780]]，你会很快感觉真气过多。由于你的冷却技能恢复得更快，拥有足够的真气以便立即施放它们变得更加重要。

如果点出了[[spell:1249832]]，那么[[spell:100784]]会产生真气而不是消耗真气。这使它既是你的主要填充技能，也是主要的真气产生技能。可以在[[spell:100784]]之间使用[[spell:100780]]，为接下来的[[spell:100784]]叠加一层寺庙教诲。这有时会导致你的真气溢出，但这总比什么都不施放要好。

[[spell:1249625]]有两层充能，所以你不需要在它可用时立即使用，而是可以规划使用时机以获得最佳效果。通过天赋，[[spell:1249625]]的冷却时间可以是60、70、80或90秒。拥有两层充能意味着你可以安全地根据最大收益时机来使用它，比如在战斗的高伤害阶段、有大量目标可攻击的时机，或在嗜血等大型增益效果期间，以及配合你的饰品使用。

### [[spell:443028]]

4.2.

#### 天神御身

[[spell:443028]]是一个强大的技能，但它最强大的地方在于它能添加[[spell:443294]]增益效果。然而，由于这个增益效果也可以通过使用[[spell:392983]]或[[spell:152175]]获得，你需要错开这些使用时机以获得最大收益。这通常意味着在[[spell:392983]]或[[spell:152175]]的施放之间间隔使用[[spell:443028]]。这旨在确保最大的覆盖时间和价值。

通过使用[[spell:1249625]]触发的[[spell:443294]]实例，与来自[[spell:443028]]、[[spell:392983]]或[[spell:152175]]的[[spell:443294]]版本可以叠加。然而，由[[spell:443028]]产生的[[spell:443294]]实例，与来自[[spell:392983]]或[[spell:152175]]的实例不能叠加。

这意味着你可以在已经拥有 [[spell:443294]] 的情况下施放 [[spell:1249625]]，而且你应该这样做，因为它们的叠加效果非常好。如果你已经拥有了来自 [[spell:392983]] 或 [[spell:152175]] 的增益效果，就要尽量避免施放 [[spell:443028]]，反之亦然。

### [[spell:123904]]

4.3.

#### 白虎下凡

随着 至暗之夜 的改动，[[spell:123904]] 主要是一个用来让你之后引导 [[spell:443028]] 的按钮。这意味着你需要稍微提前规划，以免在想要输出伤害时浪费一个公共冷却时间去召唤 雪怒。

施放 [[spell:123904]] 之后有一个很大的窗口期，你可以在此期间施放 [[spell:443028]]。因为平衡上述 [[spell:443294]] 增益通常意味着一套相对严格的技能顺序，所以你应该尽量避免大幅偏离上述起手式，即使是在战斗中期也是如此。

### [[spell:322109]]

4.4.

#### 轮回之触

[[spell:322109]] 看起来是一个使用起来很直接的技能，但试图对其极限化处理可能会导致损失伤害而非增加伤害。由于 至暗之夜 中对致命之触的改动，使用它之后不再提供伤害加成。

虽然这通常意味着你应该在它可用时立即使用，并且在有空间按下它而不会延迟其他技能的情况下使用，但这同样意味着你可以在目标生命值低于你的最大生命值时，尝试在目标即将死亡前使用它，这样它会造成你生命值 100% 的伤害，而不是像对生命值 15% 或更低的目标使用时那样只造成你最大生命值的 35%。

这是一个非常小的窗口，如果你刚刚切换目标并试图用 [[spell:322109]] 攻击它，[[spell:322109]] 有时会有延迟才能使用。这个延迟可能就是能否抓住这个非常小的窗口的区别。错过窗口通常意味着你无法施放 [[spell:322109]]，从而损失了如果你早点施放本可以造成的伤害。

### [[spell:122470]]

4.5.

#### 业报之触

[[spell:122470]] 首先是一个防御性技能。它的主要用途是吸收一些伤害，以减轻你受到的伤害。然而，[[spell:122470]] 的次要功能是，护盾吸收的部分伤害会反弹回你施放该法术的目标身上。这意味着如果你不需要它的防御价值，[[spell:122470]] 可以被用作进攻手段。

大多数内容中的大多数战斗都有你会受到伤害的时刻，此时你可以干净利落地使用 [[spell:122470]] 来同时获得其防御和进攻价值。然而，有时你受到的伤害不足以需要像 [[spell:122470]] 这样的防御性冷却技能。在这些情况下，从技术上讲，最优解是找到一些伤害然后吸收并反弹它。这可以通过站在地上的某些伤害效果中来实现，或者在极端情况下，对目标施放嘲讽并承受几次攻击。

为了从 [[spell:122470]] 获得收益而需要嘲讽目标，应该作为最后的手段，并且只有在得到你的坦克和治疗明确许可的情况下才这样做，因为一旦护盾结束，如果没有直接干预，你很可能会被杀死。

这样做风险自负。

### [[spell:388917]]

4.6.

#### 壮胆酒

[[spell:388917]] 会提高你的最大生命值，因此它也会提高 [[spell:322109]] 造成的伤害以及 [[spell:122470]] 能够吸收的伤害。因此，在使用 [[spell:322109]] 或 [[spell:122470]] 之前使用 [[spell:388917]] 是一种伤害提升。这可以在需要时进一步提高你的防御能力，但它还有一个次要效果，即增加反弹回目标的伤害量。

如果你不需要单独使用 [[spell:388917]] 的防御价值，例如当大量伤害承受更为频繁且你需要错开你的防御冷却技能时，那么你可以将它们叠加使用以获得额外收益。只要确保在使用 [[spell:322109]] 或 [[spell:122470]] 之前先使用 [[spell:388917]]，因为两者都是在使用时快照的。

使用这个的一个很好的方法是找到一种方法，在你也能在 [[spell:388917]] 持续期间使用 [[spell:322109]] 的时候，先使用 [[spell:388917]] 然后使用 [[spell:122470]]。这样你一次使用就能获得两种收益。如果你本来就要为了伤害输出目的使用它，那不妨高效一点。

### [[spell:1261703]]

4.7.

#### 顶峰天赋：猛虎之眼酒

[[spell:1261703]]是新的巅峰天赋节点，是对踏风原始伤害冷却技能的致敬，尽管主要只是名字上的致敬。正如技能说明所示，在战斗中你会积累层数，然后在施放[[spell:1249625]]时消耗这些层数来提高你的暴击几率。在非战斗状态下，它会非常快地重新叠满至10层，或者如果你已经处于10层或以上，它会保持层数。

通常你不需要围绕这个增益来打，因为你应该会自然地足够频繁地使用[[spell:1249625]]，以至于不需要担心20层的上限。这个增益影响你思维方式的主要方式是，它降低了连续使用[[spell:1249625]]两次充能的诱惑，因为第二次使用将只有很少的层数。大多数时候，将它们分开使用是合理的选择，但有时你仍然会想要连续使用它们。这个天赋可以在更极端的极限压榨情况下之外取用并忽略，这些情况可能会随着时间的推移而被研究出来。

在第一个天赋点之后，其他三个是被动伤害提升，不会改变任何东西。

:::details 常见问题：我什么时候应该忽略精通：连击？
由于

[[spell:100784]]

的伤害低于其他消耗真气的技能，你不必优先考虑它而不是

[[spell:107428]]

。因此，你非常少需要

[[spell:100784]]

连续两次。如果你没有使用

[[spell:196740]]

，那么也没有太大动力去让精通收益作用在一个伤害很低的技能上，比如

[[spell:100780]]

。因此你可以轻松地

[[spell:100780]]

连续两次，当在设置群体伤害时，或者任何其他法术组合。如果你正在使用

[[spell:196740]]

那么你将需要避免连续两次使用相同的技能。

:::

:::details 常见问题：我应该有空闲时间吗？
**是的！**

踏风 的循环中自然有空闲时间，而且几乎一直都是这样。大多数基于能量的职业都是这样。虽然获得急速会提高你的能量回复速度，但它目前仍然不是一个非常理想的属性。学会利用空闲时间来规划未来会发生什么。你的空闲时间多少可能取决于你的英雄天赋、装备、你正在做的内容以及其他几个因素。只要你按照应有的优先级执行，一些空闲时间是可以接受的。

:::

:::details 常见问题：我是否应该保留神鹤引项踢几秒，以便让怒雷破按冷却时间使用？
通常最稳妥的做法是不要延迟任何技能。不过，在这种情况下最好的选择是确保你有5点真气，以便能够连续使用这两个技能且延迟最小。然后你可以保留

[[spell:113656]]

大约1-2个公共冷却时间，以便先使用

[[spell:107428]]

：如果这两个技能的冷却时间差距再大一些，你最好先使用

[[spell:113656]]

。这适用于任何两个技能冷却时间将要对齐的情况。然而，重要的是要理解，为了一个技能而延迟另一个技能可能会引发其他连锁情况，因此这个正确的选择很容易迅速失控。这就是为什么通常建议尽可能避免延迟。

:::

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月25日：** 更新了优先级，添加了关于天界通道和至高踩踏的说明。
- **2026年8月11日：** 针对至暗之夜第二赛季更新，更新了第二赛季套装的输出循环和优先级。
- **2026年6月15日：** 已针对12.0.7补丁审查和更新，添加了起手式时间线。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 更新了优先级和起手式，添加了更多关于选择的细节。
- **2026年3月12日：** 为 至暗之夜 第1赛季进行了审阅，添加了关于套装的说明。
- **2026年2月26日：** 已为至暗之夜发布更新，采用全新的输出循环格式，并新增了天命者天赋板块。
- **2026年2月10日：** 已为12.0.1从PTR转为正式服更新。
- **2026年1月19日：** 已为至暗之夜前夕更新并进行了审查，主要是格式变更和新增板块。
- **2025年11月30日：** 已为11.2.7进行了审查，新增了几条常见问题解答。
- **2025年10月14日：** 修正了关于真气（SEF）使用的错别字。
- **2025 年 10 月 5 日：** 针对11.2.5进行了审阅，无需更改。
- **2025年8月4日：** 已更新至11.2，极少更改，全部通过包含项完成。
- **2025年6月15日：** 针对11.1.7版本更新，新增了关于循环辅助的章节。
- **2025年4月21日：** 针对11.1.5版本进行了审查，无需更改。
- **2025 年 2 月 24 日：** 为11.1版本更新，添加了关于引导之风和天神之御窗口的循环信息。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战上线审查并更新，更改了"包含内容"。
- **2024年7月23日：** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审查，移除了关于第3赛季套装奖励的信息。
- **2024年3月19日：** 为10.2.6补丁进行了审查，无需更改。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了更新和审查，更新了优先级和套装信息。
- **2023年9月4日：** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年7月10日：** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年5月1日：** 为10.1补丁进行了更新，将旭日东升踢在优先级中上移。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已更新至巨龙时代第1赛季，添加了关于化身巨龙牢窟套装奖励的说明。
- **2022年11月28日：** 已更新至巨龙时代上线，移除了暗影国度相关内容。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到《魔兽世界》12.1.5版本中你的踏风武僧的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们一应俱全！

1.

### 踏风武僧毕业装备指南

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备物品等级，难度更高的内容会掉落可以升级到更高物品等级的装备。欲了解更多信息，请阅读我们关于
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含了来自所有来源的踏风武僧最高伤害输出配置之一。 **对于踏风武僧来说，几乎每一件没有全能属性的装备都是可行的"毕业"装备。不要将此列表视为唯一选择，因为有数百或数千种组合，它们之间的差距非常小。**

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
随着至暗之夜第2赛季的改动允许催化后的部件保留其属性，现在有更多潜在的毕业装备。这意味着任何带有暴击、急速或精通属性组合的部件都可以被催化，并且是最佳配置的竞争者。这也意味着你可能会看到顶尖玩家使用各种装备、附魔和宝石，因为他们根据模拟结果来调整自己拥有的装备。

理想情况下，你希望催化手部和腿部，因为它们是代币中带有全能作为副属性的套装部件。只要这些部件没有全能属性，就可以安全地催化以维持你的4件套奖励。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 继承原物品的副属性和特殊效果，玩家现在在获取具有理想属性的套装部件方面拥有巨大的灵活性 **在所有五个** 部位。假设你 **同时** 进行团队副本和大秘境，催化以下装备：

- **头部** - [[item:271875]] ([乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>))
- **护肩** - [[item:251223]] ([虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>))
- **胸部** - [[item:268235]] ([盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>))
- **手套** - [[item:251124]] ([密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>))
- **腿部** - [[item:268225]] ([盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>))

:::

:::details 常见问题：我应该从宏伟宝库选择什么？
该 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 每周有多达九个部位的物品供你选择，取决于你的角色完成了哪些内容。这也影响每个部位的物品等级，其中 ![Mythic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-mythic.png>)史诗团队副本boss奖励完全升级的史诗路线装备！然而，这种广泛的潜在物品等级也使得提供通用推荐变得困难。此外，玩家可以选择 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 或功绩代币，可用来兑换一个毒瘴珠宝镶嵌器 [[item:275707]]。这些替代品的实力不应被低估，即使它们相比之下可能感觉有点“无聊”。

尽管你应该始终对给定宝库奖励中的选择进行模拟（包括你将在本赛季剩余时间保留的装备上的额外插槽的价值），以下是选择奖励时遵循的基本优先级：

1. （仅第一个宝库）领取功绩代币以获得一个[[item:275707]]或套装部件（如果有的话）。
2. 如果你将进行团队副本 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 至少在 **![Heroic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-heroic.png>)英雄难度**，选择一个 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 以额外抽取物品 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) **作为酒仙**。这样做直到你获得所有部件。
3. 选择可以完成你套装的最高奖励轨道物品，最好是那些符合我们为踏风武僧推荐的催化剂部件。
4. 选择物品等级最高且全能属性最少的部件，即下方毕业装备列表中的部件，或者额外的 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)/[[item:275707]]，取决于你角色的目标。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271519@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271520@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271517@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271518@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271522@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268215@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

此列表包含了来自大秘境地下城的踏风武僧最高伤害输出配置之一。 **对于踏风武僧来说，几乎每一件没有全能属性的装备都是可行的"毕业"装备。不要将此列表视为唯一选择，因为有数百或数千种组合，它们之间的差距非常小。**

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题我需要哪些套装部件？
随着至暗之夜第2赛季的改动允许催化后的部件保留其属性，现在有更多潜在的毕业装备。这意味着任何带有暴击、急速或精通属性组合的部件都可以被催化，并且是最佳配置的竞争者。这也意味着你可能会看到顶尖玩家使用各种装备、附魔和宝石，因为他们根据模拟结果来调整自己拥有的装备。

理想情况下，你希望催化手部和腿部，因为它们是代币中带有全能作为副属性的套装部件。只要这些部件没有全能属性，就可以安全地催化以维持你的4件套奖励。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 继承原物品的副属性和特殊效果，玩家现在在获取具有理想属性的套装部件方面拥有巨大的灵活性 **在所有五个** 部位。假设你 **只能** 根据需要进行大秘境，催化以下装备：

- **头部** - [[item:251140]] ([密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>))
- **护肩** - [[item:251223]] ([虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>))
- **胸部** - [[item:251159]] ([纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>))
- **手套** - [[item:251124]] ([密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>))
- **腿部** - [[item:268225]] ([盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>))

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：掉落一把非常强力的武器和一个使用型毕业饰品。
- [夺目谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：掉落最强的被动饰品。
- [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)：掉落优秀的鞋子和胸甲。
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：掉落最强力的物品，头部、颈部、手部和腿部都是很好的选择。
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：掉落一枚强力的戒指和值得催化升级的护肩。
- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：掉落一枚强力的戒指。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271519@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271520@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:159301@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nexus-king-salhadaar-raid-guide-in-manaforge-omega" rel="noopener noreferrer">纳克萨玛斯之王萨尔哈达</a></div></td></tr><tr><th>护肩</th><td>[[item:271517@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271518@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:239656@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>脚部</th><td>[[item:251153@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271522@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273796@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250214@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273783@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

此列表包含来自团队副本的踏风武僧最高DPS配置之一。 **对于踏风武僧来说，几乎每一件没有全能属性的装备都是可行的"毕业"装备。不要将此列表视为唯一选择，因为有数百或数千种组合，它们之间的差距非常小。**

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
随着至暗之夜第2赛季的改动允许催化后的部件保留其属性，现在有更多潜在的毕业装备。这意味着任何带有暴击、急速或精通属性组合的部件都可以被催化，并且是最佳配置的竞争者。这也意味着你可能会看到顶尖玩家使用各种装备、附魔和宝石，因为他们根据模拟结果来调整自己拥有的装备。

理想情况下，你希望催化手部和腿部，因为它们是代币中带有全能作为副属性的套装部件。只要这些部件没有全能属性，就可以安全地催化以维持你的4件套奖励。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 继承原物品的副属性和特殊效果，玩家现在在获取具有理想属性的套装部件方面拥有巨大的灵活性 **在所有五个** 部位。假设你 **只能** 团队副本中，催化升级以下装备：

- **头部** - [[item:271875]] ([乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>))
- **护肩** - [[item:268246]] ([万毒邪祟者瓦什尼克](<https://www.icy-veins.com/wow/vashnik-raid-guide>))
- **胸部** - [[item:268235]] ([盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>))
- **手套** - [[item:251124]] ([密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>))
- **腿部** - [[item:268234]] ([斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>))

:::

:::details 小贴士哪些团队副本掉落对踏风最重要？
以下是你应该优先寻找的物品；其中一些可能会被其他专精激烈竞争，特别是在攻击性饰品方面：

- [[item:268215]]：这把武器掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)，最终boss， [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)，并且是你的毕业装备。只有少数专精可以装备它，让你不必制作武器。此外，当在英雄难度下用 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)，该物品将以神话级变体掉落；在史诗难度下，它将被“提升”额外10个物品等级。
- [[item:268265]]：这条项链来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 以多种方式独一无二，纯暴击属性、第二个插槽以及两个进一步强化你角色的触发效果。它绝对是你能获得的最佳饰品。
- [[item:270175]]：一个强大的主动使用饰品，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 获得额外奖励时，它不仅提供固定的暴击，还能按需提供敏捷和原始物理伤害。这个选择确实是为踏风量身打造的。
- [[item:270173]]：不止一个，而是你两个毕业饰品都来自这个团队副本。由于其较高的物品等级（以及与一把非常稀有的单手武器的可选搭配），这是其中之一。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271519@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271520@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271517@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271518@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271522@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268215@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 饰品推荐：踏风 武僧

踏风有大量饰品可供选择，我们通常会想要使用一个强大的使用型饰品（如[[item:270175]]用于90秒冷却循环，[[item:273796]]用于2分钟冷却循环）和一个提供强力副属性加成或原始伤害触发的被动饰品的组合。请务必考虑
[宏](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)将你的使用型饰品与你的[[spell:1249625]]施放同步！

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **踏风武僧饰品**
**使用型 -**

[[item:270175]]

用于90秒冷却循环，

[[item:273796]]

用于2分钟冷却循环

**被动 -**

[[item:270173]]

,

[[item:250259]]

，或者

[[item:270164]]

:::

还有不少其他有价值的饰品，所以请务必点击我们的排名图表，看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看踏风武僧饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp"/></span> 影踪派和 <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp"/></span> 天神御师</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]] — 一件极其强大的饰品，甚至在你从史诗难度获得它之前就能达到344。当玩天神御师时，这件饰品会变得更强。</li>&#10;<li>[[item:270173]] — 被提升至S级，因为它是物品等级最高的被动饰品，即使与其他饰品物品等级相同，它也非常强大。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]] — 一件非常强大的饰品，由于其90秒的冷却时间，在玩天神御师时会变得更强。</li>&#10;<li>[[item:273796]] — 来自地下城的最强2分钟饰品，因此如果你玩影踪派，它是可用的最佳地下城使用型饰品。</li>&#10;<li>[[item:250225]] — 一件强大的饰品，但在多目标情况下的扩展性不如其他饰品。</li>&#10;<li>[[item:270164]] — AOE场景中最强的被动饰品，你会看到很多人使用它。</li>&#10;<li>[[item:270165]] — 在被证明是可用的最佳被动饰品之一后，被大幅提升至A级。</li>&#10;<li>[[item:281215]] — 在12.1.5版本中加入，它具备了我们在饰品中想要的一切，并且根据你角色的其他属性，它可能是你角色可用的最强被动饰品之一。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270168]]</li>&#10;<li>[[item:159617]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;0&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:241340]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:270166]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

12.1版本延续了在12.0.7版本中首次引入的额外拾取系统。值得注意的是，对英雄难度团队副本Boss使用额外拾取将使你获得1/6神话等级的物品，因此只要你投入额外的纹章来升级它，就可以相当早地获得一些后期团队副本装备。

**[朦胧虚空核心](<https://www.wowhead.com/currency=3418>)** 可以在完成地下城或击杀团队副本Boss后使用，它会从地下城或Boss的掉落列表中随机奖励你一件物品。一旦通过虚空核拾取获得了一件物品，当你再次对同一Boss或地下城使用额外拾取时，该物品就不会再次出现。

8周后，你还将免费获得一个额外的虚空核心，来源为
**奥琳·微光** 免费获得一个额外的虚空核，该NPC位于银月城的催化器旁边。这将在12.1.5版本上线时发生。

3.1.

#### 踏风武僧的虚空核心推荐用法

你想追求哪件装备，在很大程度上取决于你已经通过（例如） [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)，或者你是否期望以神话难度击败某些Boss以在9/6神话物品等级获得它们。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 史诗[[item:268215]]
2. 神话[[item:270175]]
3. 剩余的毕业装备列表物品

:::

在一个新角色上，我们建议刷那些掉落大量套装部位的地下城，比如来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)，即使你的roll“失败”了，你也能在那里获得一些不错的饰品。套装槽位的物品可以通过催化快速获得多件神话追踪器套装物品，无需依赖大秘境宝库。 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
也会掉落不错的物品，包括一件武器、一件戒指和一条项链，它们将非常实用。最终的最佳选择取决于你从大秘境宝库和潜在团队Boss中已经获得的装备。

3.2.

#### 晋升毒液石

使用你的[[item:280562]]遵循与使用你的纹章类似的优先级列表：

1. 你的武器是最高优先级
2. 你的主动使用饰品
3. 你的被动饰品
4. 你的颈部装备

你还应该优先选择神话品质装备而非英雄品质装备，除非你预计无法获得该物品的神话品质版本。也就是说，如果你不打算击杀史诗难度，那么升级英雄品质的[[item:270175]]或[[item:270168]]是可以的 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) ，那么升级英雄轨道的

1.

### 踏风武僧最佳制作物品

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

由于你将专注于对英雄难度乌拉特克使用额外奖励，这解决了你的双手武器栏位。这意味着你可以直接去制作你最好的两个纹饰。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **踏风制作装备优先级**
- 两件带有[[item:240167]]的皮甲装备，最好选择护腕和披风，因为它们是“预算”最低的栏位。如果你计划最终击杀史诗难度的盘绕祭坛，你可能想要制作护腕和靴子，因为盘绕祭坛掉落344物品等级的背部装备。

:::

4.1.

#### 踏风武僧最佳纹饰

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

由于衬饰的竞争非常激烈，你必须为你整体的DPS输出挑选出最强的两个。大多数衬饰提供的DPS收益非常相似，即使效果完全不同。对此最佳的两个选择是：

- 团队副本：在两件皮甲装备上使用[[item:240167]]，最好选择护腕和披风，因为它们是“预算”最低的栏位。
- 大秘境：在两件皮甲装备上使用[[item:240167]]，最好选择护腕和披风，因为它们是“预算”最低的栏位。

建议你自己模拟一下以找出最适合的方案，如果你也玩另外两个武僧专精，你可能想要选择对所有专精都适用的纹饰。

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于纹章每周获取量有限，而且升级不同物品所花费的纹章数量相同，你应该优先将纹章用在那些你短期内不打算更换的物品上，或是能带来最大收益的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **踏风武僧纹章升级优先级**
**武器（主手）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

➜

**披风/护腕**

:::

当然，这些并不是唯一值得升级的装备。它们只是在赛季初期、你的升级货币有限时能提供最高DPS收益的装备。请注意，例外情况是可能存在的，例如附带额外触发效果的特殊装备。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁更新，添加了升腾虚空石部分和Kithix装备。
- **2026年8月25日：** 更新了武器附魔建议，将树苗饰品下调至B级。
- **2026年8月11日：** 已针对12.1补丁更新，新的装备列表和更新的制造与硬币信息。
- **2026年6月15日：** 已针对12.0.7补丁更新，将项链/戒指/腰带添加到总体和团队副本最佳装备列表。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 添加了制作洛阿戒指的额外选项。
- **2026年3月12日：** 已为至暗之夜第1赛季更新了新内容和结构。
- **2026年3月4日：** 将美化推荐更新为暗月印记：狩猎。
- **2026年2月26日：** 为 至暗之夜 发布进行了审阅和更新，所有装备列表均为全新。
- **2026年2月10日：** 已为至暗之夜前夕更新并进行了审查，几乎无需改动。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已更新至11.2.5补丁，新增了关于谜之财团筹码的章节，并扩展了装备升级章节。
- **2025年8月16日：** 根据第一周的平衡性调整更新了饰品排名。
- **2025年8月4日：** 已更新至11.2补丁，新增了关于莱希裹布的章节，并为第3赛季更新了装备和饰品列表。
- **2025年6月22日：** 根据戒律牧腰带的平衡性调整进行了更新。
- **2025年6月15日：** 针对11.1.7版本更新，新增了关于暗影戒律腰带的章节。
- **2025年5月10日：** 完成/重做了迪纳尔章节。
- **2025年4月21日：** 针对11.1.5版本进行了更新和审查，在迪纳尔章节中加入了贾斯托戒指，并取消了迪纳尔章节的注释(?）。
- **2025年3月24日：** 针对饰品调整更新了饰品和毕业列表。
- **2025年3月16日：** 新增了制作流程图。
- **2025年3月6日：** 更新了头环宝石推荐。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年10月9日：** 审查并更新了饰品推荐。
- **2024年9月9日：** 为地心之战第1赛季更新，添加了美化推荐。
- **2024年8月21日：** 为地心之战上线审查并更新，进行了全面重做。
- **2024年7月23日：** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年5月7日：** 已更新至10.2.7。
- **2024年4月22日：** 为第4赛季进行了审查，更新了毕业装备列表、套装信息，并添加了铸币相关内容。
- **2024年3月19日：** 为10.2.6补丁进行了审查，无需更改。
- **2024年2月14日：** 将蓝色丝绒内衬换入最佳装饰推荐中。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月30日：** 更新了毕业装备列表
- **2023年11月19日：** 修复了借用时间武器的链接问题。
- **2023年11月11日：** 已针对孢子披风削弱进行更新，装饰推荐已重新制作。
- **2023年11月6日：** 为10.2补丁进行了更新和审查，更新了套装信息、毕业装备列表和装饰推荐。
- **2023年9月4日：** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年7月10日：** 为10.1.5补丁进行了更新和审查，添加了关于永恒黎明地下城中唯一物品的信息。
- **2023年5月1日：** 为10.1补丁进行了审查和更新，格式更改、更新了毕业装备搭配等。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已更新至巨龙时代第1赛季，添加了来自化身巨龙牢窟的装备。
- **2022年11月28日：** 已更新至巨龙时代上线，添加了初始地下城装备。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的踏风武僧的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和玩法互动。我们的内容已更新至《魔兽世界》12.1.5补丁。

1.

### 武僧踏风属性优先级

踏风武僧的属性优先级可能因战斗类型和你角色的装备而略有不同，但通常急速、暴击和精通都非常接近，可能会根据你的其他装备而相互超越。

敏捷

急速

暴击

精通

全能

1.

### 深入属性解析

**敏捷** 是你的主要属性。你应该在所有升级中寻找它。它为你提供攻击强度，决定了你技能的伤害。

**全能** 增加你造成的所有伤害和治疗，并减少你受到的所有伤害。

**暴击** 为你大部分法术提供造成双倍伤害的几率增加。请注意，这不会影响[[spell:322109]]和[[spell:122470]]的伤害。

**急速** 为你提供攻击速度和能量回复的增加，并减少你的[[spell:113656]]和[[spell:107428]]的冷却时间。

**精通** （[[spell:115636]]）使你的技能造成更高的伤害（伤害量取决于你的精通值），当它们没有连续使用两次或更多次时。例如，使用[[spell:100784]]和[[spell:100780]]会为两者都提供伤害加成，但如果你连续使用两次猛虎掌，第二次猛虎掌将不再受益于该加成。

:::details 常见问题踏风有属性上限吗？
没有“推荐属性等级”或“X属性的阈值”或任何属性的“必需”数量。这是一种过时的思考属性的方式，对大多数专精来说根本不适用。

模拟你自己的角色总是会更准确，因此推荐这样做。

:::

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 针对至暗之夜 12.1补丁进行审查，明确了属性优先级。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对至暗之夜第一赛季进行审查，将急速移到暴击之上。
- **2026年2月26日：** 为 至暗之夜 进行了审阅和更新，移除了关于前置补丁的提及。
- **2026年2月10日：** 已为至暗之夜前夕更新并进行了审查，调整了属性优先级。
- **2025年11月30日：** 已为11.2.7进行了审查，新增了关于属性上限的常见问题解答。
- **2025 年 10 月 5 日：** 针对11.2.5进行了审阅，无需更改。
- **2025年8月4日：** 针对11.2补丁进行了审阅，无需更改。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 针对11.1.5版本进行了审查，无需更改。
- **2025 年 2 月 24 日：** 针对11.1版本更新，更改了属性优先级。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战上线审查并更新，无需更改。
- **2024年7月23日：** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审查，无需更改。
- **2024年3月19日：** 为10.2.6补丁进行了审查，无需更改。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了更新和审查，更新了天赋推荐。
- **2023年9月4日：** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年7月10日：** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年5月1日：** 为10.1补丁进行了审查，无需更改。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页，我们列出了你的踏风武僧可以获得的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你应该在一个插槽中使用[[item:240983]]。然后，其余插槽可以根据你角色最需要的属性来填充。例如，如果你的装备上已经有很多精通和暴击，你会想要更多的急速，反之亦然。为了匹配你当前的装备，你接下来应该使用提供你最低属性的宝石，每种组合的最佳选择为：

- 急速/暴击（[[item:240890]]）
- 急速/精通（[[item:240892]]）
- 精通/暴击（[[item:240898]]）
- 精通/急速（[[item:240900]]）
- 暴击/急速（[[item:240906]]）
- 暴击/精通（[[item:240908]]）

宝石的选择高度依赖于你的装备。根据你当前穿戴的装备，急速、暴击或精通都很容易成为你模拟最高的属性，因此宝石和戒指附魔的选择可能会有很大差异。

1.

### 最佳附魔和武器强化

你应该在所有内容和场景中使用[[item:243733]]。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>肩部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]]或[[item:243986]]，取决于其他属性</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</tr></table>

1.

### 最佳消耗品

消耗品能在有限时间内大幅提升你的角色实力。任何时候当你挑战困难内容时，建议你使用药剂、食物、药水和武器油来增益自己。

3.1.

#### 药剂和药水

[[item:241325]]是所有内容的推荐选择。

3.2.

#### 药水

对于你的DPS药水，在所有情况下使用[[item:241288]]。

确保也携带[[item:271883]]来治疗自己。

3.3.

#### 食物增益

你应该吃盛宴来增加你的敏捷；[[item:255846]]。在你的背包里也保留一些[[item:242275]]，以防没有盛宴可用。

3.4.

#### 强化符文

虽然昂贵，[[item:259085]]也可用于获得少量额外敏捷。考虑随身携带几个，以备需要榨取每一点可能伤害的时候使用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月25日：** 更新了武器附魔建议。
- **2026年8月11日：** 已针对12.1补丁更新，调整为新的治疗药水。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对至暗之夜第一赛季进行审查，新增了关于血棘茶的说明。
- **2026年2月26日：** 为 至暗之夜 发布进行了更新，所有附魔和消耗品均为全新。
- **2026年2月10日：** 已为至暗之夜前夕更新，调整了附魔和宝石推荐。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 针对11.2.5进行了审阅，无需更改。
- **2025年8月4日：** 已更新至11.2，新增了新的治疗药水。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月22日：** 再次更新腐蚀推荐，因为回响虚空效果不佳。
- **2025年5月18日：** 更新了腐蚀推荐。
- **2025年4月21日：** 针对11.1.5版本更新，新增了腐蚀章节，以防我们何时能获得它。
- **2025 年 2 月 24 日：** 针对11.1版本更新，更改了戒指附魔。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年10月10日：** 修复了一个过时的强化符文章节。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战上线审查并更新，更新了所有推荐内容。
- **2024年7月23日：** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审查，无需更改。
- **2024年3月19日：** 为10.2.6补丁进行了审查，无需更改。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了更新和审查，更新了附魔推荐。
- **2023年9月4日：** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年7月10日：** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年5月1日：** 为10.1补丁进行了审查和更新，移动了原初之石部分并添加了暗影烈焰附魔。
- **2023年3月20日：** 为10.0.7补丁进行了审查，添加了原初之石部分。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的踏风武僧应对大秘境地下城的技巧和建议。

1.

### 踏风武僧在至暗之夜第2赛季大秘境中的表现

踏风武僧在大秘境中的玩法核心在于尽可能多地使用[[spell:113656]]。除了每次可用时都施放[[spell:113656]]之外，你还想要施放像[[spell:107428]]、[[spell:100784]]和[[spell:101546]]这样的技能，以通过[[spell:392993]]和[[spell:261917]]天赋来减少[[spell:113656]]的冷却时间。这涵盖了最大化你的单体和AoE伤害。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

踏风武僧在大秘境中通过像[[spell:116844]]和[[spell:119381]]这样的法术提供强大的团队辅助能力。虽然过去在伤害方面与顶级专精相比有所挣扎，但踏风应该能够在大多数钥石等级上竞争，并且每个赛季都有踏风武僧冲击最高头衔。你可以根据自己的喜好选择任一英雄天赋专精来玩，尽管影踪派通常被推荐，因为它具有更高的AoE潜力和更简单的操作。天神御师在经验丰富的玩家手中并且时机把握得当时可能会更强。

1.

### 最佳大秘境天赋配置

### 标准大秘境天赋构建—— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派

这是我们针对大多数大秘境场景的推荐配置。虽然两个标准配置之间的表现非常相似，但这个 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派版本稍微更容易执行，因此推荐用于你的每周钥石副本。

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYAMGbzMz2MAAAAAAAAAAAALDzEmxywAmxwMzMDz2wMMLzEAwiZ2mZGzMzMAA2AgZZWamZmFAMwMDAswAGwA"
}
```
:::

:::details 来源计算器编码
```
#NE-JLYamQRThnHIQkyOBI4CDzzsV12G3XQSStR-pBCEMoAASTcimnORUVv8CSWC1ST3XYL-AAAA-FGUYcgoYhpJQCA-*
```

:::

### 进阶大秘境天赋配置 —— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) 天神御师

这是我们针对高层大秘境场景的备选进阶配装方案。相比其 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) 影踪派对应版本稍微更难执行好，但如果你能玩得好，表现可以更高。

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAswsxMmZmZAAsYmlZZMBAAmxAYGgxyAYmZ2M"
}
```
:::

:::details 来源计算器编码
```
#NE-GHIJNTpuzSZnQRZBMchh5ZGU9Fkks12G3oG-pBCEMoAASTimnORUVv8WaAxSTXI5KbL-AAAA-EMQowIRZhpJQAC-*
```

:::

1.

### 功能技能与能力

### 打断

3.1.

#### 打断

[[spell:116705]]是你的“打断”，也是你在大秘境中最重要的辅助技能，用于为团队尤其是坦克打断敌人的施法。它是 **强烈推荐** 使用焦点打断宏来完成此操作。

#### 焦点打断宏

```wow-macro
#showtooltip 切喉手
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 切喉手
```

这个宏会打断你的焦点目标（如果有），如果没有焦点目标则打断鼠标悬停目标，如果两者都没有则打断你的当前目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**.

#### 焦点鼠标指向宏

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

### 眩晕和打断

3.2.

#### 眩晕与“停手”

[[spell:119381]]是你的“AoE打断”。它会击倒 **是可以的。** 半径范围内的所有目标，打断他们的施法。

[[spell:116844]]是游戏中控制敌人最有用的技能之一。它能打断施法并让敌人更好地定位。

[[spell:115078]]是一个有用的长效控制技能，用于隔离目标，使他们不参与战斗。如果其他选择不可用，它也可以用作打断。

### 其他功能

3.3.

#### 其他功能

[[spell:115450]]是一个有用的技能，帮助移除可能存在的中毒或疾病减益效果。

[[spell:8647]]是所有武僧都会提供的一个减益效果，增加目标承受的物理伤害。它会自动施加在任何被击中的目标上。在物理阵容中特别有用！

[[spell:116841]]可以作为速度提升或解除移动受限效果的方式，用于你自己或其他玩家。

[[spell:157411]]在踏风周围提供光环范围内的移动速度提升。虽然很少直接受益，但在无法骑乘的地下城中可以节省几秒钟，并且也能帮助玩家稍微快一点地移出危险效果。

它很少会是必不可少的，但[[spell:116095]]可以对目标造成50%的减速，加上踏风令人难以置信的其他控制技能，每一点帮助都有用。

[[spell:101643]]可以通过将你的灵魂放在一个地方，然后在那个地方安全后传送过去，用来跳过地面上的许多机制和其他东西。

1.

### 应对词缀

至暗之夜第2赛季只有四个提供某种应对方式的重要词缀，称为萨拉塔斯的交易。这些每周轮换，同一时间只有一个生效。许多大秘境词缀，如强韧或残暴，只是给钥石添加一个被动效果，而这四个例外则是以萨拉塔斯为主题的赛季词缀。

### 词缀：升腾

4.1.

#### 踏风武僧的升腾词缀管理

踏风武僧拥有大量技能可以应对这个词缀产生的球体的[[spell:403766]]施法。其中包括你的[[spell:116705]]、[[spell:115078]]，甚至[[spell:116844]]或[[spell:119381]]。然而，你可能想要避免过度投入资源来阻止这个词缀，以便仍然可以将它们用于地下城的传统小怪战斗；请谨慎选择你的工具。

### 词缀：虚缚

4.2.

#### 踏风武僧的虚空束缚词缀管理

此词缀触发时生成的虚空使者只有1点生命值，其余生命值均为吸收效果。这意味着你的[[spell:322109]]可以立即对其使用，造成全额伤害，从而大幅削弱其威胁。以这种生成频率，你可以在大多数情况下对虚空使者使用轮回之触。这也意味着在副本的“常规”时段你将无法使用该技能。

### 词缀：脉冲星

4.3.

#### 脉冲星词缀应对——踏风 武僧

你 **无法** 独自收集绕你角色旋转的 [[spell:1216858]]。它 **必须** 可以被另一名玩家走进去收集。此外，这些脉冲星总是顺时针旋转；利用这一点以及你自身的机动性，快速收集处于近战范围内的其他玩家的脉冲星，以避免过多干扰敌人的位置。

### 词缀：吞噬

4.4.

#### 吞噬词缀应对——踏风 武僧

[[spell:440313]]的吸收效果可在受到相当于你最大生命值53%的治疗后移除，或使用[[spell:115450]]立即移除。如果你也点出了[[spell:388812]]，在驱散次数不足时，可以考虑对自己进行驱散，并使用瞬发的[[spell:116670]]来帮助另一名玩家。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 针对至暗之夜第二赛季更新，更新了天赋构建。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对至暗之夜第一赛季更新，幸运的是几乎不需要改动
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已为至暗之夜前夕进行了审查，移除了S3相关提及，天赋变更通过包含文件完成。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 针对11.2.5进行了审阅，无需更改。
- **2025年8月21日：** 修复了图像块导致天赋和实用技能显示混乱的问题。
- **2025年8月4日：** 针对11.2补丁进行了审阅，无需实质性更改，秘境+提示已注释掉，并将天赋构建拆分开来，尽管它们是相同的。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月27日：** 新增了大秘境提示。
- **2025年4月21日：** 针对11.1.5版本进行了审查和更新，无需更改。大秘境提示稍后跟进。
- **2025 年 2 月 24 日：** 为11.1版本更新，暂时注释掉了副本提示，将湮灭换成了脉冲，提供了踏风和天神御身两套天赋配置
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 为每个副本添加了大秘境提示。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年7月17日：** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审查，无需更改。
- **2024年3月19日：** 为10.2.6补丁进行了审查，无需更改。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了更新和审查，更新了天赋推荐。
- **2023年9月4日：** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年7月10日：** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年5月1日：** 为10.1补丁进行了审查和更新，移除了风暴之拥。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已更新至巨龙时代上线，添加了风暴之拥信息，移除了暗影国度相关内容。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一系列实用的宏和插件，帮助你在《魔兽世界》12.1.5补丁中游玩你的踏风 武僧时更加轻松。

1.

### 最佳宏

欢迎来到我们的插件与宏页面。在这里，我们将介绍一些实用的插件，帮助你通过更信息丰富的界面提升游戏体验，同时还会提供一些常用的踏风 武僧宏。

1.1.

#### 武僧通用宏

1.1.1.

##### 清创生血 鼠标悬停宏

#### 清创生血 鼠标悬停宏

```wow-macro
#showtooltip 清创生血
/cast [@mouseover,help,nodead] 清创生血;清创生血
```

使用此宏将对你的鼠标悬停目标施放 [[spell:218164]]，前提是他们是友方玩家且未死亡。否则，它将对你的当前目标施放 清创生血。

1.1.2.

##### 迅如猛虎鼠标悬停宏

#### 猛虎之赐鼠标悬停宏

```wow-macro
#showtooltip 迅如猛虎
/cast [@mouseover,help,nodead] 迅如猛虎;迅如猛虎
```

使用此宏会在你的鼠标悬停目标为友方玩家且未死亡时，对其施放[[spell:116841]]。否则，它会对你的当前目标施放迅如猛虎。

1.2.

#### 踏风武僧专用宏

幸运的是，踏风并不是一个必须依赖宏才能发挥作用的专精，但仍有一些宏可能会有所帮助。

1.2.1.

##### 无打断引导宏

#### 无打断引导

```wow-macro
#showtooltip 猛虎掌
/cast [nochanneling][channeling:Spinning Crane Kick] 猛虎掌
```

该宏允许你在引导[[spell:113656]]、[[spell:117952]]和[[spell:443028]]期间连按下一个技能而不会打断引导。将[[spell:100780]]替换为你想让宏使用的技能。

对于[[spell:152175]]和[[spell:392983]]，你需要一个特定的宏才能将它们绑定在同一按钮上。如果将它们保持为独立按钮，请使用上面的宏。如果要在同一键位上使用它们，请使用下面的宏。

#### WDP/风领主之击 无打断引导

```wow-macro
#showtooltip [known:392983] 风领主之击; 升龙霸
/stopmacro [channeling:Fists of Fury]
/stopmacro [channeling:Celestial Conduit]
/cast [known:152175] 升龙霸
/cast [known:392983] 风领主之击
```

1.2.2.

##### “爆发”宏

#### 乾元之巅、饰品与药水

```wow-macro
#showtooltip 乾元之巅
/use [pet][known:450615]13
/use [mod:shift,pet][mod:shift,known:450615]item:245898
/use [mod:shift,pet][mod:shift,known:450615]item:241308
/cast 乾元之巅
```

此宏会按正确顺序使用你的主动属性饰品和药水，使你的[[spell:1272694]]在施放[[spell:1249625]]时也能受到属性增益的影响。

1.

### 最佳插件

2.1.

#### 武僧通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.4.4.

##### Omen 仇恨统计

[Omen 仇恨统计](<https://www.curseforge.com/wow/addons/omen-threat-meter>)
是显示当前目标仇恨水平最流行的插件。我们建议你使用它，以避免在坦克仍在对敌人建立仇恨时抢到仇恨。

2.5.

#### 踏风武僧专属插件

目前，我们认为你不需要任何额外的插件来充分发挥你专精的潜力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 针对至暗之夜 12.1补丁进行审查，无需更改。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对至暗之夜第一赛季进行审查，新增了WDP/SotW不取消宏。
- **2026年2月26日：** 为 至暗之夜 发布进行了审阅，添加了“爆发”宏，并更新为新格式。
- **2026年2月10日：** 已为至暗之夜前夕进行了审查，将不打断宏更新为较新版本。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了审阅，无需实质性更改。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战上线审查并更新，进行了细微的文字修改。
- **2024年7月23日：** 为《地心之战》前夕补丁进行了审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审查，无需更改。
- **2024年3月19日：** 为10.2.6补丁进行了审查，无需更改。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁进行了更新和审查，无需更改。
- **2023年9月4日：** 为10.1.7补丁进行了更新和审查，无需更改。
- **2023年7月10日：** 为10.1.5补丁进行了更新和审查，无需更改。
- **2023年4月30日：** 为10.1补丁进行了更新和审查，无需更改。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
