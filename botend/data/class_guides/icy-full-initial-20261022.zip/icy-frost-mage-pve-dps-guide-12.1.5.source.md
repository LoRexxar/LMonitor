## 专精概览

Welcome to our Frost Mage guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Frost Mage in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Frost Mythic+ Resources

[NEW! Top Frost Talent Builds](<https://raider.io/specs/frost-mage/talents>)

[Top Frost Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/mage/frost>)

[Frost Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=mage--frost>)

[Popular Frost Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=mage--frost>)

1.

### Frost Mage Overview

Frost has always excelled at limiting enemy movement while dealing
reliable and predictable damage. Frost has always been a
very potent choice for levelling and world content, given you can endlessly kite
enemies with a multitude of snares and roots.

Solid, usable everywhere despite no niche

Frost feels solid, and is tuned fairly highly. While we are not the best at any
specific thing, not having to rely on cooldowns means that we have pretty
consistent throughput pull to pull. We do not lose very much single target
damage to take our AoE talents, and aside from

[[spell:205021]]

's relative
fragility, Frost is a very good spec to go into encounters blind with.

Solid, great to learn fights with

The ease of playing the spec combined with the damage performance means that
Frost is a safe pick for most people.

Likely meta

The minimal single target loss taking AoE talents combined with the relative
ease of the spec, and the extreme utility we bring means that we are almost
always welcomed into Mythic+ runs.

Mages remain god-kings of utility

We are Mages. Slows, roots, an AoE stop,

[[spell:414664]]

, a target
drop,

[[spell:475]]

, a shorter-than-usual caster interrupt, the ability to
break certain jumping trash mobs, the list goes on. You name it, we have it.
Mage, as a whole, is brought to Mythic+ for our utility. It is why we remain
meta even when our DPS is not the highest.

Squishy

Defensive pruning has hit Mage particularly hard. 12.1 brings us nerfs to

[[spell:11426]]

and

[[spell:1244090]]

. Mage is having issues
surviving at the highest levels of play, but is perfectly viable for anything
short of Mythic+ title range.

Shimmer's still here, but...

Frost has a considerable amount of instant cast spells, although most are
utilized on cooldown. Our major cooldown,

[[spell:205021]]

has absolutely no
movement protection, functionally wasting our main cooldown if any mechanic is
thrown on top of you. While

[[spell:212653]]

exists, the increased cooldown
means that you are functionally going to keep it for Ray casts, just in case.
Likewise, our AoE is now primarily hard casting, rather than the instant cast
spam it was prior.

2.

### Frost Mage in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 is a mid-season refresh patch. Complete with a new single-boss
raid, the Unbinding of Kith-ix, and an upgrade to the delve system with the
Labyrinth of Kindo'jan! Make sure to view our pages on those new encounters
below!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

Aside from the raid and Labyrinth, there are a few new interesting things to
do, gear pathways to catch up with, and item level upgrades to be had. Please
check out the rest of the patch's content with our Patch 12.1.5 Overview.

2.3.

#### Class Changes

The patch also brings with it a number of bug fixes for long-standing 12.0
bugs Frost has had to either deal with or benefit from, but no real changes
mechanically.

Additionally, you should check out our
[gear](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>) page, as the new raid brings
new gear, and [[item:280562]]s will upgrade some of your
equipment.

- [[spell:56377]] now properly behaves with [[spell:116]], for cleave range, damage changes, and Hero talent swapping.
- [[spell:56377]] now properly works with [[spell:431166]], allowing the primary target to explode as well as the secondary.
- [[spell:112965]] and [[spell:1247729]] state for in-flight [[spell:30455]]s no longer break when fighting bosses with very large hitboxes, or at excessively high Haste.
- [[spell:1247544]] no longer breaks if you chain two [[spell:205021]] casts into each other.
- [[spell:431166]]'s bug has been codified in the tooltip rather than changed, which is to say, it takes the proc rate from 25% to 26.5% and this is intentional.
- [[spell:443783]] is now trackable in the Cooldown Manager.
- [[spell:443783]] no longer resets on encounter start, allowing you to pull a boss with [[spell:205021]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostbolt02.jpg>) Click for Previous Season 2 Changes
- **12.1 Launch**
  
  
  - [[spell:1244090]] has been adjusted to heal over time, rather than at once.
  - [[spell:11426]] has lost ~16% of its strength.
  - [[spell:1244110]] now provides a 30-second cooldown reduction to [[spell:414659]].
  - [[spell:1297073]] is a new class talent that provides us with 4% AoE damage reduction.
  - [[spell:56377]] and [[spell:378448]] have been nerfed.
  - [[spell:1262981]]'s damage buff has been nerfed, in exchange we have been buffed with global damage.
- **August 25 Hotfix**
  
  
  - [[spell:11426]] returned to pre-12.1 value.
  - [[spell:190356]] damage buffed 10%.
  - [[spell:1248825]] area damage buffed 10%.
  - [[spell:431095]] damage buffed 25%.
- **September 1 Hotfix**
  
  
  - All damage increased 6%.
- **September 22 Hotfix**
  
  
  - [[spell:84714]] buffed 15%.
  - [[spell:1247777]] buffed 50%.
  - [[spell:1248825]] area damage buffed 10%.
  - [[spell:378947]] damage buffed 50%.

:::

### Midnight   Changes Overview

2.4.

#### Midnight Changes to Frost Mage

Midnight is here, and Frost has been revamped from the ground up. Throw out
anything you know about the spec, this is the single largest change this spec
has seen in the history of the game.

The primary component is [[spell:1246769]] being changed from a Crit
bonus to a stacking debuff on the enemy, consumed by [[spell:30455]].
Functionally the same idea, where Shatter is a buff to your spells, but split
out into its own damage segment. Because of this, the freezing state no
longer matters to our DPS.

2.4.1.

##### Apex Talent

The Apex talent is a unique node you unlock as you level. You can choose to
put points gained from levelling into it, and you probably should given its
relative power. For Frost Mage, we get [[spell:1262935]] [[spell:1262981]]
and [[spell:1263249]], adding extra incentive to Shatter things, significantly
increasing the power of [[spell:205021]], and a second charge of Ray of Frost,
giving us flexibility in how we use it.

2.4.2.

##### Hero Talent Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger has had Splinters reduced to impact damage only,
with the old Storm mechanic changed into a random proc, since they are no
longer a stacking debuff on target. Changes to the passive buffs of the tree
have integrated it with the [[spell:1246769]] mechanic.
[[spell:444986]] remains nerfed, and with the loss of the Season 3
tier bonus, [[spell:84714]] refreshes have become significantly more
rare.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire loses the [[spell:438595]] and [[spell:438600]]
buffs in exchange for focusing more on core spell buffs. Notably
[[spell:44614]] becomes Frostfire with a new animation, [[spell:199786]]
explodes on impact, and the TWW S3 tier bonuses become new Hero
Talents.

2.4.3.

##### Rotational Aspects

The general idea of the new spec is to build [[spell:1246769]] on the target
using [[spell:116]] and [[spell:44614]], and consume them with
[[spell:30455]]. This is complicated by random procs adding more stacks, and
wanting to keep the stacks below a certain threshold.

[[spell:199786]] and [[spell:1247777]] have been removed as
stand-alone spells, and instead transform your [[spell:116]] and
[[spell:205021]] respectively, when they are available.

2.4.4.

##### Cooldown Adjustments

[[spell:12472]] has been removed, and our main cooldown is now
[[spell:205021]].

With the loss of [[spell:108839]], and [[spell:205021]] going on cooldown
at the beginning of the cast, this is an extremely fragile cast. Any form of
knockback, interrupt, or even dropping fire under your feet will mean the loss
of your only cooldown. While [[spell:212653]] still exists, its cooldown has
been increased and will only deal with one of those situations. Thus Ray of
Frost is going to require you pay a lot of attention to the mechanics of every
mob you are in combat with, lest you lose the cast.

2.4.5.

##### AoE DPS

The cooldown reduction on [[spell:84714]], from [[spell:190356]], has
sadly been removed. This does mean that we can no longer rely on instant cast
Blizzards at all times during AoE, and will instead have to hard cast it. It
also means that Frozen Orb is not something that will be available on every
pull.

[[spell:1247777]] is now also double the cooldown, as it is now linked to
casting [[spell:205021]].

[[spell:417493]] has been removed as well, removing our AoE burst
potential. In its stead, [[spell:1247090]], but as of current tuning and
inability to take advantage of multi-target Freezing stacks, it is unlikely that
it will be selected in any situation.

Instead, [[spell:1248825]] adds an AoE component to [[spell:1246769]], and
[[spell:1247775]] deals that same damage when a mob with Shatter stacks dies
early. This means that our AoE is functionally our single target rotation, with
an added [[spell:190356]] cast on cooldown. [[spell:1247777]] now Shatters
stacks per comet impact, leading at least ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire to try and stack
as much passive AoE Freezing stacks as possible between Comet Storms.
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger has hooks attached to [[spell:30455]] and will try and
Shatter as much as possible in between them, however.

2.4.6.

##### Defensive Changes

The removals and tweaks to existing spells are behind the click-through:

:::details ► **Click to expand**
- [[spell:55342]] no longer provides a damage reduction, and the duration
  of the copies have been reduced to 15 seconds.
- [[spell:110959]] likewise no longer provides a damage reduction.
- [[spell:11426]]'s cooldown has been increased, but the GCD has been
  shortened for it.
- [[spell:414660]] has been removed entirely.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger's [[spell:444827]] has been nerfed to half
  value, and [[spell:444784]] is now entirely useless due to the changes
  to [[spell:55342]].

:::

[[spell:1244090]] has been added, which will whenever
[[spell:342245]] is not on cooldown when you hit 24% health, instantly heal
you for 50% of your max health. This is extremely strong, but does take away
actually using Alter Time. For the average player, this is the better option, as
it will always get better than average use out of Alter Time.

[[spell:1244110]] is a choice node against [[spell:235219]]. Giving us
a second charge of our only real active defensive spells is very powerful. While
Cold Snap will have niche uses, as the cooldown is ticking concurrently to our
other spells, there is a psychological aspect of not wanting to "waste" Cold
Snap on just [[spell:11426]]. Glacial Bulwark instead sidesteps that, in
exchange for sequential cooldown timers. This is likely the go-to for everyone.

2.4.7.

##### Utility and Movement Changes

We lost a good deal of utility and movement. The highlights are as such:

:::details ► **Click to expand**
- [[spell:157981]] has been removed.
- [[spell:108839]] has been removed.
- [[spell:382826]] has been removed.
- [[spell:212653]]'s cooldown has been increased and the second charge split
  into a different talent.
- [[spell:1953]] gains access to a second charge through said talent.
- [[spell:387807]] has been changed to a flat 5 second cooldown
  reduction, rather than scaling every time we [[spell:30455]].
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire's utility node is nearly entirely useless with the loss
  of [[spell:157981]].

:::

3.

### Basics of Frost Mage Gameplay

Frost is all about generating and consuming [[spell:1246769]], and utilizing
your procs. The gameplay is incredibly simple to understand.

Everything you do revolves around [[spell:1246769]]. Almost every spell in
your arsenal will generate stacks on your target, which can then be spent by
[[spell:30455]] for bonus damage. Your two procs are [[spell:190447]],
which allows use of a hard hitting spell that adds significant amounts of stacks
to the target, and [[spell:112965]] which allows your Ice Lance to deal
the maximum amount of bonus damage, without actually consuming those stacks.

To provide you with a condensed breakdown of what Frost Mage is built around, the bulleted 
list will briefly describe its main focal points.

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_freezing.jpg>) **Optimize Freezing Usage**  
  
    The majority of Frost's damage comes from [[spell:1246769]], but it is almost impossible 
    to never waste any. Instead, minimizing what you waste is one of the core tenets. 
    Conversely, [[spell:1247729]] can proc while you are at a low stack count, and it may 
    be worth your time to quickly consider if you can add more to the stack to fill it out 
    before the Thermal Void buff ends. Keep in mind that the duration is longer than 
    [[spell:205021]]'s cast time, and you can absolutely cast [[spell:44614]] prior to 
    Ray, and still benefit from Thermal Void afterwards.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_wintersgrasp.jpg>) **Minimize Proc and Cooldown Waste**  
   
    Using [[spell:112965]] and [[spell:190447]] quickly means that you minimize 
    the odds of over capping them. Likewise, [[spell:84714]] and [[spell:199786]] 
    take a rather high priority when they come up, and reacting to them being available is 
    very important. Make sure you are not sitting on 2 full charges of [[spell:205021]]. 
    While this sounds easy, this spec can easily overflow you with resources leading you to 
    missing something coming up, or being stuck in a situation where your cooldowns are not 
    ticking.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostblast.jpg>) **Always Be Casting**  
  
    Suboptimal plays, such as partial stack [[spell:30455]], are better than 
    doing nothing while moving. Make sure your GCD is rolling at all times. We 
    have a ton of instant cast damage spells, or you could [[spell:11426]] while 
    moving just for something else useful during movement.

4.

### How to Gear Up as a Frost Mage

While we always recommend simming yourself for ideal results, we do provide a
dedicated Frost gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5 with new trinket and Venomstone priority.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for 12.1.5.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated with trinket tier list for Season 2, BiS lists.
- **10 Aug. 2026 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1 with preliminary BiS lists.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Opener tweaks.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for 12.1.
- **10 Aug. 2026 (this page):** Updated for 12.1.
- **15 Jun. 2026 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7 with Rotmire drops.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for 12.0.7 with minor Frostfire tweaks.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for 12.0.7, added Omnium Folio recommendations, added a light cleave/raid talent set by request.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **21 May 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Added FAQ about Crit vs Mastery enchants/consumables.
- **20 Apr. 2026 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Speed teas no longer work in instances.
- **22 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** New opener for Slinger single target.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated with links to our general levelling guide, and heirloom notes.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Added ArcUI and an import code.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Added gathering teas to list of consumables. Re-added tertiary enchant total comparison.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Added a note about the tier set for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **09 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Fixed mouseover macro for Remove Curse.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Added a level 80 talent import string for returning players.
- **28 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Ring enchant and flask recommendations changed.
- **28 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Wording tweaks and added a note that single target is still used on 2t.
- **28 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Minor intro tweak.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** More priority changes.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for Midnight Launch.
- **26 Feb. 2026 (this page):** Updated for Midnight Launch.
- **11 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated priorities AGAIN, theorycraft moves fast during patches.
- **10 Feb. 2026 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated priorities, added FAQ about Slinger's Freezing usage on single target.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **20 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Fixed a typo and One Button does use Frost's cooldowns now.
- **19 Jan. 2026 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7 and added FAQ widgets.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated with a section noting Cartel Chips, item levels raised in BiS lists.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **23 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Added trinket tier list and marginal changes to BiS list.
- **23 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Added Season 3 tips.
- **23 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Slinger casts Comet Storm in single target again, Shifting Power constrained.
- **06 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Fixed crafted section recommending cloak instead of bracer.
- **04 Aug. 2025 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for 11.2.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Last minute APL changes to simplify rotation slightly.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Charged Bolts nerfed.
- **15 Jun. 2025 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for 11.1.7.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated with the new Delve belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Added section on Combat Assistant for 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated with thoughts on Combat Assistant in 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **21 Apr. 2025 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for 11.1.5.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated the BiS list's trinkets, added Puzzling Cartel Chip section.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for 11.1.5's Corruption Enchant.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Minor tweaks to wording and which Hero spec is better.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **21 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Cyrce's replacement note added, tier set fixes.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Updated for Gallywix and some minor tweaks to other tips.
- **16 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated with Season 2 dungeon tips.
- **02 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Logic fix on Frostfire AoE vs Excess Fire.
- **28 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated overall BiS list.
- **28 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Minor tweak to Frostfire's Flurry logic, and updates to Slinger's DC AoE constraints.
- **24 Feb. 2025 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for 11.1.0.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Cyrce's Circlet massively buffed at launch.
- **15 Dec. 2024 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for 11.0.7.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for 11.0.7 and Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated to contain both standard Frost and Boltslinger variant rotations for both Hero Talent options.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated with Boltslinger and Standard talent option recommendations.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for 11.0.7.
- **15 Dec. 2024 (this page):** Updated for 11.0.7.
- **27 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated with new theory for 11.0.5.
- **27 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated with new theory for 11.0.5.
- **27 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated with new theory for 11.0.5.
- **27 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated with new theory for 11.0.5.
- **27 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated with new theory for 11.0.5.
- **22 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Added Season 1 dungeon tips with things we can deal with our utility casts.
- **22 Oct. 2024 (this page):** Updated for 11.0.5.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Added Ansurek tips and did an update pass on the others.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Added Signature Spell.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **07 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Minor wording changes.
- **09 Sep. 2024 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Page added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **27 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Removed GS from AoE rotation for a minor gain.
- **21 Aug. 2024 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **30 Jul. 2024 ([cosmetics](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** Page added.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/frost-mage-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/frost-mage-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/frost-mage-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.6, going back to Tepid Versatility in all situations.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6, did a minor pass fixing details that slipped through hotfixes.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **14 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Glacial Spike is cast without Flurry regardless of Icy Veins status now.
- **12 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Minor clarification on Ray of Frost/Frozen Orb.
- **12 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** BiS list and farm lists added for Season 3.
- **12 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Removed an outdated paragraph in section 3.2 and replaced it with a more in-depth dive on proc usage since the 10.1.5 changes.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Sporecloak nerfed.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Partial update for 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated with 10.2's consumables and new head enchant.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Added information about T31's impact on our 2 target DPS.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **08 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Changed wording in the Trinkets section
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.7
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.7
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7
- **11 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Shifting Power should be used in Icy Veins, once RoF/CmS/FO are on cooldown.
- **01 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Added missing rotational piece for casting Glacial Spike during Icy Veins without Flurry proc.
- **18 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Made an explicit rotation guide to go alongside the more general theory of why things are played as they are.
- **15 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Subzero nerfed enough to not be worth taking in most M+ setups.
- **11 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5 with tier/profession slot suggestions, and a note about Dawn of the Infinite's gear being untested.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for 10.1.5 with new phial and weapon rune suggestions.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.5's rotational and talent changes.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5's rotational changes. Potentially further changes as theorycraft evolves over the next couple of months.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.5's significant overhauls.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for Patch 10.1.5's changes.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for Patch 10.1.5 with a new talent tree.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **11 May 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Re-added Bloodmallet charts.
- **07 May 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Season 2 start with trinket suggestions in the wake of the Flowstone nerf.
- **07 May 2023 (this page):** Updated for Season 2 start. Todo list down to M+ mechanics to cheese.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Added the Season 2 upgrade system, Season 2 interesting items, and suggested embellishments.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Added the new belt enchant.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight Season 2, and added a section about affixes we can trivialize.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Added toggles for the AoE rotation set. Less Lance is down to 1.7% lead.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated Honour Talents and removed a handful of bugged interaction notes.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.
- **01 May 2023 (this page):** Updated for Patch 10.1, and added guide updates section and upcoming updates section.
- **29 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Removed ElvUI, added mouseover decurse for Afflicted.
- **23 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Onyx Annulet is no longer a DPS loss.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stone section with new recommendations due to hotfix changes.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/frost-mage-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Added a note about Onyx Annulet.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Added notes about Primordial Stones.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Changed the default talent tree.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Added notes about the Less Ice Lance rotation set.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated default talent trees.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Reviewed for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **10 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated Phial choice, and added Rune choice.
- **22 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Changed default build to Lonely Winter due to hotfix buffs.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for beginning of Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for beginning of Dragonflight Season 1 with weapon enchant and food choice changes.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Added a note about Lonely Winter/Water Elemental decision.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Blizzard target values with/without Ice Caller.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/frost-mage-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/frost-mage-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/frost-mage-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **10 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/frost-mage-patch-9-2-changes-analysis>)):** Updated with the last minute Blizzard/Frozen Orb nerfs.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/frost-mage-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/frost-mage-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/frost-mage-patch-9-1-changes-analysis>)):** Wording updated for live release of Patch 9.1.
- **25 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/frost-mage-patch-9-1-changes-analysis>)):** Page created with initial information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **13 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-the-eternal-palace-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **04 Sep. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-the-eternal-palace-raid-guide>)):** Added clarification that Glacial Spike does not kill melee on Za'qul, and minor tips elsewhere.
- **20 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-the-eternal-palace-raid-guide>)):** Updated with tips.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **12 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-crucible-of-storms-raid-guide>)):** Updated tips and build recommendations.
- **14 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **29 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated tips, both for hotfix changes and practical experience.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added Battle of Dazar'alor guide for Frost Mages.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **16 Oct. 2018 ([Uldir page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** Updated a few talent suggestions after having actually done the raid.
- **01 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** Added Uldir advice.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Frost Mage leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Mage leveling guide](<https://www.icy-veins.com/wow/mage-leveling-guide>).

1.

### Frost Mage Leveling Guide for Midnight

Frost Mage, being able to kite almost everything, can 
effectively kite and kill large swaths of mobs at once. Even if you wish to 
take it slowly and target one mob at a time, the fact that we have passive 
slows on almost everything we have means that we will be nearly untouched in 
outdoor content.

If you are feeling foolhardy, Frost has an excellent toolkit to pull multiple
mobs and survive unscathed relatively early. Always have [[spell:11426]]
active if you are going to pull something that will not die quickly. Remember
that you do have [[spell:66]] at level 1, as a quick escape if
you have gotten in over your head.

There are two schools of thought to playing Frost
at a low level. The first is playing it safe, [[spell:116]] provides a
heavy slow to any target you hit with it. You will rarely take damage, although
you are limited to safely pulling one mob at a time. The second throws caution
to the wind and spams [[spell:1449]], as it deals the same damage as
a Frostbolt, but without the cast time and in AoE. The downside is you will
take damage due to the close-range nature of this ability, but you will kill
significantly quicker if you pull multiple at once. You will also have to
regenerate Mana, as Arcane Explosion costs 10% of your total Mana per cast.
This is more usable with heirlooms, as you have significantly more Intellect
versus the gear you would have from standard levelling quests.

1.1.

#### Leveling Gear Options

When leveling up, you should always choose the piece of loot with the
highest item level.

When using Heirloom items, the recommendation will change slightly depending
on if you have some older exclusive items or not. If you are lucky enough to
have [[item:105690]], that stat combination is the best potential
you could get. Otherwise, [[item:122353]] is suitable. Try
and focus on pieces that have Mastery or Crit, but do not worry too much about
being "optimal" while levelling.

1.2.

#### Useful Leveling Consumables in Midnight

Speed is almost always the most useful consumable stat to get while out in
the world. Getting point to point is always going to be the bulk of your time
spent, and that goes double for time spent on the ground looting mobs.

[[item:132516]] are functionally a run speed potion that propel you
forwards at great speed. These are fantastic to have a stock of, as they have no
level requirement and can get you across a quest area incredibly quickly. You
can also [[spell:66]] afterwards, and drop all aggro you might have
pulled along the way.

[[item:109076]]s are a nice thing to have for jumping around cliffs,
especially in areas you cannot mount in, such as a cave interior.

[[item:225592]], or the equivalent lower level speed
food is a nice bonus, although lost on death, and fairly minor.

[[item:191348]] is a Speed flask to go with the above food,
again this is simply a nice bonus to have at higher levels when speed flasks
actually become a thing.

Realistically if you have a decent stock of [[item:132516]], that is about
all you should really care about if you truly wish to optimize time spent
levelling.

2.

### Leveling Talents

It is possible to follow Blizzard's "Starter
Build", as it seems to be a fairly decent talent tree with a healthy mix of
open-world damage and some AoE. The order in which it presents talents to you can be
questionable, however. This guide will follow a slightly different path, but
feel free to experiment. You can change talents at any time outside of combat,
as long as you are not trying to talent out of something that is currently on
cooldown. You can always return to the guided Starter Build at any time by
selecting it from your build dropdown menu on the talent UI.

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Frost Level 80 Midnight Levelling
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmNmZmYmxMzMzMziZmZMmZmlZamZZWAAAgFAAAAAAYBgttxMzMY2mxYGbbAAAgZGMgBAGGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmNmZmYmxMzMzMziZmZMmZmlZamZZWAAAgFAAAAAAYBgttxMzMY2mxYGbbAAAgZGMgBAGGA"
}
```
:::

:::details 来源计算器编码
```
#AB-SdXWErssYaOmlMFFtFCBB+pcQIwrAFQ7SFB-JFgDHWUoyI0QEMB4g0lRHHnW1DGm1vR-AAAA-UYckgAohZJgQxA-
```

:::

2.1.

#### War Mode Talents for Leveling

In this section, we will rank the PvP talents best for
leveling and doing solo / small group PvE content.

1. [[spell:390612]] is likely the best DPS talent of the War Mode talents.
2. [[spell:198148]] increases [[spell:84714]]'s damage
   by 10%, and allows it to be placed on the cursor. You lose the ability for it to
   track your target, but the DPS gain is a worthwhile trade.
3. [[spell:389794]] gives you access to an AoE stun that deals minor damage.

The rest have limited use in PvE content in terms of increasing 
your damage in the open-world, but they can be situationally
useful if you wish for defensive bonuses.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

3.1.

#### Single Target

1. **等级 29 起：**[[spell:205021]]
2. **等级 21 起：**[[spell:44614]]
3. **等级 23 起：**[[spell:84714]]
4. **等级 11–12：**[[spell:30455]] when there are at least 4 Freezing stacks on the target
5. **等级 13 起：**[[spell:30455]] when there are at least 4 Freezing stacks on the target or you have [[spell:112965]]
6. **等级 1 起：**[[spell:116]]

3.2.

#### Multi-Target

1. **等级 1–5：**Cry, and try to tab [[spell:116]]s between 
   everything you have pulled so you can try to maintain distance. Generally a 
   bad idea to try and AoE before level 6.
2. **等级 23 起：**[[spell:84714]]
3. **等级 15 起：**[[spell:190356]]
4. **等级 6–14：**[[spell:1449]]

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated with links to our general levelling guide, and heirloom notes.
- **02 Mar. 2026:** Added a level 80 talent import string for returning players.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Updated for Patch 10.1.7
- **18 Jul. 2023:** Made an explicit rotation guide to go alongside the more general theory of why things are played as they are.
- **11 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Frost Mage in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics for Frost Mage

This section is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

This section is going to be an attempt at an easier-to-ingest rehash of the 
rest of the guide, as there is very little that can actually be simplified out 
of it. That said, feel free to talent out of certain active talents if you find 
them hard to use. Playing what you can, well, will almost always beat playing 
the optimal build poorly.

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_freezing.jpg>) **Optimize Freezing Usage**  
  
    The majority of Frost's damage comes from [[spell:1246769]], but it is almost impossible 
    to never waste any. Instead, minimizing what you waste is one of the core tenets. 
    Conversely, [[spell:1247729]] can proc while you are at a low stack count, and it may 
    be worth your time to quickly consider if you can add more to the stack to fill it out 
    before the Thermal Void buff ends. Keep in mind that the duration is longer than 
    [[spell:205021]]'s cast time, and you can absolutely cast [[spell:44614]] prior to 
    Ray, and still benefit from Thermal Void afterwards.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_wintersgrasp.jpg>) **Minimize Proc and Cooldown Waste**  
   
    Using [[spell:112965]] and [[spell:190447]] quickly means that you minimize 
    the odds of over capping them. Likewise, [[spell:84714]] and [[spell:199786]] 
    take a rather high priority when they come up, and reacting to them being available is 
    very important. Make sure you are not sitting on 2 full charges of [[spell:205021]]. 
    While this sounds easy, this spec can easily overflow you with resources leading you to 
    missing something coming up, or being stuck in a situation where your cooldowns are not 
    ticking.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostblast.jpg>) **Always Be Casting**  
  
    Suboptimal plays, such as partial stack [[spell:30455]], are better than 
    doing nothing while moving. Make sure your GCD is rolling at all times. We 
    have a ton of instant cast damage spells, or you could [[spell:11426]] while 
    moving just for something else useful during movement.

2.

### Beginner's Guide to Frost Mage in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire   Single-Target Talents

2.1.

#### Beginner Single-Target Talents for Frost Mage

This build is optimal for pure single-target situations.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmxMjZMziZmZmxMzsMTzMLzCAAAsAAAbAAAgNA22GzMzALzYMjtFAAAwMDmBGwADA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVWWXdFXWYa4EFNltFOiikoABp59BGIUcgL-JgKCHWoqw04c1JMVCY8gBG23ILiccaP-AAAA-CIUkooZw4ABDwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire   AoE Talents

2.2.

#### Beginner Mythic+/Delve Talents for Frost Mage

This is our recommended build for AoE scenarios. This works well for AoE
fights in Raids, as well as most Mythic+ and Delves.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZbWAAAgFAAAAAAYBgttxMzMY2mxMzYbBAAAMzgZgBMDwA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqw4IM5ioB4wYXAHn2TlIJkVMsvRb--UYckgEYIgQRDzC-
```

:::

### Frost Mage   Basic Rotation

2.3.

#### Beginner Frost Mage Rotation

The goal of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire Frost Mage is to generate as many
[[spell:190447]] procs as possible so you can cast more [[spell:44614]].

1. Cast [[spell:44614]] on cooldown.
2. Cast [[spell:199786]] when it lights up and changes your [[spell:431044]] button to it.
3. Cast [[spell:84714]] when available.
4. Cast [[spell:30455]] at 10 or more Freezing stacks, or with [[spell:112965]] whenever it procs.
5. Cast [[spell:205021]] and the subsequent [[spell:1247777]] that comes from it.
6. Cast [[spell:431044]] as a filler.

2.4.

#### AoE Rotation

Functionally the only thing that gets added to our AoE is [[spell:190356]] on 
cooldown. There are some minor tweaks to the priority list when compared to the 
single target, but it is still very simple.

1. Cast [[spell:205021]] and the resultant [[spell:1247777]].
2. Cast [[spell:84714]]
3. Cast [[spell:199786]] when it lights up and changes your [[spell:431044]] button to it.
4. Cast [[spell:44614]] if available.
5. Cast [[spell:190356]].
6. Cast [[spell:30455]] if you have [[spell:112965]] available, or there 
   are more than 10 Freezing stacks on the target.
7. Cast [[spell:431044]].

2.4.1.

##### Apex Talent: ![Hand of Frost Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostbolt.jpg>) Hand of Frost

The Apex talent has no impact on our rotations, other than giving us more
availability on [[spell:205021]] and thus [[spell:1247777]]. Go crazy with
it!

2.4.2.

##### Season 2 Tier Set

There is no impact on the rotation (aside from more [[spell:199786]]
casts in general) from the Season 2 Midnight Tier bonus.
Simply aim to get it, and enjoy the free damage.

### Frost Mage   Defensive Spells

2.5.

#### Defensive Spells for Frost Mage

[[spell:11426]] is your bread and butter. It has a low cooldown, and it 
gives you a 30% health buffer. Never be afraid to hit this button; it will almost 
always be there for you due to its short cooldown. It will save you so much more 
than you think it will.

[[spell:45438]] and its alternative talent option, [[spell:414659]] are both 
our strongest single defensive buttons. Ice Block is a full immunity, which means 
you cannot be damaged inside of it except for very special attacks that pierce 
immunities. This will also clear almost all debuffs from you and is extremely 
powerful for escaping mechanics. Ice Cold on the other hand, frees you up so 
that you can still move and attack, at the cost of being shorter duration and 
not being a full immunity, although still one of the strongest defensives in the 
game.

[[spell:110959]] is a good button to hit if there's a large single 
hit coming for you, by causing a mob to drop target while casting. This can break 
many mechanics; if you are in doubt, try it.

For a beginner, never hit [[spell:342245]], and instead heavily rely 
on [[spell:1244090]].

### Frost Mage   Stat Priority

2.6.

#### Stat Priority for Frost Mage

You should simulate your own character to get stat weights, but a decent
guideline should be as follows.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>).

Intellect

Mastery

Critical Strike

Haste

Versatility

It is important to understand that this is not an indication to stack your
best stat to the exclusion of all else. This is just an approximation for an
average set of gear with a roughly normal distribution of stats on it. In almost
all cases, item level will win out. A simulation is the only way to be sure if
any given piece of gear is an upgrade for sure.

### Blizzard   Combat Assistant

2.7.

#### Combat Assistant for Frost Mage

Combat Assistant, telling you what to press next, is not a terrible option 
when you are just starting out. You are looking at an approximate 10% DPS loss, 
with lesser losses on ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger.

In dungeon content, it starts falling apart, performing another 10% worse 
again on AoE. For an alt, and for learning how this spec plays, this is not a terrible 
penalty.

The one button combat penalty jumps this penalty by another ~10%, totalling 
about 30% loss in AoE combat, and 20% in single target. Learning the spec properly 
will always perform significantly better, regardless of spec, but this could be a very 
usable option for someone new.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated with thoughts on Combat Assistant in 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for 11.0.7.
- **27 Oct. 2024:** Updated with new theory for 11.0.5.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5 with a new talent tree.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Frost Mage in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Frost Mage

Frost Mage in Season 2 of Midnight has extremely strong mobility in most scenarios, as the
majority of your casts are instant. However, it is vulnerable around [[spell:205021]]'s 
cast. This seemingly comes at the cost of having a very mediocre defensive kit, paired with
a somewhat repetitive playstyle.

Given that our Apex Talent provides [[spell:205021]] a second charge, and we 
have no traditional damage boosting cooldowns otherwise, the spec is very 
flexible in when you utilize your burst. This allows for saving a charge for 
damage bonuses, be it from a boss mechanic or a trinket cooldown.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger is the go-to for lower target counts, and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire
pulls slightly ahead in dungeon-style content. There is very little talent
variation, with the primary choice being how much cleave you wish to have.

Frost's AoE is unique in that it does not cast our primary AoE skill
[[spell:190356]] until very high target counts. It instead relies on ambient
cleave while focusing a primary
target. While this is an unfortunate, tuning-based issue, it does leave the spec
the ability to be very easily picked up by new players, and the flexibility of
not needing to memorize what target counts to shift rotations between single-target and AoE.

**Quick Start Import Codes:**

:::talents Frost Single Target
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZMziZmZmZMDAAAMzMzyyMTbAAAAAAwGAbbjZmZwsNPgxMsAAAwMbAzADYGMMA"
}
```
:::

:::talents Frost Light Cleave/Raid
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbbMzMDmthxMsAAAwMbAzADYGMMA"
}
```
:::

:::talents Frost AoE
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZZWAAAgFAAAAAAYBgttxMzMY2mxMzYbBAAAMzgZgBMDwA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Spellslinger

Single-Target

recommended

Light Cleave/Raid

recommended

Mythic+/Delves

Frostfire

Single-Target

Light Cleave/Raid

Mythic+/Delves

recommended

### 天赋方案 0-0

1.1.

#### Single-Target Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger

Standard ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger Frost. This is best utilized in raid encounters
that prioritize single target damage, and have either no adds at all or adds that
are so inconsequential as to be irrelevant.

For a light cleave situation, feel free to
swap [[spell:1247743]] and [[spell:378919]] for [[spell:56377]] and
[[spell:378448]].

### 天赋方案 0-1

1.2.

#### Light Cleave and Raid Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger

This is the recommended build for most raid fights that have adds, and any
other situation where you would really want some level of cleave, rather than
pure single target DPS.

### 天赋方案 0-2

1.3.

#### AoE/Mythic+/Delve Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger

This is our recommended build for heavy AoE raid encounters, dungeons
(Mythic+ or not), or [Delves](<https://www.icy-veins.com/wow/delves-guide>) if you prefer to
play ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger.

Swapping [[spell:418733]] for
[[spell:1247055]] can be beneficial if you are prioritizing a main target,
such as the final boss of a Delve, or a raid boss that needs just a bit more
focus.

### 天赋方案 1-0

1.4.

#### Single-Target Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

Standard ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire Frost. This is best utilized in raid encounters
that prioritize single target damage.

For a light cleave situation, move [[spell:455122]] to
[[spell:56377]].

### 天赋方案 1-1

1.5.

#### Light Cleave and Raid Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

This is the recommended build for most raid fights that have adds, and any
other situation where you would really want some level of cleave, rather than
pure single target DPS.

### 天赋方案 1-2

1.6.

#### AoE/Mythic+/Delve Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

This is our recommended build for heavy AoE raid encounters, dungeons
(Mythic+ or not), or [Delves](<https://www.icy-veins.com/wow/delves-guide>).

Swapping [[spell:418733]] for
[[spell:1247055]] can be beneficial if you are prioritizing a main target,
such as the final boss of a Delve, or a raid boss that needs just a bit more
focus.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZMziZmZmZMDAAAMzMzyyMTbAAAAAAwGAbbjZmZwsNPgxMsAAAwMbAzADYGMMA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIZAcYUYa3lDTDHn2TFkIpVM-AAAA-RKQkIMAcYIoJzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbbMzMDmthxMsAAAwMbAzADYGMMA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIZAcYUYa3FTDHn2TFkIp1AC-AAAA-RKQkIMAcYIoJzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAAWAYbbMzMDmthxMsAAAwMbAzADYGMMA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIZAcYUYS3FTDHn2TFkIp1AC-AAAA-RKQkIMAcYIoJzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZMziZmZmxMzsMTzMLzCAAAsAAAAAAAbAstNmZmB2mxYGbLAAAgZGMDMgBGGA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIZIM9yhpBY8QnoVMsIOOtnv-AAAA-UYckgAYIgQRDzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZmxiZmZmxMzsMTzMLzCAAAsAAAAAAAbAstNmZmB2mxMzwCAAAYmBzADYghB"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIBcYUYqzFTDRnoVMstIOOtH-AAAA-UYckgAYIgQRDzC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZbWAAAgFAAAAAAYBgttxMzMY2mxMzYbBAAAMzgZgBMDwA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqw4IM5ioB4wYXAHn2TlIJkVMsvRb--UYckgEYIgQRDzC-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new mini-talent system introduced in Midnight's
[Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers some minor DPS and healing options
over the course of a multi-part quest series.

Below are the recommended choices for most situations. However, the
actual DPS difference between each is fairly low, so feel free to change
things up and see how you like each. Of note, [[spell:1279596]]
is a better burst option if you primarily do outdoor content, rather than
instanced content.

- Node 1:[[spell:1279599]]
- Node 2:[[spell:1279603]]
- Node 3:[[spell:1287555]]
- Node 4:[[spell:1279609]]
- Node 5:[[spell:1279614]]

3.

### Apex Talent: ![Hand of Frost Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostbolt.jpg>) Hand of Frost

[[spell:1262935]] causes any Shatter event to have a 10% chance to fire
an extra spell that hits fairly hard, and adds 1 stack of Freezing to the target.

[[spell:1262981]] takes that, and increases the proc chance based on how
many stacks were consumed. Each time the damage spell procs, gain a 1% damage
buff for a few seconds. This can stack, and each stack is timed individually, so
they will rise and fall gradually as you play.

[[spell:1263249]] procs 4 of the damage spells over the duration of
[[spell:205021]], buffs Ray's damage, and adds a second charge to the spell.

For the most part this is an entirely passive talent, but it is fairly strong.
The flexibility of having a second charge on [[spell:205021]] allows us to
pool a charge for important things, such as trinket procs or vulnerability phases.

4.

### Hero Talents

Available at level 71 Hero talents are mutually exclusive trees you can
choose to slightly alter gameplay and visuals. Frost Mage has 
access to the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger Hero Talent trees.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire is slightly burstier, and all of its damage is fairly
front loaded. Generally speaking it is better suited to outdoor content, or
content that dies quickly.

On the AoE side, having access to [[spell:153561]], with an increased damage
to both it and [[spell:1247777]], and the exploding [[spell:199786]], it
excels at burst AoE.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger in comparison is more about more rapid, smaller hits
from Splinters.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger remains the only way to reduce the cooldown of
[[spell:84714]] through [[spell:444986]], giving it a nice niche
of more frequent Orb casts. It trades this for not really being able to spec for
[[spell:1247777]], and losing the burst possible from that talent.

5.

### PvP Talents (War Mode)

Since Battle for Azeroth, there is the option to enable "War Mode."
Enabling War Mode grants the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at max level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended enabling the feature to maximize your leveling and rewards at max
level. However, doing so will enable PvP combat and the possibility of being
attacked by members of the opposite faction while leveling or doing World
Quests exists.

- [[spell:198148]] is pretty great with no downsides.
- [[spell:390612]] is a great choice. A nice delayed burst AoE hit.
- [[spell:389794]] works as a decent short-term stun, but the damage is
  underwhelming and requires targets to be extremely close to you. There are
  better options.

[[spell:352278]] is going to get a special mention. Having the ability to
force line of sight or wall an enemy player, either in with you or away from
you, is a pretty powerful utility. This feels like one of those things you
should have with you just in case you are in War Mode. It is deceptively strong for
the area denial utility.

There are some interesting Honour Talents, but since they are restricted to
the open-world and unusable in instances, they generally are not simulated.
Thus, the above are simply the thoughts and feelings of the author.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for 12.0.7, added Omnium Folio recommendations, added a light cleave/raid talent set by request.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **28 Feb. 2026:** Minor intro tweak.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated with Boltslinger and Standard talent option recommendations.
- **27 Oct. 2024:** Updated with new theory for 11.0.5.
- **21 Oct. 2024:** Updated for 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5's significant overhauls.
- **01 May 2023:** Updated Honour Talents and removed a handful of bugged interaction notes.
- **20 Mar. 2023:** Updated default talent trees.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Frost Mage in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Frost Mage Gameplay and Rotation Guide

Welcome to our Rotation page for Frost Mages. On this page,
you will find everything you need to know about actually playing the spec in
Raiding and Mythic+ scenarios.

Each of the sections below explain the Rotation for Frost Mage in different
content types and describe the theory behind these rotations. Click the
boxes to switch to the desired damage type.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

Single Target

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

Active Talents

Passive Talents

[[spell:1247777]]

[[spell:157997]]

[[spell:1247729]]

[[spell:270233]]

[[spell:1216953]]

[[spell:1247090]]

[[spell:1247544]]

### Basics of Frost Mage

At its most basic, the premise of Frost Mage is to spam
    [[spell:116]] to stack Freezing or until you gain a proc.
    [[spell:112965]] allows you to cast [[spell:30455]] and gain the
    benefits of a full stack of Freezing. [[spell:190447]] resets the cooldown of
    [[spell:44614]].

Adding talents to the mix, [[spell:1247777]] adds a second use after
    each [[spell:205021]] that consumes Freezing stacks on any targets hit in
    addition to hitting hard itself. [[spell:1247090]] changes your
    [[spell:120]] (or [[spell:157997]] if talented for it instead) to add
    multiple stacks of Freezing in an AoE. [[spell:1247729]] changes how you
    play around with [[spell:30455]] slightly.

1.1.

#### Proc Management

Use [[spell:112965]] and [[spell:190447]] as they come.

[[spell:112965]] makes your [[spell:30455]] deal damage as if it
    consumed the maximum amount of Freezing off any given target, including a
    target with none on it at all.

[[spell:190447]] can, if talented into [[spell:1247729]], double
    the amount of your next [[spell:30455]]'s (within 8 seconds) Freezing
    stack consumption. This does work with [[spell:112965]] as well,
    allowing you to [[spell:1246769]] up to 12 stacks worth of damage without
    consuming any Freezing.

1.2.

#### Maximizing Cleave

Ultimately, Frost Mage is primarily about abusing your casts in a way that
    is suitable to the situation. There are an enormous amount of possibilities,
    synergies, and overlaps that will provide an advantageous result. It is
    important, therefore, that you, as a player, think carefully about how you can
    use your spells in a way that makes sense. Try to avoid using your major
    abilities haphazardly or without thinking, as this will invariably result in
    you losing a lot of damage. When your [[spell:84714]] is about to come
    off cooldown, for example, start thinking about the ways you are going to
    cleave with it or if the boss is going to be moved. Check your boss's timers to
    see how you can line it up for a phase with increased damage dealt or AoE. A
    lot of this might seem like common sense, but you would be surprised how
    uncommon that is!

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire Single Target Rotation

[[spell:431044]]

[[spell:205021]]

[[spell:44614]]

[[spell:84714]]

1.3.

#### Single-Target Opener

1. Pre-cast [[spell:431044]] at 2 seconds on the countdown.
2. Cast [[spell:205021]].
3. Cast [[spell:44614]].
4. Cast [[spell:84714]].
5. Follow your normal priority, as indicated below.

1.4.

#### Single-Target Priority

- Cast [[spell:199786]].
- **适用条件：Comet Storm（启用）。** Cast [[spell:1247777]].
- **适用条件：Thermal Void（未启用）。** Cast [[spell:44614]] if you have [[spell:190447]].
- **适用条件：Thermal Void（启用）。** Cast [[spell:44614]] if [[spell:1247729]] is not already active and you have [[spell:190447]].
- Cast [[spell:30455]] if you have 2 stacks of [[spell:112965]].
- **适用条件：Crystalline Refraction（启用）。** Cast [[spell:205021]] and interrupt it as soon as you have 2 stacks of [[spell:112965]].
- **适用条件：Crystalline Refraction（未启用）。** Cast [[spell:205021]] and interrupt it as soon as possible with another cast.
- Cast [[spell:84714]].
- **适用条件：Thermal Void（启用）。** Cast [[spell:30455]] when you have [[spell:112965]] and [[spell:1247729]] is up.
- Cast [[spell:30455]] at 12 or more stacks of Freezing.
- Cast [[spell:44614]] if you have a charge available but no [[spell:190447]].
- Cast [[spell:431044]].

This works out to functionally "get everything on cooldown" and try to incidentally optimize around [[spell:1247729]] in an entirely passive way. The gameplay loop is very simple once you get a feel for it.

Frost likes to continue to single target even on 2 target cleave, the AoE rotation does not take over until 3 or more.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire AoE Rotation

[[spell:190356]]

[[spell:205021]]

[[spell:44614]]

[[spell:84714]]

1.5.

#### AoE Opener

1. Pre-cast [[spell:190356]] at 2 seconds on the countdown.
2. Cast [[spell:205021]].
3. Cast [[spell:44614]].
4. Cast [[spell:84714]].
5. Follow your normal priority, as indicated below.

1.6.

#### AoE Priority

- Cast [[spell:199786]].
- **适用条件：Comet Storm（启用）。** Cast [[spell:1247777]].
- **适用条件：Thermal Void（未启用）。** Cast [[spell:44614]] with [[spell:190447]].
- **适用条件：Thermal Void（启用）。** Cast [[spell:44614]] with [[spell:190447]] if [[spell:1247729]] is not already active.
- **适用条件：Thermal Void（启用）。** Cast [[spell:30455]] if you are at 2 [[spell:112965]] or [[spell:1247729]] is active.
- **适用条件：Thermal Void（未启用）。** Cast [[spell:30455]] if you are at 2 [[spell:112965]].
- Cast [[spell:205021]].
- Cast [[spell:84714]].
- **适用条件：Freezing Rain（启用）。** Cast [[spell:190356]].
- Cast [[spell:30455]] if [[spell:112965]] is active or you have 10 or more Freezing on the target.
- Cast [[spell:44614]] if you have a charge available but no [[spell:190447]].
- Cast [[spell:431044]].

**适用条件：Cone of Frost（启用）。** [[spell:1247090]] is currently undertuned, and not worth casting for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire. You should instead try to proc [[spell:431176]] using the rest of the kit.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger   Single Target Rotation

[[spell:116]]

[[spell:44614]]

[[spell:84714]]

[[spell:205021]]

**适用条件：Crystalline Refraction（启用）。**

[[spell:30455]]

1.7.

#### Single-Target Opener

1. Pre-cast [[spell:116]].
2. Cast [[spell:44614]].
3. Cast [[spell:84714]].
4. Cast [[spell:205021]].
5. **适用条件：Crystalline Refraction（启用）。** Cast [[spell:30455]].
6. Follow your normal priority, as indicated below.

### Single-Target Priority

- **适用条件：Comet Storm（启用）。** Cast [[spell:1247777]].
- **适用条件：Thermal Void（未启用）。** Cast [[spell:44614]] with [[spell:190447]].
- **适用条件：Thermal Void（启用）。** Cast [[spell:44614]] with [[spell:190447]] if [[spell:1247729]] is not already active.
- Cast [[spell:84714]].
- Cast [[spell:30455]] if you have [[spell:112965]].
- Cast [[spell:199786]] when available.
- Cast [[spell:30455]] whenever you are at or above 6 Freezing on target.
- Cast [[spell:205021]].
- Cast [[spell:44614]].
- Cast [[spell:116]].

This works out to functionally "get everything on cooldown". [[spell:1247729]] is something you ignore when deciding to [[spell:30455]], and simply hope that it consumes more than 6 stacks. The gameplay loop is very simple once you get a feel for it.

Frost likes to continue to single target even on 2 target cleave, the AoE rotation does not take over until 3 or more.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger AoE Rotation

[[spell:190356]]

[[spell:44614]]

[[spell:84714]]

[[spell:205021]]

1.8.

#### AoE Opener

1. Cast [[spell:190356]].
2. Cast [[spell:44614]].
3. Cast [[spell:84714]].
4. Cast [[spell:205021]].
5. Follow your normal priority, as indicated below.

1.9.

#### AoE Priority

- **适用条件：Comet Storm（启用）。** Cast [[spell:1247777]].
- **适用条件：Freezing Rain（启用）。** Cast [[spell:190356]] if [[spell:270233]] is active.
- **适用条件：Thermal Void（未启用）。** Cast [[spell:44614]] with [[spell:190447]].
- **适用条件：Thermal Void（启用）。** Cast [[spell:44614]] with [[spell:190447]] if [[spell:1247729]] is not already active.
- Cast [[spell:84714]].
- Cast [[spell:30455]] if you have [[spell:112965]].
- Cast [[spell:199786]] when available.
- Cast [[spell:30455]] whenever you are above 6 Freezing on target.
- **适用条件：Ice Nova（启用）；Cone of Frost（启用）。** Cast [[spell:157997]].
- **适用条件：Cone of Frost（启用）；Ice Nova（未启用）。** Cast [[spell:120]].
- **适用条件：Freezing Winds（启用）。** Cast [[spell:190356]] if you are fighting 5 or more enemies.
- Cast [[spell:44614]].
- Cast [[spell:205021]].
- Cast [[spell:116]].

Non-instant [[spell:190356]] is fairly weak when compared to continuing to generate Splinters, which will reduce the cooldown of [[spell:84714]], which is both a massive AoE increase and the proc for instant cast Blizzard. Hence, it is not cast when it is not instant, outside of [[spell:1216953]] being talented.

2.

### Midnight Season 2 Tier Set

These are fully passive bonuses, and do not impact your gameplay in any way,
other than the frequency in which [[spell:199786]] is available.

- [[spell:1296585]] — Each stack of Freezing [[spell:1246769]]ed has a 4% chance to generate an Icicle. [[spell:199786]] damage increased by 20%.
- [[spell:1296586]] — Casting [[spell:199786]] has a chance to rapidly generate 5 Icicles over 1 sec. [[spell:1246769]] damage increased by 5%.

3.

### Class and Spec Mechanics Explained

### Freezing and Shattering

3.1.

#### Freezing

Freezing is a debuff stacked on the target by most of your spells. This can
be triggered by [[spell:30455]], [[spell:1247777]], and [[spell:199786]]
when talented into [[spell:1280780]]. This will trigger [[spell:1246769]],
dealing damage to the target and a lesser amount to targets nearby based on how
many stacks were consumed by the spell. Additionally, this AoE component will
fire if the target dies, via [[spell:1247775]], dealing reduced damage in
AoE that it would have normally triggered for that many stacks.

You will
routinely over-cap the stack cap of 20. This is, sadly, unavoidable.

:::details FAQHow Many Stacks of Freezing do I Lance at?
6+ on

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger

, 10+ on

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

.

:::

### Apex Talent

3.2.

#### Apex Talent

[[spell:1262935]] causes any Shatter event to have a 10% chance to fire
an extra spell that hits fairly hard, and adds 1 stack of Freezing to the target.

[[spell:1262981]] takes that, and increases the proc chance based on how
many stacks were consumed. Each time the damage spell procs, gain a 1% damage
buff for a few seconds. This can stack, and each stack is timed individually, so
they will rise and fall gradually as you play.

[[spell:1263249]] procs 4 of the damage spells over the duration of
[[spell:205021]], buffs Ray's damage, and adds a second charge to the spell.

For the most part this is an entirely passive talent, but it is fairly strong.
The flexibility of having a second charge on [[spell:205021]] allows us to
pool a charge for important things, such as trinket procs or vulnerability phases.

4.

### Important Cooldowns for Frost Mage

### [[spell:205021]]

4.1.

#### Ray of Frost

[[spell:205021]] is our "main" cooldown, available every minute. It causes
you to channel for 4 seconds, dealing significant damage to the target, and stacking
Freezing every tick.

It has two improvement talents directly under it in the talent tree,
[[spell:1247055]] and [[spell:418733]]. Frigid Focus is self
explanatory, but Splintering Ray will pick the nearest 5 targets to your Ray
target, and deal a portion of the damage each tick to those.

While talented into [[spell:1247777]], the button transforms into Comet
Storm after a cast.

:::details FAQWhy is Ray of Frost Such a Low Priority?
Since

[[spell:205021]]

generates so many Freezing stacks, it is better to
consume as many as required for your Hero Talent before casting it, to maximize value.

:::

### [[spell:84714]]

4.2.

#### Frozen Orb

[[spell:84714]] is our secondary cooldown. This deals AoE damage every
half second for 15 seconds.

On cast, it will fly outwards rapidly until it hits a target, at which point
it will slow drastically. After 3 seconds, it will start to slowly track the mob
you originally had targeted when you cast it.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Opener tweaks.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for 12.0.7 with minor Frostfire tweaks.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **22 Mar. 2026:** New opener for Slinger single target.
- **16 Mar. 2026:** Added a note about the tier set for Midnight Season 1.
- **28 Feb. 2026:** Wording tweaks and added a note that single target is still used on 2t.
- **26 Feb. 2026:** More priority changes.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **11 Feb. 2026:** Updated priorities AGAIN, theorycraft moves fast during patches.
- **10 Feb. 2026:** Updated priorities, added FAQ about Slinger's Freezing usage on single target.
- **20 Jan. 2026:** Fixed a typo and One Button does use Frost's cooldowns now.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **23 Aug. 2025:** Slinger casts Comet Storm in single target again, Shifting Power constrained.
- **04 Aug. 2025:** Last minute APL changes to simplify rotation slightly.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added section on Combat Assistant for 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **02 Mar. 2025:** Logic fix on Frostfire AoE vs Excess Fire.
- **28 Feb. 2025:** Minor tweak to Frostfire's Flurry logic, and updates to Slinger's DC AoE constraints.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated to contain both standard Frost and Boltslinger variant rotations for both Hero Talent options.
- **27 Oct. 2024:** Updated with new theory for 11.0.5.
- **21 Oct. 2024:** Updated for 11.0.5.
- **07 Oct. 2024:** Minor wording changes.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **27 Aug. 2024:** Removed GS from AoE rotation for a minor gain.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **14 Jan. 2024:** Glacial Spike is cast without Flurry regardless of Icy Veins status now.
- **12 Dec. 2023:** Minor clarification on Ray of Frost/Frozen Orb.
- **12 Nov. 2023:** Removed an outdated paragraph in section 3.2 and replaced it with a more in-depth dive on proc usage since the 10.1.5 changes.
- **06 Nov. 2023:** Added information about T31's impact on our 2 target DPS.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **11 Aug. 2023:** Shifting Power should be used in Icy Veins, once RoF/CmS/FO are on cooldown.
- **01 Aug. 2023:** Added missing rotational piece for casting Glacial Spike during Icy Veins without Flurry proc.
- **10 Jul. 2023:** Updated for Patch 10.1.5's rotational changes. Potentially further changes as theorycraft evolves over the next couple of months.
- **01 May 2023:** Added toggles for the AoE rotation set. Less Lance is down to 1.7% lead.
- **20 Mar. 2023:** Added notes about the Less Ice Lance rotation set.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated Blizzard target values with/without Ice Caller.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Frost Mage in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Frost Mage

Welcome to our Frost Mage Gear for
Midnight Season 2. Check this page to learn everything
you need to know about gearing a Frost Mage, including the
BiS Gear from all
sources, Raiding, and Mythic+, information on the best Trinkets, Tier Sets, and
much more.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the Best in Slot Gear for Frost Mage in Midnight Season 2.

Note that there is no such thing as a singular, all-encompassing "BiS". The best items vary per character and situation, and there are many items that are essentially equivalent in terms of DPS, namely when we are just shuffling secondary stats around. I will list one "BiS" item per slot, but ultimately, BiS lists should be taken as guidance, and you should be [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) to find out what gear to equip next.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 as a Frost Mage, the pieces you convert keep their stats and any cantrip effects. This functionally means that you should convert whatever slots you get at a high item level first. There is no benefit to one slot over another otherwise. You should aim to convert any 4 of these 5 items:

- Head: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:239031@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:273785@JAACAAgNyA]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Hands: [[item:268243@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: [[item:159234@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)

:::

:::details FAQWhat Items From the Great Vault Should I Pick?
What you want to take is going to be personal, heavily dependent on your level of progression, and current gear. The simulation result should always inform your decisions. However, there are a handful of items that you should likely take regardless:

- [[item:271092@JAACAAAG2A]]: Best-in-slot, and by a wide margin.
- All of the Venomcursed items are extremely over-budget and worth taking, possibly even replacing a higher track item.
- [[item:250215@JAACAAgNyA]] is an extremely good trinket, and very close in value to [[item:270167@JAACAAgNyA]]. It is a good pick if you prefer an on-use trinket.

:::

:::details FAQWhat about Kith'ix's Gear?
The new gear and their cantrips simply do not provide enough damage to change the BiS list to accommodate the worse stats. For people who are not fully best in slot, or are not expected to clear Mythic Coiled Altar or Ula'tek, it is possible they can be workable, as you free up a large amount of item slots from being item level 344, making them outright better than their alternatives. However, that is outside the scope of a BiS list, and best simmed on a personal level.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271564@JAAGAAgF2ghNTpC]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271565@JAAEAAwF0ghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAj1ghNTpC]]&#10;&#10;<div>[[item:240983]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:239649@JAAMAAwViAGM3WT0wwgNTpC]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271562@JAAIAAgNycBN-VTg1A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:159234@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAAEAAwF0ghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAAEAAwF0ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268249@JAAGAAgNycBNkVD]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270164@JAAEAAAOycBN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></div></td></tr><tr><th>Bracers</th><td>[[item:251154@JAAEAAgNyMlK]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAAEAAwF0ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243971]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAOAAwViscN3WT0wwgNTpCH2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup with farmable gear from Season 2 Mythic+ Dungeons.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, the pieces you convert keep their stats and any cantrip effects. This functionally means that you should convert whatever slots you get at a high item level first. There is no benefit to one slot over another. You should aim to convert any 4 of these 5 items:

- Head: [[item:251199@JAACAAgMyA]] from [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- Shoulders: [[item:239031@JAACAAgMyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:239032@JAACAAgMyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Hands: [[item:159247@JAACAAgMyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Legs: [[item:193750@JAAKAAQkCYHKvbRLfIjM]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): Your main hand weapon, a trinket, and a handful of decent options to other pieces presented.
- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): High budget pieces and a well statted staff to use while you try and get your MH/OH combo.
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): BiS trinket.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271564@JAACAAAMyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271565@JAACAAgMyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAAMyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:239649@JAAMAAwViAGM3WT0wwgNTpC]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271562@JAACAAgMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:193750@JAAKAAQkCYHKvbRLfIjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgMyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:251137@JAACAAgMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271567@JAACAAgMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgMyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgMyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273794@JAACAAAMyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:251154@JAAEAAgMyMlK]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAAMyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAACAAAMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243971]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAOAAwViscN3WT0wwgNTpCH2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup, only using gear from the Venomous Abyss Raid.

This list is by no means a replacement for **simming yourself**. Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 as a Frost Mage, the pieces you convert keep their stats and any cantrip effects. This functionally means that you should convert whatever slots you get at a high item level first. There is no benefit to one slot over another otherwise. However, the best in slot shoulder piece, is the actual tier token from the raid, as no other shoulder pieces have optimal stats. Additionally, there are no other cloth Chest pieces other than the tier token. You should convert these items:

- Head: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Hands: [[item:268243@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: [[item:268236@JAACAAgNyA]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)

:::

:::details TipsWhat Raid Items Are Most Important?
If you need a suggestion for coins or if your guild requires a BiS priority:

- [[item:271092@JAACAAAG2A]]: Highest item level weapon, with a bonus cantrip.
- [[item:271874@JAACAAAG2A]]: Highest item level hat, and the Venomcursed effect makes this an extremely high value item.
- [[item:268265@JAACAAAG2A]]: Highest item level neck, and the second socket combined with the Venomcursed effect makes this an extremely high value item.
- [[item:270164@JAACAAgNyA]]: The best trinket.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271564@JAAIAAwF0QWNWYDG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271565@JAAEAAwF0ghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAIAAwF0QWNMWDG2A]]&#10;&#10;<div>[[item:240983]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:239649@JAAMAAwViAGM3WT0wwgNTpC]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271562@JAAIAAgNycBN-VTg1A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:268236@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAAEAAwF0ghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAAEAAwF0ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268249@JAAGAAgNycBNkVD]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270164@JAAEAAAOycBN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></div></td></tr><tr><th>Bracers</th><td>[[item:268228@JAAEAAgNyMlK]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAAEAAwF0ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243971]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAOAAwViscN3WT0wwgNTpCH2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Frost Mage in Season 2

There are a decent number of usable trinkets this season, contrary to last.
[[item:270167@JAACAAgNyA]] and [[item:270164@JAACAAgNyA]] are the solid
winners in every target count and talent set, but there are significantly more
trinkets than just those that are within a fairly close margin to use.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Frost Mage Trinkets**
[[item:270167@JAACAAgNyA]]

[[item:270164@JAACAAgNyA]]

:::

A "Tier" as defined by this list is around 0.5% DPS, meaning that S-Tier
Trinkets are around 0.5% better than A-Tier Trinkets, and so on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Frost Mage Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]] with 50% uptime on being in the light beam</li>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274493@JAACAAgMyA]]</li>&#10;<li>[[item:251792@JAACAAgMyA]]</li>&#10;<li>[[item:270169@JAACAAAG2A]] used on cooldown</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:251785@JAACAAgMyA]]</li>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;<li>[[item:251786@JAACAAgMyA]]</li>&#10;<li>[[item:251784@JAACAAgMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) ans Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s can be spent to roll for an extra item off the
  boss, dungeon, or delve you have completed. Which piece you are given is
  random, but it will remove it from the potential loot pool until you have
  seen every item once. This allows you to target specific pieces of gear from
  specific locations.

3.1.

#### Recommended Nebulous Voidcore Usage for Frost Mage

What item you are looking for is going to depend heavily on what you have,
what you need, and what content you can feasibly finish yourself.  The priority
is as follows:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) on Heroic (or Mythic) provides the single best DPS benefit due to the high concentration of extremely powerful cantrip items.
2. Remaining BiS List items

:::

3.2.

#### Ascendant Venomstones

[[item:280562]]s allow for certain slots to be upgraded beyond
their track ranks. That is to say, functionally taking something to 8/6 Hero or
Myth.

Upgrade priorities should roughly follow that of Crest upgrades:

- Main or two-handed weapon
- Trinkets
- Offhand
- Necklace

Prioritize Myth or crafted pieces, as they will not be replaced this season,
unless your
personal progression does not see you killing that boss on Mythic or spending
Voidcores on Heroic. It should also be noted that Mythic raiders are somewhat
excluded, as any of the loot that drops at 344 is unable to be upgraded.

4.

### Best Crafted Items for Frost Mage

Professions are a wonderful way to fill out slots you have had no luck in
filling out, and additionally provide a small power boost through
Embellishments.

Since crafted gear is time gated, and gearing is not instant, 
the wisest decision early season is to craft a staff. While this 
does mean that you end up crafting an offhand later, wasting more 
Sparks and Crests, it provides the single largest power boost in 
the early parts of a season. Work on your other Embellished item 
afterwards.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Frost Crafted Gear Priority**
- [[item:245770]] with [[item:273060]]
- [[item:239649]] with [[item:240167]]
- [[item:245769]] after you have obtained your Main Hand off of [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Any item you do not have on Myth track yet.

:::

A staff, while not best in slot, is still the single largest DPS gain you can
obtain early season. Consider holding off if you feel you are likely to kill
[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) on Heroic early season and instead go directly for the Off-hand
and Belt.

For more information on how you can craft your own gear, you
can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Frost Mage

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

You may also remove an Embellishment that you have added to a piece of gear,
if you end up in a situation where you would need to change what item has the
bonus, or something gets tuned. This can be achieved by recrafting the first
with [[item:248130]], which will remove the bonus and allow you to craft
something else with a new Embellishment.

Currently, the best options are [[item:273060]],
and [[item:240167]] on a low-importance slot, such as Bracers or
Cloak.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the Miasmic Jewelbinder item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

You will be able to upgrade your items via Crests such as
[Myth Mistcrest](<https://www.wowhead.com/currency=3446>). Once you have upgraded a slot to a certain item
level, **upgrading other items of that slot to that item level costs no crests**.

When you upgrade with Crests, you should think of it as upgrading **slots**
and not items.

Additionally, since Crests are a limited resource, you will want to obtain
the highest item-level possible **before** upgrading a given slot,
as this means you will spend fewer Crests on that slot in total. If you are at
all capable of doing a +10 Dungeon (3/6 Hero), for example, it would be a VERY
bad idea to upgrade an item from a +9 Dungeon (2/6 Hero), because you just
wasted 20 Crests that could have been saved by just farming the slot on a +10.

Crests in Midnight are track-specific, so there is no real penalty in
upgrading Hero track pieces fully, and in fact can be beneficial as it will skip
20 Myth crests on the Myth 2 upgrade. This amounts to a full extra piece of
gear, or a Myth crafted item, every month. For the average player who can only
obtain Myth track from their weekly vault, this is a fairly important bonus.

We see a ton of players, even at a high level, mess up their upgrade
priorities, and upgrading prematurely. Getting this right will put you far
ahead of most players.

Below is the slot priority you should [ upgrade your items](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) in. If you ever 
want to deviate from this, you should have a very good reason.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Frost Mage Crest Upgrade Priority**
**Weapon**

➜

**Trinket**

➜

**Helm/Chest/Legs**

➜

**Shoulder/Gloves/Belt/Boots**

➜

**Cloak/Bracer**

➜

**Neck/Ring**

:::

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5 with new trinket and Venomstone priority.
- **14 Aug. 2026:** Updated with trinket tier list for Season 2, BiS lists.
- **10 Aug. 2026:** Updated for Patch 12.1 with preliminary BiS lists.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Rotmire drops.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated with a section noting Cartel Chips, item levels raised in BiS lists.
- **23 Aug. 2025:** Added trinket tier list and marginal changes to BiS list.
- **06 Aug. 2025:** Fixed crafted section recommending cloak instead of bracer.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **24 Jun. 2025:** Charged Bolts nerfed.
- **15 Jun. 2025:** Updated with the new Delve belt.
- **21 Apr. 2025:** Updated the BiS list's trinkets, added Puzzling Cartel Chip section.
- **21 Mar. 2025:** Cyrce's replacement note added, tier set fixes.
- **28 Feb. 2025:** Updated overall BiS list.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Dec. 2024:** Cyrce's Circlet massively buffed at launch.
- **15 Dec. 2024:** Updated for 11.0.7 and Cyrce's Circlet.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **12 Nov. 2023:** BiS list and farm lists added for Season 3.
- **07 Nov. 2023:** Sporecloak nerfed.
- **06 Nov. 2023:** Partial update for 10.2.
- **08 Sep. 2023:** Changed wording in the Trinkets section
- **04 Sep. 2023:** Updated for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5 with tier/profession slot suggestions, and a note about Dawn of the Infinite's gear being untested.
- **11 May 2023:** Re-added Bloodmallet charts.
- **07 May 2023:** Updated for Season 2 start with trinket suggestions in the wake of the Flowstone nerf.
- **01 May 2023:** Added the Season 2 upgrade system, Season 2 interesting items, and suggested embellishments.
- **23 Mar. 2023:** Onyx Annulet is no longer a DPS loss.
- **20 Mar. 2023:** Added a note about Onyx Annulet.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for beginning of Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Frost Mage. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Frost Mage Stat Priority

The following is a good guideline for stats for Frost Mages:

Intellect

Mastery

Critical Strike

Haste

Versatility

As gear gets higher and higher, Haste will start to even out with Critical
Strike and Mastery, ending with all three being approximately equal weight, at
least in Season 2.

:::details TCHow do Stat Weights Work?
As a primary example, here is are the stat weights of a given character
for whatever talent set they logged out in:

![Normal weights: Int-2.09, crit-1.59, mastery-1.52, vers-1.48, haste-1.46](<https://static.icy-veins.com/images/wow/classes/mage/frost-normal-weights.jpg>)

And here is what happens if all Haste is removed and turned into
Mastery:

![Altered weights: Int-2.05, crit-1.56, mastery-1.24 vers-1.42, haste-2.00](<https://static.icy-veins.com/images/wow/classes/mage/frost-altered-weights.jpg>)

Stacking even a small portion of stats has skewed the weights so hard
that Haste is now valued above Critical Strike, and very nearly above
Intellect.

:::

No stat should really ever be hard stacked. Everything works off each 
other. **As an example:** Haste may be great, but there comes a point where
slower yet effectively
higher damage per cast time spells would be better, through stacking Mastery 
to improve [[spell:116]]'s damage. Yet if you were to do the 
opposite, stacking Mastery to the exclusion of Haste, you would see the 
opposite show up. Faster, slightly weaker, casts would be better than heavily 
stacked Mastery casting very slowly. This is the primary reason stat weights 
are not static, and in fact, change with every piece of gear.

2.

### In-Depth Stat Breakdown

**Intellect** is your "primary" stat, meaning that you use it rather 
than Agility or Strength, not that it is the best in all situations. It 
provides you with Spell Power, which increases the damage of your spells.

**Versatility** is a flat-out damage done increase and damage taken 
reduction.

**Critical Strike** increases your chance to Critically Strike.

:::details TCIs There a Critical Strike Cap for Frost Mage? How much do I need?
Not anymore. Shatter cap is a relic of a bygone era, and Crit is now just a normal stat.

:::

**[[spell:1246752]]** is a flat increase to spells that
Freeze, or Shatter respectively. A notable exception as of writing is
[[spell:190356]] and [[spell:84714]] are included in the Freezing side of
the Mastery.

**Haste** decreases the cast time of your spells. In particular, 
decreasing the cast time of [[spell:116]] is very beneficial because 
it means that you can cast Frostbolt more often, increasing your chances to 
get procs, and the rate at which you generate [[spell:1246832]].
Haste also lowers your base Global Cooldown. Haste also increases the cast speed of your Water
Elemental and [[spell:55342]]s.

:::details TCIs There a Haste Cap for Frost Mage?
Technically, there are a few soft caps, yes. They are not obtainable caps and
should not be worried about.

The GCD cap, in which the GCD for all spells cannot be lowered any further, is
at +100% Haste. This is what people are usually referring to in regards to any
form of Haste cap. In Legion, the
GCD cap was moved from +50% to +100%, negating almost all normal scenarios in
which it is a consideration and thus is not a thing to worry about as of now.

:::

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7 and added FAQ widgets.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for 11.0.7.
- **27 Oct. 2024:** Updated with new theory for 11.0.5.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Frost Mage, based on your [stat priority](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

Make sure you have one [[item:240983]] somewhere in
your gear. This is the most valued gem out of all of them. Beyond that, fill
any other sockets with [[item:240908]].

2.

### Best Enchants and Weapon Augments

Make sure to apply [[item:243733]] to your weapon for all content.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>[[item:243957]] or whatever your sim tells you to run.&#10;The practical difference is tiny.</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>[[item:243971]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Head</td>&#10;<td>[[item:244007]] as a default, but tertiary stat&#10;enchants tend to be personal choice. Use whichever calls to you.</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:243991]] as a default, but tertiary stat&#10;enchants tend to be personal choice. Use whichever calls to you.</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>[[item:243953]] as a default, but tertiary stat&#10;enchants tend to be personal choice. Use whichever calls to you.</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;</table>

The deciding factor between Avoidance and Speed is simply if you
feel like taking a minor amount less damage compared to moving faster
at all times. You can make the argument for each in every scenario, even in
extremely high-end content. Avoidance lets you survive larger hits; Speed gives
you more leeway to run out of an AoE effect. You can pick whichever effect you prefer
here.

For comparisons, full Avoidance enchants grant 4.54% of the stat, full Leech provides
3.52% of your damage as healing, and full Speed is 11.4% more movement speed.

:::details TCWhy Do We Use Crit Enhancements Instead of Mastery?
While Mastery is our best stat in a vacuum, [[item:241288]]
really wants us to lean just marginally towards Crit when it is used. The
reason for this is that [[spell:1247025]] and [[spell:1246811]] really
enjoy the massive Crit boost from the potion during our opener.

:::

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

You should be drinking the [[item:241326]] at all times.

3.2.

#### Potions

[[item:241288]] is the best DPS potion to use.

You should also keep a stock of [[item:271883]]s to use when at
low health, and if you have a Warlock in the group, grab their
[[item:5512]]s and use them as well. Do not macro these together, they
are best used separately!

3.3.

#### Food Buff

We recommend eating from the [[item:255846]] or [[item:255845]]
when possible, and if no feast is provided for your group, use personal food
([[item:242275]] or [[item:255847]]).

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s
to increase your primary stat. Augment Runes are expensive, and disappear on death,
so use them wisely!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **21 May 2026:** Added FAQ about Crit vs Mastery enchants/consumables.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Speed teas no longer work in instances.
- **16 Mar. 2026:** Added gathering teas to list of consumables. Re-added tertiary enchant total comparison.
- **28 Feb. 2026:** Ring enchant and flask recommendations changed.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for 11.1.5's Corruption Enchant.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for 11.0.7.
- **27 Oct. 2024:** Updated with new theory for 11.0.5.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Updated for Patch 10.2.6, going back to Tepid Versatility in all situations.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated with 10.2's consumables and new head enchant.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for 10.1.5 with new phial and weapon rune suggestions.
- **01 May 2023:** Added the new belt enchant.
- **23 Mar. 2023:** Updated Primordial Stone section with new recommendations due to hotfix changes.
- **20 Mar. 2023:** Added notes about Primordial Stones.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **10 Jan. 2023:** Updated Phial choice, and added Rune choice.
- **11 Dec. 2022:** Updated for beginning of Dragonflight Season 1 with weapon enchant and food choice changes.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Frost Mage in World of Warcraft Patch 12.1.5.

1.

### Frost Mage in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Frost Mage in
Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities optimally.
For a more general overview of Talents for Frost Mage,
please visit our dedicated Talents page.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ guide. To learn more about 
the Mythic+ Meta, check out our Mythic+ Tier List below.

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire in Mythic+

The primary reason to take ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire is the slightly more bursty
damage profile in AoE.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZbWAAAgFAAAAAAYBgttxMzMY2mxMzYbBAAAMzgZgBMDwA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqw4IM5ioB4wYXAHn2TlIJkVMsvRb--UYckgEYIgQRDzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger in Mythic+

The primary reason to take ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger are the more frequent
[[spell:84714]] casts.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAAWAYbbMzMDmthxMsAAAwMbAzADYGMMA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqwIMRCw4wYHRQDHn2TlIJk1L-AAAA-RKQAkIMcYIoJzC-
```

:::

3.

### Flexible Talents

Frost's talents are extremely rigid, so there is not much to change on that
side of the tree.

The class tree side is extremely flexible, with only 7 DPS nodes on the tree.
A good deal of this tree is just pick it if you like the idea of it.

[[spell:30449]] and [[spell:475]] are extremely important if the
dungeon actually has those mechanics. Otherwise they're a complete waste of
talents.

[[spell:1250315]] can be a very nice bonus if you happen to be
eating focused damage and need both charges of [[spell:414659]] in quick
succession.

[[spell:113724]] has the occasional use in preventing charging mobs from
hitting you/the team, but it is fairly rare on top of being advanced tech.

4.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

4.1.

#### Interrupts

[[spell:2139]] is your "kick" and your most important bit of utility
in
Mythic+, used to stop enemy casts for the benefit of the group and especially
the tank. It is **highly recommended** to use a Focus Kick macro for this.

#### Focus Kick Macro

```wow-macro
#showtooltip Counterspell
/cast [@focus, exists, harm,nomod] Counterspell; [nomod]Counterspell
/focus [mod:ctrl][mod:shift/alt, @mouseover]
```

This macro will kick your focus target if you have one and your target if
you do not. Additionally, this allows for assigning a focus target quickly by
either holding Ctrl for your current target or Shift or Alt to assign to your
current mouseover.

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

4.2.

#### Stunning and "Stops"

[[spell:31661]] is our most reliable "AoE stop", which disorients all
targets in a short-range cone.

We do have the option to trade
[[spell:31661]] for [[spell:157980]], but knocks tend to be less
reliable in actually interrupting the current action than an actual hard crowd
control like disorient.

In an absolute last-ditch effort to stop something important, we can
[[spell:118]] a target if vulnerable to it. This should not be utilized
unless it is an emergency, as it will heal the target, and it will start
casting again directly after it breaks.

While not utilized in our usual sets, we do have technical access to
[[spell:113724]] and [[spell:383121]].

### Other Utility

4.3.

#### Other Utility

[[spell:110959]] can not only be used to drop aggro but also
negate certain casts and channels on you. In some
cases, these mechanics will simply re-target someone else in the group, but
occasionally, the mechanic will be entirely negated with huge benefits.

[[spell:30449]] can negate beneficial Magic effects
from enemy targets and occasionally grant them to you instead, although most
of the abusable steals have been nerfed to just let Spellsteal act as a dispel
instead.

[[spell:475]], of course, can allow us to remove curses.

[[spell:386828]] is a strange talent that allows us to completely
negate any form of slow effect, which occasionally removes a dangerous mechanic
entirely.

As Frost Mages, we also slow anything we touch, which can be either good or
bad, depending on how much your tank needs to move mobs or kite things.

5.

### Dealing with Affixes

### Affix: Ascendant

5.1.

#### Ascendant Affix Management for Frost Mage

[[spell:31661]]/[[spell:157980]] will make
short work of this affix.

### Affix: Pulsar

5.2.

#### Pulsar Affix Management for Frost Mage

We do not have anything of particular use here, although
[[spell:444752]] can be used as a run speed buff as
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger.

Make sure to not overshoot someone who is running to you to end the affix,
either. [[spell:1953]]ing past someone only for the affix to go off can be
quite bad, aim your Blink well enough that you don't confuse people coming to
end it on you.

### Affix: Devour

5.3.

#### Devour Affix Management for Frost Mage

[[spell:475]] is a valid dispel for removing [[spell:440313]].

### Affix: Voidbound

5.4.

#### Voidbound Affix Management for Frost Mage

This affix simply adds an extra mob occasionally. It should ideally die to
incidental AoE, but make sure it dies in lower DPS groups or on single target 
fights. There is nothing particularly special about it compared to any other 
mob for us.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **23 Aug. 2025:** Added Season 3 tips.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Minor tweaks to wording and which Hero spec is better.
- **16 Mar. 2025:** Updated with Season 2 dungeon tips.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Added Season 1 dungeon tips with things we can deal with our utility casts.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **15 Jul. 2023:** Subzero nerfed enough to not be worth taking in most M+ setups.
- **10 Jul. 2023:** Updated for Patch 10.1.5's rotational and talent changes.
- **01 May 2023:** Updated for Dragonflight Season 2, and added a section about affixes we can trivialize.
- **20 Mar. 2023:** Changed the default talent tree.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **22 Dec. 2022:** Changed default build to Lonely Winter due to hotfix buffs.
- **11 Dec. 2022:** Added a note about Lonely Winter/Water Elemental decision.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Frost Mage in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Listed below is a collection of useful Macros for Mage, and Frost Mage specifically, with
some of them being usable on all three specs, while others are only useful if you're playing
Frost Mage.

1.1.

#### Generic Macros for Mages

1.1.1.

##### Stopcast Blink

#### Instant Blink

```wow-macro
#showtooltip
/stopcasting
/cast Blink
```

Pressing [[spell:1953]] will now cancel your current spellcast and
causes you to immediately Blink. Note that this should not be used with
[[spell:212653]] as it will unnecessarily cancel your current cast, nor should
it be used if you are casting something that you can wait to finish casting
before needing to Blink

1.1.2.

##### 1-Button Block

#### 1-Button Ice Block

```wow-macro
#showtooltip
/stopcasting
/cancelaura Ice Block
/cast Ice Block
```

Cancels your current cast and immediately puts you in [[spell:45438]].
Pressing Ice Block again will cancel the effect. Not recommended if you spam your
buttons.

1.1.3.

##### Block Cancel

#### Cancel Aura Ice Block

```wow-macro
/cancelaura Ice Block
```

If you are a button spammer, you can put this on a separate keybind as your
[[spell:45438]], allowing you to cancel your Ice Block early if you so
desire.

1.1.4.

##### Alter Time Cancel

#### Cancel Aura Alter Time

```wow-macro
/cancelaura Alter Time
```

You can use the above macro to cancel [[spell:342245]] if you do not want to
be teleported back to the location/health where you were when you initially cast
Alter Time.

1.1.5.

##### Mouseover Decurse

#### Mouseover Remove Curse

```wow-macro
#showtooltip
/use [@mouseover]Remove Curse
```

This will remove curses on whatever unit you are mousing over. You can replace
Remove Curse for any other spells you might want to do on mouseover,
like [[spell:30449]].

1.2.

#### Specific Macros for Frost Mages

#### Blizzard on Cursor

```wow-macro
#showtooltip
/use [@cursor]Blizzard
```

This will automatically place [[spell:190356]] at your mouse cursor when 
pressed, without having to actually click the ground. It should be noted that 
the cursor condition can be applied to any ground target effect, as seen in 
the [[spell:231596]] macro below.

1.2.1.

##### Water Elemental

#### Freeze on Cursor

```wow-macro
#showtooltip
/use [@cursor]Freeze
```

This macro will let you put the [[spell:231596]] ability of your Water 
Elemental on your action bar, and have it cast instantly at your cursor 
location rather than having to click.

These macros allow you to manage your Water Elemental's movement and 
attacks.

#### Pet Attack

```wow-macro
/petattack
```

This orders your Water Elemental to attack your target.

#### Pet Follow

```wow-macro
/petfollow
```

This orders your Water Elemental to follow you.

#### Move-to

```wow-macro
/petmoveto
```

This orders your Water Elemental to move to a location of your choice. 
Moving your Water Elemental to a central location can be very helpful, as the 
Water Elemental sometimes stands very far away from the boss and wastes time 
chasing the boss if the boss moves.

2.

### Best Addons

As of Midnight, addons have been severely restricted from reading anything
combat-related. However, there are still a handful of very useful addons, and
more will be created as developers figure out ways to navigate the current
restrictions. This list will be populated with suggestions as the season goes on
and the author finalizes his UI.

2.1.

#### TargetedSpells

[TargetedSpells](<https://www.curseforge.com/wow/addons/targetedspells>)
is a warning when something is aiming a spell at you. Generally this will allow
you to know when to hit [[spell:414659]] or [[spell:11426]] in the chaos of
a trash pull in Mythic+. As a Mage in the world of pruned defensives, this is
likely going to be the single greatest asset to you.

2.2.

#### ArcUI

[ArcUI](<https://www.curseforge.com/wow/addons/arc-ui>) is an addon
that revamps the cooldown manager in a way that gives you a bit more control
than the default. It does have a fair amount of complexity, and some bugs as it
is a new addon. However, it does do what I wanted in terms of a cooldown manager
skinner, so it has earned a place on this list. What follows is an import string
that will give you what I personally use.

#### Kuni's ArcUI

```wow-macro
DEvxSTrwv441BOPdQsjE36u2s3wTaHwY2FStJtmGAR9e7yN4K4m2X5NfA8DM56zUXJNzYCh)lB3fzjQ23qYs8oYpG4vIq7RGIqibpDvEGNyxq5bEz3LkvHaeSiX5oJD(PS9f6dUZ9EpNZ98DoN735KaFOe1gRqdFSIbIs3D(D5l3DMN64To7ct0NAv3rblQJCSNy56MKBC7BSOUf11azQs7XfpRPkU1fosZXQUDbSRlXuJMojQUdsWPUlXG42wORILLHQvttHUvXTLjGUcD5kVkQgwkTdyq7qAgwYiJSkwMdnZupxLqrYg4IG6UeBA5dvmikvlQdxMME5JqkUKg48owvigy2L6A7)fnm7snoKCgl9u5irJoBS4LoCONue3YnSd2KBEv9JgUDHMeBC4EuDRMEFQ3xbWUg2tCwyD7x)ejDrU4seADKbDQ(oyKABVTMQhaKMIwgwoXcjN5HF2tEYpDKrgjKwWqozE4F9bpOmSkjxMYhDoBfwczyRJcilB5OID43Mu8zM7(3)3ESdYuddbAIcY1Y7e2L9(9nMID1WSRN5H)Lk8)PXEtyvGdqgyh3unWMU00hBzk6bHfretSQWbwMjAGigCGl03YmpKjX1ikchzzUHj6KJy3aUHYsnjQU6e2Kc8GRYIGBZVyzDmrt3L012IsCjwMcSVsjzQocqtz20YIPwTykjjfEuiDiuqEGya0hei(Sp6JHfJiJmv0TCy3ojL0bh)586MeEzvVyIqYzIhB(pK9wcSllmaTxtN9McSVwA2xxG9neytjW(MGZkaUi7wchvNIx0Ruubcc6SPbhtGfXZoZ9bJpWqrEr9LOCXdYMrNBPBIbLoaXlqDLqa8cYMmCFtRffxWROOm3SFlm7wHz3bYXbdPDcE4q7t(3F(nGphMCcajLdnTwatrUa6CXLpqNOIx2)Hq5Jrok766qmRID3nY9)zNdREkZ)9La3tW35TYm)FAfEu6()bpDpP8Qc7RgJJQN9(V)W6yEY8Xp(hcRo2VwVMmYDntJ2L7YxxSTnwYM0cBWUwzVxd5Gkp6LoI)zwtxSjuZ0o4xuwCkE(tKt(49asN7eq2asltovx(JYuQAqw9k6SBfdQopn8)S)0FEy4)zx)6pIh(FqsEflppXHxf2BdSgvQqXUBfKnn72S7YU9Gn2(ThHDhVYuq9p9Z)p34uC(P)XpIBxwKW2HiAMwo4eqoCTgyhhihwwoY9ND(iZmf7ncpied1epaE(wbv3WTNcql4Ivt4EtY79DF0XuudSA(bVyO)9X0EqLKU8GLh5zu41sazx(tv3EPOu41lbz0JA546XXgiQJvZa9BqWnXo8ymt438pkXYXwHTAq2AS8mPaS1dELxj(pPI)Ub82TatW7Ka)YHs7VV0O8Jglu)tL2zdFcBqyUkfyxCSjIEgJvKT(f917IxjWh)7o9ePK1HijC7mPGWPJn24FY5v7smPl4RM59oZjBCYnn2yte7CQacZKUeO5yJ)PN3wJ6FjxCSX)SZFWemPl6DqOF15p4YmPVm)Gx9FE(ia3mc)TZew6M0G0PdYr1pI1RIdgZ7irfo0lhLd12QoqQYk9btypoCGlNu1jpsvfAZKBehznXbCE5dEpE1zGqAbc5eORguViz1Ko6b(07INsnYLCMqA8)B(qoER6618cyeZEOHLs1fbL5R07X3FtoLCw7xxTTjciUfh6fEs0N)kjP3vOFS33iLQCF3uv3HAJua)C0(CZKXJcplB6Pc1o)xkA0y3jwSqTGVImh81rdSUpI17JQ7AjHRWBBbLGuISxHsyhov2ARjw2dGaOOxGTbWZYnAMhr(rBcSeVsOwbyAYkE0emzD2Uyg8iE7CJWuXmLrz78)eUyiD27mk779sdqSVFwwfD2J1zKGS88Kb0fH0Hhkma()MU6jZLkDrVl5lW8VZLoRTJ6B7y(2EEUTFSNxcEHYeCpg8tFeT1giGo4vd1kZVEVF8)YJAaGc4jAS9yKrzfpb75)9)IHssp8N7jjxgo8ZEc8ZYuUWld(V2zDX4NZfph87vd5QOVILkokYWOl0iGtrr58Jh66azFSAwxCn6uSVtfoNzoNb9jSdXtEBQJH((49RtSTHjHEoHMas1f5kwWWYTSmf(n7cxThHMh4LHoZ6SVTVHy7ZakAAzM71y1l3B4SauH(kQ1szQd92Xp1(Q(dzjoywhX6uxRAKo8(QMLTh3FSVe22gT97zpCsqokgo)wS(CxTG38fql609GzsuQcnvObz3zPabceuIycm5ba)Qlx0vq0QLTV8zmEMtnG9K(Ue)gEb3zYbtCkXFBiYh2Sa2agdGhRTd7BUHizOZvI9wEDlNmmBUYS3Rm4FS3DOFXEc3Ny)GY2VgeuwfXhTX)nfF23dxbPHHzQ9gb2BCAr4LQBWdhmjR)Q(4w2qxaSAY2j5dHlB7GRqA1lHK4kjkadA5a9JOG)hSNlPgM6IQzFtYbpT(ZFHRSvGUrE3vvfJxqB1KPZkRlNIuevRIy6g1eBAyTKgjX(AwfSkvWjTwAL1lT8ofxzX93dTyUulvlH5Mj2sPz1SUoz2icspxALAXtKoXAlxOsZK5MFHo5u1MVZkjuwOr(6TSSZ0w2OW0ffZ1Mq3p36RhFJ03D9vWAs7NA6TlkAvitXPt0P6I5ZwNKEARuf1Nnw6gRNEUuZSTu89KPBnR2s1svZkxJ1BMsF2nsgZA14Bhj1cBzrtlV4M6wfmLANjUK7ClLmATI7TxYizR3PuHTxjLMz8K5SmY7q1IS)oPKvQ2OU4IQX70WEvLQZJ1ZS)DV3cABvB)kvlUqSsQoK2jlUsdJ5Ap)ETqr1ZTX(4cB3OzdlX1kSJAN43lF0PxF7cLwk7slTQEQuvnMfvyZDwk9Yf3RfnItLonMxS4MlVz7DkusLiTbozvNIRmtToXselw0D2YOzDRksWqbg16F6Fg1)9d
```

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Added ArcUI and an import code.
- **09 Mar. 2026:** Fixed mouseover macro for Remove Curse.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **29 Apr. 2023:** Removed ElvUI, added mouseover decurse for Afflicted.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
