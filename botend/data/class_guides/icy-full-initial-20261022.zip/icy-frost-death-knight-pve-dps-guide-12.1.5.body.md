## 专精概览

欢迎来到我们的《魔兽世界》12.1.5版本冰霜死亡骑士指南。在这里，你将学习如何在团队副本和大秘境中扮演冰霜死亡骑士：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

冰霜大秘境资源

[全新！顶尖冰霜天赋构筑](<https://raider.io/specs/frost-death-knight/talents>)

[顶尖冰霜大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/death-knight/frost>)

[冰霜大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=death-knight--frost>)

[热门冰霜队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=death-knight--frost>)

1.

### 冰霜死亡骑士概述

冰霜死亡骑士是一个近战输出专精，通过[[spell:49020]]和[[spell:207230]]等强力攻击，以及[[spell:49143]]、[[spell:194913]]和[[spell:1249658]]等技能造成可观的直接伤害。它在顺劈和AOE方面表现不佳，但在单体目标场景中表现出色。它可以装备双手武器以及单手武器。冰霜还拥有一个强大的团队减伤技能[[spell:51052]]。

单体输出优秀

冰霜死亡骑士拥有良好的伤害曲线，每45秒有一个爆发窗口，每1.5分钟有一次更强的爆发。重要的是，两者都是前置伤害，大部分伤害集中在前15秒内。我们很容易进行目标切换，因为[[spell:51714]]的主要叠加过程非常迅速。

单体输出优秀

冰霜死亡骑士由于单体输出优秀，是团队副本中的不错选择。遗憾的是，除非牺牲大量单体输出来点出AOE天赋，否则我们在AOE方面表现不佳。主要缺点是缺乏真正的团队增益buff，以及被迫主要专注于单体目标。

伤害尚可，功能性不足

冰霜死亡骑士在大秘境中表现不错，主要是因为我们点出更多AOE天赋后单体输出会降低。冰霜整体仍能打出可观的伤害，是一个可靠的选择。

我们在大秘境中的表现很大程度上取决于数值调整。我们必须打出出色的伤害才有价值，因为我们的功能性相比其他专精有所欠缺。我们非常耐打，但无法以足够的方式帮助队伍。

有待改进

冰霜死亡骑士遗憾地缺乏大量真正有用的功能性技能。我们有[[spell:49576]]，有时非常有用，但除此之外缺乏重要的团队和队伍增益。[[spell:51052]]是一个不错的魔法减伤技能，我们还有[[spell:207167]]作为打断手段。然而与其他职业相比，除非某个团队副本首领战需要死亡之握，否则我们不会因为强大的功能性而被选中。

极其耐打

冰霜死亡骑士可以说是游戏中防御能力最强的输出专精，与邪恶死亡骑士并列。[[spell:206967]]、[[spell:48263]]、[[spell:391571]]和[[spell:454842]]只是我们众多被动防御天赋中的几个。

此外，我们还有[[spell:49998]]，在我们陷入困境时可以轻松地治疗自己，让我们即使在最危险的情况下也能存活下来。毫不意外，冰霜死亡骑士在团队副本中所有输出专精中死亡次数排名第三少。

改进空间

冰霜死亡骑士因其机动性不足而颇为出名。我们历来是一个非常缓慢的专精，更注重规避位移效果，而非快速移动。我们确实有选择可以点出

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士

来获得

[[spell:444010]]

，大大提升我们的机动机会。鉴于我们通常会使用

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者

，在移动能力方面，我们接近所有专精的垫底水平。

1.

### 冰霜死亡骑士在至暗之夜中的表现

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本对冰霜死亡骑士没有任何改动，但这并不意味着没有新内容。作为一个赛季中期的补丁，新内容相对较少。但别担心，仍然有新的团队副本；新的基斯伊克斯首领战，以及对于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 来说，还有全新的迷宫巨型地下堡！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

随着新的基斯伊克斯团队副本和迷宫巨型地下堡的推出，它们为冰霜死亡骑士提供了全新的装备获取来源。基斯伊克斯掉落极其强大的物品，都是众人争抢的对象。除此之外，在10月20日这些内容上线后，我们还可以用[[item:280562]]来升级我们的武器、饰品和项链。

2.3.

#### 职业改动

12.1.5版本目前对冰霜死亡骑士没有任何改动。

因此，我们的
[天赋](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>) 推荐和
[输出循环](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>) 优先级没有任何变化。不过新团队副本和迷宫地下堡提供了新的装备推荐，详见我们的
[装备](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>) 页面。我们还提供了一份高价值物品清单，供你决定如何花费你的第一批[[item:280562]]。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_frostpresence.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1版本职业平衡调整 隐藏12.1版本职业平衡调整
- **冰霜 12.1改动**
  
  
  
  
  冰霜的核心技能获得了大量数值调整，将伤害从冷却技能转移到了常规输出循环中。以下是所有改动的总结：
  
  
  
  
  削弱：
  
  
  
  
  - [[spell:51271]] -33%
  - [[spell:1249658]] -20%
  - [[spell:455993]] -30%
  - [[spell:279302]] -20%
  - [[spell:49020]] -23.5%
  - [[spell:439843]] -25%
  - [[spell:441378]] -17%
  
  
  
  
  增强：
  
  
  
  
  - [[spell:49184]] +100%
  - [[spell:47568]] +30%
  - [[spell:194913]] +30%
  - [[spell:435010]] +30%
  - [[spell:55095]] +100%
  - [[spell:196770]] +40%
  - [[spell:207230]] +20%
  - [[spell:49143]] +25%
  
  
  
  
  总体而言，由于[[spell:49020]]伤害被削弱（以及一套与[[spell:435010]]高度协同的职业套装），这有利于双持流派。除此之外，我们主要看到的是伤害曲线更加平缓，对爆发的依赖降低。举例来说， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士之前的峰谷比为4.4，在12.1中接近3.4。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜对冰霜死亡骑士的改动

冰霜死亡骑士在至暗之夜中没有获得太多改动。冰霜死亡骑士在《地心之战》中期获得了一次重做，看来开发者对这个新版本很满意。我们在天赋中看到了一些小改动，增强了[[spell:207057]]和[[spell:455993]]，为基础的[[spell:49020]]增加了冰霜伤害成分，并使[[spell:47568]]没有飞行时间。

2.5.

#### 新顶点天赋

我们在专精树中获得了三个新天赋，可以在80级到90级升级过程中点出。这些天赋通常非常强大，特别是增强了[[spell:279302]]。我们获得了该技能的巨大基础伤害提升，使用时的急速增益，[[spell:51271]]的延长效果，以及在首次使用后45秒内重新施放巨龙的选项。

2.6.

#### 英雄天赋改动

两者皆有 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者获得了三个新天赋。驭亡者获得[[spell:1265959]]、[[spell:1265949]]和[[spell:1265971]]。死亡使者获得[[spell:1265859]]、[[spell:1265932]]和[[spell:1265855]]。

这些天赋对我们的影响并不大，主要是以有趣的方式提供了不错的伤害提升。回响狂怒提供两层[[spell:441378]]可能是影响最大的，因为它能产生大量免费的[[spell:51128]]触发。

2.7.

#### 数值调整与生活质量

[[spell:49020]]现在默认将一部分伤害转化为冰霜伤害。这为暴风雪提供了一个很好的调整手段，帮助弥合普通湮灭与[[spell:51128]]湮灭之间的巨大差距。

[[spell:455993]]现在在消耗[[spell:51714]]层数时，对主目标额外造成300%的伤害。这对该技能来说是重大的单体增强，此前它在单体场景中表现不佳。这大大增强了双持流派，使其在所有内容中都更加可行。

[[spell:47568]]现在是瞬发的，不再有弹道。对于一个原本就很棒的技能来说，这是一个非常有用的改动。目前，符文武器增效的弹道机制在某些首领战中会造成问题，我们在实际获得符文能量和[[spell:51128]]触发之前会看到长达0.5秒的延迟。这使得输出循环感觉有些迟滞，打断了你原本熟练的节奏。现在我们可以始终可靠地期待杀戮机器在特定时间到来。

2.8.

#### 职业树改动

死亡骑士的职业树也进行了一些小改动。[[spell:337957]]、[[spell:1266818]]和[[spell:1266819]]都被添加了进来。一些不错的防御技能，以及一个点出[[spell:48743]]的前置（这非常有必要，否则我们永远不会点这个天赋）。死亡笔记在过去会是一个不错的补充，当时[[spell:1249658]]会消耗符文能量。获得它仍然不错，但不再那么有影响力了。[[spell:343294]]已经消失，因为它被移到了邪恶天赋树中，[[spell:327574]]则被直接移除。对于冰霜来说这真的无关紧要，因为我们本来就不会选择这两个天赋中的任何一个。

天赋树中的一些节点也进行了调整。[[spell:276079]]现在作为与[[spell:221562]]的抉择节点，位置好了很多。[[spell:212552]]在树中上移了，现在是与[[spell:391546]]的抉择节点。[[spell:374265]]现在也是一个2点天赋。总体而言，我们可以更多地接触到某些天赋，树中也有了更多选择。[[spell:49998]]和[[spell:389682]]被略微削弱，所以我们失去了一些防御能力，但从大局来看影响不大。

1.

### 冰霜死亡骑士基础玩法

冰霜死亡骑士是一个关于管理资源和充分利用冷却窗口的专精。要最大化冰霜死亡骑士的伤害，你还需要能够很好地调整自己的站位，尤其是在使用[[spell:1249658]]和[[spell:194913]]这类在角色前方造成伤害的天赋时。

冰霜的玩法围绕着强力触发效果、正确的冷却管理和适当的资源使用展开。专精新手可以通过下面三个要点了解玩法基础。

- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_killing_machine.jpg>)
  **消耗你的触发效果**
  
  
  
  
  冰霜在输出循环中会产生多个强力触发效果：[[spell:59057]]、[[spell:51128]]和[[spell:455993]]。关键是要尽快消耗它们，以避免它们互相覆盖。
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_breath_of_sindragosa.jpg>)
  **管理你的冷却技能**
  
  
  
  
  冰霜有多个冷却技能，一起使用时效果会大幅提升。重要的是要让它们始终保持对齐，因为一起使用会增强它们的效果。这些冷却技能是：[[spell:51271]]、[[spell:1249658]]、[[spell:279302]]和[[spell:439843]]（在使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者).
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_runic_empowerment.jpg>)
  **管理你的资源**
  
  
  
  
  冰霜有两种资源：符文和符文能量。管理它们对于最大化你的DPS和避免资源枯竭至关重要。在没有[[spell:51128]]触发时避免消耗符文，其余时候避免符文能量溢出。

1.

### 如何为冰霜死亡骑士配装

虽然我们始终建议你自行模拟以获得最佳结果，但我们确实提供了专门的冰霜配装页面。我们目前提供了第2赛季装备的推荐，以便在至暗之夜终局内容发布时有一个良好的开端。一旦你获得了一些装备，你就需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月19日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 调整了起手循环中死神印记的时机。
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 针对12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 针对12.1.5进行了更新。
- **2026年9月25日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新优先级列表以获得更好的霜之哀伤的狂怒时机。
- **2026年9月14日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对12.1补丁进行了审查。
- **2026年9月14日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 针对12.1补丁进行了审查。
- **2026年9月14日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 针对12.1补丁进行了审查。
- **2026年9月14日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 针对12.1补丁进行了审查。
- **2026年9月14日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新默认和推荐的团队副本构筑为死亡使者冰霜巨龙之辛达苟萨。
- **2026年9月14日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 更新推荐构筑为死亡使者。
- **2026年9月14日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年9月14日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对12.1补丁进行了审查。
- **2026年9月14日（本页）：** 针对12.1补丁进行了审查。
- **2026年9月13日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 针对在线修正更新了装备。
- **2026年8月31日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 更新了目标数量阈值，1-2个目标使用湮灭，3个及以上目标使用冰霜镰刀。
- **2026年8月31日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了目标数量阈值，1-2个目标使用湮灭，3个及以上目标使用冰霜镰刀。
- **2026年8月31日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 更新了目标数量阈值，1-2个目标使用湮灭，3个及以上目标使用冰霜镰刀。
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 新增了最佳制造物品章节。
- **2026年8月15日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 新增了关于洛阿戒指选项的段落。
- **2026年8月13日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 扩展了饰品梯队列表。
- **2026年8月13日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 为大秘境构筑添加了霜刺。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对12.1版本进行了更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已用12.1版本进行更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已为12.1补丁更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已用12.1版本的改动进行更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已用新的12.1构筑进行更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已用12.1版本构筑进行更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 针对12.1进行了更新，包含职业改动和攻略更新。
- **2026年7月3日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年6月20日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 大秘境改为推荐使用双持作为武器。
- **2026年6月20日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 大秘境改为推荐双持。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 针对12.0.7更新了孢子融合物品。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 将默认药水改为无脑莽撞。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对12.0.7版本进行了更新，包含新的时间轴。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 针对12.0.7进行了更新，包含新的万世卷册天赋。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 针对12.0.7版本进行了更新。
- **2026年5月24日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 修正了一处装备掉落位置的笔误。
- **2026年4月28日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 更新了推荐的戒指附魔。
- **2026年4月24日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 更新了冰柱宏。
- **2026年4月24日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手循环和冰霜巨龙之怒的冷却时间管理。
- **2026年4月24日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 阐明了冰霜巨龙之怒的使用方法。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对12.0.5更新了天赋树。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 针对12.0.5进行了更新，包含涡轮加速推荐。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对12.0.5进行审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 为12.0.5更新了构筑，推荐使用破咒者。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对12.0.5版本进行了更新，包含歼灭改动和冰霜巨龙之怒回调改动。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 针对12.0.5进行了更新，破息者现为推荐的大秘境构筑。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已用12.0.5的法术改动进行更新。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对12.0.5更新了天赋。
- **2026年4月20日（本页）：** 已用12.0.5的改动进行更新，并更新了优势部分以减少对顺劈的关注。
- **2026年4月10日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 更新了药水的措辞。
- **2026年4月10日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 澄清了鲁莽的价值。
- **2026年3月29日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 移除了单键助手的主要冷却时间功能。
- **2026年3月29日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 移除了单键助手的主要冷却时间功能。
- **2026年3月29日（本页）：** 添加了另一条调整说明。
- **2026年3月28日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 解决了最佳项链来源的一个问题。
- **2026年3月28日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 添加了双手破息者符文锻造
- **2026年3月26日（本页）：** 已用调整说明进行更新。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 为至暗之夜第1赛季更新，添加了传家宝部分并更新了一些标题。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 为至暗之夜第1赛季更新，包含BiS装备、制造和饰品。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 为至暗之夜第1赛季更新，添加了关于在冰柱宏中使用ERW的说明。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 为至暗之夜第1赛季更新，采用新的BiS天赋分配。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 针对 至暗之夜 第1赛季更新，新增天赋搭配和词缀建议。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对 至暗之夜 第1赛季更新了输出循环，加入了套装对起手的影响。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 针对第1赛季更新了天赋，包含更详细的史诗钥石地下城讨论。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对 至暗之夜 第1赛季更新，提到了套装。
- **2026年3月16日（本页面）：** 针对第1赛季 至暗之夜 更新，新增排名和第1赛季改动。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 添加了80级构筑。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对 至暗之夜 更新，新增等级跨度和天赋搭配。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 针对 至暗之夜 上线更新，新增赛季前毕业装备。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 针对 至暗之夜 更新了宏命令，新增复制功能。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 针对 至暗之夜 更新，新增附魔和消耗品。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 更新了 至暗之夜 属性优先级和属性权重示例。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对午夜更新了输出循环，包含新的循环布局和冰霜巨龙之怒优先级。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 针对 至暗之夜 更新，更改了天赋并新增了顶级天赋部分。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对 至暗之夜 更新，新增天赋搭配、输出循环和属性优先级。
- **2026年2月26日（本页）：** 已针对至暗之夜进行更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对 至暗之夜 预补丁更新，新增天赋和升级输出循环。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 阐明了双手与双持的段落。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 针对 至暗之夜 预补丁更新，对骑手的宏命令做了一些说明。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 针对 至暗之夜 更新，说明了符文锻造的选择，并新增了 至暗之夜 升级消耗品。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 针对预补丁 至暗之夜 更新，因骑手优先级而更改了属性优先级。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已将气息构筑更新为推荐构筑。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 在模拟程序修复漏洞后，更新了冰霜之灾的优先级。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 将冰霜之息更换为推荐天赋搭配，并更新了寒风使者英雄天赋。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对 至暗之夜 预补丁更新，新增天赋搭配、输出循环和属性优先级。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月25日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业装备以体现气息构筑。
- **2026年1月22日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 阐明了气息构筑的可行性。
- **2026年1月19日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 针对 至暗之夜 预补丁更新，改为双持，增加更多急速，并新增升级装备部分。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 针对 至暗之夜 更新，新增天赋搭配。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对 至暗之夜 预补丁更新，因冰霜之灾增益而更改了优先级。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 针对 至暗之夜 预补丁更新，新增天赋搭配并更新了PvP天赋。
- **2025年12月17日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 将低符文的杀戮机器规则从凛风改为冰霜之刺。
- **2025年12月14日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了地下城项链。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对11.2.7版本审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对11.2.7版本审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 针对11.2.7补丁进行了审查。
- **2025年11月27日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 新增常见问题解答并针对11.2.7版本更新。
- **2025年11月27日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 新增常见问题解答并针对11.2.7版本更新。
- **2025年11月27日（本页）：** 新增优缺点分析章节并针对11.2.7版本更新。
- **2025年11月16日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了一些饰品推荐以优先选择棱镜。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 为11.2.5补丁更新。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 新增可疑的卡特尔筹码。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为11.2.5补丁更新。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 针对11.2.5版本更新。
- **2025年9月9日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 修正错别字并改进了非镰刀流派的起手式。
- **2025年9月9日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 新增了大秘境的驭马者天赋切换。
- **2025年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 提升了表述清晰度。
- **2025年9月7日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 改进了关于AOE目标数量的表述清晰度。
- **2025年9月7日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 将冰冷之息移入了冰封之柱宏命令。
- **2025年9月7日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 更新了关于大秘境流派选择的措辞。
- **2025年9月7日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 改进了关于AOE目标数量的表述清晰度。
- **2025年9月6日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式以更好地体现更长的技能序列。
- **2025年9月5日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 改为推荐精通附魔和宝石。
- **2025年9月5日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 将精通列为首要属性。
- **2025年9月5日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 将精通列为首要属性。
- **2025年9月4日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式以反映更好且更简洁的版本。
- **2025年9月2日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业配装以匹配死亡使者属性优先级。
- **2025年9月2日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 阐明了灭绝对输出循环的影响，以及杀戮机器消耗的符文条件。
- **2025年8月31日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 改为推荐死亡使者作为推荐流派。
- **2025年8月31日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 改为推荐死亡使者作为推荐的大秘境天赋。
- **2025年8月31日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 将大秘境流派更新为死亡使者。
- **2025年8月25日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 英雄天赋方面的小幅说明澄清。
- **2025年8月25日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 改为推荐死亡使者作为推荐的团本天赋。
- **2025年8月25日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 更新为推荐死亡使者用于团本，并澄清了武器选择。
- **2025年8月12日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 简化并澄清了冰封之柱宏命令。
- **2025年8月12日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 通过将冰冷之息移出宏命令按钮来简化起手式。
- **2025 年 8 月 10 日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业配装列表和饰品梯队列表。
- **2025年8月7日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 详细说明了宏命令。
- **2025年8月5日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式以匹配新的双湮灭起手式，并添加了AOE选项。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 在11.2重做后更新了升级指南。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 针对11.2版本更新。新的毕业配装列表、神器披风、新套装和新饰品。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 针对11.2版本更新，添加了新流派。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2版本彻底改版了页面，简化了结构和输出循环。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 在11.2版本后更新。添加了新流派并提供了更简洁的建议。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 在11.2重做后更新了技能描述。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 在11.2重做后更新。新天赋、新输出循环和新的冷却章节。
- **2025年8月4日（本页面）：** 在11.2重做后更新。
- **2025年6月27日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了最佳D.I.S.C.效果并在多处改进了措辞。
- **2025年6月27日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 小幅改写以提升清晰度。
- **2025年6月27日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为碎裂之刃添加了更多输出循环切换。
- **2025年6月25日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 移除了不必要的冰封符文之刃行。
- **2025年6月23日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 在调整后更新了最佳D.I.S.C.效果。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 阐明了杀戮机器对湮灭伤害的重要性。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 将新的D.I.S.C.腰带添加到毕业配装列表中，并新增了关于腰带的专门章节。小幅更新了饰品梯队列表。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 更新了起手式宏命令以更准确地体现冰冷之息 -> 宏命令的起手式。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 从附魔表格中移除了堕落十字军以避免混淆。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 添加了更多暴击相关交互，并为属性添加了模拟建议。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了一些流派以在AOE首领战中更偏向AOE。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 为11.1.7补丁更新。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 增加了图片区块的使用并澄清了冰冷之息起手式。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 更新了冰冷之息团本流派以使用无尽寒冬，并澄清了一些流派选择。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 更新了过时的死亡使者天赋。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 详细说明了通用输出循环，为输出循环添加了图片区块，并新增了关于战斗助手的章节。
- **2025年6月15日（本页）：** 添加了11.1.7版本改动。
- **2025年5月15日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 将大秘境流派换为死亡使者。
- **2025年5月15日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 换为死亡使者用于大秘境。
- **2025年4月27日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了卡特尔的措辞和推荐以及毕业配装列表。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 移除了“恭喜你升到80级”这一部分。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 添加了腐蚀附魔推荐。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** 更新流派以使用死亡使者。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 添加了大量地下城技巧。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 在调整后将碎裂之刃流派换为死亡使者。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 更新流派以使用死亡使者。
- **2025年4月21日（本页）：** 将职业调整作为11.5改动的一部分添加。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了流派和技巧。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业配装列表、饰品梯队列表、装饰、制造推荐和套装部分。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 移除了灵魂收割的使用（不值得施放）并扩展了严寒酷刑的玩法说明。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 将毕业团本天赋更改为碎裂之刃。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（本页面）：** 添加了11.1版本改动并清理了指南链接章节。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年2月20日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1版本审查并更新。
- **2025年2月20日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对11.1版本审查并更新。
- **2025年2月20日（本页）：** 已针对11.1版本审查并更新。
- **2024年12月18日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 在新的模拟数据出炉后更新了塞尔西的宝石。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 在增强后更新了毕业配装列表以包含塞尔西的头冠。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 针对11.0.7版本更新，添加了塞尔西的头冠。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已针对11.0.7版本审查并更新。简化了冷却技能的使用。
- **2024年12月15日（本页）：** 已针对11.0.7版本审查并更新。
- **2024年11月8日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 澄清了在没有泰坦之握的情况下使用凋零缠绕的用法。
- **2024年11月8日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 添加了一个专门的大秘境冰冷之息流派。
- **2024年10月26日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 将毕业配装列表中缺失的饰品添加了回来。
- **2024年10月26日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 更新了湮灭宏命令以提升清晰度。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业配装列表中的制造装备。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.5版本更新了流派并审查了技巧。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式以体现死亡印记 + 冰封之柱，并添加了新的灵魂收割者天赋玩法。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 使用11.0.5版本新天赋更新了流派。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 添加了11.0.5的改动。
- **2024年10月14日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业被动饰品，并添加了一些地下堡饰品。
- **2024年10月8日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了收割者印记的优先级，使其与冰霜之柱配合使用。
- **2024年10月8日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 更新了双手武器构筑，使用雪崩替代死神镰刀。
- **2024年10月1日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 更新了构筑以包含碎裂选项。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/frost-death-knight-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/frost-death-knight-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/frost-death-knight-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 为第4赛季更新了所有装备。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新，将腿部附魔改为流光。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 为第4赛季进行了更新，并将湮灭的毕业模拟急速等级改为37.5%。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 为第4赛季更新了天赋。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅和更新，修改了关于冰冷之爪和旧套装的措辞。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 由于新套装，为第4赛季更新了天赋。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 为第4赛季进行了更新。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 为第4赛季进行了审阅和更新。由于新套装，更新了天赋构筑。
- **2024年4月22日（本页）：** 为第4赛季进行了审阅，更新了攻略改动和套装。
- **2024年3月22日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月22日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月22日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月22日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月22日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（本页）：** 针对10.2.6补丁进行了审查。
- **2024年1月23日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 添加了更详细的菲拉雷斯优先级。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 添加了关于镰刀使用的说明。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了冰霜镰刀的优先级。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 明确了凋零寒冬在群体伤害中冰霜之柱内的位置。
- **2023年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 更新了湮灭的杀戮机器优先级。
- **2023年12月15日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 明确了凋零寒冬在群体伤害中的使用。
- **2023年12月15日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了湮灭的优先级，不再贪图双重杀戮机器。
- **2023年12月1日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 明确了不使用湮灭宏时的损失。
- **2023年12月1日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 为急速阈值添加了更多背景信息。
- **2023年12月1日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 明确了使用单个符文武器时的湮灭循环。
- **2023年11月29日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 添加了带有正确毕业链接的传说装备。
- **2023年11月29日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 在冰霜死亡骑士加强后更新了构筑。
- **2023年11月29日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 在冰霜死亡骑士加强后更新了天赋构筑。
- **2023年11月22日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 更新了黎明地下城上下层的掉落位置，并将龙息大秘境毕业饰品改为镜子和瓷偶。
- **2023年11月22日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 更新了湮灭团本构筑以使用持久之寒。
- **2023年11月12日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 更新了食物推荐。
- **2023年11月12日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 上移了无情严冬的优先级，并明确了用凛风刷新。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 在孢子披风削弱后更新了毕业列表和纹章推荐。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 为10.2版本进行了更新。添加了新的毕业列表、饰品和纹章。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对10.2版本进行更新
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 为10.2版本进行了更新。大幅扩展了循环内容。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为10.2版本进行了更新。添加了灵魂收割的使用说明，明确了多个细节，并扩展了冰冷之爪的使用。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 明确了致命执念的玩法。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 添加了10.1.5的地下城推荐。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（本页）：** 添加了10.1.5的改动。
- **2023年6月1日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 添加了大秘境纹章推荐。
- **2023年6月1日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 将急速移到精通之上。
- **2023年6月1日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 扩展了龙息循环，并添加了湮灭的次级爆发窗口。
- **2023年6月1日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 移除了双持湮灭构筑，并更新了团本中双手湮灭的可行性。
- **2023年6月1日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 扩展了冷却技能的使用，并移除了双持湮灭构筑。
- **2023年5月31日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 将奈萨里奥饰品添加为冰霜双手湮灭的新毕业选择。
- **2023年5月8日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 在饰品调整后进行了更新。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 为10.1版本更新了所有装备。
- **2023年5月1日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 为10.1版本进行了审阅和更新。强调了湮灭宏并非必需。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 为10.1版本进行了更新。将戒指附魔改为暴击，并添加了腰带耐力扣环。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 为10.1版本进行了更新。强调了龙息对暴击的极高优先级。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 为10.1版本更新了天赋，并移除了雷鸣词缀的提及。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为10.1版本进行了审阅和更新。主要修改了冰霜巨龙之狂怒的使用。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 为10.1版本进行了更新。在天赋构筑中加入了冰霜巨龙之怒，并添加了龙息大秘境替代构筑。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 为10.1版本进行了审阅和更新。更改了天赋构筑和冰霜巨龙之怒的使用。
- **2023年5月1日（本页）：** 为10.1版本进行了审阅和更新。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/frost-death-knight-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 为10.0.7更新了原初之石宝石。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 为10.0.7更新了天赋构筑。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.7更新了循环，添加了关于致命执念的讨论。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 为10.0.7更新了天赋。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已为10.0.7更新。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 为10.0.7更新了天赋构筑。
- **2023年3月20日（本页）：** 添加了10.0.7的更新日志。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/frost-death-knight-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/frost-death-knight-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/frost-death-knight-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月13日（[9.2版本分析](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-2-changes-analysis>)):** 更新以反映杀戮机器的错误修复。
- **2022年1月19日（[9.2版本分析](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-2-changes-analysis>)):** 用最新的调整进行了更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-1-changes-analysis>)):** 用最近的热修复进行了更新。
- **2021年6月29日（[9.1 补丁分析](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-1-changes-analysis>)):** 创建了页面。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月17日（[永恒宫殿页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-the-eternal-palace-raid-guide>)):** 添加了更多关于艾萨拉女王的信息。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月19日（[风暴熔渣页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** 添加了史诗难度的技巧。
- **2019年4月16日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月16日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月16日（[风暴熔渣页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年2月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了首领建议。
- **2019年2月18日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 修正了首领顺序。
- **2019年1月22日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了达萨罗之战的冰霜死亡骑士建议的第一版。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年9月30日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** 修正了部分推荐天赋。
- **2018年9月9日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** 修正了古尔丹推荐天赋中的一个笔误。
- **2018年9月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** 添加了奥杜尔中所有首领的信息。
- **2018年8月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** 已添加页面（目前为空）。

显示更多

显示更少

:::

## 练级

在本页，您将找到我们的逐级冰霜死亡骑士练级攻略，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[死亡骑士升级指南](<https://www.icy-veins.com/wow/death-knight-leveling-guide>).

1.

### 冰霜死亡骑士练级攻略：适用于至暗之夜

冰霜死亡骑士是一个很好的练级职业，能够快速爆发击杀成群的敌人，同时在达到71级后通过[[spell:444008]]成为机动性最强的练级专精之一。此外，该专精通过[[spell:178819]]的触发拥有出色的自我续航能力，使我们在一波又一波的AoE战斗中保持健康。

1.1.

#### 升级装备选择

升级时，物品等级总是比单项属性更重要。始终选择物品等级最高的装备。带有速度副属性的物品可以帮助加快你的升级速度，尤其是在长时间室内活动期间。传家宝装备在升级时也很有用，可以让你在升级旅程的大部分时间里忽略大量配装需求。

1.2.

#### 符文锻造选择

您的符文锻造选择取决于您使用的等级和武器类型。对于双手武器，始终使用[[spell:53344]]。对于双持，使用[[spell:53344]] +[[spell:326977]]，然后在53级学会[[spell:207057]]后换成主手[[spell:53343]] + 副手[[spell:53344]]。

我们建议在升级过程中使用你物品等级最高的武器，但理想情况下在53级之前使用双手武器，之后再使用双持。

1.3.

#### 至暗之夜升级实用消耗品

在至暗之夜中，你可以使用一些消耗品来加快升级过程。[[item:225592]]是一种能显著提高移动速度的优质食物，从而改善你的升级过程。[[item:109076]]也值得一提，因为当你无法使用飞行坐骑时，它可以成为一种非常高效的交通方式。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 冰霜 80级 至暗之夜 升级
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAAYmhZmZGDzmZmZmZzMz0MjxwMjxYmhZmZmZMDAAAAAAAAAAmFDDAmFQDbYmZmZGYGADAzMAD"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAAYmhZmZGDzmZmZmZzMz0MjxwMjxYmhZmZmZMDAAAAAAAAAgNzihBGYWYohNMzMzMDMDgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-WTVVBXYhZpMAMkEf2gKAywRmggU01dieo4B-WXYHZVUldePiTSJkfjNNOGFbbCcLhg-AAAA-PQMEoYIohZBISB-
```

:::

2.1.

#### 升级用战争模式天赋

[[spell:410301]]是一项可靠的防御升级，而[[spell:204080]]有助于控制你的敌人。所有其他天赋要么影响不大，要么对我们的伤害输出来说更差！

1.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–14：**

根据你选择的种族，你会从不同的等级开始，并且有一个略有不同的开场：

- 如果你选择了一个 **同盟种族** 那么你将从10级开始。
- 另一方面，如果你以非同盟种族开始，你将从8级开始。

你将在10级开始选择天赋，每升一级获得一点天赋点来构建你的角色。

- **等级 27 起：**当你开怪一群敌人时使用[[spell:51271]]。
- **等级 31 起：**[[spell:279302]]应与[[spell:51271]]配合使用，并用于大群敌人、精英或首领怪。
- **等级 55 起：**当目标身上有5层[[spell:51714]]且你触发了[[spell:455993]]时，使用[[spell:49143]]。
- **等级 1–12：**[[spell:316239]]是你的主要伤害技能和符文消耗技能。
- **等级 21 起：**使用[[spell:49184]]来消耗[[spell:59057]]的触发效果。
- **等级 17 起：**使用[[spell:47568]]来产生符文能量和[[spell:51128]]的触发效果。
- **等级 13 起：**[[spell:49020]]是你主要的单体目标符文消耗技能，一旦你在15级开始产生[[spell:51128]]触发效果，它就是一个高伤害技能。
- **等级 23 起：**与3个以上敌人战斗时，使用[[spell:207230]]代替[[spell:49020]]。
- **等级 1–10：**当你有80以上符文能量或没有可用符文时使用[[spell:47541]]。一旦你学会了[[spell:49143]]和[[spell:194913]]，你就不会再使用这个技能了。
- **等级 18 起：**[[spell:46585]]应卡CD使用，或用于首领/精英怪。
- **等级 10 起：**只要有2个以上目标，就使用[[spell:194913]]来消耗你的符文能量。
- **等级 11 起：**在单个目标上使用[[spell:49143]]来消耗你的符文能量
- **等级 10 起：**使用[[spell:49998]]来治疗自己。
- **等级 19–32：**只要有3个以上目标，或者目标能存活到持续时间结束，就使用[[spell:196770]]。

在升级过程中，你会解锁几个被动技能，它们可以改变你的游戏风格和输出循环。

- **等级 21 起：**[[spell:59057]]使你的[[spell:49184]]造成显著更高的伤害。这通常是你唯一想使用[[spell:49184]]的时候。
- **等级 15 起：**[[spell:51128]]是一个被动技能，使你的自动攻击暴击有几率让你的下一个[[spell:49020]]暴击并造成冰霜伤害，显著提高其伤害。它还使你的[[spell:207230]]暴击造成4倍正常伤害。这个触发效果是你伤害输出的重要组成部分。
- **等级 18 起：**[[spell:178819]]对于升级来说非常出色，让你在连续拉怪时能轻松治疗并保持高血量。

**等级 10 起：**3.1.

#### **等级 10 起：**防御和效用技能

- **等级 14 起：**[[spell:48707]]是一个非常强大的魔法护盾，在吸收魔法伤害时还能产生符文能量。只要有魔法伤害就应该使用它，以利用符文能量的生成。
- **等级 9 起：**[[spell:49039]]是一个对升级来说相对强大的技能，因为它为你提供大量吸血。使用这个冷却技能来利用治疗效果，并尽量将其与高AOE或爆发组合配合使用。
- **等级 10 起：**[[spell:48792]]是一个出色的防御冷却技能，应在必要时使用，以保证你能从一个怪群移动到另一个怪群。
- **等级 19 起：**[[spell:61999]]在单人升级时无法使用，但如果你决定以副本组队的方式升级，它在副本队伍中非常出色。
- **等级 9 起：**[[spell:343257]]是你为数不多的移动速度冷却技能之一，因此在升级时非常有用。其次要效果在升级场景中不太有用，除了那个防止你被减速超过一定限度的被动效果。
- **等级 26 起：**[[spell:212552]]是一个不错的额外加速效果，我们会尽可能利用它。
- **等级 8 起：**[[spell:49576]]将你的目标拉向你，让你可以立即开始攻击。对加快升级过程非常有用。
- **等级 16 起：**[[spell:47528]] 是你的打断技能，非常适合用来打断施法怪物，能显著减少它们对你造成的伤害！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月14日：** 针对12.1补丁进行了审查。
- **2026年8月31日：** 更新了目标数量阈值，1-2个目标使用湮灭，3个及以上目标使用冰霜镰刀。
- **2026年8月10日：** 针对12.1版本进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对12.0.5更新了天赋树。
- **2026年3月16日：** 为至暗之夜第1赛季更新，添加了传家宝部分并更新了一些标题。
- **2026年3月2日：** 添加了80级构筑。
- **2026年2月26日：** 针对 至暗之夜 更新，新增等级跨度和天赋搭配。
- **2026年2月10日：** 针对 至暗之夜 预补丁更新，新增天赋和升级输出循环。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年9月7日：** 改进了关于AOE目标数量的表述清晰度。
- **2025年8月4日：** 在11.2重做后更新了升级指南。
- **2025年6月25日：** 移除了不必要的冰封符文之刃行。
- **2025年6月15日：** 阐明了杀戮机器对湮灭伤害的重要性。
- **2025年4月21日：** 移除了“恭喜你升到80级”这一部分。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月22日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩冰霜死亡骑士，使用最简单的输出循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 冰霜死亡骑士基础

本页面面向刚接触游戏或该职业的玩家，他们没有进行史诗难度团队副本的打算，或者只是想要一种更直接的方式来游玩自己的专精，而不会被大量需要考虑的细节和主动技能所淹没。

冰霜死亡骑士是一个近战DPS专精，拥有强大的单体和AOE伤害，以及相当简单易上手的游戏风格。他们可以使用双手或单手武器，其中
**单手武器** 是目前的最佳选择。

冰霜的玩法围绕着强大的触发效果、合理的冷却技能管理以及恰当的资源使用。学习该专精时需要遵循的三条快速规则是：

- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_killing_machine.jpg>)
  **消耗你的触发效果**
  
  
  
  
  冰霜在输出循环中会产生多个强力触发效果：[[spell:59057]]、[[spell:51128]]和[[spell:455993]]。关键是要尽快消耗它们，以避免它们互相覆盖。
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_breath_of_sindragosa.jpg>)
  **管理你的冷却技能**
  
  
  
  
  冰霜有多个冷却技能，一起使用时效果会大幅提升。重要的是要让它们始终保持对齐，因为一起使用会增强它们的效果。这些冷却技能是：[[spell:51271]]、[[spell:1249658]]、[[spell:279302]]和[[spell:439843]]（在使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者).
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_runic_empowerment.jpg>)
  **管理你的资源**
  
  
  
  
  冰霜有两种资源：符文和符文能量。管理它们对于最大化你的DPS和避免资源枯竭至关重要。在没有[[spell:51128]]触发时避免消耗符文，其余时候避免符文能量溢出。

1.

### 至暗之夜中冰霜死亡骑士新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士团队副本天赋

2.1.

#### 冰霜死亡骑士新手团队副本天赋

我们推荐使用带[[spell:1249658]]的
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士和两把单手武器用于单体目标。

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDwMjZmZGDz2MzMzMLmZmMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko015diigcA-WXYZHVlIadefijBPbbhCLcUTSJAAQE-AAAA-PqQMYIIAISRDzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者AOE天赋

2.2.

#### 冰霜死亡骑士新手地下堡与大秘境天赋

我们推荐使用带[[spell:1249658]]的
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者和两把单手武器用于大秘境和地下堡。

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-GIOQaACEWwgCzC-
```

:::

### 冰霜死亡骑士基础输出循环

2.3.

#### 冰霜死亡骑士基础输出循环

在整场战斗中，你的主要目标将是最大化[[spell:51128]]的消耗，同时留意[[spell:59057]]的触发效果。

请注意，下面列出的输出循环并未针对最高可能输出进行完全优化，而是做出了一些牺牲以确保其易用性。

- AOE（3个以上目标）
- 已点出[[spell:455993]]天赋
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 已点出死亡使者天赋

1. 卡CD使用[[spell:51271]]。每第二次使用时，将其与[[spell:279302]]和[[spell:1249658]]结合使用。
2. **适用条件：死亡使者 talented（启用）。** 每次使用[[spell:51271]]时都配合使用[[spell:439843]]。
3. **适用条件：AoE (3+ targets)（未启用）。** 将你的[[spell:51128]]触发效果用于[[spell:49020]]。
4. **适用条件：AoE (3+ targets)（启用）。** 将你的[[spell:51128]]触发效果用于[[spell:207230]]。
5. 使用你的[[spell:47568]]充能来产生[[spell:51128]]的触发效果。
6. 将你的[[spell:59057]]触发效果用于[[spell:49184]]。
7. **适用条件：Frostbane talented（启用）。** 当目标身上有5层[[spell:51714]]且你触发了该效果时，使用[[spell:455993]]。
8. **适用条件：AoE (3+ targets)（未启用）。** 将你的符文能量用于[[spell:49143]]。
9. **适用条件：AoE (3+ targets)（启用）。** 将你的符文能量用于[[spell:194913]]。
10. **适用条件：AoE (3+ targets)（未启用）。** 将剩余的符文用于[[spell:49020]]。
11. **适用条件：AoE (3+ targets)（启用）。** 将剩余的符文用于[[spell:207230]]。

我们第二赛季的套装围绕着我们的[[spell:196770]]技能。2件套效果在冷酷严冬造成伤害时提供叠加的攻击速度和[[spell:435010]]伤害增益。4件套使[[spell:196770]]造成伤害的频率提高25%，并增加2件套增益的持续时间。这对我们的输出循环影响不大，因为[[spell:196770]]是一个完全被动的技能，由[[spell:51271]]触发（因为我们总是点出[[spell:377253]]天赋）。

2.3.1.

##### 冷却技能

作为一名冰霜死亡骑士，你总共有六个冷却技能。下面我们将解释如何最好地使用它们。

- [[spell:439843]]应卡CD使用，并与每次[[spell:51271]]窗口配合，将它们绑定在一起。
- [[spell:51271]]应卡CD使用，与药水或你拥有的任何使用型饰品叠加。由于我们点出[[spell:281238]]，在窗口期内用[[spell:49143]]/[[spell:194913]]/[[spell:49184]]产生[[spell:51128]]，并用[[spell:49020]]/[[spell:207230]]消耗。
- [[spell:279302]]应与[[spell:51271]]协同使用。在[[spell:51271]]开始时使用第一层充能，并在12秒后仍在冰柱窗口内时重新施放。
- [[spell:1249658]]应卡CD使用，并与其他冷却技能协同。将其与[[spell:51271]]绑定在一起。
- 当你有两层充能，或者你没有符文能量且没有[[spell:51128]]用于[[spell:49020]]时，应使用[[spell:47568]]。在你的[[spell:51271]]期间，当你符文用尽时，使用它来获得免费的[[spell:49020]]/[[spell:207230]]。
- [[spell:196770]]应卡CD使用。我们经常点出[[spell:377253]]，它可以自动处理冷酷严冬，并完全移除这个按键。

2.3.2.

##### 巅峰天赋： ![Chosen of Frostbrood Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_reputation_wyrmresttemple.jpg>) 霜巢之眷

冰霜死亡骑士在至暗之夜中从80级升到90级时，可以使用[[spell:1265632]]巅峰天赋。第一级使[[spell:279302]]的伤害提高100%，并在你使用该技能时提供急速增益。第二级[[spell:1265633]]使你在其中施放[[spell:279302]]时，将你激活的[[spell:51271]]延长2/4秒，并增强[[spell:377190]]的威力。最终级[[spell:1265637]]提供10%的冰霜伤害增益，[[spell:279302]]伤害额外提高100%，并允许你在首次使用后的45秒内以50%的效果重新施放该技能。

巅峰天赋极大地激励你点出[[spell:279302]]，并促使你在我们的[[spell:51271]]窗口中使用它。我们在第一个窗口中释放两层充能，以避免错过下一次，并确保将它们错开以避免增益重叠。

### 冰霜死亡骑士属性优先级

2.4.

#### 冰霜死亡骑士属性优先级

这可能会因你角色的装备和天赋而异，所以请务必对自己进行模拟以找到你的属性优先级。此外，不同的构筑有不同的优先级。有关本页所呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>).

暴击

急速

精通

全能

### 暴风雪战斗助手

2.5.

#### 冰霜死亡骑士战斗助手

11.7补丁为游戏中的所有专精引入了战斗助手功能。它以两种工具的形式出现，你可以用它们来辅助你的输出循环。辅助高亮功能会点亮你接下来应该使用的法术，帮助你确定需要按下哪个按钮。单按钮助手会为你提供一个按钮，自动按下相应的法术。重要的是，单按钮助手每次按下都会有0.2秒的公共冷却时间惩罚，人为地减慢你的输出循环。这个惩罚意味着使用单按钮助手时，你的DPS将始终低于你完美执行输出循环所能达到的水平。

你现在可能会问自己一个问题：从这些助手中获得的输出循环有多好？如果我们假设你完美地使用了你的冷却技能，辅助高亮大约会降低5-10%的DPS，而单按钮助手大约会降低15%的DPS。请记住，这是与绝对最优操作相比的。对输出循环经验较少的玩家在使用这些助手时，损失可能会显著减小，甚至可能有所提升。

请记住，单按钮助手不会自动使用[[spell:1249658]]，你必须自己按下那个按钮！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月14日：** 针对12.1补丁进行了审查。
- **2026年8月31日：** 更新了目标数量阈值，1-2个目标使用湮灭，3个及以上目标使用冰霜镰刀。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月24日：** 阐明了冰霜巨龙之怒的使用方法。
- **2026年4月20日：** 针对12.0.5更新了天赋。
- **2026年3月29日：** 移除了单键助手的主要冷却时间功能。
- **2026年3月16日：** 针对 至暗之夜 第1赛季更新，提到了套装。
- **2026年2月26日：** 针对 至暗之夜 更新，新增天赋搭配、输出循环和属性优先级。
- **2026年2月10日：** 针对 至暗之夜 预补丁更新，新增天赋搭配、输出循环和属性优先级。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月9日：** 提升了表述清晰度。
- **2025年9月7日：** 改进了关于AOE目标数量的表述清晰度。
- **2025年9月5日：** 将精通列为首要属性。
- **2025年8月31日：** 将大秘境流派更新为死亡使者。
- **2025 年 8 月 25 日：** 更新为推荐死亡使者用于团本，并澄清了武器选择。
- **2025年8月4日：** 在11.2重做后更新。新天赋、新输出循环和新的冷却章节。
- **2025年6月15日：** 详细说明了通用输出循环，为输出循环添加了图片区块，并新增了关于战斗助手的章节。
- **2025年5月15日：** 换为死亡使者用于大秘境。
- **2025年4月21日：** 更新流派以使用死亡使者。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。简化了冷却技能的使用。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅和更新。由于新套装，更新了天赋构筑。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月29日：** 在冰霜死亡骑士加强后更新了天赋构筑。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月1日：** 扩展了冷却技能的使用，并移除了双持湮灭构筑。
- **2023年5月1日：** 为10.1版本进行了审阅和更新。更改了天赋构筑和冰霜巨龙之怒的使用。
- **2023年3月20日：** 为10.0.7更新了天赋构筑。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到《魔兽世界》12.1.5补丁中你的冰霜死亡骑士的最佳天赋。我们还为各种类型的内容（如团队副本或大秘境）提供了默认天赋构筑。如果你开启了战争模式，我们也为你提供了PvP天赋。

1.

### 最佳 至暗之夜 死亡骑士 冰霜 天赋

欢迎来到我们的 冰霜 死亡骑士 天赋指南。在这里我们将讨论与你的天赋选择相关的所有事项，提供当前可用的最佳构建，以及备选天赋和潜在天赋替换的详细信息。

冰霜 死亡骑士 的天赋树中有一个重要选择：是否点入 [[spell:207057]] 和 [[spell:455993]]。这些天赋依赖于双持构建，将 [[spell:53343]] 作为主手武器的铸符选项。另一种选择是纯 [[spell:1249658]] 配置，它与双手武器和双持都能很好地配合。

我们推荐在所有内容中使用双持 [[spell:1249658]] 构建。

**快速开始导入代码：**

:::talents 冰霜单体
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD"
}
```
:::

:::talents 冰霜 大秘境
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD"
}
```
:::

:::talents 冰霜 探险
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAYAzMMjZMDzmZmZmZxMjmZMGmZGGPwMmZmZmZmZAAAAAAAAAAsZ2MMwAzmGaYDzMzMzAAYAYmZGYA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

死亡使者

团队副本

推荐

秘境+

推荐

地下堡

推荐

天启骑士

团队副本

秘境+

地下堡

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 团队副本构建

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 略微领先于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 在团队副本中。它使用与骑士相同的专精和职业天赋，将 [[spell:436687]] 作为英雄天赋树中唯一重要的选择。

你的主要灵活选择点在于[[spell:456237]]。该天赋在DPS方面与[[spell:1230272]]、[[spell:316803]]和[[spell:1230284]]基本相当。冰霜提供了一些不错的AOE能力，这就是我们默认推荐它的原因，但总体来说有很多选择。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 大秘境构建

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 大秘境构建与我们推荐的骑士团队副本构建非常接近。我们只将 [[spell:1230223]] 替换为 [[spell:1230284]] 以获得更多伤害。死亡使者 在大秘境中以几个百分点胜过骑士，但两个英雄天赋都非常可行。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 探险构建

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 探险构建与我们推荐的骑士团队副本构建非常接近。我们只将 [[spell:1230223]] 替换为 [[spell:1230284]] 以获得更多伤害。死亡使者 在大秘境中以几个百分点胜过骑士，但两个英雄天赋都非常可行。

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 团队副本构建

我们推荐在团队副本中使用双持 [[spell:1249658]] 配置，并使用
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士。它在单体目标中稳稳领先于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者（1%）和 [[spell:455993]] 构建。

你的主要灵活选择点在于[[spell:456237]]。该天赋在DPS方面与[[spell:1230272]]、[[spell:316803]]和[[spell:1230284]]基本相当。冰霜提供了一些不错的AOE能力，这就是我们默认推荐它的原因，但总体来说有很多选择。

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 大秘境构建

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 大秘境构建与团队副本版本几乎完全相同，只是 [[spell:1230301]] 被替换为 [[spell:1230284]]。

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 探险构建

探险的玩法非常适合我们的大秘境构建，它在单体目标和 AoE 之间取得了良好的平衡！我们使用标准的大秘境构建，并使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士（主要是因为你使用骑士时获得的额外速度）。你可以在我们的专门页面上阅读更多关于探险的内容 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 指南！

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDwMjZmZGDz2MzMzMLmZmMjxYYmxgZMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko015diigcA-WXYZHVlIadefijBPbbhCLcUTSJAAQE-AAAA-GQAOCMoQIsQDzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhipqAPQjmqqyotxRuKUk01higcC-WXYZHVlUadefijIJPTSRbbhAACLQcE-AAAA-GIOQaACEWwgCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMzMDY2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhipqAPQnqqyotxRuKUk01higceA-WXYZHVlUadefijIJPTSRbbhAACLQcE-AAAA-GIOQaACEWwgCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDwMjZmZGDz2MzMzMLmZmMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko015diigcA-WXYZHVlIadefijBPbbhCLcUTSJAAQE-AAAA-PqQMYIIAISRDzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-PSMoYIIAISRDzC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-PSMoYIIAISRDzC-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

我们建议你在最初的几周内选择以下增益，但由于你可以随时自由切换，请自行尝试其他选项，如果你觉得推荐的选项效果不够好：

- 第1周：[[spell:1279599]]
- 第2周：[[spell:1279604]]
- 第3周：[[spell:1287555]]
- 第4周：[[spell:1279609]]
- 第5周：[[spell:1279614]]

1.

### 巅峰天赋： ![Chosen of Frostbrood Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_reputation_wyrmresttemple.jpg>) 霜巢之眷

冰霜死亡骑士在至暗之夜中从80级升到90级时，可以使用[[spell:1265632]]巅峰天赋。第一级使[[spell:279302]]的伤害提高100%，并在你使用该技能时提供急速增益。第二级[[spell:1265633]]使你在其中施放[[spell:279302]]时，将你激活的[[spell:51271]]延长2/4秒，并增强[[spell:377190]]的威力。最终级[[spell:1265637]]提供10%的冰霜伤害增益，[[spell:279302]]伤害额外提高100%，并允许你在首次使用后的45秒内以50%的效果重新施放该技能。

顶峰天赋强烈鼓励你点出 [[spell:279302]] 并在我们的 [[spell:51271]] 窗口中使用它。我们在第一个窗口中打出两次充能以避免错过下一个窗口，确保它们分散使用以避免增益重叠。

1.

### 英雄天赋

英雄天赋在71级解锁，是可以选择的互斥天赋树，可以稍微改变游戏玩法。冰霜 死亡骑士 可以在以下之间选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 英雄天赋更注重仆从伤害，你的骑士既可以通过 [[spell:279302]] 被动召唤，也可以主动召唤。它与 [[spell:455993]] 也有很好的协同作用，通过 [[spell:444037]] 天赋增加 [[spell:49143]] 的伤害。它通过 [[spell:444010]] 技能带来出色的实用性，并且更加强调你与 [[spell:444040]] 的1.5分钟冷却窗口。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 专注于你的45秒爆发窗口，[[spell:439843]] 不仅自身造成可观伤害，还能强化你的其他技能。它带来大量额外触发和收益，通过 [[spell:441378]] 提供多次额外的 [[spell:51128]] 触发以及免费的 [[spell:55095]] 应用。

1.

### PvP天赋（战争模式）

在本节中，我们将为升级和开放世界内容排名最佳的 PvP 天赋。

- 户外世界中启用的PvP天赋。
- 升级时获得的经验值和任务奖励提高15%。

鉴于启用战争模式对升级和PvE内容的好处，建议启用该功能以最大化你的升级效率和满级后的奖励。然而，你将使自己成为开放世界PvP的目标，并且在升级或进行世界任务时存在被“偷袭”的可能性。

在本节中，我们将为升级和单人/小队 PvE 内容排名最佳的 PvP 天赋。以下是通用 PvP 天赋和 冰霜 死亡骑士 专属 PvE 天赋的排名。

1. [[spell:204080]] 将敌人定身4秒。它可以通过直接施放 [[spell:196770]] 施加，或者对已经受到 [[spell:45524]] 影响的目标施放 [[spell:45524]] 来施加。在 PvE 内容中没有价值。
2. [[spell:233396]] 使你的 [[spell:49184]] 和 [[spell:49143]] 对目标施加 [[spell:233396]]。Delirium 使移动技能的冷却恢复速度降低50%，持续12秒。
3. [[spell:199719]] 使你周围8码内敌人的施法距离降低30%。在 PvE 中没有用处。
4. [[spell:77606]] 在你的敌人身上放置一个减益效果，当他们施放消耗法力的法术时激活。它允许你在一段时间内使用相同的法术。在 PvE 内容中没有用处。
5. [[spell:47476]] 沉默你的目标4秒。不如直接使用 [[spell:221562]]（它会替换该天赋），是一个相当无用的 PvE 天赋。
6. [[spell:356470]] 在目标受到 [[spell:45524]] 影响时降低其8%的急速。[[spell:49143]] 延长其持续时间。在 PvE 中没有用处。
7. [[spell:202727]] 为被 [[spell:43265]] 命中的任何目标添加一个吸收护盾，吸收量为伤害量的100%。在 PvE 中没有用处。
8. [[spell:410301]] 在你按下 [[spell:49998]] 时提供4秒的25%物理伤害减免。可靠的防御提升！
9. [[spell:410320]] 将 [[spell:48707]] 的冷却时间缩短10秒，并允许你对盟友使用它。这是一个很好的防御提升，因为它允许更多的反魔法护罩使用。
10. [[spell:1218603]] 强化你的 [[spell:51271]]，使其施放一个 [[spell:196770]]，伤害提高400%，半径提高150%。你的移动速度大幅降低，[[spell:51271]] 的冷却时间增加15秒。在 PvE 中通常不值得。

[[spell:410301]] 是可靠的防御升级，[[spell:204080]] 帮助控制你的敌人。所有其他天赋要么影响不大，要么对我们的伤害输出更差！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月14日：** 更新推荐构筑为死亡使者。
- **2026年8月13日：** 为大秘境构筑添加了霜刺。
- **2026年8月10日：** 已用12.1版本构筑进行更新。
- **2026年6月20日：** 大秘境改为推荐双持。
- **2026年6月15日：** 针对12.0.7进行了更新，包含新的万世卷册天赋。
- **2026年4月20日：** 针对12.0.5进行了更新，破息者现为推荐的大秘境构筑。
- **2026年3月16日：** 针对第1赛季更新了天赋，包含更详细的史诗钥石地下城讨论。
- **2026年2月26日：** 针对 至暗之夜 更新，更改了天赋并新增了顶级天赋部分。
- **2026年2月10日：** 将冰霜之息更换为推荐天赋搭配，并更新了寒风使者英雄天赋。
- **2026年1月22日：** 阐明了气息构筑的可行性。
- **2026年1月19日：** 针对 至暗之夜 预补丁更新，新增天赋搭配并更新了PvP天赋。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月9日：** 新增了大秘境的驭马者天赋切换。
- **2025年9月7日：** 更新了关于大秘境流派选择的措辞。
- **2025年8月31日：** 改为推荐死亡使者作为推荐的大秘境天赋。
- **2025 年 8 月 25 日：** 改为推荐死亡使者作为推荐的团本天赋。
- **2025年8月4日：** 在11.2版本后更新。添加了新流派并提供了更简洁的建议。
- **2025年6月15日：** 更新了冰冷之息团本流派以使用无尽寒冬，并澄清了一些流派选择。
- **2025年5月15日：** 将大秘境流派换为死亡使者。
- **2025年4月21日：** 在调整后将碎裂之刃流派换为死亡使者。
- **2025 年 2 月 24 日：** 将毕业团本天赋更改为碎裂之刃。
- **2025年2月20日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年11月8日：** 添加了一个专门的大秘境冰冷之息流派。
- **2024年10月21日：** 使用11.0.5版本新天赋更新了流派。
- **2024年10月8日：** 更新了双手武器构筑，使用雪崩替代死神镰刀。
- **2024年10月1日：** 更新了构筑以包含碎裂选项。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 由于新套装，为第4赛季更新了天赋。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月29日：** 在冰霜死亡骑士加强后更新了构筑。
- **2023年11月22日：** 更新了湮灭团本构筑以使用持久之寒。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月1日：** 移除了双持湮灭构筑，并更新了团本中双手湮灭的可行性。
- **2023年5月1日：** 为10.1版本进行了更新。在天赋构筑中加入了冰霜巨龙之怒，并添加了龙息大秘境替代构筑。
- **2023年3月20日：** 为10.0.7更新了天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何优化你的 冰霜 死亡骑士 在单体目标和多目标情况下的输出循环。我们还有关于冷却时间、触发等的进阶部分，以最大化你的 DPS。我们的所有内容均针对魔兽世界12.1.5版本补丁进行了更新。

1.

### 冰霜 死亡骑士 玩法与循环指南

欢迎来到我们的 冰霜 死亡骑士循环页面。在这里，我们将介绍你需要了解的一切，以便在团队副本和大秘境场景中最佳地发挥你的专精。

在下方选择天赋和英雄天赋后，本指南中的循环将会相应更新。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者

冰龙吐息 团队副本

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

冰龙吐息 大秘境

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

霜缚 大秘境

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士

冰龙吐息 团队副本

冰龙吐息 大秘境

霜缚 大秘境

主动天赋

被动天赋

[[spell:1249658]]

[[spell:279302]]

[[spell:439843]]

[[spell:377253]]

[[spell:207057]]

[[spell:455993]]

[[spell:207230]]

### 冰霜 死亡骑士 详解

1.1.

#### 冰霜 死亡骑士 详解

冰霜 死亡骑士 依赖于符文和符文能量的双资源系统。符文随时间被动充能，并用于 [[spell:49020]] 和 [[spell:207230]] 等技能。消耗符文会产生符文能量，我们将其用于 [[spell:49143]] 和 [[spell:194913]] 等技能。

我们的循环中有两个强大的触发效果需要围绕它们来打：[[spell:59057]] 和 [[spell:51128]]。[[spell:59057]] 通过使用 [[spell:49143]] 和 [[spell:194913]] 触发。它显著强化我们的 [[spell:49184]] 技能，这也是我们唯一使用该技能的时候。[[spell:51128]] 主要通过我们的暴击自动攻击或主动的 [[spell:47568]] 技能触发。我们还通过 [[spell:281238]] 和 [[spell:441378]]（![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者）天赋获得触发。该触发强化我们的 [[spell:49020]] 和 [[spell:207230]] 技能，使它们造成显著更高的伤害。

核心循环归结为正确管理你的资源，以及尽可能多地产生和消耗你的触发：

- 将 [[spell:51128]] 的触发消耗在 [[spell:49020]]（单体目标）或 [[spell:207230]]（AoE）上
- 将 [[spell:59057]] 的触发消耗在 [[spell:49184]] 上
- 使用 [[spell:47568]] 产生 [[spell:51128]] 的触发，以避免使用无 [[spell:51128]] 的 [[spell:49020]]/[[spell:207230]]
- 将你产生的符文能量消耗在 [[spell:49143]]（单体目标）或 [[spell:194913]]（AoE）上

### 单体输出循环

[[spell:47568]]

**适用条件：Reaper's Mark（未启用）。**

[[spell:49020]]

**适用条件：Reaper's Mark（启用）。**

[[spell:439843]]

**适用条件：Frozen Dominion（未启用）。**

[[spell:196770]]

**适用条件：Breath of 辛达苟萨（启用）。**

[[spell:51271]]

[[spell:279302]]

[[spell:1249658]]

[[item:270175]]

[[item:241288]]

[[spell:46585]]

**适用条件：Breath of 辛达苟萨（未启用）。**

[[spell:51271]]

[[spell:279302]]

[[item:270175]]

[[item:241288]]

[[spell:46585]]

**适用条件：Reaper's Mark（启用）。**

[[spell:49020]]

[[spell:47568]]

**适用条件：Reaper's Mark（未启用）。**

[[spell:49020]]

1.2.

#### 冰霜 死亡骑士单体目标起手式

起手式是你在与敌人交战时使用的一系列固定技能。记住它有助于你以最优的方式开始你的循环。

1. [[spell:47568]]
2. **适用条件：Reaper's Mark（未启用）。** [[spell:49020]]
3. **适用条件：Reaper's Mark（启用）。** [[spell:439843]]
4. **适用条件：Frozen Dominion（未启用）。** [[spell:196770]]
5. **适用条件：Breath of 辛达苟萨（启用）。** [[spell:1249658]] + [[spell:51271]] + [[spell:279302]] + 药水 + 饰品 + [[spell:46585]]
6. **适用条件：Breath of 辛达苟萨（未启用）。** [[spell:51271]] + [[spell:279302]] + 药水 + 饰品 + [[spell:46585]]
7. **适用条件：Reaper's Mark（启用）。** [[spell:49020]]
8. [[spell:47568]]
9. **适用条件：Reaper's Mark（未启用）。** [[spell:49020]]

1.3.

#### 冰霜 死亡骑士单体目标循环

1. 如果你有 [[spell:51128]] 的触发，使用 [[spell:49020]]
2. **适用条件：Shattering Blade（启用）；Frostbane（未启用）。** 如果你有5层 [[spell:51714]]，使用 [[spell:49143]]
3. **适用条件：Shattering Blade（启用）；Frostbane（启用）。** 如果你有5层 [[spell:51714]]，使用 [[spell:49143]]/[[spell:455993]]
4. 如果你有 [[spell:59057]] 的触发，使用 [[spell:49184]]
5. 使用 [[spell:49143]]
6. 使用 [[spell:47568]] 产生一层 [[spell:51128]] 和40点符文能量
7. 使用无杀戮机器的 [[spell:49020]]

让我们结合一些额外的背景信息来分解核心循环：

- 使用 [[spell:49020]] 消耗你的 [[spell:51128]] 触发。关于何时优先消耗一层 [[spell:51128]] 而不是避免符文能量溢出，有一些细微差别。如果你有3个以上符文，优先处理杀戮机器的触发。如果你的符文不足，且符文能量达到70以上（这种情况经常发生，因为你经常忽略符文能量水平），则使用 [[spell:49184]] 配合 [[spell:59057]] 或 [[spell:49143]] 的触发。如果你有两层杀戮机器，始终尽快消耗。如果你点出了 [[spell:207057]]，同样的逻辑适用，在符文不足时，优先在5层 [[spell:51714]] 时使用 [[spell:49143]] 而不是消耗 [[spell:51128]]。
- 使用 [[spell:49184]] 消耗你的 [[spell:59057]] 触发。
- 你使用 [[spell:49143]] 来消耗你的符文能量，或者以更高的优先级在拥有 [[spell:207057]]/[[spell:455993]] 触发和5层 [[spell:51714]] 时使用。由于无杀戮机器的 [[spell:49020]] 伤害很低，而且它也不产生任何触发，我们总是先用完符文能量，然后才考虑按下无杀戮机器的 [[spell:49020]]。
- 你使用 [[spell:47568]] 来尽量避免按下无杀戮机器的 [[spell:49020]]。一旦你用完了所有的符文能量，按下 [[spell:47568]] 来获得一个触发和更多符文能量，使你能够接上 [[spell:49020]] 或 [[spell:49143]]。如果你有两层，也以高优先级按下它。
- 无杀戮机器的 [[spell:49020]] 位于我们优先级列表的底部。它的伤害很低，实际上与其他任何天赋都没有协同作用。我们主要将其作为产生符文能量的手段，以便消耗在 [[spell:49143]] 上！

### 多目标循环

[[spell:47568]]

**适用条件：Frostscythe（启用）；Reaper's Mark（未启用）。**

[[spell:207230]]

**适用条件：Frostscythe（未启用）；Reaper's Mark（未启用）。**

[[spell:49020]]

**适用条件：Frozen Dominion（未启用）。**

[[spell:196770]]

**适用条件：Breath of 辛达苟萨（启用）。**

[[spell:439843]]

[[spell:1249658]]

[[spell:51271]]

[[spell:46585]]

**适用条件：Breath of 辛达苟萨（未启用）。**

[[spell:279302]]

[[spell:51271]]

[[spell:46585]]

**适用条件：Reaper's Mark（启用）；Frostscythe（未启用）。**

[[spell:49020]]

**适用条件：Frostscythe（启用）；Reaper's Mark（启用）。**

[[spell:207230]]

[[spell:279302]]

[[spell:47568]]

**适用条件：Frostscythe（启用）；Reaper's Mark（未启用）。**

[[spell:207230]]

**适用条件：Frostscythe（未启用）；Reaper's Mark（未启用）。**

[[spell:49020]]

1.4.

#### 冰霜 死亡骑士多目标起手式

1. [[spell:47568]]
2. **适用条件：Frostscythe（启用）；Reaper's Mark（未启用）。** [[spell:207230]]
3. **适用条件：Frostscythe（未启用）；Reaper's Mark（未启用）。** [[spell:49020]]
4. **适用条件：Frozen Dominion（未启用）。** [[spell:196770]]
5. **适用条件：Breath of 辛达苟萨（启用）；Reaper's Mark（启用）。** [[spell:1249658]] + [[spell:51271]] + [[spell:439843]] + 药水 + 饰品 + [[spell:46585]]
6. **适用条件：Breath of 辛达苟萨（未启用）；Reaper's Mark（未启用）。** [[spell:51271]] + [[spell:279302]] + 药水 + 饰品 + [[spell:46585]]
7. **适用条件：Reaper's Mark（启用）；Frostscythe（未启用）。** [[spell:49020]]
8. **适用条件：Frostscythe（启用）；Reaper's Mark（启用）。** [[spell:207230]]
9. [[spell:279302]]
10. [[spell:47568]]
11. **适用条件：Frostscythe（启用）；Reaper's Mark（未启用）。** [[spell:207230]]
12. **适用条件：Frostscythe（未启用）；Reaper's Mark（未启用）。** [[spell:49020]]

1.5.

#### 冰霜死亡骑士多目标输出循环

多目标循环在很多方面与单目标循环相似。你只需将[[spell:49020]]替换为[[spell:207230]]，将[[spell:49143]]替换为[[spell:194913]]。需要注意的一点是[[spell:455993]]，它会在AoE循环中引入[[spell:49143]]（作为[[spell:455993]]的触发效果）。在3个及以上目标时，我们切换使用[[spell:207230]]和[[spell:194913]]。

1. **适用条件：霜镰（未启用）。** 如果你有 [[spell:51128]] 的触发，使用 [[spell:49020]]
2. **适用条件：霜镰（启用）。** 如果你触发了[[spell:51128]]，请使用[[spell:207230]]
3. **适用条件：霜噬（启用）。** 当[[spell:455993]]触发时，对拥有5层[[spell:51714]]的目标使用[[spell:455993]]。
4. **适用条件：Frozen Dominion（未启用）。** 使用[[spell:196770]]
5. 如果你有 [[spell:59057]] 的触发，使用 [[spell:49184]]
6. 使用[[spell:194913]]
7. 使用[[spell:47568]]以产生一层[[spell:51128]]和40点符文能量。
8. **适用条件：霜镰（未启用）。** 使用无杀戮机器的 [[spell:49020]]
9. **适用条件：霜镰（启用）。** 使用一次没有杀戮机器的[[spell:207230]]

在AOE场景中，消耗[[spell:51128]]与花费符文能量之间同样存在这种微妙的权衡。如果你的符文充足（3个以上），始终消耗杀戮机器。如果符文不足，优先使用触发了[[spell:59057]]或[[spell:194913]]的[[spell:49184]]。如果已叠有两层[[spell:51128]]，则始终尽快消耗杀戮机器。

:::details 常见问题我应该在叠有两层[[spell:51128]]之前等待吗？
你理想情况下应该在 **一层** 尽可能保持一层[[spell:51128]]。在某些情况下你会故意叠到两层，主要是在符文不足的时候。如果你的符文少于三个，优先消耗[[spell:59057]]的触发以及符文能量，然后再消耗杀戮机器。

:::

1.

### 至暗之夜 第2赛季套装

我们第二赛季的套装围绕着我们的[[spell:196770]]技能。2件套效果在冷酷严冬造成伤害时提供叠加的攻击速度和[[spell:435010]]伤害增益。4件套使[[spell:196770]]造成伤害的频率提高25%，并增加2件套增益的持续时间。这对我们的输出循环影响不大，因为[[spell:196770]]是一个完全被动的技能，由[[spell:51271]]触发（因为我们总是点出[[spell:377253]]天赋）。

1.

### 职业与专精机制详解

本节将深入探讨冰霜死亡骑士的机制，涵盖我们所使用的资源以及一些在更深入理解循环时会很有用的进阶主题。

### 符文与符文能量

3.1.

#### 符文与符文能量

死亡骑士使用符文和符文能量的双重资源系统。虽然其运作方式相当简单明了，但为了完整性，我们仍在此进行说明。

3.1.1.

##### 符文

你总共有6个符文，默认情况下可用。你的一些技能有符文消耗，每当你使用消耗一个或多个符文的技能时，那些符文会立即开始充能。符文充能所需的确切时间取决于你拥有多少急速。

每当消耗一个符文时，你会获得10点符文能量（下文详述）。

最多可以有3个符文同时处于充能状态。因此，最好让至少3个符文处于冷却状态，以在整场战斗中最大化充能速率。

3.1.2.

##### 符文能量

符文能量是一种类似于怒气的资源，它在脱离战斗时会衰减，但在战斗中不会衰减。如上所述，消耗符文每花费一个符文会产生10点符文能量，这是产生符文能量的主要方式，尽管一些技能也有助于此。你的符文能量上限为100点。

一般来说，应该在符文不足时，或者没有[[spell:59057]]触发的[[spell:51128]]触发效果时花费符文能量。有些情况下你会溢出符文能量，但这完全没问题。

3.2.

#### 追踪你的资源

由于死亡骑士有多种资源需要追踪，自定义你的界面以轻松追踪资源非常有帮助。能够轻松专注于你的循环和资源可以帮助你最大化你的伤害和站位。

### 站位

3.3.

#### 站位

冰霜死亡骑士拥有多个技能，包括主动和被动技能，它们会攻击你角色前方的敌人。其中最主要的是[[spell:1249658]]、[[spell:194913]]和[[spell:435010]]。因此，在进行AOE伤害时，让你的角色面向尽可能多的敌人至关重要。始终站在一群敌人的边缘并面向内侧，以最大化你的DPS。

### 巅峰天赋

3.4.

#### 巅峰天赋

冰霜死亡骑士在至暗之夜中从80级升到90级时，可以使用[[spell:1265632]]巅峰天赋。第一级使[[spell:279302]]的伤害提高100%，并在你使用该技能时提供急速增益。第二级[[spell:1265633]]使你在其中施放[[spell:279302]]时，将你激活的[[spell:51271]]延长2/4秒，并增强[[spell:377190]]的威力。最终级[[spell:1265637]]提供10%的冰霜伤害增益，[[spell:279302]]伤害额外提高100%，并允许你在首次使用后的45秒内以50%的效果重新施放该技能。

顶峰天赋强烈鼓励你点出 [[spell:279302]] 并在我们的 [[spell:51271]] 窗口中使用它。我们在第一个窗口中打出两次充能以避免错过下一个窗口，确保它们分散使用以避免增益重叠。

### 符文、符文能量和精通

3.5.

#### 符文

你总共有6个符文，默认情况下可用。你的一些技能有符文消耗，每当你使用消耗一个或多个符文的技能时，那些符文会立即开始充能。符文充能所需的确切时间取决于你拥有多少急速。

每当消耗一个符文时，你会获得10点符文能量（下文详述）。

最多可以有3个符文同时处于充能状态。因此，最好让至少3个符文处于冷却状态，以在整场战斗中最大化充能速率。

3.6.

#### 符文能量

符文能量是一种类似于怒气的资源，它在脱离战斗时会衰减，但在战斗中不会衰减。如上所述，消耗符文每花费一个符文会产生10点符文能量，这是产生符文能量的主要方式，尽管一些技能也有助于此。你的符文能量上限为100点。

3.7.

#### 精通：冰封之心

[[spell:77514]]会提高你造成的所有冰霜伤害。

### 触发效果

3.8.

#### 杀戮机器触发效果

你的自动攻击暴击有几率使你的下一次[[spell:49020]]必定暴击并造成冰霜伤害，这意味着它会根据你的精通进行加成并无视护甲。它还会使你的[[spell:207230]]暴击伤害提升至正常的4倍，而非标准的2倍。杀戮机器基于你上次触发后所获得的自动攻击暴击次数来运作。对于双持武器，在上次触发后你第一次获得自动攻击暴击时，你有30%的几率获得新的触发。如果失败，下一次自动攻击有60%的几率。如果这又失败了，你将获得90%的触发几率，如果连续三次自动攻击暴击未触发，则下一次触发几率为100%。

装备双手武器（并通过[[spell:81333]]法术）会提高这些触发几率。你每次自动攻击暴击都有100%的几率触发。不过，由于双手武器攻击速度较慢，且你只有一把武器进行攻击，使用双手武器的配装时触发次数仍会减少28%。

通常，这些触发效果应立即使用，以确保没有触发效果被覆盖。

如果你拥有[[spell:281238]]天赋，那么该技能会使你的每一次[[spell:49143]]、[[spell:194913]]和[[spell:49184]]触发[[spell:51128]]（持续时间等同于[[spell:51271]]）。注意不要溢出[[spell:51128]]，如果你已经有两层充能，不要主动去产生它。

3.9.

#### 凛风触发效果

你的[[spell:49143]]/[[spell:194913]]有45%的几率使你的下一次[[spell:49184]]不消耗资源并造成额外伤害，这要归功于[[spell:59057]]。请务必在使用下一次[[spell:49143]]/[[spell:194913]]之前消耗这些触发效果！

1.

### 冰霜死亡骑士的重要冷却技能

### 死神印记

4.1.

#### 死神印记

[[spell:439843]] 是你从 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者天赋树中获得的主动技能。冷却时间为45秒，你可以将它与每一次[[spell:51271]]窗口对齐！只需每次都将它与你的[[spell:51271]]做成宏即可。

关于[[spell:439843]]，需要考虑的主要方面是它通过消耗[[spell:441378]]触发效果所产生的[[spell:51128]]数量。一旦[[spell:439843]]爆发，你会获得两个[[spell:441378]]，它们会提供两次[[spell:51128]]触发。注意追踪触发效果，以便你知道何时产生杀戮机器，并避免不必要的双层叠加或溢出。另外请记住，[[spell:441378]]会减少你的[[spell:49020]]/[[spell:207230]]1个符文的消耗，使你能在爆发窗口中使用更多次。

### 冰霜之柱

4.2.

#### 冰霜之柱

[[spell:51271]]为你提供20%力量，持续12秒。冷却时间为45秒，与[[spell:439843]]、[[spell:279302]]和[[spell:1249658]]配合良好，无论我们选择哪种天赋组合。

你应该在冷却好时立即使用此技能，最好与你可能拥有的任何药水或主动使用饰品结合使用。话虽如此，有时将其保留几秒直到出现高优先级目标可能更好。

在[[spell:51271]]期间最大化你使用的GCD数量对于最大化你的DPS至关重要。因此，我们在使用冰霜之柱时会利用宏，将非GCD技能与占用GCD的技能结合，以便在窗口期内立即施放你的第一个法术。这要求你在使用宏之前从一个空的GCD开始！你可以在攻略的宏部分阅读更多相关信息。

### 冷酷严冬

4.3.

#### 冷酷严冬

[[spell:196770]]在8秒内对周围所有目标造成伤害并使其减速20%。该天赋的价值和用法会根据你使用的天赋配置发生显著变化。

[[spell:377253]]完全移除了该天赋的主动部分，只需在你使用[[spell:51271]]时自动施放即可。这是最常见的情况，让使用变得简单得多。

如果没有[[spell:377253]]，情况会变得更加复杂。在单体目标中，如果我们点出了以[[spell:194912]]为首的增益类天赋，我们会卡冷却使用冷酷严冬。理想情况下，尽量让它与每一次[[spell:51271]]对齐，因此稍微延迟它以保持与45秒冷却周期同步。在这种情况下，你应该尽可能延长敌人身上的[[spell:376938]]减益效果。此外，如果你能在冷酷严冬仍在运行时刷新它（通过[[spell:194912]]显著延长它），你就能在保留增益层数的同时刷新其持续时间，这将带来巨大的DPS提升！

最后一种单体目标使用场景是你只点了[[spell:456237]]。在这种情况下，确保在你达到20层时使用[[spell:196770]]来消耗层数！

在AOE中，我们总是尽可能多地使用该技能（在没有[[spell:377253]]的情况下）来造成AOE伤害，并通过[[spell:316916]]增益你的[[spell:207230]]使用。

### 符文武器增效

4.4.

#### 符文武器增效

[[spell:47568]]是一个非GCD的[[spell:51128]]和符文能量生成器。它有助于我们减少在战斗中施放的无杀戮机器的[[spell:49020]]数量，并提供大量资源。此外，在配合[[spell:281238]]的[[spell:51271]]期间，它能提供大量免费的湮灭施放，这非常有价值。

我们希望在即将达到两层时使用该技能，以免溢出。否则，当我们无法使用[[spell:49143]]且没有[[spell:51128]]触发时，我们会使用它。最后，我们在[[spell:51271]]期间使用它来获得杀戮机器，并帮助我们维持健康的资源水平！

### 冰龙吐息

4.5.

#### 冰龙吐息

[[spell:1249658]]消耗60点符文能量，持续8秒，对面前造成AOE伤害。持续时间可以通过消耗[[spell:51128]]和[[spell:59057]]的触发来延长，最多可延长至30秒！

为了最大化该技能，我们将其与[[spell:281238]]结合使用。[[spell:281238]]完全围绕着[[spell:51128]]的生成和消耗，与[[spell:1249658]]配合得非常好！由于我们已经将触发效果置于列表顶部，我们的循环在冰龙吐息期间不会主动改变，我们只需继续执行标准的单体目标循环即可！

确保为每一个你计划使用冰龙吐息的[[spell:51271]]预留符文能量，以确保你拥有启动窗口所需的60点！

请注意，使用[[spell:1249658]]时会提供一层[[spell:47568]]。确保在按下冰龙吐息之前绝不拥有两层充能。

### 冰霜巨龙之怒

4.6.

#### 冰霜巨龙之怒

[[spell:279302]]是一个强大的单体和AOE冷却技能，并且会被我们的顶峰天赋进一步增益。每当你使用它时，你可以在45秒的窗口内再次按下按钮，以50%的效果召回巨龙。在每个[[spell:51271]]窗口使用[[spell:279302]]（在宏中与
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士一起，或者在冰霜之柱之后立即使用，配合 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者）。在约12秒后使用第二次充能，此时仍在你的[[spell:51271]]期间，且急速增益已经消退（记住召回是非GCD的）。

你可以选择将第二次[[spell:279302]]施放到下一个[[spell:51271]]窗口。这通常不被推荐，因为要正确执行非常困难，因为冰霜之柱和召回计时器的持续时间相同。

### 湮没

4.7.

#### 湮没

[[spell:281238]]本身不是冷却技能，但它确实显著改变了[[spell:51271]]的工作方式，值得提及。拥有该天赋且在冰霜之柱激活时，[[spell:49143]]、[[spell:194913]]和[[spell:49184]]都会生成[[spell:51128]]的触发。因此，我们最终进入一种“交织”循环，每个GCD都生成并消耗[[spell:51128]]的触发。

交织的特性使你能够轻松预测窗口期内的操作，优化你的法术使用和GCD利用率。你知道[[spell:49143]]/[[spell:194913]]会生成一个[[spell:51128]]，然后你用[[spell:49020]]/[[spell:207230]]来消耗它。如果你获得了[[spell:59057]]的触发，你知道接下来要按下[[spell:49184]]，然后是另一个[[spell:49020]]/[[spell:207230]]，依此类推。利用这种冷却的确定性来最大化你的技能使用！

最后，你要带着足够的资源进入窗口，以便在没有任何停顿的情况下执行它。[[spell:47568]]有助于防止这种情况，但你仍应避免在窗口开始前约5秒内消耗无杀戮机器的[[spell:49020]]（只要你的符文低于4个）。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月19日：** 调整了起手循环中死神印记的时机。
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月25日：** 更新优先级列表以获得更好的霜之哀伤的狂怒时机。
- **2026年9月14日：** 更新默认和推荐的团队副本构筑为死亡使者冰霜巨龙之辛达苟萨。
- **2026年8月31日：** 更新了目标数量阈值，1-2个目标使用湮灭，3个及以上目标使用冰霜镰刀。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 针对12.0.7版本进行了更新，包含新的时间轴。
- **2026年4月24日：** 更新了起手循环和冰霜巨龙之怒的冷却时间管理。
- **2026年4月20日：** 针对12.0.5版本进行了更新，包含歼灭改动和冰霜巨龙之怒回调改动。
- **2026年3月29日：** 移除了单键助手的主要冷却时间功能。
- **2026年3月16日：** 针对 至暗之夜 第1赛季更新了输出循环，加入了套装对起手的影响。
- **2026年2月26日：** 针对午夜更新了输出循环，包含新的循环布局和冰霜巨龙之怒优先级。
- **2026年2月10日：** 在模拟程序修复漏洞后，更新了冰霜之灾的优先级。
- **2026年1月19日：** 针对 至暗之夜 预补丁更新，因冰霜之灾增益而更改了优先级。
- **2025年12月17日：** 将低符文的杀戮机器规则从凛风改为冰霜之刺。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025年11月27日：** 新增常见问题解答并针对11.2.7版本更新。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年9月9日：** 修正错别字并改进了非镰刀流派的起手式。
- **2025年9月7日：** 将冰冷之息移入了冰封之柱宏命令。
- **2025年9月6日：** 更新了起手式以更好地体现更长的技能序列。
- **2025年9月4日：** 更新了起手式以反映更好且更简洁的版本。
- **2025年9月2日：** 阐明了灭绝对输出循环的影响，以及杀戮机器消耗的符文条件。
- **2025年8月12日：** 通过将冰冷之息移出宏命令按钮来简化起手式。
- **2025年8月5日：** 更新了起手式以匹配新的双湮灭起手式，并添加了AOE选项。
- **2025年8月4日：** 针对11.2版本彻底改版了页面，简化了结构和输出循环。
- **2025年6月27日：** 为碎裂之刃添加了更多输出循环切换。
- **2025年6月15日：** 增加了图片区块的使用并澄清了冰冷之息起手式。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 移除了灵魂收割的使用（不值得施放）并扩展了严寒酷刑的玩法说明。
- **2025年2月20日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年11月8日：** 澄清了在没有泰坦之握的情况下使用凋零缠绕的用法。
- **2024年10月21日：** 更新了起手式以体现死亡印记 + 冰封之柱，并添加了新的灵魂收割者天赋玩法。
- **2024年10月8日：** 更新了收割者印记的优先级，使其与冰霜之柱配合使用。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅和更新，修改了关于冰冷之爪和旧套装的措辞。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月23日：** 添加了更详细的菲拉雷斯优先级。
- **2024年1月15日：** 更新了冰霜镰刀的优先级。
- **2023年12月15日：** 更新了湮灭的优先级，不再贪图双重杀戮机器。
- **2023年12月15日：** 明确了凋零寒冬在群体伤害中的使用。
- **2023年12月1日：** 明确了使用单个符文武器时的湮灭循环。
- **2023 年 11 月 12 日：** 上移了无情严冬的优先级，并明确了用凛风刷新。
- **2023年11月6日：** 为10.2版本进行了更新。添加了灵魂收割的使用说明，明确了多个细节，并扩展了冰冷之爪的使用。
- **2023年9月4日：** 明确了致命执念的玩法。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月1日：** 扩展了龙息循环，并添加了湮灭的次级爆发窗口。
- **2023年5月1日：** 为10.1版本进行了审阅和更新。主要修改了冰霜巨龙之狂怒的使用。
- **2023年3月20日：** 为10.0.7更新了循环，添加了关于致命执念的讨论。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到魔兽世界12.1.5版本中你的冰霜死亡骑士的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章升级装备的建议，我们一应俱全！

1.

### 冰霜死亡骑士毕业装备指南

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

:::details 常见问题：双手武器还是单手武器更好？
在至暗之夜第2赛季中，双持武器严格更优。这是由于多种因素，但主要是与[[spell:435010]]的强大协同作用，后者受到第2赛季套装的增益。

:::

### 总体

此列表包含来自所有来源的冰霜死亡骑士最高DPS配置。请记住，还有许多其他配置的表现在误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择和你拥有的装备，你下一个最佳装备在某些方面可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第二赛季中，催化一件装备会保留其副属性（以及物品等级）。这为我们在优化装备分配时提供了更大的灵活性。因此，我们希望使用以下部件：

- 头部：[[item:281239@JAACAAQ42A]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 肩膀：[[item:251138]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 胸部：[[item:268222]]，来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 手套：[[item:271475]]，来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- 腿部：[[item:271878]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details 常见问题我应该优先选择哪些物品？
有几件物品在你的毕业装备中优先级非常高，你希望从宏伟宝库和虚空核心使用中优先获取：

- [[item:268209]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：毕业的高物品等级武器，带有与我们毕业被动饰品协同的额外效果。
- [[item:268202]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业的高物品等级武器，带有额外强大的触发型效果。
- [[item:270175]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：更高物品等级的毕业主动使用饰品。
- [[item:268265]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业的项链，物品等级更高并带有额外效果。
- [[item:270173]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：毕业的被动饰品，与我们的毕业武器协同。
- [[item:281029]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业的戒指，带有额外效果。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:281239@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271473@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271477@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[spell:62158]]</span></div></td></tr><tr><th>副手</th><td>[[item:268202@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[spell:53344]]</span></div></td></tr></tbody></table>

### 秘境+

此列表包含冰霜死亡骑士来自大秘境来源的最高DPS配置。这不是你的最佳配置 **，而是** 仅限大秘境 **来自** 大秘境的。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第二赛季中，催化一件装备会保留其副属性（以及物品等级）。从大秘境中，我们希望催化以下部件：

- 头部 - [[item:251126]]
- 肩部 - [[item:251138]]
- 胸部 - [[item:268222]]
- 手部 - [[item:159413]]
- 腿部 - [[item:273776]]

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：可靠的武器，毕业护肩和可靠的胸甲。
- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：毕业戒指。
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：毕业戒指，出色的项链和头盔。
- [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)：不错的腰带和鞋子。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271474@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAAEAAAj1gjM]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271473@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:239656@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>脚部</th><td>[[item:159412@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271477@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273797@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:158373@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[spell:62158]]</span></div></td></tr><tr><th>副手</th><td>[[item:158373@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[spell:53344]]</span></div></td></tr></tbody></table>

### 团队副本

此列表包含来自团队副本的冰霜死亡骑士最高伤害输出配装。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，催化一件装备会保留其副属性（和物品等级）。来自团队副本，我们想要催化以下装备：

- 头部 - [[item:281239@JAACAAQ42A]]
- 肩部 - [[item:268226]]
- 胸部 - [[item:268222]]
- 手部 - 套装部件
- 腿部 - [[item:271878]]

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:268209]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：毕业的高物品等级武器，带有与我们毕业被动饰品协同的额外效果。
- [[item:268202]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业的高物品等级武器，带有额外强大的触发型效果。
- [[item:270175]]：更高物品等级的毕业主动使用饰品。
- [[item:268265]]：更高物品等级且带有额外效果的毕业项链。
- [[item:270173]]：与我们毕业武器协同的毕业被动饰品。
- [[item:281029]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业的戒指，带有额外效果。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:281239@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271473@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271477@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[spell:62158]]</span></div></td></tr><tr><th>副手</th><td>[[item:268202@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[spell:53344]]</span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 第2赛季冰霜死亡骑士饰品推荐

冰霜死亡骑士偏好一个主动饰品和一个被动饰品的组合。对于主动饰品，[[item:270175]]凭借与我们1.5分钟冷却时间的良好协同，是目前的最佳选择。由于掉落自最终首领，它也拥有更高的物品等级。

对于被动饰品，[[item:270173]]是我们的最佳选择。它是一个直接伤害被动饰品，与我们的毕业武器[[item:268209]]协同良好。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **冰霜死亡骑士饰品**
**使用型 -**

[[item:270175]]

或者，作为替代，

[[item:250238]]

**被动 -**

[[item:270173]]

或者，作为替代，

[[item:270164]]

:::

还有不少其他有价值的饰品，所以请务必点击我们的排名图表，看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看冰霜死亡骑士饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270175]] - <span><em>点击查看详情</em></span>&#10;<span>目前最好的主动使用饰品，与我们1.5分钟的冷却时间协同良好。它比第二好的主动饰品领先近4%，因此没有真正的争议。&#10;       </span>&#10;&#10;&#10;&#10;[[item:270173]] - <span><em>点击查看详情</em></span>&#10;<span>低目标数量下最好的被动饰品。其伤害触发实在太过强大，尤其是与[[item:268209]]配合时。&#10;       </span>&#10;&#10;&#10;&#10;[[item:281215]] - <span><em>点击查看详情</em></span>&#10;<span>AoE场景下最好的被动属性饰品。凭借其高触发率，在低目标数量下它接近于断头台的表现，但在多目标场景中更为出色，在大秘境内容中尤其有效。&#10;       </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:249343]]（298 物品等级）</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:246305]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:273796]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193762@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:270163]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

至暗之夜的12.0.5版本引入了一个新的、但似曾相识的系统： [混沌虚空核心](<https://www.wowhead.com/currency=3418>)
允许你定向获取特定首领或地下城的战利品。使用它可保证从该来源掉落一件物品，不过具体是哪件仍然是随机的。然而，一旦你以这种方式获得了一件物品，未来的使用将优先考虑你尚未从该物品池中收集到的物品。

[[item:268552]]可以强化已经达到最高物品等级的英雄和史诗难度装备，以及完全升级的光辉锻造物品。它提供类似过往涡轮加速升级的额外威力提升，但只能应用于武器和饰品。

3.1.

#### 虚无核心推荐

从特定地下城或首领处获得一件有保障的战利品非常有用。总体而言，我们推荐将其用于团队副本首领，因为这样可以获得更高物品等级的装备。我们推荐将其用于以下首领（如果你还没有指定的物品的话）。务必自行模拟，以找到最适合你角色装备和属性的选择！

- [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 用于[[item:268209]]、[[item:270173]]、[[item:268259]]、[[item:268222]]和[[item:268253]]。
- [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 用于[[item:270175]]、[[item:268265]]、[[item:271878]]和[[item:268202]]。

3.2.

#### 至高毒石推荐

优先升级装备相对简单：从你的武器开始，然后是你的饰品，最后升级你的项链。

1.

### 冰霜死亡骑士最佳制造装备

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

决定制造什么是一项艰巨的任务。我们的毕业制造装备是靴子和护腕，两者都带有暴击精通和[[item:240167]]。然而，早期制造武器往往是目前最大的升级，也是更高效地花费你纹章的方式。总体而言，这是大多数人会做的选择。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **冰霜死亡骑士制造装备优先级**
- [[item:237834@JAAKAAwt1ENMMYDYwclI]]搭配[[item:240167]]
- [[item:237828@JAAKAAwt1ENMMYDYwclI]]搭配[[item:240167]]
- 任何你尚未获得神话级的物品。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 冰霜死亡骑士最佳美化

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

由于衬饰的竞争非常激烈，你必须为你整体的DPS输出挑选出最强的两个。大多数衬饰提供的DPS收益非常相似，即使效果完全不同。对此最佳的两个选择是：

- 团队副本：在制造的靴子和制造的护腕上使用[[item:240167]]。
- 大秘境：在制造的靴子和制造的护腕上使用[[item:240167]]。

严格来说，护腕上的[[item:251490]]加上[[item:251513]]毕业领先0.2%。然而，我们推荐双[[item:240167]]，因为它能为你的团队提供额外收益，并且便于多专精切换（邪恶使用奥术织网）。

一个强力的替代方案是在一到两把制造的单手武器上使用[[item:245876]]。这在赛季初期尤其强大，因为它能让你获得高物品等级的武器（该部位每点物品等级带来的收益最大）。因此，务必考虑在赛季初期制造武器。

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

[秘境雾崖](<https://www.wowhead.com/currency=3446>) 是一种你可以用来升级装备的货币。每件装备都属于特定的升级路线，可以升级到特定的最高等级。如果你看到一件物品显示史诗 3/6，这意味着它总共可以升级3次以达到史诗 6/6。由于纹章每周获取量有限，且升级不同物品花费的纹章数量相同，你应该优先将纹章用于那些你近期不打算更换，或能带来最大收益的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **冰霜死亡骑士纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子/戒指**

:::

这些只是通常最值得升级的物品。不要盲目遵循此优先级，因为有时你会想优先升级其他装备。务必自行模拟，以确定当前的最佳选择。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 针对12.1.5进行了更新。
- **2026年9月13日：** 针对在线修正更新了装备。
- **2026年8月17日：** 新增了最佳制造物品章节。
- **2026年8月15日：** 新增了关于洛阿戒指选项的段落。
- **2026年8月13日：** 扩展了饰品梯队列表。
- **2026年8月10日：** 已用12.1版本进行更新。
- **2026年6月15日：** 针对12.0.7更新了孢子融合物品。
- **2026年5月24日：** 修正了一处装备掉落位置的笔误。
- **2026年4月20日：** 针对12.0.5进行了更新，包含涡轮加速推荐。
- **2026年3月28日：** 解决了最佳项链来源的一个问题。
- **2026年3月16日：** 为至暗之夜第1赛季更新，包含BiS装备、制造和饰品。
- **2026年2月26日：** 针对 至暗之夜 上线更新，新增赛季前毕业装备。
- **2026年2月10日：** 阐明了双手与双持的段落。
- **2026年1月25日：** 更新了毕业装备以体现气息构筑。
- **2026年1月19日：** 针对 至暗之夜 预补丁更新，改为双持，增加更多急速，并新增升级装备部分。
- **2025年12月14日：** 更新了地下城项链。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025年11月16日：** 更新了一些饰品推荐以优先选择棱镜。
- **2025 年 10 月 5 日：** 新增可疑的卡特尔筹码。
- **2025年9月2日：** 更新了毕业配装以匹配死亡使者属性优先级。
- **2025年8月10日：** 更新了毕业配装列表和饰品梯队列表。
- **2025年8月4日：** 针对11.2版本更新。新的毕业配装列表、神器披风、新套装和新饰品。
- **2025年6月27日：** 更新了最佳D.I.S.C.效果并在多处改进了措辞。
- **2025年6月23日：** 在调整后更新了最佳D.I.S.C.效果。
- **2025年6月15日：** 将新的D.I.S.C.腰带添加到毕业配装列表中，并新增了关于腰带的专门章节。小幅更新了饰品梯队列表。
- **2025年4月27日：** 更新了卡特尔的措辞和推荐以及毕业配装列表。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 更新了毕业配装列表、饰品梯队列表、装饰、制造推荐和套装部分。
- **2024年12月18日：** 在新的模拟数据出炉后更新了塞尔西的宝石。
- **2024年12月17日：** 在增强后更新了毕业配装列表以包含塞尔西的头冠。
- **2024年12月15日：** 针对11.0.7版本更新，添加了塞尔西的头冠。
- **2024年10月26日：** 将毕业配装列表中缺失的饰品添加了回来。
- **2024年10月21日：** 更新了毕业配装列表中的制造装备。
- **2024年10月14日：** 更新了毕业被动饰品，并添加了一些地下堡饰品。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季更新了所有装备。
- **2024年3月22日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月29日：** 添加了带有正确毕业链接的传说装备。
- **2023年11月22日：** 更新了黎明地下城上下层的掉落位置，并将龙息大秘境毕业饰品改为镜子和瓷偶。
- **2023年11月7日：** 在孢子披风削弱后更新了毕业列表和纹章推荐。
- **2023年11月6日：** 为10.2版本进行了更新。添加了新的毕业列表、饰品和纹章。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 添加了10.1.5的地下城推荐。
- **2023年6月1日：** 添加了大秘境纹章推荐。
- **2023年5月31日：** 将奈萨里奥饰品添加为冰霜双手湮灭的新毕业选择。
- **2023年5月8日：** 在饰品调整后进行了更新。
- **2023年5月1日：** 为10.1版本更新了所有装备。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的冰霜死亡骑士的最佳属性优先级。我们首先介绍属性优先级，然后深入讲解属性如何与你的专精和游戏玩法相互作用。我们的内容已更新至《魔兽世界》12.1.5版本。

1.

### 冰霜死亡骑士属性优先级

对于团队副本和大秘境，冰霜死亡骑士的副属性优先级如下：

暴击

急速

精通

全能

暴击和急速与冰霜死亡骑士的技能体系有特殊协同，因为有若干能力基于自动攻击暴击，而自动攻击暴击本身通过暴击和急速进行缩放。[[spell:51128]]、[[spell:435010]]和[[spell:456240]]等等，都随着你能打出的自动攻击暴击次数而缩放。同时，我们手动的[[spell:51128]]生成器会抵消这一效果，因为必定暴击会降低暴击的价值。

请注意 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者对急速的优先级略低，使用死亡使者时请自行模拟以找到最佳平衡。

1.

### 深入属性解析

**力量** 是你的主要属性。你应该在所有升级中寻找它。它为你提供攻击强度，决定了你技能的伤害。

**急速** 提高你的攻击速度和符文回复速度，同时缩短公共冷却时间。它通过提高攻击速度来增加[[spell:51128]]的触发次数。

**暴击** 提高你所有法术和技能的暴击几率。暴击默认造成双倍伤害，但有多种效果可以提高你的暴击伤害，使暴击更加强力。

暴击同样能增加[[spell:51128]]的触发次数，因为它增加了你打出的自动攻击暴击次数！此外，它与冰霜死亡骑士技能体系中的若干能力（如[[spell:435010]]、[[spell:456240]]和[[spell:440031]]）配合良好。同时，它会被你手动生成的必定暴击的[[spell:51128]]所降低价值。

**精通**，通过[[spell:77514]]，提高你的冰霜伤害。冰霜伤害占你总伤害的很大一部分。

**全能** 增加你造成的所有伤害和治疗，并减少你受到的所有伤害。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月14日：** 针对12.1补丁进行了审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月3日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年4月10日：** 澄清了鲁莽的价值。
- **2026年3月16日：** 为至暗之夜第1赛季更新，采用新的BiS天赋分配。
- **2026年2月26日：** 更新了 至暗之夜 属性优先级和属性权重示例。
- **2026年2月10日：** 针对预补丁 至暗之夜 更新，因骑手优先级而更改了属性优先级。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月5日：** 将精通列为首要属性。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月27日：** 小幅改写以提升清晰度。
- **2025年6月15日：** 添加了更多暴击相关交互，并为属性添加了模拟建议。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新，并将湮灭的毕业模拟急速等级改为37.5%。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年12月1日：** 为急速阈值添加了更多背景信息。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月1日：** 将急速移到精通之上。
- **2023年5月1日：** 为10.1版本进行了更新。强调了龙息对暴击的极高优先级。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页，我们根据你的属性优先级，列出了你的冰霜死亡骑士可以获取的最佳宝石、附魔、药剂、药水和食物。 [属性优先级](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

我们推荐将[[item:240983]]作为你的史诗宝石，然后将[[item:240906]]或[[item:240908]]作为你的非史诗宝石，优先选择你装备上最少的属性。也就是说，如果你装备上已经有很多急速，就镶嵌提供更多精通的宝石，反之亦然。

1.

### 最佳附魔和武器强化

冰霜死亡骑士可以在武器上使用强大的符文熔炉代替普通附魔。选择正确的附魔对于优化你的伤害输出至关重要。以下是不同可行流派的最佳附魔！

- [[spell:53344]] + [[item:243733]] 用于双手武器。
- [[spell:53343]] + [[item:243733]] 用于双手破胆者。
- 主手[[spell:53343]] + [[spell:53344]] + [[item:243733]] 用于双持[[spell:207057]]/[[spell:455993]]流派。
- 主手[[spell:62158]] + [[spell:53344]] + [[item:243733]] 用于双持[[spell:1249658]]流派。
- 主手[[spell:53343]] + [[spell:53344]] + [[item:243733]] 用于双持破胆者流派。

:::details 常见问题：不同的符文熔炉附魔有什么作用？
- [[spell:53344]]：冰霜死亡骑士的标准符文熔炉，你会在大秘境和团队副本内容中始终看到使用这个符文熔炉。
- [[spell:53343]]：这个符文熔炉用于某些双持流派。它让你能从[[spell:207057]]中获得大量收益。
- [[spell:326805]]：为[[spell:49998]]提供一个小的斩杀效果和一个小的免死机制。这个符文熔炉更多用于PvP而非PvE内容。
- [[spell:326855]]：对法系职业提供少量防御，使其更偏向于PvP场景。
- [[spell:327082]]：目前与其他选项相比非常弱，尤其是与[[spell:53344]]相比。
- [[spell:62158]]：提供可观的属性量，与双持流派配合良好。
- [[spell:326977]]：由于提供移动速度、急速以及击杀敌人时的治疗，常用于升级。

:::

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>肩部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;</tr></table>

1.

### 最佳消耗品

你可以消耗多种不同的临时物品来提升你在地下城和团队副本中的实力。以下是关于所有你想要使用物品的全面概述！

3.1.

#### 合剂

你通常应该在所有内容中使用[[item:241326]]。如果你的暴击已经足够高（1600+），考虑使用[[item:241322]]或[[item:241325]]来获得更好的属性分配。请自行模拟以确定。

3.2.

#### 药水

我们有一些药水选项可以使用，但我们推荐[[item:241288]]作为你在所有内容中的常用药水。

你还应该确保备有足够的[[item:271883]]！这些治疗药水在你需要快速治疗自己、帮助你的治疗者以及确保你存活下来时非常出色。

3.3.

#### 食物增益

对于冰霜死亡骑士，提升你主属性的食物是最佳选择。这意味着你要么吃像[[item:255846]]或[[item:255845]]这样的盛宴。如果你的队伍或团队没有提供盛宴，你可以吃[[item:255847]]或[[item:242275]]作为替代。

3.4.

#### 强化符文

此外，如果负担得起，你应该使用 [[item:259085]] 来提高你的主属性。强化符文价格昂贵且死亡后消失，所以请明智而节制地使用它们！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月14日：** 针对12.1补丁进行了审查。
- **2026年8月10日：** 已用12.1版本的改动进行更新。
- **2026年6月15日：** 将默认药水改为无脑莽撞。
- **2026年4月28日：** 更新了推荐的戒指附魔。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年4月10日：** 更新了药水的措辞。
- **2026年3月28日：** 添加了双手破息者符文锻造
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 针对 至暗之夜 更新，新增附魔和消耗品。
- **2026年2月10日：** 针对 至暗之夜 更新，说明了符文锻造的选择，并新增了 至暗之夜 升级消耗品。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月5日：** 改为推荐精通附魔和宝石。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 从附魔表格中移除了堕落十字军以避免混淆。
- **2025年4月21日：** 添加了腐蚀附魔推荐。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新，将腿部附魔改为流光。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023 年 11 月 12 日：** 更新了食物推荐。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1版本进行了更新。将戒指附魔改为暴击，并添加了腰带耐力扣环。
- **2023年3月20日：** 为10.0.7更新了原初之石宝石。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5版本中使用你的冰霜死亡骑士挑战大秘境地下城的技巧和建议。

1.

### 冰霜死亡骑士在至暗之夜第2赛季的大秘境

在本指南中，我们将讨论如何在大秘境地下城中充分发挥你的冰霜死亡骑士的实力，包括设置角色的最佳方式、你的输出循环可能如何变化，以及最优化使用技能的技巧和窍门。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

冰霜死亡骑士是一个扎实的大秘境专精，拥有很高的天赋多样性和选择空间。我们每45秒提供一次不错的爆发，其中每隔一次更为强力。我们非常耐打，但通常不会带来太多团队辅助能力。

1.

### 最佳大秘境天赋配置

冰霜死亡骑士在第2赛季有两个主要天赋流派可供选择。你要么使用[[spell:1249658]]要么使用[[spell:455993]]。总体而言，[[spell:1249658]]提供了单体和AoE伤害的最佳平衡，也是我们推荐的流派。

如果你熟悉第1赛季的大量流派，第2赛季由于[[spell:435010]]的增强以及[[spell:455993]]的削弱，流派多样性有所减少。这意味着我们基本上必须点出IDT，留给流派多样性的空间就少了很多。

我们建议在所有大秘境内容中使用双持冰霜吐息流派。

### 双持 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 [[spell:455993]]

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 [[spell:455993]] 流派采用双持配置，搭配 [[spell:53343]] 和 [[spell:53344]]。这与其他流派不同，其他流派则使用 [[spell:62158]] 和 [[spell:53344]]。它拥有良好的持续AOE潜力，但在单体和整体DPS方面往往有所欠缺。

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxwMjxgxMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAARGF-AAAA-GIOQaACEWwgCzC-
```

:::

### 双持 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 [[spell:1249658]]

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 [[spell:1249658]] 流派在单体和AOE伤害之间取得了最佳平衡。它与我们的团本配置非常接近，只是将 [[spell:1230301]] 换成 [[spell:1230284]] 以获得额外的AOE能力。

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-GIOQaACEWwgCzC-
```

:::

### 双持 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 [[spell:1249658]]

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 搭配 [[spell:1249658]] 略逊一筹 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 在大秘境中的表现。它带来了略微更具爆发性的伤害曲线，更加侧重于1.5分钟的冷却窗口。

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-PSMoYIIAISRDzC-
```

:::

### 双持 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 [[spell:455993]]

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士 搭配 [[spell:455993]] 是 [[spell:1249658]] 流派的一个有趣替代方案。它提供了更持续的DPS，因为它对1.5分钟爆发窗口的依赖稍低，但单体和整体DPS往往过低，缺乏竞争力。

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxwMjxgxMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAARGF-AAAA-PSMoYIIAISRDzC-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断、昏迷和控制

[[spell:47528]] 是你的“打断”，也是你在大秘境中最重要的功能性技能，用于打断敌人的施法，使团队尤其是坦克受益。它是 **强烈推荐** 使用焦点打断宏来完成此操作。

#### 心灵冰冻 鼠标指向

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 心灵冰冻
```

这个宏会打断你的焦点目标（如果有），如果没有焦点目标则打断鼠标悬停目标，如果两者都没有则打断你的当前目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**.

#### 焦点 鼠标指向

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

3.2.

#### 眩晕与"打断"

[[spell:207167]] 是你的“AOE打断”。你致盲前方锥形范围内的所有目标，使其迷惑5秒。这是阻止一大群小怪施法的绝佳方式，尤其是当该施法免疫常规打断时。

[[spell:221562]] 是你的单体眩晕技能，持续5秒。在我们的天赋配置中不是非常常见的选择，但它仍然是一个有用的群体控制工具。

[[spell:49576]] 既可用于帮助聚集小怪，也可用于打断施法。请记住，你需要将小怪拉动一定距离才能真正打断它，这样你就不会在小怪已经在你身上时使用 [[spell:49576]]。

[[spell:49576]] 值得注意的也是防御技能。配合 [[spell:454822]]，它能对你对其使用的任何目标提供6%的伤害减免。在你为首领战或小首领减免伤害时很有用。

[[spell:279302]] 眩晕命中的所有目标3秒。它不常被用作直接的群体控制工具，只是一个能造成大量爆发AOE伤害的法术所带来的不错的“额外”效果。

### 其他功能

3.3.

#### 其他功能

[[spell:61999]] 是一个战斗复活技能，你可以用它让死去的队友复活，即使在战斗中也可以！

[[spell:207167]]、[[spell:45524]]、[[spell:196770]] 和搭配 [[spell:273952]] 的 [[spell:43265]] 都能降低命中敌人的移动速度，让我们可以帮助任何想要风筝小怪的坦克。

[[spell:111673]] 让你可以在大秘境中控制一个亡灵敌人。这主要是一个群体控制工具，让你可以暂时控制并随后释放一个特别棘手的小怪。它也可以提供造成更多伤害的机会，因为你的常规 [[spell:46585]] 效果甚微。请记住，当你正在控制敌方小怪时，不能使用 [[spell:46585]]。以下是一个在你需要重新控制小怪时有用的宏（该法术仅持续2分钟）

#### 控制亡灵

```wow-macro
#showtooltip 控制亡灵
/target pet
/script PetDismiss()
/cast 控制亡灵
```

1.

### 应对词缀

本指南主要包含针对大秘境的死亡骑士专属技巧。如果你想了解每个地下城或大秘境的通用指南，请查看下方的专用页面。

[至暗之夜 大秘境 第2赛季](<https://www.icy-veins.com/wow/midnight-mythic-season-2-guide>)

至暗之夜 第2赛季提供了四个独特的词缀，我们可以根据自身技能组合以不同程度应对它们。它们每周轮换，同一时间只有一个处于激活状态。它们也是唯一处于激活状态且需要你专门处理的词缀。

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将出现三波球体，需要被打断或阻止。[[spell:207167]] 是你处理这些球体最有效的工具，[[spell:47528]] 和 [[spell:49576]] 负责处理任何残留的球体。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：一个 虚空大使 小怪将会出现，需要被设为焦点目标并打断。只需切换到新的小怪并集火将其击杀。如果你知道它即将出现，考虑保留你的冷却技能以便快速处理它。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：球体将出现在玩家周围并绕着他们旋转。你有15秒时间吸收所有这些球体来增益你的团队。使用你的位移技能如 [[spell:212552]] 和 [[spell:343257]] 来快速吸收它们。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有小队成员都将受到治疗吸收效果的影响。你可以用 [[spell:48707]] 预先免疫。然而，这意味着你将错过护盾移除时获得的增益。或者，通过使用 [[spell:49998]] 和治疗药水/治疗石（如果需要）来帮助你的治疗者移除护盾。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月14日：** 针对12.1补丁进行了审查。
- **2026年8月10日：** 已用新的12.1构筑进行更新。
- **2026年6月20日：** 大秘境改为推荐使用双持作为武器。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 为12.0.5更新了构筑，推荐使用破咒者。
- **2026年3月16日：** 针对 至暗之夜 第1赛季更新，新增天赋搭配和词缀建议。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已将气息构筑更新为推荐构筑。
- **2026年1月19日：** 针对 至暗之夜 更新，新增天赋搭配。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月31日：** 改为推荐死亡使者作为推荐流派。
- **2025 年 8 月 25 日：** 英雄天赋方面的小幅说明澄清。
- **2025年8月4日：** 针对11.2版本更新，添加了新流派。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 添加了大量地下城技巧。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季更新了天赋。
- **2024年3月22日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 添加了关于镰刀使用的说明。
- **2023年12月15日：** 更新了湮灭的杀戮机器优先级。
- **2023年12月15日：** 明确了凋零寒冬在群体伤害中冰霜之柱内的位置。
- **2023年11月6日：** 为10.2版本进行了更新。大幅扩展了循环内容。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1版本更新了天赋，并移除了雷鸣词缀的提及。
- **2023年3月20日：** 为10.0.7更新了天赋构筑。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页面上，你将找到许多有用的宏和插件，以便在《魔兽世界》12.1.5补丁中玩你的 冰霜 死亡骑士 时让生活更轻松。

1.

### 最佳宏

1.1.

#### 死亡骑士通用宏

1.1.1.

##### 复活盟友

#### 复活盟友

```wow-macro
#showtooltip 复活盟友
/cast [@mouseover,help][@target]复活盟友
```

如果你的鼠标悬停目标是一名友方玩家，此宏会对其施放[[spell:61999]]。否则，它会对你的当前目标施放复活盟友。

1.1.2.

##### 心灵冰冻

#### 心灵冰冻

```wow-macro
#showtooltip 心灵冰冻
/cast [@focus,harm,nodead][] 心灵冰冻
```

此宏允许你打断你的焦点目标（如果你有的话），如果没有，则简单地打断你的当前目标。

1.2.

#### 冰霜 死亡骑士专属宏

1.2.1.

##### 冰霜之柱触发宏

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 可以使用一个精简的爆发宏来减少按键次数。在起手式中，它是在 [[spell:439843]] 和 [[spell:279302]] 之间脱离GCD按下的。

#### 死亡使者 起手式

```wow-macro
#showtooltip 冰霜之柱
/use trinket
/cast 冰霜之柱
/cast 亡者复生
/cast 冰龙吐息
```

对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士，我们面临更复杂的情况，因为我们理想情况下希望根据所处情况使用不同的占GCD技能。有 [[spell:279302]] 时我们可以直接使用它，否则我们需要按下适合当前情况的按键。“大爆发”宏如下：

#### 死亡使者 起手式

```wow-macro
#showtooltip 冰霜之柱
/use trinket
/cast 冰霜之柱
/cast 亡者复生
/cast 冰龙吐息
/cast 冰霜巨龙之怒
```

对于非爆发阶段，我们为[[spell:49143]]、[[spell:194913]]、[[spell:49020]]、[[spell:207230]]和[[spell:49184]]分别设置了宏。选择按哪个宏完全等同于遵循你的标准优先级（霜之哀伤可用时使用，拥有霜刃/[[spell:51714]]5层时使用冰霜打击，单目标时杀戮机器触发下使用湮灭等）。如果你想完全优化，你的每个标准技能也都有一个柱子宏版本，结构如下：

#### 通用冰霜之柱宏

```wow-macro
#showtooltip 冰霜之柱
/use trinket
/cast 冰霜之柱
/cast 亡者复生
/cast ability
```

具体要使用的宏如下所写。

#### 冰霜 打击冰霜之柱

```wow-macro
#showtooltip 冰霜之柱
/use trinket
/cast 冰霜之柱
/cast 亡者复生
/cast 冰霜打击
```

#### 冰川突进冰霜之柱

```wow-macro
#showtooltip 冰霜之柱
/use trinket
/cast 冰霜之柱
/cast 亡者复生
/cast 冰川突进
```

#### 湮灭冰霜之柱

```wow-macro
#showtooltip 冰霜之柱
/use trinket
/cast 冰霜之柱
/cast 亡者复生
/cast 湮灭
```

#### 冰霜之镰冰霜之柱

```wow-macro
#showtooltip 冰霜之柱
/use trinket
/cast 冰霜之柱
/cast 亡者复生
/cast 冰霜之镰
```

#### 凛风冲击冰霜之柱

```wow-macro
#showtooltip 冰霜之柱
/use trinket
/cast 冰霜之柱
/cast 亡者复生
/cast 凛风冲击
```

1.2.2.

##### 死亡之握 鼠标指向宏

#### 死亡之握 鼠标指向

```wow-macro
#showtooltip 死亡之握
/cast [target=mouseover,exists] 死亡之握; 死亡之握
```

此宏将对你的鼠标指向目标施放 [[spell:49576]]。

#### 反魔法领域 光标

```wow-macro
#showtooltip 反魔法领域
/cast [@cursor] 反魔法领域
```

此宏会在你的光标位置立即施放 [[spell:51052]]。通过连按此宏按钮，可以更快速地激活领域，非常有用。它通常也有助于有效放置它。

#### 心灵冰冻 鼠标指向

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 心灵冰冻
```

此宏允许你使用鼠标指向进行打断，避免不得不切换目标来打断。

#### 焦点 鼠标指向

```wow-macro
/focus [@mouseover]
```

此宏支持使用鼠标指向快速设置焦点目标。

1.2.3.

##### 控制亡灵

在地下城中控制亡灵生物是增加少量额外伤害的好方法，也可以在你想要的任何时间内控制特定的小怪。它需要每5分钟重新控制一次，而这个宏正是为此而生！它会选中你的宠物，解散它，然后立即再次控制它。

#### 控制亡灵

```wow-macro
#showtooltip 控制亡灵
/target pet
/script PetDismiss()
/cast 控制亡灵
```

1.

### 最佳插件

2.1.

#### 死亡骑士通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.5.

#### 冰霜 死亡骑士专属插件

目前，我们认为你不需要任何额外的插件来充分发挥你专精的潜力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月24日：** 更新了冰柱宏。
- **2026年4月20日：** 已针对12.0.5进行审阅。
- **2026年3月16日：** 为至暗之夜第1赛季更新，添加了关于在冰柱宏中使用ERW的说明。
- **2026年2月26日：** 针对 至暗之夜 更新了宏命令，新增复制功能。
- **2026年2月10日：** 针对 至暗之夜 预补丁更新，对骑手的宏命令做了一些说明。
- **2025年11月30日：** 已针对11.2.7版本审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月12日：** 简化并澄清了冰封之柱宏命令。
- **2025年8月7日：** 详细说明了宏命令。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 更新了起手式宏命令以更准确地体现冰冷之息 -> 宏命令的起手式。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月26日：** 更新了湮灭宏命令以提升清晰度。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月22日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年12月1日：** 明确了不使用湮灭宏时的损失。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1版本进行了审阅和更新。强调了湮灭宏并非必需。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
