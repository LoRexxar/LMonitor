## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Archimtiros。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-guide>)
- [练级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)

## 专精概览

欢迎来到我们的武器战士攻略，适用于《魔兽世界》12.1.5补丁。在这里，你将学习如何在团队副本和史诗钥石地下城中扮演一名武器战士：从最基础的内容到最大化你的伤害输出。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

武器史诗钥石资源

[全新！顶级武器天赋配装](<https://raider.io/specs/arms-warrior/talents>)

[顶级武器史诗钥石玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warrior/arms>)

[武器史诗钥石热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warrior--arms>)

[热门武器队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warrior--arms>)

1.

### 武器战士概述

武器战士是非常直接的伤害输出职业，围绕着围绕[[spell:167105]]展开的频繁短冷却爆发伤害窗口。他们最大的优势在于多样的工具箱，提供单体、多目标顺劈甚至有限的物理伤害免疫能力，不过缺点是多目标爆发有限、自我续航平庸，以及近战范围固有的其他限制。

强势

武器战士拥有全面的工具箱，具备多样的单体、双目标和强力多目标能力。他们在至暗之夜第2赛季中相当强势，尤其是在史诗钥石地下城中。

可用

武器战士在团队副本中表现出色，尤其是在包含次要目标或间歇性小怪群的战斗中。剧毒深渊的倒数第二个首领战尤其适合武器的双目标能力，使该专精成为新团本的热门选择。

即使在他们并不擅长的战斗中，[[spell:6673]]也确保大多数团队副本队伍中至少会带一名战士。

卓越

武器战士在史诗钥石地下城中极其强大，得益于强力的优先级伤害、适度的单体集中输出和持续的多目标伤害。虽然以物理伤害输出为主的队伍配置相当受限，但这很可能是武器在几个版本以来最接近主流的时刻。

众多次要效果

战士在功能性方面历来非常艰难，拥有若干在现代绝大多数内容中完全不必要的效果。[[spell:384100]]、[[spell:64382]]、[[spell:384110]]、[[spell:376079]]和[[spell:12323]]看似都是有用的效果，但它们的机制在现代内容中出现频率太低，以至于很少甚至从未被使用。

不过，战士在至暗之夜中获得了一些改进。[[spell:97462]]在小型队伍内容中得到了增强，不再需要太担心递减效应意味着昏迷可以更自由地使用，而且新增的远程沉默也提供了特定情况下的价值。

强大的先手生存能力

武器战士拥有高于平均水平的生存能力，通过若干短冷却的防御和治疗技能实现，这些技能可以独立使用来应对多种效果，也可以叠加使用以显著降低大型攻击的威胁。

[[spell:23920]]可以直接免疫多种效果，[[spell:386208]]可能是整个游戏中最可靠的减伤来源。但需要注意的是，战士的生存能力本质上非常依赖先手预判。[[spell:118038]]值得一提，因为它能招架大部分近战攻击，有时可以用它短暂承担坦克职责。

这要求玩家具备敏锐的意识，对于那些拥有真正免疫或免死技能的职业本可以承受的失误，几乎没有恢复的余地。

爆发性移动技能按冷却使用

在[[spell:6544]]、[[spell:100]]和[[spell:3411]]之间，战士拥有非常好的机动性，只要存在合适的路径或目标。

1.

### 武器战士在至暗之夜

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5补丁包含两项新的终局内容：基斯伊克斯的解放团队副本战斗，以及扩展的巨型探窟——金多詹迷宫！这两项活动都包含新的挑战、成就和奖励，你可以在我们的专属页面了解更多。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5补丁职业改动

[12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>) 作为至暗之夜第2赛季进程的延续，围绕乌拉特克和阿曼尼的故事最终带来了一个全新的单首领团队副本、升级装备等级的途径、多种追赶装备来源，以及无限量的雾玉用于升级装备。请务必查看我们的补丁中心，了解补丁12.1.5的所有新增或更新信息。

2.3.

#### 职业改动

12.1.5补丁中没有武器战士的改动，但我们的 [装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>) 已根据基斯伊克斯的解放团队副本的新建议以及使用[[item:280562]]的指南进行了更新。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_cleave.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 补丁12.1职业改动

第2赛季中武器战士进行了大量改动，旨在重新平衡和简化游戏玩法，将粉碎的可变冷却时间标准化以更好地与巨神兵猛击保持一致，使破敌者成为更强的单体技能，并降低对顺劈的重视，转而让压制和收割风暴提供更多伤害。

[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**战士**

<em>开发者说明：撕裂是一个标志性的核心战士技能，与每个专精有着不同的关系。我们在至暗之夜中对撕裂的处理方式没有达到预期，因此我们正在改变每个专精在乌拉特克诅咒中施加和与撕裂互动的方式。</em>

- **职业**
  
  
  
  
  - [[spell:772]]技能现在为武器独有，已恢复为单体技能，其怒气消耗降低至10。如果战士学会了撕裂，顺劈将会对所有目标施加撕裂。
  - [[spell:6343]]在学会后不再自动施加撕裂。
  - [[spell:1271948]]有了新的图标。
- **英雄天赋**
  
  
  
  
  <em>开发者说明：崩摧的可变冷却时间被证明弊大于利，令人沮丧，因此我们正在将其调整为与 巨神兵 猛击紧密配合，使 武器 巨神兵 战士能够协调使用，以造成最大破坏。</em>
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵：[[spell:429644]]已更新——无视苦痛每次使用所吸收的伤害提高30%（原为20%）。
  - [[spell:429636]]已更新——被崩摧伤害的敌人在10秒内对你造成的伤害降低20%（原为10%），并且不再降低崩摧的冷却时间。
  - [[spell:436358]]冷却时间缩短至30秒（原为45秒）。
  - [[spell:429641]]提高猛攻和斩杀的伤害（原为仅提高猛攻）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者：[[spell:444767]]已更新——触发屠戮者打击的几率提高至25%（原为15%）。
  - [[item:212361]]使你的下一个猛攻获得20%的伤害加成和20%的暴击伤害加成（原均为10%）。
- **武器**
  
  
  
  
  <em>开发者说明：武器的范围伤害构成主要依赖顺劈斩，我们希望将伤害分布到更多技能上。我们正在将无畏之刃更新为纯范围伤害，这将使我们能够仅为范围伤害来调整它。这应该有助于武器的范围伤害循环不再如此依赖顺劈斩，并帮助屠戮者在范围伤害方面获得更好的选择。</em>
  
  
  
  
  - [[spell:1261051]]已重新设计——巨神兵 猛击立即提供1次突然死亡的使用次数。
  - 碎裂风暴伤害提高50%。
  - 碎裂风暴在激活时不再提高顺劈斩和旋风斩的伤害。碎裂风暴现在会使其伤害到的所有敌人在12秒内受到你流血效果的伤害提高50%。
  - 碎裂风暴的持续时间不再受急速影响。
  - 放血已更新——你的技能对受割裂影响的目标的暴击几率提高5%。如果你学会了割裂，致死打击会对生命值低于35%的目标施加割裂。重伤持续时间延长33%。
  - 阔斧横扫已更新——巨神兵 猛击现在使用时提供6层横扫攻击。
  - 无畏之刃已更新——无畏之刃伤害提高100%，且不再伤害你的猛攻目标。
  - 近战自动攻击伤害提高100%。
  - 顺劈斩伤害降低10%。
  - 斩杀伤害降低15%。
  - 无视苦痛吸收量提高25%。
  - 横扫攻击现在会显示当前激活的横扫攻击充能次数。
  - 强力动量现在使横扫攻击的连锁伤害提高20%（原为25%）。
  - 至暗之夜第1赛季2件套效果现在使巨神兵 猛击的伤害提高3%（原为5%）。
  - 多个天赋在天赋树中的位置发生了变化。
  - 强化横扫攻击已被移除。

:::

### 至暗之夜改动概述

2.5.

#### 至暗之夜改动概述

虽然核心玩法保持不变，但武器战士在至暗之夜中经历了重大变化，对多个天赋进行了重做或完全移除并替换。以下是关于最具影响力的改动及其如何影响新资料片游戏体验的一般概述。

2.6.

#### 英雄天赋改动

每个英雄在90级前获得三个新天赋，尽管它们相当直接，对游戏风格没有重大变化。最显著的更新是屠戮者，[[spell:444775]]现在对每个技能施放都有更新后的触发几率，并可从[[spell:29725]]触发。

2.7.

#### 输出循环变化

除了一些新的天赋效果外，总体玩法与《地心之战》非常相似。

- 怒气生成量已降低，这可能导致更多的空闲时间，并更加需要队伍中有萨满祭司来提供[[spell:462854]]。
- 武器的精通已更改，不再与重伤互动，只是在使用双手武器时提高伤害。
- [[spell:184783]]现在对所有循环技能都有固定的触发几率，包括[[spell:29725]]。这导致猛攻的触发次数略少，但总体上更加稳定。
- 移除[[spell:200875]]简化了斩杀条件，不再需要任何复杂的追踪或延迟使用突然死亡。
- [[spell:260708]]现在使用充能系统，在使用无法被顺劈的技能时减少了浪费。

2.8.

#### 巅峰天赋：战争大师

一个新的四点专精特定巅峰天赋节点现已可用。[[spell:1269314]]是一个主动触发技能，用英勇打击替换猛击，施加一个强大的伤害增益效果。虽然它在很大程度上取代了猛击的常规施放，但它也会周期性地穿插在单体斩杀阶段中，不过该技能在多目标时始终会通过[[spell:202316]]自动使用。

- 第一点是一个触发效果，使[[spell:1269383]]替换猛击，赋予其更高的优先级，并触发一个小的护甲穿透增益效果。虽然这个增益效果可以叠加，但每层都有各自的持续时间，导致增益效果不断叠加和衰减，使其很容易被动处理并忽略。
- 第二点和第三点进一步增强战争大师增益效果，但对循环没有影响，因为所有这些技能继续以相同的方式使用。
- 最后一点使英勇打击施加一个单独的增益效果，提高巨神兵 猛击的强度，考虑到该技能如此高的覆盖率，这可能相当强大。

2.9.

#### 生存能力改动

战士在自我治疗和生存能力方面有了一些小的改进，不过移除WeakAura追踪使[[spell:23920]]更难有效使用。

- [[spell:1271926]]提高受到的治疗量。
- [[spell:29838]]现在在生命值低于35%时治疗量翻倍。
- [[spell:1280961]]显著提高了[[spell:386208]]的价值，使其成为一个非常强大的小型冷却技能。

2.10.

#### 功能性改动

虽然没有重大的新效果或技能，但战士在新资料片中在团队功能性方面有了一些改进。

- [[spell:97462]]现在在小队内容中提供更大的加成。
- 在PvE内容中，敌人在多次眩晕后不再变得免疫，使它们可以更自由地使用。
- [[spell:1271948]]现在使[[spell:384110]]充当远程沉默技能，尽管冷却时间较长。
- [[spell:12323]]现在为盟友提供短暂的移动速度增益，这对对抗机制并不特别重要，但对减少拉怪之间的空闲时间很有用。

1.

### 武器 战士基础玩法

武器 战士是一个非常直接且相对简单的专精，几乎通过自动攻击被动产生所有资源，同时用各种主动技能消耗它们。预测这种资源流动并追踪重要的技能冷却时间非常重要，以确保你既不会因怒气不足而无法在冷却完毕时使用[[spell:12294]]，也不会使[[spell:7384]]的充能溢出。

武器 战士的玩法最好用下面的三个关键概念来描述。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_charge.jpg>) **避免空闲时间**
  
  
  
  
  武器的大部分怒气来自自动攻击，因此减少追逐、跑开机制或以其他方式未能攻击目标的时间对于最大化表现至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_savageblow.jpg>) **保持技能冷却**
  
  
  
  
  武器每次消耗少量资源，但技能的冷却时间决定了循环的节奏。保持[[spell:167105]]、[[spell:12294]]和[[spell:7384]]的冷却运转对于维持高伤害至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_racial_bloodrage.jpg>) **避免浪费怒气**
  
  
  
  
  与大多数资源不同，怒气从零开始并在脱离战斗时衰减。有效且高效地使用它将有助于维持循环并消除等待更多资源的空闲时间，无论是在战斗中还是通过减少从一场战斗到另一场战斗的移动时间。

1.

### 如何为武器 战士获取装备

虽然我们总是建议你自己进行模拟以获得理想结果，但我们确实提供了专门的武器装备页面。我们目前涵盖了第2季装备的推荐，以便在至暗之夜终局内容发布时有一个良好的开始。在你获得一些装备后，你需要合适的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 更新了12.1.5补丁的装备推荐，并添加了关于毒石的新章节。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 更新了推荐的武器附魔和药水描述，以说明特殊情况下的属性问题。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月25日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 添加了额外的屠戮者天赋配置。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 更新了12.1补丁的升级天赋配置。
- **2026年8月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 更新了12.1补丁的所有装备推荐。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 更新了12.1补丁的宝石、武器附魔和治疗药水。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 更新了12.1补丁的配置推荐。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 更新了12.1补丁的配置推荐。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 更新了12.1补丁的职业改动。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 在12.0.7补丁中添加了孢化装备。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 在12.0.7补丁中添加了万卷之典能力。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月27日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 修正了错误的天赋字符串。
- **2026年4月23日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 更新了备选大秘境配置和多个配置描述。
- **2026年4月22日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 添加了多目标团本天赋配置。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月6日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 为鲁莽药水添加了免责声明。
- **2026年4月6日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 调整了战斗怒吼的描述。
- **2026年4月6日（本页）：** 更新了更新日志。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 添加了80级起始配置。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 添加了关于使用纹章升级物品的章节。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（本页）：** 为至暗之夜上线进行了更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 更新了12.0.1补丁的升级天赋配置。
- **2026年2月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 更新了12.0.1补丁的配置。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为11.2.7补丁添加了新的常见问题解答部分。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为11.2.7补丁添加了常见问题解答部分。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁添加了新的优劣势组件。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 添加了迪纳尔，更新了推荐饰品，并为涡轮增压提高了物品等级。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 添加了11.2.5补丁的改动。
- **2025年9月6日（本页）：** 添加了热修复说明。
- **2025年8月25日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 新增了临时强化，并扩充了关于武器附魔的说明。
- **2025 年 8 月 10 日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 添加了突然死亡辅助WeakAura。
- **2025 年 8 月 10 日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 澄清了关于天赋选择的解释。
- **2025 年 8 月 10 日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已根据第3赛季的循环变化进行更新。
- **2025 年 8 月 10 日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 调整了属性优先级，使其更好地与其他页面保持一致。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月20日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 热修后，将泰坦神装DISC腰带的推荐从充能箭矢改为致命连锁。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 在11.1.7补丁中添加了复苏的治疗内容。
- **2025年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为11.1.7补丁添加了泰坦神装DISC腰带。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为11.1.7补丁添加了战斗助手部分。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 为11.1.7补丁添加了战斗助手部分。
- **2025年6月15日（本页）：** 添加了11.1.7补丁的改动。
- **2025年5月12日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 更新了装备列表，添加了代币购买优先级。
- **2025年5月12日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 对腐蚀部分进行了小幅更新，将回响虚空作为备选方案。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 添加了11.1.5补丁的帮会代币推荐。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 添加了11.1.5补丁的腐蚀推荐。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 为加里维克斯添加了碎击投掷提示。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 将循环拆分为可切换的图片框架。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 添加了11.1.5补丁的职业改动。
- **2025年3月17日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 修复了失效的塞尔西的王冠链接，并在嵌入内容中添加了宝石。
- **2025年3月17日（[解放安德迈页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 更多提示、天赋调整以及加里维克斯相关信息。
- **2025年3月2日（[解放安德迈页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了团队副本提示和天赋配置。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月16日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 更新了塞尔西的王冠，以计入物品等级提升的热修。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 添加了塞尔西的王冠，并针对11.0.7补丁进行了验证。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 标记了推荐配置，并针对11.0.7补丁进行了验证。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 标记了推荐的天赋配置，并针对11.0.7补丁进行了更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 简化了循环，并针对11.0.7补丁验证了信息。
- **2024年12月15日（本页）：** 更新了11.0.7补丁中的改动。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 添加了一个简要部分，详细介绍了即将到来的时光漫游和周年庆团队副本饰品。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了丝绸宝库的各种提示和天赋推荐。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 更新了地下城词缀推荐。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 添加了11.0.5补丁改动的概述。
- **2024年10月3日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** 为丝绸宝库添加了更多提示和新的天赋推荐。
- **2024年9月23日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** 安苏雷克女王的提示和建议。
- **2024年9月23日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 对单体目标和斩杀循环进行了小幅更新。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 为地心之战第1赛季的上线进行了更新。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为地心之战第1赛季的上线进行了更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** 页面已创建。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 为地心之战第1赛季的上线进行了更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 关于切换选项的补充说明。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为地心之战第1赛季的上线进行了更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月26日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 新增了地下城（Delve）天赋配置，并进行了少量天赋更新。
- **2024年8月22日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 修复了巨神兵切换选项的错误。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（本页）：** 为地心之战季前赛的上线进行了更新。
- **2024年7月26日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 更新了主手附魔。
- **2024年7月26日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 在趁胜追击增强后，说明了急速价值的下降。
- **2024年7月26日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 对碎颅者进行了小幅说明。
- **2024年7月26日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 小幅配置更新。
- **2024年7月26日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 小幅更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/arms-warrior-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（本页面）：** 为地心之战前夕补丁进行了更新。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/arms-warrior-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月12日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 更新了天赋配置和法术优先级。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 更新了第4赛季的新装备和铸币推荐。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为第4赛季进行了更新。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 为第4赛季更新了循环。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 对简介进行了小幅更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 更新了第4赛季的新配置。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 更新了第4赛季的新天赋和循环推荐。
- **2024年4月22日（本页）：** 更新了第4赛季的新套装改动。
- **2024年3月25日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 对升级天赋树进行了小幅调整，并为10.2.6补丁进行了更新。
- **2024年3月19日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 移除了旧的WeakAuras，添加了新的，并为10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 扩展了专业制造推荐，并为10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 对推荐天赋进行了小幅更新，并为10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 扩展了推荐天赋更新，并为10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 针对10.2.6补丁进行了审查。
- **2024年2月15日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年2月15日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年2月15日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年2月15日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年1月16日（本页）：** 修正了指向狂怒页面的错误链接。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2024年1月14日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 将菲莱克巨剑添加到整体毕业列表中（祝你好运）。
- **2024年1月14日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 添加了一个强调正确使用菲莱克巨剑的部分。
- **2024年1月14日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 对配置选择工具中推荐天赋的说明进行了小幅更新。
- **2024年1月14日（本页）：** 10.2.5补丁改动概述。
- **2023年11月8日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 更新了新的装备套装，以计入孢子披风的削弱。
- **2023年11月8日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 修正了在斩杀循环中隐藏低优先级填充技能的错误。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为10.2补丁和第3赛季进行了更新。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 为10.2补丁和第3赛季进行了更新。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为第3赛季做准备，更新了T31配置和循环。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为10.2补丁和第3赛季套装更新了天赋配置。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 已为10.1.7版本审核。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已为10.1.7版本审核。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为10.1.7版本审核。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已为10.1.7版本审核。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已为10.1.7版本审核。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已为10.1.7版本审核。
- **2023年9月4日（本页）：** 已为10.1.7版本审核。
- **2023年7月12日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 小幅格式更新。
- **2023年7月12日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 小幅格式更新。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为10.1.5补丁进行了更新，以包含永恒黎明的装备。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 为10.1.5补丁进行了更新，包括碎颅者的备选配置。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为10.1.5补丁进行了小幅更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（本页）：** 更新了10.1.5补丁无职业改动的信息。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 为10.1补丁进行了审查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 更新了玛瑙指环的宝石推荐。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 更新了玛瑙指环的宝石推荐。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为10.1补丁进行了审查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 为10.1补丁进行了审查。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.7补丁进行了更新，改进了默认复选框。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 为10.1补丁进行了审查。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 为10.1补丁进行了审查。
- **2023年5月1日（本页）：** 已为10.0.7补丁更新。
- **2023年4月4日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 切换到新的按等级天赋计算器格式。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/arms-warrior-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 更新了10.0.7补丁的玛瑙指环信息。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 更新了10.0.7补丁的玛瑙指环信息。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年2月27日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 修正了剑刃风暴的错误命名。
- **2023年2月15日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 更新了升级配置和按等级的天赋选择。
- **2023年2月2日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 移除了错误的狂怒引用。
- **2023年2月2日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 更新了剑刃风暴天赋配置。
- **2023年2月2日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 更新了循环工具。
- **2023年2月2日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已更新天赋构筑。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 10.0.5补丁已更新构筑。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 10.0.5补丁已更新多个构筑。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 天赋构筑已更新至10.0.5补丁。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 修复天赋选择器的格式。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年11月18日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 更新战斗热忱的使用说明和描述。
- **2022年11月18日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 更新战斗热忱的使用说明和描述。
- **2022年11月18日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 更新战斗热忱的使用说明和描述。
- **2022年11月9日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 修正了压制在输出循环中的位置。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/arms-warrior-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/arms-warrior-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/arms-warrior-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/arms-warrior-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[WeakAuras页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-weak-auras>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/arms-warrior-patch-9-2-changes-analysis>)):** 本页已审核并批准用于9.2补丁。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/arms-warrior-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/arms-warrior-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/arms-warrior-patch-9-1-changes-analysis>)):** 移除了PTR相关内容。
- **2021年5月19日（[9.1 补丁分析](<https://www.icy-veins.com/wow/arms-warrior-patch-9-1-changes-analysis>)):** 使用9.1补丁的初步信息创建了本页。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月29日（[永恒宫殿页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-the-eternal-palace-raid-guide>)):** 增加了更多技巧，不再推荐世界之魂共鸣。
- **2019年7月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-the-eternal-palace-raid-guide>)):** 增加了更多技巧，尤其是针对艾萨拉的；更改了数个精华推荐。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月5日（[风暴熔渣页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-crucible-of-storms-raid-guide>)):** 更新了恩佐斯的天赋。
- **2019年5月9日（[风暴熔渣页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-crucible-of-storms-raid-guide>)):** 增加了额外的史诗难度技巧。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年3月12日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了吉安娜的技巧。
- **2019年1月22日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 增加了新的技巧。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 指南已创建。
- **2019年1月18日（[奥杜尔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** 已更新至第2赛季。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** 已审核并更新至8.1补丁。
- **2018年9月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** 已更新至奥迪尔开放。
- **2018年8月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-uldir-raid-guide>)):** 已添加页面（目前为空）。

显示更多

显示更少

:::

## 练级

在本页中，您将找到我们的逐级武器战士练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[战士练级指南](<https://www.icy-veins.com/wow/warrior-leveling-guide>).

1.

### 武器战士在至暗之夜中的练级指南

武器战士在练级过程中非常简单直接，一开始只有[[spell:260708]]，直到大约30级才会获得更多有用的多目标技能。

过了那个阶段，战士开始变得相当强力，经常将数个怪物拉到一起无畏地将其顺劈砍倒，这要归功于[[spell:118038]]减免伤害以及[[spell:34428]]回血。通过轮换多个不同的冷却技能，武器战士最终可以一波接一波地连续拉怪，几乎没有停顿。

只要可能，始终用[[spell:100]]发起战斗，需要时使用[[spell:57755]]或[[spell:6544]]拉更多的怪。面对多个目标时，如果它们预计能存活足够长的时间让流血效果跳完，就使用[[spell:260708]]、[[spell:845]]、[[spell:7384]]和[[spell:772]]。

在这些技能之间，或者当只剩下一只或两只怪时，使用[[spell:12294]]和[[spell:163201]]击杀优先目标。像[[spell:167105]]和[[spell:227847]]这样的冷却技能可以随意使用，但通常并不需要。所以尽量把它们留给更大的怪群或更硬的目标。

[[spell:1231418]]技能可以在战斗之间快速恢复生命值，无需携带等级对应的食物，因为它总是恢复最大生命值的50%。

1.1.

#### 升级装备选择

练级时，装备物品等级最高的装备通常是理想的。这一规则的主要例外是一些具有两项副属性而非仅一项的饰品和戒指或项链。

使用传家宝物品时，我们推荐使用带有暴击和急速属性的传家宝，因为它们会在练级期间略微改善怒气循环。

1.2.

#### 至暗之夜升级实用消耗品

在每个新资料片开始时，每个人心中最关心的事情就是如何达到最高等级。对于至暗之夜，最高等级是90级。有各种物品可以提升你的练级速度和效率，让你充分利用游戏时间。

- [[item:132516]]——巨大的移动速度提升，在坐骑无法使用时也能生效，且比地面坐骑快得多。
- [[item:109076]]——让你从悬崖边滑翔出去，快速覆盖很远的距离。
- [[item:172063]]——在你击杀敌人时给你一个速度增益。
- [[item:168412]]——别忘了这件坐骑装备，它能让你的坐骑在地面上更快。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 武器至暗之夜练级构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzMzYGAAAghpBzYmZbZmZmZYYmBAAAAwYzMwEAbmxwCMwMsRjBLAzgZbGmtZ2GMzAAmZYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzMzYGAAAghpBzYmZbZmZmZYYmBAAAAwYzMwEAbmxwCMwMsRjBLAzgZbGmtZ2GMzAAmZYA"
}
```
:::

:::details 来源计算器编码
```
#HB-DJPIBlFOakzqYEFJJNZw1cu0EAYECCED7TB-CDFBAEGQYA78Yx1NJMcpSRBK7ryTKlI-AAAA-UMECOIM0wsAEZB-
```

:::

2.1.

#### 升级用战争模式天赋

以下PvP天赋推荐用于练级和单人/小型队伍的PvE内容。你可能会发现不同的PvP天赋更适合你的游戏风格。鼓励尝试！

1. [[spell:198817]]增加一个独立的非公共冷却增益，提升[[spell:12294]]的整体伤害。
2. [[spell:213915]]提升了[[spell:23920]]的价值，在冷却时间略微延长的同时提供更多的进攻和防御价值。
3. [[spell:206572]]提供额外的机动性，这在练级时总是有用的。
4.

### 升级循环

为了在练级和学习专精时保持简单，使用滑块选择你的等级，观察练级循环随着每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

1. **等级 2 起：**尽可能使用[[spell:100]]发起战斗。
2. **等级 10 起：**使用[[spell:260708]]让单体攻击也能命中第二个目标。
3. **等级 69 起：**对成群的敌人或单个强力目标使用[[spell:228920]]。
4. **等级 33 起：**当超过三个目标需要上Rend时使用[[spell:772]]，前提是它们能在大部分减益持续时间内存活。
5. **等级 5 起：**击杀敌人后使用[[spell:34428]]获得免费的伤害和治疗。
6. **等级 3–10：**如果仍然装备盾牌，使用[[spell:23922]]造成伤害。
7. **等级 25 起：**使用[[spell:167105]]对主要目标造成更高的伤害。
8. **等级 71 起：**冷却完毕时使用[[spell:436358]]进行高爆发的多目标伤害。
9. **等级 11 起：**作为主要伤害技能使用[[spell:12294]]。
10. **等级 10 起：**只要可能就使用[[spell:163201]]。
11. **等级 13–14：**作为免费填充技能使用[[spell:7384]]。
12. **等级 15 起：**作为免费填充技能使用[[spell:7384]]，并提升[[spell:12294]]或[[spell:845]]的伤害。
13. **等级 1–8：**使用[[spell:1464]]对单个目标造成伤害。
14. **等级 9–30：**对单个目标使用[[spell:1464]]造成伤害，或对多个目标使用[[spell:1680]]。
15. **等级 31 起：**对单个目标使用[[spell:1464]]造成伤害，或对多个目标使用[[spell:845]]。
16.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 更新了12.1补丁的升级天赋配置。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月2日：** 添加了80级起始配置。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 更新了12.0.1补丁的升级天赋配置。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 在11.1.7补丁中添加了复苏的治疗内容。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月12日：** 更新了天赋配置和法术优先级。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月25日：** 对升级天赋树进行了小幅调整，并为10.2.6补丁进行了更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月4日：** 切换到新的按等级天赋计算器格式。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月15日：** 更新了升级配置和按等级的天赋选择。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩武器战士，使用最简单的输出循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 武器战士基础

欢迎来到我们的简易模式页面！本部分面向刚接触游戏或职业的玩家，他们没有参与史诗难度团队副本的打算，只想了解该专精的简明玩法，而不需要最优玩法所需的大量优先级细节。

武器是一个简单直接的伤害输出职业，专注于重击和流血效果。虽然基础输出循环并不复杂，但天赋可以添加额外的攻击或替代技能以实现自定义，这也意味着需要学习更多的游戏风格。这里展示的构筑是一种简单而有效的游戏风格，适用于所有类型的游戏内容，旨在帮助新玩家学习武器的基础知识。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_charge.jpg>) **避免空闲时间**
  
  
  
  
  武器的大部分怒气来自自动攻击，因此减少追逐、跑开机制或以其他方式未能攻击目标的时间对于最大化表现至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_savageblow.jpg>) **保持技能冷却**
  
  
  
  
  武器每次消耗少量资源，但技能的冷却时间决定了循环的节奏。保持[[spell:167105]]、[[spell:12294]]和[[spell:7384]]的冷却运转对于维持高伤害至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_racial_bloodrage.jpg>) **避免浪费怒气**
  
  
  
  
  与大多数资源不同，怒气从零开始并在脱离战斗时衰减。有效且高效地使用它将有助于维持循环并消除等待更多资源的空闲时间，无论是在战斗中还是通过减少从一场战斗到另一场战斗的移动时间。

在第2赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者在初始练级之后通常是最佳的英雄专精，使其成为大多数内容中的首选。除了强大的优先目标伤害外，它还有一个优势，即在选择多目标天赋时几乎不会牺牲单体目标的性能。

1.

### 武器战士在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者单体目标天赋

2.1.

#### 武器战士新手单体目标天赋

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

单体目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者团队副本构筑通过[[spell:260708]]和[[spell:227847]]提供了令人惊讶的多目标能力，使其能够应对大多数有少量小怪的团队副本战斗。

2.2.

#### 灵活天赋

由于不需要控制技能，几乎所有理想的天赋都已被选取，因此在特定情况之外没有太多更换的必要：

- 任何时候有带护盾的目标时，可以选取[[spell:384110]]来替代[[spell:1271925]]或[[spell:12323]]。
- 只要积极使用防御姿态，[[spell:1280961]]就具有出色的防御潜力，尽管其进攻收益充其量只是平庸。
- 如果经常面对两个目标，将[[spell:1261048]]换成[[spell:1261049]]，将[[spell:845]]换成[[spell:1261050]]。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmZzMzMzgxMDAAAAgZWmZAhxyyALgBMDTgZwGYmx2YbglZWGgZGAMDDA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPThLPDIMWGFZlpxRWSSEAQBCCDz7DE-CDFGOQCISYceqqAFG20xTRBSy0E1nYE-AAAA-HIcg0AEQQhhCzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者地下城天赋

2.3.

#### 武器战士新手地下城天赋

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

大秘境 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者构筑通过[[spell:7384]]和[[spell:444775]]带来卓越的多目标伤害，同时几乎不牺牲单体目标伤害。

2.4.

#### 灵活天赋

虽然专精树相当固定，但职业树有很大的自定义空间：

- 任何时候有带护盾的目标时，可以选取[[spell:384110]]来替代[[spell:1271926]]。选取[[spell:1271948]]而非[[spell:1280961]]也可能是值得的，用一些防御收益换取一个远程打断。
- 只要积极使用防御姿态，[[spell:1280961]]就具有出色的防御潜力，尽管其进攻收益充其量只是平庸。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTgZwGYmhhBzyMbDwMDAmhBA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlnBEGLjiqsy04kkoEBAUggww8+AB-CDFGQCIASYceqqs4AHGu0IZaiqj3nIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 武器战士基础输出循环

2.5.

#### 新手武器战士DPS输出循环

下面概述的简化输出循环涵盖了使用我们推荐天赋的单体和多目标情况。虽然武器的游戏风格相对简单，但请记住，猛击仅用于消耗英勇打击触发，一旦斩杀可用。

- 只要目标多于一个就使用[[spell:260708]]。
- 当割裂效果剩余时间少于4秒时，使用[[spell:845]]或[[spell:772]]施放或刷新割裂减益效果。
- 只要敌人存活时间足够长以享受完整效果，就尽量卡冷却使用[[spell:107574]]。
- 卡冷却使用[[spell:167105]]，并尽可能与其他冷却技能对齐。
- 在巨神兵 Smash期间使用[[spell:227847]]。
- 面对多个目标时，卡冷却使用[[spell:845]]。
- 只要可用就使用[[spell:1269383]]。
- 只要可用就使用[[spell:163201]]。
- 卡冷却使用[[spell:12294]]。
- 卡冷却使用[[spell:7384]]。
- 当没有其他技能可用时，使用[[spell:163201]]或[[spell:1464]]。

所有流派都遵循同一原则，即消耗怒气来触发[[spell:184783]]，同时利用武器循环中的各种触发效果。请记住，大部分怒气是通过自动攻击产生的，因此确保对目标保持高时间占比的攻击对维持循环至关重要，但也需要注意不要过度消耗怒气。

2.5.1.

##### 巅峰天赋： ![Master of Warfare Icon](<https://static.icy-veins.com/images/wow/large_icons/misc_legionfall_warrior.jpg>) 战争大师

武器 战士的终极天赋[[spell:1269314]]是一个主动触发技能，它能提高猛击的价值并施加一个增伤增益效果。虽然它在很大程度上取代了猛击的常规施放，但也会定期穿插在单体斩杀阶段中使用，而在多目标环境中，该技能始终会通过[[spell:202316]]自动使用。

- 第一点是一个触发效果，使[[spell:1269383]]替换猛击，赋予其更高的优先级，并触发一个小的护甲穿透增益效果。虽然这个增益效果可以叠加，但每层都有各自的持续时间，导致增益效果不断叠加和衰减，使其很容易被动处理并忽略。
- 第二点和第三点进一步增强战争大师增益效果，但对循环没有影响，因为所有这些技能继续以相同的方式使用。
- 最后一点使英勇打击施加一个单独的增益效果，提高巨神兵 猛击的强度，考虑到该技能如此高的覆盖率，这可能相当强大。

2.5.2.

##### 第2赛季套装

新的至暗之夜第2赛季套装效果大幅增强了[[spell:1464]]和[[spell:1269383]]，同时也被动地增强了其他循环技能。面对多个目标时，猛击会由[[spell:202316]]自动施放，而在等待猛击或英勇打击可用时，套装层数会自行叠加，因此在大多数情况下该套装的运作相当被动。

- [[spell:1296643]] - 致死打击和斩杀的伤害提高10%，并且当你对目标施放猛击时，猛击还会对目标8码范围内的敌人造成（100%攻击强度）的伤害。超过5个目标时伤害降低。
- [[spell:1296644]] - 压制的伤害提高15%。致死打击和压制会使你的下一个猛击伤害提高20%，最多可叠加5次。

### 武器 战士防御技能

2.6.

#### 武器 战士的防御技能

武器战士拥有多个防御技能，可以单独使用或叠加使用以获得更强的伤害减免。虽然缺乏真正的免疫或假死技能，但这使他们能够非常出色地应对可预见的来袭伤害。

- [[spell:118038]]是主要的防御冷却技能，可以减少伤害并招架大部分正面近战攻击。它还可以与时机恰当的[[spell:355]]或[[spell:3411]]配合使用，为其他玩家减轻压力。
- [[spell:23920]]是一个非常强大的工具，不仅能减少受到的魔法伤害，还能偏转甚至完全反射法术。虽然并非所有法术都会被反射回去对攻击者造成伤害，但仅仅是偏转它们的施放就能显著减少伤害，甚至能彻底化解许多危险技能。
- [[spell:386208]]是游戏中最可靠的冷却技能之一，其冷却时间极短，仅为3秒，但相应的会降低造成的伤害。虽然这使其不太受欢迎，但明智地使用该技能可以显著提高生存能力。
- [[spell:190456]]不再消耗怒气，但现在冷却时间稍长，且占用全局冷却时间。在承受伤害前与其他防御冷却技能叠加使用效果极佳。
- [[spell:202168]]是一个冷却时间很短的强大即时治疗技能，击杀敌人时会重置冷却。这使其可以经常使用，是一个应该定期使用的重要应急手段。
- [[spell:29838]]、[[spell:382549]]和[[spell:383103]]是被动触发的额外治疗效果，无需进行微操管理。

### 武器 战士属性优先级

2.7.

#### 武器 战士的属性优先级

武器 战士的一般属性优先级如下所示。这只是一个大致的指导原则，专为不希望对自己的角色进行模拟的玩家设计。如果你正在模拟自己的角色，请完全忽略此属性优先级，并按照你的模拟结果进行！关于本页呈现内容的更多信息，请查看我们的主
[属性优先级页面](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>).

装备等级

暴击

急速

精通

全能

暴击的伤害加成超过两倍，并增加自动攻击产生的怒气，从而减少循环中的空档期。精通增加敌人受到的伤害，而急速压缩循环，提高自动攻击速度并减少技能施放之间的间隔。最后，全能是静态的伤害提升，同时也会将受到的伤害减少其一半的数值。

### 暴风雪战斗助手

2.8.

#### 武器 战士战斗助手

[战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>)，在11.1.7补丁中加入，由两个选项组成，旨在帮助玩家进行战斗循环和游戏。

第一个是辅助高亮，它会推荐玩家接下来应该使用的循环技能，以帮助他们学习如何更好地玩自己的专精。虽然不是完美的极限优化循环，但它完全可用，与更复杂的手动循环相比平均只损失约5%。然而，它不会尝试推荐进攻性冷却技能、防御技能、功能性技能或其他非全局冷却技能如[[spell:100]]，因此玩家必须注意自行使用这些技能。

第二个选项是单键助手，这是放置在动作栏上的一个新按钮，按下时会自动在循环中的每个技能之间轮换。它使用与辅助高亮相同的循环，虽然可用，但在全局冷却时间上额外施加了25%的惩罚，以防止它成为一个容易具有竞争力的选项。这导致大约20-25%的性能损失。因此，它仅推荐给全新的玩家、进行简单内容的玩家，或那些无法跟上常规游戏节奏的玩家。

在两种情况下，使用像[[spell:107574]]和[[spell:260708]]这样的冷却技能可以很简单地通过将它们写成宏绑定到单键助手或像[[spell:167105]]这样的常用技能上，不过玩家也可以选择继续手动使用它们，如循环部分所述。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月10日：** 调整了属性优先级，使其更好地与其他页面保持一致。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁添加了战斗助手部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 简化了循环，并针对11.0.7补丁验证了信息。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月26日：** 小幅更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 更新了第4赛季的新天赋和循环推荐。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了审查。
- **2023年1月24日：** 天赋构筑已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 更新战斗热忱的使用说明和描述。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面，你将了解在《魔兽世界》12.1.5补丁中你的武器 战士的最佳天赋。我们还为各种类型的活动（如团队副本或大秘境）提供默认天赋构建。如果你开启了战争模式进行游戏，我们也为你提供了PvP天赋信息。

1.

### 至暗之夜 武器 战士最佳天赋

武器在第2赛季的大秘境中迎来了它最强大的赛季之一，在特定的主流组合之外，它是较强的伤害输出者之一。武器不幸的是只在少数几个团队副本首领战中表现出色，但整体上仍然高于平均水平。

- **单体目标 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者在单体目标和大多数团队副本首领战中继续保持着显著的优势。
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者已成为多目标伤害输出的主要英雄天赋选择。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵仍然可以提供更高的多目标爆发能力，但在此过程中会损失更多的单体目标价值。

**快速开始导入代码：**

:::talents 武器单体目标 - 屠戮者
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmZzMzMzgxMDAAAAgZWmZAhxyyALgBMDTgZwGYmx2YbglZWGgZGAMDDA"
}
```
:::

:::talents 武器多目标 - 屠戮者
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZgJMW2GYBMgZYCZGsBmZsN2GYZmtBYmBAzwA"
}
```
:::

:::talents 武器地下城与地下堡 - 屠戮者
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTgZwGYmhhBzyMbDwMDAmhBA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

斩杀者

单体目标团队副本

推荐

团队副本多目标

推荐

大秘境与地下堡

推荐

巨神像

团队副本多目标

大秘境与地下堡

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者单体目标团队副本天赋

这个单体目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者团队副本构建还通过[[spell:260708]]和[[spell:227847]]提供了令人惊讶的多目标能力，使其能够应对大多数有少量小怪的团队副本首领战。

1.2.

#### 灵活天赋

由于不需要控制昏迷，几乎所有理想的天赋都已经被选中，因此除了特殊情况外，没有太多更换的必要：

- 任何时候有带护盾的目标时，可以选取[[spell:384110]]来替代[[spell:1271925]]或[[spell:12323]]。
- 只要积极使用防御姿态，[[spell:1280961]]就具有出色的防御潜力，尽管其进攻收益充其量只是平庸。
- 如果经常面对两个目标，将[[spell:1261048]]换成[[spell:1261049]]，将[[spell:845]]换成[[spell:1261050]]。

### 天赋方案 0-1

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者 武器 战士大秘境地下城天赋

地下城通常会鼓励混合使用范围伤害和单体目标天赋，尽管它们通常以小怪为主，单体目标首领只占总伤害输出的较小比例。

大秘境 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者构筑通过[[spell:7384]]和[[spell:444775]]带来卓越的多目标伤害，同时几乎不牺牲单体目标伤害。

1.4.

#### 灵活天赋

虽然专精树相当固定，但职业树有很大的自定义空间：

- [[spell:1244088]]和[[spell:382260]]对于更快地移动很有用，虽然两者都不是严格必需的，而[[spell:1271926]]和[[spell:29838]]增加的内容很少，总是可以舍弃。[[spell:382767]]是一个非常好的灵活天赋，因为武器很少能达到资源上限。
- 当有带护盾的小怪时，也可以选择[[spell:384110]]，或者与[[spell:1271948]]组合以制造一个远程打断，但这需要放弃[[spell:1280961]]带来的一些防御价值。
- 只要积极使用防御姿态，[[spell:1280961]]就具有出色的防御潜力，尽管其进攻收益充其量只是平庸。

### 天赋方案 0-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者 武器 战士大秘境地下城天赋

地下城通常会鼓励混合使用范围伤害和单体目标天赋，尽管它们通常以小怪为主，单体目标首领只占总伤害输出的较小比例。

大秘境 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者构筑通过[[spell:7384]]和[[spell:444775]]带来卓越的多目标伤害，同时几乎不牺牲单体目标伤害。

1.6.

#### 灵活天赋

虽然专精树相当固定，但职业树有很大的自定义空间：

- [[spell:1244088]]和[[spell:382260]]对于更快地移动很有用，虽然两者都不是严格必需的，而[[spell:1271926]]和[[spell:29838]]增加的内容很少，总是可以舍弃。[[spell:382767]]是一个非常好的灵活天赋，因为武器很少能达到资源上限。
- 当有带护盾的小怪时，也可以选择[[spell:384110]]，或者与[[spell:1271948]]组合以制造一个远程打断，但这需要放弃[[spell:1280961]]带来的一些防御价值。
- 只要积极使用防御姿态，[[spell:1280961]]就具有出色的防御潜力，尽管其进攻收益充其量只是平庸。

### 天赋方案 1-0

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵多目标团队副本天赋

这个多目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵团队副本构建通过[[spell:845]]和[[spell:436358]]提供了很高的多目标能力，使其能够在有大量或频繁小怪波次的团队副本首领战中维持伤害输出。

1.8.

#### 灵活天赋

由于不需要控制昏迷，几乎所有理想的天赋都已经被选中，因此除了特殊情况外，没有太多更换的必要：

- [[spell:1271925]]在大多数PvE内容中的用途有限，但可以根据需要替换[[spell:384110]]、[[spell:12323]]、[[spell:382260]]或[[spell:1244088]]。
- 只要积极使用防御姿态，[[spell:1280961]]就具有出色的防御潜力，尽管其进攻收益充其量只是平庸。

### 天赋方案 1-1

1.9.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵 武器 战士大秘境地下城天赋

地下城通常会鼓励混合使用范围伤害和单体目标天赋，尽管它们通常以小怪为主，单体目标首领只占总伤害输出的较小比例。

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵通过使用[[spell:845]]和[[spell:12294]]大幅缩短[[spell:436358]]的冷却时间来提供非常高的多目标伤害，尽管其单体目标首领伤害非常平庸，且[[spell:163201]]很少使用。

1.10.

#### 灵活天赋

虽然专精树相当固定，但职业树有很大的自定义空间：

- [[spell:1244088]]和[[spell:382260]]对于更快地移动很有用，可以轻松地与[[spell:1271926]]或[[spell:382767]]互换，因为武器很少能达到资源上限。
- [[spell:1271925]]在大多数PvE内容中的用途有限，但在少数相关的情况下可以与[[spell:5246]]或[[spell:12323]]互换。
- 只要积极使用防御姿态，[[spell:1280961]]就具有惊人的防御潜力，尽管其进攻性收益充其量只是平平。在多目标内容繁重的情况下，[[spell:382764]]通常是最佳的舍弃选择，不过这也需要选择[[spell:1243660]]而不是[[spell:1271948]]。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzMmZGAAAghphxYmZzMzMzgxMDAAAAgZWmZAhxyyALgBMDTgZwGYmx2YbglZWGgZGAMDDA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPThLPDIMWGFZlpxRWSSEAQBCCDz7DE-CDFGOQCISYceqqAFG20xTRBSy0E1nYE-AAAA-HIcg0AEQQhhCzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAAzMzsMzYmZGAAAghphxYmxyMzMzgxMDAAAAgZWmZgJMW2GYBMgZYCMD2AzM2GbDsMz2AMzAgZYA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPThLPDIMYEFZpxRWSKTEAQBCCDz7DE-CDFGOQCISYceqqsAHGu0IZaiqj3nIUE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTgZwGYmhhBzyMbDwMDAmhBA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlnBEGLjiqsy04kkoEBAUggww8+AB-CDFGQCIASYceqqs4AHGu0IZaiqj3nIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzwYGAAAghphZYmZzMzMzgxMDAAAAgZ2mZgJAWMjhNYgZYjGDWAzM2GbzwsNz2gZGAgZYA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPThLPDIKWGFZlpxRWSSEAQBCCDz7DE-CDFGQCIASYceqqs4AHG21T60E1nIUUG-AAAA-AcgUphYhBTgwwC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzMzYGAAAghphxYmZzMzMzYmxMDAAAAgxmZgJAWMjhNYgZYjGDWAzMM2mhZbmtBzMAAGGA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlBEGLjiqsy04ILJRJCAoABhh59BC-CDFGQCIASYceqqs4AHGu01TRBSKV2nI-AAAA-AcgUphYhBTgwwC-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，它在完成一系列多周任务后提供了一些微小的性能增强自定义选项。其中一些增益会影响你的伤害输出，而另一些则更偏向防御性质。

我们推荐以下增益，但它们可以随时更换，所以请随意尝试其他选项或针对你自己的配装使用模拟推荐。

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279612]]
- [[spell:1279616]]

1.

### 巅峰天赋： ![Master of Warfare Icon](<https://static.icy-veins.com/images/wow/large_icons/misc_legionfall_warrior.jpg>) 战争大师

武器 战士的终极天赋[[spell:1269314]]是一个主动触发技能，它能提高猛击的价值并增强其他循环技能。虽然它在很大程度上取代了猛击的常规施放，但也会定期穿插在单体斩杀阶段中使用。然而在多目标环境中，该技能始终会通过[[spell:202316]]被动使用。

- 第一点是一个触发效果，使[[spell:1269383]]替换猛击，赋予其更高的优先级，并触发一个小的护甲穿透增益效果。虽然这个增益效果可以叠加，但每层都有各自的持续时间，导致增益效果不断叠加和衰减，使其很容易被动处理并忽略。
- 第二点和第三点进一步增强战争大师增益效果，但对循环没有影响，因为所有这些技能继续以相同的方式使用。
- 最后一点使英勇打击施加一个单独的增益效果，提高巨神兵 猛击的强度，考虑到该技能如此高的覆盖率，这可能相当强大。

1.

### 英雄天赋

武器战士可以在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵之间进行选择，它们各有自己的优势和侧重点，但总体上构建和玩法非常相似。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 斩杀者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者侧重于[[spell:163201]]和[[spell:227847]]，主要的玩法差异在于更多的[[spell:29725]]触发和更强的斩杀阶段。它通常是团队副本和单体目标战斗的更好选择，不过目前在大秘境中也重新受到了关注。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵侧重于[[spell:12294]]、流血效果和[[spell:436358]]，表现为更频繁地使用致死打击以及为其标志性技能提供一种独特的冷却缩减形式。它在多目标战斗中通常比单体目标表现更好，并且在大秘境中比团队副本战斗中使用得更频繁。

1.

### PvP天赋（战争模式）

自《争霸艾泽拉斯》以来，玩家可以选择进入“战争模式”，使他们能够与其他玩家进行PvP战斗。启用战争模式可获得以下好处：

- 在户外世界启用PvP天赋
- 在最高等级时，世界任务奖励提高10%
- 升级时获得的经验值提高10%
- 赚取征服点数，每周可兑换装备奖励

鉴于启用战争模式对升级和PvE内容的好处，建议启用该功能以最大化你的升级效率和满级后的奖励。然而，你将使自己成为开放世界PvP的目标，并且在升级或进行世界任务时存在被“偷袭”的可能性。

1. [[spell:198817]]增加一个独立的非公共冷却增益，提升[[spell:12294]]的整体伤害。
2. [[spell:213915]]提升了[[spell:23920]]的价值，在冷却时间略微延长的同时提供更多的进攻和防御价值。
3. [[spell:206572]]提供额外的机动性，这在练级时总是有用的。
4.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月25日：** 添加了额外的屠戮者天赋配置。
- **2026年8月10日：** 更新了12.1补丁的配置推荐。
- **2026年6月15日：** 在12.0.7补丁中添加了万卷之典能力。
- **2026年5月27日：** 修正了错误的天赋字符串。
- **2026年4月23日：** 更新了备选大秘境配置和多个配置描述。
- **2026年4月22日：** 添加了多目标团本天赋配置。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 更新了12.0.1补丁的配置。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 标记了推荐的天赋配置，并针对11.0.7补丁进行了更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 为地心之战第1赛季的上线进行了更新。
- **2024年8月26日：** 新增了地下城（Delve）天赋配置，并进行了少量天赋更新。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月26日：** 小幅配置更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 更新了第4赛季的新配置。
- **2024年3月19日：** 扩展了推荐天赋更新，并为10.2.6补丁进行了审查。
- **2024年2月15日：** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2024 年 1 月 14 日：** 对配置选择工具中推荐天赋的说明进行了小幅更新。
- **2023年11月6日：** 为10.2补丁和第3赛季套装更新了天赋配置。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月12日：** 小幅格式更新。
- **2023年7月10日：** 为10.1.5补丁进行了小幅更新。
- **2023年5月1日：** 为10.1补丁进行了审查。
- **2023年2月2日：** 已更新天赋构筑。
- **2023年1月24日：** 10.0.5补丁已更新多个构筑。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 更新战斗热忱的使用说明和描述。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面，你将学习如何在单体目标和多目标情况下优化你的武器 战士的循环。我们还提供了关于冷却技能、触发效果等方面的进阶内容，以帮助你最大化你的DPS。我们所有的内容均已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 武器 战士玩法与循环指南

武器的循环是一个有条件的优先级列表，可能会根据天赋选择而变化。请使用下方的复选框进行相应的自定义设置，并确保[[spell:386164]]始终处于开启状态！请注意，单体和多目标循环使用相同的开关设置。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 斩杀者

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

多目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像

单体目标

多目标

天赋选择

[[spell:107574]]

[[spell:845]]

[[spell:227847]]

[[spell:1261060]]

[[spell:444774]]

[[spell:316440]]

[[spell:228920]]

### 单体目标起手式

[[spell:100]]

**适用条件：巨神像（启用）。**

[[spell:12294]]

**适用条件：Cleave（启用）。**

[[spell:845]]

**适用条件：横扫（未启用）。**

[[spell:772]]

**适用条件：巨神兵（启用）；Ravager（启用）。**

[[spell:228920]]

**适用条件：天神下凡（启用）。**

[[spell:107574]]

[[spell:167105]]

**适用条件：屠戮者（启用）；剑刃风暴（启用）。**

[[spell:227847]]

[[spell:1269383]]

[[spell:12294]]

**适用条件：巨神像（启用）。**

[[spell:436358]]

[[spell:7384]]

**适用条件：巨神像（启用）。**

[[spell:12294]]

**适用条件：斩杀者（启用）。**

[[spell:163201]]

[[spell:29725]]

[[spell:7384]]

[[spell:12294]]

1.1.

#### 武器 战士的单体目标起手式

只要能够，始终以[[spell:100]]作为起手。

1. **适用条件：巨神像（启用）。** 使用[[spell:12294]]
2. **适用条件：Cleave（启用）。** 使用[[spell:845]]施加割裂
3. **适用条件：横扫（未启用）。** 使用[[spell:772]]施加割裂
4. **适用条件：巨神兵（启用）；Ravager（启用）。** 在巨神兵 Smash之前使用[[spell:228920]]
5. **适用条件：天神下凡（启用）。** 施放 [[spell:107574]]
6. 施放 [[spell:167105]]
7. **适用条件：屠戮者（启用）；剑刃风暴（启用）。** 施放 [[spell:227847]]
8. 施放 [[spell:1269383]]
9. 使用[[spell:12294]]
10. **适用条件：巨神像（启用）。** 施放 [[spell:436358]]
11. 施放 [[spell:7384]]
12. **适用条件：巨神像（启用）。** 使用[[spell:12294]]
13. **适用条件：斩杀者（启用）。** 施放 [[spell:163201]]，使用 [[spell:29725]]
14. 施放 [[spell:7384]]
15. 使用[[spell:12294]]

继续按以下正常优先级执行。

### 单体目标循环

1.2.

#### 武器 战士单目标循环

武器 战士循环是一个优先级列表，每次施放一个技能后，玩家都应从列表顶部重新开始，以此建立重要性层级。

:::details 套装与循环
第2赛季套装通过可叠加的伤害增益和AoE触发来强化猛击和英勇打击，同时强化循环技能：致死打击、压制和斩杀。虽然套装强化了猛击的伤害，但无需追踪其层数，也无需在五层时特意使用，可以简单地视为被动增益。

- [[spell:1296643]]
- [[spell:1296644]]

:::

循环的总体目标是尽可能多地填充公共冷却时间，利用触发效果来帮助避免怒气溢出或怒气匮乏。

1. **适用条件：巨神像（启用）。** 使用[[spell:12294]]
2. **适用条件：横扫（未启用）。** 当撕裂剩余时间少于10秒且巨神兵粉碎就绪可用时，施放 [[spell:772]] 来施加或刷新撕裂
3. **适用条件：Cleave（启用）。** 当撕裂剩余时间少于10秒且巨神兵粉碎就绪可用时，施放 [[spell:845]] 来施加或刷新撕裂
4. **适用条件：Ravager（启用）。** 在巨神兵 Smash之前使用[[spell:228920]]
5. **适用条件：天神下凡（启用）。** 冷却完毕即施放 [[spell:107574]]
6. 冷却完毕即施放 [[spell:167105]]
7. **适用条件：巨神像（启用）。** 在 [[spell:167105]] 期间施放 [[spell:436358]]
8. **适用条件：巨神像（启用）。** 施放 [[spell:1269383]]
9. 带有两层 [[spell:29725]] 时施放 [[spell:163201]]
10. **适用条件：斩杀者（启用）。** 如果剑刃风暴不在冷却中且 [[spell:444769]] 少于3层，则施放 [[spell:163201]] 以施加其伤害增益
11. **适用条件：Bladestorm（启用）。** 在 巨神兵粉碎 期间施放 [[spell:227847]]
12. **适用条件：斩杀者（启用）。** 施放 [[spell:1269383]]
13. **适用条件：屠戮者（启用）；Opportunist（启用）。** 带有两层 [[spell:444774]] 时施放 [[spell:7384]]
14. 使用[[spell:12294]]
15. 施放 [[spell:163201]]，使用 [[spell:29725]]
16. 施放 [[spell:7384]]
17. **适用条件：Cleave（启用）。** 当撕裂剩余时间少于5秒时，施放 [[spell:845]] 来刷新撕裂
18. **适用条件：横扫（未启用）。** 当撕裂剩余时间少于5秒时，施放 [[spell:772]] 来刷新撕裂
19. 施放 [[spell:1464]]

1.3.

#### 斩杀循环

当目标生命值降至35%时，切换到斩杀循环。

1. **适用条件：Ravager（启用）。** 在巨神兵 Smash之前使用[[spell:228920]]
2. **适用条件：天神下凡（启用）。** 冷却完毕即施放 [[spell:107574]]
3. 冷却完毕即施放 [[spell:167105]]
4. 施放 [[spell:1269383]]
5. **适用条件：巨神像（启用）。** 在 [[spell:167105]] 期间施放 [[spell:436358]]
6. **适用条件：巨神像（启用）。** 使用[[spell:12294]]
7. **适用条件：Bladestorm（启用）。** 在 巨神兵粉碎 期间施放 [[spell:227847]]
8. **适用条件：斩杀者（启用）。** 当撕裂剩余时间少于3秒或 [[spell:444773]] 增益激活时，施放 [[spell:12294]]
9. **适用条件：屠戮者（启用）；Opportunist（启用）。** 带有两层 [[spell:444774]] 时施放 [[spell:7384]]
10. **适用条件：屠戮者（启用）；Deep Wounds（启用）。** 当拥有 [[spell:29725]] 或怒气超过40时，施放 [[spell:163201]]
11. **适用条件：巨神兵（启用）；Deep Wounds（启用）。** 当拥有 [[spell:29725]] 或怒气超过75时，施放 [[spell:163201]]
12. 施放 [[spell:7384]]
13. **适用条件：重伤（启用）。** 施放 [[spell:163201]]
14. **适用条件：重伤（未启用）。** 施放 [[spell:1464]]

### 多目标起手

[[spell:260708]]

[[spell:100]]

**适用条件：Cleave（启用）；屠戮者（启用）。**

[[spell:845]]

**适用条件：Ravager（启用）；巨神兵（启用）。**

[[spell:228920]]

**适用条件：天神下凡（启用）。**

[[spell:107574]]

[[spell:167105]]

**适用条件：Bladestorm（启用）；屠戮者（启用）。**

[[spell:227847]]

[[spell:845]]

**适用条件：巨神像（启用）。**

[[spell:845]]

**适用条件：巨神像（启用）。**

[[spell:845]]

**适用条件：巨神像（启用）。**

[[spell:12294]]

**适用条件：巨神像（启用）。**

[[spell:436358]]

**适用条件：巨神像（启用）。**

[[spell:845]]

[[spell:7384]]

**适用条件：斩杀者（启用）。**

[[spell:163201]]

[[spell:845]]

1.4.

#### 武器 战士多目标起手

[[spell:260708]] 可以在进入战斗前预读，否则在有多个目标时冷却完毕即使用

只要能够，始终以[[spell:100]]作为起手。

1. **适用条件：Cleave（启用）；屠戮者（启用）。** 施放 [[spell:845]]
2. **适用条件：Ravager（启用）；巨神兵（启用）。** 施放 [[spell:228920]]
3. **适用条件：天神下凡（启用）。** 施放 [[spell:107574]]
4. 施放 [[spell:167105]]
5. **适用条件：Bladestorm（启用）；屠戮者（启用）。** 施放 [[spell:227847]]
6. 施放 [[spell:845]]
7. **适用条件：巨神像（启用）。** 继续施放 [[spell:845]]，使用 [[spell:1261056]]
8. **适用条件：巨神像（启用）。** 继续施放 [[spell:845]]，使用 [[spell:1261056]]
9. **适用条件：巨神像（启用）。** 使用[[spell:12294]]
10. **适用条件：巨神像（启用）。** 施放 [[spell:436358]]
11. **适用条件：巨神像（启用）。** 施放 [[spell:845]]
12. 施放 [[spell:7384]]
13. **适用条件：斩杀者（启用）。** 施放 [[spell:163201]]
14. 施放 [[spell:845]]
15. 继续按正常的多目标优先级执行。

### 多目标循环

1.5.

#### 武器 战士多目标循环

面对多个目标时，武器战士会大量使用 [[spell:845]]，而 [[spell:260708]] 则能让其余技能命中第二个目标。由于这种侧重点，面对多个目标时没有专门的斩杀阶段。

:::details 套装与循环
第2赛季套装通过可叠加的伤害增益和AoE触发来强化猛击和英勇打击，同时强化循环技能：致死打击、压制和斩杀。由于这些效果可以被

[[spell:202316]]

触发，套装基本上是被动的。

- [[spell:1296643]]
- [[spell:1296644]]

:::

顺劈斩是面对3个以上目标时的主要技能，会自动施放 [[spell:1464]] 或 [[spell:1269383]]，并触发多个强大的天赋效果。屠戮者也会尽可能配合斩杀使用斩杀，而巨神兵则会使用致死打击来帮助强化崩摧。

1. 冷却完毕即施放 [[spell:260708]]
2. **适用条件：屠戮者（启用）；Cleave（启用）。** 尽早施放 [[spell:845]] 以施加撕裂
3. **适用条件：Ravager（启用）；巨神兵（启用）。** 在巨神兵 Smash之前使用[[spell:228920]]
4. **适用条件：天神下凡（启用）。** 在 巨神兵粉碎 期间或之前施放 [[spell:107574]]
5. 施放 [[spell:167105]]
6. **适用条件：斩杀者（启用）。** 带有3层 [[spell:334779]] 时施放 [[spell:845]]
7. **适用条件：Bladestorm（启用）。** 施放 [[spell:227847]]
8. **适用条件：斩杀者（启用）。** 带有2层 [[spell:29725]] 时施放 [[spell:163201]]
9. 施放 [[spell:845]]
10. **适用条件：巨神像（启用）。** 当 [[spell:429634]] 少于10层时施放 [[spell:12294]]
11. **适用条件：巨神像（启用）。** 施放 [[spell:436358]]
12. **适用条件：斩杀者（启用）。** 拥有2次充能时施放 [[spell:7384]]
13. **适用条件：斩杀者（启用）。** 施放 [[spell:163201]]，使用 [[spell:29725]]
14. 施放 [[spell:7384]]
15. **适用条件：斩杀者（启用）。** 施放 [[spell:163201]]
16. 使用[[spell:12294]]
17. **适用条件：巨神像（启用）。** 带有斩杀时施放 [[spell:163201]]
18. 施放 [[spell:1464]]

### 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 斩杀者

1.6.

#### 作为屠戮者游玩

屠戮者围绕 [[spell:29725]] 和 [[spell:227847]] 展开，但定期使用致死打击和顺劈斩仍然很重要。

- 消耗 [[spell:29725]] 会根据 [[spell:445584]] 的层数减少 [[spell:227847]] 的冷却时间。
- [[spell:29725]] 可以叠加两层，因此无需立即使用，但也不应无谓地延迟以避免溢出。
- [[spell:227847]] 触发多个天赋，因此最好在 [[spell:167105]] 早期使用，以最大化增益效果的重叠。
- 只要不需要昏迷，任何时候都可以在剑刃风暴期间施放 [[spell:107570]]，以造成极少量的额外伤害。

### 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神像

1.7.

#### 作为巨神兵游玩

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵专注于 [[spell:436358]] 而非剑刃风暴，尽管它承担着相同的游戏角色。它的冷却时间不再动态缩短，但通常会与巨神兵粉碎对齐，两者应尽可能配合使用。

- [[spell:436358]] 触发数个天赋效果，因此最好与巨神兵粉碎配合使用，而不是严格地冷却完毕就用。
- [[spell:436358]] 是一个引导效果，会大幅降低移动速度，因此正确的站位是关键。大多数非公共冷却技能，包括 [[spell:100]]、[[spell:3411]]、[[spell:6544]]、[[spell:118038]] 和 [[spell:23920]] 都可以在引导期间使用，以帮助减少伤害或根据需要重新定位。
- [[spell:436358]] 可以免疫大多数昏迷、击退和强制移动效果，但除非绝对必要，否则不应为此延迟使用。

1.

### 至暗之夜 第2赛季套装

新的至暗之夜第2赛季套装加成通过可叠加的伤害增益和AoE触发来强化猛击和英勇打击，同时强化循环技能：致死打击、压制和斩杀。虽然套装强化了猛击的伤害，但无需追踪其层数，也无需在五层时特意使用，可以简单地视为被动增益。

- [[spell:1296643]] - 致死打击和斩杀的伤害提高10%，并且当你对目标施放猛击时，猛击还会对目标8码范围内的敌人造成（100%攻击强度）的伤害。超过5个目标时伤害降低。
- [[spell:1296644]] - 压制的伤害提高15%。致死打击和压制会使你的下一个猛击伤害提高20%，最多可叠加5次。

1.

### 职业与专精机制详解

为了更好地解释武器 战士机制的具体细节，我们编写了关于循环各个部分的更详细说明，从你需要注意的重要循环机制，到冷却技能及其使用方法，让你能够发挥全部潜力。

### 怒气管理

3.1.

#### 怒气管理

武器最重要、最核心的游戏概念是管理其主要资源，尤其是在至暗之夜中被大幅削弱之后。武器几乎每个技能都要消耗怒气，而大部分怒气通过自动攻击产生，导致两者节奏不同步。虽然在大多数情况下你不需要考虑这一点，但识别何时会出现怒气充足或匮乏的情况并尝试避免它们非常重要，因为少施放一次猛击远不如错过一次致死打击重要。

请注意，[[spell:462854]] 提供额外的自动攻击次数，同样会产生怒气，因此队伍中始终有一名萨满祭司是非常理想的，不过在游玩屠戮者时效果不太明显。

### 最大化输出时间

3.2.

#### 最大化输出时间

适用于大多数职业，但对武器战士来说尤其相关，因为怒气生成和伤害都依赖于自动攻击。任何脱离目标的时间都是损失的伤害，且几乎没有手段弥补损失的资源，不像能量类职业会持续恢复资源直到上限。

由于战士职业固有的高机动性，可以围绕Boss机制进行操作并尽量减少停手时间。如果Boss正在施放需要玩家跑开一定距离的区域效果技能，战士可以继续攻击到最后几秒，然后 [[spell:6544]] 离开，危险一过立即 [[spell:100]] 回来。

虽然武器可能因缺乏怒气而有空闲的公共冷却时间，但规划并确保在 [[spell:167105]] 减益期间尽可能填充技能，对于最大化武器 战士伤害至关重要。在这些爆发窗口之外，最好让怒气积累，只在不会妨碍施放后续 [[spell:12294]] 的前提下消耗怒气。

### 循环冲锋

3.3.

#### 循环冲锋

通过移出目标范围并使用 [[spell:100]] 可以在循环中产生额外怒气，从而进行小幅优化。应注意在 [[spell:167105]] 未激活时，在自动攻击之间进行此操作。[[spell:6544]] 也可用于为碰撞箱较大的Boss创造冲锋空间，这种情况有时更具体地称为英勇冲锋。

### 使用巅峰天赋

3.4.

#### 使用巅峰天赋

[[spell:1269383]] 的优先级高于普通的 [[spell:1464]] 施放，最主要因为它是在斩杀循环中使用的。然而，由于 [[spell:1269314]] 的层数有各自的持续时间，因此没有特别的需要或优势去追踪它，使得该增益很容易被动地处理。

[[spell:1269307]] 的不同之处在于它像普通增益一样叠加，但一旦施放 [[spell:167105]] 就会立即消耗，这也使它成为一个相当被动的增益。虽然玩家每个周期平均获得2-3层，但该增益最多可叠加5层，以确保幸运的触发不会浪费。

1.

### 武器 战士的重要冷却技能

### [[spell:167105]]

4.1.

#### 巨人打击

武器战士的主要冷却技能提供中等的爆发窗口，不如许多职业那么大，但由于 [[spell:152278]] 的持续冷却缩减，使用频率非常高。几乎总是最好严格地冷却完毕就用，但在面对小怪群或与其他重要伤害阶段对齐时，可以视情况延迟，但应注意认识到其实际冷却时间比暗示的要短得多。

### [[spell:107574]]

4.2.

#### 天神下凡

现在也受到 [[spell:152278]] 的缩减以帮助与巨神兵粉碎对齐，天神下凡已失去所有后续天赋和大部分威力，成为一个相当次要的冷却技能，没有固有的游戏收益。

### [[spell:227847]]

4.3.

#### 剑刃风暴

屠戮者的标志性技能不再是过去那样的高爆发猛兽，但仍能提供可观的伤害，其单体价值由 [[spell:386628]] 提升。作为少数不消耗怒气的技能之一，引导期间自动攻击继续命中，使其成为一个伪怒气生成器。

请记住，狂乱引发的自动致死打击也能触发它们自身的效果，例如 [[spell:184783]] 或 [[spell:444775]]。

尽管三层 [[spell:444769]] 会让按钮发光，但这并不是何时使用剑刃风暴的指示。它几乎总是应该冷却完毕就用，或者配合小怪群的时机。

### [[spell:228920]]

4.4.

#### 破坏者

作为剑刃风暴的巨神兵对应技能，破坏者实际上承担着完全不同的角色，主要是一个多目标技能，其微小的伤害被对顺劈斩的大幅增益所抵消。由于破坏者不再受任何形式的冷却缩减影响，使其与巨神兵粉碎对齐可能很困难，但两者应尽可能配合使用以利用 [[spell:1261056]]。

### [[spell:436358]]

4.5.

#### 崩摧

作为剑刃风暴的真正对应技能，崩摧无论在单体还是多目标冷却技能中的使用方式几乎相同。它有自己独特的冷却缩减形式，不总是与其他技能对齐，因此密切关注各种冷却计时器对于最大化其伤害至关重要。

### [[spell:384110]]

4.6.

#### 破裂投掷

虽然本身不是主要的冷却技能，但碎敌投掷造成的伤害出奇地高，使其成为一个称职的远程填充技能，在点出 [[spell:1271948]] 天赋时还能沉默敌人。然而，它的真正威力在面对带有吸收护盾的目标时才显现，获得500%的伤害乘数，成为整个战士技能组中最强大的单次攻击。在这种情况下，应尽快使用，仅次于巨神兵粉碎，以确保击中目标并迅速剥离其护盾。

4.7.

#### 防御技能

武器的主要生存工具是 [[spell:118038]]，它对于免疫直接物理伤害极为有用，甚至可以用来短暂地坦住团队副本Boss。当预期更频繁的尖刺伤害时，[[spell:386208]] 和 [[spell:190456]] 可以用于更多减伤，但请注意两者都会以少量伤害输出为代价，而 [[spell:202168]] 和 [[spell:29838]] 则可以帮助回复生命值。最后，[[spell:23920]] 是缓解或完全免疫许多魔法伤害来源的极其有用的工具。

该 [指向性法术](<https://www.curseforge.com/wow/addons/targetedspells>) 插件在知道敌人何时对你施放法术时非常有帮助，但它无法告诉你该法术是什么或是否可以反射，因此玩家需要自己学会识别它们。

战士还可以使用 [[spell:97462]]，这是游戏中少数群体防御冷却技能之一。它通常用于帮助团队在关键战斗机制中存活，而不是作为个人冷却技能。请记住它占用公共冷却时间，因此需要时要准备好使用。

4.8.

#### 团队增益

战士还提供 [[spell:6673]]，使所有小队和团队成员的攻击强度提高5%，应在战斗开始前施加。请注意，该增益仅适用于近战攻击者和猎人，对施法专精没有加成。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月6日：** 调整了战斗怒吼的描述。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月10日：** 已根据第3赛季的循环变化进行更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁添加了战斗助手部分。
- **2025年4月21日：** 将循环拆分为可切换的图片框架。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月23日：** 对单体目标和斩杀循环进行了小幅更新。
- **2024年9月9日：** 关于切换选项的补充说明。
- **2024年8月22日：** 修复了巨神兵切换选项的错误。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月26日：** 对碎颅者进行了小幅说明。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月15日：** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2024 年 1 月 14 日：** 添加了一个强调正确使用菲莱克巨剑的部分。
- **2023年11月8日：** 修正了在斩杀循环中隐藏低优先级填充技能的错误。
- **2023年11月6日：** 为第3赛季做准备，更新了T31配置和循环。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.0.7补丁进行了更新，改进了默认复选框。
- **2023年2月27日：** 修正了剑刃风暴的错误命名。
- **2023年2月2日：** 更新了循环工具。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 修复天赋选择器的格式。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 更新战斗热忱的使用说明和描述。
- **2022年11月9日：** 修正了压制在输出循环中的位置。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页面中，你将找到魔兽世界12.1.5版本中你的武器战士的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们应有尽有！

1.

### 武器战士毕业装备指南

欢迎来到我们的武器战士装备与毕业装备页面，适用于至暗之夜第2赛季。查看此页面，了解关于为武器战士配装的一切信息，包括来自所有来源（团队副本和大秘境）的毕业装备、关于最佳饰品、套装的信息，或查看 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 以了解有关新资料片功能的更多信息。

一般而言，物品等级是强度的最佳指标，物品等级更高的装备几乎总是比属性分配稍好的装备更强。然而，由于饰品拥有各种各样的特殊效果，饰品可能是个例外。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含武器战士来自所有来源的最高DPS配置。请注意，还有一些属性分布相似且表现相当的替代选择。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

未加衬的制造物品不如完全升级的对应物品强，但可以作为非常强力的填充部件。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，武器战士优先选择哪些套装部件已不再重要，因为通过转化器转化的套装部件现在会继承原始物品的属性和加成，使它们完全相同，并使“非套装件”的概念过时。不过，玩家对配装仍有更多控制权，因为带有默认属性的兑换物仍会像往常一样从首领身上掉落。

- 转化器头盔：[[item:281239@JAACAAgNyA]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 转化器肩膀：[[item:239037@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 转化器胸甲：[[item:268222@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

话虽如此，凑齐套装加成远比优化属性分配重要，所以不要过分执着于等待更好的部件。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271878@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>胸部</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

此列表包含武器战士专门来自地下城的最佳装备。请注意，还有一些属性分布相似的替代选择，以及几个非常有竞争力的转化器套装部件，可以从任何地下城获得。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

未加衬的制造物品不如完全升级的对应物品强，但可以作为非常强力的填充部件。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，武器战士优先选择哪些套装部件已不再重要，因为通过转化器转化的套装部件现在会继承原始物品的属性和加成，使它们完全相同，并使“非套装件”的概念过时。不过，玩家对配装仍有更多控制权，因为带有默认属性的兑换物仍会像往常一样从首领身上掉落。

- 转化器头盔：[[item:251229@JAACAAgNyA]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 转化器肩膀：[[item:239037@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 转化器胸甲：[[item:251151@JAACAAgNyA]]，来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 转化器手套：[[item:251214@JAACAAgNyA]]，来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 转化器腿部：[[item:273776@JAACAAgNyA]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

话虽如此，凑齐套装加成远比优化属性分配重要，所以不要过分执着于等待更好的部件，因此这里列出了全部五个选择。

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：包含最多的部件，包括最佳武器。
- [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)：也有若干部件，使其刷取效率更高。
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：拥有一枚非常优秀的戒指，提供重要属性。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:273781@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>腰部</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271455@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>披风</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271459@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:250229@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273782@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

此列表包含武器战士专门来自团队副本的最佳装备。请注意，还有一些属性分布相似且表现相当的替代选择。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

未加衬的制造物品不如完全升级的对应物品强，但可以作为非常强力的填充部件。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，武器战士优先选择哪些套装部件已不再重要，因为通过转化器转化的套装部件现在会继承原始物品的属性和加成，使它们完全相同，并使“非套装件”的概念过时。不过，玩家对配装仍有更多控制权，因为带有默认属性的兑换物仍会像往常一样从首领身上掉落。

- 转化器头盔：[[item:281239@JAACAAgNyA]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 转化器胸甲：[[item:268222@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 转化器腿部：[[item:271878@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

话虽如此，凑齐套装加成远比优化属性分配重要，所以不要过分执着于等待更好的部件。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271444@JAACAAgNyA]]&#10;&#10;<div><span>可交易的小怪掉落</span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271455@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>胸部</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arms-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 武器战士饰品推荐

第2赛季有几种饰品可供选择，不过本赛季主动使用型饰品非常少，大多数是随机伤害或属性增益，游戏价值不高，也无法从[[spell:107574]]或[[spell:167105]]等职业效果中受益。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看武器战士饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>两者皆有</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270175]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:250259]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:193762@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:270163]]</li>&#10;<li>[[item:273795]]</li>&#10;<li>[[item:158367]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

12.1版本继续沿用额外拾取系统，允许玩家获得一个朦胧虚空核心作为额外拾取，以代替从宏伟宝库中获取一件物品。随着12.1.5版本的发布，玩家还将能够每周从 **奥琳·微光** 银月城转化器附近的商人处额外购买一个虚空核心，从而获得两次获取额外拾取战利品的机会。

**[朦胧虚空核心](<https://www.wowhead.com/currency=3418>)** 可以在完成地下城或击败团队副本首领后使用，使你从该特定掉落列表中获得一件随机物品。每个物品在每个难度或地下城中只能被额外拾取一次，作为剔除列表以确定性地获取物品。

1.

### 推荐的朦胧虚空核心额外拾取

从12.1版本开始，玩家可以通过放弃从宏伟宝库获取物品来获得虚空核心作为额外拾取，不过在赛季开始八周内（大约在12.1.5版本预计到来之时），它们无法以其他方式每周获取。这些是强大的资源，如果宝库中的物品不够好，非常值得优先使用。归根结底这是一种赌博，玩家需要评估宝库中的装备是否比从特定首领或地下城掉落列表中额外拾取他们想要的物品的机会更好。

额外拾取的战利品会按照来自宏伟宝库的方式发放，因此英雄难度团队副本首领的战利品会以神话路线1/6的等级发放，而史诗团队副本首领的战利品则会以其最高升级等级发放，这可能节省大量纹章。

4.1.

#### 武器战士推荐的朦胧虚空核心用法

使用 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 额外拾取有两种主要方式，取决于玩家的需求。理想情况下，它们应该用在大秘境10层和史诗团队副本首领身上以最大化奖励，但请注意，史诗团队副本首领每周只能击败一次，而大秘境可以重复进行，以便囤积并使用多个额外拾取直到获得所需物品。截至12.1版本，只有一个
[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 会被消耗，无论它是用在团队副本首领身上还是在大秘境中。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 神话路线武器，特别是[[item:268213]]或[[item:280799]]。
2. 神话路线饰品，特别是[[item:270173]]和[[item:270175]]。
3. 拥有额外预算或特效的物品，例如[[item:268265]]、[[item:271878]]和[[item:281029]]。
4. 任何高预算、稀有或可替代低物品等级装备的物品。

:::

4.2.

#### 晋升毒液石

[[item:280562]]可用于升级已经达到最高等级的英雄、神话或同等制造的武器、饰品或项链。英雄装备升级至328物品等级，制造部件升级至338，而史诗装备升级至340物品等级。

1. 武器始终是战士的最高优先级。
2. 饰品位居第二，因为它们的特殊效果通常比纯粹的属性提供更多的强度。
3. 项链应该最后升级。

因为只有这三类物品可以升级，进度较高的武器战士处于一个特殊的位置：如果他们已经从史诗盘蛇祭坛和乌拉特克获得了344物品等级的部件，他们实际上并不需要毒石。然而，大多数玩家尚未达到那个阶段，且毒石可以无限刷取，因此不必为最好的物品囤积它们。它们可以而且应该用来升级你当前穿着的任何装备部件。

1.

### 武器战士最佳制造物品

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

由于早期获得高物品等级武器的难度，制造武器可以是武器战士的一个不错的首选，但如果同时也打算玩狂怒，则有可能造成浪费，特别是在这个赛季拥有一把高价值特效武器的情况下。归根结底，护腕和靴子是最好的制造选择，因为它们占用最低的预算槽位，并释放出重要得多的武器槽位。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **武器制造装备优先级**
- [[item:237834]]搭配[[item:240167]]
- [[item:237828]]搭配[[item:240167]]
- 根据需要填补剩余的装备槽位

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

5.1.

#### 武器战士最佳衬饰

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

由于衬饰的竞争非常激烈，你必须为你整体的DPS输出挑选出最强的两个。大多数衬饰提供的DPS收益非常相似，即使效果完全不同。对此最佳的两个选择是：

- 如果使用制造武器：武器上使用[[item:245876]]，护腕上使用[[item:240167]]。
- 否则，对于团队副本和大秘境：护腕和靴子上都使用[[item:240167]]。

建议你自行模拟以找出最适合你的方案，并考虑任何可能在不久的将来进行的专精转换。

5.2.

#### 为装备添加插槽

玩家可以每周选择不从宏伟宝库中挑选物品，而是选择代币，其中六个可以兑换一个[[item:275707]]，这是一种消耗品，可以为尚无插槽的头盔、护腕或腰带增加一个插槽。这使得它成为完善你打算长期保留的装备的好方法。

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于纹章每周获取量有限，而且升级不同物品所花费的纹章数量相同，你应该优先将纹章用在那些你短期内不打算更换的物品上，或是能带来最大收益的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **武器战士纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些并不是唯一值得升级的物品。它们只是在赛季初期、你的升级货币有限时提供最高的DPS收益。请注意，例外是可能存在的，例如拥有该装备独特额外效果的特殊特效物品。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 更新了12.1.5补丁的装备推荐，并添加了关于毒石的新章节。
- **2026年8月10日：** 更新了12.1补丁的所有装备推荐。
- **2026年6月15日：** 在12.0.7补丁中添加了孢化装备。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 添加了关于使用纹章升级物品的章节。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁添加了新的常见问题解答部分。
- **2025 年 10 月 5 日：** 添加了迪纳尔，更新了推荐饰品，并为涡轮增压提高了物品等级。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月20日：** 热修后，将泰坦神装DISC腰带的推荐从充能箭矢改为致命连锁。
- **2025年6月15日：** 为11.1.7补丁添加了泰坦神装DISC腰带。
- **2025年5月12日：** 更新了装备列表，添加了代币购买优先级。
- **2025年4月21日：** 添加了11.1.5补丁的帮会代币推荐。
- **2025年3月17日：** 修复了失效的塞尔西的王冠链接，并在嵌入内容中添加了宝石。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月16日：** 更新了塞尔西的王冠，以计入物品等级提升的热修。
- **2024年12月15日：** 添加了塞尔西的王冠，并针对11.0.7补丁进行了验证。
- **2024年10月21日：** 添加了一个简要部分，详细介绍了即将到来的时光漫游和周年庆团队副本饰品。
- **2024年9月9日：** 为地心之战第1赛季的上线进行了更新。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 更新了第4赛季的新装备和铸币推荐。
- **2024年3月19日：** 扩展了专业制造推荐，并为10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2024 年 1 月 14 日：** 将菲莱克巨剑添加到整体毕业列表中（祝你好运）。
- **2023年11月8日：** 更新了新的装备套装，以计入孢子披风的削弱。
- **2023年11月6日：** 为10.2补丁和第3赛季进行了更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 为10.1.5补丁进行了更新，以包含永恒黎明的装备。
- **2023年5月1日：** 更新了玛瑙指环的宝石推荐。
- **2023年3月20日：** 更新了10.0.7补丁的玛瑙指环信息。
- **2023年2月2日：** 移除了错误的狂怒引用。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面中，你将了解你的武器战士的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法相互作用。我们的内容已针对魔兽世界12.1.5版本更新。

1.

### 武器 战士属性优先级

两者皆有 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者和武器战士主要看重力量的物品等级，其次是暴击和急速，然后是精通或全能。这些属性的价值会波动，随着获取更多而下降，因此先堆叠大量暴击和急速，然后通过宝石或附魔获取更多精通或全能是很常见的。当你达到中等装备水平时，武器战士的属性优先级应该是：

装备等级

暴击

急速

精通

全能

在最高装备水平下，这些属性会因堆叠最多的属性出现收益递减而发生变化，通常导致所有四项属性的权重非常相似，不过在某个点上，你无法在不放弃另一项属性很大一部分的情况下获得更多某项属性。这就是为什么与一点力量相比的传统属性权重是一种难以使用的工具，建议玩家定期模拟自己的装备升级。

1.

### 深入属性解析

力量是你的主属性，出现在板甲、武器和饰品上。它提供攻击强度，有助于所有技能和自动攻击的伤害。

暴击通常会使攻击和技能的伤害翻倍，并使自动攻击产生的怒气提高10%。不过，多亏了[[spell:383430]]和各种其他天赋，暴击的伤害可以超过正常的+100%倍率。

急速压缩了输出循环，减少了自动攻击之间的间隔、公共冷却时间，以及循环技能[[spell:12294]]、[[spell:7384]]和[[spell:845]]的冷却时间，还加快了[[spell:227847]]、[[spell:772]]和[[spell:115767]]造成伤害的速度。

:::details 常见问题：武器战士有急速上限吗？
严格来说没有，因为即使超过100%，急速仍会继续减少循环技能的冷却时间并增加自动攻击的频率。

然而，存在几个使其价值发生变化的临界点。由于类似增益效果的不一致性，这很难计算，比如

[[spell:248621]]

这样的增益效果具有不一致性，这很难计算。值得庆幸的是，急速对武器来说仍然是一项强大的属性，因为它能在各种伤害增益期间塞进更多的公共冷却时间，并在

[[spell:152278]]

.

:::

精通会增加受到的伤害减益[[spell:115767]]，该减益通过使用[[spell:12294]]、[[spell:167105]]、[[spell:227847]]、[[spell:262161]]、[[spell:845]]和[[spell:228920]]来施加和维持。这在多目标环境中通常价值较低，但由于使用[[spell:845]]来维持该减益的便利性，其价值有所提升。

全能提供伤害输出的固定增益，并减半降低受到的伤害。直接伤害饰品、特效物品和其他外部伤害来源通常更看重全能，因为它们通常不随攻击强度缩放。

2.1.

#### 武器战士种族加成

:::details 点击查看Bloodmallet模拟数据
加载中...

如需查看完整的模拟结果，请查看 [Bloodmallet.com](<https://bloodmallet.com/index.html#warrior_arms>)

:::

种族加成对武器的表现影响极小。任何1%以内的差异通常都被认为是微不足道的，差距足够小，我们的建议是选择你最喜欢的角色。

2.2.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

:::details 常见问题：收益递减是如何运作的？
为了平滑副属性的价值并减少堆叠单一属性的倾向，在各个点上，转换为1%所需的副属性量会减少。这是按等级而非原始百分比计算的。所以它不包括职业增益效果，例如

[[spell:248621]]

或

[[spell:2825]]

，但它会影响饰品和其他添加固定数值的效果。

在实践中，这不是大多数玩家需要关注的事情，因为最好的副属性即使在收益递减点之后也往往保持价值。它只是缩小了它们之间的差距，以确保更多种类的装备有用。

:::

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁添加了常见问题解答部分。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月26日：** 在趁胜追击增强后，说明了急速价值的下降。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了审查。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面中，我们列出了你的武器战士可以获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/arms-warrior-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 武器战士最佳宝石、附魔、食物和合剂

1.

### 推荐宝石

在唯一装备的钻石中，当镶嵌多种颜色的宝石时，[[item:240967]]会更强一些，不过在装备初期插槽有限时，这可能难以兼顾。因此，[[item:240983]]可能是更简单的选择。

暴击和急速通常是武器战士的最佳属性，因此其他所有插槽都应填入[[item:240906]]或[[item:240890]]。使用多种颜色来提升强能钻石加成时，应使用一颗石榴石、一颗橄榄石和一颗紫水晶，但要避免使用青金石，因为全能属性的价值不高。

1.

### 最佳附魔和武器强化

除了附魔之外，玩家还可以为武器施加临时强化，这是一种持续两小时的增益效果，可以提高伤害或属性。虽然这些加成在死亡后依然保留，但它们并非永久性的，需要重新施加。应使用[[item:243733]]来获得更多次要属性。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>肩部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243963]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;<li></li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244643]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

几种附魔提供了在吸血、速度或闪避附魔之间进行选择的余地，这主要取决于个人偏好，因为这三者都只提供微小且在很大程度上可以互换的收益。

1.

### 最佳消耗品

- 最佳合剂：[[item:241325]]或[[item:241326]]
- 最佳战斗药水：[[item:241288]]是最佳战斗药水，但它需要非常仔细地分配属性，以确保暴击最高且全能最低，这使得[[item:241308]]或[[item:271886]]的使用要简单得多。
- 最佳治疗药水：应使用[[item:271883]]进行治疗。
- 最佳食物：[[item:255846]]是最佳的宴会食物。像[[item:242275]]这样的个人食物提供相同的进攻收益，但缺少额外的生命值加成。
- 强化符文：[[item:259085]]是至暗之夜中目前唯一可用且最佳的强化符文。

4.1.

#### 强化符文

[[item:259085]]是至暗之夜中目前唯一可用且最佳的强化符文。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 更新了推荐的武器附魔和药水描述，以说明特殊情况下的属性问题。
- **2026年8月10日：** 更新了12.1补丁的宝石、武器附魔和治疗药水。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月6日：** 为鲁莽药水添加了免责声明。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025 年 8 月 25 日：** 新增了临时强化，并扩充了关于武器附魔的说明。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月12日：** 对腐蚀部分进行了小幅更新，将回响虚空作为备选方案。
- **2025年4月21日：** 添加了11.1.5补丁的腐蚀推荐。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月26日：** 更新了主手附魔。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 更新了玛瑙指环的宝石推荐。
- **2023年3月20日：** 更新了10.0.7补丁的玛瑙指环信息。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本攻略中，你将找到在《魔兽世界》12.1.5补丁中使用你的武器战士挑战大秘境地下城的技巧和建议。

1.

### 武器战士在至暗之夜第2赛季大秘境中的表现

大秘境中的武器战士是持续输出型伤害输出者，依赖高覆盖率和频繁的冷却技能来打出稳定的伤害量，而不是短时间的高额爆发。虽然操作非常紧凑，但也非常惧怕空窗期，因为每远离目标一秒都会降低其潜在输出。因此，优秀的武器战士应该始终提前思考好几步，预判哪些机制即将发生、敌人将如何移动、何时击败它们以及是否即将拉到新的一波怪，以确保始终领先于战斗节奏。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

1.

### 最佳大秘境天赋配置

由于强调多目标伤害，巨神兵和屠戮者在大秘境地下城中使用大部分相同的通用和专精天赋，他们的选择也不会根据地下城或钥匙等级而改变。这意味着两者之间的差异很大程度上取决于他们的英雄天赋，其中
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者在数个赛季以来首次处于领先地位。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者大秘境天赋构建

2.1.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者在至暗之夜中为武器战士准备的大秘境天赋

屠戮者在至暗之夜第2赛季中取得了相当大的进步，大幅提高了即死触发以及随之而来的[[spell:444775]]触发的频率，同时也使[[spell:262150]]变得更加强力。结合其本就更强的单体伤害，这使其成为首选的英雄天赋树。

大秘境 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者构筑通过[[spell:7384]]和[[spell:444775]]带来卓越的多目标伤害，同时几乎不牺牲单体目标伤害。

2.2.

#### 灵活天赋

虽然专精树相当固定，但职业树有很大的自定义空间：

- 任何时候有带护盾的目标时，可以选取[[spell:384110]]来替代[[spell:1271926]]。选取[[spell:1271948]]而非[[spell:1280961]]也可能是值得的，用一些防御收益换取一个远程打断。
- 只要积极使用防御姿态，[[spell:1280961]]就具有出色的防御潜力，尽管其进攻收益充其量只是平庸。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTgZwGYmhhBzyMbDwMDAmhBA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlnBEGLjiqsy04kkoEBAUggww8+AB-CDFGQCIASYceqqs4AHGu0IZaiqj3nIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵大秘境天赋构建

2.3.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵在至暗之夜中为武器战士准备的大秘境天赋

巨神兵通过[[spell:436358]]、顺劈斩和强化流血效果持续提供非常强大的多目标伤害，尽管它缺乏优先目标伤害，且其集怪能力已大幅降低。尽管如此，它拥有略好一些的群体控制能力，以及一个在低生命值时触发的额外被动治疗来源。

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/colossus.webp>) 巨神兵通过使用[[spell:845]]和[[spell:12294]]大幅缩短[[spell:436358]]的冷却时间来提供非常高的多目标伤害，尽管其单体目标首领伤害非常平庸，且[[spell:163201]]很少使用。

2.4.

#### 灵活天赋

虽然专精树相当固定，但职业树有很大的自定义空间：

- [[spell:1244088]]和[[spell:382260]]对于更快地移动很有用，可以轻松地与[[spell:1271926]]或[[spell:382767]]互换，因为武器很少能达到资源上限。
- [[spell:1271925]]在大多数PvE内容中的用途有限，但在少数相关的情况下可以与[[spell:5246]]或[[spell:12323]]互换。
- 只要积极使用防御姿态，[[spell:1280961]]就具有惊人的防御潜力，尽管其进攻性收益充其量只是平平。在多目标内容繁重的情况下，[[spell:382764]]通常是最佳的舍弃选择，不过这也需要选择[[spell:1243660]]而不是[[spell:1271948]]。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CcEAAAAAAAAAAAAAAAAAAAAAAgZmxsMzMzYGAAAghphxYmZzMzMzYmxMDAAAAgxmZgJLAbmxwCMwMsRjBLgZGGGjZzsNYmBAYGGA"
}
```
:::

:::details 来源计算器编码
```
#HB-DIJNOPTlnBEGLjiqsy04kkoEBAUggww8+AB-CDFGOQCASYceqqsuoxBOMURZBq7nUKR-AAAA-AegUphQhBTgwwC-*
```

:::

1.

### 功能技能与能力

### 打断、昏迷、制止和减速

3.1.

#### 打断

[[spell:6552]]是战士版本的脚踢，经常在大秘境中使用以打断敌人的施法，从而造福整个队伍，尤其是坦克。由于有时需要打断你当前正在攻击的目标以外的目标，因此 **强烈推荐** 使用焦点或鼠标悬停宏是必要的。

屠戮者拥有在[[spell:227847]]期间使用拳击的独特能力，这通常是无法做到的。

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 拳击
```

这个宏会踢你的焦点目标（如果你有焦点目标的话），没有焦点目标则踢鼠标悬停目标，两者都没有则踢你的主要目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**.

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

严格来说不是打断技能，[[spell:23920]]是一个极其强大的个人工具，可以偏转或反射许多敌人法术的伤害和负面效果，但仅限于法术施放在战士身上时。

[[spell:384110]]配合[[spell:1271948]]还能提供远程沉默！

3.2.

#### 昏迷、“制止”和减速

[[spell:107570]]和[[spell:46968]]是单体和多目标昏迷技能，由于常用于制止敌人行动而被称为“制止”。与过去相比更容易点出天赋；这些是任何大秘境构建中的核心天赋。

[[spell:5246]]是另一个群体制止技能，它恐惧目标而不是击晕目标。这有几个限制，会导致目标逃跑并可能引来援军，某些目标对该状态免疫，以及与刺穿怒吼冲突。因此，在大秘境构建中并不总是会点出这个天赋，但可以根据需要添加。

[[spell:12323]]可用作群体减速，尽管这在大多数内容中并不是经常需要的。[[spell:1715]]是不需要天赋的单体替代方案，通常足以满足任何减速需求。刺穿怒吼还能为盟友提供少量的速度加成，但由于其超长的冷却时间，使其适用范围非常有限。

### 其他功能

3.3.

#### 其他功能

[[spell:6673]]使所有近战职业和猎人的伤害输出提高5%，应始终保持激活状态。

[[spell:97462]]是一个全队防御性冷却技能，有助于帮助自己或盟友承受即将到来的伤害。其效果在非团队副本内容中还会提高50%！

[[spell:18499]]和[[spell:384100]]可以移除恐惧和迷惑效果，这在现代游戏中并不常见。呐喊版本作用于盟友，但有几个限制：需要额外的天赋点、范围非常有限经常无法覆盖施法者，以及只能在恐惧效果施加后反应性地使用，而不能提前免疫。因此，它很少被点出，不过新的[[spell:1271925]]天赋在移除同时带有减速效果的致命减益时可能有用武之地。

1.

### 应对词缀

与大多数职业不同，战士处理各种机制的专门技巧很少，主要专注于个人伤害和防御。战士的大多数技巧都是使用[[spell:23920]]来抵消或反射即将到来的法术伤害。

该 [指向性法术](<https://www.curseforge.com/wow/addons/targetedspells>) 插件在知道敌人何时对你施放法术时非常有帮助，但它无法告诉你该法术是什么或是否可以反射，因此玩家需要自己学会识别它们。

4.1.

#### 词缀

至暗之夜 第2赛季只有四个重要的 词缀 提供任何反制手段，称为萨拉塔斯的交易。这些每周轮换，一次只有一个生效。许多大秘境词缀，如强韧或残暴，只是给钥石添加一个被动效果，只有这四个例外是本赛季以萨拉塔斯为主题的：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将刷新三波球体，需要打断或制止。[[spell:46968]]在这里效果极佳，不过紧急情况下也可以使用[[spell:5246]]。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：一个虚空大使小怪会带着护盾刷新，需要集火，这使它成为配合[[spell:1271948]]使用[[spell:384110]]的完美目标。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：球体将在玩家周围刷新并绕着他们转。你有15秒的时间吸收所有这些球体来为你的队伍提供增益。使用[[spell:12323]]可以帮助队伍更快地到达这些球体，不过要小心互相绕圈跑！
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有队伍成员都会受到一个治疗吸收效果的影响，该效果还会降低移动速度，使用[[spell:1271925]]可以立即移除整个效果。否则，可以使用[[spell:202168]]、治疗药水或治疗石来帮助清除吸收效果。

每一种词缀在被处理后都会提供一组不同的增益效果，虽然它们非常强大，但你不需要以特定的方式围绕它们进行操作。最重要的是不要让任何词缀强化敌方小怪或首领。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 更新了12.1补丁的配置推荐。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月10日：** 澄清了关于天赋选择的解释。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 标记了推荐配置，并针对11.0.7补丁进行了验证。
- **2024年10月21日：** 更新了地下城词缀推荐。
- **2024年9月9日：** 为地心之战第1赛季的上线进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 对简介进行了小幅更新。
- **2024年4月22日：** 为第4赛季更新了循环。
- **2024年3月19日：** 对推荐天赋进行了小幅更新，并为10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁和第3赛季进行了更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月12日：** 小幅格式更新。
- **2023年7月10日：** 为10.1.5补丁进行了更新，包括碎颅者的备选配置。
- **2023年5月1日：** 为10.1补丁进行了审查。
- **2023年2月2日：** 更新了剑刃风暴天赋配置。
- **2023年1月24日：** 10.0.5补丁已更新构筑。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到许多有用的宏和插件，以便在《魔兽世界》12.1.5补丁中使用你的武器战士时让游戏更加轻松。

1.

### 最佳宏

战士通常不需要太多宏就能有效操作，尽管有几个宏可以作为非常好的生活质量改进，例如自动设置目标圈和减少多余按键。

随着天赋配装系统为每套天赋创建独立的动作条，根据当前点出的天赋来切换技能的宏需求大大减少。话虽如此，[known:######]条件仍然可以实现这一点，使用已点天赋的法术名称或ID来确定显示哪个技能。

像胜利在望和即将胜利这样直接互相替换的技能，无论宏中命名的是哪个技能，都会继续正常工作。

1.1.

#### 战士通用宏

#### 巨神兵粉碎与天神下凡

```wow-macro
#showtooltip
/cast 天神下凡
/cast 巨人打击
```

这个简单的宏会同时使用[[spell:107574]]和[[spell:167105]]，不过它可以与任何其他占用GCD的技能组合使用。但请记住，多个占用GCD的技能在没有非常明确的逻辑判断时是无法组合的。

#### 拳击宏

```wow-macro
#showtooltip 拳击
/cast [@focus, harm, exists][@target] 拳击
```

这个宏会对你有焦点目标时对焦点目标使用[[spell:6552]]，没有焦点目标时则对当前目标使用。

#### 在剑刃风暴和破坏者之间切换

```wow-macro
#showtooltip
/cast [@player, known:破坏者] 破坏者; [known:剑刃风暴] 剑刃风暴
```

这将在[[spell:227847]]和[[spell:228920]]之间切换，取决于当前点出的是哪个天赋。

#### 自动英勇飞跃

```wow-macro
#showtooltip 英勇飞跃
/cast [@cursor] 英勇飞跃
```

这会在你鼠标光标所在的位置施放[[spell:6544]]，无需等待选择地面目标圈。

#### 英勇飞跃连按

```wow-macro
#showtooltip 英勇飞跃
/cast !英勇飞跃
```

这允许你连续点击[[spell:6544]]按钮，而不会清除地面目标圈。

#### 冲锋和胜利在望

```wow-macro
#showtooltip
/cast 冲锋
/cast 乘胜追击
/cancelaura 剑刃风暴
```

因为冲锋不占用公共冷却时间，胜利在望或任何其他近战技能可以使用相同的快捷键。在近战范围之外时，将施放冲锋。这个宏还会取消剑刃风暴，以确保玩家不会被阻止快速移动。

#### 姿态切换

```wow-macro
#showtooltip
/cast [stance:2]!防御姿态;[known:386164]!战斗姿态;[known:386196]!狂暴姿态
```

这允许你使用相同的快捷键在[[spell:386164]]和[[spell:386208]]之间切换。

1.2.

#### 武器战士专用宏

#### 配合巨神兵粉碎

```wow-macro
#showtooltip 巨人打击
/use 巨人打击
/use 血性狂怒
/use 狂暴
/use 13
/use 14
```

这个宏会与[[spell:167105]]一起使用不占用公共冷却时间的种族技能和任何已装备的饰品。

1.

### 最佳插件

2.1.

#### 战士通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

看看在不使用任何额外插件的情况下你能走多远甚至可能是值得的，也许你甚至会喜欢不必在每个补丁上花费数小时更新和重新配置你的界面。许多插件仍在开发中，或者专门旨在为至暗之夜上线时提供所有选项，因此你的一些最爱可能还不可用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.4.4.

##### Omen 仇恨统计

[Omen 仇恨统计](<https://www.curseforge.com/wow/addons/omen-threat-meter>)
是显示当前目标仇恨水平最流行的插件。我们建议你使用它，以避免在坦克仍在对敌人建立仇恨时抢到仇恨。

2.5.

#### 武器战士专用插件

目前，我们不认为需要任何额外的插件来充分发挥武器战士的潜力，不过有大量界面插件可供选择，以帮助为框架、动作条等创建更好的布局。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月15日：** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
