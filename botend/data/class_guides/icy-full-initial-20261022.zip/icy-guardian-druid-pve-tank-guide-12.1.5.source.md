## 专精概览

Welcome to our Guardian Druid guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to tank as a Guardian Druid in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your survivability.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Guardian Mythic+ Resources

[NEW! Top Guardian Talent Builds](<https://raider.io/specs/guardian-druid/talents>)

[Top Guardian Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/druid/guardian>)

[Guardian Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=druid--guardian>)

[Popular Guardian Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=druid--guardian>)

1.

### Guardian Druid Overview

[Guardian Druid](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-guide>) is a sturdy tank that manages damage intake with
strong passive reductions, a large health pool, increased healing 
from Mastery, and a stackable active mitigation with [[spell:192081]].
They are an excellent sponge tank. Once you have acquired enough gear, they
are mostly self-sufficient with a unique playstyle, unlike any other class.
They bring some utility to raid and Mythic+ groups as a tank and very high DPS.

Guardian Druid tends to excel against encounters where most incoming damage
is Physical or Melee damage.

This guide focuses specifically on Guardian Druid. As such, the more general
aspects of tanking will not be covered here. If you would like to learn more about
tanking in general, we recommend you read our
[tanking guide](<https://www.icy-veins.com/wow/tanking-guide>).

Powerful in all scenarios

Guardian Druid has a very flexible damage profile, with a powerful 2-3 minute
cooldown that is great on both AoE and single-target and overall quite high
sustained damage output.

Performs Fantastically

Guardian Druid is a solid pick for any raid environment, thanks to its
incredible survivability, raid buff in

[[spell:1126]]

and overall raid
utility.
It is one of the most flexible tanks, capable of handling most mechanics with
ease. Guardian does suffer from a lack of burst damage if it has no time to
ramp up our DoT's beforehand which can be relevant on some encounters but rare.

Consistently Strong

Guardian is fantastic in Midnight Mythic+, having consistently high AoE damage
and extremely strong self-sustain in addition to some of the best group
healing tools any tank can offer their group.

Feels Useful

Guardian has access to a few different utility spells, like

[[spell:1126]]

,

[[spell:106898]]

,

[[spell:371905]]

,

[[spell:99]]

and

[[spell:372119]]

to name a couple. A Guardian makes use of all their
utility feels like a real asset to the team, always impactful and helpful.

Extremely Durable

Guardian is a tank and quite a tanky tank at that. We are flexible, able to mitigate
all damage types effectively and consistently. Short cooldowns such as

[[spell:22812]]

and

[[spell:22842]]

allow us to comfortably mitigate damage and
maintain our health pool without the need for a healer in most scenarios.

Fast and Flexible

Guardian has solid mobility, however it generally requires a target to

[[spell:102401]]

to,
whereas things like

[[spell:6544]]

or

[[spell:109132]]

can be aimed anywhere.
On the plus side, while you are not actively tanking you can comfortably shift forms and make up
great distances quickly in

[[spell:783]]

or

[[spell:768]]

.

2.

### Guardian Druid in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 offers no meaningful changes to Guardian Druid.
The main focus of the patch are 2 new pieces of endgame content instead, one for Raid groups, and one
for [Delves](<https://www.icy-veins.com/wow/delves-guide>). Make sure to check out both the information on the new Kith'ix Raid encounter,
as well as the new exciting Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
a Trinket, Ring, and Chest. Additionally, you will be able to upgrade items with 
[[item:280562]] starting October 20th. Weapons, Necks, and Trinkets can all 
be upgraded.

2.3.

#### Class Changes

There are no changes to the Guardian Druid spec itself in Patch 12.1.5, but there 
will be changes to the Overall and Raid-based gear recommendations on our 
[gear](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>) page. We also have a list of 
high-value items to spend your first [[item:280562]] on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_druid_bearhug.jpg>)Click for Previous Season 2 Changes
2.4.

#### Class Changes

Guardian had a complete Apex talent rework in Patch 12.1 alongside a few talent
changes.

- [[spell:429539]] - Now reduces the cooldown of [[spell:204066]] by a flat 20 seconds.
  This is to remove the [[spell:8921]] spam playstyle.
- [[spell:29166]] - Now causes the healer to regenerate 20% of their max mana over 8 seconds instead of making casts free for 8 seconds.
- [[spell:200854]] - Now grants [[spell:192081]] a chance to make your next [[spell:6807]]/[[spell:400254]]/[[spell:441605]] free. 
  Also grants your [[spell:6807]]/[[spell:400254]]/[[spell:441605]] a chance to make your next [[spell:192081]] free.
- +8% Aura buff - Free damage, always good.

Apex rework:

1. [[spell:1269614]] - is now a 10% chance to summon a guardian spirit for 8 seconds which attacks nearby enemies when you cast [[spell:77758]] or [[spell:33917]].
2. [[spell:1269617]] - has added [[spell:33917]] to the DoT.
3. [[spell:1269619]] - when a guardian spirit is awakened your cooldown on [[spell:77758]] and [[spell:33917]] are reset and they deal 30% more damage while the spirit is active.

:::

### Midnight   Changes Overview

2.5.

#### Hero Talent Changes

The only real Hero talent change Guardian receieved in Patch 12.1 is the 
rework of [[spell:429539]] to a flat 20 second reduction on [[spell:204066]].

2.6.

#### Survivability Changes

With the removal and rework of several talents, guardian survivability has 
shifted slightly, however it mostly remains the same as Season 1 with slightly
less uptime on [[spell:204066]] being the only real difference.

2.6.1.

##### Utility Changes and New Talents

Guardian has not received any new talents in Patch 12.1 but the significant 
rework of [[spell:200854]] has added something new to track and be concious of.

2.7.

#### Guardian Druid Apex Talents in Midnight

The newly reworked (as of 12.1) Apex Talents for Guardian Druid revolve heavily around [[spell:77758]] and [[spell:33917]].

1. [[spell:1269614]] - Spending rage has a 10% chance to awakene a guardian spirit 
   for 8 seconds, which attacks nearby enemies when you cast [[spell:77758]] or [[spell:33917]].
2. [[spell:1269617]] - Mastery increased. [[spell:33917]] and [[spell:6807]]/[[spell:400254]] are now always
   empowered and deal extra Nature damage over 12 seconds.
3. [[spell:1269619]] - When a spirit is awakened, the cooldowns of [[spell:77758]] and [[spell:33917]] 
   are reset and they deal 30% increased damage while the spirit is active. Each time the spirit attacks you generate 8 rage.
   After casting [[spell:394786]], gain 1 charge of Wild Guardian, which 
   causes your next [[spell:6807]]/[[spell:400254]]/[[spell:441605]] to always awaken one spirit.

3.

### Basics of Playing a Guardian Druid

Being one of the tank specializations, your main goal, first and foremost, is
to stay alive and to ensure that you have aggro on all of the enemies so that
they are not on your weaker party/raid members.
To tank efficiently as a Guardian Druid, your goal is to spread as many
[[spell:8921]]s as possible, then generate as much Rage with spells like [[spell:33917]] and
[[spell:77758]]. This Rage can be spent defensively, with [[spell:192081]] and
[[spell:22842]], or offensively, with [[spell:6807]].
A breakdown of the main focal points of Guardian Druid can be gleaned through the following list.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_stoneclawtotem.jpg>) **Survivability First**  
  
    A dead tank is often a wipe for the group or the raid. Maximizing your DPS is 
    extremely valuable for tanks, especially on cutting edge content, but prioritizing 
    your personal survivability is the most integral part of tanking. This can 
    often mean kiting in certain scenarios (m+ primarily) where you are out of cooldowns.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_ancestralguardian.jpg>) **Never Waste Rage**  
  
    Rage is incredibly useful and powerful for Guardian, we want to make sure we 
    always spend it wisely as it comes in.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_druid_thrash.jpg>) **Cycle Cooldowns Effectively**  
   
    Guardian has a lot of short cooldowns that should be constantly cycled through
    for both maximum damage and defensiveness.

4.

### How to Gear Up as a Guardian Druid

While we always recommend simming yourself for ideal results, we do provide a
dedicated Guardian gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Added Venomstone section and updated ilvl on gear.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated easy raid build and easy m+ build.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **08 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Added Kithix items.
- **01 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated M+ Tier original pieces.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated FAQ blocks.
- **15 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Talent Updates.
- **12 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated Voidcore list and BiS List.
- **12 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Talent Update.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Talent updates.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated gear from dungeon notes.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Added tier set link.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated notes for talents and folio.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Changed easy build to EC.
- **10 Aug. 2026 (this page):** Updated Basic and changes list.
- **09 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Added Apex rage note and removed moonfire filler note.
- **08 Aug. 2026 (this page):** Added notes for 12.1 changes.
- **03 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.1.
- **03 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **03 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Patch 12.1.
- **03 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Patch 12.1.
- **03 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **20 May 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Added new EC builds.
- **20 May 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated both Easy builds.
- **23 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Updated Addon list and Macros.
- **23 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated stat explanations.
- **23 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Added DoTC Note.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **10 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated talent builds.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Removed Bloodmallet and old trinket list.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Midnight Season 1 Launch.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Added affixes.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Added intros to openers.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Midnight Season 1 Launch.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Added tuning Bluepost and moved Midnight Changes section.
- **14 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **14 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **13 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1 Launch.
- **13 Mar. 2026 (this page):** Updated for Midnight Season 1 Launch.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Midnight Launch.
- **26 Feb. 2026 (this page):** Updated for Midnight Launch.
- **12 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for 12.0.1 level gating.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated Talents for new 12.0.1 level gates.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated Talents for new 12.0.1 level gates.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Added FAQ block. Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Added FAQ block. Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Added FAQ block. Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated Strengths and Weaknesses. Reviewed for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Removed Congratulations sections.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated Gear Lists for 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Added Corruption Section.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Added 11.1.5 change section.
- **24 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated builds plus hero talent fix.
- **19 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-liberation-of-undermine-raid-guide>)):** Updated Mythic Boss Tips.
- **01 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated Tier set in M+ tab.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-liberation-of-undermine-raid-guide>)):** Guide added.
- **18 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated Cyrces Circlet suggestions and added to bis lists.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Added Cyrces Circlet section for Patch 11.0.5.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Added and Updated Recommended Builds.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated Builds and Rotation for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-nerub-ar-palace-raid-guide>)):** Updated boss tips and added Mythic tips.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Added Dungeon specific tips.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Added Patch 11.0.5 update notes.
- **17 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated trinket and gear list post buffs and nerfs.
- **17 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-nerub-ar-palace-raid-guide>)):** Updated Boss tips and added Ansurek tips.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Season 1 TWW Launch.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated Fury of Nature note.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Season 1 TWW Launch.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated TNC from 15% to 12%.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated easy M+ build.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **07 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Season 1 TWW Launch.
- **25 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Added 2 Delve Builds and updated M+/AoE Build.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for the War Within Launch.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for TWW Launch.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/guardian-druid-mists-of-pandaria-remix-guide>)):** Updated talent builds for TWW tree changes.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for the War Within.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for TWW pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for TWW pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for TWW pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for TWW pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for TWW pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for TWW pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for TWW pre-patch.
- **23 Jul. 2024 (this page):** Updated for TWW Pre-patch.
- **18 Jun. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/guardian-druid-mists-of-pandaria-remix-guide>)):** Adjusted gems.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/guardian-druid-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/guardian-druid-mists-of-pandaria-remix-guide>)):** Page added.
- **09 May 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated Gear list.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **23 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated Raze link.
- **23 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated M+ build and intro notes.
- **23 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated Tier set notes.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Removed broken DoC macro.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **25 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.6
- **20 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Reviewed and Updated for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed and Updated for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed and Updated for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for 10.2.5.
- **23 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated Trinket List.
- **21 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated BiS Lists.
- **21 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated M+ talent build.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated BiS lists for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Added new healing potion for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated Notes for Season 3.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Removed Patch 10.1.7 items to update for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated Blood Frenzy note for target cap and rage increase from 2 to 3.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Added new BiS Lists Gear block.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated M+ build and Season 2 note on meta.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Added rotation info block.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Added new Talent Template Block and Updated Talents.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated Ursocs Fury note to 45%, IR to 120% and PotP to 5%.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated talent trees.
- **04 Sep. 2023 (this page):** Added 10.1.7 note.
- **25 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated Borrowed Time link.
- **25 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Added additional Multi target notes.
- **25 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated talent builds.
- **25 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated Ursocs Fury note to 50%.
- **12 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Added High damage M+ build and fixed Raze link.
- **12 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Fixed Raze link.
- **12 Jul. 2023 (this page):** Fixed Raze link.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Updated for Patch 10.1.5. Added DoC Macro.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **26 May 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Added timewalking gear.
- **26 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Added Incorporeal note.
- **18 May 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated trinket list.
- **06 May 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated BiS list after trinket tuning.
- **06 May 2023 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated Enchants and Consumables after tuning changes.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated new trinkets and gear for patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Added Shadowflame Wreathe weapon enchant and updated Primordial stone gem note for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated info for 10.1 and removed thundering.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated and added new talent builds for 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated spells for patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated Beginner talent builds for 10.1.
- **01 May 2023 (this page):** Updated for 10.1.
- **28 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Updated for 10.1, removed old addons.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated Primordial Stone Gems recommendations.
- **24 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated talent tree strings.
- **24 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated talent tree strings.
- **24 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated talent tree strings.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Patch 10.0.7.24 Jan. 2023: Reviewed for Patch 10.0.5.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/guardian-druid-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for 10.0.7.
- **11 Feb. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated talent builds after bugfixes.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **13 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Added Embellishment section.
- **21 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated M+ Build.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/guardian-druid-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/guardian-druid-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/guardian-druid-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/guardian-druid-patch-9-2-changes-analysis>)):** Page reviewed and approved for the launch of Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/guardian-druid-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/guardian-druid-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **28 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/guardian-druid-patch-9-1-changes-analysis>)):** Updated with Covenant-specific Legendaries.
- **02 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/guardian-druid-patch-9-1-changes-analysis>)):** Page created with initial information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **14 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-crucible-of-storms-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-the-eternal-palace-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **01 Oct. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-the-eternal-palace-raid-guide>)):** Edited talent trees and essences for all bosses.
- **19 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-the-eternal-palace-raid-guide>)):** Added several more tips for bosses based on post-launch observations and experience.
- **07 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **13 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-crucible-of-storms-raid-guide>)):** Reviewed tips and talents after raid release.
- **14 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-battle-of-dazar-alor-raid-guide>)):** Updated for the Crucible of Storms raid.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-crucible-of-storms-raid-guide>)):** Guide added.
- **20 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-battle-of-dazar-alor-raid-guide>)):** Added Battle of Dazar'alor guide for Guardian Druids.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** Updated for Patch 8.1.
- **13 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** Updated all bosses with information after Heroic week.
- **11 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** Page added.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Guardian Druid leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Druid leveling guide](<https://www.icy-veins.com/wow/druid-leveling-guide>).

1.

### Guardian Druid Leveling Guide for Midnight

Guardian Druid, thanks to being a tanking spec, our leveling 
options are plentiful. If you would like to spam dungeons to level, tank queues
are often the fastest. If you would like to level solo, grouping up targets
and AoEing them down works perfectly for us. We are also fantastic in a group, as 
DPS love to have someone gather and tank the mobs for them.

1.1.

#### Leveling Gear Options

Item level is always more important than individual stats when leveling up. Always
choose the piece of gear with the highest item level. Items with Speed tertiary
stats can help speed up your leveling, especially during parts of extended time
spent indoors. Heirloom gear is also useful while leveling, allowing you to ignore a lot
of gearing for a large part of your leveling journey.

1.2.

#### Useful Leveling Items for Midnight

Here are some useful items that might assist you in leveling faster in Midnight.

- [[item:132516]]
- [[item:243191]]/[[item:224572]]
- [[item:109076]]
- [[item:122128]]
- [[item:63359]] / [[item:64398]] / [[item:64402]]

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Guardian Druid Level 80 Midnight Leveling
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwYMWMbzMPgZZZAbGGNRzMzyMzMzYMDAAAAAADbzAW2mZwYWGATAAAAbYMALmBDGssNAAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwMjZWMbmxMWGwmhRT0MzsMzMzMLjZAAAAAAYMbzAW2mZwYWGATAAAAbYmBYxMYwYzCAzMAG"
}
```
:::

:::details 来源计算器编码
```
#oB-TTBfUNh0iSA64UUqsslV8otVT7F2qc8F7pH-BAgCcxiGccE7tsoJNp6gkhiHNIdKUUX-AAAA-HSAIgYQUcIYDzC-
```

:::

2.1.

#### War Mode Talents for Leveling

In this section, we will highlight the most useful War Mode PvP talents to 
speed up your leveling process.

- [[spell:201664]] — Demoralizes all enemies within 10 yards,
  reducing the damage they do by 20% for 8 seconds. Great to further reduce 
  damage taken on big pulls.
- [[spell:202246]] — Charge to an enemy, stunning them for 3 seconds and 
  knocking back their allies within 15 yards. Just another charge adding 
  more mobility to your toolkit, allowing you to speed up levelling even more.
- [[spell:329042]] — Causes you to enter a deep slumber for 8 seconds.
  While sleeping, all other cooldowns recover 400% faster. This is great, as it 
  massively reduces the cooldown of every ability. Try to use it when not getting attacked,
  as damage will break the slumber effect.

3.

### Leveling Rotation

To help with understanding what changes as you level up and progress through 
the talent tree, use the slider below to select your current level. Each time you 
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–9：**Due to Guardian being unlocked as a talent
specialization at Level 10, you should make use of the abilities provided
to you in the intro quests until you are presented with the option.

- **等级 9 起：**Buff yourself with [[spell:1126]].
- **等级 8 起：**Enter [[spell:5487]].
- **等级 2 起：**Maintain [[spell:8921]] on the target.
- **等级 10 起：**Use [[spell:22812]] on cooldown.
- **等级 17 起：**Use [[spell:50334]] on cooldown, ideally
  against multiple enemies.
- **等级 10 起：**Cast [[spell:77758]] on cooldown.
- **等级 8 起：**Cast [[spell:33917]] on cooldown on 4 targets
  or fewer.
- **等级 11 起：**Fill downtime with [[spell:213764]].
- **等级 11 起：**Spend Rage offensively against a single target
  with [[spell:6807]].
- **等级 18 起：**Spend Rage defensively with [[spell:192081]].
- **等级 10 起：**Use [[spell:22842]] if your
  health gets below 50%.
- **等级 8 起：**Make sure to always be in [[spell:5487]]
  while in combat.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **12 Feb. 2026:** Updated for 12.0.1 level gating.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Removed Congratulations sections.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for the War Within Launch.
- **23 Jul. 2024:** Updated for the War Within.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **25 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.24 Jan. 2023: Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Guardian Druid in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Guardian Druid

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Guardian Druids reduce incoming damage through their active mitigation
[[spell:192081]]. Ironfur has a negligible cooldown and can stack, making
it strong against incoming Physical damage and melee attacks. Their
self-heal, [[spell:22842]], while not as strong as some other
tank classes, provides a decent boost to self-sustain. Their combination of both
short and long-cooldown defensive abilities helps them deal with Magic damage
effectively.

In terms of utility, Guardians bring [[spell:106898]], a raid-wide
movement speed boost, which is very powerful for many encounters where group-wide
movement is a necessity. Guardians can also resurrect allies in Combat with
[[spell:20484]] and will occasionally pulse an AoE heal around them with
[[spell:371905]].

The primary goal of a Guardian is to stay alive, using the tools at your
disposal. This means generating and spending Rage on active mitigation, 
self-healing, and effectively using your defensive cooldowns to survive
dangerous incoming damage. While keeping this all in mind, the secondary goal should be to deal damage; this is
important to maintain a threat on your target and contribute to killing
bosses faster. Luckily, this does not require much extra effort on your behalf
— if you are performing your rotation well defensively, your damage will
reflect that.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_stoneclawtotem.jpg>) **Survivability First**  
  
    A dead tank is often a wipe for the group or the raid. Maximizing your DPS is 
    extremely valuable for tanks, especially on cutting edge content, but prioritizing 
    your personal survivability is the most integral part of tanking. This can 
    often mean kiting in certain scenarios (m+ primarily) where you are out of cooldowns.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_ancestralguardian.jpg>) **Never Waste Rage**  
  
    Rage is incredibly useful and powerful for Guardian, we want to make sure we 
    always spend it wisely as it comes in.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_druid_thrash.jpg>) **Cycle Cooldowns Effectively**  
   
    Guardian has a lot of short cooldowns that should be constantly cycled through
    for both maximum damage and defensiveness.

2.

### Beginner's Guide to Guardian Druid in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen   Raiding Talents

2.1.

#### Beginner Raiding Talents

This is a great beginner raiding build. It is a very simplified version of Bear
where you primarily spend your rage on [[spell:192081]] and [[spell:22842]].

Use the calculator's 'Export Talents' to easily copy the build
in-game.

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZWMLmhZZZgZDGNRzMzyMzMzYMjBAAAAAYGbzAW2mZwY2GATAAAAbGzMALmBDYxiBYmBwA"
}
```
:::

:::details 来源计算器编码
```
#oB-TTBfUNh0iSA64UUqsslVstlYlVWTL+1FGZK-BACbcxiGWWSccERSTiXVGKqHNIIdGKMB-AAAA-RGKaMSOysEEAhA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen   AoE Talents

2.2.

#### Beginner Delves and Mythic+ Talents

This build ramps up the arcane talents and focuses on consistently
generating massive healing via [[spell:377210]] and [[spell:77758]].
We also pick up some extra CC in [[spell:132469]] and [[spell:102793]].

Use the calculator's 'Export Talents' to easily copy the build
in-game.

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMzMjZWMLGmZZZgZzwoJyMzyMzMzsMmBAAAAAgZmNDYZbmBjZZAMBAAAshZGgFzgBsYBgZGAD"
}
```
:::

:::details 来源计算器编码
```
#oB-TTBfUNh0iA64UUqsslVst9gYNWTTm1zrrTM-BACcjGwWWk4t54IKJDF11DFDIHakaQKA-AAAA-RGKaMSOwsEEAhA-
```

:::

### Guardian Druid   Basic Rotation

2.3.

#### Beginner Guardian Druid Rotation

1. Keep [[spell:8921]] up.
2. Use [[spell:77758]] as often as possible.
3. Use [[spell:33917]] as often as possible.
4. Spend rage on [[spell:192081]] defensively or to avoid rage cap.
5. Use [[spell:6807]]/[[spell:400254]] offensively.
6. Use [[spell:213764]] as the lowest priority last resort button if you have
   nothing else to press.

This rotation maximizes Rage generation while maintaining reasonable
damage.

2.4.

#### Tier Set for Guardian Druid

The Guardian Druid tier set is essentially completely passive and does not 
need to be played around at all. 
The 2p bonus grants [[spell:77758]] a chance to make your next [[spell:33917]] 
deal 100% more damage.
4p bonus causes [[spell:77758]] to summon 3 thorns that impale targets
dealing extra damage and extends our [[spell:394786]] by up to 5 seconds max.

2.4.1.

##### Cooldowns

Guardians have three baseline cooldowns.

- [[spell:22812]] reduces all damage you take by 20% for 12 seconds on
  a 60-second cooldown. Barkskin is usable while stunned, incapacitated, or
  asleep.
  This will be your first line of defense against dangerous spike damage and your
  primary way of reducing magic damage or simply as risk mitigation to
  smooth your damage intake for your healers. It has a short cooldown, so use it
  often.
- [[spell:61336]] reduces all damage you take by 50% for 6
  seconds. Survival Instincts has two charges and a 3-minute recharge time. This is
  your major defensive reduction, to be used against lethal spike damage or
  "tankbuster" mechanics. Its short duration and long cooldown mean it should
  be used sparingly.
- [[spell:50334]] reduces the cooldown on [[spell:33917]],
  [[spell:77758]] and [[spell:6795]] by 50%.

2.4.2.

##### Apex Talent: ![Wild Guardian Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_meta_emeralddream.jpg>) Wild Guardian

The Apex talents for Guardian do have a slight impact on rotation, with 
the most simplistic rule being, try not to spend rage right before 
[[spell:77758]] or [[spell:33917]] are about to come off cooldown ideally.
This is because spending rage has a chance to cause their cooldowns to reset.

### Guardian Druid   Defensive Spells

2.5.

#### Active Mitigation/Defensive Spells for Guardian Druid

By executing your rotation, you will generate Rage. You can
spend Rage in one of three ways: on your active mitigation spell
[[spell:192081]], on your self-heal [[spell:22842]], or on
a hard-hitting attack [[spell:6807]].

Deciding how to spend Rage can be boiled down to a few simple situations. If
you are taking Physical damage or melee attacks, use [[spell:192081]]. If you
are at low health or expect to be brought to low health, use
[[spell:22842]]. If you are not in danger of either, use
[[spell:6807]].

[[spell:192081]] is unique in that multiple spell applications
can overlap, meaning you can simultaneously have two or more "stacks" of Ironfur. You
can also pool Rage to spend on numerous stacks for dangerous moments in a fight.
Keep in mind that every application has an independent duration, so adding a
stack will not refresh the duration on other stacks.

[[spell:22842]] heals you for a percentage of your maximum
health over a short period. If you are talented into [[spell:1278789]], Frenzied
Regeneration overhealing grants us an absorb shield, this can be really handy walking into a pack.

[[spell:6807]] should only be used when you are either not actively
tanking or when you are taking so little damage that using [[spell:192081]]
will not reduce your need for healing or increase your chances of living.

### Guardian Druid   Stat Priority

2.6.

#### Guardian Druid Stat Priorities

You will want to prioritize **item level over all else**, as Armor,
Stamina and Agility are far more valuable than any secondary stats.
On jewelry and other slots with no primary stats, you will prefer
secondary stats in the following order.

For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>).

Haste

Versatility

Critical Strike

Mastery

### Blizzard   Combat Assistant

2.7.

#### Combat Assistant for Guardian Druid

This is a new feature introduced in Patch 11.1.7 which is oriented at helping
 new players with their rotations. While this feature can be useful for some
 it is generally around a 40% DPS loss to solely follow it for Guardian. Also
 as a tank, it does not have much emphasis on the importance of proper defensive
 usage. Use this tool at your own discretion, but it would be extremely
 suboptimal currently to follow it blindly.

[Combat Assistant Guide](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>)

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated easy raid build and easy m+ build.
- **10 Aug. 2026:** Changed easy build to EC.
- **03 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 May 2026:** Updated both Easy builds.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated Talents for new 12.0.1 level gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated Builds and Rotation for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated easy M+ build.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for TWW pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed and Updated for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated talent trees.
- **12 Jul. 2023:** Fixed Raze link.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated Beginner talent builds for 10.1.
- **24 Mar. 2023:** Updated talent tree strings.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Guardian Druid in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Talents for Guardian Druid in Midnight

For Season 2 in Midnight, Guardian will have a variety of 
different playstyles due to consistently large and impactful tuning in recent patch changes.
While there are a lot of potential options available on the tree, our current recommendations are as
follows:

- **Single-Target/Raid -** Following 12.1 changes, both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen 
    and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw perform very close to each other in single-target across
    all Season 2 Raid encounters.
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw offers a slightly burstier profile, while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen 
    offers more sustained damage with mildly better defensive options.
- **AoE/Mythic+ -** In Patch 12.1, both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen 
    are extremely even at all keystone levels. We generally recommend ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen in all scenarios,
    due to it's simpler nature and slightly more flexible profile.

Both hero talent trees are performing very close to each other in all content.
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw has a slightly higher top end ceiling with good RNG, and 
offers stronger consistent mitigation. We generally recommend playing this 
if you have a good fundamental understanding of Guardian.
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen is perfectly viable if that is your personal preference 
and you shouldn't notice a significant performance difference between the two.

**Quick Start Import Codes:**

:::talents Guardian Single Target - Druid of the Claw
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwYMzmZZGMLLDMbwoJamZWmZmZGjZMDAAAAAYGLzAAAAgmZZWmZmBAwCmZAWMDGwmFDAmZDG"
}
```
:::

:::talents Guardian AoE - Elunes Chosen
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZml5BmZMziZxwMLLDMbGGNRmZWmZmZmlxMGAAAAAgZsYAbbzMYMLDgJAAAgNMzAsYGMgNLAMzAYA"
}
```
:::

:::talents Guardian Delves - Elunes Chosen
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwMjZWMLGmZZZgZzwoJyMzyMzMzsMmxAAAAAAMjlZALbzMYMLDgJAAAgNMzAsYGMgNLAMzAYA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Druid of the Claw

Raid/Single-Target

recommended

AoE/Mythic+

Elune's Chosen

Raid/Single-Target

recommended

AoE/Mythic+

recommended

Delves

### 天赋方案 0-0

1.1.

#### Single-Target Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw

This build is great for single-target situations and has higher burst DPS
compared to Elune's Chosen but offers similar overall DPS.

### 天赋方案 0-1

1.2.

#### Multi-Target & Mythic+ Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw

This is a strong build for burst AoE scenarios.

This is build prioritizes the massive amount of absorbs generated from [[spell:77758]] and
[[spell:400254]] combined with the [[spell:377210]] talent. Playstyle and rotation remain the same.

### 天赋方案 1-0

1.3.

#### Single-Target Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

This build works well for mostly single-target situations.

### 天赋方案 1-1

1.4.

#### Multi-Target & Mythic+ Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

This is our recommended build for AoE scenarios. Primarily for Mythic+.

This is build prioritizes the massive amount of healing and absorbs generated from
[[spell:77758]].

### 天赋方案 1-2

1.5.

#### Delve Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

Delves are content which you can engage with solo or with up to
five friends (and the help of a follower!). They are very short ~3-15
minute scenarios, and as a Guardian Druid, you'll be able to
bypass some of the stages almost entirely thanks to being able to
[[spell:5215]] to objectives instead of having to fight.
We also have a dedicated page to learn everything about [Delves](<https://www.icy-veins.com/wow/delves-guide>).

Surviving can be tough in these for non-tank players in your group,
as the enemies hit hard, especially when you are undergeared and your follower's
heals aren't that strong just yet. That's why this talent build takes multiple
off-healing talents so you can help your group survive comfortably. Remember that there is no time limit, so you are free
to wait for cooldowns or heal up to full HP, and most enemies are kitable.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxs4BGjZ2MLzgZZZgZDGNRzMzyMzMzYMjZAAAAAAzYZGAAAA0MLzyMzMAAWwMDwiZwA2ssNAYmNYA"
}
```
:::

:::details 来源计算器编码
```
#oB-NBfTTU0hKKiAIqss1y1lVsdVTLW+6FGbpEJ-BACc2wiGWWccEnoRSiXmnNdIGooMnKXA-AAAA-QUEYCSMaO4owCB-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMmZMziZZGmZZZgZzwoJamZWmZmZmlxMAAAAAAMzsMDAAAAamlZZmZGAALYmHAYxMYAbWAAzsBD"
}
```
:::

:::details 来源计算器编码
```
#oB-NBfTTU0hKKiAIqss1y1lVcVTLW+6FrnzDJM-BACc2wiGWWccEnoR6QiXmHNdGKUooumA-AAAA-QUEYCSMaO4owCB-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGLzA2WmZwY2GATAAAAbYmBYxMYAbW2GgZGAD"
}
```
:::

:::details 来源计算器编码
```
#oB-NBfTTU0hKKiAIqss1y1lVsdVTLW+6FGbpEJ-BACc2wiGWWccEnoRSiXmnNdIGooKXgYC-AAAA-RGKaYOmYQAMwiA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZml5BmZMziZxwMLLDMbGGNRzMzyMzMzsMmBAAAAAgZmFDYbbmBjZbAMBAAAshZeAgFzgBsZBgZGAD"
}
```
:::

:::details 来源计算器编码
```
#oB-NBfTTU0hKKiAIqss1y1lVcVTLW+6FrnzDJM-BACc2wiGWWccEnoR6QiXmHNGKUoouIQA-AAAA-RGKaYOmYQAM4iA-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwMjZWMLGmZZZgZDmpJyMzyMzMzsMmBAAAAAgZmlZALbzMYMbDgJAAAgNMzAsYGMgNLAMzAYA"
}
```
:::

:::details 来源计算器编码
```
#oB-LNBfTTU0hKKiAIqss1y1lVsdVTLW+6FGrnT-BACc2wiGWWccEnoR6QiXmHNdIGKUoouA-AAAA-RGKaYOmYQAI4iA-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend you pick the following bonuses in Season 2, but as you
can freely switch between them at any time, feel free to experiment with other options
yourself if you feel you do not get enough mileage out of the recommended options:

- Point 1:[[spell:1279599]]
- Point 2:[[spell:1279603]]
- Point 3:[[spell:1287555]]
- Point 4:[[spell:1279613]]
- Point 5:[[spell:1279614]]

3.

### Apex Talent: ![Wild Guardian Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_meta_emeralddream.jpg>) Wild Guardian

1. [[spell:1269614]]
2. [[spell:1269617]]
3. [[spell:1269619]]

The Apex talents for Guardian Druid revolve heavily around [[spell:77758]] and [[spell:33917]], essentially
adding a 12 second DoT that you can maintain permanently by casting [[spell:6807]] or [[spell:33917]]
at least once every 12 seconds. This doesn't really affect or change our rotation
at all, as we generally have plenty of excess rage that we are already
dumping into [[spell:6807]] and we use [[spell:33917]] rotationally.

3.1.

#### Hero Talents

Both of our Hero Talent Trees are fantastic and viable in both Mythic+ and 
Raid alike. Starting at Level 71, Guardian Druid will gain access to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw and 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen.

3.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw revolves heavily around the [[spell:6807]] replacement,
 [[spell:441605]], which is an extremely hard hitting ability that 
leaves a big DoT. Thematically, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw aims to buff our
physical and bleed damage. It excels on pulls in Mythic+ where you 
have [[spell:394786]] available, as a heavy majority of it's damage 
is tied to cooldowns.
It also can deal incredibly high single-target damage to bosses, which makes 
it fantastic for Raiding.

3.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen has the power of an empowered [[spell:204066]].
This ability is often up at the start of a pull, 
which helps generate aggro quickly and keeps you relatively safe while you
start to ramp. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen also scales incredibly well the more targets
you pull, as your [[spell:8921]]'s spread rapidly and your self healing ramps
quickly with both [[spell:377210]] and [[spell:370586]].

4.

### PvP Talents (War Mode)

The Battle for Azeroth expansion introduced a new system called "War Mode."
Opting into War Mode makes you eligible for open-world PvP but also grants you
the following benefits:

- World Quests at a maximum level have 10-30% increased rewards.
- You gain 10-30% increased experience while leveling.
- Allows you to earn Conquest Points towards weekly gear rewards.
- Grants you the use of PvP talents in the open-world.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended that you enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself eligible for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

Below are the recommended PvP talents for leveling and doing PvE
content. You will get a choice of one general PvP talent and three spec-specific
talents.

1. [[spell:202246]] is a powerful charge with a stun, and the knockback it
   triggers provides a large mobility boost.
2. [[spell:329042]] Enter a deep sleep for 8 seconds that makes all
   other cooldowns recover 400% faster.
3. [[spell:201664]] reduces damage enemies deal to you by 20% for 10
   seconds.
4. [[spell:207017]] replaces [[spell:6795]], an ability that
   historically has no function in solo content. In exchange, you (and your allies)
   deal increased damage to the target you taunt.
5. [[spell:236147]] increases your [[spell:783]]
   movement speed by 20% and prevents you from being slowed below 100% movement
   speed. This improves your mobility and will reduce travel time, which is
   important while leveling.

The remaining PvP talents may have limited or niche applications in
leveling or open-world PvE content, but they do not provide the overall 
benefit of the recommended list above. The rest of the PvP talents do 
not contribute meaningfully to leveling or open world PvE.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **15 Aug. 2026:** Talent Updates.
- **12 Aug. 2026:** Talent updates.
- **10 Aug. 2026:** Updated notes for talents and folio.
- **03 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 May 2026:** Added new EC builds.
- **23 Apr. 2026:** Added DoTC Note.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **10 Apr. 2026:** Updated talent builds.
- **16 Mar. 2026:** Updated for Midnight Season 1 Launch.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated Talents for new 12.0.1 level gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Mar. 2025:** Updated builds plus hero talent fix.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Added and Updated Recommended Builds.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for Season 1 TWW Launch.
- **25 Aug. 2024:** Added 2 Delve Builds and updated M+/AoE Build.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for TWW pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **21 Nov. 2023:** Updated M+ talent build.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Added new Talent Template Block and Updated Talents.
- **25 Jul. 2023:** Updated talent builds.
- **12 Jul. 2023:** Added High damage M+ build and fixed Raze link.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated and added new talent builds for 10.1.
- **24 Mar. 2023:** Updated talent tree strings.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **11 Feb. 2023:** Updated talent builds after bugfixes.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Guardian Druid, depending on the type of damage you will be tanking.
We also have advanced sections about cooldowns, procs, etc. in order to maximize your
survivability and DPS. All our content is updated for World of Warcraft Patch
12.1.5.

1.

### Guardian Druid Gameplay and Rotation Guide

Welcome to our Rotation page for Guardian Druids. On this page, you will be
able to find everything that you need to know about playing the spec in
Raiding and Mythic+ content.

Each of the sections below explain the rotation for different environments.
Click the boxes to switch to the desired situation.

:::details FAQShould I Play Defensively or Offensively?
This is the main question most people will ask with tanking. The basic
answer is that if you are progressing or are on a character you do not
feel comfortable playing offensively with, you should play defensively. As you
get comfortable, you should start looking at DPS more and playing a
more mixed style, pushing DPS while slowly giving up
survivability.

Once you feel completely comfortable with the encounter and
will not hold your raid back, you can go for DPS. This point is different
for every person, as it depends on your group, your character, your gear, and
your skill level.

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw

Druid of the Claw - Single Target

Druid of the Claw - AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

Elunes Chosen - Single Target

Elunes Chosen - AoE

Active Talents

Passive Talents

[[spell:391528]]

[[spell:394786]]

[[spell:400254]]

[[spell:1253799]]

[[spell:1252871]]

[[spell:372567]]

[[spell:1269619]]

[[spell:400278]]

[[spell:377210]]

[[spell:370586]]

[[spell:1253461]]

[[spell:203953]]

[[spell:393427]]

[[spell:158477]]

[[spell:1253035]]

[[spell:1252994]]

### Guardian Single Target

Guardian single target revolves around maintaining the best uptime you can on [[spell:1252871]] (which replaces [[spell:8921]]) by utilizing [[spell:33917]] as frequently as possible, in addition to maintaining maximum stacks of [[spell:77758]] and using [[spell:400254]]/[[spell:263857]] at above 80 rage as often as possible. Using these above 80 rage is for the [[spell:1253035]] talent which has a massively increased chance to proc [[spell:210706]] which resets our [[spell:33917]] cooldown.

1. Cast [[spell:77758]] on cooldown
2. Cast [[spell:33917]] on cooldown
3. Cast [[spell:204066]] on cooldown (ideally aligned with [[spell:1252871]] if close)
4. Cast [[spell:1252871]] on cooldown
5. Cast [[spell:1261867]] in [[spell:768]]
6. Cast [[spell:394786]]
7. Spend rage on either [[spell:400254]] (offensively) or [[spell:192081]] (defensively)
8. Cast [[spell:213764]]

### Guardian AoE

Guardian AoE is extremely similar rotationally to single target except we no longer have to worry about [[spell:1252871]] as we take [[spell:372567]] instead.

1. Cast [[spell:77758]] on cooldown
2. Cast [[spell:33917]] on cooldown
3. Cast [[spell:204066]] on cooldown
4. Cast [[spell:1261867]] in [[spell:768]] on bosses or in [[spell:197625]] for AoE pulls.
5. Cast [[spell:394786]]
6. Spend rage on either [[spell:400254]] (offensively) or [[spell:192081]] (defensively)
7. Cast [[spell:8921]] or [[spell:213764]] as filler

2.

### Midnight Season 2 Tier Set

Season 2 of Midnight introduces the **Bark of the Enigmatic Dreamwatcher**,
available from different endgame content. This provides the following bonuses:

- [[spell:1296607]] — [[spell:77758]] has a 
  	20% chance to make your next [[spell:33917]] deal 100% increased damage.
- [[spell:1296608]] — [[spell:77758]] calls 
  	up to 3 thorns, each impaling a target for Nature damage. Also extends
  	the duration of [[spell:394786]] by 5 seconds.

The Guardian Druid tier set is entirely passive and naturally buffs our 
regular rotation.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Guardian Druid
kit, we have compiled a more detailed explanation on individual parts of our rotation, from
important rotational mechanics that you need to pay attention to, to cooldowns and how to use them.

### Ironfur

3.1.

#### Ironfur

[[spell:192081]] increases your Armor by 112% of your Agility for 7
seconds. Multiple applications of Ironfur may overlap and stack their Armor
increases, but their durations will not stack. For example, if you use Ironfur
and then use it again 3 seconds later, you will have two applications of Ironfur
for 4 seconds, granting you 224% of your Agility as Armor. After 4 seconds, the
first application will have expired, leaving you with 112% of your Agility as
Armor for 3 more seconds. Agility buffs and procs increase the amount of Armor
you gain from Ironfur.

Armor is extremely effective at reducing Physical damage intake, 
so having at least one stack of [[spell:192081]] up as often as possible
is recommended. Additionally, you will occasionally want to pool your Rage to
put up multiple stacks of Ironfur for a short period to deal
with a spike in damage. There is a hard limit to how much Armor can reduce your
incoming damage by, at 85%. This is around 7-8 (3-4 with an Aug voker) stacks of [[spell:192081]] and
can generally be achieved on 5-10 targets or inside of [[spell:394786]].

Armor does **not** normally reduce Bleed damage (typically, this is
presented in-game as a "Physical DoT") or Magic damage. However, there are
exceptions to these rules, which appear on a case-by-case basis. When faced with
Bleed or Magic damage, you will find [[spell:192081]] ineffective and should
instead use your defensive cooldowns to reduce the damage or a well-timed
[[spell:22842]] to heal yourself. Remember that if you are
tanking a boss, you are almost always taking auto-attacks and other
damage sources. Auto-attacks are Physical, so it is still worth
maintaining [[spell:192081]] on most encounters.

Finally, consider your situation carefully before using 
[[spell:192081]]. Since it is proactive, no matter how low
on health you have been brought, using it if there is no new incoming damage
is pointless.

### Rage Generation

3.2.

#### Rage Generation

Guardian Druid's primary resource is Rage.

The Rage bar has a maximum capacity of 100 and is empty by default. Rage
decays quickly out of combat. In combat, Rage does not decay.

Rage is generated in the following ways:

- Activating [[spell:5487]] grants you 25 Rage (leaving Bear Form
  empties the Rage bar).
- Auto-attacks generate 4 Rage.
- Being auto-attacked generates 3 Rage (can only occur once every
  second).
- [[spell:33917]] generates 10 Rage (+4 with a [[spell:210706]] proc and
  +5 with [[spell:158477]]).
- [[spell:77758]] generates 5 Rage.
- [[spell:8921]] with a [[spell:203964]] proc generates 8
  Rage.
- [[spell:155835]] generates 1 Rage per % of max health taken in
  damage while active.
- [[spell:203962]] generates 2 Rage every time a
  [[spell:77758]] bleed ticks on any target (Thrash ticks once every
  3 seconds, reduced by Haste).
- [[spell:1269619]] generates 8 rage each time the spirit deals damage.

### Cat/Ripweaving

3.3.

#### Catweaving/Ripweaving

As of Midnight, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw Catweaving is a DPS LOSS. Until
we see any changes/buffs or nerfs, you do not need to worry about weaving anything
other than shifting into [[spell:768]] every 2 minutes to cast [[spell:319454]], 
which is a massive DoT applied to a single target and definitely worth using 
if safe in Single Target.

Ripweaving is where you gain a buff once you cast [[spell:33917]] six times 
with the [[spell:441691]] talent that empowers your next
[[spell:1079]] and [[spell:22568]] and generates max combo points upon 
entering [[spell:768]].
You shift into [[spell:768]] by using [[spell:1822]] in [[spell:5487]], 
due to the [[spell:449193]] talent, you will instantly be shifted into Cat.
You are then able to apply this empowered [[spell:1079]] and shift straight back
into [[spell:5487]] by casting [[spell:33917]] whilst in [[spell:768]].
This is an extremely safe version of Catweaving and has very little impact on your 
survivability. You are even able to utilize this while tanking a boss actively
due to the [[spell:441678]] talent that retains [[spell:192081]] in Cat.

Make sure that you do not shift to Cat too soon after casting [[spell:33917]]
as it can be on cooldown, delaying your ability to shift back to bear quickly.

Catweaving is an advanced topic and significantly complicates the Rotation. It is not
recommended for those who are just picking up Guardian Druid or when you are
learning a new fight. That being said, when done correctly, it can be a significant
DPS increase over staying in Bear Form single-target (depending on tuning).

### Apex Talents

3.4.

#### Apex Talents for Guardian Druid

1. [[spell:1269614]]
2. [[spell:1269617]]
3. [[spell:1269619]]

The Apex talents for Guardian Druid revolve heavily around [[spell:77758]] and [[spell:33917]], essentially
adding a 12 second DoT that you can maintain permanently by casting [[spell:6807]] or [[spell:33917]]
at least once every 12 seconds. This doesn't really affect or change our rotation
at all, as we generally have plenty of excess rage that we are already
dumping into [[spell:6807]] and we naturally use [[spell:33917]] rotationally frequently.
One thing to note is, to optimize the apex, you want to try not to spend rage right
before the cooldown of [[spell:77758]] or [[spell:33917]] is about to come 
back up. This is because spending rage has a chance to reset the cooldown of
both your [[spell:77758]] and [[spell:33917]].

4.

### Important Cooldowns for Guardian Druid

Guardian Druid is a primarily proactive tank. You must be prepared with
active mitigation and defensive cooldowns before you take damage. This is in
contrast to reactive tanks, which first take the damage and then react to it by
healing themselves up.

As such, preparation plays a large part in tanking effectively. Wise use of
cooldowns and coordination with your healers is critical and can be the
difference between a boss kill and a wipe. The best way to prepare for an
encounter is to look at the damage profile of the fight (either from a log or
by reading the Dungeon Journal) and plan out what cooldowns you will use,
when you will use them, and whether any gaps need to be covered by healer
external defensives.

You have two baseline defensive cooldowns and a few more that you
can talent into. Unless you are sure you will die otherwise, it is
not advised to overlap your defensive cooldowns, as spending them that way is often overkill and
wasteful.

### [[spell:394786]]

4.1.

#### Incarnation: Guardian of Ursoc

[[spell:394786]] is our main cooldown, available every 2-3 minutes
(depending on rage spent and talents). It grants increased health and reduced 
cooldown on [[spell:77758]] and [[spell:33917]]. It also makes [[spell:33917]] hit 3 targets.

You can opt to save this as a defensive cooldown in some situations if you are 
expecting significant danger upcoming but generally is best used off cooldown as an
offensive CD.

### [[spell:22812]]

4.2.

#### Barkskin

[[spell:22812]] is a 40-60s cooldown that we want to use on CD as much as possible.
It deals damage with the [[spell:203953]] talent and reduces our damage significantly.
This helps smooth our damage intake in general and survive big hits.

### [[spell:61336]]

4.3.

#### Survival Instincts

[[spell:61336]] is our biggest defensive. Midnight gave us 2 charges
baseline so planning these is even easier. Generally saved for very dangerous 
damage intake or huge hits.

4.4.

#### Pre-Combat Checklist for Maximum DPS

- Ensure that you have eaten appropriate Food according to
  [our Consumables page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>).
- Ensure you have your appropriate Flask buff from our
  [our Consumables page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>).
- Ensure your Weapon has its temporary enchant from our [our Consumables page](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>).
- Activate your [[item:259085]], if you can spare the Gold!

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Added tier set link.
- **09 Aug. 2026:** Added Apex rage note and removed moonfire filler note.
- **03 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Added intros to openers.
- **13 Mar. 2026:** Updated for Midnight Season 1 Launch.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Added FAQ block. Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for TWW pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **23 Apr. 2024:** Updated Tier set notes.
- **22 Apr. 2024:** Reviewed for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Removed Patch 10.1.7 items to update for Patch 10.2.
- **04 Sep. 2023:** Added rotation info block.
- **25 Jul. 2023:** Added additional Multi target notes.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Guardian Druid in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Guardian Druid

Welcome to our Guardian Druid Gear page for 
Midnight Season 2. Check this page to learn everything 
you need to know about gearing a Guardian Druid, including the 
BiS Gear from all sources, Raiding, and Mythic+, information on the best 
Trinkets, Tier Sets, and much more.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Guardian Druid. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details TipsWhich Slots Do I Want Tier Set In?
With the

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

inheriting the secondary stats and special effects of the original item, players now have massive flexibility in acquiring tier pieces with ideal stats

**in all five**

slots. assuming that you are

**both**

raiding and running Mythic+ as necessary, catalyze the following gear:

- Helmet: [[item:271875]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:251223]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Chest: [[item:251159]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Gloves: [[item:251124]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs: [[item:268225]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details FAQWhat Do I Pick From the Great Vault?
The [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) has up to nine slots of items you can choose from every week, based on what content you have done on your character. This also impacts the item levels of each slot, with ![Mythic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-mythic.png>)Mythic raid bosses awarding fully upgraded Myth track gear! However, this wide variety of potential item levels also makes it hard to provide blanket recommendations. In addition, players may instead select either a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) or Tokens of Merit that can be exchanged for a [[item:275707]]. The power of these alternatives should not be underestimated, even if they may feel a bit "boring" in comparison.

Although you should always simulate your options in a given vault's rewards (including the value of an extra socket on pieces you'll keep for the rest of the season), here is a basic priority to follow on selecting rewards:

1. (First Vault only) claim Tokens of Merit for a [[item:275707]] or a piece of your tier set if available.
2. If you will be raiding the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) on at least **![Heroic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-heroic.png>)Heroic**, select a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) to bonus roll items from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>). Do so until you have obtained at least a Heroic-track [[item:268215]].
3. Choose the highest reward track items that can complete your tier set.
4. Select the highest item level pieces with Haste, those from the best-in-slot lists below, or additional [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s/[[item:275707]]s depending on your character's goals.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271875@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAG2wYNTpC]]&#10;&#10;<div>[[item:240983]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:281236@JAACAAQ42A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAACAAwt1A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268215@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup from all sources for Guardian Druid. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In two slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking and add an embellishment.

:::details FAQWhich Tier Set Pieces Do I Want?
Any combination of 4 tier pieces works for Guardian Druid, as we want a balanced stat priority overall. Long-term you will ideally want to play a specific cantrip head piece ([[item:271875]]) from [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2, you also retain the secondary stats and any other potential passive effects like damage procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear, but if that is not possible, it is not a big deal either. It is better to have the set with slightly suboptimal stats and fix it later into the season, than missing out on the bonus for another week or two. Some optimal stat items to catalyze are:

- Helmet: [[item:273791]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Shoulders: [[item:251223]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Chest: [[item:251159]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Gloves: [[item:251124]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs: [[item:251130]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): Your best on-use dungeon trinket drops here: [[item:273796]].
- [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>): Has the most amount of useful items.
- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): Drops your best weapon.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:251173@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Waist</th><td>[[item:244573@JAACAAgNyA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Feet</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAgV1A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAACAAgNyA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250228@JAACAAgV1A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:158370@JAACAAgV1A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup from all sources for Guardian Druid. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In two slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking and add an embellishment.

:::details FAQWhich Tier Set Pieces Do I Want?
Any combination of 4 tier pieces works for Guardian Druid, as we want a balanced stat priority overall.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2, you also retain the secondary stats and any other potential passive effects like damage procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear, but if that is not possible, it is not a big deal either. It is better to have the set with slightly suboptimal stats and fix it later into the season, than missing out on the bonus for another week or two. Some optimal stat items to catalyze are:

- Helmet: [[item:271875]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:268246]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Chest: [[item:268235]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- Gloves: We want these from the token
- Legs: [[item:268225]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:268215]]: This weapon drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), the final boss of the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>), and is your BiS weapon. Only a few specializations can equip it, allowing you to potentially avoid crafting a weapon. What's more, when bonus rolled on Heroic with a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>), this item will drop in its Myth-track variant; on Mythic, it will instead be "elevated" with an additional 10 item levels.
- [[item:268265]]: This necklace from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) is unique in many ways, being purely statted with Critical Strike, a second socket, and two cantrip effects that further empower your player.
- [[item:270175]]: A potent on-use trinket from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) that not only provides static Critical Strike, but also on-demand Agility and a bit of extra Physical damage.
- [[item:270173]]: Relatively passive trinket but offers the most DPS for us out of all the trinkets available.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271875@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:281236@JAACAAQ42A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAACAAAG2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268215@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Guardian Druid

There are a great number of Trinkets available for Guardian, and we generally want
  to play a combination of a powerful on-use trinket like [[item:270175]] or [[item:270168]],
  and a passive trinket providing potent secondary stat buffs or raw damage procs.

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Guardian Druid Trinkets**
**On-Use -**

[[item:270175]]

or, alternatively,

[[item:270168]]

**Passive -**

[[item:270164]]

or, alternatively,

[[item:270173]]

:::

There are quite a few other valuable trinkets out there, so make sure to click on our
  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Guardian Druid Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Guardian </th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270168]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:270165]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159617]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:270160]]</li>&#10;<li>[[item:273797]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250244]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:250243]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:270174]]</li>&#10;<li>[[item:250225]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159618]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:158374]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Patch 12.1 continues the bonus roll system that was initially introduced in Patch
12.0.7. Notably, bonus rolling on a Heroic raid boss will grant you the item at 1/6 Myth
track, so you can acquire some of the later raid gear quite early, as long as you commit
additional crests to upgrade it.

- [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) can be used to target items from specific bosses
    or dungeons, by letting you bonus roll a guaranteed piece of loot from a specific drop-location.
    Which item you will receive is random, but once an item has been acquired in this way,
    your next use of a Voidcore will grant one of the remaining items you haven't yet acquired.
- [[item:280562]] can be used to greatly increase the itemlevel of Hero or Myth
    track items if they have reached the highest possible itemlevel already, as 
    well as Crafted items at max quality. This will further boost their power.
    This only works on Weapons, Trinkets, and Necklaces.

3.1.

#### Nebulous Voidcore (Bonus Rolls) Usage for Guardian Druid

Which item you want to chase after depends heavily on the items you have already acquired
  through i.e. the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), or whether you expect to defeat certain bosses on
  Mythic difficulty regularly, as you do not want to waste your Voidcores on items you may be able to
  get on a higher difficulty track in a few weeks.

3.2.

#### Recommended Nebulous Voidcore Usage for Guardian Druid

Due to the wide variety of loot a player may have been offered over time by the
[Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) in particular, it is difficult to provide simple recommendations
for where to spend one's [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s. However, due to these voidcores
rolling against the entire loot table of a dungeon or raid encounter, some locations
are a more effective use than others for your most convenient power gains. In
particular, items from the **Heroic** [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) and [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
encounters will be obtained as Myth-track items when rolled!

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) ([[item:268215]]/[[item:270175]]/[[item:268265]])
2. [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) ([[item:270173]]/[[item:268225]]/[[item:268256]])
   [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) (has plenty of great items for us and some ideal pieces for the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>))
   Remaining BiS List items

:::

3.3.

#### Ascendant Venomstones

Following the release of Patch 12.1.5, you can now acquire [[item:280562]],
allowing you to upgrade specific item slots all the way up to item level 340 (or
338 for crafted pieces). Using these follows a similar priority to your crest
usage:

1. **Weapon** first, upgrading a crafted or mythic weapon early is a huge power boost.
2. **On-Use Trinket** second, ideally [[item:270175@JAACAAgNyA]] 
     but any S tier trinket is a good choice.
3. **Passive Trinket** third.
4. **Necklace** last.

You also want to prioritize Myth track items over Hero track pieces, unless you
don't expect to acquire a Myth track variant of the piece you're upgrading.

4.

### Best Crafted Items for Guardian Druid

You may only have two **embellishments**, present on equipped crafted gear at a time.

Guardian generally prefers to craft low stat budget, flexible items that can
easily be swapped to another embellishment at will. To find out more about
professions and crafting in general, below is a link to the dedicated professions overview page.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Guardian Crafted Gear Priority**
- [[item:245771]] with [[item:245876]]
- [[item:244576]]/[[item:244569]] with [[item:240167]]
- Any item you do not have on Myth track yet.

:::

- The [[item:245771]] with the [[item:245876]] embellishment
  is a great initial craft. Although not permanently BiS due to the cantrip weapon off Ula'tek.
- [[item:244576]] and [[item:244569]] have the least conflicting gear issues.
  Applying a simple proc embellishment like [[item:240167]] to these makes them quite competitive.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

5.

### Crest Usage

You will be able to upgrade your items via Crests. Once you have upgraded a slot to a certain item 
level, [ upgrading other items](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) of that slot to that item level is free.

When you upgrade with Crests, you should think of it as upgrading **slots** and not items.

Below is the slot priority you should upgrade your items in. If you ever want to deviate 
from this, you should have a very good reason.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Guardian Druid Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Added Venomstone section and updated ilvl on gear.
- **08 Oct. 2026:** Added Kithix items.
- **01 Sep. 2026:** Updated M+ Tier original pieces.
- **15 Aug. 2026:** Updated FAQ blocks.
- **12 Aug. 2026:** Updated Voidcore list and BiS List.
- **10 Aug. 2026:** Updated gear from dungeon notes.
- **03 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Removed Bloodmallet and old trinket list.
- **14 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Added FAQ block. Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated Gear Lists for 11.1.5.
- **01 Mar. 2025:** Updated Tier set in M+ tab.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **18 Dec. 2024:** Updated Cyrces Circlet suggestions and added to bis lists.
- **15 Dec. 2024:** Added Cyrces Circlet section for Patch 11.0.5.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **17 Sep. 2024:** Updated trinket and gear list post buffs and nerfs.
- **09 Sep. 2024:** Updated for Season 1 TWW Launch.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for TWW pre-patch.
- **09 May 2024:** Updated Gear list.
- **07 May 2024:** Reviewed for 10.2.7.
- **23 Apr. 2024:** Updated Raze link.
- **22 Apr. 2024:** Updated for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed and Updated for Patch 10.2.5.
- **23 Nov. 2023:** Updated Trinket List.
- **21 Nov. 2023:** Updated BiS Lists.
- **06 Nov. 2023:** Updated BiS lists for Patch 10.2.
- **04 Sep. 2023:** Added new BiS Lists Gear block.
- **25 Jul. 2023:** Updated Borrowed Time link.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **26 May 2023:** Added timewalking gear.
- **18 May 2023:** Updated trinket list.
- **06 May 2023:** Updated BiS list after trinket tuning.
- **01 May 2023:** Updated new trinkets and gear for patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **13 Jan. 2023:** Added Embellishment section.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Guardian Druid. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Guardian Druid Stat Priority

The stat priority for a Guardian Druid differs depending on whether you are
aiming for survivability or damage output.

Regardless of what you are prioritizing, an item 10 or more item levels above
another will almost always be an upgrade due to the sheer increase in stats.

1.1.

#### Survivability

Item Level

Haste

Versatility

Mastery

Critical Strike

Armor, Agility, and Stamina are grouped together because they typically
appear together on gear, but any one of the "main" stats will
be stronger point-for-point than secondary stats.

1.2.

#### Damage Output

Haste

Versatility

Critical Strike

Mastery

It is important to note that all secondary stats are very close together in
value. This is a rough estimation, as your stat order might slightly differ
depending on how much of each stat you currently have. Agility is also very
important for damage output and will often make the highest item level piece
the best one to choose. If you want a truly accurate evaluation of which stats
are best for you, you should sim your character for stat weights.

2.

### In-Depth Stat Breakdown

**Agility** is your primary stat. It increases your Attack Power, grants you
a small amount of Dodge, and converts into Armor due to [[spell:192081]].

**Armor** reduces the Physical damage you take. Guardians gain increased Armor
(and Stamina) from [[spell:5487]].

**Versatility** reduces your damage taken, increases your damage and healing
done.

**Mastery** ([[spell:155783]]) increases your maximum health
and your healing received. It also increases your Attack Power.

**Haste** does many things for Guardian. It increases your melee attack speed,
increases the rate at which [[spell:77758]] and [[spell:8921]]
(and bleeds such as [[spell:1822]] and
[[spell:1079]]) tick, reduces the global cooldown, and reduces the cooldown on
[[spell:33917]], [[spell:77758]], and
[[spell:22842]].

**Critical Strike** increases your chance to critically strike (dealing double damage)
and increases dodge chance.

:::details FAQWhat stats Should I Have as a Guardian Druid?
Simply put, stats for Guardian are all extremely close in terms of power and
should be treated evenly.
There are no breakpoints or anything to aim for; just acquire as much item level
as possible. People lean towards haste and vers as they are the best "feeling"
stats. If you are aiming to maximize your DPS, you should always sim your
character for best results.

:::

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 Apr. 2026:** Updated stat explanations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Added FAQ block. Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Guardian Druid, based on your [stat priority](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

The best stats for raiding are Haste and Versatility, so that is what we will be
gemming for. You should use [[item:240983]] in one socket, and the
rest of your gems can be [[item:240893]].

The best stats for Mythic+ are Haste and Versatility as well, so the same gems will
be best in that content type.

<em>We highly recommend using Raidbots to sim your character's
ideal gems and enchants though, as they might differ from our general
recommendations.</em>

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243973]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243963]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243981]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;<li>[[item:243974]] (Less DPS, more movement speed)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;<li>[[item:244643]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

You should be drinking [[item:241325]] at all times.

3.2.

#### Potions

Your stat potion should be [[item:241308]]. Use these when you will 
do the most damage with your abilities, likely during your cooldowns and/or 
[[spell:2825]]/[[spell:32182]].

You should keep a stock of [[item:271883]]'s to use when at 
low health, and if you have a Warlock in the group, grab their 
[[item:5512]]s and use them as well. Do not macro these together, they 
are best used separately!

3.3.

#### Food Buff

Either [[item:255845]] or [[item:255846]] are your best
food buffs, providing you not only with primary or secondary stats, but also with Stamina,
which will only be available from these feasts.

Make sure to carry a few [[item:242275]] as well, in case no feast is
available to you.

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s 
to increase your primary stat. Augment Runes are expensive and disappear on death, 
so use them wisely and sparingly!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1 Launch.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Added Corruption Section.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for TWW pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Added new healing potion for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **06 May 2023:** Updated Enchants and Consumables after tuning changes.
- **01 May 2023:** Added Shadowflame Wreathe weapon enchant and updated Primordial stone gem note for Patch 10.1.
- **24 Mar. 2023:** Updated Primordial Stone Gems recommendations.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Guardian Druid in World of Warcraft Patch 12.1.5.

1.

### Guardian Druid in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Guardian in
Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Guardian Druid specializes in reducing physical damage taken and smoothing damage intake.
Our AoE is exceptionally strong, and the more mobs we pull, the stronger we are.
Guardian heads into Season 2 of Midnight as quite a strong contender amongst
other tanks. We are one of the highest DPS tanks in Mythic+ and can pump out
massive amounts of group healing with excellent defensive capabilities to match.
Our unique utility tools, such as
[[spell:371905]], [[spell:1126]], [[spell:2782]], and [[spell:20484]] are
extremely valuable within dungeons.

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen Mythic+ Build

2.1.

#### Recommended ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen Talents

Both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen are viable for **High Mythic+ Pushing**.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen represents a simpler and easier-to-start-with rotation compared to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw.
[[spell:204066]] offers a very strong cooldown that can be used extremely frequently. We also gain a significant
amount of self-healing from [[spell:429523]] which makes [[spell:77758]] arcane.

Overall, this build excels in very AoE-heavy dungeons, especially where you are able to do large pulls.

2.2.

#### Flexible Talents

- [[spell:370695]] can be a flexible point.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwMjZWMLmxMWGY2MMaimZmlZmZmZZMDAAAAAADLzAW2mZwYWGATAAAAbGz8AALmBDGbWAYmBwA"
}
```
:::

:::details 来源计算器编码
```
#oB-Bf0UTTNhKKVAEl64atsldUkYl1jmW8rLM5U-BACgciwGWW0kkQqy74RnBlrCEKKHHxN-AAAA-RGKaYOkYQAI4iA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw Mythic+ Build

2.3.

#### Recommended ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw can offer great overall damage reduction and burst damage AoE damage in addition to the ability to
deal slightly higher single target dps if required.

Overall, this build excels in dungeons where pulls are smaller, such as 3-5 mobs, and where bosses pose a more significant challenge.

2.4.

#### Flexible Talents

- [[spell:370695]] can be a flexible point or 2.

Our talent tree is quite flexible and has multiple different options depending on your playstyle, preferences, and situation.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMmZMziZZmxMWGY2MMaimZmlZmZmZZMDAAAAAAzYZGAAAA0MLzyMzMAAWMm5BAWMDGwmFAwMbwA"
}
```
:::

:::details 来源计算器编码
```
#oB-Bf0UTTNhKKVAEl64atsldUkYl1jmW8rLM5U-BACciwGWW0kkQqy74RnBlrCKKHHxNbT-AAAA-QUEYaakEM4owCB-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts

[[spell:106839]] interrupts spell casts and prevents spells from the
same school from being cast again for 4 seconds. Skull Bash has a 13-yard range,
and casting it from out of melee range will cause you to charge into melee
range to interrupt. Note that although the charge animation has travel time,
the interrupt happens when you use the spell. It is **highly recommended** to use a Focus Kick macro for this.

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Skull Bash
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

3.2.

#### Stunning and "Stops"

[[spell:99]] is your "AoE stop". This will immediately disorient
all targets around you. It can be great for stopping casters, but keep in mind they
will generally recast right after.

[[spell:102793]] can be used to keep mobs from running around or from being
knocked away.

[[spell:132469]] can be used as an additional stop; it will knock enemies back which can be
disruptive, so it should be a last resort. It can be used in combination with
[[spell:102793]] to keep the mobs in relatively the same place.

### Other Utility

3.3.

#### Other Utility

[[spell:2782]] removes all harmful curse and poison debuffs from
the target. Many dungeons apply these types of effects, and being able to
dispel them is a great piece of utility.

[[spell:2908]] will remove all enrage effects on a single enemy.

[[spell:339]] can root patrolling enemies to
prevent them from entering combat with you or to skip them entirely. Casting
it will cancel [[spell:5487]], however, so do not cast it while you are
actively tanking.

[[spell:20484]] resurrects dead allies in combat. This costs 30 Rage,
but it can be handy if your healer dies during an encounter.

[[spell:8936]] is a single target heal. Casting it will cancel
[[spell:5487]].

[[spell:106898]] is mainly used indoors or during combat for short bursts of movement speed.
It is generally used for kiting or going from one pack
to the next, but it is also useful for speeding your friends out of dangerous
ground mechanics.

[[spell:371905]] This talent causes a massive burst of
healing in an AoE around you every 300 rage you spend.

[[spell:372119]] This talent enables you to do a massive single target
heal on any group member of your choice every 20-30 seconds.

4.

### Dealing with Affixes

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Guardian Druid

**Xalatath's Bargain: Ascendant** will periodically spawn a number or orbs in
waves that need to be crowd-controlled in some way, before they complete a cast.
Each orb successfully stopped provides the group bonus Haste, so it is a high
priority to deal with.

Guardian can make use of [[spell:99]] and [[spell:132469]],
which when aimed correctly can remove a huge number of orbs when they start
spawning.

### Affix: Voidbound

4.2.

#### Voidbound Affix Management for Guardian Druid

**Xalatath's Bargain: Voidbound** will periodically summon a large Void
Emissary that will begin to cast [[spell:462508]]. This enemy **must** be
killed before the cast completes to stop it, otherwise it provides significant
damage reduction to nearby enemies. If successfully stopped, the group is granted
a large amount of Versatility and cooldown reduction.

This needs to be killed off quickly, so prioritize hitting it when it is up.
As a tank, we generally need to save our offensive cooldowns for pulls, but if 
your group is having issue with this monster you can send them here too to help.

### Affix: Pulsar

4.3.

#### Pulsar Affix Management for Guardian Druid

**Xalatath's Bargain: Pulsar** spawns an orb that orbits each player, which
needs to be soaked by a separate player before they expire. Each orb will grant
the party 4% Mastery and 2% Leech, stacking, with a 30-second duration. Unsoaked
orbs will increase nearby enemies' damage done, and reduce their damage taken.

Guardian can use [[spell:106898]] to help you and your group collect these 
quickly.

### Affix: Devour

4.4.

#### Devour Affix Management for Guardian Druid

**Xalatath's Bargain: Devour** applies a debuff to each party member, that
must be either dispelled or healed off (though bear in mind this <em>does not</em>
absorb incoming heals). Each debuff dispelled provides the group with maximum
health and Critical Strike, stacking, for 30 seconds. Any debuffs <em>not</em>
cleared will heal nearby enemies a large amount.

We always have [[spell:2782]] talented and this can be used to 
dispel one or two of your group members. Shapeshifting out of
[[spell:5487]] will also remove it, as a small slow has been added to the effect
in Midnight.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **12 Aug. 2026:** Talent Update.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Added affixes.
- **14 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Added Dungeon specific tips.
- **09 Sep. 2024:** Updated Fury of Nature note.
- **07 Sep. 2024:** Updated for Season 1 TWW Launch.
- **07 May 2024:** Reviewed for 10.2.7.
- **23 Apr. 2024:** Updated M+ build and intro notes.
- **22 Apr. 2024:** Reviewed for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated Notes for Season 3.
- **04 Sep. 2023:** Updated M+ build and Season 2 note on meta.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **26 May 2023:** Added Incorporeal note.
- **01 May 2023:** Updated info for 10.1 and removed thundering.
- **24 Mar. 2023:** Updated talent tree strings.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **21 Dec. 2022:** Updated M+ Build.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Guardian Druid in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Listed below are the most useful Macros to use when playing Guardian Druid.

1.1.

#### Rebirth

#### Rebirth Macro

```wow-macro
#showtooltip Rebirth
/cast [@mouseover,help]Rebirth;Rebirth
```

This macro casts [[spell:20484]] on your mouseover target, if they are a
friendly player. Otherwise, it casts Rebirth on your current target.

1.2.

#### Remove Corruption

#### Remove Corruption Macro

```wow-macro
#showtooltip Remove Corruption
/cast [target=mouseover,help,nodead][target=target] Remove Corruption
```

Using this macro will cast [[spell:2782]] on your mouseover
target, if they are a friendly player and they are not dead. Otherwise, it
will cast Remove Corruption.

1.3.

#### Blessing of Protection Cancelaura Macro

#### Cancelaura Blessing of Protection Macro

```wow-macro
#showtooltip Thrash
/cancelaura Blessing of Protection
/cast Thrash
```

This macro is handy to have. It allows you to cancel a
[[spell:1022]] that may have been cast on you, allowing you
to resume your attacks. It is also important because, while you are under the
effect of Blessing of Protection, mobs will not attack you and instead will just
attack the next person the aggro list (usually a DPS player).
Macroing this into multiple abilities is recommended.

1.4.

#### Useful Mouseover Macros

Here are a few macros that allow you to cast some of your spells on your
mouseover target.

#### Skull Bash Macro

```wow-macro
#showtooltip Skull Bash
/cast [@mouseover,harm,nodead]Skull Bash;Skull Bash
```

#### Growl Macro

```wow-macro
#showtooltip Growl
/cast [@mouseover,harm,nodead]Growl;Growl
```

#### Moonfire Macro

```wow-macro
#showtooltip Moonfire
/cast [@mouseover,harm,nodead]Moonfire;Moonfire
```

#### Remove Corruption Macro

```wow-macro
#showtooltip Remove Corruption
/cast [@mouseover,help]Remove Corruption;Remove Corruption
```

2.

### Best Addons

Blizzard has done a solid job at making the game incredibly accessible and functional
without addons, so there are no recommended Addons at this time.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 Apr. 2026:** Updated Addon list and Macros.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for TWW pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Removed broken DoC macro.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5. Added DoC Macro.
- **28 Apr. 2023:** Updated for 10.1, removed old addons.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
