## 专精概览

Welcome to our Holy Paladin guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to heal as a Holy Paladin in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your output.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Holy Mythic+ Resources

[NEW! Top Holy Talent Builds](<https://raider.io/specs/holy-paladin/talents>)

[Top Holy Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/paladin/holy>)

[Holy Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=paladin--holy>)

[Popular Holy Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=paladin--holy>)

1.

### Holy Paladin Overview

Holy Paladins specialize in very strong single-target healing, being
one of the few healers that can truly impact whether a single player will
live or die at any given moment. They also possess several tools that
help them mitigate or avoid damage, both on themselves and on other raid
embers, such as [[spell:1022]] and [[spell:465]].
With so much utility, they are consistently one of the strongest specs in
every form of content and have been that way for years.

Mediocre

Holy Paladin has struggled to compete with other healers in terms of healing
output for quite a few expansions now. While they received numerous buffs
during Patch 12.1, they still have struggled to keep up in raids compared to
other healers. That being said, Holy Paladin does offer exceptional single-target
healing through

[[spell:20473]]

,

[[spell:19750]]

,

[[spell:82326]]

and

[[spell:85673]]

. This allows it to be one of the strongest dungeon healers
where you can constantly keep players out of danger.

A Consistent Staple

While not consistently providing the highest HPS output, Holy Paladins have been
a staple of raiding for over a decade.

[[spell:465]]

is an extremely powerful
buff and raid comps tend to gain this through bringing a Holy Paladin.

[[spell:31821]]

also allows them to offer a decent amount of damage reduction to the raid during
difficult moments. Holy Paladin also has fantastic utility and extremely strong
single-target healing to help make up for the fact they lack AoE healing compared to
other healers. With Holy Paladin being near the top of the meters again, you can
expect to see a Holy Paladin in most healing comps.

Back to being Meta

Holy Paladin may lack some of the damage output of other healers, but it provides
the highest healing output thanks to single-target spells combined with beacon
effects such as

[[spell:1244878]]

and either

[[spell:200025]]

or

[[spell:156910]]

. These allow you to better manage difficult moments
through transfering your strong single-target healing to allies. Additionally,
Holy Paladin offers some of the strongest utility of any healer through abilities
such as

[[spell:1022]]

and

[[spell:1044]]

. With all this
in mind, Holy Paladin is a great choice and likely to be competing with the best
healer specs for the "meta" spot.

Incredible Utility

Holy Paladin offers some of the best utility in the game.

[[spell:1044]]

,

[[spell:1022]]

, and

[[spell:642]]

are incredibly powerful in every
form of content. Freedom will allow you to remove roots and slows, which can make difficult
mechanics entirely trivial. Protection can help you to negate aggro problems on dangerous pulls,
while also removing physical damage and bleeds. This can be the difference maker between someone living
or dying, while also allowing them to immune certain mechanics. Finally, Divine Shield or "Bubble"
will allow you to completely ignore mechanics, allowing you to focus on keeping players alive, or
simply getting out of a tough spot.

Defensive Powerhouse

Holy Paladin has three strong defensive cooldowns:

[[spell:403876]]

,

[[spell:642]]

and

[[spell:1022]]

. Divine Protection has an incredibly short cooldown, meaning that
you can consistently have it active during dangerous moments. Divine Shield is a get out of jail free
card, allowing you to completely immune damage and mechanics - something no other healer has.
Finally, Blessing of Protection can serve as a similar immunity, but only for Physical damage and bleed
effects. When facing tough physical damage, it can be used to negate the effects entirely, just always
remember that it will not work on magic effects!

Lackluster

The biggest weakness of Holy Paladin comes in the form of mobility. While

[[spell:190784]]

has a fairly
short cooldown and multiple uses, the class still suffers compared to other specs. Being mispositioned or reacting
slowly to a mechanic can be lethal for yourself and your group. Evokers can always

[[spell:358267]]

out of mechanics
and reposition, Druids and Shamans have

[[spell:768]]

and

[[spell:2645]]

to help, while Paladins are quite limited
when

[[spell:190784]]

is on cooldown.

2.

### Holy Paladin in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

With the release of Patch 12.1.5, you will gain access to two new pieces
of endgame content: a new Raid and a new Mega-Delve. For more information on 
these new pieces of endgame content, you can visit our dedicated pages linked below.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

For a full breakdown of 12.1.5 Changes, you can visit our dedicated Hub which
will provide you all the information you need to know whether you have been playing
all expansion long, or you are a returning player.

2.3.

#### Class Changes

In Patch 12.1.5, Holy Paladin received no notable changes. That being said,
if you have not visited the Talents page recently, you may want to take a stop
by and ensure that you are playing the most up to date builds.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_deathmark.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class TuningHide Patch 12.1 Class Tuning
[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

In Patch 12.1, Holy Paladin received numerous buffs to throughput, allowing it
to better compete with the top throughput specs, providing more choice within
talent selections, and increasing the power of [[spell:85673]]. Below we
will lost some of the key changes:

- [[spell:1232616]], [[spell:157047]] and [[spell:414139]]
  all received numerical buffs which increases the power of [[spell:200025]]
  as these talents synergize much better with it than [[spell:156910]]
- [[spell:85673]]/[[spell:156322]] was buffed to the point of being
  stronger than [[spell:85222]], meaning that you will always prioritize it
  in Raid and Mythic+ settings.
- [[spell:1241511]] now decreases the duration of [[spell:384376]]
  and [[spell:394088]] by less. This is unlikely to have an impact in raid
  settings but may make it more desirable in Mythic+.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Changes to Holy Paladin

Heading into Midnight, Blizzard wanted to focus on reducing the amount of healing sources
that Holy Paladin has while also removing the need to track multiple different buffs such
as [[spell:248033]]. Additionally, they wanted to cut back on the number of cooldowns
available to the spec while also making [[spell:31821]] feel more impactful.
Even [[spell:35395]] has been removed as more emphasis is placed on [[spell:20473]]
and [[spell:53576]]. Finally, [[spell:85222]] received adjustments its
targetting and now no longer heals players in front of you but instead players around you.
Some of the core changes will be listed below:

- [[spell:114165]] and [[spell:375576]] now share a choice node.
- [[spell:24275]] is no longer castable and instead replaces [[spell:20271]] during
  [[spell:384376]]. Hammer of Wrath will gain all the talent benefits that Judgment does
  when this occurs.
- [[spell:35395]] has been removed, but when you talent into [[spell:394088]] it
  returns during the cooldown.
- [[spell:196926]] has been redesigned. It now causes [[spell:20473]] to reduce the cooldown
  of [[spell:20271]].
- The following talents have been removed: [[spell:148039]], [[spell:329722]],
  [[spell:392951]], [[spell:183415]], and [[spell:383388]].
- Numerous new talents were added, and some have been redesigned.

In addition to these changes, you will gain access to the new Apex Talents as well as 3 new Hero
Talent choices.

2.4.1.

##### Apex Talent

In Midnight, you will gain access to [[spell:1244878]], the new Apex talent. This ability
has 3 separate ranks that all increase its power. Below we will break down what each individual rank does:

- Rank 1 — While in combat, you will gain an additional beacon called [[spell:1244878]]. This beacon
  will automatically be placed on the lowest health ally and will transfer to the new lowest health ally if it heals
  a player above 50% or another ally drops below 50%.
- Rank 2 — Increases the amount of healing transferred by [[spell:1244878]] and increases the amount
  of healing you do to the target with Beacon of the Savior.
- Rank 3 — Every 8 seconds or when [[spell:1244878]] transfers, an absorb shield is placed on the
  target that also provides damage reduction until the shield is broken.

The most important aspect of [[spell:1244878]] is that it also benefits from any talents that amplify
[[spell:53563]]. This means that [[spell:387781]], [[spell:157047]], [[spell:416799]]
and even [[spell:197446]] all buff [[spell:1244878]]. This effectively means that you have an extra
Beacon at all times. Additionally, due Rank 2 of Beacon of the Savior also increasing the healing you do to Savior targets,
it is significantly less punishing than normal to heal directly into your Beacon of the Savior. At some times it can even
be beneficial compared to standard beacons where you tend to avoid healing into them.

2.4.2.

##### Hero Talent Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun has two notable changes in Midnight. One being the new talent:
[[spell:1263782]]. This gives you two Holy Power when entering [[spell:384376]].
You will ideally want to make sure that you aren't capped on Holy Power when pressing your
major cooldown, but it isn't the overall end of the world. The other change is the reduction of power placed
into [[spell:431377]]. Throughout The War Within, Dawnlights made up a large percentage of your overall
healing. After different buffs and nerfs to the spec, Dawnlight has lost a lot of power and it will be
much less punishing. While you still will want to maximize your casts and target players where you can get
high value, it will be much less important.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith has gained some interesting talents in Midnight that will increase its power.
[[spell:1271466]] causes you to have a chance of triggering [[spell:248033]] when [[spell:432472]]
are active and being utilized. While [[spell:248033]] no longer triggers [[spell:384376]] in Midnight, this 
is still a powerful addition to Lightsmith that should improve the healing done by [[spell:433718]]. 
It is important to note that this talent does not require you to be talented into Awakening to work, it will trigger 
regardless of your talent choices.

2.4.3.

##### Rotational Changes

In Midnight, Holy Paladin gameplay will remain largely intact with a focus on
maximizing the amount of Holy Power you can spend on either [[spell:156322]] 
or [[spell:85222]]. This choice will continue to depend on the form of 
content you are doing, with Mythic+ wanting to cast Eternal Flame and Raid 
Light of Dawn. Outside of this, you will be focused on maximizing your casts
of [[spell:20473]] while weaving in [[spell:19750]] casts when necessary.
[[spell:20271]] has lost a ton of power and you will typically only press it
when doing Mythic+ content and when you want to increase your damage. Healing
will focus on [[spell:20473]], [[spell:19750]] and a Holy Power spender.
Due to Crusader Strike being removed, there is also almost no reason to play 
entirely in melee. If things get extremely crowded or you are having trouble 
seeing certain mechanics, you can step back for a second with absolutely no punishment.

When playing a [[spell:394088]] build, your rotation will look largely the same, but you will
have some slight differences in ability usage. During Avenging Crusader, you regain access to [[spell:35395]]. 
This means that you will still follow the typical gameplay of rotating between [[spell:20271]] and [[spell:35395]], 
while still spending as much Holy Power as possible.

3.

### Basics of Holy Paladin Gameplay

Holy Paladin, like any healer, is all about using your abilities
strategically. Rather than a fixed rotation, you will be using your flexible
spell kit to adapt and overcome whatever the game throws at you.

In order to be a successful Holy Paladin, you must make use of your
cooldown abilities as efficiently as possible. These three main focal 
points best describe the base gameplay of Holy Paladin.

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_torch_thrown.jpg>) **Don't Waste Holy Power**  
  
    It is important when playing Holy Paladin that you do not ever waste Holy Power.
    While you do not always need to spend Holy Power the second you reach 3, you should
    still always ensure that you are spending when at 5.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_paladin_divinetoll.jpg>) **Keep Abilities on Cooldown**  
  
    Holy Paladin has two short cooldown abilities that will play a major role in your HPS.
    First is [[spell:200025]] which applies a modified [[spell:53563]] to allies,
    and the second is [[spell:375576]] which casts 5 [[spell:20473]]s. If you are
    not casting these abilities enough, you will be missing out on a large amount of healing.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_surgeoflight.jpg>) **Properly Utilize Holy Light**  
  
  [[spell:82326]] is one of our most powerful spells, offering a ton of healing
    with a very high cost. It is important that you are casting this ability often
    in order to make use of its healing, but also balance that by not using it so much
    that you run out of mana. In Mythic+ you can always be a bit more aggressive
    with this due to the fact you can drink.

4.

### How to Gear Up as a Holy Paladin

While we always recommend simming yourself for ideal results, we do provide a
dedicated Holy gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Lightsmith Mythic+ build updated.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **01 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Helm and Feet BiS recommendation updated.
- **25 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Added extra information to bonus roll strategy.
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Minor trinket tier list updates.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **04 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Mythic+ talent builds updated.
- **04 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Mythic+ talent builds updated.
- **31 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Trinket tier list updated.
- **23 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Trinket tier list updated.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 (this page):** Updated for Midnight 12.0.1.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **31 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Rotation page overhauled and updated.
- **20 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Weapon enchant recommendation updated.
- **14 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Trinket recommendations updated.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **13 May 2025 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Puzzling Cartel Chip Recommendations updated.
- **06 May 2025 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Recommended build updated.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Page Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Page Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Page Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Page Updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Page updated for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **17 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-liberation-of-undermine-raid-guide>)):** Gallywix information added.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Cyrces Circlet information added.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Page overhauled.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **24 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Avenging Crusader Rotation updated.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Page updated for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Page updated for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** Page updated for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Page updated for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Page updated for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Page updated for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Page updated for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **28 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Stat priority slightly shifted.
- **28 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Dungeon tips added.
- **16 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Embellishment information updated.
- **16 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** Boss information and talent recommendations updated.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Season 1 BiS Gear added.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Season 1 Information added.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **30 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Consumable recommendations updated.
- **30 Aug. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** Page added.
- **30 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Talent build updated.
- **30 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Talent builds updated.
- **27 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Delve build added.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewd and Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Reviewd and Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewd and Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewd and Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Reviewd and Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewd and Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewd and Updated for The War Within.
- **21 Aug. 2024 (this page):** Reviewd and Updated for The War Within.
- **17 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewd and Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/holy-paladin-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Page Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Page Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Page Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Page Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Page Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Page Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Page Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Page Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Page Updated for The War Within Pre-Patch.
- **20 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Page Updated for The War Within Pre-Patch.
- **27 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/holy-paladin-the-war-within-pve-guide>)):** Core Changes updated to reflect new changes.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/holy-paladin-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/holy-paladin-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **18 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewd for Season 4.
- **01 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Fixed leveling string.
- **26 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Updated for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Talent recommendations updated.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Rotations updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Talent recommendations updated.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Stat priority updated.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **29 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** BiS List and Embellishment recommendations updated.
- **29 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Minor updates to gem recommendations.
- **21 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Weapon enchant recommendation updated.
- **13 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Talent recommendations updated.
- **13 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Mythic+ talent recommendations updated.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Embellishment and BiS list updated for sporecloak nerfs.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Page Updated for 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Page Updated for 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Page Updated for 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Page Updated for 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 (this page):** Page Updated for 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** BiS gear added.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Formatting updates.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7
- **07 Aug. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated enchant recommendations.
- **07 Aug. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated talent recommendations.
- **07 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated rotation and added more info about Beacon of Light targetting.
- **07 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated talent recommendations.
- **07 Aug. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated talent recommendations.
- **19 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Trinket tier list updated.
- **17 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Trinket tier list updated.
- **17 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Talent recommendation updated.
- **17 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Mythic+ talent recommendation updated.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Gear recommendations updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Recommendations Updated for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Talents updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Rotations updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Talent recommendations updated for 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Spells updated for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Talent recommendation updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **27 May 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Avenging Crusader rotation updated.
- **26 May 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Information about Timewalking trinkets added.
- **20 May 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Embellishment recommendations changed to account for bug fixes.
- **16 May 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Embellishments updated.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.1.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Updated for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Patch 10.1.
- **01 May 2023 (this page):** Updated for Patch 10.1.
- **28 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Primordial Gem recommendations updated.
- **28 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Primordial Gem recommendations updated.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/holy-paladin-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Reviewed for Patch 10.0.7.
- **22 Feb. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Talent recommendation updated.
- **22 Feb. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** M+ Talent recommendation updated.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **13 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Added Spark of Ingenuity crafting recommendations.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/holy-paladin-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/holy-paladin-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/holy-paladin-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/holy-paladin-patch-9-2-changes-analysis>)):** Reviewed and approved for Patch 9.2.
- **26 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/holy-paladin-patch-9-2-changes-analysis>)):** Updated to include nerfs and double Legendary combinations.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/holy-paladin-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** Updated for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** Wording revised to reflect the launch of Patch 9.1.
- **04 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** Page updated to reflect Legendary changes.
- **17 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** Page updated to reflect recent nerfs to Holy Paladin.
- **25 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** Page filled with initial information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **09 Dec. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-the-eternal-palace-raid-guide>)):** Added Zaqul and Azshara.
- **02 Oct. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-the-eternal-palace-raid-guide>)):** Added Queens Court.
- **13 Sep. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-the-eternal-palace-raid-guide>)):** Added tips for the first 5 bosses.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **14 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** Added comments about the Glimmer of Light build.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-battle-of-dazar-alor-raid-guide>)):** Added comments about the Glimmer of Light build.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-crucible-of-storms-raid-guide>)):** Page added.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** Reviewed and deemed up to date for Patch 8.1.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** Added preliminary boss tips and talent advice.
- **10 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** Added Holy Paladin Boss by Boss page (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Holy Paladin leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Paladin leveling guide](<https://www.icy-veins.com/wow/paladin-leveling-guide>).

1.

### Holy Paladin Leveling Guide for Midnight

Paladin is one of the best leveling classes in the game.
You have extreme versatility in the fact that you can either tank or heal dungeons
while also swapping to DPS for solo questing.

At lower levels, you will often have the easiest time leveling up by playing Holy or Prot
and queueing for dungeons due to the nearly instant queue time. Even if you find yourself
uncomfortable healing or tanking, early leveling dungeons aren't too difficult, so they
are a good opportunity to learn! At higher levels where questing becomes faster and, in
some cases, mandatory (expansion campaign), you will want to spec into either Ret or Prot
as they offer much higher damage than Holy.

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level but 2 secondary stats on it
instead of 1.

When using Heirloom items to help increase leveling speed, you will generally
want to use as many **Haste** pieces as possible, to help combat the very
low secondary stats you are likely to have. This will increase the speed of your
rotation and help to prevent things from feeling slow and clunky.

1.2.

#### Useful Leveling Consumables for Midnight

When leveling in Midnight, many of the consumables you used throughout
the War Within will continue to be valuable. Make sure that you always have
a flash active: [[item:212274]]. As well as plenty of potions
that can be helpful: [[item:212265]]. At the end of the expansion
many players will try to sell off their remaining stash of consumables so you can
often find cheap ones to help you speed up your leveling!

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Holy Paladin Level 80 Midnight Leveling
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyYmZmZMzMLwYYZsZmFzkYWmxMzwY2yAwAwGYzsMzMzysNzMbNAAAALsBYDGjlZGDAAzMMjxwA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAmBAA2GzMzMjZmZBmZYZsZmFjEzyMmZGGzWGAGA2AbmlZmZWmtZmZrBAAAYBA2gxwMjZAAMzwMGDDA"
}
```
:::

:::details 来源计算器编码
```
#BB-URGsmjlZECot5Z7SnrrpJYnEKiTbji4OZdBA-BJNneMILDPMtK1oMKOcWzAEEJ3KC1PR-AAAA-OCYoQIUs0wMEJA-
```

:::

2.1.

#### War Mode Talents for Leveling

Here, you will find information on the best PvP talents
for both leveling and doing solo / small group PvE content.

1. [[spell:199441]] is excellent in group content, as it provides free
   damage to your party. [[spell:82326]] is an ability you will likely use a
   lot, and Avenging Light will cause it to damage enemies whenever you choose to
   heal an ally with Holy Light.
2. [[spell:216327]] makes one of your main abilities ([[spell:82326]]),
   significantly stronger. This talent will not have much use in solo play, but
   it is excellent when healing allies.
3. [[spell:210378]] allows you to stack up your [[spell:85222]]
   to do quite a bit more healing. As you will not be casting this ability very
   frequently, it makes it even stronger when you do choose to use it to keep your
   group healthy.

Holy Paladin unfortunately does not have any strong
solo leveling PvP talents. Most of their benefits will only be seen while
playing in group content. PvP talents not listed above are not worth
considering as they do not provide use outside of very niche situations.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–9：**When you first create your Paladin, you will only have
one ability available to you: [[spell:35395]]. At level 2, you will
unlock [[spell:53600]], and at level 3, you gain [[spell:275773]].
At level 10, you can officially spec into Holy.

**等级 10 起：**Once you reach level 10, you will be able to queue
for dungeons. If you plan on leveling as Holy, you will want to make use of the
dungeon finder tool. It will be by far the most efficient way to level up
when playing Holy. If you are interested in an in-depth rotation breakdown,
you can check out our [rotation page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>).
Otherwise, we have a summary of how to use some of the healing spells
available to Holy Paladin.

3.1.

#### Healing Rotation

- **等级 11 起：**Cast [[spell:20473]] as much as possible.
- **等级 10 起：**Cast [[spell:20271]] as much as possible.
- **等级 10 起：**Cast [[spell:85673]] if you have 3 Holy Power and
  your target is in need of healing.
- **等级 13 起：**Cast [[spell:85222]] if you have 3 Holy Power and
  you have 3 or more allies in need of healing.
- **等级 10 起：**Cast [[spell:19750]] if you cannot do any of the above.
- **等级 10 起：**Use your DPS rotation (detailed below) if no healing is required.

3.2.

#### DPS Rotation

**等级 10 起：**The DPS rotation is fairly simple and should be used when
no healing is needed, or you are questing.

- **等级 11 起：**Use [[spell:20473]] on cooldown.
- Use [[spell:275773]] on cooldown.
- If you are fighting multiple targets, you can choose to drop [[spell:26573]].
  (Once you gain access to [[spell:414113]], simply pressing [[spell:275773]]
  will drop Consecration).
- Consume Holy Power with [[spell:53600]] when no healing is necessary.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Page Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Page updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Reviewd and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **01 Apr. 2024:** Fixed leveling string.
- **26 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Holy Paladin in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Holy Paladin in Midnight

This section is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

Holy Paladin does best at passively supporting tanks with their beacons and
single-target healing in general. In addition to this, Holy Paladin is
peculiar because it has many tools at its disposal that allow it to handle
various encounter mechanics in ways that other healers cannot. 3 quick rules
to follow when learning the spec are:

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_torch_thrown.jpg>) **Don't Waste Holy Power**  
  
    It is important when playing Holy Paladin that you do not ever waste Holy Power.
    While you do not always need to spend Holy Power the second you reach 3, you should
    still always ensure that you are spending when at 5.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_paladin_divinetoll.jpg>) **Keep Abilities on Cooldown**  
  
    Holy Paladin has two short cooldown abilities that will play a major role in your HPS.
    First is [[spell:200025]] which applies a modified [[spell:53563]] to allies,
    and the second is [[spell:375576]] which casts 5 [[spell:20473]]s. If you are
    not casting these abilities enough, you will be missing out on a large amount of healing.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_surgeoflight.jpg>) **Properly Utilize Holy Light**  
  
  [[spell:82326]] is one of our most powerful spells, offering a ton of healing
    with a very high cost. It is important that you are casting this ability often
    in order to make use of its healing, but also balance that by not using it so much
    that you run out of mana. In Mythic+ you can always be a bit more aggressive
    with this due to the fact you can drink.

2.

### Beginner's Guide to Holy Paladin in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun   Raiding Talents

2.1.

#### Beginner Raid Build for Holy Paladin

This build focuses on a very standard rotation of building Holy Power through [[spell:20473]]
and [[spell:19750]] while spending it with either [[spell:85222]]. 
As always the goal is to generate as much Holy Power as possible while ensuring 
that you are not wasting any by not spending it.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGmBAwMDzghB"
}
```
:::

:::details 来源计算器编码
```
#BB-CDGIMUtIJjnD08MNddlpdbH4FHV2WloIxnp-BJLMNnrIRTWeDGPKFKo0ASUlBk4Ip6H-AAAA-GScgcpBIgQhhCD-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun   Mythic+/Delve Talents

2.2.

#### Beginner Mythic+ Build for Holy Paladin

This build is designed for those who want to play a fairly simple Mythic+-focused build,
and it is also useful in Delves if you want to heal there.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAMAAw2YmZmZMzMLwMDLjNzsY0EzyMmZGGzWGAGA2AbsMzMzysNzMbNAAAALgZwGMGGMDAgZGmxYYA"
}
```
:::

:::details 来源计算器编码
```
#BB-DGWzURilZmmCo9pz1lz2mELwfAKiTZ98iiOB-BNJMnLIePWdMtGKP0oMKIU:yAikLwKR-AAAA-GiE4IghChQxSDD-
```

:::

### Holy Paladin   Basic Rotation

2.3.

#### Raid Healing

This rotation will assume that you are playing the recommended raid build and 
would not change regardless of if you have access to your tier bonus. For more 
in-depth information please consult with the rotation page for additional 
rotations depending on your desired build.

- Cast [[spell:20473]] as much as possible.
- Consume Holy Power with [[spell:156322]] for Single-Target healing or
  [[spell:85222]] for AoE healing.
- Cast [[spell:19750]] when you do not have 3 Holy Power and cannot Holy Shock.
- Cast [[spell:82326]] for big healing, just don't do it too much or you 
  will run out of mana extremely quickly.

2.4.

#### 5-Man Healing

5-man healing is very similar to raiding rotations, with the exception that you will 
be casting [[spell:85673]] (or [[spell:156322]] if ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun) much 
more frequently. This rotation will assume that you are playing the recommended Mythic+ build.

- Use [[spell:20473]] as your primary healing spell.
- Consume Holy Power with [[spell:85673]] (or [[spell:156322]] if ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun).
- Cast [[spell:19750]] when you do not have 3 Holy Power and cannot Holy Shock.
- Cast [[spell:82326]] for big healing single-target healing.

While doing dungeons, you can rely on [[spell:82326]] much more because you
are able to drink in between pulls. This means that you will not be as concerned
about mana as you would be in Raid.

2.4.1.

##### Apex Talent: ![Beacon of the Savior Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_holyfire_buff.jpg>) Beacon of the Savior

In Midnight, you will gain access to [[spell:1244878]], the new Apex talent. This ability
has three separate ranks that all increase its power. Below we will break down what each individual rank does:

- Rank 1 — While in combat, you will gain an additional beacon called [[spell:1244878]]. This beacon
  will automatically be placed on the lowest health ally and will transfer to the new lowest health ally if it heals
  a player above 50% or another ally drops below 50%.
- Rank 2 — Increases the amount of healing transferred by [[spell:1244878]] and increases the amount
  of healing you do to the target with Beacon of the Savior.
- Rank 3 — Every 8 seconds or when [[spell:1244878]] transfers, an absorb shield is placed on the
  target that also provides damage reduction until the shield is broken.

[[spell:1244878]] is largely a passive effect that you do not need to worry about significantly. In general
treat it as having a 3rd [[spell:53563]] and you can largely ignore it. That being said, because you do additional
healing to your Beacon of the Savior, it isn't a big deal if you find yourself directly healing your Savior target like
it typically would with a Beacon of the Light target.

2.4.2.

##### Season 2 Tier Set

The Midnight Season 2 tier set is fairly straight forward for Holy Paladin.
It will provide the following bonuses:

- [[spell:1296656]] — Increases the healing done by [[spell:19750]]
  and the absorb from [[spell:231663]].
- [[spell:1296657]] — [[spell:20271]] now has a 20% chance to grant
  [[spell:53576]] and [[spell:82326]] now always grants it. Holy Light mana cost
  is also increased.

This tier set bonus provides a nice rotational boost to Holy Paladin.
[[spell:20271]] is much weaker than [[spell:19750]] with [[spell:53576]]
but it now becomes a much better ability to press when you are fishing for a
Infusion proc. Additionally, [[spell:82326]] is now a guaranteed way to get
an Infusion. This will not have a major effect on your rotation, but now you
will have much more access to [[spell:53576]] meaning that you do not
need to cast as many unbuffed [[spell:19750]]s.

The mana cost increase from [[spell:82326]] can seem quite weird on first
glance, but it is there to prevent players from spamming Holy Light endlessly
due to having infinite mana and leading to infinite [[spell:53576]]s.

### Holy Paladin   Stat Priority

2.5.

#### Stat Priority for Holy Paladin

The general stat priority for a Holy
Paladin is seen below. This is very much a rough guideline and is 
designed for players who do not wish to sim their character through 
[QuestionablyEpic](<https://questionablyepic.com/>).
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>).

Intellect

Mastery

Haste

Critical Strike

Versatility

### Blizzard   Combat Assistant

2.6.

#### Combat Assistant

Added in Patch 11.1.7, the combat assistant is a one-button ability intended to cast your rotational
abilities. Unfortunately for healer specs, this does not function well. As a Holy Paladin, the combat
assistant **will not cast healing spells**, it will not cast [[spell:20473]], and it will not
spend holy power. This makes it fairly unusable. The only situation in which you could use it is when
focused entirely on dealing damage, and even then you would still need to cast your other abilities
on your own.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Page overhauled.
- **21 Oct. 2024:** Page updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Reviewd and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Apr. 2024:** Reviewd for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Stat priority updated.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **07 Aug. 2023:** Updated talent recommendations.
- **10 Jul. 2023:** Talent recommendation updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Holy Paladin in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Holy Paladin

For Season 2, after receiving numerous buffs through the start of Midnight,
Holy Paladin has one playstyle standing above the rest for raiding, while in Mythic+ you have
a more competitive choice.

- **Raiding -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun is the go to choice for raiding
    largely for the passive boosts it provides that amplify [[spell:85222]],
    [[spell:156322]], and [[spell:20473]]. Unfortunately ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith
    is not competitive in raiding and shouldn't be played outside of wanting to have fun.
- **Mythic+ -** In Mythic+ you have a much more competitive choice with
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith offering a bit higher damage but lacking the reliable healing
    that ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun can provide. For that reason, we advise players
    to play ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun builds.

The choice for raiding is fairly straightforward, but in Mythic+ with both
Hero Talents being competitive we will provide builds for both in order to allow
you to experiment and find out what clicks. Again, a general rule is that
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun will provide better healing while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith
can offer more damage.

**Quick Start Import Codes:**

:::talents Herald of the Sun Raiding
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGmBAwMDzghB"
}
```
:::

:::talents Herald of the Sun Mythic+
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAmBAA2GzMzMjZmZBmZYZsZmFjmYWmxMzwY2yAwAwGYjlZmZWmtZmZrBAAAYBMD2AGGMDAgZGmxYYA"
}
```
:::

:::talents Lightsmith Mythic+
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMmxMzMGzWGAGA2AbsYmBAAAmZWWWsMzwGbjZwGwMGAgZGAmxY0A"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Herald of the Sun

Raiding - Standard

recommended

Mythic+

recommended

Lightsmith

Raiding - Avenging Crusader Build

Mythic+/Delves

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Standard Build

This is your standard Holy Paladin build. You will primarily be rotating between
casting [[spell:20473]] and [[spell:19750]] to build Holy Power before
spending  with [[spell:85222]] or [[spell:156322]]. Because Flash of Light
also generates a Holy Power and does not have a cooldown, you will often find
yourself using it heavily to help continue the building and spending cycle.
Many talents are set in stone but you could consider changing between [[spell:156910]]
and [[spell:200025]] depending on the fight and your playstyle. When playing
[[spell:156910]], you will want to change [[spell:1232616]] to [[spell:414203]].
Additionally, you may want to consider dropping points in [[spell:1241805]]
and [[spell:157047]] to [[spell:210294]] and [[spell:200430]].

:::details FAQShould I Play Liberation?
[[spell:461471]]

offers a decent damage boost at the expense of some healing. You may see high level
Holy Paladins competing in the Race to World First with this talent, but they are often in situations where
they need to absolutely minmax their damage as hard as possible in order to kill it with the gear they have.
Every other level of player will often benefit more from just having more healing, but if you are interested
in minmaxing your damage at the expense of healing, you can certainly talent into this ability.

:::

### 天赋方案 0-1

1.2.

#### Mythic+ Talents

The Mythic+ build sacrifices minor healing to increase your damage. This is achieved
through taking talents that increase the benefit of [[spell:53600]]. During
downtime and when only minor healing is needed, you will tend to spend Holy Power with
Shield of the Righteous. Just be careful of difficult moments where it may be better to save
Holy Power for an upcoming damage window.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith Avenging Crusader

It is important to note that ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith and [[spell:394088]]
are not as powerful as the standard ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun builds. Choosing to
play this will result in a noticeable healing loss. Additionally, this will be
worse than playing a standard ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith build with identical talents
to what you could find from a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun talent page. The purpose
of this build is to create a melee-focused playstyle for players who want to minimize
the amount of casting that they are doing.

This build focuses on the synergy between [[spell:433718]] and the
[[spell:394088]] talents. Both of these place heavy emphasis on casting
[[spell:20271]] as frequently as possible. This becomes your most important ability.
That does not mean you will want to stop spending Holy Power, but you should aim
to keep Judgment on cooldown as much as possible. During your [[spell:394088]],
you will also regain access to [[spell:35395]] which will become a high priority
ability. In order to maximize your output with this build, it is important that you have
a good understanding of the rotational differences between this and a standard build.

### 天赋方案 1-1

1.4.

#### Mythic+/Delves Talents

The Mythic+/Delves build sacrifices minor healing to increase your damage.
This is achieved through taking talents that increase the benefit of [[spell:53600]].
During downtime and when only minor healing is needed, you will tend to spend
Holy Power with Shield of the Righteous. Just be careful of difficult moments
where it may be better to save Holy Power for an upcoming damage window.

This build plays exactly the same as the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Mythic+ build,
but with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith instead.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxsMjZmhxslBgBgNwmZZGzsMbzMzWDAAAwCAsxYMMzYGAAzMMjxwA"
}
```
:::

:::details 来源计算器编码
```
#BB-CGIMUtKjlnD08MNddpdbH4ELOstuKRRciPTB-BNJnMIeLrPimsGKpE0MKAWJmBEJh63I-AAAA-GScgcpBIgQhhCD-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAmBAA2GzMzMjZmZBmZYZsZmFjmYWmxMzwY2yAwAwGYjlZmZWmtZmZrBAAAYBMD2AGGMDAgZGmxYYA"
}
```
:::

:::details 来源计算器编码
```
#BB-CxGWzyIUD0566Zrz0E8STCtKiTZjiYG88+AA-BNJMneLIHGFaDlUrPMtcAWJmBEJXC1P-AAAA-GiE4IghChQxSDD-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyMzMjZMzAjxY2GbmZzoJmlZMzMMmtMAMAsB2MLzMDAAAMzsttYbmhNMAbwYYmxAwMDAzYMaA"
}
```
:::

:::details 来源计算器编码
```
#BB-CxGWzyMIUD0566Zrz0E8STCtKiTZjiOdHa5A-BNJnLMIeGFmSDlYYUaCWAETzCmkQ9jL-AAAA-LAM8AJQwIxElFG-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAmBAA2GzMzMjZmZBmZYZsZmFjmYWmxMzwY2yAwAwGYjlZmBAAAmZ22WsNzwGYGsBMMYGAzMAMjxoB"
}
```
:::

:::details 来源计算器编码
```
#BB-CxGWzyIUD0566Zrz0E8STCtKiTZjiYG88+AA-BNJMneLIHGFaDlUrPMtcAWJmBEJXC1P-AAAA-LcgAMMQwIxElFG-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

Below we will recommend you with the best setup, but most bonuses are comparable
in power and you can change them around as you wish. Specifically, [[spell:1279612]]
can be changed out for any other secondary bonus you desire.

- [[spell:1279599]]
- [[spell:1279603]]
- [[spell:1287555]]
- [[spell:1279612]]
- [[spell:1279614]]

3.

### Apex Talent: ![Beacon of the Savior Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_holyfire_buff.jpg>) Beacon of the Savior

In Midnight, you will gain access to [[spell:1244878]], the new Apex talent. This ability
has 3 separate ranks that all increase its power. Below we will break down what each individual rank does:

- Rank 1 — While in combat, you will gain an additional beacon called [[spell:1244878]]. This beacon
  will automatically be placed on the lowest health ally and will transfer to the new lowest health ally if it heals
  a player above 50% or another ally drops below 50%.
- Rank 2 — Increases the amount of healing transferred by [[spell:1244878]] and increases the amount
  of healing you do to the target with Beacon of the Savior.
- Rank 3 — Every 8 seconds or when [[spell:1244878]] transfers, an absorb shield is placed on the
  target that also provides damage reduction until the shield is broken.

The most important aspect of [[spell:1244878]] is that it also benefits from any talents that amplify
[[spell:53563]]. This means that [[spell:387781]], [[spell:157047]], [[spell:416799]]
and even [[spell:197446]] all buff [[spell:1244878]]. This effectively means that you have an extra
Beacon at all times. Additionally, due Rank 2 of Beacon of the Savior also increasing the healing you do to Savior targets,
it is significantly less punishing than normal to heal directly into your Beacon of the Savior. At some times it can even
be beneficial compared to standard beacons where you tend to avoid healing into them.

4.

### Hero Talents

Holy Paladin gets to pick between two distinct Hero Talent choices:
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun tends to be the stronger choice for both raiding
and Mythic+. While it may offer slightly less damage than the alternative choice,
in increases the healing output of [[spell:384376]] thanks to [[spell:431425]].
Additionally, you gain access to [[spell:431377]] which helps to add throughput during your
main cooldown, as well as outside of it.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith emphasizes the use of [[spell:20271]] due to [[spell:433718]].
While this isn't controllable healing, it is still extremely powerful. This has very high synergy
with [[spell:394088]] builds, and you will often be utilizing this Hero Talent when
playing Avenging Crusader. While Lightsmith may be weaker at the moment, it can provide a nice DPS
increase for players who are looking to deal as much damage as possible.

5.

### PvP Talents (War Mode)

War Mode offers several benefits for you in the open world.

- PvP talents enabled in the outdoor world.
- At least 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will be available for open-world PvP, and
the possibility of being "ganked" while leveling or doing World Quests exists.

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of all PvP Talents for
Holy Paladin

1. [[spell:199454]] gives you an extra charge of [[spell:1044]] and [[spell:1022]],
   making it extremely powerful.
2. [[spell:199324]] increases the range of your Aura while also reducing the cooldown of
   [[spell:31821]], making it very helpful in increasing survivability.
3. [[spell:410126]] can be quite difficult to use, but also can boost your own survivability
   when timed well.

You can consider the other options essentially down to preference.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Lightsmith Mythic+ build updated.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **04 Apr. 2026:** Mythic+ talent builds updated.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **06 May 2025:** Recommended build updated.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Page updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for Season 1.
- **30 Aug. 2024:** Talent builds updated.
- **27 Aug. 2024:** Delve build added.
- **21 Aug. 2024:** Reviewd and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Talent recommendations updated.
- **13 Nov. 2023:** Mythic+ talent recommendations updated.
- **06 Nov. 2023:** Page Updated for 10.2.
- **04 Sep. 2023:** Formatting updates.
- **07 Aug. 2023:** Updated talent recommendations.
- **17 Jul. 2023:** Mythic+ talent recommendation updated.
- **10 Jul. 2023:** Talent recommendations updated for 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **22 Feb. 2023:** M+ Talent recommendation updated.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Holy Paladin, depending on the type of damage your group
is receiving. We also have advanced sections about cooldowns, procs, etc.
in order to minmax your healing output and your mana efficiency. All our
content is updated for World of Warcraft Patch
12.1.5.

1.

### Holy Paladin Gameplay and Rotation Guide

Welcome to our Rotation page for Holy Paladins. On this page,
you will find everything you need to know about actually playing the spec in
Raiding and Mythic+ scenarios.

The buttons below can be used to select between curated **Raiding** and
**Mythic+** loadouts. You can also use the switches below to add or remove
individual talents you may also be using.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun

Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith

Raid - Avenging Crusader

Mythic+

Active Talents

Passive Talents

[[spell:384376]]

[[spell:394088]]

[[spell:156910]]

[[spell:200025]]

[[spell:375576]]

[[spell:114165]]

[[spell:387170]]

[[spell:414113]]

[[spell:461529]]

### Holy Paladin Explained

1.1.

#### General Priority

Regardless of build choice, your primary focus will be casting as many [[spell:20473]]s as possible, as well as spending as much Holy Power as possible through one of: [[spell:85222]], [[spell:85673]] (or [[spell:156322]]), or  [[spell:53600]]. When you can do none of the above, you will be rotating between casting [[spell:20473]] and [[spell:19750]] for healing. [[spell:275773]] will see some use in Mythic+ settings where damage is needed.

Holy Paladin is one of the more fast paced classes and the most important  thing you can do rotationally is ensure that you are always casting something. At times you will need to make split second decisions as to which ability is best to use, simply choosing one will always be better than hesitating slightly, missing a cast, and then choosing. You should aim to cast as many spells as possible, as fast as possible. Once you are able to properly execute a fast rotation, you can then aim to optimize the specific buttons you are casting 
and when.

### Raid

1.2.

#### Raiding Rotation for Holy Paladin

While raiding, you will want to be maximizing the amount of Holy Power you generate through abilities such as: [[spell:20473]], [[spell:19750]] (or [[spell:275773]]), and [[spell:82326]] followed by spending it on [[spell:85222]] or [[spell:85673]] ([[spell:156322]] when ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun). When damage is heavy, you can also weave in [[spell:82326]] assuming that you have enough mana for it. 

Your overall priority will be as follows:

- Never waste Holy Power — if you are at 5 or about to cap, spend it.
- **适用条件：Divine Toll（启用）；Lightsmith（未启用）。** Keep [[spell:375576]] on cooldown as much as possible.
- **适用条件：Holy Prism（启用）；Lightsmith（未启用）。** Keep [[spell:114165]] on cooldown as much as possible.
- **适用条件：Lightsmith（启用）。** Keep [[spell:432472]] on cooldown as much as possible.
- **适用条件：Beacon of Virtue（启用）。** Cast [[spell:200025]] right as damage hits. Aim to keep it on cooldown as much as possible.
- Consume [[spell:53576]] with [[spell:19750]]. If no healing is needed consume with [[spell:20271]].
- Cast [[spell:20473]] as much as possible.
- **适用条件：Avenging Crusader（启用）。** Cast [[spell:275773]] as much as possible.
- **适用条件：Herald of the Sun（启用）；Empyrean Legacy（未启用）。** Spend Holy Power on [[spell:156322]]. If the ability is going to overheal a lot, you should instead consume a proc with [[spell:85222]].
- **适用条件：Lightsmith（启用）；Empyrean Legacy（未启用）。** Spend Holy Power on [[spell:85673]]. If the ability is going to overheal a lot, you should instead consume a proc with [[spell:85222]].
- **适用条件：Empyrean Legacy（启用）；Herald of the Sun（启用）。** If you have an [[spell:1241358]] proc, consume Holy Power with [[spell:156322]], otherwise consume Holy Power with [[spell:85222]]
- **适用条件：Empyrean Legacy（启用）；Lightsmith（启用）。** If you have an [[spell:1241358]] proc, consume Holy Power with [[spell:85673]], otherwise consume Holy Power with [[spell:85222]]
- Cast [[spell:82326]] when you can afford the cost and it will not overheal.
- **适用条件：Lightsmith（未启用）。** Cast [[spell:20271]] when you cannot do any of the above.
- When no healing is needed, you can consume Holy Power on [[spell:53600]] to regen small amounts of mana.

**适用条件：Avenging Crusader（启用）。** When you have [[spell:394088]] active it is important to note that your rotation will change slightly. The most notable change is that [[spell:35395]] will replace [[spell:394088]] on your action bar and you will want to be pressing it. The overall rotation will look something like this:

- **适用条件：Avenging Crusader（启用）。** Never waste Holy Power — if you are at 5 or about to cap, spend it.
- **适用条件：Avenging Crusader（启用）。** Cast [[spell:275773]] on cooldown.
- **适用条件：Avenging Crusader（启用）。** Cast [[spell:35395]] on cooldown.
- **适用条件：Avenging Crusader（启用）。** Spend Holy Power on [[spell:85222]].
- **适用条件：Avenging Crusader（启用）。** Cast [[spell:20473]] when you cannot do any of the above.

**适用条件：Beacon of Virtue（启用）。** One of the most difficult aspects of Holy Paladin is utilizing [[spell:82326]]. This ability offers an absurdly high amount of healing, but with an even higher mana cost. Additionally, you will also be playing [[spell:200025]] which is also very expensive. Part of playing Holy Paladin well requires you to get as much value out of these abilities as possible, while still having enough mana to get to the end of a fight. [[spell:29166]] can be a great tool to help you achieve this, and if you have a druid in your group you should always ask them for this. Outside of Restoration Shaman, Holy Paladin is one of the best targets for it.

:::details TipsOptimizing Beacon of Virtue
In order to truly get the most out of

[[spell:200025]]

, it is important that you are actively playing around it.

[[spell:387786]]

is the most important interaction to keep in mind, causing our

[[spell:19750]]

to deal additional healing when targetted on a player with

[[spell:200025]]

. You should aim to do this when possible. You will also want to make sure that you are primarily casting "good" spells during your Virtue windows. "Good" spells refer to any healing ability and ideally single-target ones as they will transfer more healing than AoE abilities. This means that abilities such as

[[spell:20271]]

and

[[spell:85222]]

would be bad spells to cast when

[[spell:200025]]

is active.

[[spell:20473]]

,

[[spell:19750]]

,

[[spell:156322]]

(or

[[spell:85673]]

), and

[[spell:82326]]

are all "good" abilities to cast when you have Virtue active. You will additionally want to pair strong cooldowns like

[[spell:375576]]

and

[[spell:31821]]

(if talented into

[[spell:1241542]]

) with

[[spell:200025]]

for even more healing.
The last step to optimize

[[spell:200025]]

comes spell queueing. This refers to casting an ability immediately after you had just casted one with no delay. You queue up another ability as your finishing the previous one. By casting

[[spell:200025]]

immediately after casting

[[spell:82326]]

all of the healing done from that Holy Light will transfer into your Virtue targets, giving you an insane amount of extra healing potential as well as guaranting

[[spell:53576]]

for you to use during your Virtue window thanks to the

[[spell:1296657]]

bonus. This will require a ton of mana and is only recommended when you can afford it and when a significant amount of healing is needed. Keep in mind this will

**NOT**

work if you cast the

[[spell:82326]]

on yourself. It needs to a different player.

:::

:::details FAQWhy Am I Running Out of Mana So Quickly?
[[spell:82326]]

is one of the highest healing abilities in the game but  it comes with an extremely heavy mana cost. Raiding as Holy Paladin can often feel like a balancing act trying to manage your mana while still maximizing the amount of

[[spell:82326]]

s you can cast. Keep in mind that

[[spell:53600]]

can also return mana now. While you shouldn't  be using this ability significantly, it can be helpful during downtime when no healing is needed to regen a bit of mana.

:::

**适用条件：Herald of the Sun（启用）。**

:::details FAQEternal Flame or Light of Dawn?
[[spell:156322]]

will always be your best choice to spend Holy Power. The exception to this is when

[[spell:156322]]

will overheal and in those situations you can instead cast

[[spell:85222]]

. The Heal-over-time component of

[[spell:156322]]

isn't important and you should simply cast the ability on any player in danger.

:::

**适用条件：Lightsmith（启用）。**

:::details FAQWord of Glory or Light of Dawn?
[[spell:85673]]

will always be your best choice to spend Holy Power. The exception to this is when

[[spell:85673]]

will overheal and in those situations you can instead cast

[[spell:85222]]

.

:::

**适用条件：Lightsmith（启用）。**

:::details FAQHow do I use Holy Armaments?
[[spell:227817]]

— should be cast on squishy players primarily, but casting it on yourself will cause

[[spell:432802]]

to prioritize a tank. Letting this ability target a tank can often result in the highest HPS, but it may not always be the most valuable healing. Your decision will come down to whether or not a squishy player can make use of the extra tankiness to live a difficult moment, otherwise a tank will give you the most HPS.

[[spell:432472]]

— should be cast on yourself to increase your own healing output. The additional

[[spell:432472]]

will be cast on another random healer.

:::

### Mythic+

1.3.

#### Mythic+ Rotation for Holy Paladin

Many of the priorities you would use in raiding content will stay the same in Mythic+. The main exception to this is the increased importance of [[spell:26573]], [[spell:275773]], and [[spell:53600]] in order to output extra damage because no healing is needed. Regardless of if you are playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun or ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith, the rotation will stay the exact same. Herald players will want to keep [[spell:375576]] on cooldown whereas ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith will be using [[spell:432472]] on cooldown.

Your overall priority will be as follows:

- Never waste Holy Power — if you are at 5 or about to cap, spend it. If no healing is needed remember that you can always use [[spell:53600]].
- **适用条件：Divine Toll（启用）；Lightsmith（未启用）。** Keep [[spell:375576]] on cooldown as much as possible.
- **适用条件：Holy Prism（启用）；Lightsmith（未启用）。** Keep [[spell:114165]] on cooldown as much as possible.
- **适用条件：Beacon of Virtue（启用）。** Cast [[spell:200025]] right as damage hits. Aim to keep it on cooldown as much as possible.
- **适用条件：Lightsmith（启用）。** Keep [[spell:432472]] on cooldown as much as possible.
- Consume [[spell:53576]] with [[spell:19750]] when healing is needed or [[spell:20271]] for damage or when not much healing is needed.
- Cast [[spell:20473]] as much as possible.
- **适用条件：Herald of the Sun（启用）。** Spend Holy Power on [[spell:156322]].
- **适用条件：Lightsmith（启用）。** Spend Holy Power on [[spell:85673]].
- Cast [[spell:82326]] when major healing is needed and you can afford the cost.
- Cast [[spell:20271]] as much as possible to maximize your damage. If healing is needed then instead focus on other abilities.
- Cast [[spell:19750]] when you have no other abilities available and the situation does not require [[spell:82326]].
- When no healing is needed, spend Holy Power on [[spell:53600]].

It is important to note that when healing is intense, you should be dropping [[spell:20271]] from your priority in favor of [[spell:19750]]. Flash of Light will offer you significantly more healing at the cost of damage. Part of playing Holy Paladin is swapping between these two abilities depending on the situation you are in. Consuming [[spell:53576]] will follow similar rules. For damage: [[spell:20271]]. When healing is needed: [[spell:19750]].

Keep in mind that damage may occur in Mythic+ settings that you did not expect. If you are
constantly spending Holy Power whenever possible, you may not have Holy Power available
when healing is needed. For this reason, it can often be wise as a beginner player to only
cast [[spell:53600]] when you have 4-5 Holy Power; that way, you can quickly
generate extra Holy Power when healing is needed unexpectedly.

:::details FAQShould I Ever Cast Light of Dawn?
In Mythic+, you will often find yourself casting primarily

[[spell:156322]]

/

[[spell:85673]]

. That doesn't mean that you should never press

[[spell:85222]]

. In times where no one is in significant danger and

[[spell:156322]]

/

[[spell:85673]]

would mostly overheal, you can gain a lot of value from

[[spell:85222]]

and it healing your entire party. Think of it as a way to heal everyone a little bit so that they are slightly healthier the next time you need to do large single-target healing.

:::

:::details FAQWhen Should I Use Holy Light?
Utilizing

[[spell:82326]]

effectively can be difficult due to its heavy mana cost. While it offers a ton of healing that is extremely valuable in Mythic+, overuse of the ability will leave you out of mana very quickly. That being said, you can always drink in-between bosses and trash packs which gives you room to be aggressive with Holy Light. Rather than thinking about how many Holy Light casts you should be doing, think of it from a perspective of how much mana do I need to make it through this pack? Additionally, will I be unable to heal this moment without casting Holy Light? If you have the mana and the situation demands, don't hesitate to use Holy Light. Even if you do not have the mana, sometimes it is the best choice in order to keep someone alive. The more you use it the more comfortable you will get with knowing when you can, without casting it at all you are likely to struggle.

:::

2.

### Midnight Season 2 Tier Set

The Midnight Season 2 tier set is fairly straight forward for Holy Paladin.
It will provide the following bonuses:

- [[spell:1296656]] — Increases the healing done by [[spell:19750]]
  and the absorb from [[spell:231663]].
- [[spell:1296657]] — [[spell:20271]] now has a 20% chance to grant
  [[spell:53576]] and [[spell:82326]] now always grants it. Holy Light mana cost
  is also increased.

3.

### Class and Spec Mechanics Explained

In this section, important mechanics, interactions, and gameplay elements
will be explained in depth to help you better understand how to play the class
at an advanced level.

### Infusion of Light

3.1.

#### Infusion of Light

[[spell:53576]] is a core passive for Holy Paladin. This effect has a 10% chance to be
triggered whenever you cast [[spell:20473]]. There are two different ways that you can utilize
this buff:

- **[[spell:19750]]**  
  
  When cast with [[spell:53576]], this ability becomes instant cast and the healing is
  increased by a significant margin.
- **[[spell:20271]]**  
  
  When cast with [[spell:53576]], the [[spell:231663]] effect is increased by
  a large margin and generates 1 additional Holy Power.

The best choice for consuming [[spell:53576]] largely depends on the situation
you are in. In Mythic+ and when absolutely no damage is needed, casting [[spell:20271]] can
be preferred due to it providing more Holy Power. However, **anytime** healing is needed
you should absolutely be casting [[spell:19750]]. Flash of Light offers significantly more
healing and underutilizing it can result in you falling behind in healing in Mythic+, or struggling
to keep up with your co-healers in raid.

### Beacon of the Savior

3.2.

#### Beacon of the Savior

[[spell:1244878]] is the new Apex Talent added in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
This will give you a new Beacon that will automatically be placed on the lowest
health ally. Once the target is healed beyond their maximum HP or another target
drops below 50%, the Beacon will move. There are a few interactions to keep in mind
with this Beacon:

- This ability benefits from all talents that your typical [[spell:53563]] does.
  This includes [[spell:387781]], [[spell:157047]], and any other Beacon-related talent.
- While you will still transfer healing to [[spell:1244878]] like any other Beacon, you will
  also do additional healing to the target who has your Beacon of the Savior.
- Every 8 seconds, or when [[spell:1244878]] is applied to a new target, a small shield will
  be placed on the target and they will also take reduced damage for the next 15 seconds.

Despite [[spell:1244878]] targets receiving more healing, you will not want to continuously
heal them directly. You should aim to heal them when they are in danger just like you would with any other
raid/party member. The reason that the healing increase exists in the first place is to make it less punishing
towards your healing to cast spells on your Beacon target. Due to the fact the target with your [[spell:1244878]]
is likely to be the lowest health member, you don't want to miss out on potential healing by directly heal them.
The healing increase counteracts this, meaning that you should simply aim to heal the players most in danger.

### Mastery

3.3.

#### Mastery

[[spell:183997]] is the Holy Paladin mastery. This increases the healing done by your spells based on your
proximity from the target. [[spell:197446]] increases this effect further by adding your Beacons
to the equation. The increase to healing will be calculated based on whoever is closer between yourself and players
with your Beacons. In the past, it has been common to cast [[spell:53563]] and [[spell:156910]] on tank
players as they will always be taking damage. This is no longer true and you will want to place your Beacons on ranged players
who have lower survivability. This will allow you to get good value from your Beacons while also providing you with increased
Mastery values as they will be closer to ranged while you will be closer to melee. Below we will list out a few good choices
for your [[spell:53563]] and [[spell:156910]] targets. Of course if you are playing [[spell:200025]] this
is not relevant.

- Balance Druid
- Shadow Priest
- Devastation Evoker
- Any Hunter spec
- If you have none of the above, place it on any remaining ranged.
- In small group settings with no ranged, you can often choose the tank and the melee DPS taking the most damage consistently.

4.

### Important Cooldowns for Holy Paladin

### [[spell:384376]]

4.1.

#### Avenging Wrath

[[spell:384376]] is our main cooldown. This ability has a 2-minute cooldown by default
and increases your damage, healing, and critical strike. You will want to use this cooldown as
often as possible while ideally lining it up with longer duration damage windows due to it lasting
30 seconds by default. When active, you will want to follow your standard rotation, you will just
be doing more healing!

### [[spell:31821]]

4.2.

#### Aura Mastery

[[spell:31821]] will only be used on [[spell:465]], meaning that you should have
Devotion Aura selected from your Aura bar before using (you should always keep it on by default).
When pressed, you will provide all allies with a 12% damage reduction. In a raid setting, this cooldown
is likely to be assigned to a heavy-hitting mechanic by whoever is responsible for organizing your
healing cooldowns. When you are on your own, you should prioritize using this ability anytime your
party is likely to be in danger, ideally right before large damage happens.

### [[spell:394088]]

4.3.

#### Avenging Crusader

[[spell:394088]] replaces [[spell:384376]] and grants different bonuses as well
as having a much shorter cooldown. When cast, this ability will transform into [[spell:35395]]
for the duration. While active, your [[spell:20271]] and [[spell:35395]] abilities will now
heal nearby allies when they deal damage. This means that your rotation will change slightly and you
will be wanting to press as much [[spell:20271]] and [[spell:35395]] as possible when the cooldown
is active, while still prioritizing spending Holy Power when you are near capping.

### [[spell:375576]]/[[spell:114165]]

4.4.

#### Divine Toll/Holy Prism

[[spell:375576]] and [[spell:114165]] share a choice node in Midnight.
When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith, you will have these replaces by [[spell:432472]].
Regardless of your ability choice, these are short-cooldowns which you will want to make frequent use
of. When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun, pressing these abilities is what gives you access to
[[spell:431377]], making them incredibly important.

[[spell:375576]] casts 5 [[spell:20473]]s when pressed. The important part of this cooldown is in
who you are targetting when you use it. If you are targetting an enemy, then it will prioritize casting
the 5 Holy Shocks on enemies. If there aren't enough enemies then it will cast the remaining number of Holy
Shocks on allies. This means that when your goal is to do healing, you need to make sure that you are casting
the ability at an ally, otherwise you will be wasting a ton of healing. As previously mentioned, your goal
should be to cast this ability as much as possible when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun to proc [[spell:431377]].

[[spell:114165]] functions very similarly to Divine Toll in the sense that it functions differently
depending on if you cast it on an ally or an enemy. When cast on an ally, it will deal large single-target
healing and AoE damage to enemies around you. If cast on an enemy, it will deal large single-target damage,
and do AoE healing to nearby allies. You will generally prioritize casting this on enemies, in order to trigger
the AoE healing effect. Additionally, you want to cast this ability as much as possible when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun 
to proc [[spell:431377]].

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **31 Aug. 2025:** Rotation page overhauled and updated.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Page updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **24 Oct. 2024:** Avenging Crusader Rotation updated.
- **21 Oct. 2024:** Page updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Rotations updated for Patch 10.2.5.
- **06 Nov. 2023:** Page Updated for 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **07 Aug. 2023:** Updated rotation and added more info about Beacon of Light targetting.
- **10 Jul. 2023:** Rotations updated for Patch 10.1.5.
- **27 May 2023:** Avenging Crusader rotation updated.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Holy Paladin in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Holy Paladin

Welcome to our Gear and BiS Page for Holy Paladin for
[Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>). Check this page to learn everything
you need to know about gearing a Holy Paladin, including the
BiS Gear from all sources, Raiding, and Mythic+, information on the best Trinkets, Tier Sets, and
much more. Keep in mind that with Midnight comes a stat squish, meaning that each 
item will provide significantly less stats than it once had. Your overall damage and healing
will also be lowered as a result.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest HPS setup from all sources for Holy Paladin. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [QuestionablyEpic](<https://questionablyepic.com/>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, you are able to convert any item to a tier piece and it'll keep its original stats and effects! This means that your offpiece no longer matters as much.

[[item:268222]]

and

[[item:271878]]

will always be desired due to their higher item levels, but your other 2 remaining tier slots can change depending on what gear you have available.

- **Helm:** [[item:281239]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Shoulders:** [[item:251138]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **Chest:** [[item:268222]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Gloves:** [[item:271466]] from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **Legs:** [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details FAQWhat to Get From The Great Vault?
With [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) being able to be taken from the Great Vault instead of an item, you will prioritize getting these bonus rolls with your first vault. This will allow you to roll for an item on any dungeon or boss and receive a 1/6 Myth track version of the item. Because [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) drops us Myth track [[item:271878]] from Heroic, you will prioritize the bonus rolls to get this BiS item well before you have a chance to kill the boss on Mythic. By bonus rolling the boss you can also get access to [[item:268265]]. Keep in mind that dropped items from Mythic will be at 9/6 Mythic though, whereas bonus-rolled items cap out at 6/6.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271465@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271464@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:159412@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271468@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></div></td></tr><tr><th>Bracers</th><td>[[item:268239@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268211@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268262@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest HPS setup from all sources for Holy Paladin. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [QuestionablyEpic](<https://questionablyepic.com/>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, you are able to convert any item to a tier piece and it'll keep its original stats and effects! This means that your offpiece no longer matters as much.

[[item:268222]]

and

[[item:271878]]

from the new raid are highely desirable due to their higher item levels and unique effect. If you cannot obtain those items you will want to prioritize a combination of 4 from the list below.

**Pants**

are your least desirable slot.

- **Helm:** [[item:251126]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **Shoulders:** [[item:251138]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **Chest:** [[item:193753@JAAIAAQkCYHKvbRLfA]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- **Gloves:** [[item:251197]] from [The Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- **Legs:** [[item:273776]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Drops a shield: [[item:251196]] and one of the best dungeon trinkets: [[item:250214@JAACAAgNyA]].
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): Drops one of the best trinkets: [[item:250215@JAACAAgNyA]] as well as bracers and a neck.
- [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): Drops multiple good items but nothing outstanding.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271465@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271464@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:159412@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271468@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250214@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Bracers</th><td>[[item:251133@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:160216@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251150@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest HPS setup from all sources for Holy Paladin. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [QuestionablyEpic](<https://questionablyepic.com/>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, you are able to convert any item to a tier piece and it'll keep its original stats and effects! This means that your offpiece no longer matters as much.

[[item:268222]]

and

[[item:271878]]

will always be desired due to their higher item levels, but your other 2 remaining tier slots can change depending on what gear you have available.

- **Helm:** [[item:281239]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Shoulders:** [[item:271463]] from [The Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **Chest:** [[item:268222]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Gloves:** [[item:271466]] from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **Legs:** [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:271878]]: Cantrip leg item that you will catalyze. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:268265]]: Another cantrip item that drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270162]]: incredibly powerful trinket that drops from [Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>).
- [[item:270164]]: Second best trinket. Drops from [The Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271465@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271464@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268260@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271468@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></div></td></tr><tr><th>Bracers</th><td>[[item:268239@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268211@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268262@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Holy Paladin

As always, you should consult with [QELive](<https://questionablyepic.com/live/>) to determine
  your best trinkets as the list can often change with tuning. However, this season you will want
  to utilize [[item:270162@JAACAAgNyA]] and [[item:270164@JAACAAgNyA]]. Two incredibly
  powerful trinkets from the new raid. Mythic+ trinkets are unfortunately a bit
  undertuned in comparison but you do have a few good options to use while working
  to acquire your BiS trinkets from raid.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Holy Paladin BiS Trinkets**
**Best-in-Slot -**

[[item:270162]]

and

[[item:270164]]

.

**Honorable Mention -**

[[item:250214]]

.

:::

For direct trinket comparison, use
[QELive](<https://questionablyepic.com/live/>). We will
list a few special trinkets here with comments on their power level.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Holy Paladin Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270162]]</li>&#10;<li>[[item:281215]] (Mythic+ Only)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270167]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:248583]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270169]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274493]]</li>&#10;<li>[[item:251792]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:249343]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250254]]</li>&#10;<li>[[item:250248]]</li>&#10;<li>[[item:250255]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270171]]</li>&#10;<li>[[item:264507]]</li>&#10;<li>[[item:264701]]</li>&#10;<li>[[item:250254]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

In general, there are quite a few trinkets on a similar power level. Any
of the trinkets in a tier will be roughly equal to each other. This means that item level on trinkets is quite important.
F-tier trinkets are there because they are only better than an empty trinket slot.

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) can be used to acquire specific items from specific bosses
  or dungeons, by letting you gain a guaranteed piece of loot from a specific drop-location.
  The received item is random, but once an item has been acquired in this way,
  your next use of a Voidcore will grant one of the remaining items you haven't yet acquired.

With the release of Patch 12.1.5, you can obtain an additional Voidcore for free from 
**Orin Straylight** in Silvermoon, next to The Catalyst.

**Note that obtaining an item via drop or great vault does not remove it from your Bonus Roll pool.**

3.1.

#### Recommended Nebulous Voidcore Usage for Holy Paladin

There are a few different paths you can take for your Nebulous Voidcores and crafts. These are mostly early-season problems,
  and if you pick up the spec later in the season then you will have a lot more freedom in what you choose for both. **It is a big
  power loss to bonus roll Mythic+ early in the season.**

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Raid Voidcore Priority**
- Heroic (or Mythic) [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) until you obtain [[item:271878]] and [[item:268265]].
- Mythic [Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>) until you obtain [[item:270162]].
- Then: Fill in slots you don't have Myth-track items for yet. You can use QE Live in order to get the average bonus roll value from each boss and dungeon. Typically [The Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) can be a good choice.

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **M+/Heroic Raids Voidcore Priority**
- [The Blinding Vale](<https://www.wowhead.com/achievement=61641>) - [[item:250214]] (good)
- [Murder Row](<https://www.wowhead.com/achievement=41960>) - [[item:251126]] and [[item:251138]] (BiS)

:::

If you are on a fresh character, you will still want to prioritize bonus rolling
  [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) to get the key items. From there, it is often times going to be higher
  value to bonus roll [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>) due to the large amount of items that drop,
  and the two BiS tier slots that you can instantly catalyze. While this may mean
  that you do not get the most powerful trinkets right away, it can be the best way
  to quickly gear up a character. Otherwise you can instead roll Heroic/Mythic
  [Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>) or [The Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

3.2.

#### Ascendant Venomstones

The priority for using [[item:280562]] will always be on your **weapon.**
This provides you with the largest power increase. From there you can focus on
trinkets and then your offhand. The order is very similar to how you would spend
your crests at the start of a season:

1. Weapon
2. Trinkets
3. Off-Hand

You should always prioritize Myth track items unless in situations where you
will not get the Myth track variant anytime soon.

4.

### Best Crafted Items for Holy Paladin

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose the exact
secondary stats you want.

As your ability to craft items will be time-gated in the initial stages of
Midnight, you have two choices. Crafting an early **Mainhand weapon** or heading
straight into crafting items with [[item:240167]]. Players progressing
through the raid at a quicker manner may want to avoid crafting a weapon as they
will have access to weapon drops quite early into their Mythic progression.
Players not expecting to enter and clear Mythic early into the season will
benefit from the power that accompanies crafting an early weapon and should do so
as soon as possible.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Holy Paladin Crafted Gear Priority**
- [[item:237843]] with [[item:245876]] and Haste/Mastery
- [[item:237831]] with [[item:240167]] and Haste/Mastery
- Any item you do not have on Myth track yet.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Holy Paladin

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

We tend to recommend crafting weapon slots early as they will provide the
most initial power at the start of a new season, but they will not be your
overall Best in Slot items. In general your best in slot will be:

- [[item:237834]] with [[item:240167]] and Haste/Mastery
- [[item:237828]] with [[item:240167]] and Haste/Mastery

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select 
any of the choices in your Great Vault. Not picking a choice will grant you tokens, 
six of which can be traded in for the [[item:275707]] item that allows 
you to add a socket to the above piece of gear, if you acquired them in Season 2. 
You will generally not have any of these  until later in the season since it is 
better to take an item or a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>).

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

The priority will change heavily depending on whether or not you are crafting
a weapon. If you do not craft a weapon and instead get an early Myth track one
then you should prioritize upgrading the **weapon** first. Otherwise you can follow
the order below:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Holy Paladin Crest Upgrade Priority**
**Weapon Slots**

➜

**Special Effect Slots**

➜

**Helmet/Chest/Legs**

➜

**Trinkets**

➜

**Shoulders/Gloves/Belt/Boots**

➜

**The Rest**

:::

As previously mentioned, you will want to prioritize the items you know that
you will not replace. If you have a BiS Myth track tier helm, that would take
priority over a Hero track trinket that is not BiS. The above order assumes that
everything is Myth track.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on QE Live. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **01 Oct. 2026:** Helm and Feet BiS recommendation updated.
- **25 Aug. 2026:** Added extra information to bonus roll strategy.
- **17 Aug. 2026:** Minor trinket tier list updates.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Trinket tier list updated.
- **23 Mar. 2026:** Trinket tier list updated.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **14 Aug. 2025:** Trinket recommendations updated.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **13 May 2025:** Puzzling Cartel Chip Recommendations updated.
- **21 Apr. 2025:** Page Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Cyrces Circlet information added.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **16 Sep. 2024:** Embellishment information updated.
- **09 Sep. 2024:** Season 1 BiS Gear added.
- **21 Aug. 2024:** Reviewd and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **29 Nov. 2023:** BiS List and Embellishment recommendations updated.
- **07 Nov. 2023:** Embellishment and BiS list updated for sporecloak nerfs.
- **06 Nov. 2023:** Page Updated for 10.2.
- **04 Sep. 2023:** BiS gear added.
- **19 Jul. 2023:** Trinket tier list updated.
- **17 Jul. 2023:** Trinket tier list updated.
- **10 Jul. 2023:** Gear recommendations updated for Patch 10.1.5.
- **26 May 2023:** Information about Timewalking trinkets added.
- **20 May 2023:** Embellishment recommendations changed to account for bug fixes.
- **16 May 2023:** Embellishments updated.
- **01 May 2023:** Updated for Patch 10.1.
- **28 Mar. 2023:** Primordial Gem recommendations updated.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Jan. 2023:** Added Spark of Ingenuity crafting recommendations.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Holy Paladin. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Holy Paladin Stat Priority

The stat priority for a Holy Paladin varies based on your spell selection or
fight duration, your proximity to your healing targets, and your talents. We
will give the general stat priority, then explain how each of these can change
it for you. Having said that, our secondary stats are so close in value, and
Intellect is so strong at current gear levels that an item-level upgrade will
usually be worth equipping. You should use the information on this page to
help you decide if one similar item-level piece of gear is superior to
another.

If you are interested in min-maxing your stats to gain the highest amount of
HPS is possible; you can visit [QuestionablyEpic](<https://questionablyepic.com/>), a website dedicated to healer
theorycrafting. This website will compare your stats based on gear and logs
to tell you which items in your bags you should equip to make your character
as strong as possible. Otherwise, we will provide a brief rundown of what stats you will
want to prioritize depending on your build.

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Stat Priority

Item Level

Mastery

Haste

Critical Strike

Versatility

This stat priority focuses on maximizing the output of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun.
Given that Mastery provides us with the largest HPS increase from secondary stats,
it is what we will prioritize. Critical Strike will lose value from other builds
due to it not having as much impact for Herald.

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith Stat Priority

Item Level

Mastery

Critical Strike

Haste

Versatility

When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith, Critical Strike value will increase
significantly due to [[spell:433718]]. This causes [[spell:275773]]
critical strikes to deal healing to nearby allies. Much of your playstyle revolves
around maximizing your Judgment casts and we want to also increase the healing
it does by increasing the amount of Critical Strike we have.

That being said, Mastery continues to be our strongest stat and it is what
we will prioritize overall.

1.3.

#### Mythic+ Stat Priority

Item Level

Mastery

Haste

Critical Strike

Versatility

When playing Mythic+, you have quite possibly the most interesting choice
when it comes to allocating secondary stats. Mastery will continue to provide
you with the largest HPS increase, but it does not offer any increase to your
damage like the other stats will.

We recommend sticking with **Mastery** until you gain more comfort with
the new dungeons, increase your overall gear, and feel as though more healing
isn't need. At this point you can consider dropping Mastery to the bottom of your
stat priority in favor of stats that increase damage such as Haste and Critical
Strike.

2.

### In-Depth Stat Breakdown

Understanding the impact of each stat is crucial if you aim to truly minmax
your gear and performance. Below we will break down the impact that each stat
has.

- **Mastery** — Increases your healing done based on the proximity
  of your target. The closer you are to players, the more healing you will do.
  It is important to note that [[spell:197446]] changes this slightly.
  With this talent, the healing increase will also take into account the distance
  your Beacon targets are from players. If they end up being closer, the healing
  is increased relative to that distance rather than your own distance. This is
  one of the main reasons you are incentivized to spread your Beacons to ranged
  players who aren't often close to you. They can give you extra coverage in
  the room, increasing your Mastery effectiveness.
- **Haste** — Many spells in the game "scale with Haste". What this
  means is that their cooldowns are decreased as you obtain more Haste. For Holy
  Paladin, this applies to [[spell:20473]] and [[spell:275773]] most notably.
  The more Haste you have, the lesser cooldown these abilities will have. Additionally,
  Haste will reduce the cooldown of cast times for spells such as [[spell:19750]]
  and [[spell:82326]].
- **Critical Strike** — Gives you an increased chance for spells and attacks
  to deal additional healing or damage. Additionally, some abilities will only trigger
  off of Critical Strikes such as: [[spell:433718]] for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith.
  While more procs of this ability can be a massive boost for players using Lightsmith,
  Critical Strike runs into an issue where you get so much of it through various talents
  that stacking it on your gear loses effectiveness. [[spell:385515]], [[spell:387805]],
  and [[spell:384376]] all modify your Critical Strike chance in some way, leading
  to you often having more of it that you need, decreasing the overall desire to target
  gear with Critical Strike.
- **Versatility** — By far the least interesting stat, this increases
  healing and damage done by a small amount and decreases damage taken. Unfortunately,
  this stat does not compare to the alternative options. In very high Mythic+ dungeons
  you may see players running more amounts of it in order to live very high damage
  intakes that would otherwise 1-shot them, but most players will not experience this.
  Outside of that specific situation, you will typically avoid targeting gear with
  Versatility.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Page updated for Patch 11.0.5.
- **28 Sep. 2024:** Stat priority slightly shifted.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewd and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Holy Paladin, based on your [stat priority](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

It is important that in one socket you are always using either [[item:240968]]
or [[item:240983]]. Telluric will provide a bit more mana 
at the cost of some primary stat. Overall the difference is very minor and you 
can typically run what you feel comfortable with, or simply socket the cheaper option.

In Mythic+ you may value the mana less because you can drink in between pulls, while in
Raid the extra mana can be valuable when you are struggling on a fight. To conserve your
gold, you may want to start out with the maximum Mana gem, until you notice yourself never
running oom on a fight, at which point you can switch for a tiny bit more throughput.

When using [[item:240968]], you will want to have as many 
different color gems in your gear as possible. This means you should be using 
one of each of the following:

- [[item:240900]]
- [[item:240908]]
- [[item:240892]]
- [[item:240917]]

With the remaining gem sockets, or when using [[item:240983]], you will want
to use [[item:240900]]. That being said, you should continue to consult with
[QuestionablyEpic](<https://questionablyepic.com/>) to truly optimize your gems.

2.

### Best Enchants and Weapon Augments

The best Weapon Oil for Holy Paladin will be [[item:243733]].
The secondary stat boosts provides a nice bonus in every form of content and the alternative
[[item:243735]] is not strong enough to ever be worth using. When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith,
you will not need a weapon oil as [[spell:433568]] will instead be used.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244003]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240155]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243959]]</li>&#10;<li>[[item:244015]] (Damage)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

Consumables such as Flasks, Food, Potions, even Oils can increase your power by
a noticeable margin and are worth utilizing anytime you are doing challenging
content. If gold isn't a concern, you can choose to always use them!

3.1.

#### Flask

[[item:241322]] will be your go-to choice for maximizing
your healing output. In situations like Mythic+, where you do not need extra
healing, you can instead choose to run [[item:241325]] or
[[item:241326]].

3.2.

#### Potions

There are two potions that are worth considering in Midnight: [[item:241288]]
and [[item:241301]]. It is important to note that these potions share cooldowns. 
Using one of them will put all others on cooldown. In any situation where mana is 
concerned, you should be using [[item:241301]] only. When you do not 
need the mana you can instead use [[item:241288]] alongside your major
cooldowns.

Make sure to always keep [[item:271883]]s on you at all times. These potions
do not share a cooldown with combat/mana potions meaning that you can use them whenever you are
in need of emergency healing to yourself.

3.3.

#### Food Buff

You should be eating [[spell:1278895]] as the desired feast or 
[[item:242747]] for your own personal food. These provide you
with an increase to your primary stat and that beats out any other food choices.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **20 Aug. 2025:** Weapon enchant recommendation updated.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Page Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **30 Aug. 2024:** Consumable recommendations updated.
- **21 Aug. 2024:** Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **29 Nov. 2023:** Minor updates to gem recommendations.
- **21 Nov. 2023:** Weapon enchant recommendation updated.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **07 Aug. 2023:** Updated enchant recommendations.
- **10 Jul. 2023:** Recommendations Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **28 Mar. 2023:** Primordial Gem recommendations updated.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Holy Paladin in World of Warcraft Patch 12.1.5.

1.

### Holy Paladin in Mythic+ in Midnight Season 2

[Holy Paladin](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-guide>) is one of the better healing specializations for Mythic+. It
has excellent throughput for almost any healing situation in dungeons, many
defensive tools, multiple cooldowns for emergencies, and good damage for a
healer. [Holy Paladin](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-guide>) weaknesses in Mythic+ include low mobility, lack of a
standard interrupt, and limited options for crowd control.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

While Holy Paladin has a lot of strong single-target heals through [[spell:20473]]
and [[spell:85673]], the class can struggle when facing very hard-hitting party-wide damage.
Most players will end up underusing cooldowns, which can make AoE damage feel much
harder to deal with. Remember that [[spell:375576]] has a short cooldown that
you should be aiming to press often.

:::details TipsAvoid This Common Mistake!
One common mistake that players make that can make healing the party much more difficult
is the overuse of [[spell:53600]]. When you are unfamiliar with
how much damage your party will be taking, you should aim to sit on high holy
power as much as possible so that in case unexpected damage occurs, you already
have built up Holy Power ready to heal it quickly. This does not mean you cannot
ever deal damage with [[spell:53600]], but you should not spend 3
Holy Power on it the second you get that Holy Power. Try to save up until you
get 4 or 5, and then spend Holy Power before building it up again.

:::

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Mythic+ Talent Build

2.1.

#### Default ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Mythic+ Talent Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun provides you with [[spell:156322]], [[spell:431377]],
and [[spell:431425]], but most of the tree's value comes through passive effects.
An extra 5% Haste through [[spell:431404]] and extra [[spell:20473]] healing
via [[spell:431413]] and [[spell:200482]] make this a powerful tree
in Mythic+. It may offer less damage than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith, but it offers
significantly more healing through passive effects and new abilities.

[[spell:200025]] is taken due to synergy with buffed talents such
as [[spell:1232616]], [[spell:157047]], and [[spell:414139]].
[[spell:156910]] is still a fine choice for players who hate Virtue,
but you will lose a bit of healing output.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAMAAw2YmZmZMzMLwMDLjNzsY0EzyMmZGGzWGAGA2AbsMzMzysNzMbNAAAALgZwGMGGMDAgZGmxYYA"
}
```
:::

:::details 来源计算器编码
```
#BB-DGWzURilZmmCo9pz1lz2mELwfAKiTZ98iiOB-BNJMnLIePWdMtGKP0oMKIU:yAikLwKR-AAAA-GiE4IghChQxSDD-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith Mythic+ Talent Build

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith Mythic+ Talent Build

Where this build differs from ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun is that you lose access
to [[spell:375576]]. This can make it very difficult to keep up with group
wide damage and contributes to this build not being recommended in Mythic+.
That being said, the build does offer a bit more damage and is why it can at times be seen
at the very highest levels of keys. During these higher level keys, 
healers are required to contribute more damage to still be able to time keys, 
which makes the damage increase very valuable to them. However, the amount
of healing that is lost from not taking ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun generally
makes ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith much worse, unless you are solely focused on your
damage output.

[[spell:200025]] is taken due to synergy with buffed talents such
as [[spell:1232616]], [[spell:157047]], and [[spell:414139]].
[[spell:156910]] is still a fine choice for players who hate Virtue,
but you will lose a bit of healing output.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMmxMzMGzWGAGA2AbsYmBAAAmZWWWsMzwGbjZwGwMGAgZGAmxY0A"
}
```
:::

:::details 来源计算器编码
```
#BB-CDGIMUtilnD08ANNddpdbH4FnPVWloIPPxp-BJLMNnIemoPU48AKayqkKz2G3PQpAEHB-AAAA-BGUwwBiyCTgAhE-
```

:::

3.

### Utility Kit and Abilities

### Stuns and Stops

3.1.

#### Stunning and "Stops"

[[spell:853]] is your primary "stop". This will stun your target for a
small duration, preventing them from casting any abilities.

[[spell:20066]] is a crowd-control ability but will only work against
certain specific types of enemies. Using it will not place you in combat.

[[spell:115750]] is an Area of Effect that disorients enemies within 10
yards. The effect breaks when non-Holy damage is done to the target(s). It can
also be used to interrupt the spell-casting of one or more enemies and is considered
your primary "AoE stop". Again just keep in mind that enemies will instantly start
casting/attacking right after in a dungeon setting, so you will only be able to stop
a single set of interrupts/casts.

### Other Utility

3.2.

#### Other Utility

- [[spell:1022]] will remove bleeds and other physical damage
  over time effects such as [Grievous](<https://www.wowhead.com/mythic-affix=12>), as well as preventing all
  physical damage to the target for 10 seconds. It is often used on melee DPS players
  who might pull threat from your tank.
- [[spell:1044]] will remove or prevent the application of
  movement-impairing effects, including many that cannot be dispelled with
  [[spell:4987]].
- [[spell:465]] is a very strong defensive ability for yourself and
  your group. Use of [[spell:31821]] with it can prevent large amounts of
  damage and save party members from very large damage spikes, especially those
  who lack defensive abilities. Try to stand within range of the tank when
  possible for maximum benefit.

4.

### Dealing with Affixes

Season 2 of Midnight only has four significant Affixes that offer any kind
of counterplay, called Xal'ataths Bargains. These rotate every week, with only
one of them being active at a time. Many of the Mythic+ affixes, like Fortified or
Tyrannical, simply add a passive effect to the keystone, with these four exceptions
that are seasonally themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. [[spell:115750]] is incredibly useful in
  these situations but you will typically only be able to use it on every other
  wave.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn that
  needs to be focus-targeted and interrupted. Healers can typically not help
  with this affix beyond helping to deal a bit of extra damage to it.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and circle
  around them. You have 15 seconds to soak all of these to buff your group.
  While not required, healers can often be very good at running around and soaking
  whatever is unsoaked so DPS can stand still and maintain uptime. Of course you
  will not want to do this during difficult healing moments.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb. This effect can be dispelled and you will want to make sure that
  you are dispelling players unable to clear it themselves as soon as possible in
  order to get 2 dispels off. This will allow you to only worry about clearing
  a few players debuffs. Typically passive healing will be enough to break this
  absorb, but you should always prioritize healing on players with the debuff
  when possible. [[spell:1044]] can also be used to remove this effect
  from players, and when combined with your standard dispel you may not need to
  heal anyone at all.

If these affixes are not handled, they will buff enemy trash and bosses.
However, when you are able to handle them they will provide your entire group
with beneficial buffs, increasing your output or survivability.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **04 Apr. 2026:** Mythic+ talent builds updated.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Page Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Page updated for Patch 11.0.5.
- **28 Sep. 2024:** Dungeon tips added.
- **09 Sep. 2024:** Season 1 Information added.
- **30 Aug. 2024:** Talent build updated.
- **17 Aug. 2024:** Reviewd and Updated for The War Within.
- **20 Jul. 2024:** Page Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Talent recommendations updated.
- **13 Nov. 2023:** Talent recommendations updated.
- **06 Nov. 2023:** Page Updated for 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **07 Aug. 2023:** Updated talent recommendations.
- **17 Jul. 2023:** Talent recommendation updated.
- **10 Jul. 2023:** Talents updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **22 Feb. 2023:** Talent recommendation updated.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Holy Paladin in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Holy Paladin macros.

1.1.

#### Holy Paladin Specific Macros

When playing a Healer, it is recommended that you utilize Mouseover
Macros that will allow you to heal players without having to target them
specifically. This means that you can simply position your mouse ontop of
the desired players unitframe and cast your desired spell. An example of
a mouseover macro would look like:

#### Basic Mouseover Example

```wow-macro
#showtooltip Holy Shock
/use [@mouseover,help,nodead][help,nodead][@player] Holy Shock
```

Additionally, you can utilize in game settings rather than needing to create
individual macros for each ability. You can do this by enabling "Mouseover Cast"
in the interface settings. You will also need to disable the "auto selfcast" 
setting once enabling mouseovers; otherwise every spell will be cast on you.

1.2.

#### Generic Macros for Paladins

Mouseover Macros are also recommended for core Paladin abilities that you
can utilize for many different abilities. If you decide to not to enable the
mouseover seting previously mentioned, here are a few Macros we would recommend
using in your gameplay:

#### Lay on Hands Macro

```wow-macro
#showtooltip Lay on Hands
/stopcasting
/cast [@mouseover, help, nodead] Lay on Hands
```

#### Combat Res Macro

```wow-macro
#showtooltip Intercession
/stopcasting
/cast [@mouseover, dead, exists] Intercession
```

This macro will cast [[spell:391054]] on the target you are currently
mousing over.

#### Divine Shield Macro

```wow-macro
#showtooltip Divine Shield
/stopcasting
/cast Divine Shield
```

This macro will stop your current spell cast and cast
[[spell:642]]. This prevents you from finding yourself in situations
where you are unable to become instantly immune due to having a cast
currently going.

#### Mouseover Blessing of Protection

```wow-macro
#showtooltip Blessing of Protection
/stopcasting
/cast [@mouseover, help, nodead] Blessing of Protection
```

#### Mouseover Blessing of Freedom

```wow-macro
#showtooltip Blessing of Freedom
/stopcasting
/cast [@mouseover, help, nodead] Blessing of Freedom
```

#### Mouseover Blessing of Sacrifice

```wow-macro
#showtooltip Blessing of Sacrifice
/stopcasting
/cast [@mouseover, help, nodead] Blessing of Sacrifice
```

2.

### Best Addons

2.1.

#### Harreks Advanced Raid Frames

In [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), many addons, weakauras, and overall functionality
has been removed. [Harreks Advanced Raid Frames](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>) gives you back
some of the functionality of raid frames, allowing you to fully customize what
buffs you can and cannot see on your frames, as well as the individual locations
in which the buffs appear. Without this addon, you will be unable to fully customize
your raid frames, regardless of which addon you download. Thankfully, Harreks Advanced
Raid Frames are usable with the majority of raid frame addons, giving you the best
of both worlds. If you have additional questions or require assistance, you can visit
Harreks discord, [Spiritbloom.Pro](<https://discord.gg/spiritbloompro>).

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewd and Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
