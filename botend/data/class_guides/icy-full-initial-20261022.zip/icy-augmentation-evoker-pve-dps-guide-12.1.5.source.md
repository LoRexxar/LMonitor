## 专精概览

Welcome to our Augmentation Evoker guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Augmentation Evoker in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Augmentation Mythic+ Resources

[NEW! Top Augmentation Talent Builds](<https://raider.io/specs/augmentation-evoker/talents>)

[Top Augmentation Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/evoker/augmentation>)

[Augmentation Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=evoker--augmentation>)

[Popular Augmentation Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=evoker--augmentation>)

1.

### Augmentation Evoker Overview

Augmentation Evoker is a support-oriented ranged caster DPS
  specialization that focuses on maintaining powerful buffs on its allies in
  order to deal damage.

Augmentation is the only support-oriented DPS Specialization in the game currently,
  offering a unique experience compared to other DPS options available.
  Augmentation Evoker offers a large suite of utility that it can deploy in fights
  to further assist allies. Overall, its an excellent choice
  for both Raiding and Mythic+ with strong damage and utility.

Augmentation Evoker is the first support-oriented specialization
  in World of Warcraft and acts as a mid-range caster DPS and has a **range of
    25 yards** for most of their abilities, although this can be extended to 30
  yards on your helpful spells (buffs, heals) with [[spell:454983]].

Powerful and Flexible Damage

Augmentation Evoker has a powerful and unique damage profile which mirrors
  the damage dealt of its allies. This lets you further augment your teams
  strengths in any scenario letting you handle anything a fight throws your
  way.

Augmentation Evoker's Apex Talents are exceptional, adding more power to
  buffs as well as personal damage.

Augmentation Evoker's DPS falls slightly when played with weaker teammates as
  so much of its damage comes from buffs. Despite this, it will always be
  competitive within your specific group.

Excellent Raid Choice

In raid, Augmentation Evoker is a very strong pick up for any raiding team,
  offering powerful Utility, high mobility, good defensiveness alongside a
  Cheat Death. Furthermore, Augmentation Evoker gets access to powerful
  stackable Evoker raid utility, such as [[spell:374227]],
  [[spell:406732]], or [[spell:374968]].

Good Damage and Utility for M+

Augmentation Evoker is slightly weaker in Midnight Season 2 compared to
  Midnight Season 1 but remains a viable option. Augmentation Evoker is still
  significantly stronger than it was prior to Midnight despite the nerfs it has
  received in Season 2.

Additionally, Augmentation Evoker has an excellent kit for Mythic+ with
  frequent AoE CC from [[spell:396286]], true CC to enable skips from
  [[spell:360806]], as well as strong utility like [[spell:374251]]
  that can remove bleeds.

Versatile Utility

Augmentation has a large utility kit that is extremely powerful in all
  content. Augmentation can increase the survivability of other allies with
  [[spell:374227]]; improve allies mobility with either [[spell:406732]],
  [[spell:374968]], [[spell:370665]], or [[spell:408233]]; CC
  enemies with [[spell:358385]], [[spell:360806]], [[spell:396286]],
  [[spell:357214]], or [[spell:307974]].

Augmentation Evoker can increase the power of the healer with
  [[spell:369459]] empowered by [[spell:418101]]. This helps to
  compensate for the lack of a potent Raid Buff in Mythic+.
  On top of this, [[spell:374251]] lets Augmentation Dispel almost any
  debuff once every minute, including Bleeds! This significantly helps healers
  handle encounters as the game is full of extremely dangerous debuffs.

Good Defensives and a Cheat Death!

Augmentation Evoker has a Cheat Death alongside powerful defensive
  abilities. Augmentation has two charges on its main defensive,
  [[spell:363916]], giving it excellent flexibility and top tier
  Survivability.

The Defensives Augmentation Evoker has are: [[spell:363916]],
  [[spell:374227]], and [[spell:404195]], which is a cheat death on a 6 minute
  Cooldown (5 minute with [[spell:1268881]]).

Exceptional Mobility

Augmentation Evoker has excellent mobility, having access to [[spell:358267]]
  which allows it to cast all spells except its empowers ([[spell:357208]]
  and [[spell:396286]]) while moving.

Additionally, [[spell:358267]] allows it to traverse a large distance quickly
  if used while holding a direction key, as it will dash in that direction.

2.

### Augmentation Evoker in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

This patch offers two new interesting pieces of endgame
      content, a new raid to fight and new endgame [Delves](<https://www.icy-veins.com/wow/delves-guide>)
      to explore. Make sure to check the information on the new
      Kith'ix Raid encounter, as well as the new exciting
      Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
    a Trinket, Ring, and Gloves. Additionally, you will be able to upgrade items with 
    [[item:280562]] starting October 20th. Weapons, Necks, and Trinkets can all 
    be upgraded.

2.3.

#### Class Changes

Augmentation Evoker received a few small bugfixes to
      [[spell:406380]] in Patch 12.1.5. They have
      added several spells that were previously missing to
      the duration extension effect. The most notable new
      includes are [[spell:431695]] from
      ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden and, [[spell:1297728]]
      from the [[spell:1296638]].
      This slightly improves our Mastery scaling but it
      was already our best stat so this does not change
      any gearing.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/classicon_evoker_augmentation.jpg>)Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Changes

Along with Season 2 comes an expansive new area which features a whole
      host of new areas and activities alongside the endgame PvE and PvP
      Content. The new area is [Coiled Isle](<https://www.icy-veins.com/wow/the-coiled-isle-guide>) and grants you access to
      [Vaults of Atal'Utek](<https://www.icy-veins.com/wow/vaults-of-atalutek-guide>) which are the main locations where the story
      of Patch 12.1 happens, containing new rares and treasures to hunt, as
      well as new housing ans transmog items. Blizzard also significant updates
      to existing systems and added more quality of life improvements. For more
      information, check out our patch 12.1 hub linked below!

2.5.

#### Patch 12.1 Class Changes

Augmentation Evoker has received some high impact changes to its Hero
      Talents for Midnight Season 2 that alter optimal Hero Talent choice,
      talent builds, and stat priority. We will briefly go over the changes
      below.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander has had significant nerfs to
      [[spell:441206]] vastly reducing the power of the talent. You now get
      approximately half the cooldown reduction you previously got on 
      single-target amount of cooldown reduction that is possible to get. 
      Blizzard tried to offset the damage loss by buffing the damage nodes tied 
      to [[spell:403631]] casts it was not sufficient to offset the loss of
      [[spell:1259173]] uptime.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden had [[spell:431874]] redesigned to be a
      temporary buff upon casting [[spell:395152]] instead of lasting for
      an entire cast. This change is approximately a 1-2% DPS nerf for
      ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden and nerfs the Critical Strike Scaling of
      Augmentation.

Additionally, during Season 2 as an Augmentation Evoker you have access
      to a new set bonus, listed below:

- 2-Piece Bonus: [[spell:1296637]] —
          [[spell:396286]]'s cooldown is reduced by 10 seconds.
- 4-Piece Bonus: [[spell:1296638]] —
          Casting [[spell:396286]] magnifies your [[spell:412774]] effects
          for 8 seconds, increasing the amount of damage echoed to 45% (normally
          15%).

Due to all of the changes above and the new Tier Set, we will be moving 
      towards ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden buff centric gameplay. We will be 
      focusing around stacking Mastery while playing 
      [[spell:409267]] for more powerful [[spell:413984]] and, 
      higher uptime of other supportive buffs such as [[spell:409311]], 
      especially with our new Tier Set improving the damage of 
      [[spell:412774]].

With a higher emphasis on Augmentation's buffs, the correct targeting of
      [[spell:409311]] is now more relevant and is approximately a 3-5% DPS 
      gain over using auto targeting.

To see the full list of changes please see below:

[Curse of Ula'tek Patch Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281/#item16>)

**Augmentation Evoker**

<em>Developers' notes: The additional stopping power created by
              Duplicate-cast Upheavals was more warping to dungeon gameplay
              than desired, and could be frustrating in some situations due to
              its uncontrolled timing.</em>

- Apex Talent: [[spell:1259173]] — [[spell:396286]]
                casts by your [[spell:1259173]] no longer knock enemies into
                the air.
- All ability and pet damage increased by 3%.
- The Midnight Season 1 2-set bonus no longer increases the
                duration that Eruption extends [[spell:395152]].
- [[spell:404195]], [[spell:355913]], 
                [[spell:361469]], [[spell:410643]], [[spell:387761]], and 
                [[spell:360995]] healing increased by 25%.
- Hero Talents
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden
  - - <em>Developers' notes: The behavior of an
                              [[spell:395152]] critical strike's stat bonus
                              lasting for the full duration of the 
                              [[spell:395152]] put more emphasis on tracking 
                              [[spell:395152]]'s critical state than desired, 
                              and created an unintuitive decision space
                              regarding whether re-casting [[spell:395152]] was
                              correct.</em>
    - [[spell:431874]] has been updated — The
                            additional stats granted when [[spell:395152]] 
                            critically strikes now last 15 seconds (modified by
                            [[spell:406380]]). If [[spell:395152]] 
                            reapplies [[spell:431874]] while it is already active, 
                            [[spell:431874]]'s duration is extended instead of 
                            overwriting the previous [[spell:431874]] effect. 
                            [[spell:431874]]'s functionality with 
                            [[spell:409311]] is unchanged.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander
  - - <em>Developers' notes: [[spell:441206]]'s cooldown
                              reduction mechanic strongly incentivized spreading
                              [[spell:434300]] applications across multiple
                              targets. We feel that this gameplay is unintuitive in 
                              isolation, and additionally creates unhealthy behaviors 
                              such as [[spell:438587]] pooling. This redesign is 
                              intended to retain the multitarget focus of the talent, 
                              while addressing those issues. We are increasing some of
                              Scalecommander's sources of area damage to compensate
                              for the lessened cooldown reduction the new
                              [[spell:441206]] will provide, and will be keeping a 
                              close eye on Devastation and Augmentation’s performance 
                              over the course of PTR to make additional adjustments 
                              as needed.</em>
    - [[spell:441206]] has been redesigned —
                            [[spell:438587]] reduces the remaining cooldown of
                            [[spell:403631]] by 1.5 seconds for each target
                            struck.
    - [[spell:1260745]]'s [[spell:1236970]] damage
                            increased by 40%.
    - [[spell:433871]] damage over time increased by 40%.

:::

### Midnight   Changes Overview

2.6.

#### Midnight Changes Summary for Augmentation Evoker

With the Midnight Expansion Augmentation Evoker has received a
      number of changes that slightly adjust how it plays with a general goal
      of simplifying its moment to moment decision making regarding buffs,
      primarily in Raid. We have broken down these changes into smaller
      categories to make it easier to understand the changes that
      Augmentation Evoker is receiving during Midnight. All of the
      changes Augmentation Evoker has received have been listed below.

2.7.

#### Apex Talents

While leveling in Midnight you will gain access to Apex Talents. These
      are powerful nodes at the bottom of your Specialization Tree. You will be
      able to put a talent point into these at levels 81, 84, 87 and 90.
      Augmentation's Apex Talents are listed below:

- [[spell:1259173]]
- [[spell:1259174]]
- [[spell:1259175]]

Augmentation's Apex Talent is focused around [[spell:1259173]]. This
      makes [[spell:403631]] summon a pet that casts [[spell:396286]],
      [[spell:357208]] and [[spell:395160]] alongside you. These casts
      only deal damage and do not extend your [[spell:395152]] or cause
      [[spell:413984]]. During Duplicate you receive significant boosts
      to personal damage and the power of [[spell:395152]] thanks to the
      fourth Apex Talent Point [[spell:1259175]].

Augmentation Evoker's Second and Third Apex Talent Points
      [[spell:1259174]] and [[spell:1259175]] will cause anything that
      extends [[spell:395152]] to also extend the Duplicate at 50/100%
      effect. This causes you to shift towards focusing on Haste and Critical
      Strike Chance as these both impact the uptime of the duplicate while
      Versatility and Mastery do not.

For more information on the Apex Talent please see the
      [dedicated
        section on our Talents Page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents#apex>).

2.8.

#### Buff Changes

We have received significant changes to how our buffs work. These changes
      do not affect gameplay in Mythic+, while making Raiding play more
      similarly to Mythic+. In Raid going forward, the only buff that you will
      need to manually target on players will be [[spell:409311]], which no
      longer has secondary implications, as [[spell:395152]] now affects
      everyone. This lets you focus on buffing your allies that are doing the
      most damage **now**, without having to think about how much damage
      they will be doing in 30 seconds.

These changes result in a slight buff power decrease for Raiding, a large
      simplification of buff management for Raiding and a significant potency
      increase for buffs in Mythic+ (+45% for [[spell:395152]] and +36%
      for [[spell:403631]]).

Altogether, these changes bring Raiding and Mythic+ gameplay more in
      sync for both rotation and output, normalising how the class functions in
      all content. This should make it significantly easier for Blizzard to
      tune going forwards.

:::details **Click to expand to see changes.**
[Midnight Beta Test Development Notes](<https://www.wowhead.com/blue-tracker/topic/us/midnight-beta-test-development-notes-2174760>)

Developers' notes: The goal of these changes is to simplify Ebon
            Might targeting in raid environments. Since it now applies to all
            members of the raid, there is no need to micromanage who it
            should go on. There will still be some buff management gameplay
            with Prescience, which will continue to have a smart-targeting
            option for those who do not want to swap targets between enemies
            and allies frequently. Overall, this should make raid gameplay
            much smoother and similar to dungeon gameplay.

- [[spell:395152]] applies to all damage dealing allies within
            100 yards and DPS can now be affected by any number of
            [[spell:395152]].
- [[spell:403631]] and [[spell:403631]] now reduce their
            effect if affecting more than two other allies.
- [[spell:395152]] now grants 8% Primary Stat (was 5%).
- [[spell:403631]] now accumulates 15% of damage (was 10%).
- [[spell:396043]] has been disabled as it no longer is
            needed to bring Mythic+ and Raiding to parity.
- [[spell:409311]] is still capped to a maximum of 2 (1 per
            Augmentation Evoker).
- [[spell:413984]] is still capped to 1.

:::

2.9.

#### Chronowarden Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden has received relatively significant changes that
      smooth out the overall gameplay experience, making it more consistent to
      play and lowering rotational friction. The design now focuses on stronger
      [[spell:409311]] casts, while removing constraints like trying to
      maximise the number of empower casts during [[spell:431695]]. These
      changes align with making ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden the main buff focused
      Hero Talent for Augmentation Evoker.

:::details **Click to expand to see changes.**
- Removed Talents: [[spell:431715]] and
            [[spell:431840]].
- Reworked Talent: [[spell:432004]] mdash; now makes
            [[spell:409311]] last 15% longer (Previously 20% chance to be
            100% longer).
- New Talent: [[spell:431715]] — Reduces the Cooldown of
            [[spell:409311]] by 2 seconds and increases the Critical Strike
            Chance Buff provided by 1% to 4%.
- New Talent: [[spell:1260484]] — Reduces the
            Cooldown of [[spell:370553]] by 30 Seconds.
- New Talent: [[spell:1260568]] — [[spell:431695]]
            grants an [[spell:396187]] every 6 seconds (5
            [[spell:396187]]s in total).
- New Talent: [[spell:293930]] — [[spell:431442]] maximum
            damage is increased by 40%.

:::

2.10.

#### Scalecommander Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander has received relatively minor changes opting to
      further double down on increasing the damage of [[spell:395160]] and
      the personal damage output of Augmentation Evoker. These
      changes do not change your gameplay and allow you to further specialise
      in what ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander already excelled at.

:::details **Click to expand to see changes.**
- New Talent: [[spell:1260745]] — While flying during
            [[spell:403631]] or [[spell:357210]] summon 2 Dracthyr that
            will cast [[spell:1236970]] up to 4 times each (8 times total).
- New Talent: [[spell:1261448]] —
            [[spell:438587]] strikes 1 additional target.
- New Talent: [[spell:1261452]] — [[spell:395160]]
            deals 15% more damage.
- Adjusted Talent: [[spell:441257]] — Now grants only one
            charge of [[spell:358267]] instead resetting all charges.

:::

2.11.

#### Defensive Changes

Augmentation Evoker received several nerfs to its defensive
      talents, resulting in a slight decrease in survivability going forwards,
      the most notable being the loss of [[spell:370888]] as a defensive
      option. Other Specializations are receiving comparable nerfs to their
      defensives as part of broader, game-wide changes to healer and defensive
      balance, so Augmentation Evoker is still very durable relative
      to other classes.

:::details **Click to expand to see changes.**
- Reworked Talent: [[spell:370888]] — Now increases
            movement speed of you and the target of [[spell:370665]] by 100% and
            allows cast while moving for 3 seconds instead of giving an absorb
            shield equal to 30% of your health.
- Reworked Talent: [[spell:374348]] — This is now passive
            and causes [[spell:363916]] to heal you equal to 100% of
            damage it reduced over 8 seconds (Was an active Defensive).
- New Talent: [[spell:1268881]] — Reduces the cooldown
            of Defy Fate by 1 minute and increases its healing by 100%.
- Moved Talent: [[spell:410352]] — This is now on the Class
            Tree instead of the Specialization Tree and has been buffed to
            stagger 100% of all damage taken during [[spell:403631]].
- Removed Talent: [[spell:386405]]

:::

2.12.

#### Core Spell and Talent Changes

Augmentation Evoker received several changes to Spells and
      Talents which only cause minor changes to rotation. The most significant
      rotational change comes from [[spell:459725]]. With the new
      [[spell:459725]], it is now optimal to only use Rank 1
      [[spell:357208]] rather than upranking it. The other changes mainly
      contribute to quality-of-life and small adjustments to damage output.

:::details **Click to expand to see changes.**
- Spell Change: [[spell:358267]] — Can now be cast while casting
            granting you the [[spell:358267]] buff. It also no longer has an
            Animation Lockout letting you use it at almost any time (except
            during Empowers).
- New Talent: [[spell:1250914]] — Increases
            [[spell:409267]] chance to Proc by 10% and allows it to
            grant [[spell:409311]] to allies.
- Reworked Talent: [[spell:459725]] — Enemies affected by
            [[spell:357208]] now take 25% increased damage from Black Spells
            (Previously, scaled between 10 and 40% depending on Empower Rank).
- Reworked Talent: [[spell:459537]] —
            [[spell:403631]] reduces the Essence cost of your next 4
            [[spell:395160]]'s by 1, stacking up to 8 times (Previously
            lasted for 15 seconds and increased [[spell:395160]] damage by
            10% for the duration).
- Buffed Talent: [[spell:408775]] —
            [[spell:396187]] reduces the cast time of
            [[spell:395160]] by 40% and increases its damage by 20%
            (Previously only reduced the cast time). Moved to
            [[spell:1219236]]'s old position.
- Buffed Talent: [[spell:406907]] — Now increases
            the damage of [[spell:360827]] by 20% and stops it from
            losing charges (Previously, added 5 charges and gained an
            additional charge every time you cast [[spell:395160]]).
- Buffed Talent: [[spell:410261]] — When casting
            [[spell:357208]] you and one nearby ally gain the Inferno's
            Blessing Buff. [[spell:410261]] damage buffed 4x to
            compensate for affecting less targets (Previously affected you and
            4 allies).
- Removed Talent: [[spell:1219236]]
- [[spell:351338]] is now learned in the Augmentation Tree.

:::

3.

### Basics of Augmentation Evoker Gameplay

Augmentation Evoker's core gameplay is about buffing your allies
  and accomplishes this by casting [[spell:409311]] and maintaining
  [[spell:395152]]. Augmentation Evoker has many interactions that help
  with this. The backbone of Augmentation Evoker can be best summarized through
  these three concepts.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_sarkareth.jpg>)
  **Maintain your Ebon Might**  
  
      Augmentation's main damage contributor is [[spell:395152]], as it
      provides a large primary stat buff to your allies while also boosting your
      own damage. Your highest priority is to maintain this buff by casting
      [[spell:395152]], [[spell:357208]], [[spell:396286]] and
      [[spell:395160]] as much as possible.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_prescience.jpg>)
  **Cycle Ability Cooldowns**  
  
      Augmentation has three important short cooldown abilities:
      [[spell:357208]], [[spell:396286]] and [[spell:409311]]. These
      abilities cause powerful buffs on allies that make up a large portion of
      your damage meaning it is crucial to maximise uses!
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_eruption.jpg>)
  **Spend All Available Resources**  
  
      Augmentation has two important resources: Essence and
      [[spell:396187]]. These can be used to cast
      [[spell:395160]] which is crucial to deal damage and maintain
      [[spell:395152]]. You will generate Essence over time and get
      [[spell:396187]] from [[spell:409311]] and
      [[spell:361469]].

Most of your rotational depth comes from
  choosing correct targets for [[spell:409311]] and using the various
  interactions listed above to extend [[spell:395152]] as long as possible.

4.

### How to Gear Up as a Augmentation Evoker

While we always recommend simming yourself for ideal results, we do provide a
  dedicated Augmentation gearing page. We currently cover recommendations for
  Season Two gear to start off on the right foot for the release of endgame
  Midnight content. Once you've picked up some gear, you'll need the
  appropriate consumables, gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for PAtch 12.1.5.
- **12 Oct. 2026 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5 adding new Raid Boss items.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Revieed for Patch 12.1.5
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for Patch 12.1.5 including new Mythic+ Build.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update trinket Tierlist and crafting recommendations for the changes.
- **18 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Add Missing Ebon Might cast to Rotation Opener for Chronowarden.
- **12 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Correct Mythic+ Item Sources typos for ring and cloak.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 (this page):** Updated for Midnight Season 2.
- **26 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Drop Gaze of the Alnseer in the M+ Tier List due to the bug reducing the average stacks not being resolved.
- **16 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Typo fix in Sporefused Section.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Add section for Sporefused Gear.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.7. Added Overlord Build for High Keys.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7 adding Omnium Folio information. Change High Keys build to Overlord.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **04 May 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update Mythic+ Trinket Ranking.
- **04 May 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Adjust Talent build comments. Talent Builds themselves are unchanged.
- **04 May 2026 (this page):** Updated for May 5th/6th Tuning
- **30 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Correct Spelling Mistake.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update Gear section for Ascendant Voidcores and Nebulous Voidcores. Update Trinket Tierlists.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Fixed typo in Recommended Gem.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5 with new talent builds.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for Patch 12.0.5 shifting to Echoing Strike build.
- **20 Apr. 2026 (this page):** Updated For Patch 12.0.5.
- **27 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Add Litany of Lightblind Wrath trinket.
- **23 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Drop Vessel of Tortued Souls placement on the tierlist.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Remove the Gathering Teas from the consumables section. These no longer work.
- **19 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Soulcatchers Charm Trinket now properly drops for Evokers.
- **19 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Motes of Possibility has been removed from all Chronowarden Builds.
- **19 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Motes of Possibility has been removed from all Chronowarden Builds.
- **19 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for the Motes of Possibility Change.
- **19 Mar. 2026 (this page):** Updated for more information about the Motes of Possibility Change.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update Trinkets and Tierset information.
- **17 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated Talent Build based on nerfs.
- **17 Mar. 2026 (this page):** Updated for Last Minute Tuning Hotfixes.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for Midnight Pre-Season.
- **26 Feb. 2026 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Midnight Pre-Season.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Season.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Updated for Midnight Pre-Season.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Season.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Midnight Pre-Season.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Season.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Season.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Added Apex Talents for Midnight Launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for Midnight Pre-Season.
- **26 Feb. 2026 (this page):** Updated for Midnight Pre-Season.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Fix Opener having Fire Breath Hidden
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Builds updated for Midnight 12.0.1 Prepatch
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 (this page):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Midnight pre-patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for patch 11.2.7
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated Intro for Patch 11.2.7
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated to include information for Dinars and Tierset Comparison.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Fix a typo in a spell name.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated Intro for Patch 11.2.5
- **10 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update Gear Page indicating tierset performance after Hotfixes.
- **10 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Remove Tierset Disclaimer. Rotation is unchanged.
- **10 Sep. 2025 (this page):** Updated Intro with information about Patch 11.2 Hotfixes.
- **22 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Fix Rotation Sequencing Problems for Chronowarden Opener.
- **20 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated Scalecommander Talent Builds.
- **12 Aug. 2025 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Add Buff Information for Season 3.
- **12 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update Trinket Tierset after initial Trinket Tuning.
- **09 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Change ordering of Easy Rotation to be less confusing to people.
- **05 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update Tierset Values for Scalecommander, change Trinket Tierlist, and adjust BiS List.
- **05 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Hero Talent tuning Hotfixes. (Chronowarden for Raid, Scalecommander for M+)
- **05 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Remove Chronowarden Stat Priority from Easy (as we suggest Scalecommander).
- **05 Aug. 2025 (this page):** Add warning about constantly influx tuning.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Update Easy Mode Page for Patch 11.2
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update DISC Recommendation for Nerfs
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7 to include the DISC belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7 with information about the Combat Assistant and Single-Button Assistant.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7 fixing an error in a descriptive section.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Update Easy Mode for Patch 11.1.7 and Assisted Combat. Swap the builds to Chronowarden because they perform better with the Combat Assistant due to not being reliant on Time Skip.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update a few trinket comments.
- **08 May 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Completely update the gear list for the Patch 11.1.5 Hotfixes causing stat priorities to change.
- **08 May 2025 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5 Hotfixes changing best Enchantments and Gems
- **08 May 2025 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for Patch 11.1.5 Hotfixes changing Stat Priorities.
- **08 May 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** Talent Builds updated due to Patch 11.1.5 Hotfixes.
- **08 May 2025 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated talent builds for Patch 11.1.5 Hotfixes.
- **08 May 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Update Easy Mode Talents and Stats due to Patch 11.1.5 Hotfixes.
- **08 May 2025 (this page):** Updated for Patch 11.1.5 Hotfixes which causes significant build and gearing changes.
- **02 May 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated Dinar Section.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5 with Horrific Visions Enchantments.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **12 Apr. 2025 (this page):** Updated for Second Set of Patch 11.1.0 Hotfixes.
- **25 Mar. 2025 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Updated for Patch 11.1.0 Hotfixes including initial data from raid.
- **25 Mar. 2025 (this page):** Updated for Patch 11.1.0 Hotfixes.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** Updated with information for Gallywix
- **04 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Raid Week 1 Gear Tuning.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for Patch 11.1 with different talent ordering because of new talent.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** All buff mechanics were updated for Patch 11.1. Best Buff section temporarily removed.
- **24 Feb. 2025 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1 with new BiS Lists and trinket information.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.1
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for Patch 11.1 with Mastery being dominant for all Hero Talents.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1 including Rotation changes for Season 2 Tierset.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1 for the new talent changes.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1 changes
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **04 Jan. 2025 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update Trinket Tierlist to increase the rank of Cirrals Concoctory.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Cyrce's Ring Recommendations updated with the changes.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Recommended gear pages updated with Cyrce's Ring's. Comment about Roaring Warqueens added to gear section for M+.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7 adding Cyrce's Ring, BiS changed.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for Patch 11.0.7 with Mastery beating Crit for Scalecommander
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.7
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7
- **05 Dec. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Updated for latest tuning during Patch 11.0.5
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for Patch 11.0.5
- **21 Oct. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Added disclaimer for Patch 11.0.5
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update for Patch 11.0.5
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.5 with new default build strings
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5 changing the class talent tree.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.5 with new class trees due to changes.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for Patch 11.0.5
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5
- **21 Oct. 2024 (this page):** Update for Patch 11.0.5
- **04 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** Add information for Silken Court and a lot of information for Queen Ansurek. Update Rashanan.
- **04 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Update default Scalecommander M+ Build based on hotfixes.
- **04 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Update default Scalecommander M+ Build based on hotfixes.
- **04 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Update default Scalecommander M+ Build based on hotfixes.
- **04 Oct. 2024 (this page):** Update to mention new Hotfixes for Overlord.
- **22 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Correct Typos.
- **22 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Update Rotation for Scalecommander & Molten Embers.
- **22 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Correct Typos.
- **22 Sep. 2024 (this page):** Update to mention Molten Embers and Scalecommander.
- **21 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for new Scalecommander Information.
- **21 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for new Scalecommander information.
- **21 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** All recommendations swapped to Scalecommander.
- **21 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Update for new Scalecommander builds and change to Molten Embers.
- **21 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for Molten Embers Change
- **21 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** All recommendations swapped to Scalecommander.
- **17 Sep. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Update buffs page for a better snapshot of Mythic week launch.
- **17 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update Trinket Tier List for Mythic Launch.
- **13 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Remove Preason Gear List
- **11 Sep. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Correct a typo
- **11 Sep. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Correct another typo
- **10 Sep. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Preliminary update of Buff Targets for The War Within Season 1.
- **10 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Update references of Upranking Firebreath because of Molten Embers.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Add The War Within Season 1 BiS Lists for Gear and Trinkets.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Add The War Within Season 1 Embellishment Information
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Fix typo
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Add mention of Authority of Radiant Power for M+. Add Speed Blasphemite.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Update for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Improve readability for Tip the Scales info.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Update incorrect talent links and add information about Time Convergence in Mythic+
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **27 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Add comments about Delve
- **22 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Correct a typo
- **22 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Add a disclaimer for Embellishment items
- **22 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated best Weapon Oil/Temporary Weapon Enchantment comments
- **22 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Fixes to typos
- **22 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Fix incorrect Spell Links
- **22 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Correct M+ Talent Build (Was missing Oppressing Roar and Sleep walk)
- **22 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Fix incorrect Spell Links
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for The War Within Launch with new builds.
- **21 Aug. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** All buff mechanics were updated for The War Within Launch. Best Buff section temporarily removed.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated with a Pre-Season BiS for The War Within Launch.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Launch with all of the new consumables and enchants.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for The War Within Launch including new stats for Chronowarden.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Launch with Hero Talent support.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for The War Within Launch adding Hero Talents.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for The War Within Launch adding Hero Talents.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Minor adjustments to the rotation for The War Within Launch as well as additions of Hero Talents.
- **21 Aug. 2024 (this page):** Updated for The War Within Launch.
- **18 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for The War Within Launch.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/augmentation-evoker-mists-of-pandaria-remix-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Disclaimer added for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Fixed Mythic+ Talent Tree.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Opener fixed with Molten Embers.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Fixed Mythic+ Talent Tree.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **19 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/augmentation-evoker-the-war-within-pve-guide>)):** Updated for The War Within pre-patch.
- **19 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for The War Within pre-patch.
- **15 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/augmentation-evoker-the-war-within-pve-guide>)):** Update comment for Motes of Possibility.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/augmentation-evoker-the-war-within-pve-guide>)):** Page added.
- **20 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/augmentation-evoker-mists-of-pandaria-remix-guide>)):** Further Updated after reviewing changes.
- **19 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/augmentation-evoker-mists-of-pandaria-remix-guide>)):** Updated after live testing.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/augmentation-evoker-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Season 4
- **22 Apr. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed and updated for Dragonflight Season 4
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed and updated for Dragonflight Season 4
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 4
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed and reformatted for Dragonflight Season 4
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed and updated for Dragonflight Season 4
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 4
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and updated for Dragonflight Season 4
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated and Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed and updated for Dragonflight Season 4
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **19 Mar. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Patch 10.2.6
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6
- **08 Mar. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Rewording and typo fixes
- **08 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Update stats and change formatting
- **08 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Use Regenerative Chitin in the default M+ Build.
- **08 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Default builds updated.
- **08 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Update default builds.
- **19 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6
- **19 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6
- **19 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6
- **19 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6
- **19 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6
- **19 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6
- **19 Jan. 2024 (this page):** Reviewed for Patch 10.2.6
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Update Buff Targets with latest Priorities.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.5 changing the BiS Dungeon Only Weapon
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for patch 10.2.5
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5
- **24 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Fix Typo in Dungeon Gear.
- **22 Nov. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Update Buffs Page - BM Now Attributes
- **21 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Update BiS trinktes to account for stack losses.
- **13 Nov. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Update Buff Targets after Latest Hotfixes and Tuning
- **13 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Gear adjustments and updates based on latest hotfixes.
- **13 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Hotfixes
- **13 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Update for Hotfixes
- **13 Nov. 2023 (this page):** Updated for the Nov 14 Hotfixes
- **09 Nov. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Update Buff Targets Slightly
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Gear adjustments and updates based on latest hotfixes.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Updated for patch 10.2
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for patch 10.2
- **06 Nov. 2023 (this page):** Updated for patch 10.2
- **06 Oct. 2023 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Page updated with more information.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/augmentation-evoker-leveling-guide>)):** Page added.
- **04 Sep. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.1.7 and updated format
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Reviewed for Patch 10.1.7
- **09 Aug. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Update information on Buffs for recent Changes.
- **09 Aug. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Update Build for this weeks patch.
- **09 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Builds updated for this weeks changes.
- **09 Aug. 2023 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Updated for talent changes.
- **15 Jul. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Redo Priority List for recent Eons Changes.
- **13 Jul. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Change note for Elemental Shaman Opener Priority.
- **13 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Fix default talent checkboxes and include Auto Targeting note.
- **12 Jul. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Buff Priority Adjusted for Feral.
- **10 Jul. 2023 ([Buffs](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)):** Page added.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot>)):** Page added.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-macros-addons>)):** Page added.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gems-enchants-consumables>)):** Page added.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>)):** Page added.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-mythic-plus-tips>)):** Page added.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Page added.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spec-builds-talents>)):** Page added.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-spell-summary>)):** Page added.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-easy-mode>)):** Page added.
- **10 Jul. 2023 (this page):** Page added.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Augmentation Evoker leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Evoker leveling guide](<https://www.icy-veins.com/wow/evoker-leveling-guide>).

1.

### Augmentation Evoker Leveling Guide for Midnight

Augmentation Evoker is a support oriented specialisation and as such has
significantly lower personal damage output compared to Devastation Evoker. If
you choose to level primarily through dungeons, this will not be an issue. But
you may have a smoother leveling experience in the open world via questing as
Devastation. If you would like to level as Devastation instead, we suggest
following our [Devastation 
Evoker Leveling Guide](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>).

1.1.

#### Leveling Gear Options

In most cases, you will want to prioritize item level while going
  through the leveling process. This means selecting whatever has the highest
  item level. When selecting jewellery pieces (Necklace or Rings) it can be
  worth dropping a small amount of item level to use items without
  Versatility as the stat is not very good for Augmentation Evoker.

When using Heirloom items, we recommend using any heirlooms that do not have
  Versatility. If you are playing solo then you should try to prioritise haste 
  and critical strike chance as mastery would have very little effect on your 
  DPS without allies to buff.

1.2.

#### Useful Leveling Consumables for Midnight

In this section we will detail some Consumables that are useful for leveling 
during Midnight. These will be primarily focused on items that increase your 
Speed — both actual Movement Speed and DPS.

- [[item:225592]] — Most Recent Food buff that 
      provides a large amount of speed that will make leveling considerably 
      faster.
- [[item:172063]] or [[item:133576]] — Older food buffs 
      that still provide a noticeable increase in Speed. If you have any of these 
      still from leveling in previous Expansions they would be good to use 
      again.
- [[item:212265]]: This is the Combat Potion from The War Within 
      This can be used from level 71 or above and can be used to speed up quest 
      bosses or make larger pulls faster (and thus safer). If you already have 
      these then we recommend using these during the leveling process.
- Health Potions are invaluable for saving your life during leveling. We 
      suggest making sure you have some [[item:244835]] (The 
      War Within Health Potion, Lv71+) saved up for leveling before starting 
      Midnight but not too many as [[item:241305]] and 
      [[item:271883]] invalidate these after you hit 
      level 81 and are often very cheap at 1 star.

We suggest making sure you have some of these consumables as they make 
leveling significantly faster.

- [[item:109076]]
- [[item:132516]] or [[item:212268]]
- [[item:168412]]

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a 
Level 80 import string for you. You can follow the point-by-point allocation 
of the below tree once you start gaining levels in Midnight.

:::talents Augmentation Level 80 Midnight Leveling
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzYmZMzGAAAAAAAAmBmBjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0IWwYMzAAPA"
}
```
:::

:::talents Universal Build - Chronowarden
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA"
}
```
:::

:::details 来源计算器编码
```
#BX-UacsFKLLRRZblqqIIPXYYkkpEWejnDfhmWB-CVELHWGuSMNCIWOpQBWE+BjD5LVrbDC-AAAA-UAQaYMECKWOIMA-
```

:::

2.1.

#### War Mode Talents for Leveling

Here, you will find information on the best PvP talents
for leveling and doing solo / small group PvE content.

Augmentation Evoker PvP talents barely provide any noticeable speed up in 
combat. We have listed the best ones to have active below.

- [[spell:378464]] is recommended as it gives you an easy way to 
  immune loss of control effects from both NPCs and enemy players trying to 
  gank you.
- [[spell:378444]] will allow you to safely cast spells while enemies 
  are trying to knock you back.
- [[spell:378437]] can be useful when you are
  trying to run away from a pack of enemies and not be slowed by Daze.

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider 
to select your level, and watch as the leveling rotation grows with each 
level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

- **等级 35 起：**Cast [[spell:409311]]
- **等级 11 起：**Cast [[spell:395152]]
- **等级 1–42：**Cast [[spell:357210]]
- **等级 43 起：**Cast [[spell:403631]]
- **等级 27 起：**Cast [[spell:370553]]
- **等级 11 起：**Cast [[spell:357208]] at empower level 1 if [[spell:395152]] is up.
- **等级 1–10：**Cast [[spell:357208]] at empower level 1.
- **等级 57 起：**Cast [[spell:404977]] if both [[spell:357208]] and [[spell:396286]] are on cooldown.
- **等级 19 起：**Cast [[spell:396286]] at empower level 1 if [[spell:395152]] is up.
  For AoE you can empower this more so it hits as many mobs as you can.
- **等级 15 起：**Cast [[spell:395160]] if [[spell:395152]] is up or you have 2 [[spell:369297]] or capped Essence.
- **等级 1–14：**Cast [[spell:356995]]
- Cast [[spell:361469]]
- If you need to move whilst casting, use [[spell:358267]]. If you have no
  charges of [[spell:358267]] left, then use [[spell:362969]].

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for PAtch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Pre-Season.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **24 Feb. 2025:** Updated for Patch 11.1 with different talent ordering because of new talent.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7
- **21 Oct. 2024:** Updated for Patch 11.0.5
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch with new builds.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **06 Oct. 2023:** Page updated with more information.
- **04 Sep. 2023:** Page added.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Augmentation Evoker in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Augmentation Evoker in Midnight

This page is intended for players who are new to the game or class, have no
  intentions of raiding Mythic difficulty, or simply want a more
  straightforward way to play their specialization without being overwhelmed by
  the numerous subtleties and active abilities that need to be taken into
  consideration for optimal play.

Augmentation's playstyle is very fluid, revolving around buffing others then
  casting your damaging spells to extend your buffs.

Augmentation Evoker has auto-targeting features for buffs to make the class
  as welcoming as possible for newer players. For example, while targeting an
  enemy, casting [[spell:409311]] will default to the nearest DPS and
  [[spell:360827]] will target the enemies current target.
  [[spell:395152]] will automatically affect every DPS.

In Mythic+, you do not have to worry about target selection of your buffs at
  all, as they will mostly automatically cast on the correct targets. Manual
  targeting of your [[spell:409311]] in Mythic+ is at most a 1% DPS gain.

While optimization of who you buff in a raid is possible, with the change to
  make [[spell:395152]] raidwide, it is now smaller than it has been
  historically. That said, it is still a significant gain to make sure
  [[spell:409311]] is on your strongest DPS and, we suggest that you keep it
  on them all fight where possible. However, we do not believe that this is
  necessary to enjoy the class. If you would prefer to let the game handle it automatically, that is completely viable for all content.

Augmentation Evoker's highest priority is to **always be casting
  something**. All of your actions contribute to your overall damage in some 
  way and pressing something, even if its the wrong button, is better than 
  pressing nothing at all! Here are some simple key points to focus on:

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_sarkareth.jpg>)
  **Maintain your Ebon Might**  
  
      Augmentation's main damage contributor is [[spell:395152]], as it
      provides a large primary stat buff to your allies while also boosting your
      own damage. Your highest priority is to maintain this buff by casting
      [[spell:395152]], [[spell:357208]], [[spell:396286]] and
      [[spell:395160]] as much as possible.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_prescience.jpg>)
  **Cycle Ability Cooldowns**  
  
      Augmentation has three important short cooldown abilities:
      [[spell:357208]], [[spell:396286]] and [[spell:409311]]. These
      abilities cause powerful buffs on allies that make up a large portion of
      your damage meaning it is crucial to maximise uses!
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_eruption.jpg>)
  **Spend All Available Resources**  
  
      Augmentation has two important resources: Essence and
      [[spell:396187]]. These can be used to cast
      [[spell:395160]] which is crucial to deal damage and maintain
      [[spell:395152]]. You will generate Essence over time and get
      [[spell:396187]] from [[spell:409311]] and
      [[spell:361469]].

2.

### Beginner's Guide to Augmentation Evoker in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden   Universal Talents

2.1.

#### Universal Build for Augmentation Evoker

This build will work in both Raid and Mythic+ although we would still
      recommend using the dedicated Mythic+ talents for keys instead as this is
      lacking some utility options and [[spell:360827]] talents.
      We currently suggest playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden as it does significantly
      more damage with less onus on personal play.

We take [[spell:412713]] for this build to minimise the overall
      complexity of the rotation. Playing [[spell:404977]] with 
      [[spell:410260]] does deal approximately 1% more damage if you feel 
      comfortably managing the additional cooldown.

:::talents Easy Build - Chronowarden
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMmZAgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMmZAgB"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKbpkkIIWeEnmG:WDHWWA-CVELHDWuSMNCIWOpQBGu4hDB77cqW3G-AAAA-UAQMECaYKWOIMA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden   Mythic+ Talents

2.2.

#### Mythic+ and Delve Talents for Augmentation Evoker

This build also plays ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden and swaps to
      [[spell:360827]] talents. These talents specialise
      in doing AoE damage and do not perform well in low-target
      situations, like many Raid encounter, but excel in Mythic+. Remember to
      cast your [[spell:360827]] on the tank at the
      start of the dungeon!

For utility points in the class tree, we move two points from
      [[spell:375554]] to both [[spell:360806]] and
      [[spell:371032]] as they are useful utility in Mythic+.

:::talents Easy M+ Build - Chronowarden
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZmZMmZWGzMwMbGYMjFWgBmhhGYBjxMDAM"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZmZMmZWGzMwMbGYMjFWgBmhhGYBjxMDAM"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKJbpkkIIWeEnmG:WDH6A-CVELHDWuSMNCIWOpQB+whg9dOVrjxRD-AAAA-UAQMECaYKWOIMA-
```

:::

### Augmentation Evoker   Basic Rotation

2.3.

#### Beginner Rotation for Augmentation Evokers

The priority system for [Augmentation Evoker](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-guide>) is not very
      complicated as a whole, as you are focusing on several short cooldown
      abilities and filling the gaps with [[spell:361469]]. However,
      delaying casts of [[spell:409311]] or [[spell:395152]] can lead
      to large DPS losses quickly. It is important to only use Empower spells
      during [[spell:395152]].

- Cast [[spell:360827]] if your tank does not currently have it.
- Cast [[spell:395152]].
- Cast [[spell:409311]].
- Cast [[spell:403631]].
- Cast [[spell:370553]].
- Cast [[spell:357208]] at empower level 3 if [[spell:395152]]
          is up.
- Cast [[spell:396286]] at empower level 1 if
          [[spell:395152]] is up.
- Cast [[spell:395160]] if [[spell:395152]] is up.
- Cast [[spell:361469]].
- If you need to move whilst casting, use [[spell:358267]]. If you have
          no charges of [[spell:358267]] left, then use [[spell:362969]].

2.3.1.

##### Tier Set

Augmentation's Midnight Season 2 Tier Set does not cause
      you to play your rotation differently. However, it does allow you to cast
      [[spell:396286]] more often.

2.3.2.

##### Apex Talent: ![Duplicate Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_recall.jpg>) Duplicate

Augmentation's Apex talent [[spell:1259173]] has no direct impact on
      your moment to moment gameplay and simply enhances your characters damage
      output and buff strength.

### Augmentation Evoker   Defensive Spells

2.4.

#### Defensive Spells for Augmentation Evoker

All of Augmentation Evoker's Defensive spells are **proactive**. You
      need to use them before damage happens to get maximum effect and do not do
      anything if used afterward.

[[spell:404195]] is a cheat death effect that will save you from dying
      once every six minutes.

[[spell:363916]] is your bread and butter defensive, offering 30%
      damage reduction on a 90s cooldown with two charges thanks to
      [[spell:375406]]. This talent is usually further enhanced by
      [[spell:374348]] which causes you to heal back equal to the damage
      reduced by [[spell:363916]] making this a very potent defensive.

[[spell:374227]] reduces the area damage taken by you and the 4 nearest
      allies by 20%. Due to affecting 5 people this is incredibly strong even
      if it only applies to AoE damage. Most encounters have heavy-hitting AoEs
      that this is very good against.

[[spell:429483]] with [[spell:431873]] (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Hero
      Talents) provides 20% decaying Damage Reduction, losing 2% every 0.3s.

### Augmentation Evoker   Stat Priority

2.5.

#### Stat Priority for Augmentation Evoker

Currently, Intellect is your most important stat per point with Mastery
      being a close second. Mastery is currently significantly ahead of the
      other stats and Versatility is extremely low value. This means it can be
      correct to equip items that have lower item level but better secondary
      stats.

Mastery

Critical Strike

Haste

Versatility

### Blizzard   Combat Assistant

2.6.

#### Combat Assistant for Augmentation Evoker

The [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) is intended to be a way to help newer
      players approach content without being as overwhelmed by World of
      Warcrafts complex rotations. You can have the game highlight your next
      action for you or have the game take actions for you. The rest of this
      section primarily refers to the Single-Button assistant as the
      performance of the highlighting is acceptable with no real loss of
      performance. You can find the Single-Button assistant in your spellbook
      as a button you can drag onto your hotbars that will rotate through your
      abilities according to priorities defined by Blizzard.

For Augmentation Evoker the Combat Assistant has issues with casting
      Empower Spells like [[spell:357208]] or [[spell:396286]]. If you
      press the button too frequently when it suggests casting an Empower Spell
      then the Combat Assistant will cancel the Empower spell instead of
      properly queueing it. To work around this we suggest paying attention to
      when the spells are nearly off cooldown and slowing down your button
      presses. When it casts an Empower it will work like the "Press-and-tap"
      casting mode where it will start casting and pressing it a second time
      will release it.

Another notable issue with the Combat Assistant is that it cannot help
      you during movement. Despite Augmentation Evoker having [[spell:358267]] it
      will not recommend you to use it and can get stuck recommending you cast
      an Empower spell while you are moving which you cannot do even if you had
      manually cast [[spell:358267]]. Because of this we do recommend having some
      of the basic spells keybound in addition to the cooldowns. We suggest
      making sure [[spell:395160]], [[spell:361469]] and
      [[spell:362969]] are keybound as well as all of the classes cooldowns
      listed below along with utility spells and defensives.

As an Augmentation Evoker this assistant will not use all of your spells
      for you. The assistant will not use your cooldowns or items and you will
      need to weave in the following abilities in order to get full damage out
      of your class and this feature:

- [[spell:403631]]
- [[spell:370553]]
- [[spell:404977]]
- On-Use Trinkets
- Combat Potion
- [[spell:358267]] for movement

By using this assistant and weaving in your cooldowns, you can perform at
      a high level rotationally. Blizzard balances this out by increasing
      yourGlobal Cooldown while using the Combat Assistant. Currently the
      Combat Assistant is 5.4% damage behind playing manually.

This tool is an excellent way to jump into the game and start out. After
      you get comfortable we recommend that you try playing the rotation
      manually to improve your gameplay even further.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5 including new Mythic+ Build.
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5 shifting to Echoing Strike build.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Pre-Season.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **10 Sep. 2025:** Remove Tierset Disclaimer. Rotation is unchanged.
- **09 Aug. 2025:** Change ordering of Easy Rotation to be less confusing to people.
- **05 Aug. 2025:** Remove Chronowarden Stat Priority from Easy (as we suggest Scalecommander).
- **04 Aug. 2025:** Update Easy Mode Page for Patch 11.2
- **15 Jun. 2025:** Update Easy Mode for Patch 11.1.7 and Assisted Combat. Swap the builds to Chronowarden because they perform better with the Combat Assistant due to not being reliant on Time Skip.
- **08 May 2025:** Update Easy Mode Talents and Stats due to Patch 11.1.5 Hotfixes.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Reviewed for Patch 11.0.7
- **21 Oct. 2024:** Reviewed for Patch 11.0.5
- **21 Sep. 2024:** All recommendations swapped to Scalecommander.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Minor adjustments to the rotation for The War Within Launch as well as additions of Hero Talents.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed and updated for Dragonflight Season 4
- **19 Mar. 2024:** Reviewed for Patch 10.2.6
- **08 Mar. 2024:** Update default builds.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5
- **06 Nov. 2023:** Reviewed for patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Page added.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Augmentation Evoker in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Augmentation Evoker

Augmentation has two Hero Talents that focus on different aspects of the 
  class. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden has a greater focus on [[spell:409311]] and 
  the power of your buffs. Meanwhile, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander focuses on 
  higher damage output with buffs to [[spell:395160]] and additional damage 
  sources like [[spell:434300]].

Additionally, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden will feel more fast paced as it grants 
  additional [[spell:369297]] procs and Haste buffs which accelerate your 
  rotation.

We are recommending ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden for the default raiding choice, 
  as it will vastly outperform ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander in all scenarios in 
  Raid. We currently recommend playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander in weekly keys 
  and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden for higher keys.

For more in-depth information please check the dedicated sections for each 
  build and hero talent below.

**Recommended Build Import Codes:**

:::talents Raiding Build - Chronowarden
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA"
}
```
:::

:::talents Mythic+ Build - Chronowarden
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMzMDAM"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Chronowarden

Raid Build

Recommended

Mythic+ Build

Recommended

Scalecommander

Raid Build

Weekly Mythic+/Delve Build

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Raid Build

This build focuses on increasing the power of your buffs and deals 15% more
  DPS than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden synergises
  extremely well with our Season 2 Tier Set due to having dedicated nodes for
  [[spell:396286]] and more support for [[spell:409311]].

We play [[spell:404977]] in this build in order to free up an additional
  point to take [[spell:410260]] which adds significant damage when you can
  cleave multiple targets with [[spell:403631]]. Furthermore, currently
  [[spell:404977]] with either [[spell:410260]] or [[spell:410261]]
  performs approximately 0.5% better than [[spell:412713]] baseline.

One of the biggest considerations on whether to play
  [[spell:412713]], [[spell:412723]] or base [[spell:404977]]
  comes down to [[spell:403631]] timings. Depending on the fight you can
  find that [[spell:403631]] lines up naturally better with adds or other
  important moments better with either talent. This improvement is enough to
  outperform the slight default bias towards [[spell:404977]] so we recommend
  trying out both options and playing what feels best.

When playing the [[spell:404977]] variant you
  will want to use a cancelaura macro for [[spell:370553]]. For more
  information see our rotation guide.

#### Chronowarden Cancelaura Tip the Scales

```wow-macro
#showtooltip
/cast Tip the Scales
/cancelaura Tip the Scales
```

Additionally, if simply do not enjoy playing [[spell:404977]] you can move
  the point from [[spell:410260]] to [[spell:412713]], for a
  loss of approximately 0.5% less DPS, but gaining significantly smoother
  gameplay and slightly different cooldown timings.

Our Raid build starts out with a universal talent setup that will work
  everywhere but not every boss will need you to have [[spell:351338]]. If you
  are on a boss that has no interrupts this we suggest moving them to other
  utility like [[spell:454983]], [[spell:408233]] or
  [[spell:407243]]. This is a very minor benefit so we opted to
  include it always by default!

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Mythic+ Build

We currently suggest playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden in all Mythic+ as it
  deals significantly more single-target damage making keys noticeably faster.
  However, if you prefer the gameplay of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander it is not
  far behind, especially in lower keys.

This build opts into playing [[spell:412713]] over
  [[spell:404977]] which allows for a smoother gameplay experience.
  We also take [[spell:360827]] and [[spell:409329]].
  These talents now deal significant damage on AoE packs making them
  worth investing in.

Our Mythic+ build starts out with a universal talent setup that will work
  everywhere. You can move utility in your class tree around, such as moving
  the points from [[spell:370888]] to other utility like
  [[spell:372048]] or [[spell:371032]] if you would prefer.

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander Raid Build

This build is approximately 15% DPS behind ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden in raids,
  and as such we do strongly recommend against playing it.

For Midnight Season 2 [[spell:441206]] got massively nerfed, drastically
  lowering the overall performance of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander. Furthermore,
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander synergises relatively poorly with the Season 2 Tier
  Set as it does not have any special interactions with [[spell:409311]].

Just like our ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Raid build, this plays around [[spell:409267]]
  and [[spell:410260]] with one key difference: we move the point from [[spell:275339]]
  to [[spell:412713]]. This lets us have the significantly smoother gameplay
  of [[spell:412713]] which synergises well with [[spell:441206]].
  We cannot make this swap on ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden as it needs to play [[spell:275339]]
  to get maximum effect of [[spell:431657]] on single-target encounters.

Our Raid build starts out with a universal talent setup that will work
  everywhere but not every boss will need you to have [[spell:351338]]. If you
  are on a boss that has no interrupts this we suggest moving them to other
  utility like [[spell:454983]], [[spell:408233]] or
  [[spell:407243]]. This is a very minor benefit so we opted to
  include it always by default!

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander Mythic+ and Delve Build

We currently do not recommend this build in High Mythic+ as it will
  perform worse than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden. That said, the
  difference is quite low so if you prefer the playstyle or
  gameplay of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander then it is still viable,
  especially for Weekly Keys.

This build focuses on playing [[spell:412713]] and [[spell:407866]]
  and maximising your personal damage dealt from [[spell:403631]] casts.

We play [[spell:410784]] for this build to get a slight
  single-target DPS gain. Due to playing [[spell:410784]] you will
  use [[spell:362969]] over [[spell:361469]] at all target counts.
  You still need to use [[spell:361469]] to consume
  [[spell:369939]].

Another reason we have chosen [[spell:410784]] for this build is that
  it is a lot simpler to play due to having instant cast builder as its main generator
  in all situations. You will deal approximately 2% more single-target DPS at the
  cost of 2% less AoE compared to playing [[spell:407814]]. If you would
  rather play [[spell:407814]] then you can swap to it and move the class
  tree point in [[spell:369909]] to [[spell:376930]] or another utility point.

This build has slightly lower potential DPS compared to its
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden counterpart, but has less reliance on allies
  for performance. This means it can perform better on average,
  but of course your mileage may vary.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNwCGjZGAYA"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKbpkkIIWeEnmG:WDHWWA-CVELHDWuSMNCIWOpQBGu4hDB7LVrbDC-AAAA-UAQMECaYKWOIMA-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMzMDAM"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKJbpkkIIWeEnmG:WDHaB-CVELHDWuSMNCIWOpQB+whg9lq1dmxRD-AAAA-UAQMECaYKWOIMA-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbjZmxyMYmlZMzMmBAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZzYwCsMGGbDgZQshxAzMAG"
}
```
:::

:::details 来源计算器编码
```
#BX-UacsFKRRZblqqIIPXYYkkpEWejnDfhmWXWA-CELVWuAHOSYcQZCUYURs8Bj77cqW3GE-AAAA-JOQSaACIYowIzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzMzyAzsNjxMmBAAAAAAAAmhHYGYM1YmZGAAAAMzMjxMz2YmBmZzYwCsMGGbDgZQshxMYmBDG"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFtZUYYlXPpcKJkkIjWeEnm:WDVV72cB-CVELHWHATMNyoQ54CQss4hD77cqWXDC-AAAA-JSCUg0wscMAIwI-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio was a new system added in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>). 
  After a short questline, you will be able to choose from several small 
  bonuses that provide additional throughput, survivability or utility. We 
  recommend completing these quests as soon as possible, as this system will be 
  active for the rest of Midnight and provides a noticeable boost in power.

We currently suggest the following talents as your default progression path. 
  As you can swap the runes at any time, you can always adjust these later 
  based on the encounter or personal preference once you are more comfortable:

- First Rune: [[spell:1279599]]
- Second Rune: [[spell:1279603]]
- Third Rune: [[spell:1287555]]
- Fourth Rune: [[spell:1279612]]
- Fifth Rune: [[spell:1279614]]

:::details FAQWhich secondary stat rune should I pick?
As an Augmentation Evoker you should always take

[[spell:1279612]]

.

:::

3.

### Apex Talent: ![Duplicate Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_recall.jpg>) Duplicate

In Midnight Augmentation Evoker gains access to the Apex Talent: 
[[spell:1259173]]. This Apex Talent and its upgrades have significant 
impact on Augmentation Evoker's Talent Choices and Stat Priority.

The First Point [[spell:1259173]] summons a Pet after you cast 
[[spell:403631]] that deals significant damage while active. This Pet 
casts [[spell:395160]], [[spell:357208]], and [[spell:396286]]. 
These casts will not extend [[spell:395152]]. The [[spell:395160]] 
casts will scale with all of Augmentation's talents except for 
[[spell:438587]] and [[spell:441176]].

The Second and Third Apex Talent Points [[spell:1259174]] allows anything 
that triggers [[spell:395153]] to also extend [[spell:1259173]]. This 
leads to a minigame very similar to maintaining [[spell:395152]] where 
you attempt to maximise the uptime of [[spell:1259173]]. This considerably
increases the power of Haste and Critical Strike as these boost the uptime of
[[spell:1259173]]. Additionally, it significantly boosts the power of the
[[spell:403631]]' talents [[spell:459537]] and
[[spell:407866]] as they increase the amount of casts you can get
within your [[spell:1259173]].

The Final Apex Talent point, [[spell:1259175]], makes the Duplicate provide 
an incredibly powerful buff effect that increases your [[spell:395152]] on
allies by 75% and significantly boosts the damage of your [[spell:396286]].

Another significance of [[spell:1259175]] is that it heavily
incentivises pressing [[spell:403631]] on cooldown. Maximising
uptime on the doubled Primary Stat from the Buff ultimately contributes
more for overall DPS than holding [[spell:403631]] for an ideal
damage window.

Even though [[spell:403631]]' amplifier is a more significant DPS boost 
than the 12% Primary Stat increase from having your [[spell:1259173]] up 
with [[spell:1259175]], using [[spell:403631]] on cooldown results in 
significantly higher [[spell:1259173]] uptime due to more frequent casts 
that get extended by [[spell:1259174]].

At the same time, you will still get a sufficiently strong 
[[spell:403631]] window due to how varied most DPS are in their damage 
profile.

4.

### Hero Talents

Hero Talents become available at Level 71 and are mutually exclusive trees 
that offer slightly different gameplay and visuals. As an Augmentation Evoker 
you can pick between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden. 
We go into some of the details and differences between them below!

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander is the Personal Damage focused Hero Talent Tree 
that has the least emphasis on Buff based gameplay instead opting to boost 
Empower Spells and Essence Spenders. This is perfect for anyone who wants 
fire and forget gameplay and does not want to track their co-DPS's cooldowns.

Currently we recommend ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander in Mythic+ for weekly keys 
  as it functions better with worse performing allies. In optimal conditions 
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden can significantly outperform 
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander, but both are viable at all levels of Mythic+, 
  depending on what you enjoy the most.

For Raiding ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander is 15% behind ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden 
  and we strongly recommend against playing it.

The core focus of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander gameplay comes from applying 
  [[spell:434300]] with [[spell:395160]] after gaining stacks from 
  using [[spell:357208]] and [[spell:396286]]. After applying 
  [[spell:434300]] you want to extend it as much as possible by casting 
  [[spell:395160]] while having the talent [[spell:441212]]. These
  bombardments add additional damage procs from your allies which ends up doing
  a considerable amount of damage over time!

Another central pillar of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander gameplay is
  [[spell:438587]]. After casting each of your empower spells you
  will gain a stack of [[spell:438587]] which will allow your next
  [[spell:395160]] cast to cleave dealing additional hits to other nearby
  enemies. This is especially important now that [[spell:441206]] is tied
  to [[spell:438587]] instead of [[spell:434300]]. The extra
  cooldown reduction provided to [[spell:403631]] provides makes
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander lean into [[spell:403631]] talents
  like [[spell:459537]] and [[spell:407866]]. All
  combined, you are strongly incentivised to maximise the overall casts of
  [[spell:403631]] for personal benefit instead of opting for higher
  quality casts that deal more damage from allies.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden is the Buff Oriented Hero Talent Tree that is themed 
around Time Magic. As a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden a larger fraction of your 
damage comes from Buffs than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander since you get stronger 
[[spell:409311]] and [[spell:395152]] buffs from 
[[spell:431715]] and [[spell:431874]]. This tree is perfect for 
players who want their friends to be the strongest they can be and, is 
slightly more forgiving for personal play.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden enhances your [[spell:361469]] turning it into 
[[spell:431442]] augmenting it with bronze magic that deals additional 
damage based off of damage dealt recently. [[spell:431442]] still 
functions as a normal [[spell:361469]] that interacts fully with all 
[[spell:361469]] talents, with each projectile fired dealing additional 
[[spell:431442]] damage.

This is currently our recommended Hero Talent tree for High End Mythic+ and 
  Raiding as it outperforms ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander considerably.

If you are playing [[spell:404977]] as a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden you will 
want to use a Cancelaura Macro for [[spell:370553]]. This lets you keep 
the cooldowns of [[spell:404977]] and [[spell:370553]] lined up. You 
need to do this because the cooldown of [[spell:370553]] only starts 
when the buff is consumed.

#### Cancelaura Tip the Scales Macro

```wow-macro
#showtooltip
/cast Tip the Scales
/cancelaura Tip the Scales
```

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden does not add any additional rotational gameplay 
elements that you have to play around. Instead, you just get you more 
resources and stats. You gain more Haste from [[spell:431657]] and 
[[spell:431695]], and better resource generation from 
[[spell:1291522]] and [[spell:431875]], to help the performance your base 
rotation. These resources and stats makes it significantly easier to maintain 
your buffs.

:::details FAQWhen Should I Play ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Over ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander?
We recommend playing

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden

over

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander

in most scenarios. That said, due to

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden

s heavy reliance on
ally performance, you may experience better performance as

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander

on average in Mythic+.

:::

5.

### PvP Talents (War Mode)

Enabling War Mode grants you several benefits in the open world which you 
made decide are beneficial. We have listed the main benefits below.

- PvP talents enabled in the outdoor world.
- At least 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

We do not recommend enabling War Mode for general leveling and PvE content 
as it allows other players to kill you which is incredibly frustrating. The 
War Mode talents available to Augmentation Evoker are not a considerable time 
save as none of them provide a significant increase of DPS. That said, it is 
optimal to enable it if you are willing to engage in PvP.

Augmentation Evoker PvP talents barely provide any noticeable speed up in 
combat. We have listed the best ones to have active below.

1. [[spell:378464]] is recommended as it gives you an easy way to 
       immune loss of control effects from both NPCs and enemy players trying to 
       gank you.
2. [[spell:378444]] will allow you to safely cast spells while enemies 
       are trying to knock you back.
3. [[spell:378437]] can be useful when you are
       trying to run away from a pack of enemies and not be slowed by Daze.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **15 Jun. 2026:** Updated for Patch 12.0.7 adding Omnium Folio information. Change High Keys build to Overlord.
- **04 May 2026:** Adjust Talent build comments. Talent Builds themselves are unchanged.
- **20 Apr. 2026:** Updated for Patch 12.0.5 with new talent builds.
- **19 Mar. 2026:** Motes of Possibility has been removed from all Chronowarden Builds.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Pre-Season.
- **10 Feb. 2026:** Builds updated for Midnight 12.0.1 Prepatch
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **20 Aug. 2025:** Updated Scalecommander Talent Builds.
- **05 Aug. 2025:** Updated for Hero Talent tuning Hotfixes. (Chronowarden for Raid, Scalecommander for M+)
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7 fixing an error in a descriptive section.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **24 Feb. 2025:** Updated for Patch 11.1 for the new talent changes.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7
- **21 Oct. 2024:** Updated for Patch 11.0.5 with new class trees due to changes.
- **04 Oct. 2024:** Update default Scalecommander M+ Build based on hotfixes.
- **21 Sep. 2024:** Update for new Scalecommander builds and change to Molten Embers.
- **09 Sep. 2024:** Update incorrect talent links and add information about Time Convergence in Mythic+
- **27 Aug. 2024:** Add comments about Delve
- **22 Aug. 2024:** Correct M+ Talent Build (Was missing Oppressing Roar and Sleep walk)
- **22 Aug. 2024:** Fix incorrect Spell Links
- **21 Aug. 2024:** Updated for The War Within Launch adding Hero Talents.
- **23 Jul. 2024:** Fixed Mythic+ Talent Tree.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated and Reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6
- **08 Mar. 2024:** Default builds updated.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **09 Aug. 2023:** Builds updated for this weeks changes.
- **10 Jul. 2023:** Page added.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Augmentation Evoker in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Augmentation Evoker Gameplay and Rotation Guide

Welcome to our Rotation page for Augmentation Evokers. On this
  page, you will find everything you need to know about rotational gameplay for the spec 
  in Raiding and Mythic+ scenarios.

The rotation for [Evoker](<https://www.icy-veins.com/wow/evoker-class-overview-dragonflight>) plays largely in 30-second cycles around
  your empowered spells ([[spell:357208]] and [[spell:396286]]) and
  [[spell:395152]]. Between these cycles, you use [[spell:395160]],
  [[spell:409311]] and filler spells like [[spell:361469]].

Every two minutes, you can use [[spell:403631]], and you want to
  have [[spell:395152]] to go with it to ensure that [[spell:395152]] 
  lasts the full [[spell:403631]] Duration.

1.1.

#### General Rotational Goals for Augmentation Evoker

1. Use [[spell:403631]] on Cooldown.
2. Avoid overcapping charges of [[spell:409311]]
3. Use your Empower spells to give allies Versatility with
       [[spell:413984]] and to extend [[spell:395152]].
4. Maintain [[spell:395152]] for as long as you can with
       [[spell:395160]] and Empowers.
5. Maximise your time spent casting spells — Even if a large portion of
       your damage comes from allies your spells are still valuable! This should
       come naturally from maintaining [[spell:395152]].

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander

Raid Build

Weekly Keys, Delve and Open World

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden

Raid Build

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

High Keys, Delve and Open World

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:404977]]

[[spell:412713]]

[[spell:360995]]

[[spell:396286]]

[[spell:403631]]

[[spell:360827]]

[[spell:409311]]

[[spell:412723]]

[[spell:407814]]

[[spell:410784]]

[[spell:369939]]

[[spell:406907]]

### Augmentation Single Target

1.2.

#### Core Rotational Goals

**适用条件：Chronowarden（未启用）。** Augmentation Evoker Single Target is relatively simplistic and focuses on maintaining [[spell:395152]] for as long as possible by weaving in its other abilities.
While maintaining [[spell:395152]] Augmentation Evoker should use its short Cooldown spells like [[spell:357208]], [[spell:396286]], and [[spell:409311]] on Cooldown for optimal DPS filling time between with [[spell:395160]] and [[spell:362969]]. Currently [[spell:362969]] is a better builder on Single Target for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander even without [[spell:410784]].

**适用条件：Chronowarden（启用）。** Augmentation Evoker Single Target is relatively simplistic and focuses on maintaining [[spell:395152]] for as long as possible by weaving in its other abilities.
While maintaining [[spell:395152]] Augmentation Evoker should use its short Cooldown spells like [[spell:357208]], [[spell:396286]], and [[spell:409311]] on Cooldown for optimal DPS filling time between with [[spell:395160]] and [[spell:431442]].

A more in depth Rotational Priority List is shown below:

1.3.

#### Full Rotational Priority

1. **适用条件：Chronowarden（未启用）。** Cast [[spell:395152]] if it has 4 or less seconds remaining on its duration.
2. **适用条件：Chronowarden（启用）。** Cast [[spell:395152]] on cooldown unless you are about to cast [[spell:403631]] and [[spell:395152]] is not up.
3. **适用条件：Breath of Eons（启用）。** Cast [[spell:403631]] on cooldown.
4. **适用条件：Breath of Eons（未启用）。** Cast [[spell:357210]] on cooldown.
5. **适用条件：Prescience（启用）。** Cast [[spell:409311]] on cooldown.
6. **适用条件：Chronowarden（未启用）。** Cast [[spell:370553]] if [[spell:357208]] is up.
7. **适用条件：Chronowarden（启用）。** Cast [[spell:370553]] on Cooldown.
8. Cast [[spell:357208]] at the highest rank available.
9. Cast [[spell:396286]] on Cooldown.
10. **适用条件：Chronowarden（启用）；Interwoven Threads（未启用）。** Cancel the [[spell:370553]] Buff if you do not have an empower available within the next GCD to maximise uptime of [[spell:431695]].
11. **适用条件：Time Skip（启用）。** Cast [[spell:404977]] if both [[spell:357208]] and [[spell:396286]] are on Cooldown.
12. Cast [[spell:358267]] if you need to move.
13. Cast [[spell:395160]] if [[spell:395152]] is up or you have two [[spell:396187]].
14. **适用条件：Blistering Scales（启用）。** Cast [[spell:360827]] if it not currently active on any tank.
15. **适用条件：Chronowarden（未启用）。** Cast [[spell:362969]].
16. **适用条件：Chronowarden（启用）。** Cast [[spell:431442]].
17. **适用条件：Chronowarden（启用）。** Cast [[spell:362969]] for Movement if you do not have any charges of [[spell:358267]] remaining.
18. **适用条件：Blistering Scales（启用）；Regenerative Chitin（未启用）。** Cast [[spell:360827]] in downtime while no enemies are available.

### Augmentation 2T+

1.4.

#### Core Rotational Goals

**适用条件：Chronowarden（未启用）。** Augmentation Evoker AoE Rotation is very similar to its Single Target rotation with only minor changes to its filler priority. The rotation otherwise is still simplistic and focuses on maintaining [[spell:395152]] for as long as possible by weaving in its other abilities.
While maintaining [[spell:395152]] Augmentation Evoker should use its short Cooldown spells like [[spell:357208]], [[spell:396286]], and [[spell:409311]] on Cooldown for optimal DPS filling time between with [[spell:395160]] and [[spell:361469]].

**适用条件：Chronowarden（启用）。** Augmentation Evoker AoE Rotation is very similar to its Single Target rotation with only minor changes to its filler priority. The rotation otherwise is still simplistic and focuses on maintaining [[spell:395152]] for as long as possible by weaving in its other abilities.
While maintaining [[spell:395152]] Augmentation Evoker should use its short Cooldown spells like [[spell:357208]], [[spell:396286]], and [[spell:409311]] on Cooldown for optimal DPS filling time between with [[spell:395160]] and [[spell:431442]].

A more in depth Rotational Priority List is shown below:

1.5.

#### Full Rotational Priority

1. **适用条件：Chronowarden（未启用）。** Cast [[spell:395152]] if it has 4 or less seconds remaining on its duration.
2. **适用条件：Chronowarden（启用）。** Cast [[spell:395152]] on cooldown unless you are about to cast [[spell:403631]] and [[spell:395152]] is not up.
3. **适用条件：Breath of Eons（启用）。** Cast [[spell:403631]] on cooldown.
4. **适用条件：Breath of Eons（未启用）。** Cast [[spell:357210]] on cooldown.
5. **适用条件：Prescience（启用）。** Cast [[spell:409311]] on cooldown.
6. **适用条件：Chronowarden（启用）。** Cast [[spell:370553]] on Cooldown.
7. **适用条件：Chronowarden（未启用）。** Cast [[spell:370553]] if [[spell:357208]] is up.
8. Cast [[spell:357208]] at the highest rank available.
9. Cast [[spell:396286]] on Cooldown.
10. **适用条件：Chronowarden（启用）。** Cancel the [[spell:370553]] Buff if you do not have an empower available within the next GCD to maximise uptime of [[spell:431695]].
11. **适用条件：Time Skip（启用）。** Cast [[spell:404977]] if both [[spell:357208]] and [[spell:396286]] are on Cooldown.
12. Cast [[spell:358267]] if you need to move.
13. Cast [[spell:395160]] if [[spell:395152]] is up or you have two [[spell:396187]].
14. **适用条件：Blistering Scales（启用）。** Cast [[spell:360827]] if it not currently active on any tank.
15. **适用条件：Echoing Strike（启用）；Chronowarden（未启用）。** Cast [[spell:362969]].
16. **适用条件：Chronowarden（启用）。** Cast [[spell:431442]].
17. **适用条件：Pupil of Alexstrasza（启用）；Chronowarden（未启用）；Echoing Strike（未启用）。** Cast [[spell:361469]].
18. **适用条件：Pupil of Alexstrasza（启用）；Echoing Strike（未启用）。** Cast [[spell:362969]] for Movement if you do not have any charges of [[spell:358267]] remaining.
19. **适用条件：Echoing Strike（启用）；Chronowarden（启用）。** Cast [[spell:362969]] for Movement if you do not have any charges of [[spell:358267]] remaining.
20. **适用条件：Blistering Scales（启用）；Regenerative Chitin（未启用）。** Cast [[spell:360827]] in downtime while no enemies are available.

### Opener

1.6.

#### Example Opener Sequence

**适用条件：Blistering Scales（启用）。**

[[spell:360827]]

Precast

**适用条件：Chronowarden（启用）。**

[[spell:431442]]

Precast

**适用条件：Chronowarden（未启用）。**

[[spell:361469]]

Precast

Pull

**适用条件：Chronowarden（未启用）。**

[[spell:395152]]

**适用条件：Prescience（启用）。**

[[spell:409311]]

x2

[[item:241288]]

[[item:249346]]

**适用条件：Breath of Eons（未启用）。**

[[spell:357210]]

**适用条件：Breath of Eons（启用）。**

[[spell:403631]]

**适用条件：Chronowarden（启用）。**

[[spell:395152]]

[[spell:370553]]

[[spell:357208]]

**适用条件：Upheaval（启用）。**

[[spell:396286]]

**适用条件：Time Skip（启用）。**

[[spell:404977]]

**适用条件：Time Skip（启用）；Chronowarden（启用）。**

[[spell:395152]]

**适用条件：Time Skip（启用）。**

[[spell:357208]]

**适用条件：Prescience（启用）；Time Skip（启用）。**

[[spell:409311]]

x2

**适用条件：Time Skip（启用）。**

[[spell:395160]]

x2

**适用条件：Time Skip（启用）。**

[[spell:396286]]

[[spell:395160]]

x3

1.6.1.

##### Before Combat Starts

1. **适用条件：Blistering Scales（启用）。** Cast [[spell:360827]] on the main tank.
2. **适用条件：Chronowarden（启用）。** Precast [[spell:431442]] 1.5s.
3. **适用条件：Chronowarden（未启用）。** Precast [[spell:361469]] at 1.5s

1.7.

#### Post Combat Start

1. **适用条件：Chronowarden（未启用）。** Cast [[spell:395152]].
2. Use DPS Potion.
3. Use Trinkets.
4. Cast [[spell:409311]].
5. Cast [[spell:409311]].
6. **适用条件：Breath of Eons（启用）。** Cast [[spell:403631]].
7. **适用条件：Breath of Eons（未启用）。** Cast [[spell:357210]].
8. **适用条件：Chronowarden（启用）。** Cast [[spell:395152]]
9. Use [[spell:370553]].
10. Cast [[spell:357208]].
11. Cast [[spell:396286]] at the lowest rank that can fit all enemies in the AoE.
12. **适用条件：Time Skip（启用）；Interwoven Threads（未启用）。** Cast [[spell:404977]].
13. **适用条件：Time Skip（启用）；Chronowarden（启用）。** Cast [[spell:395152]]
14. **适用条件：Time Skip（启用）。** Cast [[spell:357208]] at the highest rank possible.
15. **适用条件：Time Skip（启用）；Interwoven Threads（未启用）。** Cast [[spell:409311]].
16. **适用条件：Time Skip（启用）。** Cast [[spell:409311]].
17. Cast [[spell:395160]].
18. Cast [[spell:395160]].
19. **适用条件：Time Skip（启用）。** Cast [[spell:396286]] at the lowest rank that can fit all enemies in the AoE.
20. Cast [[spell:395160]].
21. Continue with Normal Rotation Priority.

:::details TipsDoes Augmentation Work with Blizzard's DPS Meter/Warcraft Logs?
Augmentation does not fully work with Blizzard's DPS Meter. Blizzard's DPS
  meter only displays your personal damage and does not show the
  impact of your buffs, nor simple effects like [[spell:434300]].
  We **strongly** recommend you use Warcraft Logs instead as Blizzard has
  implemented combat hooks for logs, so damage gained from your support effects
  will be re-attributed back to you. This means they will display your total
  damage dealt, including any damage contributed through buffs or damage procs
  like [[spell:434300]].

The combat hooks implementation is not perfect and potentially inaccurate for
  some events. If you find notable errors in the attribution math, make sure to
  report it to Blizzard!

:::

:::details FAQWhen Should I Use Breath of Eons?
You want to use [[spell:403631]] on cooldown to maximise the uptime of
  [[spell:1259173]].

In Mythic+ you should hold [[spell:403631]] if you are approaching the
  end of a pull as you will waste the [[spell:1259173]] uptime.

In a raiding environment if your entire raid is aligning cooldowns for a
  raidwide damage amplification effect then it will be a slight DPS gain to
  save [[spell:403631]] until then as long as it does not cost you a use.

:::

:::details FAQWhen Should I Use Empowers and Eruption?
You should use your Empowers and Eruption during [[spell:395152]]. You
  should not cast them if it is down as it will waste the extension you would
  get from [[spell:395153]].

:::

:::details FAQWhy does the Echoing Strike builds use Azure Strike on Single-Target?
Currently the damage per second of [[spell:361469]] and
  [[spell:362969]] is identical for single-target and, the
  [[spell:396187]] generation is equivalent. If you play
  [[spell:410784]] it does more DPS and generates more
  [[spell:396187]]s per second while being
  fully instant cast.

[[spell:362969]] being instant also makes it a bit easier and more
  forgiving to play, allowing you to hold onto [[spell:358267]] charges more
  freely. You will be able to hold onto more charges for more important fight
  moments to let you keep casting [[spell:395160]].

:::

:::details TipsHow Should I Move While Dealing Damage?
With Evoker, you have multiple options in order to deal damage while on the move.

1. Hover is most preferable as this will allow you to cast whilst moving after
       the short animation.
2. [[spell:409311]] is an instant cast spell and can be used to efficiently
       fill a GCD to move.
3. Finally you can always use [[spell:362969]] which can still generate
       [[spell:369297]]s, allowing you to recoup the lost damage after you
       finish moving.

:::

2.

### Midnight Season 2 Tier Set

Augmentations Tier Set for Season 2 is shown below:

- 2-Piece Bonus: [[spell:1296637]] —
      [[spell:396286]]'s cooldown is reduced by 10 seconds.
- 4-Piece Bonus: [[spell:1296638]] —
      Casting [[spell:396286]] magnifies your [[spell:412774]] effects
      for 8 seconds, increasing the amount of damage echoed to 45% (normally
      15%).

The Midnight Season 2 Tier Set has no direct impact on Augmentation Evoker's 
  rotational decision making. However, the tier set does let you cast 
  [[spell:396286]] more often and desyncs it from your 
  [[spell:395152]]. However, the 4pc bonus does increase the
  importance of good target selection for [[spell:409311]] as
  it adds a large amount of extra damage.

3.

### Class and Spec Mechanics Explained

Below we will be going through some of the core mechanics to playing
      Augmentation Evoker. We want to help you understand why certain decisions in
      your rotation are being made so you can bring your gameplay to a higher level.

### Extending Ebon Might

3.1.

#### Extending Ebon Might

[[spell:395152]] is a powerful buff that is one of your most 
      significant damage sources. [[spell:395152]] both increases your own 
      damage and boosts the primary stat of allied DPS. For this reason, 
      maintaining this buff is the highest priority while playing Augmentation 
      Evoker and, most decisions are based around maximising the uptime of 
      [[spell:395152]] is one way or another.

Extending [[spell:395152]] is the core gameplay loop of Augmentation
      Evoker. [[spell:395152]] can be extended by:

- Casting Empowers — [[spell:357208]] and [[spell:396286]].
- Casting [[spell:395160]] — This means generating additional
          resources, either Essence or [[spell:396187]], lead to
          increased [[spell:395152]] uptime by letting you cast more
          [[spell:395160]]s.
- Casting [[spell:403631]] — If this is cast without
          [[spell:395152]] being active it will function as a new cast. If it
          is cast during [[spell:395152]] then it will extend 
          [[spell:395152]].
- Casting [[spell:395152]] — Ebon Might can Pandemic its
          duration up to an additional 30% extra duration. This means you can 
          refresh [[spell:395152]] before it expires!
- Casting [[spell:355913]] with [[spell:414969]].

### Prescience Targeting

3.2.

#### Prescience Targeting

[[spell:409311]] is an important buff that you can target on an ally to
      grant them Critical Strike Chance. If you cast [[spell:409311]] on an
      enemy it will automatically go onto a nearby DPS, prioritising players with
      [[spell:361021]] active.

By targeting allies manually you can get a higher quality targets, especially
      if the performance of your allies is not equal. Some players or classes often
      perform better on a specific fight and buffing them can outperform the default
      [[spell:361021]] targeting by as much as 3-5%!

A good general suggestion for most players who want to try manual targeting
      is to target the highest performing players in your raid. These players will
      get the most benefit out of prescience.

An additional improvement is to look at logs for a fight and see when players
      are doing the most damage, especially around important moments like adds, 
      raid vulnerabilities, and player cooldowns. These are excellent opportunities
      to gain significantly more damage from manual targeting with minimal work.
      You could even use general auto targeting between these important windows!

An example of this would be targeting powerful cooldown specialisations like 
      Elemental Shaman during their Ascendance and then buffing classes with a
      flatter damage profile like Beast Mastery Hunter or Devourer Demon Hunter between.

### Duplicate

3.3.

#### Duplicate

[[spell:1259173]] is Augmentation Evoker's Apex Talent. 
      [[spell:1259173]] has a significant impact on Augmentation Evoker's 
      Rotation, Stat Priority, and Talent Choices.

[[spell:1259173]] deals significant damage while active casting
      [[spell:395160]], [[spell:357208]] and [[spell:396286]].
      [[spell:395160]] will scale all of Augmentation's talents
      except for [[spell:438587]], [[spell:441176]]. These 
      casts will not extend your [[spell:395152]].

[[spell:1259173]] has additional talents, [[spell:1259174]] (2pts) and
      [[spell:1259175]], that significantly increase the power of and maintain
      high uptime of [[spell:1259173]].

[[spell:1259175]] grants an incredibly powerful buff effect during
      [[spell:1259173]] increases the power of your [[spell:395152]] by 
      75% on allies and significantly boosts the damage of your 
      [[spell:396286]].

[[spell:1259174]] allows anything that triggers [[spell:395153]] to
      also extend [[spell:1259173]]. This leads to a minigame very similar to
      maintaining [[spell:395152]] where you attempt to maximise the uptime
      of [[spell:1259173]]. Additionally, it significantly boosts the power of
      the talents from [[spell:403631]], [[spell:459537]] 
      and [[spell:407866]], increasing the amount of casts you can get
      within your [[spell:1259173]].

Another significance of [[spell:1259175]] is that it heavily
      incentivises pressing [[spell:403631]] on cooldown. Maximising 
      uptime on the doubled Primary Stat from the Buff ultimately contributes 
      more for overall DPS than holding [[spell:403631]] for an ideal 
      damage window.

Notably, [[spell:403631]] storing 30% of the raid's 
      DPS during its duration is a larger boost in DPS than the 
      additional 12% Primary Stat from having [[spell:1259173]] up. However,
      using [[spell:403631]] on cooldown results in significantly higher 
      [[spell:1259173]] uptime due to more frequent casts that get extended 
      by [[spell:1259174]]. At the same time, you will still get
      sufficiently strong [[spell:403631]] windows due to how varied most 
      DPS are in their damage profiles.

### Handling Movement

3.4.

#### Handling Movement

Handling movement on Augmentation Evoker is quite simple as you have
      access to [[spell:358267]]. [[spell:358267]] can be cast during any 
      non-empower cast to give yourself the ability to cast on the move. If 
      [[spell:358267]] is used while moving in any direction it will perform a 
      short dash in that direction.

For short movement events we suggest using holding a charge of
      [[spell:409311]] to handle it to preserve charges of [[spell:358267]] for
      more important moments.

If you find yourself caught without [[spell:358267]] or any charges of
      [[spell:409311]] available you should use [[spell:362969]] to fill
      with. This can still generate [[spell:396187]] for you
      making the DPS loss very small.

4.

### Important Cooldowns for Augmentation Evoker

Augmentation Evoker does not have many spells to use, but 
      correct utilisation is vital as most of the class's power comes from 
      using its short cooldown spells and its filler rotation.

### [[spell:403631]]

4.1.

#### Breath of Eons

[[spell:403631]] is Augmentation Evokers major cooldown. 
      [[spell:403631]] will debuff enemies storing a portion of damage 
      dealt by allies, exploding dealing that damage when the debuff expires.

Make sure to hit every enemy with [[spell:403631]] as this applies 
      the damage amplification effect to every target.

You should aim to use [[spell:403631]] at the shortest distance, as 
      the longer the line, the more time you are locked out from using other 
      spells. It is inevitable if you need to move further, but you will lose 
      some potential damage.

Augmentation Evoker has many talents that enhance [[spell:403631]] 
      such as [[spell:459537]], [[spell:407866]] and 
      [[spell:441176]], [[spell:433871]], 
      [[spell:1260745]] and [[spell:441206]] 
      from the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander Hero Talent.

As a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander you will want to cast 
      [[spell:403631]] on cooldown due to its Apex Talent 
      [[spell:1259173]] adding significant value to each cast.

As a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander you get [[spell:433871]] which 
      lets you steer your [[spell:403631]] and end it at any time. It is 
      important to end it as soon as you can, but wait for all of the 
      [[spell:1236970]] casts from your [[spell:1260745]]. They take 
      approximately two seconds to complete all of their casts.

Please see our dedicated section on our [Buffs Page](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)
      for more precise mechanics on how [[spell:403631]] works.

### [[spell:395152]]

4.2.

#### Ebon Might

[[spell:395152]] is the bread and butter of Augmentation Evoker's 
      damage output and gameplay. All decisions revolve around maintaining this 
      buff as much as possible.

You should aim to cast [[spell:395152]] if there are 3 or less 
      seconds remaining on the buff. We opt to cast [[spell:395152]] at 3 
      or less seconds because it can pandemic, adding up to 30% of its duration 
      to the next cast without losing any duration, which makes this the most 
      efficient point to recast at to optimise for effect and cooldown 
      efficiency.

If you are playing Mythic+ and are approaching the tail end of a pull it 
      might be correct to hold [[spell:395152]] and allow it to drop for 
      the last few seconds to guarantee that you will have it at the start of 
      the next pull. If you know that there is enough time between the end of 
      the current pull and the start of next to get the cooldown back then you 
      should still use it.

Please see our dedicated section on our [Buffs Page](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>)
      for more precise mechanics on how [[spell:395152]] works.

### [[spell:370553]]

4.3.

#### Tip the Scales

[[spell:370553]] is a 2 minute cooldown that will make your next 
      Empower cast instantly, at maximum rank.

[[spell:370553]] does not start its cooldown until you consume the 
      buff by using an Empower Spell.

As a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander this spell is best used on cooldown paired 
      with [[spell:357208]] to give you a higher rank without spending any 
      additional time.

As a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden you get several talents that boost the power 
      of [[spell:370553]]. The most notable being [[spell:431695]] 
      which gets enhanced further by [[spell:1260484]]. 
      These additional talents turn [[spell:370553]] into a potent 
      cooldown.

If you are playing [[spell:404977]] as a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden then we 
      suggest using a Macro to cancel the buff immediately. If you have an 
      empower available within a GCD then you should use it instead. This is a 
      DPS gain as [[spell:370553]] does not go on cooldown upon being 
      used, instead when it is consumed. This would cause it to desync from 
      [[spell:404977]] if it is not used nearly on Cooldown.

#### Chronowarden Cancelaura Tip the Scales

```wow-macro
#showtooltip
/cast Tip the Scales
/cancelaura Tip the Scales
```

As a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden, we use [[spell:370553]] on cooldown to 
      get the highest uptime on the stat buff as possible. This helps to 
      maintain [[spell:395152]] and [[spell:1259173]] for as long as 
      possible.

If you do not want to use [[spell:370553]] on cooldown then we 
      strongly suggest holding it to be used alongside [[spell:403631]] as 
      this remains perfectly viable, albeit slightly weaker for performance.

### [[spell:409311]]

4.4.

#### Prescience

[[spell:409311]] is a short cooldown, 2 charge, buff spell that 
      Augmentation Evoker should use rotationally. The [[spell:409311]] buff 
      will give Critical Strike Chance to an ally of your choosing. You should 
      avoid ever overcapping on charges of [[spell:409311]] unless forced to 
      by downtime.

[[spell:409311]] is enhanced by [[spell:407869]] which gives you a 
      chance to receive an [[spell:396187]] on cast, 
      [[spell:412774]] which gives the player with [[spell:409311]] a 
      chance to replicate damage done. Additionally, there are three 
      ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden talents that buff [[spell:409311]]: 
      [[spell:431874]], [[spell:431715]] and 
      [[spell:432004]].

You can choose to optimise the targeting of this buff by putting it on 
      the players who are doing the most damage in your Raid but it will not be 
      a significant difference in DPS. You could instead opt to cast it on the 
      boss and allow the games auto targeting to take care of it. Manual 
      targeting can be up to a 5% DPS gain from a worst case to a best case.

Please see our dedicated section on our [Buffs Page](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>) for more precise mechanics on 
      how [[spell:409311]] works.

### Empowers

4.5.

#### Empowers

Augmentation Evoker has two empowers: [[spell:357208]] and 
      [[spell:396286]].

Augmentation Evoker gets additional effects from casting Empower spells. 
      The most significant effect is that you will grant a nearby DPS the 
      [[spell:413984]] buff which increases their versatility. 
      Please see our dedicated section on our [Buffs Page](<https://www.icy-veins.com/wow/augmentation-evoker-buffs>) if you would like to know more 
      specifically about how [[spell:413984]] works.
      Additionally, Augmentation will extend [[spell:395152]] via 
      [[spell:395153]].

You should not cast [[spell:357208]] or [[spell:396286]] without
      [[spell:395152]] being up as this would waste the extension from
      [[spell:395153]], which is most of the value.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **18 Aug. 2026:** Add Missing Ebon Might cast to Rotation Opener for Chronowarden.
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **30 Apr. 2026:** Correct Spelling Mistake.
- **20 Apr. 2026:** Updated for Patch 12.0.5
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Pre-Season.
- **10 Feb. 2026:** Fix Opener having Fire Breath Hidden
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **22 Aug. 2025:** Fix Rotation Sequencing Problems for Chronowarden Opener.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7 with information about the Combat Assistant and Single-Button Assistant.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **24 Feb. 2025:** Updated for Patch 11.1 including Rotation changes for Season 2 Tierset.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7
- **21 Oct. 2024:** Reviewed for Patch 11.0.5
- **04 Oct. 2024:** Update default Scalecommander M+ Build based on hotfixes.
- **22 Sep. 2024:** Correct Typos.
- **22 Sep. 2024:** Update Rotation for Scalecommander & Molten Embers.
- **10 Sep. 2024:** Update references of Upranking Firebreath because of Molten Embers.
- **09 Sep. 2024:** Improve readability for Tip the Scales info.
- **21 Aug. 2024:** Updated for The War Within Launch with Hero Talent support.
- **23 Jul. 2024:** Opener fixed with Molten Embers.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed and updated for Dragonflight Season 4
- **19 Jan. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **13 Jul. 2023:** Fix default talent checkboxes and include Auto Targeting note.
- **10 Jul. 2023:** Page added.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Augmentation Evoker in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Augmentation Evoker

Welcome to our Gearing Page for Augmentation Evoker for 
  Midnight Season 2. This section will cover everything you need 
  to know about equipping your character correctly. Please see the sections 
  below for information on the best gear, including Trinkets, and Crafted Items.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which 
  lets you increase the item level of gear along tracks that relate to where 
  you obtained the item, which harder content dropping gear that can be 
  upgraded to higher Item Levels. For more information, read up on our 
  dedicated page on how the  [gearing 
    system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has  changed in the Midnight expansion.

### Overall

This list highlights one overall BiS setup for obtainable for Augmentation Evoker. There are other gear setups possible that can have equivalent DPS output. Other setups depend on what items you get to drop for your character. If you would like to acquire personalised recommendations tailored to your specific character, we suggest checking out our full guide on simming your character that can be found [here](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 the catalyst will preserve the stats and effects of the items you catalyse. We have listed the best items to catalyse per slot below:

- Helm: [[item:159374@JAAEAAgNyQWN]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Shoulders: [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Chest: [[item:271876@JAAEAAAG2YhN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Hands: [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Legs: [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details FAQWhat are the highest priority items to acquire?
The highest priority items to acquire are all three cantrip items from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>). We suggest taking a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) each week that you can and using it on Heroic Difficulty while on **Preservation**, which removes the damage trinket, loot spec until you have all three.

Other priorities are high mastery items, such as [[item:193752@JAAIAAQkCYHKvbRLfA]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>).

Other high priority items include: [[item:268249@JAACAAgNyA]], [[item:158366@JAACAAgNyA]], and [[item:250224@JAACAAgNyA]].

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271502@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268251@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271504@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268197@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup with farmable gear from Season 2 Mythic+ Dungeons. There are other gear setups possible that can have equivalent DPS output. Other setups depend on what items you get to drop for your character. If you would like to acquire personalised recommendations tailored to your specific character, we suggest checking out our full guide on simming your character that can be found [here](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 the catalyst will preserve the stats and effects of the items you catalyse. We have listed the best items to catalyse from Mythic+ per slot below:

- Helm: [[item:159374@JAAEAAgNyQWN]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Shoulders: [[item:239049@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Chest: [[item:251233@JAACAAgNyA]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Hands: [[item:193752@JAAKAAQkCYHKvbRLfYjM]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- Legs: [[item:159375@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): This dungeon has the highest number of BiS items of any dungeon so we strongly recommend starting your farm here. Make sure you are on Preservation loot spec to avoid the trinket.
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): This has one of Augmentation Evokers best trinkets ([[item:250224@JAACAAgNyA]]) as well as a good belt, helm and neck.
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): This has another good Mythic+ Trinket ([[item:250215@JAACAAgNyA]]) and our second best ring.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271499@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271500@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271504@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250224@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:271681@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup with items from the Midnight Season 2 Raids. There are other gear setups possible that can have equivalent DPS output. Other setups depend on what items you get to drop for your character. If you would like to acquire personalised recommendations tailored to your specific character, we suggest checking out our full guide on simming your character that can be found [here](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 the catalyst will preserve the stats and effects of the items you catalyse. We have listed the best items to catalyse per slot below:

- Helm: [[item:268230@JAAEAAgNyQWN]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Shoulders: [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Chest: [[item:271876@JAAEAAAG2YhN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Hands: [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Legs: [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

:::

:::details FAQWhat are the highest priority items to acquire?
The highest priority items to acquire are all three cantrip items from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>). We suggest taking a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) each week that you can and using it on Heroic Difficulty while on **Preservation**, which removes the damage trinket, loot spec until you have all three.

Other high priority items include: [[item:268249@JAACAAgNyA]], good trinkets like [[item:270170@JAACAAAKxA]], [[item:270161@JAACAAAKxA]] or [[item:270164@JAACAAAKxA]].

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271502@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268251@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271504@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Augmentation Evoker

Augmentation Evoker currently prefers to wear passive trinkets, as the 
cooldown of [[spell:403631]] often does not line up with trinkets due to 
Cooldown Reduction effects. If you are using an on-use trinket, you can use 
them on Cooldown.

The main standout trinkets available this tier are
  [[item:270168@JAACAAAG2A]], [[item:281215@JAACAAAOyA]]
  and [[item:270161@JAACAAAOyA]]. For raiding we suggest using 
  [[item:281215@JAACAAAOyA]] and [[item:270168@JAACAAAG2A]].
  For Mythic+ we suggest using [[item:270161@JAACAAAOyA]] and 
  [[item:281215@JAACAAAOyA]].

With so many trinkets to choose from, we suggest taking a look at 
our trinket ranking chart below to get a better understanding of which 
trinkets are good.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Augmentation Evoker Trinket Rankings
All trinkets are assumed to be Mythic item level unless a lower item level 
    is specified for the sake of comparison. The idea is to compare trinkets at 
    their maximum obtainable item level to give you an idea of where things are 
    placed. We do not suggest using two on use trinkets even if the trinkets 
    are ranked higher than passive trinkets on this list. For more accurate 
    information on how trinkets perform relative to each other for your own 
    character, please [sim your character](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

A "Tier" as defined by this list is around 0.5% DPS, meaning that S-Tier 
    Trinkets are around 0.5% better than A-Tier Trinkets, and so on.

<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Raiding</th>&#10;<th>Mythic+</th>&#10;</tr>&#10;<tr>&#10;<td><span><strong>S Tier</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<span>This is a channeled on use trinket that deals an extremely large burst&#10;             of damage upon being used with a long 4 minute cooldown.&#10;             This trinket is exceptional on both <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> and <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a>&#10;             due to having damage vulnerability phases. On other fights this trinket&#10;             still performs extremely well.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a passive trinket that provides a large amount of average&#10;            Critical Strike chance with high consistency. The additional effect&#10;            significantly improves the average stats provided on fights with adds.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:249346@JAACAAgV1A]] - <span><em>Click for Details</em></span>&#10;<span>Despite being a trinket from Season 1 this is a highly competitive trinket&#10;            for Augmentation this tier to get more Burst DPS. At 298 item level this trinket&#10;            is only outperformed by Myth trinkets. If you do not have this trinket at 298&#10;            item level you will not be able to acquire it during this Season and will need&#10;            to use another trinket.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270161@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a damage proc trinket leaves a stacking DoT on an enemy. This DoT does&#10;            reasonable damage by itself but what makes it really powerful in Mythic+ is the&#10;            extra effect on killing an enemy. These explosions do a lot of damage and&#10;            heavily reward chainpulling monsters to let the DoT effects cascade onto&#10;            enemies.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a passive trinket that provides a large amount of average&#10;            Critical Strike chance with high consistency. The additional effect&#10;            significantly improves the average stats provided in Mythic+ as each pack&#10;            gives you a large burst of additional stacks.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>A Tier</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270169@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<span>This is an interesting on use trinket that has a ramping negative main stat&#10;            debuff. When you use the on-use it will remove the debuff and grant you a large&#10;            on-use buff. This trinket is currently slightly undertuned despite being&#10;            obtainable at 344 item level. This trinket can be used to great effect on&#10;            bosses with damage vulnerability phases or adds to shift your damage&#10;            into those windows.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270167@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is passive trinket that provides an intellect buff that rises&#10;            and falls over an encounter. This trinket is rated highly as it is both&#10;            highly tuned and scales better on fights with multi-target cleave than&#10;            damage trinkets do.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270170@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a decent on use damage trinket. The extra effect on this trinket&#10;            gets very little cooldown reduction despite there being fights with adds due&#10;            to requiring you to get the finishing blow.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a mastery proc trinket that provides a large boost to passive mastery,&#10;            which is augmentations best stat. This trinket will proc a zone you have to&#10;            stand in that provides even more mastery. This will always spawn on your head&#10;            and is quite easy to see but you are not guaranteed to have 100% uptime.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270161@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a damage proc trinket leaves a stacking DoT on an enemy. This DoT does&#10;            excellent single-target damage by itself and is the bulk of the contribution in&#10;            raid as you will not usually get much damage from the explosions.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250224@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is passive trinket that has no stats on it whatsoever, instead having both&#10;            a damage proc and a main stat proc. This is reasonably well tuned for single-target&#10;            but is slightly worse than stat trinkets for multi-target encounters.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is the best on use stat trinket available this season. This trinket is good&#10;            if you want to improve your burst damage on an encounter, especially for dealing&#10;            with Adds or damage burns.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a high budget stat trinket which provides a strong consistent DPS&#10;            increase despite Augmentations poor secondary stat scaling. This trinket is&#10;            highly rated for AoE damage which makes up a significant portion of this raid.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<span>This is a channeled on use trinket that deals a large burst&#10;            of damage upon being used. This trinket can be used if you need&#10;            additional burst on specific pulls throughout a dungeon.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250224@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is passive trinket that has no stats on it whatsoever, instead having both&#10;            a damage proc and a main stat proc. This is reasonably well tuned for Single&#10;            Target but is slightly worse than stat trinkets for AoE.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270167@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is passive trinket that provides an intellect buff that rises&#10;            and falls over an encounter. This trinket is rated highly as it is both&#10;            highly tuned and scales better on fights with multi-target cleave than&#10;            damage trinkets do.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a high budget stat trinket which provides a strong consistent DPS&#10;            increase despite Augmentations poor secondary stat scaling. In Mythic+ this&#10;            is rated higher as Stat Trinkets are stronger relative to raid since the&#10;            potent damage trinkets usually do not scale.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a mastery proc trinket that provides a large boost to passive mastery,&#10;            which is augmentations best stat. This trinket will proc a zone you have to&#10;            stand in that provides even more mastery. This will always spawn on your head&#10;            and is quite easy to see but you are not guaranteed to have 100% uptime.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is the second best on use trinket available this season, behind&#10;            [[item:249346@JAACAAgV1A]] from Season 1. This trinket is good&#10;            if you want to improve your burst damage on an encounter, especially for dealing&#10;            with Adds or damage burns.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270170@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a strong single-target damage trinket that is available from&#10;            the raid. This deals execllent priority and single-target damage throughout&#10;            a key. Furthermore, this trinket gets additional cooldown reduction when enemies&#10;            die letting you get more uses over an entire dungeon.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270169@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<span>This is an interesting on use trinket that has a ramping&#10;            negative main stat debuff. When you use the on-use it will remove&#10;            the debuff and grant you a large on-use buff. This trinket lets you&#10;            shift damage from less relevant parts of a pull, such as the tail end&#10;            when you are cleaning up a pack, to the start of a pull where DPS have&#10;            their cds running. Despite this, it is currently slightly undertuned and&#10;            is only recommended at 344 item level.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>B Tier</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:248583@JAAEAAANyE4M]] (Hero) - <span><em>Click for Details</em></span>&#10;<span>This is a Delve Trinket that can have its stats changed to proc &#10;            any of the four types. For Augmentation Evoker, we want this &#10;            trinket to proc Mastery. Use the trinket at the Jan'alai temple to &#10;            get this stat. Note: Make sure to remove the trinket slot from &#10;            any macros, as the on-use on this trinket will break your &#10;            macros.</span>&#10;</li>&#10;<li>[[item:273794@JAACAAAOyA]]</li>&#10;<li>[[item:273796@JAACAAAOyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfgjM]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:248583@JAAEAAANyE4M]] (Hero) - <span><em>Click for Details</em></span>&#10;<span>This is a Delve Trinket that can have its stats changed to proc &#10;            any of the four types. For Augmentation Evoker, we want this &#10;            trinket to proc Mastery. Use the trinket at the Jan'alai temple to &#10;            get this stat. Note: Make sure to remove the trinket slot from &#10;            any macros, as the on-use on this trinket will break your &#10;            macros.</span>&#10;</li>&#10;<li>[[item:273794@JAACAAAOyA]]</li>&#10;<li>[[item:273796@JAACAAAOyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfgjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>C Tier</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>[[item:251792@JAACAAANyA]] (Hero)</li>&#10;<li>[[item:249809@JAACAAgV1A]]</li>&#10;<li>[[item:249343@JAACAAgV1A]]</li>&#10;<li>&#10;&#10;&#10;[[item:245829@JAAKAAwt1wgNRDjexwhN]] - <span><em>Click for Details</em></span>&#10;<span>This is a Craftable Darkmoon Deck trinket. This trinket is the &#10;            best performing Darkmoon Deck but like all the other Darkmoon &#10;            Decks costs you an embellishment slot. The loss of an &#10;            Embellishment is equivalent to losing ~1% DPS dropping this &#10;            trinket from A tier to C tier.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAAOyA]]</li>&#10;<li>[[item:251792@JAACAAANyA]] (Hero)</li>&#10;<li>[[item:249809@JAACAAgV1A]]</li>&#10;<li>&#10;&#10;&#10;[[item:245829@JAAKAAwt1wgNRDjexwhN]] - <span><em>Click for Details</em></span>&#10;<span>This is a Craftable Darkmoon Deck trinket. This trinket is the &#10;            best performing Darkmoon Deck but like all the other Darkmoon &#10;            Decks costs you an embellishment slot. The loss of an &#10;            Embellishment is equivalent to losing ~1% DPS dropping this &#10;            trinket from A tier to C tier.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>D Tier</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAACAAAOyA]]</li>&#10;<li>[[item:251786@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:245855@JAAKAAwt1wgNRDjexwhN]] - <span><em>Click for Details</em></span>&#10;<span>This is a Craftable Darkmoon Deck trinket. This trinket costs you&#10;            an embellishment slot. The loss of an Embellishment is equivalent to&#10;            losing ~1% DPS dropping this trinket from B tier to D tier.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:245846@JAAKAAwt1wgNRDjexwhN]] - <span><em>Click for Details</em></span>&#10;<span>This is a Craftable Darkmoon Deck trinket. This trinket costs you&#10;            an embellishment slot. The loss of an Embellishment is equivalent to&#10;            losing ~1% DPS dropping this trinket from B tier to D tier.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:245750@JAAKAAwt1wgNRDjexwhN]] - <span><em>Click for Details</em></span>&#10;<span>This is a Craftable Darkmoon Deck trinket. This trinket costs you&#10;            an embellishment slot. The loss of an Embellishment is equivalent to&#10;            losing ~1% DPS dropping this trinket from B tier to D tier.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAACAAAOyA]]</li>&#10;<li>[[item:251786@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:245855@JAAKAAwt1wgNRDjexwhN]] - <span><em>Click for Details</em></span>&#10;<span>This is a Craftable Darkmoon Deck trinket. This trinket costs you&#10;            an embellishment slot. The loss of an Embellishment is equivalent to&#10;            losing ~1% DPS dropping this trinket from B tier to D tier.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:245846@JAAKAAwt1wgNRDjexwhN]] - <span><em>Click for Details</em></span>&#10;<span>This is a Craftable Darkmoon Deck trinket. This trinket costs you&#10;            an embellishment slot. The loss of an Embellishment is equivalent to&#10;            losing ~1% DPS dropping this trinket from B tier to D tier.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:245750@JAAKAAwt1wgNRDjexwhN]] - <span><em>Click for Details</em></span>&#10;<span>This is a Craftable Darkmoon Deck trinket. This trinket costs you&#10;            an embellishment slot. The loss of an Embellishment is equivalent to&#10;            losing ~1% DPS dropping this trinket from B tier to D tier.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

The [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) Bonus Rolls added in Patch 12.0.5 have been
  continued for Patch 12.1. These can be used in dungeons or after killing a
  specific raid boss, and lets you gain a guaranteed piece of loot from that
  dungeon or raid boss. The item you get is random, but you can not get a
  duplicate item so using it again in a specific place will give you another
  chance on the remaining items.

3.1.

#### Recommended Nebulous Voidcore Usage for Augmentation Evoker

For Season 2 we recommend starting with a [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) centric Bonus Roll
  Strategy. If you use a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) on Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 
  then you will acquire a 1/6 Myth item from the boss. This is incredibly 
  powerful as those items are all cantrip items and are so strong that they
  are only outperformed by the Elevated versions from beating the Mythic encounter.

We will perform this strategy by taking [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s from your
  first three vaults after the season starts in place of the items inside the
  vaults. If you see a BiS item that would otherwise be time consuming to 
  obtain, such as a Mythic+ item with perfect stats, then you can comfortably skip the
  [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) that week.

Additionally, even if you do not clear [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in the 2nd week of it
  being available you can hold onto your [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s for when you
  do beat it and reclear the fight three times, even while saved, and use your
  bonus rolls!

After using your [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s on [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), another good
  place to use your coins is [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>) for the
  [[item:268249@JAACAAgNyA]] and
  [[item:268254@JAACAAgNyA]]. You can go Preservation loot 
  spec here as well to avoid [[item:270161@JAACAAgNyA]] if 
  you already have good trinkets for Raid. If you are mainly gearing up for 
  Mythic+ then we suggest staying on DPS lootspec as the trinket is BiS for 
  Mythic+.

After this we suggest using your coins to hunt for the remaining BiS list 
  items that you still need.

Here is a short summary of the above strategy:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Four rolls on [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) DPS Loot Spec to get 
         all three Cantrip Items and the trinket.
2. Roll on [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) to get the ring and trinket.
3. Roll on [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>) as many times as it takes to acquire
         [[item:268249@JAACAAgNyA]] and
         [[item:268254@JAACAAgNyA]].
4. Optionally, roll on [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>) while DPS Loot Spec for
         [[item:270161@JAACAAgNyA]] if Mythic+ oriented.
         You need to swap to DPS loot spec before you acquire every item from
         Vashnik.
5. Remaining BiS List items

:::

3.2.

#### Ascendant Venomstones

We suggest priotising slots in the following order when spending your [[item:280562]]:

1. Your Weapon
2. Your Offhand
3. Your on-use trinket
4. Your passive trinket
5. Your neck item

:::details TipsWhat is the best neck when using Venomstones?
A Mastery neck like

[[item:268251@JAACAAAOyA]]

at 340 item level will be better than Mythic

[[item:268265@JAACAAAG2A]]

at 344, as it was previously only
Best-in-Slot due to having higher item level.

:::

4.

### Best Crafted Items for Augmentation Evoker

Profession gear is extremely useful for Augmentation Evoker in 
  Midnight Season 2. Augmentation currently prioritises Mastery 
  above all of its other stats so being able to select the perfect stats on 
  crafted pieces is incredibly good. Additionally, you can use up to two 
  embellishments in total between your crafted pieces which further augment 
  your DPS!

This section focuses on crafting items in the most optimal order to gain 
immediate, efficient and effective power gains. Some of the items you 
make here will not be a part of your final Best-in-Slot gear list in the 
endgame and will need to be replaced. We will be crafting them anyway 
though as they are an incredibly effective way to get DPS from your 
Sparks and Mistcrests.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Augmentation Crafted Gear Priority**
- [[item:245769@JAAMAAwt1wgNRDzViscNcYD]] with
        [[item:273060]]. You will eventually replace this with a
        Myth offhand as [[item:240167]] is stronger than either
        [[item:273060]] or [[item:245876]]
- If you do not manage to coin 
        [[item:271092@JAACAAgNyA]] immediately then you can 
        opt to craft [[item:237838@JAAMAAwt1wgNRDzViscNcYD]]
        with [[item:273060]]. You should only do this if you 
        need power early, as your weapon slot is the single largest power 
        increase possible. You will continue to use this until you obtain
        [[item:271092@JAACAAgNyA]] at equal or higher item 
        level and have another free spark to create an Armour Piece with
        [[item:240167]].
- Highest upgrade Armour Slot with [[item:240167]].
        This would not be part of your Best-in-Slot gear and is a temporary
        item for power for progression. You can opt to craft the belt and
        wrist, shown below, instead.
- [[item:244584@JAAKAAgIvYTNbWCYwclI]] 
        with [[item:240167]], removing the Embellishment from your 
        weapon if you are still using a crafted weapon.
- [[item:244581@JAAKAAgIvYTNbWCYwclI]] 
        with [[item:240167]], removing the Embellishment from your 
        offhand if you are still using a crafted offhand.
- Engineering Crafts like [[item:244745@JAAKAAAD2cbNbWit1E4K]]
        and [[item:244773@JAAKAAAD2cbNbWit1E4K]].
- Any item you do not have on Myth track yet.

:::

:::details FAQWhy Craft an Off Hand First if Main Hand or Staff is higher budget?
We are opting to Craft an Off Hand first as we are assuming you are following
the

[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

Bonus Roll strategy outlined in the Nebulous Voidcore
Section. We do not want to immediately craft a Main Hand if we have a chance to
acquire a better weapon the following week, and an offhand is the next highest
budget craft available. If you do not plan on following this strategy you should
craft a staff.

:::

:::details FAQWhy Should Augmentation Use [[item:240167]]?
We opt to use

[[item:240167]]

as it is currently one of the
highest budget embellishments when including the Primary Stat granted to an
ally.

:::

:::details FAQAny Slots to Avoid Crafting For?
With the changes in how the Catalyst works with Tier pieces there are no
slots to avoid crafting in, although you should still be somewhat careful over
crafting in Tier Piece slots.

:::

4.1.

#### Best Embellishments for Augmentation Evoker

Embellished Items are more powerful than other items of the same item level. 
This means that, despite not being the highest item level, they are used as a
part of our Best-in-Slot list.

For Augmentation Evoker there are only a few good Embellishments: 
  [[item:240167]], [[item:273060]], 
  [[item:245876]] and [[item:251487]]. You will want 
  to use these on your crafted items while filling out the gaps in your gear.

[[item:273060]] is a new Embellishment added in Patch 12.1. This 
  Embellishment can proc any secondary stat buff with an equal chance. This is 
  a very powerful Embellishment as it grants a large amount of stats. This can 
  only be crafted on Weapons and Offhands.

All of these Embellishment effects stack. Having two of the same effect will 
double the effectiveness of the procs!

[[item:245876]] grants a temporary secondary stat buff when
your spells or abilities trigger it. The stat granted depends on the 
**type of creature you are fighting**:

- **Haste:** Elemental, Aberration, Demon
- **Critical Strike:** Beast, Mechanical
- **Mastery:** Humanoid, Dragonkin
- **Versatility:** Undead, Giant, Other

For Augmentation Evoker, this embellishment is powerful 
because it has a very high uptime. This effect is completely passive and 
does not require you to play around it.

**Important Notes:**

- The stat gained is **determined by the enemy creature
    type**, meaning its value can vary depending on the dungeon or 
    raid encounter making this embellishment better or worse.
- Many raid bosses and dungeon enemies fall into the **Humanoid or 
    Demon categories**, which often results in **Mastery or 
  Haste**. Haste is an extremely good stat for Augmentation 
  Evoker while Mastery is worse so this Embellishment can swing quite 
  wildly in power depending on the boss.
- We recommend removing this embellishment as soon as you can create your 
  third Crafted Item due to the inconsistency in which stat you will 
  receive.

[[item:240167]] has a chance to summon a **Mana
Wyrm** that grants [[spell:1229746]] to you and a
nearby ally. This effect increases the **Primary Stat** of 
both players for a short duration.

This is Augmentation Evoker's best embellishment providing close to 1% DPS 
increase. Augmentation Evoker scales far better with Primary Stat 
compared to Secondary Stats as it affects almost all of your damage 
output, even [[spell:395152]]!

[[item:251487]] is a single target damage proc
embellishment that can only be crafted on jewellery slots.

This can be added to one of the two items:

- [[item:240949@JAAKAAgIvYTNbWyVi0IN]]
- [[item:240950@JAAKAAgIvYTNbWyVi0IN]]

**Important Notes:**

- The damage of this Embellishment scales with the total types of gems 
  you have equipped (Which Main Stat). Despite this, the increase is so 
  small so we do not suggest equipping gems for Versatility or Mastery. 
  You will want to use at least one of each Haste and Crit gems though!
- The effect performs best in **single target encounters**, 
  as it only damages one enemy.
- This Embellishment is worse than [[item:240167]] above one 
  target while approximately equivalent at one target.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with the 
[[item:275707]] consumable. You can get this item from the Vendor 
near the Great Vault for the tokens you receive when not choosing an item. 
You will need to hand in six to get a [[item:275707]].

5.

### Crest Usage

Early on in the season, your access to crests is restricted by the weekly 
  cap. During this period you will want to be efficient with your use of 
  [Myth Mistcrest](<https://www.wowhead.com/currency=3446>) and [Hero Mistcrest](<https://www.wowhead.com/currency=3445>). You can use these 
  currencies to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) to higher item levels. We 
  suggest only upgrading items that you will be using for a long time or in 
  order of the greatest upgrade.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Augmentation Evoker Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

You will ideally upgrade all of your items to their maximum upgrades 
  possible but it is very important early on to be efficient with the use of 
  crests to keep yourself from falling behind your peers and remaining 
  competitive!

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5 adding new Raid Boss items.
- **18 Aug. 2026:** Update trinket Tierlist and crafting recommendations for the changes.
- **12 Aug. 2026:** Correct Mythic+ Item Sources typos for ring and cloak.
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **26 Jun. 2026:** Drop Gaze of the Alnseer in the M+ Tier List due to the bug reducing the average stacks not being resolved.
- **16 Jun. 2026:** Typo fix in Sporefused Section.
- **15 Jun. 2026:** Add section for Sporefused Gear.
- **04 May 2026:** Update Mythic+ Trinket Ranking.
- **20 Apr. 2026:** Update Gear section for Ascendant Voidcores and Nebulous Voidcores. Update Trinket Tierlists.
- **27 Mar. 2026:** Add Litany of Lightblind Wrath trinket.
- **23 Mar. 2026:** Drop Vessel of Tortued Souls placement on the tierlist.
- **19 Mar. 2026:** Soulcatchers Charm Trinket now properly drops for Evokers.
- **17 Mar. 2026:** Update Trinkets and Tierset information.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Pre-Season.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated to include information for Dinars and Tierset Comparison.
- **10 Sep. 2025:** Update Gear Page indicating tierset performance after Hotfixes.
- **12 Aug. 2025:** Update Trinket Tierset after initial Trinket Tuning.
- **05 Aug. 2025:** Update Tierset Values for Scalecommander, change Trinket Tierlist, and adjust BiS List.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **24 Jun. 2025:** Update DISC Recommendation for Nerfs
- **15 Jun. 2025:** Updated for Patch 11.1.7 to include the DISC belt.
- **12 May 2025:** Update a few trinket comments.
- **08 May 2025:** Completely update the gear list for the Patch 11.1.5 Hotfixes causing stat priorities to change.
- **02 May 2025:** Updated Dinar Section.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **04 Mar. 2025:** Updated for Raid Week 1 Gear Tuning.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **24 Feb. 2025:** Updated for Patch 11.1 with new BiS Lists and trinket information.
- **04 Jan. 2025:** Update Trinket Tierlist to increase the rank of Cirrals Concoctory.
- **17 Dec. 2024:** Recommended gear pages updated with Cyrce's Ring's. Comment about Roaring Warqueens added to gear section for M+.
- **17 Dec. 2024:** Cyrce's Ring Recommendations updated with the changes.
- **15 Dec. 2024:** Updated for Patch 11.0.7 adding Cyrce's Ring, BiS changed.
- **21 Oct. 2024:** Update for Patch 11.0.5
- **22 Sep. 2024:** Correct Typos.
- **21 Sep. 2024:** Updated for new Scalecommander Information.
- **17 Sep. 2024:** Update Trinket Tier List for Mythic Launch.
- **13 Sep. 2024:** Remove Preason Gear List
- **09 Sep. 2024:** Add The War Within Season 1 Embellishment Information
- **09 Sep. 2024:** Add The War Within Season 1 BiS Lists for Gear and Trinkets.
- **22 Aug. 2024:** Add a disclaimer for Embellishment items
- **22 Aug. 2024:** Correct a typo
- **21 Aug. 2024:** Updated with a Pre-Season BiS for The War Within Launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed and updated for Dragonflight Season 4
- **19 Jan. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Updated for Patch 10.2.5 changing the BiS Dungeon Only Weapon
- **24 Nov. 2023:** Fix Typo in Dungeon Gear.
- **21 Nov. 2023:** Update BiS trinktes to account for stack losses.
- **13 Nov. 2023:** Gear adjustments and updates based on latest hotfixes.
- **07 Nov. 2023:** Gear adjustments and updates based on latest hotfixes.
- **06 Nov. 2023:** Updated for patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7 and updated format
- **10 Jul. 2023:** Page added.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Augmentation Evoker. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Augmentation Evoker Stat Priority

Currently both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander have 
  similar stat priorities with both heavily investing into Mastery and playing 
  [[spell:409267]] along with [[spell:1250914]]. As a 
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Crit is very slightly better than Haste but they are 
  extremely close. As a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander they are equivalent. 
  Versatility is awful for both Hero Talents.

Item Level

Mastery

Critical Strike

Haste

Versatility

Item level is by far the most important aspect of gearing for non jewellery 
  slots. On jewellery it can be worth dropping a small amount of item level for 
  better stats, as Augmentation does not scale very well with secondary stats.

Currently Mastery is significantly ahead of any other stat until you get 
  close to the Second Stat DR around 1840 Mastery. At that point it is 
  approximately equal to Haste and Critical Strike Chance. Prior to that you 
  would prioritise it trying to get as much as possible, ideally having 
  Critical Strike Chance or Haste as the second stat on the item.

As a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden with [[spell:431874]], you gain the ability 
  to critically strike with [[spell:395152]] and [[spell:409311]],
  increasing the power of those buffs by 50% on Critical Strike. This improves 
  the power of Critical Strike above that of Haste making it Augmentations 
  second best stat.

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. You should look for this stat in all
of your upgrades. It provides you with Spell Power, which increases the damage
of your spells.

**Mastery** ([[spell:406380]]) causes empower spells you cast to 
  give a DPS [[spell:413984]] which grants Versatility to another ally 
  for 10 seconds. Additionally, it increases the duration of 
  [[spell:413984]], [[spell:403631]], [[spell:395152]], and 
  other helpful Auras.

**Critical Strike** increases your chance for your abilities to deal
200% damage. [[spell:395153]] means your [[spell:395152]] extension
effects can Critically Strike, increasing the amount of extension granted
by 50%.

**Haste** increases your spell casting speed (including Empowered Spells)
and the tick rate of your periodic effects.

**Versatility** increases all your damage and healing done, and decreases
all damage taken.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point gained, which are known as the points of diminishing return. Once you have reached these amounts, stats will become progressively less valuable and may fall behind other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight Pre-Season.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **08 May 2025:** Updated for Patch 11.1.5 Hotfixes changing Stat Priorities.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **24 Feb. 2025:** Updated for Patch 11.1 with Mastery being dominant for all Hero Talents.
- **15 Dec. 2024:** Updated for Patch 11.0.7 with Mastery beating Crit for Scalecommander
- **21 Oct. 2024:** Reviewed for Patch 11.0.5
- **21 Sep. 2024:** Updated for new Scalecommander information.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch including new stats for Chronowarden.
- **18 Aug. 2024:** Updated for The War Within Launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed and updated for Dragonflight Season 4
- **19 Mar. 2024:** Reviewed for Patch 10.2.6
- **08 Mar. 2024:** Update stats and change formatting
- **15 Jan. 2024:** Reviewed for Patch 10.2.5
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Page added.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Augmentation Evoker, based on your [stat priority](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

In Midnight there are both Primary Stat gems (Epic Quality) and Main StatGems 
  (Rare). Currently, the Main Stat Gem is significantly stronger than the 
  Secondary Gem.

You may only run one Main Stat gem and we recommend running 
  [[item:240983]] as it offers the most Main Stat. We 
  suggest filling all of your remaining sockets with  
  [[item:240898]], as Mastery and Critical Strike Chance are 
  Augmentations best stats. You can use [[item:240900]] if you 
  would like a small amount extra haste on your character.

2.

### Best Enchants and Weapon Augments

You should be using [[item:243733]] at all times.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>[[item:244031]]</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>Ring</td>&#10;<td>[[item:243959]]</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come 
  prepared with the right consumables to endgame content has a big impact on 
  your performance.

3.1.

#### Flask

You should use [[item:241322]] for all content, as Mastery is 
  Augmentation Evoker's best stat.

3.2.

#### Potion

We recommend making sure you have the new 
  [[item:271883]] Healing Potions as they heal for 
  considerably more than old [[item:241305]]s.

We recommend using the Secondary Stat potion [[item:241288]] in 
  all content if Mastery is your highest stat. If Mastery is not your highest 
  stat we suggest using a Primary Stat Potion like 
  [[item:241292]] or [[item:241308]].

[[item:241292]] is stronger than [[item:241308]] 
  but has a downside where it spawns voidzones that will silence you, these can 
  be easily avoided by using hover and moving whenever you see one appear 
  underneath your feet. If you would rather not deal with this then 
  [[item:241308]] is fine.

3.3.

#### Food Buff

As an Augmentation Evoker you will want to use the best Primary stat food 
  available to you. Currently this would be the [[item:255845]] 
  feast. If the feast is not available, or if the secondary stat Feast is 
  placed, then you should use [[item:242275]] to ensure you get the primary 
  stat buff.

3.4.

#### Augment Rune

You should use [[item:259085]], if you can afford it, when 
  challenging the hardest content the game has to offer. We do not suggest 
  using these regularly for farm kills or dungeons, as they are often 
  expensive, but if your wallet allows for it, you can expect approximately a 
  1% DPS gain from using these.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Revieed for Patch 12.1.5
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Fixed typo in Recommended Gem.
- **23 Mar. 2026:** Remove the Gathering Teas from the consumables section. These no longer work.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Pre-Season.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **08 May 2025:** Updated for Patch 11.1.5 Hotfixes changing best Enchantments and Gems
- **21 Apr. 2025:** Updated for Patch 11.1.5 with Horrific Visions Enchantments.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Reviewed for Patch 11.0.7
- **21 Oct. 2024:** Reviewed for Patch 11.0.5
- **09 Sep. 2024:** Add mention of Authority of Radiant Power for M+. Add Speed Blasphemite.
- **09 Sep. 2024:** Fix typo
- **22 Aug. 2024:** Fixes to typos
- **22 Aug. 2024:** Updated best Weapon Oil/Temporary Weapon Enchantment comments
- **21 Aug. 2024:** Updated for The War Within Launch with all of the new consumables and enchants.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed and reformatted for Dragonflight Season 4
- **19 Jan. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Page added.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Augmentation Evoker in World of Warcraft Patch 12.1.5.

1.

### Augmentation Evoker in Mythic+ in Midnight Season 2

[Augmentation Evoker](<https://www.icy-veins.com/wow/augmentation-evoker-pve-dps-guide>) is a support-focused specialization that brings
value to the group by buffing the other members. The 25-yard range might take
some getting used to, but the rest of the class has been designed to be as
simple and smooth to play as possible!

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

In 5-man content, most of your buffs will automatically target the correct
  targets always for you. For example, [[spell:395152]] will always hit
  the entire group, [[spell:409311]] will auto-target the other two damage
  dealers before targeting the healer or tank, [[spell:360827]] will
  always go on the tank. This helps alleviate any burdens for you and lets
  you focus on the enemies in the Keys.

However, if both DPS have
  [[spell:409311]] then auto-targeted casts may choose the target 
  suboptimally. Ideally, you would prefer for the Prescience to be on both 
  damage dealers and either you or the tank, but auto-targeting may give it to 
  the healer. It is approximately a 1% DPS gain in keys to manually target 
  [[spell:409311]] to maximize uptime on the optimal players.

2.

### Best Talents for Augmentation Evoker

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Threads Reactive Hide

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Threads Reactive Hide Mythic+ Build for Augmentation Evoker

We currently suggest playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden in all Mythic+ as it
      deals significantly more single-target damage, making keys noticeably faster.
      However, if you prefer the gameplay of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander it is not that
      far behind, especially in lower keys.

This build opts into playing [[spell:412713]] over
      [[spell:404977]] which allows for a smoother gameplay experience.
      We also take [[spell:360827]] and [[spell:409329]].
      These talents now deal significant damage on AoE packs, making them
      worth investing in.

We play both [[spell:459537]] and [[spell:407866]] as
      they provide a comfortable gameplay experience, due to the additional Haste and
      resources provided around your [[spell:403631]] windows. These two
      talents perform very similarly to taking [[spell:1250914]] and
      [[spell:410260]]. Therefore, you could play either, depending on which you
      prefer.

Our Mythic+ build starts out with a universal talent setup that will work
      everywhere. You can move utility in your class tree around, such as moving 
      the points from [[spell:370888]] to other utility like 
      [[spell:372048]] or [[spell:371032]] if you would prefer.

**Be sure to make use of the 'Export Talents' button to import the build 
      directly into your game!**

:::talents Mythic+ Build - Chronowarden
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMzMDAM"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzYbmZmZWGMzsMjxMmBAAAAAAAAzMMzAjpGzMzAAAAgZMjxMzyYmBmZzAjZswCMwMM0ALYMzMDAM"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFZUcYYlqqXPKJbpkkIIWeEnmG:WDHaB-CVELHDWuSMNCIWOpQB+whg9lq1dmxRD-AAAA-UAQMECaYKWOIMA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander Threads Reactive Hide

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander Threads Overlord Mythic+ Build for Augmentation Evoker

This build focuses on playing [[spell:412713]] and [[spell:407866]]
      and maximising your personal damage dealt from [[spell:403631]] casts.

We play [[spell:410784]] for this build to get a slight 
      single-target DPS gain. Due to playing [[spell:410784]] you will 
      use [[spell:362969]] over [[spell:361469]] at all target counts. 
      You still need to use [[spell:361469]] to consume 
      [[spell:369939]].

Another reason we have chosen [[spell:410784]] for this build is that
      it is a lot simpler to play due to having instant cast builder as its main generator
      in all situations. You will deal approximately 2% more Single Target DPS at the
      cost of 2% less AoE compared to playing [[spell:407814]]. If you would
      rather play [[spell:407814]] then you can swap to it and move the class
      tree point in [[spell:369909]] to [[spell:376930]] or another utility point.

This build has slightly lower potential DPS compared to its 
      ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden counterpart, but has less reliance on allies
      for performance. This means it can perform better on average,
      but of course your mileage may vary.

**Be sure to make use of the 'Export Talents' button to import the build 
      directly into your game!**

:::talents Mythic+ Build - Scalecommander
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzMzyAzsNjxMmBAAAAAAAAmhHYGYM1YmZGAAAAMzMjxMz2YmBmZzYwCsMGGbDgZQshxMYmBDG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEcBAAAAAAAAAAAAAAAAAAAAAMMzMbzMzMzyAzsNjxMmBAAAAAAAAmhHYGYM1YmZGAAAAMzMjxMz2YmBmZzYwCsMGGbDgZQshxMYmBDG"
}
```
:::

:::details 来源计算器编码
```
#BX-aRRsFtZUYYlXPpcKJkkIjWeEnm:WDVV72cB-CVELHWHATMNyoQ54CQss4hD77cqWXDC-AAAA-JSCUg0wscMAIwI-
```

:::

3.

### Augmentation Evoker Rotation Changes

In Mythic+, you will be fighting against groups of enemies. Augmentation has
very few adjustments to its playstyle on AoE, which are listed below.

- You can empower [[spell:396286]] to a higher stage than Rank 1, stopping 
      when all enemies are within its AoE.
- Without the talent [[spell:407814]] you would use 
      [[spell:362969]] over [[spell:361469]] from 2t+.
- You should save [[spell:395152]] near the end of trash packs unless you 
      think there will be thirty seconds until the tank pulls and groups the next 
      enemies.
- You will want to hold [[spell:403631]] near the end of packs instead of 
      pressing it on cooldown. If you use it too close to the end of a pack you 
      will waste a lot of your Apex Talent [[spell:1259173]]'s uptime! 
      Occasionally, it can also be good to hold it for a few seconds to better line 
      it up with DPS cooldowns but this is not necessary. Right now both Hero 
      Talents get a significant boost in DPS just from using it as often as 
      possible due to the Apex Talents.

4.

### Utility Kit and Abilities

### Interrupts, Stuns, and Stops

4.1.

#### Interrupt, Stuns, Stops, and other CC

[[spell:351338]] is your interrupt ability and is always taken on the
      class tree for pathing reasons. We also take [[spell:371016]] on
      the Augmentation tree to lower the cooldown to 20 seconds.

[[spell:396286]] is one of your primary rotational damage abilities
      but it also knocks all enemies into the air. For most enemies, this stops
      their cast. Some enemies will recast after they land, but some will not; this
      is inconsistent and something you will have to learn on a mob-by-mob
      basis. You fairly often over-empower [[spell:396286]] or delay it for
      an extra few GCDs in order to cancel important spells to allow your group
      interrupts to come back off cooldown and stop the spells.

[[spell:357214]] knocks enemies away from you, which can let
      you reposition enemies or cancel their spells. The knockback will stop
      most casts. Some enemies will recast after they land, but some will not; this
      is inconsistent and something you will have to learn on a mob-by-mob
      basis.

[[spell:368970]] knocks enemies up into the air. For most
      enemies this stops their current cast. Most enemies will recast after they
      land but some will not — this is inconsistent and something you will 
      have to learn on a mob by mob basis.

[[spell:360806]] is an incredible ST CC that is on a 15-second
      cooldown. This counts as a true CC, which means it will not put you or 
      your allies in combat if you walk past the monster CC'd, making it 
      invaluable for skips; additionally, it can also be used to stop casts in a 
      pinch or to reduce the pressure of a specific pull.

[[spell:358385]] is a 90s cooldown AoE root. This is fairly
      infrequently used, but it is nice as a fallback option, especially in
      cases of disaster, such as when a tank dies.

[[spell:371032]] makes your [[spell:403631]] stun enemies
      for 3 seconds.

[[spell:372048]] is a 2-minute cooldown that increases the
      duration of crowd controls on an enemy by 50%. This is often paired with
      Vengeance DemonHunters sigils to CC monsters for a long time or with
      long-duration AoE Stuns.

[[spell:408543]] is an incredibly niche and rarely taken talent
      that allows [[spell:358385]] to stun enemies that are in mid-air. This
      is relatively difficult to land and requires you to use one of your other
      CCs, such as [[spell:396286]] or [[spell:368970]]. In most
      cases, using either of these spells would have already stopped the spell
      going off, making the follow-up stun unnecessary.

### Group Survivability Cooldowns

4.2.

#### Group Survivability Cooldowns

[[spell:409676]] gives your entire group an absorb shield based on
      the damage they deal during [[spell:403631]] up to 30% of their
      health. This can often eat a large amount of an upcoming dangerous
      ability, making your healer's life easier.

[[spell:374227]] grants you and your entire party 20% reduced damage
      taken from area of effect attacks.

[[spell:403208]] grants you and your entire party 2%
      increased maximum health.

[[spell:410643]] is a niche talent that makes
      [[spell:360827]] give a small shield to the target. This is not
      often taken due to the shield being too insignificant in most content.
      This is sometimes taken in extremely high level keys because someone in
      the group needs the small absorb to survive a mechanic.

### Support Buffs

4.3.

#### Support Buffs

[[spell:395152]] provides 8% of your primary stat to the other two
      DPS in your group while it is up.

[[spell:409311]] grants 3% increased critical strike chance to the
      players who have the buff. Additionally, players with [[spell:409311]]
      get an another approximately 3% increased damage and healing from
      [[spell:412774]]. This is typically placed on your fellow DPS as the
      effect it gives to healers is minimal.

[[spell:413984]] grants players Versatility based on your Mastery.
      This is incredible as it both contributes a lot of your damage done but
      also increases the survivability of players with [[spell:413984]]
      because Versatility grants damage reduction.

[[spell:403631]] is your primary cooldown. This effectively reads
      as your DPS do 15% more damage for 10 seconds. We mainly use this on 
      cooldown due to our Apex Talent [[spell:1259173]] being more important 
      than syncing. It can be worth holding [[spell:403631]] near the tail 
      end of pulls to not waste uptime on your [[spell:1259173]] and to 
      better sync it with DPS CDs (as they usually use them at the start of 
      pulls).

[[spell:369459]] alongside [[spell:418101]] buff your healer,
      giving them 3% increased healing and damage done.

[[spell:360827]] provides a tank with 20% of your armor. The
      amount of damage reduction this grants depends on the tank, but for most
      tanks, it is approximately 7% extra physical damage reduction.

### Other Utility

4.4.

#### Other Utility

[[spell:390386]] provides your party with a
      [[spell:80353]]/[[spell:32182]]/[[spell:2825]] effect. This is
      incredibly strong and most groups want at least one class that can provide
      this.

[[spell:365585]] is your dispel and lets you remove all Poison effects.
      This is extremely useful in Season 2 because there are a
      lot of Poisons in these dungeons. Additionally, this lets you dispel
      someone affected by [[spell:440313]] during
      [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>) weeks.

[[spell:374251]] is one of the best Evoker utility spells and
      lets you remove all Bleed, Poisons, Curses, and Diseases on a target. You
      always want this in Mythic+. Use this to remove important debilitating
      debuffs from your allies. Additionally, this lets you dispel a second
      person affected by [[spell:440313]] during
      [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>) weeks.

[[spell:406732]] gives a buff to both you and your healer,
      doubling the range of all of your spells by 100% and letting you both cast
      while moving. This is situationally useful and can make it easier for some
      healers to keep you alive during hard mechanics.

[[spell:374968]] gives everyone in your group an additional use of
      their major movement ability. This is niche, but tanks often appreciate
      the extra mobility to help them group packs quickly.

5.

### Dealing with Affixes

### Affix: Ascendant

5.1.

#### Ascendant Affix Management for Augmentation Evoker

During [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>) weeks orbs of cosmic energy will
      periodically spawn near your group. As a Augmentation Evoker, you
      can use the following spells to get rid of these orbs:

- [[spell:396286]]
- [[spell:351338]] - This is usually best used on the monsters in the
          pack not the affix.
- [[spell:368970]]
- [[spell:357214]]
- [[spell:403631]] with [[spell:371032]]. Make sure to 
          also hit the enemy mobs.

### Affix: Voidbound

5.2.

#### Voidbound Affix Management for Augmentation Evoker

When the Voidbound affix spawns, you should immediately swap targets
      to focus this down. It is not worth talenting [[spell:368432]] to help 
      kill these as it does not deal enough damage.

### Affix: Pulsar

5.3.

#### Pulsar Affix Management for Augmentation Evoker

During [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>) help your allies out by walking 
      into the pulsars that orbit them.

### Affix: Devour

5.4.

#### Devour Affix Management for Augmentation Evoker

During [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>) be prepared to use your 
      [[spell:365585]] and [[spell:374251]] to remove the debuffs from 
      your party members. It is important to note this is <em>not</em> an 
      Absorb despite looking like one and simply tracks healing dealt to the 
      target.

Healers will typically heal the mechanic off but it can be good 
      to remove them quickly with dispels if its better for DPS burst or if the 
      debuff is about to expire. If the debuff expires all nearby monsters get 
      healed which is very bad.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **15 Jun. 2026:** Updated for Patch 12.0.7. Added Overlord Build for High Keys.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **19 Mar. 2026:** Motes of Possibility has been removed from all Chronowarden Builds.
- **17 Mar. 2026:** Updated Talent Build based on nerfs.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **08 May 2025:** Updated talent builds for Patch 11.1.5 Hotfixes.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Reviewed for Patch 11.0.7
- **21 Oct. 2024:** Updated for Patch 11.0.5 changing the class talent tree.
- **04 Oct. 2024:** Update default Scalecommander M+ Build based on hotfixes.
- **09 Sep. 2024:** Update for The War Within Season 1.
- **23 Jul. 2024:** Fixed Mythic+ Talent Tree.
- **19 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4
- **19 Mar. 2024:** Reviewed for Patch 10.2.6
- **08 Mar. 2024:** Use Regenerative Chitin in the default M+ Build.
- **15 Jan. 2024:** Reviewed for patch 10.2.5
- **13 Nov. 2023:** Updated for Hotfixes
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **09 Aug. 2023:** Update Build for this weeks patch.
- **10 Jul. 2023:** Page added.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Augmentation Evoker in World of Warcraft Patch 12.1.5.

1.

### Best Macros

1.1.

#### Emerald Blossom on Mouseover

This macro will cast [[spell:355913]] on your mouseover target; if
  they are not a friendly target (or a dead friendly target), it will cast on
  yourself instead.

#### Emerald Blossom Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Emerald Blossom
```

1.2.

#### Rescue on Mouseover

This macro will cast [[spell:370665]] on your mouseover target; if
  they are not a friendly target (or a dead friendly target), it will attempt
  to cast it on your current target instead.

#### Rescue Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Rescue
```

1.3.

#### Verdant Embrace on Mouseover

This macro will cast [[spell:360995]] on your mouseover target; if
  they are not a friendly target (or a dead friendly target), it will cast on
  yourself instead.

#### Verdant Embrace Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Verdant Embrace
```

1.4.

#### Cauterizing Flame on Mouseover

This macro will cast [[spell:374251]] on your mouseover target; if
  they are not a friendly target (or a dead friendly target), it will cast on
  yourself instead.

#### Cauterizing Flame Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Cauterizing Flame
```

2.

### Specific Macros for Augmentation Evokers

2.1.

#### Prescience on Mouseover

This macro will cast [[spell:409311]] on your mouseover target; if they
  are not a friendly target (or a dead friendly target), it will use Blizzard's
  default targeting instead.

#### Prescience Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Prescience
```

2.2.

#### Blistering Scales on Mouseover

This macro will cast [[spell:360827]] on your mouseover target; if
  they are not a friendly target (or a dead friendly target), it will use
  Blizzard's default targeting instead.

#### Blistering Scales Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Blistering Scales
```

2.3.

#### Spatial Paradox on Mouseover

This macro will cast [[spell:406732]] on your mouseover target; if
  they are not a friendly target (or a dead friendly target), it will use
  Blizzard's default targeting instead.

#### Spatial Paradox Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Spatial Paradox
```

2.4.

#### Bestow Weyrnstone on Mouseover

This macro will cast [[spell:408233]] on your mouseover target; if
  they are not a friendly target (or a dead friendly target), it will use
  Blizzard's default targeting instead.

#### Bestow Weyrnstone Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Bestow Weyrnstone
```

2.5.

#### Random Favourite Mount Bronze Attunement Macro

This Macro is a replacement for your Summon Random Favourite Mount keybind 
  that will cause it to gain some additional Quality of Life. If you wish for 
  the tooltip to show a mount then add your favourite mount to the showtooltip 
  line. Additionally, if you wish for it to only summon a specific mount then 
  replace the last line with /cast mount.

This macro will automatically put you into [[spell:403265]] when 
  pressing your mount keybind and return you to [[spell:403295]] if you 
  dismount by pressing your mount keybind again.

#### Attunement Mount Macro

```wow-macro
#showtooltip 
/cast [nostance:2] Bronze Attunement
/cast [mounted,nostance:1] Black Attunement
/run C_MountJournal.SummonByID(0)
```

2.6.

#### No Stance Black Attunement Macros

This macro will automatically swap back to [[spell:403295]] if you
  are not in that stance. This specific example is for Eruption, but you can
  copy the Black attunement line into any of your other macros or change the
  spells!

This is useful because every time you use [[spell:358267]] with
  [[spell:407243]] talented, you will automatically be swapped to
  [[spell:403265]] after using [[spell:358267]].

Swapping stances is off GCD and will not interfere with your rotation and
  there is a 3-second lockout before you will be able to change back, so you
  will still get the most out of the hover movement speed bonus from Aspect's
  Favor.

This macro may potentially be annoying if you are doing old content and wish
  to be in [[spell:403265]] the entire time, but it is a nice QoL
  boost elsewhere.

#### Black Attunement Eruption

```wow-macro
#showtooltip Eruption
/cast [nostance:1] Black Attunement
/cast Eruption
```

2.7.

#### Mount Bronze Attunement Macro

This macro will automatically put you into [[spell:403265]]
  whenever you mount up giving you slightly more movement speed.
  If you dismount via the macro it will also automatically return you
  to [[spell:403295]].

This macro is setup to summon your favourited mounts, if you would like
  it to be a specific one replace the run line at the bottom with /cast
  and the specific name of that mount. You may also wish to adjust the
  showtooltip at the top of the macro so that it always shows one of
  your favourite mounts.

#### Summon Favourited Mount and Attunement Swap Macro

```wow-macro
#showtooltip
/cast [nostance:2] Bronze Attunement
/cast [mounted,nostance:1] Black Attunement
/run C_MountJournal.SummonByID(0)
```

2.8.

#### Cancelaura Tip the Scales Macro

This macro will let you immediately cancel the [[spell:370553]] buff
  to let it go on Cooldown faster. This is a DPS increase as
  a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden since the spell does not start its cooldown until
  the buff is consumed. It is significantly more important to maximise the 
  total casts of [[spell:370553]] than to get a max rank fast Empower. 
  However, you should still ideally use [[spell:370553]] on 
  [[spell:357208]] if its coming up in the next GCD.

#### Chronowarden Cancelaura Tip the Scales

```wow-macro
#showtooltip
/cast Tip the Scales
/cancelaura Tip the Scales
```

3.

### Best Addons

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

3.1.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

3.2.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

3.2.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

3.2.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

3.2.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

3.3.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

3.3.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

3.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

3.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.4.

#### Raidframe Addons

3.4.1.

##### Harreks Advanced Raid Frames

[Harreks Advanced Raid Frames](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>)
   is a highly customizable addon that improves the usability of Raid Frames. 
   This addon supports the Blizzard Frames as well as popular Raid Frame 
   addons. This Addon allows you to customise the appearance and placement of 
   your buffs on Raid Frames making it easier to see who has your buffs. If you 
   have additional questions or require assistance, you can visit Harreks 
   discord, [Spiritbloom.Pro](<https://discord.gg/spiritbloompro>).

3.4.2.

##### Xephs Spotlights

[Spotlights](<https://www.curseforge.com/wow/addons/spotlights>)
   is a new customizable addon that gives you the ability to create spotlight
   raid frames. You can freely customise the appearance of these raid frames,
   configure buffs to display per frame, and more to help with picking the
   correct targets for your buffs! If you have additional questions or
   require assistance, you can join the Evoker Discord discord,
   [Wyrmrest Temple](<https://discord.com/invite/Evoker>).

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Pre-Season.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for patch 11.2.7
- **05 Oct. 2025:** Fix a typo in a spell name.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **24 Feb. 2025:** Reviewed for Patch 11.1
- **15 Dec. 2024:** Reviewed for Patch 11.0.7
- **21 Oct. 2024:** Reviewed for Patch 11.0.5
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4
- **19 Jan. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Page added.

Show more

Show less

:::
