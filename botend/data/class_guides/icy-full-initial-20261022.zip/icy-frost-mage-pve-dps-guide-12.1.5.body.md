## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本冰霜法师指南。在这里，你将学习如何在团队副本和大秘境中扮演好一个冰霜法师：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

冰霜大秘境资源

[全新！顶尖冰霜天赋构筑](<https://raider.io/specs/frost-mage/talents>)

[顶尖冰霜大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/mage/frost>)

[冰霜大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=mage--frost>)

[热门冰霜队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=mage--frost>)

1.

### 冰霜法师概述

冰霜在限制敌人移动的同时输出稳定且可预期的伤害方面一直表现出色。鉴于你可以用大量的减速和定身技能无限风筝敌人，冰霜一直是练级和世界内容中非常强力的选择。

扎实，无短板，处处可用

冰霜手感扎实，数值调整也相当高。虽然我们在任何特定方面都不是最强的，但不必依赖冷却技能意味着我们每一波怪的输出都相当稳定。选择我们的AoE天赋并不会损失太多单体伤害，除了

[[spell:205021]]

自身的相对脆弱之外，冰霜是一个非常适合开荒未知战斗的专精。

扎实，非常适合用来熟悉战斗

该专精易上手的特点加上不俗的伤害表现，使得冰霜对大多数人来说都是一个稳妥的选择。

很可能进入主流

选择AoE天赋带来的单体伤害损失极小，加上该专精相对容易上手，以及我们带来的极强功能性，意味着我们几乎总是被大秘境队伍所欢迎。

法师依然是功能性的神

我们是法师。减速、定身、群体打断，

[[spell:414664]]

、单体驱散，

[[spell:475]]

，比通常更短的施法者打断，打断某些跳跃小怪的能力，诸如此类，不胜枚举。你想到的，我们都有。法师整体而言被带入大秘境靠的就是我们的功能性。这就是为什么即使我们的DPS不是最高的，我们依然保持在主流阵容中。

脆皮

防御性调整对法师的打击尤为沉重。12.1版本为我们带来了以下削弱

[[spell:11426]]

和

[[spell:1244090]]

。法师在最高水平的对局中生存存在问题，但在秘钥+称号范围之外的一切内容中都是完全可用的。

冰霜新星还在，但是……

冰霜拥有相当数量的瞬发法术，尽管大多数都是在冷却时使用的。我们的主要冷却技能，

[[spell:205021]]

完全没有移动保护功能，如果任何机制砸到你头上，实际上就浪费了我们的主要冷却技能。虽然

[[spell:212653]]

存在，但冷却时间的增加意味着你实际上会为了冰霜射线的施放而保留它，以防万一。同样，我们的AOE现在主要是硬读条，而不是之前的瞬发连发。

1.

### 冰霜 法师在至暗之夜

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5补丁是一个赛季中期的更新补丁。包含一个全新的单Boss团本——基斯伊克斯的解放，以及地下城系统的升级——金多占迷宫！请务必查看我们关于这些新遭遇战的页面！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

除了团本和迷宫之外，还有一些新的有趣内容可以体验、追赶装备的途径以及装等提升。请通过我们的12.1.5补丁概览查看补丁的其余内容。

2.3.

#### 职业改动

该补丁还带来了大量针对长期存在的12.0漏洞的修复，这些漏洞冰霜不得不应对或从中受益，但机制上没有真正的改变。

此外，你应该查看我们的
[装备](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>) 页面，因为新团本带来了新装备，而[[item:280562]]将升级你的一些装备。

- [[spell:56377]]现在与[[spell:116]]配合正常，包括顺劈范围、伤害变化和英雄天赋切换。
- [[spell:56377]]现在与[[spell:431166]]配合正常，允许主要目标与次要目标一同爆炸。
- [[spell:112965]]和[[spell:1247729]]对飞行中的[[spell:30455]]的状态，在对抗拥有巨大碰撞箱的Boss或在极高急速下不再失效。
- 如果你连续施放两个[[spell:205021]]，[[spell:1247544]]不再失效。
- [[spell:431166]]的漏洞已被写入技能说明而非更改，也就是说，它将触发几率从25%提升至26.5%，这是有意为之的。
- [[spell:443783]]现在可以在冷却管理器中追踪。
- [[spell:443783]]不再在战斗开始时重置，允许你用[[spell:205021]]开怪。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostbolt02.jpg>) 点击查看上赛季第二赛季的改动
- **12.1上线**
  
  
  
  
  - [[spell:1244090]]已被调整为持续治疗，而非一次性治疗。
  - [[spell:11426]]的强度降低了约16%。
  - [[spell:1244110]]现在为[[spell:414659]]提供30秒的冷却缩减。
  - [[spell:1297073]]是一个新的职业天赋，为我们提供4%的AOE伤害减免。
  - [[spell:56377]]和[[spell:378448]]已被削弱。
  - [[spell:1262981]]的伤害增益已被削弱，作为交换，我们获得了全局伤害的增强。
- **8月25日热修**
  
  
  
  
  - [[spell:11426]]恢复至12.1之前的数值。
  - [[spell:190356]]伤害提高10%。
  - [[spell:1248825]]范围伤害提高10%。
  - [[spell:431095]]伤害提高25%。
- **9月1日热修复**
  
  
  
  
  - 所有伤害提高6%。
- **9月22日热修**
  
  
  
  
  - [[spell:84714]]增强15%。
  - [[spell:1247777]]增强50%。
  - [[spell:1248825]]范围伤害提高10%。
  - [[spell:378947]]伤害提高50%。

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜中冰霜 法师的改动

至暗之夜来了，而冰霜经历了彻底的重做。抛开你所知道的关于这个专精的一切，这是该专精在游戏历史上所经历的最大规模的改动。

主要组成部分是[[spell:1246769]]从暴击加成变为施加在敌人身上的可叠加减益效果，由[[spell:30455]]消耗。概念上是相同的，即碎裂是对法术的增益，但被拆分为独立的伤害部分。因此，冻结状态不再影响我们的DPS。

2.4.1.

##### 顶点天赋

巅峰天赋是你在升级过程中解锁的一个独特节点。你可以选择将升级获得的天赋点投入其中，考虑到其相对强度，你很可能应该这么做。对于冰霜法师，我们获得[[spell:1262935]][[spell:1262981]]和[[spell:1263249]]，增加了冻结粉碎的额外动力，显著提升了[[spell:205021]]的威力，以及冰霜射线的第二层充能，让我们在使用方式上更加灵活。

2.4.2.

##### 英雄天赋改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师的碎裂已削减为仅造成冲击伤害，旧的风暴机制改为随机触发，因为它们不再是目标身上的可叠加减益效果。天赋树被动增益的改动使其与[[spell:1246769]]机制整合。[[spell:444986]]仍然被削弱，且随着第3赛季套装加成的移除，[[spell:84714]]的刷新变得极为罕见。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火失去了[[spell:438595]]和[[spell:438600]]增益，转而更专注于核心法术的强化。值得注意的是，[[spell:44614]]获得了新动画并变为霜火，[[spell:199786]]在命中时爆炸，而地心之战第3赛季的套装加成成为了新的英雄天赋。

2.4.3.

##### 循环要点

新专精的大致思路是使用[[spell:116]]和[[spell:44614]]在目标身上叠加[[spell:1246769]]，然后用[[spell:30455]]消耗它们。随机触发带来更多层数，以及想要将层数保持在特定阈值以下，使情况变得复杂。

[[spell:199786]]和[[spell:1247777]]已作为独立法术被移除，取而代之的是在可用时分别转化你的[[spell:116]]和[[spell:205021]]。

2.4.4.

##### 冷却调整

[[spell:12472]]已被移除，我们的主要冷却技能现在是[[spell:205021]]。

随着[[spell:108839]]的移除，以及[[spell:205021]]在开始施法时就进入冷却，这是一次极为脆弱的施法。任何形式的击退、打断，甚至脚下掉落的火焰，都意味着你唯一冷却技能的损失。虽然[[spell:212653]]仍然存在，但其冷却时间已增加，且只能应对其中一种情况。因此，冰霜射线需要你密切关注每一个交战中的小怪的机制，以免施法被打断。

2.4.5.

##### AOE伤害输出

遗憾的是，来自[[spell:190356]]的[[spell:84714]]冷却缩减已被移除。这意味着我们不能再在AOE期间始终依赖瞬发暴风雪，而必须硬读条施放。这也意味着寒冰宝珠不是每次拉怪都能使用的技能。

[[spell:1247777]]现在的冷却时间也翻倍了，因为它现在与施放[[spell:205021]]相关联。

[[spell:417493]]也被移除了，剥夺了我们的AOE爆发潜力。取而代之的是[[spell:1247090]]，但就目前的调整以及无法利用多目标冻结层数而言，它不太可能在任何情况下被选中。

相反，[[spell:1248825]]为[[spell:1246769]]添加了AOE部分，而[[spell:1247775]]在带有碎裂层数的怪物提前死亡时造成相同的伤害。这意味着我们的AOE在功能上就是我们的单体循环，外加在冷却时施放一个[[spell:190356]]。[[spell:1247777]]现在每次彗星冲击都会碎裂层数，至少 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火会尝试在彗星风暴之间尽可能多地叠加被动AOE冻结层数。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 然而，疾咒师与[[spell:30455]]挂钩，并会尝试在两者之间尽可能多地进行冻结粉碎。

2.4.6.

##### 防御改动

现有法术的移除和调整内容需点击展开查看：

:::details ► **点击展开**
- [[spell:55342]]不再提供伤害减免，分身的持续时间已缩短至15秒。
- [[spell:110959]]同样不再提供伤害减免。
- [[spell:11426]]的冷却时间已增加，但其公共冷却时间已缩短。
- [[spell:414660]]已被完全移除。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师的[[spell:444827]]已被削弱至一半效果，由于[[spell:55342]]的改动，[[spell:444784]]现在完全无用。

:::

新增了[[spell:1244090]]，当你的生命值降至24%且[[spell:342245]]不在冷却中时，它会立即为你恢复最大生命值的50%。这非常强大，但确实会占用你实际使用操控时间的机会。对于普通玩家而言，这是更好的选择，因为它总能比平均情况更好地利用操控时间。

[[spell:1244110]]是与[[spell:235219]]的选择节点。为我们唯一的真正主动防御法术提供第二层充能非常强大。虽然寒冰屏障会有小众用途，但由于冷却时间与其他法术同时运行，会有一种不想在仅仅[[spell:11426]]上“浪费”寒冰屏障的心理因素。冰川壁垒则绕开了这一点，代价是顺序冷却计时。这很可能是所有人的首选。

2.4.7.

##### 功能性和移动性改动

我们失去了一大部分功能性和移动性。重点如下：

:::details ► **点击展开**
- [[spell:157981]]已被移除。
- [[spell:108839]]已被移除。
- [[spell:382826]]已被移除。
- [[spell:212653]]的冷却时间已增加，第二层充能被拆分到不同的天赋中。
- [[spell:1953]]通过上述天赋获得第二层充能。
- [[spell:387807]]已改为固定的5秒冷却缩减，而不是每次我们[[spell:30455]]时递增。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 随着[[spell:157981]]的移除，霜火的功能性节点几乎完全无用。

:::

1.

### 冰霜 法师玩法基础

冰霜的核心在于生成和消耗[[spell:1246769]]，并利用你的触发效果。其玩法非常简单易懂。

你所做的一切都围绕着[[spell:1246769]]。你武器库中几乎每个法术都会在目标身上产生层数，然后可以通过[[spell:30455]]消耗以获得额外伤害。你的两个触发效果是[[spell:190447]]，它允许使用一个高伤害法术为目标增加大量层数，以及[[spell:112965]]，它让你的冰枪术造成最大量的额外伤害，而不实际消耗那些层数。

为了让你快速了解冰霜 法师的核心内容，下面的要点列表将简要描述其主要焦点。

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_freezing.jpg>) **优化冻结的使用**
  
  
  
  
  冰霜的大部分伤害来自[[spell:1246769]]，但几乎不可能完全不浪费任何一层。相反，尽量减少浪费是核心原则之一。另一方面，[[spell:1247729]]可能在层数较低时触发，花点时间快速考虑是否能在热能真空增益结束前再叠加几层以填满它可能是值得的。请记住，其持续时间比[[spell:205021]]的施法时间更长，你完全可以在射线之前施放[[spell:44614]]，之后仍然享受热能真空的加成。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_wintersgrasp.jpg>) **尽量减少触发和冷却的浪费**
  
  
  
  
  快速使用[[spell:112965]]和[[spell:190447]]意味着你最大限度地降低了溢出它们的几率。同样，[[spell:84714]]和[[spell:199786]]在出现时具有相当高的优先级，对它们可用做出反应非常重要。确保你没有囤积2层满的[[spell:205021]]。虽然这听起来很容易，但这个专精很容易让你资源过剩，导致你错过即将到来的东西，或陷入冷却时间没有在运行的境地。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostblast.jpg>) **始终施法**
  
  
  
  
  次优的操作，比如层数不足的[[spell:30455]]，也比移动时什么都不做要好。确保你的公共冷却时间一直在转。我们有大量的瞬发伤害法术，或者你可以在移动时[[spell:11426]]，仅仅为了在移动期间做点其他有用的事。

1.

### 作为冰霜 法师如何获取装备

虽然我们始终建议你自行模拟以获得最佳结果，但我们确实提供了专门的冰霜配装页面。我们目前提供了第2赛季装备的推荐，以便在至暗之夜终局内容发布时有一个良好的开端。一旦你获得了一些装备，你就需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对12.1.5补丁更新，包含新的饰品和毒石优先级。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 已针对12.1.5更新。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已更新第二赛季饰品梯队列表，BiS列表。
- **2026年8月10日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对12.1补丁更新，包含初步BiS列表。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 起手调整。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对12.1更新。
- **2026年8月10日（本页）：** 已针对12.1更新。
- **2026年6月15日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新，包含腐肉沼泽掉落。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7更新，对霜火进行了小幅调整。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对12.0.7更新，新增了Omnium Folio推荐，应请求新增了一套轻度顺劈/团本天赋。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月21日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 新增了关于暴击与精通附魔/消耗品的常见问题解答。
- **2026年4月20日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 迅捷茶在副本中不再生效。
- **2026年3月22日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 新增投弹手单体起手式。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 添加了指向我们通用升级指南和传家宝说明的链接。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 添加了ArcUI和一个导入代码。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 将采集茶加入消耗品列表。重新添加了三级属性附魔对比。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于至暗之夜第1赛季套装的说明。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月9日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 修复了解除诅咒的鼠标悬停宏。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 为回归玩家添加了80级天赋导入字符串。
- **2026年2月28日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 戒指附魔和药水推荐已更改。
- **2026年2月28日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 措辞调整，并添加了在双目标时仍使用单体的说明。
- **2026年2月28日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 对简介进行了细微调整。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 更多优先级变更。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（本页）：** 已针对至暗之夜发布更新。
- **2026年2月11日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 再次更新了优先级，补丁期间理论计算变化很快。
- **2026年2月10日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了优先级，添加了关于投弹手的冰冻在单体目标上使用的常见问题。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026 年 1 月 20 日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 修正了错别字，一键现在会使用 冰霜 的冷却技能了。
- **2026年1月19日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 已针对至暗之夜前夕进行审查。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 为11.2.7版本进行了审查，并添加了常见问题解答组件。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 更新并添加了一个关于Cartel Chips的章节，毕业装备列表中的物品等级已提高。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025 年 8 月 23 日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 添加了饰品排行榜，并对毕业装备列表进行了细微调整。
- **2025 年 8 月 23 日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 添加了第3赛季提示。
- **2025 年 8 月 23 日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 弹幕射手在单体目标时再次施放彗星风暴，奥术涌动受到限制。
- **2025年8月6日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 修正了制造装备部分推荐披风而非护腕的问题。
- **2025 年 8 月 4 日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 针对11.2进行了审阅。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 最后时刻的APL改动，略微简化了输出循环。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 充能箭矢被削弱。
- **2025年6月15日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 已为 11.1.7 进行审查。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 为11.1.7补丁更新。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已用新的探底腰带更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 新增了11.1.7战斗助手章节。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 更新了关于11.1.7战斗助手的想法。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年4月21日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 已针对11.1.5进行审查。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 更新了毕业装备列表中的饰品，添加了谜之财团芯片部分。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 针对11.1.5的腐蚀附魔进行了更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 对措辞和哪个英雄天赋更好进行了微调。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月21日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 添加了赛尔希的替换说明，套装修复。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 已为加里维克斯更新，并对其他提示进行了一些小调整。
- **2025年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 加入了第2赛季地下城提示。
- **2025年3月2日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 修复了霜火范围输出与过量火焰的逻辑问题。
- **2025年2月28日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 更新了总体毕业装备列表。
- **2025年2月28日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 对霜火的冰枪术逻辑进行了微调，并更新了投弹者的DC范围限制。
- **2025年2月24日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 针对11.1.0进行了审查。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 针对11.1进行了更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 赛尔西的王冠在上线时获得大幅增强。
- **2024年12月15日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 为11.0.7进行了审阅。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 为11.0.7进行了审阅。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 针对11.0.7和Cyrce's Circlet进行了更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 为11.0.7进行了审阅。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 为11.0.7进行了审阅。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 为11.0.7进行了审阅。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 为11.0.7进行了审阅。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已更新为包含两种英雄天赋选项的标准冰霜和弹幕射手变体输出循环。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已更新Boltslinger和标准天赋选项建议。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 为11.0.7进行了审阅。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 为11.0.7更新。
- **2024年12月15日（本页）：** 为11.0.7更新。
- **2024年10月27日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 针对11.0.5更新了新的理论。
- **2024年10月27日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 针对11.0.5更新了新的理论。
- **2024年10月27日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5更新了新的理论。
- **2024年10月27日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 针对11.0.5更新了新的理论。
- **2024年10月27日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 针对11.0.5更新了新的理论。
- **2024年10月22日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 新增了第一赛季地下城提示，包含我们可以用实用施法应对的内容。
- **2024年10月22日（本页）：** 已更新至11.0.5版本。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 添加了Ansurek的提示，并对其他内容进行了更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已更新至11.0.5版本。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已更新至11.0.5版本。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 添加了标志性法术。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月7日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 措辞上的小改动。
- **2024年9月9日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 页面已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月27日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 从AOE循环中移除了GS，以获得小幅收益。
- **2024年8月21日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月30日（[外观](<https://www.icy-veins.com/wow/frost-mage-cosmetics>)):** 页面已添加。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/frost-mage-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/frost-mage-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/frost-mage-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 为第4赛季进行了更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已为 10.2.6 补丁更新，在所有情况下都改回微温全能药水。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 为10.2.6补丁进行了复查，对热修复中遗漏的细节进行了小幅修正。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2024年1月14日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 冰川尖刺现在无论冰冷血脉状态如何，都不配合冰枪施放。
- **2023年12月12日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 对冰霜射线和寒冰宝珠的说明作了小幅澄清。
- **2023年11月12日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 为第3赛季添加了毕业装备列表和刷取列表。
- **2023年11月12日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 移除了3.2节中过时的段落，并根据10.1.5的改动，用更深入的触发使用分析取而代之。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 孢子披风已被削弱。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 针对 10.2 的部分更新。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已更新10.2的消耗品和新的头部附魔。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 为10.2版本进行了审查。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于T31对双目标DPS影响的信息。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 为10.2版本进行了审查。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 为10.2版本进行了审查。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 为10.2版本进行了审查。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月8日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 修改了饰品部分的措辞
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对10.1.7补丁更新
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对10.1.7补丁更新
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对10.1.7补丁更新
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 已针对10.1.7补丁更新
- **2023年8月11日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 幻能涌动应该在冰冷血脉期间使用，一旦火焰之息/寒冰宝珠/冰霜之球进入冷却。
- **2023年8月1日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 添加了在冰冷血脉期间没有寒霜指触发时施放寒冰长矛的缺失循环部分。
- **2023年7月18日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 制作了一份详细的循环指南，作为更通用的理论补充，解释为什么技能要按特定方式使用。
- **2023年7月15日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 零下严寒已被大幅削弱，在大多数大秘境配置中不值得点出。
- **2023年7月11日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对10.1.5补丁更新，包含套装/专业插槽建议，并注明永恒黎明的装备尚未经过测试。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 针对10.1.5更新，加入了新的药剂和武器符文建议。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已针对10.1.5补丁的循环和天赋改动进行更新。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁的循环改动进行更新。随着未来几个月理论研究的深入，可能会有进一步的改动。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已针对10.1.5补丁的重大改版进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对10.1.5补丁的改动进行更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 为补丁10.1.5更新了全新的天赋树。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月11日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 重新添加了Bloodmallet图表。
- **2023年5月7日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已更新至第2赛季开始，并在流石削弱后提供了饰品建议。
- **2023年5月7日（本页）：** 已针对第2赛季开始进行更新。待办事项列表已缩减至大秘境机制的应对。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 添加了第2赛季升级系统、第2赛季实用物品以及推荐的纹章。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 添加了新的腰带附魔。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已针对巨龙时代第2赛季更新，并新增了一个关于我们可以轻松应对的词缀章节。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 为AoE循环方案新增了开关选项。减少寒冰箭的方案差距已缩小至1.7%。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 更新了荣誉天赋，并移除了一些存在Bug的互动说明。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 为10.1补丁进行了复查。
- **2023年5月1日（本页）：** 已针对10.1补丁更新，并新增了指南更新章节和即将更新章节。
- **2023年4月29日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 移除了ElvUI，为受难者新增了鼠标指向驱散。
- **2023年3月23日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 熔玉项圈不再造成DPS损失。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 因热修改动，更新了原初石章节的新推荐。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/frost-mage-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 新增了关于熔玉项圈的说明。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 添加了关于原初之石的信息。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 更改了默认天赋树。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 新增了关于减少寒冰箭循环方案的说明。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 更新了默认天赋树。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已针对10.0.7补丁进行审核。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月10日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 更新了药水选择，并新增了符文选择。
- **2022年12月22日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 因热修增强，将默认构筑改为孤独之冬。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季开始更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季开始更新，武器附魔和食物选择有变动。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 添加了关于孤寂寒冬/水元素选择的说明。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了有/没有冰霜呼唤者时的暴风雪目标值。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月24日（[升级](<https://www.icy-veins.com/wow/frost-mage-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/frost-mage-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/frost-mage-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/frost-mage-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[装备页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[属性页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[统御圣所页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[大秘境页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[循环页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[天赋页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[法术页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月10日（[9.2版本分析](<https://www.icy-veins.com/wow/frost-mage-patch-9-2-changes-analysis>)):** 已更新最后时刻的暴风雪/冰霜之球削弱。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/frost-mage-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/frost-mage-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/frost-mage-patch-9-1-changes-analysis>)):** 已针对9.1补丁正式上线更新措辞。
- **2021年4月25日（[9.1 补丁分析](<https://www.icy-veins.com/wow/frost-mage-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月13日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-the-eternal-palace-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2019年9月4日（[永恒宫殿页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-the-eternal-palace-raid-guide>)):** 新增了关于冰川尖刺在扎库尔不会杀死近战的说明，以及其他地方的小提示。
- **2019年7月20日（[永恒宫殿页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-the-eternal-palace-raid-guide>)):** 更新了提示。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月12日（[风暴熔渣页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-crucible-of-storms-raid-guide>)):** 更新了提示和配装建议。
- **2019年4月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年1月29日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了提示，涵盖热修改动和实际经验两方面。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为冰霜法师添加了达萨罗之战指南。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年10月16日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** 在实际打过团本后更新了几项天赋建议。
- **2018年9月1日（[奥杜尔页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-uldir-raid-guide>)):** 添加了奥杜尔攻略。

显示更多

显示更少

:::

## 练级

在本页，你将找到我们的逐级冰霜法师练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[法师升级指南](<https://www.icy-veins.com/wow/mage-leveling-guide>).

1.

### 冰霜 法师 练级指南：至暗之夜

冰霜法师能够风筝几乎所有东西，可以有效地风筝并一次性击杀大量怪物。即使你希望放慢节奏、一次只打一个怪物，我们几乎所有技能都带有被动减速这一事实意味着我们在户外内容中几乎不会受到伤害。

如果你觉得自己胆大包天，冰霜拥有出色的工具组，可以在相对早期就拉取多个怪物并毫发无损地存活下来。如果你要拉一个不会很快死掉的怪，务必保持[[spell:11426]]激活。记住你在1级就有[[spell:66]]，当你惹上麻烦时可以快速逃脱。

在低等级游玩冰霜有两种思路。第一种是稳妥游玩，[[spell:116]]对命中的任何目标提供沉重的减速。你很少会受到伤害，尽管你被限制为一次只能安全地拉一个怪物。第二种则将谨慎抛在脑后，狂按[[spell:1449]]，因为它造成的伤害与寒冰箭相同，但没有施法时间且是AOE。缺点是由于此技能的近战性质你会受到伤害，但如果你一次拉多个，你会明显更快地击杀。你还必须恢复法力，因为奥术爆炸每次施放消耗你总法力的10%。使用传家宝时这更可行，因为与你从标准升级任务中获得的装备相比，你拥有显著更高的智力。

1.1.

#### 升级装备选择

升级时，你应该始终选择物品等级最高的那件战利品。

使用传家宝物品时，推荐会根据你是否拥有某些较旧的专属物品而略有不同。如果你运气好拥有[[item:105690]]，那么该属性组合就是你能获得的最佳潜力。否则，[[item:122353]]是合适的。尽量专注于带有精通或暴击的装备，但在升级过程中不必过于担心是否“最优”。

1.2.

#### 至暗之夜中实用的升级消耗品

在野外时，速度几乎总是最有用的消耗品属性。点对点的移动始终会占据你大部分的时间，而在地面上拾取怪物的时间更是如此。

[[item:132516]]在功能上是一种移动速度药水，能让你以极快的速度向前推进。储备一些是非常棒的，因为它们没有等级要求，可以让你极快地穿过任务区域。之后你还可以[[spell:66]]，并摆脱沿途可能拉到的所有仇恨。

[[item:109076]]是跳跃悬崖的好帮手，尤其是在你无法骑乘的区域，例如洞穴内部。

[[item:225592]]或等效的低等级速度食物是一个不错的加成，尽管死亡后会消失，而且效果相当小。

[[item:191348]]是一种速度药水，与上述食物搭配使用，同样，这在高等级时只是一个不错的加成，那时速度药水才真正变得有意义。

实际上，如果你储备了足够的[[item:132516]]，如果你真的想优化升级所花费的时间，那大概就是你唯一需要在意的事情了。

1.

### 升级天赋

你可以按照 暴风雪 的“新手构建”进行，因为那似乎是一套相当不错的天赋树，拥有健康的开放世界伤害和一定的AoE能力的混合搭配。不过，它向你呈现天赋的顺序可能存在问题。本指南将遵循略有不同的路径，但请随意尝试。你可以在非战斗状态下随时更改天赋，只要你不尝试取消当前正在冷却中的天赋即可。你随时都可以通过在天赋界面的构建下拉菜单中选择它来返回引导式新手构建。

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 冰霜 80级 至暗之夜 升级
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmNmZmYmxMzMzMziZmZMmZmlZamZZWAAAgFAAAAAAYBgttxMzMY2mxYGbbAAAgZGMgBAGGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmNmZmYmxMzMzMziZmZMmZmlZamZZWAAAgFAAAAAAYBgttxMzMY2mxYGbbAAAgZGMgBAGGA"
}
```
:::

:::details 来源计算器编码
```
#AB-SdXWErssYaOmlMFFtFCBB+pcQIwrAFQ7SFB-JFgDHWUoyI0QEMB4g0lRHHnW1DGm1vR-AAAA-UYckgAohZJgQxA-
```

:::

2.1.

#### 升级用战争模式天赋

在本章节中，我们将对最适合升级以及进行单人/小队PvE内容的PvP天赋进行排名。

1. [[spell:390612]]很可能是战争模式天赋中最好的DPS天赋。
2. [[spell:198148]]使[[spell:84714]]的伤害提高10%，并允许将其放置在光标位置。你将失去其追踪目标的能力，但DPS的提升是值得的交换。
3. [[spell:389794]]让你获得一个造成少量伤害的范围眩晕。

其余天赋在PvE内容中对于提升你在开放世界的伤害作用有限，但如果你想要防御性加成，它们在某些情况下可能有用。

1.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

3.1.

#### 单体目标

1. **等级 29 起：**[[spell:205021]]
2. **等级 21 起：**[[spell:44614]]
3. **等级 23 起：**[[spell:84714]]
4. **等级 11–12：**当目标身上至少有4层冻结时使用[[spell:30455]]
5. **等级 13 起：**当目标身上至少有4层冻结或你拥有[[spell:112965]]时使用[[spell:30455]]
6. **等级 1 起：**[[spell:116]]

3.2.

#### 多目标

1. **等级 1–5：**哭吧，然后尝试在你拉到的所有目标之间切换施放[[spell:116]]，以便你能尽量保持距离。在6级之前尝试AoE通常是个坏主意。
2. **等级 23 起：**[[spell:84714]]
3. **等级 15 起：**[[spell:190356]]
4. **等级 6–14：**[[spell:1449]]
5.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 添加了指向我们通用升级指南和传家宝说明的链接。
- **2026年3月2日：** 为回归玩家添加了80级天赋导入字符串。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为11.0.7进行了审阅。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 已针对10.1.7补丁更新
- **2023年7月18日：** 制作了一份详细的循环指南，作为更通用的理论补充，解释为什么技能要按特定方式使用。
- **2023 年 7 月 11 日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页，我们解释如何在《魔兽世界》12.1.5 补丁中轻松游玩 冰霜 法师，使用最简单的输出循环、天赋树、属性优先级、装备配置等，而不牺牲性能。

1.

### 冰霜法师基础篇

本章节适用于对游戏或职业不熟悉的玩家，没有打史诗难度团本的打算，或者只是想以更直接的方式进行游戏，而不会被为实现最优操作所需考虑的众多优先级和主动技能所淹没。

本章节将尝试以更易消化的方式重述指南的其余部分，因为其中实际上很少有可以简化的空间。话虽如此，如果你觉得某些主动天赋难以使用，尽管将其洗掉。把你所能做到的事情做好，几乎总是胜过拙劣地使用最优构筑。

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_freezing.jpg>) **优化冻结的使用**
  
  
  
  
  冰霜的大部分伤害来自[[spell:1246769]]，但几乎不可能完全不浪费任何一层。相反，尽量减少浪费是核心原则之一。另一方面，[[spell:1247729]]可能在层数较低时触发，花点时间快速考虑是否能在热能真空增益结束前再叠加几层以填满它可能是值得的。请记住，其持续时间比[[spell:205021]]的施法时间更长，你完全可以在射线之前施放[[spell:44614]]，之后仍然享受热能真空的加成。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_wintersgrasp.jpg>) **尽量减少触发和冷却的浪费**
  
  
  
  
  快速使用[[spell:112965]]和[[spell:190447]]意味着你最大限度地降低了溢出它们的几率。同样，[[spell:84714]]和[[spell:199786]]在出现时具有相当高的优先级，对它们可用做出反应非常重要。确保你没有囤积2层满的[[spell:205021]]。虽然这听起来很容易，但这个专精很容易让你资源过剩，导致你错过即将到来的东西，或陷入冷却时间没有在运行的境地。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostblast.jpg>) **始终施法**
  
  
  
  
  次优的操作，比如层数不足的[[spell:30455]]，也比移动时什么都不做要好。确保你的公共冷却时间一直在转。我们有大量的瞬发伤害法术，或者你可以在移动时[[spell:11426]]，仅仅为了在移动期间做点其他有用的事。

1.

### 至暗之夜中冰霜法师新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火单体天赋

2.1.

#### 新手单体目标天赋方案：冰霜 法师

此构筑在纯单体目标情况下是最优的。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmxMjZMziZmZmxMzsMTzMLzCAAAsAAAbAAAgNA22GzMzALzYMjtFAAAwMDmBGwADA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVWWXdFXWYa4EFNltFOiikoABp59BGIUcgL-JgKCHWoqw04c1JMVCY8gBG23ILiccaP-AAAA-CIUkooZw4ABDwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火AOE天赋

2.2.

#### 冰霜法师新手大秘境/地下堡天赋

这是我们推荐的AoE场景构筑。它在团本的AoE战斗中表现良好，也适用于大多数大秘境和地下堡。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZbWAAAgFAAAAAAYBgttxMzMY2mxMzYbBAAAMzgZgBMDwA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqw4IM5ioB4wYXAHn2TlIJkVMsvRb--UYckgEYIgQRDzC-
```

:::

### 冰霜法师基础循环

2.3.

#### 新手冰霜法师循环

目标是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火 冰霜 法师 的目标是尽可能多地触发 [[spell:190447]]，这样你就能施放更多的 [[spell:44614]]。

1. 卡冷却时间施放[[spell:44614]]。
2. 当[[spell:199786]]亮起并将你的[[spell:431044]]按钮变为它时施放。
3. 可用时施放[[spell:84714]]。
4. 在冻结层数达到10层或更多时施放[[spell:30455]]，或者在触发[[spell:112965]]时随时施放。
5. 施放[[spell:205021]]及其随之而来的[[spell:1247777]]。
6. 作为填充技能施放[[spell:431044]]。

2.4.

#### AOE循环

实际上，唯一加入我们AoE循环的就是卡冷却时间施放[[spell:190356]]。与单体目标相比，优先级列表有一些细微调整，但仍然非常简单。

1. 施放[[spell:205021]]及其产生的[[spell:1247777]]。
2. 施放[[spell:84714]]
3. 当[[spell:199786]]亮起并将你的[[spell:431044]]按钮变为它时施放。
4. 如果可用，施放[[spell:44614]]。
5. 施放[[spell:190356]]。
6. 如果你有[[spell:112965]]可用，或者目标身上有超过10层冻结，则施放[[spell:30455]]。
7. 施放[[spell:431044]]。

2.4.1.

##### 巅峰天赋： ![Hand of Frost Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostbolt.jpg>) 寒冰之手

巅峰天赋对我们的循环没有影响，只是让我们有更多机会使用[[spell:205021]]从而更多地使用[[spell:1247777]]。尽管疯狂使用吧！

2.4.2.

##### 第2赛季套装

第2赛季的至暗之夜套装加成对输出循环没有影响（除了总体上施放更多[[spell:199786]]）。只需以获取它为目标，享受免费伤害即可。

### 冰霜 法师防御法术

2.5.

#### 冰霜 法师的防御法术

[[spell:11426]] 是你的核心技能。它的冷却时间很短，能为你提供30%的生命值缓冲。永远不要害怕按下这个按钮；由于冷却时间短，它几乎总会为你准备就绪。它能救你的命，远超你的想象。

[[spell:45438]]及其替代天赋选项[[spell:414659]]都是我们最强的单体防御技能。寒冰屏障是一个完全免疫，这意味着在它持续期间你不会受到伤害，除了极少数能穿透免疫的特殊攻击。它还会清除你身上几乎所有的减益效果，对于逃脱机制非常强大。而寒冰屏障则让你可以继续移动和攻击，代价是持续时间较短且不是完全免疫，尽管它仍然是游戏中最强的防御技能之一。

[[spell:110959]]是一个很好的应对技能，当你即将受到一次高额单体伤害时使用，它可以让怪物在施法时丢失目标。这可以打断许多机制；如果你不确定，就试试看。

对于新手来说，永远不要使用[[spell:342245]]，而是要大量依赖[[spell:1244090]]。

### 冰霜法师属性优先级

2.6.

#### 冰霜 法师属性优先级

你应该模拟自己的角色以获取属性权重，但一个不错的参考标准如下。有关本页所呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>).

智力

精通

暴击

急速

全能

重要的是要理解，这并不意味着你应该堆叠你最强的属性而忽视其他所有属性。这只是一套属性分布大致正常的平均装备的近似值。在几乎所有情况下，物品等级都会胜出。要确定某件装备是否肯定是升级，模拟是唯一的方法。

### 暴风雪战斗助手

2.7.

#### 法师 冰霜 战斗助手

战斗助手告诉你接下来该按什么，当你刚开始时并不是一个糟糕的选择。你将面临约10%的DPS损失，在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师.

在地下城内容中，它开始表现不佳，在范围伤害上又差了10%。对于一个副角色，以及对于学习这个专精的玩法来说，这并不是一个太糟糕的惩罚。

一键战斗惩罚会让这个惩罚再增加约10%，在AOE战斗中总共损失约30%，在单体目标中损失20%。正确学习专精的表现总会明显更好，无论哪个专精都是如此，但对于新手来说这可能是一个非常可用的选项。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已针对12.1更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 更新了关于11.1.7战斗助手的想法。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为11.0.7更新。
- **2024年10月27日：** 针对11.0.5更新了新的理论。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为补丁10.1.5更新了全新的天赋树。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到魔兽世界12.1.5版本中你的冰霜法师的最佳天赋。我们还提供了适用于各种内容类型的默认天赋配置，例如团队副本或大秘境。如果你开启了战争模式，我们也为你提供了PvP天赋的选择。

1.

### 冰霜 法师 最佳 至暗之夜 天赋

冰霜 法师 在 至暗之夜 第2赛季的大多数场景中拥有极强的机动性，因为你的大部分施法都是瞬发的。然而，在 [[spell:205021]] 施放时它较为脆弱。这似乎是以拥有非常平庸的防御手段以及略显重复的玩法为代价的。

鉴于我们的巅峰天赋为[[spell:205021]]提供第二层充能，而且我们没有传统的爆发性伤害冷却技能，该专精在何时使用你的爆发方面非常灵活。这使你可以留一层充能用于伤害加成场合，无论是应对首领机制还是配合饰品冷却。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师是低目标数量时的首选， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火在地下城类内容中略占优势。天赋变化很小，主要选择是你希望拥有多少顺劈。

冰霜的AoE很独特，它在目标数量非常高之前不会施放我们的主要AoE技能[[spell:190356]]。它转而依赖在专注于主要目标时的顺劈伤害。虽然这是一个令人遗憾的、基于数值调整的问题，但它确实使该专精非常容易上手，新玩家也能轻松掌握，并且无需记住在单体目标和AoE之间切换循环的目标数量，具有灵活性。

**快速开始导入代码：**

:::talents 冰霜单体
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZMziZmZmZMDAAAMzMzyyMTbAAAAAAwGAbbjZmZwsNPgxMsAAAwMbAzADYGMMA"
}
```
:::

:::talents 冰霜光束/团队
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbbMzMDmthxMsAAAwMbAzADYGMMA"
}
```
:::

:::talents 冰霜范围伤害
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZZWAAAgFAAAAAAYBgttxMzMY2mxMzYbBAAAMzgZgBMDwA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

疾咒师

单体目标

推荐

轻度顺劈/团队副本

推荐

大秘境/地下堡

霜火

单体目标

轻度顺劈/团队副本

大秘境/地下堡

推荐

### 天赋方案 0-0

1.1.

#### 单目标天赋（适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师

标准 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师 冰霜。这在优先考虑单体伤害的团队副本首领战中效果最佳，且要么完全没有小怪，要么小怪无关紧要到可以忽略。

在轻度顺劈的情况下，可以随意将[[spell:1247743]]和[[spell:378919]]替换为[[spell:56377]]和[[spell:378448]]。

### 天赋方案 0-1

1.2.

#### 轻度分裂与团队副本天赋 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师

这是大多数有小怪的团本战斗的推荐构建，以及任何你真正需要一定顺劈能力而非纯单体输出的其他场景。

### 天赋方案 0-2

1.3.

#### AoE/大秘境/地下堡 天赋方案，适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师

这是我们为大量AOE团本战斗、地下城（无论是否大秘境）或推荐的构筑 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 如果你更喜欢玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师.

如果你正在优先攻击一个主要目标，比如地下堡的最终首领，或者一个需要更多集火的团队副本首领，那么将[[spell:418733]]替换为[[spell:1247055]]会很有益。

### 天赋方案 1-0

1.4.

#### 单目标天赋（适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

标准 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火 冰霜。这在优先考虑单体伤害的团队副本战斗中效果最佳。

在轻度顺劈场景中，将[[spell:455122]]换成[[spell:56377]]。

### 天赋方案 1-1

1.5.

#### 轻度分裂与团队副本天赋 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

这是大多数有小怪的团本战斗的推荐构建，以及任何你真正需要一定顺劈能力而非纯单体输出的其他场景。

### 天赋方案 1-2

1.6.

#### AoE/大秘境/地下堡 天赋方案，适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

这是我们为大量AOE团本战斗、地下城（无论是否大秘境）或推荐的构筑 [地下堡](<https://www.icy-veins.com/wow/delves-guide>).

如果你正在优先攻击一个主要目标，比如地下堡的最终首领，或者一个需要更多集火的团队副本首领，那么将[[spell:418733]]替换为[[spell:1247055]]会很有益。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZMziZmZmZMDAAAMzMzyyMTbAAAAAAwGAbbjZmZwsNPgxMsAAAwMbAzADYGMMA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIZAcYUYa3lDTDHn2TFkIpVM-AAAA-RKQkIMAcYIoJzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAA2AYbbMzMDmthxMsAAAwMbAzADYGMMA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIZAcYUYa3FTDHn2TFkIp1AC-AAAA-RKQkIMAcYIoJzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAAWAYbbMzMDmthxMsAAAwMbAzADYGMMA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIZAcYUYS3FTDHn2TFkIp1AC-AAAA-RKQkIMAcYIoJzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZMziZmZmxMzsMTzMLzCAAAsAAAAAAAbAstNmZmB2mxYGbLAAAgZGMDMgBGGA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIZIM9yhpBY8QnoVMsIOOtnv-AAAA-UYckgAYIgQRDzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGjZmxiZmZmxMzsMTzMLzCAAAsAAAAAAAbAstNmZmB2mxMzwCAAAYmBzADYghB"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqIBcYUYqzFTDRnoVMstIOOtH-AAAA-UYckgAYIgQRDzC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZbWAAAgFAAAAAAYBgttxMzMY2mxMzYbBAAAMzgZgBMDwA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqw4IM5ioB4wYXAHn2TlIJkVMsvRb--UYckgEYIgQRDzC-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是至暗之夜中引入的一个新的迷你天赋系统
[12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个多阶段的任务系列过程中提供一些次要的输出和治疗选择。

以下是大多数情况下的推荐选择。然而，每者之间的实际DPS差异相当低，所以请随意改变设置并看看你喜欢哪个。值得注意的是，如果你主要进行户外内容而非副本内容，[[spell:1279596]]是一个更好的爆发选择。

- 节点1：[[spell:1279599]]
- 节点 2：[[spell:1279603]]
- 节点3：[[spell:1287555]]
- 节点 4：[[spell:1279609]]
- 节点5：[[spell:1279614]]

1.

### 巅峰天赋： ![Hand of Frost Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_frost_frostbolt.jpg>) 寒冰之手

[[spell:1262935]]使任何碎裂事件有10%的几率发射一个额外的法术，伤害相当可观，并为目标增加1层冻结效果。

[[spell:1262981]]在此基础上，根据消耗的层数来提高触发几率。每当伤害法术触发时，获得一个持续几秒的1%伤害增益。这个增益可以叠加，且每层的计时是独立的，所以随着你的游戏过程，它们会逐渐上升和下降。

[[spell:1263249]]在[[spell:205021]]的持续时间内触发4个伤害法术，强化光束的伤害，并为该法术增加一层充能。

在大多数情况下，这是一个完全被动的天赋，但它相当强大。拥有[[spell:205021]]的第二层充能的灵活性使我们可以为重要事物储备一层充能，例如饰品触发或易伤阶段。

1.

### 英雄天赋

在71级可用的英雄天赋是互斥的天赋树，你可以选择它们来稍微改变游戏玩法和视觉效果。冰霜法师可以使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师 英雄天赋树。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火爆发性稍强，且其所有伤害都相当前置。一般而言，它更适合户外内容，或那些死得很快的内容。

在AoE方面，拥有[[spell:153561]]，并且其和[[spell:1247777]]的伤害都得到了提升，再加上会爆炸的[[spell:199786]]，它在爆发AoE方面表现出色。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 相比之下，疾咒师更侧重于通过碎片进行更快速、更小伤害的攻击。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师仍然是通过[[spell:444986]]减少[[spell:84714]]冷却时间的唯一途径，使其拥有更频繁施放宝珠的独特优势。它以无法真正选择[[spell:1247777]]天赋，并失去该天赋可能带来的爆发作为代价。

1.

### PvP天赋（战争模式）

自争霸艾泽拉斯以来，可以启用“战争模式”。启用战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于开启战争模式在升级和PvE内容中的好处，建议开启该功能以最大化你的升级速度和满级后的奖励。然而，这样做会开启PvP战斗，在升级或进行世界任务时存在被对立阵营成员攻击的可能性。

- [[spell:198148]]非常好，没有任何缺点。
- [[spell:390612]]是一个很好的选择。一次不错的延迟爆发AOE伤害。
- [[spell:389794]] 作为一个不错的短期眩晕技能，但伤害不尽如人意，且需要目标离你极近。有更好的选择。

[[spell:352278]]将获得特别提及。能够强制制造视线遮挡或将敌方玩家卡在你身边或远离你，是一种非常强大的实用功能。这感觉就像是你应该随身携带以防万一进入战争模式的东西之一。它在区域封锁方面的实用效果出奇地强大。

有一些有趣的荣誉天赋，但由于它们仅限于开放世界且在副本中无法使用，因此通常不会进行模拟。因此，以上内容仅是作者的想法和感受。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7更新，新增了Omnium Folio推荐，应请求新增了一套轻度顺劈/团本天赋。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月28日：** 对简介进行了细微调整。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已更新Boltslinger和标准天赋选项建议。
- **2024年10月27日：** 针对11.0.5更新了新的理论。
- **2024年10月21日：** 已更新至11.0.5版本。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已针对10.1.7补丁更新
- **2023年7月10日：** 已针对10.1.5补丁的重大改版进行更新。
- **2023年5月1日：** 更新了荣誉天赋，并移除了一些存在Bug的互动说明。
- **2023年3月20日：** 更新了默认天赋树。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面，你将学习如何在单目标和多目标情况下优化你的冰霜法师的输出循环。我们还提供了关于冷却技能、触发效果等方面的进阶章节，以最大化你的DPS。我们的所有内容均针对《魔兽世界》12.1.5补丁进行了更新。

1.

### 冰霜 法师玩法与循环指南

欢迎来到我们的 冰霜 法师输出循环页面。在这个页面上，你将找到关于在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

以下各节分别讲解了冰霜法师在不同内容类型中的循环，并描述了这些循环背后的原理。点击框体可切换到所需的伤害类型。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

单体目标

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

主动天赋

被动天赋

[[spell:1247777]]

[[spell:157997]]

[[spell:1247729]]

[[spell:270233]]

[[spell:1216953]]

[[spell:1247090]]

[[spell:1247544]]

### 冰霜 法师 基础知识

冰霜法师最基本的前提是spam [[spell:116]]来叠加Freezing，或者直到你获得一个触发。[[spell:112965]]允许你施放[[spell:30455]]并获得满层Freezing的效果。[[spell:190447]]重置[[spell:44614]]的冷却时间。

加入天赋后，[[spell:1247777]]在每次[[spell:205021]]之后增加一次额外使用，除了自身伤害高之外，还会消耗所有命中目标身上的冻结层数。[[spell:1247090]]会将你的[[spell:120]]（或如果你点出天赋则改为[[spell:157997]]）改为在范围伤害中叠加多层冻结。[[spell:1247729]]会略微改变你围绕[[spell:30455]]的玩法。

1.1.

#### 触发效果管理

使用刷新的 [[spell:112965]] 和 [[spell:190447]]。

[[spell:112965]]使你的[[spell:30455]]造成的伤害视为消耗了目标身上最大量的严寒层数，即使目标身上完全没有严寒层数也是如此。

[[spell:190447]]如果点出[[spell:1247729]]，可以使你下一次（8秒内）[[spell:30455]]的冻结层数消耗翻倍。这与[[spell:112965]]同样有效，让你能够[[spell:1246769]]出高达12层的伤害而不消耗任何冻结层数。

1.2.

#### 最大化顺劈

归根结底，冰霜法师主要是关于以适合当前情况的方式滥用你的施法。这里存在大量的可能性、协同效应和重叠，它们将带来有利的结果。因此，作为一名玩家，你仔细思考如何以合理的方式使用你的法术是非常重要的。尽量避免随意或不加思考地使用你的主要技能，因为这不可避免地会导致你损失大量伤害。例如，当你的[[spell:84714]]即将冷却完毕时，开始思考你将如何用它来顺劈，或者首领是否会被移动。查看你的首领时间轴，看看你如何能将其对齐到一个伤害提升或AOE的阶段。其中很多可能看起来是常识，但你会惊讶于这有多么少见！

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火 单体循环

[[spell:431044]]

[[spell:205021]]

[[spell:44614]]

[[spell:84714]]

1.3.

#### 单体目标起手

1. 在倒计时 2 秒时预读 [[spell:431044]]。
2. 施放[[spell:205021]]。
3. 施放[[spell:44614]]。
4. 施放[[spell:84714]]。
5. 遵循你下方指示的常规优先级。

1.4.

#### 单体目标优先级

- 施放[[spell:199786]]。
- **适用条件：Comet Storm（启用）。** 施放[[spell:1247777]]。
- **适用条件：Thermal Void（未启用）。** 如果你拥有[[spell:190447]]，则施放[[spell:44614]]。
- **适用条件：Thermal Void（启用）。** 如果[[spell:1247729]]尚未激活且你拥有[[spell:190447]]，则施放[[spell:44614]]。
- 如果你有2层[[spell:112965]]，则施放[[spell:30455]]。
- **适用条件：Crystalline Refraction（启用）。** 施放 [[spell:205021]]，一旦你获得2层 [[spell:112965]] 就立即打断它。
- **适用条件：晶体折射（未启用）。** 施放[[spell:205021]]并尽快用另一个施法打断它。
- 施放[[spell:84714]]。
- **适用条件：Thermal Void（启用）。** 当你拥有[[spell:112965]]且[[spell:1247729]]激活时，施放[[spell:30455]]。
- 在拥有12层或更多冰冷效果时施放 [[spell:30455]]。
- 如果你有一层充能可用但没有[[spell:190447]]，则施放[[spell:44614]]。
- 施放[[spell:431044]]。

这在功能上意味着“让所有技能进入冷却”，并尝试以完全被动的方式围绕[[spell:1247729]]进行优化。一旦你掌握了诀窍，游戏循环非常简单。

冰霜即使在2目标顺劈时也倾向于继续单体输出，AoE循环要到3个或更多目标时才会接管。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火AoE循环

[[spell:190356]]

[[spell:205021]]

[[spell:44614]]

[[spell:84714]]

1.5.

#### AoE起手

1. 在倒计时还剩2秒时预读[[spell:190356]]。
2. 施放[[spell:205021]]。
3. 施放[[spell:44614]]。
4. 施放[[spell:84714]]。
5. 遵循你下方指示的常规优先级。

1.6.

#### AoE优先级

- 施放[[spell:199786]]。
- **适用条件：Comet Storm（启用）。** 施放[[spell:1247777]]。
- **适用条件：Thermal Void（未启用）。** 在拥有[[spell:190447]]时施放[[spell:44614]]。
- **适用条件：Thermal Void（启用）。** 如果[[spell:1247729]]尚未激活，在拥有[[spell:190447]]时施放[[spell:44614]]。
- **适用条件：Thermal Void（启用）。** 如果你有2个[[spell:112965]]或[[spell:1247729]]已激活，施放[[spell:30455]]。
- **适用条件：Thermal Void（未启用）。** 如果你有2个[[spell:112965]]，施放[[spell:30455]]。
- 施放[[spell:205021]]。
- 施放[[spell:84714]]。
- **适用条件：Freezing Rain（启用）。** 施放[[spell:190356]]。
- 如果[[spell:112965]]已激活或目标身上有10层或更多冻结，施放[[spell:30455]]。
- 如果你有一层充能可用但没有[[spell:190447]]，则施放[[spell:44614]]。
- 施放[[spell:431044]]。

**适用条件：Cone of 冰霜（启用）。** [[spell:1247090]]目前数值偏低，不值得施放 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火。你应该转而尝试使用其余技能组来触发[[spell:431176]]。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师单体目标循环

[[spell:116]]

[[spell:44614]]

[[spell:84714]]

[[spell:205021]]

**适用条件：Crystalline Refraction（启用）。**

[[spell:30455]]

1.7.

#### 单体目标起手

1. 预读[[spell:116]]。
2. 施放[[spell:44614]]。
3. 施放[[spell:84714]]。
4. 施放[[spell:205021]]。
5. **适用条件：Crystalline Refraction（启用）。** 施放[[spell:30455]]。
6. 遵循你下方指示的常规优先级。

### 单体目标优先级

- **适用条件：Comet Storm（启用）。** 施放[[spell:1247777]]。
- **适用条件：Thermal Void（未启用）。** 在拥有[[spell:190447]]时施放[[spell:44614]]。
- **适用条件：Thermal Void（启用）。** 如果[[spell:1247729]]尚未激活，在拥有[[spell:190447]]时施放[[spell:44614]]。
- 施放[[spell:84714]]。
- 如果你有[[spell:112965]]，施放[[spell:30455]]。
- 可用时施放[[spell:199786]]。
- 当目标身上的冻结层数达到或超过6层时，随时施放[[spell:30455]]。
- 施放[[spell:205021]]。
- 施放[[spell:44614]]。
- 施放[[spell:116]]。

这在功能上意味着“让所有技能进入冷却”。[[spell:1247729]]是你在决定施放[[spell:30455]]时可以忽略的东西，只需希望它消耗超过6层即可。一旦你掌握了诀窍，游戏循环非常简单。

冰霜即使在2目标顺劈时也倾向于继续单体输出，AoE循环要到3个或更多目标时才会接管。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师AoE循环

[[spell:190356]]

[[spell:44614]]

[[spell:84714]]

[[spell:205021]]

1.8.

#### AoE起手

1. 施放[[spell:190356]]。
2. 施放[[spell:44614]]。
3. 施放[[spell:84714]]。
4. 施放[[spell:205021]]。
5. 遵循你下方指示的常规优先级。

1.9.

#### AoE优先级

- **适用条件：Comet Storm（启用）。** 施放[[spell:1247777]]。
- **适用条件：Freezing Rain（启用）。** 如果[[spell:270233]]已激活，施放[[spell:190356]]。
- **适用条件：Thermal Void（未启用）。** 在拥有[[spell:190447]]时施放[[spell:44614]]。
- **适用条件：Thermal Void（启用）。** 如果[[spell:1247729]]尚未激活，在拥有[[spell:190447]]时施放[[spell:44614]]。
- 施放[[spell:84714]]。
- 如果你有[[spell:112965]]，施放[[spell:30455]]。
- 可用时施放[[spell:199786]]。
- 当目标身上的冻结层数超过6层时，随时施放[[spell:30455]]。
- **适用条件：Ice Nova（启用）；Cone of 冰霜（启用）。** 施放 [[spell:157997]]。
- **适用条件：Cone of 冰霜（启用）；Ice Nova（未启用）。** 施放 [[spell:120]]。
- **适用条件：凛冽寒风（启用）。** 如果你正在与 5 个或更多敌人战斗，则施放 [[spell:190356]]。
- 施放[[spell:44614]]。
- 施放[[spell:205021]]。
- 施放[[spell:116]]。

非瞬发的 [[spell:190356]] 相比持续生成冰刺来说相当弱，因为冰刺会缩短 [[spell:84714]] 的冷却时间，而寒冰宝珠既能大幅提升 AoE 伤害，又能触发 暴风雪 的瞬发。因此，除非点出了 [[spell:1216953]]，否则非瞬发时不施放该技能。

1.

### 至暗之夜 第2赛季套装

这些都是完全被动的增益，除了影响 [[spell:199786]] 的可用频率外，不会以任何方式影响你的操作。

- [[spell:1296585]] — 每层冻结[[spell:1246769]]效果有4%的几率生成一根冰枪。[[spell:199786]]伤害提高20%。
- [[spell:1296586]] — 施放 [[spell:199786]] 时，有几率在 1 秒内快速生成 5 根冰刺。[[spell:1246769]] 伤害提高 5%。

1.

### 职业与专精机制详解

### 冰冻与碎裂

3.1.

#### 冻结

冻结是你大部分法术施加在目标身上的减益效果。这可以由[[spell:30455]]、[[spell:1247777]]以及在点出[[spell:1280780]]天赋时的[[spell:199786]]触发。这将触发[[spell:1246769]]，对目标造成伤害，并根据该法术消耗的层数对附近目标造成较少伤害。此外，如果目标通过[[spell:1247775]]死亡，这个AOE部分也会触发，造成比正常情况下该层数应触发的AOE伤害更低的伤害。

你会经常叠满 20 层上限。遗憾的是，这是不可避免的。

:::details 常见问题：我应该在多少层冰冻时使用冰枪术？
对 6 层以上，

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师

对 10 层以上，

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

.

:::

### 顶点天赋

3.2.

#### 顶点天赋

[[spell:1262935]]使任何碎裂事件有10%的几率发射一个额外的法术，伤害相当可观，并为目标增加1层冻结效果。

[[spell:1262981]]在此基础上，根据消耗的层数来提高触发几率。每当伤害法术触发时，获得一个持续几秒的1%伤害增益。这个增益可以叠加，且每层的计时是独立的，所以随着你的游戏过程，它们会逐渐上升和下降。

[[spell:1263249]]在[[spell:205021]]的持续时间内触发4个伤害法术，强化光束的伤害，并为该法术增加一层充能。

在大多数情况下，这是一个完全被动的天赋，但它相当强大。拥有[[spell:205021]]的第二层充能的灵活性使我们可以为重要事物储备一层充能，例如饰品触发或易伤阶段。

1.

### 冰霜 法师 的重要冷却技能

### [[spell:205021]]

4.1.

#### 冰霜射线

[[spell:205021]]是我们的"主要"冷却技能，每分钟可用一次。它使你引导4秒，对目标造成大量伤害，并在每次跳字时叠加一层冰霜效果。

在天赋树中，它的正下方有两个强化天赋：[[spell:1247055]] 和 [[spell:418733]]。冰寒专注不言自明，但碎裂射线会选择离你的射线目标最近的 5 个目标，并在每一跳中对他们造成一部分伤害。

点出 [[spell:1247777]] 后，该按钮会在施放后变为彗星风暴。

:::details 常见问题：为什么冰霜射线的优先级如此之低？
由于

[[spell:205021]]

会生成如此多的冰冻层数，因此最好在施放它之前消耗英雄天赋所需的层数，以最大化其价值。

:::

### [[spell:84714]]

4.2.

#### 寒冰宝珠

[[spell:84714]] 是我们的次要冷却技能。它在 15 秒内每半秒造成一次 AoE 伤害。

施放时，它会快速向外飞出，直到击中一个目标，此时它会大幅减速。3 秒后，它将开始缓慢追踪你施放时最初选定的那个怪物。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 起手调整。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7更新，对霜火进行了小幅调整。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026 年 3 月 22 日：** 新增投弹手单体起手式。
- **2026年3月16日：** 添加了关于至暗之夜第1赛季套装的说明。
- **2026年2月28日：** 措辞调整，并添加了在双目标时仍使用单体的说明。
- **2026年2月26日：** 更多优先级变更。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026 年 2 月 11 日：** 再次更新了优先级，补丁期间理论计算变化很快。
- **2026年2月10日：** 更新了优先级，添加了关于投弹手的冰冻在单体目标上使用的常见问题。
- **2026 年 1 月 20 日：** 修正了错别字，一键现在会使用 冰霜 的冷却技能了。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025 年 8 月 23 日：** 弹幕射手在单体目标时再次施放彗星风暴，奥术涌动受到限制。
- **2025年8月4日：** 最后时刻的APL改动，略微简化了输出循环。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 新增了11.1.7战斗助手章节。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 3 月 2 日：** 修复了霜火范围输出与过量火焰的逻辑问题。
- **2025 年 2 月 28 日：** 对霜火的冰枪术逻辑进行了微调，并更新了投弹者的DC范围限制。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已更新为包含两种英雄天赋选项的标准冰霜和弹幕射手变体输出循环。
- **2024年10月27日：** 针对11.0.5更新了新的理论。
- **2024年10月21日：** 已更新至11.0.5版本。
- **2024 年 10 月 7 日：** 措辞上的小改动。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月27日：** 从AOE循环中移除了GS，以获得小幅收益。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2024 年 1 月 14 日：** 冰川尖刺现在无论冰冷血脉状态如何，都不配合冰枪施放。
- **2023 年 12 月 12 日：** 对冰霜射线和寒冰宝珠的说明作了小幅澄清。
- **2023 年 11 月 12 日：** 移除了3.2节中过时的段落，并根据10.1.5的改动，用更深入的触发使用分析取而代之。
- **2023年11月6日：** 添加了关于T31对双目标DPS影响的信息。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023 年 8 月 11 日：** 幻能涌动应该在冰冷血脉期间使用，一旦火焰之息/寒冰宝珠/冰霜之球进入冷却。
- **2023年8月1日：** 添加了在冰冷血脉期间没有寒霜指触发时施放寒冰长矛的缺失循环部分。
- **2023年7月10日：** 已针对10.1.5补丁的循环改动进行更新。随着未来几个月理论研究的深入，可能会有进一步的改动。
- **2023年5月1日：** 为AoE循环方案新增了开关选项。减少寒冰箭的方案差距已缩小至1.7%。
- **2023年3月20日：** 新增了关于减少寒冰箭循环方案的说明。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 更新了有/没有冰霜呼唤者时的暴风雪目标值。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页面中，你将找到《魔兽世界》12.1.5 中 冰霜 法师 的最佳装备、饰品以及毕业装备推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们应有尽有！

1.

### 冰霜 法师 毕业装备指南

欢迎查看我们 至暗之夜 第 2 赛季的 冰霜 法师 装备指南。查看此页面，了解有关为 冰霜 法师 配装所需的一切信息，包括来自所有来源的毕业装备、团本和大秘境、关于最佳饰品、套装等更多信息。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

本列表包含 至暗之夜 第 2 赛季中 冰霜 法师 的毕业装备。

请注意，不存在单一的、包罗万象的"毕业"装备。最佳装备因角色和情况而异，有许多装备在DPS方面实际上是等效的，尤其是当我们只是在调整次要属性时。我会为每个部位列出一件"毕业"装备，但归根结底，毕业装备列表应被视为指导，你应该 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 来决定接下来该装备什么。

:::details 常见问题我需要哪些套装部件？
对于 至暗之夜 第 2 赛季的 冰霜 法师 来说，你转化的部件会保留其属性和任何咒术效果。这实际上意味着你应该优先转化你在高物品等级下获得的部位。除此之外，不同部位之间没有优劣之分。你应该争取转化这 5 件中的任意 4 件：

- 头部：[[item:271874@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:239031@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸部：[[item:273785@JAACAAgNyA]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 手部：[[item:268243@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿部：[[item:159234@JAACAAgNyA]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)

:::

:::details 常见问题我应该从大宝库中选择哪些物品？
你想选择什么取决于个人情况，很大程度上取决于你的进度水平和当前装备。模拟结果应该始终为你的决策提供参考。不过，有一些物品你可能应该无论如何都选择：

- [[item:271092@JAACAAAG2A]]：毕业装备，且遥遥领先。
- 所有剧毒诅咒物品都严重超出属性预算，值得获取，甚至可能替换更高层级的物品。
- [[item:250215@JAACAAgNyA]] 是一个非常好的饰品，其价值非常接近 [[item:270167@JAACAAgNyA]]。如果你更喜欢主动使用型饰品，这是一个不错的选择。

:::

:::details 常见问题：基斯希克斯的装备怎么样？
新装备及其咒术提供的伤害不足以改变毕业列表以适应较差的属性。对于那些并非完全毕业，或不期望打通史诗巢穴祭坛或 乌拉特克 的人来说，它们可能是可行的，因为你可以从物品等级 344 中腾出大量物品栏位，使其完全优于替代品。然而，这超出了毕业列表的范围，最好在个人层面上进行模拟。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271564@JAAGAAgF2ghNTpC]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271565@JAAEAAwF0ghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAj1ghNTpC]]&#10;&#10;<div>[[item:240983]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:239649@JAAMAAwViAGM3WT0wwgNTpC]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>护肩</th><td>[[item:271562@JAAIAAgNycBN-VTg1A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:159234@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAAEAAwF0ghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAAEAAwF0ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268249@JAAGAAgNycBNkVD]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270164@JAAEAAAOycBN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></div></td></tr><tr><th>护腕</th><td>[[item:251154@JAAEAAgNyMlK]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAAEAAwF0ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243971]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAOAAwViscN3WT0wwgNTpCH2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 秘境+

本列表包含使用第 2 赛季大秘境可刷取装备的最高 DPS 配置。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
对于 至暗之夜 第 2 赛季，你转化的部件会保留其属性和任何咒术效果。这实际上意味着你应该优先转化你在高物品等级下获得的部位。不同部位之间没有优劣之分。你应该争取转化这 5 件中的任意 4 件：

- 头部：[[item:251199@JAACAAgMyA]]，来自 [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- 肩部：[[item:239031@JAACAAgMyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸部：[[item:239032@JAACAAgMyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 手部：[[item:159247@JAACAAgMyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 腿部：[[item:193750@JAAKAAQkCYHKvbRLfIjM]]，来自 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：你的主手武器、一个饰品，以及一些用于其他部位的不错选择。
- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：高属性预算的部件和一把属性良好的法杖，供你在尝试获取主手/副手组合时使用。
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：毕业饰品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271564@JAACAAAMyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271565@JAACAAgMyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAAMyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:239649@JAAMAAwViAGM3WT0wwgNTpC]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>护肩</th><td>[[item:271562@JAACAAgMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:193750@JAAKAAQkCYHKvbRLfIjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgMyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:251137@JAACAAgMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271567@JAACAAgMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgMyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgMyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273794@JAACAAAMyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:251154@JAAEAAgMyMlK]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAAMyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAAMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243971]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAOAAwViscN3WT0wwgNTpCH2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 团队副本

本列表包含仅使用来自剧毒深渊团本装备的最高 DPS 配置。

此列表绝不能替代 **模拟你自己**。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
对于 至暗之夜 第 2 赛季的 冰霜 法师 来说，你转化的部件会保留其属性和任何咒术效果。这实际上意味着你应该优先转化你在高物品等级下获得的部位。除此之外，不同部位之间没有优劣之分。然而，毕业肩部实际上是团本的套装代币，因为没有其他肩部具有最优属性。此外，除了套装代币外，没有其他布甲胸部。你应该转化这些物品：

- 头部：[[item:271874@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手部：[[item:268243@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿部：[[item:268236@JAACAAgNyA]]，来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)

:::

:::details 提示哪些团队副本装备最重要？
如果你需要金币建议，或者你的公会要求毕业优先级：

- [[item:271092@JAACAAAG2A]]：最高物品等级的武器，并带有额外的咒术效果。
- [[item:271874@JAACAAAG2A]]：最高物品等级的头部，剧毒诅咒效果使其成为价值极高的物品。
- [[item:268265@JAACAAAG2A]]：最高物品等级的项链，第二个插槽与剧毒诅咒效果的结合使其成为价值极高的物品。
- [[item:270164@JAACAAgNyA]]：最佳饰品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271564@JAAIAAwF0QWNWYDG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271565@JAAEAAwF0ghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAIAAwF0QWNMWDG2A]]&#10;&#10;<div>[[item:240983]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:239649@JAAMAAwViAGM3WT0wwgNTpC]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>护肩</th><td>[[item:271562@JAAIAAgNycBN-VTg1A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:268236@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAAEAAwF0ghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAAEAAwF0ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268249@JAAGAAgNycBNkVD]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270164@JAAEAAAOycBN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></div></td></tr><tr><th>护腕</th><td>[[item:268228@JAAEAAgNyMlK]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAAEAAwF0ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243971]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAOAAwViscN3WT0wwgNTpCH2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 第2赛季 冰霜 法师 饰品推荐

与上个赛季相反，本赛季有相当多可用的饰品。[[item:270167@JAACAAgNyA]] 和 [[item:270164@JAACAAgNyA]] 在所有目标数量和天赋组合中都是稳健的赢家，但除了这些之外，还有相当多差距很小的饰品可供使用。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **冰霜法师饰品**
[[item:270167@JAACAAgNyA]]

[[item:270164@JAACAAgNyA]]

:::

此列表中定义的“Tier”差距约为 0.5% DPS，这意味着 S 级饰品比 A 级饰品好约 0.5%，以此类推。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 冰霜 法师 饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]，在光束中保持50%的覆盖时间</li>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274493@JAACAAgMyA]]</li>&#10;<li>[[item:251792@JAACAAgMyA]]</li>&#10;<li>[[item:270169@JAACAAAG2A]] 按冷却时间使用</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:251785@JAACAAgMyA]]</li>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;<li>[[item:251786@JAACAAgMyA]]</li>&#10;<li>[[item:251784@JAACAAgMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚无核心（额外拾取）和晋升毒液石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>)可以用来从你完成的首领、地下城或地下堡中额外掷取一件物品。你获得哪一件是随机的，但一旦获得就会从潜在掉落池中移除，直到你每件物品都见过一次。这使你能够定向获取特定地点的特定装备。

3.1.

#### 冰霜 法师的推荐虚空核心使用指南

你需要寻找什么物品在很大程度上取决于你已有什么、你需要什么，以及你可以自行完成哪些内容。优先级如下：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 在英雄（或史诗）难度中提供了最佳的DPS收益，因为其中高度集中了极其强大的法器物品。
2. 剩余的毕业装备列表物品

:::

3.2.

#### 晋升毒液石

[[item:280562]]允许某些部位的装备升级超过其品质等级上限。也就是说，在功能上可以将某件装备提升到8/6英雄或史诗等级。

升级优先级应大致遵循纹章升级的优先级：

- 主手或双手武器
- 饰品
- 副手
- 项链

优先选择史诗或制造装备，因为它们在这个赛季不会被替换，除非你的个人进度无法让你在史诗难度击杀该首领，或者无法在英雄难度上花费虚空核心。还应该指出的是，史诗团本玩家在某种程度上被排除在外，因为任何在344装等掉落的物品都无法升级。

1.

### 法师 冰霜 最佳专业制造物品

专业是填补你一直运气不好未能填满的装备栏位的绝佳方式，并且还能通过美化提供少量的强度提升。

由于制造装备有时间限制，且获取装备并非一蹴而就，赛季初期最明智的决定是制作一根法杖。虽然这意味着你之后不得不制作一个副手，浪费更多的火花和纹章，但它能提供赛季初期最大的单次战力提升。之后再制作你的其他美化装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **冰霜专业制造装备优先级**
- [[item:245770]]与[[item:273060]]
- [[item:239649]]搭配[[item:240167]]
- 从以下来源获得主手武器后，再获取[[item:245769]]： [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 任何你尚未获得神话级的物品。

:::

法杖虽然不是毕业装备，但仍然是赛季初期你能获得的最大单件DPS提升。如果你觉得你可能会击杀
[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 在赛季初期购买英雄难度装备，而不是直接购买副手和腰带。

有关如何制造你自己装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 冰霜 法师最佳纹章

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

你也可以移除添加到装备上的装饰，如果你最终需要更换拥有该加成的物品，或者某些东西被调整了。这可以通过使用[[item:248130]]重新制作第一个来实现，这将移除加成并允许你用新的装饰制作其他东西。

目前，最佳选择是[[item:273060]]，以及在低重要性部位（如护腕或披风）上的[[item:240167]]。

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕打孔，如果你在大宝库中没有选择任何一件装备，就可以获得该物品。不选择装备会获得代币，其中六个可以兑换成瘴气珠宝师工具，允许你为上述装备打孔，但前提是这些代币是在第2赛季获得的。

1.

### 纹章使用

你将能够通过徽章升级你的物品，例如
[秘境雾崖](<https://www.wowhead.com/currency=3446>)。一旦你将某个部位升级到特定物品等级， **将该部位的其他物品升级到该物品等级不消耗纹章**.

当你使用纹章升级时，你应该将其视为升级 **插槽**
而不是物品。

此外，由于纹章是一种有限资源，你会希望获得尽可能高的物品等级 **之前** 升级某个特定插槽，因为这意味着你在该插槽上总共花费的纹章会更少。例如，如果你完全有能力打+10地下城（3/6英雄），那么从+9地下城（2/6英雄）升级一件装备将是一个非常糟糕的主意，因为你白白浪费了20个纹章，这些纹章本可以通过直接在+10刷取该插槽来节省。

至暗之夜中的纹章是按路线区分的，所以完全升级英雄路线的物品没有真正的惩罚，事实上可能是有益的，因为它将在神话2升级时跳过20个神话纹章。这相当于每月多出一件完整装备，或一件神话制造物品。对于只能从每周大宝库获得神话路线的普通玩家来说，这是一个相当重要的奖励。

我们看到大量玩家，即使在高水平，也会搞错升级优先级，过早进行升级。把这件事做对，你会远远领先于大多数玩家。

以下是你应该……的部位优先级 [ 升级你的装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 中。如果你想要偏离这一点，你需要有一个非常好的理由。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **冰霜法师徽记升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿部**

➜

**肩部/手套/腰带/靴子**

➜

**披风/护腕**

➜

**项链/戒指**

:::

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁更新，包含新的饰品和毒石优先级。
- **2026年8月14日：** 已更新第二赛季饰品梯队列表，BiS列表。
- **2026年8月10日：** 已针对12.1补丁更新，包含初步BiS列表。
- **2026年6月15日：** 已针对12.0.7补丁更新，包含腐肉沼泽掉落。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 更新并添加了一个关于Cartel Chips的章节，毕业装备列表中的物品等级已提高。
- **2025 年 8 月 23 日：** 添加了饰品排行榜，并对毕业装备列表进行了细微调整。
- **2025年8月6日：** 修正了制造装备部分推荐披风而非护腕的问题。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月24日：** 充能箭矢被削弱。
- **2025年6月15日：** 已用新的探底腰带更新。
- **2025年4月21日：** 更新了毕业装备列表中的饰品，添加了谜之财团芯片部分。
- **2025年3月21日：** 添加了赛尔希的替换说明，套装修复。
- **2025 年 2 月 28 日：** 更新了总体毕业装备列表。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月17日：** 赛尔西的王冠在上线时获得大幅增强。
- **2024年12月15日：** 针对11.0.7和Cyrce's Circlet进行了更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023 年 11 月 12 日：** 为第3赛季添加了毕业装备列表和刷取列表。
- **2023年11月7日：** 孢子披风已被削弱。
- **2023年11月6日：** 针对 10.2 的部分更新。
- **2023年9月8日：** 修改了饰品部分的措辞
- **2023年9月4日：** 已针对10.1.7补丁更新
- **2023年7月10日：** 已针对10.1.5补丁更新，包含套装/专业插槽建议，并注明永恒黎明的装备尚未经过测试。
- **2023年5月11日：** 重新添加了Bloodmallet图表。
- **2023年5月7日：** 已更新至第2赛季开始，并在流石削弱后提供了饰品建议。
- **2023年5月1日：** 添加了第2赛季升级系统、第2赛季实用物品以及推荐的纹章。
- **2023年3月23日：** 熔玉项圈不再造成DPS损失。
- **2023年3月20日：** 新增了关于熔玉项圈的说明。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季开始更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的冰霜 法师的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法互动。我们的内容已更新至《魔兽世界》12.1.5版本。

1.

### 冰霜法师属性优先级

以下是 冰霜 Mages 属性的一个良好参考准则：

智力

精通

暴击

急速

全能

随着装备越来越高，急速将开始与暴击和精通持平，最终三者的权重将大致相等，至少在第2赛季是这样。

:::details 属性权重是如何运作的？
作为一个主要示例，以下是某个角色在登出时所用天赋套装下的属性权重：

![Normal weights: Int-2.09, crit-1.59, mastery-1.52, vers-1.48, haste-1.46](<https://static.icy-veins.com/images/wow/classes/mage/frost-normal-weights.jpg>)

以下是如果将所有急速全部移除并转化为精通后的情况：

![Altered weights: Int-2.05, crit-1.56, mastery-1.24 vers-1.42, haste-2.00](<https://static.icy-veins.com/images/wow/classes/mage/frost-altered-weights.jpg>)

即使只堆叠少量属性，也已经使权重严重倾斜，以至于急速现在的价值高于暴击，并且非常接近高于智力。

:::

任何属性都不应该被强行堆叠。所有属性都相互配合。 **例如：** 急速可能很棒，但总有一个临界点，此时通过堆叠精通来提高[[spell:116]]的伤害，使施法速度较慢但每次施法时间实际伤害更高的法术变得更好。然而，如果你反其道而行之，只堆叠精通而忽略急速，你会看到相反的结果。更快、稍弱的施法会比重度堆叠精通而施法非常缓慢更好。这就是属性权重不是静态的，并且实际上随每件装备变化的主要原因。

1.

### 深入属性解析

**智力** 是你的“主属性”，意味着你使用它而不是敏捷或力量，但这并不意味着它在所有情况下都是最好的。它为你提供法术强度，从而提升你法术的伤害。

**全能** 是纯粹的造成伤害提升和承受伤害降低。

**暴击** 提高你的暴击几率。

:::details 冰霜法师有暴击上限吗？我需要多少？
不再是了。暴击阈值是旧时代的遗物，而暴击现在只是一个普通属性。

:::

**[[spell:1246752]]** 是对冻结或碎裂法术的直接提升。截至撰写时的一个显著例外是[[spell:190356]]和[[spell:84714]]被包含在精通的冻结部分中。

**急速** 会缩短你的法术施法时间。特别是，缩短 [[spell:116]] 的施法时间非常有益，因为这意味着你可以更频繁地施放 寒冰箭，增加你触发特效的几率，以及你生成 [[spell:1246832]] 的速度。急速还会降低你的基础公共冷却时间。急速也会提高你的水元素 元素 和 [[spell:55342]] 的施法速度。

:::details TCIs 冰霜 法师有急速上限吗？
严格来说，确实有几个软上限。它们是无法达到的上限，不应为此担心。

GCD 上限，即所有法术的公共冷却时间无法再进一步降低的阈值，在 +100% 急速时达到。这就是人们在讨论任何形式的急速上限时通常所指的。在军团再临中，GCD 上限从 +50% 提高到了 +100%，消除了几乎所有需要考虑它的情况，因此目前不必担心这个问题。

:::

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7版本进行了审查，并添加了常见问题解答组件。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为11.0.7进行了审阅。
- **2024年10月27日：** 针对11.0.5更新了新的理论。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的冰霜 法师可以获取的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/frost-mage-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

确保你的装备中有一颗[[item:240983]]。这是所有宝石中最有价值的。除此之外，用[[item:240908]]填满你的其他插槽。

1.

### 最佳附魔和武器强化

确保在所有内容中都给你的武器涂上 [[item:243733]]。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>[[item:243957]]或你的模拟建议使用的任何附魔。实际差异很小。</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>[[item:243971]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>默认使用[[item:244007]]，但三级属性附魔通常是个人选择。使用任何吸引你的。</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:243991]]作为默认选择，但三级属性附魔往往是个人选择。使用你心仪的那一个。</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>[[item:243953]]作为默认选择，但三级属性附魔往往是个人选择。使用任何吸引你的。</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;</table>

闪避和速度之间的决定因素很简单，就是你是否愿意承受略少一点的伤害，以换取始终更快的移动速度。你可以在每种场景中为两者找到理由，即使在极高难度的内容中也是如此。闪避让你能承受更大的伤害；速度让你有更多余地跑出范围效果区域。你可以在这里选择你更喜欢的任何一种效果。

作为比较，满级闪避附魔提供4.54%的属性，满级吸血提供相当于你伤害3.52%的治疗，满级急速提供11.4%的移动速度。

:::details TC为什么我们使用暴击强化而不是精通？
虽然专精属性在单体情况下是我们最好的属性，但使用[[item:241288]]时，我们确实需要略微偏向暴击。原因是[[spell:1247025]]和[[spell:1246811]]在起手阶段非常享受药水提供的巨额暴击加成。

:::

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

你应该随时饮用 [[item:241326]]。

3.2.

#### 药水

[[item:241288]]是最佳的输出药水。

你还需要储备一些 [[item:271883]] 以便在低生命值时使用；如果队伍中有 术士，记得拿上他们的 [[item:5512]] 并同样使用。不要把这些做成一个宏，分开使用效果最好！

3.3.

#### 食物增益

我们建议在可能的情况下食用 [[item:255846]] 或 [[item:255845]]，如果团队没有提供大餐，则使用个人食物（[[item:242275]] 或 [[item:255847]]）。

3.4.

#### 强化符文

此外，如果经济条件允许，你应该使用 [[item:259085]] 来提高你的主属性。强化符文价格昂贵且死亡时会消失，请明智使用！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026 年 5 月 21 日：** 新增了关于暴击与精通附魔/消耗品的常见问题解答。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 迅捷茶在副本中不再生效。
- **2026年3月16日：** 将采集茶加入消耗品列表。重新添加了三级属性附魔对比。
- **2026年2月28日：** 戒指附魔和药水推荐已更改。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 针对11.1.5的腐蚀附魔进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为11.0.7进行了审阅。
- **2024年10月27日：** 针对11.0.5更新了新的理论。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 已为 10.2.6 补丁更新，在所有情况下都改回微温全能药水。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新10.2的消耗品和新的头部附魔。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 针对10.1.5更新，加入了新的药剂和武器符文建议。
- **2023年5月1日：** 添加了新的腰带附魔。
- **2023年3月23日：** 因热修改动，更新了原初石章节的新推荐。
- **2023年3月20日：** 添加了关于原初之石的信息。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023 年 1 月 10 日：** 更新了药水选择，并新增了符文选择。
- **2022年12月11日：** 已针对巨龙时代第1赛季开始更新，武器附魔和食物选择有变动。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的冰霜法师挑战史诗钥石地下城的提示和建议。

1.

### 冰霜法师在至暗之夜第2赛季中的大秘境

在本指南中，我们将讨论如何在大秘境地下城中充分发挥你的冰霜法师的实力，包括最佳的角色配装方式、你的输出循环可能如何变化，以及最优化使用技能的技巧和窍门。有关冰霜法师天赋的更全面介绍，请访问我们专门的天赋页面。

如果你不熟悉大秘境及其相关通用机制，可以在我们的至暗之夜大秘境指南中阅读更多内容。想了解更多关于大秘境环境的信息，请查看下面的大秘境梯队列表。

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 大秘境中的霜火

选择的主要原因是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) 霜火在AOE中是稍微更具爆发性的伤害类型。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZbWAAAgFAAAAAAYBgttxMzMY2mxMzYbBAAAMzgZgBMDwA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqw4IM5ioB4wYXAHn2TlIJkVMsvRb--UYckgEYIgQRDzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 秘境+中的疾咒师

选择的主要原因是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师会更频繁地施放[[spell:84714]]。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CAEAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsMmZmYmZGzMzMziZmZMjZAAAgZmZWWmZaDAAAAAAWAYbbMzMDmthxMsAAAwMbAzADYGMMA"
}
```
:::

:::details 来源计算器编码
```
#AB-SVdXWiiEtsumYakNmsFq+BiKEocowDBCyBD-JgKGCXoqwIMRCw4wYHRQDHn2TlIJk1L-AAAA-RKQAkIMcYIoJzC-
```

:::

1.

### 灵活天赋

冰霜的天赋非常固定，所以在天赋树那一侧没有太多可更改的内容。

职业天赋树这一侧非常灵活，树上只有 7 个 DPS 节点。这个天赋树的很大一部分内容就是，如果你喜欢它的效果就点它。

如果地下城确实有那些机制，[[spell:30449]] 和 [[spell:475]] 就非常重要。否则它们完全是浪费天赋点。

如果你正好受到集火伤害，需要在短时间内连续使用 [[spell:414659]] 的两次充能，[[spell:1250315]] 可以是一个非常好的增益。

[[spell:113724]] 偶尔可用于阻止冲锋怪物击中你/团队，但这种情况相当罕见，而且属于高级技巧。

1.

### 功能技能与能力

### 打断、昏迷和控制

4.1.

#### 打断

[[spell:2139]]是你的"打断"技能，也是你在大秘境中最重要的功能性技能，用于为团队尤其是坦克打断敌人的施法。它 **强烈推荐** 使用焦点打断宏来完成此操作。

#### 焦点打断宏

```wow-macro
#showtooltip 法术反制
/cast [@focus, exists, harm,nomod] 法术反制; [nomod]法术反制
/focus [mod:ctrl][mod:shift/alt, @mouseover]
```

此宏会踢你的焦点目标（如果有）或你的目标（如果没有）。此外，这允许通过按住Ctrl指定当前目标，或按住变换或Alt指定当前鼠标悬停目标，来快速设置焦点目标。

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

4.2.

#### 眩晕与"打断"

[[spell:31661]]是我们最可靠的"群体控制"技能，会使短距离锥形范围内的所有目标迷惑。

我们确实可以选择用 [[spell:31661]] 换成 [[spell:157980]]，但击飞在实际打断当前动作方面往往不如迷惑这种真正的硬性群体控制可靠。

在绝对万不得已的情况下，为了阻止某些重要动作，我们可以对易受其影响的目标 [[spell:118]]。除非是紧急情况，否则不应使用，因为它会治疗目标，并且目标在变形结束后会立即重新开始施法。

虽然我们通常的配装不使用它们，但我们在技术上可以使用 [[spell:113724]] 和 [[spell:383121]]。

### 其他功能

4.3.

#### 其他功能

[[spell:110959]] 不仅可以用来脱离仇恨，还可以使某些针对你的施法和引导失效。在某些情况下，这些机制只是会重新锁定团队中的其他人，但偶尔，该机制会被完全抵消，带来巨大收益。

[[spell:30449]] 可以消除敌方目标身上有益的魔法效果，并偶尔将其转移给你，尽管大多数可滥用的偷取已被削弱，使法术窃取只能作为驱散来使用。

[[spell:475]] 当然可以让我们移除诅咒。

[[spell:386828]] 是一个奇特的天赋，允许我们完全抵消任何形式的减速效果，偶尔可以完全移除一个危险的机制。

作为冰霜法师，我们还会减速任何我们接触到的目标，这可能是好事也可能是坏事，取决于你的坦克在移动怪物或风筝方面有多大的需求。

1.

### 应对词缀

### 词缀：升腾

5.1.

#### 冰霜法师的升腾词缀应对

[[spell:31661]]/[[spell:157980]] 将轻松解决这个词缀。

### 词缀：脉冲星

5.2.

#### 冰霜法师的脉冲词缀应对

我们在这里没有什么特别有用的技能，尽管 [[spell:444752]] 可以作为移动速度增益使用，因为
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师.

还要确保不要闪现过头，冲过一个正跑向你来解除词缀的人。[[spell:1953]]过去某人却发现词缀还是触发了，情况可能相当糟糕，所以要瞄准好你的闪现术，不要让来你身上解除词缀的人感到困惑。

### 词缀：吞噬

5.3.

#### 冰霜 法师的吞噬词缀应对指南

[[spell:475]]是解除[[spell:440313]]的有效驱散手段。

### 词缀：虚缚

5.4.

#### 冰霜 法师 虚空绑定词缀应对

该词缀只是偶尔额外添加一只小怪。理想情况下它应该死于顺带的范围伤害，但在低输出队伍或单体战斗中请确保将其击杀。对我们来说，它与其他任何小怪相比没有什么特别之处。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025 年 8 月 23 日：** 添加了第3赛季提示。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 对措辞和哪个英雄天赋更好进行了微调。
- **2025年3月16日：** 加入了第2赛季地下城提示。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 新增了第一赛季地下城提示，包含我们可以用实用施法应对的内容。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月15日：** 零下严寒已被大幅削弱，在大多数大秘境配置中不值得点出。
- **2023年7月10日：** 已针对10.1.5补丁的循环和天赋改动进行更新。
- **2023年5月1日：** 已针对巨龙时代第2赛季更新，并新增了一个关于我们可以轻松应对的词缀章节。
- **2023年3月20日：** 更改了默认天赋树。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月22日：** 因热修增强，将默认构筑改为孤独之冬。
- **2022年12月11日：** 添加了关于孤寂寒冬/水元素选择的说明。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页面上，你将找到许多有用的宏和插件，以便在魔兽世界12.1.5补丁中玩你的 法师 冰霜 时让你的生活更轻松。

1.

### 最佳宏

下面列出的是 法师，特别是 冰霜 法师 的有用宏集合，其中一些可在所有三个专精上使用，而其他则只有在你玩 冰霜 法师 时才有用。

1.1.

#### 法师通用宏

1.1.1.

##### 打断闪现

#### 瞬发闪现

```wow-macro
#showtooltip
/stopcasting
/cast 闪现术
```

按下[[spell:1953]]现在会取消你当前的法术施放并使你立即闪现。注意，这不应该与[[spell:212653]]一起使用，因为它会不必要地取消你当前的施法，也不应该在你施放某个法术时使用，如果你可以等待完成施法再需要闪现的话

1.1.2.

##### 一键格挡

#### 一键 寒冰屏障

```wow-macro
#showtooltip
/stopcasting
/cancelaura 寒冰屏障
/cast 寒冰屏障
```

取消你当前的施法并立即进入 [[spell:45438]]。再次按下 寒冰屏障 会取消该效果。如果你习惯狂按技能键，不推荐使用。

1.1.3.

##### 格挡取消

#### 取消光环寒冰屏障

```wow-macro
/cancelaura 寒冰屏障
```

如果你是狂按按钮的玩家，可以将其放在单独的快捷键上作为你的[[spell:45438]]，让你能够提前取消你的寒冰屏障。

1.1.4.

##### 操控时间 取消

#### 取消光环 操控时间

```wow-macro
/cancelaura 操控时间
```

你可以使用上面的宏来取消 [[spell:342245]]，如果你不想被传送回最初施放 操控时间 时的位置/生命值。

1.1.5.

##### 鼠标悬停驱散

#### 鼠标悬停解除诅咒

```wow-macro
#showtooltip
/use [@mouseover]解除诅咒
```

这将移除你鼠标悬停的任何单位身上的诅咒。你可以将解除诅咒替换为你可能想通过鼠标悬停施放的任何其他法术，例如[[spell:30449]]。

1.2.

#### 冰霜 法师专用宏

#### 光标处 暴风雪

```wow-macro
#showtooltip
/use [@cursor]暴风雪
```

按下此键时，将自动在鼠标光标位置放置[[spell:190356]]，无需实际点击地面。值得注意的是，光标条件可以应用于任何地面目标效果，如下方的[[spell:231596]]宏所示。

1.2.1.

##### Water 元素

#### 在光标处冻结

```wow-macro
#showtooltip
/use [@cursor]冰冻术
```

这个宏可以让你将你的水元素元素的[[spell:231596]]技能放到动作条上，并让它在你的光标位置瞬发，而无需点击。

这些宏允许你管理水元素元素的移动和攻击。

#### 宠物攻击

```wow-macro
/petattack
```

这会命令你的水元素攻击你的目标。

#### 宠物跟随

```wow-macro
/petfollow
```

这会命令你的水元素元素跟随你。

#### 移动至

```wow-macro
/petmoveto
```

这会命令你的水元素移动到你选择的位置。将水元素移到中央位置可能很有帮助，因为水元素有时会站在距离首领很远的地方，首领移动时，它会把时间浪费在追赶首领上。

1.

### 最佳插件

自至暗之夜以来，插件被严格限制读取任何与战斗相关的内容。然而，仍然有少数非常有用的插件，随着开发者找到绕过当前限制的方法，将会有更多插件被创建。随着赛季的进行以及作者最终确定他的界面，此列表将逐步填充建议。

2.1.

#### TargetedSpells

[TargetedSpells](<https://www.curseforge.com/wow/addons/targetedspells>)
是一个有法术瞄准你的警告。通常这能让你知道何时在大秘境清理小怪的混乱中按下 [[spell:414659]] 或 [[spell:11426]]。作为一个身处防御技能被削减时代的 法师，这很可能是你最大的财富。

2.2.

#### ArcUI

[ArcUI](<https://www.curseforge.com/wow/addons/arc-ui>) 是一款以比默认冷却管理器提供更多控制权的方式彻底改造冷却管理器的插件。它确实有一定的复杂性，并且由于是新插件而存在一些缺陷。然而，就冷却管理器美化功能而言，它确实实现了我想要的效果，因此在本列表中占有一席之地。以下是将为你提供我个人使用设置的导入字符串。

#### Kuni's ArcUI

```wow-macro
DEvxSTrwv441BOPdQsjE36u2s3wTaHwY2FStJtmGAR9e7yN4K4m2X5NfA8DM56zUXJNzYCh)lB3fzjQ23qYs8oYpG4vIq7RGIqibpDvEGNyxq5bEz3LkvHaeSiX5oJD(PS9f6dUZ9EpNZ98DoN735KaFOe1gRqdFSIbIs3D(D5l3DMN64To7ct0NAv3rblQJCSNy56MKBC7BSOUf11azQs7XfpRPkU1fosZXQUDbSRlXuJMojQUdsWPUlXG42wORILLHQvttHUvXTLjGUcD5kVkQgwkTdyq7qAgwYiJSkwMdnZupxLqrYg4IG6UeBA5dvmikvlQdxMME5JqkUKg48owvigy2L6A7)fnm7snoKCgl9u5irJoBS4LoCONue3YnSd2KBEv9JgUDHMeBC4EuDRMEFQ3xbWUg2tCwyD7x)ejDrU4seADKbDQ(oyKABVTMQhaKMIwgwoXcjN5HF2tEYpDKrgjKwWqozE4F9bpOmSkjxMYhDoBfwczyRJcilB5OID43Mu8zM7(3)3ESdYuddbAIcY1Y7e2L9(9nMID1WSRN5H)Lk8)PXEtyvGdqgyh3unWMU00hBzk6bHfretSQWbwMjAGigCGl03YmpKjX1ikchzzUHj6KJy3aUHYsnjQU6e2Kc8GRYIGBZVyzDmrt3L012IsCjwMcSVsjzQocqtz20YIPwTykjjfEuiDiuqEGya0hei(Sp6JHfJiJmv0TCy3ojL0bh)586MeEzvVyIqYzIhB(pK9wcSllmaTxtN9McSVwA2xxG9neytjW(MGZkaUi7wchvNIx0Ruubcc6SPbhtGfXZoZ9bJpWqrEr9LOCXdYMrNBPBIbLoaXlqDLqa8cYMmCFtRffxWROOm3SFlm7wHz3bYXbdPDcE4q7t(3F(nGphMCcajLdnTwatrUa6CXLpqNOIx2)Hq5Jrok766qmRID3nY9)zNdREkZ)9La3tW35TYm)FAfEu6()bpDpP8Qc7RgJJQN9(V)W6yEY8Xp(hcRo2VwVMmYDntJ2L7YxxSTnwYM0cBWUwzVxd5Gkp6LoI)zwtxSjuZ0o4xuwCkE(tKt(49asN7eq2asltovx(JYuQAqw9k6SBfdQopn8)S)0FEy4)zx)6pIh(FqsEflppXHxf2BdSgvQqXUBfKnn72S7YU9Gn2(ThHDhVYuq9p9Z)p34uC(P)XpIBxwKW2HiAMwo4eqoCTgyhhihwwoY9ND(iZmf7ncpied1epaE(wbv3WTNcql4Ivt4EtY79DF0XuudSA(bVyO)9X0EqLKU8GLh5zu41sazx(tv3EPOu41lbz0JA546XXgiQJvZa9BqWnXo8ymt438pkXYXwHTAq2AS8mPaS1dELxj(pPI)Ub82TatW7Ka)YHs7VV0O8Jglu)tL2zdFcBqyUkfyxCSjIEgJvKT(f917IxjWh)7o9ePK1HijC7mPGWPJn24FY5v7smPl4RM59oZjBCYnn2yte7CQacZKUeO5yJ)PN3wJ6FjxCSX)SZFWemPl6DqOF15p4YmPVm)Gx9FE(ia3mc)TZew6M0G0PdYr1pI1RIdgZ7irfo0lhLd12QoqQYk9btypoCGlNu1jpsvfAZKBehznXbCE5dEpE1zGqAbc5eORguViz1Ko6b(07INsnYLCMqA8)B(qoER6618cyeZEOHLs1fbL5R07X3FtoLCw7xxTTjciUfh6fEs0N)kjP3vOFS33iLQCF3uv3HAJua)C0(CZKXJcplB6Pc1o)xkA0y3jwSqTGVImh81rdSUpI17JQ7AjHRWBBbLGuISxHsyhov2ARjw2dGaOOxGTbWZYnAMhr(rBcSeVsOwbyAYkE0emzD2Uyg8iE7CJWuXmLrz78)eUyiD27mk779sdqSVFwwfD2J1zKGS88Kb0fH0Hhkma()MU6jZLkDrVl5lW8VZLoRTJ6B7y(2EEUTFSNxcEHYeCpg8tFeT1giGo4vd1kZVEVF8)YJAaGc4jAS9yKrzfpb75)9)IHssp8N7jjxgo8ZEc8ZYuUWld(V2zDX4NZfph87vd5QOVILkokYWOl0iGtrr58Jh66azFSAwxCn6uSVtfoNzoNb9jSdXtEBQJH((49RtSTHjHEoHMas1f5kwWWYTSmf(n7cxThHMh4LHoZ6SVTVHy7ZakAAzM71y1l3B4SauH(kQ1szQd92Xp1(Q(dzjoywhX6uxRAKo8(QMLTh3FSVe22gT97zpCsqokgo)wS(CxTG38fql609GzsuQcnvObz3zPabceuIycm5ba)Qlx0vq0QLTV8zmEMtnG9K(Ue)gEb3zYbtCkXFBiYh2Sa2agdGhRTd7BUHizOZvI9wEDlNmmBUYS3Rm4FS3DOFXEc3Ny)GY2VgeuwfXhTX)nfF23dxbPHHzQ9gb2BCAr4LQBWdhmjR)Q(4w2qxaSAY2j5dHlB7GRqA1lHK4kjkadA5a9JOG)hSNlPgM6IQzFtYbpT(ZFHRSvGUrE3vvfJxqB1KPZkRlNIuevRIy6g1eBAyTKgjX(AwfSkvWjTwAL1lT8ofxzX93dTyUulvlH5Mj2sPz1SUoz2icspxALAXtKoXAlxOsZK5MFHo5u1MVZkjuwOr(6TSSZ0w2OW0ffZ1Mq3p36RhFJ03D9vWAs7NA6TlkAvitXPt0P6I5ZwNKEARuf1Nnw6gRNEUuZSTu89KPBnR2s1svZkxJ1BMsF2nsgZA14Bhj1cBzrtlV4M6wfmLANjUK7ClLmATI7TxYizR3PuHTxjLMz8K5SmY7q1IS)oPKvQ2OU4IQX70WEvLQZJ1ZS)DV3cABvB)kvlUqSsQoK2jlUsdJ5Ap)ETqr1ZTX(4cB3OzdlX1kSJAN43lF0PxF7cLwk7slTQEQuvnMfvyZDwk9Yf3RfnItLonMxS4MlVz7DkusLiTbozvNIRmtToXselw0D2YOzDRksWqbg16F6Fg1)9d
```

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 添加了ArcUI和一个导入代码。
- **2026年3月9日：** 修复了解除诅咒的鼠标悬停宏。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行审查。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为11.0.7进行了审阅。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年4月29日：** 移除了ElvUI，为受难者新增了鼠标指向驱散。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
