## 专精概览

Welcome to our Preservation Evoker guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to heal as a Preservation Evoker in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your output.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Preservation Mythic+ Resources

[NEW! Top Preservation Talent Builds](<https://raider.io/specs/preservation-evoker/talents>)

[Top Preservation Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/evoker/preservation>)

[Preservation Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=evoker--preservation>)

[Popular Preservation Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=evoker--preservation>)

1.

### Preservation Evoker Overview

[Preservation Evoker](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) specializes in stacked environments where they can
make full use of their extremely strong AoE heals. With abilities like
[[spell:355936]] and [[spell:355913]], they can thrive when their party and
raid members are within their small area.

[Preservation Evoker](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) also
brings many forms of utility through a party-wide damage reduction in [[spell:374227]],
raid buffs in [[spell:374968]] and [[spell:364342]], and even
their version of [[spell:80353]] through [[spell:390386]].

Strong Cooldowns, Stronger Healing

Despite lacking a strong raid buff or some of the utility offered by other healers,
Preservation Evoker makes up for it with their healing output. [[spell:363534]]
is by far the strongest healing cooldown in the game, with no theoretical limit
to the amount of healing it can do. The more damage you take, the more healing it
will do, making it incredibly powerful.

Outside of this, Evoker is consistently tuned to be near the top of the
HPS meters as compensation for its limited range and this does not change in
Patch 12.1 where Evoker is expected to be amongst the best healers in terms of HPS.

Exceptional

Preservation Evoker has had an up and down history since being added in Dragonflight.
At times they have been so powerful that you would run two of them while they did
30% more healing than every other healer in the game. Other times they have not seen
any place among the worlds best guilds. In Patch 12.1 you can expect Evokers to be
on the dominant side thanks to their exceptional healing output and powerful raid
cooldowns such as [[spell:363534]], which remains the best healing cooldown in
the game. No matter the level of play, you are guaranteed to see an Evoker in
the healing composition.

Better than Ever

Preservation Evoker has always struggled to be competitive in a Mythic+ setting,
but with changes in Patch 12.1, it looks to be finally challenging the top specs.
The lack of a strong raid buff will hold it back from being the "meta" healer,
but Preservation offers some of the highest damage from any healer paired with
very strong HPS output and solid utility. While it may finally be in a good place,
it can often take a while for public perception to catch up and players may still
find themselves struggling to get into PUG groups compared to the more typical
meta healers.

Niche at Best

Preservation Evoker's biggest weakness is a lack of utility. While [[spell:370665]] can be
valuable and [[spell:374968]] has its niche uses, these are not enough to warrant a high
utility score, especially when compared to other classes. The interrupts
provided from the Dracthyr racial can be nice in a Mythic+ setting and
[[spell:406732]] can be occasionally good, but these do not do much to move
the needle. The strongest piece of utility comes through [[spell:374251]],
which allows you to remove a bleed effect. No other spec can replicate this
besides Holy Paladin with their cooldown [[spell:1022]], the downside
is that bleed dispels are not always useful meaning that this very unique and
powerful piece of utility can be entirely useless at times.

Among the Best

Preservation Evoker has extremely strong survivability, and even better external cooldowns.
Two charges of [[spell:363916]] are extremely powerful, allowing you to chain casts
during very difficult moments. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper players can even use this ability on others
thanks to the [[spell:444322]] talent, giving you an additional external defensive.

This, combined with [[spell:357170]], means that Evoker can provide
some of the best defensives to players in the game. While
[[spell:374227]] only applies to damage labeled as Area-of-Effect, it can still provide
immense value when the situation is right.

The Kings of Movement

Preservation Evoker has by far the best mobility out of any healer in the game.
Being able to [[spell:358267]] constantly is extremely valuable in repositioning
and getting places quickly. This ability also allowing you to cast some spells
while moving ([[spell:361469]] and [[spell:373861]] mainly) provides
nice benefit when combined with the fact that [[spell:364343]] is instant cast.

So no matter what movement is required, you will always be able to maintain your
healing rotation, unlike other healers who can suffer massively when having to move.

2.

### Preservation Evoker in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

With the release of Patch 12.1.5, you will gain access to two new pieces
of endgame content: a new Raid and a new Mega-Delve. For more information on 
these new pieces of endgame content, you can visit our dedicated pages linked below.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

For a full breakdown of 12.1.5 Changes, you can visit our dedicated Hub which
will provide you all the information you need to know whether you have been playing
all expansion long, or you are a returning player.

2.3.

#### Class Changes

In Patch 12.1.5, Preservation Evoker only received one minor change for
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper only. Specifically, [[spell:444088]] had its
healing increased by 20% to offset a recent bug fix that was causing it to 
double dip with healing increases such as [[spell:376239]]. This will not
impact any talent choices or rotational elements.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_temporalanomaly.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class TuningHide Patch 12.1 Class Tuning
[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

In Patch 12.1, Preservation received changes focused on adjusting the power of [[spell:355936]]
while also increasing the power of other abilities to help provide more triage
healing and strengthen its Mythic+ healing output. The most notable changes are
as follows:

- [[spell:355936]] periodic healing has increased significantly but upfront
  healing has been reduced
- [[spell:361469]] direct healing has been increased
- [[spell:360995]] healing has increased

In Season 1, the class struggled significantly at triage healing and dealing
with difficult debuffs. Additionally, [[spell:355936]] had been buffed significantly
to help compensate for the loss of [[spell:373270]]. In return this led to it
losing some of its identity within the kit. These changes are aimed at sending
[[spell:355936]] back to its original identity of being a powerful HoT
effect while also increasing the power of [[spell:361469]] and [[spell:360995]]
to help cover areas where Dream Breath previously did.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Changes to Preservation Evoker

Heading into Midnight, Blizzard wanted to simplify the gameplay of Preservation 
Evoker. One of their goals was to make the spec much more approachable for new 
players while also removing some of the very tight timings that were required to 
execute the spec at a high level. If you are coming back to the game and haven't 
played since a previous expansion, we will break down some of the key changes overall:

- [[spell:373270]] can no longer be replicated to other players through [[spell:364343]].
- [[spell:367226]], [[spell:370960]] and [[spell:371832]] have been removed.
- [[spell:373834]] has changed and now just increases the healing of [[spell:355936]]
  and [[spell:361469]].
- [[spell:443328]] has been removed and [[spell:444088]] has been reworked. Rather than healing
  the entire raid when you proc the effect, you will only heal the player you targetted.
- [[spell:206005]] is a new talent, increasing the healing of [[spell:360995]] and also
  making it so that you do not fly to your target when using Verdant Embrace.
- [[spell:1241704]] is a new talent, granting you an additional charge of [[spell:360995]].
- [[spell:1236776]] returns from The War Within as a new reworked talent. For 15/20 seconds after
  casting [[spell:370537]]/[[spell:359816]], your healing over time is increased and your chance
  to generate [[spell:369297]] is increased by 100%.
- [[spell:355936]] will gain two charges when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper.
- [[spell:376150]] will also now reduce the cooldown of Dream Breath.
- Some other talents have received minor changes or changed positions in the tree.

In addition to these changes, you will gain access to the new Apex Talents as well as 3 new Hero
Talent choices.

2.5.

#### Apex Talent

In Midnight, you will gain access to [[spell:1256577]], the new Apex talent. This ability
has three separate ranks that all increase its power. Below we will break down what each individual rank does.

- Rank 1 — Abilities that consume Essence have a chance to trigger [[spell:1256577]], causing
  your next [[spell:366155]] to be transformed. On top of providing the standard Reversion effects, it will change
  icon and have a spiritbloom-like effect where healing will shoot out and bounce to players.
- Rank 2 — [[spell:366155]] now reduces damage taken by 1% per point and also heals them by 1% per point
  instead. This is both a damage reduction and a heal with the damage reduction portion showing up in damage meters
  as an absorb.
- Rank 3 — [[spell:355936]]s instant healing is increased by a significant amount and each cast will
  trigger [[spell:1256577]], allowing you to reliably proc the passive whenever you cast Dream Breath.

[[spell:1256577]] is an extremely powerful ability massively enhancing the power of [[spell:366155]].
Primarily due to Rank 2, you will want to make sure you have Reversion on as many players as possible, as often as
possible. Due to Merithra's Blessing providing a large burst of healing in addition to all Reversion effects, you can
double dip with [[spell:364343]] usage and this is primarily how you will be aiming to use [[spell:364343]] in Midnight.

2.6.

#### Hero Talent Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper has received two very important changes as we have briefly touched on. [[spell:444088]]
works completely different, no longer triggering an explosion of healing on the entire raid. Consume Flame
will be a much smaller part of your rotation and will matter much less overall. A ton of the value in Flameshaper
will come through the new [[spell:1264269]] talent. This gives you two charges of [[spell:355936]].
Due to Dream Breath always proccing [[spell:1256577]], you can execute consistent ramps and [[spell:364343]]
Merithra's for very large healing.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden will play largely the same as there are no notable changes/additions that should
play a large role in your output. The only one worth noting is [[spell:431715]] which reduces the cooldown
and mana cost of [[spell:373861]]. This makes it incredibly important to keep Temporal Anomaly on cooldown
as much as possible, to maximize the amount of [[spell:364343]]es you generate while 
also outputting a ton of shields.

2.7.

#### Rotational Changes

In Midnight, you can expect significant rotational changes in every form of content. What contributes the
most to these changes are the loss of [[spell:373270]] and [[spell:367226]]. Losing these abilities means
that you will not need to execute very precisely timed ramps in order to achieve your full healing output.
While [[spell:360995]] can still be powerful with [[spell:364343]] for burst healing, you will often find
yourself utilizing Echo with [[spell:366155]] like done in previous patches.

Additionally, [[spell:1242031]] creates an interesting change in the
rotation where it can be highly valuable to press [[spell:355913]] (which has 
received significant buffs in Midnight) with [[spell:369297]] inbetween your ramps to get free [[spell:364343]] casts. 
Previously, you were forced into one or the other but with the Twin Echoes talent you have high flexibility with your rotations.

In Mythic+ settings, the loss of [[spell:367226]] will be even larger and you may find yourself relying on
[[spell:361469]] even more when ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper, you will gain an additional
charge of [[spell:355936]] to help you manage difficult moments. Outside of this though, you will focus on using
[[spell:360995]] for burst healing and [[spell:366155]] and for standard healing.

The final rotational change worth mentioning is for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper specifically. Due to changes to [[spell:444088]],
you will no longer be executing large burst heals on the entire raid. Your gameplay will focus on utilizing [[spell:355936]]
casts for [[spell:1256577]] burst healing and  [[spell:366155]]/[[spell:360995]] otherwise.

3.

### Basics of Preservation Evoker Gameplay

Preservation Evoker, like any healer, is all about using your
abilities strategically. Rather than a fixed rotation, you will be using your flexible
spell kit to adapt and overcome whatever the game throws at you.

This specialization heavily relies on [[spell:364343]] for all builds,
playstyles, and forms of content. [[spell:364343]] provides a minor amount of healing
but more importantly places a buff on players causing your next healing spell to
also trigger on a player with the [[spell:364343]] buff. This allows you to pull off
powerful combos where you can get abilities such as [[spell:366155]] or [[spell:355936]]
on a ton of players at once. Preservation can be broken down further by the following 
three focal points.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_essenceburst.jpg>) **Manage Essence Usage**  
  
  Ensure that you are constantly spending Essence. Whenever you waste Essence by
  overcapping, you miss out on potential [[spell:364343]] casts. This can result
  in a significant healing loss and you struggling to keep up with incoming damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_dreambreath.jpg>) **Keep Abilities on Cooldown**  
  
  Preservation relies on key abilities such as [[spell:355936]] and [[spell:373861]]
  in order to properly function. [[spell:355936]] guarantees you a proc of 
  [[spell:1256577]] and [[spell:373861]] gives you a ton of [[spell:364343]]s. 
  Keeping these abilities on coolodown for an extended period of time will lessen 
  your ability to deal with incoming damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_echo.jpg>) **Consume Echo Correctly**  
  
  Part of the difficulty in [[spell:364343]] is that it can be consumed on accident
  with a wide array of abilities. Doing so will result in a massive loss of healing.
  It is important that you are consistently consuming [[spell:364343]] with [[spell:1256577]]
  in raid. In Mythic+ you have a bit more leeway as [[spell:360995]], [[spell:355936]],
  and [[spell:366155]] can all be good choices.

4.

### How to Gear Up as a Preservation Evoker

While we always recommend simming yourself for ideal results, we do provide a
dedicated Preservation gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** BiS list updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **01 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Minor Fix to Mythic+ roll recommendations.
- **28 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated class tree for raiding builds.
- **25 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Added extra information to bonus roll strategy.
- **23 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated Flameshaper M+ build.
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Minor trinket tier list updates.
- **13 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Added information about Inner Flame.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **03 May 2026 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Recommended stats updated.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **31 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** BiS Trinkets and Trinket tier list updated.
- **31 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Extra rotational information added.
- **31 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Talent recommendations updated.
- **23 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Trinket tier list updated.
- **20 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Extra information added for Emerald Blossom and Verdant Embrace.
- **20 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Talent recommendations updated.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Recommend talents updated.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 (this page):** Updated for Midnight 12.0.1.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **31 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Emerald Blossom build updated.
- **31 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Page overhauled and Emerald Blossom build adjusted.
- **29 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Lifebind information updated.
- **20 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Weapon enchant recommendations updated.
- **14 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Trinket recommendations updated.
- **11 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Minor updates.
- **09 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Rotation updates.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **13 May 2025 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Puzzling Cartel Chip recommendations updated.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Page updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Page updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Page updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Page updated for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Page updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Page updated for Patch 11.1.5.
- **17 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-liberation-of-undermine-raid-guide>)):** Gallywix tips added.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Flameshaper rotation updated for Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Talent recommendations updated for Patch 11.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Cyrces Circlet information added.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Page overhauled.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Reviewed for Patch 11.0.5.
- **07 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** Boss recommendations updated.
- **07 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated Rotation for Chronowarden Echo builds.
- **28 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Specific dungeon tips added.
- **19 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** Talent recommedations and tips added.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Season 1 BiS Gear added.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Season 1 Information added.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **30 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Consumable recommendations updated.
- **30 Aug. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** Page added.
- **27 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Delve build added.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Page Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Page Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Page Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Page Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Page Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Page Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Page Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Page Reviewed and Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Page Reviewed and Updated for The War Within.
- **21 Aug. 2024 (this page):** Page Reviewed and Updated for The War Within.
- **17 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Page Reviewed and Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/preservation-evoker-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Page Updated for War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Page Updated for War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Page Updated for War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Page Updated for War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Page Updated for War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Page Updated for War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Page Updated for War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Page Updated for War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Page Updated for War Within Pre-Patch.
- **20 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Page Updated for War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/preservation-evoker-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/preservation-evoker-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Page updated for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Page updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Page updated for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Page updated for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Page updated for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Page updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Updated for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Page updated for Season 4.
- **22 Apr. 2024 (this page):** Page updated for Season 4.
- **01 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Fixed talent strings for leveling.
- **26 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Talent recommendations updated for 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Talent recommendations updated for 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **08 Feb. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Echo build updated to include Ouroboros.
- **17 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Minor updates to Echo build recommendation.
- **16 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Rotation changes.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Build recommendation updated for 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Rotations updated for 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Build recommendations updated for 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** 10.2.5 changes added.
- **29 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Minor BiS list updates.
- **21 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Weapon enchant recommendation changed.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Embellishment and BiS lists updated for sporecloak nerfs.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 (this page):** Updated for 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** BiS Gear added.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Formatting updates.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Reviewed for Patch 10.1.7
- **08 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Extra information added for Emerald Blossom rotations.
- **19 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Trinket tier list updated.
- **17 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Trinket tier list updated.
- **17 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Minor talent recommendation changes.
- **17 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Minor talent recommendation changes.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **08 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Talent recommendations updated.
- **26 May 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Information about Timewalking trinkets added.
- **20 May 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Embellishment recommendations changed to account for bug fixes.
- **16 May 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Embellishment recommendations updated.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.1.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Updated for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for Patch 10.1.
- **01 May 2023 (this page):** Updated for Patch 10.1.
- **20 Apr. 2023 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Leveling build updated.
- **28 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Primordial Gem recommendations updated.
- **28 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Primordial Gem recommendations updated.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/preservation-evoker-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Reviewed for Patch 10.0.7.
- **31 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Talent recommendation updated slightly.
- **31 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Talent explanations updated.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Talents updated for 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Rotation updated for 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Talents updated for 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **13 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Added Spark of Ingenuity crafting recommendations.
- **28 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Consumable/enchants updated.
- **28 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Moved Haste to be just under Critical Strike in the stat priority.
- **28 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Talent build updated.
- **28 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Rotation updated to include differences between emerald blossom and reversion builds.
- **28 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Talent builds updated.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **15 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** Page added.
- **15 Nov. 2022 ([Legendaries](<https://www.icy-veins.com/wow/preservation-evoker-best-legendaries-shadowlands>)):** Page added.
- **15 Nov. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/preservation-evoker-best-covenants-soulbinds-and-conduits>)):** Page added.
- **15 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** Page added.
- **15 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** Page added.
- **15 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** Page added.
- **15 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** Page added.
- **15 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** Page added.
- **15 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** Page added.
- **15 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** Page added.
- **15 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** Page added.
- **15 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** Page added.
- **15 Nov. 2022 (this page):** Page added.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Preservation Evoker leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Evoker leveling guide](<https://www.icy-veins.com/wow/evoker-leveling-guide>).

1.

### Preservation Evoker Leveling Guide for Midnight

Preservation Evoker is an extremely fast leveling class
largely due to the very high mobility it has compared to other classes.
Not to mention, you also can heal dungeons for a faster
queue time.

At lower levels, you will often have the easiest time leveling up by playing 
Preservation and queueing for dungeons due to the nearly instant queue time.
Even if you find yourself uncomfortable healing, early leveling dungeons are not 
too difficult, so they are a good opportunity to learn!

At higher levels where questing becomes faster and, in some cases, mandatory
(such as the expansion campaign), you will want to spec into
[Devastation Evoker](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-guide>) as it will offer you the most overall DPS, giving
you the fastest possible questing experience.

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level but 2 secondary stats on it
instead of 1.

When using Heirloom items to help increase leveling speed, you will generally
want to use as many **Haste** pieces as possible, to help combat the very
low secondary stats you are likely to have. This will increase the speed of your
rotation and help to prevent things from feeling slow and clunky.

1.2.

#### Useful Leveling Consumables for Midnight

When leveling in Midnight, many of the consumables you used throughout
the War Within will continue to be valuable. Make sure that you always have
a flash active: [[item:212274]]. As well as plenty of potions
that can be helpful: [[item:212265]]. At the end of the expansion
many players will try to sell off their remaining stash of consumables so you can
often find cheap ones to help you speed up your leveling!

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Preservation Evoker Level 80 Midnight Leveling
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2MwwMjZzMGzs9AMAAwMmxMYYmMzMDAAAsNzMTzYmZmxYGAYMDsAWAzwEYhxmhBwMDD"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2MwwMjZzMGzs9AMAAwMmxMYYmMzMDAAAsNzMTzYmZmxYGAYMDsAWAzwEYhxmhBwMDD"
}
```
:::

:::details 来源计算器编码
```
#8W-SsFLLKbTlPpqqXkkjIIHaZBWedgniihEYY-lEkDjFiCQUVlii8iY8qJMmmGXwHAwZH-AAAA-ZaWCSIMQxogwBA-
```

:::

2.1.

#### War Mode Talents for Leveling

Here, you will find information on the best PvP talents
for both leveling and doing solo / small group PvE content.

1. [[spell:377509]] is a powerful cooldown that
   will place a large HoT on yourself and allies.
2. [[spell:378437]] is useful for kiting enemies
   and running away to prevent being staggered.
3. [[spell:370388]] can be useful in moving you and one of
   your party members around.

**等级 20 起：**Preservation Evoker PvP talents do not provide much
benefit to speed up the leveling process. Their sole use is for utility purposes, and overall,
these talents will not greatly improve or hinder your leveling speed.

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider 
to select your level, and watch as the leveling rotation grows with each 
level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 11 起：**Cast [[spell:364343]] to apply the buff to allies and spend Essence.
2. **等级 15 起：**Use [[spell:366155]] on cooldown.
3. **等级 10 起：**Cast [[spell:360995]] for a quick single-target
   heal.
4. **等级 13 起：**Cast [[spell:355936]] to heal your party as long
   as they are within the radius.
5. **等级 17 起：**Cast [[spell:363534]] during massive party-wide damage.
6. **等级 37 起：**Use [[spell:370537]] to store healing and recast it
   whenever your party takes large damage.
7. **等级 10 起：**Heal with [[spell:361469]] when you have no other
   abilities available.
8. **等级 10 起：**Use your DPS rotation (detailed below) if no healing
   is required.

**等级 10 起：**The DPS Rotation is fairly simple and should 
be used when no healing is needed, or you are questing.

1. **等级 10 起：**Use [[spell:357210]] on cooldown for large AoE
   damage.
2. **等级 10 起：**Use [[spell:357208]] on cooldown.
3. **等级 10 起：**Use [[spell:356995]] whenever you have the
   Essence for it.
4. **等级 10 起：**Cast [[spell:361469]] when you have no Essence and
   [[spell:357208]]
   is on cooldown.

Until you get access to more abilities, you may find yourself heavily relying on [[spell:361469]] for healing.
Once you gain access to more spells you can start to add them to your rotation and cast less Living Flames.

While leveling, [[spell:364343]] can realistically be consumed with any abilities, 
but your best choices will be similar to that of Mythic+. Using it on [[spell:366155]] 
will give you strong passive healing, [[spell:360995]] will give you 
more burst healing, and [[spell:355936]] gives you some extra healing over 
time as well. You should experiment with all of them and just get used to pressing 
different kinds of abilities while leveling. The more you experiment, the more you 
learn, and the better you will become once you reach max level.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Page updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Page Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **01 Apr. 2024:** Fixed talent strings for leveling.
- **26 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Apr. 2023:** Leveling build updated.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Preservation Evoker in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Preservation Evoker in Midnight

This section is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

The key to playing Preservation Evoker will come down to frequent
use of [[spell:355936]] and [[spell:373861]], while also spending
Essence on [[spell:364343]], then consuming that [[spell:364343]] with [[spell:1256577]]. 
Outside of this, you can deal damage through [[spell:361469]], [[spell:357208]], 
and [[spell:356995]]. Three quick rules to follow when learning the spec are:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_essenceburst.jpg>) **Manage Essence Usage**  
  
  Ensure that you are constantly spending Essence. Whenever you waste Essence by
  overcapping, you miss out on potential [[spell:364343]] casts. This can result
  in a significant healing loss and you struggling to keep up with incoming damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_dreambreath.jpg>) **Keep Abilities on Cooldown**  
  
  Preservation relies on key abilities such as [[spell:355936]] and [[spell:373861]]
  in order to properly function. [[spell:355936]] guarantees you a proc of 
  [[spell:1256577]] and [[spell:373861]] gives you a ton of [[spell:364343]]s. 
  Keeping these abilities on coolodown for an extended period of time will lessen 
  your ability to deal with incoming damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_echo.jpg>) **Consume Echo Correctly**  
  
  Part of the difficulty in [[spell:364343]] is that it can be consumed on accident
  with a wide array of abilities. Doing so will result in a massive loss of healing.
  It is important that you are consistently consuming [[spell:364343]] with [[spell:1256577]]
  in raid. In Mythic+ you have a bit more leeway as [[spell:360995]], [[spell:355936]],
  and [[spell:366155]] can all be good choices.

2.

### Beginner's Guide to Preservation Evoker in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper   Raid Talents

2.1.

#### Beginner ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Raid Build for Preservation Evoker

This is the recommended Beginner raid built for Preservation Evoker. The focus will be on using
[[spell:373861]] as much as possible while also spending Essence on [[spell:364343]]. With these
[[spell:364343]] buffs, you will consume them with [[spell:366155]] and [[spell:1256577]].

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAwMjZMDGzIzMDAAAwMzMZGzMmtZGAYGzALgFwMMB2MsZYAMzMGA"
}
```
:::

:::details 来源计算器编码
```
#8W-SsFLLKbRRZBYYlPuoIIHjpXWeEnmFF:WDHA-lEkDFCjiUVVUWakiiuSSC2004+829ZC-AAAA-TKMIgpZRxogwBA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper   Dungeon Talents

2.2.

#### Beginner ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Dungeon Build for Preservation Evoker

This build is designed for those who want to play a fairly simple Mythic+ focused build. The benefit
of playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper is that you gain two charges of [[spell:355936]], meaning that you
have a few extra tools available to you. While it can also be difficult to learn, you also gain access
to the very powerful [[spell:444322]].

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WGzYYmxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAjZgFwCYGmAbM2MMAmZGD"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVliiu8qosgYsJAA4877AG-AAAA-TKMIgpZRxogwBA-
```

:::

### Preservation Evoker   Basic Rotation

2.3.

#### Basic Playstyle for Preservation Evokers

Below, we will break down your overall priorities depending
on the form of content you find yourself doing.

2.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Raid Healing

- Cast [[spell:355936]] at Rank 1 Empower and cast it as frequently as you
  can.
- Cast [[spell:373861]] and [[spell:364343]] as much as possible.
- Consume [[spell:364343]] with [[spell:366155]] or [[spell:1256577]] when possible.
- Cast [[spell:360995]] on players in need of single-target healing.

It is important that you only consume [[spell:364343]]s with [[spell:366155]]
or [[spell:1256577]]. Other abilities such as [[spell:355936]] and
[[spell:360995]] only when you do not have any active [[spell:364343]]s.

2.5.

#### 5-Man Healing

- Cast [[spell:355936]] at max rank when dealing with heavy damage or at
  low rank for minor HoT healing.
- Cast [[spell:373861]] and [[spell:364343]] as much as possible.
- Consume [[spell:364343]] with [[spell:366155]] or [[spell:1256577]] when possible.
- Use [[spell:360995]] for quick burst single-target healing. Try to
  use as much as possible and on targets in the most need of large healing.
  Aim to use this with [[spell:364343]] instead of Reversion when it is off cooldown.
- Spam [[spell:361469]] only if the situation is desperate.

2.5.1.

##### Apex Talent: ![Merithra's Blessing Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_boss_valithradreamwalker.jpg>) Merithra's Blessing

In Midnight, you will gain access to [[spell:1256577]], the new Apex talent. This ability
has three separate ranks that all increase its power but not all are important to understand. Below
we will list the two main components you will want to understand.

- Abilities that consume Essence have a chance to trigger [[spell:1256577]], causing
  your next [[spell:366155]] to be transformed. On top of providing the standard Reversion effects, it will change
  icon and have a spiritbloom-like effect where healing will shoot out and bounce to players.
- Each cast of [[spell:355936]]s will trigger [[spell:1256577]], allowing you to reliably proc the 
  passive whenever you cast Dream Breath.

[[spell:1256577]] is an extremely powerful ability massively enhancing the power of [[spell:366155]].
You will want to make sure you have Reversion on as many players as possible, as often as possible. 
Due to Merithra's Blessing providing a large burst of healing in addition to all Reversion effects, you can
double dip with [[spell:364343]] usage and this is primarily how you will be aiming to use [[spell:364343]] in Midnight.

2.5.2.

##### Season 2 Tier Set

The Midnight Season 2 Tier set is fairly straight forward for Preservation Evoker
and focuses on [[spell:360995]]. The bonuses will be listed below.

- [[spell:1296641]] — Consuming [[spell:369297]]
  will fire off a [[spell:361469]] at your target or a nearby injured ally.
- [[spell:1296642]] — [[spell:360995]] will
  now grant an [[spell:369297]]. Additionally, all green spells now restore
  5% more health.

This set is largely passive and will provide you with a nice healing boost.
When desired, you can use [[spell:360995]] as a guaranteed way to generate
[[spell:369297]]. But in most cases, you will often just continue your
rotation as normal but with extra power now.

### Preservation Evoker   Stat Priority

2.6.

#### Stat Priority for Preservation Evoker

The general stat priority for a Preservation
Evoker is seen below. This is very much a rough guideline, and is
designed for players who do not wish to sim their character through 
[QuestionablyEpic](<https://questionablyepic.com/>).
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>).

Intellect

Mastery

Critical Strike

Haste

Versatility

### Blizzard   Combat Assistant

2.7.

#### Combat Assistant

Added in Patch 11.1.7, the combat assistant is a one-button ability intended to cast your rotational
abilities. Unfortunately for healer specs, this does not function well. As a Preservation Evoker, the combat
assistant **will not cast healing spells**. Instead it will only cast [[spell:357208]] and [[spell:361469]].
This creates a unique situation where it is possible to use the Combat Assistant as a single key instead of needing
two keys for each respective ability, but this is not recommended as there are times you will want to Living Flame
without casting Fire Breath, and the Living Flames being cast will only be dealing damage.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Page overhauled.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Page Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Preservation Evoker in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Preservation Evoker

While Preservation has a large amount of competitive choices, our recommendations
focus on ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper which provides you with the largest boost to both
your damage and healing output. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden remains a competitive
alternative, but comes with more intense mana concerns and less output.

- **Raiding -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper further increases the power of
    [[spell:355936]] and gives you extra healing through your [[spell:369297]]s,
    making it particularly strong in a raiding environment.
- **Mythic+ -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper offers you the highest damage
    and healing potential while also providing extra flexibility and unique
    utility. [[spell:1264269]] will grant you two charges of [[spell:355936]],
    and [[spell:444322]] allows you to give a group member [[spell:363916]], albeit
    at reduced effectiveness.

**Quick Start Import Codes:**

:::talents Flameshaper Raiding
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsNzMAYGzALgFwMMB2MsZYAMzMGA"
}
```
:::

:::talents Flameshaper Mythic+
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WmZGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAjZgFwCYGmAbM2MMAmZGD"
}
```
:::

:::talents Chronowarden Raiding
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZwMjBzY2MMzMbYAAgZMjBzYGZmZAAAAmZmJzYmxsNzMAYgxM2YBGYGGawYBGzMAjB"
}
```
:::

:::talents Chronowarden Mythic+
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMz2yAzYmxsZGjx2wAAAzYGzghZyMzMAAAw2MzMNjZmZGjZAAYMjFWgBmhhGGWgxMDAD"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Flameshaper

Raid

Recommended

Mythic+/Delve

recommended

Chronowarden

Raid

Mythic+

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Raid Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper plays very similar to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden builds, but
with a few extra important details you will want to keep in mind. Firstly, you will have
two charges of [[spell:355936]], which means that you can more reliably proc [[spell:1256577]]
for large burst healing. Secondly, [[spell:444322]] will allow you to place [[spell:363916]]
on other players. This, combined with [[spell:357170]], creates a very interesting niche for
Preservation where you are able to offer a ton of external defensive cooldowns.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Mythic+ Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper's main benefit is that you gain an extra charge of [[spell:355936]]
as well as the very strong [[spell:444322]] talent. These extra tools can
make Preservation feel more forgiving, as you will always have some ability available to deal
with whatever the dungeon can throw at you and the party. That being said, Flameshaper lacks some
of the overall power that Chronowarden has in a 5-man party environment.

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Raid Build

When playing a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden build, it is important that you are using
[[spell:373861]] as much as possible to maximize the [[spell:431715]]
effect. You will also want to keep [[spell:370553]] on cooldown as much as possible. To really
gain full value from this Hero Talent tree, you will need to play around the [[spell:394332]]
and [[spell:431657]] effects: each time you cast [[spell:360995]], you get stacking
Haste, meaning that you need to keep using Verdant Embrace as often as possible.

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Mythic+ Build

While ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden turns [[spell:370553]] into a powerful
cooldown, a lot of the value comes from other nodes within the Hero Talent Tree.
[[spell:431875]], [[spell:431442]], and [[spell:431615]] can add
a ton of passive healing. You will also gain extra [[spell:369297]]s through
[[spell:1260568]] and [[spell:364343]] is increased through [[spell:432004]].
Chronowarden is full of powerful talents that increase your output and allow you
to manage difficult windows even when you do not have cooldowns available.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsNzMAYGzALgFwMMB2MsZYAMzMGA"
}
```
:::

:::details 来源计算器编码
```
#8W-KSbsFRRZlqqIIOPXYYpuHjoEWefgiinrhmB-lEFkDjCiKKLNSUVv8mkEFt1Fopx99ZC-AAAA-JckUhpBIQYgxSB-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WmZGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAjZgFwCYGmAbM2MMAmZGD"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVlu8qosgYsJAA4877AWSC-AAAA-TKMIgpZRxogwBA-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZwMjBzY2MMzMbYAAgZMjBzYGZmZAAAAmZmJzYmxsNzMAYgxM2YBGYGGawYBGzMAjB"
}
```
:::

:::details 来源计算器编码
```
#8W-SsFKbRRZBYYlPuoIIHjpXqqWefriihEnOmB-lEkDFCjiUVVUWakii8elkE0BAsppxdC-AAAA-OIoYI0wsEAgUME-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WGzYYmxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAwYGbsADMDDNYsAjZGgxA"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVliiu8qosgYsJAA4877AG-AAAA-OUaAQYMIMUIYpA-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

Below we will recommend you with the best setup, but most bonuses are comparable
in power and you can change them around as you wish. Specifically, [[spell:1279612]]
can be changed out for any other secondary bonus you desire.

- [[spell:1279599]]
- [[spell:1279603]]
- [[spell:1287555]]
- [[spell:1279612]]
- [[spell:1279614]]

3.

### Apex Talent: ![Merithra's Blessing Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_boss_valithradreamwalker.jpg>) Merithra's Blessing

In Midnight, you will gain access to Merithra's Blessing, the new Apex talent. This ability
has three separate ranks that all increase its power. Below we will break down what each individual rank does.

- Rank 1 ([[spell:1256577]]) — Abilities that consume Essence have a chance to trigger Merithra's Blessing, causing
  your next [[spell:366155]] to be transformed. On top of providing the standard Reversion effects, it will change
  icon and have a spiritbloom-like effect where healing will shoot out and bounce to players.
- Rank 2 ([[spell:1256682]]) — [[spell:366155]] now reduces damage taken by 1% per point and also heals them by 1% per point
  instead. This is both a damage reduction and a heal with the damage reduction portion showing up in damage meters
  as an absorb.
- Rank 3 ([[spell:1256689]]) — [[spell:355936]]s instant healing is increased by a significant amount and each cast will
  trigger [[spell:1256577]], allowing you to reliably proc the passive whenever you cast Dream Breath.

Merithra's Blessing is an extremely powerful ability, massively enhancing the power of [[spell:366155]].
Primarily due to Rank 2, you will want to make sure you have Reversion on as many players as possible, as often as
possible. Due to Merithra's Blessing providing a large burst of healing in addition to all Reversion effects, you can
double dip with [[spell:364343]] usage and this is primarily how you will be aiming to use [[spell:364343]] in Midnight.

4.

### Hero Talents

Preservation Evoker gets to pick between two distinct Hero Talent choices:
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper. Both remain competitive
in Raiding and Mythic+, but ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper pulls ahead. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden
can offer strong burst healing and extra Haste to make the spec feel faster, but it
falls behind in both damage and healing output.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden focuses on [[spell:370553]] and [[spell:431695]]
to massively increase your Haste, movement speed, and cooldown reduction. Through [[spell:431875]]
and [[spell:431442]] you gain a nice boost to any Empower spell you cast. This allows you
to have a ton of power tied to your [[spell:355936]] cast. Additionally, [[spell:431715]]
places a ton of power in [[spell:373861]] specifically. Allowing you to constantly output
shields on players while also generating a ton of [[spell:364343]]es.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper grants you an additional charge of [[spell:355936]] and [[spell:357208]].
Given that [[spell:1256577]] (the new Apex Hero Talent) is guaranteed to proc from Dream Breath,
you can constantly setup large ramps where you Dream Breath, cast as many [[spell:364343]]s as possible,
and then consume the Echos with Merithra's Blessing. Finally, you will gain a nice boost of healing through
[[spell:444088]] which you can trigger on players with [[spell:360995]] and [[spell:355913]].

5.

### PvP Talents (War Mode)

War Mode offers several benefits for you in the open world.

- PvP talents enabled in the outdoor world.
- At least 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will be available for open-world PvP, and
the possibility of being "ganked" while leveling or doing World Quests exists.

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of all PvP Talents for
Preservation Evoker.

1. [[spell:378464]] prevents the next 3 crowd control effects on you, making it exceptionally powerful
   when you are in danger of being CC'd. It is important to note that it does have a cast time, meaning you will need
   to cast it when safe.
2. [[spell:378438]] serves as a [[spell:370]], which can be helpful when you are on the offensive
   and attempting to kill someone.
3. [[spell:378437]] massively increases your movement abilities, preventing you from having your
   movement speed reduced during [[spell:358267]]. This allows you to navigate the playing field and reach allies
   much easier.

You can consider the other options essentially down to preference.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **28 Aug. 2026:** Updated class tree for raiding builds.
- **23 Aug. 2026:** Updated Flameshaper M+ build.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Talent recommendations updated.
- **20 Mar. 2026:** Talent recommendations updated.
- **16 Mar. 2026:** Recommend talents updated.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **31 Aug. 2025:** Page overhauled and Emerald Blossom build adjusted.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Talent recommendations updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **27 Aug. 2024:** Delve build added.
- **21 Aug. 2024:** Page Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page updated for Season 4.
- **19 Mar. 2024:** Talent recommendations updated for 10.2.6.
- **08 Feb. 2024:** Echo build updated to include Ouroboros.
- **17 Jan. 2024:** Minor updates to Echo build recommendation.
- **15 Jan. 2024:** Build recommendations updated for 10.2.5.
- **06 Nov. 2023:** Updated for 10.2.
- **04 Sep. 2023:** Formatting updates.
- **17 Jul. 2023:** Minor talent recommendation changes.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **31 Jan. 2023:** Talent explanations updated.
- **24 Jan. 2023:** Talents updated for 10.0.5.
- **28 Dec. 2022:** Talent builds updated.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Preservation Evoker, depending on the type of damage your group
is receiving. We also have advanced sections about cooldowns, procs, etc.
in order to minmax your healing output and your mana efficiency. All our
content is updated for World of Warcraft Patch
12.1.5.

1.

### Preservation Evoker Gameplay and Rotation Guide

Welcome to our Rotation page for Preservation Evokers. On this page,
you will find everything you need to know about actually playing the spec in
Raiding and Mythic+ scenarios.

Each of the sections below explain the rotation for Preservation Evoker depending
on the build you choose and the content you are doing.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden

Raid

Mythic+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper

Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:359816]]

[[spell:370537]]

[[spell:372233]]

[[spell:443177]]

### Preservation Evoker Explained

1.1.

#### General Priority

Preservation Evoker gameplay focuses on buffing players with [[spell:364343]]. When this buff is active on players, the next healing spell you do will also be cast on any player with Echo. The exception to this is [[spell:355913]], which will no longer consume [[spell:364343]]. Generally that will mean that you should consume [[spell:369297]]s with [[spell:355913]] when talented into [[spell:1242031]], to apply even more Echoes to players. Similarly, [[spell:373861]] allows you to spread more Echos.

In [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), [[spell:364343]] usage has simplified significantly and you will almost always be consuming Echoes with [[spell:1256577]] in Raid. In Mythic+ settings you will still be prioritizing [[spell:1256577]] but you will also need to utilize other spells such as [[spell:360995]] to manage burst damage.

### Raid

1.2.

#### Raiding Rotation for Preservation Evoker

Healing as a Preservation Evoker focuses on using [[spell:373861]], [[spell:364343]], and [[spell:355913]] as effectively as possible. In nearly every situation you will be consuming [[spell:364343]] with [[spell:1256577]].

In general, you should be aiming to maximize [[spell:364343]] generation while consuming them with [[spell:366155]] or [[spell:1256577]]. This means casting [[spell:373861]] on cooldown and not wasting any Essence. Keep in mind that you should use [[spell:369297]] with [[spell:355913]] to generate free [[spell:364343]]s thanks to [[spell:1242031]]. Outside of this, maintain abilities on cooldown.

When you have absolutely nothing to do and no Essence to spend, you should aim to cast [[spell:361469]] on enemies to generate [[spell:369297]]s. Because you cast it offensively, it will refund some of the mana cost. Using it for healing can often be very costly. Additionally, make sure that you are making frequent use of [[spell:357208]] to trigger [[spell:369939]], allowing you to generate even more [[spell:369297]]s.

Your overall priority will be as follows:

- **适用条件：Chronowarden（启用）；Stasis（启用）。** Keep [[spell:370537]] on cooldown and aim to combine it with [[spell:370553]].
- **适用条件：Flameshaper（启用）；Stasis（启用）。** Keep [[spell:370537]] on cooldown.
- **适用条件：Chronowarden（启用）；Stasis（未启用）。** Use [[spell:370553]] as often as possible.
- Keep [[spell:373861]] on cooldown as much as possible.
- Keep [[spell:355936]] on cooldown as much as possible to guarantee procs of [[spell:1256577]]. Remember that 
  you will want to cast this at Rank 1.
- Consume [[spell:369297]]s with [[spell:355913]] to trigger [[spell:1242031]].
- Cast as many [[spell:364343]]s as possible, whenever you have the Essence to do so.
- Consume [[spell:364343]]s with [[spell:1256577]]. (if you mess up and do not have Merithra's, you can consume them with [[spell:366155]])
- Cast [[spell:360995]] after finishing a ramp and when you have no Essence available.
- **适用条件：Lifespark（启用）。** Cast [[spell:357208]] as much as possible between ramps. Use a [[spell:443177]] proc with [[spell:369939]] for healing. Line this up with big damage windows when possible.
- **适用条件：Lifespark（未启用）。** When you have nothing to do, cast [[spell:357208]] to trigger [[spell:369939]] which you can use to help you generate [[spell:369297]]s.
- **适用条件：Energy Loop（启用）。** Consume Essence with [[spell:356995]] when no healing is needed to regen mana.

Each ramp should be done with [[spell:355936]] in mind, because this is what guarantees us a proc of [[spell:1256577]]. If you are in a situation where it is off cooldown but you have [[spell:1256577]] proc, then you should quickly spend your proc in order to restart your ramp with [[spell:355936]]. If you are completely out of Essence and just completed a ramp, you will more than likely have procs of [[spell:369297]] that you can begin using before your next [[spell:355936]]. If you have no procs of [[spell:369297]] you should instead start casting [[spell:360995]] and [[spell:361469]] to generate procs until your [[spell:355936]] is off cooldown.

:::details TipsGet the most out of Inner Flame!
Going through your typical rotation, you have been told to cast

[[spell:355913]]

when you have

[[spell:369297]]

. While this continues to be true during

[[spell:1242745]]

, it is important to know that you will focus primarily on

[[spell:355913]]

over

[[spell:364343]]

for the duration. To understand this, we must first understand how

[[spell:1242745]]

works. After casting

[[spell:370537]]

, you gain access to Inner Flame which increases HoT healing but more importantly causes

[[spell:361469]]

and

[[spell:366155]]

to have a 100% increased chance to generate an

[[spell:369297]]

. Next, consider our tier set:

[[spell:1296641]]

. When you consume an

[[spell:369297]]

you shoot out a

[[spell:361469]]

. With

[[spell:1242745]]

active, our tier set bonus will give us an

[[spell:369297]]

gives us the ability to cast a large amount of

[[spell:355913]]

s back to back assuming that we are lucky enough with procs. You will want to prioritize casting as many

[[spell:355913]]

s as possible during this window.
In order to help minimize the chances that you run out of

[[spell:369297]]

s due to getting unlucky, there are a few things you can do to prepare. Firstly, you should aim to cast a max rank

[[spell:357208]]

before casting

[[spell:370537]]

. This will give you

[[spell:369939]]

which you can use when you run out of procs during

[[spell:1242745]]

. Additionally, you can always use a quick

[[spell:373861]]

+

[[spell:1256577]]

(or

[[spell:366155]]

) to quickly generate more procs. There will be situations where you find yourself running low or completely empty on procs, and you should always have a plan of how to quickly get them before your

[[spell:1242745]]

window ends.
To summarize everything, focus on casting as many

[[spell:355913]]

s as possible during

[[spell:1242745]]

and if you run out of procs do not forget to utilize

[[spell:369939]]

and

[[spell:373861]]

as ways to quickly generate more.

:::

:::details FAQHow much should I cast Emerald Blossom?
You will want to cast

[[spell:355913]]

with every

[[spell:369297]]

proc. With changes in

[Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>)

, Emerald Blossom will no longer
consume

[[spell:364343]]

. Additionally,

[[spell:1242031]]

causes every Emerald
Blossom cast to give you a buff stacking two times. This buff causes

[[spell:364343]]

to apply to an additional player. With this, you can safely use Emerald Blossom
in your healing rotation while also not impacting your ability to get Echoes
out for large damage windows. That being said, Emerald Blossom has a very high
mana cost and is 1 Essence more expensive than Echo, meaning that you should only
cast it when you have

[[spell:369297]]

active. This will allow you to gain
a significant amount of extra healing while also not impacting your mana.

:::

**适用条件：Chronowarden（启用）。**

:::details FAQHow much should I cast Verdant Embrace?
Utilizing

[[spell:360995]]

effectively can be difficult. In general
you will want to prioritize using this ability in-between ramps. There are two
difference sequences to cast it depending on whether or not you have a

[[spell:369297]]

proc.

- [[spell:369297]] proc — Finish your ramp by casting [[spell:1256577]].
  Follow that by spending your [[spell:369297]] on [[spell:355913]].
  Cast a single [[spell:364343]]. Cast [[spell:360995]] which will consume the
  two Echoes (from [[spell:364343]] cast and the [[spell:1242031]] proc). This will
  give you the max stacks of [[spell:431657]]. Start your next ramp by casting
  [[spell:355936]] and begin generating [[spell:364343]]s.
- No [[spell:369297]] proc — Finish your ramp by casting [[spell:1256577]].
  Cast [[spell:360995]] followed by [[spell:355936]] to start a new ramp.

Keep in mind that you will often find yourself unable to do this on cooldown.
It is simply too expensive and you will often find yourself with little downtime
between ramps. When deciding whether or not you should do this you will want to
ensure that you just casted

[[spell:1256577]]

and are completely out
of Essence. This means that you can quickly cast

[[spell:360995]]

without
missing out on any

[[spell:364343]]

s that could've been included in your previous ramp.

:::

**适用条件：Stasis（启用）；Flameshaper（启用）。**

:::details FAQHow should I use Stasis?
The best way to utilize

[[spell:370537]]

can be difficult because it will require you to have both charges of

[[spell:355936]]

available. You will need to pool your charges to ensure they are off cooldown as

[[spell:370537]]

is coming off cooldown. The idea combo will look like:

- Activate [[spell:370537]] and cast [[spell:355936]].
- Cast your second [[spell:355936]] charge..
- Cast [[spell:373861]] as your final [[spell:370537]] spell.

After you store all 3 spells in your

[[spell:370537]]

, you should focus on maximizing

[[spell:1242745]]

by casting as many

[[spell:355913]]

s as you can and generating

[[spell:369297]]

procs through

[[spell:369939]]

and

[[spell:373861]]

+

[[spell:1256577]]

.

:::

**适用条件：Stasis（启用）；Chronowarden（启用）。**

:::details FAQHow should I use Stasis?
Using

[[spell:370537]]

with

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden

can be a bit simpler than

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper

. You will be wanting to cast

[[spell:355936]]

,

[[spell:373861]]

, and then either

[[spell:355913]]

or

[[spell:364343]]

.

- Activate [[spell:370537]] and cast [[spell:355936]].
- Cast [[spell:373861]] as your second spell..
- If you have an [[spell:369297]] or extra Essence, cast [[spell:355913]]. Otherwise cast [[spell:364343]].

After you store all 3 spells in your

[[spell:370537]]

, you should focus on maximizing

[[spell:1242745]]

by casting as many

[[spell:355913]]

s as you can and generating

[[spell:369297]]

procs through

[[spell:369939]]

and

[[spell:373861]]

+

[[spell:1256577]]

.

:::

### Mythic+

1.3.

#### Mythic+ Rotation for Preservation Evoker

[Preservation Evoker](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) does not have strong spammable heals that can be used when times get tough. [Holy Priest](<https://www.icy-veins.com/wow/holy-priest-pve-healing-guide>)s can spam [[spell:2060]], and [Restoration Shaman](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-guide>)s can spam [[spell:1064]], but [Evoker](<https://www.icy-veins.com/wow/evoker-class-overview-dragonflight>)'s only similar button is [[spell:361469]], which is quite weak. To excel at Preservation in Mythic+, you must think of your many cooldowns and how you can rotate them for every damage event.

You will generally want to ensure that you are constantly spending your Essence, keeping [[spell:373861]] on cooldown, and making frequent use of key abilities such as [[spell:355936]] and [[spell:360995]]. Additionally, the new Apex talent: [[spell:1256577]] provides us another great source of burst healing to manage difficult moments.

Your overall priority will look something like this:

- **适用条件：Chronowarden（启用）。** Cast [[spell:364343]] to prepare for damage.
- Keep [[spell:373861]] on cooldown at all times.
- Keep [[spell:366155]] on your party members when damage is going out to gain
  extra healing through [[spell:376239]].
- Cast [[spell:355936]] at Rank 1 in most cases. Higher ranks can be used in truly emergency situations where players may die without the additional healing.
- **适用条件：Flameshaper（启用）。** Cast [[spell:355913]] to trigger [[spell:444088]] and other effects anytime AoE healing is needed.
- When significant spot healing is needed [[spell:361469]] can be used if you have a [[spell:443177]] proc. Just keep in mind that this will be very expensive mana wise.
- Make frequent use of [[spell:357208]] for not only damage purposes
  but to also generate extra [[spell:369297]] and proc [[spell:369939]].
- **适用条件：Energy Loop（启用）。** When absolutely no healing is needed, you can consume Essence on [[spell:356995]] for additional damage.

In order to further understand the Mythic+ rotation, you should also understand the main ways that you will 
be consuming [[spell:364343]]:

- **适用条件：Chronowarden（启用）。** [[spell:355936]] — With increases to the Dream Breath HoT effect, it can be very beneficial to maintain this HoT on players at all times. With so many [[spell:364343]]s at your disposal, it should not be overly difficult to [[spell:364343]] this ability on cooldown.
- **适用条件：Flameshaper（启用）。** [[spell:355936]] — With [[spell:444088]] being buffed, this ability now becomes your most important one to [[spell:364343]]. When you have both [[spell:355936]]s on players, [[spell:355913]] will trigger the [[spell:444088]] on both, leading to massive burst healing. You should aim to always [[spell:364343]] [[spell:355936]] when it is off cooldown.
- [[spell:1256577]] — This ability will proc from spending Essence and after casting [[spell:355936]]. When you consume [[spell:364343]] with this ability, you gain a ton of burst healing while also placing [[spell:366155]] on every player who had [[spell:364343]] on them. This gives every benefit of [[spell:366155]] (think [[spell:378196]]). This is your easiest way to get good group healing and maintain [[spell:366155]]s.
- [[spell:360995]] — Using this ability to consume your [[spell:364343]]
  will allow you to do quick burst healing. Due to Evoker struggling with single-target
  healing specifically, being able to Echo this ability during difficult moments will be
  very valuable.
- [[spell:366155]] — Keeping the passive healing on your will make every pack more manageable, as well as providing the [[spell:376239]] buff. Thanks to [[spell:378196]], it can be very powerful in terms of overall healing and also dealing with burst damage. After your party takes large damage, Golden Hour by itself can provide a ton of extra
  healing. Generally, you will be getting all of these effects from [[spell:1256577]] which means that you won't cast as many [[spell:366155]]s as you did in previous expansions. It falls behind [[spell:360995]] for that reason as well.

In general, your gameplay will focus on constantly getting [[spell:364343]]s out on players through [[spell:373861]], keeping your party covered in [[spell:355936]] HoTs, and triggering [[spell:444088]] with [[spell:355913]] when you need AoE healing. Consuming Echo will always be situational and you will often find yourself rotating through the different abilities based on what you have available. Maintaining [[spell:366155]]s will always be important similar to [[spell:355936]] HoTs, and you can use [[spell:360995]] for additional burst healing.

:::details FAQHow should I use Stasis?
Choosing the best spells for

[[spell:370537]]

is largely situational.

[[spell:355936]]

,

[[spell:373861]]

,

[[spell:1256577]]

,

[[spell:360995]]

and

[[spell:355913]]

are all powerful choices you will want to be deciding between. We will recommend the following Stasis combo:

- Activate [[spell:370537]] and start with a strong spell: [[spell:355936]].
- Follow this cast with [[spell:373861]] in order to get [[spell:364343]]s on your party.
- Cast [[spell:1256577]] or [[spell:360995]] as your final spell to consume the [[spell:364343]]s and provide a large burst of healing to your party.

With this combo, you are able to output a quick amount of AoE healing by consuming

[[spell:364343]]

s generated by

[[spell:373861]]

on

[[spell:1256577]]

. In the event that

[[spell:355936]]

is on cooldown, you can change the order of spells. You will just want to make sure that you always cast

[[spell:373861]]

followed by a strong spell:

[[spell:1256577]]

/

[[spell:360995]]

. As long as you have this combo, you can realistically put a wide variety of spells in your

[[spell:370537]]

as the third spell.

:::

**适用条件：Flameshaper（启用）。**

:::details FAQHow do I use Emerald Blossom?
[[spell:355913]]

has gone from an ability we never press in Mythic+ to one that we rely heavily on which can be a change for many players. Buffs to

[[spell:444088]]

and changes to

[[spell:370062]]

has caused this ability to skyrocket in value. You will aim to use

[[spell:355913]]

as much as possible to deal with group wide damage, but that means you also need to maintain

[[spell:355936]]

s on players. And while this ability is your primary way of healing, you will still want to maintain

[[spell:366155]]

s on players through

[[spell:1256577]]

and use

[[spell:360995]]

for quick burst and single-target healing.

:::

2.

### Midnight Season 2 Tier Set

The Midnight Season 2 Tier set is fairly straight forward for Preservation Evoker
and focuses on [[spell:360995]]. The bonuses will be listed below.

- [[spell:1296641]] — Consuming [[spell:369297]]
  will fire off a [[spell:361469]] at your target or a nearby injured ally.
- [[spell:1296642]] — [[spell:360995]] will
  now grant an [[spell:369297]]. Additionally, all green spells now restore
  5% more health.

This set is largely passive and will provide you with a nice healing boost.
When desired, you can use [[spell:360995]] as a guaranteed way to generate
[[spell:369297]]. But in most cases, you will often just continue your
rotation as normal but with extra power now.

3.

### Class and Spec Mechanics Explained

In this section, important mechanics, interactions, and gameplay elements
will be explained in depth to help you better understand how to play the class
at an advanced level.

### Echo

3.1.

#### Echo

[[spell:364343]] is the most core ability of Preservation Evoker. When cast on an ally,
players will gain the [[spell:364343]] buff. Anytime you have an Echo buff active, the next healing
spell you cast will also be cast on any player with an Echo at that moment. This does not apply
to major cooldowns such as [[spell:363534]], but any core ability can Echo.

Below we will break down the ways that you can use [[spell:364343]]:

- **[[spell:366155]]**  
  
  [[spell:366155]] continues to be one of the most common and strongest methods of consuming
  [[spell:364343]]. While it provides a consistent source of healing, it also benefits from many
  different talents. Specifically: [[spell:378196]] will also applying to any target who received
  [[spell:366155]] from [[spell:364343]], adding even more power to this ability. In Mythic+ and Raiding
  it has also become a staple due to [[spell:376239]], allowing you get the extra healing bonus
  on many different targets.
- **[[spell:1256577]]**  
  
  In [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), [[spell:1256577]] is the new Apex Hero Talent. This ability is procd
  from [[spell:355936]] and Essence abilities. It offers quite a large amount of burst healing that
  is entirely controllable since you can reliably proc it through [[spell:355936]]. In Midnight,
  this will be one of if not your strongest choice for consuming [[spell:364343]]s in both Raid and Mythic+.
- **[[spell:360995]]**  
  
  Without [[spell:373270]], [[spell:360995]] has lost a bit of its power. With buffs to its healing,
  it remains a solid choice for burst healing, especially in Mythic+. In raid it will often fall behind 
  [[spell:1256577]] due to Merithra's also providing the [[spell:366155]] benefits to the player,
  giving you both styles of healing at once. But that being said, when you are in need of the burst healing
  and do not have access to Merithras at a given moment, it can be powerful.
- **[[spell:355936]]**  
  
  [[spell:355936]] has typically fallen behind [[spell:366155]] due to the extra effects granted by
  [[spell:366155]] and that continues to be the case. Where it gains most of its value is in Mythic+
  settings where you already have Reversion on a ton of players, so by using [[spell:364343]] on Dream Breath,
  you are just applying even more HoT effects on your group, making it easier to manage constant damage.
- **[[spell:355913]]**  
  
  In [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), **[[spell:355913]] no longer consumes echo.**This means that you can continue
  to cast [[spell:355913]] without interrupting any ramps you are doing. Many builds will make
  frequent use of this ability in both Mythic+ and Raid now that you no longer have to worry
  about it consuming your [[spell:364343]]s.
- **[[spell:361469]]**  
  
  You should only every consume [[spell:364343]] with [[spell:361469]] during truly desperate single-target healing
  moments. This should never be done in raid and is primarily a Mythic+ situation where you do not have access at
  that moment to stronger spells.

While spending Essence on [[spell:364343]] is great, most of your [[spell:364343]]s
will come through [[spell:373861]] It is incredibly important that 
regardless of build you are pressing this ability as much as possible for not only 
the Echoes but the shields as well.

### Essence and Essence Burst

3.2.

#### Essence and Essence Burst

In addition to Mana, Preservation Evoker has Essence as an additional resource that will need to be managed. As is the
case with any Healer, you will want to avoid wasting Essence as much as possible, but sometimes it is unavoidable when
you are facing downtime where not much is happening. There are three different abilities that you can consume Essence on:

- **[[spell:364343]]**  
  
  Costing 2 Essence, [[spell:364343]] will be your primary way of spending Essence. It is the foundation of
  Preservation Evoker gameplay, allowing you to execute large ramps or output a ton of healing at once.
- **[[spell:355913]]**  
  
  Costing 3 Essence, [[spell:355913]] provides a solid amount of healing to a player and anyone else
  within the radius of its effect. In [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), this ability no longer directly competes with Echo
  when you are running the [[spell:1242031]] talent. Allowing you to cast [[spell:355913]] and not miss out
  on potential [[spell:364343]] buffs. Additionally, Emerald Blossom **will no longer consume active [[spell:364343]]s.**.
- **[[spell:356995]]**  
  
  [[spell:356995]] is your way of dealing damage through Essence. By itself this ability is quite weak, but when
  combined with the [[spell:372233]] talent, it becomes a nice way to deal damage, spend extra Essence, and generate
  Mana. In most raid builds, you won't take this talent meaning that you almost never press [[spell:356995]], but
  in Mythic+ it is a staple.

Now that these abilities have been discussed, it is important to discuss [[spell:369297]] and how they are generated.
Below we will discuss the main things that you will want to keep in mind:

- **[[spell:361469]] and [[spell:366155]]**  
  
  Both [[spell:361469]] and [[spell:366155]] have a chance to generate a [[spell:369297]] when cast.
  Typically you will find yourself using [[spell:361469]] for damage in downtime as it will refund some of
  the mana cost when used offensively, also giving you the opportunity to generate Essence Bursts during downtime.
  [[spell:366155]] is one of our most commonly used abilities, meaning that you are constantly feeding into a cycle
  of spending Essence, generating Essence Burst, and then consuming to continue the process.
- **[[spell:369939]]**  
  
  When talented into [[spell:369939]], your [[spell:357208]] will cause your next [[spell:361469]] to cast
  on multiple targets (increasing based on the rank at which you cast Fire Breath). Casting a max rank [[spell:357208]]
  followed by [[spell:361469]] is a sure-fire way to generate 1-2 [[spell:369297]].
- **[[spell:1236776]]**  
  
  While not taken in every build, the [[spell:1236776]] talent is triggered by casting either [[spell:370537]] or [[spell:359816]].
  Once triggered, for a short duration you will generate increased [[spell:369297]]s.

When spending [[spell:369297]], there are multiple factors that you want to consider. 
[[spell:355913]] and [[spell:356995]] have a 3-Essence cost compared to 
[[spell:364343]]s 2 cost. This makes it more efficient to consume Essence Bursts with 
either Emerald Blossom or Disintegrate.

That being said, we are often not casting [[spell:356995]] in raid, 
making our choice a bit easier. [[spell:364343]] will help us to get out additional 
Echoes needed to execute a large ramp in a quick fashion, but again costs must 
be considered. [[spell:355913]] has a very high mana cost, furthering 
the effectiveness of casting it with an [[spell:369297]] proc.

Not to mention, when you are using [[spell:1242031]], which is common in
most builds, you are effectively getting both [[spell:364343]] and [[spell:355913]] at once, making it
the correct choice in most situations. Of course if you are aiming to execute a quick ramp it can be
faster to just cast [[spell:364343]], but you will again want to be flexible
in your approach and how you decide to consume your [[spell:369297]]s.

### Apex Talent - Merithra's Blessing

In Midnight, you will gain access to [[spell:1256577]], the new Apex talent. This ability
has 3 separate ranks that all increase its power. Below we will break down what each individual rank does:

- Rank 1 — Abilities that consume Essence have a chance to trigger [[spell:1256577]], causing
  your next [[spell:366155]] to be transformed. On top of providing the standard Reversion effects, it will change
  icon and have a spiritbloom-like effect where healing will shoot out and bounce to players.
- Rank 2 — [[spell:366155]] now reduces damage taken by 1% per point and also heals them by 1% per point
  instead. This is both a damage reduction and a heal with the damage reduction portion showing up in damage meters
  as an absorb.
- Rank 3 — [[spell:355936]]'s instant healing is increased by a significant amount and each cast will
  trigger [[spell:1256577]], allowing you to reliably proc the passive whenever you cast Dream Breath.

[[spell:1256577]] is an extremely powerful ability massively enhancing the power of [[spell:366155]].
Primarily due to Rank 2, you will want to make sure you have Reversion on as many players as possible, as often as
possible. Due to Merithra's Blessing providing a large burst of healing in addition to all Reversion effects, you can
double dip with [[spell:364343]] usage and this is primarily how you will be aiming to use [[spell:364343]] in Midnight.

4.

### Important Cooldowns for Preservation Evoker

### [[spell:370537]]

4.1.

#### Stasis

[[spell:370537]] is an extremely powerful cooldown in both Raiding and Mythic+. When activated,
this cooldown will store the next 3 healing spells that you cast. Any damage spells or major cooldowns
such as [[spell:363534]] will not be stored. You have an infinite amount of time to store spells, but once
3 spells have been stored, you will have only 30 seconds to either reactivate the ability or they it will
reactivate itself.

It is important to note that the order in which you stored the abilities is also the
order in which they will be cast once you reactivate the ability. This is specifically relevant for 
[[spell:373861]]. If you were to cast [[spell:373861]] at the start of your 
[[spell:370537]], then the free Echoes would be instantly consumed by your next spell.

For that reason it is always best to end your [[spell:370537]] with
[[spell:373861]], rather than casting it early and wasting the Echoes.

Below we will break down some common [[spell:370537]] you may see:

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper: [[spell:355936]], [[spell:355936]], [[spell:373861]].
  Given that you are able to have two charges of Dream Breath through [[spell:1264269]],
  you will want to have two charges pooled for each Stasis use, giving you powerful burst HoT coverage
  and a guaranteed [[spell:1256577]].
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden: [[spell:355936]], [[spell:373861]], [[spell:355913]].
  This combo gives you a guaranteed [[spell:1256577]] proc and extra [[spell:364343]]s
  to help jumpstart a new ramp.
- Mythic+ AoE burst: [[spell:355936]], [[spell:373861]], [[spell:360995]].
  Utilizing this combo provides you with immediate group wide burst and a [[spell:1256577]]
  proc that you can utilize after for more group healing.
- Pre-Pull Cheese: [[spell:373861]], [[spell:373861]] and [[spell:373861]]. 
  This can be useful if done right before pulling a boss, allowing you to quickly 
  generate massive shields on your raid at the start of a fight. Keep in mind that 
  you will want to only cast the first 2 [[spell:373861]] and wait until 
  you are pulling to cast the 3rd so your [[spell:370537]] doesn't expire early.

It is also important to note that [[spell:370537]] will preserve the targets you originally casted the healing
spell on. In other words, if I cast [[spell:355913]] on my co-healer "Youtee" during my Stasis storing phase,
when I reactivate Stasis the ability will again be cast on "Youtee".

### [[spell:363534]]

4.2.

#### Rewind

[[spell:363534]] should be used after an extremely heavy damage window. Its
healing is determined by how much damage you have taken in the last 5 seconds,
meaning the more that your raid or party took, the more it will heal. This
cooldown is one of the few true emergency buttons that [Preservation Evoker](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>)s have;
you should use it as best you can in truly dire situations.

One of the most common mistakes that players make is holding [[spell:363534]] for too long.
While it is an extremely powerful cooldown, you should still aim to use it anytime you are
falling behind. Using it proactively when you begin struggling will prevent you from having
to scramble to catchup later.

### [[spell:359816]]

4.3.

#### Dream Flight

[[spell:359816]] is a powerful cooldown but shares a choice node with [[spell:370537]],
which makes it significantly less seen. It can be a viable choice for players who do not want
to deal with the [[spell:370537]] mechanics, but it will often be worse.

[[spell:359816]] has two main mechanics you need to keep in mind. First, it will deal
large healing on the initial cast while you are flying over players. This means that you should
aim to use it in situations where you can get strong value from the initial healing portion.

Additionally, it will leave a long HoT on any players hit meaning that it can be good for extended
damage windows. Ideally, you are casting this ability in situations where both areas of the healing
are powerful, but this is not always achievable and you should still aim to use the ability as much
as possible.

### [[spell:370553]]

4.4.

#### Tip the Scales

[[spell:370553]] gains most of its value through ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden.
While ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper will still have access, the only benefit comes in being able
to quickly get max rank empowers off.

As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden, you gain access to [[spell:431695]] which provides you
with a large amount of haste, movement speed, and cooldown reduction that decreases every
second over the duration. With most of the power being front-loaded, you want to ensure that
you are using this ability right away during difficult movements to massively empower you.
Because [[spell:1260484]] also reduces the duration by 30 seconds and the long duration
of the buff itself, it is important that you are making frequent use of it.

### [[spell:374227]]

4.5.

#### Zephyr

[[spell:374227]] causes you and your 4 closet allies to take 20% reduced
Area-of-Effect damage for 8 seconds. Given that this only targets your 4 closest
allies, it will be easier to use in Mythic+ than raid. However, you will still want
to make active use of it when you know that you are going to take a large AoE
hit in the next few seconds. Not every damage event is considered AoE, so you
must have a good understanding of what type of damage you will be
taking to ensure you do not waste the effects of the ability.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **13 Aug. 2026:** Added information about Inner Flame.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Extra rotational information added.
- **20 Mar. 2026:** Extra information added for Emerald Blossom and Verdant Embrace.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **31 Aug. 2025:** Emerald Blossom build updated.
- **29 Aug. 2025:** Lifebind information updated.
- **09 Aug. 2025:** Rotation updates.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Flameshaper rotation updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **07 Oct. 2024:** Updated Rotation for Chronowarden Echo builds.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Page Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **16 Jan. 2024:** Rotation changes.
- **15 Jan. 2024:** Rotations updated for 10.2.5.
- **06 Nov. 2023:** Updated for 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **08 Aug. 2023:** Extra information added for Emerald Blossom rotations.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Rotation updated for 10.0.5.
- **28 Dec. 2022:** Rotation updated to include differences between emerald blossom and reversion builds.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Preservation Evoker in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Preservation Evoker

Welcome to our Preservation Evoker Gear page for
Midnight. Check this page to learn everything
you need to know about gearing a Preservation Evoker, including the
BiS Gear from all sources, Raiding, and Mythic+, information on the best Trinkets, Tier Sets, and
much more. Keep in mind that with Midnight comes a stat squish, meaning that each 
item will provide significantly less stats than it once had. Your overall damage and healing
will also be lowered as a result.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest HPS setup from all sources for Preservation Evoker. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [QuestionablyEpic](<https://questionablyepic.com/>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, you are able to convert any item to a tier piece and it'll keep its original stats and effects! This means that your offpiece no longer matters as much.

[[item:268231]]

,

[[item:271876]]

, and

[[item:268237]]

will always be desired due to their higher item levels, but your other 2 remaining tier slots can change depending on what gear you have available.

- **Helm:** [[item:159374]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **Shoulders:** [[item:268231]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Chest:** [[item:271876]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **Gloves:** [[item:281238]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Legs:** [[item:268237]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details FAQWhat to Get From The Great Vault?
With [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) being able to be taken from the Great Vault instead of an item, you will prioritize getting these bonus rolls with your first vault. This will allow you to roll for an item on any dungeon or boss and receive a 1/6 Myth track version of the item. Because [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) drops us Myth track [[item:271092]] from Heroic, you will prioritize the bonus rolls to get this BiS item well before you have a chance to kill the boss on Mythic. By bonus rolling the boss you can also get access to [[item:268265]] and [[item:271876]]. Keep in mind that dropped items from Mythic will be at 9/6 Mythic though, whereas bonus-rolled items cap out at 6/6.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271504@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></div></td></tr><tr><th>Bracers</th><td>[[item:268217@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251191@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest HPS setup from all sources for Preservation Evoker. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [QuestionablyEpic](<https://questionablyepic.com/>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, you are able to convert any item to a tier piece and it'll keep its original stats and effects! This means that your offpiece no longer matters as much.

[[item:268231]]

,

[[item:271876]]

, and

[[item:268237]]

will always be desired due to their higher item levels, but if you are unable to acquire these items from raid, you can instead get these items from Mythic+:

- **Helm:** [[item:159374]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **Shoulders:** [[item:239049]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **Chest:** [[item:159370]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **Gloves:** [[item:251165]] from [The Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- **Legs:** [[item:159375]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Drops one of the best dungeon trinkets: [[item:250214@JAACAAgNyA]].
- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): Drops many good items that you can catalyze for tier.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:251155@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271499@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271500@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271504@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250214@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Bracers</th><td>[[item:273775@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:160216@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251191@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest HPS setup from all sources for Preservation Evoker. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [QuestionablyEpic](<https://questionablyepic.com/>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, you are able to convert any item to a tier piece and it'll keep its original stats and effects! This means that your offpiece no longer matters as much.

[[item:268231]]

,

[[item:271876]]

, and

[[item:268237]]

will always be desired due to their higher item levels, but your other 2 remaining tier slots can change depending on what gear you have available.

- **Helm:** [[item:251220]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **Shoulders:** [[item:268231]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Chest:** [[item:271876]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **Gloves:** [[item:281238]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Legs:** [[item:268237]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:271876]]: Cantrip chest item that you will catalyze. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:271092]]: Cantrip weapon from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270162]]: incredibly powerful trinket that drops from [Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>).
- [[item:270164]]: Second best trinket. Drops from [The Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271504@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></div></td></tr><tr><th>Bracers</th><td>[[item:268217@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Preservation Evoker

As always, you should consult with [QELive](<https://questionablyepic.com/live/>) to determine
  your best trinkets as the list can often change with tuning. However, this season you will want
  to utilize [[item:270162@JAACAAgNyA]] and [[item:270164@JAACAAgNyA]]. Two incredibly
  powerful trinkets from the new raid. Mythic+ trinkets are unfortunately a bit
  undertuned in comparison but you do have a few good options to use while working
  to acquire your BiS trinkets from raid.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Preservation Evoker BiS Trinkets**
**Best-in-Slot -** [[item:270162]] and [[item:270164]].   

**Honorable Mention -** [[item:250214]].

:::

For direct trinket comparison, use
[QELive](<https://questionablyepic.com/live/>). We will
list a few special trinkets here with comments on their power level.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Preservation Evoker Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270162]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270167]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:248583]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:270169]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:249343]]</li>&#10;<li>[[item:249811]]</li>&#10;<li>[[item:251792]]</li>&#10;<li>[[item:274493]]</li>&#10;<li>[[item:273796]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250248]]</li>&#10;<li>[[item:250255]]</li>&#10;<li>[[item:268292]]</li>&#10;<li>[[item:264507]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250254]]</li>&#10;<li>[[item:270171]]</li>&#10;<li>[[item:264701]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

In general, there are quite a few trinkets on a similar power level. Any
of the trinkets in a tier will be roughly equal to each other. This means that item level on trinkets is quite important.
F-tier trinkets are there because they are only better than an empty trinket slot.

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) can be used to acquire specific items from specific bosses
  or dungeons, by letting you gain a guaranteed piece of loot from a specific drop-location.
  The received item is random, but once an item has been acquired in this way,
  your next use of a Voidcore will grant one of the remaining items you haven't yet acquired.

With the release of Patch 12.1.5, you can obtain an additional Voidcore for free from 
**Orin Straylight** in Silvermoon, next to The Catalyst.

**Note that obtaining an item via drop or [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) does not remove it from your Bonus Roll pool.**

3.1.

#### Recommended Nebulous Voidcore usage for Preservation Evoker

There are a few different paths you can take for your Nebulous Voidcores and crafts. These are mostly early-season problems,
  and if you pick up the spec later in the season then you will have a lot more freedom in what you choose for both. **It is a big
  power loss to bonus roll Mythic+ early in the season.**

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Raid Voidcore Priority**
- Heroic (or Mythic) [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) until you obtain [[item:271876]], [[item:271092]],
    and [[item:268265]].
- Heroic (or Mythic) [Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>) until you obtain [[item:270162]].
- Then: Fill in slots you don't have Myth-track items for yet. You can use QE Live in order to get the average bonus roll value from each boss and dungeon.

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **M+/Heroic Raids Voidcore Priority**
- [The Blinding Vale](<https://www.wowhead.com/achievement=61641>) - [[item:250214]] (good)
- [The Temple of Sethraliss](<https://www.wowhead.com/achievement=12504>) - Multiple good items

:::

If you are on a fresh character, you will still want to prioritize bonus rolling
  [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) to get the key items. From there, it is often times going to be higher
  value to bonus roll [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>) due to the large amount of items that drop,
  and three strong tier slots that you can instantly catalyze. While this may mean
  that you do not get the most powerful trinkets right away, it can be the best way
  to quickly gear up a character. Otherwise you can instead roll Heroic/Mythic
  [Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>) or [The Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

3.2.

#### Ascendant Venomstones

The priority for using [[item:280562]] will always be on your **weapon.**
This provides you with the largest power increase. From there you can focus on
trinkets and then your offhand. The order is very similar to how you would spend
your crests at the start of a season:

1. Weapon
2. Trinkets
3. Off-Hand

You should always prioritize Myth track items unless in situations where you
will not get the Myth track variant anytime soon.

4.

### Best Crafted Items for Preservation Evoker

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose the exact
secondary stats you want.

With our Bonus Roll strategy focusing on obtaining a main-hand weapon early,
our recommended crafting order will focus on getting a **off-hand** first.
From there you will want to craft an item with [[item:240167]].
If you decide to go against the recommended strategy and do not craft an off-hand,
you would simply craft two items early with [[item:240167]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Preservation Evoker Crafted Gear Priority**
- [[item:245769]] with [[item:245876]]
- [[item:244584]] with [[item:240167]]
- [[item:244577]] with [[item:240167]]
- Any item you do not have on Myth track yet.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Preservation Evoker

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

We tend to recommend crafting weapon slots early as they will provide the
most initial power at the start of a new season, but they will not be your
overall Best in Slot items. In general your best in slot will be:

- [[item:244584]] with [[item:240167]]
- [[item:244577]] with [[item:240167]]

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item. This allows you to add a socket to the above piece
of gear if you acquired them in Season 2.

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Preservation Evoker Crest Upgrade Priority**
**Weapon Slots** ➜ **Special Effect Slots** ➜ **Helmet/Chest/Legs** ➜ **Trinkets** ➜ **Shoulders/Gloves/Belt/Boots** ➜ **The Rest**

:::

As previously mentioned, you will want to prioritize the items you know that
you will not replace. If you have a BiS Myth track tier helm, that would take
priority over a Hero track trinket that is not BiS. The above order assumes that
everything is Myth track.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on QE Live. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** BiS list updated for Patch 12.1.5.
- **01 Oct. 2026:** Minor Fix to Mythic+ roll recommendations.
- **25 Aug. 2026:** Added extra information to bonus roll strategy.
- **17 Aug. 2026:** Minor trinket tier list updates.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** BiS Trinkets and Trinket tier list updated.
- **23 Mar. 2026:** Trinket tier list updated.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **14 Aug. 2025:** Trinket recommendations updated.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **13 May 2025:** Puzzling Cartel Chip recommendations updated.
- **21 Apr. 2025:** Page updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Cyrces Circlet information added.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Season 1 BiS Gear added.
- **21 Aug. 2024:** Page Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **29 Nov. 2023:** Minor BiS list updates.
- **07 Nov. 2023:** Embellishment and BiS lists updated for sporecloak nerfs.
- **06 Nov. 2023:** Updated for 10.2.
- **04 Sep. 2023:** BiS Gear added.
- **19 Jul. 2023:** Trinket tier list updated.
- **17 Jul. 2023:** Trinket tier list updated.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **26 May 2023:** Information about Timewalking trinkets added.
- **20 May 2023:** Embellishment recommendations changed to account for bug fixes.
- **16 May 2023:** Embellishment recommendations updated.
- **01 May 2023:** Updated for Patch 10.1.
- **28 Mar. 2023:** Primordial Gem recommendations updated.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Jan. 2023:** Added Spark of Ingenuity crafting recommendations.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Preservation Evoker. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Preservation Evoker Stat Priority

The stat priority for a [Preservation Evoker](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) will remain fairly
consistent regardless of content choice. Mastery provides the largest increase
to your healing while other stats offer a bit less of a healing boost but
also increase your damage output. When optimizing your gear, you will generally
be aiming for as much Mastery as possible while keeping a balanced amount of
other secondaries.

Regardless if you are playing a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden or ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper
build, your stat priority will stay the same. The emphasis will
continue to be on maximizing your Mastery.

Intellect

Mastery

Critical Strike

Haste

Versatility

Within [Mythic+](<https://www.icy-veins.com/wow/dragonflight-mythic-season-4-guide>), your stat priority will not change, but you have a bit
more choice as to how you want to allocate your stats. Mastery continues to offer
the largest healing increase per point, but it does not offer any damage. If you
find yourself in situations where you have more healing than you need and want
to optimize your damage, you can choose to drop some Mastery in favor of Critical
Strike or Haste.

2.

### In-Depth Stat Breakdown

Understanding the impact of each stat is crucial if you aim to truly minmax
your gear and performance. Below we will break down the impact that each stat
has.

- **Mastery** — [Preservation Evoker](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>)'s [[spell:363510]] 
  increases your healing done when your max health percentage is higher than 
  whoever you are attempting to heal. While this stat is quite good by itself, 
  it is important to remember that it provides **no** damage increase, which 
  can hurt its value in content where damage output is important. Every other 
  secondary stat increases  your damage even if it is only slightly above 0, 
  Mastery does not.
- **Haste** — Many spells in the game "scale with haste". What this
  means is that their cooldowns are decreased as you obtain more haste. For Preservation 
  Evoker, this applies to [[spell:373861]] and [[spell:360995]] most notably.
  The more haste you have, the lesser cooldown these abilities will have.
- **Critical Strike** — Gives you an increased chance for spells and attacks
  to deal additional healing or damage. [[spell:366155]] will additionally have its
  duration extended when it crits. When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden, the hero talent
  [[spell:431874]] will cause [[spell:355936]] and [[spell:357208]] to have
  their duration extended with crits.
  
  
  
  
  It is important to note that all abilities listed to this point have caps as
  to how far their duration can be extended to prevent
  infinite duration. Additionally, a large percentage of our healing cannot crit.
  [[spell:373861]], for example, is unable to crit which hurts the overall
  value of the stat.
- **Versatility** — By far the least interesting stat, this increases
  healing and damage done by a small amount and decreases damage taken. Unfortunately,
  this stat does not compare to the alternative options. In very high Mythic+ dungeons
  you may see players running more amounts of it in order to live very high damage
  intakes that would otherwise 1-shot them, but most players will not experience this.
  Outside of that specific situation, you will typically avoid targeting gear with
  Versatility.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **03 May 2026:** Recommended stats updated.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Page updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Page Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **28 Dec. 2022:** Moved Haste to be just under Critical Strike in the stat priority.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Preservation Evoker, based on your [stat priority](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

It is important that in one socket you are always using either [[item:240968]]
or [[item:240983]]. Telluric will provide a bit more mana 
at the cost of some primary stat. Overall the difference is very minor and you 
can typically run what you feel comfortable with, or what is cheaper to craft or buy.

In Mythic+ you may value the mana less, because you can drink in-between pulls. Whereas
in Raid, the extra mana can be valuable when you are struggling on a fight and go oom before
the fight ends.

When using [[item:240968]], you will want to have as many 
different color gems in your gear as possible. This means you should be using 
one of each of the following:

- [[item:240900]]
- [[item:240908]]
- [[item:240892]]
- [[item:240917]]

With the remaining gem sockets, and when using [[item:240983]], you will want
to use [[item:240900]]. That being said, you should continue to consult with
[QuestionablyEpic](<https://questionablyepic.com/>) to truly optimize your gems.

2.

### Best Enchants and Weapon Augments

The best Weapon Oil for Preservation Evoker will be [[item:243733]].
The secondary stat boosts provides a nice bonus in every form of content and the alternative
[[item:243735]] is not strong enough to ever be worth using.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240155]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243959]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

Consumables such as Flasks, Food, Potions, even Oils can increase your power by
a noticeable margin and are worth utilizing anytime you are doing challenging
content. If gold is not a concern, you can choose to always use them!

3.1.

#### Flask

[[item:241322]] will be your go-to choice for maximizing
your healing output. In situations like Mythic+, where you do not need extra
healing, you can instead choose to run [[item:241325]].

3.2.

#### Potions

There are two potions that are worth considering in Midnight: [[item:241288]]
and [[item:241301]]. It is important to note that these potions share cooldowns. 
Using one of them with put all others on cooldown. In any situation where mana is 
concerned, you should be using [[item:241301]] only. When you do not 
need the mana you can instead use [[item:241288]].

Make sure to always keep [[item:271883]]s on you 
at all times. These potions do not share a cooldown with combat/mana potions 
meaning that you can use them whenever you are in need of emergency healing to yourself.

3.3.

#### Food Buff

You should be eating [[item:242747]] as the desired feast or 
[[spell:1278895]] for your own personal food. These provide you
with an increase to your primary stat and that beats out any other food choices.

3.4.

#### Augment Rune

[[item:259085]] provide around 1% HPS increase and
should be evaluated during progress, especially when close to pivotal
kills. They can be quite pricey though, so use them sparingly when truly needed.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **20 Aug. 2025:** Weapon enchant recommendations updated.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Page updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **30 Aug. 2024:** Consumable recommendations updated.
- **21 Aug. 2024:** Page Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Page Updated for War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **21 Nov. 2023:** Weapon enchant recommendation changed.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **28 Mar. 2023:** Primordial Gem recommendations updated.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **28 Dec. 2022:** Consumable/enchants updated.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Preservation Evoker in World of Warcraft Patch 12.1.5.

1.

### Preservation Evoker in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Evoker in
Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Preservation Evoker offers some of the highest damage and healing
of any healer. That being said, healing on it can be more difficult than
others, and it will require some practice and learning to get the hang of
it fully.

2.

### Best Mythic+ Talent Builds

Regardless of if you are just doing your weekly +10 key or pushing high level 
content, your build will focus on ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper. Flameshaper currently
provides the highest healing and damage output as well as providing unique utility 
in the form of [[spell:444322]].

Default ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Mythic+ Talent Build
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Mythic+ Talent Build

### Default ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Mythic+ Talent Build

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Mythic+ Talent Build

With changes in [Patch 12.1](<https://www.icy-veins.com/wow/midnight-patch-12-1-guide>), ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper has become
the superior Hero Talent choice for Preservation. [[spell:355936]] and
[[spell:444088]] have received noticeable buffs, and with the new [[spell:1296641]]
and 4-set bonus, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper has pulled ahead.

In addition to more power, you will gain access to [[spell:1264269]] 
and [[spell:444322]]. Having two charges of [[spell:355936]] will grant you
more flexibility in your healing, and [[spell:444322]] will allow you to 
place [[spell:363916]] on a player. This gives you an extra
defensive cooldown that can be very valuable in a Mythic+ setting.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WmZGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAjZgFwCYGmAbM2MMAmZGD"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVlu8qosgYsJAA4877AWSC-AAAA-TKMIgpZRxogwBA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Mythic+ Talent Build

2.2.

#### Default ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden Mythic+ Talent Build

While ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper has pulled ahead, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden is still
a viable choice for players who enjoy the playstyle. [[spell:370553]] continues
to be a powerful cooldown through [[spell:431695]], granting you extra Haste,
cooldown reduction, and movement speed. Additionally, [[spell:431442]] gains
extra power through the [[spell:1296641]] and 4-set bonuses.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) Chronowarden may not provide the same damage or healing boosts, but
it plays much faster due to the Haste bonus. Having [[spell:429483]] is also always
a positive.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WGzYYmxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAwYGbsADMDDNYsAjZGgxA"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVliiu8qosgYsJAA4877AG-AAAA-OUaAQYMIMUIYpA-
```

:::

3.

### Utility Kit and Abilities

### Stuns and Stops

3.1.

#### Stunning and "Stops"

- [[spell:372048]] can be used to increase the duration of crowd
  control
  effects that your party members will be throwing out. Using this before an AoE
  stun from a party member such as a Monk's [[spell:119381]] will cause
  the stun to last
  even longer. This ability can even be used to dispel Enrage effects from mobs, thanks to the [[spell:374346]] talent in the class tree.
- [Preservation Evoker](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) can also bring both a root and stun to make
  difficult
  packs much easier to deal with for both your tank and your party.
  [[spell:358385]] can
  be used to root enemies, and [[spell:357210]] can be used to stun them if you
  talent into the [[spell:371032]] passive from the class tree.
- It is also worth mentioning that [[spell:357214]] and
  [[spell:368970]],
  both racial abilities can be used to knock enemies into the air and knock them
  away from you.

### Other Utility

3.2.

#### Other Utility

- [[spell:390386]] provides your party with a
  [[spell:80353]]/[[spell:2825]] effect.
  The only other healer that can bring this massive benefit is Shaman.
- [[spell:370665]] will allow you to pick up an ally and bring them to your
  cursor
  location. If an ally is struggling to run somewhere with a mechanic, group up
  with your party, or even just needs a simple movement boost, this can really
  help them get to where they need to be.

4.

### Dealing with Affixes

Season 2 of Midnight only has four significant Affixes that offer any kind
of counterplay, called Xal'ataths Bargains. These rotate every week, with only
one of them being active at a time. Many of the Mythic+ affixes, like Fortified or
Tyrannical, simply add a passive effect to the keystone, with these four exceptions
that are seasonally themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. [[spell:368970]] and [[spell:357214]]
  can be very useful in dealing with this mechanic.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn that
  needs to be focus-targeted and interrupted. Healers can typically not help
  with this affix beyond helping to deal a bit of extra damage to it.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and circle
  around them. You have 15 seconds to soak all of these to buff your group.
  While not required, healers can often be very good at running around and soaking
  whatever is unsoaked so DPS can stand still and maintain uptime. Of course you
  will not want to do this during difficult healing moments.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb. This effect can be dispelled and you will want to make sure that
  you are dispelling players unable to clear it themselves as soon as possible in
  order to get 2 dispels off. This will allow you to only worry about clearing
  a few players debuffs. [[spell:374251]] can also be used to dispel 
  one extra debuff.

If these affixes are not handled, they will buff enemy trash and bosses.
However, when you are able to handle them they will provide your entire group
with beneficial buffs, increasing your output or survivability.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **11 Aug. 2025:** Minor updates.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Page updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **28 Sep. 2024:** Specific dungeon tips added.
- **09 Sep. 2024:** Season 1 Information added.
- **17 Aug. 2024:** Page Reviewed and Updated for The War Within.
- **20 Jul. 2024:** Page Updated for War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page updated for Season 4.
- **19 Mar. 2024:** Talent recommendations updated for 10.2.6.
- **15 Jan. 2024:** Build recommendation updated for 10.2.5.
- **06 Nov. 2023:** Updated for 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **17 Jul. 2023:** Minor talent recommendation changes.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **08 Jul. 2023:** Talent recommendations updated.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **31 Jan. 2023:** Talent recommendation updated slightly.
- **24 Jan. 2023:** Talents updated for 10.0.5.
- **28 Dec. 2022:** Talent build updated.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Preservation Evoker in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Since the release of Dragonflight, you were given the option to enable mouseover
casting. This will cause your abilities to heal whoever your cursor is currently
hovering over when you press an ability. This will save you from having to
create many mouseovers for each ability. Keep in mind that many players will need
to disable the "auto selfcast" setting once enabling mouseovers; otherwise every
spell will be cast on you.

If you have been using macros for a long time and prefer them over the new
in game options, you can copy the following macro and adjust it for every spell
that you wish to macro:

#### Emerald Blossom Macro

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Emerald Blossom
```

This macro will cast a spell on the target you are mouseovering on; if they
are dead or you have no target, it will instead cast it on yourself.

2.

### Best Addons

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.1.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.2.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.2.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.2.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.2.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.3.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.3.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.

### Harreks Advanced Raid Frames

In [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), many addons, weakauras, and overall functionality
has been removed. [Harreks Advanced Raid Frames](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>) gives you back
some of the functionality of raid frames, allowing you to fully customize what
buffs you can and cannot see on your frames, as well as the individual locations
in which the buffs appear. Without this addon, you will be unable to fully customize
your raid frames, regardless of which addon you download.

Thankfully, Harreks Advanced
Raid Frames are usable with the majority of raid frame addons, giving you the best
of both worlds. If you have additional questions or require assistance, you can visit
Harreks discord, [Spiritbloom.Pro](<https://discord.gg/spiritbloompro>).

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Page Reviewed and Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::
