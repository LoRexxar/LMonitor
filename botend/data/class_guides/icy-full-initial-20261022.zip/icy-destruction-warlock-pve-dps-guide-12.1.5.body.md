## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本毁灭 术士指南。在这里，你将学习如何在团队副本和大秘境地下城中扮演毁灭 术士：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

毁灭大秘境资源

[全新！顶级毁灭天赋配装](<https://raider.io/specs/destruction-warlock/talents>)

[顶级毁灭大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warlock/destruction>)

[毁灭大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warlock--destruction>)

[热门毁灭队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warlock--destruction>)

1.

### 毁灭 术士概述

毁灭 术士是一个非常灵活的专精，能够在各种环境中找到脱颖而出的方法。毁灭可以对单个目标造成大量爆发伤害，同时也能高效地顺劈和AOE多个目标。

毁灭几乎是推进战斗的常备选择，因为它的预热时间在所有术士专精中是最短的。它能够轻松压制优先目标，并通过[[spell:80240]]拥有强大的顺劈能力。与所有术士专精一样，毁灭能带来[[spell:111771]]，这是一个强大的团队冷却技能，可以瞬间将你的整个团队传送40码。

适应性与表现

毁灭 术士在单体和多目标上伤害都很高，拥有远程顺劈、集火和快速转火能力，代价是伤害曲线相对平缓。恶魔使徒在单体上伤害更高，而地狱召唤者则提升了多目标能力。

炮台型施法者

在至暗之夜中，毁灭可能是最容易受到数值调整影响的专精。它提供高DPS能力和一套几乎能应对任何战斗的工具，唯一的缺点是机动性有限，由于斩杀阶段之外缺乏瞬发法术，以及对填充伤害和目标身上持续时间的更高要求而更加凸显。

全能大师

随着目标数量增加，毁灭的表现优于大多数专精，可用于在关键目标上产生纯粹的集火伤害输出。由于其伤害曲线不像其他专精那样依赖爆发，该专精不会因拉怪节奏的变化而受到惩罚。

除此之外，至暗之夜 为 术士 职业带来了很多实用性，包括诅咒和AoE诅咒，以及所有职业中最高的生存能力之一。

高功能性

[[spell:111771]]在团队副本环境中大多数时候是必备的，而[[spell:20707]]和[[item:5512]]则提供了不错的便利性。

在地下城中情况则有所不同，传送门用于罕见的跳怪场景，灵魂石是一个需要施法时间的战斗复活，而治疗石则只是更好的药水。

诅咒目前处境更好，提供AOE施加方式，以及凋零这种更强但有时间限制的变体。宠物也可以被视为功能性的一部分，但实际上主要就是使用地狱猎犬进行法术封锁和吞噬魔法，除非急需小鬼的驱散。

非常有限

毁灭或许是施法者中最不灵活的，尤其是在单体战斗中，只有

[[spell:17962]]

和

[[spell:17877]]

可以在移动中施放。在地下城中，根据天赋不同，机动性会更好一些，但该专精的核心特色在于持续不断地站桩读条。

名列前茅

术士 的生存能力总体不错。虽然该职业缺乏免疫或伤害转移工具，但主要机制是通过

[[spell:108370]]

的护盾溢出来缓冲现有生命值上限，

[[spell:108415]]

来自

[[spell:108416]]

和

[[spell:104773]]

.

1.

### 毁灭 术士在至暗之夜中的表现

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

本次补丁没有术士的改动，而是专注于两个新的终局内容：一个新团队副本和备受期待的迷宫巨型地下堡。请查看以下链接获取更多详情：

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

本次补丁延续了第2赛季的剧情和装备进度，专注于游戏体验优化、新的单人向内容，以及 [安其拉入侵](<https://www.icy-veins.com/wow/aqir-invasions-guide>)，还有更多！如果你对12.1.5版本及之后还有什么在等着你感到好奇，请务必访问我们的专题页面。

2.3.

#### 职业改动

毁灭 术士在12.1.5版本中没有改动，因此该专精最近的改动发生在第2赛季初期。装备页面已更新了来自的所有新物品 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)的新物品，以及关于一旦[[item:280562]]可用后如何使用的建议。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1补丁改动 隐藏12.1补丁改动
8月25日的热修复增强了毁灭的AOE伤害，缩小了与恶魔学识在顺劈上的相对差距。此次调整使得3个术士专精在伤害上更加接近。

[至暗之夜 8月25日热修](<https://us.forums.blizzard.com/en/wow/t/world-of-warcraft-midnight-hotfixes-august-25/2336376/68>)

**术士**

<em>开发者说明：我们正在提升痛苦和恶魔学识的输出能力，主要专注于它们的单体目标技能，次要关注它们的多目标技能。此外，我们还大幅提升了术士恶魔的伤害，使它们对整体输出的贡献更大。这也有助于在单人游玩时减轻一些仇恨问题。</em>

- 小鬼、虚空行者、萨亚德和地狱猎犬的伤害提高350%。

**毁灭**

- 火焰之雨伤害提高30%

在迈向12.1版本的过程中，毁灭 术士收到了多项改动，影响了英雄天赋树和专精天赋树，同时修复了专精和基础[[spell:108370]]的错误，后者现在提供更实质性的防御层。

相对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者将使用场景转向带有优先伤害和分散顺劈的单体目标，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒及其被动顺劈则退居于需要集火的多目标场景。

[乌拉特克之诅咒 补丁说明](<https://us.forums.blizzard.com/en/wow/t/2317811>)

**地狱召唤者**

<em>开发者说明：我们正在更新焦黑之魂，为地狱召唤者提供一个更好的工具来将伤害集中到优先目标上，从而提升英雄天赋树的整体灵活性，而不是让它仅在多目标场景中表现出色。然而，我们保持了恶意的功能不变，使其仍然是地狱召唤者工具箱中一个很酷且有影响力的工具。</em>

- 黑化之魂已重新设计：如果目标受到你的凋零影响，你的混沌之箭和暗影灼烧会使其层数增加1层。每次凋零获得一层时，它有几率坍缩，每1秒消耗一层对宿主造成暗影烈焰伤害，直到剩余1层。
- 佩洛萨恩之印已被重新设计：枯萎造成的伤害性暴击伤害为215%，而不是通常的200%。焦黑之魂造成的伤害性暴击伤害为225%，而不是通常的200%。
- 焦黑之魂伤害提高45%。
- 枯萎伤害提高25%。

天赋树改动旨在专门提高毁灭的单体伤害，代价是进一步减少了天赋选择中的可能替代方案。

[乌拉特克之诅咒 补丁说明](<https://us.forums.blizzard.com/en/wow/t/2317811/18>)

**毁灭**

<em>开发者说明：我们正在提高每个术士专精的单体伤害，并降低毁灭的顺劈伤害曲线。我们希望毁灭在双目标场景中表现出色；然而，我们希望将这种优势保持在合理的范围内。</em>

- 浩劫现在使法术对被标记目标造成50%的伤害（原为60%）。
- 灵魂火焰伤害提高45%。
- 混沌之箭伤害提高5%。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜版本总结：毁灭 术士

2.5.

#### 巅峰天赋

该资料片最突出的特色是巅峰天赋，它们将在升级过程中逐渐解锁。这些点数独立于天赋树存在，必须按顺序投入才能解锁后续点数。

1. [[spell:1265770]]
2. [[spell:1265772]]
3. [[spell:1265774]]

总的来说，这些天赋主要提供基础能力加成，并不会广泛影响输出循环本身，因为任何优化都与现有的手法重叠。

2.6.

#### 改动总结

以下列出了按章节划分的改动明细，以便于阅读。

- **英雄天赋** 获得了基础的小幅改动，并新增了第四列。
  
  
  
  
  ► **点击展开**
  
  
  
  
  2.6.1.
  
  
  
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒
  
  
  
  
  - [[spell:429893]] 已被调整为轻微的伤害增益
  - 新天赋：[[spell:1268709]] 每当你消耗碎片时，召唤最多3个眼球，在消耗恶魔艺术时会爆炸造成AoE伤害
  - 新天赋：[[spell:1268713]] 激活期间，邪能眼球每秒会对你的目标施放 [[spell:1269892]]
  - 新天赋：[[spell:407470]] 每个爆炸的邪能眼球将使你获得2%智力，持续10秒
  
  
  
  
  2.6.2.
  
  
  
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者
  
  
  
  
  - 新天赋：[[spell:1266799]]提高基础碎片消耗技能的伤害，在[[spell:430014]]期间效果翻倍
  - 新天赋：[[spell:1266805]] [[spell:445465]]有几率触发[[spell:430014]]
  - 新天赋：[[spell:1266803]] [[spell:430014]]提供额外的急速，施放该技能会叠加更多[[spell:445465]]层数
- 核心/循环技能发生了重大改动 **毁灭 术士** 法术进行了几项改动。
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:17877]]已更改为只能对生命值低于20%的目标使用
  - [[spell:1245633]]现在是暴击触发的效果，允许免费施放一次[[spell:17877]]，无论目标生命值多少都可以使用
  - [[spell:1244877]]已作为[[spell:152108]]的辅助天赋加入
  - [[spell:205184]]现在会将[[spell:348]]扩散到最多3个附近目标，而不是一个提高伤害的减益效果
  - [[spell:387156]]已被移除
  - [[spell:387176]]已被移除
  - [[spell:457025]]和[[spell:457064]]已被移除
  - [[spell:1280868]] 现在是一个与 [[spell:6353]] 组成的选择节点，其中 [[spell:1245089]] 是相关的辅助天赋。
- 术士的辅助法术也发生了一些值得注意的改动。
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:1714]]和[[spell:334275]]现在是独立的天赋
  - [[spell:1265813]]已被添加，使每个诅咒也能影响主目标周围10码内的敌人
  - 引入了灾祸，提供了比诅咒更强大的版本，持续时间和冷却时间更短
  - [[spell:5484]] 现在是与 [[spell:30283]] 互选的选择节点，并且有一个新的辅助天赋 [[spell:1270255]]，减少其冷却时间并最多影响10个目标
  - [[spell:755]]已被移除，其治疗效果被添加到[[spell:234153]]并配合[[spell:1265810]]

1.

### 毁灭 术士 基础玩法

毁灭 术士 是一个相当直接的专精，偏向于高伤害的直接伤害法术、强大且持久的冷却技能，以及一定程度的宠物管理。其核心玩法围绕着产生和消耗术士的标志性资源：灵魂碎片。

基础很简单：在目标身上保持[[spell:348]]，将灵魂碎片用于[[spell:116858]]或[[spell:5740]]，冷却就绪时施放[[spell:17962]]，并在空闲时使用[[spell:29722]]。毁灭术士的最佳描述就是这三个核心要点。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_immolation.jpg>) **保持 献祭**
  
  
  
  
  [[spell:348]] 是一个看似不起眼但非常强大的持续伤害技能，能在战斗中产生大量灵魂碎片。利用 [[spell:152108]] 和 [[spell:205184]] 在每个目标上施加并延长 [[spell:348]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_warlock_demonbolt.jpg>) **最大化利用 浩劫 和浩劫窗口**
  
  
  
  
  由于 [[spell:80240]] 会复制你的单体法术，因此对 [[spell:387506]] 的触发做出反应，保证一次双倍的 [[spell:17962]] 以及一次 [[spell:116858]] 或两次 [[spell:29722]] 来额外产生碎片是非常容易实现的。请记住 浩劫 也会复制法术产生的碎片。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **灵活应对**
  
  
  
  
  毁灭 储存资源的能力有限，但碎片获取速度足够快，可以在之后迅速恢复。利用这一点，在需要时爆发击杀关键目标。[[spell:80240]] 和 [[spell:387506]] 让你在进行单体输出时不会在群体伤害中损失太多。

1.

### 如何为 毁灭 术士 配装

虽然我们始终建议你自己进行模拟以获得理想结果，但我们确实提供了专门的 毁灭 配装页面。我们目前涵盖了当前赛季装备的推荐，以便为 至暗之夜 终局内容的发布打好基础。一旦你获得了一些装备，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 更新了饰品列表。
- **2026年8月31日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 更新了群体输出循环部分。
- **2026年8月25日（本页）：** 已更新至8月25日热修。
- **2026年8月16日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 更新了最佳配装列表、美化和饰品，以适应新的属性配置和饰品调整。
- **2026年8月16日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了消耗品以反映新的最佳配装列表。
- **2026年8月12日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 更新了暗影灼烧的斩杀线。
- **2026年8月11日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 更新了宝石和常见问题解答部分。
- **2026年8月11日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了宝石。
- **2026年8月11日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 更新了天赋选择。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为12.0.7补丁添加了全知卷册。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月22日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 更新了最佳装备列表以考虑不同的天赋。
- **2026年4月22日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 更新了单体天赋。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了茶部分。
- **2026年3月23日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 更新了碎片消耗部分，使用了新的斩杀线。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 更新了饰品排名以考虑凝视的削弱。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 扩展了套装奖励部分。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 添加了一个用于升级到至暗之夜的80级导入方案。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 为至暗之夜的发布更新了天赋树。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为 至暗之夜 发布进行了更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜的发布更新了输出循环并添加了巅峰部分。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为至暗之夜的发布更新了天赋树并添加了巅峰部分。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 为 至暗之夜 版本添加了巅峰天赋。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为 至暗之夜 版本添加了巅峰天赋部分并更新了天赋。
- **2026年2月26日（本页）：** 为 至暗之夜 版本更新了性能和巅峰天赋部分。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 针对每次解锁节点的变化更新了天赋树。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 针对每次解锁节点的变化更新了天赋树。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 针对每次解锁节点的变化更新了天赋树。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为11.2.7补丁更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为11.2.7补丁更新。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月9日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 更新了多目标逻辑。
- **2025年8月22日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔。
- **2025年8月22日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 更新了灵魂 火焰 相关内容。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 根据调整更新了暗影牧师的插槽推荐。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为 11.1.7 补丁和暗影牧师进行了更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 添加了战斗助手部分。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 添加了战斗助手部分。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年4月4日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已更新饰品推荐。
- **2025年4月4日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 修复了一个损坏的导入链接。
- **2025年3月19日（[解放安德迈页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了天赋推荐。
- **2025年3月19日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 更新了单体配置。
- **2025年3月6日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 更新了地下城天赋推荐。
- **2025年3月4日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 更新了毕业装备列表和饰品排行。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为 11.0.7 补丁和赛尔西的指环进行了更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月30日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 热修后更新了最佳装备列表。
- **2024年10月30日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 热修后更新了单体天赋。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了天赋推荐。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 针对11.0.5补丁进行了审阅。
- **2024年9月25日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 重新制作了页面布局，并相应地更新了各部分。
- **2024年9月25日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为 恶魔使徒 构建添加了一个暗影灼烧变体。
- **2024年9月19日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 为 11.0.5 补丁进行了更新，并添加了地下城提示部分。
- **2024年9月12日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔和磨刀石。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 添加了第1赛季毕业装备列表，更新了饰品部分。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了宝石部分，因为策略发生了变化。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 针对第1赛季上线更新了天赋选择。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 更新了第1赛季天赋推荐。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 更新了强度评估以反映第1赛季状况。
- **2024年8月26日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 添加了探宝地下城天赋推荐。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 添加了升级玩法风格部分。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 添加了赛季前毕业装备列表部分。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 添加了英雄天赋部分和选择器。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 更新了推荐以包含英雄天赋树。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 更新了各部分以考虑英雄天赋。
- **2024年8月21日（本页）：** 更新了优劣势和强度评估部分。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/destruction-warlock-mists-of-pandaria-remix-guide>)):** 页面已针对《地心之战》前夕补丁进行更新。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年7月19日（[地心之战](<https://www.icy-veins.com/wow/destruction-warlock-the-war-within-pve-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月19日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年6月19日（[地心之战](<https://www.icy-veins.com/wow/destruction-warlock-the-war-within-pve-guide>)):** 页面创建。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/destruction-warlock-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 为 10.2.7 补丁进行了更新。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为第4赛季上线进行了更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已针对10.2.6进行审查。
- **2024年3月19日（本页面）：** 已针对10.2.6进行审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为 10.2.5 补丁更新了饰品部分。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 为10.2.5版本更新了天赋。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2024 年 1 月 3 日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 更新了天赋和属性。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 在波纹孢子斗篷被削弱后更新了美化推荐。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 为10.2版本进行了审查。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为 10.2 补丁和第3赛季更新了装备推荐。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 为10.2补丁和第3赛季进行了更新。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为 10.2 补丁更新了天赋。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已针对10.2版本进行更新
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为10.2补丁更新了天赋。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 重新格式化了页面，包含毕业装备表格和部分更新。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 重构了天赋部分。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对10.1.7补丁更新
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 已针对10.1.7补丁更新
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 针对10.1.5补丁更新了天赋。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为 10.1.5 补丁更新了天赋。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 针对 10.1.5 补丁的天赋变更进行了更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为 10.1.5 补丁更新了天赋。
- **2023年7月10日（本页）：** 添加了 10.1.5 补丁并更新了强度评估部分。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已更新至10.1补丁。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 在腐化之怒增益后更新了药水推荐。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 为10.1版本更新。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 为10.1补丁更新了天赋。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已更新至10.1补丁。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为10.1版本更新了天赋。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为 10.1 补丁进行了审查。
- **2023年5月1日（本页）：** 为 10.1 补丁添加了新部分并更新了强度评估部分。
- **2023年3月24日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 更新了黑龙戒指部分以考虑正式服的在线修复。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了原始宝石推荐以考虑额外的正式服在线修复。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了原始宝石推荐以考虑25%增益的在线修复。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 针对10.0.7补丁更新了天赋树。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/destruction-warlock-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 添加了 10.0.7 补丁新戒指部分。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 为 10.0.7 补丁添加了原始宝石部分。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 为 10.0.7 补丁更新了天赋。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 添加了浩劫部分。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为10.0.7版本更新了天赋。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 更新了天赋树以反映10.0.7版本的职业改动。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为10.0.7版本更新了天赋。
- **2023年3月20日（本页）：** 添加了 10.0.7 补丁并更新了强度评估部分。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 添加了地狱火部分，并更新了天赋推荐。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 为10.0.5版本更新了单体和双目标的天赋选择。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 为10.0.5版本更新了天赋选择。
- **2023年1月24日（本页）：** 已更新至10.0.5补丁。
- **2023年1月7日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 将地下城药水更新为更可靠的微温全能药水。
- **2022年12月24日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 更新了单体天赋选择。
- **2022 年 12 月 14 日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了武器符文。
- **2022年12月13日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 更新了美化推荐。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已为第一赛季上线更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 更新了推荐配置。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式和优先级列表的选择器。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/destruction-warlock-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/destruction-warlock-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/destruction-warlock-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年7月30日（[9.2版本分析](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-2-changes-analysis>)):** 为第4赛季平衡性调整更新。
- **2022年2月22日（[9.2版本分析](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-2-changes-analysis>)):** 更新以反映 9.2 补丁上线。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-1-changes-analysis>)):** 针对9.1.5补丁更新。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-1-changes-analysis>)):** 移除了PTR免责声明。
- **2021年6月27日（[9.1 补丁分析](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-1-changes-analysis>)):** 基础变更，更新了传说装备和盟约推荐。
- **2021年5月5日（[9.1 补丁分析](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-1-changes-analysis>)):** 页面已创建。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-the-eternal-palace-raid-guide>)):** 更新了首领提示和天赋/精华选择。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 在最近的团队副本削弱后进行了更新。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年2月11日（[达萨罗之战页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了更好的天赋选择和更多提示。
- **2019年2月5日（[达萨罗之战页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为达萨罗之战英雄难度首周修复更新。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-uldir-raid-guide>)):** 为8.1补丁进行了更新。审查了所有首领的天赋建议。
- **2018年11月9日（[奥杜尔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-uldir-raid-guide>)):** 更新了首领指南。
- **2018年9月7日（[奥杜尔页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-uldir-raid-guide>)):** 为奥迪尔进行了更新。

显示更多

显示更少

:::

## 练级

在本页中，你将找到我们的 毁灭 术士 逐级练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[术士 升级指南](<https://www.icy-veins.com/wow/warlock-leveling-guide>).

1.

### 毁灭 术士 练级指南：至暗之夜

毁灭 术士 的优势在于在遭受反击前快速击杀单个目标，因此最好快速击杀单个敌人然后转向下一个。毁灭 的锁定目标能力通常仅限于 [[spell:17962]] 和 [[spell:17877]]，直到后来解锁 [[spell:445465]] 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者.

[[spell:17877]] 是用来快速连续击杀弱小敌人的主要工具，其重置机制应尽可能多地利用。

值得一提的是 毁灭 的群体伤害难以有效利用，因为法术会产生高仇恨，且 [[spell:5740]] 需要目标停留在其区域内。

诅咒、控制技能和宠物副坦克可以显著减少承受的伤害，鼓励激进的打法，而所有个人防御冷却技能即使在拉多怪时也能提供一定程度的安全保障。

对于精英或稀有等更大的敌人，毁灭 受到虚空行者仇恨不足的影响最大，要么形成与 [[spell:234153]] 和 [[spell:1265810]] 的非常缓慢的消耗战，要么在玩家施放几次 [[spell:116858]] 后出现仇恨被OT的情况。

1.1.

#### 升级装备选择

升级时，应始终选择物品等级最高的装备。如果物品等级相同，则应选择属性最有利于你专精的装备。如果你当前的装备是传家宝，则不应更换。

虽然传家宝最重要的方面是经验加成，但为了最大化其属性收益，你应该优先考虑智力，然后是急速，然后是暴击。其原因在于，急速通常能提供更流畅的战斗体验，并以均匀的方式提升你的DPS，而暴击虽然同样重要，但本质上不够稳定。

能够更快施法提供了更快标记怪物的优势，而且当大多数动作都更快完成时，整体感觉会更好。

1.2.

#### 至暗之夜升级实用消耗品

以下列出了几种可以用来加快升级进程的消耗品，无论数值调整如何，它们通常都是有益的。

地心之战的附魔在整个练级过程中仍然有效，并有助于提升角色速度。优先考虑以下附魔。

- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

战斗药水能提供爆发性的力量，如果有什么区别的话，最好在它们于满级变得无关紧要之前使用它们。

这些消耗品主要用于加快穿越和导航速度。

- [[item:109076]]
- [[item:132516]]或[[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]]或[[item:133576]]

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 毁灭 80级 至暗之夜 练级
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAYMjZGNLmx2MzYWmNmZmFzMbLmBAAzMjZmZxCMwwoBAmNsxAAAjBAAwMDGzMMAAAMjxAAwMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAYMzMzoZxM2mZGzysxMzsYmZbxMAAYmZMzMLWgBmFjGzAY2wGDAAMGAAAzMYMzwsAAAYGjBAgZYA"
}
```
:::

:::details 来源计算器编码
```
#LE-ITVVUUHDPfiklbLMOJSD80kw01ZkdF1ZURB-lZawYalEpI98ABcqhhB1BSyNilrrhuC-AAAA-JUGYkAQohZBZwB-
```

:::

2.1.

#### 升级用战争模式天赋

1. [[spell:200546]] 将 [[spell:80240]] 替换为地面目标的群体伤害变体，使其能够对区域内被击中的任何目标造成巨大伤害。
2. [[spell:200586]] 在练级时主要对移动减速有用。
3. 在无法使用坐骑的封闭空间中，应始终考虑使用[[spell:248855]]来加快你的移动速度。
4. 在风筝目标时，[[spell:353753]]可以提供额外的范围爆发伤害。
5.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1 起：**

**等级 1–9：**从1级开始，你只有一个主要攻击技能：[[spell:686]]。

1. **等级 2–3：**当连续施放几个 [[spell:686]] 无法更快击杀敌人时，应使用 [[spell:172]] 来锁定多个目标并削弱它们。
2. **等级 35 起：**尽可能频繁地使用 [[spell:1122]]。
3. **等级 67 起：**一旦你点出 [[spell:1245633]]，你的暴击将有几率免费获得一次 [[spell:17877]]，可以对任何敌人施放，无论其生命值如何。
4. **等级 29 起：**对生命值低于20%的目标使用 [[spell:17877]] 来斩杀它们，并希望能触发碎片返还。
5. **等级 27 起：**尽可能频繁地使用 [[spell:152108]]。
6. **等级 19 起：**当有第二个目标时使用 [[spell:80240]] 来复制每一个单体法术。
7. **等级 11 起：**当你至少有2个碎片时施放 [[spell:116858]]。
8. **等级 15 起：**当你有3个碎片且至少有3个目标聚集在一起时施放 [[spell:5740]]。
9. **等级 10 起：**在尽可能多的目标身上保持 [[spell:348]] 以获得高伤害和碎片生成。
10. **等级 13 起：**移动时以及碎片不超过4个半时施放 [[spell:17962]]。
11. **等级 10 起：**[[spell:29722]] 将 [[spell:686]] 替换为能够产生灵魂碎片碎片。将其作为最低优先级的法术使用。

小贴士：治疗你的恶魔

不要忘记在战斗中使用[[spell:234153]]配合[[spell:1265810]]来保持你的恶魔的生命值。

小贴士：不要低估诅咒！

随着[[spell:1265813]]的引入，诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:440057]]是独有的， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者并结合了上述两种诅咒。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

1.

## 升级时的宠物选择

[[spell:688]] 是你第一个可用的恶魔。这只宠物在升级时并不是特别有用，但在早期等级你别无选择。

如果你是单人升级，[[spell:697]]在升级过程中是一个不错的选择，因为它能为你分担很多压力。避免施法被打断也能提高升级速度。

如果你在组队升级或进入地下城，[[spell:691]]可能是一个不错的选择。额外的打断技能对于处理麻烦的施法怪物很有帮助。

1.

## 更新日志

- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月2日：** 添加了一个用于升级到至暗之夜的80级导入方案。
- **2026年2月26日：** 为至暗之夜的发布更新了天赋树。
- **2026年2月10日：** 针对每次解锁节点的变化更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 添加了升级玩法风格部分。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 针对10.0.7补丁更新了天赋树。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5版本中轻松游玩 毁灭 术士，使用最简单的输出循环、天赋树、属性优先级、配装等，而不牺牲性能。

1.

### 毁灭 术士 基础

本章节适用于对游戏或职业不熟悉的玩家，没有打史诗难度团本的打算，或者只是想以更直接的方式进行游戏，而不会被为实现最优操作所需考虑的众多优先级和主动技能所淹没。

毁灭 是一个灵活的专精，可以在输出循环复杂度不高的情况下提供各种类型的伤害和压力。在本节中，我们将专注于一个尽可能减少所需按键数量和反应速度的配置，同时不会过度损害整体伤害输出。

以下是三条简单的规则，帮助你理解该专精：

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_immolation.jpg>) **保持 献祭**
  
  
  
  
  [[spell:348]] 是一个看似不起眼但非常强大的持续伤害技能，能在战斗中产生大量灵魂碎片。利用 [[spell:152108]] 和 [[spell:205184]] 在每个目标上施加并延长 [[spell:348]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_warlock_demonbolt.jpg>) **最大化利用 浩劫 和浩劫窗口**
  
  
  
  
  由于 [[spell:80240]] 会复制你的单体法术，因此对 [[spell:387506]] 的触发做出反应，保证一次双倍的 [[spell:17962]] 以及一次 [[spell:116858]] 或两次 [[spell:29722]] 来额外产生碎片是非常容易实现的。请记住 浩劫 也会复制法术产生的碎片。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **灵活应对**
  
  
  
  
  毁灭 储存资源的能力有限，但碎片获取速度足够快，可以在之后迅速恢复。利用这一点，在需要时爆发击杀关键目标。[[spell:80240]] 和 [[spell:387506]] 让你在进行单体输出时不会在群体伤害中损失太多。

1.

### 毁灭 术士 新手指南：至暗之夜

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒 新手天赋

2.1.

#### 毁灭 术士 新手天赋

此构建针对易用性进行了优化，同时提供了一个适用于任何情况、无需调整的配置，包括团队副本、大秘境甚至地下城。就输出而言，这并非单体或多目标的最优选择，但它作为一个构建，可以帮助玩家在转向我们天赋页面中更专精的构建之前，先熟悉专精的核心。

要直接在游戏中导入这个全能构建，请点击计算器底部的导出按钮：

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAgZmZGNLmxiZGzyshZmlZmZZZmBAAjZWmZmFwYGDbwAbDL0YhBAAGAAgZGgxMjZ2AAAMzMGAAmhB"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfhiklnELM028MTjchprrowwJbM-lZaswSYEZYo488ANRB8ASjrrNSSiilK-AAAA-AOQo0QswITgwwC-
```

:::

### 毁灭 术士 基础输出循环

2.2.

#### 单体输出循环

1. 冷却好就施放 [[spell:1122]]。
2. 始终保持 [[spell:348]]。
3. 如果你有5个灵魂碎片，施放 [[spell:116858]]。
4. 如果你有2次充能，施放 [[spell:17962]]。
5. 可用时施放 [[spell:152108]]。
6. 施放 [[spell:17962]] 来产生灵魂碎片。
7. 施放 [[spell:29722]] 来产生灵魂碎片。

:::details 常见问题：我应该使用什么宠物/恶魔？
在地下城和大秘境中，我们推荐使用/牺牲地狱猎犬，因为打断技能在这样的环境中非常宝贵。这在高层大秘境中尤为重要，因为某些法术可能导致团队灭团。

在团队副本环境中，如果战斗要求使用[[spell:89808]]或需要频繁切换目标，我们推荐使用小鬼。

虚空行者推荐用于升级，或在你计划使用[[spell:108503]]但不需要地狱猎犬打断技能的环境中使用。牺牲虚空行者会为玩家授予[[spell:17767]]技能，这是一个防御性冷却技能，能提高玩家的生存能力。

魅魔通常比小鬼或地狱猎犬提供略高的伤害，如果你喜欢其视觉效果，或需要对单个目标施加永久的50%减速，可以使用它。

:::

2.3.

#### 多目标循环

通过在主目标身上施放 [[spell:17962]] 并激活 [[spell:348]]，在最多3个目标身上保持 [[spell:348]]。当至少5个目标聚集在一起时，[[spell:5740]] 应成为你主要的灵魂碎片消耗法术。请记住，在某些情况下使用 [[spell:116858]] 会更有利，例如目标不断远离 [[spell:5740]] 区域时。

:::details 小贴士：治疗你的恶魔
不要忘记在战斗中使用[[spell:234153]]配合[[spell:1265810]]来保持你的恶魔的生命值。

:::

:::details 小贴士：不要低估诅咒！
随着

[[spell:1265813]]

诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:440057]]是独有的， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者并结合了上述两种诅咒。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

2.4.

#### 巅峰天赋： ![Embers of Nihilam Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_shadowflame_missile.jpg>) 虚无之烬

你的顶峰天赋 [[spell:1265770]] 提供被动伤害触发，无需改变玩法即可获得全部价值。

2.5.

#### 毁灭 术士 至暗之夜 第2赛季套装

第2赛季套装加成完全是被动的，不会改变游戏玩法。

### 毁灭 术士 属性优先级

2.6.

#### 毁灭 术士 属性优先级

目前，你应按以下顺序优先考虑次要属性。关于本页呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>).

装备等级

急速达到22%

暴击

精通

急速

全能

### 暴风雪战斗助手

2.7.

#### 毁灭 术士 战斗助手

该 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 包含两个主要功能：

- **辅助高亮：** 显示下一个要排队的法术，在单体目标上提供足够准确的输出循环，在多目标上功能有限，最适合用来熟悉专精的流程和节奏。
- **单键助手：** 允许使用单个输入来完成辅助高亮提示序列中的多个技能，代价是更长的基础公共冷却时间（这会导致额外5%到10%的DPS损失）

**值得指出的是，这些工具首先是无障碍功能，不应被视为学习专精的直接替代品。**

战斗助手在 毁灭 术士 中表现最差的方面是：

- 持续伤害技能的覆盖率，因为没有支持流行机制的逻辑，在多目标情况下尤其恼人
- 多目标，因为它无论情况如何都考虑所有目标聚在一起。

2.8.

#### 战斗助手小贴士

- 冷却时间的对齐必须手动完成，特别是考虑到种族技能、药水和使用型装备
- 持续伤害技能应在流行范围内刷新，盲目遵循战斗助手将导致覆盖率大大降低
- [[spell:17962]] 的优势来自于使用时的机动性，最好在发生移动时保留1次充能
- 一般来说，尽量最大化施法时间，特别是在使用单键助手时，因为等待时间是游戏任何阶段的改进领域之一

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为 至暗之夜 版本添加了巅峰天赋部分并更新了天赋。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 添加了战斗助手部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年4月4日：** 修复了一个损坏的导入链接。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 更新了各部分以考虑英雄天赋。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁更新了天赋。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为 10.1.5 补丁更新了天赋。
- **2023年5月1日：** 为 10.1 补丁进行了审查。
- **2023年3月20日：** 为10.0.7版本更新了天赋。
- **2023年1月24日：** 为10.0.5版本更新了天赋选择。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到《魔兽世界》12.1.5版本中你的 毁灭 术士 的最佳天赋。我们还为各种类型的内容（如团队副本或大秘境）提供了默认天赋构建。如果你开启了战争模式，我们也涵盖了你的PvP天赋。

1.

### 毁灭 术士 的最佳 至暗之夜 天赋

在第2赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者 重做将英雄天赋的身份转向单体和分散顺劈，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒 在任何涉及集中顺劈或群体伤害的情况下都能提供更好的表现。虽然仍有一些个人偏好和情境调整的空间，以下是我们的当前推荐：

- **单体目标**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者 是单体以及双目标和分散顺劈的更好选择。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒 在任何具有集中顺劈的战斗中仍具有竞争力。
- **群体伤害**— [[spell:470479]] 和 [[spell:1268709]] 提供了大量的顺劈机会，使得 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒 在任何层数的大秘境中都是更好的选择，尤其是低层数，因为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者 在12.1补丁中损失了太多AoE能力。

**快速开始导入代码：**

:::talents 毁灭 单体目标 - 地狱召唤者
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMzmZmZWmFzMzsYMWMDAAmZGzMziNYgZxoxMAmtYjBAAGDM2AAmZwYGzYDAAwMzMAAMGG"
}
```
:::

:::talents 毁灭 AoE - 恶魔使徒
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysNzYmFzYZZMAAYGjZmZBMmxwCMw2wCNWYAAgxMMsBgZGgxMjZ2AAAMzMzAAYMM"
}
```
:::

:::talents 毁灭 探窟 - 地狱召唤者
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysZGzsYYZZmBAAzMjZmZxCMwsY0YGAzG2YAAgxMAAAzMYMzMmNAAAzMzMAAMDD"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

恶魔使徒

单体目标

秘境+

推荐

地狱召唤者

单体目标

推荐

秘境+

地下堡

### 天赋方案 0-0

1.1.

#### 单体目标天赋

一套围绕[[spell:116858]]伤害和快速仪式循环构建的标准单体配置，辅以[[spell:387173]]、[[spell:6353]]和[[spell:1280483]]带来的碎片生成增加。

### 天赋方案 0-1

1.2.

#### AOE/大秘境 恶魔使徒天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒 在地下城中适合优先目标伤害和爆发，使用[[spell:205184]]来传播[[spell:348]]，并利用任何机会使用[[spell:17877]]。

在[[spell:387506]]和[[spell:80240]]之间的选择是个人化的，前者提供更高的顺劈覆盖率，后者则让玩家可以选择何时何地复制伤害。

### 天赋方案 1-0

1.3.

#### 单体目标天赋

此配置的天赋选择旨在最大化[[spell:116858]]伤害和所需的碎片生成，像[[spell:387173]]、[[spell:6353]]和[[spell:1280483]]这样的天赋为你不断释放混乱之箭提供燃料。

### 天赋方案 1-1

1.4.

#### AoE/大秘境 地狱召唤者天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者 提供更高的AoE爆发和单体伤害，代价是较差的AoE和顺劈能力，并更加强调传播最大数量的[[spell:445465]]并将碎片花费在[[spell:5740]]上。

[[spell:387384]]中的2点可以换成[[spell:152108]]和[[spell:1244877]]，以在超过7个目标时增加AoE，或在短时间战斗中进一步增加爆发。

### 天赋方案 1-2

1.5.

#### 地下堡天赋

虽然英雄天赋树的选择并非特别具有决定性，
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者 提供[[spell:440057]]作为你在地下城中可能遇到的任何困难战斗的通用减益效果 [地下堡](<https://www.icy-veins.com/wow/delves-guide>).

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMzmZmZWmFzMzsYMWMDAAmZGzMzCYMjhFYgthFaswAAAjBGbAYmBYMjZsBAAYmZGAAGDD"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPQghklnoLM028Mtuw01JUUYENbM-lZaATswikm6MMa88ARB4w11m4RhBiiF-AAAA-OUAaYWCQUYUgwA-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysNzYmFzYZZMAAYGjZmZBMmxwCMw2wCNWYAAgxMMsBgZGgxMjZ2AAAMzMzAAYMM"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfhiklnoELM028MTjehprTwwJbM-lZaswSYEJ1FYYo0wBi6DowQxhrrNPxj-AAAA-AOQo0QowITgwwC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMzmZmZWmFzMzsYMWMDAAmZGzMziNYgZxoxMAmNsxAAAjBGbAAzMYMjZsBAAYmZGAAGDD"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPQghklnoLM028Mtuw01JUUYENbM-lZaATswikm6MMa88ARB4w11m4RhBiiF-AAAA-JQSU2AMQYgxBzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzysNzMzsYGLLjBAAzYMzMLWgBmFjGzAY2wGDAAMGMsBAMzgxMjZ2AAAMzMzAAYMM"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfiklnoELM028MTjchprTwwJbcI-lZaswSYEJ1FYYo0wBi6DowQxhrrNxjE-AAAA-JQSU2AIQYgxBzC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysZGzsYYZZmBAAzMjZmZxCMwsY0YGAzG2YAAgxMAAAzMYMzMmNAAAzMzMAAMDD"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfgiklnoELM028MTjehprTwwJbM-lZaswSYEJN1ZY0w55BiCowQxhrrNPSS-AAAA-JQSU2AIQYgxBzC-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

在 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)万卷书是一种新的玩家力量来源，会在数周内逐步解锁，并提供一系列小而灵活的加成选择，可随时更换以匹配所需的内容。符文的选择可以量身定制以提供输出，也可以转向生存能力和实用性。

以下是推荐的指南，逐点列出：

1. [[spell:1279599]]
2. [[spell:1279603]]或[[spell:1279604]]
3. [[spell:1287555]]
4. [[spell:1279609]]
5. [[spell:1279615]]和[[spell:1279614]]提供相似的输出

:::details 常见问题：哪个副属性符文最好？
术士的默认选择是

[[spell:1279609]]

。如果你不知怎么设法让暴击几率超过35%而忽视了精通，可以考虑使用

[[spell:1279612]]

.

:::

1.

### 巅峰天赋： ![Embers of Nihilam Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_shadowflame_missile.jpg>) 虚无之烬

在至暗之夜练级期间可用，这些天赋与专精树的其余部分分开，需要后续投入点数才能解锁更高的等级。

1. [[spell:1265770]]
2. [[spell:1265772]]
3. [[spell:1265774]]

总的来说，这些天赋主要提供基础能力加成，并不会广泛影响输出循环本身，因为任何优化都与现有的手法重叠。

1.

### 英雄天赋

英雄天赋在71级时可用，是互斥的天赋树，你可以选择它们来稍微改变游戏玩法和视觉效果。毁灭 术士可以在以下天赋树之间选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒以恶魔为主题，围绕通过[[spell:470479]]召唤的霸主、混沌之母和深渊领主的循环。因此其游戏玩法具有可预测的节奏和更高的爆发潜力，与英雄天赋树的召唤和法术强化相关联。

在实用性方面，[[spell:428911]]在[[spell:48020]]期间提供减速和定身免疫以及50%的移动速度，而另一方面[[spell:429072]]结合[[spell:1270255]]可启用25秒冷却的[[spell:5484]]，最多可影响10个目标。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者 以暗影烈焰伤害和更强力的持续伤害效果为主题。[[spell:445465]]取代了[[spell:348]]，并可以在[[spell:440043]]中产生第二个暗影烈焰持续伤害效果。该英雄天赋树提供了一种更有条理的碎片消耗方式，[[spell:430014]]每分钟强化一次爆发窗口。

在实用性方面，[[spell:440057]]提供了一个对近战和法系敌人都有效的减益效果，无需选择目标，且与[[spell:1265813]]配合时特别强大。

1.

### PvP天赋（战争模式）

在我们的天赋部分，有一个启用“战争模式”的选项。启用战争模式可提供以下好处：

- 在户外世界启用PvP天赋
- 在最高等级时，世界任务奖励提高10%
- 升级时获得的经验值提高10%
- 赚取征服点数，每周可兑换装备奖励

考虑到开启战争模式进行升级和PvE内容的好处，建议你启用该功能。在大多数情况下，尽管存在风险，这将带来最大收益。你将使自己可用于开放世界PvP，在升级或进行世界任务时存在被“偷袭”的可能性。

5.1.

#### 最佳战争模式天赋

在本节中，我们将对最适合练级和进行单人/小队PvE内容的PvP天赋进行排名。以下是通用PvP天赋和毁灭 术士专属PvE天赋的排名。

1. [[spell:353753]]允许你将目标从标记位置拖走来进行爆发。
2. [[spell:248855]]将你的传送门射程增加20码，并将使用它的玩家身上的减益效果持续时间缩短15秒，使其成为需要更高机动性时的良好选择。
3. [[spell:212295]]召唤一个持续3秒的护盾，反射所有以你为目标的有害法术。
4. [[spell:201996]]只在应对大量施法小怪时才有意义。
5. [[spell:200586]]使[[spell:116858]]在目标下方产生一个5码的邪能火池，使移动速度降低50%，并使所有敌人受到的治疗降低25%。这个天赋在所有情况下都很棒，尤其是当你同时面对多个敌人时。
6. [[spell:200546]]使[[spell:80240]]变为地面目标法术。其中的所有目标都会被视为被[[spell:80240]]施加了减益效果。
7.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 更新了天赋选择。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 为12.0.7补丁添加了全知卷册。
- **2026年4月22日：** 更新了单体天赋。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜的发布更新了天赋树并添加了巅峰部分。
- **2026年2月10日：** 针对每次解锁节点的变化更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月19日：** 更新了单体配置。
- **2025年3月6日：** 更新了地下城天赋推荐。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024 年 10 月 30 日：** 热修后更新了单体天赋。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月25日：** 为 恶魔使徒 构建添加了一个暗影灼烧变体。
- **2024年9月9日：** 更新了第1赛季天赋推荐。
- **2024年8月26日：** 添加了探宝地下城天赋推荐。
- **2024年8月21日：** 更新了推荐以包含英雄天赋树。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为 10.2 补丁更新了天赋。
- **2023年9月4日：** 已针对10.1.7补丁更新
- **2023年7月10日：** 为 10.1.5 补丁更新了天赋。
- **2023年5月1日：** 为10.1版本更新了天赋。
- **2023年3月20日：** 为10.0.7版本更新了天赋。
- **2023年1月24日：** 为10.0.5版本更新了单体和双目标的天赋选择。
- **2022年12月24日：** 更新了单体天赋选择。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何在单体和多目标情况下优化你的毁灭 术士的输出循环。我们还有关于冷却时间、触发效果等的进阶部分，以帮助你最大化DPS。我们的所有内容均已更新至《魔兽世界》12.1.5补丁。

1.

### 毁灭 术士 游戏玩法与输出循环指南

欢迎来到我们的毁灭术士输出循环页面。在本页中，你将找到在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

在下方选择天赋和英雄天赋后，本指南中的循环将会相应更新。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒

单体目标

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

主动天赋

被动天赋

[[spell:1122]]

[[spell:152108]]

[[spell:17877]]

[[spell:196447]]

[[spell:6353]]

[[spell:80240]]

[[spell:1245633]]

[[spell:1244310]]

[[spell:1244877]]

[[spell:1244928]]

[[spell:387108]]

### 单体目标

1.1.

#### 单体目标优先级

毁灭专精主要围绕通过填充法术产生灵魂碎片，然后将其用于释放大量爆发伤害。该专精并不遵循严格且固定的输出循环；相反，重点在于利用出现的机会。

1. **适用条件：恶魔使徒（启用）。** 始终保持 [[spell:348]]。
2. **适用条件：地狱召唤者（启用）。** 始终保持[[spell:445465]]。
3. **适用条件：召唤地狱火（启用）。** 施放[[spell:1122]]。
4. **适用条件：地狱召唤者（启用）。** 施放[[spell:430014]]。
5. **适用条件：Shadowburn（启用）。** 可用时立即施放[[spell:17877]]。
6. **适用条件：Soul 火焰（启用）。** 如果碎片低于4个，则可用时施放[[spell:6353]]。
7. 如果即将达到灵魂碎片上限，则施放[[spell:116858]]。
8. **适用条件：Cataclysm（启用）；Lake of 火焰（启用）。** 冷却完毕时施放[[spell:152108]]
9. **适用条件：恶魔使徒（启用）。** 当灵魂碎片少于4个时，施放[[spell:433891]]。
10. **适用条件：Channel Demonfire（启用）。** 可用时立即施放[[spell:196447]]。
11. 如果你有2层充能，则施放[[spell:17962]]，可能用于加速像[[spell:116858]]这样的长读条法术。
12. 施放 [[spell:17962]] 来产生灵魂碎片。
13. 施放 [[spell:29722]] 来产生灵魂碎片。

### 群体伤害

1.2.

#### 多目标优先级

毁灭 在有稳定顺劈的环境中可以蓬勃发展，因为我们能高效地处理顺劈。在许多情况下，次要目标的存在实际上会显著提升我们的单体输出，这要归功于产生的额外资源。

1. **适用条件：恶魔使徒（启用）。** 在主目标身上保持[[spell:348]]。
2. **适用条件：地狱召唤者（启用）。** 在尽可能多的目标身上保持[[spell:445465]]。
3. **适用条件：召唤地狱火（启用）。** 施放[[spell:1122]]。
4. **适用条件：地狱召唤者（启用）。** 在尽可能多的目标受到[[spell:445465]]影响时施放[[spell:430014]]。
5. **适用条件：Roaring Blaze（未启用）；地狱召唤者（未启用）。** 在任何至少能持续10秒的次要目标身上施加[[spell:348]]。
6. **适用条件：Roaring Blaze（启用）。** 对主目标使用[[spell:17962]]，以在次要目标身上传播[[spell:348]]。
7. **适用条件：Roaring Blaze（启用）；地狱召唤者（启用）。** 对主目标使用[[spell:17962]]，以在次要目标身上传播[[spell:445465]]。
8. **适用条件：Cataclysm（启用）。** 冷却完毕时施放[[spell:152108]]，除非延迟几秒可以命中更多目标。
9. **适用条件：地狱召唤者（启用）；Shadowburn（启用）。** 在[[spell:430014]]期间，可用时施放[[spell:17877]]。
10. **适用条件：恶魔使徒（启用）。** 如果可用，使用[[spell:116858]]或[[spell:17877]]来触发[[spell:470479]]
11. **适用条件：地狱召唤者（启用）。** 如果有4个以上目标，则施放[[spell:5740]]。
12. **适用条件：Shadowburn（启用）。** 可用时立即施放[[spell:17877]]。
13. **适用条件：恶魔使徒（启用）。** 如果有3个以上目标，则施放[[spell:5740]]。
14. **适用条件：Soul 火焰（启用）。** 如果碎片低于4个，则可用时施放[[spell:6353]]。
15. 如果你有5个灵魂碎片，施放 [[spell:116858]]。
16. **适用条件：恶魔使徒（启用）。** 如果碎片低于3个，则施放[[spell:433891]]。
17. **适用条件：Cataclysm（启用）。** 施放[[spell:152108]]。
18. **适用条件：浩劫（启用）。** 如果存在次要目标，则施加[[spell:80240]]。
19. **适用条件：Channel Demonfire（启用）。** 可用时施放[[spell:196447]]。
20. 施放[[spell:17962]]以产生灵魂碎片和[[spell:196406]]层数。
21. 施放 [[spell:29722]] 来产生灵魂碎片。

### 起手序列

**适用条件：Soul 火焰（启用）。**

[[spell:6353]]

**适用条件：Soul 火焰（未启用）。**

[[spell:29722]]

**适用条件：恶魔使徒（启用）；Soul 火焰（未启用）；Lake of 火焰（未启用）。**

[[spell:348]]

**适用条件：Lake of 火焰（启用）；Soul 火焰（未启用）。**

[[spell:152108]]

**适用条件：地狱召唤者（启用）；Lake of 火焰（未启用）；Soul 火焰（未启用）。**

[[spell:445465]]

[[spell:17962]]

**适用条件：Lake of 火焰（启用）；Soul 火焰（启用）。**

[[spell:152108]]

**适用条件：召唤地狱火（启用）。**

[[spell:1122]]

[[item:250215]]

[[item:241288]]

**适用条件：地狱召唤者（启用）。**

[[spell:430014]]

[[spell:116858]]

[[spell:17962]]

1.3.

#### 起手序列

1. **适用条件：Soul 火焰（启用）。** 预读施放[[spell:6353]]。
2. **适用条件：Soul 火焰（未启用）。** 预读施放[[spell:29722]]。
3. **适用条件：恶魔使徒（启用）；Soul 火焰（未启用）；Lake of 火焰（未启用）。** 预读施放[[spell:348]]。
4. **适用条件：Lake of 火焰（启用）；Soul 火焰（未启用）。** 预读施放[[spell:152108]]
5. **适用条件：地狱召唤者（启用）；Lake of 火焰（未启用）；Soul 火焰（未启用）。** 施放[[spell:445465]]。
6. 施放[[spell:17962]]。
7. **适用条件：Lake of 火焰（启用）；Soul 火焰（启用）。** 施放[[spell:152108]]
8. **适用条件：召唤地狱火（启用）。** 施放[[spell:1122]]。
9. 使用你的饰品和种族技能。
10. **适用条件：地狱召唤者（启用）。** 施放[[spell:430014]]。
11. 施放[[spell:116858]]。
12. 施放[[spell:17962]]。

:::details 小贴士：不要低估诅咒！
随着

[[spell:1265813]]

诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:440057]]是独有的， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者并结合了上述两种诅咒。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

1.

### 至暗之夜 第2赛季套装

第2赛季套装加成如下：

- [[spell:1296571]]增加[[spell:29722]]的伤害，并使触发[[spell:1265770]]的几率翻倍。
- [[spell:1296572]]在受到[[spell:1265770]]影响的目标身上添加一个伤害放大效果。

这两个套装加成都不是特别强，其设计目的是提供被动的伤害提升，不会改变游戏中的优先级或决策。

1.

### 职业与专精机制详解

以下章节介绍了与毁灭和术士相关的各种机制，以及以特定方式使用技能的原因。

### 快照机制

3.1.

#### 快照与高效刷新持续伤害效果

快照是一种隐藏机制，允许你提前刷新某些限时效果而不会受到惩罚。当你的持续伤害效果剩余时间少于其最大持续时间的30%时，你就可以刷新它。这会将新持续伤害效果的最大持续时间与当前持续伤害效果的剩余时间相加。

对于[[spell:348]]，安全刷新的基准值为5.4秒，点出[[spell:388832]]天赋时为6.3秒。

### 浩劫

3.2.

#### 浩劫 使用

[[spell:80240]]是你最重要的法术之一。浩劫会复制你的任何直接法术，而且它确实会影响产生灵魂碎片的技能的灵魂碎片生成量（即，你产生双倍灵魂碎片）。然而，消耗灵魂碎片的技能仍然花费相同数量的碎片，并且只会复制总伤害的60%。

最好使用[[spell:80240]]来复制受灵魂碎片限制的法术，因为这样碎片消耗效率最高。如果可能，尽量在准备好数个灵魂碎片后再进入你的[[spell:80240]]。然后连续倾泻[[spell:116858]]施放，使你的碎片效率翻倍。

在对目标施加减益效果后，[[spell:80240]]的范围为60码，且不受视线要求的影响。随着时间的推移，你将培养出充分利用该技能的知识和直觉。

积累这种经验的好方法是密切关注首领的时间轴。如果你知道敌人将在接下来的10秒内出现，你应该保留你的灵魂碎片和[[spell:17962]]充能，用于浩劫。

如果你有4个灵魂碎片准备就绪，可以在小怪出现后立即施放浩劫。施放[[spell:348]]，然后燃烧，倾泻2个[[spell:116858]]，再燃烧以产生一个灵魂碎片。然而，如果不确定，当第二个目标出现时，冷却完毕就使用浩劫。

记得对次要目标施放[[spell:80240]]，因为它只会以原始值的一定百分比复制单体法术。

请注意，[[spell:387506]]施加的[[spell:80240]]效果持续时间会减少（目前为6秒）。

### 顶点天赋

3.3.

#### 虚无之烬

毁灭的顶点天赋[[spell:1265770]]的设计理念是提供一个法术伤害触发效果，它不一定影响输出循环本身，而是在后台发生。

- 第1层在[[spell:29722]]命中时增加一个小几率，
- 第2层和第3层在纸面上提供短暂的暴击和急速加成，
- 而第4层保证每次使用碎片消耗技能时都会触发一个较弱的效果。

对于第2层和第3层，它们唯一的保证触发方式与碎片消耗绑定，这使得保持高Buff覆盖率成为一项困难的任务。然而，多目标情况是例外。

1.

### 毁灭 术士的重要冷却技能

### 地狱火

4.1.

#### 地狱火

毁灭的主要冷却技能[[spell:1122]]的使用方式相当直接。地狱火在召唤时会眩晕并伤害该区域内的敌人。在整个持续时间内，它将造成近战和脉冲AoE伤害，并被动产生碎片。由于其相对较高的覆盖率，通常最好冷却完毕就使用，尤其是当点出 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒的[[spell:429581]]时。[[spell:1122]]本身看起来可能并不特别强大，尤其是在单体目标中，但用[[spell:417234]]强化消耗技能或用[[spell:266086]]产生碎片的能力，使这个冷却技能出乎意料地强大。

### 大灾变

4.2.

#### 大灾变

在当前的版本和数值调整下，[[spell:152108]]应被视为在一次施放中对目标区域施加最大数量[[spell:348]]的手段，而非AoE爆发工具。它与[[spell:196447]]配合得特别好，并共同在多目标情况下极大地辅助了[[spell:445465]]的管理，尤其是在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者.

虽然在多目标情况下应或多或少地冷却完毕就使用（如果能命中更多目标，可以延迟几秒），但在单体目标中，其相对较弱的法术强度系数使其成为在[[spell:348]]或[[spell:445465]]即将到期时偶尔用来刷新的法术。

根据当前的数值调整，[[spell:152108]]在纯单体目标中并不能提升DPS。

1.

### 毁灭 术士 重要注意事项

### 灵魂碎片

5.1.

#### 灵魂碎片的生成与消耗

每场战斗开始时你拥有3颗灵魂碎片/30个灵魂碎片碎片。战斗中，灵魂碎片通过使用你的核心技能来生成。

- [[spell:1280868]] 施放时生成3个灵魂碎片碎片。
- [[spell:17962]] 施放时生成5个灵魂碎片碎片。
- [[spell:348]] 每次普通跳动生成1个灵魂碎片碎片，暴击跳动时有50%几率额外生成1个灵魂碎片碎片。
- [[spell:6353]] 施放时生成10个灵魂碎片碎片。
- [[spell:17877]]（如果点了天赋）在目标于5秒内死亡时返还其灵魂碎片消耗。
- [[spell:29722]] 普通施放时生成2个灵魂碎片碎片，暴击时额外生成1个灵魂碎片碎片。
- [[spell:196408]] 仅在点了 [[spell:387173]] 天赋时，暴击才会生成1个灵魂碎片碎片。

灵魂碎片主要通过以下技能消耗。

- [[spell:17877]] 消耗1颗灵魂碎片/10个灵魂碎片碎片
- [[spell:116858]] 消耗2颗灵魂碎片/20个灵魂碎片碎片。
- [[spell:5740]] 消耗3颗灵魂碎片/30个灵魂碎片碎片。
- [[spell:688]]、[[spell:697]]、[[spell:712]] 和 [[spell:691]] 每次施放消耗1颗灵魂碎片/10个灵魂碎片碎片。

### 混乱之箭

5.2.

#### 混乱之箭

[[spell:116858]] 施放消耗2颗灵魂碎片/20个灵魂碎片碎片。由于我们最多只能拥有5颗灵魂碎片/50个碎片，这意味着我们在短时间内能可靠施放的 [[spell:116858]] 最多为 [[spell:116858]] → [[spell:17962]] → [[spell:116858]] → [[spell:17962]] → [[spell:116858]]。因此，在增益触发期间施放 [[spell:116858]] 的优先级降低了，因为我们无法在短时间内塞入同样多的施放次数。

### 暗影灼烧

5.3.

#### 暗影灼烧

[[spell:17877]] 在 至暗之夜 中作为斩杀技能回归，有一些细节需要注意，部分与特定天赋选择或目标数量有关。

默认情况下，该技能在目标于施加的减益效果期间死亡时有返还碎片机制，而触发返还的是减益效果，因此每个目标仅限1颗碎片。不过 [[spell:80240]] 可以触发第二次返还。

[[spell:387108]] 极大地增益了 [[spell:17877]]，因为其提供的增益通常足够长，可以覆盖 [[spell:1245633]] 的触发，并且自然延续到斩杀阶段，平均而言超过95%的施放都是暴击，伤害相应提高。

以下列表详细说明了应优先使用 [[spell:17877]] 而非其他碎片消耗技能的目标数量。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒:

- 最多7个目标，仅使用 [[spell:387108]]，无论是否有 [[spell:1244928]]
- 未点 [[spell:387108]] 天赋时，最多4个目标
- 有 [[spell:1244928]] 但没有 [[spell:387108]] 时，多目标情况下绝不能施放 [[spell:17877]]。

[[spell:1245633]] 将上述目标数量各增加1个。

作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者:

- 点了 [[spell:387108]] 天赋时最多4个目标，有 [[spell:1245633]] 时最多6个目标
- 没有 [[spell:387108]] 时，最多4个目标下应仅在有 [[spell:1245633]] 时施放 [[spell:17877]]

### 恶魔选择

5.4.

#### 宠物选择

9.2版本改动后，萨亚德（魅魔或魅魔）在单体伤害方面有明显优势，前提是不存在频繁的远距离目标切换。然而，宠物选择通常由每种宠物提供的独特功能决定：对于防御性驱散，以及如果频繁在远距离目标之间切换，小鬼将提供最高的正常运作时间。

每当需要打断或驱散效果时使用地狱猎犬。虚空行者可以通过其折磨技能提供一些额外的AoE，但其最大的用处在于嘲讽。

魅魔提供额外的控制和对单个目标的永久减速，在某些情况下可能有用。

### 移动能力

5.5.

#### 移动管理

虽然很难描述在地下城或团队副本遭遇中定位和移动的最佳方式，但这是你作为 毁灭 术士 成功的关键。[[spell:111771]] 在许多遭遇中可以非常有效，但被许多玩家和团队低估了。

把 [[spell:111771]] 想象成一个团队冷却技能，可以立即将你的整个团队传送 40 码，这项技能的潜力很快就变得清晰了。询问你的团队是否希望 [[spell:111771]] 放在特定位置；如果不符合你们的策略，就把它当作个人冷却技能使用。

[[spell:17962]] 可以战略性地用来覆盖移动，[[spell:80240]] 也可以。如果目标频繁死亡，在移动量大的战斗中 [[spell:17877]] 也是一个好选择，因为你可以获得2层新的瞬发技能来利用。

你可以通过定位在战斗移动的中心位置来减少移动需求。例如，如果Boss被风筝绕圈移动，你应该待在风筝路径的内侧以确保最小移动。你还应该确定你的 [[spell:268358]] 如何让战斗对你来说更轻松。许多Boss机制可以通过巧妙的传送门来简化，这可以让你腾出手来造成更多伤害。

[[spell:385899]]与[[spell:111771]]配合使用提供了一种快速覆盖长距离的方法，并在需要立即重新定位时可以用于冲刺。

5.5.1.

##### 静默移动

许多玩家会在战斗中无意识地移动，尽管没有必要。例如，有时Boss或小怪会被坦克移动几码，虽然你仍在施法范围内，但你下意识地跟随移动，浪费了你的公共冷却时间。

有意识地努力“减少”你的移动，将不必要的移动降到最低。观察这一点的最佳方式是录制你的团队副本视频，然后观看自己的操作。大多数玩家会惊讶于自己浪费的移动量。当你被迫移动时，让你的路径尽可能直接和果断。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月31日：** 更新了群体输出循环部分。
- **2026年8月12日：** 更新了暗影灼烧的斩杀线。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月23日：** 更新了碎片消耗部分，使用了新的斩杀线。
- **2026 年 3 月 17 日：** 扩展了套装奖励部分。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜的发布更新了输出循环并添加了巅峰部分。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月9日：** 更新了多目标逻辑。
- **2025年8月22日：** 更新了灵魂 火焰 相关内容。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 添加了战斗助手部分。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月25日：** 重新制作了页面布局，并相应地更新了各部分。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 添加了英雄天赋部分和选择器。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 添加了浩劫部分。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 更新了起手式和优先级列表的选择器。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页，你将找到魔兽世界12.1.5中你的 毁灭 术士 的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们都为你准备好了！

1.

### 毁灭 术士 毕业装备指南

欢迎来到我们的 毁灭 术士 配装页面；本节将涵盖正确为你的角色装备所需了解的一切。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含来自所有来源的 毁灭 术士 最高 DPS 配置。请记住，还有许多其他配置的表现在误差范围之内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题：应该以哪些套装部件为目标？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

已被改为保留原物品的基础属性和物品等级，这使得在遵循特定属性分配的同时能够获得套装加成。以下是理想的催化物品，但请注意

**胸甲和腿甲**

是直接掉落的。

- 头部：[[item:271874@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:239031@JAACAAAG2A]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸甲：[[item:271549@JAACAAgNyA]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 手套：[[item:268243]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿甲：[[item:271545@JAACAAgNyA]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

优先获取套装加成而非理想的属性分配，因为前者带来的DPS提升更高。

:::

:::details 常见问题我应该从大宝库中选择哪些物品？
团队副本中的稀有掉落以及在模拟中

[最佳装备](<https://www.raidbots.com/simbot/topgear>)

能带来最高提升的物品应优先追求。以下是值得追逐的部分物品：

- [[item:271092]]：仅凭物品等级就是最佳的施法者武器
- [[item:271874@JAACAAAG2A]] 和 [[item:268265@JAACAAAG2A]]，高物品等级且带有强力咒术效果的物品
- [[item:270164@JAACAAgNyA]] 是本赛季最好的饰品

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护肩</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含来自所有来源的 毁灭 术士 最高 DPS 配置。请记住，还有许多其他配置的表现在误差范围之内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题：应该以哪些套装部件为目标？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

已被改为保留原物品的基础属性和物品等级，这使得在遵循特定属性分配的同时能够获得套装加成。以下是理想的催化物品，但请注意

**胸甲和腿甲**

是直接掉落的。

- 头部：[[item:251199@JAACAAgNyA]]，来自 [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- 肩部：[[item:239031@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸部：[[item:273785@JAACAAgNyA]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 手部：来自的[[item:159247@JAACAAgNyA]] [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 腿部：[[item:251160@JAACAAgNyA]] 来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

优先获取套装加成而非理想的属性分配，因为前者带来的DPS提升更高。

:::

:::details 小贴士：应该优先刷哪些地下城？
如果你的游戏时间有限，可以考虑刷以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：武器和饰品
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：项链、腰带和第二个饰品
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：饰品和非套装件

:::

:::details 常见问题：双手法杖和单手武器+副手之间有区别吗？
只要物品等级相同，两者在总属性值上就没有区别。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:251199@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护肩</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:251137@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含来自所有来源的 毁灭 术士 最高 DPS 配置。请记住，还有许多其他配置的表现在误差范围之内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题：应该以哪些套装部件为目标？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

已被改为保留原物品的基础属性和物品等级，这使得在遵循特定属性分配的同时能够获得套装加成。以下是理想的催化物品，但请注意

**胸甲和腿甲**

是直接掉落的。

- 头部：[[item:271874@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩膀：[[item:268241]]，来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- 胸甲：[[item:271549@JAACAAgNyA]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 手套：[[item:268243]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿甲：[[item:271545@JAACAAgNyA]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

优先获取套装加成而非理想的属性分配，因为前者带来的DPS提升更高。

:::

:::details 小贴士：团队副本中最重要的掉落是什么？
以下是值得优先获取的最重要掉落。

- [[item:271092@JAACAAAG2A]]：物品等级最高的武器。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:271874@JAACAAAG2A]]：在属性预算较高的部位中物品等级最高且属性优秀。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:270164@JAACAAgNyA]]：团队副本中最佳的饰品替代品。掉落自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270170@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 毁灭 术士 饰品推荐

以下列表提供了所有可供玩家获取的饰品的综合排名，以便更好地了解哪些饰品可能更具吸引力。这些排名假设每件物品都处于其最高可能的物品等级，因此若要进行直接或即时的装备提升，最好还是对自己的角色进行模拟。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **毁灭 术士 饰品**
**毕业 -**

[[item:250215@JAACAAgNyA]]

和

[[item:281215@JAACAAgNyA]]

**次选被动饰品——**

[[item:270164@JAACAAgNyA]]

或

[[item:250224@JAACAAgNyA]]

**次选主动饰品——**

[[item:270170@JAACAAgNyA]]

或

[[item:270168@JAACAAAG2A]]

:::

任何未在此列表上显示的饰品，通常都被认为比此列表上所有其他饰品都要差。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 毁灭 术士 饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;<li>[[item:273649@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169@JAACAAAG2A]]</li>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:158368@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 作为额外战利品使用，可保证从首领或地下城的掉落列表中掉落一件物品。虽然掉落本身是随机的，但每额外消耗一个虚空核心，都会保证在掉落列表全部掉落完之前不会出现重复物品。

3.1.

#### 毁灭 术士 推荐的虚空核心使用方式

朦胧虚空核心是一种宝贵但有限的资源，虽然通常应用于填补玩家当前装备的空缺，但重要的是要记住，能多快保证获得一件物品，取决于该来源已经掉落了多少件其他物品。

并非所有掉落都同样重要，以下是应优先关注的通用优先级列表：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心定向优先级**
1. 史诗级路线的[[item:271092@JAACAAAG2A]]
2. 史诗级 [[item:271874@JAACAAAG2A]]
3. 史诗级武器（单手或双手）；
4. 史诗级饰品（尤其是 [[item:270164@JAACAAgNyA]]）；
5. 缺少2件套或4件套加成的套装部件；
6. 你BiS列表中影响最大的部位。

:::

3.2.

#### 晋升毒液石

[[item:280562]]作为第2赛季中升级装备的方式回归。以下是各装备部位的升级优先顺序：

1. 主手武器最为重要
2. 副手武器
3. 主动使用饰品
4. 被动饰品
5. 项链。

[[item:280562]]也可用于将后2个首领掉落的英雄难度命运骰子物品升级至340物品等级。

1.

### 毁灭 术士 最佳制造物品

制造装备的主要限制因素仍然是每周发放的火花，这是制作高端装备所必需的，因此了解如何处理这个问题很重要。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **毁灭 术士 制造装备优先级**
1. 总体最佳组合是手腕部位使用[[item:240167]]，副手饰品使用[[item:273059]]，但这适用于装备已毕业的角色，因此应被视为长期策略，更适合那些不需要立即获得最高战力提升，而是选择最少重铸次数和资源投入的玩家。
2. 如果重点是立即获得战力提升，那么使用4个火花制作带有[[item:273060]]的[[item:245770@JAAGAAwt1ENMMYD]]，并以较低物品等级制作带有[[item:240167]]的手腕，能提供最大的DPS提升。

:::

每次制造所使用的公函如下：

- 武器和手腕使用[[item:245786]]
- 其他任何部位使用[[item:245783]]

:::details 常见问题：为什么我们要先制造一件并非毕业最佳的武器？
武器提供最高额的主属性，尤其是在前期，这是非常珍贵的资源。然而制造物品的物品等级上限比完全升级的史诗级替代品低4个物品等级，因此在高端装备方面有所限制，前提是玩家能够获得那种级别的装备。

:::

:::details 常见问题：是否值得为更换公函而重铸？
如果相关的重铸成本不是问题，可以考虑在任何时候模拟你自己的角色，以获得当时最佳的铭文。在单件装备上更改副属性不太可能带来超过十分之一个百分点的 DPS 提升。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 为装备添加插槽

在第2赛季中，[[item:275707]]可在宏伟宝库中以6个代币兑换，可用于为任意头部、腰部或手腕物品添加插槽。

1.

### 纹章使用

迷雾纹章是一种有每周上限的赛季限定货币，上限每周增加，用于将物品升级至各自奖励路线中的最高等级。

由于每个装备部位的设计不同，其战力也存在差异，这与特定效果或更高的属性有关。因此，以下是投资迷雾纹章最有价值的部位顺序：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **毁灭 术士 饰章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**项链**

➜

**副手**

➜

**肩部/手套/腰带/靴子**

➜

**戒指**

➜

**手腕/披风**

:::

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月31日：** 更新了饰品列表。
- **2026年8月16日：** 更新了最佳配装列表、美化和饰品，以适应新的属性配置和饰品调整。
- **2026年8月11日：** 更新了宝石和常见问题解答部分。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月22日：** 更新了最佳装备列表以考虑不同的天赋。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 17 日：** 更新了饰品排名以考虑凝视的削弱。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为 至暗之夜 发布进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月24日：** 根据调整更新了暗影牧师的插槽推荐。
- **2025年6月15日：** 为 11.1.7 补丁和暗影牧师进行了更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月4日：** 已更新饰品推荐。
- **2025年3月4日：** 更新了毕业装备列表和饰品排行。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为 11.0.7 补丁和赛尔西的指环进行了更新。
- **2024 年 10 月 30 日：** 热修后更新了最佳装备列表。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 添加了第1赛季毕业装备列表，更新了饰品部分。
- **2024年8月21日：** 添加了赛季前毕业装备列表部分。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季上线进行了更新。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 为 10.2.5 补丁更新了饰品部分。
- **2023年11月7日：** 在波纹孢子斗篷被削弱后更新了美化推荐。
- **2023年11月6日：** 为 10.2 补丁和第3赛季更新了装备推荐。
- **2023年9月4日：** 重新格式化了页面，包含毕业装备表格和部分更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月24日：** 更新了黑龙戒指部分以考虑正式服的在线修复。
- **2023年3月20日：** 添加了 10.0.7 补丁新戒指部分。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月13日：** 更新了美化推荐。
- **2022年12月11日：** 已为第一赛季上线更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面，你将找到你的 毁灭 术士 的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和玩法相互作用。我们的内容已针对《魔兽世界》12.1.5版本更新。

1.

### 毁灭 术士 属性优先级

毁灭 术士 的属性优先级如下：

装备等级

急速达到22%

暴击

精通

急速

全能

值得注意的是，我们的副属性在价值上相对接近，因此通常认为优先考虑物品等级是最好的方法，尤其是当你接近属性收益递减时。更均衡的属性分配优于将两个最佳属性堆叠到收益递减的程度。

1.

### 深入属性解析

**智力** 是你的主属性。你应该在所有升级中寻找该属性。它为你提供法术强度，增加你法术的伤害。

**急速** 影响你的法术施放速度。[[spell:348]] 的跳动频率也会提高，[[spell:17962]] 的冷却时间则会缩短。这有助于在急速等级较高时显著提高灵魂碎片的生成。你的恶魔也会随急速而增强。

**暴击** 提高你所有法术和技能的暴击几率。[[spell:116858]] 总是暴击，其伤害会随你的暴击等级提高，每 1% 暴击提供 1% 伤害。[[spell:348]] 暴击产生灵魂碎片的几率翻倍。你的恶魔也会随暴击而增强。

**精通**，通过 [[spell:77220]] 提高你在指定范围内随机量的伤害输出。这不影响宠物伤害。

**全能** 是纯粹的伤害输出提升和受到的伤害降低。你的恶魔也会随全能而增强。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对至暗之夜前夕进行审查。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1版本更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面，我们列出你的 毁灭 术士 能获得的最佳宝石、附魔、药水和食物，这基于你的 [属性优先级](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

可镶嵌宝石分为两类：史诗和稀有。前者提供强大的效果但只能装备1个，后者包括单属性或双副属性组合的宝石。

宝石可以通过来自宝库的[[item:275707]]物品镶嵌到头盔、护腕或腰带上。

闪耀钻石史诗宝石的选择是[[item:240983]]或[[item:240967]]。在获得史诗级装备之前前者更优，之后后者表现更好。

在物品属性方面，选择暴击宝石能获得最佳效果，因为该副属性对术士总体而言非常强大。[[item:240898]]是你与[[item:240983]]搭配的最佳宝石，而通过装备4个不同颜色的稀有宝石来激活[[item:240967]]的完整收益也非常重要。

你应该装备的四种稀有宝石是：

- 橄榄石：[[item:240890]]
- 青金石：[[item:240914]]
- 紫水晶：[[item:240900]]
- 石榴石：[[item:240906]]

<em>强烈建议使用 [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 来模拟你角色的理想宝石和附魔，因为它们可能与一般推荐不同。</em>

**确保在选项中勾选"Always use"和"Only 4+ Colors"复选框。**

1.

### 最佳附魔和武器强化

在所有内容中使用 [[item:243733]] 作为你的武器油。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243973]]</li>&#10;<li>[[item:244031]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

副属性武器附魔可能比 [[item:244029]] 提供更好的价值，但哪一个对你最好很大程度上取决于你其余的装备。因此，根据你当前的属性分布，你可能需要 [模拟自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)，因为你最佳的副属性附魔可能与上面列出的不同。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

对于第 2 赛季，[[item:241326]] 是默认选择。

[[item:241322]]在使用[[item:250215]]饰品和[[item:244031]]时能获得大量价值，因此请务必调整你的消耗品。

3.2.

#### 药水

如果你的装备几乎没有全能，那么[[item:241288]]应该是首选，否则使用[[item:241308]]。

[[item:271883]]是治疗药水的选择。

3.3.

#### 食物

[[item:242275]]和[[item:255846]]是推荐的食物。你可以直接购买最便宜的那种，或者在团队提供盛宴时食用。

在灭团/死亡相当频繁的情况下，应考虑丰盛版本的食物，因为它们在死亡后仍然存在。

3.4.

#### 强化符文

[[item:259085]]提供约1%的DPS提升，应在开荒期间评估，尤其是在接近关键击杀时。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月16日：** 更新了消耗品以反映新的最佳配装列表。
- **2026年8月11日：** 更新了宝石。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 更新了茶部分。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月22日：** 更新了武器附魔。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月12日：** 更新了武器附魔和磨刀石。
- **2024年9月9日：** 更新了宝石部分，因为策略发生了变化。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 在腐化之怒增益后更新了药水推荐。
- **2023年3月24日：** 更新了原始宝石推荐以考虑额外的正式服在线修复。
- **2023年3月22日：** 更新了原始宝石推荐以考虑25%增益的在线修复。
- **2023年3月20日：** 为 10.0.7 补丁添加了原始宝石部分。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月7日：** 将地下城药水更新为更可靠的微温全能药水。
- **2022年12月14日：** 更新了武器符文。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的毁灭术士挑战大秘境地下城的技巧和建议。

1.

### 毁灭术士在至暗之夜第2赛季的大秘境中

大秘境已成为《魔兽世界》终局内容的重要组成部分，但数量庞大的各种变量让许多玩家感到不知所措。队伍构成、每周词缀、队伍装等、钥石等级以及队伍的经验和舒适度，只是影响你如何应对每个地下城的几个因素。本页面的目的是让你为大秘境区别于典型《魔兽世界》终局体验的关键差异做好准备，包括那些乍看之下可能不明显的天赋和输出循环异常。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

[毁灭 术士](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-guide>)在所有输出职业中拥有最高的即时爆发和2目标顺劈潜力，同时冷却时间足够短且强力，可以在每次拉怪中频繁使用。该专精仍然保留了所有职业基础工具，包括治疗石、灵魂石、诅咒、用于跳怪的[[spell:111771]]、以及[[spell:30283]]和[[spell:5484]]等群体控制技能。

1.

### 最佳大秘境天赋配置

### 最佳大秘境天赋

2.1.

#### 毁灭术士的大秘境天赋

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒配装提供更高的顺劈伤害，并使用[[spell:205184]]作为主要手段来在多目标上管理[[spell:348]]。更加强调[[spell:17877]]机制，因为该法术通过巧妙地狙杀濒死目标来触发碎片返还，具有通过高伤害进行杠杆操作的巨大潜力。

由于其更快的爆发，它通常更适合每周钥石，因为战斗不会持续那么久。

要直接在游戏内导入配装，请点击计算器底部的导出按钮

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysNzYmFzYZZMAAYGjZmZBMmxwCMw2wCNWYAAgxMMsBgZGgxMjZ2AAAMzMzAAYMM"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfhiklnoELM028MTjehprTwwJbM-lZaswSYEJ1FYYo0wBi6DowQxhrrNPxj-AAAA-AOQo0QowITgwwC-
```

:::

### 地狱召唤者变体

2.2.

#### 地狱召唤者毁灭术士的大秘境天赋

该变体选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者系以牺牲AoE为代价获得更多单体伤害。由于[[spell:445465]]覆盖率极其重要，[[spell:205184]]再次成为配装核心，如果你经常拉超过7个怪，可以选择将[[spell:387384]]中的2点移出，以获得[[spell:152108]]和[[spell:1244877]]。

在高层钥石中 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者表现亮眼，因为该环境下通常会有更多目标的拉怪和更长的战斗，使[[spell:440043]]叠加更高，并有更多[[spell:5740]]能够打出完整伤害。

要直接在游戏内导入配装，请点击计算器底部的导出按钮

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWmtZmZmFzYZZMAAYGjZmZxCMwsY0YGAzG2YAAgxghNAgZGMmZY2AAAMzMzAAYMM"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPSfiklnoELM028MTjchprTwwJbM-lZaswSYEJ1FYYo0wBi6DowQxhrrNxjE-AAAA-JQSU2AIQYgxBzC-
```

:::

1.

### 毁灭术士的大秘境灵活天赋

### 功能/防御天赋替换

3.1.

#### 功能/防御灵活天赋

关于AOE打断，[[spell:30283]]和[[spell:5484]]通常可以互换，应在存在免疫眩晕或恐惧的目标时，以及更快的冷却时间是否更重要时进行评估。

[[spell:710]]是一个更加小众的工具，可以将畸变怪、恶魔或元素目标从战斗中移除长达30秒。它对首领无效，在首领战斗中大多数时候主要机制通常会出现免疫该法术的目标。

[[spell:268358]]和[[spell:111771]]可以被视为重新定位工具，后者通常允许特定路线的跳怪，前者则用于个人处理那些会迫使长时间移动的机制。

对于[[spell:108416]]的辅助天赋，[[spell:386664]]减少生命值损失，主要用于需要保持在一定生命值阈值以上的场合，但总体而言不如其替代选择[[spell:386686]]适用，后者冷却时间更快，因此有更多机会减免伤害。

反过来，对于[[spell:104773]]，选择[[spell:317138]]使伤害减免更为显著，通常是首选，因为基础冷却时间足够长，只有在特定战斗需要在3分钟内进行两次减伤时，才应考虑使用[[spell:386659]]。

### 伤害天赋替换

3.2.

#### DPS灵活天赋

两种配装都针对最高的总体伤害输出进行优化，同时仍提供强大的优先目标伤害和爆发。话虽如此，如果更希望更频繁地打击优先目标，而非拥有更频繁但更短的复制窗口，可以将[[spell:387506]]换成[[spell:80240]]。

可以将[[spell:387384]]中的2点从[[spell:152108]]和[[spell:1244877]]移出，以获得更多单体伤害。

[[spell:6353]]和[[spell:1245089]]可以换成2/2 湮灭，以获得更多AoE，代价是单体伤害大幅下降。

1.

### 大秘境深度输出循环提示

虽然单体和多目标循环与中概述的标准优先级没有实质性差异 [循环、冷却与技能页面](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>) 有几点值得注意：

- 虽然[[spell:5740]]在数值上通常很强，但目标因风筝或走位而移出范围会影响该法术的整体效果。在难以利用大量[[spell:5740]]的情况中，考虑改用[[spell:80240]] [[spell:116858]]进行顺劈。
- 毁灭的工具组在爆发目标和集中优先目标伤害方面非常出色，这得益于多个[[spell:348]]能提供的惊人碎片生成，因此在那些比起AoE更需要关注关键目标的周次中请牢记这一点。

1.

### 功能技能与能力

虽然伤害是带毁灭术士的更大原因，但该职业本身提供了相当数量的控制和各种辅助能力：

- 诅咒最近回归，可以针对特定危险敌人提供一些优势：[[spell:1714]]可以降低团队的打断需求。同时，[[spell:702]]减轻坦克受到的普通攻击伤害。最后但同样重要的是，[[spell:334275]]可以在需要风筝时减速目标。
- [[item:5512]]冷却时间为1分钟，恢复25%最大生命值，允许每位玩家进行一次紧急治疗。
- [[spell:20707]]提供战斗复活，你可以在死亡跑尸的情况下主动和预防性地使用。
- [[spell:111771]]提供了独特的能力，可以根据地下城跳过地图的某些部分，避免特定的小怪。
- [[spell:30283]]是一个3秒的AOE眩晕，有助于在大型拉怪时减轻坦克的压力。
- [[spell:5484]]在当前版本中，点出[[spell:1270255]]后，作为短冷却时间的群体打断技能尤其强大。
- [[spell:5782]]和[[spell:710]]都是可重复施放的控制技能，可在紧急情况下打断施法或暂时移除目标的战斗能力。

:::details 小贴士：不要低估诅咒！
随着

[[spell:1265813]]

诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:440057]]是独有的， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者并结合了上述两种诅咒。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

:::details 常见问题如何最好地使用凋零？
灾厄是诅咒的强化版本，但代价是绑定2分钟冷却时间且仅持续12秒。因此应将其视为队伍的防御性冷却技能，以便在适用时减轻即将到来的伤害。每个灾厄遵循与其对应诅咒相同的规则：

- [[spell:1271748]]适用于任何攻击，降低攻击频率和暴击几率
- [[spell:1271802]]适用于任何可被打断的施法

:::

1.

### 应对词缀

### 词缀：升腾

6.1.

#### 毁灭术士的升腾者词缀应对

大约每分钟一次，萨拉塔斯会出现并召唤总共10个升腾宝珠，其施法需要被打断。任何控制或打断法术均可生效：

- [[spell:30283]];
- [[spell:5484]]（上限为10个）；
- [[spell:5782]];
- [[spell:6789]];
- 宠物打断。

### 词缀：虚缚

6.2.

#### 毁灭术士的虚空束缚词缀应对

战斗中，萨拉塔斯会召唤一个虚空大使来强化附近的敌人，它成为优先目标，最好集火击杀。

### 词缀：脉冲星

6.3.

#### 毁灭 术士 脉冲星词缀应对

战斗中，萨拉塔斯会显现脉冲星宝珠，缠绕并环绕玩家15秒。对于该机制没有特别的建议，只需承受这些宝珠即可，虽然移动速度降低可以用[[spell:111400]]来抵消。

### 词缀：吞噬

6.4.

#### 毁灭 术士 吞噬词缀应对

周期性地，萨拉塔斯会对所有5名玩家施加护盾减益，可以通过治疗量或驱散来移除。诸如[[spell:6789]]和[[item:5512]]之类的治疗技能可以在没有其他驱散手段时帮助移除护盾。

- [[spell:688]][[spell:89808]]可以驱散一个护盾。

1.

### 毁灭 术士 宠物选择

地狱猎犬通常是最佳选择，因为它能提供打断能力，这在大秘境中是巨大的优势；如果你需要额外的驱散，可以考虑换成小鬼。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 针对每次解锁节点的变化更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月19日：** 为 11.0.5 补丁进行了更新，并添加了地下城提示部分。
- **2024年9月9日：** 针对第1赛季上线更新了天赋选择。
- **2024年7月19日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 为10.2.5版本更新了天赋。
- **2024年1月3日：** 更新了天赋和属性。
- **2023年11月6日：** 为10.2补丁和第3赛季进行了更新。
- **2023年9月4日：** 重构了天赋部分。
- **2023年7月10日：** 针对10.1.5补丁更新了天赋。
- **2023年5月1日：** 为10.1补丁更新了天赋。
- **2023年3月20日：** 为 10.0.7 补丁更新了天赋。
- **2023年1月24日：** 添加了地狱火部分，并更新了天赋推荐。
- **2022年12月11日：** 更新了推荐配置。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页，你将找到许多有用的宏和插件，让你在魔兽世界12.1.5补丁中使用 毁灭 术士 时更加轻松。

1.

### 最佳宏

以下是常用宏的示例；你可以根据需要将其调整为任何法术。

1.1.

#### 宠物宏

这些宏允许你管理你的恶魔，因为将宠物姿态设置为协助是首选的游玩方式。

#### 宠物攻击

```wow-macro
/petattack
```

这会命令你的恶魔攻击你的目标。

#### 宠物跟随

```wow-macro
/petfollow
```

这会命令你的恶魔跟随你。

#### 宠物移动

```wow-macro
/petmoveto
```

这会命令你的恶魔移动到你指定的位置。此宏在需要让宠物处于预定位置以完成特定任务时特别有用——例如打断一个原本超出范围的目标——但也可用于最大化恶魔卫士的顺劈/[[spell:89751]]伤害，不过要注意任何下达的命令也会使你的恐惧猎犬、邪犬（如果点了天赋）和暴君移动，如果使用不当会造成更大的损失。

1.1.1.

##### 鼠标指向持续伤害技能

#### 鼠标指向腐蚀术

```wow-macro
#showtooltip 腐蚀术
/use [@mouseover,harm] [harm] 腐蚀术
```

如果鼠标指向的目标是敌对且存活的，则对其施放[[spell:172]]，否则对当前目标施放。

值得一提的是，暴风雪在控制设置中增加了将所有施法切换为鼠标指向逻辑的功能，不过某些技能可能无法正常运作，因此仍然建议花点时间为任何需要鼠标指向用例的技能制作一个宏。

1.1.2.

##### 放逐焦点

#### 放逐焦点

```wow-macro
#showtooltip 放逐术
/use [mod:shift,@focus] [] 放逐术
```

按住Shift同时对焦点目标施放[[spell:710]]，否则对当前目标施放。

1.1.3.

##### 灵魂石鼠标指向

#### 灵魂石鼠标指向

```wow-macro
#showtooltip 灵魂石
/target [@mouseover] 灵魂石
/use 灵魂石
/targetlasttarget
```

针对当前与鼠标指向已死亡盟友相关的bug的变通宏。该宏会先选中鼠标指向的目标以施放[[spell:20707]]，然后切换回之前的目标。

1.1.4.

##### 恶魔法阵

#### 恶魔法阵

```wow-macro
#showtooltip
/stopcasting
/use [mod:shift] 恶魔法阵; [nomod] 恶魔法阵：传送
```

按住Shift放置恶魔之环，或不使用修饰键传送到法阵，同时取消任何正在进行的施法。这样你就省去了手动打断施法的麻烦（以及时间！）。

1.1.5.

##### 暗影之怒/恐惧嚎叫

#### 暗影之怒/恐惧嚎叫

```wow-macro
#showtooltip
/use [known:暗影之怒,@cursor] 暗影之怒; [known:恐惧嚎叫] 恐惧嚎叫
```

根据所选天赋，在光标处施放[[spell:30283]]或改为施放[[spell:5484]]。

1.2.

#### 浩劫

#### 浩劫

```wow-macro
#showtooltip
/cast [@mouseover,harm] 浩劫; [harm] 浩劫
```

此宏在你有鼠标悬停目标时对其施放 [[spell:80240]]，否则施放在你的目标上（前提是敌人）。不推荐对此技能使用鼠标悬停宏，因为这很容易导致将 浩劫 施加到错误的目标上。只有在鼠标悬停是你的偏好时才使用此宏。

1.3.

#### 光标 火焰之雨

#### 光标 火焰之雨

```wow-macro
#showtooltip
/cast [@cursor] 火焰之雨
```

有些人可能会觉得这个宏非常有用。它会将[[spell:5740]]放置在你光标所在的位置，而不需要不断将绿色圆圈放置到你想要的地方。这是一种放置[[spell:5740]]的更快方式。

1.4.

#### 光标 大灾变

#### 光标 大灾变

```wow-macro
#showtooltip
/cast [@cursor] 大灾变
```

与上面的宏类似，这个宏在光标位置施放[[spell:152108]]，绕过了瞄准圈和需要点击两次的操作。

1.5.

#### 暗影灼烧

#### 暗影灼烧

```wow-macro
#showtooltip
/cast [known:暗影灼烧,@mouseover,harm] 暗影灼烧;
[known:Shadowburn,harm] Shadowburn
```

这是一个用于[[spell:17877]]的鼠标悬停宏，因为它比单独选中目标更快地帮助你从姓名板上狙杀濒死的目标。如果鼠标位置没有可用的目标，它将改为对当前目标施放。

1.

### 最佳插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.1.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.2.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.2.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.2.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.2.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.3.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.3.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行审查。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
