## 专精概览

Welcome to our Frost Death Knight guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Frost Death Knight in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Frost Mythic+ Resources

[NEW! Top Frost Talent Builds](<https://raider.io/specs/frost-death-knight/talents>)

[Top Frost Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/death-knight/frost>)

[Frost Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=death-knight--frost>)

[Popular Frost Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=death-knight--frost>)

1.

### Frost Death Knight Overview

Frost Death Knight is a melee DPS spec that deals significant direct damage
through hard-hitting attacks like [[spell:49020]] and [[spell:207230]], as well as 
abilities such as [[spell:49143]], [[spell:194913]],
and [[spell:1249658]]. It generally does not do well in cleave and AoE,
excelling in Single Target scenarios.
It can wield two-handed weapons as well as one-handed
weapons. Frost also has a solid defensive raid cooldown in the form of [[spell:51052]].

Good Single Target

Frost Death Knight has a good damage profile with a burst window every 45 seconds
and stronger ones every 1.5 minutes. Importantly, they are both front-loaded with the majority
of the damage coming in the first 15 seconds. We have an easy time target-swapping
as the primary build-up of [[spell:51714]] stacks quickly.

Good Single Target

Frost Death Knight is a good pick for a raid environment due to our good
single target. We unfortunately do not do well in AoE unless we talent
into a significant single target loss. The main drawback
is the lack of a proper raid buff, as well as forcing primarily Single Target.

Okay Damage, Lacking Utility

Frost Death Knight is good in Mythic+, mainly because of our lower single target
when we talent into more AoE. Frost still does respectable damage overall and is a solid
pick.

Our Mythic+ performance very much depends on tuning. We have to bring great
damage to be worthwhile as our utility is lacking in comparison to other specs.
We are extremely tanky, but do not help the party in a sufficient manner.

Could Be Better

Frost Death Knight unfortunately lacks a significant amount of really useful
utility. We have [[spell:49576]], which is sometimes incredibly useful, but we
lack a significant raid and party buff otherwise. [[spell:51052]] is a nice
defensive magic cooldown and we do have a stop with [[spell:207167]]. Compared
to other classes however, we are not brought due to strong utility unless Grip
is a requirement for a given raid encounter.

Incredibly Tanky

Frost Death Knight is arguably the best defensive DPS spec in the game, tied with
Unholy Death Knight. [[spell:206967]], [[spell:48263]],
[[spell:391571]] and [[spell:454842]] are just a couple of our many passive
defensive talents.

Furthermore, we have [[spell:49998]] that can easily
heal us up when we are in a pickle, allowing us to survive even the most scary
scenarios. There is no surprise that Frost Death Knight has the third fewest
deaths in raid amongst all DPS specs.

Room for Improvement

Frost Death Knight is rather famous for its lacking of mobility. We have historically
been a very slow spec with more focus on avoiding displacement, rather than quickly
moving around. We do have the option with

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse

to pick
up

[[spell:444010]]

, significantly increasing our mobility opportunity. Given
that we tend to run

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer

, we are close to the bottom of all
specs when we are talking about movement capabilities.

2.

### Frost Death Knight in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 has no changes for Frost Death Knights, but that doesnt mean theres no new content available.
Being a mid season patch, its a bit light on new content. But worry not, there is still a new Raid; the new Kith'ix encounter, 
and for [Delves](<https://www.icy-veins.com/wow/delves-guide>) there is the new Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

With both a new Kythu'ix raid, and the Labrynth Mega-Delve being introduced, they serve 
  as a new source of gearing for Frost Death Knights. Kyth'ix drops incredibly powerful 
  items that are all sought after. In addition to all that, we can also upgrade our 
  Weapons, Trinkets, and Necklaces with [[item:280562]] once these become 
  available on October 20th.

2.3.

#### Class Changes

Patch 12.1.5 offers no changes to Frost DKs so far.

As a result, there are a no changes to our
[Talent](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>) recommendations or
[rotational](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>) priorities. Though there are
new gear recommendations from the new raid and Delve Labyrinth on our
[gear](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>) page. We also have a list of 
high-value items to spend your first [[item:280562]] on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_frostpresence.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class TuningHide Patch 12.1 Class Tuning
- **Frost 12.1 Changes**
  
  
  Frost received a significant number of tuning updates to its core abilities, moving
    damage away from its cooldowns into the rotational toolkit. Here is a summary of all the changes:
  
  
  
  
  Nerfs:
  
  
  
  
  - [[spell:51271]] -33%
  - [[spell:1249658]] -20%
  - [[spell:455993]] -30%
  - [[spell:279302]] -20%
  - [[spell:49020]] -23.5%
  - [[spell:439843]] -25%
  - [[spell:441378]] -17%
  
  
  
  
  Buffs:
  
  
  
  
  - [[spell:49184]] +100%
  - [[spell:47568]] +30%
  - [[spell:194913]] +30%
  - [[spell:435010]] +30%
  - [[spell:55095]] +100%
  - [[spell:196770]] +40%
  - [[spell:207230]] +20%
  - [[spell:49143]] +25%
  
  
  
  
  Overall, this benefits dual-wield builds due to the nerfs to [[spell:49020]] damage 
    (and a tier set that synergises heavily with [[spell:435010]]).
    Other than that, we mainly see a slightly flatter damage profile with less emphasis on burst.
    As an example, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse previously had a peak to valley ratio of 4.4
    which in 12.1 is closer to 3.4.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Changes for Frost Death Knight

Frost Death Knight has not received a significant number of changes
in Midnight. Frost Death Knights received a rework in the middle of
The War Within and it seems the developers are happy with this new iteration.
We saw some minor changes within the talents,
buffing [[spell:207057]] and [[spell:455993]], adding a frost-damage component to baseline
[[spell:49020]] and making [[spell:47568]] have no travel time.

2.5.

#### New Apex Talents

We have received three new talents in our spec tree that we can talent into as we
level from 80 to 90. These are generally really powerful, buffing [[spell:279302]]
specifically. We get a huge raw damage increase to the ability, a Haste buff whenever we use it,
a [[spell:51271]] extension as well the option to recast the wyrm within 45 seconds
of using it initially.

2.6.

#### Hero Talent Changes

Both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer have received three new talents.
Rider gets [[spell:1265959]], [[spell:1265949]] and [[spell:1265971]]. Deathbringer receives
[[spell:1265859]], [[spell:1265932]] and [[spell:1265855]].

The impact to us is not that
significant from these talents, mainly presenting some nice damage increases in interesting ways.
Echoing Fury granting two stacks of [[spell:441378]] is probably the most impactful as it
generates a significant amount free procs of [[spell:51128]].

2.7.

#### Tuning and Quality-of-life

[[spell:49020]] now deals a portion of its damage as Frost Damage by default. This
provides a nice tuning knob for Blizzard to help bridge the huge gap between raw Obliterates
and [[spell:51128]] Obliterates.

[[spell:455993]] now also deals 300% additional damage to the main target when it consumes
stacks of [[spell:51714]]. This is a significant single-target buff to the ability that previously
struggled in that scenario. This significantly buffs dual-wield builds and make them more viable
in all content.

[[spell:47568]] is now instant and no longer has a projectile. This is a very useful
change to an otherwise great ability. Currently, the projectile aspect of Empower Rune Weapon
causes issues on certain bosses where we see up to 0.5 seconds delay before we actually get
our Runic Power and [[spell:51128]] proc. This makes the rotation feel a bit more laggy
and disrupts your otherwise practiced flow. We can now always reliably expect the Killing Machine
to come at a specific time.

2.8.

#### Class Tree Changes

The Death Knight class tree has also seen some minor changes. [[spell:337957]], [[spell:1266818]],
and [[spell:1266819]] have all been added. Some nice defensives and a hook to talent into [[spell:48743]]
(which is very much needed, we never pick this talent otherwise). Death Notes would have been a nice addition
back in the day, when [[spell:1249658]] drained Runic Power. It is still nice to get but not as impactful
anymore. [[spell:343294]] is gone as it has been moved to the Unholy talent
tree and [[spell:327574]] has been simply removed. For Frost this really
does not matter since we did not pick either talent anyway.

We have also had some movement of nodes around the tree. [[spell:276079]] is in a much better spot as a choice node
with [[spell:221562]]. [[spell:212552]] has moved further up the tree and is now a choice with [[spell:391546]].
[[spell:374265]] is now a 2-point talent as well. Overall we get a bit more access to certain talents and some more options
in the tree. [[spell:49998]] and [[spell:389682]] were nerfed a bit so we also lost some defensive power, but not that
much in the grand scheme of things.

3.

### Basics of Frost Death Knight Gameplay

Frost Death Knight is a spec that is all about managing your resources and
making the most out of your cooldown windows. To maximize your damage
as a Frost Death Knight, you also need to be able to position yourself well,
especially while using talents like [[spell:1249658]] and
[[spell:194913]] that deal damage in front of your character.

Frost gameplay revolves around powerful procs, proper cooldown management,
and appropriate resources use. Beginners to the specialization can view 
the basics of the gameplay through the three bullet points below.

- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_killing_machine.jpg>)
  **Spend Your Procs**  
  
    Frost generates several powerful procs in its rotation; [[spell:59057]], [[spell:51128]] and [[spell:455993]].
    It is critical to spend these as soon as possible to avoid them overwriting themselves.
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_breath_of_sindragosa.jpg>)
  **Manage Your Cooldowns**  
  
    Frost has multiple cooldowns that benefit greatly from being used together.
    It is important that they're always aligned, as using them together will increase their power.
    These cooldowns are: [[spell:51271]], [[spell:1249658]], [[spell:279302]],
    and [[spell:439843]] (when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer).
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_runic_empowerment.jpg>)
  **Manage Your Resources**  
  
    Frost has two resources, Runes and Runic Power. Managing them is critical in maximizing your
    DPS and avoiding resource starvation. Avoid spending Runes
    when you do not have procs of [[spell:51128]] and otherwise
    avoid capping Runic Power.

4.

### How to Gear Up as a Frost Death Knight

While we always recommend simming yourself for ideal results, we do provide a
dedicated Frost gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **19 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Adjust Reapers Mark timing in opener.
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Update for 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Update for 12.1.5.
- **25 Sep. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Update priority list for better Frostwyrm's Fury timing.
- **14 Sep. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 12.1.
- **14 Sep. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.
- **14 Sep. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.
- **14 Sep. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.
- **14 Sep. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Default and recommended raid build to Deathbringer Breath of Sindragosa.
- **14 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated recommended builds to Deathbringer.
- **14 Sep. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.
- **14 Sep. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.
- **14 Sep. 2026 (this page):** Reviewed for Patch 12.1.
- **13 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated gear for hotfixes.
- **31 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated the target-count threshold to use Obliterate at 1-2 targets and Frostscythe at 3+ targets.
- **31 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated the target-count threshold to use Obliterate at 1-2 targets and Frostscythe at 3+ targets.
- **31 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated the target-count threshold to use Obliterate at 1-2 targets and Frostscythe at 3+ targets.
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Added best crafted items section.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Added paragraph on Loa band option.
- **13 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Expanded trinket tier list.
- **13 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Added sleet to M+ builds.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated with Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated with Patch 12.1 changes.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated with new 12.1 builds.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated with Patch 12.1 builds.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for 12.1 with class changes and guide updates.
- **03 Jul. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **20 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** CHanged to dual-wield for M+ as recommended weapon.
- **20 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Changed to recommen dual-wield for M+.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Update with sporefused items for 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Changed to recklessness as default potion.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.7 with new timeline.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for 12.0.7 with new Omnium Folio talents.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for patch 12.0.7.
- **24 May 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Fixed a gear drop location typo.
- **28 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated recommended ring enchant.
- **24 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated pillar macros.
- **24 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated opener and frostwyrm cooldown management.
- **24 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Clarified frostwyrm usage.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated talent tree for 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for 12.0.5 with turboboost recommendations.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated builds for 12.0.5 with Breathbane being the recommended one.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5 with Exterminate changes and frostywrm callback change.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for 12.0.5 with Breathbane now being recommended M+ build.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated with 12.0.5 changes to spells.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated talents for 12.0.5.
- **20 Apr. 2026 (this page):** Updated with 12.0.5 changes and updated strengths section to focus less on cleave.
- **10 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated potion wording.
- **10 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Clarified Recklessness value.
- **29 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Removed major CD aspect of single button assistant.
- **29 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Removed major CD aspect of single button assistant.
- **29 Mar. 2026 (this page):** Added another tuning note.
- **28 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Resolved an issue with bis neck source.
- **28 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Added 2H Breathbane runeforge
- **26 Mar. 2026 (this page):** Updated with tuning note.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for Midnight Season 1, added heirloom section and updated some headers.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1 with BiS gear, crafting and trinkets.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for Midnight Season 1, adding a note on ERW usage in pillar macro.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Midnight Season 1 with new bis talent distribution.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1 with new build and affix tips.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation with Midnight Season 1, brining in tier set impact on opener.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated talents for Season 1 with a more detailed Mythic+ discussion.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated for Midnight Season 1 with tier set mention.
- **16 Mar. 2026 (this page):** Updated for Season 1 Midnight with new rankings and Season 1 changes.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Added level 80 build.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for Midnight with new level span and build.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Midnight launch with pre-season bis.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated macros for Midnight with new copy functionality.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Midnight with new enchants and consumables.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated with Midnight stat priority and sample weights.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation for midnight with new rotation layout and frostwyrm priority.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for Midnight, changing talents and adding apex talents section.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated for Midnight.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated for Midnight with new builds, rotation and stat priority.
- **26 Feb. 2026 (this page):** Updated for Midnight.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for Midnight pre-patch with new talents and leveling rotation.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Clarified 2H vs DW paragraph.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for Midnight pre-patch with some macro clarification for rider.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Midnight, clarifying Runeforge choice and adding Midnight leveling consumables.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for pre-patch Midnight, changing stat prio due to Rider prio.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated to use Breath as recommended build.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated frostbane priority after simc bugfix.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Swapped to Breath as recommended build and updated frostbringer hero talents.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated for Midnight pre-patch with new builds, rotation and stat priority.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **25 Jan. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated bis to represent breath build.
- **22 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Clarified Breath viability.
- **19 Jan. 2026 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Midnight pre-patch changing to DW, adding more haste and adding level items section.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Midnight with new talent builds.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight pre-patch, changing priority due to Frostbane buff.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for Midnight pre-patch, adding new talent builds and updated pvp talents.
- **17 Dec. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Changed low Rune KM rule to FS instead of Rime.
- **14 Dec. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated dungeon neck.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reivewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Reviewed for Patch 11.2.7.
- **27 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added FAQs and updated for Patch 11.2.7.
- **27 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Added FAQ and updated for Patch 11.2.7.
- **27 Nov. 2025 (this page):** Added new Strengths and Weaknesses section and updated for Patch 11.2.7.
- **16 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated some trinket recommendations to push prism.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Added Puzzling Cartel Chips.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for patch 11.2.5.
- **09 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Fixed typo and improved opener for non-scythe builds.
- **09 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Added rider talent swap for M+.
- **09 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Improved clarity.
- **07 Sep. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Improved clarity around AoE target count.
- **07 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Moved Breath into Pillar macro.
- **07 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated wording around M+ build choices.
- **07 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Improved clarity around AoE target count.
- **06 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Opener to better represent longer sequence.
- **05 Sep. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Swapped to recommending Mastery enchants and gems.
- **05 Sep. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Put Mastery as top stat.
- **05 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Put Mastery as top stats.
- **04 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated opener to reflect better and simpler version.
- **02 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS to match deathbringer stat priority.
- **02 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified Exterminate impact on rotation as well as Rune condition for KM consumption.
- **31 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Swapped to Deathbringer as recommended build.
- **31 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Swapped to Deathbringer as recommend Mythic+ talents.
- **31 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated Mythic+ build to deathbringer.
- **25 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Minor hero-talents clarification.
- **25 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Swapped to Deathbringer as the recommend raid talents.
- **25 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated to recommend deathbringer for raid, and clarified weapon choice.
- **12 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Simplified and clarified pillar macros.
- **12 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Simplified the opener by moving Breath out of Macro button.
- **10 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS list and trinke tier list.
- **07 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Elaborated on Macros.
- **05 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated opener to match new Double-Oblit opener and added AoE option.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated leveling after 11.2 rework.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated with Patch 11.2. New BiS list, artifact cloak, new tier sets and new trinkets.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2, adding new builds.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Completely revamped page with Patch 11.2, simplifying structure and rotations.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated after Patch 11.2. Adding new builds and providing more consise advise.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated spell descriptions after 11.2 rework.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated after Patch 11.2. Rework. New talents, new rotation and new cooldown section.
- **04 Aug. 2025 (this page):** Updated after 11.2 Rework.
- **27 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated best D.I.S.C effect and improved wording in multiple spots.
- **27 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Minor rewordings to improve clarity.
- **27 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added more rotation switches for shattering blade.
- **25 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Removed unnecessary razorice line.
- **23 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated best D.I.S.C effect after tuning.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Clarified Killing Machine importance for Obliterate damage.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Added the new D.I.S.C belt to the bis list as well as a dedicated section for the belt. Minor trinket tier list updates.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated opener macro to more accurately represent Breath -> Macro opener.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Removed Fallen Crusader from enchant table to avoid confusion.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Added more crit interactions and added sim advise for stats.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** Updated some builds to be more AoE-heavy on AoE bosses.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Increased use of image blocks and clarified Breath opener.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated Breath raid build to use inex and clarified some build choices.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated outdated Deathbringer talents.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Elaborated on generic rotation, added image block for rotations and section on combat assistant.
- **15 Jun. 2025 (this page):** Added 11.1.7 changes.
- **15 May 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Swapped M+ build to deathbringer.
- **15 May 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Swapped to deathbringer for M+.
- **27 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated Cartel wording and recommendations as well as BiS list.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Removed "Congratulations for hitting level 80" bit.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Added corruption enchant recommendations.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** Updated builds to use Deathbringer.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Added extensive dungeon tips.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Swapped Shattering Blade build to Deathbringer after tuning.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated builds to use deathbringer.
- **21 Apr. 2025 (this page):** Added class tuning as part of 11.5 changes.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** Updated builds and tips.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS lists, trinket tier lists, embellishments, crafting recommendations and tier set portion.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Removed Soul Reaper usage (it is not worth to cast) and expanded on Remorseless Winter gameplay.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Changed BiS raid talents to Shattering Blade.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 (this page):** Added 11.1 changes and cleaned up guide link section.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **20 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and updated for Patch 11.1.
- **20 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed and updated for Patch 11.1.
- **20 Feb. 2025 (this page):** Reviewed and updated for Patch 11.1.
- **18 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated Cyrce's gems after news sims.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS lists to include Cyrce's Circlet after buffs.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Update for Patch 11.0.7, adding Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed and update for Patch 11.0.7. Simplified cooldown usages.
- **15 Dec. 2024 (this page):** Reviewed and update for Patch 11.0.7.
- **08 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified Death and Decay use without TLW.
- **08 Nov. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Added a specific M+ Breath build.
- **26 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Added back missing trinkets in BiS list.
- **26 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated Obliteration macros for better clarity.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS list crafted pieces.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** Updated builds for 11.0.5 and reviewed tips.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated openers to reflect Mark + Pillar, and added new reaper of soul talent gameplay.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated builds with new 11.0.5 talents.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Added 11.0.5 changes.
- **14 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS passive trinket and added some delve trinkets.
- **08 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Reapers Mark prio to be used with pillar.
- **08 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated 2H build to run avalanche instead of scythe.
- **01 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated builds to include shattering options.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/frost-death-knight-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/frost-death-knight-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/frost-death-knight-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated all gear for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Season 4, changed leg enchant to lambent.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Season 4, and changed the BiS Sim Haste level for Oblit to 37.5%.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated talents for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and Updated for Season 4, changing wording around Chill Streak and the old tier set.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated talents for Season 4 due to new tier set.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed and Updated for Season 4. Updated talent builds due to new tier set.
- **22 Apr. 2024 (this page):** Reviewed for Season 4, updated guide changes and tier set.
- **22 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **22 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **22 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **22 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **22 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **23 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added more detailed Fyralath priority.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Added note on Scythe usage.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated frostscythe priority.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **15 Dec. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Clarified DnD location in pillar for AoE.
- **15 Dec. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated Obliteration KM priority.
- **15 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified DnD usage in AoE.
- **15 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Obliteration priority to not be greedy with double KM.
- **01 Dec. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Clarified loss when not using Oblit Macros.
- **01 Dec. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Added more context to haste breakpoints.
- **01 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified Obliteration rotation with single ERW.
- **29 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Added Legendary with proper link to bis.
- **29 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated builds after Frost DK Buffs.
- **29 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated talent builds after Frost DK buffs.
- **22 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated drop location from dawn upper and lower and changed Breath m+ bis trinkets to mirror and porcelain.
- **22 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated Obliteration raid builds to run enduring chill.
- **12 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated food recommendation.
- **12 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Moved Remorseless Winter priority up and clarified refreshing with gathering storm.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS Lists and Embellishment recommendations after Sporecloak nerfs.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for patch 10.2. Added new bis lists, trinkets and embellishment.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2. Expanded on rotation significantly.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2. Added Soul Reaper usage, clarified various bits and expanded on Chill Streak use.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified gameplay around Fatal Fixation.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Added 10.1.5 dungeon recommendation.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Added 10.1.5 changes.
- **01 Jun. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Added m+ embellishment recommendation.
- **01 Jun. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Moved Haste above Mastery in priority.
- **01 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Expanded on Breath rotation and added Obliteration secondary burst window.
- **01 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Removed DW oblit build and updated 2h oblit viability in raid.
- **01 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Expanded on CD usage and removed DW oblit as a build.
- **31 May 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Added neltharion trinket as new bis for frost 2H oblit.
- **08 May 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated after trinket tuning.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated all gear for Patch 10.1.
- **01 May 2023 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed and Updated for Patch 10.1. Emphasised that oblit macros are not necessary.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.1. Changed to Crit enchant for rings and added Belt stamina buckle.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Patch 10.1. Emphasised the very high Crit priority for Breath.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated talents for Patch 10.1. and removed Thundering affix mention.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and Updated for Patch 10.1. Primarily changing Frostwyrm's Fury usage.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1. Included FwF in talent builds and added a Breath M+ altenrative build.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed and Updated for Patch 10.1. Changed the talent builds and FwF Usage.
- **01 May 2023 (this page):** Reviewed and Updated for Patch 10.1.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/frost-death-knight-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated with Primordial Stone Gems for 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated talent builds for 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation for 10.0.7, adding discussion about Fatal Fixation.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated talents for 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated for 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated talent builds for 10.0.7.
- **20 Mar. 2023 (this page):** Added 10.0.7 Changelog.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/frost-death-knight-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/frost-death-knight-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/frost-death-knight-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/frost-death-knight-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **13 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-2-changes-analysis>)):** Updated to reflect Killing Machine bugfix.
- **19 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-2-changes-analysis>)):** Updated with latest tuning.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **17 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-1-changes-analysis>)):** Updated with recent hotfixes.
- **29 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/frost-death-knight-patch-9-1-changes-analysis>)):** Created page.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **17 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-the-eternal-palace-raid-guide>)):** Added more information on Queen Azshara.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **19 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** Added Mythic tips.
- **16 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **16 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **16 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **24 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated boss advice.
- **18 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** Fixed the boss order.
- **22 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added first version of Frost DK advice for Battle of Dazar'alor.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **30 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** Fixed some of the recommended talents.
- **09 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** Fixed a typo for the recommended G'huun talents.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** Added information for all bosses in Uldir.
- **12 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-uldir-raid-guide>)):** Page added (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Frost Death Knight leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Death Knight leveling guide](<https://www.icy-veins.com/wow/death-knight-leveling-guide>).

1.

### Frost Death Knight Leveling Guide for Midnight

Frost Death Knight is a good leveler, being able to
burst down groups of enemies quickly while also being
one of the most mobile leveling specs via [[spell:444008]] once you
reach level 71. Furthermore, this spec has great self-sustain through
procs of [[spell:178819]], keeping us healthy as we AoE down
pack after pack.

1.1.

#### Leveling Gear Options

Item level is always more important than individual stats when leveling up. Always
choose the piece of gear with the highest item level. Items with Speed tertiary
stats can help speed up your leveling, especially during parts of extended time
spent indoors. Heirloom gear is also useful while leveling, allowing you to ignore a lot
of gearing for a large part of your leveling journey.

1.2.

#### Runeforge Choice

Your Runeforge choise matters depending on the level and weapon type you use.
For 2H weapons, always use [[spell:53344]]. For Dual-wield,
use [[spell:53344]] + [[spell:326977]] and then
swap to [[spell:53343]] Mainhand + [[spell:53344]]
offhand once you learn [[spell:207057]] at level 53.

We recommend using your highest ilvl weapon as you level, but ideally 2H before
level 53 and then dual-wield after.

1.3.

#### Useful Leveling Consumables for Midnight

There are a couple of consumables you can use to speed up your leveling
process in Midnight. [[item:225592]] is a great
food that significantly increases your speed, improving your leveling
process. [[item:109076]] also deserves a mention as it can be
a highly efficient means of transportation when you cannot
use your flying mount.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Frost Level 80 Midnight Leveling
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAAYmhZmZGDzmZmZmZzMz0MjxwMjxYmhZmZmZMDAAAAAAAAAAmFDDAmFQDbYmZmZGYGADAzMAD"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAAYmhZmZGDzmZmZmZzMz0MjxwMjxYmhZmZmZMDAAAAAAAAAgNzihBGYWYohNMzMzMDMDgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-WTVVBXYhZpMAMkEf2gKAywRmggU01dieo4B-WXYHZVUldePiTSJkfjNNOGFbbCcLhg-AAAA-PQMEoYIohZBISB-
```

:::

2.1.

#### War Mode Talents for Leveling

[[spell:410301]] is a solid defensive upgrade and
[[spell:204080]] helps to control your enemies. All other talents are not
very impactful or simply worse for our damage output!

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–14：**

Depending on which race you picked, you will start at a different level, and
have a slightly different intro:

- If you picked an **Allied Race** then you start at level 10.
- On the other hand, if you started with a non-allied race, you start at level
  8.

You will begin selecting talents at level 10, building your character as you
gain one point per level to spend.

- **等级 27 起：**[[spell:51271]] when you open on a pack.
- **等级 31 起：**[[spell:279302]] should be paired with
  [[spell:51271]] and used on big packs, elites, or boss mobs.
- **等级 55 起：**[[spell:49143]] when you get a proc of [[spell:455993]] on
  a target with 5 stacks of [[spell:51714]].
- **等级 1–12：**[[spell:316239]] is your main damaging ability
  and Rune spender.
- **等级 21 起：**[[spell:49184]] to consume procs of
  [[spell:59057]].
- **等级 17 起：**[[spell:47568]] to generate Runic Power and procs
  of [[spell:51128]].
- **等级 13 起：**[[spell:49020]] is your main Single Target Rune spender and a big
  damage ability once you start generating [[spell:51128]] procs at level 15.
- **等级 23 起：**[[spell:207230]] over [[spell:49020]] when fighting 3+ enemies.
- **等级 1–10：**Use [[spell:47541]] when you have 80+ Runic Power
  or no available Runes. You won't use this ability once you pick up [[spell:49143]] and
  [[spell:194913]].
- **等级 18 起：**[[spell:46585]] should be used off cooldown or
  for bosses/elite mobs.
- **等级 10 起：**[[spell:194913]] to consume your Runic Power
  whenever there are 2+ targets.
- **等级 11 起：**[[spell:49143]] to consume your Runic Power on 1 target
- **等级 10 起：**[[spell:49998]] to heal yourself.
- **等级 19–32：**[[spell:196770]] whenever there are 3+
  targets or the target will last the duration.

There are several passive abilities that you unlock through the
leveling process that can change your play style and rotation.

- **等级 21 起：**[[spell:59057]] makes your [[spell:49184]] deal
  significantly more damage. This is generally the only time you want to
  use [[spell:49184]].
- **等级 15 起：**[[spell:51128]] is a passive ability that
  gives your auto attack Critical Strikes the chance to make your next
  [[spell:49020]] critically strike and deal frost damage, significantly
  increasing its damage. It also makes your [[spell:207230]] crit for 4x its normal
  damage. This proc is a large part of your damage output.
- **等级 18 起：**[[spell:178819]] is incredible for leveling,
  allowing you to easily heal and stay at high health while chain-pulling packs
  and
  mobs.

**等级 10 起：**3.1.

#### **等级 10 起：**Defensive and Utility Abilities

- **等级 14 起：**[[spell:48707]] is
  a very strong magic shield that also generates Runic Power when it
  absorbs magic damage. This should be used
  whenever magic damage is present to take advantage of the Runic Power
  generation.
- **等级 9 起：**[[spell:49039]] is a relatively powerful ability
  for leveling, as it provides you with a good chunk of Leech. Use this cooldown
  to take advantage of the healing and try to pair it with high AoE or
  burst combinations.
- **等级 10 起：**[[spell:48792]] is an amazing defensive
  cooldown that should be used whenever necessary in order to keep you moving
  from pack to pack.
- **等级 19 起：**[[spell:61999]] cannot be used when solo leveling,
  however, it is fantastic in dungeon groups if you decide to level that way.
- **等级 9 起：**[[spell:343257]] is one of your only movement
  speed cooldowns making it incredibly useful when leveling. The secondary
  effects of this are not too useful in leveling scenarios, except for the
  passive that prevents you from being slowed past a certain point.
- **等级 26 起：**[[spell:212552]] is a nice extra speed boost
  that we leverage as much as possible.
- **等级 8 起：**[[spell:49576]] grips your target towards
  you, allowing you to start fighting it straight away. Really useful
  to speed up the leveling process.
- **等级 16 起：**[[spell:47528]] is your interrupt which is great
  to use against casting mobs, significantly reducing the damage they deal to you!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **14 Sep. 2026:** Reviewed for Patch 12.1.
- **31 Aug. 2026:** Updated the target-count threshold to use Obliterate at 1-2 targets and Frostscythe at 3+ targets.
- **10 Aug. 2026:** Updated for patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated talent tree for 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1, added heirloom section and updated some headers.
- **02 Mar. 2026:** Added level 80 build.
- **26 Feb. 2026:** Updated for Midnight with new level span and build.
- **10 Feb. 2026:** Updated for Midnight pre-patch with new talents and leveling rotation.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **07 Sep. 2025:** Improved clarity around AoE target count.
- **04 Aug. 2025:** Updated leveling after 11.2 rework.
- **25 Jun. 2025:** Removed unnecessary razorice line.
- **15 Jun. 2025:** Clarified Killing Machine importance for Obliterate damage.
- **21 Apr. 2025:** Removed "Congratulations for hitting level 80" bit.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **22 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Frost Death Knight in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Frost Death Knight

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Frost Death Knights are a melee DPS specialization with
strong single-target and AoE damage and a fairly simple and
approachable play style. They can use either 2-Handed or 1-Handed weapons, with
**1-Handed weapons** being the best choice currently.

Frost gameplay revolves around powerful procs, proper cooldown management
and, appropriate resources use. Three quick rules to follow when learning the
spec are:

- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_killing_machine.jpg>)
  **Spend Your Procs**  
  
    Frost generates several powerful procs in its rotation; [[spell:59057]], [[spell:51128]] and [[spell:455993]].
    It is critical to spend these as soon as possible to avoid them overwriting themselves.
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_breath_of_sindragosa.jpg>)
  **Manage Your Cooldowns**  
  
    Frost has multiple cooldowns that benefit greatly from being used together.
    It is important that they're always aligned, as using them together will increase their power.
    These cooldowns are: [[spell:51271]], [[spell:1249658]], [[spell:279302]],
    and [[spell:439843]] (when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer).
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_runic_empowerment.jpg>)
  **Manage Your Resources**  
  
    Frost has two resources, Runes and Runic Power. Managing them is critical in maximizing your
    DPS and avoiding resource starvation. Avoid spending Runes
    when you do not have procs of [[spell:51128]] and otherwise
    avoid capping Runic Power.

2.

### Beginner's Guide to Frost Death Knight in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse   Raid Talents

2.1.

#### Beginner Raid Talents for Frost Death Knight

We recommend the [[spell:1249658]] with
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse and two 1-handed weapons for Single Target.

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDwMjZmZGDz2MzMzMLmZmMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko015diigcA-WXYZHVlIadefijBPbbhCLcUTSJAAQE-AAAA-PqQMYIIAISRDzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer   AoE Talents

2.2.

#### Beginner Delves and Mythic+ Talents for Frost Death Knight

We recommend the [[spell:1249658]] with
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer and two 1-handed weapons for Mythic+ and Delves.

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-GIOQaACEWwgCzC-
```

:::

### Frost Death Knight   Basic Rotation

2.3.

#### Basic Rotations for Frost Death Knight

Your main goal throughout fights will be to maximize your [[spell:51128]]
consumption while also keeping an eye out for procs of [[spell:59057]].

Note that the rotation listed below are not fully optimized for the highest
possible output, instead making some sacrifices to ensure their ease of use.

- AoE (3+ targets)
- [[spell:455993]] talented
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer talented

1. Use [[spell:51271]] on cooldown. Combine it with [[spell:279302]]
   and [[spell:1249658]] every second use.
2. **适用条件：Deathbringer talented（启用）。** Use [[spell:439843]] with every [[spell:51271]].
3. **适用条件：AoE (3+ targets)（未启用）。** Spend your procs of [[spell:51128]] on [[spell:49020]].
4. **适用条件：AoE (3+ targets)（启用）。** Spend your procs of [[spell:51128]] on [[spell:207230]].
5. Spend your [[spell:47568]] charges to generate procs of [[spell:51128]].
6. Spend your procs of [[spell:59057]] on [[spell:49184]].
7. **适用条件：Frostbane talented（启用）。** Use [[spell:455993]] when you get a proc of it and the target has 5 stacks of [[spell:51714]].
8. **适用条件：AoE (3+ targets)（未启用）。** Spend your Runic Power on [[spell:49143]].
9. **适用条件：AoE (3+ targets)（启用）。** Spend your Runic Power on [[spell:194913]].
10. **适用条件：AoE (3+ targets)（未启用）。** Spend leftover Runes on [[spell:49020]].
11. **适用条件：AoE (3+ targets)（启用）。** Spend leftover Runes on [[spell:207230]].

Our Season 2 tier set revolves around our [[spell:196770]] ability. The 2-set
provides a stacking attack speed and [[spell:435010]] damage buff whenever Remorseless
Winter deals damage. The 4-set makes [[spell:196770]] deal damage 25% more frequently,
and increases the duration of the buff from the 2-set. This has little impact on our rotation
as [[spell:196770]] is a completely passive ability that triggers off [[spell:51271]]
(since we always run the [[spell:377253]] talent).

2.3.1.

##### Cooldowns

As a Frost Death Knight, you have six total cooldowns. Below, we
explain how they are best used.

- [[spell:439843]] should be used on cooldown with each [[spell:51271]]
  window, macro them together.
- [[spell:51271]] should be used on cooldown, stacking it with
  potions or any on-use trinkets you have. Since we run [[spell:281238]], spend the
  window generating [[spell:51128]] with [[spell:49143]]/[[spell:194913]]/[[spell:49184]]
  and consume with [[spell:49020]]/[[spell:207230]].
- [[spell:279302]] should be used in synergy with
  [[spell:51271]]. Use your first charge at the start of the [[spell:51271]]
  and the re-cast after 12 seconds while still in your Pillar window.
- [[spell:1249658]] should be used on cooldown in synergy with your
  other cooldowns. Macro it with [[spell:51271]].
- [[spell:47568]] should be used whenever you have two charges or
  when you have no Runic Power and no [[spell:51128]] to use on [[spell:49020]].
  In your [[spell:51271]], use it to get free [[spell:49020]]/[[spell:207230]]
  when you are out of Runes.
- [[spell:196770]] should be used on cooldown. We often pick up
  [[spell:377253]] which handles Remorseless automatically and completely
  removes the button for us.

2.3.2.

##### Apex Talent: ![Chosen of Frostbrood Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_reputation_wyrmresttemple.jpg>) Chosen of Frostbrood

Frost Death Knight gets access to [[spell:1265632]] Apex Talents
as you level up from 80 to 90 in Midnight. The first rank buffs [[spell:279302]]
by 100% and provides a Haste buff when you use the ability. The second rank [[spell:1265633]]
extends your active [[spell:51271]] by 2/4 seconds when you cast [[spell:279302]]
in it, and improves the power of [[spell:377190]]. The final rank [[spell:1265637]]
provides a flat 10% Frost damage buff, an additional 100% increase to [[spell:279302]]
damage and allows you to recast the ability at 50% effectiveness for 45 seconds
after the first use.

The Apex Talents significantly incentivise picking up [[spell:279302]] and
additionally pushes you to use it in our [[spell:51271]] windows. We send both charges
in our first window to avoid missing the next one, making sure to spread them out to
not overlap the buffs.

### Frost Death Knight   Stat Priority

2.4.

#### Frost Death Knight Stat Priorities

This can be different depending on your character's gear and talents, so make sure you
sim yourself to find what your stat priority is. Furthermore, different builds
have different priorities. For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>).

Critical Strike

Haste

Mastery

Versatility

### Blizzard   Combat Assistant

2.5.

#### Combat Assistant for Frost Death Knights

Patch 11.7 introduced the Combat Assistant functionality for all specs in the game.
This comes in the form of two tools that you can use to assist your rotation. The
Assisted Highlight feature will light up the spell that you are supposed to use next,
helping you determine what button you need to press. The Single-Button Assistant
will provide you with a single button that automatically pressed the appropriate spell.
Importantly the Single-Button Assistant has a GCD penalty of 0.2 seconds every time you
press it, artificially slowing down your rotation. This penalty means that you will always
do less DPS when using the Single-Button Assistant compared to what you could have done
with a perfectly executed rotation.

One question you might ask yourself now is: how good is the rotation I can get from
these assistants? If we assume that you handle your Cooldown usage perfectly, the
Assisted Highlight is roughly 5-10% less DPS and the Single-Button Assistant is about
15% less DPS. Do bear in mind that this is compared to absolutely
optimal play. A player with less experience with the rotation might see a significantly smaller loss,
or even a gain when using the assistants.

Remember that the Single-Button Assistant does not use [[spell:1249658]] automatically,
you have to press that button yourself!

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **14 Sep. 2026:** Reviewed for Patch 12.1.
- **31 Aug. 2026:** Updated the target-count threshold to use Obliterate at 1-2 targets and Frostscythe at 3+ targets.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **24 Apr. 2026:** Clarified frostwyrm usage.
- **20 Apr. 2026:** Updated talents for 12.0.5.
- **29 Mar. 2026:** Removed major CD aspect of single button assistant.
- **16 Mar. 2026:** Updated for Midnight Season 1 with tier set mention.
- **26 Feb. 2026:** Updated for Midnight with new builds, rotation and stat priority.
- **10 Feb. 2026:** Updated for Midnight pre-patch with new builds, rotation and stat priority.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **09 Sep. 2025:** Improved clarity.
- **07 Sep. 2025:** Improved clarity around AoE target count.
- **05 Sep. 2025:** Put Mastery as top stats.
- **31 Aug. 2025:** Updated Mythic+ build to deathbringer.
- **25 Aug. 2025:** Updated to recommend deathbringer for raid, and clarified weapon choice.
- **04 Aug. 2025:** Updated after Patch 11.2. Rework. New talents, new rotation and new cooldown section.
- **15 Jun. 2025:** Elaborated on generic rotation, added image block for rotations and section on combat assistant.
- **15 May 2025:** Swapped to deathbringer for M+.
- **21 Apr. 2025:** Updated builds to use deathbringer.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7. Simplified cooldown usages.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed and Updated for Season 4. Updated talent builds due to new tier set.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **29 Nov. 2023:** Updated talent builds after Frost DK buffs.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 Jun. 2023:** Expanded on CD usage and removed DW oblit as a build.
- **01 May 2023:** Reviewed and Updated for Patch 10.1. Changed the talent builds and FwF Usage.
- **20 Mar. 2023:** Updated talent builds for 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Frost Death Knight in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Frost Death Knight

Welcome to our talent guide for Frost Death Knight. Here we will
discuss all matters associated with your talent choices, providing the best
available builds, as well as details regarding alternative picks
and potential talent swaps.

Frost Death Knight has one major choice in its
talent tree: whether or not to route into [[spell:207057]]
and [[spell:455993]]. These talents rely on Dual-Wield builds that
pick up [[spell:53343]] as a Runeforging option on the Main hand. The alternative is
to run a pure [[spell:1249658]] setup, which works well with both
2H and Dual-Wield.

We recommend running the Dual-Wield [[spell:1249658]]
build in all content.

**Quick Start Import Codes:**

:::talents Frost Single Target
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMAmZMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD"
}
```
:::

:::talents Frost Mythic+
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD"
}
```
:::

:::talents Frost Delves
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAYAzMMjZMDzmZmZmZxMjmZMGmZGGPwMmZmZmZmZAAAAAAAAAAsZ2MMwAzmGaYDzMzMzAAYAYmZGYA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Deathbringer

Raid

recommended

Mythic+

recommended

Delves

recommended

Rider of the Apocalypse

Raid

Mythic+

Delves

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer Raid Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer is slightly ahead of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse
in Raid. It runs the same spec and class talent as Rider, picking up [[spell:436687]]
as the one important choice in the Hero Talent tree.

Your primary flex point comes in the form of [[spell:456237]]. This talent
is essentially equal in DPS compared to [[spell:1230272]], [[spell:316803]] and
[[spell:1230284]]. Cryo provides some nice AoE which is why we recommend it by default
but overall there is a lot of choice.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer Mythic+ Build

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer Mythic+ build is extremely close to our
recommended Rider raiding build. We only swap [[spell:1230223]]
for [[spell:1230284]] for some additional damage. Deathbringer
beats out Rider with a few % in Mythic+ but both Hero Talents
are very much
viable.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer Delves Build

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer Delves build is extremely close to our
recommended Rider raiding build. We only swap [[spell:1230223]]
for [[spell:1230284]] for some additional damage. Deathbringer
beats out Rider with a few % in Mythic+ but both Hero Talents
are very much viable.

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse Raid Build

We recommend running a Dual-Wield [[spell:1249658]] setup with
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse for Raid. It sits comfortably ahead
of both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer (1%) and [[spell:455993]] builds in
Single Target.

Your primary flex point comes in the form of [[spell:456237]]. This talent
is essentially equal in DPS compared to [[spell:1230272]], [[spell:316803]] and
[[spell:1230284]]. Cryo provides some nice AoE which is why we recommend it by default
but overall there is a lot of choice.

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse Mythic+ Build

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse Mythic+ build is almost identical to the Raid
version with only [[spell:1230301]] being replaced by [[spell:1230284]].

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse Delve Build

The gameplay of delves cater well to our Mythic+ build that brings a good balance
between Single Target and AoE! We run our standard Mythic+ build with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse
(mainly for the extra speed you get with Rider).
You can read more about Delves on our dedicated page [Delves](<https://www.icy-veins.com/wow/delves-guide>) Guide!

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDwMjZmZGDz2MzMzMLmZmMjxYYmxgZMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko015diigcA-WXYZHVlIadefijBPbbhCLcUTSJAAQE-AAAA-GQAOCMoQIsQDzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhipqAPQjmqqyotxRuKUk01higcC-WXYZHVlUadefijIJPTSRbbhAACLQcE-AAAA-GIOQaACEWwgCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMAzMMzMDY2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEYsgZGzMDMAMMzAMzgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhipqAPQnqqyotxRuKUk01higceA-WXYZHVlUadefijIJPTSRbbhAACLQcE-AAAA-GIOQaACEWwgCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDwMjZmZGDz2MzMzMLmZmMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko015diigcA-WXYZHVlIadefijBPbbhCLcUTSJAAQE-AAAA-PqQMYIIAISRDzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-PSMoYIIAISRDzC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-PSMoYIIAISRDzC-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend you pick the following bonuses in the first couple of weeks, but as you
can freely switch between them at any time, feel free to experiment with other options
yourself if you feel you do not get enough mileage out of the recommended options:

- Week 1:[[spell:1279599]]
- Week 2:[[spell:1279604]]
- Week 3:[[spell:1287555]]
- Week 4:[[spell:1279609]]
- Week 5:[[spell:1279614]]

3.

### Apex Talent: ![Chosen of Frostbrood Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_reputation_wyrmresttemple.jpg>) Chosen of Frostbrood

Frost Death Knight gets access to [[spell:1265632]] Apex Talents
as you level up from 80 to 90 in Midnight. The first rank buffs [[spell:279302]]
by 100% and provides a Haste buff when you use the ability. The second rank [[spell:1265633]]
extends your active [[spell:51271]] by 2/4 seconds when you cast [[spell:279302]]
in it, and improves the power of [[spell:377190]]. The final rank [[spell:1265637]]
provides a flat 10% Frost damage buff, an additional 100% increase to [[spell:279302]]
damage and allows you to recast the ability at 50% effectiveness for 45 seconds
after the first use.

The Apex Talents significantly incentivise picking up [[spell:279302]] and
additionally using it in our [[spell:51271]] windows. We send both charges
in our first window to avoid missing the next one, making sure to spread them out to
not overlap the buffs.

4.

### Hero Talents

Available at level 71, Hero talents are mutually exclusive trees you can
choose to slightly alter gameplay. Frost Death Knight can choose
between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse Hero Talents provide more focus
on minion damage with your Riders being summoned both passively
as well as actively via [[spell:279302]]. It also has nice synergy
with [[spell:455993]] via the [[spell:444037]] talent which increases
[[spell:49143]] damage. It brings great
utility through the [[spell:444010]] ability as well as
more emphasis is but on your 1.5 minute Cooldown window with [[spell:444040]].

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer focuses on your 45-seconds burst windows with
[[spell:439843]] both dealing significant damage on its own, but also
buffing your other abilities. It comes with lots of extra procs and benefits,
providing multiple extra procs of [[spell:51128]] via [[spell:441378]]
and free [[spell:55095]] applications.

5.

### PvP Talents (War Mode)

In this section, we will rank the PvP talents that are best for leveling
and doing open-world content.

- PvP talents enabled in the outdoor world.
- 15% more experience and quest awards gained while leveling.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of both General PvP Talents
and Frost Death Knight-specific PvE talents.

1. [[spell:204080]] roots enemies for 4 seconds. It is applied either via
   the direct cast of [[spell:196770]], or by casting [[spell:45524]]
   on a target already affected by [[spell:45524]]. Not valuable in PvE content.
2. [[spell:233396]] causes your [[spell:49184]] and
   [[spell:49143]] to apply [[spell:233396]] to the target.
   Delirium reduces the cooldown recovery rate of movement abilities by 50%
   for 12 seconds.
3. [[spell:199719]] reduces the cast range of enemies within 8 yards
   around you by 30%. Not useful in PvE.
4. [[spell:77606]] places a debuff on your enemy, activating when they
   cast a spell that uses mana. It allows you to use that same spell for some time.
   Not useful in PvE content.
5. [[spell:47476]] silences your target for 4 seconds. Inferior to just
   running [[spell:221562]] (it replaces the talent) and a pretty useless PvE talent.
6. [[spell:356470]] reduces the target's haste by 8% when affected by
   [[spell:45524]]. [[spell:49143]] extends its duration. Not useful in PvE.
7. [[spell:202727]] adds an absorption shield to any target hit by
   [[spell:43265]] for 100% of the damage amount. Not useful in PvE.
8. [[spell:410301]] provides 4 seconds of 25% physical damage reduction
   whenever you press [[spell:49998]]. Solid defensive gain!
9. [[spell:410320]] lowers the cooldown of [[spell:48707]] by 10
   seconds and allows you to use it on allies. It's just a nice defensive gain because it
   allows more AMS usage.
10. [[spell:1218603]] empowers your [[spell:51271]] to cast a [[spell:196770]]
    at 400% increase damage and 150% increased radius. Your movement speed is heavily reduced
    and the cooldown of [[spell:51271]] is increased by 15 seconds. Generally not worth it
    in PvE.

[[spell:410301]] is a solid defensive upgrade and
[[spell:204080]] helps to control your enemies. All other talents are not
very impactful or simply worse for our damage throughput!

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **14 Sep. 2026:** Updated recommended builds to Deathbringer.
- **13 Aug. 2026:** Added sleet to M+ builds.
- **10 Aug. 2026:** Updated with Patch 12.1 builds.
- **20 Jun. 2026:** Changed to recommen dual-wield for M+.
- **15 Jun. 2026:** Updated for 12.0.7 with new Omnium Folio talents.
- **20 Apr. 2026:** Updated for 12.0.5 with Breathbane now being recommended M+ build.
- **16 Mar. 2026:** Updated talents for Season 1 with a more detailed Mythic+ discussion.
- **26 Feb. 2026:** Updated for Midnight, changing talents and adding apex talents section.
- **10 Feb. 2026:** Swapped to Breath as recommended build and updated frostbringer hero talents.
- **22 Jan. 2026:** Clarified Breath viability.
- **19 Jan. 2026:** Updated for Midnight pre-patch, adding new talent builds and updated pvp talents.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **09 Sep. 2025:** Added rider talent swap for M+.
- **07 Sep. 2025:** Updated wording around M+ build choices.
- **31 Aug. 2025:** Swapped to Deathbringer as recommend Mythic+ talents.
- **25 Aug. 2025:** Swapped to Deathbringer as the recommend raid talents.
- **04 Aug. 2025:** Updated after Patch 11.2. Adding new builds and providing more consise advise.
- **15 Jun. 2025:** Updated Breath raid build to use inex and clarified some build choices.
- **15 May 2025:** Swapped M+ build to deathbringer.
- **21 Apr. 2025:** Swapped Shattering Blade build to Deathbringer after tuning.
- **24 Feb. 2025:** Changed BiS raid talents to Shattering Blade.
- **20 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **08 Nov. 2024:** Added a specific M+ Breath build.
- **21 Oct. 2024:** Updated builds with new 11.0.5 talents.
- **08 Oct. 2024:** Updated 2H build to run avalanche instead of scythe.
- **01 Oct. 2024:** Updated builds to include shattering options.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated talents for Season 4 due to new tier set.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **29 Nov. 2023:** Updated builds after Frost DK Buffs.
- **22 Nov. 2023:** Updated Obliteration raid builds to run enduring chill.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 Jun. 2023:** Removed DW oblit build and updated 2h oblit viability in raid.
- **01 May 2023:** Updated for Patch 10.1. Included FwF in talent builds and added a Breath M+ altenrative build.
- **20 Mar. 2023:** Updated talents for 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Frost Death Knight in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Frost Death Knight Gameplay and Rotation Guide

Welcome to our Rotation page for Frost Death Knights. Here, we
will go over everything you will need to know to optimally play your
spec for Raiding and Mythic+ scenarios.

By selecting talents and Hero Talents below, the rotations in this guide will
update accordingly.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer

Breath Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Breath Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Frostbane Mythic+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse

Breath Raid

Breath Mythic+

Frostbane Mythic+

Active Talents

Passive Talents

[[spell:1249658]]

[[spell:279302]]

[[spell:439843]]

[[spell:377253]]

[[spell:207057]]

[[spell:455993]]

[[spell:207230]]

### Frost Death Knight Explained

1.1.

#### Frost Death Knight Explained

Frost Death Knight relies on a dual-resource system with Runes and Runic Power. Runes passively recharge over time and are spent on abilities such as [[spell:49020]] and [[spell:207230]]. Spending Runes generates Runic Power that we spend on abilities such as [[spell:49143]] and [[spell:194913]].

We have two powerful procs in our rotation that we play around: [[spell:59057]] and [[spell:51128]]. [[spell:59057]] is triggered from using [[spell:49143]] and [[spell:194913]]. It significantly empowers our [[spell:49184]] ability which is also the only time when we use this ability. [[spell:51128]] primarily triggers from our critical auto-attacks or the active [[spell:47568]] ability. We also gain procs via the [[spell:281238]] and [[spell:441378]] (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer) talents. The proc empowers our [[spell:49020]] and [[spell:207230]] abilities, making them do significantly more damage.

The core rotation boils down to managing your resources properly as well as generating and spending your procs as much as possible:

- Spend procs of [[spell:51128]] on [[spell:49020]] (Single Target) or [[spell:207230]] (AoE)
- Spend procs of [[spell:59057]] on [[spell:49184]]
- Use [[spell:47568]] to generate procs of [[spell:51128]] to avoid using no-[[spell:51128]] [[spell:49020]]/[[spell:207230]]
- Spend your generated Runic Power on [[spell:49143]] (Single Target) or [[spell:194913]] (AoE)

### Single-Target Rotation

[[spell:47568]]

**适用条件：Reaper's Mark（未启用）。**

[[spell:49020]]

**适用条件：Reaper's Mark（启用）。**

[[spell:439843]]

**适用条件：Frozen Dominion（未启用）。**

[[spell:196770]]

**适用条件：Breath of Sindragosa（启用）。**

[[spell:51271]]

[[spell:279302]]

[[spell:1249658]]

[[item:270175]]

[[item:241288]]

[[spell:46585]]

**适用条件：Breath of Sindragosa（未启用）。**

[[spell:51271]]

[[spell:279302]]

[[item:270175]]

[[item:241288]]

[[spell:46585]]

**适用条件：Reaper's Mark（启用）。**

[[spell:49020]]

[[spell:47568]]

**适用条件：Reaper's Mark（未启用）。**

[[spell:49020]]

1.2.

#### Single-Target Opener for Frost Death Knights

The opener is a set sequence of abilities you use as you engage an enemy. Memorising it helps initiate your rotation in the most optimal way possible.

1. [[spell:47568]]
2. **适用条件：Reaper's Mark（未启用）。** [[spell:49020]]
3. **适用条件：Reaper's Mark（启用）。** [[spell:439843]]
4. **适用条件：Frozen Dominion（未启用）。** [[spell:196770]]
5. **适用条件：Breath of Sindragosa（启用）。** [[spell:1249658]] + [[spell:51271]] + [[spell:279302]] +  Potion + Trinket + [[spell:46585]]
6. **适用条件：Breath of Sindragosa（未启用）。** [[spell:51271]] + [[spell:279302]] +  Potion + Trinket + [[spell:46585]]
7. **适用条件：Reaper's Mark（启用）。** [[spell:49020]]
8. [[spell:47568]]
9. **适用条件：Reaper's Mark（未启用）。** [[spell:49020]]

1.3.

#### Single-Target Rotation for Frost Death Knights

1. Use [[spell:49020]] if you have a proc of [[spell:51128]]
2. **适用条件：Shattering Blade（启用）；Frostbane（未启用）。** Use [[spell:49143]] if you have 5 stacks of [[spell:51714]]
3. **适用条件：Shattering Blade（启用）；Frostbane（启用）。** Use [[spell:49143]]/[[spell:455993]] if you have 5 stacks of [[spell:51714]]
4. Use [[spell:49184]] if you have a proc of [[spell:59057]]
5. Use [[spell:49143]]
6. Use [[spell:47568]] to generate a charge of [[spell:51128]] and 40 Runic Power
7. Use a no-KM [[spell:49020]]

Let's break down the core rotation with some additional context:

- Consume your procs of [[spell:51128]] with  [[spell:49020]]. There is some nuance regarding when you prioritise consuming [[spell:51128]] at one stack versus avoiding capping Runic Power. If you have 3+ Runes, you prioritse the proc of Killing Machine. If you are low on Runes, use [[spell:49184]] with a proc of [[spell:59057]] or [[spell:49143]] instead if you are at 70+ Runic Power (which happens frequently as you often ignore your Runic Power level). If you have two stacks of Killing Machine, always consume ASAP. The same logic applies if you talent into [[spell:207057]] where you prioritise [[spell:49143]] at 5 stacks of [[spell:51714]] over [[spell:51128]] consumption when low on Runes.
- Consume your procs of [[spell:59057]] with [[spell:49184]].
- You use [[spell:49143]] to consume your Runic Power, or with a higher priority with procs of [[spell:207057]]/[[spell:455993]] and 5 stacks of [[spell:51714]]. Due to how little damage a non-Killing Machine [[spell:49020]] does, and since it does not generate any procs either, we always use up our Runic Power before we consider pressing a no-KM [[spell:49020]].
- You use [[spell:47568]] to try and avoid pressing a no-KM [[spell:49020]]. Once you have used up all your Runic Power, press [[spell:47568]] to gain a proc and some more Runic Power, allowing you to follow up with [[spell:49020]] or [[spell:49143]]. Also press this at a high priority if you have two stacks.
- The no-KM [[spell:49020]] is at the bottom of our priority list. It does very little damage and does not synergise with any other talent, really. We primarily use it as a builder to gain Runic Power to spend on [[spell:49143]]!

### Multi-Target Rotation

[[spell:47568]]

**适用条件：Frostscythe（启用）；Reaper's Mark（未启用）。**

[[spell:207230]]

**适用条件：Frostscythe（未启用）；Reaper's Mark（未启用）。**

[[spell:49020]]

**适用条件：Frozen Dominion（未启用）。**

[[spell:196770]]

**适用条件：Breath of Sindragosa（启用）。**

[[spell:439843]]

[[spell:1249658]]

[[spell:51271]]

[[spell:46585]]

**适用条件：Breath of Sindragosa（未启用）。**

[[spell:279302]]

[[spell:51271]]

[[spell:46585]]

**适用条件：Reaper's Mark（启用）；Frostscythe（未启用）。**

[[spell:49020]]

**适用条件：Frostscythe（启用）；Reaper's Mark（启用）。**

[[spell:207230]]

[[spell:279302]]

[[spell:47568]]

**适用条件：Frostscythe（启用）；Reaper's Mark（未启用）。**

[[spell:207230]]

**适用条件：Frostscythe（未启用）；Reaper's Mark（未启用）。**

[[spell:49020]]

1.4.

#### Multi-Target Opener for Frost Death Knights

1. [[spell:47568]]
2. **适用条件：Frostscythe（启用）；Reaper's Mark（未启用）。** [[spell:207230]]
3. **适用条件：Frostscythe（未启用）；Reaper's Mark（未启用）。** [[spell:49020]]
4. **适用条件：Frozen Dominion（未启用）。** [[spell:196770]]
5. **适用条件：Breath of Sindragosa（启用）；Reaper's Mark（启用）。** [[spell:1249658]] + [[spell:51271]] + [[spell:439843]] + Potion + Trinket + [[spell:46585]]
6. **适用条件：Breath of Sindragosa（未启用）；Reaper's Mark（未启用）。** [[spell:51271]] + [[spell:279302]] + Potion + Trinket + [[spell:46585]]
7. **适用条件：Reaper's Mark（启用）；Frostscythe（未启用）。** [[spell:49020]]
8. **适用条件：Frostscythe（启用）；Reaper's Mark（启用）。** [[spell:207230]]
9. [[spell:279302]]
10. [[spell:47568]]
11. **适用条件：Frostscythe（启用）；Reaper's Mark（未启用）。** [[spell:207230]]
12. **适用条件：Frostscythe（未启用）；Reaper's Mark（未启用）。** [[spell:49020]]

1.5.

#### Multi-Target Rotation for Frost Death Knights

The multi-target rotation mirrors the single-target one in many ways. You simply replace [[spell:49020]] with [[spell:207230]] and [[spell:49143]] with [[spell:194913]]. The one thing to consider is [[spell:455993]] which introduces [[spell:49143]]s in the AoE rotation (as procs of [[spell:455993]]). We swap to [[spell:207230]] and [[spell:194913]] at 3+ targets.

1. **适用条件：Frostscythe（未启用）。** Use [[spell:49020]] if you have a proc of [[spell:51128]]
2. **适用条件：Frostscythe（启用）。** Use [[spell:207230]] if you have a proc of [[spell:51128]]
3. **适用条件：Frostbane（启用）。** Use [[spell:455993]] on a target with 5 stacks of [[spell:51714]] when [[spell:455993]] procs.
4. **适用条件：Frozen Dominion（未启用）。** Use [[spell:196770]]
5. Use [[spell:49184]] if you have a proc of [[spell:59057]]
6. Use [[spell:194913]]
7. Use [[spell:47568]] to generate a charge of [[spell:51128]] and 40 Runic Power.
8. **适用条件：Frostscythe（未启用）。** Use a no-KM [[spell:49020]]
9. **适用条件：Frostscythe（启用）。** Use a no-KM [[spell:207230]]

The same nuance around consuming [[spell:51128]] vs spending Runic Power exists in AoE. If you are healthy on Runes (3+), consume the Killing Machine always. If low on Runes, use [[spell:49184]] with procs of [[spell:59057]] or [[spell:194913]] first. If at two stacks of [[spell:51128]], always consume Killing Machine ASAP.

:::details FAQShould I Wait for Two Stacks of [[spell:51128]] Before Consuming?
You should ideally consume at **one stack** of [[spell:51128]]
as much as possible. There are scenarios where you deliberately go up to two,
mainly when you are low on Runes. If you are at less than three Runes, prioritise
spending procs of [[spell:59057]] as well as Runic Power before consuming.

:::

2.

### Midnight Season 2 Tier Set

Our Season 2 tier set revolves around our [[spell:196770]] ability. The 2-set
provides a stacking attack speed and [[spell:435010]] damage buff whenever Remorseless
Winter deals damage. The 4-set makes [[spell:196770]] deal damage 25% more frequently,
and increases the duration of the buff from the 2-set. This has little impact on our rotation
as [[spell:196770]] is a completely passive ability that triggers off [[spell:51271]]
(since we always run the [[spell:377253]] talent).

3.

### Class and Spec Mechanics Explained

This section deep dives into the mechanics of Frost Death Knight, covering both
the resources we use as well as some advanced topics that can be useful when tryingt
to understand the rotation in more depth.

### Runes and Runic Power

3.1.

#### Runes and Runic Power

Death Knights use a dual resource system of runes and Runic Power. While it
is quite straightforward in how it works, we will explain it here for the
sake of completion.

3.1.1.

##### Runes

You have a total of 6 Runes, which are available by default. Some of your
abilities have Rune costs, and whenever you use an ability that consumes one
or more Runes, those Runes will immediately begin recharging. The exact amount
of time it takes a Rune to recharge depends on how much Haste you have.

Whenever a Rune is consumed, you gain 10 Runic Power (more on that
below).

At most, 3 of your runes can be charging up at the same time. It is
therefore optimal to keep at least 3 runes on cooldown to maximise
the recharge rate over the course of the fight.

3.1.2.

##### Runic Power

Runic Power is a resource that resembles Rage, in the sense that it
decays when out of combat, but does not decay during combat. As mentioned
above, consuming Runes generates 10 Runic Power per Rune spent, and this is
the primary means of generating Runic Power, although some abilities also
help with this. You can have a maximum of
100 Runic Power.

In general, spending Runic Power should be done when you are low
on Runes or if you do not have a [[spell:59057]] proc of a [[spell:51128]] proc.
There are cases where you will overcap on Runic Power but that is completely fine.

3.2.

#### Keeping Track of your Resources

Since Death Knights have multiple resources that they need to track, it
is very helpful to customize your UI to easily track your
resources. Being able
to easily focus on your rotation and resources can help you
maximize your damage and positioning.

### Positioning

3.3.

#### Positioning

Frost Death Knight has a number of spells, both active and passive, that hit enemies in front of your character. [[spell:1249658]],
[[spell:194913]] and [[spell:435010]] being the main ones. Due
to this, positioning your character to face as many enemies as possible is crucial
when doing AoE damage. Always stand at the edge of a pack of enemies and face
inward to maximise your DPS.

### Apex Talents

3.4.

#### Apex Talents

Frost Death Knight gets access to [[spell:1265632]] Apex Talents
as you level up from 80 to 90 in Midnight. The first rank buffs [[spell:279302]]
by 100% and provides a Haste buff when you use the ability. The second rank [[spell:1265633]]
extends your active [[spell:51271]] by 2/4 seconds when you cast [[spell:279302]]
in it, and improves the power of [[spell:377190]]. The final rank [[spell:1265637]]
provides a flat 10% Frost damage buff, an additional 100% increase to [[spell:279302]]
damage and allows you to recast the ability at 50% effectiveness for 45 seconds
after the first use.

The Apex Talents significantly incentivise picking up [[spell:279302]] and
additionally using it in our [[spell:51271]] windows. We send both charges
in our first window to avoid missing the next one, making sure to spread them out to
not overlap the buffs.

### Runes, Runic Power and Mastery

3.5.

#### Runes

You have a total of 6 Runes, which are available by default. Some of your
abilities have Rune costs, and whenever you use an ability that consumes one
or more Runes, those Runes will immediately begin recharging. The exact amount
of time it takes a Rune to recharge depends on how much Haste you have.

Whenever a Rune is consumed, you gain 10 Runic Power (more on that
below).

At most, 3 of your runes can be charging up at the same time. It is
therefore optimal to keep at least 3 runes on cooldown to maximise
the recharge rate over the course of the fight.

3.6.

#### Runic Power

Runic Power is a resource that resembles Rage, in the sense that it
decays when out of combat, but does not decay during combat. As mentioned
above, consuming Runes generates 10 Runic Power per Rune spent, and this is
the primary means of generating Runic Power, although some abilities also
help with this. You can have a maximum of
100 Runic Power.

3.7.

#### Mastery: Frozen Heart

[[spell:77514]] increases all Frost damage dealt.

### Procs

3.8.

#### Killing Machine Procs

Your auto-attack critical strikes have a chance to make your next
[[spell:49020]] a guaranteed critical strike and
deal Frost Damage, meaning it will scale off your Mastery and ignore armor. It
also makes your [[spell:207230]] crit for 4x the normal damage, up from the standard 2x amount.
Killing Machine works based on the number of auto-attack critical strikes you
have had since the last proc. For dual wield, the first time you get an
auto-attack critical strike after your previous proc, you have a 30% chance to
get a new proc. If this fails, the next auto attack has a 60% chance. If this
also fails, you get a 90% proc chance and then a 100% proc chance if 3 auto-attack
critical strikes have failed in a row.

Wielding a Two-Handed weapon (and via the [[spell:81333]] spell)
increases these proc chances. You simply have a 100% chance to trigger a proc
every time you get a critical auto-attack. Still,
due to the lower attack speed of a Two-Handed weapon, and since you only have
one weapon to attack with, you still get 28% fewer procs when with Two-Handed
builds.

Generally, these procs should be used right away to ensure that no
procs are overwritten.

If you have the [[spell:281238]] talent, then this ability
causes each [[spell:49143]], [[spell:194913]] and [[spell:49184]] to trigger
[[spell:51128]] (for the duration of [[spell:51271]]).
Aim to never overcap [[spell:51128]], never actively generating one
if you are already at two charges.

3.9.

#### Rime Procs

Your [[spell:49143]] / [[spell:194913]] has a 45% chance of causing your next
[[spell:49184]] to be free of cost and deal additional damage,
thanks to [[spell:59057]]. Make sure to consume these procs before you use the next
[[spell:49143]]/[[spell:194913]]!

4.

### Important Cooldowns for Frost Death Knight

### Reaper's Mark

4.1.

#### Reaper's Mark

[[spell:439843]] is the active ability you gain from the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer
tree. With a 45-second cooldown, you can align it with every [[spell:51271]]
window! Simply macro it with your [[spell:51271]] every time.

The main aspect to consider with [[spell:439843]] is the amount of
[[spell:51128]]s it generates through the consumption of the [[spell:441378]]
procs. Once [[spell:439843]] pops, you get two [[spell:441378]]s which give two 
procs of [[spell:51128]]. Keep track of the proc so you know
when you generate Killing Machines, and avoid double-stacking or overcapping
unnecessarily. Also bear in mind that the [[spell:441378]]s reduce the cost of your
[[spell:49020]]/[[spell:207230]] by 1 Rune, allowing you to use a lot more of them
in your burst window.

### Pillar of Frost

4.2.

#### Pillar of Frost

[[spell:51271]] grants you 20% Strength for 12 seconds. With a 45-seconds
Cooldown it aligns well with [[spell:439843]], [[spell:279302]] and
[[spell:1249658]], whichever combination of the talents we pick up.

You should use this ability on cooldown and ideally couple
it with any potions or on-use trinkets you may have.
That said, it can sometimes be better to save it for a few seconds until a high-priority target
becomes available.

Maximising the number of GCDs that you use within [[spell:51271]] is important
to maximise your DPS. Due to this, we leverage Macros whenever we use Pillar, combining
the off-GCD ability with an on-GCD ability to instantly cast your first spell within
the window. This requires you to start off on an empty GCD before you use the macro!
You can read more about it in the Macro section of the guide.

### Remorseless Winter

4.3.

#### Remorseless Winter

[[spell:196770]] deals damage and slows by 20% to all targets
around you over 8 seconds. The value and usage of the talent changes significantly
depending on the talent setup you use.

[[spell:377253]] completely removes the active part of the talent, simply
casting it automatically whenever you use [[spell:51271]]. This is the most
common situation, making a lot easier to deal with the usage.

Without [[spell:377253]], the situation becomes more complicated. In Single
Target, we use Remorseless on Cooldown if we pick up the buffing talents starting
with [[spell:194912]]. Ideally try and align it with every [[spell:51271]],
so delay it slightly to keep it synced to a 45 seconds Cooldown cycle.
In this scenario, you should aim to extend your [[spell:376938]] debuff on enemies
when possible. Furthermore, if you can refresh your Remorseless Winter while
it is running still (extending it significantly with [[spell:194912]]), you refresh
its duration while keeping the buff stacks, a big DPS increase!

The final Single Target use-case is when you have only talented [[spell:456237]].
In this case, make sure to use [[spell:196770]] to consume the stacks
whenever you reach 20!

For AoE, we always use this ability as much as possible (without [[spell:377253]])
to deal AoE damage and buff your [[spell:207230]] use with [[spell:316916]].

### Empower Rune Weapon

4.4.

#### Empower Rune Weapon

[[spell:47568]] is an off-gcd [[spell:51128]] and Runic Power
generator. It helps us reduce the number of no-KM [[spell:49020]]s we cast
in a fight, as well as providing a ton of resources. Furthermore, during [[spell:51271]]
with [[spell:281238]], it gives a lot of free casts of Obliterate which is a lot of value.

We want to use this ability whenever we are about to reach two stacks of it, so
we do not overcap. Otherwise we use it when we cannot use [[spell:49143]]
and we do not already have a proc of [[spell:51128]]. Finally, we use
it during [[spell:51271]] to gain Killing Machines and help us maintain
a healthy Resource level!

### Breath of Sindragosa

4.5.

#### Breath of Sindragosa

[[spell:1249658]] costs 60 Runic power and lasts for 8 seconds,
dealing AoE damage in front of you. The duration can be increased by consuming
procs of [[spell:51128]] and [[spell:59057]], extending it up to 30
seconds!

To maximise this ability, we use it in combination with [[spell:281238]].
[[spell:281238]] is all about the generation and consumption of [[spell:51128]],
synergising very well with [[spell:1249658]]! As we already prioritise
our procs at the top of our list, our rotation does not actively change during
Breath, we just keep going with our standard Single Target rotation!

Make sure to pool Runic Power for every [[spell:51271]] that you
are planning to use Breath for, to make sure you have the required 60 to initiate
the window!

Note that [[spell:1249658]] grants a charge of [[spell:47568]]
when you use it. Make sure to never have two charges available before you press Breath.

### Frostwyrm's Fury

4.6.

#### Frostwyrm's Fury

[[spell:279302]] is a strong single-target and AoE Cooldown which gets further buffed 
by our Apex Talents. Whenever you use it you will be able to press the button once
again within a 45-second window, to recall the dragon at 50% effectiveness.
Use [[spell:279302]] with each [[spell:51271]] window (in a macro with
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse, or just after Pillar with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer). 
Use the second charge ~12 seconds later, still within your [[spell:51271]],
with the Haste buff having elapsed (remember that the callback is off the GCD).

You have the option of saving the second cast of [[spell:279302]]
to the next [[spell:51271]] window. This is generally not recommended
as it gets really tight to pull off right, since Pillar and the recall timer
has the same duration.

### Obliteration

4.7.

#### Obliteration

[[spell:281238]] is not a Cooldown on its own but it does significantly
alter how [[spell:51271]] works and deserves a mention. With this talent
and when Pillar is active, [[spell:49143]], [[spell:194913]] and [[spell:49184]]
all generate procs of [[spell:51128]]. Due to this, we end up in a "weaving"
rotation where we generate and consume procs of [[spell:51128]] every GCD.

The weaving nature enables you to easily predict your actions within the window,
optimising your spell usage and GCD utilisation. You know that the [[spell:49143]]/[[spell:194913]]
will generate a [[spell:51128]] that you then consume with [[spell:49020]]/[[spell:207230]].
If you got a proc of [[spell:59057]] you know that you then press [[spell:49184]]
followed by another [[spell:49020]]/[[spell:207230]] and so on. Leverage
this deterministic nature of the Cooldown to maximise your ability use!

Finally, you want to enter the window with sufficient resources to execute it
without any downtime. [[spell:47568]] helps a lot to prevent this but you
should still avoid consuming no-KM [[spell:49020]]s within 5 seconds or so
before the window starts (as long as you are below 4 Runes).

5.

### Changelog

:::details 历史更新记录
- **19 Oct. 2026:** Adjust Reapers Mark timing in opener.
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Sep. 2026:** Update priority list for better Frostwyrm's Fury timing.
- **14 Sep. 2026:** Updated Default and recommended raid build to Deathbringer Breath of Sindragosa.
- **31 Aug. 2026:** Updated the target-count threshold to use Obliterate at 1-2 targets and Frostscythe at 3+ targets.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with new timeline.
- **24 Apr. 2026:** Updated opener and frostwyrm cooldown management.
- **20 Apr. 2026:** Updated for Patch 12.0.5 with Exterminate changes and frostywrm callback change.
- **29 Mar. 2026:** Removed major CD aspect of single button assistant.
- **16 Mar. 2026:** Updated rotation with Midnight Season 1, brining in tier set impact on opener.
- **26 Feb. 2026:** Updated rotation for midnight with new rotation layout and frostwyrm priority.
- **10 Feb. 2026:** Updated frostbane priority after simc bugfix.
- **19 Jan. 2026:** Updated for Midnight pre-patch, changing priority due to Frostbane buff.
- **17 Dec. 2025:** Changed low Rune KM rule to FS instead of Rime.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **27 Nov. 2025:** Added FAQs and updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **09 Sep. 2025:** Fixed typo and improved opener for non-scythe builds.
- **07 Sep. 2025:** Moved Breath into Pillar macro.
- **06 Sep. 2025:** Updated Opener to better represent longer sequence.
- **04 Sep. 2025:** Updated opener to reflect better and simpler version.
- **02 Sep. 2025:** Clarified Exterminate impact on rotation as well as Rune condition for KM consumption.
- **12 Aug. 2025:** Simplified the opener by moving Breath out of Macro button.
- **05 Aug. 2025:** Updated opener to match new Double-Oblit opener and added AoE option.
- **04 Aug. 2025:** Completely revamped page with Patch 11.2, simplifying structure and rotations.
- **27 Jun. 2025:** Added more rotation switches for shattering blade.
- **15 Jun. 2025:** Increased use of image blocks and clarified Breath opener.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Removed Soul Reaper usage (it is not worth to cast) and expanded on Remorseless Winter gameplay.
- **20 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **08 Nov. 2024:** Clarified Death and Decay use without TLW.
- **21 Oct. 2024:** Updated openers to reflect Mark + Pillar, and added new reaper of soul talent gameplay.
- **08 Oct. 2024:** Updated Reapers Mark prio to be used with pillar.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed and Updated for Season 4, changing wording around Chill Streak and the old tier set.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **23 Jan. 2024:** Added more detailed Fyralath priority.
- **15 Jan. 2024:** Updated frostscythe priority.
- **15 Dec. 2023:** Updated Obliteration priority to not be greedy with double KM.
- **15 Dec. 2023:** Clarified DnD usage in AoE.
- **01 Dec. 2023:** Clarified Obliteration rotation with single ERW.
- **12 Nov. 2023:** Moved Remorseless Winter priority up and clarified refreshing with gathering storm.
- **06 Nov. 2023:** Updated for Patch 10.2. Added Soul Reaper usage, clarified various bits and expanded on Chill Streak use.
- **04 Sep. 2023:** Clarified gameplay around Fatal Fixation.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 Jun. 2023:** Expanded on Breath rotation and added Obliteration secondary burst window.
- **01 May 2023:** Reviewed and Updated for Patch 10.1. Primarily changing Frostwyrm's Fury usage.
- **20 Mar. 2023:** Updated rotation for 10.0.7, adding discussion about Fatal Fixation.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Frost Death Knight in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Frost Death Knight

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

:::details FAQAre Two-Handed or One-Handed Weapons Better?
Dual-Wield weapons are strictly better in Midnight season 2. This is
due to a number of factors but mainly the strong synergy with [[spell:435010]]
which is buffed by the season 2 tier set.

:::

### Overall

This list contains the highest DPS setup from all sources for Frost Death Knight. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your best next piece might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, catalysing an item retains its secondary stats (and ilvl). This provides a lot more flexibility in how we optimise our gear distribution. Due to this, we want the following pieces:

- Head: [[item:281239@JAACAAQ42A]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Shoulders: [[item:251138]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Chest: [[item:268222]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Gloves: [[item:271475]] from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- Legs: [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details FAQWhich Items Should I Prioritise?
There are a couple of items that are very high priority in your BiS gear and that you want to prioritise from Great Vault and Voidcore usage:

- [[item:268209]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): BiS higher-ilvl weapon with an additional effect that synergises with our BiS passive trinket.
- [[item:268202]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS higher-ilvl weapon with an extra powerful on-proc effect.
- [[item:270175]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS on-use trinket with a higher ilvl.
- [[item:268265]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS neck with higher ilvl and an extra effect.
- [[item:270173]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): BiS passive trinket that synergises with our BiS weapon.
- [[item:281029]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS ring with an extra effect.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:281239@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271473@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271477@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[spell:62158]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268202@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[spell:53344]]</span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup from Mythic+ sources for Frost Death Knight. This is not your best setup **for** Mythic+ but only **from** Mythic+.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, catalysing an item retains its secondary stats (and ilvl). From Mythic+, we want to catalyse the following pieces:

- Head - [[item:251126]]
- Shoulders - [[item:251138]]
- Chest - [[item:268222]]
- Hands - [[item:159413]]
- Legs - [[item:273776]]

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): Solid weapon, BiS shoulders and solid chest.
- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): BiS ring.
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): BiS ring, great neck and helm.
- [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): Good waist and feet.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271474@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAAEAAAj1gjM]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271473@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:239656@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Feet</th><td>[[item:159412@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271477@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273797@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:158373@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[spell:62158]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:158373@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[spell:53344]]</span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup from Raid sources for Frost Death Knight.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, catalysing an item retains its secondary stats (and ilvl). From Raid, we want to catalyse the following pieces:

- Head - [[item:281239@JAACAAQ42A]]
- Shoulders - [[item:268226]]
- Chest - [[item:268222]]
- Hands - Tier Piece
- Legs - [[item:271878]]

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:268209]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): BiS higher-ilvl weapon with an additional effect that synergises with our BiS passive trinket.
- [[item:268202]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS higher-ilvl weapon with an extra powerful on-proc effect.
- [[item:270175]]: BiS on-use trinket with a higher ilvl.
- [[item:268265]]: BiS neck with higher ilvl and an extra effect.
- [[item:270173]]: BiS passive trinket that synergises with our BiS weapon.
- [[item:281029]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS ring with an extra effect.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:281239@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271473@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271477@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/frost-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[spell:62158]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268202@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[spell:53344]]</span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Frost Death Knight in Season 2

Frost Death Knight favours a combination of one active trinket and one
passive trinket. For active trinkets, [[item:270175]] is by far
our best option with great synergy with our 1.5 minute Cooldowns. It also comes at a higher
ilvl due to dropping from the final boss.

For passive trinkets, [[item:270173]] is our best option. It is a direct
damage passive trinket which synergises with our BiS weapon [[item:268209]].

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Frost Death Knight Trinkets**
**On-Use -**

[[item:270175]]

or, alternatively,

[[item:250238]]

**Passive -**

[[item:270173]]

or, alternatively,

[[item:270164]]

:::

There are quite a few other valuable trinkets out there, so make sure to click on our
  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Frost Death Knight Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270175]] - <span><em>Click for Details</em></span>&#10;<span>Best on-use by far which synergises nicely with our 1.5 minute cooldowns. It sits almost 4% ahead of the second&#10;       best on-use so there is no real debate.&#10;       </span>&#10;&#10;&#10;&#10;[[item:270173]] - <span><em>Click for Details</em></span>&#10;<span>Best passive trinket for low target counts. The damage proc is simply too strong, especially when combined with [[item:268209]].&#10;       </span>&#10;&#10;&#10;&#10;[[item:281215]] - <span><em>Click for Details</em></span>&#10;<span>Best passive stat trinket for AoE situations. With its high proc rate, its close to comparable to Guillotine in low target counts, &#10;        but shines in multi-target scenarios, while being particularly effective in Mythic+ content.&#10;       </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:249343]] (298 ilvl)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:246305]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:273796]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193762@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:270163]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Midnight's patch 12.0.5 introduced a new, yet familiar system: [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) 
allows you to target loot from specific bosses or dungeons. 
Using it guarantees a drop from that source, though the exact item is still random. 
However, once you’ve obtained an item this way, future uses will prioritize items you 
haven’t collected yet from that pool.

[[item:268552]] enhances Hero- and Myth-track gear that has already reached 
its maximum item level, as well as fully upgraded Radiance-Crafted items. It provides an 
extra power boost similar to past Turbo Boost upgrades, but can only be applied to weapons 
and trinkets.

3.1.

#### Nebulous Voidcore Recommendation

Getting a guaranteed piece of loot from a specific dungeon or boss is very useful.
In general, we recommend using these for raid encounters as you can obtain higher ilvl
pieces that way. We recommend using them on the following bosses (if you do not have the item
specified already). Always simulate yourself to find the best possible choice given your
character's gear and stats!

- [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) for [[item:268209]], [[item:270173]], [[item:268259]], [[item:268222]] and [[item:268253]].
- [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:270175]], [[item:268265]], [[item:271878]] and [[item:268202]].

3.2.

#### Ascendant Venomstone Recommendation

Prioritising the item upgrade is relatively simple: start with your weapon and then
follow-up with your trinkets, before finally upgrading your necklace.

4.

### Best Crafted Items for Frost Death Knight

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose the exact
secondary stats you want.

Deciding what to craft is a difficult task. Our BiS crafted items are
Boots and Wrists, both with Crit Mastery and [[item:240167]].
However, crafting weapons early is often by far the largest upgrade possible
and a significantly more efficient spend of your crests. In general, this
is what most poeple will do.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Frost Death Knight Crafted Gear Priority**
- [[item:237834@JAAKAAwt1ENMMYDYwclI]] with [[item:240167]]
- [[item:237828@JAAKAAwt1ENMMYDYwclI]] with [[item:240167]]
- Any item you do not have on Myth track yet.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Frost Death Knight

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

As there is a lot of competition for Embellishments, you will have to pick
and choose the two strongest ones for your overall DPS output. Most of them provide
very similar DPS benefits, even if the effects are entirely different. The two best
choices for this are:

- For Raid: [[item:240167]] on crafted Boots and a crafted Wrists.
- For Mythic+: [[item:240167]] on crafted Boots and a crafted Wrists.

Technically, [[item:251490]] on wrists + [[item:251513]]
is BiS by 0.2%. However, we recommend double [[item:240167]] since it provides an
extra benefit to your raid and allows for easier multi-speccing (Unholy runs Arcanoweave).

A strong alternative is to run [[item:245876]] on one or two crafted
1H weapons. This is especially powerful early in the season as it allows you
to get high-ilvl weapons (which is the slot that provides by far the most benefit
per point of ilvl). Therefore, always consider crafting weapons early in the season.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

[Myth Mistcrest](<https://www.wowhead.com/currency=3446>) is a currency you can use to upgrade your gear. Each
piece comes in a specific leveling track where it can be upgrade to a specific max
level. If you see an item with Myth 3/6, it means that it can be upgrade a total of
3 times to reach Myth 6/6. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Frost Death Knight Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots/Rings**

:::

These are simply the items that tend to be the best to upgrade. Do not
follow the priority blindly as there are cases where you would want to upgrade
something else first. Always sim yourself to figure out what it your current
best option.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Update for 12.1.5.
- **13 Sep. 2026:** Updated gear for hotfixes.
- **17 Aug. 2026:** Added best crafted items section.
- **15 Aug. 2026:** Added paragraph on Loa band option.
- **13 Aug. 2026:** Expanded trinket tier list.
- **10 Aug. 2026:** Updated with Patch 12.1.
- **15 Jun. 2026:** Update with sporefused items for 12.0.7.
- **24 May 2026:** Fixed a gear drop location typo.
- **20 Apr. 2026:** Updated for 12.0.5 with turboboost recommendations.
- **28 Mar. 2026:** Resolved an issue with bis neck source.
- **16 Mar. 2026:** Updated for Midnight Season 1 with BiS gear, crafting and trinkets.
- **26 Feb. 2026:** Updated for Midnight launch with pre-season bis.
- **10 Feb. 2026:** Clarified 2H vs DW paragraph.
- **25 Jan. 2026:** Updated bis to represent breath build.
- **19 Jan. 2026:** Updated for Midnight pre-patch changing to DW, adding more haste and adding level items section.
- **14 Dec. 2025:** Updated dungeon neck.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **16 Nov. 2025:** Updated some trinket recommendations to push prism.
- **05 Oct. 2025:** Added Puzzling Cartel Chips.
- **02 Sep. 2025:** Updated BiS to match deathbringer stat priority.
- **10 Aug. 2025:** Updated BiS list and trinke tier list.
- **04 Aug. 2025:** Updated with Patch 11.2. New BiS list, artifact cloak, new tier sets and new trinkets.
- **27 Jun. 2025:** Updated best D.I.S.C effect and improved wording in multiple spots.
- **23 Jun. 2025:** Updated best D.I.S.C effect after tuning.
- **15 Jun. 2025:** Added the new D.I.S.C belt to the bis list as well as a dedicated section for the belt. Minor trinket tier list updates.
- **27 Apr. 2025:** Updated Cartel wording and recommendations as well as BiS list.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated BiS lists, trinket tier lists, embellishments, crafting recommendations and tier set portion.
- **18 Dec. 2024:** Updated Cyrce's gems after news sims.
- **17 Dec. 2024:** Updated BiS lists to include Cyrce's Circlet after buffs.
- **15 Dec. 2024:** Update for Patch 11.0.7, adding Cyrce's Circlet.
- **26 Oct. 2024:** Added back missing trinkets in BiS list.
- **21 Oct. 2024:** Updated BiS list crafted pieces.
- **14 Oct. 2024:** Updated BiS passive trinket and added some delve trinkets.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated all gear for Season 4.
- **22 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **29 Nov. 2023:** Added Legendary with proper link to bis.
- **22 Nov. 2023:** Updated drop location from dawn upper and lower and changed Breath m+ bis trinkets to mirror and porcelain.
- **07 Nov. 2023:** Updated BiS Lists and Embellishment recommendations after Sporecloak nerfs.
- **06 Nov. 2023:** Updated for patch 10.2. Added new bis lists, trinkets and embellishment.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Added 10.1.5 dungeon recommendation.
- **01 Jun. 2023:** Added m+ embellishment recommendation.
- **31 May 2023:** Added neltharion trinket as new bis for frost 2H oblit.
- **08 May 2023:** Updated after trinket tuning.
- **01 May 2023:** Updated all gear for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Frost Death Knight. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Frost Death Knight Stat Priority

For raiding and Mythic+, the secondary stat priority for Frost Death Knight
is as follows:

Critical Strike

Haste

Mastery

Versatility

Crit and Haste have special synergy with Frost Death Knight kit due to
several abilities being based off Critical Auto Attacks, which themselves
scale via Critical Strike and Haste. [[spell:51128]],
[[spell:435010]], and [[spell:456240]], to name a few, are all scaled with
the number of critical autos you can get off. At the same time, our manual [[spell:51128]]
generators counteract this effect as guaranteed Critical Strikes devalue
Crit value.

Note that ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer has a slightly lower priority on Haste,
sim yourself to find the best balance when running Deathbringer.

2.

### In-Depth Stat Breakdown

**Strength** is your primary statistic. You should look for it
in all of your upgrades. It provides you with Attack Power, which
determines the damage your abilities do.

**Haste** increases your attack speed and your Rune regeneration rate
while decreasing the global cooldown. It increases the number of
[[spell:51128]] procs via the increased attack speed.

**Critical Strike** increases your chance to critically hit with
all spells and abilities. Crits deal double damage by default, but several 
effects can increase your crit damage, and make crits even stronger.

Crit also increases the number of [[spell:51128]] procs since it
increases the number of critical auto attacks you do! Furthermore, it scales well
with several abilities in Frost Death Knight kit like [[spell:435010]],
[[spell:456240]] and [[spell:440031]]. At the same time, it is devalued
by your manually generated [[spell:51128]]s that automatically Crit.

**Mastery**, through [[spell:77514]], increases your
Frost damage. Frost damage makes up a great part of your total damage.

**Versatility** increases all your damage and healing done, and decreases
all damage taken.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **14 Sep. 2026:** Reviewed for Patch 12.1.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **03 Jul. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **10 Apr. 2026:** Clarified Recklessness value.
- **16 Mar. 2026:** Updated for Midnight Season 1 with new bis talent distribution.
- **26 Feb. 2026:** Updated with Midnight stat priority and sample weights.
- **10 Feb. 2026:** Updated for pre-patch Midnight, changing stat prio due to Rider prio.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **05 Sep. 2025:** Put Mastery as top stat.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **27 Jun. 2025:** Minor rewordings to improve clarity.
- **15 Jun. 2025:** Added more crit interactions and added sim advise for stats.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4, and changed the BiS Sim Haste level for Oblit to 37.5%.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **01 Dec. 2023:** Added more context to haste breakpoints.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 Jun. 2023:** Moved Haste above Mastery in priority.
- **01 May 2023:** Updated for Patch 10.1. Emphasised the very high Crit priority for Breath.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Frost Death Knight, based on your [stat priority](<https://www.icy-veins.com/wow/frost-death-knight-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

We recommend going for [[item:240983]] as your epic gem and then
[[item:240906]] or [[item:240908]] as your
non-epic gems, prioritizing the stats that you have the least of on your gear. I.e.
if you already have lots of Haste on your gear, play the gem that provides more
Mastery, and vice versa.

2.

### Best Enchants and Weapon Augments

Frost Death Knights can utilize powerful Runeforges on their weapons instead
of normal enchants. Choosing the right enchant is crucial for optimizing your
DPS. Here are the best enchants for the different viable builds!

- [[spell:53344]] + [[item:243733]] for 2H .
- [[spell:53343]] + [[item:243733]] for 2H Breathbane.
- [[spell:53343]] MH + [[spell:53344]] +
  [[item:243733]] for Dual-Wield [[spell:207057]]/[[spell:455993]] Builds.
- [[spell:62158]] MH + [[spell:53344]] +
  [[item:243733]] for Dual-Wield [[spell:1249658]] builds.
- [[spell:53343]] MH + [[spell:53344]] +
  [[item:243733]] for Dual-Wield Breathbane Builds.

:::details FAQWhat do the Different Runeforge Enchants Do?
- [[spell:53344]]: The staple Runeforge for Frost Death
  Knights, you will always see this Runeforge used in both Mythic+ and Raid
  content.
- [[spell:53343]]: This Runeforge is used for some Dual-Wield builds.
  It allows you to gain a lot of benefit from [[spell:207057]].
- [[spell:326805]]: Provides a
  small execute effect for [[spell:49998]] and a small cheat death mechanic.
  This Runeforge has more of a place in PvP as opposed to PvE content.
- [[spell:326855]]: Provides
  small defense towards casters, making it more geared towards PvP
  situations.
- [[spell:327082]]: Currently very weak compared to other options,
  especially [[spell:53344]].
- [[spell:62158]]: Solid amount of stats, works well with
  Dual-Wield builds.
- [[spell:326977]]: Commonly used for leveling since it provides
  movement speed, Haste, and heals when you kill an enemy.

:::

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Head</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;</tr></table>

3.

### Optimal Consumables

You can consume a number of different temporary items to increase your power
in Dungeons and Raids. Below is a comprehensive overview of everything you want
to use!

3.1.

#### Flask

You generally want to use [[item:241326]]
in all content. If your crit is already sufficiently high (1600+)
consider using either [[item:241322]] or [[item:241325]]
to get a better stat distribution. Sim yourself to be sure.

3.2.

#### Potions

There are some options for potions that we can use, but we recommend [[item:241288]]
as your go-to potion for all content.

You should also make sure to keep up a stock of [[item:271883]]! These healing
potions are great for when you need to quickly heal yourself, helping your healers, and
ensuring that you stay alive.

3.3.

#### Food Buff

For Frost Death Knights, food which boosts your main stat is the best option. This
means that you either want to eat a feast such as [[item:255846]] or
[[item:255845]]. If your party or raid team does not supply a feast, you can eat
[[item:255847]] or [[item:242275]] as an alternative.

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s 
to increase your primary stat. Augment Runes are expensive and disappear on death, 
so use them wisely and sparingly!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **14 Sep. 2026:** Reviewed for Patch 12.1.
- **10 Aug. 2026:** Updated with Patch 12.1 changes.
- **15 Jun. 2026:** Changed to recklessness as default potion.
- **28 Apr. 2026:** Updated recommended ring enchant.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **10 Apr. 2026:** Updated potion wording.
- **28 Mar. 2026:** Added 2H Breathbane runeforge
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight with new enchants and consumables.
- **10 Feb. 2026:** Updated for Midnight, clarifying Runeforge choice and adding Midnight leveling consumables.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **05 Sep. 2025:** Swapped to recommending Mastery enchants and gems.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Removed Fallen Crusader from enchant table to avoid confusion.
- **21 Apr. 2025:** Added corruption enchant recommendations.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4, changed leg enchant to lambent.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **12 Nov. 2023:** Updated food recommendation.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1. Changed to Crit enchant for rings and added Belt stamina buckle.
- **20 Mar. 2023:** Updated with Primordial Stone Gems for 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Frost Death Knight in World of Warcraft Patch 12.1.5.

1.

### Frost Death Knight in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Frost Death Knight in
Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Frost Death Knight is a solid Mythic+ spec with a lot of talent
diversity and options. We bring good burst on a 45 seconds cadence with every other
one being more powerful. We are incredibly tanky but generally do not bring much group
utility.

2.

### Best Mythic+ Talent Builds

Frost Death Knight has two main talent builds to choose from in
      Season 2. Either you run [[spell:1249658]] or [[spell:455993]].
      In general, [[spell:1249658]] provides the best balance of
      single-target and AoE damage, and is the build we recommend.

If you are familiar with the large number of builds in Season 1,
      Season 2 has less build diversity as a result of [[spell:435010]] buffs
      as well as [[spell:455993]] nerfs. This means that we are essentially
      required to pick up IDT which leaves a lot less room for build diversity.

Our recommendation is to run the DW Breathbane build in all Mythic+ content.

### DW ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer    [[spell:455993]]

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer [[spell:455993]] build runs
a Dual-Wield setup with [[spell:53343]] and
[[spell:53344]]. This is different from other
builds, which instead run [[spell:62158]]
and [[spell:53344]]. It has good constant AoE potential
but tends to lack in single-target and overall DPS.

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxwMjxgxMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAARGF-AAAA-GIOQaACEWwgCzC-
```

:::

### DW ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer [[spell:1249658]]

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer [[spell:1249658]] build brings
the best balance of single-target and AoE damage. It sits very close to our Raid setup,
only swapping [[spell:1230301]] for [[spell:1230284]] to gain some extra
AoE.

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmAjFMzYmZgBghZGAgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-GIOQaACEWwgCzC-
```

:::

### DW ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse    [[spell:1249658]]

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse with [[spell:1249658]] sits
slightly behind ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer in Mythic+. It brings a slightly
more bursty damage profile, focusing more on the 1.5-minute cooldown windows.

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAAQRE-AAAA-PSMoYIIAISRDzC-
```

:::

### DW ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse    [[spell:455993]]

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse with [[spell:455993]] is a fun alternative
to the [[spell:1249658]] builds. It brings more constant DPS, as it relies
slightly less on the 1.5-minute burst window, but tends to have too low single-target
and overall DPS to be competitive.

:::talents 天赋构筑
```json
{
  "code": "CsPAAAAAAAAAAAAAAAAAAAAAAMDYmZMzMzYY2mZmZmZxMjMjxwMjxgxMzMzMzMDAAAAAAAAAgNzihBGY2YohNMzYmZgBgBgZGgB"
}
```
:::

:::details 来源计算器编码
```
#7D-BGGSUWXYhiQjmqqywRKMw8sVko01diigcAA-WXYZHVladefijBPbbhCLcUTSJAARGF-AAAA-PSMoYIIAISRDzC-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts, Stuns and Stops

[[spell:47528]] is your "kick" and your most important bit of utility in
Mythic+, used to stop enemy casts for the benefit of the group and especially
the tank. It is **highly recommended** to use a Focus Kick macro for this.

#### Mind Freeze Mouseover

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Mind Freeze
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

#### Focus Mouseover

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

3.2.

#### Stunning and "Stops"

[[spell:207167]] is your "AoE stop". You blind all targets in a cone in front of you, disorienting them for 5 seconds.
Great way of stopping a big pack of mobs casting, especially if the cast is immune to standard interrupt.

[[spell:221562]] is your Single Target stun, lasting for 5 seconds. Not a
very common pick in our talent loadouts, but it's still a useful crowd-control tool.

[[spell:49576]] can both be used to help group up mobs, as well as
stop-cast them. Remember that you need to move the move a certain distance
to actually interrupt it, just so you do not use [[spell:49576]] when
the mob is already on top of you.

[[spell:49576]] is notably also a defensive ability. With [[spell:454822]],
it provides 6% DR against any target you use it on. Useful when you are mitigating
damage in boss fights or mini bosses.

[[spell:279302]] stuns all targets hit
for 3 seconds. Not commonly used as a direct crowd control tool, simply a
nice "extra" from a spell that does a huge amount of burst AoE damage.

### Other Utility

3.3.

#### Other Utility

[[spell:61999]] is a combat-ress that you can use to bring a dead teammate back
to life, even during combat!

[[spell:207167]], [[spell:45524]], [[spell:196770]]
and [[spell:43265]] with [[spell:273952]] all reduce the movement
speed of enemies hit, allowing us to help any tank that wants to kite the mobs.

[[spell:111673]] allows you to control an undead enemy in Mythic+. This is
primarily a crowd-control tool, allowing you to temporarily control and then release
a specifically difficult mob. It can also present an opportunity to do slightly more
damage, as your standard [[spell:46585]] does very little. Remember that you
cannot use [[spell:46585]] when you are controlling an enemy mob. Below is a
useful macro when you need to recontrol the mob (the spell only lasts for 2 minutes)

#### Control Undead

```wow-macro
#showtooltip Control Undead
/target pet
/script PetDismiss()
/cast Control Undead
```

4.

### Dealing with Affixes

This guide mostly has Death-Knight-specific tips for Mythic+. If you want 
general guides for each of our Dungeons or Mythic+ in general, check out our 
dedicated page below.

[Midnight Mythic+ Season 2](<https://www.icy-veins.com/wow/midnight-mythic-season-2-guide>)

Midnight Season 2 offers four unique affixes that we can deal with to different
degrees with our kit. They rotate weekly with only one being active at a time. They
are also the only affixes that are active and require you to specifically handle them.

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. [[spell:207167]] is your most effective tool
  here to handle these orbs, with [[spell:47528]] and [[spell:49576]] handling
  any stray ones left.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn that
  needs to be focus-targeted and interrupted. Simply swap to the new add
  and focus it down. If you know it is spawning soon, considering holding your
  Cooldowns to deal with it quickly.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and circle
  around them. You have 15 seconds to soak all of these to buff your group. Use
  your movement abilities like [[spell:212552]] and [[spell:343257]]
  to quickly soak these up.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb. You can pre-immune this with [[spell:48707]]. However,
  this does mean that you miss out on the buff received when the shield is removed.
  Alternatively, help your healer to remove the shield by using [[spell:49998]]
  and Health Potions/ Healthstones if required.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **14 Sep. 2026:** Reviewed for Patch 12.1.
- **10 Aug. 2026:** Updated with new 12.1 builds.
- **20 Jun. 2026:** CHanged to dual-wield for M+ as recommended weapon.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated builds for 12.0.5 with Breathbane being the recommended one.
- **16 Mar. 2026:** Updated for Midnight Season 1 with new build and affix tips.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated to use Breath as recommended build.
- **19 Jan. 2026:** Updated for Midnight with new talent builds.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **31 Aug. 2025:** Swapped to Deathbringer as recommended build.
- **25 Aug. 2025:** Minor hero-talents clarification.
- **04 Aug. 2025:** Updated for Patch 11.2, adding new builds.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Added extensive dungeon tips.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated talents for Season 4.
- **22 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Added note on Scythe usage.
- **15 Dec. 2023:** Updated Obliteration KM priority.
- **15 Dec. 2023:** Clarified DnD location in pillar for AoE.
- **06 Nov. 2023:** Updated for Patch 10.2. Expanded on rotation significantly.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated talents for Patch 10.1. and removed Thundering affix mention.
- **20 Mar. 2023:** Updated talent builds for 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Frost Death Knight in World of Warcraft Patch 12.1.5.

1.

### Best Macros

1.1.

#### Generic Macros for Death Knights

1.1.1.

##### Raise Ally

#### Raise Ally

```wow-macro
#showtooltip Raise Ally
/cast [@mouseover,help][@target]Raise Ally
```

This macro casts [[spell:61999]] on your mouseover target, if they are a
friendly player. Otherwise, it casts Raise Ally on your current target.

1.1.2.

##### Mind Freeze

#### Mind Freeze

```wow-macro
#showtooltip Mind Freeze
/cast [@focus,harm,nodead][] Mind Freeze
```

This macro allows you to interrupt your focus target, if you have one, and
if not to simply interrupt your current target.

1.2.

#### Specific Macros for Frost Death Knights

1.2.1.

##### Pillar Trigger Macro

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer can use a condensed macro for the burst
to help cut down on button presses. This is pressed off the GCD inbetween [[spell:439843]]
and [[spell:279302]] in the opener.

#### Deathbringer Opener

```wow-macro
#showtooltip Pillar of Frost
/use trinket
/cast Pillar of Frost
/cast Raise Dead
/cast Breath of Sindragosa
```

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse, we end up in a more complicated situation
as we ideally want to use different on-GCD abilities depending on the situation we are in.
With [[spell:279302]] we can simply use that, but otherwise we need
to press the button that is appropriate for the situation. The "big burst"
 macro is the following:

#### Deathbringer Opener

```wow-macro
#showtooltip Pillar of Frost
/use trinket
/cast Pillar of Frost
/cast Raise Dead
/cast Breath of Sindragosa
/cast Frostwyrm's Fury
```

For our non-burst, we have separate macros for [[spell:49143]], [[spell:194913]],
[[spell:49020]], [[spell:207230]] and [[spell:49184]]. Choosing what macro
you press is exactly like following your standard priority (Frostwyrm when available,
Frost Strike with Frostbane/ 5 stacks of [[spell:51714]],
Obliterate with Killing Machine in Single Target etc). If you want to fully optimise
each one of your standard abilities has a pillar macro version as well with the following
structure:

#### Generic Pillar Macro

```wow-macro
#showtooltip Pillar of Frost
/use trinket
/cast Pillar of Frost
/cast Raise Dead
/cast ability
```

The exact macros to use are the written out below.

#### Frost Strike Pillar

```wow-macro
#showtooltip Pillar of Frost
/use trinket
/cast Pillar of Frost
/cast Raise Dead
/cast Frost Strike
```

#### Glacial Advance Pillar

```wow-macro
#showtooltip Pillar of Frost
/use trinket
/cast Pillar of Frost
/cast Raise Dead
/cast Glacial Advance
```

#### Obliterate Pillar

```wow-macro
#showtooltip Pillar of Frost
/use trinket
/cast Pillar of Frost
/cast Raise Dead
/cast Obliterate
```

#### Frostscythe Pillar

```wow-macro
#showtooltip Pillar of Frost
/use trinket
/cast Pillar of Frost
/cast Raise Dead
/cast Frostscythe
```

#### Howling Blast Pillar

```wow-macro
#showtooltip Pillar of Frost
/use trinket
/cast Pillar of Frost
/cast Raise Dead
/cast Howling Blast
```

1.2.2.

##### Death Grip Mouseover Macro

#### Death Grip Mouseover

```wow-macro
#showtooltip Death Grip
/cast [target=mouseover,exists] Death Grip; Death Grip
```

This macro will cast [[spell:49576]] on your mouseover target.

#### Anti-Magic Zone Cursor

```wow-macro
#showtooltip Anti-Magic Zone
/cast [@cursor] Anti-Magic Zone
```

This macro instantly casts [[spell:51052]] at your cursor's location.
It is useful for activating the Zone a tiny bit more quickly by spamming this
macro button. It also generally helps in placing it effectively.

#### Mind Freeze Mouseover

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Mind Freeze
```

This macro allows you to use your interrupt with a mouseover, avoiding
having to swap targets to interrupt.

#### Focus Mouseover

```wow-macro
/focus [@mouseover]
```

This macro enables a quick focus target setting using a mouseover.

1.2.3.

##### Control Undead

Controlling an Undead creature in dungeons is a nice way to add some minor
extra damage, as well as control a specific mob for however long you want.
It does need re-controlling every 5 minutes, and this macro
is perfect for that! It will target your pet, dismiss it, and then instantly
control it again.

#### Control Undead

```wow-macro
#showtooltip Control Undead
/target pet
/script PetDismiss()
/cast Control Undead
```

2.

### Best Addons

2.1.

#### Generic Addons for Death Knights

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.5.

#### Specific Addons for Frost Death Knights

Currently, we do not believe that you need any additional addons to play your
specialisation to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **24 Apr. 2026:** Updated pillar macros.
- **20 Apr. 2026:** Reviewed for 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1, adding a note on ERW usage in pillar macro.
- **26 Feb. 2026:** Updated macros for Midnight with new copy functionality.
- **10 Feb. 2026:** Updated for Midnight pre-patch with some macro clarification for rider.
- **30 Nov. 2025:** Reviewed for patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **12 Aug. 2025:** Simplified and clarified pillar macros.
- **07 Aug. 2025:** Elaborated on Macros.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated opener macro to more accurately represent Breath -> Macro opener.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **26 Oct. 2024:** Updated Obliteration macros for better clarity.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **22 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **01 Dec. 2023:** Clarified loss when not using Oblit Macros.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed and Updated for Patch 10.1. Emphasised that oblit macros are not necessary.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
