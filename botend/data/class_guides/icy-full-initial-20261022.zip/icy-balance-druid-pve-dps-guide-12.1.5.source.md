## 专精概览

Welcome to our Balance Druid guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Balance Druid in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Balance Mythic+ Resources

[NEW! Top Balance Talent Builds](<https://raider.io/specs/balance-druid/talents>)

[Top Balance Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/druid/balance>)

[Balance Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=druid--balance>)

[Popular Balance Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=druid--balance>)

1.

### Balance Druid Overview

The Balance specialization provides a simple but rewarding rotation, making
it great for new players while still maintaining a level of depth to keep older,
more experienced players engaged and competitive. It performs well on
multiple target instances and excels on single target fights, but has other
skill sets and a raid buff it brings to balance out some of its less viable
encounter types such as cleave and multi-target burst.

The other main goal of the rotation is to cycle through Eclipse, your main
buff. There are several talents influenced by entering or leaving Eclipse, which
incentivizes you to have a high uptime in an Eclipse state.

Good Priority Damage

Balance Druid performs well on both ends of the damage spectrum. Balance Druid is
currently an extremely hybrid focused class with both

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove

and

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

having many multi-target elements to their rotation
which allow them to adapt to most situations. Considering that it also does good
single target damage, this puts it in the higher end caster classes good in all PvE content.

Good Burst, Weaker Sustain

Balance Druid is a strong contender for a ranged DPS slot at all skill levels. It has
flexible major and minor cooldowns which allow it to output damage consistently or
pool for better bursts for priority targets or vulnerability windows. Additionally,
Balance Druid does fill the niche, spread multi target role when applicable in a raid
fight. It is generally not the best overall ranged option but it does provide valuable
damage on several of the more challenging fights.

Uncapped Multi-Target

Balance Druid does good damage in keys and shines on the trash between bosses. It does
great DPS and also brings

[[spell:78675]]

and other various knockbacks and mob
control abilities. It can

[[spell:2908]]

and Dispel as well as cast

[[spell:1126]]

, one of the stronger class buffs. The current build also is
flexible in single target as many of the same talents are ran across both builds.

Broad Toolkit

Balance Druid has a wide variety of utility spells at their disposal. They also have
many talents to alter or improve these utility spells. They have

[[spell:106898]]

for mobility as well as knockbacks, roots, cleanses, and

[[spell:2908]]

. These
spells can find use in all types of content.

Moderate Survivability

Balance Druids do have options to increase their survivability.

[[spell:5487]]

is
always available to increase Health and generally best used to take big hits.

[[spell:22812]]

also provides a low cooldown damage reduction that can be used
many times in a fight. What it lacks the most is both passive survivability and an
immunity or cheat death. It does not need these things but there is a distinct
difference going from a class with some of those tools to Balance Druid.

Highly Mobile

Balance Druid has great mobility options. It has its raid utility

[[spell:106898]]

as well as a baseline

[[spell:1850]]

. It takes passive
mobility talents and has Disengage as well. While it does have great mobility, it is
still difficult to maintain your rotation while moving long distances and if possible,
it is often better to shorten the time running rather than cast suboptimal spells.

2.

### Balance Druid in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 offers no meaningful changes to Druid or the Balance Druid Specialization.
The main focus of the patch are 2 new pieces of endgame content instead, one for Raid groups, and one
for [Delves](<https://www.icy-veins.com/wow/delves-guide>). Make sure to check out both the information on the new Kith'ix Raid encounter,
as well as the new exciting Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
a Trinket, Ring, and Chest. Additionally, you will be able to upgrade items with 
[[item:280562]] starting October 20th. Weapons, Necks, and Trinkets can all 
be upgraded.

2.3.

#### Class Changes

There are no changes to the Balance Druid Specialization in Patch 12.1.5, but there 
will be changes to the Overall and Raid based gear recommendations on our 
[gear](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>) page. We also have a list of 
high-value items to spend your first [[item:280562]] on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_moonglow.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class TuningHide Patch 12.1 Class Tuning
[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Balance Druid**

<em>Developers' notes: Our goal for Balance in Curse of Ula'tek is to 
	emphasize its core gameplay of building, spending, and pooling Astral Power. In 
	Midnight, Balance had high Astral Power generation and a lot of free spender 
	procs, which meant there weren't many GCDs left after casting spenders. In Curse 
	of Ula'tek we've reduced Astral Power generation and the number of free spenders 
	but increased the damage each spender does. The intent is to provide more time 
	to react to Astral Power gain and make pooling Astral Power outside Eclipse to 
	spend inside Eclipse more impactful. We've also adjusted some talent power to 
	increase build diversity.</em>

- **Class**
  
  
  - [[spell:385786]] absorb increased by 25%.
  - [[spell:319454]] empowered [[spell:48438]] healing increased by 25%.

- **Hero Talents**
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen: Star Cascade no longer triggers off of gaining 
    	  Astral Power with Wrath.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen: Star Cascade has a 30% chance to launch a 
    	  Starsurge at 50% effectiveness (was 40% at 70% effectiveness).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove: Bounteous Bloom now extends the duration of 
    	  Force of Nature Treants by 4 seconds instead of adding a fourth Treant.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove: Cenarius' Might haste increase reduced to 6% 
    	  (was 8%).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove: Potent Enchantments haste increase reduced to 
    	  6% (was 10%).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove: Sylvan Beckoning Dryad's Starfall damage 
    	  increased to 250% effectiveness (was 200%).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove: Spirit of the Thicket increases Starfall 
    	  damage by 18% (was 12%).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove: Dream Burst damage increased by 30%.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove: Power of Nature increases your treant melee 
    	  damage by 300% (was 200%).

- **Balance**
  
  
  - All damage dealt increased by 8%.
  - Apex Talent: [[spell:1261565]] (Rank 2) has been updated – 
    		Astral Smolder damage reduced to 10%/20% of Critical Strike damage 
    		(was 12%/24%) and its duration is increased to 8 seconds (was 6 seconds).
  - Apex Talent: [[spell:1261566]] (Rank 3) –Solar Bolt increased 
    		by 27% and Lunar Bolt damage increased by 10%.
  - [[spell:383195]] has been updated – Now increases Wrath and 
    		Starfire damage by 12% at all times.
  - [[spell:1240188]] and [[spell:202359]] have swapped 
    		positions in the Talent Tree. Sculpt the Stars reduces Eclipse cooldown by 3 
    		seconds (was 2 seconds).
  - [[spell:450212]] is now only applied to 1 target.
  - [[spell:8921]] damage increased by 5%.
  - [[spell:93402]] damage increased by 5%.
  - [[spell:5176]] damage increased by 10%.
  - [[spell:194153]] damage increased by 20%.
  - [[spell:78674]] damage increased by 71%.
  - [[spell:191034]] damage increased by 4%.
  - [[spell:202342]] damage increased by 10%.
  - [[spell:1240907]] damage increased by 15%.
  - [[spell:1240185]] increases the damage of Moonfire, Sunfire, and 
    		Shooting Stars by 10% (was 8%).
  - [[spell:383197]] effectiveness reduced to 50% (was 60%).
  - [[spell:394414]] chance to trigger from Wrath reduced to 12% (was 
    		15%), and chance to trigger from Starfire reduced to 15% (was 20%).
  - [[spell:1240206]] chance to trigger increased to 15%/30% (was 10%/20%).
  - [[spell:774]] healing increased by 25%.
  - [[spell:48438]] healing increased by 25%.
  - [[spell:8936]] healing increased by 25%.

:::

:::

### Midnight   Changes Overview

2.4.

#### Balance Druid Spec and Guide Changes for Midnight Launch

Midnight is bringing many changes to the game including class changes. Balance 
Druid will have access to three new Hero Talents for both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove 
and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen but, most importantly, we will have a new Eclipse system. 
This change is aimed at reducing the time it takes to enter Eclipse when you need to 
be doing damage.

2.5.

#### Eclipse Rework

Eclipse has been redesigned. It no longer requires two casts of the opposite 
filler type to enter your Eclipse. Now, it is a spell which will put you into an 
Eclipse based on your last cast. If you cast [[spell:5176]], you will enter Solar 
Eclipse and if you cast [[spell:194153]] you will enter Lunar Eclipse. Eclipse will 
still provide the same buffs and properties as it had previously. There will be new 
talents which interact with this Eclipse system which will be discussed later.

2.6.

#### Balance Druid Apex Talent

Midnight introduces three new Apex Talents for every class which will be earned as 
you level to max. The Balance Druid Apex Talent set is called Ascendant Eclipses.

1. [[spell:1261564]] – Activating an Eclipse makes your next [[spell:5176]] or [[spell:194153]] 
   instant. The first three [[spell:78674]]s or [[spell:191034]]s you cast during each 
   Eclipse deal 20% increased damage.
2. [[spell:1261565]] – Your Critical Strikes dealt during an Eclipse cause their victims to 
   languish for an additional 20% of damage dealt for 8 seconds.
3. [[spell:1261566]] – Activating an Eclipse also launches Solar or Lunar Bolts at enemies within 40 yds 
   that always critically strike. [[spell:1261573]] hits one target and [[spell:1263137]] 
   hits three targets and deals splash damage.

These talents are passive by nature and are generally not played around nor do 
they interact with the rest of the toolkit in any meaningful way. There are some 
tangible benefits to the instant cast filler as well as some of the burst potential 
on multi-target but you will generally not alter your rotation for these talents.

3.

### Basics of Balance Druid Gameplay

Balance Druid is a spec that utilizes two major systems in Eclipse and Astral 
Power. Eclipse is your main vehicle for dealing damage. It buffs your spell damage 
and cast speed based on the type of Eclipse you are in. You can choose to enter 
Solar Eclipse to do more single target damage or Lunar Eclipse to do more multi-target 
damage.

Almost all of your spells will generate Astral Power either directly through 
dealing damage or from some of your DoT effects. You will always want to keep your 
DoTs on any viable targets and do your best to always be casting spells to maintain 
Astral Power generation. When you have enough Astral Power, you can choose to spend 
it on either [[spell:78674]] for single target or [[spell:191034]] for multi 
target.

You will always talent into your main cooldown, [[spell:194223]], and 
this will give you both Eclipse states allowing you to cast whatever is appropriate 
while dealing increased damage. A quick breakdown of the main tenets of Balance 
Druid can be found in the bullet list below.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_moonglow.jpg>) **Build your Astral Power**  
  
    Many of your spells generate our main resource, Astral Power. You can spend 
    Astral Power on [[spell:78674]] and [[spell:191034]], dealing massive damage. 
    You always want to be building this resource and you never want to cap this resource.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_eclipseorange.jpg>) **High Eclipse Uptime**  
  
    Eclipse is Balance Druid's primary buff. You want to be in Eclipse as often as possible. When 
    you are not in Eclipse, you want to prepare for the next one by casting [[spell:8921]] 
    and [[spell:93402]] and building Astral Power.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_natureguardian.jpg>) **Manage your Cooldowns**  
  
    Balance Druid gets its primary cooldown early on in [[spell:194223]]. 
    This cooldown is enhanced multiple times through [[spell:468743]] and 
    sometimes [[spell:394013]]. You want to be stacking cooldowns 
    together such as [[spell:391528]], [[spell:205636]], or 
    [[spell:202770]] to compound their benefits and deal large bursts of damage 
    when you need it.

4.

### How to Gear Up as a Balance Druid

While we always recommend simming yourself for ideal results, we do provide a
dedicated Balance gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for patch 12.1.5
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated weapon enchant recommendation.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated crafted and embellishment sections.
- **17 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated consumable recommendations.
- **17 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Updated for Elune's Chose stat preference.
- **17 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Elune's Chose stat preference.
- **12 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Fixed Meteor Storm recommendation.
- **12 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated Stellar Amplification mention.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated best talent recommendations.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for Patch 12.1.0
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.0
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.0
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.0
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.0
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.0
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Patch 12.1.0
- **10 Aug. 2026 (this page):** Updated for Patch 12.1
- **30 Jun. 2026 (this page):** Updated for Class Tuning on June 30.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Sporefall release.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Added Heart of the Wild macro.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated ring enchant recommendations.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Updated stat priority recommedations.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reformatted Mechanics and Tips section.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Added Omnium Folio talent recommendations.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated Heart of the Wild entry.
- **15 Jun. 2026 (this page):** Updated for Patch 10.0.7.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **23 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated trinket recommendations.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Removed Tea mention and added context to tertiary stats.
- **23 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated talent recommendations.
- **23 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Added in context for the rotation in FAQ blocks and further expansions on Gameplay mechanics.
- **23 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated Talent recommendations
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation to remove Starweaver mentions.
- **17 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated Talent recommendations
- **17 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated Talent Recommendations
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed and Updated for Midnight S1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed and Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed and Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed and Updated for Midnight S1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed and Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed and Updated for Midnight S1.
- **16 Mar. 2026 (this page):** Reviewed and Updated for Midnight S1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed and Updated for the Midnight Launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed and Updated for the Midnight Launch.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed and Updated for the Midnight Launch.
- **26 Feb. 2026 (this page):** Reviewed and Updated for the Midnight Launch.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch
- **10 Feb. 2026 (this page):** Reviewed for Midnight Pre-Patch
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Added in FAQ block.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Added FAQ block.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Reviewed for Patch 11.2.7
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Puzzling Cartel Chip release and D.I.S.C nerf.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5
- **05 Oct. 2025 (this page):** Reviewed for Patch 11.2.5
- **30 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Added Keeper of the Grave Opener with new Tier set.
- **11 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for tier set changes and trinket sims.
- **11 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for tier change and buffs.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 11.2.0
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.0
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.0
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.0
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.0
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.0
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.0
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.0
- **04 Aug. 2025 (this page):** Reviewed for Patch 11.2.0
- **21 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Charged Bolts Nerf.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.7
- **15 Jun. 2025 (this page):** Reviewed for Patch 11.1.7
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated and Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Updated and Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed and Updated for Patch 11.1.5
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Updated and Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** Updated and Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated and Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated and Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated and Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Updated and Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed and Updated for Patch 11.1.5
- **21 Apr. 2025 (this page):** Updated and Reviewed for Patch 11.1.5.
- **16 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Added in some additional trinket notes.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** Updated raid tips for first 4 mythic.
- **03 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated Best in Slot list for Liberation of Undermine and Season 2.
- **03 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** Updated raid tips for Liberation of Undermine Normal and Heroic.
- **27 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed and Updated for Patch 11.1.0.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed and Updated for Patch 11.0.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed and Updated for Patch 11.0.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed and Updated for Patch 11.0.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed and Updated for Patch 11.0.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed and Updated for Patch 11.0.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and Updated for Patch 11.0.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed and Updated for Patch 11.0.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed and Updated for Patch 11.0.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed and Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Reviewed and Updated for Patch 11.0.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for the Cyrce's Circlet release of 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Reviewed for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for Patch 11.0.5 talent rework.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5 talent rework.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.5 talent rework.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Reviewed for Patch 11.0.5.
- **07 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated raid trinket recommendations.
- **07 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated some consumable recommendations.
- **07 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Made consistent with other Stat mentions.
- **07 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Added additional affix notes.
- **07 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated some talent recommendations.
- **07 Oct. 2024 (this page):** Updated some talent recommendations.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Season 1.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Season 1.
- **09 Sep. 2024 (this page):** Reviewed for Season 1.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/balance-druid-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **19 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/balance-druid-the-war-within-pve-guide>)):** Reviewed for The War Within Pre-Patch.
- **19 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for The War Within Pre-Patch.
- **18 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/balance-druid-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/balance-druid-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for new tier set in Dragonflight Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 (this page):** Updated for Dragonflight Season 4.
- **25 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6. Updated mentions of Blue Silken Linen.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6. Adjusted talent recommendations.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **08 Dec. 2023 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated some trinket recommendations relating to Balefire Branch.
- **08 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated mention of Rattle the Stars buff.
- **09 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Fixed Class Talent Selection Tree.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated with recent Sporecloak nerfs.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for Patch 10.2.0.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.0.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.0.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Updated for Patch 10.2.0.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2.0.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.0.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Updated for Patch 10.2.0.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Patch 10.2.0.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.0.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.7
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **08 May 2023 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for May 9th Hotfixes.
- **08 May 2023 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for May 9th Patch Changes.
- **08 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** New Mythic Plus Season launch.
- **08 May 2023 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated with May 9th Hotfixes.
- **08 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for May 9th Hotfixes.
- **08 May 2023 (this page):** Balance Druid Changes on May 9th.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Moved Primordial Stone recommendations to bottom of the page.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** No changes required for Patch 10.1.0.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for new talents in Patch 10.1.0.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Patch 10.1.0.
- **01 May 2023 (this page):** Updated for Patch 10.1.0.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/balance-druid-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.7. .
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated Phial recommendations and Primordial Stones.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated some builds and clarified Starweaver and Rattle the Stars viability.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated some sections to maintain consistency. Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Reviewed for Patch 10.0.7.
- **28 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated broken talent link.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed and updated for Patch 10.0.5.
- **21 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated embellishments and expanded trinket recommendations.
- **21 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Added notes for Neck consumable.
- **21 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Added some notes on Orbital Strike and Pulsar.
- **21 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated Starweaver versus Rattle the Stars.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Vault of the Incarnates and Season 1 Mythic +.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated personal food choice.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for Vault of the Incarnates and Season 1 Mythic +.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Added jewelry and item level notes.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for T29 Tier Set.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated broken talent links.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated talent choices and some basic info.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **15 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated talent recommendations.
- **15 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated talent recommendations.
- **15 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated talent recommendations.
- **15 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated talent recommendations.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/balance-druid-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/balance-druid-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/balance-druid-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/balance-druid-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **30 Jul. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/balance-druid-patch-9-2-changes-analysis>)):** Updated to reflect Patch 9.2.5 buff.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/balance-druid-patch-9-2-changes-analysis>)):** Page reviewed and approved for Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/balance-druid-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/balance-druid-patch-9-1-changes-analysis>)):** Updated for Patch 9.1.5.
- **17 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/balance-druid-patch-9-1-changes-analysis>)):** Page created.
- **17 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-ny-alotha-raid-guide>)):** Updated Essence recomendations. .
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **06 Nov. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** Updated some sections & added a section on Major Essence choice.
- **26 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** Added Mythic Zaqul and Queen Azshara.
- **29 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** Added Mythic mode notes for the first six bosses.
- **16 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for Queen Azshara.
- **16 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** Changed some Essence recommendations.
- **10 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for the first 7 bosses.
- **07 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-the-eternal-palace-raid-guide>)):** Page Added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-crucible-of-storms-raid-guide>)):** Added Mythic Mode.
- **23 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of Patch 8.2.
- **23 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of Patch 8.2.
- **12 May 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** Changed some talent recommendations.
- **25 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-crucible-of-storms-raid-guide>)):** Added tips for Heroic mode and below.
- **16 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **16 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **16 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-crucible-of-storms-raid-guide>)):** Page added.
- **26 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated Mythic Mekkatorque.
- **13 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** Finished the Mythic Mode sections.
- **07 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** Fixed some errors and added some Mythic Mode entries.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** Page Added.
- **13 Jan. 2019 ([Uldir page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** Updated some talent recommendations.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** Updated for Patch 8.1.
- **12 Oct. 2018 ([Uldir page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** Added Mythic Mode sections.
- **04 Oct. 2018 ([Uldir page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** Updated talent recommendations.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** Added talents.
- **13 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-uldir-raid-guide>)):** Added page.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Balance Druid leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Druid leveling guide](<https://www.icy-veins.com/wow/druid-leveling-guide>).

1.

### Balance Druid Leveling Guide for Midnight

The Druid class in general is a fantastic leveling class that offers a variety of 
different playstyles and the only class that lets you play as every type of style in 
the game. Feral for melee, Balance for caster, Guardian for tank, and Restoration for 
healing. Balance Druid has its own fun and interesting gameplay features that I hope 
you will come to enjoy as you level yourself!.

The biggest strength of Balance Druid leveling is its sheer toolkit which only 
increases as it gets levels. With its instant cast DoTs like [[spell:8921]], 
its unlimited target AoE (Area of Effect) spender [[spell:191034]], and eventually 
its 45-yard cast range, it is a fantastic puller. You are able to hit mobs quickly 
from far away and group them to be killed quickly and efficiently.

You can heal yourself and control enemies easily as a Balance Druid. Once you have 
access to abilities such as [[spell:132469]] and [[spell:102793]], you gain the 
ability to much more easily pull large quantities of monsters and keep them away from 
you as you cast on them safely.

When leveling in open-world or dungeons, Balance Druid is a very basic
builder-spender rotation priority. The basic idea is to rotate between
[[spell:1239669]]s, which lasts 15 seconds. Apply your DoTs ([[spell:8921]] and
[[spell:93402]]) to your target and cast the Eclipse-appropriate filler
([[spell:190984]] for Solar and [[spell:194153]] for Lunar). When you
have enough Astral Power, you can cast a spender ([[spell:78674]] on a single
target and [[spell:191034]] on multiple targets).

Here are some explanations for some of the phrases inside the guide that may
help you understand the information better.

- A DoT refers to Damage over Time spells such as [[spell:8921]] and
  [[spell:93402]].
- Fillers refer to spells that generate your main resource, which is Astral
  Power. Fillers should always be cast when there is nothing else we can do. Our
  fillers are [[spell:190984]] and [[spell:194153]].
- A spender is an ability that consumes our main resource. These are powerful
  abilities that are crucial to dealing damage. [[spell:78674]] is spent on
  single or priority targets, and [[spell:191034]] on multiple targets.

Balance Druid cooldowns all come from the talent tree.
[[spell:194223]] is your big cooldown and
provides the benefit of both [[spell:1239669]] states, allowing you to cast
whatever you want as well as buffing all of your spells. On a single target, you
will still be casting [[spell:190984]], and on multiple targets, you will
want to cast [[spell:194153]].

As an added note, do not forget to make use of [[spell:1231418]] to top yourself 
off after pulls as it will be faster than healing yourself.

1.1.

#### Leveling Gear Options

Item level is always more important than individual stats when leveling up. Always
choose the piece of gear with the highest item level. Items with Speed tertiary
stats can help speed up your leveling, especially during parts of extended time
spent indoors. Heirloom gear is also useful while leveling, allowing you to ignore a lot
of gearing for a large part of your leveling journey.

1.2.

#### Useful Leveling Consumables for Midnight

As you level up, you may want to visit the Auction House to look for level 
appropriate food, potions, and flasks depending on the type of content you are doing. 
Consumables can help significantly speed up the leveling process.

You may also wish to purchase [[item:132516]] to traverse long distances of the 
new continent quickly as well as [[item:109076]]s to cancel out fall 
damage or jump off mountains.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Balance Druid Level 80 Midnight Leveling
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmFmZmZDYMmZZsNjZmNWmxYMYDDAGgttxCmmZWGAAAAsxMzMD2MwYAYmBAGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmFmZmZDGjxMLjtZMzsxyMGjZmZDDAGgttxCmmZWGAAAAsxMzMD2MGGzAYmBAGA"
}
```
:::

:::details 来源计算器编码
```
#mB-nLLPO0NUJtaWA86QMehjllqYbztK86X5yxR-UWDfaBITak4QMZYAGqgh5lhpwTxRutO-AAAA-JSAUphZ5AJowAD-
```

:::

2.1.

#### War Mode Talents for Leveling

In this section, we will list the PvP talents best for leveling and doing
solo / small group PvE content. Note that these may not be optimal in actual
PvP situations.

- [[spell:356517]] is a passive effect that calls down falling stars on
  enemies during [[spell:191034]]. Enemies who run into this take damage and get
  knocked up. Allies can pick these up and run into enemies to detonate them.
- [[spell:209740]] is amazing for group combat and strong for solo
  content as well. This can buff all members in your party and help finish quests
  and rares faster. We would recommend this for all group content.
- [[spell:305497]] can provide minimal peel or damage in open-world content.
- [[spell:236147]] will let you move at 100% Movement Speed
  even while in combat. Great for open-world content.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–9：**Due to Balance only being unlocked as a talent
specialization at Level 10, you should make use of the abilities provided
to you in the intro quests until you are presented with the option.

1. **等级 10 起：**Enter [[spell:24858]] and be in this form at
   all times.
2. Cast [[spell:205636]] to hold aggro and damage mobs.
3. **等级 2 起：**Apply [[spell:8921]] to the target.
4. **等级 10 起：**Apply [[spell:93402]] to the target.
5. **等级 27 起：**Cast [[spell:194223]] on cooldown.
6. **等级 55 起：** Cast [[spell:391528]] inside cooldowns.
7. **等级 11 起：**Cast [[spell:1239669]]  if [[spell:194223]] 
   is on cooldown. Cast [[spell:190984]] to activate Solar Eclipse on single target 
   and [[spell:194153]] to enter Lunar Eclipse on multi target.
8. **等级 10 起：**Cast [[spell:78674]] when available on a single
   target and inside [[spell:1239669]].
9. **等级 10 起：**Cast [[spell:191034]] on more than one target.
10. **等级 10 起：**Cast [[spell:190984]] or [[spell:194153]] as
    a filler to build Astral Power inside [[spell:1239669]].

When talenting any cooldowns, such as
[[spell:205636]] or [[spell:391528]], you should use them as they
come up. While leveling, most enemies will not pose much of a threat or have
extended battles. Use these cooldowns to help speed things up as you level.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.0
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed and Updated for Midnight S1.
- **26 Feb. 2026:** Reviewed and Updated for the Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **04 Aug. 2025:** Reviewed for Patch 11.2.0
- **15 Jun. 2025:** Reviewed for Patch 11.1.7
- **21 Apr. 2025:** Updated and Reviewed for Patch 11.1.5.
- **27 Feb. 2025:** Reviewed and Updated for Patch 11.1.0.
- **24 Feb. 2025:** Reviewed and Updated for Patch 11.0.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5 talent rework.
- **09 Sep. 2024:** Reviewed for Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **25 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **09 Nov. 2023:** Fixed Class Talent Selection Tree.
- **06 Nov. 2023:** Updated for Patch 10.2.0.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **08 May 2023:** Updated for May 9th Hotfixes.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **28 Jan. 2023:** Updated broken talent link.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Balance Druid in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Balance Druid

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Balance Druid has a single target and multi-target rotation, which both
require good DoT uptime and proper building and spending of Astral Power.
Cooldowns should be used as they become available.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_moonglow.jpg>) **Build your Astral Power**  
  
    Many of your spells generation our main resource, Astral Power. You can spend 
    Astral Power on [[spell:78674]] and [[spell:191034]], dealing massive damage. 
    You always want to be building this resource and you never want to cap this resource.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_eclipseorange.jpg>) **High Eclipse Uptime**  
  
    Eclipse is Balance Druid's primary buff. You want to be in Eclipse as often as possible. When 
    you are not in Eclipse, you want to prepare for the next one by casting [[spell:8921]] 
    and [[spell:93402]] and building Astral Power.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_natureguardian.jpg>) **Manage your Cooldowns**  
  
    Balance Druid gets its primary cooldown early on in [[spell:194223]]. 
    This cooldown is enhanced multiple times through [[spell:468743]] and 
    sometimes [[spell:394013]]. You want to be stacking cooldowns 
    together such as [[spell:391528]], [[spell:205636]], or 
    [[spell:202770]] to compound their benefits and deal large bursts of damage 
    when you need it.

2.

### Beginner's Guide to Balance Druid

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove   Single-Target Talents

2.1.

#### Beginner Single-Target Talents for Balance Druid

With current tuning, both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove 
are within 2% of each other. This build is optimal for single-target situations.

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmlZmZmBYwyMbzYGzMbsMjZGjZ2wAgBYbbsgpZmlBAAAAbmZmZGsZMMmBwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04YZbpBUYEJpzTdFWebjM1NWG-UWaDJXfHNSmADFQYYo4gh15lh5JnYxR-AAAA-FGQYcgkQpBYQmF-
```

:::

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen   Multi-Target Talents

2.2.

#### Beginner Multi-Target Talents for Balance Druid

This is our recommended build for AoE scenarios. This works well for AoE
Fights in Raids, as well as most Mythic+.

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmlZmZmBYYMzyMbmZmZhlZWGjxYDDAGbLzMYMbDgJAAAALmZmZGsZMMGAAmZwyA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04YZbpBUYEJpzTdFWebjM1NWG-UWaBDHfEKNSmwwAJZY44lh5RFOxCIDXA-AAAA-GKOik0AMggBDxC-
```

:::

**You will <em>not</em> be able to enter Solar [[spell:1239669]] while playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen due to [[spell:429523]].**

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

### Balance Druid   Basic Rotation

2.3.

#### Beginner Balance Druid DPS Rotation

Balance Druid has an Eclipse cycle-based gameplay loop. You will enter
Solar Eclipse on single and up to three and Lunar Eclipse on four or more
targets. You cast [[spell:5176]] in Solar Eclipse and [[spell:194153]] in
Lunar Eclipse. The exception to this is when you are using ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen 
where you will always use [[spell:194153]] as filler.

It is important to keep your DoTs up to generate Astral Power and deal additional 
passive damage. [[spell:93402]] is easily spread to all targets
around your main target, and [[spell:8921]] can be cleaved to one additional
unit per cast with [[spell:279620]].

On a single target, you will use your cooldowns as they come up or when you
can stack multiple cooldowns together. You will use [[spell:78674]] as your
way of spending Astral Power. On multiple targets, you will instead cast
[[spell:191034]] as your main way to spend Astral Power.

Once your DoTs are up and you start generating Astral Power, you will have
some other cooldowns to utilize. The below talents are opt-in from talents and
may not always be applicable to a given fight.

- [[spell:194223]] is your primary cooldown, which can be
  further improved with [[spell:390378]]. This gives you the effects of
  both [[spell:1239669]] states, amplifying certain damage types.
- [[spell:391528]] is a strong cooldown that casts 16 spells over
  4-seconds. This does good single-target damage but is still useful in
  multi-target fights.
- [[spell:202770]] and [[spell:274281]] are commonly taken spells in
  the Talent Tree. Fury of Elune is commonly taken to boost Astral Power generation.
- [[spell:205636]] is a strong cooldown when talented into 
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove. It procs [[spell:433831]] and other passive damage 
  bonuses and can be stacked with other cooldowns such as [[spell:194223]].

There are more spells that can be taken, but these are ones that will be taken
more often than not.

2.3.1.

##### Utility Spells

Balance Druid brings many buffs and utility spells to the table. On top of
being able to heal others, we have many iconic spells that help us and our
teammates in unique ways.

Balance Druids have multiple displacement spells. [[spell:132469]] to knock
back enemies. [[spell:102793]] and [[spell:102359]], as well as
[[spell:339]] can keep enemies in one place. There have been entire
bosses and mechanics revolving around the coordinated use of these abilities.

Balance Druid also has other ways to help the raid. [[spell:106898]]
increases your movement as well as those around you when you cast the spell.
If you are in a party, [[spell:29166]] is a great spell to help the healer
conserve mana.

2.3.2.

##### Balance Druid Tier Set Bonus

The Season 2 Midnight Tier Set revolves around Eclipse. The 2-set offers flat 
damage bonuses to both [[spell:78674]] and additional damage to [[spell:191034]] 
through an additional, instant tick on eligible mobs.

The 4-set provides a waxing and waning damage buff within Eclipse which is further 
increased when in both Eclipse states through use of Cooldowns or [[spell:1240206]]. 
This means we will want to be stacking [[spell:202345]] early for Haste but then 
pool as much as we can for the peak of the damage buff.

Mechanically, the set does not offer much difference in playstyle but it does 
further emphasize the spend early, pool late playstyle which has been prevalent for 
Balance Druids in Midnight.

### Balance Druid   Defensive Spells

2.4.

#### Defensive Spells for Balance Druid

[[spell:22812]] is your primary defensive resource. It is a short cooldown
low damage reduction spell, which is often up most times you would need it. In
the class tree, there are several other passives that buff Barkskin, but the most
notable is [[spell:449191]], which further increases the damage reduction.

[[spell:5487]] is the most accessible but most detrimental defensive
resource we have. This increases your Health and is always available for use, but you are unable to use most damaging spells while in Bear Form.

[[spell:319454]] offers a 30-second Health boost if used in [[spell:5487]]. 
This extra Health is not considered a Heal and should be used prior to taking a 
large hit. The buff persists when you swap back into [[spell:24858]]. You can 
also cast this in any caster form to Heal 5-players.

These are the key defensive resources for Balance Druids. There are other
ways to remain safe, including strong passives such as [[spell:377847]]
but those three spells cover the majority of our defensives.

### Balance Druid   Stat Priority

2.5.

#### Stat Priority for Balance Druid

The general stat priority for a Balance
Druid is seen below. This is very much a rough guideline and is
designed for players who do not wish to sim their character. If you are simming
your character, please disregard this stat priority completely and follow your
sim! For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>).

The stat priority for a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen is as follows:

Intellect

Mastery

Haste

Critical Strike

Versatility

The stat priority for a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove is as follows:

Intellect

Mastery

Critical Strike

Haste

Versatility

### Blizzard   Combat Assistant

2.6.

#### Balance Druid Combat Assistant

The new [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) has been added alongside the new One-Button
rotation, which comes with a minor GCD penalty. The Combat Assistant is a good
learning tool and will play at a 10-15% damage loss while the One-Button rotation
will be 15-20% worse than an optimally player-driven rotation.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **17 Aug. 2026:** Updated for Elune's Chose stat preference.
- **10 Aug. 2026:** Updated for Patch 12.1.0
- **15 Jun. 2026:** Updated Heart of the Wild entry.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **17 Mar. 2026:** Updated Talent Recommendations
- **16 Mar. 2026:** Reviewed and Updated for Midnight S1.
- **26 Feb. 2026:** Reviewed and Updated for the Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **11 Aug. 2025:** Updated for tier change and buffs.
- **04 Aug. 2025:** Reviewed for Patch 11.2.0
- **15 Jun. 2025:** Reviewed for Patch 11.1.7
- **21 Apr. 2025:** Reviewed and Updated for Patch 11.1.5
- **24 Feb. 2025:** Reviewed and Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **07 Oct. 2024:** Updated some talent recommendations.
- **09 Sep. 2024:** Updated for Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.0.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **08 May 2023:** Updated for May 9th Hotfixes.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **11 Dec. 2022:** Updated talent choices and some basic info.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Updated talent recommendations.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Balance Druid in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Talents for Balance Druid in Midnight

For Season 2, after a somewhat turbulent first season in Midnight, Balance Druid has
finally settled in the meta and for its rotation, with both Hero Talent builds having
carved out their own distinct niches and strengths. While players needed some time to
really figure out how to play with the new [[spell:1239669]] Our current recommendations are as follows:

- **Single Target -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen is the best single target 
    Talent set for Balance Druid. It offers great sustained DPS and good hybrid damage 
    without sacrificing as much as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove.
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen is better for all-around cleave and pure AoE 
    damage profile. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove can be used in some situations where 
    super quick burst AoE is necessary from Balance Druid or even in lower keys.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen is currently the best overall Hero Talent set for both 
single target and AoE. The damage is consistent and less cooldown reliant than 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove. It is flexible in overall Talent choices having the 
ability to play for pure single target, pure AoE, and even intermittent cleave fights.

**Quick Start Import Codes:**

:::talents Balance Druid Single-Target - Elune's
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLMMMmZZGGzYhlZWmZMmZDDAGbLzMYMbDgJAAAALMzMzgNjZMmBAwMDWGA"
}
```
:::

:::talents Balance Druid AoE - Elune's
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLMMMmZZmFzMjFWmZZMmZsgBAjttZGMmtBwEAAAgFmZmZwmxMGzAAYmBGA"
}
```
:::

:::talents Balance Druid Delves - Keeper
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmlZmZmZDgZZmtZWmxMzGLzYMGzshBADw22YBTzMbDAAAA2MzMzMYzYGjBgZGAYA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Elune's Chosen

Raid/Single-Target

recommended

Mythic+

recommended

Keeper of the Grove

Raid/Single-Target

Mythic+

weekly-keys

Delves

### 天赋方案 0-0

1.1.

#### Single-Target Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

These are the pure single target Talents for for Balance Druid, generally your
Raiding build unless you know there are adds in the encounter.

**You will NOT be able to enter Solar [[spell:1239669]] while playing
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen due to [[spell:429523]].**

### 天赋方案 0-1

1.2.

#### Mythic+ Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

This is our recommended Mythic+ build for most scenarios. It forgoes some of the
burst oriented potential of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove for more sustained damage
output. This is in higher demand this season in Mythic+, so we recommend this
build for most key-levels.

If you notice enemies not living long enough for you to leverage the strong sustained
damage Balance Druid has, with enemies dying before you even finished your proper ramp,
then we recommend swapping to our ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove Mythic+
build instead, which focuses more on burst damage.

### 天赋方案 1-0

1.3.

#### Single-Target Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove

The best pure single target talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove.

### 天赋方案 1-1

1.4.

#### Multi-Target & Mythic+ Talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove

This is our recommended build for lower difficulty Mythic+ and dungeons where enemies
die very quickly, or AoE Fights in Raids. If you played Elune's Chosen and you couldn't
get your full sustained damage going due to mobs dying too fast, then this build is for you!

### 天赋方案 1-2

1.5.

#### Best Delve Talents

This is our recommended build for [Delves](<https://www.icy-veins.com/wow/delves-guide>). It is similar to the
multi-target build but removes group utility spells from the class tree and adds
a single target cooldown for bosses and mini bosses on the specialization tree.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLMMMmZZGGzYhlZWmZMmZDDAGbLzMYMbDgJAAAALMzMzgNjZMmBAwMDWGA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUWX04EZZbpBUYEpzTdFWeeb7j7MyE-UWaBDHXfEKNSmwwADJZYww8grzrYhKj-AAAA-GKOik0AMggBDxC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgxMLzswMzswyMLjxMjNMAYssNzgxsNAmAAAAswMzMwmxMGzAAYmBLDA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUWX04EZZbpBUYEpzTdFWeeb7jbsMK-UWaBDHI+IakMtBSywwBDzLDzjKcijFWA-AAAA-GKOik0AIogBDxC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmlZmZmBMDWmZbGzYGLsMjZmZMzGGAMALbjFMNzsMAAAAYjZmZGsZgxMAmZAgBA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04YZbpBUYEJpzTdFebbck0NWG-UWaDJXfHNSmADFQYYogh15lh5BnYxsR-AAAA-FGQYcgkQpBQQmF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMwDMbzsMWmxMWYZGjxMjFMAYAW2GLYamZZAAAAwmZmHYmBbGzYMDgZGAYA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04EZbpBUYEpzbebTd1NsMW2nU-UWaBDIS+ESo0IZCDbDM0wgh5BnHRgCj-AAAA-FGQYcgkQpBQQmF-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmlZmZmZDgZZmtZWmxM2YZGjxMjNMAYA22GLYamZbAAAAwmZmZmBbGzYMDgZGAYA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUWX04YZbpBUYEJpzbe972mqbYZssU-UWaDJfHNSmADJMMUww8yw8kTsYAixNB-AAAA-FGQYcgkUpBYQmF-
```

:::

### 天赋方案 0-0

For a build that can cleave and cast [[spell:191034]] for burst AoE, use this code:

:::talents Elunes Chosen Cleave Build
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLMMMmZZmFzMjFWmZZMmZsgBAjttZGMmtBwEAAAgFmZmZwmxMGzAAYmBGA"
}
```
:::

### 天赋方案 1-0

For a build that can cleave and cast [[spell:191034]] for burst AoE, use this code:

:::talents Keeper of the Grove Cleave Build
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNjxMDMmlZmZmBMDjZWmZZGzYhlZMmZmxCGAMALbjFMNzsMAAAAYjZmZGsZgxMAmZAgBA"
}
```
:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend you pick the following bonuses, but as you can freely switch between 
them at any time, feel free to experiment with other options yourself if you feel 
you do not get enough mileage out of the recommended options:

- Node 1:[[spell:1279599]]
- Node 2:[[spell:1279603]]
- Node 3:[[spell:1287555]]
- Node 4:[[spell:1279609]]
- Node 5:[[spell:1279614]]

2.

### Apex Talent: ![Ascendant Eclipses Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_eclipse.jpg>) Ascendant Eclipses

Midnight introduces three new Apex Talents for every class which will be earned as 
you level to max. The Balance Druid Apex Talent set is called Ascendant Eclipses.

1. [[spell:1261564]] – Activating an Eclipse makes your next [[spell:5176]] or [[spell:194153]] 
   instant. The first three [[spell:78674]]s or [[spell:191034]]s you cast during each 
   Eclipse deal 20% increased damage.
2. [[spell:1261565]] – Your Critical Strikes dealt during an Eclipse cause their victims to 
   languish for an additional 20% of damage dealt for 8 sec.
3. [[spell:1261566]] – Activating an Eclipse also launches Solar or Lunar Bolts at enemies within 40 yds 
   that always critically strike. [[spell:1261573]] hits one target and [[spell:1263137]] 
   hits three targets and deals splash damage.

There are some small gameplay changes associated with the first Apex Talent, 
[[spell:1261564]]. Firstly, when you are going into cooldowns, you use your 
free instant cast on [[spell:194153]]. Additionally, you want to maximize the usage 
of your buffed spenders in your opener which delays your first cooldown cast.

The second and third Apex Talents are much more passive and do not affect gameplay. 
[[spell:1261565]] does heavily incentivize Critical Strike and ends up 
doing a large portion of our damage. [[spell:1261566]] is a minor damage 
boost at the start of Eclipse. The main gameplay adjustment is just in 
[[spell:1239669]] charge management where you do not want to be sitting on 2-charges 
before going into cooldowns.

3.

### Hero Talents

Upon reaching Level 71, Balance Druid gets to pick between two Hero Talent trees that fill vastly 
different roles, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen. 
The are both competitive and fill in different niches.

3.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove

The benefit of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove is it turns Balance Druid into a 
short cooldown, burst-focused spec. Burst damage is more often required in PvE content 
as the faster something dies, the less likely it is to kill you. Both the pure 
single target and high target count multi-target builds are slightly worse than 
the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen builds. Keeper of the Grove is much more likely to find 
its place somewhere in the middle taking advantage of [[spell:433850]] and 
[[spell:205636]] to do great priority target damage on many encounters that it 
excels on.

3.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen heavily focuses on Arcane spells and [[spell:194153]]. 
It currently has the highest simming single target and mass multi-target builds. When 
it is able to take advantage of these profiles, it is a top-tier caster DPS. 
[[spell:429523]] makes you chain cast Starfire at all times within [[spell:1239669]] 
which can be a bit clunky given its long cast time compared to [[spell:5176]].

4.

### PvP Talents (War Mode)

There will be the option to go into "War Mode."
Enabling War Mode provides the following benefits:

- PvP Talents enabled in the outdoor world.
- 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended enabling the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility of being killed while leveling or doing World Quests
exists.

In this section, we will list the PvP Talents best for leveling and doing
solo / small group PvE content. Note that these may not be optimal in actual
PvP situations.

- [[spell:356517]] is a passive effect that calls down falling stars on
  enemies during [[spell:191034]]. Enemies who run into this take damage and get
  knocked up. Allies can pick these up and run into enemies to detonate them.
- [[spell:209740]] is amazing for group combat and strong for solo
  content. This can buff all members in your party and help finish quests
  and rares faster. We would recommend this for all group content.
- [[spell:305497]] can provide minimal peel or damage in open-world content.
- [[spell:236147]] will let you move at 100% Movement Speed
  even while in combat. Great for open-world content.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **12 Aug. 2026:** Updated best talent recommendations.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Added Omnium Folio talent recommendations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Updated Talent recommendations
- **17 Mar. 2026:** Updated Talent recommendations
- **16 Mar. 2026:** Reviewed and Updated for Midnight S1.
- **26 Feb. 2026:** Reviewed and Updated for the Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **04 Aug. 2025:** Reviewed for Patch 11.2.0
- **15 Jun. 2025:** Reviewed for Patch 11.1.7
- **21 Apr. 2025:** Updated and Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed and Updated for Patch 11.0.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5 talent rework.
- **09 Sep. 2024:** Updated for Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.0.
- **04 Sep. 2023:** Updated for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **21 Dec. 2022:** Updated Starweaver versus Rattle the Stars.
- **11 Dec. 2022:** Updated broken talent links.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Updated talent recommendations.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Balance Druid in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Balance Druid Gameplay and Rotation Guide

Welcome to our Rotation page for Balance Druids. On this page, you will
find everything you need to know about actually playing the spec in Raiding
and Mythic+ scenarios.

By selecting talents and Hero Talents below, the rotations in this guide will
update accordingly.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

Single-Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove

Single-Target with

[[spell:394013]]

Single-Target with

[[spell:391528]]

AoE

Active Talents

Passive Talents

[[spell:205636]]

[[spell:194223]]

[[spell:88747]]

[[spell:468936]]

[[spell:394013]]

[[spell:391528]]

[[spell:202770]]

[[spell:274281]]

[[spell:202430]]

[[spell:383195]]

[[spell:1240262]]

[[spell:327541]]

[[spell:114107]]

[[spell:390378]]

[[spell:468743]]

[[spell:394414]]

[[spell:1240907]]

[[spell:393940]]

[[spell:393954]]

[[spell:394094]]

[[spell:383197]]

[[spell:394121]]

[[spell:393991]]

### Balance Druid Explained

1.1.

#### Basics of Balance Druid

As a Balance Druid, you will be engaging with the [[spell:1239669]] system. You will choose an Eclipse state based on the last filler spell that you cast. [[spell:5176]] will allow you to enter [[spell:326053]] and [[spell:194153]] will allow you to enter [[spell:326055]]. Being inside [[spell:194223]] or [[spell:394013]] will grant you the 
benefits of both Eclipse states.

You will be applying DoTs to all applicable targets, building Astral Power with the [[spell:1239669]] appropriate filler, and then spending that Astral Power to deal a large amount of damage. The basic priority of these actions are as follows:

1. Do not cap Astral Power. You will spend Astral Power even when not inside [[spell:1239669]] if you would otherwise cap.
2. Apply [[spell:93402]] and [[spell:8921]] to your targets. DoTs are efficient damage and interact with many talents
3. Enter [[spell:326053]] when hitting one target with your filler and [[spell:326055]] when hitting multiple targets.
4. Build Astral Power using [[spell:5176]] when in [[spell:326053]] and [[spell:194153]] when in [[spell:326055]].
5. Spend Astral Power on [[spell:78674]] on one target and [[spell:191034]] on multiple targets.

**适用条件：Elune's Chosen（启用）。**

:::details FAQWhy cant I enter [[spell:326053]]?
The

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen

Hero Talent tree has a talent which disables

[[spell:326053]]

called

[[spell:429523]]

. You can still cast

[[spell:5176]]

but will no longer be able to
change

[[spell:1239669]]

types. Your primary filler when using Lunar Calling will be

[[spell:194153]]

as it does increased damage.

:::

### Single-Target Rotation

1.2.

#### Balance Druid Single-Target Priority List

1. Do not cap Astral Power.
2. Apply and maintain [[spell:93402]] and recast before entering [[spell:194223]]/[[spell:394013]].
3. **适用条件：Force of Nature（未启用）。** Apply and maintain [[spell:8921]] and recast before entering [[spell:194223]]/[[spell:394013]].
4. **适用条件：Force of Nature（启用）。** Apply and maintain [[spell:8921]]. [[spell:205636]] will apply it for you when cast.
5. **适用条件：Fury of Elune（启用）。** Cast [[spell:202770]] before entering [[spell:1239669]] or casting [[spell:194223]]/[[spell:394013]].
6. **适用条件：Force of Nature（启用）。** Cast [[spell:205636]] before entering [[spell:1239669]] or casting [[spell:194223]]/[[spell:394013]].
7. **适用条件：Convoke the Spirits（启用）。** Cast [[spell:194223]].
8. **适用条件：Convoke the Spirits（未启用）。** Cast [[spell:394013]].
9. **适用条件：Convoke the Spirits（启用）。** Cast [[spell:391528]] while inside [[spell:194223]] and under 40 Astral Power.
10. **适用条件：Keeper of the Grove（启用）。** Enter [[spell:326053]].
11. **适用条件：Elune's Chosen（启用）。** Enter [[spell:326055]].
12. **适用条件：Starweaver（启用）；Touch the Cosmos（启用）。** Cast [[spell:191034]] if you have a [[spell:393940]] or [[spell:394414]] proc.
13. **适用条件：Starweaver（启用）。** Cast [[spell:78674]] to spend Astral Power or have a [[spell:393940]] proc.
14. **适用条件：Starweaver（未启用）。** Cast [[spell:78674]] to spend Astral Power
15. **适用条件：Keeper of the Grove（启用）。** Cast [[spell:5176]] to generate Astral Power.
16. **适用条件：Elune's Chosen（启用）。** Cast [[spell:194153]] to generate Astral Power.
17. Before leaving any [[spell:1239669]], save Astral Power if you are going to enter Eclipse right or spend your Astral Power if you are going to be waiting outside of Eclipse for several seconds.

### Single-Target Opener

[[spell:5176]]

[[spell:5176]]

**适用条件：Keeper of the Grove（未启用）。**

[[spell:8921]]

[[spell:93402]]

**适用条件：Fury of Elune（启用）。**

[[spell:202770]]

**适用条件：Elune's Chosen（启用）。**

[[spell:326055]]

**适用条件：Elune's Chosen（启用）。**

[[spell:194153]]

**适用条件：Force of Nature（启用）。**

[[spell:205636]]

**适用条件：Convoke the Spirits（启用）；Incarnation: Chosen of Elune（未启用）。**

[[item:249346]]

[[spell:194223]]

[[item:241308]]

**适用条件：Incarnation: Chosen of Elune（启用）；Convoke the Spirits（未启用）。**

[[item:249346]]

[[spell:394013]]

[[item:241308]]

[[spell:194153]]

[[spell:78674]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:78674]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:78674]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:391528]]

1.3.

#### Balance Druid Single-Target Opener Explained

Before combat starts, make sure you are in [[spell:24858]] and have [[spell:1126]] active.

1. At approximately 4-seconds on the pull timer, precast two [[spell:5176]].
2. **适用条件：Elune's Chosen（启用）。** Apply and maintain [[spell:8921]] on the target.
3. **适用条件：Elune's Chosen（启用）。** Apply and maintain [[spell:93402]] on the target.
4. **适用条件：Keeper of the Grove（启用）。** Apply [[spell:93402]] to the target. You will not need to apply [[spell:8921]] as it will be applied by [[spell:205636]]. Maintain both DoTs.
5. **适用条件：Fury of Elune（启用）。** Cast [[spell:202770]].
6. Cast [[spell:326055]].
7. Cast [[spell:194153]].
8. **适用条件：Force of Nature（启用）。** Cast [[spell:205636]].
9. **适用条件：Convoke the Spirits（启用）。** Use your trinkets and potions and cast [[spell:194223]].
10. **适用条件：Convoke the Spirits（未启用）。** Use your trinkets and potions and cast [[spell:394013]].
11. **适用条件：Convoke the Spirits（启用）。** Cast [[spell:78674]] to get below 40 Astral Power.
12. **适用条件：Convoke the Spirits（启用）。** Cast [[spell:391528]].
13. Cast [[spell:194153]] to proc the instant cast [[spell:1261564]] while inside [[spell:194223]]/[[spell:394013]] (if you wont cap Astral Power).
14. **适用条件：Elune's Chosen（未启用）。** Cast [[spell:78674]] to spend Astral Power and [[spell:5176]] to generate it.
15. **适用条件：Elune's Chosen（启用）。** Cast [[spell:78674]] to spend Astral Power and [[spell:194153]] to generate it.

### AoE Rotation

1.4.

#### Balance Druid AoE Priority List

1. Do not cap on Astral Power.
2. **适用条件：Force of Nature（未启用）。** Apply and maintain [[spell:8921]] and recast before entering [[spell:194223]]/[[spell:394013]]. You will cast this as targets are being stacked.
3. **适用条件：Force of Nature（启用）。** Apply and maintain [[spell:8921]]. You will cast this as targets are being collected. [[spell:205636]] will spread Moonfire to 6 unafflicted targets.
4. Apply and maintain [[spell:93402]] and recast before entering [[spell:194223]]/[[spell:394013]]. You will want to wait until multiple targets are stacked if possible.
5. **适用条件：Fury of Elune（启用）。** Cast [[spell:202770]] before entering [[spell:1239669]] or casting [[spell:194223]]/[[spell:394013]].
6. **适用条件：Force of Nature（启用）。** Cast [[spell:205636]] before entering [[spell:1239669]] or casting [[spell:194223]]/[[spell:394013]].
7. **适用条件：Convoke the Spirits（启用）。** Cast [[spell:194223]].
8. **适用条件：Convoke the Spirits（未启用）。** Cast [[spell:394013]].
9. **适用条件：Convoke the Spirits（启用）。** Cast [[spell:391528]] if there are less than 8 targets and you have less than 40 Astral Power.
10. Enter [[spell:326055]].
11. **适用条件：Touch the Cosmos（启用）。** Cast [[spell:191034]] to spend Astral Power or if you have a [[spell:393940]] or [[spell:394414]] proc.
12. **适用条件：Starweaver（启用）。** Cast [[spell:78674]] if there are less than 8 targets and you have a [[spell:393940]] proc.
13. Cast [[spell:194153]] to build Astral Power.
14. Before leaving any [[spell:1239669]], save Astral Power if you are going to enter Eclipse right or spend your Astral Power if you are going to be waiting outside of Eclipse for several seconds.

---

:::details FAQ[[spell:1240262]] or [[spell:327541]]?
This is an interesting choice node early on in the Talent tree.

[[spell:1240262]]

if best used when you are bursting down a medium to large group of enemies in a more periodic fashion. Consider this a burst option for some raid encounters.

[[spell:327541]]

is good for longer duration AoE fights and pulls where your DoTs would have otherwise fallen off or needed to be reapplied once before the targets died.

:::

### AoE Opener

[[spell:5176]]

[[spell:5176]]

[[spell:8921]]

[[spell:93402]]

**适用条件：Fury of Elune（启用）。**

[[spell:202770]]

[[spell:326055]]

[[spell:194153]]

**适用条件：Keeper of the Grove（启用）。**

[[spell:205636]]

**适用条件：Incarnation: Chosen of Elune（未启用）。**

[[item:249346]]

[[spell:194223]]

[[item:241308]]

**适用条件：Incarnation: Chosen of Elune（启用）。**

[[item:249346]]

[[spell:394013]]

[[item:241308]]

[[spell:194153]]

[[spell:191034]]

1.5.

#### Balance Druid AoE Opener Explained

Before combat starts, make sure you are in [[spell:24858]] and have [[spell:1126]] active.

1. At approximately 4-seconds on the pull timer, precast two [[spell:5176]].
2. **适用条件：Elune's Chosen（启用）。** Apply [[spell:8921]] to the targets as they are collected.
3. **适用条件：Keeper of the Grove（启用）。** Apply [[spell:8921]] to targets. [[spell:205636]] will spread Moonfire to 6 unafflicted targets.
4. Apply [[spell:93402]] to the targets when they are collected to reduce excess globals.
5. **适用条件：Fury of Elune（启用）。** Cast [[spell:202770]].
6. Cast [[spell:326055]] if you will cap on charges during your cooldowns.
7. Cast [[spell:194153]] to proc the instant cast [[spell:1261564]] while inside [[spell:194223]]/[[spell:394013]] (if you wont cap Astral Power).
8. **适用条件：Keeper of the Grove（启用）。** Cast [[spell:205636]].
9. **适用条件：Incarnation: Chosen of Elune（未启用）。** Cast [[spell:194223]].
10. **适用条件：Incarnation: Chosen of Elune（启用）。** Cast [[spell:394013]].
11. Cast [[spell:191034]] to spend Astral Power and [[spell:194153]] to generate it.

2.

### Midnight Season 2 Tier Set

- 2-piece Set Bonus: [[spell:78674]] damage increased by 20%. [[spell:191034]] 
  also deals Astral damage instantly to all valid enemies in range when cast.

The 2-piece set bonus is purely numerical. It makes our spenders more powerful. 
One nice bonus is that it does add some minor burst damage to [[spell:191034]].

- 4-piece Set Bonus: Your damage is increased by 10% while in any Eclipse. This 
  bonus wanes to 2% at the midpoint of the Eclipse, then waxes back to 10% at the end.

The 4-set bonus has some gameplay implications but it is further reinforcing the 
standard cycle of the build-and-spend rotation. It does deviate from the previous 
Season as you do want to hold your spenders, if possible for the apex of the damage 
bonus.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Balance Druid 
kit, we have compiled a more detailed explanation on individual parts of our rotation, from
important rotational mechanics that you need to pay attention to, to cooldowns and how to use them, so you can
reach your full potential when playing Balance Druid.

### Utilizing Eclipse

3.1.

#### Utilizing Eclipse

The new [[spell:1239669]] system reduces ramp-up time at the cost of overall uptime.
This is most noticeable in raids, but you will feel this downtime on any fight longer
than two to three minutes.

On average, you can maintain Eclipse, including cooldowns, for 65-75% of the time. 
What matters is having Eclipse when it is needed. Plan your downtimes based on the 
needs of the fight, and avoid capping charges of Eclipse to reach the highest 
achievable uptime. For example, if you know you want to hit a priority target in 
10 seconds, just sit outside Eclipse and generate Astral Power. If your pack in a 
dungeon is close to dying, save your charge.

Additionally you want to consider the types of spells you cast or actions you 
take while inside and outside of Eclipse. While inside Eclipse, your top priority 
should be to spend as much of your Astral Power as possible because it is your 
most effective damage. Spells such as [[spell:78674]] and [[spell:191034]] will 
be the best spells and [[spell:5176]] and [[spell:194153]] are good spells to cast 
while inside Eclipse.

While outside of your Eclipse you want to be casting preparation or maintenance 
spells. Spells that last through your Eclipse state or buff your upcoming abilities. 
The best example is your DoTs, [[spell:8921]] and [[spell:93402]]. These will 
last through Eclipse and since they update with your buffs, you only lose damage on 
their low damage application. You should also use spells that generate Astral 
Power or buff you, such as [[spell:202770]] and [[spell:205636]].

### DoT Break Points

3.2.

#### DoT Break Points

When DoTing targets, you need to factor in the amount of time those DoTs will be 
dealing damage. When a target lives through an entire DoT duration, that single global 
you used to apply the DoT is the most efficient global per damage you can cast. 
However not every target lives the entire 15 to 24 seconds. If a target will only live 
5-6 seconds, you will want to focus on getting as much raw damage into that target 
as possible via your spenders and other abilities, and forgo DoTing that target as it 
would do less damage for that global than say a [[spell:5176]] or [[spell:78674]].

When DoTing targets on AoE, you have to also consider how many globals you will 
be using. If your targets are spread out, you may only want to [[spell:8921]] them 
as it will cleave to ones much further away than [[spell:93402]]. Once the targets 
are grouped, you will want to Sunfire them there, as you can hit every target with 
one global.

When casting [[spell:93402]] you want to ensure that the targets will live at least 
5-seconds. With [[spell:8921]], you want the target to live at least 8-seconds.

### Target Breakpoints

3.3.

#### Target Breakpoints

On **one** target it is best to cast [[spell:78674]] instead of 
[[spell:191034]].

You will sometimes cast [[spell:191034]] on two targets and sometimes on three 
targets. [[spell:191034]] and [[spell:78674]] are generally close on two targets 
but you will always cast Starfall on three targets. Talents play a big factor in 
this choice. As a quick go-to, if you are investing in AoE enough to take 
[[spell:1240907]], you will always cast Starfall on two targets. Same with 
[[spell:393940]] with the exception of if you were playing pure single target 
talents.

If you are taking [[spell:450212]] or [[spell:394046]] 
but not Meteorites when playing [[spell:393954]] you will Starsurge on two 
targets.

Its important to understand that you will generally be taking [[spell:1240907]] 
when you are AoEing so you should not need to memorize all the conditionals.

When choosing which [[spell:1239669]] to enter, you want to know how many targets 
you will be able to hit with your filler spell. If you are able to hit 3-targets 
consistently with [[spell:194153]], you will want to be in Lunar Eclipse. If you are 
not able to, make sure you are in Solar Eclipse and cast [[spell:5176]]. 

If you are specced into ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen, you will always go into 
Lunar Eclipse and always cast [[spell:194153]]. You can open with [[spell:5176]] 
to not early pull the boss.

### Starweaver and Touch the Cosmos

3.4.

#### Starweaver and Touch the Cosmos

With the amount of free spender procs Balance Druid has, it is important to 
understand when to use them and which spells to cast./

When using [[spell:393940]], you are given a free cast of spender opposite of 
what procced it. [[spell:191034]] procs will always be used but on 8 or more targets, 
you will not use [[spell:78674]] procs.

[[spell:393940]] also has differing proc rates for each spender. You are more 
likely to get a [[spell:78674]] proc when you cast [[spell:191034]] than vice 
versa. So when you have a [[spell:394414]] proc while talented into Starweaver, 
you will always cast Starfall.

4.

### Important Cooldowns for Balance Druid

### [[spell:194223]]

4.1.

#### Celestial Alignment

It is important to first note that [[spell:194223]] and 
[[spell:394013]] are both stronger [[spell:1239669]] states and the 
rules stated in the Utilizing Eclipse section apply here as well and even more so 
for the types of spells you cast inside these cooldowns.

The spells themselves provide small stat buffs but the important part is that they 
provide both [[spell:1239669]] state which gives your Astral Damage spells additional 
damage. This includes spenders like [[spell:78674]], procs like 
[[spell:202342]], and cooldowns like [[spell:202770]].

You always want to be overlapping your cooldowns together. With 
[[spell:468743]], two charges of this ability and it allows you to stagger 
their use to line up with other cooldowns such as [[spell:391528]], 
[[spell:205636]], and [[spell:205636]]. The more cooldowns you can stack 
the more potent they become.

### [[spell:205636]]

4.2.

#### Force of Nature

[[spell:205636]] is the primary mechanic of the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove 
Hero Talent tree. Casting [[spell:205636]] often and at the right times will 
boost your damage significantly. By itself, it grants the powerful [[spell:433831]] 
buff which provides on demand burst, a flat 4% damage bonus, and applies 
[[spell:8921]] on up to 8-targets.

You always want to pair [[spell:205636]] with your major cooldown, 
[[spell:194223]] or [[spell:394013]]. If these are on 
cooldown for 45-seconds (or 30-seconds with [[spell:428937]]) you will want 
to pair Force of Nature with your next [[spell:1239669]].

### [[spell:202770]]

4.3.

#### Fury of Elune

[[spell:202770]] can be taken with either Hero Talent choice but is more 
effective and plays differently with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen.

When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove, you are mainly using it for its 
Astral Power generation. As such it is generally something paired with 
[[spell:194223]] and [[spell:205636]] to allow you to spend more 
Astral Power while inside those buff windows. You want to use it before entering 
[[spell:1239669]] or cooldowns because it is not the primary damage driver.

When playing [[spell:202770]] inside ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen, it becomes a 
much more potent ability as it is directly buffed by the primary and capstone 
Hero Talent. Additionally, it has its cooldown significantly reduced by 
[[spell:429539]]. What changes with Elune's Chosen is that you will always 
want to cast it inside your [[spell:1239669]] and you will want to be casting it 
as quickly as it comes up, unless you need to save it for a specific damage window.

### [[spell:391528]]

4.4.

#### Convoke the Spirits

Always try to overlap [[spell:391528]] with
[[spell:194223]] / [[spell:394013]] as well as the
buff from [[spell:394048]].

[[spell:391528]] has a 45-yard range from the center of any target's
hitbox. This means for larger bosses, max range Convoke the Spirits may end up
whiffing all Balance spells if you are too far away.

With [[spell:393991]] talented, melee [[spell:391528]] is
less consistent than ranged Convoke. Avoid being in melee if possible, or you are
more likely to lose a Balance-specific catch. This is a minor point but something
to avoid if possible.

If you are using [[spell:391528]] on multiple targets, cast Convoke
before casting other [[spell:191034]]s to raise the chance that you will cast
a free Starfall.

4.5.

#### Defensive Utility

All Druids have some innate tankiness from their Class Talent Tree. We receive 
more healing, take less flat damage and less damage from some physical spells. We 
also have access to several passive heals that proc under varying circumstances.

- [[spell:22812]] is your primary defensive resource. It is a short cooldown
  low damage reduction spell, which is often up most times you would need it. In
  the class tree, there are several other passives that buff Barkskin, but the most
  notable is [[spell:449191]], which further increases the damage reduction.
- [[spell:5487]] is the most accessible but most detrimental defensive
  resource we have. This increases your Health and is always available for use, but you 
  are unable to use most damaging spells while in Bear Form.
- [[spell:319454]] offers a 30-second Health boost if used in [[spell:5487]]. 
  This extra Health is not considered a Heal and should be used prior to taking a 
  large hit. The buff persists when you swap back into [[spell:24858]]. You can 
  also cast this in any caster form to Heal 5-players.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **12 Aug. 2026:** Updated Stellar Amplification mention.
- **10 Aug. 2026:** Reviewed for Patch 12.1.0
- **15 Jun. 2026:** Reformatted Mechanics and Tips section.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Added in context for the rotation in FAQ blocks and further expansions on Gameplay mechanics.
- **17 Mar. 2026:** Updated rotation to remove Starweaver mentions.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch
- **30 Nov. 2025:** Added FAQ block.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **30 Aug. 2025:** Added Keeper of the Grave Opener with new Tier set.
- **04 Aug. 2025:** Reviewed for Patch 11.2.0
- **15 Jun. 2025:** Reviewed for Patch 11.1.7
- **21 Apr. 2025:** Updated and Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed and Updated for Patch 11.0.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for new tier set in Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **08 Dec. 2023:** Updated mention of Rattle the Stars buff.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **08 May 2023:** Updated with May 9th Hotfixes.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Updated some sections to maintain consistency. Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **11 Dec. 2022:** Updated for T29 Tier Set.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Updated talent recommendations.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Balance Druid in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Balance Druid

Welcome to our Gear and BiS Page for Balance Druid for
Midnight Season 2! Check this page to learn everything you need to know to make your 
character as powerful as they can be!

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the best overall items for Balance Druid using all available content including the newly released [Sporefall](<https://www.icy-veins.com/wow/midnight-season-1-raid-guide>) raid. This is gear to chase towards but will not include gear that can not be reliably obtained, such as some gear from the Weekly Vault.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Season 2 you will want to try and prioritize getting the

**Helmet, Gloves, Chest, and Legs**

set pieces. Completing the bonus is more important than getting the perfect items so take whatever you can get. In the long term, you will want to get the Elevated item level items from

[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

and

[Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

. The Catalyst will also retain the effect of special items such as

[[item:271875]]

.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2 you also retain the secondary stats and any other potential passive effects like damage and stat procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear. Some optimal stat items to catalyze are:

- Helmet: [[item:271875]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:268246]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Chest: [[item:239048]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Gloves: [[item:159312]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Legs: [[item:268225]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details TipsWhich Items Do I want the most from all content?
Here are some of the items worth bonus rolling or taking from your Vault if you see them at an appropriate item level.

- [[item:271092]]: Our best weapon. It drops from the final boss of the raid at an elevated item level. There is no weapon that could be better.
- [[item:273796]]: Our best on-use trinket from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>).
- [[item:281215]]: Our best raid encounter passive trinket.

:::

:::details FAQHow Strong is the Tier Set?
The Balance Druid Midnight Season 2 Tier set is extremely powerful. On single target, the 2-piece is approximately 6%-7% DPS and the 4-piece is 11%-13% DPS. The Tier set is even stronger on multi-target with the extra burst damage it adds to

[[spell:191034]]

.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:268246@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:268240@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAIAAwt1ENMMYDH2A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup with farmable gear from Midnight Season 2 Mythic+ Dungeons.

This list is by no means a replacement for **simming yourself**. Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 as a Balance Druid, you will want to try and prioritize getting the

**Helmet, Gloves, Chest, and Legs**

set pieces. Completing the bonus is more important than getting the perfect items so take whatever you can get. In the long term, you will want to get the Elevated item level items from

[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

and

[Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

. The Catalyst will also retain the effect of special items such as

[[item:271875]]

.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2 you also retain the secondary stats and any other potential passive effects like damage and stat procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear. Some optimal stat items to catalyze are:

- Helmet: [[item:159318]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Shoulders: [[item:251223]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Chest: [[item:239048]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Gloves: [[item:159312]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Legs: [[item:251130]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): This dungeon has our best on-use trinket, [[item:273796]].
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): Drops a good passive trinket in the [[item:250224]] and a decent weapon but the raid items will be better.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:159301@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:251223@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:251183@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Trinket</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAACAAAMyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAIAAwt1ENMMYDH2A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup, using raid gear alongside recommended crafted items in Midnight Season 2.

This list is by no means a replacement for **simming yourself**. Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 as a Balance Druid, you will want to try and prioritize getting the

**Helmet, Gloves, Chest, and Legs**

set pieces. Completing the bonus is more important than getting the perfect items so take whatever you can get. In the long term, you will want to get the Elevated item level items from

[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

and

[Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

. The Catalyst will also retain the effect of special items such as

[[item:271875]]

.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2 you also retain the secondary stats and any other potential passive effects like damage and stat procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear. Some optimal stat items to catalyze are:

- Helmet: [[item:271875]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:268246]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Chest: Base Tier item from the tier token is better.
- Gloves: [[item:268234]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- Legs: [[item:268225]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:271092]]: Our best weapon. It drops from the final boss of the raid at an elevated item level.
- [[item:281215]]: Our best raid encounter passive trinket.
- Venomcursed items such as [[item:268265]] and [[item:271875]]. They offer the same amount of secondary stats as other items as well as additional Critical Strike and Haste procs.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:268246@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270169@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:268240@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/balance-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAIAAwt1ENMMYDH2A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Balance Druid

There are many usable trinkets for Balance Druid in Midnight Season 2. The two 
best overall options are [[item:273796]] for an on-use choice and 
[[item:281215]] for our passive trinket option.

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Balance Druid Trinkets**
**On-Use -**

[[item:273796]]

or, alternatively,

[[item:250215]]

**Passive -**

[[item:281215]]

is our primary passive trinket from the new raid.

:::

There are quite a few other valuable trinkets out there, so make sure to click on our
  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Balance Druid Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Best Balance Druid Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:270167]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:270169]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270170]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250224]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:270161]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273794]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:158368]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Patch 12.1 continues the bonus roll system that was initially introduced in Patch
12.0.7. Notably, bonus rolling on a Heroic raid boss will grant you the item at 1/6 Myth
track, so you can acquire some of the later raid gear quite early, as long as you commit
additional crests to upgrade it.

**[Nebulous Voidcores](<https://www.wowhead.com/currency=3418>)** can be spent after finishing a dungeon or killing
a raid boss, and will grant you a random from the dungeon's or boss's loot table.
Once an item has been looted through a Voidcore roll, it cannot appear again when you
bonus roll on the same boss or dungeon again.

After 8 weeks, you will also be granted one additional Voidcore for free from
**Orin Straylight** in Silvermoon, next to The Catalyst. This happens with the launch of
Patch 12.1.5.

3.1.

#### Recommended Nebulous Voidcore Usage for Balance Druid

Which item you want to chase after depends heavily on the items you have already acquired
  through content such as the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), or whether you expect to down certain bosses on
  your highest achievable difficulty, as you do not want to waste your Voidcores on items you may be able to
  get on a higher difficulty track in a few weeks.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [[item:271092]]
2. [[item:268265]]
3. [[item:281215]]
4. [[item:271875]]
5. Replace low item level, high stat budget pieces where possible, preferably elevated items from the final 2 raid bosses.

:::

[[item:271092]] fully upgraded is your handsdown best item to 
coin from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), only replaced by the same item at a higher item level or 
a massive item level gap increase. Both [[item:271875]] and 
[[item:268265]] are great adds from the same boss making it worthwhile to 
coin.

As always, we recommend using Raidbots to sim your character and see which bosses 
have the best item to roll.

3.2.

#### Ascendant Venomstones

[[item:280562]] allow you to increase the item level of Weapons, 
Offhands, Necks and Trinkets by 6, up to a maximum item level of 340 for non-crafted 
gear and 337 for crafted gear. You cannot upgrade items that are already 344 item 
level.

As with Crests, you should prioritize upgrading items that provide the largest DPS 
increase. For Balance Druid, we recommend the following order:

1. Your Mainhand Weapon
2. Your on-use Trinket
3. Your passive Trinket
4. Your Offhand, if you are not using a Staff

Generally, you should prioritize upgrading Myth-track items over Hero-track items, 
particularly if you expect to replace the Hero-track version relatively soon. 
Upgrading a Hero-track item is still a reasonable choice if you do not expect to 
obtain its Myth-track equivalent in the near future.

Ultimately, the best item to upgrade depends on your current gear and progression. 
We recommend saving your Venomstones for items you expect to keep for a while rather 
than spending them on pieces you are likely to replace.

4.

### Best Crafted Items for Balance Druid

You can have two Embellishments which are special effects attached to crafted 
items. What you craft depends entirely on which encounters you are able to defeat.

For the competitive Heroic and Mythic Raider, you should follow this crafting 
order:

1. [[item:245769]] is an off-hand which can use weapon embellishments such 
   as [[item:273060]]. Pair this with [[item:271092]] or 
   [[item:268203]] at Mythic item levels.
2. If you are stuck with a Heroic weapon and need the power boost, you should then 
   craft a Main-hand weapon with a second embellishment and replace this later on when 
   you get a [[item:271092]].
3. If you have two embellishments, it is often best to hold the third craft for when 
   you do not need crests. As a third craft, you should craft **Boots, Gloves, or 
   Shoulders** with [[item:240167]] (if possible) to replace your lowest 
   item level piece that is not reliant as a tier slot.

If getting a Mythic item level weapon is not possible from the raid or you need 
an immediate power boost, consider crafting [[item:245770]] instead (make sure it is the
Int staff!).

We recommend crafting your items with [[item:219823]], but if you
want to fully min-max for another half percent or so, you should use Raidbots to sim your
character first in case a different secondary stat combination is better for you.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Balance Druid

Early on, crafting a main-hand and off-hand paired with [[item:273060]] can 
be an easily obtainable DPS boost. The embellishment is powerful and usable on both 
items allowing you to stack the power early to carry you through most Mythic content.

[[item:240167]] is a good embellishment for non-weapon embellishments. 
The amount of stats provided scales with the stat-budget on the item so crafting on 
an item with higher stats is actually preferred in this situation. In this raid, 
you will be targeting mid-budget items such as boots, gloves, and shoulders depending 
on what other items you have.

As always, it is recommended to sim yourself to see what would be best with your 
gear situation.

Late in the tier when you have full sockets on your Helm, Bracers, and Belt as 
well as the double socket on [[item:268265]], you can consider simming 
[[item:251513]].

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

1. Weapon and Trinkets often provide the best value for each item level
2. Helm, Chest, and Legs have the highest stat bonuses
3. Shoulders, Boots, Gloves, and Belt have medium stat bonuses
4. Cloak and Bracers have the lowest stat bonuses
5. Jewelry is the lowest priority as it does not have primary stats

As always, it is recommended to sim yourself to see what would be best with your 
gear situation.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for patch 12.1.5
- **17 Aug. 2026:** Updated crafted and embellishment sections.
- **10 Aug. 2026:** Updated for Patch 12.1.0
- **15 Jun. 2026:** Updated for Sporefall release.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Updated trinket recommendations.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Puzzling Cartel Chip release and D.I.S.C nerf.
- **11 Aug. 2025:** Updated for tier set changes and trinket sims.
- **04 Aug. 2025:** Reviewed for Patch 11.2.0
- **21 Jun. 2025:** Updated for Charged Bolts Nerf.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7
- **16 Mar. 2025:** Added in some additional trinket notes.
- **03 Mar. 2025:** Updated Best in Slot list for Liberation of Undermine and Season 2.
- **24 Feb. 2025:** Reviewed and Updated for Patch 11.0.1.
- **15 Dec. 2024:** Updated for the Cyrce's Circlet release of 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **07 Oct. 2024:** Updated raid trinket recommendations.
- **09 Sep. 2024:** Updated for Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6. Updated mentions of Blue Silken Linen.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **08 Dec. 2023:** Updated some trinket recommendations relating to Balefire Branch.
- **07 Nov. 2023:** Updated with recent Sporecloak nerfs.
- **06 Nov. 2023:** Updated for Patch 10.2.0.
- **04 Sep. 2023:** Updated for Patch 10.1.5.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **08 May 2023:** Updated for May 9th Patch Changes.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7. .
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **21 Dec. 2022:** Updated embellishments and expanded trinket recommendations.
- **11 Dec. 2022:** Updated for Vault of the Incarnates and Season 1 Mythic +.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Balance Druid. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Balance Druid Stat Priority

The stat priority for a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen is as follows:

Intellect

Mastery

Haste

Critical Strike

Versatility

The stat priority for a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove is as follows:

Intellect

Mastery

Critical Strike

Haste

Versatility

Mastery is the best stat for both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen and 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove. Mastery provides a damage boost for Nature and Arcane 
spells which double-dips with Astral damage abilities such as [[spell:78674]]. 
Critical Strike is great with [[spell:1261565]] which applies a DoT based 
on any damage you deal inside an Eclipse. Haste is a good all-around stat, and is 
particularly useful for Elune's Chosen to make [[spell:194153]]s long cast a little
more manageable.

:::details FAQIs There a Haste Cap for Balance Druid?
There are no Haste caps for Balance Druids. All damage-over-time effects
scale dynamically with your Haste and other stats. There are in general, no break
points for any secondary stats but there are diminishing returns.

:::

2.

### In-Depth Stat Breakdown

The Stat Priority is a fluid entity. Every piece of gear you equip, socket you
add to your gear, and every piece you swap, affects your stat priority. If you
neglect a stat too much, its priority will rise higher and higher until it
overtakes other stats. If the stat is lower on the above general priority, it
will generally not take too much of the stat to drop it back down quickly.

Often, you may sim your gear and see Mastery is low or Critical Strike
is high or any other stat for that matter. You change one or two pieces or even
an enchantment and may see wildly different results. Use [Top Gear](<https://www.icy-veins.com/wow/how-to-use-the-top-gear-feature-of-raidbots>) on [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) to
get a more accurate depiction of how upgrades will fit into your character-specific gear.

**Intellect** is your primary stat. You should look for this stat in all
of your upgrades. It provides you with Spell Power, which increases the damage
of your spells.

**Mastery** increases the damage your Nature and Arcane spells do to targets. This 
is further increased when afflicted by [[spell:93402]] or [[spell:8921]] 
respectively.

**Haste** increases your casting speed and your Astral Power generation
(as a result of you being able to cast more spells).

**Critical Strike** increases your chance to critically hit with all
spells and abilities. This stat has an element of randomness, meaning that it
may not always be as effective as other stats or may be more effective than
other stats on a fight-by-fight basis.

**Versatility** increases all your damage and healing done and decreases
all damage taken. This stat can be undervalued while doing more difficult
content, as the damage reduction is not factored into most decisions. When doing
raid progression, high Mythic+, or any other hard-hitting content, consider
valuing Versatility higher.

2.1.

#### Item Level

Intellect is strong enough to make item level a good indicator of an upgrade. 
If you have two pieces of gear at the same item level, and one has Mastery and 
the other does not, you can make an informed decision that the piece is at 
least pretty good. You can still quickly and easily sim yourself for the most 
accurate results.

2.1.1.

##### Jewelry

This means less for rings and necks as they do not have Intellect. Lower 
item-level jewelry can be much better than a higher item-level piece just by 
having better stats.

2.1.2.

##### Sockets

There is not a hard number of item levels that can be assigned to a socket 
on a piece of gear, as it depends on the type of gear and type of gem you are 
using in that slot. When picking between similar items of different item 
levels and one has a socket, it is best to sim the answer than to approximate.

2.2.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **17 Aug. 2026:** Updated for Elune's Chose stat preference.
- **10 Aug. 2026:** Reviewed for Patch 12.1.0
- **15 Jun. 2026:** Updated stat priority recommedations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed and Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch
- **30 Nov. 2025:** Added in FAQ block.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **04 Aug. 2025:** Reviewed for Patch 11.2.0
- **15 Jun. 2025:** Reviewed for Patch 11.1.7
- **21 Apr. 2025:** Updated and Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed and Updated for Patch 11.0.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **07 Oct. 2024:** Made consistent with other Stat mentions.
- **09 Sep. 2024:** Reviewed for Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.0.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** No changes required for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Added jewelry and item level notes.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Balance Druid, based on your [stat priority](<https://www.icy-veins.com/wow/balance-druid-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

2.

### Best Gems for Balance Druid

You should use [[item:240983]] in one socket, and a combination
of Mastery and Haste gems should be socketed into your remaining sockets. While
there are some edge-cases where other gems might be slightly more valuable, you cannot go
wrong with this setup.

When comparing gems while simming, we recommend testing these different variants to see
if you want to deviate from the standard Mastery+Haste recommendations:

- Sapphire Gem - [[item:240917]]
- Emerald Gem - [[item:240892]]
- Ruby Gem - [[item:240908]]
- Onyx Gem - [[item:240900]]

3.

### Best Enchants and Weapon Augments

The best weapon enhancement/oil is [[item:243733]], and you will want
to apply it to your weapon in all content.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Helmet</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240133]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</tr></table>

:::details FAQWhich Tertiary Stats do I want?
Speed, Leech, and Avoidance all have their specific applications. Assuming they
offer the same quantity of stats, the type of tertiary is largely a personal
preference. There are specific mechanic types that influence each type especially if
you have the gold to freely swap:

- Leech is best against Heal absorbs and DoT damage.
- Avoidance is best against pulsing damage and large hits.
- Speed is a good default tertiary if you are not familiar with the mechanics
  	but is almost never mandatory to complete any type of encounter.

:::

4.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

4.1.

#### Flask

The default flask for most situations is [[item:241322]]. Depending 
on your gear set, you could also use [[item:241325]] if you have plenty 
of Mastery.

4.2.

#### Potions

The best DPS potion is [[item:241288]]. Depending on your gear, 
[[item:241308]] may be better. Considering how close they are in power, you 
do want to sim yourself to determine the best option.

During encounters, you can heal yourself using
[[item:271883]] and [[item:5512]]. Make sure you use
these when in danger of dying.

4.3.

#### Food Buff

[[item:255846]] or [[item:255845]] should
be used in raid or dungeons if possible. Otherwise, [[item:242275]]
offers main stat but no stamina, making it a great choice for all content. The
feast heavily outperforms other food options.

4.4.

#### Augment Rune

For close progression pulls or for pushing your damage, you can also use a
[[item:259085]]s.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated weapon enchant recommendation.
- **17 Aug. 2026:** Updated consumable recommendations.
- **10 Aug. 2026:** Updated for Patch 12.1.0
- **15 Jun. 2026:** Updated ring enchant recommendations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Removed Tea mention and added context to tertiary stats.
- **16 Mar. 2026:** Reviewed and Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **04 Aug. 2025:** Reviewed for Patch 11.2.0
- **15 Jun. 2025:** Reviewed for Patch 11.1.7
- **21 Apr. 2025:** Reviewed and Updated for Patch 11.1.5
- **24 Feb. 2025:** Reviewed and Updated for Patch 11.0.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **07 Oct. 2024:** Updated some consumable recommendations.
- **09 Sep. 2024:** Reviewed for Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.0.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Moved Primordial Stone recommendations to bottom of the page.
- **20 Mar. 2023:** Updated Phial recommendations and Primordial Stones.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **21 Dec. 2022:** Added notes for Neck consumable.
- **11 Dec. 2022:** Updated for Vault of the Incarnates and Season 1 Mythic +.
- **11 Dec. 2022:** Updated personal food choice.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Balance Druid in World of Warcraft Patch 12.1.5.

1.

### Balance Druid in Mythic+ in Midnight Season 2

Balance Druid is a strong ranged contender for higher-level Mythic+. While it
does come with ramp-up, making it worse for lower-level content, once the pull is
in full swing, [[spell:191034]] and [[spell:194153]] are unparalleled in their
uncapped multi-target damage.

In addition to our good throughput at higher key levels, we have a large
utility toolkit.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our dedicated Mythic+ page below. You can also find
out more about the Mythic+ Meta on our Tier List page.

2.

### Best Mythic+ Talent Builds

### Elune's Chosen

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen Mythic+ Build

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen build focuses on sustained throughput which caps out
at a higher end than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove. It can be harder to use in lower
keys (this could vary based on level of group play).

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgxMLzswMzswyMLjxMjNMAYssNzgxsNAmAAAAswMzMwmxMGzAAYmBLDA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUWX04EZZbpBUYEpzTdFWeeb7jbsMK-UWaBDHI+IakMtBSywwBDzLDzjKcijFWA-AAAA-GKOik0AIogBDxC-
```

:::

### Keeper of the Grove

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove Mythic+ Build

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove build focuses on doing quick bursts of damage
at the start of the pull utilizing [[spell:205636]] buffs such as
[[spell:428544]] and [[spell:433831]]. It is a bit easier to play than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen,
and thus the recommended build when not pushing high-keys.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CYGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgZbmlxyMmZWYZGjxMjFMAYAW2GLYamZZAAAAwmZmHYmBbGzYMDgZGAYA"
}
```
:::

:::details 来源计算器编码
```
#mB-LLPnNOUUWX04EZbpBUYEpzbebTd1NsMW2nU-UWaBDIS+ESo0IZCDbDM0wgh5BnHxCjO-AAAA-FGQYcgkQpBQQmF-
```

:::

3.

### In-Depth Rotation Tips for Mythic+

One of the most important things to do in Mythic+ is to pool your Astral
Power
towards the end of every trash pull to reduce the ramp-up time needed to reach
your maximum output. Being able to get directly into your rotation pack-to-pack
is extraordinarily helpful when bursting down priority targets.

Use all of your cooldowns liberally. Treat the whole time you are in the dungeon as
though it were a raid encounter. You never lose uses in raid if you can help it, and you should work to do the same in Dungeons. Exceptions are the occasional
massive pull or important DPS race boss.

With [[spell:468743]], it is important to keep one charge on cooldown
at almost all times to maximize usage in the key.

3.1.

#### Elune's Chosen Tips

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen Hero Talent build focuses on Arcane-based spells such as
[[spell:194153]] and [[spell:202770]]. Starfire is your primary damage
dealer with talents such as [[spell:383195]] and 
[[spell:114107]] adding several multipliers of damage to our
primary filler spell.

Focus on ramping into each pack quickly by applying your DoTs and then
stack [[spell:202345]] with [[spell:191034]].

[[spell:429539]] paired with [[spell:394121]] allows you to have
[[spell:202770]] up every pack and sometimes multiple times each pack. Use
these smaller cooldowns as they come up, with the exception of if a pack is going
to die before the end of the effect.

3.2.

#### Keeper of the Grove Tips

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove does quick burst damage and also has shorter ramp times
to get into the standard DPS rotation. [[spell:428544]] allows you
to focus on applying [[spell:93402]] and then go right into Eclipse or cooldowns.
This means you can [[spell:93402]] into [[spell:205636]] and then
[[spell:390378]] a pack for massive damage.

[[spell:434249]] gives some flexibility to your main cooldowns,
allowing you not feel the need to use each one as it comes up and but as each
feels best to use. Sometimes holding a cooldown at the end of one pack, will
let you get off two uses in the next pack.

4.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

4.1.

#### Interrupts

[[spell:78675]] interrupts spell casts and prevents spells from the
same school from being cast again for 4 seconds. Solar Beam also acts as a blanket 
silence ability, silencing all crowd controllable targets for the entire 8 seconds 
they remain in the beam. You can choose to use a focus macro for this ability but 
given the long cooldown on this spell, you may not need one.

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Solar Beam
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

4.2.

#### Stunning and "Stops"

[[spell:132469]] is an iconic Balance Druid spell. This will knock
enemies in front of you away in the direction the cast was aimed. Use this to
knock enemies away from the tank, yourself, or away from special mob-specific
mechanics.

[[spell:102793]] is another group of crowd control that can assist in
kiting mobs. Additionally, this works great against mobs that leap, oftentimes 
negating damage. It can be combined with [[spell:132469]] to act as either an 
emergency stop or stacking method.

[[spell:99]] can be used to stop a group of enemies from
casting. This can interrupt non spell casts that could not ordinarily be silenced.

[[spell:339]] can be used to root patrols or crowd control immune
packs. In those packs, the main target can normally be rooted, allowing you to
handle the leftovers more easily. Additionally, some bosses have adds that it 
can be advantageous to root.

[[spell:102359]] can root a group of enemies. It can sometimes be used
in niche strategies for bosses.

[[spell:33786]] can be used to block healing, as a last-resort interrupt,
or block the application of dangerous enemy buffs.

### Other Utility

4.3.

#### Other Utility

[[spell:2908]] will dispel all enrage buffs applied to enemies.

[[spell:2782]] will dispel Curses and Poisons.

[[spell:29166]] is best used on heavy group damage boss encounters.
This will allow you to expand your healer's Mana pool and allow them to extend
the duration of the encounter if needed.

[[spell:106898]] provides some additional mobility for skips or just
to get through the dungeon faster.

[[spell:319454]] can provide valuable healing, especially on
[Tyrannical](<https://www.wowhead.com/mythic-affix=9>) bosses with constant damage.

5.

### Dealing with Affixes

This section contains quick tips to deal with each of the weekly Xalatath-themed
affixes in Mythic+

### Affix: Ascendant

5.1.

#### Ascendant Affix Management for Balance Druid

**Xalatath's Bargain: Ascendant** will periodically spawn a number or orbs in
waves that need to be crowd-controlled in some way, before they complete a cast.
Each orb successfully stopped provides the group bonus Haste.

Balance Druid can wait for all of the orbs to spawn and then cast 
[[spell:99]]. This will generally interrupt all orbs. [[spell:132469]] 
can also be used but be careful not to knock mobs into bad positions.

### Affix: Voidbound

5.2.

#### Voidbound Affix Management for Balance Druid

**Xalatath's Bargain: Voidbound** will periodically summon a large Void
Emissary that will begin to cast [[spell:462508]]. This enemy **must** be
killed before the cast completes to stop it, otherwise it provides significant
damage reduction to nearby enemies. If successfully stopped, the group is granted
a large amount of Versatility and cooldown reduction.

This should be focused down at top priority whenever it spawns. Freely use your 
cooldowns like [[spell:194223]], [[spell:205636]], and 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) Elune's Chosen on this mob as it will recharge them faster after the 
add is killed.

### Affix: Pulsar

5.3.

#### Pulsar Affix Management for Balance Druid

**Xalatath's Bargain: Pulsar** spawns an orb that orbits each player, which
needs to be soaked by a separate player before they expire. Each orb will grant
the party 4% Mastery and 2% Leech, stacking, with a 30-second duration. Unsoaked
orbs will increase nearby enemies' damage done, and reduce their damage taken.

There is no Balance Druid specific tip for this mechanic. As a ranged caster, you 
can sometimes extend the timer by standing out and popping the orb later as each 
application also refreshes the buff duration.

### Affix: Devour

5.4.

#### Devour Affix Management for Balance Druid

**Xalatath's Bargain: Devour** applies a debuff to each party member, that
must be either dispelled or healed off (though bear in mind this <em>does not</em>
absorb incoming heals). Each debuff dispelled provides the group with maximum
health and Critical Strike, stacking, for 30 seconds. Any debuffs <em>not</em>
cleared will heal nearby enemies a large amount.

As a caster with [[spell:2782]], you should always be able to dispel 
yourself or someone else.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **12 Aug. 2026:** Fixed Meteor Storm recommendation.
- **10 Aug. 2026:** Updated for Patch 12.1.0
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Updated talent recommendations.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **04 Aug. 2025:** Reviewed for Patch 11.2.0
- **15 Jun. 2025:** Reviewed for Patch 11.1.7
- **21 Apr. 2025:** Updated and Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed and Updated for Patch 11.0.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5 talent rework.
- **07 Oct. 2024:** Added additional affix notes.
- **09 Sep. 2024:** Updated for Season 1.
- **19 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6. Adjusted talent recommendations.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.0.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **08 May 2023:** New Mythic Plus Season launch.
- **01 May 2023:** Updated for new talents in Patch 10.1.0.
- **20 Mar. 2023:** Updated some builds and clarified Starweaver and Rattle the Stars viability.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **21 Dec. 2022:** Added some notes on Orbital Strike and Pulsar.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Updated talent recommendations.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Balance Druid in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Balance Druids, and Druids in general, have some pretty good macros you can use
to smooth out your gameplay or speed up using your utility in a hectic moment.

1.1.

#### Generic Macros for Druids

1.1.1.

##### Rebirth

#### Rebirth Macro

```wow-macro
#showtooltip Rebirth
/cast [@mouseover,help]Rebirth;Rebirth
```

This macro casts [[spell:20484]] on your mouseover target, if they are a
friendly player. Otherwise, it casts Rebirth on your current target.

1.1.2.

##### Remove Corruption

#### Remove Corruption Macro

```wow-macro
#showtooltip Remove Corruption
/cast [target=mouseover,help,nodead][target=target] Remove Corruption
```

Using this macro will cast [[spell:2782]] on your mouseover
target, if they are a friendly player and they are not dead. Otherwise, it
will cast Remove Corruption.

1.2.

#### Specific Macros for Balance Druids

This macro can be pressed twice to enter [[spell:5487]] and then cast 
[[spell:319454]] to give you extra Health for 30-seconds. You can then cast 
to leave form if you have [[spell:449193]] talented or swap back to [[spell:24858]] 
normally.

#### Moonkin Form Toggle

```wow-macro
#showtooltip Heart of the Wild
/cast [nostance:1] Bear Form
/cast Heart of the Wild
```

This macro will place you in Moonkin Form, but now lets you double press and 
leave Moonkin Form. You may need a Keybind to return to human form, depending on 
what you need to cast.

#### Moonkin Form Toggle

```wow-macro
#showtooltip
/cancelform [nostance:4]
/dismount [nostance:4]
/cast [nostance:4] Moonkin Form
```

When using [[spell:391528]], you want to immediately start casting
after the channel is complete to minimize downtime. Use this addon so you can
still spam your next spell. I just used [[spell:78674]] as an example.

#### No-Channeling Starsurge

```wow-macro
/stopmacro [channeling:Convoke the Spirits]
/cast Starsurge
```

The macro below can be altered given any extra off GCD abilities.

#### Celestial Alignment + Trinket

```wow-macro
#showtooltip Celestial Alignment
/use [Insert trinket name here]
/cast Berserking
/cast Celestial Alignment
```

Here are some of the utility-driven mouseover macros you can use.

#### Mouseover Innervate

```wow-macro
#showtooltip Innervate
/cast [@mouseover,exists] Innervate
```

#### Mouseover Soothe

```wow-macro
#showtooltip Soothe
/cast [@mouseover,harm,nodead][] Soothe
```

#### Mouseover Hibernate

```wow-macro
#showtooltip Hibernate
/cast [@mouseover,harm,nodead][] Hibernate
```

#### Mouseover Cyclone

```wow-macro
#showtooltip Cyclone
/cast [@mouseover,harm,nodead][] Cyclone
```

#### Mouseover Rebirth

```wow-macro
#showtooltip Rebirth
/cast [@mouseover,exists] Rebirth
```

At cursor macros save you an extra click and place certain spells at your
cursor.

#### Cursor Force of Nature

```wow-macro
#showtooltip Force of Nature
/cast [@cursor] Force of Nature
```

#### Cursor Ursol's Vortex

```wow-macro
#showtooltip Ursol's Vortex
/cast [@cursor] Ursol's Vortex
```

#### Cursor Celestial Alignment

```wow-macro
#showtooltip Celestial Alignment
/cast [@cursor] Celestial Alignment
```

The next two macros are good for multi-dotting new targets using their unit
frames without swapping off of your main target.

#### Mouseover Moonfire

```wow-macro
#showtooltip Moonfire
/cast [@mouseover,harm,nodead][@target,harm,nodead]Moonfire
```

#### Mouseover Sunfire

```wow-macro
#showtooltip Sunfire
/cast [@mouseover,harm,nodead][@target,harm,nodead]Sunfire
```

2.

### Best Addons

2.1.

#### Generic Addons for Druids

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.5.

#### Specific Addons for Balance Druids

We have no specific recommendations for addons for the Midnight expansion. What is 
important is that you have a way to track your buffs and abilities closely. You can 
do this using the in-game cooldown tracker.

You should keep track of your Astral Power, Eclipse and [[spell:194223]] 
buffs, and your DoTs on the target. You should also track any cooldowns or buffs 
that you need. Often times it is best to track these in the lower center of your 
screen between yours and your target's Health bars but you should do what is most 
comfortable and natural for you.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Added Heart of the Wild macro.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7
- **21 Apr. 2025:** Updated and Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
