## 专精概览

欢迎阅读我们的 浩劫 恶魔猎手 指南，适用于《魔兽世界》12.1.5 版本。在这里，你将学习如何在团队副本和大秘境中扮演 浩劫 恶魔猎手：从入门到最大化你的 DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

浩劫 大秘境资源

[全新！顶尖 浩劫 天赋构筑](<https://raider.io/specs/havoc-demon-hunter/talents>)

[顶尖 浩劫 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/demon-hunter/havoc>)

[浩劫 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=demon-hunter--havoc>)

[热门 浩劫 团队配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=demon-hunter--havoc>)

1.

### 浩劫 恶魔猎手 概览

浩劫 是 恶魔猎手 的近战输出专精，通过混合无情的物理攻击与邪能魔法来造成伤害，并在战场上轻松自如地移动。

其玩法高度围绕经典的 <em>资源积累与消耗</em> 资源循环展开，使用 狂怒，并混合多种短时间、高强度的爆发冷却技能。游戏节奏非常快，奖励良好的技能排序，并拥有最好的机动性工具包之一。作为 恶魔猎手，它还能为团队提供[[spell:255260]]减益效果。

1.

### 浩劫 恶魔猎手 表现分析

与任何专精一样，浩劫 也有一些优势和劣势。下面我们根据一些关键类别对其进行了评估。

**高爆发与理想的伤害类型**

浩劫 拥有高价值的伤害类型，可以根据需要在不同风格之间切换。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者 提供单体集中伤害（漏斗伤害），这通常是最理想的伤害类型之一，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 则提供纯粹的爆发和 AoE 能力。虽然第 2 赛季在一定程度上限制了在保持完整单体伤害的同时构建 AoE 的完全灵活性，但在混合搭配专精时，其妥协程度仍低于许多其他专精。

**灵活且坚韧**

毒液深渊拥有多种非典型的战斗风格，需要应对各种不同的伤害类型。浩劫拥有足够的手段来调整其伤害以适应任何战斗，同时也具备应对它们所需的机动性和防御能力。对 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者在本赛季的改进意味着两棵英雄天赋树在整个团队副本中都能发挥作用，各有其专长。除此之外，它还带来了[[spell:196718]]作为团队防御冷却技能，以及[[spell:255260]]这一关键的团队减益效果。

**高伤害与防御**

第二赛季改变了浩劫的伤害分布，但它仍然保持着强大的爆发性范围伤害， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄。同样，第二赛季对
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者的改进，加上持续的增益，使其崭露头角，通过[[spell:442806]]使其在高层大秘境中成为强大的优先目标伤害专家。能够根据队伍配置或地下城需求在两种风格之间切换并做出实质性贡献，使得浩劫成为一个可靠的全能选择。

**广泛的工具与良好的控制**

浩劫的实用工具相当扎实，提供了一系列无论面对何种战斗都有其用途的技能——特别是恶魔猎手团队增益[[spell:255260]]。凭借[[spell:179057]]、[[spell:207684]]和[[spell:217832]]提供的控制、[[spell:196718]]提供的团队防御工具，以及出色的机动性，浩劫通常能够提供 <em>东西</em>。虽然这些工具都不是特别独特，但能够广泛覆盖大多数团队需求本身就是一种优势。

**强大的防御与续航手段**

至暗之夜改进了浩劫本就扎实的防御工具，并延续到了第二赛季，使其成为较为耐打的近战选择之一。拥有两层[[spell:198589]]（提供35%减伤，1分钟充能一次）、生命值低于35%时通过[[spell:205411]]提供的被动防御，以及[[spell:204909]]提供的吸血，浩劫几乎不需要惧怕任何机制。

**卓越的机动性**

行动自由是浩劫的关键卖点之一，因此它自然是现有最机动的近战专精之一。[[spell:344865]]在低冷却下提供瞬间位移，而[[spell:198793]]则作为备用位移手段。再加上通过[[spell:320654]]精通转换提供的高额被动移动速度，以及通过[[spell:131347]]重置动量的能力（现在还通过[[spell:1266493]]提供额外的按需移动），你在战斗中几乎不会为跟上移动需求而发愁。

1.

### 浩劫 恶魔猎手在至暗之夜中

### **第2赛季**   改动

3.1.

#### 至暗之夜 12.1.5版本内容指南

虽然12.1.5补丁没有给浩劫本身带来重大变化，但如果你错过了的话，它在整个第二赛季中确实接受了大量的调整。该补丁还带来了新的终局PvE内容供你深入体验。团队副本可以挑战 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
这一全新的单体首领战，以获取强大的战利品，同时 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)
推出了首个超级大秘境迷宫供你探索！请务必查看下方关于这两项新增内容的详细信息。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

3.2.

#### 12.1.5版本改动

主要改动将来自基斯提克斯团队副本战斗的新物品。最值得注意的是一个饰品、一个戒指和一件胸甲。此外，你将能够从 10 月 20 日起使用[[item:280562]]升级物品。武器、项链和饰品都可以升级。

3.3.

#### 职业改动

尽管12.1.5补丁的发布对浩劫没有任何改动，但在补丁发布前的几周里，有一次重大的在线修复大幅提升了
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者。以下说明来自9月22日，但其重要性足以让我们为错过它的人保留高亮：

[职业调整即将到来 - 9月22日](<https://eu.forums.blizzard.com/en/wow/t/class-tuning-incoming-22-september/629804>)

**浩劫 恶魔猎手**

<em>开发者说明：奥达奇收割者在它可用的两个专精中，都远远落后于其他英雄天赋选项。我们正在提升其对两个专精的核心效果，而对于浩劫来说，特别是破碎之魂的灵魂碎片生成量将增加，以小幅提升狂怒的生成并加快收割者战刃及其加成的循环。</em>

- [[spell:442290]]使强化攻击的伤害提高15%（原为10%）和30%（原为20%）。
- [[spell:442294]]伤害提高25%。
- [[spell:442624]]使你对目标造成的伤害提高7%（原为6%）。
- [[spell:1272143]]击碎灵魂碎片的概率提高至20%（原为15%）。

这些改动在补丁发布前就已经生效两周了，并且使 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者在许多团队副本战斗中都能达到最佳选择。虽然在一些缺乏即时爆发的战斗中，这种玩法需要更多的操作，但其纯粹的输出能力和集火能力使其非常适合许多战斗。它也被证明是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄在大秘境中的有力竞争者——尤其是在高层大秘境中，集火能力和优先目标伤害变得至关重要。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_specdps.jpg>)点击查看上赛季第二赛季的改动
3.4.

#### 12.1 补丁 浩劫 变更

第2赛季的到来为 浩劫 带来了大量变更，撼动了天赋树的同时也改变了资源经济。

[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**浩劫 恶魔猎手**

<em>开发者笔记：以下对 狂怒 生成的改动是小幅的整体提升，节奏更为平滑，且对献祭光环的天赋效果依赖更少。</em>

- 新天赋：[[spell:427794]] - 生命值高于50%时伤害提高3%，生命值低于50%时吸血提高5%。
- [[spell:427794]] 已被移除。
- [[spell:258881]] 现在立即造成全部伤害，而非在4秒内造成。
- [[spell:390154]] 现在是施加在玩家身上的12秒增益，而非施加在受影响的目标上。
- [[spell:203550]] 现在每点每秒生成 10 点 狂怒（从 15 降低）。
- [[spell:389693]] 已被移至与 [[spell:389687]] 的抉择节点。
- [[spell:427640]] 现在在6秒内使伤害提高12%（此前为5秒内提高18%）。
- [[spell:258920]] 伤害降低8%。
- [[spell:258860]] 初始伤害提高49%。
- [[spell:320374]] 使 [[spell:258920]] 额外生成 30 点 狂怒（从 40 降低）。
- [[spell:203555]] 现在每次命中生成 10-16 点 狂怒（从 8-15 提高）。
- [[spell:188499]]、[[spell:210152]]、[[spell:344862]] 和 [[spell:201427]] 伤害提高6%。
- [[spell:370965]] 伤害提高12%。

这些变更中的许多对此前关键天赋的价值产生了重大影响，同时提供了更多选择，使其在不依赖 [[spell:258920]] 的情况下维持其 狂怒 需求。结合此前的一些变更，这使得
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者 拉近了许多——尤其是在单体目标中——而且两种流派都能根据情况大放异彩。尽管其部分关键手段被削弱， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 依然是强力的选择，能够毫不费力地将其伤害构成适配到所有战斗类型。

:::

### 至暗之夜改动概述

3.5.

#### 浩劫 恶魔猎手 在 至暗之夜 中的变更

至暗之夜 的发布对某些专精带来了大规模的重做，但就 浩劫 而言，它与《地心之战》中构建的核心非常相似。最显著的变更与其 狂怒 生成有关，该生成已被降低，同时还进行了精细的调整以减少一些连招顺序的要求。以下是一些需要注意的关键事项，分为几个部分。

3.5.1.

##### 浩劫 天顶天赋 - 永恒狩猎

至暗之夜 中的职业新特性是天顶天赋，这是强大的4层天赋节点，点出后能提供叠加收益。对于 浩劫，[[spell:1270898]] 侧重于 [[spell:370965]]，将其转变为带有后续效果的更强力冷却技能：

- [[spell:1270898]] — 使 [[spell:370965]] 提高你下一次施放的 [[spell:198013]] 的伤害，并影响更大范围内的敌人。
- [[spell:1270900]] — 有两点，每点使 [[spell:370965]] 的冷却时间缩短15秒，并使其每点击中2个额外的敌人。
- [[spell:1270901]] — 使 [[spell:188499]] 伤害提高20%，并且每当你完整引导 [[spell:198013]] 时，你的下一次刃舞施放将刷新其自身的冷却时间。

这套整体对两个英雄天赋都极为强大，其中 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者 获得更频繁的 [[spell:442294]] 触发，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 通过额外的 [[spell:210152]] 施放进一步强化其 [[spell:213410]] 窗口。这些点数包含在每个配装中，将 [[spell:370965]] 变成强大的连招启动冷却技能，在单体和AoE中都很有用。

3.5.2.

##### 英雄天赋改动

尽管两个英雄天赋树的变更对 浩劫 来说相对温和，但它们尤其受到 狂怒 生成变更的影响。它们在保留伤害构成利基的同时，仍保持相似的游戏流程，以下是一些关键变更：

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) **奥达奇收割者 变更 -** <em>点击查看详情</em>
  
  
  
  
  - [[spell:442686]] 现在提供6%急速，并使你下一次 [[spell:442294]] 的伤害提高30%。
  - [[spell:442806]] 的汇聚效果现在有8个目标的软上限。
  - **三个新天赋：** [[spell:1272143]]、[[spell:1272138]] 和 [[spell:1272153]]。
    
    
    
    
    在两棵树中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者 受到发生的 狂怒 和天赋树变更的负面影响更大。[[spell:390163]] 和 [[spell:204596]]（连同 [[spell:395446]]）已被 [[spell:1266330]] 取代，但这明显减少了稳定的灵魂生成。新的 [[spell:1272143]] 在一定程度上弥补了这一点，尽管其通过 [[spell:442806]] 在高目标数情况下的汇聚强度已被削弱。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) **邪痕枭雄 变更 -** <em>点击查看详情</em>
  
  
  
  
  - [[spell:452402]] 现在造成混沌伤害，随精通属性加成。
  - [[spell:452415]] 每层使 [[spell:452402]] 伤害提高5%，从10%降低。
  - [[spell:452408]] 累积35%的造成伤害，从50%降低，但现在也适用于 [[spell:188499]] 中 [[spell:206416]] 的伤害。
  - **三个新天赋：** [[spell:1272364]]、[[spell:1272405]] 和 [[spell:1272453]]。
    
    
    
    
    另一方面， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 在各方面都获得了生活质量的提升。最重要的是 [[spell:452402]] 被重新加入 浩劫 精通，同时将 [[spell:206416]] 纳入 [[spell:452408]] 效果中。这在很大程度上修复了之前出现的一些循环问题，虽然失去 [[spell:204596]] 确实影响了 [[spell:452415]]，但这棵树相比之前的版本确实得到了改进。

3.5.3.

##### 循环与天赋改动

开始使用 至暗之夜 浩劫 时最明显的变化将是 狂怒 的变更。[[spell:204596]] 和 [[spell:390163]] 均已被移除，[[spell:344859]] 也是如此（[[spell:203555]] 现在变为基础技能，并增强了20%）。再加上 [[spell:232893]] 的生成降低至15，你会发现资源获取更慢，同时也更加被动。

在天赋树上，有些东西发生了变化和移动：

- [[spell:370965]] 和 [[spell:213410]] 现在都在专精树的中心位置。
- [[spell:389693]] 和 [[spell:388112]] 已合并为一个抉择节点。
- [[spell:427775]] 现在是 [[spell:258920]] 的固定冷却缩减，而非重置触发。
- [[spell:258860]] 现在触发固定加成伤害，而非乘数。
- [[spell:342817]] 现在是当 [[spell:188499]] 命中3个或更多敌人时的被动触发，而非主动技能。

这使树上的路径规划更加顺畅，同时也精简了可能妨碍流畅游戏的延长起手连招和AoE随机性连发。

3.5.4.

##### 功能性与防御

在防御方面，浩劫 随着 [[spell:1266307]] 的加入获得了巨大提升。为 [[spell:198589]] 增加第二层充能对生存是巨大的利好，随之而来的专精树节点变更甚至更强。[[spell:205411]] 现在将减伤提高到35%，并在你生命值低于35%时提供10%的减伤。尽管这以额外的闪避几率为代价，但仍显著提升了你的整体耐久度。[[spell:196555]] 也在向 至暗之夜 的过渡中失去了。

在实用技能方面，[[spell:211881]] 被移除，但作为交换 [[spell:179057]] 的昏迷持续时间已增加到3秒。这与新的后续效果 [[spell:1266296]] 搭配，将你当前目标的持续时间增加到5秒。[[spell:1266493]] 也被加入，提高你在滑翔时的移动速度，为本已机动性很强的专精提供更多机动性。

1.

### 浩劫 恶魔猎手 游戏玩法基础

浩劫 拥有一套紧凑的核心技能包，使其易于上手。这通过天赋树得到了极大的扩展，配装多样性也增加了深度。分解为几个关键构建模块，一般流程遵循以下规则：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_chaosstrike.jpg>)
  **积累与消耗 狂怒**
  
  
  
  
  浩劫 的核心循环涉及用 [[spell:203555]] 和 [[spell:232893]] 积累 狂怒，然后将其消耗在 [[spell:188499]] 和 [[spell:344862]] 上。这是该专精的核心支柱。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_eyebeam.jpg>)
  **连招爆发窗口**
  
  
  
  
  浩劫 有许多短冷却的爆发效果，重叠使用效果最佳。[[spell:198013]]、[[spell:258860]] 和 [[spell:198793]] 都会触发强大的增益和减益以供利用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_felscarreddemonhunter_demonsurge.jpg>)
  **最大化英雄天赋树效果**
  
  
  
  
  浩劫 的每个英雄天赋树都增加了一个核心效果。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者 使用 [[spell:442294]] 来触发连招，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 每次 [[spell:191427]] 都会执行一套 [[spell:452402]] 连招。

这些共同充实了 浩劫 的循环，并在你的主要冷却窗口 [[spell:191427]] 期间仍然发挥作用。该专精有许多隐藏的复杂性需要优化，但在底层它遵循一些非常简单易懂的规则。结合其在 [[spell:344865]] 和 [[spell:198793]] 中强大的机动性工具包，该专精在各方面都有着独特的快节奏体验。

1.

### 如何为 浩劫 恶魔猎手 配装

虽然我们始终建议你自行模拟以获得理想结果，但我们确实提供了专门的 浩劫 配装页面。我们目前涵盖第2赛季装备的推荐，以便在踏入终局 至暗之夜 内容时有一个良好的开端。一旦你获得了一些装备，你将需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 为12.1.5补丁和基斯伊克斯的加入更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 为12.1.5补丁更新，将奥达奇调整为推荐以配合第2赛季中期的增益。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月30日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 根据模拟修复后更新了对毒怒之源强度的评估。
- **2026年8月30日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 切换为双哈希之誓——非常接近但更容易融入装备搭配。
- **2026年8月30日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新以将推荐设置为 邪痕枭雄，并默认为团队副本顺劈。
- **2026年8月30日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 由于当前表现，将团队副本中的推荐切换为 邪痕枭雄。
- **2026年8月30日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 更新以将团队副本推荐切换为 邪痕枭雄。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 在装备变更后确认了配装，切换了武器附魔并扩展了关于早期制作优化的常见问题解答。
- **2026年8月24日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 由于项链变更鼓励更多暴击，切换为双贾纳莱的精准。
- **2026年8月19日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 由于阿希尔班圣匣在线修正，添加了关于装备推荐不确定性的免责声明。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已根据12.0.7补丁使用孢子坠落装备进行更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已根据12.0.7补丁使用全知卷册推荐进行更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月24日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手手法以获得更好的连招顺序。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月7日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 添加了关于早期制作以优化破晓冠使用的常见问题解答说明。
- **2026年4月7日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 将戒指附魔推荐调整为鹰眼。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新完整的第1赛季推荐。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已为第1赛季更新——为大秘境增加了茶饮和额外的消耗品。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为第1赛季发布进行更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月16日（本页面）：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 根据 至暗之夜 发布和季前赛进行更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 为 至暗之夜 发布更新，包含复制元素。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（本页）：** 已为至暗之夜的发布进行更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 为11.2.7补丁更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 为11.2.7补丁更新。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为11.2.7补丁更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 为11.2.7补丁更新。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 为11.2.7补丁更新。
- **2025年11月30日（本页面）：** 已为11.2.7版本进行更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已为11.2.5版本更新，并加入了卡特尔代币推荐。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月3日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已更新以强调推荐是基于新套装的。
- **2025年8月28日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 根据当前表现重新整理了饰品排名。
- **2025年8月28日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 添加了大秘境实用天赋速查表，涵盖各副本中的使用场景。
- **2025年8月28日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 改进了循环工具中配装用例的指引。
- **2025年8月28日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 更新以更清晰地突出 邪痕枭雄 在单体目标上的优势。
- **2025年8月14日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 为第3赛季发布的饰品热修更新。
- **2025年8月12日（本页）：** 更新以包含第3赛季发布的增益。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新以纳入D.I.S.C.的热修。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 为11.1.7补丁更新，添加了D.I.S.C.腰带，并为双加里维克斯武器略微调整了毕业列表。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月28日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 由于回响虚空的持续错误，修改了腐蚀推荐。
- **2025年5月12日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已为涡轮加速发布确认迪纳尔推荐。
- **2025年5月12日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已根据腐蚀调整进行更新。
- **2025年5月12日（本页）：** 添加了说明以突出更新后的卡特尔代币和腐蚀推荐。
- **2025年4月28日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 添加了各个副本的提示。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对11.1.5版本进行审查，并添加了卡特尔代币部分。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 为11.1.5补丁审查——由于执行简便，将奥达奇AoE配装移回低移动选项。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 为11.1.5补丁审查——由于执行简便，将奥达奇AoE配装移回低移动选项。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 为11.1.5补丁审查——由于执行简便，将奥达奇AoE配装移回低移动选项。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对正式服的Boss和加里维克斯提示进行更新。
- **2025年3月4日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 调整了一些饰品排名以考虑近期变更。
- **2025年3月4日（[解放安德迈页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 调整了职业树使其更适合团队副本。
- **2025年3月4日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 暂时为 奥达奇收割者 配装添加了惯性。
- **2025年3月4日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 将惯性添加到基础奥达奇AoE配装中。
- **2025年3月4日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 将 奥达奇收割者 AoE转向选择惯性。
- **2025年3月4日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 暂时将移动天赋加回 奥达奇收割者 AoE中。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新以突出热修后新戒指的强度。
- **2024年12月17日（本页）：** 已更新以突出热修后新戒指的强度。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已为11.0.7版本更新，加入希尔赛的项圈。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.7版本进行审查，添加了推荐标签。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.0.7版本进行审查，添加了推荐标签。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对11.0.7版本进行审查，添加了推荐标签。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 为11.0.7补丁更新，基础循环分解更加简单。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 为11.0.5补丁审查，调整了推荐饰品。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 为11.0.5补丁审查，切换为精通推荐。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对11.0.5补丁更新，以区分 邪痕枭雄 和 奥达奇收割者 的权重。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年9月30日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 已更新为所有Boss配上了合适的配装和更新的提示。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新第1赛季毕业列表。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 添加了关于亵渎尖晶石的说明。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 页面已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已为地心之战第1赛季的发布进行更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新以反映新的 邪痕枭雄 推荐。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已更新以反映新的 邪痕枭雄 推荐。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已更新以反映新的 邪痕枭雄 推荐。
- **2024年9月9日（本页）：** 添加了关于套装热修的说明。
- **2024年9月2日（本页）：** 已更新以反映新的 邪痕枭雄 信息。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/havoc-demon-hunter-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/havoc-demon-hunter-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/havoc-demon-hunter-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月13日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 格式调整，将滑块移近循环部分。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 为第4赛季进行了更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 为第4赛季进行了更新。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新以包含第4赛季的配装方案。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已为第4赛季更新，加入新的天赋选择。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 为第4赛季进行了更新。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月21日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 饰品推荐略有调整，但10.2.6补丁的内容保持不变。
- **2024年3月21日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.2.6补丁进行审阅，推荐配装方案调整为战刃风暴，其余无变化。
- **2024年3月21日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.6补丁进行审阅，核心推荐保持不变。
- **2024年3月21日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对10.2.6补丁进行审阅，最强配装方案保持不变，但保留了备选方案。
- **2024年3月21日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（本页）：** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审阅，将 烬魄之灰 列为备选方案。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对10.2.5版本进行审查，无需更改。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5版本进行审查，无需更改。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审阅，添加了暴击即使在收益递减期间依然优秀的说明。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对第3赛季中期的信息进行审阅和调整。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审阅，进行了小幅清理，无需重大更改。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审阅，对AOE最终天赋点的选择进行了小幅推荐清理。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已更新以考虑10.2.5补丁中的法术学派变更。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对10.2.5版本进行审查，无需更改。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2023年12月6日（本页）：** 已更新并加入了12月6日热修的说明。
- **2023 年 11 月 27 日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 将占卜加入理想饰品列表。
- **2023年11月13日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 对T30 AOE配装方案的提示进行了微调，并添加了低移动战的T30单体目标方案。
- **2023年11月9日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已为10.2版本重构并更新。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新以移除孢子披风的推荐，改为推荐蓝色丝线/剧毒荆棘选项。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对10.2补丁进行检查，无需更改。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已更新大秘境中心的链接。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2改版进行了重构和全面更新。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对10.2版本进行更新
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对10.2改版进行更新。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 添加了10.1.7补丁的毕业装备列表并重构了页面。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.1.7补丁进行更新，添加了战刃风暴/怒火配装方案，并将其改为推荐选择。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.7补丁进行审阅，在循环部分添加了配装方案按钮并重构了页面。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对10.1.7补丁进行审阅，将AOE推荐改为战刃风暴/怒火，重构了页面。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新，清理了饰品和专业制造部分，并添加了永恒黎明物品。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审阅，无需更改。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行更新，添加了飘渺虔诚的说明并建议不要使用永恒之戒。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审阅，在单体目标中提升了急速的优先级。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.1.5补丁进行审阅，无需更改。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审阅，进行了小幅调整以提高清晰度，并突出了孤立猎物。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对10.1.5补丁进行更新，添加了单独的部分和不移动配装方案的推荐。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行审阅，无需更改。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行审阅，无需更改。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月25日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 添加了时光漫游部分，清理了原有的饰品推荐。
- **2023年5月15日（本页）：** 添加了关于5月15日增益热修的说明。
- **2023年5月9日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对饰品变更进行更新。
- **2023年5月9日（本页）：** 已更新以指向首领提示和饰品更新。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已为10.1版本和第2赛季的发布更新，加入新的装备推荐。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对10.1补丁进行更新，无需重大更改。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.1补丁进行更新，添加了关于新词缀的详细信息，配装方案保持不变。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1补丁进行更新，添加了锯齿战刃及说明，并添加了额外的精华击破连招说明。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 配装方案已更新以考虑10.1补丁的变更，包括将锯齿战刃作为选项。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已根据10.1补丁天赋改动更新。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对10.1补丁进行审阅，添加了强调精华击破重要性的部分。
- **2023年5月1日（本页）：** 已根据10.1补丁改动更新，添加了新的亮点部分和预期表现。
- **2023年4月29日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已根据10.1补丁审查，无需更改。
- **2023年3月24日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已根据原始宝石的在线修复更新。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已根据原始宝石的在线修复更新。
- **2023年3月22日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已为10.0.7补丁更新。
- **2023年3月22日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新以考虑原始宝石的增益。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已根据原始宝石的增益效果更新。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/havoc-demon-hunter-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对10.0.7补丁进行更新，添加了永恒之戒的信息。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已根据10.0.7补丁审查并更新。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已根据10.0.7补丁审查并更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审阅和清理。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已为10.0.7补丁更新。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.5补丁进行审阅，循环工具已优化。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 已根据10.0.7补丁审查并更新。
- **2023年1月1日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式。
- **2022年12月31日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 武器附魔推荐改为睿智的虔诚。
- **2022年12月31日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 提升了单体目标中精通的优先级。
- **2022年12月31日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 提升了属性优先级中精通的排名。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 更新为装备页面格式。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 修复了格式和热修问题。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月27日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 添加了一个额外的、侧重单体目标的配装方案。
- **2022年10月24日（[升级](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** 已针对巨龙时代进行更新。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/havoc-demon-hunter-best-legendaries-shadowlands>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/havoc-demon-hunter-torghast-guide-and-best-anima-powers>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/havoc-demon-hunter-best-covenants-soulbinds-and-conduits>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[属性页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[大秘境页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[天赋页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** 已针对巨龙时代前夕进行更新。
- **2022年10月24日（本页）：** 已针对巨龙时代前夕进行更新。
- **2022年7月30日（[统御圣所页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** 为第4赛季进行了更新。
- **2022年7月29日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-castle-nathria-raid-guide>)):** 为第4赛季进行了更新。
- **2022年2月19日（[9.2版本分析](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-2-changes-analysis>)):** 已针对9.2补丁发布进行检查。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年11月1日（[统御圣所页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** 已针对9.1.5补丁进行更新，更广泛地将燃焰血脉/恶魔之性视为等同。
- **2021年7月10日（[统御圣所页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** 页面已添加。
- **2021年5月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-1-changes-analysis>)):** 页面已更新，加入盟约传奇。
- **2021年4月27日（[9.1 补丁分析](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2021年1月21日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-castle-nathria-raid-guide>)):** 已针对纳斯利亚堡发布稳定后的最新日志进行更新。
- **2020年12月8日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-castle-nathria-raid-guide>)):** 已针对暗影国度第1赛季发布进行更新。
- **2020年12月1日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-castle-nathria-raid-guide>)):** 添加了纳斯利亚堡的占位页面。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月1日（[风暴熔渣页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 已更新，加入每个首领的详细信息。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019 年 2 月 3 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年9月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** 已根据第1周奥杜尔的观察结果进行更新。
- **2018年9月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** 已更新，加入奥杜尔发布的初步提示。
- **2018年8月9日（[奥杜尔页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** 为最终的奥杜尔发布创建了页面（目前为空）。

显示更多

显示更少

:::

## 练级

在本页面上，您将找到我们的逐级 浩劫 恶魔猎手 练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[恶魔猎手 练级指南](<https://www.icy-veins.com/wow/demon-hunter-leveling-guide>).

1.

### 浩劫 恶魔猎手 练级指南（适用于 至暗之夜）

欢迎阅读我们的 至暗之夜 练级指南。本指南将帮助您作为 浩劫 恶魔猎手 顺利升至满级，涵盖您应该了解的天赋和技能。

浩劫 恶魔猎手 在练级过程中拥有强大的前置AOE爆发能力，适合拉取大量敌人并快速击杀。它还拥有出色的自我恢复能力，这意味着您通常不必担心拉多少怪。凭借这套AOE工具组，它也非常适合地下城，但如果您改用 复仇 去当坦克，排队速度可能会更快。

1.1.

#### 升级装备选择

升级时，物品等级总是比单项属性更重要。始终选择物品等级最高的装备。带有速度副属性的物品可以帮助加快你的升级速度，尤其是在长时间室内活动期间。传家宝装备在升级时也很有用，可以让你在升级旅程的大部分时间里忽略大量配装需求。

1.2.

#### 至暗之夜升级实用消耗品

如果你想获得额外助力来度过至暗之夜的练级过程并追赶满级内容，有一些物品和附魔可以帮助你加快进度。

- [[item:191348]] —— 一瓶药水，来自 [巨龙时代](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  死亡后依然存在，提供30分钟的移动速度加成。如果你装备已经不错，重点往往在于各波怪物之间的移动速度，而不是多一点伤害。
- [[item:225592]] —— 一种食物，来自 [地心之战](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)，提供持续1小时的大量移动速度加成，但死亡后会失去。
- [[item:213746]] —— 如果你的装备插槽足够多，就换上这颗阿格里安钻石，配合每种 [地心之战](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)宝石颜色来获得额外速度。
- [[item:223653]] / [[item:223683]] / [[item:223725]] / [[item:223800]] —— 如果你之前使用的是闪避或吸血附魔，请将所有护甲附魔换成额外的移动速度效果。
- [[item:132516]] —— 练级时经久不衰的选择，在无法骑马的区域总能派上用场，甚至在水面上也能使用。这些 <em>无法</em> 在战斗中激活，并且在受到伤害时会被取消。
- [[item:154168]] / [[item:154169]] — 这些来自争霸艾泽拉斯的消耗品可以帮助应对任何涉及下水的区域——尽管在 至暗之夜 的区域中这种情况并不常见。

1.

### 升级天赋

**等级 1–9：**与许多职业不同，您从8级开始，并在马顿开始 恶魔猎手 的初始战役。随着您推进这段剧情，一些技能将被解锁，当您在10级选择专精时，即可获得核心的 浩劫 技能。

**等级 10 起：**

在10级时，您将解锁 [[spell:198793]]，这是一个额外的移动工具，可与 [[spell:344865]] 搭配使用。您的第一个职业树点数是 [[spell:232893]]，用于产生 狂怒，而您的第一个专精树点数是 [[spell:198013]]——一个强大的爆发性AOE冷却技能。

只要脱离战斗，您可以在世界任何地方更改天赋。在练级过程中，请务必随意尝试各种天赋组合，以熟悉游戏的节奏。我们在下面提供了一个示例练级路线，在您的旅程中逐步介绍核心的 浩劫 概念。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 浩劫 练级 - 80级起始天赋
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmwMDAAAAAAY2MGmxYwMDmZmx2Y2YWGwsZGY2QjZmxwGAAAAAAAAzMYAAAAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmwMDAAAAAAY2mxwMGDmZwMzM2GzGzyAbzmZMMbMNmZGDbAAAAAAAAMzwMAAAAM"
}
```
:::

:::details 来源计算器编码
```
#BJ-iNEVUSgKkIIWZKAqpdc055tYmaIMONhddhC-PIJXgOhEtOqqMCEGoaaAm0IJHJ44y2F-AAAA-ZaWUMCEekYAISB-
```

:::

**等级 20 起：**2.1.

#### **等级 20 起：**升级用战争模式天赋

**等级 20 起：**在本部分中，我们将对练级以及单人或小队PVE内容中的PVP天赋进行排名。以下是通用PVP天赋和 浩劫 恶魔猎手 专属PVE天赋的排名。

1. [[spell:213480]] 就是免费的 狂怒 生成，因为您在野外总会受到伤害。
2. [[spell:206803]] 可以在保证安全的同时帮助应对危险的敌人，尽管它不如直接使用技能那么强力。
3. [[spell:355995]] 可以提供少量额外的治疗和灵魂碎片生成

**等级 20 起：**[[spell:205604]]、[[spell:205596]]、[[spell:357419]]、[[spell:205625]]、[[spell:205630]] 和 [[spell:354489]] 在PVE中的用途都非常有限。这些更侧重于控制工具，或者迫使敌方玩家消耗比他们原本想要更多的资源，因此在野外并没有什么实际用途。

1.

### 升级循环

为了帮助你了解升级和天赋树进程中的变化，请使用下方的滑块选择你当前的等级。每次升级时，将滑块移动，本节内容也会随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 71 起：**达到71级并解锁英雄天赋后，我们建议使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 用 [[spell:452402]] 强化您的 [[spell:191427]]。

3.1.

#### 核心概念

随着您升级并填充天赋树，您将获得额外的工具来探索世界，而不仅仅局限于循环。本部分将随滑块的每一级同步增长。

- **记得恢复！** - 每当你在波次之间生命值较低时，可以使用所有职业都有的[[spell:1231418]]技能来快速恢复。
- **等级 1–9：****善用您的移动能力！** - 浩劫 可以使用 [[spell:344865]]，让您能够快速跨越距离以保持战斗状态。
- **等级 10 起：****善用您的移动能力！** - 浩劫 可以使用 [[spell:344865]] 和 [[spell:198793]]，为您提供两种在目标之间快速跳跃的方式。
- **等级 1–27：****利用您的治疗能力** - 浩劫 通过击杀敌人产生的 [[spell:178940]] 球体来治疗。
- **等级 28 起：****利用您的治疗能力** - 浩劫 通过击杀敌人产生的 [[spell:178940]] 球体来治疗。[[spell:204909]] 还能提供大量的吸血（尤其是在 [[spell:191427]] 期间），所以尽情拉怪吧！
- **等级 18–69：****记住您的防御手段** - [[spell:198589]] 是一个强大的防御技能，请经常使用！
- **等级 70 起：****记住您的防御手段** - [[spell:198589]] 是一个强大的防御技能，甚至有两层充能，所以要经常使用它！

**等级 10 起：**3.2.

#### **等级 10 起：**动态优先级列表

以下是需要关注使用哪些技能的优先级列表示例：

1. **等级 56 起：**尽可能频繁地施放 [[spell:370965]]（尤其是对抗强力敌人时）。
2. **等级 10 起：**施放 [[spell:232893]] 来接近目标
3. **等级 75 起：**在处于 [[spell:191427]] 状态时施放 [[spell:452487]] / [[spell:452497]]。
4. **等级 20–50：**尽可能频繁地使用 [[spell:191427]]（尤其是对抗强力敌人时）。
5. **等级 11 起：**冷却完毕就施放 [[spell:198013]]。
6. **等级 15 起：**冷却完毕就施放 [[spell:188499]] / [[spell:210152]]。
7. **等级 14 起：**冷却完毕就施放 [[spell:258920]]。
8. **等级 51 起：**当 [[spell:198013]] 和 [[spell:188499]] 都在冷却时，尽可能频繁地使用 [[spell:191427]]（尤其是对抗强力敌人时）。
9. **等级 12–14：**对抗多个敌人时，冷却完毕就施放 [[spell:188499]]。
10. **等级 8 起：**每当拥有足够的 狂怒 时，施放 [[spell:344862]] / [[spell:201427]]。
11. **等级 10 起：**施放 [[spell:232893]] 来产生 狂怒。
12. **等级 16 起：**当你需要从远处拉怪时，施放 [[spell:185123]]。

**等级 10 起：**3.2.

#### **等级 10 起：**生存工具

**等级 10 起：**浩劫 习惯于拉到大量怪物并陷入危险境地，但幸运的是，它自带多种工具来帮助应对这种情况：

- **等级 10 起：**击杀敌人时会产生 [[spell:178940]]，按生命值的一定百分比进行治疗。
- **等级 10 起：**如果你发现自己被困住或陷入危险境地，[[spell:344865]] 的冲刺和 [[spell:198793]] 几乎总能让你脱身。
- **等级 18 起：**[[spell:198589]] 持续时间长、冷却时间短，所以如果你感到不安全，尽管使用它。
- **等级 24 起：**如果你陷入糟糕的境地，[[spell:179057]] 会为你提供一个紧急的范围眩晕。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月13日：** 格式调整，将滑块移近循环部分。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月22日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已针对巨龙时代进行更新。

显示更多

显示更少

:::

## 快速入门

在本页面中，我们将解释如何在魔兽世界 12.1.5 补丁中轻松游玩 恶魔猎手 的 浩劫，使用最简单的循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能。

1.

### 恶魔猎手 浩劫 基础知识

欢迎来到我们的简易模式页面！本部分面向刚接触游戏或职业的玩家，他们没有参与史诗难度团队副本的打算，只想了解该专精的简明玩法，而不需要最优玩法所需的大量优先级细节。

浩劫 的循环在核心上相对简单，但被天赋树极大地扩展了。它几乎完全被公共冷却时间（GCD）锁定，因此遵循常见的近战原则：
**永远在按技能**。需要记住的三条简单规则涵盖了其核心要点：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_chaosstrike.jpg>) **积累与消耗 狂怒**
  
  
  
  
  你的进攻资源。它通过自动攻击配合 [[spell:203555]]、[[spell:232893]] 和 [[spell:258920]] 来积累。大多数技能都需要它，例如 [[spell:188499]]（冷却完毕就施放）和 [[spell:344862]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_eyebeam.jpg>) **利用爆发窗口**
  
  
  
  
  浩劫 拥有带后续连招的冷却窗口。[[spell:198013]] 触发 [[spell:213410]]，每 20 秒冷却完毕就施放，随后通过 [[spell:1270901]] 施放两次 [[spell:210152]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_metamorphasisdps.jpg>) **使用大冷却技能**
  
  
  
  
  [[spell:191427]] 每 2 分钟重置 [[spell:188499]] 和 [[spell:198013]] 的冷却时间，所以在施放它之前先用掉这两个技能。[[spell:370965]] 应该冷却完毕就施放，以强化眼棱。

学习 浩劫 的关键在于理解 狂怒 的节奏并规划你的冷却循环。最好从感受它积累资源的速度开始，并培养何时需要保留一些资源以避免耗尽的直觉。一旦你掌握了这一点，就熟悉你的冷却时机并学习它们的使用顺序。

虽然之前我们在本页面上使用的是低移动战选项，但第 2 赛季向 [[spell:206476]] 的转变使标准构建更容易执行。虽然在我们指南的其他地方我们推荐使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者 进行团队副本战斗，但为了上手这个专精，我们将坚持使用
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄。它的操作简单得多，更灵活，而且在所有类型的终局内容中对失误的惩罚也更轻。

1.

### 至暗之夜 中 恶魔猎手 浩劫 新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 团队副本构建

2.1.

#### 恶魔猎手 浩劫 团队副本/单体目标天赋构建

在剧毒深渊中，浩劫 的两个英雄天赋树各有其优势，但是
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 凭借其前置爆发，能够根据情况调整其伤害构成，这使得上手时更容易施展。它围绕着你 [[spell:213410]] 窗口的威力构建，通过 [[spell:452402]] 额外造成范围伤害爆发。

它拥有 20 秒的爆发循环，使用 [[spell:198013]] 和 [[spell:258887]]。每分钟，[[spell:370965]] 会进一步强化你的眼棱，而 [[spell:191427]] 则每 2 分钟提供一段猛烈的爆发期，附带额外的 [[spell:452402]]。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMzMmJjZGAAAAAAwsZMbzMGDmZsMzYGmZMmlB2mFzYY2YaMzMG2AAAAAAAAYmBDAAAAD"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUiEKSVWBJLQQSY688OO00GNTFMmmw4C2C-PXgiIJOWAHNSUeGRm044IJ3CFIMQ0MC-AAAA-BeERhphowYJQwA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 地下城与宝库构建

2.2.

#### 恶魔猎手 浩劫 地下城/范围伤害天赋构建

在范围伤害和地下城内容中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 提供了频繁且有效的爆发工具，无论目标数量多少都能造成可观的总体伤害。拥有其大部分单体目标工具的好处是无价的，而每 20 秒通过施放 [[spell:198013]] 触发 [[spell:452402]] 带来的爆发使其很容易规划。

其游戏风格相当直接，奖励你合理地冷却完毕就使用 [[spell:198013]] 并高效地使用 狂怒。范围伤害战斗也更侧重于 [[spell:258920]] 来对周围造成脉冲伤害。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJOhACEGOoqqsMkiMpxxRSWSsNC-AAAA-BeERhphowYJQ4A-
```

:::

### 单体与范围输出循环详解

2.3.

#### 恶魔猎手 浩劫 新手 DPS 循环

凡提到 [[spell:344862]] 之处，这也同样适用于 [[spell:191427]] 期间的 [[spell:201427]]。[[spell:188499]] 和 [[spell:210152]] 也是同理。浩劫 没有需要施加给队伍的增益效果，也不需要在进入战斗前做任何准备。它随时准备就绪！

2.4.

#### 单体输出详解

浩劫 的单体目标循环由积累和消耗 狂怒 来驱动其技能。管理好这一点是需要学习的最重要的技巧。以下是入门时关键步骤的简要分解：

- **产生与消耗 狂怒**
  
  
  
  
  你的自动攻击通过 [[spell:203555]] 产生资源，而 [[spell:232893]] / [[spell:258920]] 在施放时产生资源。
  
  
  
  
  <em>始终</em> 冷却完毕就施放 [[spell:188499]]，否则将资源消耗在 [[spell:344862]] 上。
- **斩杀 你的连招**
  
  
  
  
  每 20 秒施放一次 [[spell:198013]]，随后使用 [[spell:1270901]] 施放两次 [[spell:210152]]。
  
  
  
  
  穿着套装时，冷却完毕就施放 [[spell:258860]]。
- **使用大冷却技能**
  
  
  
  
  每 2 分钟施放一次 [[spell:191427]]——确保 [[spell:188499]] 和 [[spell:198013]] 都已进入冷却。
  
  
  
  
  每分钟冷却完毕就施放一次 [[spell:370965]]。
- **消耗你的恶魔涌动**
  
  
  
  
  每次施放 [[spell:198013]] 后都应接上 [[spell:201427]] 和 [[spell:210152]]。
  
  
  
  
  你的 [[spell:191427]] 施放也会将此效果延伸到 [[spell:452487]] 和 [[spell:452497]]。

刚开始时，最好将各个步骤拆分开来，以适应游戏流程。我们建议按以下顺序重点关注掌握每一件事。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_specdps.jpg>) **浩劫 单体目标**
**狂怒 管理**

➜

**[[spell:198013]] 与 [[spell:452402]] 的使用**

➜

**连招与冷却技能**

:::

2.5.

#### 范围输出详解

浩劫 在范围伤害战斗中的玩法几乎完全相同，只是增加了更多 [[spell:258920]] 的施放，因为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 使用了 [[spell:427775]]。以下是其变化的详细说明：

- **优先使用刃舞**
  
  
  
  
  保留一份 狂怒 储备，以保持 [[spell:188499]] / [[spell:210152]] 的冷却循环。
- **保持献祭光环的冷却循环**
  
  
  
  
  你绝不希望在拥有 [[spell:427775]] 时 [[spell:258920]] 达到 2 层充能。
  
  
  
  
  在施放 [[spell:191427]] 之前消耗掉所有充能。

谈到范围伤害，很多核心原则都可以通过练习单体目标来学习。我们建议按以下顺序重点关注：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_specdps.jpg>) **浩劫 范围伤害**
**学习单体目标**

➜

**[[spell:452402]] 的使用**

➜

**[[spell:258920]] 优先级**

:::

2.5.1.

##### 巅峰天赋：永恒狩猎

所有构建都在巅峰天赋 [[spell:1270898]] 中投入四点，它将 [[spell:370965]] 变成一个每分钟使用的强力冷却技能。每次施放后接上一个强化的 [[spell:198013]]，然后利用 [[spell:1270901]] 提供的重置效果连续施放 [[spell:210152]]。

2.5.2.

##### 第2赛季套装

至暗之夜第2赛季引入了 **深渊末日猎犬的追击**，可在不同的终局内容中获得。它提供以下加成：

- [[spell:1296611]] —— [[spell:188499]]、[[spell:344862]] 和 [[spell:258860]] 造成的伤害提高 12%。
- [[spell:1296612]] —— [[spell:258860]] 现在会施加并受益于 [[spell:258887]] 的效果，初始打击伤害提高 35%，持续时间延长 2 秒。

这两项加成都使 [[spell:258860]] 成为必点天赋，冷却完毕就使用它来触发额外伤害。虽然我们在主页面上介绍了一些优化技巧， [循环页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)但基本原则就是点出该天赋并冷却完毕就使用它。

### 生存工具与   **防御法术**

2.6.

#### 恶魔猎手 浩劫 的防御法术

浩劫 可以使用几种不同的主动和被动防御工具，在战斗中提供坚实的生存能力和自我续航。浩劫 通常被认为相当耐打，在单人或组队内容中都很出色。

**[[spell:198589]] -** 提供持续 10 秒的 25% 伤害减免，冷却时间为 1 分钟，并且通过 [[spell:1266307]] 拥有两层充能。这是 浩劫 最稳定的防御工具，由于其低冷却时间和额外充能，应大量使用来抵消受到的伤害。

**[[spell:205411]] -** 进一步将 [[spell:198589]] 的伤害减免提高到 35%。此外，在生命值低于 35% 时，始终将受到的所有伤害降低 10%，提供一些额外的耐久度。

**[[spell:427776]] -** 在 [[spell:188499]] 的施法动画期间，提供一个相当于你最大生命值 15% 的吸收护盾。如果时机把握得当，这是减轻伤害的额外方式，可以让你在致命机制中存活下来，但由于该技能通常冷却完毕就施放，掌握好时机可能会有些困难。

**[[spell:196718]] -** 为你和附近的盟友提供 15% 的几率（在团队副本队伍之外提高到 30%）在 8 秒内免疫所受攻击的伤害。这可能极其强大，但最好用于应对频繁的伤害，而不是指望它来避免致命伤害。

**[[spell:191427]] -** 在施法动画期间，你会短暂地免疫所有伤害和效果 1 秒。在罕见的情况下，这可以用来避开危险的机制。

**自我治疗 -** 虽然不是主动防御工具，但 浩劫 通过 [[spell:204909]] 内置了吸血能力。这在任何时候都提供固定的 10%，在 [[spell:191427]] 期间额外提供 10%。除此之外，[[spell:206478]] 和敌人死亡通常会触发灵魂碎片，在战斗中提供治疗。

**![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者 -** 可以使用 [[spell:442714]]，它使 [[spell:232893]] 在施放时将受到的伤害降低 10%，持续 5 秒。由于邪能之刃需要用于产生 狂怒，该效果的覆盖率不稳定且难以规划，但它提供了一些额外的防御。

### 装备选择与   **属性优先级**

2.7.

#### 恶魔猎手 浩劫 属性优先级

浩劫 的属性优先级相当直接，如下所示。有关本页面呈现内容的更多信息，请查看我们的主页面 [属性优先级页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>).

敏捷

暴击

精通

急速

全能

属性优先级可能会根据所选的其他天赋或不同的战斗类型而变化，但这应该涵盖大多数情况。

2.8.

#### 为 恶魔猎手 浩劫 配装

谈到 至暗之夜 第 2 赛季的配装，你希望尽快优先获取你的套装，而制作一件武器是开局就能获得大量实力的快速方式。由于角色配装有太多不同的选择，最好跳转到我们的主页面 [装备页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)
以获取关于需要追求哪些装备的更全面解析。

### 暴风雪循环助手

2.9.

#### 暴风雪 为 恶魔猎手 浩劫 提供的循环助手

循环助手工具由暴风雪在《地心之战》中推出，有两种模式：第一种会以推荐优先级高亮动作条按钮，第二种则提供单个快捷键，自动按下该列表中优先级最高的技能，但每次施放之间有25%的公共冷却时间惩罚。

对于浩劫而言，它独特地受到该工具推荐功能限制的严重影响， <em>非</em> 而且在至暗之夜中这一点仍未改变。除了主动使用饰品、种族技能和主要冷却技能外，任何会位移你角色的浩劫技能都将 **绝对不要** 不会被列入优先级推荐中。这包括：

- **冷却技能 -** [[spell:191427]], [[spell:370965]].
- **移动/位移技能 -** [[spell:232893]], [[spell:344865]], [[spell:198793]].

如果你点了与之相关的天赋，所有这些技能都需要手动使用。这同样适用于防御技能和控制技能。

由于[[spell:232893]]被排除在外，浩劫在维持资源需求方面更加吃力，循环经常被打断。虽然它仍然可以使用，但你仍需要在战斗中手动插入这些施放，才能真正充分利用它。

虽然在许多情况下，该工具对于上手一个全新专精相当好用，但不幸的是，在浩劫这里它受到了严重影响，并不能真正执行它需要执行的操作。我们强烈建议避免使用该工具来游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者，而是坚持使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄流派。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月30日：** 更新以将团队副本推荐切换为 邪痕枭雄。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月3日：** 已更新以强调推荐是基于新套装的。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年4月21日：** 为11.1.5补丁审查——由于执行简便，将奥达奇AoE配装移回低移动选项。
- **2025年3月4日：** 暂时将移动天赋加回 奥达奇收割者 AoE中。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为11.0.7补丁更新，基础循环分解更加简单。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已更新以反映新的 邪痕枭雄 推荐。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，无需更改。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行审阅，无需更改。
- **2023年5月1日：** 已针对10.1补丁进行审阅，添加了强调精华击破重要性的部分。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月31日：** 提升了属性优先级中精通的排名。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已针对巨龙时代前夕进行更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到魔兽世界12.1.5补丁中你的浩劫恶魔猎手的最佳天赋。我们还为团队副本或大秘境等不同类型的玩法提供了默认天赋配置。如果你开启了战争模式，我们也为你提供了PvP天赋方案。

1.

### 浩劫 恶魔猎手在至暗之夜中的最佳天赋

在至暗之夜中，浩劫的天赋树进行了一些重构，第2赛季放宽了一些选择，使得配装要求不再那么严格。它仍然需要比以前更加专精，但拥有一些不错的工具，尤其是顶级天赋——[[spell:1270898]]——将[[spell:370965]]巩固为一个强大的1分钟冷却技能。

- **团队副本 –**
  两棵英雄天赋树都能在团队副本中发挥作用，但 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者在多次加强后拥有更高的上限。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 不过邪痕枭雄在顺劈战斗中依然非常强力，所以两者都可以玩。
- **大秘境 –**
  类似地，两棵英雄天赋树都很强力，各有不同的专精方向。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄擅长整体的原始总输出，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者则是在更高层数中作为优先目标专精的存在。

第2赛季的上线带来了大量调整，试图拉近两棵英雄天赋树之间的差距，但 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者需要后续加强才能达到那个水平。现在到了12.1.5补丁，两者都具有竞争力，各自开辟了专精方向，使其能在不同领域大放异彩。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄易于操作，带来强劲的开场爆发和全程免费的顺劈，非常适合大秘境以及拥有多目标或伤害增益窗口的团队副本战斗。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 另一方面，奥达奇收割者借助[[spell:442806]]带来强大的单体聚焦输出，在低目标数时同样拥有出色的顺劈工具，使其在更困难的团队副本战斗和高层大秘境中脱颖而出。

**快速开始导入代码：**

:::talents 团队副本/单体目标 – 奥达奇收割者
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZMjZmZmxMZMzAAAAAAAmNjZbmxYmtZmxyMjZsMzwMLzsNDGGLbMhxMjhFAAAAAAAwMDwAAAAwA"
}
```
:::

:::talents AoE/大秘境 – 邪痕枭雄
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::talents 高层大秘境 – 奥达奇收割者
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxEGzMmxCAAAAAAAYmBYAAAAYA"
}
```
:::

:::talents 地下堡 – 邪痕枭雄
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMjxMhZGAAAAAAwsYmhZMzAzYZmZmxyMDmlB2mNzYY2YaMzMzM2AAAAAAAAYmBDAAAAD"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

奥达奇收割者

单体目标

推荐

秘境+

高层钥匙

地下堡

邪痕枭雄

团队副本/顺劈

团队副本/单体目标

秘境+

推荐

地下堡

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者单体目标配装

在第2赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者受益于针对浩劫所做的许多改动，尤其是[[spell:203555]]提供的额外狂怒。由于新套装的强度和反复的加强调整，它现在是最强的单体目标选择，同时带来了足够的顺劈和单体聚焦输出，使其在剧毒深渊中脱颖而出。因此，它是我们的推荐选择：

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者AoE配装

与单体目标非常相似， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者在第2赛季获得了巨大提升，针对其专精方向的反复加强提升了它的价值。它重新成为强力的优先伤害和单体聚焦专精，非常适合高层钥匙，因为这在高层中非常宝贵。虽然它的适用场景较窄，但在顶尖内容中它成为了首选。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者地下堡配装

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者非常适合 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) ，因为灵魂碎片生成量高，提供了额外的续航能力。它可以轻松应对更大的拉怪规模，不过[[spell:442624]]所需的额外管理在某些情况下会有些棘手。除此之外，它是一个可靠的选择。

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄团队副本顺劈配装

由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 由于邪痕枭雄的配装在纯单体目标构建时存在较大差异，我们选择提供一套针对剧毒深渊中大量顺劈场景量身定制的配装。虽然这在正确操作时会略微落后于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者，但其操作简便和灵活性使其成为一个值得考虑的竞争对手，如果你觉得它更顺手的话：

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄单体目标配装

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄此前是剧毒深渊中最强的天赋树，但针对 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者的反复加强使其略微落后。不过它仍然完全有能力跟上，而且更简单的操作配合对爆发的更高侧重，意味着它在某些战斗中依然表现出色。然而，如果你打算大量使用它，我们仍然推荐 **团本顺劈**
如果你打算大量使用这个，就选择这套天赋。

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄AoE配装

虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄在单体目标方面失去了领先优势，但在AoE方面保留了大部分优势。它仍然提供更多的爆发伤害，同时拥有扎实的单体目标核心来应对Boss战。由于它也相当容易上手，它是我们第2赛季中 **推荐选择** 用于第2赛季的常规大秘境钥匙。

### 天赋方案 1-3

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄地下堡配装

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄在地下堡中表现出色， [地下堡](<https://www.icy-veins.com/wow/delves-guide>)，通过每20秒一次的[[spell:213410]]拥有频繁而强大的爆发AoE。再配合每2分钟一次的[[spell:191427]]应对危险敌人，以及只要你处于变形状态就提供吸血的[[spell:204909]]，你通常可以非常安全地碾过战斗。它拥有的大量专门针对地下堡中单人战斗的工具，使其成为 **推荐** 选择。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZMjZmZmxMZMzAAAAAAAmNjZbmxYmtZmxyMjZsMzwMLzsNDGGLbMhxMjhFAAAAAAAwMDwAAAAwA"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUiEKSVWBJLQQSY688OO00GNTFMmmw4C2C-PXgiIJKOWhAOaako+MYiMpxxRSWsMzG-AAAA-GIOi0AEUowgCzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxEGzMmxCAAAAAAAYmBYAAAAYA"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJKOWhAOaako+MYiMpxxRSWsMzG-AAAA-GIOi0AEUowgCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZMjZmZMmJMzAAAAAAAmFzMMjZmZbmZsMzYGLzMMzyMbzghxyGTYMzMzYBAAAAAAAMzAMAAAAM"
}
```
:::

:::details 来源计算器编码
```
#BJ-NUiEKSVWAJPLQQY6OO00GNTFMmmC88yKxCB-PXgiIJKOWhAOaako+MYiMpxxRSWsMzG-AAAA-GIOi0AEUowgCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMzMmJjZGAAAAAAwsZMbzMGDmZsMz8AzwMDmlB2mFzYY2YaMzMG2AAAAAAAAYmBDAAAAD"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUiEKSVWBJLQQSY688OO00GNTFMmmw4C2C-PXgiIJOWAHNSUGRm044IJ3CFIMQ0UNC-AAAA-BeERhphowYJQwA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMjZMzMzMmJjZGAAAAAAwsZMbzMGjlZmxyMzDMzsMzsMGDsNLmxwsx0wMjhNAAAAAAAAmZwAAAAwA"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUiEKSVWBJLQQSY688OO00GNTFMmmw4C2C-PXYgiIJOWAHNNSUVeGMRm0446QSuIzG-AAAA-BeERhphowYJQwA-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJOhACEGOoqqsMkiMpxxRSWSsNC-AAAA-BeERhphowYJQ4A-
```

:::

### 天赋方案 1-3

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMjxMhZGAAAAAAwsYmhZMzAzYZmZmxyMDmlB2mNzYY2YaMzMzM2AAAAAAAAYmBDAAAAD"
}
```
:::

:::details 来源计算器编码
```
#BJ-NhiEKUVgknFIIMSWy688KPO00GNTFMmmwCA-PXgiIJOhACEGOoqqsMkiMpxxRSSkZbE-AAAA-BeERhphowYJQ4A-
```

:::

### 天赋方案 0-0

在单体情况下， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者点出了所有[[spell:185123]]天赋来强化[[spell:442294]]，并使用[[spell:1220506]]在循环中从中获取价值。它同时点出[[spell:206476]]和[[spell:389688]]将移动融入配装，并在最终选择节点上点出[[spell:388116]]。

[[spell:258887]]是天赋树底部的关键选择，它为[[spell:198013]]和[[spell:213410]]开启20秒爆发循环。由于第2赛季套装效果，它还点出了[[spell:258860]]。最后，它将全部四点投入[[spell:1270898]]，从而获得更多使用[[spell:370965]]的机会，并进而获得更多[[spell:442294]]触发。

### 天赋方案 0-1

在AoE场景中 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者配装与单体目标配装极为相似，同样点出[[spell:185123]]组合来强化[[spell:442294]]。由于其大量AoE伤害源自于单体目标中依赖的技能，天赋树其余部分遵循相同优先级，优化[[spell:188499]]和其他物理伤害效果来为[[spell:442806]]服务。你唯一的选择是点出[[spell:427794]]还是[[spell:258881]]——两者在输出方面相近，后者在副本中能提供更多整体伤害。

第2赛季套装加成使得[[spell:258860]]在底部成为必选项，而[[spell:258887]]对于构建其20秒爆发循环仍然至关重要。最后，全部四点都投入到顶级天赋[[spell:1270898]]中，以将[[spell:370965]]强化为1分钟冷却技能。

### 天赋方案 1-0

在功能上，这与单体目标配装的目标相同，即构建[[spell:191427]]相关天赋来强化[[spell:213410]]窗口。它不是跳过[[spell:427776]]并纯粹点出单体目标天赋，而是通过它来到达高价值的顺劈选择，同时构建[[spell:258920]]。这大大增加了灵活性，在需要优先击杀小怪刷新的战斗中表现更好。 **中间的**
一个天赋点是灵活的，取决于战斗类型：

- **放弃 -** 在[[spell:203550]]中点一点。
- **点出 -** [[spell:388113]].

这用于战斗中有大量 <em>显著的</em> 时间只与Boss单独作战的场景（例如瓦什尼克）。你在小怪刷新时保留顺劈收益，同时在战斗的其余时间点出强力的单体目标天赋。

### 天赋方案 1-1

第2赛季仍然高度侧重于你的[[spell:213410]]窗口，通过[[spell:258887]]与[[spell:389688]]激活对齐来强调20秒循环。由于[[spell:427640]]强度的降低，它转而使用[[spell:206476]]来获得更稳定的伤害。它还在天赋树底部点出[[spell:388116]]而不是[[spell:427775]]，因为现在通过[[spell:203555]]的改进它可以维持其狂怒。由于在团队副本中有几个不同的选择可以切换，我们有一些额外的说明。

- 随着[[spell:427794]]的加入， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄现在可以在避开[[spell:427776]]的同时走出开局的限制，点出纯粹的进攻天赋。然而，这限制了一些可用的顺劈选择，所以剧毒深渊中的许多战斗更适合团队副本顺劈配装。
- 第2赛季套装显著提升了[[spell:258860]]，使其在最后一道门中成为必选项，并与之前的配装相比锁定了一个天赋点。
- [[spell:388113]]是一个难以评估的选择，因为它的强度随着小怪刷新而起伏。在 <em>大多数</em> 但在某些情况下，只要该Boss战不是 <em>完全</em> 顺劈场景，它的价值就足够高，值得点出。

### 天赋方案 1-2

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄的目标与单体目标和顺劈配装非常相似，高度侧重于每20秒一次的[[spell:213410]]窗口。与所有配装一样，第2赛季套装需要[[spell:258860]]来激活，而[[spell:258887]]和[[spell:1270901]]构成了其核心的中程冷却技能。

它总是点出[[spell:258920]]天赋，依靠[[spell:427775]]和[[spell:388107]]在AoE中强化它，同时在英雄天赋树上点出[[spell:452413]]。由于第2赛季中[[spell:427640]]强度的降低，它还切换到了[[spell:206476]]。

以上列出的构筑是基于强度和流行度的推荐，涵盖了终局PvE的每个内容领域。每个构筑都有自己需要执行的输出循环、需要掌握的独特方面，以及各自的技巧来在不同的战斗中协助你的团队。

1.

### 全知典籍

在 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)中引入，万灵卷册是一个玩家强度系统，通过一系列任务解锁少量的性能增强效果。这些加成与任何装备无关，并且始终在你的角色身上生效。有些提供额外伤害，而另一些则提供一些治疗和额外的防御手段。

在下方，我们列出了完成典籍任务链后解锁的五个符文的推荐：

- **符文1 –** [[spell:1279599]]
- **符文2 –** [[spell:1279603]]
- **符文3 –** [[spell:1287555]]
- **符文4 –** [[spell:1279609]]
- **符文5 –** [[spell:1279614]]

值得注意的是，这些效果之间的差异非常小。然而，第四个提升属性的符文是相关的，它通过常规触发提供大量你选择的副属性。由于对浩劫有独特而强大的收益，推荐选择暴击。

1.

### 巅峰天赋： ![Eternal Hunt Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_demonhunter_eternalhunt.jpg>) 永恒狩猎

浩劫的顶级天赋[[spell:1270898]]同时聚焦于[[spell:370965]]和[[spell:198013]]，为每次施放添加额外的组合效果。全部四点都极其强大，每个节点都有独特的互动， <em>同时</em>
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者以及 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄:

- [[spell:1270898]] **第一点 –** 使[[spell:370965]]强化你的下一次[[spell:198013]]施放，使其伤害提高100%并增加光束的范围。
- [[spell:1270900]] **第二和第三点 –** 每点减少[[spell:370965]]15秒冷却时间，并使持续伤害效果的命中目标数增加2个。
- [[spell:1270901]] **第四点 –** 使[[spell:188499]]伤害提高20%，完整引导[[spell:198013]]会使你的下一次刃舞施放重置其自身冷却时间。

这将[[spell:370965]]变成一个1分钟的爆发冷却技能，自身就能造成高额AoE伤害，同时还使每次后续的[[spell:213410]]窗口必定触发两次[[spell:210152]]施放。这显著改善了每个天赋树的20秒爆发循环，更倾向于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄对这些窗口的高度侧重。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 另一方面，奥达奇收割者则从冷却时间缩短中获益良多，提供了可靠的方式来保证[[spell:442294]]的触发。

1.

### 英雄天赋

浩劫有两个截然不同的英雄天赋树选择，如上文各节所述，根据你选择哪一个会极大改变你的游戏目标。这两个英雄天赋是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者以及 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者

这棵天赋树通过消耗灵魂触发[[spell:442294]]，并将你的下一次[[spell:185123]]替换为一个威力大得多的版本。具体机制如下：

- 施放[[spell:442294]]后，会启动一个组合序列。你的下一次[[spell:344862]]和[[spell:188499]]将触发一个额外效果，两者都使用后你将获得[[spell:442686]]。
- [[spell:442624]]通过组合中的[[spell:344862]]施加。这使得 <em>全部</em> 你造成的物理伤害通过[[spell:442806]]将其中一部分复制为混沌伤害作用于受影响的目标。

这使得 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者成为一个强大的单体聚焦专精，这通常是非常抢手的。[[spell:1272153]]在至暗之夜中的加入，使得[[spell:188499]]施放能将大量AoE伤害直接转化为作用于你标记目标的伤害，从而使其能够点杀优先目标。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄聚焦于你的[[spell:191427]]窗口——包括2分钟冷却和通过[[spell:213410]]的激活。它带来了一系列对核心技能的增益和效果，以及一些特定机制：

- 通过任何方式进入[[spell:191427]]后，你的下一次[[spell:201427]]施放 <em>和</em> [[spell:210152]]将触发[[spell:452402]]，造成高额AoE混沌伤害。
- 施放[[spell:191427]]后，你的下一个[[spell:198013]]和[[spell:258920]]也会触发一次[[spell:452402]]。变形期间，它们还会分别转化为[[spell:452497]]和[[spell:452487]]。

这意味着 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄的伤害围绕其20秒的爆发循环展开，利用[[spell:258887]]来缩短[[spell:198013]]的冷却时间以进入[[spell:213410]]状态。随后，每两分钟在[[spell:191427]]期间会进一步放大这一效果，通过[[spell:452402]]连击打出强力的前置爆发。

1.

### PvP天赋（战争模式）

「战争模式」是一个可选功能，启用后可开启开放世界的PvP遭遇，并在激活时提供一些好处：

- 在开放世界中获得使用PvP天赋的权限。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可以获得装备奖励。

考虑到战争模式在练级和PvE内容中的好处，它是最大化你练级速度和奖励潜力的一种可选方式。然而，你将使自己暴露在开放世界的PvP中，因此要注意可能干扰你的敌对玩家；这是一个你需要自己决定是否要承担的风险。

在这里，我们只关注那些在升级或开放世界PvE场景中有用的PvP天赋，因为它们的PvP收益已在我们的PvP页面上讨论。通常，这些选择是为了优化你更快击杀敌人的能力，从而加快你推进内容的节奏。

- [[spell:213480]] 就是免费的 狂怒 生成，因为您在野外总会受到伤害。
- [[spell:206803]] 可以在保证安全的同时帮助应对危险的敌人，尽管它不如直接使用技能那么强力。
- [[spell:355995]]可以提供少量额外治疗和灵魂生成。

[[spell:205604]]、[[spell:205596]]、[[spell:357419]]、[[spell:205625]]和[[spell:354489]]在PvE中用处极小，因为它们非常侧重于控制工具或迫使敌方玩家消耗比他们原本想要更多的资源。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为12.1.5补丁更新，将奥达奇调整为推荐以配合第2赛季中期的增益。
- **2026年8月30日：** 由于当前表现，将团队副本中的推荐切换为 邪痕枭雄。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已根据12.0.7补丁使用全知卷册推荐进行更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月28日：** 更新以更清晰地突出 邪痕枭雄 在单体目标上的优势。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 为11.1.5补丁审查——由于执行简便，将奥达奇AoE配装移回低移动选项。
- **2025年3月4日：** 将 奥达奇收割者 AoE转向选择惯性。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7版本进行审查，添加了推荐标签。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已更新以反映新的 邪痕枭雄 推荐。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为第4赛季更新，加入新的天赋选择。
- **2024年3月21日：** 已针对10.2.6补丁进行审阅，最强配装方案保持不变，但保留了备选方案。
- **2024年1月15日：** 已针对10.2.5补丁进行审阅，对AOE最终天赋点的选择进行了小幅推荐清理。
- **2023年11月13日：** 对T30 AOE配装方案的提示进行了微调，并添加了低移动战的T30单体目标方案。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 已针对10.1.7补丁进行审阅，将AOE推荐改为战刃风暴/怒火，重构了页面。
- **2023年7月10日：** 已针对10.1.5补丁进行更新，添加了单独的部分和不移动配装方案的推荐。
- **2023年5月1日：** 配装方案已更新以考虑10.1补丁的变更，包括将锯齿战刃作为选项。
- **2023年3月20日：** 已根据10.0.7补丁审查并更新。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已针对巨龙时代前夕进行更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页，你将学习如何在单目标和多目标情况下优化你的浩劫恶魔猎手的输出循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以帮助你最大化你的DPS。我们所有的内容均已针对《魔兽世界》12.1.5版本补丁更新。

1.

### 浩劫恶魔猎手玩法与输出循环指南

欢迎来到我们的浩劫恶魔猎手指南的输出循环部分，这里涵盖了你在团队副本和大秘境中了解浩劫玩法所需的一切！

由于浩劫的两个英雄天赋专精各有特色，下面我们在至暗之夜第2赛季中为每种内容类型提供了一些快速推荐：

- **团队副本 / 单目标 –**
  两棵英雄天赋树都能在团队副本中发挥作用，但 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者在多次加强后拥有更高的上限。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 不过邪痕枭雄在顺劈战斗中依然非常强力，所以两者都可以玩。
- **大秘境 / 群体伤害 –**
  类似地，两棵英雄天赋树都很强力，各有不同的专精方向。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄擅长整体的原始总输出，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者则是在更高层数中作为优先目标专精的存在。

在第2赛季伊始，曾尝试将两者 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者以及 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄拉近。虽然最初未能达标，但后续的调整实现了这一目标，甚至使得 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者反超。通过[[spell:442806]]，它成为一个强大的单体优先目标伤害专精，能够应对大多数团队副本首领战。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄则几乎可以胜任所有情况，利用其与[[spell:452402]]配合的20秒爆发循环来应对不同的战斗节奏。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者

团队副本 / 单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

大秘境 / AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄

团队副本 / 顺劈

团队副本 / 单体目标

大秘境 / AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:258860]]

[[spell:427775]]

[[spell:206476]]

[[spell:427640]]

[[spell:388108]]

### 单体目标

1.1.

#### 浩劫恶魔猎手单目标输出循环

浩劫的单目标输出循环与其积攒-消耗循环紧密相连。它使用产生资源的工具来驱动[[spell:188499]]，将多余的狂怒消耗在[[spell:344862]]上，并将冷却技能组合使用。

---

1. **适用条件：奥达奇收割者（启用）。**
   施放[[spell:370965]] - <em>点击查看说明</em>
   
   
   
   
   - <em>确保</em> 在施放前，你已消耗掉任何激活的[[spell:442294]]触发效果。
2. **适用条件：奥达奇收割者（启用）。** 如果[[spell:198013]]和[[spell:210152]]就绪，则施放[[spell:191427]] **同时** 卡着冷却
3. **适用条件：Inertia（启用）；奥达奇收割者（启用）。**
   在[[spell:427640]]就绪时施放[[spell:232893]] - <em>点击查看说明</em>
   
   
   
   
   - 如果[[spell:232893]]不可用，则改用[[spell:344865]]。
4. **适用条件：Exergy（启用）。**
   施放[[spell:198793]]以触发[[spell:206476]] - <em>点击查看说明</em>
   
   
   
   
   - <em>始终</em> 尝试将其与[[spell:198013]]对齐以获得[[spell:388108]]。
5. **适用条件：Initiative（启用）；Exergy（未启用）。**
   施放[[spell:198793]]以触发[[spell:388108]] - <em>点击查看说明</em>
   
   
   
   
   - <em>始终</em> 尝试将其与[[spell:198013]]对齐。
6. **适用条件：奥达奇收割者（启用）。**
   施放[[spell:442294]] - <em>点击查看说明</em>
   
   
   
   
   - 确保没有激活的[[spell:442442]]或[[spell:442435]]增益效果
   - 紧接着施放[[spell:344862]] / [[spell:201427]]以施加[[spell:442624]]
7. **适用条件：邪痕枭雄（启用）。**
   如果[[spell:198013]]和[[spell:210152]]就绪，则施放[[spell:191427]] **同时** 冷却即用 - <em>点击查看说明</em>
   
   
   
   
   - 确保你已消耗掉[[spell:452402]]的任何[[spell:210152]]和[[spell:201427]]触发效果
8. **适用条件：Inertia（启用）；邪痕枭雄（启用）。**
   在[[spell:427640]]就绪时施放[[spell:232893]] - <em>点击查看说明</em>
   
   
   
   
   - 如果[[spell:232893]]不可用，则改用[[spell:344865]]。
9. **适用条件：邪痕枭雄（启用）。**
   施放[[spell:370965]] - <em>点击查看说明</em>
   
   
   
   
   - 如果[[spell:191427]]可用，则留待用来强化[[spell:452497]]。
10. **适用条件：邪痕枭雄（启用）；Essence Break（未启用）。** 在[[spell:452402]]激活期间施放[[spell:210152]]
11. **适用条件：A 火焰 Inside（启用）；邪痕枭雄（启用）。**
    如果有2层充能，则施放[[spell:258920]] - <em>点击查看说明</em>
    
    
    
    
    - 如果[[spell:191427]]即将就绪，消耗两层充能以利用重置效果。
12. **适用条件：邪痕枭雄（启用）；Essence Break（启用）。** 在[[spell:258860]]期间或在[[spell:452402]]激活时施放[[spell:210152]]
13. **适用条件：奥达奇收割者（启用）。** 施放[[spell:198013]]
14. **适用条件：Essence Break（启用）；奥达奇收割者（启用）。**
    施放[[spell:258860]] - <em>点击查看说明</em>
    
    
    
    
    - 如果[[spell:198013]]的冷却时间剩余4秒或更少，则留待其后施放。
15. **适用条件：邪痕枭雄（启用）。** 在[[spell:452402]]激活期间施放[[spell:201427]]
16. **适用条件：邪痕枭雄（启用）。**
    施放[[spell:198013]] / [[spell:452497]] - <em>点击查看说明</em>
    
    
    
    
    - 确保你已消耗掉[[spell:452402]]的任何[[spell:201427]]和[[spell:210152]]触发效果。
17. **适用条件：Essence Break（启用）；奥达奇收割者（未启用）。**
    施放[[spell:258860]] - <em>点击查看说明</em>
    
    
    
    
    - 如果[[spell:198013]]的冷却时间剩余4秒或更少，则留待其后施放。
18. 施放[[spell:210152]] / [[spell:188499]]
19. **适用条件：邪痕枭雄（启用）。** 在[[spell:452402]]激活期间施放[[spell:452487]]
20. 施放[[spell:201427]] / [[spell:344862]]
21. **适用条件：邪痕枭雄（启用）。** 施放[[spell:258920]] / [[spell:452487]]
22. 施放[[spell:232893]]
23. **适用条件：奥达奇收割者（启用）。** 施放[[spell:258920]]
24. 在没有其他可用技能时施放[[spell:344865]]

---

**适用条件：邪痕枭雄（启用）。** 浩劫的玩法循环深受你的天赋选择影响，许多效果会影响你的优先级。每个英雄天赋树也以不同方式与技能组互动，改变你的关键爆发时机。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄高度专注于每次[[spell:198013]]之后的[[spell:213410]]窗口，同时每2分钟通过施放[[spell:191427]]打出前置爆发。

**适用条件：奥达奇收割者（启用）。** 浩劫的玩法循环深受你的天赋选择影响，许多效果会影响你的优先级。每个英雄天赋也以不同方式与技能组互动，改变你的关键爆发时机。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者在其循环中穿插通过收集灵魂获得的[[spell:442294]]，强化你的[[spell:188499]]和[[spell:344862]]施放，并每分钟使用一次[[spell:370965]]以确保触发效果。

1.2.

#### 单体输出循环说明与技巧

**适用条件：邪痕枭雄（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄，基于你在上方工具中的选择：

**适用条件：奥达奇收割者（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者，基于你在上方工具中的选择：

- **适用条件：邪痕枭雄（启用）。** 每次进入[[spell:213410]]时，你应通过[[spell:1270901]]施放两次[[spell:210152]]，并施放一次[[spell:201427]]以消耗[[spell:452402]]。在施放[[spell:191427]]之后，这将扩展为消耗来自[[spell:452497]]和[[spell:452487]]两者的效果。
- **适用条件：邪痕枭雄（启用）。** 在至暗之夜中，通过[[spell:452497]]从[[spell:191427]]触发[[spell:213410]]
  <em>将会</em> 产生新的[[spell:452402]]触发效果，因此你可以自由刷新以获得新的一组。
- **适用条件：奥达奇收割者（启用）。** [[spell:442294]]因其原始伤害而成为高优先级按键。[[spell:442624]]应始终保持，但层数不是特别重要。
- **适用条件：奥达奇收割者（启用）。** [[spell:370965]]用于在开怪时瞬间产生[[spell:442294]]，或用于优先目标。
- **适用条件：Essence Break（启用）。** 由于套装效果，[[spell:258860]]窗口更长，因此你要避免用[[spell:198013]]削减减益效果。如果即将发生冲突，则留待进入[[spell:191427]]后再使用。
- **适用条件：邪痕枭雄（启用）。** 你希望用[[spell:1270901]]来强化[[spell:452497]]，因此当[[spell:191427]]就绪时，留待其后使用。
- **适用条件：Exergy（启用）。** [[spell:206476]]通过冷却即用[[spell:198793]]来维持。
- **适用条件：Inertia（启用）。** [[spell:427640]]应在每次[[spell:198013]]窗口之前立即触发，因为[[spell:198793]]的冷却时间自然对齐。在开始你的[[spell:198013]]之前，用后续的[[spell:232893]]（或不可用时的[[spell:344865]]）触发它。

---

:::details 常见问题我应该为了伤害施放邪能冲撞吗？
很少。虽然你偶尔可能会遇到一些空的GCD，但如果你因此失去近战攻击时间，其伤害就会被抵消。在使用

[[spell:427640]]

然而，在你没有的情况下，这是一个触发该效果的重要备用方法。

[[spell:232893]]

就绪时触发效果的重要备用手段。

:::

:::details 常见问题我应该主动施放投掷利刃吗？
很少使用。它是一个填充GCD，伤害极低，如果你有

<em>绝对没有其他任何</em>

可用时，它是一个造成极小伤害的填充GCD。由于其

[[spell:1220506]]

运作方式，当你点了

[[spell:185123]]

相关天赋时，你不应主动施放

[[spell:188499]]

，而应使用

:::

### 群体伤害

1.3.

#### 浩劫恶魔猎手群体输出循环

浩劫的玩法在群体伤害中变化不大，这得益于其许多核心技能内置的大量被动顺劈伤害。不过其天赋构建会略有变化，从而改变优先级。

---

1. **适用条件：奥达奇收割者（启用）。** 如果[[spell:198013]]和[[spell:210152]]就绪，则施放[[spell:191427]] **同时** 卡着冷却
2. **适用条件：奥达奇收割者（启用）。**
   施放[[spell:370965]] - <em>点击查看说明</em>
   
   
   
   
   - <em>确保</em> 在施放前，你已消耗掉任何激活的[[spell:442294]]触发效果。
3. **适用条件：Inertia（启用）；奥达奇收割者（启用）。**
   在[[spell:427640]]就绪时施放[[spell:232893]] - <em>点击查看说明</em>
   
   
   
   
   - 如果[[spell:232893]]不可用，则改用[[spell:344865]]。
4. **适用条件：Exergy（启用）。**
   施放[[spell:198793]]以触发[[spell:206476]] - <em>点击查看说明</em>
   
   
   
   
   - <em>始终</em> 尝试将其与[[spell:198013]]对齐以获得[[spell:388108]]。
5. **适用条件：Initiative（启用）；Exergy（未启用）。**
   施放[[spell:198793]]以触发[[spell:388108]] - <em>点击查看说明</em>
   
   
   
   
   - <em>始终</em> 尝试将其与[[spell:198013]]对齐。
6. **适用条件：奥达奇收割者（启用）。**
   施放[[spell:442294]] - <em>点击查看说明</em>
   
   
   
   
   - 确保没有激活的[[spell:442442]]或[[spell:442435]]增益效果
   - 紧接着施放[[spell:344862]] / [[spell:201427]]以对你的优先目标施加[[spell:442624]]
7. **适用条件：邪痕枭雄（启用）。**
   如果[[spell:198013]]和[[spell:210152]]就绪，则施放[[spell:191427]] **同时** 冷却即用 - <em>点击查看说明</em>
   
   
   
   
   - 确保你已消耗掉[[spell:452402]]的任何[[spell:210152]]和[[spell:201427]]触发效果
8. **适用条件：Inertia（启用）；邪痕枭雄（启用）。**
   在[[spell:427640]]就绪时施放[[spell:232893]] - <em>点击查看说明</em>
   
   
   
   
   - 如果[[spell:232893]]不可用，则改用[[spell:344865]]。
9. **适用条件：邪痕枭雄（启用）。**
   施放[[spell:370965]] - <em>点击查看说明</em>
   
   
   
   
   - 如果[[spell:191427]]可用，则留待用来强化[[spell:452497]]。
10. **适用条件：邪痕枭雄（启用）；Essence Break（未启用）。** 在[[spell:452402]]激活期间施放[[spell:210152]]
11. **适用条件：A 火焰 Inside（启用）；邪痕枭雄（启用）。**
    如果有2层充能，则施放[[spell:258920]] - <em>点击查看说明</em>
    
    
    
    
    - 如果[[spell:191427]]即将就绪，消耗两层充能以利用重置效果。
12. **适用条件：邪痕枭雄（启用）；Essence Break（启用）。** 在[[spell:258860]]期间或在[[spell:452402]]激活时施放[[spell:210152]]
13. **适用条件：Essence Break（启用）；奥达奇收割者（启用）。** 在[[spell:258860]]期间施放[[spell:210152]]
14. **适用条件：邪痕枭雄（启用）。** 在[[spell:452402]]激活期间施放[[spell:201427]]
15. **适用条件：奥达奇收割者（启用）。** 施放[[spell:198013]]
16. **适用条件：邪痕枭雄（启用）。**
    施放[[spell:198013]] / [[spell:452497]] - <em>点击查看说明</em>
    
    
    
    
    - 确保你已消耗掉[[spell:452402]]的任何[[spell:201427]]和[[spell:210152]]触发效果。
17. **适用条件：Essence Break（启用）。**
    施放[[spell:258860]] - <em>点击查看说明</em>
    
    
    
    
    - 如果[[spell:198013]]的冷却时间剩余4秒或更少，则留待其后施放。
18. 施放[[spell:210152]] / [[spell:188499]]
19. **适用条件：邪痕枭雄（启用）。** 施放[[spell:258920]] / [[spell:452487]]
20. **适用条件：奥达奇收割者（启用）；A 火焰 Inside（启用）。** 施放[[spell:258920]]
21. 施放[[spell:201427]] / [[spell:344862]]
22. **适用条件：奥达奇收割者（启用）；A 火焰 Inside（未启用）。** 施放[[spell:258920]]
23. 施放[[spell:232893]]
24. 在没有其他可用技能时施放[[spell:344865]]

---

**适用条件：邪痕枭雄（启用）。** 你在单目标中使用的大部分工具都直接适用于群体伤害，除了[[spell:201427]] / [[spell:344862]]的影响略小之外。你的侧重点取决于所使用的英雄天赋，其中 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄更侧重于将[[spell:258920]]与[[spell:427775]]结合使用。

**适用条件：奥达奇收割者（启用）。** 你在单目标中使用的大部分工具都直接适用于群体伤害，除了[[spell:201427]] / [[spell:344862]]的影响略小之外。你的侧重点取决于所使用的英雄天赋，其中 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者 利用 [[spell:442806]] 通过 [[spell:188499]] / [[spell:210152]] 对优先目标造成高额集中伤害。

1.4.

#### AoE循环说明与提示

**适用条件：邪痕枭雄（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄，基于你在上方工具中的选择：

**适用条件：奥达奇收割者（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者，基于你在上方工具中的选择：

- **适用条件：邪痕枭雄（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 流派在每2分钟的 [[spell:191427]] 期间能造成极高的范围爆发伤害。务必围绕这些时间点做好规划，用 [[spell:452402]] 强化的技能最大化你的输出。
- **适用条件：邪痕枭雄（启用）；A 火焰 Inside（启用）。** [[spell:258920]] 是范围输出的核心组成部分 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄。[[spell:388107]] 需要你留意其到期时间，确保爆炸能击中目标。在拥有 [[spell:427775]] 时，你应避免停留在2层充能，并确保在施放 [[spell:191427]] 之前用光所有充能以返还两层充能。
- **适用条件：奥达奇收割者（启用）。** [[spell:442294]] 是高优先级的技能，无论是为了其自身伤害还是 [[spell:442718]] 汇入 [[spell:442806]] 的效果。始终先对你的优先目标施加 [[spell:442624]]，然后消耗 [[spell:188499]] 增益 **秒可用一次** 以获得 [[spell:1272153]] 的强化。
- **适用条件：奥达奇收割者（启用）。** [[spell:370965]]用于在开怪时瞬间产生[[spell:442294]]，或用于优先目标。
- **适用条件：Essence Break（启用）。** [[spell:258860]] 窗口在套装加持下更强，但主要目标是在窗口内尽可能多地施放 [[spell:210152]]，以最大化减益效果的触发。在可能的情况下，将使用时机与 [[spell:1270901]] 重置的机会对齐。
- **适用条件：邪痕枭雄（启用）。** 你希望用[[spell:1270901]]来强化[[spell:452497]]，因此当[[spell:191427]]就绪时，留待其后使用。
- **适用条件：Exergy（启用）。** [[spell:206476]]通过冷却即用[[spell:198793]]来维持。
- **适用条件：Inertia（启用）。** [[spell:427640]]应在每次[[spell:198013]]窗口之前立即触发，因为[[spell:198793]]的冷却时间自然对齐。在开始你的[[spell:198013]]之前，用后续的[[spell:232893]]（或不可用时的[[spell:344865]]）触发它。

---

:::details 常见问题我应该为了伤害施放邪能冲撞吗？
很少。虽然你偶尔可能会遇到一些空的GCD，但如果你因此失去近战攻击时间，其伤害就会被抵消。在使用

[[spell:427640]]

然而，在你没有的情况下，这是一个触发该效果的重要备用方法。

[[spell:232893]]

就绪时触发效果的重要备用手段。

:::

:::details 常见问题我应该主动施放投掷利刃吗？
很少使用。它是一个填充GCD，伤害极低，如果你有

<em>绝对没有其他任何</em>

可用时，它是一个造成极小伤害的填充GCD。由于其

[[spell:1220506]]

运作方式，当你点了

[[spell:185123]]

相关天赋时，你不应主动施放

[[spell:188499]]

，而应使用

:::

### 单体起手

1.5.

#### 浩劫 恶魔猎手 单体起手

浩劫 的起手遵循一个序列，以利用 [[spell:388112]]。目标是让所有技能进入冷却，然后尽快进入 [[spell:191427]]。

---

**适用条件：奥达奇收割者（启用）。**

[[spell:258920]]

1s

拉怪

[[spell:370965]]

[[item:241288]]

[[spell:442294]]

[[item:270175]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:232893]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

[[spell:198013]]

**适用条件：Essence Break（启用）。**

[[spell:258860]]

[[spell:210152]]

[[spell:442718]]

[[spell:201427]]

[[spell:442624]]

[[spell:210152]]

[[spell:191427]]

[[spell:198793]]

[[spell:344865]]

[[spell:427640]]

[[spell:198013]]

[[spell:210152]]

x2

**适用条件：邪痕枭雄（启用）。**

[[spell:258920]]

1s

拉怪

**适用条件：Inertia（未启用）。**

**适用条件：Inertia（未启用）。**

[[spell:232893]]

**适用条件：Inertia（未启用）。**

[[item:241288]]

**适用条件：Inertia（启用）。**

[[spell:344865]]

**适用条件：A 火焰 Inside（启用）。**

[[spell:258920]]

[[spell:198013]]

[[item:270175]]

[[spell:370965]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:232893]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

**适用条件：Essence Break（启用）。**

[[spell:258860]]

[[spell:210152]]

x2

[[spell:201427]]

[[spell:191427]]

[[spell:198793]]

[[spell:210152]]

[[spell:452487]]

[[spell:201427]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:344865]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

[[spell:452497]]

---

1. 在开怪前1秒施放 [[spell:258920]]
2. **适用条件：奥达奇收割者（启用）。** 施放 [[spell:370965]] 接触目标
   
   
   
   
   - 使用[[item:241288]]
   - 使用主动饰品，例如[[item:270175]]
3. **适用条件：邪痕枭雄（启用）；Inertia（未启用）。** 施放 [[spell:232893]] 接触目标
   
   
   
   
   - 使用[[item:241288]]
   - 使用主动饰品，例如[[item:270175]]
4. **适用条件：邪痕枭雄（启用）；Inertia（启用）。** 施放 [[spell:344865]] 接触目标
   
   
   
   
   - 使用[[item:241288]]
   - 使用主动饰品，例如[[item:270175]]
5. **适用条件：奥达奇收割者（启用）。** 施放 [[spell:442294]]
6. **适用条件：奥达奇收割者（启用）；Inertia（启用）。** 施放 [[spell:232893]] 以触发 [[spell:427640]]
7. **适用条件：邪痕枭雄（启用）；A 火焰 Inside（启用）。** 施放[[spell:258920]]
8. 施放[[spell:198013]]
9. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:370965]]
10. **适用条件：Inertia（启用）；邪痕枭雄（启用）。** 施放 [[spell:232893]] 以触发 [[spell:427640]]
11. **适用条件：Essence Break（启用）。** 施放 [[spell:258860]]
12. **适用条件：奥达奇收割者（启用）。** 施放 [[spell:210152]]
13. **适用条件：奥达奇收割者（启用）。** 施放 [[spell:201427]]
14. **适用条件：奥达奇收割者（启用）。** 施放 [[spell:210152]]
15. **适用条件：邪痕枭雄（启用）。** 施放两次 [[spell:210152]]
16. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:201427]]
17. 施放 [[spell:198793]] 并立即 [[spell:191427]]
18. **适用条件：Inertia（启用）。** 施放 [[spell:344865]] 以触发 [[spell:427640]]
19. **适用条件：奥达奇收割者（启用）。** 施放[[spell:198013]]
20. **适用条件：奥达奇收割者（启用）。** 施放两次 [[spell:210152]]
21. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:210152]]
22. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:201427]]
23. **适用条件：邪痕枭雄（启用）；A 火焰 Inside（启用）。** 施放 [[spell:452487]]
24. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:452497]]
25. 继续按照正常的技能优先级。

---

对初始循环影响最大的是 [[spell:388112]]，它会使你的 [[spell:188499]] 和 [[spell:198013]] 冷却时间重置。[[spell:1270901]] 还意味着你需要在进入 [[spell:191427]] 之前，从起手的 [[spell:198013]] 施放中挤出两次 [[spell:210152]] 施放。

### AoE起手

1.6.

#### 浩劫 恶魔猎手 范围起手

与单体类似，范围起手的关键是在 [[spell:191427]] 之前做好准备。序列类似，但对范围技能的优先级有所提高。

---

**适用条件：奥达奇收割者（启用）。**

[[spell:258920]]

1s

拉怪

[[spell:370965]]

[[item:241288]]

[[spell:442294]]

[[item:270175]]

[[spell:198013]]

[[spell:201427]]

[[spell:442624]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:232893]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

**适用条件：Essence Break（启用）。**

[[spell:258860]]

[[spell:210152]]

x2

[[spell:442718]]

[[spell:191427]]

[[spell:198793]]

[[spell:198013]]

[[spell:210152]]

x2

**适用条件：邪痕枭雄（启用）。**

[[spell:258920]]

1s

拉怪

**适用条件：Inertia（未启用）。**

**适用条件：Inertia（未启用）。**

[[spell:232893]]

**适用条件：Inertia（未启用）。**

[[item:241288]]

**适用条件：Inertia（启用）。**

[[spell:344865]]

**适用条件：A 火焰 Inside（启用）。**

[[spell:258920]]

[[spell:198013]]

[[item:270175]]

[[spell:370965]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:232893]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

[[spell:201427]]

**适用条件：Essence Break（启用）。**

[[spell:258860]]

[[spell:210152]]

x2

[[spell:191427]]

[[spell:198793]]

[[spell:210152]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:344865]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

**适用条件：A 火焰 Inside（启用）。**

[[spell:452487]]

[[spell:201427]]

[[spell:452497]]

---

1. 在开怪前1秒施放 [[spell:258920]]
2. **适用条件：奥达奇收割者（启用）。** 施放 [[spell:370965]] 接触目标
   
   
   
   
   - 使用[[item:241288]]
   - 使用主动饰品，例如[[item:270175]]
3. **适用条件：邪痕枭雄（启用）；Inertia（未启用）。** 施放 [[spell:232893]] 接触目标
   
   
   
   
   - 使用[[item:241288]]
4. **适用条件：邪痕枭雄（启用）；Inertia（启用）。** 施放 [[spell:344865]] 接触目标
   
   
   
   
   - 使用[[item:241288]]
5. **适用条件：奥达奇收割者（启用）。** 施放 [[spell:442294]]
6. **适用条件：邪痕枭雄（启用）；A 火焰 Inside（启用）。** 施放[[spell:258920]]
7. 施放[[spell:198013]]
   
   
   
   
   - 在施放前使用主动饰品，例如 [[item:270175]]
8. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:370965]]
9. **适用条件：Inertia（启用）；邪痕枭雄（启用）。** 施放 [[spell:232893]] 以触发 [[spell:427640]]
10. **适用条件：奥达奇收割者（启用）。** 施放 [[spell:201427]]
11. **适用条件：奥达奇收割者（启用）；Inertia（启用）。** 施放 [[spell:232893]] 以触发 [[spell:427640]]
12. **适用条件：Essence Break（启用）。** 施放 [[spell:258860]]
13. **适用条件：奥达奇收割者（启用）。** 施放两次 [[spell:210152]]
14. **适用条件：邪痕枭雄（启用）。** 施放两次 [[spell:210152]]
15. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:201427]]
16. 施放 [[spell:198793]] 并立即 [[spell:191427]]
17. **适用条件：奥达奇收割者（启用）。** 施放[[spell:198013]]
18. **适用条件：奥达奇收割者（启用）。** 施放两次 [[spell:210152]]
19. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:210152]]
20. **适用条件：邪痕枭雄（启用）；A 火焰 Inside（启用）。** 施放 [[spell:452487]]
21. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:201427]]
22. **适用条件：Inertia（启用）。** 施放 [[spell:344865]] 以触发 [[spell:427640]]
23. **适用条件：邪痕枭雄（启用）。** 施放 [[spell:452497]]
24. 继续按照正常的技能优先级。

---

**适用条件：邪痕枭雄（启用）。** 与单体一样，对你起手序列影响最大的是 [[spell:388112]]，这要求你在进入 [[spell:191427]] 之前让 [[spell:188499]] 和 [[spell:198013]] 都进入冷却。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 还需要让 [[spell:258920]] 进入冷却以获得重置，同时确保正确排序所有 [[spell:452402]] 触发。

**适用条件：奥达奇收割者（启用）。** 与单体一样，对你起手序列影响最大的是 [[spell:388112]]，这要求你在进入 [[spell:191427]] 之前让 [[spell:188499]] 和 [[spell:198013]] 都进入冷却。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者 需要确保对其目标施加 [[spell:442624]] <em>之前</em> 触发 [[spell:442435]]，然后在 [[spell:258860]] 期间最大化 [[spell:210152]] 施放以获得范围套装触发。

1.

### 至暗之夜 第2赛季套装

至暗之夜第2赛季引入了 **深渊末日猎犬的追击**，可在不同的终局内容中获得。它提供以下加成：

- [[spell:1296611]] —— [[spell:188499]]、[[spell:344862]] 和 [[spell:258860]] 造成的伤害提高 12%。
- [[spell:1296612]] —— [[spell:258860]] 现在会施加并受益于 [[spell:258887]] 的效果，初始打击伤害提高 35%，持续时间延长 2 秒。

这些加成都牢牢确立了 [[spell:258860]] 作为必选天赋的地位，使其成为一个强大的爆发冷却技能。理想情况下，你希望将其叠加在 [[spell:191427]] 内部，以利用额外的急速更频繁地触发减益效果。但这并不总是可行的，因为即使在4层和30秒冷却的情况下，它也会与 [[spell:198013]] 的20秒不同步。不要为了强行重叠而等待太久，尤其是如果这会导致后续使用次数减少的话。

冷却缩减 <em>在达到最大层数之前</em> 是动态的，意味着 [[spell:258860]] 会将 [[spell:198013]] 的当前冷却时间缩短2.5秒，反之亦然。一旦你达到4层，施放时两个冷却时间都会固定减少10秒。这意味着你会比正常更快地达到4层，在第三次施放后进入20秒的眼棱循环。

2.1.

#### 浩劫 恶魔猎手 机制详解

在以下章节中，将详细解释 浩劫 的一些核心机制。它们深入探讨了主要冷却技能和循环技能的底层机制，帮助你更好地理解
<em>为什么</em> 你为何按下每个按钮。

1.

### 浩劫 机制详解

### 顶点天赋

3.1.

#### 浩劫 天顶天赋 - 永恒狩猎

浩劫 的顶峰天赋 [[spell:1270898]] 将 [[spell:370965]] 转化为强大的冷却技能，同时也为 [[spell:198013]] 和 [[spell:188499]] 提供增益。由于这两个都是每个英雄天赋树的核心循环技能，所有四点天赋都有显著的收益，并且是同时点出的：

- [[spell:1270898]] **第一点 -** 使[[spell:370965]]强化你的下一次[[spell:198013]]施放，使其伤害提高100%并增加光束的范围。
- [[spell:1270900]] **第二和第三点 -** 每点减少[[spell:370965]]15秒冷却时间，并使持续伤害效果的命中目标数增加2个。
- [[spell:1270901]] **第四点 -** 使[[spell:188499]]伤害提高20%，完整引导[[spell:198013]]会使你的下一次刃舞施放重置其自身冷却时间。

这将 [[spell:370965]] 变为一个1分钟的爆发工具，随后是一次更强的 [[spell:198013]] 施放，然后在接下来的 [[spell:213410]] 窗口中进行双重 [[spell:210152]] 施放。最后一点适用于 <em>全部</em> 眼棱施放，这意味着两个英雄天赋树都使用的20秒爆发循环得到了显著强化。 **至关重要** 但是，请确保你在决定施放眼棱时能够完整完成施放，因为失去后续效果将是重大损失。

当游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 对于 邪痕枭雄，只要可能，你就应该强化 [[spell:452497]] 而不是 [[spell:198013]]。这意味着每两分钟当 [[spell:191427]] 可用时，你应该使用 [[spell:370965]] <em>掌握</em>
变形，而不是在那之前的眼棱施放。

### 移动天赋

3.2.

#### 移动天赋

浩劫 拥有大量独特的天赋，利用其移动工具来获得额外伤害。因此，与其他专精不同，了解如何在战斗中管理移动是 浩劫 的一项关键技能。利用这种玩法的值得注意的天赋包括：

- [[spell:388108]] <em>和</em> [[spell:389688]]
- [[spell:206476]] <em>或</em> [[spell:427640]]
- [[spell:347461]]

[[spell:198793]] 是 [[spell:206476]] 和 [[spell:427640]] 的主要触发器，应卡冷却施放。在施放复仇回避后回到目标身边最好的方法是 [[spell:232893]]，但它在施放后有一个短暂的共享移动冷却时间。这意味着你必须等待才能施放它，但这
<em>通常</em> 提供了足够的距离来激活冲锋效果。这也是触发 [[spell:347461]] 的方法，能显著强化返回的邪能之刃。

3.2.1.

##### Exergy

[[spell:206476]] 使 [[spell:198793]] 和 [[spell:370965]] 都提供5%的伤害加成，持续20秒，并可延长至30秒。在整个战斗过程中应保持100%的覆盖率，因为猎杀提供的额外时间缓冲让你有一些余地来稍微推迟复仇回避的使用。这个天赋操作更简单，非常稳定，是第二赛季的首选。

3.2.2.

##### 冲撞惯性

[[spell:427640]] 提供一个短时间、高强度的爆发窗口。这与 浩劫 的许多工具配合良好，并且与 [[spell:258887]] 配合时，它能完美地将 [[spell:198793]] 与每一次 [[spell:198013]] 对齐。你应该围绕这些窗口安排复仇回避的施放时机，并确保有 [[spell:232893]] 可用以快速回到目标身边。

### 狂怒 管理

3.3.

#### 狂怒 管理

由于 浩劫 非常依赖其资源，因此识别何时需要积极消耗 狂怒 与预期生成量的情况非常重要。至暗之夜 降低了天赋树上的生成量，但第二赛季通过 [[spell:203555]] 增加了被动生成，缓解了一些资源问题。你还需要接住 [[spell:344862]] 的返还，并可能随时调整你的消耗计划。

在实际操作中管理 狂怒 时需要遵循的一些基本规则：

- <em>始终</em> 保持足够的 狂怒 以施放 [[spell:188499]] / [[spell:210152]] 和 [[spell:198013]]。
- 尽可能频繁地施放 [[spell:344862]] / [[spell:201427]]，除非是为了爆发窗口而预留。
- 施放 [[spell:232893]] 以主动获取资源。
- 如果 狂怒 落后，则施放 [[spell:258920]] 作为后备生成手段。
- 等待，让 [[spell:203555]] 生成 狂怒，或收集 [[spell:206478]] 光球。
- 如果超出任何目标的范围或处于空闲的GCD期间，则施放 [[spell:185123]] 或 [[spell:344865]]。

由于 [[spell:203555]] 是主要的生成方式，通常会有一些等待时间，特别是如果你决定过度消耗的话。这是正常的，但有了一些经验后，你应该能够规划并缓解最坏的情况。但最重要的是要记住，你绝不能在爆发窗口期间没有 狂怒 来利用它。

在运气好的连续触发期间，也会有 狂怒 充足的时期。这也是正常的，在此期间有一些浪费是可以的。确保让高优先级技能保持冷却始终更重要。

### 精华破碎

3.4.

#### 精华破碎

[[spell:258860]] 是一个额外的高价值爆发冷却技能，但只持续4秒，通过新的第二赛季套装增加到6秒。在 至暗之夜 中，这现在是固定伤害而不是乘数，因此在 [[spell:191427]] 期间执行不再那么重要。然而，在此窗口内施放仍然有益，因为额外的急速允许更多的触发。

根据你的急速以及你是否受到 [[spell:2825]] 的影响，你应该能够在此窗口内进行4次施放（有套装时为5-6次）。其中尽可能多的应该是 [[spell:210152]] / [[spell:201427]] 施放。有了顶峰天赋 [[spell:1270901]]，只要你是在 [[spell:198013]] 之后施放以触发 [[spell:213410]]，这应该能可靠地让你每次使用至少施放两次死亡横扫。如果有 [[spell:191427]] 可用，通过 [[spell:388112]] 这将扩展到三次。

### 投掷利刃

3.5.

#### 投掷利刃天赋

虽然这些天赋更多是补充而非核心，但天赋树上有许多协同天赋将 [[spell:185123]] 纳入循环成为一个相关技能。

- [[spell:391275]] – 使 [[spell:185123]] 的伤害提高60%，每次弹跳减少30%。
- [[spell:393029]] – 为 [[spell:185123]] 增加25点 狂怒 消耗，但施放时会发射第二把战刃。
- [[spell:390154]] – 使 [[spell:185123]] 和 [[spell:344862]] 在12秒内使你使用这两种技能造成的伤害提高15%。
- [[spell:388106]] – [[spell:185123]] 还会在目标身上留下一个混沌伤害DoT，在6秒内造成所造成伤害的80%。
- [[spell:1220506]] – 每次施放 [[spell:188499]] 会自动消耗一层 [[spell:185123]]，并在你的主要目标上免费施放它。每次单独的刃舞斩击也有50%的几率投掷一把额外的战刃，效果为35%。

这些天赋通常作为一套一起点出，并使用 [[spell:1220506]] 作为触发器，在循环玩法中获取这些效果。这比将GCD投入到手动施放它要高效得多——目前没有任何流派会这样做——因此它通常是点出其他 [[spell:185123]] 天赋的驱动力。这意味着这套天赋实际上比表面上看起来要被动得多。

在游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 对于 奥达奇收割者，这些是必需的天赋，因为它们也影响你的 [[spell:442294]] 施放。重要的是要知道 [[spell:1220506]] **不会** 与 [[spell:188499]] 一起施放收割者战刃时，它始终需要手动施放。

### 献祭光环

3.6.

#### 献祭光环

[[spell:258920]] 在天赋树右侧有一组专属的辅助天赋。这些天赋通常一起点出，尤其是在范围输出中，它们之间有很好的协同效应：

- [[spell:320374]] – 施放时在6秒内额外生成18点 狂怒。
- [[spell:390158]] – 每次跳动时伤害提高10%。
- [[spell:391189]] – [[spell:203555]] 和 [[spell:185123]] 施加一个15秒的DoT，造成混沌伤害。受影响的目标受到的 [[spell:258920]] 伤害提高35%，最多3层伤口。
- [[spell:388107]] – [[spell:258920]] 最多3次暴击所造成伤害的35%被积聚为怒焰。当其到期时，你会引爆，对附近敌人造成等于储存量的伤害。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 – [[spell:452413]] 使其范围增加2码，暴击伤害提高50%。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 – [[spell:1272405]] 在到期时有25%的几率重新点燃。

这在范围输出中形成了一个强大的核心，与下面讨论的天赋 [[spell:427775]] 配合良好，并且在点出后通常会尽可能频繁地施放。[[spell:1220506]] 在范围输出中自然会施加最大数量的 [[spell:391189]]，但如果你没有使用它，则需要通过 [[spell:203555]] 切换目标来施加。

[[spell:388107]] 是一个需要注意的关键机制，了解每个 [[spell:258920]] 实例何时即将到期很重要。确保在它触发之前不要移出敌人的范围（或使用移动工具位移）有助于避免它在空地上爆炸。

3.6.1.

##### 焰由心生

当使用 [[spell:427775]] 时，你的 [[spell:258920]] 获得第二层充能，冷却时间减少6秒。此外，它允许多个光环同时激活，因此施放频率要高得多。这通常与其他献祭光环天赋搭配使用，以最大化其伤害。

当你点出它时，你的目标应该是避免让它停留在2层充能，确保你围绕它即将达到上限的时间进行规划并提前使用它。记住——由于增益效果重叠，不会有任何损失。当使用
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄，[[spell:452415]]施放时会返还两点充能，使你完全恢复以叠加两次[[spell:452487]]。这意味着在[[spell:191427]]之前，你应该耗尽所有充能以获得最大收益。

3.7.

#### 浩劫 恶魔猎手 重要冷却技能

在整个天赋树中，有几个不同的冷却选项，以不同方式提供爆发。下面我们将介绍每一个，它们如何影响循环，以及如何使用它们。

1.

### 浩劫 恶魔猎手 的重要冷却技能

### 恶魔变形

4.1.

#### 恶魔变形

浩劫的主要冷却技能是[[spell:191427]]，冷却时间为2分钟。施放时，它会造成少量混沌伤害，施放后昏迷你所在位置的目标，并进入恶魔形态持续20秒。变形期间，它提供以下增益：

- **急速** 提高20%
- [[spell:344862]]替换为[[spell:201427]]，造成显著更高的伤害
- [[spell:188499]]替换为[[spell:210152]]，造成显著更高的伤害
- [[spell:388112]] – 重置[[spell:188499]]和[[spell:198013]]的冷却时间
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 – [[spell:452415]]重置[[spell:258920]]的冷却时间

此效果激活期间，浩劫造成显著更高的伤害，并生成额外资源以驱动其更强的技能。尽量带着尽可能多的狂怒进入，并以尽可能少的资源离开，规划你的[[spell:191427]]施放，使其始终处于冷却中。在使用[[spell:388112]]时，你应该确保 <em>绝对确定</em> 在按下它之前，[[spell:188499]]和[[spell:198013]]都已进入冷却。你还可以利用施放它时的跳跃来取消起手式中的[[spell:198793]]动画，从而让你贴近目标。

作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄，狂怒的生成也大幅增加。这意味着你应该更 <em>好得多的</em> 激进地消耗资源，旨在用[[spell:201427]]叠加[[spell:452408]]的持续伤害效果。

### 眼棱

4.2.

#### 眼棱

尽管[[spell:198013]]的冷却时间较短，仅为30秒，但它仍是一项强大的技能，是浩劫伤害构成的核心部分，在引导期间造成大量混沌伤害。它有多种天赋可以增强，使其在单体和 <em>尤其是</em> 范围伤害环境中都是优先施放的技能：

- [[spell:213410]] – 提供5秒的[[spell:191427]]
- [[spell:390152]] – 召唤一个友方恶魔猎手来施放[[spell:212084]]
- [[spell:203550]] – 引导期间生成大量狂怒
- [[spell:388113]] – 如果只命中一个目标，伤害提高30%
- [[spell:343311]] – 引导完成后提供10%急速，持续10秒
- [[spell:1270898]] – 施放[[spell:370965]]后伤害提高100%
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄 – [[spell:452412]]提供18%精通并生成狂怒。

你应该尽可能频繁地施放此技能，既是为了它提供的伤害，更是为了[[spell:213410]]的触发。唯一值得保留的情况是在单体战斗中，当你预期小怪会在其冷却完成前出现时。此外，确保在施放[[spell:191427]]之前它已进入冷却，因为它的冷却时间会被[[spell:388112]]重置。

4.2.1.

##### 仇恨之轮

[[spell:258887]]增加了你使用[[spell:198013]]的机会，在战斗过程中逐渐叠加。每次你在战斗中施放恶魔追击，它都会获得一层，最多4层。每层使恶魔追击的冷却时间减少2.5秒，是两种英雄天赋下浩劫循环的基石。这意味着，在你的起手式之后，它应该降至25秒，接下来的两次施放后降至20秒。此后，它将自然地与其他爆发窗口（如[[spell:389688]]）对齐。

此效果在死亡后依然存在，但在脱离战斗1分钟后会恢复为1层。

### 恶魔追击

4.3.

#### 恶魔追击

[[spell:370965]]在基础层面上是一个影响力较低的冷却技能，作为一个1.5分钟冷却的爆发工具，拥有巨大的50码范围。它造成大量混沌伤害，对你的目标以及你穿过的最多5个其他敌人施加持续伤害效果。你的判定框在到达后也会短暂保持激活，使你能够更稳定地传播持续伤害效果。

这通过 <em>显著</em> 顶峰天赋 – [[spell:1270898]] – 得到增强，它不仅将冷却时间减少至1分钟，还将持续伤害效果的应用次数增加到9次。除此之外，它还为[[spell:198013]]提供后续伤害增益，有效地将其转变为一个1分钟的连招启动器，为每种英雄天赋树造成显著的爆发伤害。

当游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者，它还提供一层[[spell:442294]]并粉碎一个额外的灵魂。这意味着它用于在开怪时快速设置你的英雄天赋，对优先目标施加[[spell:442624]]。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月30日：** 更新以将推荐设置为 邪痕枭雄，并默认为团队副本顺劈。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月24日：** 更新了起手手法以获得更好的连招顺序。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为第1赛季发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月28日：** 改进了循环工具中配装用例的指引。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月4日：** 将惯性添加到基础奥达奇AoE配装中。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已更新以反映新的 邪痕枭雄 推荐。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已更新以包含第4赛季的配装方案。
- **2024年3月21日：** 已针对10.2.6补丁进行审阅，核心推荐保持不变。
- **2024年1月15日：** 已针对10.2.5补丁进行审阅，进行了小幅清理，无需重大更改。
- **2023年11月6日：** 已针对10.2改版进行了重构和全面更新。
- **2023年9月4日：** 已针对10.1.7补丁进行审阅，在循环部分添加了配装方案按钮并重构了页面。
- **2023年7月10日：** 已针对10.1.5补丁进行审阅，进行了小幅调整以提高清晰度，并突出了孤立猎物。
- **2023年5月1日：** 已针对10.1补丁进行更新，添加了锯齿战刃及说明，并添加了额外的精华击破连招说明。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已针对10.0.5补丁进行审阅，循环工具已优化。
- **2023年1月1日：** 更新了起手式。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已针对巨龙时代前夕进行更新。

显示更多

显示更少

:::

## 装备选择

在本页，你将找到魔兽世界12.1.5版本中你的浩劫 恶魔猎手的最佳装备、饰品和毕业装备推荐。从制造物品到关于如何使用你的纹章升级装备的建议，我们都为你准备好了！

1.

### 浩劫 恶魔猎手 毕业装备指南

欢迎来到我们的浩劫 恶魔猎手的至暗之夜装备和毕业页面！查看本页，了解你需要知道的关于为浩劫 恶魔猎手配装的一切，包括来自所有来源、团队副本和大秘境的毕业装备、最佳饰品、套装等信息。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，允许你沿着与获取内容难度相关的轨道提升装备物品等级。更难的内容会掉落更高等级轨道的装备，从而达到更高的物品等级。欲了解更多信息，请阅读我们关于纹章如何运作的专属页面。 [配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 在至暗之夜中的运作方式。

12.1.5更新带来了[[item:280562]]的发布，允许334物品等级的武器、饰品和项链升级至340物品等级。此外，它还带来了新首领基斯希克斯，掉落强大的新战利品，其中有一些不错的装备适合浩劫。

### 总体

以下列表包含来自 <em>所有可能的终局内容来源</em>的装备，包括团本、大秘境、制造、地下宝库和大宝库。它旨在提供绝对最佳的配置，但请记住，每个 **单件** 装备在你特定的配装中可能并非最强。套装件如果比标准版本更强，则会列出理想转化器部件的掉落位置。

这套装备旨在尽可能优化你的暴击和精通等级。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

目前每个部位可供转化的最佳物品为：

- **头盔 –** [[item:271875@JAAEAAAG2chN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **肩膀 –** [[item:268246@JAACAAgNyA]] 来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- **胸甲 –** [[item:281236@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **手套 –** [[item:271538@JAACAAgNyA]] 来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **腿部 –** [[item:268225@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 常见问题：有哪些需要留意的高优先级大宝库或虚空核心物品吗？
第2赛季团本中提供的任何特殊效果物品都极具价值，即使它们不是来自史诗难度的344物品等级。以下物品即使来自英雄难度宝库也强烈值得考虑，如果你不打算快速推进史诗难度，甚至值得使用虚空核心来获取：

1. [[item:268209@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
2. [[item:270173@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
3. [[item:270168@JAACAAAG2A]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271875@JAAEAAAG2chN]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

三个物品中的两个在 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 战利品池中也非常强力，增加了值得寻找的装备清单。它们足够强力，如果你 <em>没有</em> 击杀任何史诗首领以获得更高的宝库奖励，如果这些物品都没有出现，你总是可以选择从大宝库中获取一个虚空核心。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271537@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240908]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271536@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:159327@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271540@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237840@JAAMAAwt1ENMMYzy1clIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 秘境+

以下套装包含来自大秘境的最佳物品，仅使用第2赛季副本池中的装备，以及你理想的套装转化器位置和用于装饰效果的制造物品。请注意，这是 <em>可获得的最佳物品</em> 来自大秘境地下城的 **非** 并非你在大秘境内容中应使用的严格列表。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

最佳 **仅限地下城** 的各部位转化件为：

- **头盔 –** [[item:159318@JAACAAgNyA]] 来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **肩膀 –** [[item:251223@JAACAAgNyA]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **胸甲 –** [[item:239048@JAACAAgNyA]] 来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **手套 –** [[item:159312@JAACAAgNyA]] 来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **腿部 –** [[item:251130@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 提示我应该刷哪些地下城？
浩劫的所有核心装备都来源于第2赛季的团队副本，但在等待获得它们的同时，也有一些值得追求的替代品：

1. [[item:250225@JAACAAAOyA]] – [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
2. [[item:250228@JAACAAAOyA]] – [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
3. [[item:159327@JAACAAgNyA]] – [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
4. [[item:158366@JAACAAgNyA]] – [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271537@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:159301@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271536@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:159327@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271540@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250225@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:251186@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237840@JAAMAAwt1ENMMYzy1clIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 团队副本

以下套装是你的 **团本** 毕业列表，使用来自 **只能** 团本掉落的装备，以及理想的套装件（或用于转化器的物品）和用于激活装饰效果的制造物品。请注意，这是 <em>可获得的最佳物品</em> 团本内部的 **非** 并非你在团本内部应使用的严格列表。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

最佳 **仅限团本** 的各部位转化件为：

- **头盔 –** [[item:271875@JAAEAAAG2chN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **肩膀 –** [[item:268246@JAACAAgNyA]] 来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- **胸甲 –** [[item:281236@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **手套 –** [[item:271538@JAACAAgNyA]] 来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **腿部 –** [[item:268225@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 小贴士：我最应该追求哪些物品？
浩劫在第2赛季团队副本中有一些价值极高的法术触发装备选择，重点集中在剧毒深渊的最后两个首领。由于物品等级提升，几乎所有这些装备都值得获取，但其中一些特别强力：

1. [[item:268209@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
2. [[item:270173@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
3. [[item:270168@JAACAAAG2A]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271875@JAAEAAAG2chN]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271537@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240908]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271536@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271540@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237840@JAAMAAwt1ENMMYzy1clIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 浩劫 恶魔猎手 饰品推荐

浩劫通常寻求使用一个与[[spell:191427]]对齐的主动饰品以增强其爆发窗口，然后搭配一个强力的被动饰品。由于[[spell:388118]]，属性触发和伤害效果都很有用，因此提供了很大的灵活性。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **至暗之夜 第2赛季值得追求的饰品**
**主动使用 –**

[[item:270168@JAACAAAG2A]]

或

[[item:270175@JAACAAAG2A]]

**被动 –**

[[item:270173@JAACAAAG2A]]

或

[[item:281215@JAACAAAOyA]]

:::

你可以点击下方打开其他饰品的排名图表，以防你捡到了别的东西并想看看它与其他饰品相比如何。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 浩劫 第2赛季饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270173@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   一个强力的直接伤害饰品，但与法术触发武器[[item:268209@JAACAAAG2A]]搭配时会更强。由于饰品效果通过[[spell:388118]]造成大量伤害，它非常强力，甚至能延伸到范围伤害环境中，并且在启用时是大多数剧毒深渊战斗中最强大的饰品。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   Font早已因[[spell:388118]]而进入浩劫的视野，由于正式服发布后的一些额外发现，其表现远好于预期。能够与[[spell:388108]]配合，在关键时刻造成惊人伤害，使其无论在何种情况下都是出色的主动工具。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270175@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   尽管冷却时间是尴尬的1分30秒，但这仍然是第2赛季中最好的属性提升主动选择。这与Font竞争你的主动饰品位，取决于你是想更频繁地提升自己的伤害，还是通过饰品本身造成前置爆发。两者都是强力的选择。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   补丁12.1.5新增，这对浩劫在范围伤害环境中极为强大，仅略逊于套装加成启用的断头台技艺。提供大量暴击（如果有频繁的小怪刷新则更多），使其完美适合多目标环境。</p>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:250225@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   尽量始终对一个存活时间足够长的目标使用它，以便叠加暴击增益，否则它的大部分价值都会流失。</p>&#10;</li>&#10;<li>[[item:273796@JAACAAAOyA]]</li>&#10;<li>[[item:270165@JAACAAAOyA]]</li>&#10;<li>[[item:270166@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   触发各种不同的属性提升效果，且不同的增益可以重叠。虽然其效果池中有一个负面触发，但它仍是一个可靠的属性饰品。</p>&#10;</li>&#10;<li>[[item:250228@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   在单体战斗中可以卡冷却使用，但在范围伤害中应为[[spell:191427]]保留。</p>&#10;</li>&#10;<li>[[item:159617@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:248583@JAACAAAMyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   前往 祖尔'Aman 中的 Jan'alai 祭坛，将其设置为 <strong>精通</strong>，或阿基尔宗祭坛将其重置为 <strong>暴击</strong>，取决于你的装备配置。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   虽然这个饰品调校得不错，但停留在触发区域内非常受限，尤其是对于经常移动的浩劫。再加上团队副本战斗中的大型场地和地下城中繁忙的移动，实际使用时效果可能因人而异。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250259@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   非常偏向单体目标的直接伤害饰品，但在你寻找断头台技艺期间是一个替代选择。然而，它在命中某些首领时可能会有问题，因此并不总是像模拟结果暗示的那么强力。</p>&#10;</li>&#10;<li>[[item:251792@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:265657@JAACAAAMyA]]</li>&#10;<li>[[item:158374@JAACAAAOyA]]</li>&#10;<li>[[item:251785@JAACAAAMyA]]</li>&#10;<li>[[item:274493@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274497@JAACAAAMyA]]</li>&#10;<li>[[item:251784@JAACAAAMyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:246304@JAAIAAwt1ENMMYDH2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>制造饰品详情</em></span>&#10;<span>&#10;		   虽然这些饰品选项并不 <em>差</em>，但第二赛季的装饰比以前更强了。这意味着使用它们的机会成本太高，它们比原本就已经落后的地位更加落后了。</span>&#10;</li>&#10;<li>[[item:246305@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246306@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246307@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:241340@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:251783@JAACAAAMyA]]</li>&#10;<li>[[item:274496@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚无核心与升腾毒石

第二赛季沿用了第一赛季推出的额外奖励骰系统，提供了一种获取重要装备的途径：

**[混沌虚空核心](<https://www.wowhead.com/currency=3418>)s** 可在完成终局地下城或击败团队副本首领后使用，从相应的掉落表中随机获得一件物品。一旦通过虚无核心骰获得过某件物品，它就不会再次出现。在第二赛季， **单** 虚无核心用于对地下城掉落进行掷骰 <em>或</em> 单个团队副本首领，获得相当于你每周宏伟宝库奖励装等的掉落。

每周可从 **奥琳·微光** 获得一个，该物品位于催化剂旁边，随12.1.5补丁发布后开放。此外，如果你解锁了总共三个奖励，也可以从宏伟宝库中选择一个虚无核心而非一件物品。

3.1.

#### 浩劫 恶魔猎手 推荐的虚空核心使用方法

你应该优先获取哪件物品，很大程度上取决于你已经拥有的装备、可通过 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)获得的物品，以及你目前已击杀的首领。虽然随着12.1.5补丁加入每周奖励，它们现在更容易获得，但从宏伟宝库中拿一个应被视为 <em>安慰奖</em> ，在没有更好选择的情况下。

关于 <em>以及</em> 当你确实拿到一个虚无核心后，应该在哪里使用它，答案很简单：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **第二赛季虚无核心用途**
1. **乌拉特克** （英雄/史诗） <em>浩劫 战利品专精</em>
   
   
   
   
   - [[item:270168@JAACAAAG2A]]
   - [[item:270175@JAACAAAG2A]]
   - [[item:268265@JAAGAAAG2MqNTpC]]
   - [[item:271875@JAAEAAAG2chN]]
2. **盘卷祭坛** （英雄/史诗） <em>浩劫 战利品专精</em>
   
   
   
   
   - [[item:268209@JAACAAAG2A]]
   - [[item:270173@JAACAAAG2A]]
3. **Kith'ix** （英雄/史诗） <em>浩劫 战利品专精</em>
   
   
   
   
   - [[item:281236@JAAEAAgNyEuN]]
   - [[item:281215@JAACAAAOyA]]

:::

:::details 常见问题：我何时应该考虑从宏伟宝库中选择虚无核心？
随着赛季推进，虚无核心更容易获得，推荐也更加具体。虽然你现在拥有更多掷骰机会，但仍需记住一些可能让你觉得拿一个不太划算的情况：

- 如果你尚未解锁你的四件套效果，获取它应优先考虑。
- 如果 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 或 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
  中的关键追求装备被提供，就选它。
- 留意早期史诗难度首领击杀掉落的关键单品（例如来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)），因为它们以6/6神话难度提供，可以节省纹章并免去额外拾取的需要。

对于浩劫来说，最后两个首领掉落的物品非常强力，以至于除了获取你的套装加成外，即使英雄难度版本也值得额外拾取以获得其独特的战利品。这对 <em>尤其是</em> 也适用，
[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)其战利品池中没有差的物品。

:::

3.2.

#### 晋升毒液石

随着12.1.5补丁发布，你现在可以获取 [[item:280562]]，允许你将特定装备栏位一直升级到装等340（制造装备为338）。使用这些的优先级与你的纹章使用类似：

1. **主手武器** 始终优先。
2. **饰品** 其次和第三。
3. **副手武器** 第四位。
4. **项链** 最后。

你还希望优先选择神话难度物品而非英雄难度装备，除非你预计无法获得你正在升级的装备的神话难度版本。例外情况是从剧毒深渊的乌拉特克掉落的最难获取的物品之一 – [[item:270168@JAACAAgNyA]]。由于这是浩劫一个极其强大的主动饰品选择，且没有更容易获取的替代品，即使在较低的难度轨道上也值得投资。

1.

### 浩劫 恶魔猎手 最佳制造物品

制造装备提供了在赛季中获取高价值物品最简单的方式之一，让你能够定向获取关键装备来完善你的配装。随着第二赛季发布，每次制造需要两个 [[item:274476]]。

除非物品已分配副属性，否则你应该在制造时使用[[item:245789]]来获得暴击和精通。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_green.jpg>) **浩劫 制造订单**
**[[item:237840@JAAMAAwt1ENMMYzy1clIcYD]]**

➜

**[[item:244576@JAAKAAwt1ENMMYDYwclI]]**

➜

**可选制造**

:::

- 首先制造一把 **武器**，因为它在早期影响最大。战刃最佳，因为它允许你切换专精。为你的第一个美化附上[[item:273060]]。
- 制造 **一个非核心部位的第二个** – 我们推荐手腕部位的[[item:244576@JAAKAAwt1ENMMYDYwclI]]。为你的第二个美化附上[[item:240167]]。
- 之后，根据你当前装备的空缺来制造物品。

:::details 常见问题：第二赛季的新装饰好吗？
**有些**。在第二赛季发布前，许多装饰被削弱了，这在12.1.5补丁中并未改变：

- [[item:273060]]是更好的[[item:245876]]，使其成为最佳武器美化。
- [[item:273069]]提供叠加的急速触发。其价值接近[[item:240167]]，但落后足够多，考虑到后者还能增益队友，因此无法证明其合理性。
- [[item:273066]] 遭到了 <em>巨大的</em> 削弱，所以虽然它通常完美契合浩劫，但它太弱了，不值得使用。
- [[item:270899]]也遭到了大幅削弱，所以即使有浩劫通过[[spell:388118]]对法术触发效果造成的额外伤害，它仍然不值得使用。

:::

一旦你完成了两个主要的美化制造，你就有了一个稳固的配置。在进一步优化装备时，你的优先事项应该是制造高物品等级的物品来填补装备空缺。好的候选是珠宝首饰，虽然有独特的强力选择，但它们通常是 <em>极</em>
竞争激烈。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

1.

### 纹章使用

赛季初期，或者如果你刚开始玩一个副角色，你获得升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 以提升装等）的机会有限。纹章每周上限为100个，升级无论哪个栏位都花费20个纹章。因此，你应该优先将这些纹章用在你短期内不打算更换的物品上，或者能提供更大属性收益的特定栏位：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_121_crest_myth.jpg>) **浩劫 恶魔猎手 纹章升级优先级**
**武器（主手）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些不是唯一值得升级的物品。它们只是在赛季初期、你的升级货币有限时能提供最高DPS收益的物品。注意例外情况是可能的，例如附带额外触发的特殊咒术物品，比如 [[item:268265@JAAGAAAG2MqNTpC]]。

5.1.

#### 为装备添加插槽

虽然所有戒指和项链默认带有一个插槽，但头盔、腰带和护腕栏位在掉落时作为奖励可以获得三个额外插槽。这些也可以使用 [[item:275707]] 消耗品手动添加，该消耗品可以用6个 [[item:258556]] 购买，这是宏伟宝库的保底货币。

使用这些时，最好将它们用在你预计永远不会替换的装备上。这意味着史诗级物品，或这些栏位中的任何制造装备，因为它们无法通过其他方式添加插槽。由于它们是非常有限的货币，如果你拥有这些，最好在使用前做好长期规划。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为12.1.5补丁和基斯伊克斯的加入更新。
- **2026年8月30日：** 根据模拟修复后更新了对毒怒之源强度的评估。
- **2026年8月24日：** 在装备变更后确认了配装，切换了武器附魔并扩展了关于早期制作优化的常见问题解答。
- **2026年8月19日：** 由于阿希尔班圣匣在线修正，添加了关于装备推荐不确定性的免责声明。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已根据12.0.7补丁使用孢子坠落装备进行更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月7日：** 添加了关于早期制作以优化破晓冠使用的常见问题解答说明。
- **2026年3月16日：** 已更新完整的第1赛季推荐。
- **2026年2月26日：** 根据 至暗之夜 发布和季前赛进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已为11.2.5版本更新，并加入了卡特尔代币推荐。
- **2025年8月28日：** 根据当前表现重新整理了饰品排名。
- **2025年8月14日：** 为第3赛季发布的饰品热修更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月24日：** 已更新以纳入D.I.S.C.的热修。
- **2025年6月15日：** 为11.1.7补丁更新，添加了D.I.S.C.腰带，并为双加里维克斯武器略微调整了毕业列表。
- **2025年5月12日：** 已为涡轮加速发布确认迪纳尔推荐。
- **2025年4月21日：** 已针对11.1.5版本进行审查，并添加了卡特尔代币部分。
- **2025年3月4日：** 调整了一些饰品排名以考虑近期变更。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月17日：** 已更新以突出热修后新戒指的强度。
- **2024年12月15日：** 已为11.0.7版本更新，加入希尔赛的项圈。
- **2024年10月21日：** 为11.0.5补丁审查，调整了推荐饰品。
- **2024年9月9日：** 已更新第1赛季毕业列表。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月21日：** 饰品推荐略有调整，但10.2.6补丁的内容保持不变。
- **2024年1月15日：** 已针对10.2.5补丁进行审阅，将 烬魄之灰 列为备选方案。
- **2023年11月27日：** 将占卜加入理想饰品列表。
- **2023年11月7日：** 已更新以移除孢子披风的推荐，改为推荐蓝色丝线/剧毒荆棘选项。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 添加了10.1.7补丁的毕业装备列表并重构了页面。
- **2023年7月10日：** 已针对10.1.5补丁进行更新，清理了饰品和专业制造部分，并添加了永恒黎明物品。
- **2023年5月25日：** 添加了时光漫游部分，清理了原有的饰品推荐。
- **2023年5月9日：** 已针对饰品变更进行更新。
- **2023年5月1日：** 已为10.1版本和第2赛季的发布更新，加入新的装备推荐。
- **2023年3月24日：** 已根据原始宝石的在线修复更新。
- **2023年3月22日：** 已更新以考虑原始宝石的增益。
- **2023年3月20日：** 已针对10.0.7补丁进行更新，添加了永恒之戒的信息。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月11日：** 更新为装备页面格式。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已针对巨龙时代前夕进行更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的浩劫 恶魔猎手的最佳属性优先级。我们首先介绍属性优先级，然后深入解释这些属性如何与你的专精和游戏玩法互动。我们的内容已根据魔兽世界12.1.5补丁更新。

1.

### 浩劫 恶魔猎手 属性优先级

欢迎来到我们的浩劫 恶魔猎手在至暗之夜资料片中的属性优先级页面！在这里，我们将快速介绍你应该在装备上追求的属性，以及根据你的构建需要考虑的任何特殊情况。

浩劫在英雄天赋或目标数量之间没有显著变化，因此可以安全地为两者使用相似的装备配置。浩劫 <em>通常</em> 具有以下属性优先级：

敏捷

暴击

精通

急速

全能

在至暗之夜中，属性压缩后敏捷的收益大幅提升，这意味着你的大多数配装决策再次由物品等级驱动。

[[spell:388118]]由于其提供的额外乘数以及与触发效果的配合，保持暴击为核心。它也是你理想中希望你的[[item:241288]]在使用时提供的属性。精通是浩劫大部分最强技能的另一个强大乘数，因此其价值通常非常接近。一般来说，你希望尽可能多地堆叠这两种属性。

由于[[spell:203555]]增强带来的资源收益，急速在第2赛季有了很大改善，但仍略逊于上述两个选择。

全能排在最后，虽然它提供了一些防御性收益，但明显不如其他三个选择。此外，在第2赛季，随着剧毒诅咒物品在[[item:241288]]之上的加入，保持它尽可能低是有益的，因为它不能低于零。这绕过了这些触发效果的缺点，使它们更加强大。

:::details 常见问题：天赋“知己知彼”会影响饰品吗？
**是的**

.

[[spell:388118]]

影响

<em>一切</em>

，所以饰品触发、法术触发效果和美化都能从其暴击伤害乘数中受益。因此，无论你的装备选择如何，它都保持了该属性的高价值。

:::

1.

### 深入属性解析

作为浩劫 恶魔猎手， **敏捷** 是你的主属性，意味着你希望在所有可能的装备上都有它。各个属性提供以下收益：

- **敏捷**：为你提供攻击强度，增加你的浩劫技能和近战攻击的伤害。
- **暴击**：提高你攻击暴击的几率，造成双倍伤害。此外：
  
  
  
  
  - 浩劫有具有特定 <em>额外</em> 会随暴击加成，包括[[spell:320413]]和[[spell:388107]]。
  - [[spell:388118]]还会以固定比例将暴击几率转化为暴击伤害加成，基于装备提升基础的200%倍率。
- **精通**：通过[[spell:185164]]提高你造成的所有混沌伤害。此外：
  
  
  
  
  - 同时通过[[spell:320654]]提高你的基础移动速度。
  - 某些天赋会将非混沌技能转化为混沌伤害，使其受到精通效果的影响。重要示例包括[[spell:206416]]、[[spell:427775]]和[[spell:388106]]。
- **急速**：提高你的自动攻击速度，通过[[spell:203555]]增加狂怒的获取。此外：
  
  
  
  
  - 将你的全局冷却时间缩短至最低0.75秒。
  - 缩短[[spell:188499]]、[[spell:258920]]和[[spell:185123]]的冷却时间。
- **全能**：以固定数值提升你造成的所有伤害和治疗（包括饰品和触发效果）。此外，使你受到的所有伤害降低该数值的一半。

2.1.

#### 属性递减收益

每种属性都有一个收益递减点，超过该点后每点属性带来的提升会减少。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对第1赛季发布进行审查。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对11.0.5补丁更新，以区分 邪痕枭雄 和 奥达奇收割者 的权重。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审阅，添加了暴击即使在收益递减期间依然优秀的说明。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行审阅，在单体目标中提升了急速的优先级。
- **2023年5月1日：** 已针对10.1补丁进行更新，无需重大更改。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月31日：** 提升了单体目标中精通的优先级。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已针对巨龙时代前夕进行更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的浩劫恶魔猎手可以获取的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

所有内容推荐的宝石为：

- 在你的第一个插槽中使用[[item:240983]]。
  
  
  
  
  - 在其他插槽中使用[[item:240908]]。
- 由于 **5个及以上插槽**，切换为[[item:240967]]。
  
  
  
  
  - 每种颜色使用一颗以最大化加成——[[item:240898]]、[[item:240908]]、[[item:240890]]和[[item:240914]]。

根据你的属性配比，插槽通常是弥补装备差距的最佳选择。由于精通和暴击对浩劫来说非常接近，我们建议对你的角色进行模拟，看看两者中哪一个更值得在宝石上侧重。

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td><strong>主手</strong></td>&#10;<td>&#10;<ul>&#10;<li>&#10;[[item:273072]]<br/>&#10;   使用[[item:243733]]&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>副手</strong></td>&#10;<td>&#10;<ul>&#10;<li>&#10;[[item:273072]]<br/>&#10;   使用[[item:243733]]&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>头部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>护肩</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>胸部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>腿部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>靴子</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>戒指</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

头盔、肩膀和靴子的附魔取决于个人喜好，因为它们对性能没有直接影响，但我们建议所有插槽都选择闪避附魔以获得额外的生存能力。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

根据你角色的属性，你的合剂选择有两个选项：

- [[item:241326]]——提供暴击。通常是最优选择。
- [[item:241322]]——提供精通，如果你的装备严重缺乏精通的话。

你也可以从炼金术士提供的 [[item:241319]] 获得你选择的合剂。

3.2.

#### 药水

[[item:241288]]是你最好的选择，前提是你能使其提供暴击。始终将它们与[[spell:2825]]/[[spell:32182]]配合[[spell:191427]]一起使用。你也可以从炼金师提供的[[item:241285]]中获得[[item:245902]]。

关于[[item:241292]]的一点说明是，虽然它在技术上更强，但它生成的虚空区域会使你平静。在其中只需1-2个GCD就能抵消额外的收益，所以通常不值得。

[[item:271883]]是目前最好的治疗药水。使用后有5分钟冷却时间，但如果首领战持续足够长，可以消耗多个。此外，术士的[[item:5512]]与其他治疗消耗品不共享冷却时间。如果你持有一个，记得也要使用它！

3.3.

#### 食物增益

敏捷在第2赛季仍然是最强的属性，所以如果可能的话，你应该吃[[item:255845]]或其他主属性大餐。如果团队没有提供，就改用[[item:242275]]个人食物。

3.4.

#### 强化符文

此外，如果负担得起，你应该使用[[item:259085]]来提升你的主属性。记住：强化符文价格昂贵且死亡后消失，所以明智地使用它们！

3.5.

#### 其他消耗品

除了标准的增益消耗品外，还有少数其他物品值得保留——尤其是在大秘境中：

- [[item:188152]]——让你自动与附近的术士[[spell:111771]]互动。
- [[item:244639]]——使用时为你的小队提供较弱的15%急速[[spell:2825]]效果。这些仍会受到[[spell:57724]]的影响，所以只应在你没有小队成员自然提供该效果时使用。
- [[item:269586]] —— 可以对你的目标用作战斗复活，并且 <em>不会</em> 需要工程学。
- [[item:241303]]——至暗之夜的隐身药水，可用于在大秘境中跳过某些小怪战斗。请注意，这 <em>确实</em>
  与你的进攻药水[[item:241288]]共享冷却时间。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月30日：** 切换为双哈希之誓——非常接近但更容易融入装备搭配。
- **2026年8月24日：** 由于项链变更鼓励更多暴击，切换为双贾纳莱的精准。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月7日：** 将戒指附魔推荐调整为鹰眼。
- **2026年3月16日：** 已为第1赛季更新——为大秘境增加了茶饮和额外的消耗品。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月28日：** 由于回响虚空的持续错误，修改了腐蚀推荐。
- **2025年5月12日：** 已根据腐蚀调整进行更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 为11.0.5补丁审查，切换为精通推荐。
- **2024年9月9日：** 添加了关于亵渎尖晶石的说明。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，无需更改。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行更新，添加了飘渺虔诚的说明并建议不要使用永恒之戒。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月24日：** 已根据原始宝石的在线修复更新。
- **2023年3月22日：** 已根据原始宝石的增益效果更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月31日：** 武器附魔推荐改为睿智的虔诚。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已针对巨龙时代前夕进行更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的浩劫恶魔猎手挑战史诗钥石地下城的技巧和建议。

1.

### 浩劫恶魔猎手在至暗之夜第2赛季的史诗钥石地下城中

在本页中，我们将介绍如何在史诗钥石地下城中充分发挥你的浩劫恶魔猎手的实力，包括最佳天赋构建、你需要了解的任何循环变化，以及在钥石中脱颖而出的技巧和窍门。

如果你不熟悉大秘境及其相关的一般机制，你可以在下面我们专门的大秘境页面上了解更多信息。你也可以在我们的层级列表页面上了解更多关于大秘境环境的内容。

浩劫恶魔猎手在史诗钥石地下城中拥有出色的输出能力，其每棵英雄天赋树都专精于两种最受欢迎的伤害类型之一。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄每20秒提供一次高爆发范围伤害，在你的[[spell:191427]]施放期间每两分钟变得更强。另一方面， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者通过[[spell:442806]]提供强大的单体聚焦伤害，使其能够快速集火优先目标。再加上强大的防御工具和一些普遍有用的实用技能，它创造了一个全面的史诗钥石专精。

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄推荐选择

2.1.

#### 浩劫恶魔猎手史诗钥石构建—— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄在至暗之夜第2赛季中仍然是一个可靠的全能选择，带来强大而稳定的爆发范围伤害。通过[[spell:213410]]触发的[[spell:452402]]每20秒一次的节奏与大多数地下城路线配合良好，同时还有[[spell:191427]]的额外优势，可以在危险的拉怪中倾泻威力。由于其大多数工具在单体和范围伤害之间灵活切换，当被迫应对首领战时，它仍然能发挥出色的作用。

2.1.1.

##### 天赋更换选项

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄有几个替换选项需要记住：

- **移动天赋——** 虽然[[spell:389688]]和[[spell:206476]]都通过在循环中引入移动天赋来增加复杂性，但它们提供了
  <em>极</em> 很高的价值，并使狂怒更加流畅。如果你真的难以利用它们，可以将两者都替换为[[spell:389978]]。
- [[spell:342817]]给狂怒管理增加了一些压力，但范围伤害通常是值得的。它可以替换为[[spell:389978]]或[[spell:389693]]，但会造成巨大损失。
- 如果你需要更多的总体续航而不是一点减伤，[[spell:452406]]可以替换为[[spell:452407]]。
- [[spell:1266496]]和[[spell:1266316]]都是根据地下城而定的特定情况工具。根据是否存在诅咒或疾病选择相应的选项。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 史诗钥石/范围伤害——邪痕枭雄
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJOhACEGOoqqsMkiMpxxRSWSsNC-AAAA-BeERhphowYJQ4A-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者高层钥石替代方案

2.2.

#### 浩劫恶魔猎手高层钥石构建—— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者

在第2赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者以及 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄之间的差距小得多，这使得它们的伤害类型差异更加突出。[[spell:442806]]结合[[spell:1272153]]提供的单体聚焦伤害非常高，使其成为处理优先目标的专家。它的总体范围伤害较低，并且需要更高的操作要求来管理[[spell:442624]]，使其在一般钥石中成为一种不太通用的玩法。也就是说，在有组织的高端游戏中， <em>你对什么</em> 你造成的伤害往往比 <em>造成多少</em>伤害更重要，这最终可能成为某些阵容的选择。

2.2.1.

##### 天赋更换选项

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者有几个替换选项需要记住：

- [[spell:428492]]和[[spell:388116]]可以替换为像[[spell:258881]]和[[spell:342817]]这样的高价值范围伤害选择，但这些会削弱你单体聚焦伤害的价值。由于那是
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者的主要优势，所以通常不建议这样做。
- [[spell:442714]]可以替换为[[spell:442736]]以获得一些免费的吸收护盾，从而减轻为防御而把握[[spell:232893]]时机的压力。
- [[spell:1266496]]和[[spell:1266316]]都是根据地下城而定的特定情况工具。根据是否存在诅咒或疾病选择相应的选项。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 史诗钥石/范围伤害——奥达奇收割者
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxEGzMmxCAAAAAAAYmBYAAAAYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxEGzMmxCAAAAAAAYmBYAAAAYA"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJKOWhAOaako+MYiMpxxRSWsMzG-AAAA-GIOi0AEUowgCzC-
```

:::

1.

### 地下城天赋切换速查表

为了快速参考你的浩劫实用天赋的额外用途，请使用下面的工具选择一个地下城。在下方，相关选项将与它们所克制的内容一起高亮显示。

<table>&#10;<tr>&#10;<th colspan="2">地下城</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></td>&#10;</tr>&#10;</table>

基于上述选择，以下职业天赋有独特的用例：

![Consume Magic not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/consume.jpg>)**适用条件：纳洛拉克的洞穴（未启用）；密谋小径（未启用）；诸王之眠（未启用）；红玉新生法池（未启用）。**

![Consume Magic Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/consume.jpg>)**适用条件：纳洛拉克的洞穴（启用）；密谋小径（启用）；诸王之眠（启用）；红玉新生法池（启用）。**

‌

![Burn It Out not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/burnitout.jpg>)**适用条件：毒牙祭坛（未启用）；诸王之眠（未启用）。**

![Burn It Out Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/burnitout.jpg>)**适用条件：毒牙祭坛（启用）；诸王之眠（启用）。**

‌

![Soul Cleanse Not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/cleanse.jpg>)**适用条件：纳洛拉克的洞穴（未启用）；密谋小径（未启用）。**

![Soul Cleanse Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/cleanse.jpg>)**适用条件：纳洛拉克的洞穴（启用）；密谋小径（启用）。**

‌

![Vengeful Retreat Not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/retreat.jpg>)**适用条件：毒牙祭坛（未启用）；Blinding Vale（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；红玉新生法池（未启用）；虚空之痕竞技场（未启用）。**

![Vengeful Retreat Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/retreat.jpg>)**适用条件：毒牙祭坛（启用）；Blinding Vale（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）；虚空之痕竞技场（启用）。**

‌

- **适用条件：毒牙祭坛（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 清除 [[spell:1296069]]，在 **拉维** 首领战斗中。
  - 从 [[spell:1310974]] 中清除 **扭缠盘蛇**.
  - 从 [[spell:1294569]] 中清除 **双牙折磨者**.
- **适用条件：毒牙祭坛（启用）。** [[spell:1266316]]用途：
  
  
  
  
  - 驱散由施加的[[spell:1296069]] **拉维**.
- **适用条件：Blinding Vale（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 清除由施加的[[spell:1238084]] **鞭笞者** 如果你在近战中被击中。
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 清除由施加的[[spell:1309919]] **严寒殴斗者**.
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:278326]]用途：
  
  
  
  
  - 驱散 [[spell:1297696]]，来源： **地语看护者**.
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:1266496]]用途：
  
  
  
  
  - 驱散由召唤的雕像施加的 [[spell:1238760]] **猎人之魂**.
- **适用条件：诸王之眠（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 清除由施加的[[spell:1294815]] **复生巫师**.
  - 清除由施加的 [[spell:106823]] **帕特拉女王**.
  - 清除由施加的 [[spell:271563]] **防腐液**.
  - 清除由施加的 [[spell:12548]] **幽灵萨满祭司**.
- **适用条件：诸王之眠（启用）。** [[spell:278326]]用途：
  
  
  
  
  - 驱散 [[spell:269935]] 的激活效果，来源： **祖尔的爪牙**.
  - 驱散 [[spell:1296671]] 的施加效果，来源： **卫队长阿图**.
  - 驱散 [[spell:270901]]，来源： **总管姆巴拉**.
- **适用条件：诸王之眠（启用）。** [[spell:1266316]]用途：
  
  
  
  
  - 驱散由施加的[[spell:267763]] **未完成的木乃伊**.
  - <em>注意：</em> 虽然[[spell:1266496]]可以驱散来自的[[spell:269972]] **复生巫师** 但在这个节点上，这些施法应优先使用打断来处理，而不是用驱散来覆盖。你更有可能在这里存活下来并能够驱散疾病，使得[[spell:1266316]]成为更有价值的选择。
- **适用条件：密谋小径（启用）。** [[spell:278326]]用途：
  
  
  
  
  - 驱散 [[spell:1229433]] 的施加效果，来源： **恶棍法师**.
- **适用条件：密谋小径（启用）。** [[spell:1266496]]用途：
  
  
  
  
  - 驱散由施加的 [[spell:1217973]] **被腐化的术士**.
- **适用条件：红玉新生法池（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 从 [[spell:373803]] 中清除 **灌能雏龙** 如果你在近战中被击中。
- **适用条件：红玉新生法池（启用）。** [[spell:278326]]用途：
  
  
  
  
  - 驱散 [[spell:373973]] 的施加效果，来源： **灰烬先知燃鞭者** 在低血量时。
  - 驱散 [[spell:391031]] 的激活效果，来源： **原始雷云**.
- **适用条件：塞塔里斯神庙（启用）。** 当前 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>) 没有通过天赋替换获得的驱散实用用途。
- **适用条件：虚空之痕竞技场（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 在 [[spell:1263982]] 层数中清除 **煞戎努斯** 首领战斗中。
  - 清除由施加的[[spell:1249621]] **愤怒的克洛斯克**.

1.

### 功能技能与能力

本节介绍浩劫可以利用的关键天赋和技能，这些可以在史诗钥石场景中发挥作用。

### 控制

4.1.

#### 打断与控制

浩劫拥有多种阻止敌人施法的工具。由于用途不同，我们将它们分为单体情况的工具和更适合范围伤害的工具。

4.1.1.

##### 单体控制

[[spell:183752]]是浩劫的打断技能，冷却时间为15秒。应积极使用它来阻止危险的敌人施法（参见我们的瓦解宏，在 [浩劫恶魔猎手宏页面上的](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)).

[[spell:217832]]是一个45秒冷却时间的硬控制，但会因受到伤害而解除。它可以用作战斗中的打断，或者锁定你想要跳过的目标。禁锢的独特之处在于，受其影响的敌人在你或你的队伍跑过时不会进入战斗。

4.1.2.

##### 群体控制

[[spell:179057]]是浩劫的范围眩晕工具，使附近目标眩晕3秒。冷却时间为45秒，消耗25点狂怒。它非常适合打断大群敌人，由于其瞬时启动，当多个目标同时施法时，它可以成为强力的范围打断。在点出[[spell:1266296]]后，它还会将当前目标的眩晕延长至5秒，使其成为更好的锁定工具。

[[spell:207684]]是一个冷却时间为2分钟（点出[[spell:320418]]后减少至1.5分钟）的范围迷惑，在2秒延迟后迷惑范围内的目标15秒。该效果会因受到伤害而解除，延迟意味着它需要很好地把握时机才能用作范围打断。它也可以用来跳怪，因为受影响的敌人不会攻击队友（但会攻击你），所以你需要一种脱离战斗的方法，比如在你通过后使用[[spell:58984]]。

[[spell:191427]]可能是你的主要冷却技能，但施放时它也会眩晕影响区域内的敌人3秒。你不应该主要为此而使用它，但如果它已经就绪，你可以将其作为在拉怪开始时打断一群敌人的额外方式。

### 防御与自我治疗

4.2.

#### 防御与自我治疗

浩劫是最坚韧的近战专精之一，拥有主动和被动减伤工具的混合。它还带有一些被动自我治疗效果，即使在最前沿的钥石等级下也能为生存提供良好的基础。

4.2.1.

##### 减伤工具

[[spell:198589]]是浩劫的主要主动防御工具，在10秒内将受到的伤害降低25%，冷却时间为1分钟。在点出[[spell:1266307]]后，它获得一个额外的充能，而在点出[[spell:205411]]后，减伤效果提高到35%。由于拥有两个充能 <em>和</em> 和较短的冷却时间，它应被主动用于应对致命伤害或危险情况。

[[spell:427776]]在施放[[spell:210152]]/[[spell:188499]]期间提供一个护盾，吸收最多相当于你最大生命值15%的伤害。它的持续时间非常短暂，但允许你通过把握循环施法的时机来规避一些伤害事件。这是一个高操作上限的工具，非常适合应对秒杀机制。

[[spell:205411]]还会在生命值低于35%时被动降低你受到的伤害。这也适用于会将你打到 <em>详细说明</em> 该阈值以下的伤害事件，为你提供更多被动承受致命攻击的空间。

[[spell:1266329]]在使用[[spell:183752]]成功打断后，使你在12秒内受到的所有魔法伤害降低15%。由于在史诗钥石地下城中你应该频繁打断，这是一个出色的防御工具。

[[spell:196718]]提供15%的几率（在地下城中提高到30%）为你或站在范围内的队友闪避任何伤害事件。持续8秒，冷却时间5分钟。持续时间可通过[[spell:389781]]延长至11秒，或者冷却时间可通过[[spell:389783]]缩短至3分钟。对团队生存很有帮助的额外效果， <em>尤其是</em>
对抗重复的伤害事件（如持续伤害），帮助你的治疗者跟上。由于冷却时间较长，你应该提前计划何时部署它。

[[spell:442714]]，专属于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者，在施放[[spell:232893]]后提供5秒内10%的减伤。这是一个不错的额外好处，也可以把握时机来应对危险的机制。在至暗之夜中，邪能之刃的可用频率较低，所以不像以前那么强了。但请记住，如果你使用[[spell:444931]]，你总是可以强制触发它。

4.2.2.

##### 自我治疗

[[spell:204909]]提供 <em>大量</em> 自我治疗，始终提供10%的吸血，在[[spell:191427]]期间提高到20%。这已经提供了大量的续航，但它在冷却期间提供的额外稳定性意味着浩劫由于其自给自足的特性，在大拉怪中通常可以更加激进。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) 邪痕枭雄在使用[[spell:452407]]时还可以分别将此提高2%和4%。

[[spell:1227619]]结合[[spell:206478]]在战斗中产生持续的灵魂碎片流，为你恢复少量生命值。当敌人被击杀时产生的大型灵魂碎片恢复的生命值要多得多，使浩劫在钥石期间拥有出色的自给自足能力。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) 奥达奇收割者还会产生多得多的灵魂，为其提供额外的被动续航，这可以通过[[spell:442736]]来增强，同时提供吸收护盾。

在12.1补丁中加入的[[spell:427794]]也有一些次要的防御好处，在生命值低于50%时将吸血提高5%。理想情况下，你不会在这个阈值以下停留太久，因为它会降低你的伤害，但它有助于你摆脱糟糕的局面。

### 其他功能

4.3.

#### 其他功能

[[spell:328725]]在被你的[[spell:188499]]/[[spell:210152]]击中后，使敌人受到的治疗效果降低50%，持续6秒。虽然用途特定，但通过削减敌人获得的治疗量，它能提供大量有效伤害，并且在范围伤害中容易施加。

[[spell:255260]]是浩劫被带去打团本的最强理由，在史诗钥石地下城中也是如此。 <em>根据团队阵容</em>，这会非常有利，因为游戏中有大量职业目前至少 <em>一些</em> 造成魔法伤害供其放大。这通常会在你自己造成的伤害之外，额外提供可观的伤害。

[[spell:278326]] 是 浩劫 的进攻性驱散技能，冷却时间为10秒。其优势在于射程为30码，可用于移除敌方目标身上的增益效果。不过它的冷却时间意味着你必须谨慎选择驱散目标，尤其是在多个敌人同时拥有增益效果时。

[[spell:198793]] 虽然用途有限，但在施放时可以打破定身效果。这在某些地下城中会很有用。

[[spell:1266496]] / [[spell:1266316]] 使你可以将 [[spell:258920]] 作为自我驱散使用。前者移除诅咒，后者移除疾病，因此你应该根据所进行的地下城来选择该天赋节点。

1.

### 应对词缀

本节包含应对大秘境第2赛季每周萨拉塔斯主题词缀的快速提示。

### 词缀：升腾

5.1.

#### 浩劫 恶魔猎手 升腾词缀应对

**萨拉塔斯的交易：升腾** 会定期生成一波波的光球，需要以某种方式对其进行群体控制，阻止它们完成施法。每成功阻止一个光球，团队就会获得急速加成，因此处理它们是高度优先事项。

浩劫 可以且应该利用 [[spell:179057]] 和 [[spell:207684]] 来阻止一波怪，同时还有 [[spell:183752]] 可以在你的队伍难以清理所有怪物时用来捕捉漏网之鱼。

### 词缀：虚缚

5.2.

#### 浩劫 恶魔猎手 虚空绑定词缀应对

**萨拉塔斯的交易：虚缚** 会周期性地召唤一个大型的虚空大使，它将开始施放[[spell:462508]]。这个敌人 **必须** 在施法完成前被击杀以阻止它，否则它会为附近的敌人提供显著的减伤。如果成功阻止，队伍将获得大量的全能和冷却缩减。

这个需要快速击杀，所以理想情况下，在它刷新时要准备好像 [[spell:198013]] 或 [[spell:370965]] 这样的短时间爆发冷却技能。然而这并非总是可行，因为它们是你AoE循环的关键，所以只需留意它们出现的时间并相应切换目标即可。

### 词缀：脉冲星

5.3.

#### 浩劫 恶魔猎手 脉冲星词缀应对

**萨拉塔斯的交易：脉冲星** 会生成一个围绕每个玩家旋转的光球，需要由另一名玩家在光球消失前分担。每个光球将为队伍提供4%精通和2%吸血，可叠加，持续30秒。未被分担的光球会增加附近敌人的伤害输出，并降低他们受到的伤害。

浩劫 没有特定的应对手段。相反，你需要注意自己的站位，既要确保其他玩家能够吸收围绕你旋转的光球，也要能够接住附近玩家的光球。

### 词缀：吞噬

5.4.

#### 浩劫 恶魔猎手 吞噬词缀应对

**萨拉塔斯的交易：吞噬** 会对每名队伍成员施加一个减益效果，必须通过驱散或治疗来消除（但请注意这 <em>不会</em>
吸收即将到来的治疗）。每驱散一个减益效果都会为队伍提供最大生命值和暴击，可叠加，持续30秒。任何被 <em>非</em>
清除的减益效果都会为附近的敌人恢复大量生命值。

[[spell:1266316]] 和 [[spell:1266496]] 都可以在此处使用以立即移除减益效果。此外，[[spell:198793]] 也能移除该减益效果，因为在 至暗之夜 中它现在还会施加一个轻微减速效果。如果你没有这些技能可用，或者 [[spell:258920]] 没有充能，在治疗者跟不上时请使用治疗石/治疗药水。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月28日：** 添加了大秘境实用天赋速查表，涵盖各副本中的使用场景。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月28日：** 添加了各个副本的提示。
- **2025年4月21日：** 为11.1.5补丁审查——由于执行简便，将奥达奇AoE配装移回低移动选项。
- **2025年3月4日：** 暂时为 奥达奇收割者 配装添加了惯性。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7版本进行审查，添加了推荐标签。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为地心之战第1赛季的发布进行更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月21日：** 已针对10.2.6补丁进行审阅，推荐配装方案调整为战刃风暴，其余无变化。
- **2024年1月15日：** 已针对第3赛季中期的信息进行审阅和调整。
- **2023年11月9日：** 已为10.2版本重构并更新。
- **2023年11月6日：** 已更新大秘境中心的链接。
- **2023年9月4日：** 已针对10.1.7补丁进行更新，添加了战刃风暴/怒火配装方案，并将其改为推荐选择。
- **2023年7月10日：** 已针对10.1.5补丁进行审阅，无需更改。
- **2023年5月1日：** 已针对10.1补丁进行更新，添加了关于新词缀的详细信息，配装方案保持不变。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月27日：** 添加了一个额外的、侧重单体目标的配装方案。
- **2022年10月24日：** 已针对巨龙时代前夕进行更新。

显示更多

显示更少

:::

## 宏与插件

在本页面中，你将找到一些实用的宏命令和插件，帮助你在《魔兽世界》12.1.5版本中更轻松地游玩你的 浩劫 恶魔猎手。

1.

### 最佳宏

欢迎来到我们的插件与宏命令页面。在这里，我们将介绍一些有用的插件，你可以通过更信息丰富的界面来提升游戏体验，同时提供一些常用的 浩劫 恶魔猎手 宏命令。

1.

### 浩劫 恶魔猎手 宏命令

宏命令可以通过游戏内的/macro命令访问，允许你创建在按下快捷键时执行的小型脚本。这对于将多个动作组合在一起非常有用，一个常见的例子是将不占用GCD的饰品与冷却技能组合在一次按键中使用。

2.1.

#### 瓦解 焦点打断宏

#### 焦点打断

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] 瓦解
```

此宏会停止你当前的施法，并在焦点目标可用时对其施放 [[spell:183752]]；否则将对你的目标施放（更多关于 瓦解 的信息请见我们的 [法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)).

2.2.

#### 吞噬魔法

#### 焦点驱散

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] 吞噬魔法
```

此宏会停止你当前的施法，并在焦点目标可用时对其施放 [[spell:278326]]，否则将对你的目标施放（更多关于吞噬魔法的信息请见我们的 [法术页面](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)).

2.3.

#### 悲苦咒符 目标选择宏

[[spell:207684]] 可以被修改为瞬发施放，无需使用目标选择圈并省去一次输入操作。这可以通过两种不同的方式实现，以下是在你的鼠标光标处放置它的方式：

#### 光标处符咒

```wow-macro
#showtooltip
/stopcasting
/cast [@cursor] 悲苦咒符
```

或者，如果你已经站位良好，可以在自己脚下施放：

#### 自身处符咒

```wow-macro
#showtooltip
/stopcasting
/cast [@player] 悲苦咒符
```

2.4.

#### 恶魔变形宏

类似地，你可以将 [[spell:191427]] 设置为以同样的方式施放，以便在需要时瞬发进入恶魔变形，以下是在你的光标处落地：

#### 光标处变形

```wow-macro
#showtooltip
/stopcasting
/cast [@cursor] 恶魔变形
```

或者在你当前站立的位置：

#### 自身处变形

```wow-macro
#showtooltip
/stopcasting
/cast [@player] 恶魔变形
```

1.

### 最佳插件

3.1.

#### 恶魔猎手 通用插件

你的大部分界面需求可以通过至暗之夜中新的暴风雪界面选项在一定程度上得到满足，但如果你想要一些额外的自定义，以下是一些热门选择。

3.1.1.

##### 首领模块插件：Deadly Boss Mods 或 Bigwigs

首领模块插件会警告你首领的技能，并就如何处理某些机制提供实时建议。我们强烈建议你安装这样一个插件。在Icy Veins，我们主要使用
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>)，这是最受欢迎的首领模块插件。一个不错的替代选择是
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

3.2.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) 是对默认用户界面的完整替代。它包含了你正常发挥所需的几乎所有功能：动作条、单位框体、冷却计时器、触发提示等。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对第1赛季发布进行审查。
- **2026年2月26日：** 为 至暗之夜 发布更新，包含复制元素。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，无需更改。
- **2023年11月6日：** 已针对10.2补丁进行检查，无需更改。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行审阅，无需更改。
- **2023年4月29日：** 已根据10.1补丁审查，无需更改。
- **2023年3月20日：** 已根据10.0.7补丁审查并更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月24日：** 已针对巨龙时代前夕进行更新。

显示更多

显示更少

:::
