## 专精概览

Welcome to our Retribution Paladin guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Retribution Paladin in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Retribution Mythic+ Resources

[NEW! Top Retribution Talent Builds](<https://raider.io/specs/retribution-paladin/talents>)

[Top Retribution Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/paladin/retribution>)

[Retribution Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=paladin--retribution>)

[Popular Retribution Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=paladin--retribution>)

1.

### Retribution Paladin Overview

Retribution is the melee DPS spec of Paladin. It can use the wide 
array of utility options that Paladin is known for,
including its sought-after Auras, along with some incredibly strong defensive 
and healing abilities. Retribution is one of the most popular specs in the game
due to its strong class fantasy and good all-round utility toolkit.

Solid Throughput

Retribution has very short cooldowns for burst, with

[[spell:255937]]

being a 30-second CD and

[[spell:384376]]

a 60-second one.
There is also reasonable flexibility between builds that either have more 30 or 60-second emphasis.
This allows you to have cooldowns for practically any damage window or new pack of enemies, with the majority of the damage
being dealt in the first few seconds. Retribution also has a considerable amount of
passive cleave in its burst windows, as most of its important cooldowns deal AoE damage.
Overall, it does solid damage relative to other classes in most situations.

Decent Capabilities

Retribution has reasonable raid viability. As a Paladin it can bring a useful raid buff in

[[spell:465]]

, although other Paladin specializations tend to be favoured for that role.
Its damage profile is solid for raids, where it has excellent passive cleave in burst cooldowns,
loses little damage to swap targets, and is able to take AoE talent builds without losing much single-target.

Consistent Cooldowns

Retribution is a solid performer in Mythic+, with its short cooldowns being a nice bonus here. Being able
to have burst damage for every new pack of enemies you fight is a great asset.
Retribution's talents allow you to run builds that will not require any severe trade-offs between
single-target and AoE either, while still allowing you to make adjustments for more single-target damage if necessary.

Many Options, Niche Uses

Retribution has access to a lot of utility abilities, like

[[spell:1022]]

,

[[spell:1044]]

,

[[spell:6940]]

, and

[[spell:633]]

. However,
the usefulness of these depends a lot on the content - in Mythic+, these are strong options that have
a lot of possible applications, but in Raids they tend to be much less useful. In the cases where Paladin utility
is sought after, Retribution is rarely considered the best option to bring for utility,
since you do not have access to strong abilities that other Paladin specializations do in PvE, such as

[[spell:204018]]

.

Solid Durability

Retribution has a decent number of damage reduction and healing tools, such as

[[spell:403876]]

,

[[spell:184662]]

, and

[[spell:633]]

, in addition to a full immunity with

[[spell:642]]

.
This gives you tools to deal with most mechanics, but since our passive damage reduction and healing is either situational or relatively weak,
playing Retribution will still require you to fully use all available abilities
in more difficult content.

Good Enough

Retribution's mobility is essentially just one ability,

[[spell:190784]]

. This is good enough for most situations
that require regular movement speed bursts, but it definitely leaves something to be desired. For example,
Retribution is the only melee DPS that cannot deal with repeated knockback effects without external help. Retribution does have a lot more
ranged abilities than other melee though, which mitigates this weakness a little, as
you can still deal damage while out of melee range of bosses.

2.

### Retribution Paladin in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1 brings a new raid with The Unbinding of Kith'ix, a new extra large 
Delve, and more options for gear upgrades and bonus rolls. For more information on these two
new pieces of PvE Content, make sure to check out our dedicated guides.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

Patch 12.1.5 brings a new one-boss Raid with new BiS items, and a new upgrade 
system for items with [[item:280562]]. There are also a bunch of new
quality of life improvements, new Invasions, and a variety of other changes that you
might be interested in.

2.3.

#### Class Changes

Retribution Paladin received no changes with Patch 12.1.5. :(

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_bladeofjustice.jpg>) Click for Previous Season 2 Changes
2.4.

#### Class Changes

Retribution received a lot of changes with patch 12.1, mostly adjusting damage away from cooldowns 
and towards sustained damage, as well as a couple of quality of life adjustments.

- [[spell:1261113]] now allows [[spell:267344]] and [[spell:402912]] to each stack an additional time.
- [[spell:267344]] now increases [[spell:184575]] damage by 80% (was 150%).
- [[spell:184575]] damage increased by 40%.
- [[spell:383327]] damage increased by 15%.
- [[spell:53385]] damage increased by 39%.
- [[spell:384376]] now increases damage done and critical strike chance by 15% (was 20%).
- [[spell:406646]] damage increased by 50%.
- [[spell:406647]] damage increased by 50%.
- [[spell:20271]] damage increased by 50%.
- [[spell:24275]] damage increased by 50%.
- [[spell:375576]] [[spell:20271]]s now deals 50% increased damage (was 100%).
- [[spell:1261159]] damage reduced by 25%.
- [[spell:19750]] healing increased by 25%.
- [[spell:85673]] healing increased by 25%.
- [[spell:156322]] healing increased by 25%.
- [[spell:267344]] no longer activates from additional Skyfury attacks.
- Additional Skyfury attacks no longer generate Holy Power when talented into [[spell:404542]].
- [[spell:404542]] now increases auto-attack speed by 15% (was decreasing by 20%).
- [[spell:343527]] area of effect radius increased to 10 yards and now includes the bounding radius of the target (was 8 yards).
- [[spell:231663]] debuff now lasts for 18 seconds (was 15 seconds).
- [[spell:429826]] damage reduced by 30%.
- [[spell:429826]] now costs 3 Holy Power (was 5).

:::

### Midnight   Changes Overview

2.5.

#### Midnight Changes for Retribution Paladin

With the release of Midnight, Retribution received a complete 
rework of the structure of its spec talent tree, 
as well as many changes to talents, abilities, and Hero Talents. 
The major changes are broken down and explained in the sections below.

2.6.

#### Apex Talent

Retribution's new Apex Talent, [[spell:1261113]], is focused on [[spell:267344]] and [[spell:402912]], 
providing larger damage increases and extra effects when they proc. The bonus can be mostly treated as passive, but it is now best to prioritize spending procs 
in order to minimize the chance the bonus effects are wasted.

2.7.

#### Hero Talent Changes

Both Hero Talents have had some new talents added in Midnight, but they 
are both still very similar to how they worked previously.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar has had [[spell:198137]] added as a 
passive talent that triggers after [[spell:375576]] is cast. 
It has also had the talents buffing [[spell:431625]] nerfed 
a little, and some extra talents added mimicking some of the effects 
of the War Within Season 3 tier set.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun has had some new talents added with fairly 
basic passive effects. More importantly, it has had some redesigns 
to old effects so that 
[[spell:431377]] has much lower overall uptime, and the addition of 
[[spell:1263782]], which significantly increases the power 
of [[spell:24275]]. 
These changes put a lot more emphasis on [[spell:384376]] for 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun.

2.8.

#### Generator Changes

[[spell:24275]] has been removed as a separate ability. 
Instead, [[spell:20271]] is now upgraded into [[spell:24275]] 
during [[spell:384376]], 
and it inherits all of the buffs [[spell:20271]] gains from various 
talents and effects. [[spell:405278]] no longer increases the 
Holy Power that [[spell:20271]] provides. 
[[spell:404542]] has been changed to reduce attack speed, but 
now grants Holy Power with every hit instead and can work with 
[[spell:462854]]. 
[[spell:355098]] no longer automatically casts [[spell:20271]] 
periodically, but instead causes future casts to be cast twice. 
Overall, these changes slightly reduce the amount of Holy Power you can 
generate, but give you a bit more control over exactly how Holy Power is 
generated.

2.9.

#### Cooldown Changes

[[spell:458359]] has been nerfed and no longer can proc 
extra [[spell:384376]] duration. [[spell:384392]] has been 
redesigned to be an additional stacking Haste effect 
to [[spell:384376]] rather than replacing the flat damage 
and Critical Strike increases entirely. [[spell:343527]] 
has had the effects of Final Reckoning added to it, 
but is now a 60-second cooldown. Retribution now has a lot less focus 
on 30-second cooldown intervals, but has much more power for its 
1-minute cooldown windows.

3.

### Basics of Retribution Paladin Gameplay

Retribution gameplay revolves around managing your Holy Power and maximizing the cooldowns and GCDs of your abilities.
It can sometimes be reactive, but it is usually very helpful to plan your casts several spells ahead
in order to not accidentally waste Holy Power, especially during cooldowns.

There are two main options for different methods of Holy Power generation. [[spell:404542]] is generally more popular,
and it includes a lot more passive Holy Power generation but can sometimes have downtime in its rotation.
[[spell:406646]] is the alternative, which will generally have more control over its Holy Power generation, 
but is usually a bit weaker.

Retribution Paladin's rotation can be broken down into these three main concepts:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_malkorok_blightofyshaarj_yellow.jpg>) **Spend Holy Power**  
  
  Retribution's main resource is Holy Power, which you want to spend as often as possible. 
  Wasting Holy Power by continuing to cast abilities that generate it, while already 
  at 4 or 5 HP, will lose you a ton of damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_artofwar.jpg>) **Use Your Procs**  
   
  Procs like [[spell:267344]] are important to spend due to [[spell:1261159]]. 
  These don't always need to be spent instantly, but generally should be prioritized 
  to avoid accidentally wasting them.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_paladin_executionsentence.jpg>) **Utilize Cooldowns Properly**  
  
  Retribution has most of its damage concentrated in cooldown windows. As much as 
  using your abilities in the right sequence is important, knowing when to cast them 
  during a fight - such as holding them a few seconds for an important damage amp 
  or new wave of add spawns - can improve your damage a lot.

4.

### How to Gear Up as a Retribution Paladin

While we always recommend simming yourself for ideal results, we do provide a
dedicated Retribution gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **25 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for hotfixes.
- **25 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated enchant recommendations.
- **25 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated builds.
- **25 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for hotfixes.
- **25 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for hotfixes.
- **25 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for hotfixes.
- **25 Aug. 2026 (this page):** Updated for hotfixes.
- **11 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Patch 12.1.
- **11 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **11 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **11 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **11 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **11 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **11 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **11 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **11 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **11 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **11 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **23 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated recommendations.
- **23 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated explanations.
- **23 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated recommendations.
- **23 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated recommendations.
- **23 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated priority.
- **23 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated recommended raid talents.
- **23 Apr. 2026 (this page):** Updated change discussion.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **24 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated recommendations.
- **24 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated recommendations.
- **24 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated recommendations.
- **24 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated builds.
- **24 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated priority.
- **24 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated builds and added recommended raid talents.
- **24 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated builds.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for hotfixes.
- **17 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for hotfixes.
- **17 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for hotfixes.
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for hotfixes.
- **17 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for hotfixes.
- **17 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for hotfixes.
- **17 Mar. 2026 (this page):** Updated for hotfixes.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **05 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Added Midnight talent import.
- **05 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated gear and crafting recommendations.
- **05 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated enchant recommendations.
- **05 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated priority.
- **05 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated talent builds.
- **05 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated talent builds.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 (this page):** Updated for Midnight 12.0.1.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 (this page):** Updated for Midnight pre-patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **15 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated trinket recommendations.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **05 Jul. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated D.I.S.C. recommendations.
- **05 Jul. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** Updated builds.
- **05 Jul. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated builds.
- **05 Jul. 2025 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated builds.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **04 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** Updated builds.
- **03 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated gear recommendations.
- **03 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Added build details.
- **18 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** Updated tips.
- **03 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated discussion.
- **03 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated discussion.
- **03 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated builds.
- **27 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated gear recommendations.
- **27 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated priority.
- **27 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated talent discussion.
- **27 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated rotation section.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 11.1.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **01 Jan. 2025 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated trinket recommendations.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **08 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for hotfixes.
- **08 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for hotfixes.
- **08 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for hotfixes.
- **08 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for hotfixes.
- **25 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** Updated tips and builds.
- **25 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated dungeon tips.
- **25 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Added extra details for niche builds.
- **25 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Added extra builds.
- **25 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated builds.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for hotfixes.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for hotfixes.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for hotfixes.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **28 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated embellishment recommendations.
- **28 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Adjusted opener rotation.
- **28 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Added Delve build.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/retribution-paladin-the-war-within-pve-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/retribution-paladin-mists-of-pandaria-remix-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/retribution-paladin-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/retribution-paladin-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 (this page):** Updated for Dragonflight Season 4.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Updated for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **28 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Added the new Legendary and adjusted trinket recommendations.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Added BiS lists and overhauled page formatting for Patch 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated talent builds and ability discussion for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated formatting and ability descriptions for Patch 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated builds and rotation for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **10 Aug. 2023 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated all recommendations.
- **10 Aug. 2023 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated stat recommendations and explanations.
- **10 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated priority lists, added trinket explanation.
- **08 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated talent builds and explanations.
- **07 Aug. 2023 (this page):** Updated all sections.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **24 May 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Cataclysm Timewalking and added Pocket Anvil for pure single-target.
- **24 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated talents and affix tips.
- **24 May 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated mixed single-target and full cleave build.
- **06 May 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for trinket and T30 secondary stat changes.
- **06 May 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Simplified page and changed wording to assume key talents.
- **06 May 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Divine Toll no longer pulls out of combat or neutral enemies.
- **06 May 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated Templar Stikes single-target talent build to use Zealots Fervor instead of Penitence.
- **06 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated Hammer of Wrath to T30 cleave priority and Holy Power management based on recommend talents.
- **02 May 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated Raid and Dungeon gear and added m+ embellishments.
- **02 May 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated Hammer of Wrath to T30 priority for cleave.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 10.1.
- **01 May 2023 (this page):** Updated for Patch 10.1.
- **05 Apr. 2023 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Primordial Stone update.
- **05 Apr. 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated Shield of Vengeance duration.
- **05 Apr. 2023 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated various descriptions for latest hotfixes.
- **21 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Patch 10.0.7.
- **21 Mar. 2023 (this page):** Updated for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **17 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Readded Idol of Tampling Hooves after it got fixed.
- **17 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated Stat priority.
- **17 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated 2-min talents.
- **17 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated Talents.
- **17 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Shield of Vengeance now has a 90-second cooldown.
- **17 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated Talents and Stats.
- **16 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Removed Idol of Tampling Hooves because it didnt hit raid bosses properly.
- **16 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Added second on-use trinket Manic Grieftorch.
- **13 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Added fallback Versatility Phial.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Mythic+ Season 1 loot tables.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Added fallback Phial and Potion options.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated Rotation and Notes.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated the single target talents to Sanctify.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Seal of the Crusader no longer affects allies.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated Talents and Rotation.
- **11 Dec. 2022 (this page):** Seal of the Crusader no longer affects allies.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/retribution-paladin-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/retribution-paladin-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/retribution-paladin-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **13 Apr. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-2-changes-analysis>)):** Updated for tier set changes.
- **02 Mar. 2022 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-1-changes-analysis>)):** Updated for 9.2 Raid opening.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-2-changes-analysis>)):** Reviewed and approved for Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **14 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-1-changes-analysis>)):** Updated with retail information.
- **20 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-1-changes-analysis>)):** Page filled with preliminary information.
- **10 Nov. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-ny-alotha-raid-guide>)):** Page updated for Execution Sentence and Final Reckoning changes.
- **13 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **11 Apr. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-the-eternal-palace-raid-guide>)):** Updated talent and essence recommendations.
- **14 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-the-eternal-palace-raid-guide>)):** Updated for Patch 8.3.
- **05 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-the-eternal-palace-raid-guide>)):** Updated for Mythic.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **13 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-crucible-of-storms-raid-guide>)):** Added Mythic notes.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** Inquisition has been added as a viable Talent.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** Inquisition has been added as a viable Talent.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **11 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Patch 8.1.5 and no changes are necessary.
- **17 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added Mythic recommendations.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** Page added.
- **11 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** Adjustments to talent advice for N'Zoth and Zul.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** Updated for 8.1.
- **12 Nov. 2018 ([Uldir page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** Added Uldir Mythic talent recommendations and tips. Updated a few Normal/Heroic boss talent recommendations.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** Added content for Uldir release.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Retribution Paladin leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Paladin leveling guide](<https://www.icy-veins.com/wow/paladin-leveling-guide>).

1.

### Retribution Paladin Leveling Guide for Midnight

Retribution Paladin is a spec with a lot of burst AoE cooldowns available. 
It is best either fighting large groups of enemies at once while solo questing, 
or doing great AoE damage in dungeons in a group. You will want to tag as many 
enemies as possible with ranged abilities like [[spell:20271]] to group them 
up, then use your cooldowns like [[spell:384376]] and [[spell:255937]] 
to kill them all quickly.

1.1.

#### Leveling Gear Options

In general, you will want to equip the highest item level gear you happen to pick up as you level. 
Retribution cares a lot more about Strength than any specific combination of secondary stats, and you will 
generally replace any gear very quickly as you continue to level.

Heirloom items can help your leveling experience, as they boost experience gains 
and automatically scale with your level.

1.2.

#### Useful Leveling Consumables for Midnight

Regular Flasks and Potions like [[item:212283]] and [[item:212265]] 
can make combat a little bit easier if you are willing to spend the gold. 
Otherwise, items like [[item:132516]] and [[item:109076]] can improve your movement speed, 
allowing you to move faster and fly without mounting up, which can be useful when travelling indoors or across large gaps.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Retribution Level 80 Midnight Leveling
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANLLzMzyMzMzMAAAAAAzUGGMjtxsNMzmZY8AzgxGbDAAgZ02YMDAYDwAAmhBGmZWwyMYMjZMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANLLzMzyMzMzMAAAAAAzUGzgZsNzsNMzmZY8AzgxGbDAAgZm2mZ2mBAsBYAAzwMYYmZBLzgxMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-VI1Eyzvcd36AdaKe56qZgmqGbUUqnHaRrkC-EFBiaAxIoR5gHgmGIKkurhpHMsPLnkF-AAAA-bYWUoEcAQMxQAJ-
```

:::

2.1.

#### War Mode Talents for Leveling

None of the options for War Mode talents have any impact on your leveling speed for Retribution. 
Feel free to take any that you want.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–9：**When creating your Paladin, you
only have one ability: [[spell:35395]]. It is your
first Holy Power generator. At level 2, you will unlock
[[spell:53600]], your first Holy Power spender. At level 3, you gain
[[spell:20271]]. [[spell:26573]] is unlocked at level 6. At Level 9, you
learn the class ability [[spell:62124]], a 30-yard range taunt
on an 8-second cooldown. Use this long-range taunt to pull more
mobs when you no longer have long-range damage abilities. At level
10 you can officially spec into Retribution and gain access to
[[spell:85256]]. From now you need to switch to a Two-Handed weapon. Otherwise, you will not be able to use your new abilities. Say goodbye to
[[spell:53600]], because you will never waste Holy Power on it again.

1. **等级 1–9：**Cast [[spell:35395]] on cooldown as
    long as you have 4 or less Holy Power.
2. **等级 2–9：**Cast [[spell:53600]] once you
    have 3 or more Holy Power generated.
3. **等级 3–9：**Cast [[spell:20271]] on cooldown.
4. **等级 6–9：**Cast [[spell:26573]].

**等级 10 起：**Starting at Level 10, you can queue for dungeons
with the in-game group finder. Always queue as DPS, so you have the proper training
environment to practice your Retribution kit at your given level in a dungeon situation.
To understand in-depth how to use this Retribution kit, especially when
reaching higher levels, check out our [rotation page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>),
but we have added a short version below:

1. **等级 23–65：**Cast [[spell:384376]].
2. **等级 61 起：**Cast [[spell:343527]].
3. **等级 10 起：**Follow the priority list below until you have at least 3 Holy Power.
   
   
   - **等级 51 起：**Cast [[spell:255937]] if you have 2 or less Holy Power.
   - **等级 26 起：**Cast [[spell:375576]].
   - **等级 10 起：**Cast [[spell:24275]].
   - **等级 11 起：**Cast [[spell:184575]].
   - **等级 10 起：**Cast [[spell:20271]].
   - **等级 10–41：**Cast [[spell:35395]].
   - **等级 41 起：**Cast [[spell:406647]] / [[spell:406646]].
4. **等级 10 起：**Once you reach 3 or more Holy Power, you want
   to switch to the second priority list below, which is used to spend Holy Power.
   
   
   - **等级 70 起：**Cast [[spell:429826]] when available.
   - **等级 13 起：**Cast [[spell:53385]] against 2 or more
     targets.
   - **等级 10–19：**Cast [[spell:85256]] against a single
     target.
   - **等级 19 起：**Cast [[spell:383327]] against a single
     target.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 Apr. 2026:** Updated recommendations.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **05 Mar. 2026:** Added Midnight talent import.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **21 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Retribution Paladin in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Retribution Paladin in Midnight

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

There are a few basic things to keep in mind while playing Retribution:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_malkorok_blightofyshaarj_yellow.jpg>) **Spend Holy Power**  
  
  Retribution's main resource is Holy Power, which you want to spend as often as possible. 
  Wasting Holy Power by continuing to cast abilities that generate it while already 
  at 4 or 5 will lose you a ton of damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_artofwar.jpg>) **Use Your Procs**  
   
  Procs like [[spell:267344]] are important to spend due to [[spell:1261159]]. 
  These don't always need to be spent instantly, but generally should be prioritized 
  to avoid accidentally wasting them.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_paladin_executionsentence.jpg>) **Utilize Cooldowns Properly**  
  
  Retribution has most of its damage concentrated in cooldown windows. As much as 
  using your abilities in the right sequence is important, knowing when to cast them 
  during a fight - such as holding them a few seconds for an important damage amp 
  or new wave of add spawns - can improve your damage a lot.

Retribution is a melee DPS specialization with a relatively
easy-to-grasp playstyle. Retribution's greatest strength is its straightforward
playstyle, with a very easy to understand gameplay loop and not too many 
keybinds.

2.

### Beginner's Guide to Retribution Paladin in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar   Single-Target Talents

2.1.

#### Beginner ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar Single-Target Talents for Retribution Paladin

This build is focused on pure single-target, without any extra talents that would 
only be used for cleave or AoE. You can use the "copy export string" button to import 
this build directly into the game.

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAAAMz02Mz2MAgNADAGzwMYGzMbYbGMMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJarSB-EQFBZiaIEoqCMyhlOJNthpHLrsNMsPP-AAAA-bYWCQMpQJw4QAJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar   Dungeon Talents

2.2.

#### Beginner ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar Cleave/Dungeon Talents for Retribution Paladin

This build maintains fairly strong priority damage while also taking some 
options to be able to perform better on AoE. You can use the "copy export 
string" button to import this build directly into the game.

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAMz02Mz2MAgNADAGzwAzYmZDLzghxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3ONddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-bYWAQMpQJw4QAJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun   Single-Target Talents

2.3.

#### Beginner ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Single-Target Talents for Retribution Paladin

This build is focused on pure single-target, without any extra talents that would 
only be used for cleave or AoE. You can use the "copy export string" button to import 
this build directly into the game.

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJarSB-EQFBZiaIEoqCMyhlOJNNvhpHLrsNMsP-AAAA-WaYUIEKOCYMEJA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun   Dungeon Talents

2.4.

#### Beginner ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Cleave/Dungeon Talents for Retribution Paladin

This build maintains fairly strong priority damage while also taking some 
options to be able to perform better on AoE. You can use the "copy export 
string" button to import this build directly into the game.

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-WaYIEKUOCYMEJA-
```

:::

### Retribution Paladin   Basic Rotation

2.5.

#### Retribution Paladin Rotation for Beginners

Retribution Paladins do not have a fixed rotation of abilities. Instead,
your goal is to make sure that high-priority cooldowns are used as
often as possible while making sure that Holy Power spenders are used before
Holy Power gets overcapped.

1. Use your major cooldown abilities like [[spell:255937]] and 
   [[spell:375576]] as often as possible.
2. Spend Holy Power with [[spell:383327]] for single-target or 
   [[spell:53385]] against 2+ targets.
3. Generate Holy Power with [[spell:184575]], [[spell:20271]], and 
   [[spell:24275]]. You should prioritize using [[spell:184575]] 
   first.

2.5.1.

##### Apex Talent: ![Light Within Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_holyfire_buff.jpg>) Light Within

The Apex Talent for Retribution, [[spell:1261113]], increases the 
power of [[spell:267344]] procs. You will want to use 
[[spell:184575]] as soon as possible with two stacks of [[spell:267344]], 
even at 4 Holy Power, but should spend first at 5.

2.5.2.

##### Season 2 Tier Set

The Season 2 Tier Set bonus increases the proc rate of [[spell:408459]] 
and increases the damage of other Holy Power spenders after consuming a proc. 
To use it optimally you'll want to weave in [[spell:53385]] casts after consuming 
[[spell:408459]] on single-target and [[spell:383327]] on AoE.

### Retribution Paladin   Defensive Spells

2.6.

#### Defensive Spells for Retribution Paladin

Retribution has many defensive options available. Here is a list of the main 
ones you will regularly use.

- [[spell:642]] - Prevents all damage and removes most harmful effects 
  for 8 seconds. Also applies [[spell:25771]].
- [[spell:403876]] - Reduces all damage taken by 20% for 8 seconds. 
  Also applies an absorb from [[spell:184662]].
- [[spell:633]] - Heals a target for an amount equivalent to your 
  maximum health. Also applies [[spell:25771]].
- [[spell:1022]] - Prevents all physical damage and removes 
  most harmful physical effects for 8 seconds. Also applies 
  [[spell:25771]].

### Retribution Paladin   Stat Priority

2.7.

#### Stat Priority for Retribution Paladin

For the above talent builds, you will want to prioritize stats as 
follows. For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>).

Item Level

Mastery

Haste

Critical Strike

Versatility

### Blizzard   Combat Assistance

2.8.

#### Combat Assistance for Retribution Paladin

There are two related systems in the game to help players in combat: Assisted 
Highlight and the Single-Button Assistant.

2.9.

#### Assisted Highlight

This system works by highlighting the next ability that Blizzard suggests for 
you to use on your action bar. If you're new to the spec and aren't fully familiar with its rotational priorities 
just yet, this might be a useful reminder for you. This tool does 
not always recommend the most optimal ability to use in every situation, but as 
Retribution, following it exactly will result in a very minor damage difference 
compared to theoretically optimal play.

2.10.

#### Single-Button Assistant

This allows you to perform the same recommended assisted rotation by instead 
just continually pressing a single button, at the cost of a considerably 
increased global cooldown. For Retribution, this is a large damage loss as 
Retribution is a specialization that highly values frequent ability casts, for 
example with effects that provide a significant amount of Haste like 
[[spell:384392]]. We do not recommended this feature to be used outside of 
accessibility circumstances.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Aug. 2026:** Updated for hotfixes.
- **11 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **24 Mar. 2026:** Updated builds.
- **17 Mar. 2026:** Updated for hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **05 Mar. 2026:** Updated talent builds.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **05 Jul. 2025:** Updated builds.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **27 Feb. 2025:** Updated rotation section.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **08 Oct. 2024:** Updated for hotfixes.
- **25 Sep. 2024:** Updated builds.
- **09 Sep. 2024:** Updated for hotfixes.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated builds and rotation for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **06 May 2023:** Updated Hammer of Wrath to T30 cleave priority and Holy Power management based on recommend talents.
- **01 May 2023:** Updated for Patch 10.1.
- **21 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **17 Jan. 2023:** Updated Talents and Stats.
- **11 Dec. 2022:** Updated Talents and Rotation.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Retribution Paladin in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Retribution Paladin

Retribution can choose between [[spell:404542]] and 
[[spell:406646]] for different types of Holy Power generation in its 
builds. Currently, [[spell:404542]] is significantly stronger than 
[[spell:406646]], so all builds recommended on this page will be using 
[[spell:404542]], but if you want to play the alternative style then 
no additional talent swaps are needed.

For Hero Talents, both are strong choices with different niches. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar 
has stronger single-target damage and better defensives. 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun has stronger burst inside 
[[spell:384376]] and better sustained cleave damage.

- **Single Target -** Both are viable on single-target, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar 
    having a small edge. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun tends to do better with [[spell:10060]].
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun performs much better on low target cleave, 
    but the difference is smaller on large target counts. For burst AoE, 
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar is much stronger.

In practice it is optimal to play both Hero trees depending on the specific situation, 
but the default builds recommended here use ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun because it 
is a better all-round choice, especially given the prominance of sustained cleave in 
The Venomous Abyss.

**Quick Start Import Codes:**

:::talents Retribution Single Target - Herald of the Sun
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAYWmtZmZrBBAAsAYAwYGmBzYmZDYmZYMjBD"
}
```
:::

:::talents Retribution AoE - Herald of the Sun
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBBAAsAYAwYGGYGzMbAzMDjZMYA"
}
```
:::

:::talents Retribution Delves - Templar
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGjZmBAAAAAYmyYGMjtZmthZ2mxYMzwM2YDAAgZm2mZ2mBAsBYAAzwAzYGbYZGMmxMGMA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Templar

Single-Target/Raid Build

Cleave/Mythic+ Build

Delves/Open World

Herald of the Sun

Raid/Single-Target

recommended

Cleave/Mythic+

recommended

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar Single-Target Talents

This build is best for pure single-target situations.
Using [[spell:1260429]] and [[spell:379391]] instead will provide some
extra passive cleave.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar Cleave/Dungeon Talents

This build drops the worst single-target talents for stronger AoE
options. The main choice to make in Mythic+ for damage is whether you want to prioritize
single-target or AoE damage. For more AoE, the only realistic option to take is
[[spell:382536]], which you would take instead of [[spell:204979]].
Swapping [[spell:343527]] for [[spell:458359]] will also give you
smoother cooldowns, since they will never be desynced, and are easier to use
when playing with tanks with unknown or unorthodox pull strategies.

### 天赋方案 0-2

1.3.

#### Delves and Open World Talents

This build works best for short-duration multi-target combat and frequent
movement from enemy to enemy. For longer sustained combat where enemies live
for more than a few seconds like higher level [Delves](<https://www.icy-veins.com/wow/delves-guide>), the regular
Mythic+ builds should be used instead.

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Single-Target Talents

This build is best for pure single-target situations. Sadly,
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun has no real swap options for single-target.

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Cleave/Dungeon Talents

This build drops the worst single-target talents for stronger AoE
options. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun has no real options for more single-target or AoE damage through talent swaps.
Swapping [[spell:343527]] for [[spell:458359]] will also give you
more smoother cooldowns, since they will never be desynced and are easier to use
when playing with tanks with unorthodox pulling strategies.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAAAMz02Mz2MAgNADAGzwMYGzMbYbGMMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJarSB-EQFBZiaIEoqCMyhlOJNthpHLrsNMsPP-AAAA-bYWCQMpQJw4QAJ-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAMz02Mz2MAgNADAGzwAzYmZDLzghxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3ONddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-bYWAQMpQJw4QAJ-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGjZmBAAAAAYmyYGMjtZmthZ2mxYMzwM2YDAAgZm2mZ2mBAsBYAAzwAzYGbYZGMmxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3ONddN0sAl2hqGbUUqnnSRgUMK-EQFBZiaIEoqCMyhOJvhpHLrMMsGlrNH-AAAA-bYWAQMpQJw4QAJ-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJarSB-EQFBZiaIEoqCMyhlOJNNvhpHLrsNMsP-AAAA-WaYUIEKOCYMEJA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-WaYIEKUOCYMEJA-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have its own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend the following bonuses for each rank:

- Tier 1: [[spell:1279599]]
- Tier 2: [[spell:1279604]]
- Tier 3: [[spell:1287555]]
- Tier 4: [[spell:1279612]]
- Tier 5: [[spell:1279614]]

3.

### Apex Talent: ![Light Within Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_holyfire_buff.jpg>) Light Within

The Apex Talent for Retribution is [[spell:1261113]]. This provides 
bonus effects to [[spell:267344]] or [[spell:402912]], increasing the 
damage of the next [[spell:184575]] cast and causing it to also deal 
additional AoE damage. It also increases Holy Power spender damage during 
[[spell:384376]]. Prioritizing using [[spell:184575]] when at 2 
stacks is a sizeable damage increase.

4.

### Hero Talents for Retribution Paladin

Retribution has two Hero Talent trees, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar and 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun. These each have different visuals and gameplay, 
augmenting the core Retribution talents and abilities.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar gives you access to [[spell:429826]] after casting 
[[spell:255937]], which is a separate Holy Power spender that does 
significant AoE damage. It also has extra bonus effects such as 
[[spell:198137]] and [[spell:431625]] that do additional AoE damage 
passively.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun procs [[spell:431377]]s when [[spell:255937]] 
is cast, which are powerful DoT effects that grant extra bonuses while active. 
It also significantly increases the power of [[spell:24275]] through 
talents like [[spell:1263782]].

5.

### PvP Talents (War Mode)

"War Mode" is an opt-in feature that enables cross-faction PvP combat in the 
open-world.
Enabling War Mode provides the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended enabling the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

No War Mode talents have any impact on open-world PvE content for 
Retribution.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **25 Aug. 2026:** Updated for hotfixes.
- **11 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **23 Apr. 2026:** Updated recommended raid talents.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **24 Mar. 2026:** Updated builds and added recommended raid talents.
- **17 Mar. 2026:** Updated for hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **05 Mar. 2026:** Updated talent builds.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **05 Jul. 2025:** Updated builds.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **03 Apr. 2025:** Added build details.
- **03 Mar. 2025:** Updated builds.
- **27 Feb. 2025:** Updated talent discussion.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **08 Oct. 2024:** Updated for hotfixes.
- **25 Sep. 2024:** Added extra builds.
- **09 Sep. 2024:** Updated for hotfixes.
- **28 Aug. 2024:** Added Delve build.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **08 Aug. 2023:** Updated talent builds and explanations.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **24 May 2023:** Updated mixed single-target and full cleave build.
- **06 May 2023:** Updated Templar Stikes single-target talent build to use Zealots Fervor instead of Penitence.
- **01 May 2023:** Updated for Patch 10.1.
- **21 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **17 Jan. 2023:** Updated Talents.
- **11 Dec. 2022:** Updated the single target talents to Sanctify.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Retribution Paladin in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Retribution Paladin Gameplay and Rotation Guide

Welcome to our Rotation page for Retribution Paladins. Here you
will find out more about your rotational priorities in both single-target
and multi-target situations, which you will apply in both Raiding and Mythic+
scenarios.

Each of the sections below explain the rotation for different environments.
Click the boxes to switch to the desired situation. Currently, there are no rotational
differences between single-target and Mythic+ builds.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun

Raid & Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar

Raid & Mythic+

Holy Power Talents

Cooldown Talents

[[spell:404542]]

[[spell:406646]]

[[spell:343527]]

[[spell:458359]]

### Opener

[[spell:184575]]

**适用条件：Radiant Glory（未启用）。**

[[spell:282113]]

[[item:241288]]

**适用条件：Execution Sentence（启用）。**

[[spell:343527]]

[[spell:255937]]

**适用条件：Templar（启用）。**

[[spell:429826]]

**适用条件：Herald of the Sun（启用）。**

[[spell:383327]]

**适用条件：Herald of the Sun（启用）。**

[[spell:383327]]

[[spell:53385]]

[[spell:375576]]

1.1.

#### Opener for Retribution Paladin

For your opener, you will want to cast the abilities in the order listed here before moving on to the regular rotation priority. Your opener is the same in both single-target and AoE scenarios.

1. Cast [[spell:184575]].
2. **适用条件：Radiant Glory（未启用）。** Cast [[spell:384376]].
3. Use [[item:241288]] and any on-use trinkets.
4. **适用条件：Execution Sentence（启用）。** Cast [[spell:343527]].
5. Cast [[spell:255937]].
6. **适用条件：Templar（启用）。** Cast [[spell:429826]].
7. **适用条件：Herald of the Sun（启用）。** Cast [[spell:383327]].
8. **适用条件：Herald of the Sun（启用）。** Cast [[spell:383327]] ([[spell:53385]] on AoE).
9. Cast [[spell:375576]].
10. Continue with the regular priority.

Your goal in your opener should be to start generating Holy Power before your cooldowns and then begin your burst window.

### Single-Target

Retribution follows a priority for its rotation, as listed below. Start from the top and work your way down the list until you reach an ability with all criteria met, and that will be the best one to cast for the situation.

1. **适用条件：Radiant Glory（未启用）。** Cast [[spell:384376]].
2. **适用条件：Execution Sentence（启用）。** Cast [[spell:343527]].
3. **适用条件：Templar（启用）。** Cast [[spell:429826]] if it is castable from using [[spell:255937]].
4. **适用条件：Templar（启用）。** Cast [[spell:429826]] with a [[spell:425518]] proc, under any of the following conditions:
   
   
   - [[spell:384376]] or [[spell:343527]] is active and will end shortly.
   - The [[spell:432626]] buff is not active and [[spell:384376]] isn't about to come off cooldown.
   - The proc's duration will expire soon or your target will die.
5. Cast [[spell:53385]] with a [[spell:1306161]] proc from [[spell:383327]] and 5 Holy Power.
6. Cast [[spell:383327]] if you have 5 Holy Power.
7. Cast [[spell:255937]].
8. Cast [[spell:375576]].
9. **适用条件：Templar（启用）。** Cast [[spell:184575]] with 2 stacks of [[spell:267344]].
10. **适用条件：Herald of the Sun（启用）。** Cast [[spell:184575]] with 2 stacks of [[spell:267344]] and [[spell:384376]] not active.
11. **适用条件：Herald of the Sun（启用）。** Cast [[spell:24275]] with 2 charges.
12. Cast [[spell:53385]] with a [[spell:1306161]] proc from [[spell:383327]].
13. Cast [[spell:383327]].
14. **适用条件：Herald of the Sun（启用）。** Cast [[spell:24275]].
15. Cast [[spell:184575]].
16. **适用条件：Templar（启用）。** Cast [[spell:24275]].
17. Cast [[spell:20271]].
18. **适用条件：Templar Strikes（启用）。** Cast [[spell:406646]] or [[spell:406647]].
19. **适用条件：Templar Strikes（未启用）；Crusading Strikes（未启用）。** Cast [[spell:35395]].

### AoE

Retribution follows a priority for its rotation, as listed below. Start from the top and work your way down the list until you reach an ability with all criteria met, and that will be the best one to cast for the situation.

1. **适用条件：Radiant Glory（未启用）。** Cast [[spell:384376]].
2. **适用条件：Execution Sentence（启用）。** Cast [[spell:343527]].
3. **适用条件：Templar（启用）。** Cast [[spell:429826]] if it is castable from using [[spell:255937]].
4. **适用条件：Templar（启用）。** Cast [[spell:429826]] with a [[spell:425518]] proc, under any of the following conditions:
   
   
   - [[spell:384376]] or [[spell:343527]] is active and will end shortly.
   - The [[spell:432626]] buff is not active and [[spell:384376]] isn't about to come off cooldown.
   - The proc's duration will expire soon or your target will die.
5. Cast [[spell:383327]] with a [[spell:1306161]] proc from [[spell:53385]] and 5 Holy Power.
6. Cast [[spell:53385]] if you have 5 Holy Power.
7. Cast [[spell:255937]].
8. Cast [[spell:375576]].
9. **适用条件：Templar（启用）。** Cast [[spell:184575]] with 2 stacks of [[spell:267344]].
10. **适用条件：Herald of the Sun（启用）。** Cast [[spell:184575]] with 2 stacks of [[spell:267344]] and [[spell:384376]] not active.
11. **适用条件：Herald of the Sun（启用）。** Cast [[spell:24275]] with 2 charges.
12. **适用条件：Herald of the Sun（启用）。** Cast [[spell:383327]] if you have [[spell:387170]] active.
13. **适用条件：Templar（启用）。** Cast [[spell:383327]] with a [[spell:1306161]] proc from [[spell:53385]].
14. Cast [[spell:53385]].
15. **适用条件：Herald of the Sun（启用）。** Cast [[spell:24275]].
16. Cast [[spell:184575]].
17. **适用条件：Templar（启用）。** Cast [[spell:24275]].
18. Cast [[spell:20271]].
19. **适用条件：Templar Strikes（启用）。** Cast [[spell:406646]] or [[spell:406647]].
20. **适用条件：Templar Strikes（未启用）；Crusading Strikes（未启用）。** Cast [[spell:35395]].

The philosophy behind the rotation for AoE is essentially the same as it is for single-target. You will want to swap to the AoE rotation at 2 or more targets.

2.

### Midnight Season 2 Tier Set

The Season 2 Tier Set bonus increases the proc rate of [[spell:408459]] 
and increases the damage of other Holy Power spenders after consuming a proc. To 
use it optimally you'll want to weave in [[spell:53385]] casts after consuming 
[[spell:408459]] on single-target and [[spell:383327]] casts on AoE.

3.

### Class and Spec Mechanics Explained

### Resource Management

3.1.

#### Resource Management

You need to manage two resources when playing Retribution, **Holy Power** 
and **time**. Most of your damage comes by generating and spending Holy Power, 
and increasing the efficiency of this loop will increase your damage in turn.
To optimize Holy Power generation, you need to consider both the cooldowns of 
generators and periodic effects that provide it, like [[spell:404542]].

Minimizing wasting Holy Power should be kept in mind at all times. You do not 
want to continue to generate Holy Power when you already have 5 just to put an 
ability on cooldown, and you need to consider whether you will gain Holy Power 
within a GCD before you use a generator to reach 5. With current design, waste is 
unavoidable, especially with effects like [[spell:1263782]], so try to minimize 
avoidable waste while being aware that some kinds of waste are inevitable.

Currently Retribution is willing to spend Holy Power at a higher priority than it has historically, 
due to high rate of passive Holy Power generation. Other than keeping abilities like 
[[spell:255937]] on cooldown as fast as possible and spending an [[spell:267344]] 
proc at 2 stacks, you can simply spend Holy Power as soon as possible.

### Apex Talents

3.2.

#### Apex Talents

The Apex Talent for Retribution, [[spell:1261113]], increases the 
power of [[spell:267344]] procs. You will want to use 
[[spell:184575]] as soon as possible with two stacks of [[spell:267344]], 
even at 4 Holy Power, but should spend first at 5.

4.

### Important Cooldowns for Retribution Paladin

### [[spell:384376]]

4.1.

#### Avenging Wrath

[[spell:384376]] increases damage and Critical Strike chance of all abilities, so it should be used before other cooldowns. 
It also converts [[spell:20271]] into [[spell:24275]], upgrading its effects. With [[spell:384392]], it provides a stacking Haste buff, 
but stacking this doesn't need to be prioritized over all other abilities as it used to be, since the damage and Crit bonuses remain flat.

### [[spell:343527]]

4.2.

#### Execution Sentence

[[spell:343527]] deals initial AoE damage, then after 10s deals damage to the primary target based on damage done to all initial targets hit. 
On AoE, you should continue using AoE abilities as normal for its duration. You should use this before other cooldowns that deal significant damage like [[spell:255937]].

### Trinkets

4.3.

#### Trinket Usage

There are two types of on-use trinkets that you will use, trinkets that just 
deal damage and trinkets that provide a stat bonus. For trinkets that provide a 
stat bonus, usage is straightforward; you should use them with [[spell:384376]] unless 
the encounter will end before [[spell:384376]] will come off cooldown 
if their cooldowns do not naturally line up. You can use multiple on-use stat 
trinkets by simply using them with alternating cooldown sets.

For on-use damage trinkets, usage can depend on the trinket. [[spell:384376]] 
does not buff trinket damage, but it does increase the critical strike chance of the damage. 
For instant on-use damage from trinkets you will want to make sure you use it inside [[spell:384376]].

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Aug. 2026:** Updated for hotfixes.
- **11 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 Apr. 2026:** Updated priority.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **24 Mar. 2026:** Updated priority.
- **17 Mar. 2026:** Updated for hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **05 Mar. 2026:** Updated priority.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **03 Mar. 2025:** Updated discussion.
- **27 Feb. 2025:** Updated priority.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **25 Sep. 2024:** Added extra details for niche builds.
- **09 Sep. 2024:** Updated for hotfixes.
- **28 Aug. 2024:** Adjusted opener rotation.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Aug. 2023:** Updated priority lists, added trinket explanation.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **06 May 2023:** Divine Toll no longer pulls out of combat or neutral enemies.
- **06 May 2023:** Simplified page and changed wording to assume key talents.
- **02 May 2023:** Updated Hammer of Wrath to T30 priority for cleave.
- **01 May 2023:** Updated for Patch 10.1.
- **05 Apr. 2023:** Updated Shield of Vengeance duration.
- **21 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated Rotation and Notes.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Retribution Paladin in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Retribution Paladin

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) uses the Crest system which lets you
increase the item level of gear along tracks based on where you obtained the
item from, with harder content dropping gear that can be upgraded to higher item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the BiS items from any source for Midnight Season 2. Although this is a theoretical best list, the best item for your character specifically can often be different depending on other items currently equipped.

This list is intended as a reference, but we always recommend confirming by [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on the exact gear you have available, your best gear to use might look different than this list for some slots.

:::details FAQWhich Tier Set Pieces Do I Want?
Catalyzing items in Midnight Season 2 works differently, as items keep their previous stats and effects. This means that the original item's source matters a lot. These are strong items to catalyze in each slot:

- **Helm** - [[item:281239]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Shoulders** - [[item:251138]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **Chest** - [[item:268222]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Hands** - [[item:251214]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- **Legs** - [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details FAQWhat to Take From The Great Vault?
The most important item to take is a Myth track weapon. After acquiring that, or if you don't hit one, trinkets or 6/6 Myth items are good choices, but otherwise you may want to take bonus rolls instead.

Instead of picking an item from the Great Vault, you can instead choose to take a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>). This lets you bonus roll on any dungeon or boss, and receive a 1/6 Myth track version of the item for Heroic raid and Mythic +10 dungeons, or 6/6 Myth for Mythic raid. Details on bonus rolling strategies can be found below.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271465@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271464@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268245@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271468@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251513@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">Jewelcrafting</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAKAAwt1ENMMYjVi4IN]]&#10;&#10;<div>[[item:240892]][[item:251490]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This list contains the BiS items from Mythic+ for Midnight Season 2. Although this is a theoretical best list, the best item for your character specifically can often be different depending on other items currently equipped.

This list is intended as a reference, but we always recommend confirming by [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on the exact gear you have available, your best gear to use might look different than this list for some slots.

:::details FAQWhich Tier Set Pieces Do I Want?
Catalyzing items in Midnight Season 2 works differently, as items keep their previous stats and effects. This means that the original item's source matters a lot. These are strong items to catalyze in each slot:

- **Helm** - [[item:251126]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **Shoulders** - [[item:251138]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **Chest** - [[item:193753@JAAIAAQkCYHKvbRLfA]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- **Hands** - [[item:251214]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- **Legs** - [[item:273776]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>), [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>), [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): All drop weapons and useful trinkets.
- **Weapon**: Any of [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>), [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>), and [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) drop a weapon with good stats.
- **Trinkets**: [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>), [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>), and [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>) have the best trinket options from dungeons.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271465@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271464@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:273777@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271468@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251513@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">Jewelcrafting</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:193762@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAKAAwt1ENMMYjVi4IN]]&#10;&#10;<div>[[item:240892]][[item:251490]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:193755@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the BiS items from Raids for Midnight Season 2. Although this is a theoretical best list, the best item for your character specifically can often be different depending on other items currently equipped.

This list is intended as a reference, but we always recommend confirming by [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on the exact gear you have available, your best gear to use might look different than this list for some slots.

:::details FAQWhich Tier Set Pieces Do I Want?
Catalyzing items in Midnight Season 2 works differently, as items keep their previous stats and effects. This means that the original item's source matters a lot. These are strong items to catalyze in each slot:

- **Helm** - [[item:281239]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Shoulders** - Tier Token from [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **Chest** - [[item:268222]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Hands** - [[item:268220]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- **Legs** - [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items these are the best available:

- [[item:268213@JAACAAAG2A]]: Our BiS weapon. Drops from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).
- [[item:270175@JAACAAAG2A]]: The best on-use trinket. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270173@JAACAAAG2A]]: The best passive trinket. Also from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271465@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271464@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268245@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271468@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251513@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">Jewelcrafting</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAKAAwt1ENMMYjVi4IN]]&#10;&#10;<div>[[item:240892]][[item:251490]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Retribution Paladin

There are very few strong trinkets available this tier, with the stronger raid trinkets 
far outperforming the rest. There are also a few decent on-use options available, and 
multiple can be used together by using them with alternating cooldown sets.

Your ideal combination is:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Retribution Paladin Trinkets**
**Active -**

[[item:270175@JAACAAAG2A]]

**Passive -**

[[item:270173@JAACAAAG2A]]

:::

There are quite a few other options available, which can be found below.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Retribution Paladin Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270173@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<span>Requires the set bonus from [[item:268213@JAACAAAG2A]] &#10;		   to gain maximum power on cleave/AoE.</span>&#10;</li>&#10;<li>[[item:270175@JAACAAAG2A]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:270165@JAACAAgNyA]]</li>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:193762@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:250228@JAACAAgNyA]]</li>&#10;<li>[[item:270163@JAACAAgNyA]]</li>&#10;<li>[[item:158367@JAACAAgNyA]]</li>&#10;<li>[[item:250229@JAACAAgNyA]]</li>&#10;<li>[[item:273797@JAACAAgNyA]]</li>&#10;<li>[[item:250245@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250238@JAACAAgNyA]]</li>&#10;<li>[[item:273795@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Patch 12.1 continues the system of [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s allowing you 
to target specific items by rolling for a guaranteed item from a boss's loot table, 
without duplicates from previous rolls. [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s can either be 
acquired by taking them from your Great Vault instead of a regular item, or will 
be periodically acquired later in the season. [[item:280562]]s increase 
the item level of Hero or Myth track Weapons, Trinkets, and Necks by 6 each, up to item level 340.

3.1.

#### Recommended Nebulous Voidcore Usage for Retribution Paladin

The ideal usage of bonus rolls is on the final two Mythic bosses, since all the 
items they drop have a higher base item level than any other loot this season. 
However, they will take most players a while to be able to kill, so early on it 
may be better for you to use rolls on other content instead.

- For Mythic+: [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>) doesn't have any items that are BiS longterm, 
  but it has the smallest loot table with a weapon as well as a decent trinket, so 
  if you are spending bonus rolls in dungeons early on, this will probably have the 
  highest average value for you.
- For Raid: [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) and [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)'s items are almost all BiS 
  and are worth rolling on Mythic. Rolling them on Heroic will drop Myth track loot, 
  but with a lower item level cap.

In Season 2, there are some items that are substantially stronger than anything 
comparable like [[item:268213@JAACAAAG2A]] and [[item:270173@JAACAAAG2A]] 
which make bonus rolling a bit more complicated. Although these can be rolled through 
Heroic as well, there are upsides and downsides to rolling them on lower difficulties. 
To quickly discuss your relevant options:

- Early on, bonus rolls require you to give up a Vault item to use. Although 
  this will often not be anything useful that you'd be sacrificing by taking one, 
  there can be situations that taking an item from your vault is worth more than a roll. 
  For example, if you are completing the [[item:268213@JAACAAAG2A]] set bonus, 
  or if you are taking a 6/6 Myth weapon without a Myth weapon already. In some cases 
  you may want to take a bonus roll despite an item you want to roll being in your Vault 
  anyway, because there are additional items you also want to roll from the same boss 
  still left.
- If you are able to kill [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) or [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) on Mythic,
  spend your rolls there.
- If you are not killing all Mythic bosses but are able to kill a few Mythic and 
  all Heroic bosses, your choices of what to roll will depend largely on whether 
  you have extra Crests to spend and whether you have a Myth weapon. Rolling Heroic 
  [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) until you get both [[item:268213@JAACAAAG2A]] and [[item:270173@JAACAAAG2A]] 
  will give you a weapon and trinket that are BiS until you start killing Mythic [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>), 
  and will take on average 4 rolls with a worst case of 5 rolls. However, it also 
  requires you to spend at least 80 Myth Crests per item you roll to upgrade them fully. 
  Rolling early Mythic bosses like [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>) or [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>) 
  that also can drop a Weapon is an alternative route that will cost no Crests, 
  since Mythic boss bonus roll loot is already 6/6 upgraded. When you pick a boss to roll, 
  you will want to commit to rolling it until you get a weapon.
- When rolling [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), you can remove both trinkets from your loot pool 
  by setting your loot spec to Holy. If you want a guaranteed upgrade from a single roll 
  then this is a fine strategy, since [[item:270168@JAACAAAG2A]] 
  is close to a useless item, but [[item:270175@JAACAAAG2A]] 
  is one of our best trinkets, so in the long term it's better to wait until after 
  you hit it before swapping loot to Holy.
- [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) drops some BiS cantrip items, but the effects are less powerful 
  than the ones from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) or [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>). You will still want to roll it 
  for the Ring and Helm, but don't prioritize it over the other two.

3.2.

#### Ascendant Venomstones

When choosing items to upgrade, in general simming is the easiest way, but as a 
default, your weapon should be the top priority, followed by trinkets, and finally your
necklace. Ideally you want to upgrade Myth track items rather than Heroic, but keep in
mind that you need to fully upgrade them to 6/6 before they can be improved further
using [[item:280562]].

4.

### Best Crafted Items for Retribution Paladin

Professions are useful as a way to fill slots and customize secondary 
stats on items, as well as adding special effects to the items too. Although 
you should sim your options to check what the best one for your gear setup would 
be, a good default to use is [[item:245783]].

Early on, crafting a **Two-Handed Weapon** is a strong choice if you use 
[Myth Mistcrest](<https://www.wowhead.com/currency=3446>) to upgrade it to 331 item level, since weapons 
provide a much larger increase than any other item slot. It will cost 4 
[[item:274476]] rather than 2, but it is definitely worth it. If you are planning 
on using bonus rolls on bosses with weapons though, you should skip crafting one. Once you 
either loot or craft a weapon, other embellished items are the next priority.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Retribution Crafted Gear Priority**
- **Optional**: [[item:237846]] with [[item:273060]]
- [[item:251513@JAAGAAwt1ENMMYD]]
- Any low item level slot with [[item:251490]]
- Any slot you do not have on Myth track yet

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Retribution Paladin

For Retribution, you have a few embellishment combinations that are competitive:

- [[item:251513@JAAGAAwt1ENMMYD]] and another item with [[item:251490]]
- Two items with [[item:240167]] and/or [[item:273069]]
- [[item:273060]] on a weapon

Most of these options you can mix and match - e.g. you can use a weapon with 
[[item:273060]] plus either [[item:251513@JAAGAAwt1ENMMYD]] or another slot with 
[[item:240167]]. However, [[item:251490]] won't 
do anything by itself without [[item:251513]].

[[item:240167]] and [[item:273069]] are very similar in power to 
[[item:251513@JAAGAAwt1ENMMYD]] with [[item:251490]] boosting 
its effectiveness, and either combination could perform slightly better 
depending on your exact gear setup. [[item:251513@JAAGAAwt1ENMMYD]] 
is the default recommendation here as it is stronger with full BiS gear. 
[[item:273060]] is the best option for a weapon embellishment if you 
craft a weapon early, but is weaker than armor 
embellishment options long term.

When using [[item:251513]], you will want to use 
[[item:240892]] as 
secondary stat gems instead to maximize the power of its proc.

Because crafted gear has a slightly lower item level cap than Myth track items, 
you will eventually want to use armor embellishments on slots that have relatively less Strength.
Bracers is a good choices for slots to craft on later, but keep in mind 
that this is an eventual best slot - for your first craft or two,
bracers are the worst slot to use since you want to get a high item level piece 
for an impactful slot.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you purchase instead of selecting 
an item from your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for a [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

Gear can be upgraded using Crests. Early on these are fairly limited, so you 
will want to prioritize the most important slots to upgrade first. 
For Retribution, these are:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Retribution Paladin Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helm/Chest/Legs/Jewellery**

➜

**Shoulders/Gloves/Belt/Boots**

:::

6.

### Evaluating Upgrades

With the sheer number of possible gear combinations, a generic stat 
priority or BiS list is not going to tell the entire story of how to gear your character.
Instead, you should use [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) to get a better idea of how 
changing different items will affect your character. Especially for Retribution, you will frequently find
the values of different stats fluctuate a lot as you upgrade your gear, 
so using a more objective metric to help you make gearing decisions is invaluable.

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **25 Aug. 2026:** Updated for hotfixes.
- **11 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **23 Apr. 2026:** Updated explanations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **24 Mar. 2026:** Updated recommendations.
- **17 Mar. 2026:** Updated for hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **05 Mar. 2026:** Updated gear and crafting recommendations.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **15 Aug. 2025:** Updated trinket recommendations.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **05 Jul. 2025:** Updated D.I.S.C. recommendations.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **03 Apr. 2025:** Updated gear recommendations.
- **27 Feb. 2025:** Updated gear recommendations.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **01 Jan. 2025:** Updated trinket recommendations.
- **17 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW Season 1.
- **28 Aug. 2024:** Updated embellishment recommendations.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **28 Nov. 2023:** Added the new Legendary and adjusted trinket recommendations.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Added BiS lists and overhauled page formatting for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **24 May 2023:** Updated for Cataclysm Timewalking and added Pocket Anvil for pure single-target.
- **06 May 2023:** Updated for trinket and T30 secondary stat changes.
- **02 May 2023:** Updated Raid and Dungeon gear and added m+ embellishments.
- **01 May 2023:** Updated for Patch 10.1.
- **21 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **17 Jan. 2023:** Readded Idol of Tampling Hooves after it got fixed.
- **16 Dec. 2022:** Added second on-use trinket Manic Grieftorch.
- **16 Dec. 2022:** Removed Idol of Tampling Hooves because it didnt hit raid bosses properly.
- **11 Dec. 2022:** Updated for Dragonflight Mythic+ Season 1 loot tables.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Retribution Paladin. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Retribution Paladin Stat Priority

There are no stat breakpoints that you should aim for specifically for any stat or any
build. Your general stat priority will be as follows:

Item Level

Mastery

Haste

Critical Strike

Versatility

As mentioned above, these priorities should only be considered a general guide. There
could be many gearing situations where stats ranked lower here end up being more valuable
than ones ranked highly. Using simulations to help determine your gear will always be a
better method since the relative value of stats can change significantly as you change your
gear.

2.

### In-Depth Stat Breakdown

**Strength** increases the damage of all your abilities and will generally be a higher
priority stat than any secondary stat. As a result, item level will usually trump any other
stat-specific comparisons 
since Strength increases significantly with item level on all non-jewellery slots.

**Haste** is valuable due to the resource generation it provides via [[spell:404542]],
as well as reducing the cooldowns of all of your major Holy Power generators.

**Versatility** increases all damage done and reduces damage taken. It does not have
any innate synergies with any talents or abilities but ends up becoming more valuable 
as you gain more of other secondary stats. Notably, Versatility also increases the damage
done of trinkets and other damage effects from items, which can make it more valuable when
these effects make up a larger portion of your total damage.

**Critical Strike** does gain some value from talents like [[spell:406154]],
which increase the amount of damage that critical hits deal. [[spell:267344]] also has a
higher chance to trigger from melees that critically hit, which can make Crit more valuable 
han simply the damage increase itself. It also is slightly more valuable on AoE for
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar due to [[spell:431551]].

**Mastery** increases the damage of all of your abilities that deal Holy damage. This
includes abilities that deal Holystrike or Radiant damage, as they also count as Holy for
the purposes of [[spell:267316]]. It also gives [[spell:20271]] a chance
to deal extra Holy damage when cast, and this chance can be increased with a number of talents.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **24 Mar. 2026:** Updated recommendations.
- **17 Mar. 2026:** Updated for hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Aug. 2023:** Updated stat recommendations and explanations.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **21 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **17 Jan. 2023:** Updated Stat priority.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Retribution Paladin, based on your [stat priority](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You will generally want to use one [[item:240983]] in
your first socket and [[item:240892]] in your other sockets. While there
are many other gems available, this combination provides the highest performance benefits
in all types of content.

2.

### Best Enchants and Weapon Augments

[[item:243733]] is the best weapon oil to use.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>[[item:273072]]</td>&#10;</tr>&#10;<tr>&#10;<td>Head</td>&#10;<td>[[item:244007]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>[[item:243991]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:244641]]</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>[[item:243953]]</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>[[item:243957]]</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

In general, [[item:241322]] is the best flask to use. However,
other secondary stat flasks are alternative options depending on the stats that your
equipped gear provides. You will have to sim yourself to figure out whether another
flask might be better, but the Magister's flask will serve you well in most scenarios.

3.2.

#### Potions

The best potion to use is [[item:241288]]. However, it requires 
minimizing its downside by having close to 0 Versatility, and not having Haste as your highest secondary stat. 
If either of these apply to you, [[item:241308]] can be a stronger choice.

[[item:271883]] is the best option you have for a health potion.
Using this has a 5-minute cooldown, but multiple can be consumed in an extended boss
fight should it go on long enough. Additionally, Warlock's
[[item:5512]] does not share a cooldown with other healing consumables.
Remember to use it as well if you are holding one!

3.3.

#### Food Buff

[[item:242275]] and other similar food that buffs your Strength are the
best food to use. If a feast is placed, we recommend eating from it instead as it also
provides Stamina alongside the primary or secondary stat.

3.4.

#### Augment Rune

If you want to (and can afford to) use them, [[item:259085]] is the
best choice.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Aug. 2026:** Updated enchant recommendations.
- **11 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 Apr. 2026:** Updated recommendations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **24 Mar. 2026:** Updated recommendations.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **05 Mar. 2026:** Updated enchant recommendations.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Aug. 2023:** Updated all recommendations.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **05 Apr. 2023:** Primordial Stone update.
- **21 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Dec. 2022:** Added fallback Versatility Phial.
- **11 Dec. 2022:** Added fallback Phial and Potion options.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Retribution Paladin in World of Warcraft Patch 12.1.5.

1.

### Retribution Paladin in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Retribution Paladin in
Mythic+ dungeons, including the best ways to set up your character, how your
rotation may change, and tips and tricks for optimally using your abilities.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our dedicated Mythic+ page below.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar Build

2.1.

#### Best Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar Talent Build for Retribution Paladin

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar generally has stronger instant burst and single-target 
 damage than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun, but worse sustained cleave. It also has 
 stronger defensive options.

This build drops the worst single-target talents for stronger AoE 
options. The main choices to make in Mythic+ for damage are just between whether you want to prioritize 
single-target or AoE damage. For more AoE, the only realistic option to take is 
[[spell:382536]], which you would take instead of [[spell:204979]]. 
Swapping [[spell:343527]] for [[spell:458359]] will also give you 
smoother cooldowns since they will never be desynced, and are easier to use 
when playing with tanks with unorthodox pulling strategies or routes.

**Use the 'Export Talents' button to import the best build directly into your game.**

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAMz02Mz2MAgNADAGzwAzYmZDLzghxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3ONddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-bYWAQMpQJw4QAJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Build

2.2.

#### Best Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun Talent Build for Retribution Paladin

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun has stronger cleave on multiple targets during 
 longer pulls than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar, but longer cooldowns between burst 
 windows and worse survivability.

This build drops the worst single-target talents for stronger AoE 
options. The main choices to make in Mythic+ for damage are just between whether you want to prioritize 
single-target or AoE damage. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) Herald of the Sun has no real options for more AoE. 
Swapping [[spell:343527]] for [[spell:458359]] will also give you 
more smoother cooldowns, since they will never be desynced and are easier to use 
when playing with tanks with unorthodox pulling strategies.

**Use the 'Export Talents' button to import the best build directly into your game.**

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-WaYIEKUOCYMEJA-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns, and Stops

3.1.

#### Interrupts, Stuns, and Stops

- [[spell:96231]] is your regular short cooldown interrupt. Use it first if you need to interrupt spellcasting.
- [[spell:853]] is a single-target stun with a very long 6-second
  duration. Use it often to stun-casting mobs that you cannot interrupt with
  [[spell:96231]].
- [[spell:115750]] can be used to disorient enemies within 10 yards.
  This can be used as an AoE interrupt for crowd-controllable casting enemies.
- With a 5-second duration, [[spell:255937]] is a very potent AoE stun, but it
   only works against Demon and Undead enemies.
- [[spell:10326]] fears an Undead, Aberration, or Demon target within 20
  yards for up to 40 sec.

### Other Utility

3.2.

#### Other Utility

- [[spell:391054]] allows you to bring an ally back to life during combat.
- Activate [[spell:465]] to reduce all damage taken by your group by 3%.
- [[spell:213644]] can remove all Poison and Disease effects
  from a group member.
- [[spell:1022]] removes bleeds and other Physical
  damage effects. Additionally, it grants your target immunity to Physical damage
  and harmful effects for 10 seconds. It is often used on group members who
  pulled aggro from the tank via damage or healing.
- [[spell:6940]] reduces damage taken by a party member by 30%,
  but you suffer 100% of damage prevented. It lasts 12 seconds, or until transferred
  damage would cause you to fall below 20% health. Communicate with your tank
  and healer to plan when to use this.
- [[spell:1044]] removes and prevents movement-impairing
  effects for 8 seconds.
- [[spell:633]] heals a friendly target for an amount equal to your
  maximum Health.
- [[spell:85673]] can also be used as a heal if necessary, but as it costs Holy Power, you will lose
  a significant amount of damage if you cast it too frequently.

4.

### Dealing with Affixes

This section has Retribution-specific tips for dealing with the various
affixes of Mythic+.

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Retribution Paladin

[[spell:115750]] is our only AoE stop that will deal with the orbs. You can use single-target CC and interrupts
like [[spell:853]] and [[spell:96231]] if necessary too.

### Affix: Voidbound

4.2.

#### Voidbound Affix Management for Retribution Paladin

Just focus down the Void Emissary when it spawns. You will not need to take any different talents for this.

### Affix: Pulsar

4.3.

#### Pulsar Affix Management for Retribution Paladin

Soak orbs orbiting other players when they spawn. Try to keep a charge of [[spell:190784]] available for this.

### Affix: Devour

4.4.

#### Devour Affix Management for Retribution Paladin

[[spell:213644]] and healing abilities like [[spell:85673]] and [[spell:633]] can be used to remove this debuff. 
[[spell:1044]] also removes it, and can be used with [[spell:305394]] on 
another player to remove both of your debuffs at once.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Aug. 2026:** Updated builds.
- **11 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 Apr. 2026:** Updated recommendations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **24 Mar. 2026:** Updated builds.
- **17 Mar. 2026:** Updated for hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **03 Mar. 2025:** Updated discussion.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **08 Oct. 2024:** Updated for hotfixes.
- **25 Sep. 2024:** Updated dungeon tips.
- **09 Sep. 2024:** Updated for TWW Season 1.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated talent builds and ability discussion for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **24 May 2023:** Updated talents and affix tips.
- **01 May 2023:** Updated for Patch 10.1.
- **21 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **17 Jan. 2023:** Updated 2-min talents.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Retribution Paladin in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Retribution Paladin macros.

1.1.

#### Generic Macros for Paladins

These macros will let you cast your Blessing spells on party members using mouseover macros. They will cast the ability on a 
friendly target if you have your cursor hovered over one. Otherwise, the ability will be cast on your target or yourself as normal.

#### Blessing of Protection Macro

```wow-macro
#showtooltip Blessing of Protection
/cast [@mouseover,noharm,exists] [] Blessing of Protection
```

#### Blessing of Freedom Macro

```wow-macro
#showtooltip Blessing of Freedom
/cast [@mouseover,noharm,exists] [] Blessing of Freedom
```

#### Blessing of Sacrifice Macro

```wow-macro
#showtooltip Blessing of Sacrifice
/cast [@mouseover,noharm,exists] [] Blessing of Sacrifice
```

1.1.1.

##### Intercession Mouseover Macro

#### Intercession Macro

```wow-macro
#showtooltip Intercession
/cast [@mouseover,dead,exists] [] Intercession
```

1.1.2.

##### Lay on Hands Mouseover Macro

#### Lay on Hands Macro

```wow-macro
#showtooltip Lay on Hands
/stopcasting
/cast [@mouseover,noharm,exists] [] Lay on Hands
```

1.1.3.

##### Cleanse Toxins Mouseover Macro

#### Cleanse Toxin Macro

```wow-macro
#showtooltip Cleanse Toxins
/cast [@mouseover,noharm,exists] [] Cleanse Toxins
```

1.1.4.

##### Rebuke Focus Macro

#### Rebuke Focus Macro

```wow-macro
#showtooltip Rebuke
/cast [@focus,harm,nodead] [] Rebuke
```

This macro will cast [[spell:96231]] on your focus target if you have an enemy focused, 
and otherwise will cast it on your current target.

2.

### Best Addons

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.1.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.2.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.2.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.2.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.2.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.3.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.3.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **21 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
