## 专精概览

Welcome to our Discipline Priest guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to heal as a Discipline Priest in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your output.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Discipline Mythic+ Resources

[NEW! Top Discipline Talent Builds](<https://raider.io/specs/discipline-priest/talents>)

[Top Discipline Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/priest/discipline>)

[Discipline Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=priest--discipline>)

[Popular Discipline Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=priest--discipline>)

1.

### Discipline Priest Overview

[Discipline Priest](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-guide>) relies on healing players through dealing
damage (thanks to the [[spell:81749]] passive), but also has traditional
heals and absorption spells. Healing through dealing damage allows Discipline
Priests to contribute to the group's DPS while still performing the duties of
a full healer.

Balancing healing and dealing damage can be difficult to master at first, but
through research and practice, Discipline can be one of the more rewarding
specializations to play.

[观看原文视频](<https://www.youtube.com/embed/ZvNB6c0QPL4?si=bi98pvfQpiJbL87k>)

Solid Output

Discipline Priest delivers strong, consistent healing through [[spell:81749]]
as well as strong effective HP pool increases
via [[spell:17]], [[spell:238063]], and [[spell:62618]].
This allows disc to provide significant contribution in both raw HPS as well as
in mitigating damage through damage reduction or shields.

Top Performer

Discipline Priest provides a very strong amount of overall healing output while
also providing some incredible value in other places in a raid environment.
With all of Discipline's damage coming at basically no opportunity cost there
are scenarios where Discipline can provide a significant amount of DPS while
other healers are forced to spend their GCDs healing. Disipline also brings
[[spell:10060]] to add to the strong DPS it provides itself.

Additionally, Discipline Priest can
bring multiple potential forms of Damage Reduction in [[spell:238063]] and
[[spell:62618]], as well as multiple charges of the incredibly
powerful external, [[spell:33206]].

Finally, Discipline also brings
[[spell:10060]], something that all priests bring, to provide a significant
damage boost to a single DPS in the raid.

Middle of the Pack Performance

Discipline Priest is in an ok spot in Mythic+ content currently. While
it is not the preferred healer for the highest level keys at the moment, it is very
capable of completing weekly keys with ease. With both solid damage contribution
and solid AoE healing, Discipline is able to keep up
with most required healing checks while contributing a good amount of DPS for
the group.

Niche But Incredibly Powerful

While Discipline Priest utility can be incredibly strong, it also tends to be very
niche.

[[spell:8122]] and [[spell:10060]] are the only skills
that are very frequently used. [[spell:9484]] and [[spell:205364]]
are much more niche and see minimal usage, but when they can be leveraged they are
very potent tools that round out our utility kit. [[spell:32375]] can be
incredibly powerful if an encounter has a mechanic that can be trivialized by it,
but those encounters are fairly limited in recent history.

Finally, [[spell:453]] occasionally sees use in Mythic+ content to skip
certain packs for specific routes, matching [[spell:114018]] in value
but without the 6-minute cooldown.

Worse Than Average

Priest survivability, and Discipline Priest specifically, has historically been
one of the major weaknesses of the class. While we have some tools available to
us, our overall defensive package is quite a bit weaker than the average.

[[spell:19236]] is our primary defensive cooldown and simply provides
an increase to your max HP for a short duration, along with a heal for the same
amount. This is different from most classes who gain powerful defensive abilities
that grant strong damage reduction effects instead.

Outside of that, we have a few options for
small damage reductions. [[spell:373446]] provides a 10% damage
reduction when you press [[spell:586]] and [[spell:193063]] provides
an additional 10% damage reduction when you cast a [[spell:2061]] on
yourself.

Combining all of these effects will allow you to survive the necessary
mechanics, but it requires micromanaging multiple small effects to meet the
bare minimum defensive capabilities of most encounters.

Very Poor Mobility

Mobility is yet another category where Priest struggles. Our only real mobility
tool is [[spell:121536]], which simply provides a moderate movement speed
increase for a short duration. Outside of that, [[spell:64129]] is
available, but as a Discipline Priest, [[spell:17]] is often part
of our actual healing rotation, so using it for mobility can be difficult.

With no displacement mobility option like [[spell:1953]], there are many encounters
and mechanics that either require near-perfect positioning and play from the Priest,
or assistance from external sources, like [[spell:370665]] from an Evoker, to solve.

2.

### Discipline Priest in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 brings two new forms of content, a one boss Raid and a new 
  Labyrinth Mega-Delve. Take a look at our guides to both new pieces of content 
  linked below:

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
a Trinket, Ring, and Legs. Additionally, you will be able to upgrade items with 
[[item:280562]] starting October 20th. Weapons, Necks, and Trinkets can all 
be upgraded.

2.3.

#### Class Changes

Unfortunately, Discipline Priest has received no class changes going into 
  Patch 12.1.5.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_rapture.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class ChangesHide Patch 12.1 Class Changes
Patch 12.1 introduces a significant amount of class changes that heavily 
  impact playstyle. The following is a summary of what you need to know going 
  into the new season:

[12.1 Patch Notes](<https://us.forums.blizzard.com/en/wow/t/midnight-curse-of-ulatek-ptr-development-notes/2317811>)

**Discipline Priest:**

- Developers’ notes: For Discipline in Curse of Ula’tek, our changes 
            are aimed at reducing the spec’s reliance on procs for effective 
            healing, improving sources of consistent damage, and improving Hero 
            talent balance. We felt the spec was too reliant on Shadow Mend and 
            Void Shield procs for effective healing, so we’re updating Shadow Mend 
            to be a passive upgrade to Flash Heal and adding a deterministic way 
            to gain access to Void Shield. Additionally, Smite contributes a low 
            amount of damage despite being frequently cast, so we’re increasing 
            its damage and updating the talent tree for easier access to Greater 
            Smite.

- [[spell:186263]]: Updated to be a passive upgrade to [[spell:2061]]
- [[spell:1253593]]: Added deterministic way to gain access via 
      [[spell:8092]]. Deck size has also been increased to 4 to compensate. 
      Void Shield's Absorption effect was also nerfed to shift power into 
      other portions of the spec. Additionally, the buff granting Void Shield 
      can now stack to 2 to prevent situations where you lose a proc by casting
      Mind Blast and [[spell:47540]] in quick succession and getting a proc 
      from both.
- [[spell:81749]] scaling has been adjusted to fall off more harshly 
      after 5 targets.
- [[spell:1253724]]: is now a one point talent (was 2) and the duration 
      of the buff is now 4 seconds instead of 2.
- [[spell:373427]]: was nerfed by 30%, bringing the power of the 
      pet package down greatly.
- [[spell:585]]: increased the damage done by 40%. Additionally 
      [[spell:450405]] damage was increased by a further 25% AND [[spell:450612]]
      was increased from 50% to 75%, resulting in a massive increase to Void Blast's
      healing.
- [[spell:47540]] no longer applies Atonement, so the playstyle of 
      exclusively defensively casting outside of DoT spread purposes is dead.

:::

:::details Show August 18th HotfixesHide August 18th Hotfixes
[August 18th Hotfixes](<https://us.forums.blizzard.com/en/wow/t/class-tuning-incoming-%E2%80%93-august-18/2336820>)

**Discipline Priest:**

- Developers’ notes: We are reducing Discipline Priest’s damage done 
            and offsetting this in Atonement to not affect their overall healing 
            as their damage has been overperforming compared to other healers. At 
            the same time, we are increasing the damage of Entropic Rift to 
            minimize the impact this will have on Voidweaver’s dungeon viability 
            and help maintain high damage as one of its strengths.

- All damage reduced by 30%. Does not affect PvP combat.
- [[spell:447444]] damage increased by 20%/
- [[spell:81749]] now transfers 46% of damage into healing (was 32%).
      Does not affect PvP combat.
- [[spell:1253593]] now reflects 10% of damage absorbed (was 15%).

As described by the developers in the blue post, these changes are meant to
  bring down Discipline's incredible single target DPS without impacting their 
  healing. These changes result in basically no change in our Healing.

With that in mind, these changes do not result in any changes to recommended
  talents choices or gameplay decisions.

:::

:::

### Midnight   Changes Overview

2.4.

#### Major Changes to Discipline Priest in Midnight

Going into Midnight, the developers have pushed a significant number of 
    changes targeting healers in general with the goal of reducing the number 
    of cooldowns in the game, reducing burst healing, and in general flattening 
    and slowing down healing. The following as the quote provided about their 
    goals with Discipline Priest moving into Midnight.

[Midnight Alpha Test Development Notes](<https://eu.forums.blizzard.com/en/wow/t/midnight-alpha-test-development-notes/590289>)

Developers’ notes: The primary aim of these changes is to consolidate and
         remove cooldowns and damage/healing modifiers to make base spell casts
         feel strong. With removing Schism, Shadow Covenant, and several
         supporting talents, we can focus on Mind Blast, Penance, and Shadow
         Word: Pain dealing solid consistent damage, so you can access chunky
         burst healing on a more consistent cadence. Evangelism has also been
         redesigned as a way to quickly apply Atonements to allies in raids,
         providing a much snappier way to ramp up your area of effect healing.
         The result should be a smoother gameplay experience that requires a
         little less planning and aura tracking, but still retains depth.

With that in mind, the following is a list of the major gameplay related 
    changes to be aware of going into Midnight.

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle has been redesigned and no longer has any active 
          abilities to maintain. Instead, you get a second charge of 
          [[spell:47540]] and a handful of other passive benefits.
- [[spell:472433]] has been redesigned. Instead of simply extending
          your active [[spell:81749]]s, it now instantly casts a
          [[spell:194509]] and then makes your next 2 Radiance casts 
          instant cast. This drastically simplifies your ramp sequences in Raid 
          as Evangelism with two Radiance charges can cover 15 Atonements on its 
          own very quickly.
- [[spell:200829]] has been added to our class tree to fill the same
          niche [[spell:139]] did previously. This allows us to have an instant
          cast [[spell:81749]] applicator that is cheaper than
          [[spell:2061]].
- All pets like Shadowfiend and Mindbender are no longer active abilities 
          and are now passive effects that summon said pets via various activation 
          criteria. [[spell:34433]] is a new talent that can summon a pet 
          when hitting [[spell:32379]] on an execute target. 
          [[spell:123040]] is a talent that summons a Mindbender when
          you cast [[spell:472433]]. Finally, [[spell:451234]] now summons 
          a Void Wraith when your [[spell:447444]] ends.
- With all of your pets no longer active buttons, [[spell:314867]]
          has been removed and replaced with a simple passive Shadow damage and 
          healing increase in [[spell:1250293]].
- [[spell:421453]] and [[spell:62618]] now share a 
          choice node with each other, forcing you to pick either one at a time.

2.5.

#### Apex Talent for Discipline Priest in Midnight

Discipline Priest's Apex talent, Master the Darkness, has 4 total ranks with 
three different effects in total. The first [[spell:1253590]], 
provides a 30% chance for your next [[spell:17]] after 
casting [[spell:47540]] to be turned into [[spell:1253593]]. This shield 
is significantly stronger than normal and splashes to two additional nearby 
allies. Your second and third ranks of Master the Darkness,
[[spell:1253845]], are simple passive nodes increasing both your 
overall [[spell:81749]] healing and all shadow damage per rank. 
Finally, your fourth rank of Master the Darkness, [[spell:1253827]],
causes a percentage of your [[spell:1253593]] amount to be reflected back 
as damage when absorbed. This damage does contribute to healing through 
[[spell:81749]], making this talent incredibly powerful.

3.

### Basics of Discipline Priest Gameplay

Discipline Priest playstyle can vary patch to patch depending on what 
specific build we are playing due to tuning. Some builds like this season's 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver build are incredibly damage/[[spell:81749]] focused 
where 75-80% of your total output will be Atonement as well as other seasons
where tuning leans more towards your direct healing spells like
[[spell:2061]]/[[spell:186263]] and [[spell:17]]. 
Regardless of the build, the core gameplay of Discipline Priest is to focus 
on balancing your damage globals and your Atonement application globals to 
maximize your output.

The basics of Discipline Priest can be described using the three following concepts.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_penance.jpg>) **Don't Overcap Penance**  
  
  The sheer amount of power and other procs tied to [[spell:47540]] makes it 
  incredibly important to simply be casting this as often as possible. Ensuring 
  you are **NEVER** sitting on multiple charges of Penance available will 
  provide you significant output from the Penance casts themselves, help proc
  more [[spell:1253593]]s, and reduce the cooldown of your [[spell:8092]]
  via your 2-piece tier set bonus which in turn results in more Void Shield procs.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_plea_yellow.jpg>) **Don't Overuse Applicators**  
   
  Many new players get stuck in the trap of not trusting their [[spell:81749]] 
  enough and quickly falling back into either spamming direct heals or simply 
  overapplying Atonement thinking they need to be actively "healing" instead of 
  pressing a filler DPS button. Not only is this incredibly mana inefficient and
  will quickly result in you having mana issues, but Discipline requires a 
  delicate balance between the two. It is incredibly important to actually be 
  DPSing and utilizing the Atonement's you have active instead of rushing to 
  simply apply more.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_priest_voidshield.jpg>) **The Importance of Void Shield**  
  
  Many people do not realize how significant the damage [[spell:1253593]] does 
  is. Many new players will simply cast Void Shield and assume the absorb itself 
  is the full value of the spell. Not only is it a fantastic Atonement applicator,
  applying Atonement to 3 targets at once, the damage it reflects results in a 
  significant amount of Atonement healing. As a result, in some situations it can 
  make sense to hold the Void Shield cast until the party has taken a bit of damage 
  first so that all the reflected Atonement healing isn't instantly overhealing.

4.

### How to Gear Up as a Discipline Priest

Take a look at our dedicated Discipline gearing page. We currently cover 
  recommendations for Season Two gear to start off as soon as the Season goes 
  live. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.5 release.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5 release.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated embellishment recommendations based on recent Ritual Stone nerf.
- **18 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Fixed typo.
- **18 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Fixed missed outdated reference.
- **18 Aug. 2026 (this page):** Updated additional August 18th hotfix note.
- **17 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Fixed evang sequence formatting and added raid boss info.
- **17 Aug. 2026 (this page):** Added pre-season class tuning.
- **16 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Adjust trinket recommendations based on recent trinket tuning.
- **16 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Replaced VW food recommendation with new Coiled Isle food
- **11 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Various formatting and typo fixes.
- **11 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Added a note to the Penance No Channeling Macro.
- **11 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Various formatting fixes.
- **11 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Various formatting fixes.
- **11 Aug. 2026 (this page):** Added mention of Void Shield stacking to 2 charges and fixed a broken link.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Season 2 release.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Season 2 release.
- **10 Aug. 2026 (this page):** Updated for Season 2 release.
- **15 Jul. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated enchant/gem recommendations.
- **15 Jul. 2026 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated stat recommendations.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated with Patch 12.0.7 Sporefall gear.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.7 and Omnium Folio.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **20 May 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Fixed visual coloring of items in the BiS lists.
- **20 May 2026 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Added mention of Power Word: Toolbox.
- **20 May 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated page formatting to be more consistent with other guides.
- **20 May 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Fixed minor formatting issue and adjusted the ordering of some advanced sections.
- **20 May 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Fixed incorrect delve talent build.
- **20 May 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Fixed header typo and expanded general gameplay description.
- **04 May 2026 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated stat prio to reflect further sequence optimizations.
- **04 May 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Added sections for a few advanced topics.
- **04 May 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Added mention of Deck system for Void Shield.
- **04 May 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Fixed incorrect mention of an outdated talent.
- **04 May 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Added a few missing mentions
- **04 May 2026 (this page):** Updated Raid performance to reflect recent nerfs.
- **22 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated embellishment and bis list recommendations based on recent class tuning.
- **22 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Fixed error in Evangelism description.
- **22 Apr. 2026 (this page):** Swapped video link to 12.0.5 video.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **26 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated trinket recommendations post hotfixes.
- **26 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated weapon enchant recommendation.
- **26 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Fixed ramp rotation sequences post tier set bug fix.
- **24 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Removed mention of Tea post hotfix.
- **21 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated trinket recommendations based on better data from live servers.
- **21 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated talent recommendations post upcoming class tuning.
- **21 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated talent recommendations post upcoming class tuning.
- **21 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated talent recommendations post upcoming class tuning.
- **21 Mar. 2026 (this page):** Updated for upcoming class tuning.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Season 1 Midnight Release.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for Season 1 release.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated trinket recommendations following Gaze nerf.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated for Season 1 release.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for Season 1 Release.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Season 1 Release.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Season 1 release.
- **16 Mar. 2026 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Season 1 release.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Season 1 Midnight Release.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Season 1 Midnight Release.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1 Release.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Added talent import code for starting at level 80.
- **02 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Fixed food recommendation error.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Midnight release.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for Midnight release.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated for Midnight release.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for Midnight release.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated for Midnight release.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight release.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Midnight Release.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Midnight release.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Midnight release.
- **26 Feb. 2026 (this page):** Updated for Midnight Release.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated Shackle Undead to Shackle Horror
- **10 Feb. 2026 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated Shackle Undead to Shackle Horror
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 (this page):** Updated Shackle Undead to Shackle Horror
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 (this page):** Updated for Midnight pre-patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Added Dinar Section.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **14 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated page to include Nexus-Kings Command Trinket Information.
- **10 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Adding missing trinket and updated crafting recommendations.
- **10 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Fixed issue with tier set check box in Oracle Evang rotation.
- **10 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Fixed some typos on page.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for Season 3 release.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for patch 11.2.
- **17 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated D.I.S.C recommendation.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Added information on the D.I.S.C Belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Added Combat Assistant information.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Added Combat Assistant Section.
- **15 Jun. 2025 (this page):** Updated for patch 11.1.7.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** updated Puzzling Cartel Chip Section.
- **12 May 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Updated CDs for a handful of Mythic bosses.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Added Puzzling Cartel Chip Section for 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Added section for Corruption Enchants.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Added mention of post 11.1 Tuning changes.
- **03 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Minor Typo Fixes.
- **02 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Formatting Fix
- **01 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Updated to include some talent adjustments + added more bosses.
- **01 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Added more information about Oracle in M+
- **01 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated post recent tuning.
- **24 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated post trinket tuning.
- **24 Mar. 2025 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated post Discipline Nerfs.
- **24 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Added section describing adapting your output windows to boss damage patterns.
- **24 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated post Discipline Nerfs.
- **16 Mar. 2025 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated Premo macro to a slightly more consistent version.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Fixed incorrect talent string on Cauldron on Carnage.
- **16 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated rotation to reflect removal of the Weal and Woe Spell Queue Interaction.
- **13 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Added Viserio links below each example CDs. Added initial Mythic boss plans.
- **11 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Updated post week 1 with the remainder of the Heroic timers and information.
- **03 Mar. 2025 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Adjusted NoChanneling Macro.
- **03 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Updated for Raid Release.
- **02 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Fixed formatting issue.
- **01 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated Circlet recommendation based on recent tuning.
- **01 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated post recent tuning.
- **01 Mar. 2025 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated based on recent tuning.
- **01 Mar. 2025 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Swapped talent strings to 11.1 talents.
- **01 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated based on recent tuning.
- **01 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated post recent tuning.
- **01 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated post recent tuning.
- **01 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated post recent tuning.
- **28 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Added note to insight spell queue macro.
- **25 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Fixed broken link on page.
- **25 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Fixed small typo in Oracle Rotation.
- **25 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Fixed incorrect talent string.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Swapped Weapon Enchant/Added alternative Consumables for Oracle.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated Stat Prio slightly moving into 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Patch 11.1.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated Cyrce's Circlet info based on further TC Work.
- **16 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated following Cyrce's Circlet Buff.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Added section for Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Added section mentioning no changes for Siren Isle patch.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Added section talking about on use trinket usage.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Added recommended Weakaura and Grid2 Profiles.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Added additional Mythic boss tips.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Removed some outdated references.
- **21 Oct. 2024 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated Ultimate Penitence usage section.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Added flexible point and some additional talent discussions.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Added section mentioning no changes in new patch.
- **17 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Updated raid guide post heroic week
- **14 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Added example timers for Heroic Queen Ansurek
- **11 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reordered talent recommendation and added note about bender bug.
- **10 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Added Fatebender rotation switch for Oracle.
- **10 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Added section clarifying expected pet CDs.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated page for Season 1 Release.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated food and gem recommendations.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated page for Season 1 Release.
- **09 Sep. 2024 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for season 1 release.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **26 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Swapped chest enchant recommendation.
- **26 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Fixed raid string import issue.
- **22 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated Embellishments following tuning.
- **22 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reformated page for easier reading.
- **22 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Fixed m+ talent tree linking to the old patch talents.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for The War Within Release.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for The War Within Release.
- **21 Aug. 2024 (this page):** Updated for The War Within Release.
- **23 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/discipline-priest-the-war-within-pve-guide>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/discipline-priest-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **18 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/discipline-priest-the-war-within-pve-guide>)):** Added Page.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/discipline-priest-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Season 4.
- **22 Apr. 2024 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Updated for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **27 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **27 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.6
- **27 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6 and updated food recommendation.
- **27 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.6
- **27 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.2.6
- **27 Mar. 2024 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 10.2.6
- **27 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6
- **27 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.2.6
- **27 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.6
- **27 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.6
- **27 Mar. 2024 (this page):** Reviewed for Patch 10.2.6
- **16 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Adjusted wording on Dreaming Devotion enchant.
- **16 Jan. 2024 (this page):** Fixed recent changes section.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **11 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Fixed Health Potion Mention.
- **11 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Removed outdated mention.
- **11 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Fixed small rotation issue.
- **07 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated page for Patch 10.2
- **07 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Added additional clarification.
- **07 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 10.2.
- **07 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Removed outdated reference.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Added mention of new Weapon enchant and Helm enchant for 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Patch 10.2
- **06 Nov. 2023 (this page):** Updated for Patch 10.2
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for patch 10.1.7.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for patch 10.1.7.
- **04 Sep. 2023 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Reviewed for Patch 10.1.7
- **10 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated rotation to reflect Rhapsody hotfix.
- **10 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated post hotfix to Rhapsody and VE.
- **10 Aug. 2023 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated M+ talent recommendations and updated wording for raid.
- **19 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Fixed formatting issue.
- **12 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Fixed talent tree issue.
- **12 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated to new page format.
- **11 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated Annulet recommendation section.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated talent recommendation for 10.1.5.
- **10 Jul. 2023 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Patch 10.1.5
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated Talent recommendations.
- **10 Jul. 2023 (this page):** Reviewed for Patch 10.1.5
- **06 May 2023 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated Enchant and Phial Recommendations based on hotfixes/tuning
- **06 May 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated to include Season 2 Dungeon Specific Talent Choices.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated Primordial Stone Recommendations post Hotfixes.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.1
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Patch 10.0.7.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 10.1
- **01 May 2023 (this page):** Reviewed for Patch 10.1
- **21 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **21 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.7.
- **21 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.0.7.
- **21 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.7.
- **21 Mar. 2023 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **22 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Added Macro for Potion of Chilled Clarity Cancelaura.
- **22 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated talent recommendation for patch 10.0.5.
- **22 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated Rotations to reflect 10.0.5 changes and talent changes.
- **22 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated talent recommendation for patch 10.0.5.
- **22 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated Spell list to reflect 10.0.5 changes.
- **22 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated talent recommendation for patch 10.0.5.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated Halo/DStar macro to work with Scov.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Removed missed mentions of Shining Force on page.
- **11 Dec. 2022 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Reformatted the page to utilize build toggles.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Fixed Talent Calculator M+ Link.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Moved SotM to the proper location and added Blaze of Light.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/discipline-priest-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/discipline-priest-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/discipline-priest-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **31 May 2022 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Page reviewed for Patch 9.2.5.
- **22 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/discipline-priest-patch-9-2-changes-analysis>)):** Page updated for Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/discipline-priest-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/discipline-priest-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **14 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/discipline-priest-patch-9-1-changes-analysis>)):** Updated page to reflect the launch of Patch 9.1.
- **29 Jun. 2021 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Updated for Patch 9.1.
- **07 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/discipline-priest-patch-9-1-changes-analysis>)):** Added new covenant legendaries.
- **04 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/discipline-priest-patch-9-1-changes-analysis>)):** Page created with initial information.
- **09 Mar. 2021 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Reviewed for Patch 9.0.5.
- **04 Feb. 2021 ([DPS guide](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** Page added.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **07 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-the-eternal-palace-raid-guide>)):** Added page with raid advice for The Eternal Palace.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **12 May 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** Updated page after peer review.
- **12 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-crucible-of-storms-raid-guide>)):** Updated guide with Live data instead of PTR testing. .
- **16 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-crucible-of-storms-raid-guide>)):** Guide added.
- **20 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** Added Battle of Dazar'alor tips for Discipline Priest.
- **11 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-uldir-raid-guide>)):** Updated formatting for talent selection.
- **11 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-uldir-raid-guide>)):** Added page with raid advice for Uldir.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Discipline Priest leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Priest leveling guide](<https://www.icy-veins.com/wow/priest-leveling-guide>).

1.

### Discipline Priest Leveling Guide for Midnight

While leveling as a healer is viable, it will generally be much slower 
when playing solo compared to swapping to shadow. However, it is still 
possible to level as a Discipline Priest if you are ok with a slower 
leveling experience. Additionally, leveling as a healer allows you easy 
access to dungeon queues with the healer role generally being in high 
demand resulting in very short queue times.

1.1.

#### Leveling Gear Options

When leveling as a Discipline Priest, always target the gear with the
highest item level available. Looking for specific stats on leveling gear
will not matter, as you will most likely have a fairly large item level gap on
items when you get another of the same slot.

When leveling, Heirlooms are an option to allow the gear you are wearing to 
scale with your level instead of needing to constantly replace your gear 
with pieces from quests or dungeons as you level.

1.2.

#### Useful Leveling Consumables for Midnight

While leveling, adjusting some enchants to focus on speed can help reduce 
downtime when moving from quest to quest. The following is a list of 
movement speed enchants to consider.

- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

Additionally, there are a variety of consumables that can assist while 
leveling in regards to either mobility or combat power. The following is a 
list of items to consider acquiring prior to the release of Midnight:

- [[item:109076]] - These can be useful to traverse terrain 
          quickly, especially in scenarios where you are prevented from mounting.
- [[item:132516]] - These give a large boost of movement speed to 
          quickly move across large distances on the ground.
- [[item:219905]] - If you are leveling with someone that 
          provides [[spell:2825]] or a similar effect, these are not necessary,
          but in scenarios where you do not have access, these can be a solid 
          boost every 10 minutes.
- [[item:212250]] - Invisibility potions can be used 
          to skip areas of mobs that you do not need to kill for a quest to 
          speed up your leveling experience.
- [[item:172063]] or [[item:133576]] - Both of these foods 
          will provide a large burst of movement speed when you kill an 
          enemy.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Discipline Level 80 Midnight Leveling
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsYMzGjxYmZMbsNzMzMzAAAAAAAAAAgBLzgZmZwYmBbmmpZAzAAAYbWAGbGAAGDzYwMYmBjmB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsgZ2YMGzMjZzsNzMzMzAAAAAAAAAAgZYZGMzMDGzMYz0MNDMzAAAMbzyCYsZAAYMmZMYGMzgRzwA"
}
```
:::

:::details 来源计算器编码
```
#AE-WBAkNighObqKKHsoteVuUdZNOZYWkkKYaKA-bcdA0yw69AdlsEFRV9rJswUSy4ZIIBB-AAAA-RYWUKESMEQEY4A-
```

:::

2.1.

#### War Mode Talents for Leveling

1. [[spell:356085]] is a toggle-able ability that grants you either
   10% increased spell damage and [[spell:81749]] healing or 15% less Mana cost
   on healing spells. Leaving this on the damage increase portion while leveling
   will result in a solid DPS and survivability gain.
2. [[spell:391297]] provides a fairly substantial damage increase when soloing 
   content that is actually dealing significant damage to you. In cases where you 
   are playing with others or the content is easy enough you are not taking 
   significant damage, feel free to replace this talent with another.
3. [[spell:1218211]] increases your damage and the damage of all
   allies with your [[spell:81749]] by 15% for 8 seconds. This is great for
   small group world content where giving your group a DPS buff will be more
   impactful than taking a small boost to your own damage via any of the above
   three talents.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 4 起：**Cast [[spell:17]] on yourself if your HP
   has begun to drop.
2. **等级 18 起：**Cast [[spell:10060]] on cooldown.
3. **等级 2 起：**Maintain [[spell:589]]
   on all targets unless the target will die before a significant portion of the
   DoT ticks.
4. **等级 28 起：**Cast [[spell:32379]] if the target is below
   20% HP. Be careful not to kill yourself with this spell.
5. **等级 11 起：**Cast [[spell:47540]] on cooldown.
6. **等级 5 起：**Cast [[spell:8092]] on cooldown.
7. **等级 1 起：**Cast [[spell:585]] as your filler.

Starting at level 15, you can queue for dungeons with the in-game
group finder. The following is a general priority list of healing spells in dungeons:

1. **等级 4 起：**Cast [[spell:17]] on cooldown if a single player
   is taking damage.
2. **等级 15 起：**Cast [[spell:194509]] when it is available
   and you have multiple people that need Atonement at the same time.
3. **等级 3 起：**Cast [[spell:2061]] when you
   need to direct heal someone if your [[spell:81749]] healing is not enough.

In situations where your passive Atonement healing or shields are not enough, 
you have some Cooldowns to fall back on. The following is a list of the 
cooldowns you can utilize when incoming damage is high:

1. **等级 19 起：**Cast [[spell:421453]] on an enemy after 
   applying Atonement to your full group with a [[spell:194509]].
2. **等级 35 起：**Cast [[spell:472433]] if there is a lot of damage
   occuring for an instant heal and Atonement coverage.
   **等级 37 起：**Cast [[spell:33206]] on either the tank 
   or another player that is taking significant single target damage.

In addition to these baseline abilities, there is a passive effect that is
crucial to understand leveling as a Discipline Priest.

[[spell:81749]] causes your damaging spells to heal all targets with
Atonement on them. It is crucial that you DPS to utilize your Atonements applied
instead of getting stuck in the habit of spamming direct heals. Follow the
healing spell priority list above to apply Atonement, and then once all players
taking damage have Atonement on them, follow the damage spell priority list.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Season 2 release.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Season 1 Midnight Release.
- **02 Mar. 2026:** Added talent import code for starting at level 80.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **27 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **12 Jul. 2023:** Fixed talent tree issue.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **21 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Discipline Priest in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Discipline Priest

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Discipline Priests rely on healing players by dealing damage (through
[[spell:81749]]), but also has traditional heals and absorption spells, which
are to be used in situations where Atonement is not sufficient.
Healing through dealing damage allows them to contribute to the group's DPS
while still performing the job of a full healer.

With the current design of Discipline, there are a few rules to follow 
that will help you learn the spec easier.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_penance.jpg>) **Don't Overcap Penance**  
  
    The sheer amount of power and other procs tied to [[spell:47540]] makes it 
  incredibly important to simply be casting this as often as possible. Ensuring 
  you are **NEVER** sitting on multiple charges of Penance available will 
  provide you significant output from the Penance casts themselves, help proc
  more [[spell:1253593]]s, and reduce the cooldown of your [[spell:8092]]
  via your 2-piece tier set bonus which in turn results in more Void Shield procs.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_plea_yellow.jpg>) **Don't Overuse Applicators**  
   
    Many new players get stuck in the trap of not trusting their [[spell:81749]] 
  enough and quickly falling back into either spamming direct heals or simply 
  overapplying Atonement thinking they need to be actively "healing" instead of 
  pressing a filler DPS button. Not only is this incredibly mana inefficient and
  will quickly result in you having mana issues, but Discipline requires a 
  delicate balance between the two. It is incredibly important to actually be 
  DPSing and utilizing the Atonement's you have active instead of rushing to 
  simply apply more.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_priest_voidshield.jpg>) **The Importance of Void Shield**  
  
    Many people do not realize how significant the damage [[spell:1253593]] does 
  is. Many new players will simply cast Void Shield and assume the absorb itself 
  is the full value of the spell. Not only is it a fantastic Atonement applicator,
  applying Atonement to 3 targets at once, the damage it reflects results in a 
  significant amount of Atonement healing. As a result, in some situations it can 
  make sense to hold the Void Shield cast until the party has taken a bit of damage 
  first so that all the reflected Atonement healing isn't instantly overhealing.

2.

### Beginner's Guide to Discipline Priest in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle   Raid Talents

2.1.

#### Beginner Raid Talents for Discipline Priest

This build is a straight forward and simple build in run in Raid. Focus on 
    pressing [[spell:47540]] and [[spell:8092]] on cooldown for damage 
    and to cycle for [[spell:1253593]] procs. Use [[spell:194509]] 
    to apply [[spell:81749]] when healing is needed. Just be careful to not 
    overuse [[spell:17]]/[[spell:2061]]/[[spell:200829]] as you can 
    easily run out of mana if you are not careful.

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMGWmZmBDmZbmtZmZmxMDAAAAAAAAAgZYZGMzMDzYmBMNTzMAzsghwYWGgxgFAAYMmZMYGgZmBYA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWghkANObdeiqstuHKKVoRnGMMSSmmCFWA-bcdeAoqq9los8kFGadhNwwxBi4I5wwE-AAAA-CEMYkow0AUgscA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle   Mythic+ Talents

2.2.

#### Beginner Mythic+ Talents for Discipline Priest

This build is your primary build for Mythic+ content. Focus on casting 
    [[spell:47540]] and [[spell:8092]] on cooldown for damage and to cycle
    for [[spell:1253593]] procs. [[spell:186263]] and swapping your 
    [[spell:47540]] targeting to allies will help you get through single 
    target healing situations when needed.

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGgZA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAacoqq9lskFGadhNQwwxBi4IJ6E-AAAA-CEMYkow0AUgscA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver   Delve Talents

2.3.

#### Beginner Delve Talents for Discipline Priest

This build is your primary build for delve content. Pushing large damage 
windows with your [[spell:447444]] and [[spell:1280137]] to AoE down 
medium sized groups of enemies. Make sure to heavily utilize 
[[spell:205364]] in this content to bring along the strongest enemy 
you can find to fight on your side as they will often do more damage than 
you yourself will. Additionally, make heavy use of [[spell:586]] to 
utilize [[spell:1250378]] to keep focus off yourself so you can 
spend more time dealing damage and less time worrying about your own 
health bar.

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgBbzgZmZGGzMYz0MxgZGAAgZb2WAjNDAAjZmZmBzgZGMCmB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPLukC-bcdeAaoqq9ls8AlFGiF8SckMQYYgwAK-AAAA-FIikwAMUY8wSgC-
```

:::

### Discipline Priest   Basic Rotation

2.4.

#### Basic Playstyle for Discipline Priests

Discipline Priests rely on applying [[spell:81749]] and then dealing
damage to heal through Atonement for a portion of your healing. Direct healing 
via things like [[spell:47540]], [[spell:2061]], or [[spell:186263]] 
(in Mythic+ specifically) as well as strong absorb effects from 
[[spell:17]] or our Apex talent [[spell:1253593]] provide the
rest of your healing.

2.5.

#### Raid Healing

In Raid, you want to generally cast [[spell:47540]] on cooldown. 
[[spell:17]] is strong, but you want to make sure your casts 
are providing good value as if you over-utilize them, you can quickly run 
out of mana. Make sure you use any proc of [[spell:1253593]] that you get.

Combine this with cycling your [[spell:194509]]
charges and you will continuously do a very solid amount of HPS. When looking 
to utilize our primary cooldown, [[spell:472433]], you want to plan
out your usage around major damage events. Try to ensure you have 
[[spell:194509]] charges available to use with Evangelism.

2.6.

#### Dungeon Healing

Your primary focus for dungeon healing will heavily revolve around 
casting [[spell:47540]] on cooldown. With talents like 
[[spell:440742]] and the passive from Penance itself, you get strong 
single target healing and solid [[spell:81749]] healing. Additionally, each
cast has a chance to proc 
[[spell:1253593]], which will is your strongest spell by far in your kit. 
Cycling Penance often for more Void Shield casts is incredibly important. Casting 
[[spell:8092]] on cooldown is also important as it also procs Void Shield.

Additionally, [[spell:186263]] is a major throughput tool in dungeon
content to assist with single target healing. Swapping to defensively casting 
Penance, casting some Shadow Mends, and some Void Shields will be your primary 
single target methods.

2.7.

#### Apex Talent

In most cases our Apex talent is very simple to play around. With the buff 
lasting quite a while once procced, simple ensure you utilize the 
available cast prior to casting your next [[spell:47540]] to not
potentially waste a proc. Outside of that, keep in mind that both the 
primary target of Void Shield and its additional targets will receive 
Atonement.

2.8.

#### Atonement Applicators

- [[spell:200829]] is an instant cast, single target [[spell:81749]]
  applicator with a small direct heal effect tied to it. The largest benefit
  to using Plea is that it can be cast while moving.
- [[spell:17]] is an instant cast, single target Atonement
  applicator with a fairly strong shield tied to it. While this is a very potent
  option for applying Atonement to a single target, it does have a cooldown.
- [[spell:1253593]] is the upgraded version of Power Word: Shield applying 
  a shield on 3 targets instead of one. From an Atonement 
  application perspective, it's very important to understand that all 
  three targets hit by Void Shield will receive Atonement.
- [[spell:2061]] is a 1.5-second cast, single target Atonement
  applicator with a decent-sized single target heal tied to it. With this costing
  more Mana than Plea, as well as requiring you to stand still, it will not see
  nearly as much play as your primary applicator outside of a few situations. The
  first situation where this gains significant strength is when the single target
  heal portion of the spell is relevant. The other would be to abuse other
  talents, like [[spell:109186]] or [[spell:368275]]. When 
  Flash Heal is upgraded to [[spell:186263]], it still 
  applies Atonement and acts as a single target applicator.
- [[spell:194509]] is a 2-second cast, multi-target Atonement
  applicator with a decent heal tied to it. Power Word: Radiance applies
  Atonement to 5 people, but at a reduced duration. This is useful in raids for
  getting large coverage before a major damage event or in M+ to quickly cover
  the whole group in Atonement.

2.9.

#### Cooldowns

- Evangelism
  
  - In Dungeon content, [[spell:472433]] immediately heals your whole group 
    for a non-insignificant amount on cast. Additionally, it causes your next two casts of 
    [[spell:194509]] to be instant cast. This buff lasts forever, so 
    you can hold those Radiance casts for as long as you need them, making this 
    a very strong tool to assist with mobility heavy encounters.
  - In Raiding content, this tool is a primary enabler for what we call a ramp.
    This concept will be described in the next section.
  - Evangelism also activates either [[spell:197862]] or [[spell:1280137]] 
    depending on what one you are talented into. This either buffs all your 
    healing and absorbs for a period of time or summons a pet for a short 
    duration to both deal damage as well as interact with other talents
    such as [[spell:373427]] if talented.
- Ultimate Penitence
  
  - While this spell has an incredibly long cooldown at 4 minutes, its also 
    incredibly powerful. When cast offensively, it will throw bolts at random
    enemies, dealing significant damage which translates to a large amount of
    [[spell:81749]] healing if the group has Atonement active on them.
    When cast defensively, it will throw bolts at injured allies, healing them
    directly.
  - In Raid, you will almost always utilize this offensively with 
    a full ramp sequence described below to ensure proper Atonement coverage.
    Similar to how it is used in raid, it will be used almost exclusively offensively
    in dungeon content as well, but without needing a full ramp sequence to be 
    effective. Still make sure you apply Atonement to the group via a 
    [[spell:194509]] before casting it.
- Power Word: Barrier
  
  - Shares a choice node with [[spell:421453]], 
    meaning you have to choose between one or the other. Power Word: Barrier 
    can be incredibly powerful in any scenario where the incoming damage 
    during its duration is significant enough.
  - Keep in mind that it does 
    require the group and or raid to be able to stack under the barrier for its 
    duration to benefit, so some encounters it is very difficult to use even 
    if the damage intake warrants it. While we are recommending Ultimate Penitence
    by default, keep an eye out for good situations to swap to Power 
    Word: Barrier.
- Pain Suppression
  
  - Provides very large Damage
    Reduction on a single target. Utilizing this either on the tank or on a player
    with a large damage over time effect on them can have a significant impact.
    When running the talent [[spell:373035]], you will have a lot of
    additional casts available of Pain Suppression, so make sure you use it often
    instead of just sitting on maximum charges.

2.9.1.

##### Season 2 Tier Set

Our two piece bonus, [[spell:1296577]], is 
    incredibly powerfuil. It both increases the damage and healing of 
    [[spell:47540]] by 20%, but also causes every Penance cast to reduce the 
    cooldown of Mind Blast by 2 seconds. This is incredibly powerful for a few
    reasons. First, Mind Blast now procs [[spell:1253593]] on cast. With 
    this tier set directly increasing your Mind Blast CPM, its also increasing 
    your Void Shield CPM. Additionally, when playing Voidweaver, this drastically
    increases your access to [[spell:447444]] which is a huge spike in 
    power. This two piece is incredibly important to get as soon as possible.

Our four piece bonus, [[spell:1296578]], 
while not nearly as strong and impactful as our 2-piece bonus, still provides a 
meaningful boost to our output by increasing the size of your next Void 
Shield after casting Mind Blast.

### Discipline Priest   Stat Priority

2.10.

#### Stat Priority for Discipline Priest

The stat priority is as follows **when deciding between equal item level
gear**. For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>).

Haste

Mastery

Critical Strike

Versatility

### Blizzard   Combat Assistant

2.11.

#### Combat Assistant for Discipline Priests

Since Patch 11.1.7, World of Warcraft has an incredible
accessibility function called the Combat Assistant. While I may be praising
this as an accessibility option, its usefulness in regards to healers is questionable. 
The Combat Assistant will never recommend, or in the case of the one button 
rotation press, any cooldowns or healing buttons. For Discipline, it follows 
the following very simple priority list:

1. Maintain Shadow Word: Pain on your active target
2. Cast [[spell:8092]] when available
3. Cast [[spell:47540]] when available
4. Cast [[spell:585]]

Overall, the best use case for this functionality is likely doing open 
world content or delves as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **18 Aug. 2026:** Fixed missed outdated reference.
- **10 Aug. 2026:** Updated for Season 2 release.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 May 2026:** Fixed header typo and expanded general gameplay description.
- **04 May 2026:** Added a few missing mentions
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **21 Mar. 2026:** Updated talent recommendations post upcoming class tuning.
- **16 Mar. 2026:** Updated for Season 1 Midnight Release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added Combat Assistant Section.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Mar. 2025:** Updated post Discipline Nerfs.
- **01 Mar. 2025:** Updated post recent tuning.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **27 Mar. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Aug. 2023:** Updated M+ talent recommendations and updated wording for raid.
- **10 Jul. 2023:** Updated Talent recommendations.
- **01 May 2023:** Reviewed for Patch 10.1
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **22 Jan. 2023:** Updated talent recommendation for patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Discipline Priest in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Discipline Priest

With the changes going into 12.1, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver has received a significant 
	amount of help and does very solid numbers as a result. However, in Mythic+ dungeons
	there are still some significant single-target healing requirements present, which it struggles with.
	As a result, our recommendation for now is ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver in Raid and Delve 
	content, and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle in Mythic+ content. If the single-target healing 
	requirements in dungeons turn out to not be the pressure points we struggle with 
	and Voidweaver is doing well, we will update our recommendations.

- **Raid -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver simply does a large amount of raw 
  	Atonement healing permanently. With the new tier set reducing the cooldown
  of [[spell:8092]], you have a very high uptime on [[spell:447444]]. As 
  a result, your access to a significantly buffed [[spell:450405]] is greatly 
  increased. This spec's largest weakness, however, is movement. So in situations
  where there is very high movement requirements, there could be situations
  where ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle is better. **Voidweaver gains significant value 
  from the new 2-piece set bonus and may feel weak until you have it.**
- **Mythic+ -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle is our recommended build for Mythic+ 
  	content due to its superior single-target healing capabilities. By cycling 
  through Void Shield procs, utilizing 2 charges of defensive [[spell:47540]] 
  more easily as a result of [[spell:440742]], and being less locked to 
  spamming a filler dps spell for output, you get the ability to push 
  single-target healing a bit easier when needed.

**Quick Start Import Codes:**

:::talents Voidweaver Raid
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtFwYzAAwYMzYwMYmBjgB"
}
```
:::

:::talents Oracle Mythic+
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGBzA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Voidweaver

Raid

recommended

Mythic+

Delves

recommended

Oracle

Raid

Mythic+

weekly-keys

high-keys

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Raid Build

This build pushes an incredibly high amount of raw healing throughput at all times.
	With an insanely high uptime on [[spell:447444]], thanks to the new
	tier set reducing the cooldown of [[spell:8092]], your near constant
	access to it results in a very strong amount of permanent HPS. This build
	does, however, struggle with movement, because [[spell:450405]] makes up a very
	large percentage of our CPM with this build. As a result, while it is our
	default recommendation for Raid content based on potential output,
	it is possible that ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle sees play in situations where this spec
	struggles to function properly.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Mythic+ Build

While this build does a lot of raw output, that output is not as flexible as
	the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle alternative.
	While you can easily push a lot of Atonement healing, the single-target
	healing requirements in Mythic+ content are often more difficult to
	keep up with. Additionally, it is fairly common for only a few targets at a time
	to be requiring healing in keys. Voidweaver is lacking any way to
	really push extra Atonement healing into those targets, as the Atonement
	scaling based on targets doesn't do anything until 5 targets, which you'll
	never surpass in keys. As a result, this build is not recommended for
	 Mythic+ content, but could still see play in situations where you're just
	 looking for raw AoE output.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Delve Build

This build is recommended for [Delve](<https://www.icy-veins.com/wow/delves-guide>) content both solo and in groups.
	The Voidweaver talent tree is capable of pushing incredible amounts of
	damage while also keeping you and your group alive.

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Raid Build

This build will be an alternative option for Raid content. While the
	output is not nearly as competitive as Voidweaver, it has the benefit
	of being incredibly mobile, with most of your important casts not having a
	cast time. This can make the spec much simpler to execute on difficult
	fights with a lot of movement or complex mechanics. Something to keep in
	mind, however, is that this build has significantly worse mana economy
	compared to the near infinite Mana Voidweaver has access to.

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Mythic+ Build

This is your default recommended talent build for Mythic+ content. With its
	very flexible output, it can handle a variety of incoming damage patterns.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtFwYzAAwYMzYwMYmBjgB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWghkANObdeiqstuHKKVoRnGMMSSmmCFWA-bcdeAoqq9los8AlFGadhFUMgwwxB5wA-AAAA-FIikwAMUY8wSgC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgZYZGMzMzwYmBbmmJGMzAAAMbz2CYsZAAYMzMjBzgZGMCmB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAaoqq9ls8AlFGiF8SckMQYYgwAK-AAAA-FIikwAMUY8wSgC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgBbzgZmZGGzMYz0MxgZGAAgZb2WAjNDAAjZmZmBzgZGMCmB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPLukC-bcdeAaoqq9ls8AlFGiF8SckMQYYgwAK-AAAA-FIikwAMUY8wSgC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMGWmZmBDmZbmtZmZmxMDAAAAAAAAAgZYZGMzMDzYmBMNTzMAzsghwYWGgxgFAAYMmZMYGgZmBYA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWghkANObdeiqstuHKKVoRnGMMSSmmCFWA-bcdeAoqq9los8kFGadhNwwxBi4I5wwE-AAAA-CEMYkow0AUgscA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGgZA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAacoqq9lskFGadhNQwwxBi4IJ6E-AAAA-CEMYkow0AUgscA-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend you pick the following bonuses in the first couple of weeks, but as you
can freely switch between them at any time, feel free to experiment with other options
yourself if you feel you do not get enough mileage out of the recommended options:

- Week 1:[[spell:1279599]]
- Week 2:[[spell:1279603]]
- Week 3:[[spell:1287555]]
- Week 4:[[spell:1279612]]
- Week 5:[[spell:1279614]]

3.

### Apex Talent: ![Master the Darkness Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_nullstone_void.jpg>) Master the Darkness

Discipline Priest's Apex talent, Master the Darkness, has 4 total ranks with 
3 different effects in total. The first [[spell:1253590]], 
provides a chance for your next [[spell:17]] after 
casting [[spell:47540]] to be turned into [[spell:1253593]]. This shield 
splashes to two additional nearby 
allies. Your second and third ranks of Master the Darkness,
[[spell:1253845]], are simple passive nodes increasing both your 
overall [[spell:81749]] healing and all shadow damage per rank. 
Finally, your fourth rank of Master the Darkness, [[spell:1253827]],
causes a percentage of your [[spell:1253593]] amount to be reflected back 
as damage when absorbed. This damage does contribute to healing through 
[[spell:81749]], making this talent incredibly powerful. This final point
also causes [[spell:8092]] to force-proc Void Shield, giving you a way to 
access a proc when needed.

From a rotation perspective, this talent is not particularly difficult to use. 
Whenever you get a proc, use it before you cast your next 
[[spell:47540]] to ensure you do not waste a potential proc. Additionally, 
you can delay your cast to line it up with a major damage event to abuse 
the reflect damage contributing to Atonement healing.

:::details TCIn-depth Void Shield Explanation
The specific way that Void Shield procs work is based on a Four card **deck
	system**. So while it looks like RNG at a high level, there is a level
	of predictability to the procs. Imagine you have 4 cards in a deck. One
	of those cards reads "Void Shield Proc", while the other three read "No Proc".
	Every time you cast Penance, you draw a card from the deck. This continues
	until the deck is empty, at which point you are given a fresh deck with
	the same distribution of cards. This means that you are guaranteed to get
	a Void Shield proc every four casts of Penance but you cannot
	predict which cast it will happen on in that set of four. Additionally,
	there is no way to track where you are in the deck with the default UI.

With the deck system working as it does, there are two extreme edges of
	potential RNG that you can experience. Getting a proc on the first cast of
	a fresh deck followed by getting a proc on the last cast of your next deck
	would leave you with 6 no proc casts of penance in between the two. This is
	the largest dry streak you can have with this system. Additionally, getting
	a Void Shield proc on the last card of the first deck followed by the
	first card of the second deck will give you two back to back procs with
	three no proc casts on either side.

Understanding how this deck system works can allow you to, in the moment,
	have some level of subconscious tracking of where you are likely to get a
	proc per cast giving you a small amount of control over an otherwise RNG
	based effect.

:::

4.

### Hero Talents

Starting at level 71, Hero Talents allow players the ability to shape and focus their 
gameplay by picking one of two mutually exclusive options. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle 
and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver are the options given to Discipline Priest.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle

The beginning node of the tree, [[spell:1248423]], provides an additional 
charge of Penance, providing a large amount of flexibility and control in 
your output. Other nodes like [[spell:440662]], 
[[spell:1272359]], [[spell:1246799]], and the immensely 
powerful [[spell:440742]] all push the power of Penance.

Oracle also provides some solid bonuses to [[spell:17]] via 
[[spell:440662]] and [[spell:440681]]. Combine this with 
nodes on the Discipline tree like [[spell:390786]] and 
[[spell:238135]] and pressing Power Word: Shield often
provides significant value.

Oracle synergizes incredibly well with Discipline's new Apex Talent due to 
the fact that [[spell:1253593]] inherits [[spell:17]] 
modifiers.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver focuses entirely on [[spell:447444]]. Casting 
[[spell:8092]] creates a rift that deals damage to all enemies within. 
This rift grows in power as you cast [[spell:47540]], making it larger 
and stronger. During the duration of the rift, your smite is transformed 
into [[spell:450405]], which is a significantly more powerful version. 
When the rift expires, it collapses and deals a large burst of damage, 
which can be a significant amount of healing.

Voidweaver also provides [[spell:451234]], which is a pet that is summoned
after the rift expires. This pet's attacks heal allies via [[spell:81749]]
and synergizes well with talents in the Discipline tree like 
[[spell:373427]] and [[spell:1240364]].

This Hero Tree also has a very large modifier for [[spell:8092]] via 
[[spell:1266883]]. Between all of the 
above mentioned effects, this tree pushes a significant amount of power 
into Mind Blast as a button, but as a result can leave you feeling quite 
weak when it is on cooldown. This spec also suffers from a lack of strong 
single target healing options unlike ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle.

5.

### PvP Talents (War Mode)

In Midnight, there remains the option to go into "War Mode."
Enabling War Mode provides the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for PvE content minimal in this
expansion, it is not recommended to enable the feature. War Mode remains an
attractive option for leveling purposes due to
the increased experience gain.

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of Discipline Priest-specific
PvP talents. For more information on what is valuable in a competitive PvP
setting instead of an open-world focus, please take a look at our PvP guide.

1. [[spell:356085]] is a toggleable ability that grants you either
   10% increased spell damage and [[spell:81749]] healing or 15% less Mana cost
   on healing spells. Leaving this on the damage increase portion while leveling
   will result in a solid DPS and survivability gain.
2. [[spell:1218211]] increases your damage and the damage of all
   allies with your [[spell:81749]] by 15% for 8 seconds. This is great for
   small group world content where giving your group a DPS buff will be more
   impactful than taking a small boost to your own damage via any of the above
   three talents.
3. Your third option is very flexible as the remaining options do not provide 
   much raw DPS value. Pick whatever seems fun to you for defensive/healing 
   value.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **18 Aug. 2026:** Fixed typo.
- **11 Aug. 2026:** Various formatting fixes.
- **10 Aug. 2026:** Updated for Season 2 release.
- **15 Jun. 2026:** Updated for Patch 12.0.7 and Omnium Folio.
- **20 May 2026:** Fixed incorrect delve talent build.
- **04 May 2026:** Added mention of Deck system for Void Shield.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **21 Mar. 2026:** Updated talent recommendations post upcoming class tuning.
- **16 Mar. 2026:** Reviewed for Season 1 Midnight Release.
- **26 Feb. 2026:** Updated for Midnight Release.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Aug. 2025:** Fixed some typos on page.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **01 Apr. 2025:** Updated post recent tuning.
- **01 Mar. 2025:** Updated post recent tuning.
- **25 Feb. 2025:** Fixed incorrect talent string.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Added flexible point and some additional talent discussions.
- **11 Sep. 2024:** Reordered talent recommendation and added note about bender bug.
- **10 Sep. 2024:** Added section clarifying expected pet CDs.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **26 Aug. 2024:** Fixed raid string import issue.
- **22 Aug. 2024:** Fixed m+ talent tree linking to the old patch talents.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **27 Mar. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **07 Nov. 2023:** Removed outdated reference.
- **07 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Aug. 2023:** Updated post hotfix to Rhapsody and VE.
- **19 Jul. 2023:** Fixed formatting issue.
- **12 Jul. 2023:** Updated to new page format.
- **10 Jul. 2023:** Updated for patch 10.1.5.
- **06 May 2023:** Updated to include Season 2 Dungeon Specific Talent Choices.
- **01 May 2023:** Reviewed for Patch 10.1.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **22 Jan. 2023:** Updated talent recommendation for patch 10.0.5.
- **11 Dec. 2022:** Fixed Talent Calculator M+ Link.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Discipline Priest, depending on the type of damage your group
is receiving. We also have advanced sections about cooldowns, procs, etc.
in order to minmax your healing output and your mana efficiency. All our
content is updated for World of Warcraft Patch
12.1.5.

1.

### Discipline Priest Gameplay and Rotation Guide

The Discipline specialization revolves heavily around healing through
dealing damage, thanks to the [[spell:81749]] passive ability. We detail
this [below](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities#atonement>), but for now all you need to
keep in mind is that dealing damage is an integral part of healing as
Discipline.

In the sections that follow, we will look at which abilities you should use
to deal damage (to generate Atonement healing), as well as how to
handle single target and AoE healing.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle

Raid

Mythic Plus

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver

Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic Plus

Active Talents

Passive Talents

[[spell:421453]]

[[spell:62618]]

[[spell:472433]]

[[spell:1253590]]

[[spell:123040]]

[[spell:373427]]

[[spell:390832]]

### Raid - Evangelism Ramp

**适用条件：Oracle（启用）；Voidweaver（启用）。**

[[spell:589]]

**适用条件：Oracle（启用）；Voidweaver（启用）。**

[[spell:17]]

**适用条件：Oracle（启用）；Voidweaver（启用）。**

[[spell:2061]]

**适用条件：Oracle（启用）；Voidweaver（启用）。**

[[spell:472433]]

**适用条件：Oracle（启用）；Voidweaver（启用）。**

[[spell:194509]]

[[spell:194509]]

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

[[spell:32379]]

**适用条件：Oracle（启用）；Voidweaver（启用）。**

**适用条件：Oracle（启用）；Voidweaver（启用）。**

[[spell:8092]]

**适用条件：Oracle（启用）；Voidweaver（启用）。**

[[spell:47540]]

**适用条件：Oracle（启用）；Voidweaver（启用）。**

[[spell:280749]]

**适用条件：Oracle（启用）；Voidweaver（启用）。**

**适用条件：Oracle（启用）。**

[[spell:47540]]

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

[[spell:32379]]

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

**适用条件：Oracle（启用）。**

[[spell:585]]

[[spell:47540]]

[[spell:17]]

**适用条件：Voidweaver（启用）。**

[[spell:450405]]

[[spell:47540]]

1.1.

#### Evangelism Ramp Sequence

When you have [[spell:472433]] available and are looking to utilize the cooldown for a specific damage event, the actual usage of the spell can be fairly flexible due to the current scaling on [[spell:81749]]. As a result, the following is a general rotation you can follow but not all inclusive for how you may see it used depending on the exact scenario.

---

> All [[spell:17]] casts can be assumed to be [[spell:280749]] casts when a proc is available

1. **适用条件：Oracle（启用）；Voidweaver（启用）。** Refresh your [[spell:589]] if it would fall off before the end of your Ramp window
2. **适用条件：Oracle（启用）；Voidweaver（启用）。** Cast a [[spell:17]]
3. **适用条件：Oracle（启用）；Voidweaver（启用）。** Cast a [[spell:2061]]
4. **适用条件：Oracle（启用）；Voidweaver（启用）。** Cast [[spell:472433]]
5. **适用条件：Oracle（启用）；Voidweaver（启用）。** Cast [[spell:194509]] 1-2 times depending on coverage needed
6. **适用条件：Inescapable Torment（启用）；Expiation（启用）。** Cast [[spell:32379]]
7. **适用条件：Oracle（启用）；Voidweaver（启用）。** Cast [[spell:8092]]
8. **适用条件：Oracle（启用）；Voidweaver（启用）。** Cast [[spell:47540]]
9. **适用条件：Oracle（启用）；Voidweaver（启用）。** Cast [[spell:280749]]
10. **适用条件：Oracle（启用）。** Cast [[spell:47540]]
11. **适用条件：Inescapable Torment（启用）；Expiation（启用）。** Cast [[spell:32379]]
12. **适用条件：Oracle（启用）。** Cast [[spell:585]] until [[spell:47540]]/[[spell:17]] is available again
13. **适用条件：Voidweaver（启用）。** Cast [[spell:450405]] until [[spell:47540]] is available again

:::details FAQWhy is There a Single Flash Heal Cast in our Raid Ramp Rotations?
[[spell:368275]]

causes

[[spell:2061]]

to apply

[[spell:81749]]

to both your target and yourself. This means that you can get 2 Atonement applications for the cost of a single GCD. As a result, you should avoid applying Atonement to yourself earlier in the Ramp to ensure that you get the most value out of this cast.

:::

### Raid - Ultimate Penitence Ramp

[[spell:589]]

[[spell:17]]

[[spell:2061]]

[[spell:194509]]

[[spell:8092]]

[[spell:421453]]

[[spell:280749]]

[[spell:47540]]

**适用条件：Voidweaver（启用）。**

[[spell:450405]]

[[spell:17]]

**适用条件：Oracle（启用）。**

[[spell:47540]]

**适用条件：Oracle（启用）。**

[[spell:585]]

[[spell:47540]]

[[spell:17]]

**适用条件：Voidweaver（启用）。**

[[spell:450405]]

[[spell:47540]]

[[spell:127399]]

1.2.

#### Ultimate Penitence Ramp

The goal of an [[spell:421453]] ramp is to get a suitable number of [[spell:81749]]'s active prior to casting the spell. In Raid, all of your uses of Ultimate Penitence should be utilized on enemies to heal through Atonement, not directly on allies.

:::details FAQHow does Ultimate Penitence choose its target?
It's targeting is based on your active target as a player. If you have an enemy selected when you cast this spell, it will prioritize firing all bolts against enemies when possible. Alternatively, if you have an ally targeted when casting, it will prioritize direct healing allies instead.

:::

---

> All [[spell:17]] casts can be assumed to be [[spell:280749]] casts when a proc is available

1. Refresh your [[spell:589]] to ensure it lasts the entire duration of your Ramp.
2. Cast [[spell:17]]
3. Cast [[spell:2061]]
4. Cast [[spell:194509]] twice
5. Cast [[spell:8092]]
6. Cast [[spell:421453]] - cast [[spell:280749]] while traveling into the air. See Advanced section below for more details.
7. Cast [[spell:47540]]
8. **适用条件：Voidweaver（启用）。** Cast [[spell:450405]] x3
9. Cast [[spell:17]]
10. **适用条件：Oracle（启用）。** Cast [[spell:47540]]
11. **适用条件：Oracle（启用）。** Cast [[spell:585]] until [[spell:47540]]/[[spell:17]] is available again
12. **适用条件：Voidweaver（启用）。** Cast [[spell:450405]] until [[spell:47540]]/[[spell:127399]] is available again

### Mythic+ Rotation

**适用条件：Oracle（启用）。** Discipline Priest as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle in Mythic Plus plays very heavily into 2 primary buttons: [[spell:280749]] and [[spell:47540]]. Running a variety of modifiers for both, casting Void Shield as often as possible is incredibly important for your potential output. Since Void Shield procs off of Penance casts AND [[spell:8092]] casts, casting both as close to on cooldown as possible is incredibly important for overall Void Shield CPM. Additionally, with the new tier set this Season, casting Penance gives you Mind Blast cooldown reduction as well, therefore further increasing the number of Mind Blast casts possible. Outside of that general gameplay loop, you will mostly cast your Penances offensively, but due to [[spell:440742]] you can easily cast Penance directly on an ally if a specific person needs help. Just keep in mind you're giving up [[spell:589]] spread to do so. Additionally, [[spell:1252215]] is available when needed to help people through heavy single target healing requirements. The following is a general priority list to follow in Mythic plus. Keep in mind that Mythic Plus is a very fluid environment and the expectation is that you are reacting to and planning around incoming damage instead of simply following a set rotation

**适用条件：Voidweaver（启用）。** Discipline priest as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver in Mythic Plus plays around [[spell:81749]] as much as possible with strong output from [[spell:447444]] and [[spell:450405]]. Casting [[spell:47540]] and [[spell:8092]] on cooldown to get as many procs of [[spell:280749]] as possible provides both a large amount of output as well as good Atonement coverage. With access to your rift significantly more often due to the Season 2 tier set, you can push a consistent amount of HPS at all times. [[spell:186263]] will shore up a lot of your single target healing weakness that isn't covered by Atonement. The following is a general priority list to follow in Mythic plus. Keep in mind that Mythic Plus is a very fluid environment and the expectation is that you are reacting to and planning around incoming damage instead of simply following a set rotation

---

1. Cast [[spell:589]] if not present on your active target
2. **适用条件：Voidweaver（启用）。** Cast [[spell:8092]] to access [[spell:447444]] and proc [[spell:280749]]
3. **适用条件：Oracle（启用）。** Cast [[spell:8092]] for a small burst of damage and to proc [[spell:280749]]
4. Cast [[spell:47540]] if available
5. Cast [[spell:1253593]] if available
6. **适用条件：Expiation（启用）。** Cast [[spell:32379]]
7. **适用条件：Voidweaver（启用）。** Cast [[spell:450405]] until one of the above spells is available
8. Cast [[spell:186263]] if a player needs single target healing and Atonement isn't enough
9. **适用条件：Oracle（启用）。** Cast [[spell:585]] if nothing else is available/no one is in danger

---

In addition to the above priority list, you also have your cooldowns ([[spell:472433]], [[spell:421453]], and [[spell:33206]]) available:

- [[spell:472433]] - Evangelism accomplishes two things in keys; Making it easier to apply Atonement to the group via both its initial heal on cast as well as making future [[spell:194509]] casts instant and activating [[spell:197862]] giving you a temporary boost to your healing and absorption effects. If you find yourself in need of immediate Atonement coverage on the group or need the healing increase, feel free to hit this button. Coming in at a 1:30 cooldown, you should be pressing it fairly often, so don't get caught in the common trap of sitting on it for too long.
- **适用条件：Oracle（启用）。** [[spell:421453]] - Uppies comes in as one of the longest cooldowns in the game at 4 minutes with a power level that isn't exactly proportional. You will mainly utilize this button as a gap fill CD when you have nothing available. Its general use case will be targeting an enemy when you have Atonement on your group to benefit from the Atonement healing. It does provide a very large personal shield allowing you to use it as a major defensive as well.
- **适用条件：Voidweaver（启用）。** [[spell:421453]] - Uppies comes in as one of the longest cooldowns in the game at 4 minutes and is incredibly powerful if used correctly. A note on using this spell as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver is that [[spell:450612]]'s amp to [[spell:47540]] also applies to Uppies. As a result, it is incredibly important to make sure you cast [[spell:8092]] and open an [[spell:447444]] prior to casting Uppies for it to be used at its full power. This spells general use case will be targeting an enemy when you have Atonement on your group to benefit from the Atonement healing. It does also provide a very large personal shield allowing you to use it as a major defensive as well.
- [[spell:33206]] - With [[spell:373035]] talented, you have an incredibly high number of Pain Suppression charges available over the course of a full dungeon. With this spell being as powerful as it is, make sure you are using it fairly liberally on any target that's taking significant single target damage. Also don't be afraid to use it on yourself if the situation calls for it due to your own defensives being fairly lackluster.

2.

### Midnight Season 2 Tier Set

This season's 2-piece set bonus,[[spell:1296577]], is 
    incredibly important. With so much power being tied to [[spell:8092]] 
via both [[spell:447444]] when ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver and [[spell:1253593]]
for either spec, more casts of Mind Blast is incredibly powerful. While playing
around the tier set isn't complicated and generally results in just hitting 
your buttons on CD a bit faster than without, the difference in output is 
immense.

The new 4-piece set bonus, [[spell:1296578]], provides
a solid boost to our Void Shield after casting Mind Blast, which ties nicely
into the rest of our gameplan. While this is a nice bonus, it is not as 
impactful as the 2-piece set bonus.

3.

### Important Cooldowns for Discipline Priest

### [[spell:472433]]

3.1.

#### Evangelism

In Dungeon content, [[spell:472433]] immediately heals your whole group 
for a non-insignificant 
amount on cast. Additionally, it causes your next two casts of 
[[spell:194509]] to be instant cast. This buff lasts forever, so 
you can hold those Radiance casts for as long as you need them, making this 
a very strong tool to assist with mobility heavy encounters.

In Raiding content, this tool is a primary enabler for what we call a ramp.
    This season, however, is a bit different in regards to how we recommend 
    focusing on Ramps as you may know it. Check the Mastering Your Discipline
    Priest section below talking about Atonement for more information.

Evangelism also activates either [[spell:197862]] or [[spell:1280137]] 
depending on what one you are talented into. This either buffs all your 
healing and absorbs for a period of time or summons a pet for a short 
duration to both deal damage as well as interact with other talents
such as [[spell:373427]] if talented.

### [[spell:421453]]

3.2.

#### Ultimate Penitence

While this spell has an very long cooldown at 4 minutes, its also 
    incredibly powerful. When cast offensively, it will throw bolts at random
    enemies, dealing significant damage which translates to a large amount of
    [[spell:81749]] healing if the group has Atonement active on them.
    When cast defensively, it will throw bolts at injured allies, healing them
    directly.

In both Dungeon and Raid content you will almost exclusively want to utilize
    this spell offensively. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle and in dungeons there can 
    be very niche scenarios where you might want to use this defensively, 
    but those situations are rare. Additionally, as Voidweaver, 
    [[spell:307334]]'s buff to [[spell:47540]] [[spell:81749]] healing 
    does work with the Atonement healing from Ultimate Penitence. As a result,
    as Voidweaver you should always be trying to use this spell during a 
    rift window to maximize its output potential unless you are specifically 
    holding it as a gap fill tool to get you to your next [[spell:447444]].

### [[spell:62618]]

3.3.

#### Power Word: Barrier

Power Word: Barrier shares a choice node with [[spell:421453]], 
meaning you have to choose between one or the other. Power Word: Barrier 
can be incredibly powerful in any scenario where the incoming damage 
during its duration is significant enough. Keep in mind that it does 
require the group and or raid to be able to stack under the barrier for its 
duration to benefit, so some encounters it is very difficult to use even 
if the damage intake warrants it. While we are recommending Ultimate Penitence
by default, keep an eye out for good situations to swap to Power Word: Barrier.

### [[spell:33206]]

3.4.

#### Pain Suppression

Pain Suppression is a very large Damage
Reduction on a single target. Utilizing this either on the tank or on a player
with a large damage over time effect on them can have a significant impact.
When running the talent [[spell:373035]], you will have a lot of
additional casts available of Pain Suppression, so make sure you use it often
instead of just sitting on maximum charges.

4.

### Venomous Abyss Builds, Tips, and Tricks for Discipline Priest

<table>&#10;<tr>&#10;<th colspan="2" style="text-align: center">Raid Difficulty</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<strong>Heroic Raid</strong>&#10;</td>&#10;<td>&#10;<strong>Mythic Raid</strong>&#10;</td>&#10;</tr>&#10;</table>

### Nek'zali the Soulcoiler

4.1.

#### Nek'zali the Soulcoiler

4.1.1.

##### Damage Pattern Breakdown and Ramp Targets

**适用条件：Heroic Raid（启用）。**

<em>Coming soon!</em>

**适用条件：Mythic Raid（启用）。**

<em>Coming soon!</em>

The following is an example cooldown plan you can utilize for this boss fight:

**适用条件：Heroic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3470;Difficulty:Heroic;Name:Nek'zali

time:1;ph:1;tag:PLAYER;spellid:194509;

time:2;ph:1;tag:PLAYER;spellid:472433;

time:2;ph:1;tag:PLAYER;spellid:194509;

time:37;ph:1;tag:PLAYER;spellid:194509;

time:64;ph:1;tag:PLAYER;spellid:194509;

time:78;ph:1;tag:PLAYER;spellid:421453;

time:79;ph:1;tag:PLAYER;spellid:194509;

time:96;ph:1;tag:PLAYER;spellid:472433;

time:96;ph:1;tag:PLAYER;spellid:194509;

time:117;ph:1;tag:PLAYER;spellid:194509;

time:146;ph:1;tag:PLAYER;spellid:194509;

time:199;ph:1;tag:PLAYER;spellid:472433;

time:199;ph:1;tag:PLAYER;spellid:194509;

time:47;ph:1.5;tag:PLAYER;spellid:472433;

time:47;ph:1.5;tag:PLAYER;spellid:194509;

time:74;ph:1.5;tag:PLAYER;spellid:194509;

time:96;ph:1.5;tag:PLAYER;spellid:194509;

time:142;ph:1.5;tag:PLAYER;spellid:194509;

time:142;ph:1.5;tag:PLAYER;spellid:472433;

time:164;ph:1.5;tag:PLAYER;spellid:194509;

time:233;ph:2;tag:PLAYER;spellid:472433;

time:233;ph:2;tag:PLAYER;spellid:194509;

time:273;ph:2;tag:PLAYER;spellid:194509;

time:273;ph:2;tag:PLAYER;spellid:421453;

time:323;ph:2;tag:PLAYER;spellid:472433;

time:323;ph:2;tag:PLAYER;spellid:194509;

time:373;ph:2;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3470;Difficulty:Mythic;Name:Nek'zali

time:2;ph:1;tag:PLAYER;spellid:472433;

time:2;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:194509;

time:69;ph:1;tag:PLAYER;spellid:194509;

time:70;ph:1;tag:PLAYER;spellid:194509;

time:70;ph:1;tag:PLAYER;spellid:421453;

time:92;ph:1;tag:PLAYER;spellid:472433;

time:92;ph:1;tag:PLAYER;spellid:194509;

time:43;ph:1.5;tag:PLAYER;spellid:194509;

time:81;ph:1.5;tag:PLAYER;spellid:472433;

time:81;ph:1.5;tag:PLAYER;spellid:194509;

time:103;ph:1.5;tag:PLAYER;spellid:194509;

time:171;ph:2;tag:PLAYER;spellid:472433;

time:171;ph:2;tag:PLAYER;spellid:194509;

time:212;ph:2;tag:PLAYER;spellid:194509;

time:213;ph:2;tag:PLAYER;spellid:421453;

time:213;ph:2;tag:PLAYER;spellid:194509;

time:260;ph:2;tag:PLAYER;spellid:194509;

time:261;ph:2;tag:PLAYER;spellid:472433;
```

:::

To utilize the above example cooldowns in game, you will need the
    [Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
    addon to read out the note for you and provide alerts during the encounter.
    If you are not familiar with the Northern Sky Raid Tools addon and how to
    utilize it with notes, Viserio provides a great guide [here](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
    on how to import the note provided.

**适用条件：Heroic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-nekzali-the-soulcoiler-heroic-nekzali-heroic-wcp-cds-0sv8kwn>) .

**适用条件：Mythic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-nekzali-the-soulcoiler-mythic-nekzali-mythic-wcp-cds-olml7bm>) .

### Entombed Sentinels

4.2.

#### Entombed Sentinels

4.2.1.

##### Damage Pattern Breakdown and Ramp Targets

**适用条件：Heroic Raid（启用）。**

<em>Coming soon!</em>

**适用条件：Mythic Raid（启用）。**

<em>Coming soon!</em>

The following is an example cooldown plan you can utilize for this boss fight:

**适用条件：Heroic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3445;Difficulty:Heroic;Name:Sentinels

time:15;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:1;tag:PLAYER;spellid:421453;

time:46;ph:1;tag:PLAYER;spellid:472433;

time:46;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:2;tag:PLAYER;spellid:194509;

time:47;ph:2;tag:PLAYER;spellid:194509;

time:68;ph:2;tag:PLAYER;spellid:194509;

time:90;ph:2;tag:PLAYER;spellid:472433;

time:90;ph:2;tag:PLAYER;spellid:194509;

time:15;ph:3;tag:PLAYER;spellid:194509;

time:47;ph:3;tag:PLAYER;spellid:194509;

time:68;ph:3;tag:PLAYER;spellid:194509;

time:90;ph:3;tag:PLAYER;spellid:472433;

time:90;ph:3;tag:PLAYER;spellid:194509;

time:14;ph:4;tag:PLAYER;spellid:194509;

time:15;ph:4;tag:PLAYER;spellid:194509;

time:15;ph:4;tag:PLAYER;spellid:421453;

time:47;ph:4;tag:PLAYER;spellid:194509;

time:68;ph:4;tag:PLAYER;spellid:194509;

time:91;ph:4;tag:PLAYER;spellid:472433;

time:91;ph:4;tag:PLAYER;spellid:194509;

time:14;ph:5;tag:PLAYER;spellid:194509;

time:47;ph:5;tag:PLAYER;spellid:194509;

time:68;ph:5;tag:PLAYER;spellid:194509;

time:91;ph:5;tag:PLAYER;spellid:472433;

time:91;ph:5;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3445;Difficulty:Mythic;Name:Sentinels

time:15;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:1;tag:PLAYER;spellid:421453;

time:46;ph:1;tag:PLAYER;spellid:472433;

time:46;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:2;tag:PLAYER;spellid:194509;

time:47;ph:2;tag:PLAYER;spellid:194509;

time:68;ph:2;tag:PLAYER;spellid:194509;

time:90;ph:2;tag:PLAYER;spellid:472433;

time:90;ph:2;tag:PLAYER;spellid:194509;

time:15;ph:3;tag:PLAYER;spellid:194509;

time:47;ph:3;tag:PLAYER;spellid:194509;

time:68;ph:3;tag:PLAYER;spellid:194509;

time:90;ph:3;tag:PLAYER;spellid:472433;

time:90;ph:3;tag:PLAYER;spellid:194509;

time:14;ph:4;tag:PLAYER;spellid:194509;

time:15;ph:4;tag:PLAYER;spellid:194509;

time:15;ph:4;tag:PLAYER;spellid:421453;

time:47;ph:4;tag:PLAYER;spellid:194509;

time:68;ph:4;tag:PLAYER;spellid:194509;

time:91;ph:4;tag:PLAYER;spellid:472433;

time:91;ph:4;tag:PLAYER;spellid:194509;

time:115;ph:5;tag:PLAYER;spellid:194509;

time:148;ph:5;tag:PLAYER;spellid:194509;

time:169;ph:5;tag:PLAYER;spellid:194509;

time:192;ph:5;tag:PLAYER;spellid:472433;

time:192;ph:5;tag:PLAYER;spellid:194509;
```

:::

To utilize the above example cooldowns in game, you will need the
    [Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
    addon to read out the note for you and provide alerts during the encounter.
    If you are not familiar with the Northern Sky Raid Tools addon and how to
    utilize it with notes, Viserio provides a great guide [here](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
    on how to import the note provided.

**适用条件：Heroic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-entombed-sentinels-heroic-entombed-sentinels-heroic-wcp-cds-9p0kboo>) .

**适用条件：Mythic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-entombed-sentinels-mythic-entombed-sentinels-mythic-wcp-cds-n77u0hf>) .

### The Lost Explorers

4.3.

#### The Lost Explorers

4.3.1.

##### Damage Pattern Breakdown and Ramp Targets

**适用条件：Heroic Raid（启用）。**

<em>Coming soon!</em>

**适用条件：Mythic Raid（启用）。**

<em>Coming soon!</em>

The following is an example cooldown plan you can utilize for this boss fight:

**适用条件：Heroic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3497;Difficulty:Heroic;Name:Explorers

time:2;ph:1;tag:PLAYER;spellid:472433;

time:2;ph:1;tag:PLAYER;spellid:194509;

time:19;ph:1;tag:PLAYER;spellid:194509;

time:20;ph:1;tag:PLAYER;spellid:421453;

time:21;ph:1;tag:PLAYER;spellid:194509;

time:50;ph:1;tag:PLAYER;spellid:194509;

time:20;ph:2;tag:PLAYER;spellid:194509;

time:38;ph:2;tag:PLAYER;spellid:472433;

time:38;ph:2;tag:PLAYER;spellid:194509;

time:59;ph:2;tag:PLAYER;spellid:194509;

time:85;ph:2;tag:PLAYER;spellid:194509;

time:115;ph:2;tag:PLAYER;spellid:194509;

time:5;ph:3;tag:PLAYER;spellid:472433;

time:5;ph:3;tag:PLAYER;spellid:194509;

time:20;ph:3;tag:PLAYER;spellid:194509;

time:40;ph:3;tag:PLAYER;spellid:194509;

time:59;ph:3;tag:PLAYER;spellid:194509;

time:95;ph:3;tag:PLAYER;spellid:472433;

time:95;ph:3;tag:PLAYER;spellid:194509;

time:115;ph:3;tag:PLAYER;spellid:194509;

time:115;ph:3;tag:PLAYER;spellid:421453;

time:116;ph:3;tag:PLAYER;spellid:194509;

time:144;ph:4;tag:PLAYER;spellid:194509;

time:164;ph:4;tag:PLAYER;spellid:194509;

time:185;ph:4;tag:PLAYER;spellid:472433;

time:185;ph:4;tag:PLAYER;spellid:194509;

time:209;ph:4;tag:PLAYER;spellid:194509;

time:239;ph:4;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

<em>Coming soon!</em>

To utilize the above example cooldowns in game, you will need the
    [Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
    addon to read out the note for you and provide alerts during the encounter.
    If you are not familiar with the Northern Sky Raid Tools addon and how to
    utilize it with notes, Viserio provides a great guide [here](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
    on how to import the note provided.

**适用条件：Heroic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-the-lost-explorers-heroic-turtles-heroic-wcp-cds-n7fmpzo>) .

**适用条件：Mythic Raid（启用）。**

### Vashnik the Malignant

4.4.

#### Vashnik the Malignant

4.4.1.

##### Damage Pattern Breakdown and Ramp Targets

**适用条件：Heroic Raid（启用）。**

<em>Coming soon!</em>

**适用条件：Mythic Raid（启用）。**

<em>Coming soon!</em>

The following is an example cooldown plan you can utilize for this boss fight:

**适用条件：Heroic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3455;Difficulty:Heroic;Name:Vashnik

time:3;ph:1;tag:PLAYER;spellid:472433;

time:3;ph:1;tag:PLAYER;spellid:194509;

time:33;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:421453;

time:54;ph:1;tag:PLAYER;spellid:194509;

time:79;ph:1;tag:PLAYER;spellid:194509;

time:99;ph:1;tag:PLAYER;spellid:472433;

time:99;ph:1;tag:PLAYER;spellid:194509;

time:119;ph:1;tag:PLAYER;spellid:194509;

time:129;ph:1;tag:PLAYER;spellid:194509;

time:144;ph:1;tag:PLAYER;spellid:194509;

time:163;ph:1;tag:PLAYER;spellid:194509;

time:190;ph:1;tag:PLAYER;spellid:472433;

time:190;ph:1;tag:PLAYER;spellid:194509;

time:204;ph:1;tag:PLAYER;spellid:194509;

time:218;ph:1;tag:PLAYER;spellid:194509;

time:247;ph:1;tag:PLAYER;spellid:194509;

time:280;ph:1;tag:PLAYER;spellid:472433;

time:280;ph:1;tag:PLAYER;spellid:194509;

time:295;ph:1;tag:PLAYER;spellid:194509;

time:297;ph:1;tag:PLAYER;spellid:421453;

time:298;ph:1;tag:PLAYER;spellid:194509;

time:331;ph:1;tag:PLAYER;spellid:194509;

time:372;ph:1;tag:PLAYER;spellid:472433;

time:372;ph:1;tag:PLAYER;spellid:194509;

time:384;ph:1;tag:PLAYER;spellid:194509;

time:415;ph:1;tag:PLAYER;spellid:194509;

time:445;ph:1;tag:PLAYER;spellid:194509;

time:456;ph:1;tag:PLAYER;spellid:194509;

time:464;ph:1;tag:PLAYER;spellid:472433;

time:464;ph:1;tag:PLAYER;spellid:194509;

time:499;ph:1;tag:PLAYER;spellid:194509;

time:528;ph:1;tag:PLAYER;spellid:194509;

time:540;ph:1;tag:PLAYER;spellid:194509;

time:555;ph:1;tag:PLAYER;spellid:472433;

time:555;ph:1;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3455;Difficulty:Mythic;Name:Vashnik

time:3;ph:1;tag:PLAYER;spellid:472433;

time:3;ph:1;tag:PLAYER;spellid:194509;

time:33;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:421453;

time:54;ph:1;tag:PLAYER;spellid:194509;

time:74;ph:1;tag:PLAYER;spellid:194509;

time:99;ph:1;tag:PLAYER;spellid:472433;

time:99;ph:1;tag:PLAYER;spellid:194509;

time:119;ph:1;tag:PLAYER;spellid:194509;

time:129;ph:1;tag:PLAYER;spellid:194509;

time:144;ph:1;tag:PLAYER;spellid:194509;

time:159;ph:1;tag:PLAYER;spellid:194509;

time:190;ph:1;tag:PLAYER;spellid:472433;

time:190;ph:1;tag:PLAYER;spellid:194509;

time:204;ph:1;tag:PLAYER;spellid:194509;

time:218;ph:1;tag:PLAYER;spellid:194509;

time:242;ph:1;tag:PLAYER;spellid:194509;

time:280;ph:1;tag:PLAYER;spellid:472433;

time:280;ph:1;tag:PLAYER;spellid:194509;

time:295;ph:1;tag:PLAYER;spellid:194509;

time:297;ph:1;tag:PLAYER;spellid:421453;

time:298;ph:1;tag:PLAYER;spellid:194509;

time:326;ph:1;tag:PLAYER;spellid:194509;

time:372;ph:1;tag:PLAYER;spellid:472433;

time:372;ph:1;tag:PLAYER;spellid:194509;

time:384;ph:1;tag:PLAYER;spellid:194509;

time:410;ph:1;tag:PLAYER;spellid:194509;

time:445;ph:1;tag:PLAYER;spellid:194509;

time:456;ph:1;tag:PLAYER;spellid:194509;

time:464;ph:1;tag:PLAYER;spellid:472433;

time:464;ph:1;tag:PLAYER;spellid:194509;

time:528;ph:1;tag:PLAYER;spellid:194509;

time:540;ph:1;tag:PLAYER;spellid:194509;

time:555;ph:1;tag:PLAYER;spellid:472433;

time:555;ph:1;tag:PLAYER;spellid:194509;
```

:::

To utilize the above example cooldowns in game, you will need the
    [Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
    addon to read out the note for you and provide alerts during the encounter.
    If you are not familiar with the Northern Sky Raid Tools addon and how to
    utilize it with notes, Viserio provides a great guide [here](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
    on how to import the note provided.

**适用条件：Heroic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-vashnik-the-malignant-heroic-vashnik-heroic-wcp-cds-hesput1>) .

**适用条件：Mythic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-vashnik-the-malignant-mythic-vashnik-mythic-wcp-cds-3qbcsvb>) .

### Sszorak

4.5.

#### Sszorak

4.5.1.

##### Damage Pattern Breakdown and Ramp Targets

**适用条件：Heroic Raid（启用）。**

<em>Coming soon!</em>

**适用条件：Mythic Raid（启用）。**

<em>Coming soon!</em>

The following is an example cooldown plan you can utilize for this boss fight:

**适用条件：Heroic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3420;Difficulty:Heroic;Name:Sszorak

time:13;ph:1;tag:PLAYER;spellid:472433;

time:13;ph:1;tag:PLAYER;spellid:194509;

time:44;ph:1;tag:PLAYER;spellid:194509;

time:64;ph:1;tag:PLAYER;spellid:194509;

time:65;ph:1;tag:PLAYER;spellid:421453;

time:65;ph:1;tag:PLAYER;spellid:194509;

time:96;ph:1;tag:PLAYER;spellid:194509;

time:112;ph:1;tag:PLAYER;spellid:472433;

time:112;ph:1;tag:PLAYER;spellid:194509;

time:126;ph:1;tag:PLAYER;spellid:194509;

time:147;ph:1;tag:PLAYER;spellid:194509;

time:156;ph:1;tag:PLAYER;spellid:194509;

time:182;ph:1;tag:PLAYER;spellid:194509;

time:205;ph:1;tag:PLAYER;spellid:472433;

time:205;ph:1;tag:PLAYER;spellid:194509;

time:212;ph:1;tag:PLAYER;spellid:194509;

time:234;ph:1;tag:PLAYER;spellid:194509;

time:255;ph:1;tag:PLAYER;spellid:194509;

time:266;ph:1;tag:PLAYER;spellid:194509;

time:296;ph:1;tag:PLAYER;spellid:472433;

time:296;ph:1;tag:PLAYER;spellid:194509;

time:320;ph:1;tag:PLAYER;spellid:194509;

time:337;ph:1;tag:PLAYER;spellid:194509;

time:338;ph:1;tag:PLAYER;spellid:194509;

time:338;ph:1;tag:PLAYER;spellid:421453;

time:373;ph:1;tag:PLAYER;spellid:194509;

time:388;ph:1;tag:PLAYER;spellid:472433;

time:388;ph:1;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

Coming soon!

To utilize the above example cooldowns in game, you will need the
    [Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
    addon to read out the note for you and provide alerts during the encounter.
    If you are not familiar with the Northern Sky Raid Tools addon and how to
    utilize it with notes, Viserio provides a great guide [here](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
    on how to import the note provided.

**适用条件：Heroic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-sszorak-heroic-sszorak-heroic-wcp-cds-1ozm7ml>) .

**适用条件：Mythic Raid（启用）。**

### The Twin Fangs

4.6.

#### The Twin Fangs

4.6.1.

##### Damage Pattern Breakdown and Ramp Targets

**适用条件：Heroic Raid（启用）。**

<em>Coming soon!</em>

**适用条件：Mythic Raid（启用）。**

<em>Coming soon!</em>

The following is an example cooldown plan you can utilize for this boss fight:

**适用条件：Heroic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3421;Difficulty:Heroic;Name:Twin Fangs

time:39;ph:1;tag:PLAYER;spellid:194509;

time:40;ph:1;tag:PLAYER;spellid:472433;

time:54;ph:1;tag:PLAYER;spellid:194509;

time:71;ph:1;tag:PLAYER;spellid:194509;

time:107;ph:1;tag:PLAYER;spellid:194509;

time:120;ph:1;tag:PLAYER;spellid:194509;

time:139;ph:1;tag:PLAYER;spellid:472433;

time:139;ph:1;tag:PLAYER;spellid:194509;

time:209;ph:1;tag:PLAYER;spellid:194509;

time:222;ph:1;tag:PLAYER;spellid:194509;

time:240;ph:1;tag:PLAYER;spellid:472433;

time:240;ph:1;tag:PLAYER;spellid:194509;

time:277;ph:1;tag:PLAYER;spellid:194509;

time:290;ph:1;tag:PLAYER;spellid:194509;

time:308;ph:1;tag:PLAYER;spellid:194509;

time:379;ph:1;tag:PLAYER;spellid:472433;

time:379;ph:1;tag:PLAYER;spellid:194509;

time:391;ph:1;tag:PLAYER;spellid:194509;

time:410;ph:1;tag:PLAYER;spellid:194509;

time:446;ph:1;tag:PLAYER;spellid:194509;

time:459;ph:1;tag:PLAYER;spellid:194509;

time:478;ph:1;tag:PLAYER;spellid:472433;

time:478;ph:1;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

Coming soon!

To utilize the above example cooldowns in game, you will need the
    [Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
    addon to read out the note for you and provide alerts during the encounter.
    If you are not familiar with the Northern Sky Raid Tools addon and how to
    utilize it with notes, Viserio provides a great guide [here](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
    on how to import the note provided.

**适用条件：Heroic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-the-twin-fangs-heroic-the-twin-fangs-heroic-wcp-cds-voia9cc>) .

**适用条件：Mythic Raid（启用）。**

### The Coiled Altar

4.7.

#### The Coiled Altar

4.7.1.

##### Damage Pattern Breakdown and Ramp Targets

**适用条件：Heroic Raid（启用）。**

<em>Coming soon!</em>

**适用条件：Mythic Raid（启用）。**

<em>Coming soon!</em>

The following is an example cooldown plan you can utilize for this boss fight:

**适用条件：Heroic Raid（启用）。**

:::details Example Cooldowns
Enter your Character Name to be used in the personal note:

```
EncounterID:3429;Difficulty:Heroic;Name:Coiled Altar

time:1;ph:1;tag:PLAYER;spellid:472433;

time:4;ph:1;tag:PLAYER;spellid:194509;

time:46;ph:1;tag:PLAYER;spellid:194509;

time:79;ph:1;tag:PLAYER;spellid:194509;

time:80;ph:1;tag:PLAYER;spellid:421453;

time:80;ph:1;tag:PLAYER;spellid:194509;

time:127;ph:1;tag:PLAYER;spellid:472433;

time:127;ph:1;tag:PLAYER;spellid:194509;

time:18;ph:2;tag:PLAYER;spellid:194509;

time:51;ph:2;tag:PLAYER;spellid:194509;

time:103;ph:2;tag:PLAYER;spellid:472433;

time:103;ph:2;tag:PLAYER;spellid:194509;

time:136;ph:2;tag:PLAYER;spellid:194509;

time:187;ph:2;tag:PLAYER;spellid:194509;

time:4;ph:2.5;tag:PLAYER;spellid:472433;

time:4;ph:2.5;tag:PLAYER;spellid:194509;

time:19;ph:2.5;tag:PLAYER;spellid:194509;

time:3;ph:3;tag:PLAYER;spellid:194509;

time:6;ph:3;tag:PLAYER;spellid:421453;

time:6;ph:3;tag:PLAYER;spellid:194509;

time:35;ph:3;tag:PLAYER;spellid:194509;

time:64;ph:3;tag:PLAYER;spellid:194509;

time:97;ph:3;tag:PLAYER;spellid:194509;

time:97;ph:3;tag:PLAYER;spellid:472433;

time:128;ph:3;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

Coming soon!

To utilize the above example cooldowns in game, you will need the
    [Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
    addon to read out the note for you and provide alerts during the encounter.
    If you are not familiar with the Northern Sky Raid Tools addon and how to
    utilize it with notes, Viserio provides a great guide [here](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
    on how to import the note provided.

**适用条件：Heroic Raid（启用）。**

Prefer to look at the note directly on wowutils? Take a look at the 
        public version of the above note [here](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-the-coiled-altar-heroic-the-coiled-altar-heroic-wcp-cds-p4nxq3p>) .

**适用条件：Mythic Raid（启用）。**

### Ula'tek

4.8.

#### Ula'tek

4.8.1.

##### Damage Pattern Breakdown and Ramp Targets

**适用条件：Heroic Raid（启用）。**

<em>Coming soon!</em>

**适用条件：Mythic Raid（启用）。**

<em>Coming soon!</em>

The following is an example cooldown plan you can utilize for this boss fight:

**适用条件：Heroic Raid（启用）。**

Coming Soon!

**适用条件：Mythic Raid（启用）。**

Coming soon!

5.

### Optional Read: Mastering Your Discipline Priest

While the guidelines we have given so far will enable you to perform very
decently as a Discipline Priest, there are some subtleties that you need to
be aware of if you want to play your character to its full potential.

5.1.

#### The Current State of Atonement Scaling

[[spell:81749]] includes scaling that reduces the effectiveness of 
    additional Atonements past 5 active targets. This is intended to allow 
    the developers to make Atonement feel impactful in keys or at lower 
    Atonement counts while still being balanced in raid at higher counts. 
    However, after repeated tweaking, the scaling is now so extreme that the 
    action of applying more Atonements past a certain point is simply for 
    coverage purposes and barely actually increasing your total output as 
    shown in the chart below

[
![Discipline Atonement Healing Graph](<https://static.icy-veins.com/images/wow/classes/priest/diminishing_value_of_atonements.png>)
](<https://static.icy-veins.com/images/wow/classes/priest/diminishing_value_of_atonements.png>)

With the increased CPM of [[spell:1253593]] via the addition of [[spell:8092]]
    forcing a proc as well as the new 2-piece tier set bonus increasing 
    Mind Blast casts, you will simply maintain a non-insignificant number of 
    Atonements naturally via pressing your buttons on cooldown and placing
    your [[spell:194509]] casts on relevant incoming damage events.
    Past that, intentionally applying further Atonements via things like 
    [[spell:200829]] or [[spell:2061]], past the occasional cast to get value 
    out of [[spell:368275]], come at a significant cost. Not only are they 
    incredibly mana inefficient casts, but they're also, in many situations not 
    even an HPS increase as you're spending GCDs for, as I mentioned above, 
    coverage instead of more throughput.

This leaves Discipline in a weird spot. While the spec, historically, has 
    focused around setting up major ramps up to 20 Atonements and pushing out 
    huge healing during those windows, instead we find ourselves preferring to 
    stay at low Atonements as its more efficient.

**TLDR: While you can still ramp to 20 if you need to for coverage 
    purposes, understand that its for just that, coverage. You are barely 
    gaining more HPS doing so.**

5.2.

#### Penance Clipping as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver

When playing Voidweaver, [[spell:450405]] is so incredibly powerful 
    that it manages to outvalue a handful of existing spells despite being a 
    "filler" spell. For example, a Void Blast is stronger than a 
    [[spell:32379]] while in execute, essentially pushing that core 
    spell to a movement GCD instead of an actual rotational button. Unfortunately, 
    this is also true with [[spell:47540]] to an extent.

Clipping your Penance casts, allowing you to get back to casting Void Blast 
    faster, maintain your [[spell:1253724]] stacks easier, and potentially
    get some minor amount of time from being able to better utilize the spell 
    queueing system result in an actual HPS gain instead of letting the spell
    full channel. Keep in mind there is a case where it is still correct to 
    let the spell full channel; when you have both a [[spell:373180]] 
    proc AND a [[spell:198068]] proc available at the same time.

Whether you do this or not is entirely up to you as its a fairly minor 
    optimization, but it is a gain nonetheless.

5.3.

#### Optimizing Evangelism usage in Raid

While the default recommended Raid Ramp rotation has you casting 
    EVangelism first followed by the two instant cast Radiances, the HPS 
    difference between casting Radiance before or after Evangelism is 
    incredibly minimal. As a result, you can easily move the Radiance's 
    exact placement based on when the instant cast portion of the buff is most 
    valuable. If the mechanic you are using Radiance on requires significant 
    movement, feel free to Evang first and use both instant casts on that 
    event. However, if you can safely stand still and hard cast both 
    Radiance's without issue and you know your next Radiance cast would 
    benefit from the instant cast instead, feel free to hard cast them before 
    Evangelism instead to save the buff.

5.4.

#### Ultimate Penitence

When casting [[spell:421453]], after your cast finishes but before 
    the channel of the actual spell begins, there is a brief period of time 
    where you are floating into the air. During this time, you can actually 
    cast an instant cast spell without canceling the channel of Ultimate 
    Penitence. This will commonly be used to cast a [[spell:17]]
     where you would normally do nothing. This is a very important interaction 
    to be aware of and to be utilizing.

The following video shows this mechanic in action:

[观看原文视频](<https://static.icy-veins.com/images/wow/classes/priest/UppiesFreeCastWebm.webm>)

<em>Ultimate Penitence Free GCD Example</em>

5.5.

#### Optimizing Void Shield Usage

[[spell:1253593]] is an incredible amount of our current output and 
    therefore is very important to understand how to utilize it. If you don't 
    understand how the deck system works, please read the following TC block
    before continuing.

:::details TCIn-depth Void Shield Explanation
The specific way that Void Shield procs work is based on a four card **deck
	system**. So while it looks like RNG at a high level, there is a level
	of predictability to the procs. Imagine you have 4 cards in a deck. One
	of those cards reads "Void Shield Proc", while the other 3 read "No Proc".
	Every time you cast Penance, you draw a card from the deck. This continues
	until the deck is empty, at which point you are given a fresh deck with
	the same distribution of cards. This means that you are guaranteed to get
	a Void Shield proc every 4 casts of Penance but you cannot
	predict which cast it will happen on in that set of 4. Additionally,
	there is no way to track where you are in the deck with the default UI.

With the deck system working as it does, there are two extreme edges of
	potential RNG that you can experience. Getting a proc on the first cast of
	a fresh deck followed by getting a proc on the last cast of your next deck
	would leave you with 6 no proc casts of penance in between the two. This is
	the largest dry streak you can have with this system. Additionally, getting
	a Void Shield proc on the last card of the first deck followed by the
	first card of the second deck will give you two back to back procs with
	3 no proc casts on either side.

Understanding how this deck system works can allow you to, in the moment,
	have some level of subconscious tracking of where you are likely to get a
	proc per cast giving you a small amount of control over an otherwise RNG
	based effect.

:::

As a side note, when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle specifically due to 
    [[spell:433905]] existing, self casting your Void Shield's when you 
    do not already have an active shield on yourself results in an HPS gain as 
    the increased size of the shield on yourself will also translate into more
    [[spell:81749]] healing via the reflect.

5.6.

#### Personal Defensive Usage

- [[spell:19236]] — This is one of our primary defensive
  abilities, healing us and bolstering our maximum HP, allowing us to take larger
  hits while dying. Use this whenever you expect to take a large hit you are
  worried about surviving or just in general when you drop to low health.
- [[spell:586]] / [[spell:373446]] — Fade, when combined with
  Translucent Image becomes a small damage reduction on a short cooldown. With
  how weak our defensives are in general, using this often when damage is going
  out is very important. Many players struggle to utilize this effectively when
  it is one of the only defensive abilities in our kit.
- [[spell:193063]] — This is another option in our toolbox
  to provide damage reduction before dangerous moments. Due to it's usage in our
  Raid ramps, you will likely have this active already for most high damage
  moments, but it may require a bit more thought in dungeons. Note that casting
  [[spell:2061]] on another target will provide the DR to yourself via
  [[spell:368275]].

5.7.

#### Surge of Light Decision Making

As [[spell:109186]] only reduces the mana cost of [[spell:2061]] by
    50%, there will be cases where you get procs that you do not want to use.
    If both the Flash Heal healing and the subsequent healing from the
    [[spell:81749]] applied by said cast are all significantly overhealing,
    it can be better to not consume the proc to conserve mana. This is highly
    situational based on your mana consumption and what healing is needed in the
    moment, but just be careful about not instantly sending every Surge of Light
    proc without first thinking about how effective that cast will be.

5.8.

#### Power Infusion

Due to most builds including [[spell:373466]], which will
grant you [[spell:10060]] when cast on an ally, you should never cast
this spell on yourself. While there may be some niche situations where you want
to utilize Power Infusion on yourself for hard healing checks in mythic plus,
the **vast majority** of your casts should align with a DPS player's
cooldowns to help maximize their damage output.

5.9.

#### Atonement

- While we generate healing through dealing damage, the way it is calculated
  is not as simple. For instance, things that increase our damage and healing (for
  example, Versatility) will **not** double dip. This is because only the
  healing portion of such buffs will modify Atonement.
- Mechanics that reduce our damage dealt do not affect the healing done with
  Atonement. For example, some raid bosses have phases with 99% reduced damage
  taken; Disc damage done will still heal for full through Atonement. That being
  said, immunities will stop our damage completely, which also means our Atonement
  healing.
- External buffs that increase our damage dealt will also not affect our
  Atonement healing.
  There is only one external buff that will affect Atonement healing —
  [[spell:255260]], from Demon Hunters.
- Once Atonement is applied to a friendly target, the range at which the
  healing applies is extremely far. You will rarely find any encounter room where
  your Atonement will be out of range unless the encounter phases you and your
  target apart.
- Damage trinkets and Racials do not heal through Atonement
  (unless they increase our baseline spells damage).
- AoE damage effects, such as
  [[spell:132157]] and [[spell:373427]] will do healing through 
  Atonement, but only on the first instance of damage.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **17 Aug. 2026:** Fixed evang sequence formatting and added raid boss info.
- **11 Aug. 2026:** Various formatting fixes.
- **10 Aug. 2026:** Updated for Season 2 release.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 May 2026:** Fixed minor formatting issue and adjusted the ordering of some advanced sections.
- **04 May 2026:** Added sections for a few advanced topics.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **26 Mar. 2026:** Fixed ramp rotation sequences post tier set bug fix.
- **16 Mar. 2026:** Updated for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Aug. 2025:** Fixed issue with tier set check box in Oracle Evang rotation.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added Combat Assistant information.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **03 Apr. 2025:** Minor Typo Fixes.
- **02 Apr. 2025:** Formatting Fix
- **01 Apr. 2025:** Added more information about Oracle in M+
- **24 Mar. 2025:** Added section describing adapting your output windows to boss damage patterns.
- **16 Mar. 2025:** Updated rotation to reflect removal of the Weal and Woe Spell Queue Interaction.
- **02 Mar. 2025:** Fixed formatting issue.
- **01 Mar. 2025:** Updated post recent tuning.
- **25 Feb. 2025:** Fixed small typo in Oracle Rotation.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated Ultimate Penitence usage section.
- **10 Sep. 2024:** Added Fatebender rotation switch for Oracle.
- **09 Sep. 2024:** Updated for season 1 release.
- **22 Aug. 2024:** Reformated page for easier reading.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **27 Mar. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **11 Nov. 2023:** Fixed small rotation issue.
- **07 Nov. 2023:** Added additional clarification.
- **07 Nov. 2023:** Updated page for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Aug. 2023:** Updated rotation to reflect Rhapsody hotfix.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **22 Jan. 2023:** Updated Rotations to reflect 10.0.5 changes and talent changes.
- **11 Dec. 2022:** Reformatted the page to utilize build toggles.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Discipline Priest in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Discipline Priest

Welcome to our Gear and BiS Page for Discipline Priest. Check this page to learn everything
you need to know about gearing a Discipline Priest, including the
BiS Gear from all
sources, Raiding, and Mythic+, information on the best Trinkets, Tier Sets, and
much more.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

2.

### Hero Talent

### Voidweaver

### Overall

This list contains the Best in Slot Gear for Discipline Priest in Midnight Season 2. Keep in mind that there are plenty of other pieces of gear that will be within a margin of error to the ones provided here as well as the inclusion of any tertiary stats can throw off the entire recommendation, but this list is a good starting point/target for what you should be looking for.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 the catalyst will preserve the stats and effects of the items you catalyse. We have listed the best items to catalyse per slot below:

- Helm: [[item:271874@JAAEAAgNyQWN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Shoulders: [[item:268241@JAACAAAG2A]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Chest: [[item:251139@JAACAAAG2A]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Hands: [[item:268243@JAACAAgNyA]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Legs: [[item:271554@JAACAAAG2A]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

:::

:::details FAQWhat Should I Be Taking from My Vault Early?
With the start of Season 2,

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)

's are now available to claim from your Vault instead of a piece of gear (except for the first week of the season). Additionally, spending these bonus rolls on Heroic bosses in the Raid will provide you with Mythic items at 1/6 on the upgrade track. Additionally, the final boss in the Raid drops 3 incredibly powerful cantrip items as including a weapon as the bosses only loot for Cloth healers. As a result, the recommendation is to take a bonus roll from the vault for the first 3 weeks that you can and bonus roll the end boss on Heroic until you have all 3 items.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:239649@JAACAAQ0wA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">The Twin Fangs</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAACAAQ0wA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:159667]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the Best in Slot Gear setup made up of gear farmable from only Mythic+ Dungeons.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 the catalyst will preserve the stats and effects of the items you catalyse. We have listed the best items to catalyse per slot below:

- Helm: [[item:251232@JAAEAAgNyQWN]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Shoulders: [[item:239031@JAACAAAG2A]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:251139@JAACAAAG2A]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Hands: [[item:159247@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Legs: [[item:251160@JAACAAAG2A]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

:::

:::details FAQWhat Should I Be Taking from My Vault Early?
The following is a list of dungeons to target early for good immediate upgrades:

- The Blinding Vale provides you access to the [[item:250214]], which is one of your more valuable options trinket wise from dungeons.
- Murder Row gets you access to another solid trinket, [[item:250215]], as well as a few other solid pieces like a heavy haste chest piece which is a very good early catalyst target.
- Any dungeon with a weapon drop is a high priority. The specific stats on the weapon matter far less than just getting an elevated ilvl weapon to hold you over until you get your Mythic dagger from the recommended Bonus Roll strategy.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:251232@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Neck</th><td>[[item:251173@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Waist</th><td>[[item:193691@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:251219@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Bracers</th><td>[[item:251127@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:159636@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the Best in Slot Gear setup made up of gear from the Season 2 Raids.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 the catalyst will preserve the stats and effects of the items you catalyse. We have listed the best items to catalyse per slot below:

- Helm: [[item:271874@JAAEAAgNyQWN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Shoulders: [[item:268241@JAACAAAG2A]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Chest: [[item:271558@JAAEAAAG2wYN]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Hands: [[item:268243@JAACAAgNyA]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Legs: [[item:271554@JAACAAAG2A]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

:::

:::details FAQWhat Raid-Items Do i Want Most?
The following is a list of the most important item to target from the Raid:

- [[item:271092@JAACAAAG2A]]: Our BiS weapon. This item drops from the Ula'tek. You will aquire this at Mythic Ilvl early in the season by Bonus rolling the Ula'tek on Heroic using tokens aquired from the Great Vault
- [[item:271874@JAACAAAG2A]]: An incredibly powerful cantrip helm that also drops from Ula'tek. You will aquire this at Mythic Ilvl early in the season by Bonus rolling the Ula'tek on Heroic using tokens aquired from the Great Vault
- [[item:268265@JAACAAAG2A]]: An incredibly powerful cantrip neck that drops from Ula'tek. You will aquire this at Mythic Ilvl early in the season by Bonus rolling the Ula'tek on Heroic using tokens aquired from the Great Vault
- [[item:270162]]: A very powerful healer trinket that drops off the first boss of the Raid.
- [[item:270167]]: Another very powerful trinket that drops off the Lair Boss [Nymrissa Wavecaller](<https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">The Twin Fangs</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></div></td></tr><tr><th>Bracers</th><td>[[item:268228@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

### Oracle

### Overall

This list contains the Best in Slot Gear for Discipline Priest in Midnight Season 2. Keep in mind that there are plenty of other pieces of gear that will be within a margin of error to the ones provided here as well as the inclusion of any tertiary stats can throw off the entire recommendation, but this list is a good starting point/target for what you should be looking for.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 the catalyst will preserve the stats and effects of the items you catalyse. We have listed the best items to catalyse per slot below:

- Helm: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Shoulders: [[item:268241@JAACAAgNyA]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Chest: [[item:251139@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Hands: [[item:268243@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Legs: [[item:281235@JAACAAgNyA]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

:::

:::details FAQWhat should I be taking from my Vault early?
With the start of Season 2,

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)

's are now available to claim from your Vault instead of a piece of gear (except for the first week of the season). Additionally, spending these bonus rolls on Heroic bosses in the Raid will provide you with Mythic items at 1/6 on the upgrade track. Additionally, the final boss in the Raid drops 3 incredibly powerful cantrip items as including a weapon as the bosses only loot for Cloth healers. As a result, the recommendation is to take a bonus roll from the vault for the first 3 weeks that you can and bonus roll the end boss on Heroic until you have all 3 items.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:239649@JAACAAQ0wA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">The Twin Fangs</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:281235@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAACAAQ0wA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:159667]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the Best in Slot Gear setup made up of gear farmable from only Mythic+ Dungeons.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 the catalyst will preserve the stats and effects of the items you catalyse. We have listed the best items to catalyse per slot below:

- Helm: [[item:251232@JAAEAAgNyQWN]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Shoulders: [[item:239031@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:251139@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Hands: [[item:159247@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Legs: [[item:251160@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

:::

:::details FAQWhat Dungeons Should I Farm?
The following is a list of dungeons to target early for good immediate upgrades:

- The Blinding Vale provides you access to the [[item:250214]], which is one of your more valuable options trinket wise from dungeons.
- Murder Row gets you access to another solid trinket, [[item:250215]], as well as a few other solid pieces like a heavy haste chest piece which is a very good early catalyst target.
- Any dungeon with a weapon drop is a high priority. The specific stats on the weapon matter far less than just getting an elevated ilvl weapon to hold you over until you get your Mythic dagger from the recommended Bonus Roll strategy.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:251232@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Neck</th><td>[[item:251173@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Waist</th><td>[[item:193691@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:251219@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Bracers</th><td>[[item:251127@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:159636@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the Best in Slot Gear setup made up of gear from the Season 1 Raids.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 the catalyst will preserve the stats and effects of the items you catalyse. We have listed the best items to catalyse per slot below:

- Helm: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Shoulders: [[item:268241@JAACAAgNyA]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Chest: [[item:271558@JAACAAgNyA]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Hands: [[item:268243@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Legs: [[item:281235@JAACAAgNyA]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

:::

:::details FAQWhat should I be taking from my Vault early?
The following is a list of the most important item to target from the Raid:

- [[item:271092@JAACAAAG2A]]: Our BiS weapon. This item drops from the Ula'tek. You will aquire this at Mythic Ilvl early in the season by Bonus rolling the Ula'tek on Heroic using tokens aquired from the Great Vault
- [[item:271874@JAACAAAG2A]]: An incredibly powerful cantrip helm that also drops from Ula'tek. You will aquire this at Mythic Ilvl early in the season by Bonus rolling the Ula'tek on Heroic using tokens aquired from the Great Vault
- [[item:268265@JAACAAAG2A]]: An incredibly powerful cantrip neck that drops from Ula'tek. You will aquire this at Mythic Ilvl early in the season by Bonus rolling the Ula'tek on Heroic using tokens aquired from the Great Vault
- [[item:270162]]: A very powerful healer trinket that drops off the first boss of the Raid.
- [[item:270167]]: Another very powerful trinket that drops off the Lair Boss [Nymrissa Wavecaller](<https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">The Twin Fangs</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:281235@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></div></td></tr><tr><th>Bracers</th><td>[[item:268228@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

3.

### Trinket Recommendations for Discipline Priest

While there are a large number of trinkets available, the following are the 
  highest priority options to focus on obtaining for Discipline Priest.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Discipline Priest Trinkets**
**On-Use -**

[[item:270162]]

**Passive -**

[[item:270167]]

:::

Looking for where the trinkets you have rank in comparison? Take a look at 
  the complete chart below!

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Discipline Priest Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270167]]</li>&#10;<li>[[item:270162]]</li>&#10;<li>[[item:280835]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270169]] - This trinket is very strong and &#10;      competitive with the top two trinkets but only when at its elevated &#10;      possible item level. At equal ilvl, the other 2 will pull ahead.&#10;     </li>&#10;<li>[[item:281215]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:251792]]</li>&#10;<li>[[item:248583@JAACAAgMyA]] (Set to Haste)</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270603]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:249343]]</li>&#10;<li>[[item:249341]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250256]]</li>&#10;<li>[[item:250215]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250248]]</li>&#10;<li>[[item:268292]]</li>&#10;<li>[[item:250255]]</li>&#10;<li>[[item:250254@JAACAAgNyA]]</li>&#10;<li>[[item:193718@JAAIAAQkCYHKvbRLfA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250224]]</li>&#10;<li>[[item:270161]]</li>&#10;<li>[[item:270170]]</li>&#10;<li>[[item:273794]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:158368]]</li>&#10;<li>[[item:270171]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

:::details FAQDoes Damage from Trinkets Work with [[spell:81749]]?
No. External damage effects (trinkets/racials/enchants/embellishments/etc) provide no healing benefit.

:::

4.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)'s can be utilized to roll for bonus pieces
  of loot from Raid bosses or dungeons. You will receive two of these per week 
  starting later in the season. It will cost one to roll on a Raid boss or on a
  specific dungeon's loot table. Which item you will receive from the 
  location you utilize these will be random, but once you get a specific item 
  from that loot table you will not receive it again. As a result, it may 
  take a handful of weeks/attempts to get the specific item you want, but you 
  are eventually guaranteed to get it with enough attempts.

While the ability to purchase [Nebulous Voidcores](<https://www.wowhead.com/currency=3418>) directly will 
  remain locked until later in the season, you will have the ability to earn 
  these through your [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>).

4.1.

#### Recommended Nebulous Voidcore Usage for Discipline Priest

In Season 2, bonus rolling on a heroic difficulty raid boss will provide a 
  1/6 upgrade track Mythic item instead of a Heroic item. This means you can 
  get access to powerful items early off bosses that normally would be incredibly 
  difficult to kill on Mythic difficulty. Specifically, the final boss of the 
  raid has 3 powerful cantrip items make up the bosses entire loot table 
  for cloth healers. One of these items is a main-hand weapon. As a result, 
  we recommend spending your first 3 vaults of the season claiming Nebulous 
  Voidcores and using them to bonus roll the final boss of the raid on heroic 
  difficulty until you have all 3 items.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Mythic [[item:271092]]
2. Mythic [[item:271874]]
3. Mythic [[item:268265]]
4. Any remaining items from the BiS lists.

:::

5.

### Ascendant Venomstones

When using your [[item:280562]], you want to prioritize your 
  weapon's first as they are your highest budget options. Keep in mind if you 
  already have a 344 dagger or necklace from Mythic Ula'tek, you cannot further 
  upgrade them, but any regular mythic track version that you may have bonus 
  rolled from Heroic can be upgraded. The following is your general priority 
  order:

1. Mainhand Weapon
2. Offhand
3. Trinkets
4. Necklace

6.

### Crafted Gear and Embellishments for Discipline Priests

As your ability to craft early season is heavily time-gated by both your 
access to sparks and higher tier crests, you want to ensure your early crafts 
are high value. Due to the fact that we will be bonus rolling for a Mythic 
cantrip Main-hand weapon, we do not want to be crafting a weapon in most cases. 
As a result, your general priority will be as follows:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Discipline Crafted Gear Priority**
- [[item:245769@JAAKAAwt1wgNRDTWiscN]] with [[item:273060]]
- Any high budget slot you do not have at Myth track yet with 
    [[item:240167]] on it.
- Any item you do not have on Myth track yet

:::

Keep in mind that while it is a waste of sparks, if you get unlucky with 
  the bonus roll strategy early on and don't get the Mythic cantrip weapon 
  in your first roll or two, you can craft a main hand as well as a temporary 
  hold-over. Crest wise, you're fine because it will simply discount the cantrip 
  dagger the cost of the sparks you spend when you do eventually get it, 
  you're just wasting the 2 sparks. Whether or not you do this will be 
  heavily dependent on your specific situation and the order in which you get 
  your items via the bonus roll.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

6.1.

#### Best Embellishments for Discipline Priest

Embellishments are special effects that are either found on crafted pieces
by default or can be added to crafted pieces during the crafting process. A
character can have **two** embellishments equipped at any time.

We are currently recommending crafting the following two embellishments for 
  your eventual BiS setup:

- [[item:273060]] on any main-hand or off-hand craft during 
        the gearing process.
- [[item:240167]] on 2 different items. Early on you can throw 
      this on any piece of crafted gear that accepts it, but eventual BiS will
      have these on low budget item slots like Bracers and Cloak.

6.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

7.

### Crest Usage

Early into a season when you have limited access to crests, such as 
[Myth Mistcrest](<https://www.wowhead.com/currency=3446>), it is very important to be spending them in an 
efficient manner. This will allow you to optimize your early season power as 
best as possible. The following is a general priority list of what slots 
have the largest power budget and should be a the priority upgrades with your 
crests.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Discipline Priest Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Rings/Amulet**

➜

**Shoulders/Gloves/Belt/Boots**

:::

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5 release.
- **18 Aug. 2026:** Updated embellishment recommendations based on recent Ritual Stone nerf.
- **16 Aug. 2026:** Adjust trinket recommendations based on recent trinket tuning.
- **11 Aug. 2026:** Various formatting and typo fixes.
- **10 Aug. 2026:** Updated for Season 2 release.
- **15 Jun. 2026:** Updated with Patch 12.0.7 Sporefall gear.
- **20 May 2026:** Fixed visual coloring of items in the BiS lists.
- **22 Apr. 2026:** Updated embellishment and bis list recommendations based on recent class tuning.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **26 Mar. 2026:** Updated trinket recommendations post hotfixes.
- **21 Mar. 2026:** Updated trinket recommendations based on better data from live servers.
- **16 Mar. 2026:** Updated trinket recommendations following Gaze nerf.
- **16 Mar. 2026:** Updated for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Added Dinar Section.
- **14 Aug. 2025:** Updated page to include Nexus-Kings Command Trinket Information.
- **10 Aug. 2025:** Adding missing trinket and updated crafting recommendations.
- **04 Aug. 2025:** Updated for Season 3 release.
- **17 Jun. 2025:** Updated D.I.S.C recommendation.
- **15 Jun. 2025:** Added information on the D.I.S.C Belt.
- **12 May 2025:** updated Puzzling Cartel Chip Section.
- **21 Apr. 2025:** Added Puzzling Cartel Chip Section for 11.1.5.
- **24 Mar. 2025:** Updated post trinket tuning.
- **01 Mar. 2025:** Updated Circlet recommendation based on recent tuning.
- **25 Feb. 2025:** Fixed broken link on page.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **17 Dec. 2024:** Updated Cyrce's Circlet info based on further TC Work.
- **16 Dec. 2024:** Updated following Cyrce's Circlet Buff.
- **15 Dec. 2024:** Added section for Cyrce's Circlet.
- **21 Oct. 2024:** Added section talking about on use trinket usage.
- **09 Sep. 2024:** Updated page for Season 1 Release.
- **22 Aug. 2024:** Updated Embellishments following tuning.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Discipline Priest. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Discipline Priest Stat Priority

All of our secondary stats are very close in value. Due to the
scaling of Intellect on gear as well as the closeness of the secondary stat
values, targeting the highest item level possible is the recommended
play in terms of gearing.

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Stat Priority

The stat priority is as follows **when deciding between equal item level
gear**.

Haste (until 1800 rating)

Mastery

Critical Strike

Versatility

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Stat Priority

The stat priority is as follows **when deciding between equal item level
gear**.

Haste

Mastery

Critical Strike

Versatility

For Oracle, all our stats are fairly close in value, so you should avoid 
  stacking any single stat past any diminishing returns breakpoint.

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. Ensure that all gear you are wearing
(except for trinkets and jewelry) have intellect on them as every point of 
Intellect will increase your the power of your damage and healing.

**Haste** reduces the cast time of your spells, reduces the cooldown of
[[spell:17]], [[spell:8092]], and [[spell:47540]], reduces your 
global cooldown and more. Moreover, it increases the number of attacks your 
[[spell:34433]]/[[spell:123040]] can make, and the number of 
ticks from [[spell:589]].

**Mastery** ([[spell:271534]]) increases your healing on
Atonement targets. Please note that this **DOES** work with your
Atonement healing and not just your direct healing.

**Critical Strike** grants your damaging spells and heals a chance to
double their value. That said, it is worth noting that it does not double-dip
with regards to [[spell:81749]] healing (Atonement heals cannot be
critical hits; they only heal for the amount of damage that was done, which is
the only portion that can be a critical strike).

**Versatility** is a simple damage and healing done increase. Additionally,
however, it does also provide a small damage taken reduction as well.

**Leech** grants you self-healing based on your outgoing damage and
healing events. This free self-sustain can reduce the amount of Mana and
global cooldowns you and the other healers have to spend healing you during
major damage events, allowing you to focus more on the people that need it.
Due to this stat being a tertiary stat instead of a secondary stat, it is not
going to be found very often but will remain powerful when it is.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Season 2 release.
- **15 Jul. 2026:** Updated stat recommendations.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **04 May 2026:** Updated stat prio to reflect further sequence optimizations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Season 1 Release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Mar. 2025:** Updated post Discipline Nerfs.
- **01 Mar. 2025:** Updated based on recent tuning.
- **24 Feb. 2025:** Updated Stat Prio slightly moving into 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **27 Mar. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **21 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Discipline Priest, based on your [stat priority](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

In Midnight, you will have two categories of gems to choose from: Rare or
Epic. The Rare gems are either just a single stat or a combination of two
secondary stats on one gem. The Epic gems are significantly stronger, but you
can only use one at a time for your entire character.

Gems can be applied to a Helm, Bracer, or Belt via the
[[item:275707]] item from the Great Vault.

You will want to use a single [[item:240983]] first.
This provides a solid amount of primary stat. After that, all remaining slots
should utilize [[item:240892]].

2.

### Best Enchants and Weapon Augments

You should utilize [[item:243733]] as your weapon oil whenever possible.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244003]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240155]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flasks

For Flasks, you should utilize [[item:241325]].

3.2.

#### Potions

As a general use recommendation, [[item:241308]] is your best bet.
    However, when playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver, [[item:241288]]
    is valid alternative option. Recklessness can give you more overall output 
    in a single window, but you need to be careful when using it as it cannot 
    be used with [[spell:10060]] or a Lust window as you can easily 
    reach haste levels where the stat is heavily devalued. As a result, for 
    Voidwewaver specifically, Recklessness is your best option if you want an 
    additional cooldown to use separate of your existing cooldowns and Light's 
    Potential is your best option if you want to stack it with an existing 
    cooldown window.

For mana potions, if you do use one it would be a  [[item:241294]].
    Howeveer, the power level of combat pots means you should **NEVER** be 
    using mana potions.

For health potions, utilize [[item:271883]].

3.3.

#### Food

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver, you should use [[item:275265]] or 
    [[item:275266]] when available (or [[item:275258]] as a 
    personal food alternative.)

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle, you should use [[item:255845]] or 
    [[item:255846]] when available (or [[item:242275]] as a 
    personal food alternative.)

3.4.

#### Augment Runes

You should aim to use [[item:259085]] whenever possible.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **16 Aug. 2026:** Replaced VW food recommendation with new Coiled Isle food
- **10 Aug. 2026:** Updated for Season 2 release.
- **15 Jul. 2026:** Updated enchant/gem recommendations.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 May 2026:** Updated page formatting to be more consistent with other guides.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **26 Mar. 2026:** Updated weapon enchant recommendation.
- **24 Mar. 2026:** Removed mention of Tea post hotfix.
- **16 Mar. 2026:** Updated for Season 1 Release.
- **02 Mar. 2026:** Fixed food recommendation error.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Added section for Corruption Enchants.
- **01 Mar. 2025:** Updated post recent tuning.
- **24 Feb. 2025:** Swapped Weapon Enchant/Added alternative Consumables for Oracle.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated food and gem recommendations.
- **26 Aug. 2024:** Swapped chest enchant recommendation.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **27 Mar. 2024:** Reviewed for Patch 10.2.6 and updated food recommendation.
- **16 Jan. 2024:** Adjusted wording on Dreaming Devotion enchant.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **11 Nov. 2023:** Fixed Health Potion Mention.
- **06 Nov. 2023:** Added mention of new Weapon enchant and Helm enchant for 10.2.
- **04 Sep. 2023:** Reviewed for patch 10.1.7.
- **11 Jul. 2023:** Updated Annulet recommendation section.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **06 May 2023:** Updated Enchant and Phial Recommendations based on hotfixes/tuning
- **01 May 2023:** Updated Primordial Stone Recommendations post Hotfixes.
- **21 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Discipline Priest in World of Warcraft Patch 12.1.5.

1.

### Discipline Priest in Mythic+ in Midnight Season 2

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Mythic+ Build

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Mythic+ Talents

This build is your primary build for Mythic+ content. This build focuses on
   casting [[spell:47540]] on cooldown for throughput via [[spell:81749]],
   while also providing procs of [[spell:1253593]]. Running both 
   [[spell:238135]] and [[spell:390786]] for stronger shields make 
   Void Shield a power house of a button each time it is cast. This allows the build 
   to give you a high amount of control over where your healing is going via 
   Penance targeting, Void Shield targeting, base Power Word: Shields, and 
   [[spell:186263]].

**Be sure to make use of the 'Export Talents' button to import
the build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGgZA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAacoqq9lskFGadhNQwwxBi4IJ6E-AAAA-CEMYkow0AUgscA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Mythic+ Build

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver Mythic+ Talents

This build is an alternative build for Mythic+ content. Providing a
	very strong amount of output with every [[spell:447444]] window 
   which you have access to very frequently. Additionally, you still have 
   Eternal Barrier talented, so your Void Shields still provide a solid 
   amount of output per cast. This builds largest weakness is mobility, due to 
   the sheer amount of time you need to spend casting [[spell:450405]].

**Be sure to make use of the 'Export Talents' button to import
	the build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgZYZGMzMzwYmBbmmJGMzAAAMbz2CYsZAAYMzMjBzgZGMCmB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAaoqq9ls8AlFGiF8SckMQYYgwAK-AAAA-FIikwAMUY8wSgC-
```

:::

3.

### In-Depth Rotation Tips for Mythic+

With [[spell:1253593]] being such a large part of our total output 
   regardless of build, as well as our new tier set providing cooldown reduction
   to [[spell:8092]] on each [[spell:47540]] cast, it is absolutely
   critical to be casting Penance on cooldown.

While you need to be utilizing [[spell:186263]] to assist in dealing with 
   single-target spot-healing requirements, swapping to spamming Shadow Mend too early 
   when you could have continued to rely on your core spells for longer is 
   one of the biggest reasons for Discipline Priests to run into Mana issues
   in keys. Try to cycle through your other available spells as well as both of 
   your [[spell:33206]] charges first, before you start spamming
   Shadow Mend.

4.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

4.1.

#### Interrupts, Stuns, and Stops

Discipline Priest does not have access to an interrupt ability as is the 
    cast for most healers.

[[spell:8122]] gives us the capability to fear a
 group of enemies. This is our only form of AoE crowd control, so utilizing it
 to interrupt or disrupt large groups of enemies makes it immensely valuable.

[[spell:9484]] provides a potential single target CC.
 Always be on the lookout for Undead/Aberration enemies to utilize this crowd 
 control ability.

[[spell:205364]] grant us to capability to control an enemy for a
    short period. In most cases, this does not provide significant value, but there
    have been times in the past where dungeon or raid enemies had extremely
    powerful spells we could cast by utilizing these abilities.

### Other Utility

4.2.

#### Other Utility

[[spell:528]] allows us to dispel
 buffs and effects off of enemy targets. This can be valuable in many
 situations where the buffs on various enemies can make them either
 significantly more threatening via damage increases or a lot harder to kill
 via damage reductions.

[[spell:390632]] alters our default magic dispel to also remove
    Disease effects. How useful this is heavily relies on the content you are
    doing, but in situations where there are disease effects being applied to
    allies, this utility can have immense value.

[[spell:32375]] may be one of our most powerful pieces of utility. The
    ability to remove magic debuffs from an entire group of allies or from a
    group of enemies with a single cast is immensely powerful. Many mechanics
    in both dungeons and raids have been trivialized by this spell over the
    years, and it will likely remain to do so in the future.

[[spell:10060]] is an immensely powerful spell available to us
    in our talent tree. This ability allows us to provide a significant haste
    buff to a single player on a two-minute cooldown, most often used on an
    ally DPS player, especially when considering [[spell:373466]].

[[spell:21562]], while not the most interesting piece of
    utility, is very valuable in many situations. Keep this buff active
    on your group at all times.

5.

### Dungeon-Specific Tips

This section is focused on Priest-specific tips and tricks to help in
specific dungeons' bosses and trash.

### Talent Choice Cheat Sheet

For a quick guide of which talents to use, check the dungeon and affixes
in the table below and see the list of suggested utility talents you should
make sure you work into your build. You can also use the 
[Mythic Plus Utility](<https://www.curseforge.com/wow/addons/mythic-plus-utility-mpu>) 
Addon to remind you to swap to various talents.

Once Season 2 has begun proper, we will be updating this section with specific tips
and tricks for both trash mechanics and bosses, and how to best deal with them as a
Discipline Priest. Make sure to check back again later!

<table>&#10;<tr>&#10;<th>Dungeons</th>&#10;<th>Affixes</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=148" rel="noopener noreferrer">Xal'atath's Bargain: Ascendant</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=158" rel="noopener noreferrer">Xal'atath's Bargain: Voidbound</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=162" rel="noopener noreferrer">Xal'atath's Bargain: Pulsar</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=160" rel="noopener noreferrer">Xal'atath's Bargain: Devour</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></td>&#10;<td></td>&#10;</tr>&#10;</table>

Based on the selections above, you should run the following class talents:

![Improved Purify not Talented](<https://static.icy-veins.com/images/wow/classes/priest/purify_disease.jpg>)**适用条件：Xal'atath's Bargain: Devour（未启用）；Altar of Fangs（未启用）；King's Rest（未启用）。**

![Improved Purify Talented](<https://static.icy-veins.com/images/wow/classes/priest/purify_disease.jpg>)**适用条件：Xal'atath's Bargain: Devour（启用）；Altar of Fangs（启用）；King's Rest（启用）。**

![Mass Dispel not Talented](<https://static.icy-veins.com/images/wow/classes/priest/mass_dispel.jpg>)**适用条件：Xal'atath's Bargain: Ascendant（未启用）；Xal'atath's Bargain: Devour（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Murder Row（未启用）；Ruby Life Pools（未启用）；Temple of Sethraliss（未启用）。**

![Mass Dispel Talented](<https://static.icy-veins.com/images/wow/classes/priest/mass_dispel.jpg>)**适用条件：Xal'atath's Bargain: Ascendant（启用）；Xal'atath's Bargain: Devour（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Ruby Life Pools（启用）；Temple of Sethraliss（启用）。**

![Phantasm not Talented](<https://static.icy-veins.com/images/wow/classes/priest/phantasm.jpg>)**适用条件：Xal'atath's Bargain: Devour（未启用）；Altar of Fangs（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Ruby Life Pools（未启用）；Blinding Vale（未启用）；Voidscar Arena（未启用）。**

![Phantasm Talented](<https://static.icy-veins.com/images/wow/classes/priest/phantasm.jpg>)**适用条件：Xal'atath's Bargain: Devour（启用）；Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；Blinding Vale（启用）；Voidscar Arena（启用）。**

- **适用条件：Xal'atath's Bargain: Devour（启用）；Altar of Fangs（启用）；King's Rest（启用）。** [[spell:390632]]
- **适用条件：Xal'atath's Bargain: Ascendant（启用）；Xal'atath's Bargain: Devour（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Ruby Life Pools（启用）；Temple of Sethraliss（启用）。** [[spell:32375]]
- **适用条件：Xal'atath's Bargain: Devour（启用）；Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；Blinding Vale（启用）；Voidscar Arena（启用）。** [[spell:108942]]
- **适用条件：Xal'atath's Bargain: Voidbound（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) Voidweaver for access to [[spell:451840]]
- **适用条件：Xal'atath's Bargain: Devour（未启用）；Xal'atath's Bargain: Voidbound（未启用）；Xal'atath's Bargain: Ascendant（未启用）；Altar of Fangs（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Murder Row（未启用）；Ruby Life Pools（未启用）；Temple of Sethraliss（未启用）；Blinding Vale（未启用）；Voidscar Arena（未启用）。** There are no specific talent suggestions.

5.1.

#### Rav'i

- Tips to be added soon!

5.2.

#### The Writhing Coil

- Tips to be added soon!

5.3.

#### Zul'jan

- Tips to be added soon!

5.4.

#### Trash

- Tips to be added soon!

5.5.

#### The Hoardmonger

- Tips to be added soon!

5.6.

#### Sentinel of Winter

- Tips to be added soon!

5.7.

#### Nalorakk

- Tips to be added soon!

5.8.

#### Trash

- Tips to be added soon!

5.9.

#### The Golden Serpent

- Tips to be added soon!

5.10.

#### Mchimba the Embalmer

- Tips to be added soon!

5.11.

#### The Council of Tribes

- Tips to be added soon!

5.12.

#### Dazar, The First King

- Tips to be added soon!

5.13.

#### Trash

- Tips to be added soon!

5.14.

#### Kystia Manaheart

- Tips to be added soon!

5.15.

#### Zaen Bladesorrow

- Tips to be added soon!

5.16.

#### Xathuux the Annihilator

- Tips to be added soon!

5.17.

#### Lithiel Cinderfury

- Tips to be added soon!

5.18.

#### Trash

- Tips to be added soon!

5.19.

#### Melidrussa Chillworn

- Tips to be added soon!

5.20.

#### Kokia Blazehoof

- Tips to be added soon!

5.21.

#### Kyrakka and Erkhart Stormvein

- Tips to be added soon!

5.22.

#### Trash

- Tips to be added soon!

5.23.

#### Adderis and Aspix

- Tips to be added soon!

5.24.

#### Merektha

- Tips to be added soon!

5.25.

#### Galvazzt

- Tips to be added soon!

5.26.

#### Avatar of Sethraliss

- Tips to be added soon!

5.27.

#### Trash

- Tips to be added soon!

5.28.

#### Lightblossom Trinity

- Tips to be added soon!

5.29.

#### Ikuzz the Light Hunter

- Tips to be added soon!

5.30.

#### Lightwarden Ruia

- Tips to be added soon!

5.31.

#### Ziekket

- Tips to be added soon!

5.32.

#### Trash

- Tips to be added soon!

5.33.

#### Taz'Rah

- Tips to be added soon!

5.34.

#### Atroxus

- Tips to be added soon!

5.35.

#### Charonus

- Tips to be added soon!

5.36.

#### Trash

- Tips to be added soon!

5.37.

#### Gearing for Mythic+

The primary difference you may see between Discipline Priests gearing for
Raid content versus Mythic Plus content is that, often times, Discipline players
may look towards prioritizing Versatility a bit more as a secondary stat due 
to the damage reduction provided.

This does come at the cost of some HPS as 
Versatility is our worst stat for actual healing contribution. This is something 
that is primarily only relevant for very high level keys and not something we 
recommend to be copied in the vast majority of cases.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Season 2 release.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **21 Mar. 2026:** Updated talent recommendations post upcoming class tuning.
- **16 Mar. 2026:** Updated for Season 1 release.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Shackle Undead to Shackle Horror
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **01 Mar. 2025:** Updated based on recent tuning.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Removed some outdated references.
- **09 Sep. 2024:** Updated page for Season 1 Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **27 Mar. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **11 Nov. 2023:** Removed outdated mention.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for patch 10.1.7.
- **10 Jul. 2023:** Updated talent recommendation for 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **22 Jan. 2023:** Updated talent recommendation for patch 10.0.5.
- **11 Dec. 2022:** Removed missed mentions of Shining Force on page.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Discipline Priest in World of Warcraft Patch 12.1.5.

1.

### Best Macros

We highly suggest that all of your heals, as well as other spells castable
on raid members (such as [[spell:1706]], for preventing fall
damage), be incorporated into mouseover macros. The macros will allow you to
cast them on raid members more easily. As an alternative to creating mouseover
macros, you can use [Clique](<https://www.curseforge.com/wow/addons/clique>).

Here is an example of a mouseover macro. Simply replace
[[spell:17]] with the name of the spell you want to use:

#### Generic Mouseover Macro Example

```wow-macro
#showtooltip Power Word: Shield
/cast [target=mouseover,help,nodead][]Power Word: Shield
```

This will cast [[spell:17]] on your mouseover target if it is a
friendly target and not dead. Otherwise, it will cast on your current
target.

1.1.

#### Penance Macros

It is strongly recommended to keep the Offensive and Defensive
[[spell:47540]] components separated. You can either use a macro with modifiers
or use two separate keybinds with harm/help modifiers.

**Harm Only:**

#### Offensive Only Penance

```wow-macro
#showtooltip Penance
/cast [harm] Penance
```

**Help Only:**

#### Defensive Only Penance

```wow-macro
#showtooltip Penance
/cast [@mouseover,help] Penance
```

1.2.

#### NoChanneling Macro

Due to the way [[spell:47540]] works, when you try to queue another spell
during its cast, you can accidentally interrupt the last bolt. To avoid this,
apply the following conditional to specific spells, very often being
[[spell:585]], that cause it the most for you. This works with any spell
and not just smite. Smite is simply used as an example here.

**Note: Current recommendations include intentionally clipping Penance casts
    for optimal gameplay. As a result, you should likely not be using this macro 
    this patch. Check out the rotation page for more information.**

#### NoChanneling Example

```wow-macro
#showtooltip Smite
/cast [nochanneling:penance] Smite
```

1.3.

#### Angelic Feather Macro

This is a really handy macro that casts [[spell:121536]] under the
player using the @player shorthand.

#### Angelic Feather Macro

```wow-macro
#showtooltip Angelic Feather
/cast [@player] Angelic Feather
/stopspelltarget
```

2.

### Best Addons

Listed below are some recommended Addons for Discipline Priest.

2.1.

#### Alternative Raid Frame Options

Grid2 is our recommended Addon for Raid frames, providing a massive 
    amount of customization options as well as being incredibly performant.
    The largest downside of this Addon is the high barrier to entry as its not 
    the simplest to learn, but very rewarding once you do so.

EllesmereUI is an incredibly popular full UI suite with solid customization 
    and performance right out of the box. This addon also includes custom 
    Raid frames. If you are looking for a full Ui package with minimal effort, 
    this is a very good option over just sticking with default UI.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Added a note to the Penance No Channeling Macro.
- **10 Aug. 2026:** Updated for Season 2 release.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 May 2026:** Added mention of Power Word: Toolbox.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **16 Mar. 2025:** Updated Premo macro to a slightly more consistent version.
- **03 Mar. 2025:** Adjusted NoChanneling Macro.
- **28 Feb. 2025:** Added note to insight spell queue macro.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Added recommended Weakaura and Grid2 Profiles.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within Release.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **27 Mar. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **21 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **22 Jan. 2023:** Added Macro for Potion of Chilled Clarity Cancelaura.
- **11 Dec. 2022:** Updated Halo/DStar macro to work with Scov.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
