## 专精概览

Welcome to our Demonology Warlock guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Demonology Warlock in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Demonology Mythic+ Resources

[NEW! Top Demonology Talent Builds](<https://raider.io/specs/demonology-warlock/talents>)

[Top Demonology Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warlock/demonology>)

[Demonology Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warlock--demonology>)

[Popular Demonology Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warlock--demonology>)

1.

### Demonology Warlock Overview

Demonology Warlock is a versatile specialization centered around
summoning waves of expendable minions to do your bidding while generating
resources in-between. While the specialization does have some ramp-up time,
it does feel smooth and fast once it is running at full steam. Demonology
Warlocks are especially strong in encounters that have stable mobility
rather than very chaotic and disorderly movement.

Like all Warlock specializations, Demonology brings
[[spell:111771]], a powerful raid cooldown that can transport your
entire group 40 yards instantly.

Strong Single Target and Cleave

Demonology Warlock boasts good single target damage and strong AoE at the
expense of very little funneling, swap potential and total lack of spread
cleave. Apex talent brings lot of power to the spec, and unfortunately a good
amount of volatility in the overall output.

High Performance Workhorse

In Midnight, Demonology Warlock brings good single target, with relative
easy access to bonus cleave spells, strong cooldowns and good enough
mobility. Apex introduces some variance on a spec that previously had almost
none, and whilst SoulHarvester adds more of it, Diabolist on the other hand
is the old reliable.

Standout DPS

Demonology's damage profile in keys is very solid, offering strong single
target and stacked cleave while also retaining a certain level of mobility.
Apex volatility will be at its worst here however, with how some of the
summons brings exceptional AoE and others focus more on single target.

Beside that, Midnight brings to the Warlock class a lot of
utility, in the form of Banes and AoE curses, as well as one of the highest
survivability across all classes.

High Utility

[[spell:111771]]s, most of the time, are a must in Raid environment,
while [[spell:20707]]s and [[item:5512]]s provide nice Quality
of Life.

In Dungeons the situation is different however, with Gateways
used for the rare skips, Soulstones being a cast time combat resurrection,
and Healthstones being just better potions.

Curses are in a better spot, offering AoE application and a stronger, but
timed variant in Blights. The addition of [[spell:1276467]] allows
Demonology to have a dedicated interrupt and the interrupt/stun from Felguard
at the same time, if the situation demands multiple kicks in a row.

Good Enough

Demonology is a rather mobile spec outside of cooldowns, especially as a Warlock.
Depending on the talent configuration, there are multiple procs that can
be saved for movement windows.

Among the best

Warlock survivability is mostly fine. While the class lacks immunity or
damage reversal tools, the main mechanic is to buffer the existing Health
Pool with Overshield from

[[spell:108370]]

, mitigation
from

[[spell:108415]]

, and active spells like

[[spell:108416]]

and

[[spell:104773]]

.

2.

### Demonology Warlock in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

The patch features no Warlock changes and is instead focused on two new
endgame activities, a new Raid and the anticipated Labyrinth Mega-Delve. Make
sure to check the following links for further details:

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

This patch continues Season 2 storyline and gear progression, focusing on
quality of live improvements, new solo-focused content
with [Aqir Invasions](<https://www.icy-veins.com/wow/aqir-invasions-guide>), and much more! Make sure to visit our hub page
if you're curious what else awaits you with the 12.1.5 launch, and
beyond.

2.3.

#### Class Changes

Demonology Warlock received no changes for Patch 12.1.5, so the most recent changes to
the spec happened early into Season 2. Gear page has been updated with all the new
items from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>), as well as recommendations on how to use [[item:280562]]
once they become available.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 ChangesHide Patch 12.1 Changes
August 25 changes are primarily aimed to increase Demonology single target
output and bring it closer to Destruction. The side-effect is those changes
also augment Demonology AoE as well, cementing it as the best AoE Warlock
spec and among the highest AoE in general. The buff relative to pets does not
change Felguard being the current default pet for the spec.

[Midnight Hotfixes August 25](<https://us.forums.blizzard.com/en/wow/t/world-of-warcraft-midnight-hotfixes-august-25/2336376/68>)

**Warlock**

<em>Developers’ notes: We’re increasing the throughput of Affliction and
    Demonology by primarily focusing on their single-target tools with a
    secondary focus on their multi-target kit. Additionally, we’re
    considerably increasing the damage of Warlock demons so that they have a
    larger contribution to overall throughput. This should also help a bit
    more with aggro concerns during solo play.</em>

- Imp, Voidwalker, Sayaad, and Felhunter damage increased by
        350%.

**Demonology**

- Shadow Bolt damage increased by 35%. Does not apply to PvP
        combat.
- Demonbolt damage increased by 30%.
- Wild Imp damage increased by 20%.
- Summon Felguard damage increased by 20%.
- Demons summoned by Dominion of Argus damage increased by 20%. Does
        not apply to PvP combat.
- Call Dreadstalkers damage increased by 30%.

August 18th change is lifting the Demonology set bonuses from single digit
gains to around 10%, depending on Hero Tree.

[Class Tuning Incoming – 18 August](<https://us.forums.blizzard.com/en/wow/t/class-tuning-incoming-%E2%80%93-august-18/2336820>)

**Demonology**

- <em>Developers’ notes: We are increasing the throughput of the Venomous
        Abyss 2-set bonus for Demonology so that its performance is closer to
        other specialization tier set bonuses.</em>
- The Venomous Abyss 2-set bonus has been updated – Wild Imps now
        Implode at 350% effectiveness to their main target (was 250%) and 315%
        effectiveness to other targets (was 225%).

Heading towards Patch 12.1 Demonology Warlock received several changes
affecting both Hero and Spec trees, alongside bugfixes to the spec and the
baseline [[spell:108370]] which now offers a more substantial defensive
layer.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist nerfs are an attempt to raise the
value ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester which now becomes the slightly better single-target
option.

[Curse of Ula'tek Patch Notes](<https://us.forums.blizzard.com/en/wow/t/2317811/16>)

**Demonology**

- Shadow Bolt damage increased by 45%.
- Demonbolt damage increased by 55%.
- Summon Gloomhound damage increased by 35%.

**Diabolist**

- Chaos Salvo damage reduced by 20%.
- Felseeker damage reduced by 20%.
- Wicked Cleave damage reduced by 20%.
- Eye Explosion damage reduced by 20%
- Flames of Xoroth now increases Fire damage and damage dealt by your
        demons by 3% (was 4%).

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Summary for Demonology Warlock

2.5.

#### Apex Talents

The most prominent feature of the expansion are the Apex talents which will
be gradually available during leveling. These points exists separate from the
tree and have to be invested sequentially in order to unlock the later
points.

1. [[spell:1276163]]
2. [[spell:1276190]]
3. [[spell:1276222]]

These talents are strong enough to warrant building the rotation around
them, with a shift from a Tyrant setup to a post Tyrant one, aimed at
maximising the amount of additional summons.

2.6.

#### Summary of Changes

Listed below is a breakdown of the changes separated in sections to
facilitate the read.

- **Hero Talents** received minor baseline changes and an addition of a fourth column.  
  
  
   ► **Click to expand**
  
  
  2.6.1. 
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist
  
  
  
  
  - [[spell:429893]] has been toned down to a minor damage
            	buff
  - New Talent: [[spell:1268709]] everytime you spend shards
            	summon up to 3 Oculi which will explode for AoE damage whenever a
            	Demonic Art is consumed
  - New Talent: [[spell:1268713]] while active Diabolic Oculi
            	will cast [[spell:1269892]] at your target every second
  - New Talent: [[spell:407470]] Each Diabolic Oculi exploded will
            	grant 2% intellect for 10 seconds
  
  
    
  
  
  
  2.6.2. 
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester
  
  
  
  
  - New Talent: [[spell:1268884]] each Succulent Soul
        			consumed has a chance to trigger [[spell:1239714]] for additional
        			damage on all targets within 10 yards
  - New Talent: [[spell:1268889]] increase Mastery by a
        			percentage which is doubled when [[spell:449614]] triggers
  - New Talent: [[spell:1268903]] increases duration and damage
        			of [[spell:1268884]]
- Substantial changes happened to core/rotational **Demonology Warlock** spells.  
  
  
   ► **Click to expand**
  
  
  - [[spell:105174]] can now be casted only at 3 shards
  - [[spell:428344]], [[spell:267171]]
        			and [[spell:267211]] have been removed
  - [[spell:196277]] is now a choice node cooldown
        			with [[spell:264130]]
  - [[spell:265187]] has been changed, to
        			**dynamically** scale its damage based on the numbers
        			of Wild Imps and Dreadstalkers active
  - [[spell:265187]] does not extend other demons
        			duration, nor provide a damage increase aura baseline
  - [[spell:1251778]] and its upgrades are not a separate
        			spell anymore but are now attached
        			to [[spell:418540]]
  - [[spell:111898]] has been removed
  - A new Choice node has been added
        			featuring [[spell:1276452]] and [[spell:1276467]]
        			which offer extra utility in the form of Singe Magic or Spell Lock
        			respectively
  - [[spell:1276947]] has been changed from being a chance to
        			now apply cast time and shard cost reductions to
        			every [[spell:418540]] cast
  - [[spell:1276672]] functionality has changed from being a
        			chance to proc with [[spell:453568]] to a cooldown that
        			is dynamically reduced when spending Demonic Cores
- Few noteworthy changes also happened to Warlockutility spells.  
  
  
   ► **Click to expand**
  
  
  - [[spell:1714]] and [[spell:334275]] are now
        			separate talents
  - [[spell:1265813]] has been added, allowing every curse to also
        			affect enemies around 10 yards of the main target
  - Blights were introduced, offering a more powerful version of
        			Curses, with a shorter duration and cooldown associated
  - [[spell:5484]] is now a choice node
        			with [[spell:30283]] and has a new supporting talent
        			in [[spell:1270255]], reducing its cooldown and affe
        			ting up to 10 targets
  - [[spell:755]] has been removed and its healing has been
        			added to [[spell:234153]] with [[spell:1265810]]

3.

### Basics of Demonology Warlock Gameplay

[Demonology Warlock](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-guide>) is a spec designed around continuously
summoning temporary demons to do your bidding with relatively short
cooldowns, some of them requiring a precise setup and a good amount of pet
management. At its core, the gameplay is about generating and spending
the Warlock's iconic resource: Soul Shards.

Demonology is the spec that embodies the rule of Always-Be-Casting the most,
but is also straightforward and intuitive. Keep generating Soul Shards
through [[spell:686]] and [[spell:264178]], then
spend those resources on [[spell:104316]] and [[spell:105174]].
These concepts can be broken down into the following three bullet points.

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **Always be Casting**  
  
    Demonology is the spec with the fastest Shard flow so it is important to constantly 
    generate shards with [[spell:686]] and [[spell:264178]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_warlock_calldreadstalkers.jpg>) **Use your Short Cooldowns**  
  
  [[spell:104316]] and [[spell:196277]] are short cooldown spells that 
    provide additional resources and cleave, and should be used as often as possible.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_warlock_dominionofargus.jpg>) **Maximise Hand of Guldan Casts in the Apex Window**  
  
  ![Dominion of Argus Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_felstalkermount_green.jpg>) Dominion of Argus is the main damage window for Demonology. In order 
    to have the most summons try to enter the phase with some Demonic Cores in order 
    to get more [[spell:105174]]s before the timer runs out.

4.

### How to Gear Up as a Demonology Warlock

While we always recommend simming yourself for ideal results, we do provide a
dedicated Demonology gearing page. We currently cover recommendations for
the ongoing Season gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket list.
- **31 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Added non-Felguard talent swaps.
- **25 Aug. 2026 (this page):** Updated for August 25 Hotfixes.
- **16 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated BiS lists, embellishment and trinkets to account for a new profile and trinket tuning.
- **16 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated consumables to reflect new BiS lists.
- **15 Aug. 2026 (this page):** Added August 18th changes.
- **11 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated Gems and FAQ sections.
- **11 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated Gems.
- **11 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated Talent choices.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **25 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated single target recommendation following Patch 12.0.7.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated Diabolist talents.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated Diabolist talents.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **12 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Added Omnium Folio for Patch 12.0.7.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **13 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated talents options to accomodate for hotfixes.
- **13 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated dungeon talents after further bugfixes.
- **02 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated Diabolist dungeon talents following bugfixes.
- **27 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket rankings.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated Tea section.
- **23 Mar. 2026 (this page):** Updated for the upcoming tuning pass.
- **17 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Clarified Tyrant usage.
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Expanded the Tier Set bonuses section.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Added a lv80 import for leveling to Midnight.
- **02 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Fixed opener for situational talent choices.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated talent tree for Midnight release.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Midnight Release.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Updated for Midnight release.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Midnight release.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated Rotations and added Apex sections for Midnight release.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated talent trees and added Apex section for Midnight release.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Added Apex for Midnight release.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Added an Apex section and updated talents for Midnight Release.
- **26 Feb. 2026 (this page):** Updated Performance and Apex sections for Midnight Release.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated talent trees for the changes to each gate unlock.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated talent trees for the changes to each gate unlock.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated talent trees for the changes to each gate unlock.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **22 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated weapon enchants.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated DISC socket recommendation following tuning.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7 and DISC.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Added a section for Combat Assistant.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Added a section for the Combat Assistant.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **04 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket recommendations.
- **19 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Updated talent recommendations.
- **05 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Minor talent recommendation update.
- **04 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated BiS lists and trinket ranking.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7. and Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **29 Nov. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated talents recommendations following a simc update.
- **29 Nov. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated talents following simc implementation update.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** Updated talents recommendations.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Reviewed for Patch 11.0.5.
- **25 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Re-done page layout, updating sections accordingly.
- **25 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated single target recommendation back to Diabolist after latest hotfixes.
- **19 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5 and added a dungeon tooltip section.
- **12 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated weapon enchants and oils.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Added BiS lists for Season 1, updated trinket section.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated gems section, as the strategy changed.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated talent selection for Season 1 launch.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated talents recommendation for Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Updated Viability assessment to reflect Season 1 status.
- **29 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated single target talent recommendation.
- **26 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated all talent trees and added a Delve talents reccomendation.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Added a leveling playstyle section.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Added Pre-Season BiS list section.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Added Hero Talent sections and selectors.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated recommendations to feature Hero Trees.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated sections to account for Hero Talents.
- **21 Aug. 2024 (this page):** Updates strenghts/weaknesses and viability sections.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/demonology-warlock-mists-of-pandaria-remix-guide>)):** Page updated for The War Within pre-patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **19 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/demonology-warlock-the-war-within-pve-guide>)):** Updated for The War Within pre-patch.
- **19 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **19 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/demonology-warlock-the-war-within-pve-guide>)):** Page Created.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/demonology-warlock-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Season 4 launch.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Updated for Dragonflight Season 4.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket section for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated Talents and Stats.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated AoE talents for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **28 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated Single Target setup.
- **13 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated talent tree.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Embellishment recommendations updated after Undulating Sporecloak has been annihilated.
- **07 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated Tyrannical Talents.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated Gear recommendations for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Talents updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated talents for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Reformat of the page with BiS tables and section updates.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Restructured Talent section.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.7
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Talents updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated talents for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for talent changes in Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated talents for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Added Patch 10.1.5 and updated the viability sections.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated Phial recommendation after Corrupted Rage buff.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Talents updated for Patch 10.1.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed talents for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Renamed From the Shadows to The Houndsmaster's Stratagem as per change in Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for patch 10.1.
- **01 May 2023 (this page):** Added a new section for patch 10.1 and updated the viability section.
- **24 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated Onyx Annulet section to account for live hotfixes.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stones recommendations to account for the additional live hotfixes.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stones recommendations to account for 25% buff hotfix.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated talent tree for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/demonology-warlock-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Added patch 10.0.7 new ring section. .
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Added Primordial Stones section for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Talents updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated talents for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated talent trees to reflect class and spec changes for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated talents for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Added Patch 10.0.7 and updated the viability sections.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Updated for Patch 10.0.5.
- **07 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated dungeon phial to a more reliable Phial of Tepid Versatility.
- **03 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Removed Soulburn macro.
- **23 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated talent tree.
- **15 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Clarified the priority list reasoning.
- **14 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated Weapon Runes.
- **14 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Split the stats priority between single and multitarget.
- **13 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated Embellishment recommendations.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Season 1 launch.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated recommended build.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated selectors for the openers and priority lists.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/demonology-warlock-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/demonology-warlock-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/demonology-warlock-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **22 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-2-changes-analysis>)):** Updated to reflect Patch 9.2 launch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-1-changes-analysis>)):** Updated for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-1-changes-analysis>)):** Removed PTR disclaimer.
- **27 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-1-changes-analysis>)):** baseline changes, legendary and covenant recommendations updated.
- **05 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-1-changes-analysis>)):** Page created.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **14 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-the-eternal-palace-raid-guide>)):** Updated Boss Tips and Talent/Essences selection.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated after recent raid nerfs.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **11 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated with better talent choices, and more tips.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Page added.
- **03 Jan. 2019 ([Uldir page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** Updated Nether Portal value after simc hotfix.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** Updated for Patch 8.1. Reviewed talent advice for all bosses.
- **06 Nov. 2018 ([Uldir page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** Updated tips for Uldir bosses.
- **07 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** Updated for Uldir.
- **12 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** Page added.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Demonology Warlock leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Warlock leveling guide](<https://www.icy-veins.com/wow/warlock-leveling-guide>).

1.

### Demonology Warlock Leveling Guide for Midnight

Demonology Warlock relies on Felguard to do the heavy lifting
during leveling, being equally durable and powerful on its own. While it does
not have many ways of tagging mobs, primarily using pets or Demonic
Core [[spell:264178]]s, its strength lies in very high aoe burst potential
and a low threat generating player spells in comparison to other
specializations.

Curses, crowd controls, and pet off-tanking can substantially reduce the amount
of incoming damage, promoting aggressive play, while all the personal
defensive cooldowns offer a degree of safety even when overpulling.

For bigger enemies, such as Elites or Rares, Demonology's damage profile is
centered around several separate demons and guardians that allow us to use
all cooldowns with the safety of a Felguard able to maintain aggro, although
some [[spell:234153]] with [[spell:1265810]] may be required for
the harder hitting enemies.

1.1.

#### Leveling Gear Options

When leveling up, you should always choose the piece of loot with the
highest item level. If the item levels are equal, you should choose the piece
with stats that are most favorable to your specialization. If your current item
is an Heirloom, it should not be replaced.

While the most important aspect of Heirloom is the bonus Experience, to get
most out of their stats allocation, you want to prioritize Intellect, then
Haste, then Critical Strike. The reason behind this is that Haste generally offers a
smoother combat experience while increasing your DPS in a homogeneous way,
unlike Critical Strike, which is still important but less consistent by
nature.

Being able to cast faster offers the advantage of tagging mobs quicker and
overall has a nicer feeling when most of the actions complete quicker.

1.2.

#### Useful Leveling Consumables for Midnight

Listed below are several consumables that can be leveraged to quicken the
leveling process and are generically beneficial regardless of tuning.

The War Within enchants will still work throughout the leveling process,
and can help augmenting character speed. Prioritize the following:

- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

Combat potions give a burst of power and if anything its best to use them
before they become irrelevant at max level.

These consumables are mostly aimed at speeding up the traversal and navigation.

- [[item:109076]]
- [[item:132516]] or [[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]] or [[item:133576]]

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Demonology Level 80 Midnight Leveling
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAYMjZGNLmx2MzYWGAAAAAAAwYGDLwAbDL0wixMzsMbzYGGAwYGjBAjZGGAAAzMGzMzgZmBA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAYMzMzoZxM2mZGzyAAAAAAAAGzYYBGYbYhGWMmZmlZbmZGGAwMGjZmBYMzwsAAAmZGjZmZwMGwA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITVVUUHDPfiklbLM8OJSD0kw01ZkdF1ZURB-DGRCYUFeYYCC804IWS62QQKFHtOmpIB-AAAA-AUMKEcQYARRDzC-
```

:::

2.1.

#### War Mode Talents for Leveling

1. [[spell:212459]] can be useful mostly when engaging with other players
    in PvP, as it offers a moment of respite from melee that is focusing
    you.
2. [[spell:212619]] offers an interrupt every 24 seconds, provided your
    active pet is not the Felhunter.
3. [[spell:201996]] summons a demon that will zap any enemy casting
    harmful spells within 20 yards for 5% of their maximum health.
4. [[spell:1240189]] is passable at best, considering we
    take [[spell:1276947]].
5. **等级 49 起：**[[spell:248855]] should always be considered
    to expedite your whereabouts in a closed space where mounts are not
    usable.
6. **等级 55 起：**[[spell:353753]] can offer further AoE burst when
    kiting targets around.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1 起：**

**等级 1–2：**Starting at Level 1, you only
have one main attack ability: [[spell:686]].

1. **等级 2–3：**Cast [[spell:172]] to tag and soften up
    multiple enemies whenever spamming a few shadowbolts will not kill them
    quicker.
2. **等级 45 起：**Cast [[spell:265187]]
     once you have 5 shards available and [[spell:104316]] active.
3. **等级 13 起：**Cast [[spell:104316]]
    on cooldown, regardless of the number of targets.
4. **等级 11 起：**[[spell:105174]] is the first
    shard spender, and the only one without cooldown. Cast it whenever you have
    no other spenders and you have 5 shards.
5. **等级 15 起：**[[spell:264178]] is unlocked,
    use it whenever a Demonic Core proc happens.
6. **等级 23 起：**[[spell:196277]] should be used
    whenever at least 6 imps are active.

TipsHealing Your Demon

Do not forget to keep your Demon healthy in combat
using [[spell:234153]] with [[spell:1265810]].

TipsDo Not Underestimate Curses!

With the introduction of [[spell:1265813]], Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

4. 

## Pet Choice while Leveling

[[spell:688]] is your first available demon. This
pet is not particularly useful for leveling, but you have no choice for the
early levels.

If you are leveling alone, [[spell:697]]
can be a helpful choice while leveling up, as it takes a lot of the pressure
off you. Avoiding casting pushback can also increase leveling speed.

[[spell:30146]] is the default choice for the
vast majority of content, leveling included, as demonology, due to a
combination of hard Crowd Control, Damage, Cleave, and tanking potential.

[[spell:691]] can be a good choice if
you are leveling in a group or venturing into dungeons. The extra interrupt
is helpful for dealing with troublesome caster mobs.

5. 

## Changelog

- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **17 Mar. 2026:** Clarified Tyrant usage.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **02 Mar. 2026:** Added a lv80 import for leveling to Midnight.
- **26 Feb. 2026:** Updated talent tree for Midnight release.
- **10 Feb. 2026:** Updated talent trees for the changes to each gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Added a leveling playstyle section.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **13 Nov. 2023:** Updated talent tree.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated talent tree for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less


## 快速入门

On this page, we explain how to easily play Demonology Warlock in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Demonology Warlock

This section is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

Demonology focuses on maintaining a small army of demons at all times,
which will deal most of your damage. This specialization can be
very effective, particularly on single targets and burst AoE.

In this section, we will be focusing on a setup that minimizes the
amount of buttons, Add-ons, and reactivity necessary without
compromising overall damage output. Listed below are three 
simple rules to help you understand the spec.

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **Always be Casting**  
  
    Demonology is the spec with the fastest Shard flow so it is important to constantly 
    generate shards with [[spell:686]] and [[spell:264178]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_warlock_calldreadstalkers.jpg>) **Use your Short Cooldowns**  
  
  [[spell:104316]] and [[spell:196277]] are short cooldown spells that 
    provide additional resources and cleave, and should be used as often as possible.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_warlock_dominionofargus.jpg>) **Maximise Hand of Guldan Casts in the Apex Window**  
  
  ![Dominion of Argus Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_felstalkermount_green.jpg>) Dominion of Argus is the main damage window for Demonology. In order 
    to have the most summons try to enter the phase with some Demonic Cores in order 
    to get more [[spell:105174]]s before the timer runs out.

2.

### Beginner's Guide to Demonology Warlock in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester   Beginner Talents

2.1.

#### Beginner Talents for Demonology Warlock

This build is optimized for ease of use while offering a setup that
works in any situation with no adjustments required, including Raid, Mythic+,
and even Delves. This is not the optimal choice in either single target or multi-target in
terms of output, but serves as a build that can help players become familiar with the
specialization at its core before moving on to more specialized builds from our Talents page.

To import this all-rounder build directly in-game, click on the export button at the
bottom of the calculator:

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAgZmZGNLmxmZGzyAAAAAAAMW2GYADYGWCM2MmZsMbzYGzAAzMzYMAzMjZGzsBAAGzMjZMDmxAGA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnELM028MTjehprrowwJbM-DGRUCFewyCCSYYcgk268KXmmEHRQsOC-AAAA-HIOQ0AEQYhhCzC-
```

:::

### Demonology Warlock   Basic Rotation

2.2.

#### Single Target Rotation

1. Cast [[spell:104316]] whenever available.
2. Cast [[spell:105174]] if you have 4-5 Soul Shards.
3. Cast [[spell:196277]] when you have 6 Wild Imps.
4. Cast [[spell:264178]] if you have 2+ stacks of [[spell:267102]].
5. Cast [[spell:105174]] with 3 Soul Shards.
6. Cast [[spell:686]] to generate Soul Shards.

[[spell:265187]] should be cast on cooldown, making sure to
extend [[spell:104316]].

:::details FAQWhat Pets/Demons Should I Use?
Always Felguard, in any circumstances, as Demonology Warlock.

:::

2.3.

#### Multi-Target Rotation for Demonology Warlock

The rotation is identical to a single target, as the vast majority of your damage
also cleaves around the main target.

:::details TipsHealing Your Demon
Do not forget to keep your Demon healthy in combat
using

[[spell:234153]]

with

[[spell:1265810]]

.

:::

:::details TipsDo Not Underestimate Curses!
With the introduction of

[[spell:1265813]]

Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:440057]] is unique to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and combines
  	the above two curses
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

:::

2.3.1.

##### Apex Talent: ![Dominion of Argus Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_felstalkermount_green.jpg>) Dominion of Argus

[[spell:1276163]]'s idea is to maximize the amount
of [[spell:105174]] casts after [[spell:265187]]. In order
to achieve that goal it is best to cast [[spell:265187]] when
already at 5 shards and ideally with up to 4 [[spell:267102]]s to speed
up the whole sequence. Worth noting that delaying Tyrants in order to have
more Demonic Cores is likely a DPS loss if additional Tyrants will be missed
over the course of a fight or a dungeon run.

2.3.2.

##### Season 2 Tier Set

Season 2 set bonuses are entirely passive and do not alter the gameplay.

### Demonology Warlock   Stat Priority

2.4.

#### Stat Priority for Demonology Warlock

Currently, you will want to prioritize secondary stats as follows.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>).

Item Level

Haste to 22%

Critical Strike

Mastery

Haste

Versatility

### Blizzard   Combat Assistant

2.5.

#### Combat Assistant For Demonology Warlock

Introduced in Patch 11.1.7, the [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) is, at the 
time of writing, comprised of two main features:

- **Assisted Highlight:** Displays the next spell to be queued, in a
  adequately accurate rotation single target and limited capabilities in
  multitarget, best used to familiarize with the flow and cadence of the
  spec
- **Single Button Assistant:** Enables use of a single input for multiple
  skills in the sequence prompted by the Assisted Highlight, at the
  expense of a longer base global cooldown (which accounts for an
  additional 5% to 10% dps loss)

**It is worth pointing out that these tools are Accessibility features
first and foremost, and should not be considered a direct replacement to learn a
spec nor the logic behind it.**

The areas where the Combat Assistant struggle the most
for Demonology Warlock are:

- Multi-target in general, due how it considers all targets stacked
  regardless of the situation
- Cooldown usage, since it is either missing, or there is no preparation
  entering a given cooldown, Tyrant is entirely missing
  and setting it up correctly is a major part of Demonology overall dps
- [[spell:196277]] is not supported

2.6.

#### Combat Assistant Tips

- Cooldown alignment has to be done manually, especially considering
  racials, potions, and on-use equipment
- [[spell:460551]] spread has to be done manually, as well in multi-target
  situations
- In general, try to maximize the amount of time spent casting,
  especially when using the Single Button Assistant, as downtime is one
  of the improvement areas at any stage of the game

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Added an Apex section and updated talents for Midnight Release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added a section for the Combat Assistant.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated sections to account for Hero Talents.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated talents for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated talents for Patch 10.1.5.
- **01 May 2023:** Reviewed for patch 10.1.
- **20 Mar. 2023:** Updated talents for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **23 Dec. 2022:** Updated talent tree.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Demonology Warlock in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Demonology Warlock

For Season 2, Demonology talent selections remain mostly unchanged,
with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester becoming the slightly better choice in pure
single-target. Whilst there are still some opportunities for personal preferences and
situational adjustments, below are our current recommendations:

- **Single-Target**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester is tuned around
      3% higher than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist in pure single-target, but suffers
      from a substantial lack of cleave in comparison.
- **AoE**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist is the better choice at any key
      level. The Mythic+ builds offers comparable single-target
      to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester, whilst retaining superior AoE.

**Quick Start Import Codes:**

:::talents Demonology Single-Target - Soul Harvester
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmxsMAAAAAAAjtlBGwAmhtQGbmhZ2mlZmZMDAYMzMzAMzMmxMDAAwMzMzMjZYZAYA"
}
```
:::

:::talents Demonology AoE - Diabolist
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAAAAAAGzYYBGYb0CNsYMzYZ2mZmxMAwMjZGzMDwYmxMbAAgxMzMzww2MGwA"
}
```
:::

:::talents Demonology Delves - Soul Harvester
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzyAAAAAAAMWWGYADYG2CM2MmZsMmxMzMAwMzMGDwMzYmxMbAAgxMzMzYw2MDwA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Diabolist

Single-Target

Mythic+

recommended

Soul Harvester

Single-Target

recommended

Mythic+

Delves

### 天赋方案 0-0

1.1.

#### Single-Target Talents

Demonology single-target revolves around
maximising [[spell:1276163]] windows in order to spawn as many demons
as possible. Currently, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist offers much more free cleave at the expense of
3% worse performance in single-target, compared to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester.

### 天赋方案 0-1

1.2.

#### AoE/Mythic+ Diabolist Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist offers better multi-target scaling with the
ability to front-load high burst from Overlord and Pit Lord.

[[spell:196277]] is being used both to generate Demonic Cores and to
allow for Wild Imps to cleave at small target counts thanks
to [[spell:1281511]].

### 天赋方案 1-0

1.3.

#### Single-Target Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester trades around 3% better single target damage and a
ranged [[spell:265187]] for substantially worse cleave
performance.

### 天赋方案 1-1

1.4.

#### AoE/Mythic+ Soul Harvester Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester offers slightly faster ramp up at the expense of
higher variance and worse overall damage, making it a very situational choice whenever you
need to get the damage out as soon as possible.

The playstyle is very similar to the other Hero Tree, with the notable
exception of allowing much quicker [[spell:1276163]] setups
because of [[spell:449638]].

### 天赋方案 1-2

1.5.

#### Delve Talents

The choice of Hero Tree is more of a stylistical preference. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester
offers better defensives overall, but ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist has stronger burst and can
trivialise some otherwise difficult situations.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjZ2mZGzyAAAAAAAAGzYYBGYbYhGWMGjlZZmZGzAAzMmZmZmBwMjZAAAMmZmxwwyMGwA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPQSghklnoBLM18MjehhrrToowID-DGRUVYFeyCCSYYcgku28KVWCJOigYdA-AAAA-AOQo0QowITgwwC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAAAAAAGzYYBGYbYhGWMmZsMbzMzYGAYmxMzMzMAjZGzsBAAGzMzMDYbGDYA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjehprTwwJbM-DGRUVYCFYYceyCCSgk2KVWCLOigYd8C-AAAA-AOQo0QowITgwwC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmxsMAAAAAAAjtlBGwAmhtAjNzwMbzyMzMmBAMmZmZAmZGzYmBAAYmZmZmxMsMAMA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPSghiklnoELM128MTvw01JUUYkB-DGRUVYFfy0IWYYcu68S2AQQUmmsCJeA-AAAA-HIOQ2AEUQhhCzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzyAAAAAAAMWWGYADYG2CM2MmZsMbzMzYGAYmxMzMAzMjZGzsBAAGzMzMDYbGDYA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjchprTwwJbM-DGRUVYCFYYceyCCSgku2KVWCLOigYdE-AAAA-HIOQ2AEQQhhCzC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzyAAAAAAAMWWGYADYG2CM2MmZsMmxMzMAwMzMGDwMzYmxMbAAgxMzMzYw2MDwA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjchprTwwJbM-DGRUCFewyCCSYYcgk26WmmEHJRQasCD-AAAA-HIOQ2AEQQhhCzC-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

Introduced in [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), Omnium Folio is a new source of player
power that unlocks over the course of few weeks and offers a choice of small
but flexible bonuses that can be swapped at any time to match the desired
content. The selection of Runes can be tailored to offer throughput, or pivot
to survivability and utility.

The following list is the recommended guideline, point by point:

1. [[spell:1279599]]
2. [[spell:1279603]] or [[spell:1279604]]
3. [[spell:1287555]]
4. [[spell:1279609]]
5. [[spell:1279615]] and [[spell:1279614]] offer similar output

:::details FAQWhich Secondary Stat Rune is Best?
The default choice for Warlocks is

[[spell:1279609]]

. If you
have somehow managed to hit >35% Critical Strike chance and neglected Mastery
in the process, consider using

[[spell:1279612]]

.

:::

3.

### Apex Talent: ![Dominion of Argus Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_felstalkermount_green.jpg>) Dominion of Argus

Available during the leveling in Midnight, these talents are separated from
the rest of the spec tree and require subsequent points investment in order
to unlock the later ranks.

1. [[spell:1276163]]
2. [[spell:1276190]]
3. [[spell:1276222]]

These talents are strong enough to warrant building the rotation around
them, with a shift from a Tyrant setup to a post Tyrant one, aimed at
maximising the amount of [[spell:105174]] casts and thus additional
summons.

4.

### Hero Talents

Available at level 71 Hero talents are mutually exclusive trees you can
choose to slightly alter gameplay and visuals. Demonology Warlocks can choose
between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist is themed around Demons and the cycle of Overlord,
Mother of Chaos and Pit Lord summoned with [[spell:470479]]. The
gameplay as a result is of predictable cadence with a higher degree of burst
potential, tied with the Hero Tree summons and spell empowerments.

In terms of utility [[spell:428911]] gives snare and root
immunity on [[spell:48020]] on top of 50% movement speed but
on the other hand [[spell:429072]] coupled
with [[spell:1270255]] enables 25s cooldown [[spell:5484]]
that can affect up to 10 targets.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester identity lies in spending shards very
aggressively, in order to benefit from the various DoT effects triggered, and
generating more Demonic Core procs
through [[spell:449637]].

As for utility [[spell:449701]] guarantees stronger Healthstones
without the need of Soulburn shards, [[spell:449703]] increase
the active mitigation, and [[spell:389623]]
brings [[spell:20707]] on par with alternative combat resurrection
spells.

5.

### PvP Talents (War Mode)

Under our Talents section, there is the option to enter "War Mode."
Enabling War Mode provides the following benefits:

- PvP talents enabled in the outdoor world
- 10% increase in World Quest rewards at maximum level
- 10% more experience gained while leveling
- Earn Conquest Points, which can reward gear every week

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended you enable the feature. In most situations, this will allow for
the maximum returns despite the risks. You will make yourself available for
open-world PvP and the possibility to be "ganked" while leveling or doing
World Quests exists.

5.1.

#### Best War Mode Talents

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of both General PvP Talents
and Demonology Warlock-specific PvE talents.

1. [[spell:353753]] allows to burst targets by dragging them away from the marked location.
2. [[spell:248855]] increases your gateway's range by 20 yards and reduces the
     duration of the debuff placed on players using it by 15 seconds, making it a good choice when
     increased mobility is needed.
3. [[spell:212295]] summons a shield lasting 3 seconds and reflecting back
     all harmful spells targeted at you.
4. [[spell:201996]] is only relevant when dealing with a lot of casting mobs.

1. [[spell:212459]] guards a location for 15 seconds; any enemies that
     come within range take up to 5% of maximum Health as damage. This can be used
     very strategically in certain situations and is capable of dealing some nice
     burst damage.
2. [[spell:201996]] guards a location for 20 seconds; any enemies that
     cast spells in the radius will take up to 5% of maximum Health as damage. This
     has a lot more limited use but can have absurd value in specific situations.
3. [[spell:1240189]] makes [[spell:104316]] an instant
     cast. Since we are often using [[spell:1276947]], the quality of life
     of this talent is diminished. It can be used if you prefer the consistency, but
     there are generally better choices.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Updated Talent choices.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **25 Jun. 2026:** Updated single target recommendation following Patch 12.0.7.
- **15 Jun. 2026:** Updated Diabolist talents.
- **12 Jun. 2026:** Added Omnium Folio for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **13 Apr. 2026:** Updated dungeon talents after further bugfixes.
- **02 Apr. 2026:** Updated Diabolist dungeon talents following bugfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated talent trees and added Apex section for Midnight release.
- **10 Feb. 2026:** Updated talent trees for the changes to each gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **05 Mar. 2025:** Minor talent recommendation update.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **29 Nov. 2024:** Updated talents following simc implementation update.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **25 Sep. 2024:** Updated single target recommendation back to Diabolist after latest hotfixes.
- **09 Sep. 2024:** Updated talents recommendation for Season 1.
- **29 Aug. 2024:** Updated single target talent recommendation.
- **26 Aug. 2024:** Updated all talent trees and added a Delve talents reccomendation.
- **21 Aug. 2024:** Updated recommendations to feature Hero Trees.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated AoE talents for Patch 10.2.5.
- **28 Nov. 2023:** Updated Single Target setup.
- **06 Nov. 2023:** Talents updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7
- **10 Jul. 2023:** Updated talents for Patch 10.1.5.
- **01 May 2023:** Reviewed talents for Patch 10.1.
- **20 Mar. 2023:** Updated talents for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Demonology Warlock in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Demonology Warlock Gameplay and Rotation Guide

Welcome to our Rotation page for Demonology Warlocks. On this page, you will
find everything you need to know about actually playing the spec in Raiding
and Mythic+ scenarios.

By selecting talents and Hero Talents below, the rotations in this guide will
update accordingly.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist

Single Target

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

Active Talents

Passive Talents

[[spell:196277]]

[[spell:264130]]

[[spell:265187]]

[[spell:1276672]]

[[spell:1276452]]

[[spell:1276467]]

[[spell:1281511]]

[[spell:267216]]

### Single Target

1.1.

#### Single Target Priority

Demonology Warlock revolves around a system of generating demonic forces.
The more active demons you have, the more damage you will deal.
In addition to straight damage, you will also receive more procs of
[[spell:267102]], which feeds back into more Soul Shard generation
and, by extension, more demons.

1. **适用条件：Grimoire: Imp Lord（启用）。** Cast [[spell:1276452]].
2. **适用条件：Grimoire: Fel Ravager（启用）。** Cast [[spell:1276467]].
3. **适用条件：Summon Demonic Tyrant（启用）。** Cast [[spell:265187]].
4. **适用条件：Summon Doomguard（启用）。** Cast [[spell:1276672]].
5. **适用条件：Power Siphon（启用）。** Cast [[spell:264130]] with 2 or less [[spell:267102]] and at least 2 Wild Imps out.
6. **适用条件：To Hell and Back（启用）；Implosion（启用）。** Cast [[spell:196277]] with 6 Wild Imps out.
7. Cast [[spell:104316]] whenever available.
8. Cast [[spell:105174]] if you have 4-5 Soul Shards.
9. Cast [[spell:264178]] if you have 2+ stacks of [[spell:267102]].
10. **适用条件：Diabolist（启用）。** Cast [[spell:433891]] when at 2 or less Soul Shards.
11. Cast [[spell:686]] to generate Soul Shards.

### AoE

This is a new build. Click to edit and add your content here.

1.2.

#### Multiple Target Priority

Demonology has little variation in playstyle when multiple targets are
present.

1. **适用条件：Grimoire: Imp Lord（启用）。** Cast [[spell:1276452]].
2. **适用条件：Grimoire: Fel Ravager（启用）。** Cast [[spell:1276467]].
3. **适用条件：Summon Demonic Tyrant（启用）。** Cast [[spell:265187]].
4. **适用条件：Summon Doomguard（启用）。** Cast [[spell:1276672]].
5. **适用条件：Power Siphon（启用）。** Cast [[spell:264130]] with 2 or less [[spell:267102]] and at least 2 Wild Imps out.
6. **适用条件：Implosion（启用）。** Cast [[spell:196277]] with 6 Wild Imps out.
7. Cast [[spell:104316]] whenever available.
8. Cast [[spell:105174]] if you have 4-5 Soul Shards.
9. Cast [[spell:264178]] if you have 2+ stacks of [[spell:267102]].
10. **适用条件：Diabolist（启用）。** Cast [[spell:433891]] when at 2 or less Soul Shards.
11. Cast [[spell:686]] to generate Soul Shards.

### Opening Sequence

**适用条件：Power Siphon（未启用）。**

[[spell:264178]]

**适用条件：Power Siphon（启用）；Inner Demons（未启用）。**

[[spell:264178]]

**适用条件：Power Siphon（启用）；Inner Demons（启用）。**

[[spell:264130]]

**适用条件：Power Siphon（启用）；Inner Demons（启用）。**

[[spell:686]]

**适用条件：Power Siphon（启用）；Inner Demons（启用）。**

[[spell:686]]

**适用条件：Summon Doomguard（启用）。**

[[spell:1276672]]

**适用条件：Grimoire: Imp Lord（启用）。**

[[spell:1276452]]

**适用条件：Grimoire: Fel Ravager（启用）。**

[[spell:1276467]]

**适用条件：Summon Doomguard（启用）；Diabolist（启用）。**

[[spell:686]]

**适用条件：Grimoire: Imp Lord（启用）；Diabolist（启用）。**

[[spell:686]]

**适用条件：Grimoire: Fel Ravager（启用）；Diabolist（启用）。**

[[spell:686]]

**适用条件：Soul Harvester（启用）。**

[[spell:686]]

[[spell:246985]]

[[spell:246985]]

[[spell:104316]]

**适用条件：Summon Demonic Tyrant（启用）。**

[[spell:265187]]

[[spell:105174]]

[[item:250144]]

[[item:241308]]

[[spell:105174]]

**适用条件：Implosion（启用）。**

[[spell:196277]]

[[spell:267102]]

**适用条件：Power Siphon（启用）；Inner Demons（未启用）。**

[[spell:264130]]

[[spell:105174]]

1.3.

#### Opening Sequence

1. **适用条件：Power Siphon（未启用）。** Pre-cast [[spell:264178]].
2. **适用条件：Power Siphon（启用）；Inner Demons（未启用）。** Pre-cast [[spell:264178]].
3. **适用条件：Power Siphon（启用）；Inner Demons（启用）。** Pre-cast [[spell:264130]] with 2 Wild Imps out.
4. **适用条件：Power Siphon（启用）；Inner Demons（启用）。** Pre-cast [[spell:686]].
5. **适用条件：Power Siphon（启用）；Inner Demons（启用）。** Cast [[spell:686]].
6. **适用条件：Summon Doomguard（启用）。** Cast [[spell:1276672]].
7. **适用条件：Grimoire: Imp Lord（启用）。** Cast [[spell:1276452]].
8. **适用条件：Grimoire: Fel Ravager（启用）。** Cast [[spell:1276467]].
9. **适用条件：Summon Doomguard（启用）；Diabolist（启用）。** Cast [[spell:686]].
10. **适用条件：Grimoire: Imp Lord（启用）；Diabolist（启用）。** Cast [[spell:686]].
11. **适用条件：Grimoire: Fel Ravager（启用）；Diabolist（启用）。** Cast [[spell:686]].
12. **适用条件：Soul Harvester（启用）。** Cast [[spell:686]] if below 2 Soul Shards.
13. Cast [[spell:104316]].
14. **适用条件：Summon Demonic Tyrant（启用）。** Cast [[spell:265187]].
15. Focus on casting as many [[spell:105174]] possible.
16. **适用条件：Implosion（启用）。** Cast [[spell:196277]] with 6 Wild Imps out and 1 or less [[spell:267102]].
17. **适用条件：Power Siphon（启用）；Inner Demons（未启用）。** Cast [[spell:264130]] after the second [[spell:105174]]

:::details TipsDo Not Underestimate Curses!
With the introduction of

[[spell:1265813]]

Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

:::

2.

### Midnight Season 2 Tier Set

Season 2 tier set bonuses are the following:

- [[spell:1296573]] Wild Imps damage increased by
      10%. [[spell:196277]] damage increased by 20%.
- [[spell:1296574]] passively gives a chance for
      Wild Imps to implode themselves at the end of their lifespan.

Both set bonuses are not particularly strong and designed to offer a
passive damage increase that do not alter the priorities or the decision
making in the gameplay.

3.

### Class and Spec Mechanics Explained

The following sections present an explanation of various mechanics
        pertinent to the Demonology and the Warlock, alongside reasons as
        to why abilities are used in a specific way.

### Doom

3.1.

#### Doom

The latest iteration of [[spell:460551]] provides a more nuanced gameplay with
optimization opportunities, especially in multitarget. To maximize
its contribution, it is important to understand the damage trigger
conditions: [[spell:460551]] will deal damage if the target dies or the debuff
duration ends.

As a result, it is important to cast [[spell:264178]] at
different targets when possible, especially those at lower health.

In situations where there is only one target, it is worth remembering that
each subsequent [[spell:105174]] cast will reduce [[spell:460551]]
duration by 3 seconds. As such it is advised to hold when possible 1 Demonic
Core charge to apply doom once expired.

### Implosion

3.2.

#### Implosion

To better understand [[spell:196277]] usage, it is important to outline
how the spell works.

[[spell:196277]] damage has two different components:

1. The damage on the main target, which is directly proportional to the
   remaining energy of the Wild Imps being imploded at a given moment
2. The damage on the secondary target, which will always be the full
   value, regardless of Wild Imps' energy at the moment of the
   Implosion

When factoring the cost of 1 global cooldown, the [[spell:196277]] cast
itself has the opportunity cost of 0.75 shards per activation (where you could
cast [[spell:686]] instead).

Another element to consider is the interaction specific
with [[spell:1281511]]:

- Without it [[spell:196277]] is never worth casting single target
- With the talent it is worth using [[spell:196277]] in single target
      because of the additional Wild Imps generated, and the
      extra [[spell:267102]]s from imploding itself

### Apex Talent

3.3.

#### Dominion of Argus

Demonology Apex [[spell:1276163]] is a throwback to the original
Nether Portal, packaged in a much more accessible and straight-forward
fashion, albeit less nuanced. The goal is to get as many summons going during
Portal duration and to do so players will need to cast twice the amount
of [[spell:105174]] per summoned demon.

As result it is imperative to enter the Tyrant window with as many
resources (both Soul Shards and [[spell:267102]]s) possible to speed up
the process of generating Shards and casting [[spell:105174]].

The introduction of the Apex Talents, alongside the change for Tyrant,
dynamically updates its damage based on the active summons has
shifted a rotation centered around a pre-Tyrant setup to a post-Tyrant
cast sequence instead.

4.

### Important Cooldowns for Demonology Warlock

### Tyrant

4.1.

#### Demonic Tyrant

[[spell:265187]] is our main cooldown. The Demonic Tyrant lasts
20 seconds and deals damage based on the number of Wild Imps and
Dreadstalkers active. Unlike previous iterations there is no snapshot as the
damage is being calculated dynamically with each cast.

While [[spell:265187]] setup window is not as rigid as it was
in the past, the emphasis has shifted to the Tyrant window itself where
getting as many [[spell:105174]] casts will be the determining factor in
order to optimise DPS.

5.

### Demonology Warlock Important Notes

### Soul Shards

5.1.

#### Soul Shards

All Warlocks use Soul Shards as their primary resource. Properly managing
your Shards is crucially important to success, as they control the size of
your demon horde. Incorrectly dumping Soul Shards at the wrong time can have
domino effects that reduce your damage output, particularly
around the time [[spell:265187]] is coming off of cooldown.

With the introduction of [[spell:1276947]] to reduce the shard cost
of [[spell:104316]], and a fixed cost of [[spell:105174]],
shard management and comboing has been streamlined, however.

### Demonic Cores

5.2.

#### Managing Demonic Core

[[spell:267102]] is our main proc and almost a secondary resource
of the specialization. If you played Demonology in Warlords of Draenor or
earlier, you will notice Demonic Core and Demonbolt are almost exactly the same
as Molten Core and Soul Fire. Demonic Core enables the use of
[[spell:264178]], which, in other words, enables us to generate a lot of
Soul Shards quickly. Demonic Core has a maximum of 4 stacks, which makes proper
management of this ability a necessity for skillful play.

Each time you are approaching a [[spell:265187]] usage,
you will want to have at least 2 stacks of [[spell:267102]]. This will
allow you to quickly generate Soul Shards to pump out as many summons as
possible inside Demonic Tyrant window.

If you are in a situation where you are making frequent use of
[[spell:196277]], you can be a lot more liberal with your use of
[[spell:267102]] stacks. Your damage will benefit a lot more from
the increased Wild Imps you can fling at the adds rather than having a
maximum power Tyrant. You will still want to ensure your Tyrant is powering
up a few waves of un-detonated Imps, but you should not feel like you have to
save stacks of Demonic Core that you could be using for cleave.

In general, you do not want to pool more than 2 charges
of [[spell:267102]], else you risk losing potential stacks; however,
whenever you need a burst or a quick switch, do not hesitate to plan ahead
and hold more charges.

### Demon Choice

5.3.

#### Demon Choice

Always use a Felguard, your Demonology-specific demon. Your
[[spell:119898]] ability is now [[spell:89766]], which act as both an
interrupt and a stun. It is recommended that you leave the
[[spell:89751]], [[spell:30213]] and [[spell:428344]] abilities on
auto-cast.

Remember to turn off your Felguard's [[spell:134477]]
when in party or raid environments.

### Movement

5.4.

#### Movement Management

While it is difficult to describe the best ways to position and move during
a dungeon or raid encounter, it is essential to your success as a Demonology
Warlock. [[spell:111771]] can be highly effective in many encounters
and is under-appreciated by many players and raid groups.

Think of [[spell:111771]] as a raid cooldown that can instantly
teleport your entire raid group 40 yards, and the potential this ability
holds quickly becomes clear. Ask your group if they want
[[spell:111771]] anywhere specific; if not used for your strategy, use
it instead as a personal cooldown.

[[spell:264178]] can be used strategically to cover movement, as it
is the only instant cast we have access to. You can mitigate the need to
move by positioning in locations central to fight movement.

For instance, if a boss is being kited in a circle, you should stay on
the inside of the kite path to ensure minimal movement. You should also
determine how your [[spell:268358]] can make a fight easier for you.
There are many boss mechanics that can be trivialized with a clever portal,
which can free you up to deal a lot more damage.

[[spell:385899]] used in conjunction with [[spell:111771]]
offers a quick way to cover large distances and can be used in a rush when
the need to reposition is immediate.

5.4.1.

##### Quiet Movement

Many players will unconsciously move during fights, despite it being
unnecessary. For example, sometimes the boss or adds will be moved by the tank
a couple of yards, and though you are still in range to cast, you subconsciously
mirror that movement, costing you global cooldowns. Consciously work to "quiet"
your movement, and reduce unnecessary movement to a minimum. The best way to
see this in action is to take a video of your raid and then watch yourself play.
Most players will be surprised by the amount of wasted movement they commit.
When you are forced to move, make your path as direct and decisive as
possible.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **17 Mar. 2026:** Expanded the Tier Set bonuses section.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **02 Mar. 2026:** Fixed opener for situational talent choices.
- **26 Feb. 2026:** Updated Rotations and added Apex sections for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added a section for Combat Assistant.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **25 Sep. 2024:** Re-done page layout, updating sections accordingly.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Added Hero Talent sections and selectors.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated selectors for the openers and priority lists.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Demonology Warlock in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Demonology Warlock

Welcome to our Gearing Page for Demonology Warlock; this
section will cover everything you need to know about equipping your character
correctly.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Demonology Warlock. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces to Aim for?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

was changed to retain the base stats, and item level of the original item, which allows to acquire tier set bonuses while following a specific stat distribution. Listed below are the ideal items to catalyse, but be aware

**Chest and Legs**

are direct drops.

- Head: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:239031@JAACAAAG2A]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:271549@JAACAAgNyA]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Hands: [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: [[item:271545@JAACAAgNyA]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

Prioritise acquiring the tier set bonuses over ideal stat distribution since it is a higher DPS increase.

:::

:::details FAQWhat Items From the Great Vault Should I Pick?
Rare drops from raid and items that present the highest upgrade in

[Top Gear](<https://www.raidbots.com/simbot/topgear>)

sims should be prioritised. Listed below are few of the items to chase:

- [[item:271092]]: Best caster weapon due to item level alone
- [[item:271874@JAACAAAG2A]] and [[item:268265@JAACAAAG2A]], high item level items with strong cantrip effects
- [[item:270164@JAACAAgNyA]] is the best trinket this tier

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273649@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup from Dungeons for Demonology Warlock. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces to Aim for?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

was changed to retain the base stats, and item level of the original item, which allows to acquire tier set bonuses while following a specific stat distribution. Listed below are the ideal items to catalyse, but be aware

**Chest and Legs**

are direct drops.

- Head: [[item:251199@JAACAAgNyA]] from [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- Shoulders: [[item:239031@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:273785@JAACAAgNyA]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Hands: [[item:159247@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Legs: [[item:251160@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

Prioritise acquiring the tier set bonuses over ideal stat distribution since it is a higher DPS increase.

:::

:::details TipsWhich Dungeons Should Be Prioritised?
If your playtime is limited consider the following dungeons to farm:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): weapon and trinket
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): neck, belt, and second trinket
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): ring, cloak, and boots

:::

:::details FAQIs There a Difference Between 2H Staves and 1H + Off Hand?
As long as the item level is the same, there is no difference between both, in terms of total amount of stats.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:251199@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:251137@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273649@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup from Raids for Demonology Warlock. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces to Aim for?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

was changed to retain the base stats, and item level of the original item, which allows to acquire tier set bonuses while following a specific stat distribution. Listed below are the ideal items to catalyse, but be aware

**Chest and Legs**

are direct drops.

- Head: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:268241]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- Chest: [[item:271549@JAACAAgNyA]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Hands: [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: [[item:271545@JAACAAgNyA]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

Prioritise acquiring the tier set bonuses over ideal stat distribution since it is a higher DPS increase.

:::

:::details TipsWhat Are the Most Important Drops from the Raid?
Listed below are the most significant drops worth prioritising.

- [[item:271092@JAACAAAG2A]]: Highest item level weapon. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:271874@JAACAAAG2A]]: Highest item level with good stats on a slot with a high stat budget. This drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:281215@JAACAAgNyA]]: Best trinket in general. Drops from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270170@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Demonology Warlock

The following list provides a general ranking for all trinkets available
for players to better understand what may be more appealing. These rankings
assume each item at its highest possible item level, thus for direct or
immediate upgrade it is still best practice to sim your own character.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Demonology Warlock Trinkets**
**Best-In-Slot -**

[[item:281215@JAACAAgNyA]]

and

[[item:273649@JAACAAgNyA]]

**Runner Up Passive-**

[[item:270164@JAACAAgNyA]]

or

[[item:250224@JAACAAgNyA]]

**Runner Up Active-**

[[item:270170@JAACAAgNyA]]

or

[[item:250215@JAACAAgNyA]]

:::

Any trinket not shown on this list is generally considered worse than all
other trinkets available on this list.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Demonology Warlock Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAACAAgNyA]]</li>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:270169@JAACAAAG2A]]</li>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:158368@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) work as bonus loot and guarantee a drop
	from the loot table of a Boss or a Dungeon. While the drop in itself is
	random, each additional Voidcore spent will guarantee no duplicate until
	the whole list has been dropped.

3.1.

#### Recommended Nebulous Voidcore Usage for Demonology Warlock

Nebulous Voidcores are a valuable yet limited resource and whilst in
general should be used to bridge gaps in a player current gearset, it is
important to remember that how quickly an item can be guaranteed depends on
how many other items have been already dropped from that source.

Not all drops are equally impactful, so listed below is a generic priority
list on what to focus on:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore Targeting Priority**
1. Mythic-track [[item:271092@JAACAAAG2A]]
2. Mythic-track [[item:271874@JAACAAAG2A]]
3. Mythic-track weapons (1H or 2H);
4. Mythic-track trinkets (especially [[item:281215@JAACAAgNyA]]);
5. Tier set pieces missing from 2 or 4-piece bonus;
6. High-impact slots from your BiS list.

:::

3.2.

#### Ascendant Venomstones

[[item:280562]] return as a mean to upgrade your equipment in
Season 2. Listed below is the order of importance of equipment slots to
upgrade:

1. Mainhand Weapon is the most important
2. Offhand weapon
3. On-use trinket
4. Passive trinket
5. Neck item.

[[item:280562]] can also be used to upgrade bonus rolled
Heroic cantrip items from last 2 bosses to 340 item level.

4.

### Best Crafted Items for Demonology Warlock

Crafting gear main limiting factor remains the weekly rollout of Sparks,
necessary for high end items, as such it is important to understand how to
approach the topic.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Demonology Warlock Crafted Gear Priority**
1. The overall best combination is [[item:240167]] in the
     	Wrists slot and [[item:273059]] in the off-hand frill,
     	but that is in the context of fully geared characters, and thus should
     	be considered a long term strategy, better suited for players who do not
     	require the highest power gain immediately, but instead opt for the
     	least amount of recrafts and resource investment.
2. If immediate power is instead the focus, then crafting
     	a [[item:245770@JAAGAAwt1ENMMYD]]
     	with [[item:273060]] using 4 Sparks and Wrists
     	with [[item:240167]] at a lower item level provide the
     	highest dps jump.

:::

The missives used for each craft are the following:

- [[item:245786]] for Weapon and Wrists
- [[item:245783]] for any other slot

:::details FAQWhy Craft A Weapon First If It Is Not Best-In-Slot?
Weapons provide the highest amount of primary stat, and especially the
first tier it is a very precious commodity. However crafted items cap 4 item
levels below fully Mythic upgraded alternatives, thus being somewhat limited
at the top end, assuming a player get access to that kind of gear.

:::

:::details FAQIs It Worth Recrafting for a Different Missive?
If the associated recrafting cost is not an issue, consider simming your
own character at any given point to get the best Missive at the moment. Changing secondary
stats on a single item is unlikely to provide more than a tenth of a percent of DPS increase.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Adding Sockets to Gear

In Season 2 [[item:275707]] is available as a
trading option at six tokens from Great Vault, which can be used to add a
sockets to any Head, Waist, or Wrist item.

5.

### Crest Usage

Mistcrests are a seasonal limited currency with a cap that increases each
week and is used to upgrade items to their respective maximum level in each
reward track.

Due to how each item slot is designed, there is a difference in power, tied
to either specific effects or simply higher stats. As a result the following
sequence highlights the most valuable slots where to invest Mistcrests:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Demonology Warlock Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Neck**

➜

**Off-hand**

➜

**Shoulders/Gloves/Belt/Boots**

➜

**Rings**

➜

**Wrists/Back**

:::

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **31 Aug. 2026:** Updated trinket list.
- **16 Aug. 2026:** Updated BiS lists, embellishment and trinkets to account for a new profile and trinket tuning.
- **11 Aug. 2026:** Updated Gems and FAQ sections.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **27 Mar. 2026:** Updated trinket rankings.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **24 Jun. 2025:** Updated DISC socket recommendation following tuning.
- **15 Jun. 2025:** Updated for Patch 11.1.7 and DISC.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **04 Apr. 2025:** Updated trinket recommendations.
- **04 Mar. 2025:** Updated BiS lists and trinket ranking.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7. and Cyrce's Circlet.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Added BiS lists for Season 1, updated trinket section.
- **21 Aug. 2024:** Added Pre-Season BiS list section.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4 launch.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated trinket section for Patch 10.2.5.
- **07 Nov. 2023:** Embellishment recommendations updated after Undulating Sporecloak has been annihilated.
- **06 Nov. 2023:** Updated Gear recommendations for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Reformat of the page with BiS tables and section updates.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **24 Mar. 2023:** Updated Onyx Annulet section to account for live hotfixes.
- **20 Mar. 2023:** Added patch 10.0.7 new ring section. .
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Dec. 2022:** Updated Embellishment recommendations.
- **11 Dec. 2022:** Updated for Season 1 launch.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Demonology Warlock. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Demonology Warlock Stat Priority

The stat priority for a Demonology Warlock is as follows:

Item Level

Haste to 22%

Critical Strike

Mastery

Haste

Versatility

It is worth noting that our secondary stats are relatively close to
each other in value, so prioritizing item-level is generally considered the best approach,
especially as you approach hitting diminishing returns on the stat value you gain. A
more balanced stat distribution is preferable to stacking the two best stats to the point
where they diminish in value.

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. You should look for this stat in all
of your upgrades. It provides you with Spell Power, which increases the damage
of your spells.

**Haste** influences the cast speed of all your spells, as well as the
number of attacks your demons (outside Wild Imps) can output before despawning.
Haste is a desirable stat, as it generates additional resources
via [[spell:267102]] and allows for increased Soul Shard generation.

**Mastery**, through [[spell:77219]], increases the
damage dealt by your demons. It has higher importance in multitarget compared
to single target.

**Critical Strike** increases your chance to critically hit with all
spells and abilities.

**Versatility** is a flat-out damage done increase and damage taken
reduction.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **15 Dec. 2022:** Clarified the priority list reasoning.
- **14 Dec. 2022:** Split the stats priority between single and multitarget.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Demonology Warlock, based on your [stat priority](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

Socketable gems are divided in two categories: Epic and Rare. The former
offer a powerful effect but is limited to 1 equipped, whereas the latter
includes single or two secondaries stats combination gems.

Gems can be applied to a Helm, Bracer, or Belt via the
[[item:275707]] item from the Great Vault.

The Dazzling Diamond Epic gems of choice
are [[item:240983]]
or [[item:240967]]. The former is better until Mythic track
gear, at which point the latter performs better.

In terms of itemization, opting for Critical Strike gems yields the best
result, due how strong that secondary stat is for Warlocks in general. [[item:240906]]
is your best gem to pair with the [[item:240983]], while it is very
important to activate the full benefit of the [[item:240967]] by
equipping 4 different-coloured rare gems.

The four rare gems you should be looking to equip are:

- Peridots: [[item:240890]]
- Lapis: [[item:240914]]
- Amethysts: [[item:240898]]
- Garnets: [[item:240906]]

<em>It is highly recommended using [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) to sim your
character's ideal gems and enchants, as they might differ from general
recommendations.</em>

**Make sure to enable the checkboxes with "Always use" and "Only 4+
Colors" in the options.**

2.

### Best Enchants and Weapon Augments

Use [[item:243733]] as your weapon oil in all content.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Secondary stat weapon enchants may provide better value
 than [[item:244029]] but which one is best for you
 heavily depends on the rest of your gear. As such, depending on your current stat
 distribution, you may want to [sim yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) as your best secondary stat enchant
 may differ from the one listed above.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

For Season 2, [[item:241326]] is the default choice.

3.2.

#### Potions

[[item:241288]] should be the first choice if your gearset
has little to no Versatility, otherwise use [[item:241308]].

[[item:271883]] is the healing potion of choice.

3.3.

#### Food

[[item:242275]] and [[item:255846]] are the recommended food to
consume. You can simply buy whichever is the cheapest, or eat from a feast when it is
provided for the group.

Hearty version of food should be considered in situations where
wiping/dying is rather frequent, as those persists through death.

3.4.

#### Augment Rune

[[item:259085]] provide around 1% dps increase and
should be evaluated during progress, especially when close to pivotal
kills.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **16 Aug. 2026:** Updated consumables to reflect new BiS lists.
- **11 Aug. 2026:** Updated Gems.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Updated Tea section.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **22 Aug. 2025:** Updated weapon enchants.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **12 Sep. 2024:** Updated weapon enchants and oils.
- **09 Sep. 2024:** Updated gems section, as the strategy changed.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated Phial recommendation after Corrupted Rage buff.
- **24 Mar. 2023:** Updated Primordial Stones recommendations to account for the additional live hotfixes.
- **22 Mar. 2023:** Updated Primordial Stones recommendations to account for 25% buff hotfix.
- **20 Mar. 2023:** Added Primordial Stones section for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **07 Jan. 2023:** Updated dungeon phial to a more reliable Phial of Tepid Versatility.
- **14 Dec. 2022:** Updated Weapon Runes.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Demonology Warlock in World of Warcraft Patch 12.1.5.

1.

### Demonology Warlock in Mythic+ in Midnight Season 2

Mythic+ has become a large part of the World of Warcraft endgame, but the
sheer amount of different variables has left many players feeling overwhelmed.
The group composition, weekly affixes, the item level of the group, the
keystone level and the experience and comfort level of the group are just
several of the factors that will influence how you approach each dungeon. The
purpose of this page is to prepare you for the key differences that set
Mythic+ apart from the typical World of Warcraft endgame experience, including
talents and rotational anomalies that may not be obvious at first glance.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Demonology Warlocks have the potential to deal extremely high burst AoE
damage after a proper setup while also offering multiple short cooldowns that
suit well the average dungeon pull cadence. With multiple abilities having
some form of cleave effect, Demonology's damage profile is well-suited for
dungeons, with the only negative of being limited by specific setup periods,
and a slightly longer interrupt that shares a stun. The spec still retains all
the class baseline toolkit comprised of Healthstones, Soulstones, Curses,
skip-enabling [[spell:111771]], AoE crowd control abilities such as
[[spell:30283]] and [[spell:5484]].

:::details TipsHow to Deal With Wild Imps Ninja-Pulling in Keys?
Besides the always applicable suggestions, such as trying to be mounted whenever
possible, or to dismiss the Felguard, Wild Imps and other guardians will try
to align perpendicularly to the direction the player is facing, thus making
the practice of strafing a solution to mitigate the issue of proximity aggro.
The goal is to have the Wild Imps formation be as narrow as possible when
moving through packs of enemies, as opposed to a wide formation by
default.

:::

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist Mythic+ Build

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist Mythic+ Talents

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist setup offers more burst opportunities through
both [[spell:428522]] and [[spell:428517]] and in general scales better
at higher target count which often happen in high keys.

To import the build directly ingame, click on the export button at the
bottom of the calculator:

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAAAAAAGzYYBGYbYhGWMmZsMbzMzYGAYmxMzMzMAjZGzsBAAGzMzMDYbGDYA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjehprTwwJbM-DGRUVYCFYYceyCCSgk2KVWCLOigYd8C-AAAA-AOQo0QowITgwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester Variant

2.2.

#### Soul Harvester Mythic+ Talents

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester variant is centered around the idea of
augmenting Demonic Core generation while simultaneously offering on-death
damage effects. It offers better damage at lower target count and is slightly
faster at starting the Apex sequence, making it preferred for weekly keys or
Dungeons where there will be smaller pulls.

To import the build directly ingame, click on the export button at the
bottom of the calculator:

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzyAAAAAAAMWWGYADYG2CM2MYsMmxMzMAwMmZmZAmZGzMmZDAAMzMzMzMD2mZAGA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjchprTwwJbM-DGRUVYFey04WYYcu6Sg2QQmmsCLOS2A-AAAA-HIOQ2AEQQhhCzC-
```

:::

3.

### Mythic+ Flexible Talents for Demonology Warlock

### Utility / Defensive Talent Swaps

3.1.

#### Utility / Defensive Flexible Talents

In regards to AoE stops [[spell:30283]] and [[spell:5484]] are
often interchangeable, and should be evaluated in situations where stun or
fear immunity targets are present and if faster cooldowns are more
important.

[[spell:710]] is a much more niche tool to take out an Aberration, Demon
or Elemental target from the fight for up to 30 seconds. It does not work on
bosses and in boss encounter most of the time major mechanics often present
targets immune to the spell.

[[spell:268358]] and [[spell:111771]] can be considered
repositioning tools, with the latter generally allowing specific route skips
and the former used personally to handle mechanics that would force otherwise
prolonged movements.

For [[spell:108416]] supporting talents, [[spell:386664]] reduces
the Health Loss and is mostly used in situation where staying above a certain
Health threshold is preferable, but in general is less applicable than its
alternative [[spell:386686]] which offers a faster cooldown and thus
more opportunities to mitigate damage.

Inversely, for [[spell:104773]] opting for [[spell:317138]]
makes the damage mitigation more substantial and is generally preferred as
the base cooldown is long enough that a reduction with [[spell:386659]]
should be only considered if a specific fight requires double mitigation in
less than 3 minutes.

:::details TipsGrimoire Choice
Whilst

[[spell:1276452]]

is the baseline recommendation, it should
be noted that it is in fact a flexible choice. Both Grimoires do comparable
damage as cooldown so the main distinction is instead which utility spell
between

[[spell:19505]]

or

[[spell:89808]]

is better suited in a
specific dungeon or group composition. If there is need for offensive purge it is worth
considering

[[spell:1276467]]

.

:::

### Damage Talents Swaps

3.2.

#### DPS Flexible Talents

Opting out of [[spell:30146]] and instead taking
[[spell:267216]] opens up the demon choice
for [[spell:691]] to be used, offering a non-stun interrupt and
offensive purge, with the added benefit of additional single-target, at the
expense of some AoE. If neither utility is required on a boss,
then [[spell:366222]] offers even more single-target.

Picking [[spell:455449]] over [[spell:455450]] yields over 4% more
single-target at the expense of around 2% worse AoE, depending on target
count.

[[spell:1250375]] should be considered a last flex point, and can
be reallocated on [[spell:267216]] for a bit more single-target.

4.

### In-Depth Rotation Tips for Mythic+

While both single and multi-target rotations do not differ substantially
from the standard priority outlined in [Rotation, Cooldowns, and Abilities page](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>) there
are few points worth noting:

- Starting a new pull without resources means a relatively long period of
  a time when the damage will be low, due to
  [[spell:686]] being the only resource generator
  outside of procs. This makes transitioning between pulls with Soul
  Shards/Demonic Cores/Wild Imps extremely important to maintaining a higher
  DPS profile across the dungeon.
- While it may look tempting, it is generally better not to implode at the
  end of a dungeon pack, trying to spend all the Shards on additional Wild
  Imps, in order to regenerate 3 shards out of combat and being able to cast a
  massive [[spell:196277]] or Tyrant at the next pack.

5.

### Utility Kit and Abilities

While damage is the bigger reason to bring a Demonology Warlock, the class
itself offers a noticeable amount of crowd control and various supporting
abilities:

- Recently reintroduced, the Curses can offer some advantages against specific
   dangerous enemies: [[spell:1714]] can reduce the group's interrupt
   requirements. At the same time, [[spell:702]] alleviates the incoming
   damage on the tank from auto attacks. Last but not least,
   [[spell:334275]] can slow targets when kiting is required.
- [[item:5512]]s have a 1-minute cooldown and heal for 25% of max
   health, allowing for an emergency heal for each player.
- [[spell:20707]]s offer a combat resurrection that you can use reactively
   and preemptively in the case of a death run.
- [[spell:111771]] offers the unique ability to skip certain parts of
   the map, depending on the dungeon in question, avoiding specific pulls.
- [[spell:30283]] helps alleviate pressure on the tank during big pulls as
   it is a 3-second AoE stun.
- [[spell:5484]] in its current iteration is especially strong as a
   short cooldown aoe interrupt when talenting
   into [[spell:1270255]].
- [[spell:5782]] and [[spell:710]] are both spammable crowd control abilities
   that can interrupt a cast in a pinch or temporarily remove a target from combat.

:::details TipsDo Not Underestimate Curses!
With the introduction of

[[spell:1265813]]

Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

:::

:::details FAQHow To Best Use Blights?
Blights are much stronger version of Curses, at the expense of being tied to
a 2 minutes cooldown and lasting only 12 seconds. As such they should be
treated as a defensive cooldown for the party, in order to alleviate any
incoming damage, if applicable. Each Blight follows the same rules as their
correspective Curse:

- [[spell:1271748]] works on any attacks, reducing the frequency
  	and critical strike chance
- [[spell:1271802]] works on any cast that can be interrupted

:::

6.

### Dealing with Affixes

### Affix: Ascendant

6.1.

#### Ascendant Affix Management for Demonology Warlock

About every minute, Xal'atath will show up and summon a total of 10 Orbs of
Ascendance with a cast that needs to be interrupted. Any crowd-control or
interrupt spell will work:

- [[spell:30283]];
- [[spell:5484]] (capped to 10);
- [[spell:5782]];
- [[spell:6789]];
- Pet interrupts.

### Affix: Voidbound

6.2.

#### Voidbound Affix Management for Demonology Warlock

While in combat, Xal'atath summons a Void Emissary to empower nearby
enemies, which becomes the priority target and is best focused down.

### Affix: Pulsar

6.3.

#### Pulsar Affix Management for Demonology Warlock

While in combat, Xal'atath manifests pulsar orbs that tether and orbit
around players for 15 seconds. There is no particular suggestion for this
mechanic centered around just soaking those orbs, although the movement
reduction can be offset by [[spell:111400]].

### Affix: Devour

6.4.

#### Devour Affix Management for Demonology Warlock

Periodically, Xal'atath will cast a shield debuff on all 5 players, which
can either be removed by healing done or by dispelling. Healing abilities
such as [[spell:6789]] and [[item:5512]] can help removing the
shields if no other means to dispel them are available.

- [[spell:89808]] from both Imp and  [[spell:1276452]] can each
  	dispel a single shield.

7.

### Pet Choice for Demonology Warlock

You should be using your Felguard at all times as a Demonology Warlock.

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **31 Aug. 2026:** Added non-Felguard talent swaps.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated Diabolist talents.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **13 Apr. 2026:** Updated talents options to accomodate for hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated talent trees for the changes to each gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **29 Nov. 2024:** Updated talents recommendations following a simc update.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **19 Sep. 2024:** Updated for Patch 11.0.5 and added a dungeon tooltip section.
- **09 Sep. 2024:** Updated talent selection for Season 1 launch.
- **19 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated Talents and Stats.
- **07 Nov. 2023:** Updated Tyrannical Talents.
- **06 Nov. 2023:** Updated for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Restructured Talent section.
- **10 Jul. 2023:** Talents updated for Patch 10.1.5.
- **01 May 2023:** Talents updated for Patch 10.1.
- **20 Mar. 2023:** Talents updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated recommended build.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Demonology Warlock in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Below are examples of useful macros; you can adapt them for whatever spell you deem fit.

1.1.

#### Pet Macros

These macros allow you to manage your demon, as playing with your Pet Stance
on Assist is the preferred way to play.

#### Pet Attack

```wow-macro
/petattack
```

This orders your demon to attack your target.

#### Pet Follow

```wow-macro
/petfollow
```

This orders your demon to follow you.

#### Pet Move

```wow-macro
/petmoveto
```

This orders your demon to move to a location specified by you. This macro
is especially useful for situations where you need your pet in a predetermined
position in order to accomplish a given task — such as an interrupt on a
otherwise out of range target — but can also be used to maximize Felguard
cleave/[[spell:89751]] damage, just be aware that any imparted commands will
also make your Dreadstalkers, Vilefiend (if talented) and Tyrant move,
resulting in a much bigger loss when used improperly.

1.1.1.

##### DoT Mouseover

#### Corruption Mouseover

```wow-macro
#showtooltip Corruption
/use [@mouseover,harm] [harm] Corruption
```

Casts [[spell:172]] on current mouseover target if hostile and alive,
else cast it on your current target.

Worth mentioning that Blizzard has added the ability to toggle all casts to
follow a mouseover logic in the control settings, however some abilities may
not function correctly, and thus it is still recommended to take the time and
make a macro for any ability with a mouseover use case.

1.1.2.

##### Banish Focus

#### Banish Focus

```wow-macro
#showtooltip Banish
/use [mod:shift,@focus] [] Banish
```

Cast [[spell:710]] on focus target by holding also shift, else cast
it on your current target.

1.1.3.

##### Soulstone Mouseover

#### Soulstone Mouseover

```wow-macro
#showtooltip Soulstone
/target [@mouseover] Soulstone
/use Soulstone
/targetlasttarget
```

Workaround macro for the current bug related to mouseover dead allies. The
Macro itself will target the mouseover in order to cast [[spell:20707]]
then target the previous target.

1.1.4.

##### Demonic Circle

#### Demonic Circle

```wow-macro
#showtooltip
/stopcasting
/use [mod:shift] Demonic Circle(Summon); [nomod] Demonic Circle: Teleport(Teleport)
```

Place the Demonic Circle while holding shift, or teleport to the circle
without any modifiers, while cancelling any ongoing casts. This saves you the
trouble (and the time!) of interrupting your spell cast manually.

1.1.5.

##### Shadowfury/Howl of Terror

#### Shadowfury/Howl of Terror

```wow-macro
#showtooltip
/use [known:Shadowfury,@cursor] Shadowfury; [known:Howl of Terror] Howl of Terror
```

Depending on the talent selected cast [[spell:30283]] at cursor
or [[spell:5484]] instead.

1.2.

#### Mouseover Demonbolt

#### Mouseover Demonbolt

```wow-macro
#showtooltip Demonbolt
/use [@mouseover,harm,nodead] [] Demonbolt
```

This macro will cast [[spell:264178]] on mouseover if it is a valid
target, otherwise on the current target. Useful to spread [[spell:460551]] in
multitarget.

1.3.

#### Grimoire: Imp and Grimoire: Fel Ravager

#### Grimoire Imp and Fel

```wow-macro
#showtooltip [known:1276467] Grimoire: Fel Ravager; [known:1276452] Grimoire: Imp Lord
/cast [known:1276467,@mouseover,harm,nodead][] Grimoire: Fel Ravager
/cast [known:1276452,@mouseover,exists,nodead][] Grimoire: Imp Lord
```

The above macro combines both Grimoires (depending which one is talented)
that can be used on mouseover first else on current target. This works both
for the cooldown themselves and the utility spells associated.

2.

### Best Addons

2.1.

#### Generic Add-Ons for Warlocks

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **03 Jan. 2023:** Removed Soulburn macro.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
