## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Pumps。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-guide>)
- [练级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)

## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本 守护德鲁伊指南。在这里，你将学习如何在团队副本和大秘境中担任 守护德鲁伊坦克。我们涵盖从基础知识到极限生存优化技术的所有内容。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

守护大秘境资源

[最新！顶级 守护天赋构筑](<https://raider.io/specs/guardian-druid/talents>)

[顶级 守护大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/druid/guardian>)

[守护大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=druid--guardian>)

[热门 守护队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=druid--guardian>)

1.

### 守护德鲁伊概览

[守护 德鲁伊](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-guide>) 是一个坚实的坦克，通过强大的被动减伤、庞大的生命值池、精通带来的治疗加成，以及可叠加的主动减伤技能[[spell:192081]]来管理承受的伤害。他们是非常优秀的沙包坦克。一旦你获得了足够的装备，他们基本上可以自给自足，拥有独特的游戏风格，与其他任何职业都不同。作为坦克，他们为团队副本和大秘境队伍带来一些实用功能，并能造成极高的DPS。

守护德鲁伊在大多数承受伤害为物理或近战伤害的战斗中通常表现出色。

本指南专门聚焦于 守护德鲁伊。因此，更通用的坦克相关内容将不会在此涵盖。如果你想了解更多关于坦克的通用知识，我们建议你阅读我们的
[坦克指南](<https://www.icy-veins.com/wow/tanking-guide>).

在所有场景中都很强大

守护德鲁伊拥有非常灵活的伤害输出，一个强大的2-3分钟冷却技能在群体和单体战斗中都非常出色，总体持续伤害输出也相当高。

表现极佳

守护德鲁伊是任何团队副本环境的可靠选择，这得益于其出色的生存能力、

[[spell:1126]]

团队增益以及整体团队实用性。它是最灵活的坦克之一，能够轻松应对大多数机制。守护如果没有时间提前铺开持续伤害效果，就会缺乏爆发伤害，这在某些战斗中可能相关，但很少见。

持续强势

守护在 至暗之夜大秘境中表现出色，拥有持续的高额群体伤害和极强的自我恢复能力，此外还拥有任何坦克能为队伍提供的最好的群体治疗工具。

感觉有用

守护可以使用几种不同的实用技能，比如

[[spell:1126]]

,

[[spell:106898]]

,

[[spell:371905]]

,

[[spell:99]]

和

[[spell:372119]]

等等。一个善用所有实用功能的 守护会让团队觉得是真正的资产，总是有影响力且有帮助。

极其耐打

守护是一个坦克，而且是个相当硬的坦克。我们很灵活，能够有效且持续地减免所有类型的伤害。像

[[spell:22812]]

和

[[spell:22842]]

这样的短冷却技能让我们能够舒适地减免伤害并维持生命值池，在大多数场景下无需治疗者。

快速灵活

守护拥有可靠的机动性，但通常需要一个目标来

[[spell:102401]]

，而像

[[spell:6544]]

或

[[spell:109132]]

这样的技能则可以瞄准任何方向。好的一面是，当你不主动坦怪时，你可以舒适地变形，并在

[[spell:783]]

或

[[spell:768]]

.

1.

### 守护 德鲁伊在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本对 守护德鲁伊没有实质性改动。该版本的主要重点是2个新的终局内容，一个面向团队副本，一个面向 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。请务必查看关于新的基斯提克斯团队副本战斗的信息，以及令人兴奋的全新迷宫巨型地下堡！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

主要改动将来自基斯提克斯团队副本战斗的新物品。最值得注意的是一个饰品、一个戒指和一件胸甲。此外，你将能够从 10 月 20 日起使用[[item:280562]]升级物品。武器、项链和饰品都可以升级。

2.3.

#### 职业改动

12.1.5版本对 守护德鲁伊专精本身没有任何改动，但我们网站上的总体和团队副本装备推荐将会有所变更。
[装备](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>) 页面。我们还提供了一份高价值物品清单，供你决定如何花费你的第一批[[item:280562]]。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_druid_bearhug.jpg>)点击查看上赛季第二赛季的改动
2.4.

#### 职业改动

守护在12.1版本中对巅峰天赋进行了彻底重做，同时还有一些天赋改动。

- [[spell:429539]] - 现在将[[spell:204066]]的冷却时间固定减少20秒。这是为了移除spam[[spell:8921]]的游戏风格。
- [[spell:29166]] - 现在使治疗者在8秒内恢复20%的最大法力值，而不是使施法在8秒内免费。
- [[spell:200854]] - 现在使[[spell:192081]]有几率使你的下一个[[spell:6807]]/[[spell:400254]]/[[spell:441605]]免费。同时使你的[[spell:6807]]/[[spell:400254]]/[[spell:441605]]有几率使你的下一个[[spell:192081]]免费。
- +8%光环增益 - 免费的伤害，总是好的。

巅峰重做：

1. [[spell:1269614]] - 现在有10%的几率召唤一个持续8秒的守护之魂，当你施放[[spell:77758]]或[[spell:33917]]时攻击附近的敌人。
2. [[spell:1269617]] - 已将[[spell:33917]]加入持续伤害效果中。
3. [[spell:1269619]] - 当一个守护之魂被唤醒时，你的[[spell:77758]]和[[spell:33917]]的冷却时间被重置，并且在灵魂激活期间它们造成30%的额外伤害。

:::

### 至暗之夜改动概述

2.5.

#### 英雄天赋改动

守护在12.1版本中唯一真正的英雄天赋改动是将[[spell:429539]]重做为固定减少[[spell:204066]]的20秒冷却。

2.6.

#### 生存能力改动

随着几个天赋的移除和重做，守护者的生存能力略有变化，但基本与第1赛季相同，[[spell:204066]]的覆盖率略低是唯一的真正区别。

2.6.1.

##### 实用功能改动和新天赋

守护在12.1版本中没有获得任何新天赋，但[[spell:200854]]的重大重做增加了一些新的需要跟踪和注意的内容。

2.7.

#### 守护德鲁伊巅峰天赋（在 至暗之夜中）

守护德鲁伊新重做的（截至12.1版本）巅峰天赋主要围绕[[spell:77758]]和[[spell:33917]]展开。

1. [[spell:1269614]] - 消耗怒气有10%的几率唤醒一个持续8秒的守护之魂，当你施放[[spell:77758]]或[[spell:33917]]时攻击附近的敌人。
2. [[spell:1269617]] - 精通提高。[[spell:33917]]和[[spell:6807]]/[[spell:400254]]现在总是被强化，并在12秒内造成额外的自然伤害。
3. [[spell:1269619]] - 当一个灵魂被唤醒时，[[spell:77758]]和[[spell:33917]]的冷却时间被重置，并且在灵魂激活期间它们造成30%的额外伤害。每次灵魂攻击你都会产生8点怒气。施放[[spell:394786]]后，获得1层狂野守护，使你的下一个[[spell:6807]]/[[spell:400254]]/[[spell:441605]]必定唤醒一个灵魂。
4.

### 守护德鲁伊基础玩法

作为坦克专精之一，你的首要目标是活下来，并确保你对所有敌人都有仇恨，这样他们就不会攻击你较弱的队友/团员。要高效地担任守护德鲁伊坦克，你的目标是尽可能多地铺开[[spell:8921]]，然后用[[spell:33917]]和[[spell:77758]]等技能产生尽可能多的怒气。这些怒气可以用于防御，如[[spell:192081]]和[[spell:22842]]，或者用于进攻，如[[spell:6807]]。守护德鲁伊的主要要点可以通过以下列表了解。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_stoneclawtotem.jpg>) **生存优先**
  
  
  
  
  坦克死亡通常意味着团队或副本的灭团。最大化你的DPS对坦克来说极其有价值，尤其是在极限内容中，但优先考虑个人生存是坦克最重要的部分。这通常意味着在某些场景中（主要是大秘境）风筝，当你没有冷却技能可用时。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_ancestralguardian.jpg>) **绝不浪费怒气**
  
  
  
  
  怒气对守护来说极其有用和强大，我们要确保在获得怒气时总是明智地使用它。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_druid_thrash.jpg>) **有效循环冷却技能**
  
  
  
  
  守护有很多短冷却技能，应该不断循环使用，以获得最大的伤害和防御能力。

1.

### 守护德鲁伊如何获取装备

虽然我们始终建议你使用模拟工具以获得理想结果，但我们确实提供了一个专门的 守护配装页面。我们目前涵盖了第二赛季装备的推荐，以便在终局 至暗之夜内容发布时有一个良好的开端。在你获得一些装备后，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 新增了毒石部分并更新了装备物品等级。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 更新了简易团本天赋和简易大秘境天赋。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年10月8日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 新增了基希克斯物品。
- **2026年9月1日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了大秘境套装原始部件。
- **2026年8月15日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了常见问题解答区块。
- **2026年8月15日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 天赋更新。
- **2026年8月12日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了虚空核心列表和最佳列表。
- **2026年8月12日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 天赋更新。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 天赋更新。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对12.1更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了来自地下城的装备说明。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 新增了套装链接。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 天赋和手册说明已更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 简易配装已改为EC。
- **2026年8月10日（本页）：** 更新了基础说明和变更列表。
- **2026年8月9日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 添加了天怒狂怒说明，并移除了月火填充说明。
- **2026年8月8日（本页）：** 添加了12.1版本变更的说明。
- **2026年8月3日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月3日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月3日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月3日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月3日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月20日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 添加了新的EC配装。
- **2026年5月20日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 更新了两个简易配装。
- **2026年4月23日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 更新了插件列表和宏命令。
- **2026年4月23日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 更新了属性说明。
- **2026年4月23日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 添加了持续伤害说明。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月10日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已更新天赋构筑。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 移除了Bloodmallet和旧饰品列表。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已更新至至暗之夜第1赛季开赛。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 添加了词缀。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 添加了起手式的介绍。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已更新至至暗之夜第1赛季开赛。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 添加了蓝贴调整说明，并移动了至暗之夜变更章节。
- **2026年3月14日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月14日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月13日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已更新至至暗之夜第1赛季开赛。
- **2026年3月13日（本页）：** 已更新至至暗之夜第1赛季开赛。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（本页）：** 已针对至暗之夜发布更新。
- **2026年2月12日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已更新为12.0.1等级解锁机制。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 天赋已更新为12.0.1新的等级解锁要求。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 天赋已更新为12.0.1新的等级解锁要求。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 添加了常见问题板块。已针对11.2.7版本进行审阅。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 添加了常见问题板块。已针对11.2.7版本进行审阅。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 添加了常见问题板块。已针对11.2.7版本进行审阅。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 更新了优势与劣势。已针对11.2.7版本进行审阅。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 已更新至11.2版本
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 为11.1.7补丁更新。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 移除了恭喜板块。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 装备列表已更新至11.1.5。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 添加了腐蚀板块。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 添加了11.1.5版本变更板块。
- **2025年3月24日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 更新了配装，并修正了英雄天赋。
- **2025年3月19日（[解放安德迈页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-liberation-of-undermine-raid-guide>)):** 更新了史诗首领战提示。
- **2025年3月1日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了大秘境标签页中的套装。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月18日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了塞什斯之冠的推荐，并添加到毕业列表中。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 为11.0.5版本添加了塞什斯之冠板块。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 添加并更新了推荐配装。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 为11.0.7版本更新了配装和输出循环。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-nerub-ar-palace-raid-guide>)):** 更新了首领战提示，并添加了史诗提示。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 添加了副本专属提示。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 添加了11.0.5版本更新说明。
- **2024年9月17日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 在增强和削弱后更新了饰品和装备列表。
- **2024年9月17日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-nerub-ar-palace-raid-guide>)):** 更新了首领战提示，并添加了安苏雷克提示。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已更新至地心之战第1赛季开赛。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 更新了狂怒之怒的说明。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已更新至地心之战第1赛季开赛。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** TNC已从15%更新为12%。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 更新了简易大秘境配装。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年9月7日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已更新至地心之战第1赛季开赛。
- **2024年8月25日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 添加了2个地下堡配装，并更新了大秘境/群体输出配装。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已更新至地心之战开服。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已更新至地心之战开服。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/guardian-druid-mists-of-pandaria-remix-guide>)):** 根据地心之战天赋树改动更新了天赋配装。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已更新至地心之战。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已更新至地心之战前夕。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对地心之战前夕进行审阅。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已更新至地心之战前夕。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已更新至地心之战前夕。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已更新至地心之战前夕。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已更新至地心之战前夕。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已更新至地心之战前夕。
- **2024年7月23日（本页面）：** 已更新至地心之战前夕。
- **2024年6月18日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/guardian-druid-mists-of-pandaria-remix-guide>)):** 调整了宝石。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/guardian-druid-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/guardian-druid-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月9日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了装备列表。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月23日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了碎地猛击链接。
- **2024年4月23日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 更新了大秘境配装和介绍说明。
- **2024年4月23日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 更新了套装说明。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 为第4赛季进行了更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 移除了损坏的野性之心宏。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 为第4赛季进行了更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月25日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对10.2.6版本进行审阅
- **2024年3月20日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（本页）：** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已针对10.2.5版本进行审阅和更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对10.2.5版本进行审阅和更新。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对10.2.5版本进行审阅和更新。
- **2024年1月15日（本页）：** 已针对10.2.5进行审阅。
- **2023年11月23日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了饰品列表。
- **2023年11月21日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了毕业列表。
- **2023年11月21日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 更新了大秘境天赋配装。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 为10.2版本更新了毕业列表。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 为10.2版本添加了新的治疗药水。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 为10.2版本进行了审查。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 更新了第3赛季的说明。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 移除了10.1.7版本物品，以更新至10.2版本。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 为10.2版本进行了审查。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 更新了鲜血狂乱的目标上限和怒气增加从2到3的说明。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至10.2。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 添加了新的毕业列表装备板块。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 更新了大秘境配装和第2赛季关于主流玩法的说明。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 添加了输出循环信息板块。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 添加了新的天赋模板板块，并更新了天赋。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 将乌索克的 狂怒 备注更新为45%，IR更新为120%，PotP更新为5%。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 更新了天赋树。
- **2023年9月4日（本页）：** 添加了10.1.7说明。
- **2023年7月25日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了借时还魂链接。
- **2023年7月25日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 添加了额外的多目标说明。
- **2023年7月25日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已更新天赋构筑。
- **2023年7月25日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 将乌索克的狂怒说明更新为50%。
- **2023年7月12日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 添加了高伤害大秘境配装，并修正了碎地猛击链接。
- **2023年7月12日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 修复了Raze链接。
- **2023年7月12日（本页）：** 修复了Raze链接。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已为10.1.5版本更新。添加了DoC宏。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月26日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 添加了时空漫游装备。
- **2023年5月26日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 添加了无实体注意事项。
- **2023年5月18日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了饰品列表。
- **2023年5月6日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 饰品调整后更新了BiS列表。
- **2023年5月6日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 调整后更新了附魔和消耗品。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 更新了10.1版本的新饰品和装备。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 为10.1版本添加了暗焰缠绕武器附魔，并更新了原初之石宝石说明。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 更新了10.1的信息并移除了雷鸣效果。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已更新至10.1补丁。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 更新并添加了10.1的新天赋配置。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 更新了10.1版本的法术。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 更新了10.1的初学者天赋配置。
- **2023年5月1日（本页）：** 已为10.1更新。
- **2023年4月28日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已为10.1更新，移除了旧插件。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 更新了原初之石宝石推荐。
- **2023年3月24日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 更新了天赋树字符串。
- **2023年3月24日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 更新了天赋树字符串。
- **2023年3月24日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 更新了天赋树字符串。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已为10.0.7版本审查。2023年1月24日：已为10.0.5版本审查。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/guardian-druid-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已为10.0.7更新。
- **2023年2月11日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 修复漏洞后更新了天赋配置。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已更新至10.0.5补丁。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月13日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 添加了美化部分。
- **2022年12月21日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 更新了大秘境配置。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/guardian-druid-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/guardian-druid-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/guardian-druid-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/guardian-druid-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/guardian-druid-patch-9-2-changes-analysis>)):** 已审查并批准本页面用于9.2版本上线。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/guardian-druid-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/guardian-druid-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年6月28日（[9.1 补丁分析](<https://www.icy-veins.com/wow/guardian-druid-patch-9-1-changes-analysis>)):** 更新了盟约专属传奇装备。
- **2021年5月2日（[9.1 补丁分析](<https://www.icy-veins.com/wow/guardian-druid-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-crucible-of-storms-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-the-eternal-palace-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2019年10月1日（[永恒宫殿页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-the-eternal-palace-raid-guide>)):** 编辑了所有首领的天赋和精华。
- **2019年7月19日（[永恒宫殿页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-the-eternal-palace-raid-guide>)):** 根据上线后的观察和经验，为首领添加了更多提示。
- **2019年7月7日（[永恒宫殿页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-crucible-of-storms-raid-guide>)):** 团队副本发布后审查了提示和天赋。
- **2019年4月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-battle-of-dazar-alor-raid-guide>)):** 已为风暴熔渣团队副本更新。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年1月20日（[达萨罗之战页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-battle-of-dazar-alor-raid-guide>)):** 为守护德鲁伊添加了达萨罗之战指南。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** 针对8.1补丁进行了更新。
- **2018年9月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** 英雄难度周后更新了所有首领的信息。
- **2018年8月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-uldir-raid-guide>)):** 页面已添加。

显示更多

显示更少

:::

## 练级

在本页中，您将找到我们的守护德鲁伊逐级升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[德鲁伊 升级指南](<https://www.icy-veins.com/wow/druid-leveling-guide>).

1.

### 守护德鲁伊至暗之夜升级指南

守护德鲁伊由于是一个坦克专精，我们的升级选择非常丰富。如果您想刷副本升级，坦克排队通常是最快的。如果您想单人升级，聚怪并用AoE技能清理对我们来说非常完美。我们在团队中也很出色，因为DPS职业很喜欢有人为他们聚怪和坦住小怪。

1.1.

#### 升级装备选择

升级时，物品等级总是比单项属性更重要。始终选择物品等级最高的装备。带有速度副属性的物品可以帮助加快你的升级速度，尤其是在长时间室内活动期间。传家宝装备在升级时也很有用，可以让你在升级旅程的大部分时间里忽略大量配装需求。

1.2.

#### 至暗之夜中有用的升级物品

以下是一些可能帮助您在至暗之夜中更快升级的有用物品。

- [[item:132516]]
- [[item:243191]]/[[item:224572]]
- [[item:109076]]
- [[item:122128]]
- [[item:63359]] / [[item:64398]] / [[item:64402]]

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 守护德鲁伊80级至暗之夜升级
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwYMWMbzMPgZZZAbGGNRzMzyMzMzYMDAAAAAADbzAW2mZwYWGATAAAAbYMALmBDGssNAAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwMjZWMbmxMWGwmhRT0MzsMzMzMLjZAAAAAAYMbzAW2mZwYWGATAAAAbYmBYxMYwYzCAzMAG"
}
```
:::

:::details 来源计算器编码
```
#oB-TTBfUNh0iSA64UUqsslV8otVT7F2qc8F7pH-BAgCcxiGccE7tsoJNp6gkhiHNIdKUUX-AAAA-HSAIgYQUcIYDzC-
```

:::

2.1.

#### 升级用战争模式天赋

在本节中，我们将重点介绍最实用的战争模式PvP天赋，以加快您的升级过程。

- [[spell:201664]]——使10码内的所有敌人受到挫败，使其造成的伤害降低20%，持续8秒。在大量拉怪时可以进一步减少承受的伤害。
- [[spell:202246]]——冲向一个敌人，使其昏迷3秒，并击退其15码内的盟友。这是另一个冲锋技能，为您的技能库增加更多机动性，让您进一步加快升级速度。
- [[spell:329042]]——使你进入深度沉睡8秒。睡眠期间，所有其他冷却时间恢复速度加快400%。这非常强大，因为它大幅缩短了每个技能的冷却时间。尽量在未被攻击时使用，因为受到伤害会打破沉睡效果。

1.

### 升级循环

为了帮助你了解升级和天赋树进程中的变化，请使用下方的滑块选择你当前的等级。每次升级时，将滑块移动，本节内容也会随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–9：**由于守护在10级解锁为天赋专精，在您获得选择之前，应充分利用入门任务中提供的技能。

- **等级 9 起：**使用[[spell:1126]]为自己增益。
- **等级 8 起：**进入[[spell:5487]]。
- **等级 2 起：**在目标身上保持[[spell:8921]]。
- **等级 10 起：**使用[[spell:22812]]，冷却好就用。
- **等级 17 起：**使用[[spell:50334]]，冷却好就用，最好在面对多个敌人时使用。
- **等级 10 起：**施放[[spell:77758]]，冷却好就用。
- **等级 8 起：**在4个或更少目标上施放[[spell:33917]]，冷却好就用。
- **等级 11 起：**用[[spell:213764]]填充空闲时间。
- **等级 11 起：**在单目标时用[[spell:6807]]进攻性地消耗怒气。
- **等级 18 起：**用[[spell:192081]]防御性地消耗怒气。
- **等级 10 起：**如果生命值低于50%，使用[[spell:22842]]。
- **等级 8 起：**确保在战斗中始终处于[[spell:5487]]状态。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已针对12.1更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月12日：** 已更新为12.0.1等级解锁机制。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 移除了恭喜板块。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已更新至地心之战开服。
- **2024年7月23日：** 已更新至地心之战。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月25日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已为10.0.7版本审查。2023年1月24日：已为10.0.5版本审查。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5版本中轻松游玩守护德鲁伊，使用最简单的循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 守护德鲁伊基础

本页面面向刚接触游戏或该职业的玩家，他们不打算参与史诗难度团队副本，或者只是想要一种更直接的方式来游玩他们的专精，而不会被为实现最优游玩所需考虑的众多细节和主动技能所淹没。

守护德鲁伊通过其主动减伤技能[[spell:192081]]来减少受到的伤害。铁鬃的冷却时间可以忽略不计，并且可以叠加，使其对物理伤害和近战攻击非常有效。他们的自我治疗技能[[spell:22842]]虽然不如其他一些坦克职业强大，但为自我续航提供了相当不错的提升。他们兼具短冷却和长冷却的防御技能，有助于有效应对魔法伤害。

在功能性方面，守护者带来了[[spell:106898]]，这是一个全团移动速度提升技能，在许多需要全团移动的战斗中非常强大。守护者还可以在战斗中用[[spell:20484]]复活盟友，并偶尔用[[spell:371905]]在周围产生AoE治疗脉冲。

守护的首要目标是利用手中的工具存活下来。这意味着产生和消耗怒气用于主动减伤、自我治疗，并有效使用防御冷却技能来应对危险的伤害。在牢记这一切的同时，次要目标应该是造成伤害；这对于保持对目标的仇恨以及更快击杀首领很重要。幸运的是，这不需要您付出太多额外努力——如果您在防御方面很好地执行了循环，您的伤害也会反映出这一点。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_stoneclawtotem.jpg>) **生存优先**
  
  
  
  
  坦克死亡通常意味着团队或副本的灭团。最大化你的DPS对坦克来说极其有价值，尤其是在极限内容中，但优先考虑个人生存是坦克最重要的部分。这通常意味着在某些场景中（主要是大秘境）风筝，当你没有冷却技能可用时。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_ancestralguardian.jpg>) **绝不浪费怒气**
  
  
  
  
  怒气对守护来说极其有用和强大，我们要确保在获得怒气时总是明智地使用它。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_druid_thrash.jpg>) **有效循环冷却技能**
  
  
  
  
  守护有很多短冷却技能，应该不断循环使用，以获得最大的伤害和防御能力。

1.

### 守护德鲁伊在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者团队副本天赋

2.1.

#### 新手团队副本天赋

这是一个非常适合新手的团队副本配置。这是一个非常简化的熊形态版本，您主要将怒气花费在[[spell:192081]]和[[spell:22842]]上。

使用计算器的'导出天赋'功能，可以轻松地在游戏中复制该配置。

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZWMLmhZZZgZDGNRzMzyMzMzYMjBAAAAAYGbzAW2mZwY2GATAAAAbGzMALmBDYxiBYmBwA"
}
```
:::

:::details 来源计算器编码
```
#oB-TTBfUNh0iSA64UUqsslVstlYlVWTL+1FGZK-BACbcxiGWWSccERSTiXVGKqHNIIdGKMB-AAAA-RGKaMSOysEEAhA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 AoE天赋

2.2.

#### 新手地下城和大秘境天赋

这个配置强化了奥术天赋，并专注于通过[[spell:377210]]和[[spell:77758]]持续产生大量治疗。我们还通过[[spell:132469]]和[[spell:102793]]获得了一些额外的控制技能。

使用计算器的'导出天赋'功能，可以轻松地在游戏中复制该配置。

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMzMjZWMLGmZZZgZzwoJyMzyMzMzsMmBAAAAAgZmNDYZbmBjZZAMBAAAshZGgFzgBsYBgZGAD"
}
```
:::

:::details 来源计算器编码
```
#oB-TTBfUNh0iA64UUqsslVst9gYNWTTm1zrrTM-BACcjGwWWk4t54IKJDF11DFDIHakaQKA-AAAA-RGKaMSOwsEEAhA-
```

:::

### 守护德鲁伊基础循环

2.3.

#### 新手守护德鲁伊循环

1. 保持[[spell:8921]]。
2. 尽可能频繁地使用[[spell:77758]]。
3. 尽可能频繁地使用[[spell:33917]]。
4. 将怒气用于[[spell:192081]]进行防御或避免怒气溢出。
5. 进攻性地使用[[spell:6807]]/[[spell:400254]]。
6. 在没有其他技能可用时，将[[spell:213764]]作为最低优先级的最后手段使用。

这个循环在保持合理伤害的同时最大化了怒气生成。

2.4.

#### 守护德鲁伊套装

守护德鲁伊套装基本上完全是被动效果，完全不需要围绕它进行操作。2件套奖励使[[spell:77758]]有几率让你的下一个[[spell:33917]]造成100%的额外伤害。4件套奖励使[[spell:77758]]召唤3根荆棘刺穿目标造成额外伤害，并将我们的[[spell:394786]]延长最多5秒。

2.4.1.

##### 冷却技能

守护者有三个基础冷却技能。

- [[spell:22812]]使你受到的所有伤害降低20%，持续12秒，冷却时间60秒。树皮术可以在昏迷、瘫痪或睡眠状态下使用。这将是您应对危险尖峰伤害的第一道防线，也是减少魔法伤害或作为风险缓解手段来平滑治疗者承受的治疗压力的主要方式。它的冷却时间很短，所以要经常使用。
- [[spell:61336]] 在6秒内使你受到的所有伤害降低50%。生存 生存 本能有两层充能，冷却时间为3分钟。这是你的主要减伤技能，应用于应对致命的尖刺伤害或“坦克杀手”机制。其持续时间短且冷却时间长，意味着应谨慎使用。
- [[spell:50334]]使[[spell:33917]]、[[spell:77758]]和[[spell:6795]]的冷却时间缩短50%。

2.4.2.

##### 巅峰天赋： ![Wild Guardian Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_meta_emeralddream.jpg>) 狂野守护

守护的顶峰天赋对循环有轻微影响，最简单的规则是，尽量不要在[[spell:77758]]或[[spell:33917]]即将冷却完成时消耗怒气。这是因为消耗怒气有几率重置它们的冷却时间。

### 守护德鲁伊防御法术

2.5.

#### 守护德鲁伊的主动减伤/防御法术

通过执行循环，您将产生怒气。您可以通过三种方式之一消耗怒气：用于主动减伤技能[[spell:192081]]、自我治疗[[spell:22842]]或强力攻击技能[[spell:6807]]。

如何消耗怒气可以归结为几种简单的情况。如果您正在承受物理伤害或近战攻击，使用[[spell:192081]]。如果您生命值较低或预计会被打到低血量，使用[[spell:22842]]。如果两者都没有危险，使用[[spell:6807]]。

[[spell:192081]]的独特之处在于可以叠加多次施放效果，这意味着你可以同时拥有两层或更多层的“铁鬃”。你也可以囤积怒气，在战斗中的危险时刻消耗在多层铁鬃上。请记住，每一层的持续时间都是独立的，因此添加一层不会刷新其他层的持续时间。

[[spell:22842]]会在短时间内为你恢复最大生命值的一定百分比。如果你点出了[[spell:1278789]]天赋，狂暴回复的过量治疗会为我们提供一个吸收护盾，这在冲进怪群时非常实用。

[[spell:6807]]应该只在你没有实际扛怪，或者你承受的伤害非常低，以至于使用[[spell:192081]]不会降低你的治疗需求或提高你的生存几率时使用。

### 守护德鲁伊属性优先级

2.6.

#### 守护德鲁伊属性优先级

你需要优先考虑 **装等高于一切**，因为护甲、耐力和敏捷远比任何次要属性更有价值。在没有主属性的珠宝和其他部位上，你会按照以下顺序偏好次要属性。

关于本页呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>).

急速

全能

暴击

精通

### 暴风雪战斗助手

2.7.

#### 守护德鲁伊战斗助手

这是11.1.7补丁引入的新功能，旨在帮助新手玩家进行循环。虽然此功能对某些人可能有用，但对于守护来说，完全按照它操作通常会损失约40%的DPS。此外，作为一个坦克，它并没有太多强调正确使用防御技能的重要性。请自行斟酌使用此工具，但目前盲目跟随它将是极其不理想的。

[战斗助手指南](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>)

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 更新了简易团本天赋和简易大秘境天赋。
- **2026年8月10日：** 简易配装已改为EC。
- **2026年8月3日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月20日：** 更新了两个简易配装。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 天赋已更新为12.0.1新的等级解锁要求。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为11.0.7版本更新了配装和输出循环。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 更新了简易大秘境配装。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至地心之战前夕。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审阅和更新。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 更新了天赋树。
- **2023年7月12日：** 修复了Raze链接。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 更新了10.1的初学者天赋配置。
- **2023年3月24日：** 更新了天赋树字符串。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页，你将找到魔兽世界12.1.5补丁中守护德鲁伊的最佳天赋。我们还为团队副本或大秘境等不同类型的内容提供了默认天赋方案。如果你开启了战争模式进行游戏，我们也为你提供了PvP天赋。

1.

### 守护德鲁伊在至暗之夜中的最佳天赋

在至暗之夜第二赛季中，守护将拥有多种不同的玩法风格，这得益于近期补丁中持续且重大的调整。虽然天赋树上有许多潜在的选择，但我们目前的建议如下：

- **单体/团队副本 -** 在12.1改动之后， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊在第二赛季所有团队副本战斗中的单体表现都非常接近。
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊提供略微更偏向爆发的输出曲线，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者提供更持续的伤害以及稍微更好的防御选择。
- **AoE/大秘境 -** 在12.1补丁中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者在所有钥石等级下都极为接近。我们通常推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者，因为它的机制更简单，输出曲线也稍微更灵活。

两个英雄天赋树在所有内容中的表现都非常接近。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊在运气好时有略高的上限，并提供更强的稳定减伤。如果你对守护有良好的基本理解，我们通常推荐使用它。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 如果你个人偏好艾露恩钦选者，它完全可行，你不会注意到两者之间有显著的性能差异。

**快速开始导入代码：**

:::talents 守护单体 - 利爪德鲁伊
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwYMzmZZGMLLDMbwoJamZWmZmZGjZMDAAAAAYGLzAAAAgmZZWmZmBAwCmZAWMDGwmFDAmZDG"
}
```
:::

:::talents 守护AoE - 艾露恩钦选者
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZml5BmZMziZxwMLLDMbGGNRmZWmZmZmlxMGAAAAAgZsYAbbzMYMLDgJAAAgNMzAsYGMgNLAMzAYA"
}
```
:::

:::talents 守护地下堡 - 艾露恩钦选者
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwMjZWMLGmZZZgZzwoJyMzyMzMzsMmxAAAAAAMjlZALbzMYMLDgJAAAgNMzAsYGMgNLAMzAYA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

利爪德鲁伊

团队副本/单体目标

推荐

AoE/大秘境

艾露恩钦选者

团队副本/单体目标

推荐

AoE/大秘境

推荐

地下堡

### 天赋方案 0-0

1.1.

#### 单目标天赋（适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊

此方案非常适合单体情况，与艾露恩钦选者相比有更高的爆发DPS，但整体DPS相似。

### 天赋方案 0-1

1.2.

#### 多目标及大秘境天赋，适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊

这是一个针对爆发AoE场景的强力方案。

此方案优先考虑从[[spell:77758]]和[[spell:400254]]结合[[spell:377210]]天赋产生的大量吸收效果。玩法和循环保持不变。

### 天赋方案 1-0

1.3.

#### 单目标天赋（适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

此方案适用于以单体为主的情况。

### 天赋方案 1-1

1.4.

#### 多目标及大秘境天赋，适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

这是我们针对AoE场景的推荐方案。主要用于大秘境。

此方案优先考虑从[[spell:77758]]产生的大量治疗和吸收效果。

### 天赋方案 1-2

1.5.

#### 地下堡天赋 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

地下堡是你单人或与最多五位好友（以及一个随从的帮助！）一起参与的内容。它们是非常简短的约3-15分钟的场景，作为守护德鲁伊，你将能够通过[[spell:5215]]到达目标点来几乎完全绕过某些阶段，而无需战斗。我们还有一个专门的页面来了解关于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>).

在这些内容中，你队伍中的非坦克玩家生存可能很艰难，因为敌人伤害很高，尤其是在你装备不足且你的随从治疗还不够强的时候。这就是为什么这个天赋方案包含了多个辅助治疗天赋，这样你就可以帮助你的队伍舒适地生存。记住这里没有时间限制，所以你可以自由地等待冷却或恢复到满血，并且大多数敌人都可以风筝。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxs4BGjZ2MLzgZZZgZDGNRzMzyMzMzYMjZAAAAAAzYZGAAAA0MLzyMzMAAWwMDwiZwA2ssNAYmNYA"
}
```
:::

:::details 来源计算器编码
```
#oB-NBfTTU0hKKiAIqss1y1lVsdVTLW+6FGbpEJ-BACc2wiGWWccEnoRSiXmnNdIGooMnKXA-AAAA-QUEYCSMaO4owCB-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMmZMziZZGmZZZgZzwoJamZWmZmZmlxMAAAAAAMzsMDAAAAamlZZmZGAALYmHAYxMYAbWAAzsBD"
}
```
:::

:::details 来源计算器编码
```
#oB-NBfTTU0hKKiAIqss1y1lVcVTLW+6FrnzDJM-BACc2wiGWWccEnoR6QiXmHNdGKUooumA-AAAA-QUEYCSMaO4owCB-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGLzA2WmZwY2GATAAAAbYmBYxMYAbW2GgZGAD"
}
```
:::

:::details 来源计算器编码
```
#oB-NBfTTU0hKKiAIqss1y1lVsdVTLW+6FGbpEJ-BACc2wiGWWccEnoRSiXmnNdIGooKXgYC-AAAA-RGKaYOmYQAMwiA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZml5BmZMziZxwMLLDMbGGNRzMzyMzMzsMmBAAAAAgZmFDYbbmBjZbAMBAAAshZeAgFzgBsZBgZGAD"
}
```
:::

:::details 来源计算器编码
```
#oB-NBfTTU0hKKiAIqss1y1lVcVTLW+6FrnzDJM-BACc2wiGWWccEnoR6QiXmHNGKUoouIQA-AAAA-RGKaYOmYQAM4iA-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwMjZWMLGmZZZgZDmpJyMzyMzMzsMmBAAAAAgZmlZALbzMYMbDgJAAAgNMzAsYGMgNLAMzAYA"
}
```
:::

:::details 来源计算器编码
```
#oB-LNBfTTU0hKKiAIqss1y1lVsdVTLW+6FGrnT-BACc2wiGWWccEnoR6QiXmHNdIGKUoouA-AAAA-RGKaYOmYQAI4iA-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

我们建议你在第二赛季选择以下加成，但由于你可以随时自由切换，如果你觉得推荐的选项效果不够好，请随意尝试其他选项：

- 第1点：[[spell:1279599]]
- 第2点：[[spell:1279603]]
- 第3点：[[spell:1287555]]
- 第4点：[[spell:1279613]]
- 第5点：[[spell:1279614]]

1.

### 巅峰天赋： ![Wild Guardian Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_meta_emeralddream.jpg>) 狂野守护

1. [[spell:1269614]]
2. [[spell:1269617]]
3. [[spell:1269619]]

守护德鲁伊的巅峰天赋主要围绕[[spell:77758]]和[[spell:33917]]，本质上是添加了一个持续12秒的DoT，你可以通过每12秒至少施放一次[[spell:6807]]或[[spell:33917]]来永久维持它。这并不会真正影响或改变我们的循环，因为我们通常有大量多余的怒气已经倾泻到[[spell:6807]]上，并且我们循环使用[[spell:33917]]。

3.1.

#### 英雄天赋

我们的两个英雄天赋树在大秘境和团队副本中都非常出色且可行。从71级开始，守护德鲁伊将获得 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊和
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者.

3.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊主要围绕[[spell:6807]]的替代技能[[spell:441605]]，这是一个伤害极高并留下大量DoT的技能。从主题上来说， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊旨在增强我们的物理和流血伤害。它在大秘境的拉怪中表现出色，此时你有[[spell:394786]]可用，因为它绝大部分伤害都与冷却技能绑定。它还能对Boss造成极高的单体伤害，这使它非常适合团队副本。

3.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者拥有强化版[[spell:204066]]的力量。这个技能通常在拉怪开始时可用，有助于快速建立仇恨，并在你开始叠加状态时让你相对安全。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者在拉到更多目标时也能极好地扩展，因为你的[[spell:8921]]迅速扩散，并且你的自我治疗随着[[spell:377210]]和[[spell:370586]]快速叠加。

1.

### PvP天赋（战争模式）

争霸艾泽拉斯资料片引入了一个名为“战争模式”的新系统。选择开启战争模式使你有资格参加开放世界PvP，但也会授予你以下好处：

- 满级的世界任务奖励提高10-30%。
- 升级时获得的经验提高10-30%。
- 允许你获得征服点数，以换取每周装备奖励。
- 授予你在开放世界中使用PvP天赋的权限。

鉴于开启战争模式对升级和PvE内容的好处，我们建议你启用此功能，以最大化你的升级过程和满级后的奖励。然而，你会使自己有资格参与开放世界PvP，在升级或做世界任务时存在被“偷袭”的可能性。

以下是升级和进行PvE内容的推荐PvP天赋。你将获得一个通用PvP天赋和三个专精特定天赋的选择。

1. [[spell:202246]]是一个带有昏迷效果的强力冲锋，它触发的击退提供了巨大的机动性提升。
2. [[spell:329042]]进入深度睡眠8秒，使所有其他冷却时间恢复速度加快400%。
3. [[spell:201664]]使敌人对你造成的伤害降低20%，持续10秒。
4. [[spell:207017]]替换[[spell:6795]]，后者在单人内容中历来没有作用。作为交换，你（和你的盟友）对被你嘲讽的目标造成更高的伤害。
5. [[spell:236147]]使你的[[spell:783]]移动速度提高20%，并防止你被减速到100%移动速度以下。这提高了你的机动性并减少了旅行时间，这在升级时很重要。

其余的PvP天赋在升级或开放世界PvE内容中可能有有限或小众的应用，但它们不提供上述推荐列表的整体收益。其余的PvP天赋对升级或开放世界PvE没有实质性贡献。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月15日：** 天赋更新。
- **2026年8月12日：** 天赋更新。
- **2026年8月10日：** 天赋和手册说明已更新。
- **2026年8月3日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年5月20日：** 添加了新的EC配装。
- **2026年4月23日：** 添加了持续伤害说明。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月10日：** 已更新天赋构筑。
- **2026年3月16日：** 已更新至至暗之夜第1赛季开赛。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 天赋已更新为12.0.1新的等级解锁要求。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月24日：** 更新了配装，并修正了英雄天赋。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 添加并更新了推荐配装。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已更新至地心之战第1赛季开赛。
- **2024年8月25日：** 添加了2个地下堡配装，并更新了大秘境/群体输出配装。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至地心之战前夕。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月21日：** 更新了大秘境天赋配装。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 添加了新的天赋模板板块，并更新了天赋。
- **2023年7月25日：** 已更新天赋构筑。
- **2023年7月12日：** 添加了高伤害大秘境配装，并修正了碎地猛击链接。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 更新并添加了10.1的新天赋配置。
- **2023年3月24日：** 更新了天赋树字符串。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月11日：** 修复漏洞后更新了天赋配置。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页，你将学习如何根据你将要扛的伤害类型来优化守护德鲁伊的循环。我们还有关于冷却技能、触发效果等的进阶部分，以最大化你的生存能力和DPS。我们所有的内容都已针对魔兽世界12.1.5补丁更新。

1.

### 守护德鲁伊玩法与循环指南

欢迎来到我们的守护德鲁伊循环页面。在本页，你将找到关于在团队副本和大秘境内容中游玩该专精所需了解的一切。

以下各部分分别讲解不同环境下的输出循环。点击方框可切换到所需场景。

:::details 常见问题：我应该以防御还是进攻的方式游戏？
这是大多数人在坦克时会问的主要问题。基本答案是，如果你正在开荒进度，或者你使用的是一个你对输出没有信心的角色，你应该采取防御姿态。当你逐渐熟悉后，你应该开始更多地关注DPS，并采用更混合的风格，在推进DPS的同时慢慢牺牲一些生存能力。

一旦你对战斗完全熟悉并且不会拖累团队，你就可以追求DPS。这个临界点因人而异，因为它取决于你的团队、你的角色、你的装备和你的技术水平。

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊

利爪德鲁伊 - 单体

利爪德鲁伊 - AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者

艾露恩钦选者 - 单体

艾露恩钦选者 - AoE

主动天赋

被动天赋

[[spell:391528]]

[[spell:394786]]

[[spell:400254]]

[[spell:1253799]]

[[spell:1252871]]

[[spell:372567]]

[[spell:1269619]]

[[spell:400278]]

[[spell:377210]]

[[spell:370586]]

[[spell:1253461]]

[[spell:203953]]

[[spell:393427]]

[[spell:158477]]

[[spell:1253035]]

[[spell:1252994]]

### 守护单体

守护的单体循环围绕尽可能保持[[spell:1252871]]（它替换[[spell:8921]]）的最佳覆盖时间，方法是尽可能频繁地使用[[spell:33917]]，此外还要维持[[spell:77758]]的最大层数，并尽可能在怒气高于80时使用[[spell:400254]]/[[spell:263857]]。在高于80怒气时使用它们是为了[[spell:1253035]]天赋，该天赋大幅提高触发[[spell:210706]]的几率，从而重置我们的[[spell:33917]]冷却时间。

1. 卡好冷却时间使用[[spell:77758]]
2. 卡好冷却时间使用[[spell:33917]]
3. 卡好冷却时间使用[[spell:204066]]（如果接近，最好与[[spell:1252871]]对齐）
4. 卡好冷却时间使用[[spell:1252871]]
5. 在[[spell:768]]中施放[[spell:1261867]]
6. 施放[[spell:394786]]
7. 将怒气用于[[spell:400254]]（进攻性）或[[spell:192081]]（防御性）
8. 施放[[spell:213764]]

### 守护AoE

守护的AoE循环与单体极其相似，只是我们不再需要担心[[spell:1252871]]，因为我们改用了[[spell:372567]]。

1. 卡好冷却时间使用[[spell:77758]]
2. 卡好冷却时间使用[[spell:33917]]
3. 卡好冷却时间使用[[spell:204066]]
4. 在Boss战中于[[spell:768]]中施放[[spell:1261867]]，或在AoE拉怪时于[[spell:197625]]中施放。
5. 施放[[spell:394786]]
6. 将怒气用于[[spell:400254]]（进攻性）或[[spell:192081]]（防御性）
7. 使用[[spell:8921]]或[[spell:213764]]作为填充技能
8.

### 至暗之夜 第2赛季套装

至暗之夜第2赛季引入了 **神秘梦行者之皮**，可在不同的终局内容中获得。它提供以下加成：

- [[spell:1296607]] — [[spell:77758]]有20%的几率使你的下一个[[spell:33917]]造成的伤害提高100%。
- [[spell:1296608]] — [[spell:77758]]召唤最多3根荆棘，每根刺穿一个目标并造成自然伤害。同时将[[spell:394786]]的持续时间延长5秒。

守护德鲁伊的套装完全是被动的，天然地增强了我们的常规循环。

1.

### 职业与专精机制详解

为了更好地解释守护德鲁伊套装的具体用法和好处，我们编写了关于循环各部分的更详细说明，从你需要注意的重要循环机制，到冷却技能及其使用方式。

### 铁鬃

3.1.

#### 铁鬃

[[spell:192081]]使你的护甲提高你敏捷值的112%，持续7秒。铁鬃的多次施放可以重叠并叠加护甲增益，但持续时间不会叠加。例如，如果你使用铁鬃，3秒后再使用，你将拥有两层铁鬃持续4秒，获得相当于你敏捷值224%的护甲。4秒后，第一层铁鬃将过期，你将在接下来的3秒内拥有相当于你敏捷值112%的护甲。敏捷增益和触发效果会提高你从铁鬃获得的护甲量。

护甲在减少物理伤害承受方面极为有效，因此建议尽可能常驻至少一层[[spell:192081]]。此外，你偶尔会想要积攒怒气，在短时间内叠起多层铁鬃以应对伤害尖峰。护甲减少你承受伤害的硬上限为85%。这大约相当于7-8层（有增辉唤魔师时为3-4层）[[spell:192081]]，通常可以在5-10个目标或在[[spell:394786]]内实现。

护甲不能 **非** 通常用于降低流血伤害（在游戏中通常表现为“物理持续伤害”）或魔法伤害。然而，这些规则存在例外，会因具体情况而异。当面对流血或魔法伤害时，你会发现铁鬃 [[spell:192081]] 无效，此时应改用你的减伤技能来降低伤害，或使用时机恰当的狂暴回复 [[spell:22842]] 来治疗自己。请记住，如果你在坦boss，你几乎总是会承受自动攻击和其他伤害来源。自动攻击是物理伤害，因此在大多数战斗中维持铁鬃 [[spell:192081]] 仍然值得。

最后，在使用[[spell:192081]]之前要仔细考虑你的情况。由于它是主动技能，无论你的血量被压到多低，如果没有新的伤害到来，使用它都是毫无意义的。

### 怒气获取

3.2.

#### 怒气获取

守护德鲁伊的主要资源是怒气。

怒气条的最大容量为100，默认为空。脱离战斗时怒气会快速衰减。战斗中，怒气不会衰减。

怒气通过以下方式产生：

- 激活[[spell:5487]]使你获得25点怒气（离开熊形态会清空怒气条）。
- 自动攻击产生4点怒气。
- 被自动攻击产生3点怒气（每秒最多触发一次）。
- [[spell:33917]]产生10点怒气（有[[spell:210706]]触发时+4，有[[spell:158477]]时+5）。
- [[spell:77758]]产生5点怒气。
- [[spell:8921]]在有[[spell:203964]]触发时产生8点怒气。
- [[spell:155835]]在激活期间，每承受最大生命值1%的伤害产生1点怒气。
- [[spell:203962]]每次在任意目标身上触发[[spell:77758]]流血时产生2点怒气（痛击每3秒触发一次，受急速影响缩短）。
- [[spell:1269619]]每次灵魂造成伤害时产生8点怒气。

### 猎豹形态编织/割裂编织

3.3.

#### 猎豹形态编织/割裂编织

截至至暗之夜， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊的猎豹形态编织是DPS损失。在我们看到任何改动/增强或削弱之前，你不需要担心编织任何东西，除了每2分钟切换到[[spell:768]]施放[[spell:319454]]，这是一个施加在单个目标上的大量持续伤害，在单体战斗中如果安全绝对值得使用。

割裂编织是指你施放6次[[spell:33917]]后获得一个增益（通过[[spell:441691]]天赋），该增益强化你的下一个[[spell:1079]]和[[spell:22568]]，并在进入[[spell:768]]时产生最大连击点数。你在[[spell:5487]]中使用[[spell:1822]]来切换到[[spell:768]]，由于[[spell:449193]]天赋，你会立即切换到猎豹形态。然后你可以施加这个强化的[[spell:1079]]，并在[[spell:768]]中通过施放[[spell:33917]]直接切换回[[spell:5487]]。这是猎豹形态编织的一个非常安全的版本，对你的生存能力影响极小。由于[[spell:441678]]天赋在猎豹形态中保留[[spell:192081]]，你甚至可以在坦boss时主动使用它。

确保你在施放[[spell:33917]]后不要过早切换到猎豹形态，因为它可能在冷却中，这会延迟你快速切回熊形态的能力。

猎豹形态编织是一个高级话题，会显著复杂化循环。不推荐刚上手守护德鲁伊的人或在学习新战斗时使用。话虽如此，正确执行的话，它可以在单体战斗中比留在熊形态中带来显著的DPS提升（取决于平衡性调整）。

### 巅峰天赋

3.4.

#### 守护德鲁伊的顶点天赋

1. [[spell:1269614]]
2. [[spell:1269617]]
3. [[spell:1269619]]

守护德鲁伊的顶点天赋主要围绕[[spell:77758]]和[[spell:33917]]，本质上添加了一个12秒的持续伤害，只要你每12秒至少施放一次[[spell:6807]]或[[spell:33917]]就能永久维持。这实际上不会影响或改变我们的循环，因为我们通常有大量过剩的怒气已经倾泻到[[spell:6807]]中，而且我们自然地频繁循环使用[[spell:33917]]。需要注意的一点是，为了优化顶点，你要尽量避免在[[spell:77758]]或[[spell:33917]]的冷却即将结束时花费怒气。这是因为花费怒气有机会重置你的[[spell:77758]]和[[spell:33917]]的冷却。

1.

### 守护德鲁伊的重要冷却技能

守护德鲁伊是一个主要为主动式的坦克。你必须在承受伤害之前就准备好主动减伤和防御冷却技能。这与反应式坦克形成对比，后者先承受伤害然后通过治疗自己来应对。

因此，准备工作在有效坦克中扮演着重要角色。明智地使用冷却技能并与治疗者协调至关重要，这可能是boss击杀和灭团之间的区别。为一场战斗做准备的最好方法是查看战斗的伤害模式（通过战斗日志或阅读地下城手册），并规划你将使用哪些冷却技能、何时使用，以及是否有任何空档需要治疗者的外部防御技能来覆盖。

你有两个基础防御冷却技能，还有一些可以通过天赋点出的。除非你确定否则会死，否则不建议重叠你的防御冷却技能，因为那样使用它们通常是过度和浪费的。

### [[spell:394786]]

4.1.

#### 化身：乌索克的守护者

[[spell:394786]]是我们的主要冷却技能，每2-3分钟可用（取决于花费的怒气和天赋）。它提供提高的生命值，并减少[[spell:77758]]和[[spell:33917]]的冷却时间。它还使[[spell:33917]]命中3个目标。

在某些情况下，如果你预期即将有重大危险，可以选择将其保留为防御冷却技能，但通常最好作为进攻冷却技能在冷却好时就使用。

### [[spell:22812]]

4.2.

#### 树皮术

[[spell:22812]]是一个40-60秒的冷却技能，我们希望尽可能在冷却好时使用。它通过[[spell:203953]]天赋造成伤害，并显著减少我们承受的伤害。这有助于总体上平滑我们的伤害承受并承受大型攻击。

### [[spell:61336]]

4.3.

#### 生存本能

[[spell:61336]]是我们最大的防御技能。至暗之夜给了我们2次基础充能，所以规划这些更加容易。通常保留给非常危险的伤害承受或大型攻击。

4.4.

#### 战前检查清单以最大化DPS

- 确保你已经根据情况食用了合适的食物
  [我们的消耗品页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>).
- 确保你从我们这里获得了相应的药剂增益
  [我们的消耗品页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>).
- 确保你的武器有来自我们 [我们的消耗品页面](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-gems-enchants-consumables>).
- 激活你的[[item:259085]]，如果你能省下金币的话！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 新增了套装链接。
- **2026年8月9日：** 添加了天怒狂怒说明，并移除了月火填充说明。
- **2026年8月3日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 添加了起手式的介绍。
- **2026年3月13日：** 已更新至至暗之夜第1赛季开赛。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 添加了常见问题板块。已针对11.2.7版本进行审阅。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至地心之战前夕。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月23日：** 更新了套装说明。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 移除了10.1.7版本物品，以更新至10.2版本。
- **2023年9月4日：** 添加了输出循环信息板块。
- **2023年7月25日：** 添加了额外的多目标说明。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页面，你将找到魔兽世界12.1.5中你的守护德鲁伊的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们应有尽有！

1.

### 守护德鲁伊毕业装备指南

欢迎来到我们的守护德鲁伊装备页面，适用于至暗之夜第2赛季。查看此页面了解关于配装守护德鲁伊你需要知道的一切，包括来自所有来源的毕业装备、团队副本和大秘境、最佳饰品、套装等信息。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含守护德鲁伊来自所有来源的最高DPS配置。请记住，还有许多其他配置在误差范围内表现相当。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 小贴士：我想要套装在哪些部位？
随着

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

继承原物品的副属性和特殊效果，玩家现在在获取具有理想属性的套装部件方面拥有巨大的灵活性

**在所有五个**

部位。假设你

**同时**

进行团队副本和大秘境，催化以下装备：

- 头盔：[[item:271875]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:251223]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 胸部：[[item:251159]]，来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 手套：[[item:251124]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 腿部：[[item:268225]]，来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 常见问题：我应该从宏伟宝库选择什么？
该 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 每周有多达九个部位的物品供你选择，取决于你的角色完成了哪些内容。这也影响每个部位的物品等级，其中 ![Mythic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-mythic.png>)史诗团队副本boss奖励完全升级的史诗路线装备！然而，这种广泛的潜在物品等级也使得提供通用推荐变得困难。此外，玩家可以选择 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 或功绩代币，可用来兑换一个毒瘴珠宝镶嵌器 [[item:275707]]。这些替代品的实力不应被低估，即使它们相比之下可能感觉有点“无聊”。

尽管你应该始终对给定宝库奖励中的选择进行模拟（包括你将在本赛季剩余时间保留的装备上的额外插槽的价值），以下是选择奖励时遵循的基本优先级：

1. （仅第一个宝库）领取功绩代币以获得一个[[item:275707]]或套装部件（如果有的话）。
2. 如果你将进行团队副本 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 至少在 **![Heroic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-heroic.png>)英雄难度**，选择一个 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 以额外抽取物品 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)。这样做直到你至少获得一个英雄路线的[[item:268215]]。
3. 选择能完成你套装的最高奖励路线物品。
4. 选择带有急速的最高物品等级部件、下方毕业装备列表中的物品，或额外的 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)/[[item:275707]]，取决于你角色的目标。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271875@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAG2wYNTpC]]&#10;&#10;<div>[[item:240983]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:281236@JAACAAQ42A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAACAAwt1A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268215@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

此列表包含守护德鲁伊来自所有来源的最高DPS配置。请记住，还有许多其他配置在误差范围内表现相当。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在两个部位中，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性并添加一个美化。

:::details 常见问题我需要哪些套装部件？
任何4件套装部件的组合都适用于守护德鲁伊，因为我们整体上需要平衡的属性优先级。长期来看，你理想情况下会想使用一个特定的咒术头部部件（[[item:271875]]），来自 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装部件时也会保留副属性和任何其他潜在的被动效果，如伤害触发。这意味着我们要尝试催化那些确保我们在装备上获得最佳副属性的物品，但如果不可能的话，也没关系。拥有属性稍次的套装并在赛季后期修复，比错过一两周的套装加成要好。一些催化时属性最佳的物品有：

- 头部：[[item:273791]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 肩部：[[item:251223]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 胸部：[[item:251159]]，来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 手套：[[item:251124]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 腿部：[[item:251130]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：你最好的主动使用副本饰品掉落在这里：[[item:273796]]。
- [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)：拥有最多有用的物品。
- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：掉落你最好的武器。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>项链</th><td>[[item:251173@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>腰部</th><td>[[item:244573@JAACAAgNyA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>脚部</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAgV1A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAACAAgNyA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250228@JAACAAgV1A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:158370@JAACAAgV1A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

此列表包含守护德鲁伊来自所有来源的最高DPS配置。请记住，还有许多其他配置在误差范围内表现相当。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在两个部位中，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性并添加一个美化。

:::details 常见问题我需要哪些套装部件？
任何4件套装部件的组合都适用于守护德鲁伊，因为我们整体上需要平衡的属性优先级。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装部件时也会保留副属性和任何其他潜在的被动效果，如伤害触发。这意味着我们要尝试催化那些确保我们在装备上获得最佳副属性的物品，但如果不可能的话，也没关系。拥有属性稍次的套装并在赛季后期修复，比错过一两周的套装加成要好。一些催化时属性最佳的物品有：

- 头盔：[[item:271875]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:268246]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 胸部：[[item:268235]]，来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- 手套：我们想要这些来自代币
- 腿部：[[item:268225]]，来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:268215]]：这把武器掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)，最终boss， [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)，并且是你的毕业武器。只有少数专精可以装备它，让你有可能避免制造武器。此外，当在英雄难度用 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)，该物品将以神话级变体掉落；在史诗难度下，它将被“提升”额外10个物品等级。
- [[item:268265]]：这条项链来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 在很多方面都是独特的，纯暴击属性、第二个插槽和两个进一步强化你角色的咒术效果。
- [[item:270175]]：一个强大的主动使用饰品，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) ，不仅提供静态暴击，还提供按需的敏捷和一些额外的物理伤害。
- [[item:270173]]：相对被动的饰品，但在所有可用饰品中为我们提供最多的DPS。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271875@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:281236@JAACAAQ42A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAACAAAG2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/guardian-druid-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268215@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 守护德鲁伊饰品推荐

守护有大量饰品可用，我们通常想要搭配一个强大的主动使用饰品如[[item:270175]]或[[item:270168]]，以及一个提供强大副属性增益或原始伤害触发的被动饰品。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **守护德鲁伊饰品**
**使用型 -**

[[item:270175]]

或者，作为替代，

[[item:270168]]

**被动 -**

[[item:270164]]

或者，作为替代，

[[item:270173]]

:::

还有不少其他有价值的饰品，所以请务必点击我们的排名图表，看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看守护德鲁伊饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>守护 </th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270168]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:270165]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159617]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:270160]]</li>&#10;<li>[[item:273797]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250244]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:250243]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:270174]]</li>&#10;<li>[[item:250225]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159618]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:158374]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

12.1版本延续了在12.0.7版本中首次引入的额外拾取系统。值得注意的是，对英雄难度团队副本Boss使用额外拾取将使你获得1/6神话等级的物品，因此只要你投入额外的纹章来升级它，就可以相当早地获得一些后期团队副本装备。

- [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可用于针对特定boss或地下城的物品，通过让你额外抽取保证从特定掉落位置获得一件战利品。你将获得哪件物品是随机的，但一旦以这种方式获得了一件物品，你下一次使用虚空核心将获得你尚未获得的剩余物品之一。
- [[item:280562]] 可用于大幅提升英雄或神话路线装备的物品等级（前提是它们已达到最高可能物品等级），也可用于最高品质的制造装备。这将进一步提升它们的强度。此功能仅适用于武器、饰品和项链。

3.1.

#### 朦胧虚空核心（额外拾取）在 守护 德鲁伊 中的使用

你想追求哪件装备，在很大程度上取决于你已经通过（例如） [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)获得了哪些装备，或者你是否预计能定期以史诗难度击败某些首领，因为你不想把虚空核心浪费在几周后就能在更高难度路线获得的装备上。

3.2.

#### 守护 德鲁伊 朦胧虚空核心推荐用法

由于玩家在游戏过程中可能会被提供各种各样的战利品
[大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 提供了种类繁多的战利品，因此很难给出关于如何花费你的 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)的简单推荐。不过，由于这些虚空核心会在副本或团队副本首领的整个掉落表中进行判定，因此某些位置对于获取最便捷的强度提升来说比其他位置更有效。特别是来自 **英雄难度** [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 和 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
的首领的装备，在使用时将作为神话路线物品获得！

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) ([[item:268215]]/[[item:270175]]/[[item:268265]])
2. [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) ([[item:270173]]/[[item:268225]]/[[item:268256]])
   [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) （拥有大量适合我们的优秀装备，以及一些适合 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)的理想装备）剩余毕业装备清单

:::

3.3.

#### 晋升毒液石

随着12.1.5补丁发布，你现在可以获取 [[item:280562]]，允许你将特定装备栏位一直升级到装等340（制造装备为338）。使用这些的优先级与你的纹章使用类似：

1. **武器** 首先，尽早升级制造或史诗武器是巨大的强度提升。
2. **主动使用型饰品** 其次，理想情况下是 [[item:270175@JAACAAgNyA]]，但任何 S 级饰品都是不错的选择。
3. **被动饰品** 第三。
4. **项链** 最后。

你还应优先考虑神话路线装备而非英雄路线装备，除非你不打算获得你正在升级的装备的神话路线版本。

1.

### 守护 德鲁伊 最佳制造装备

你同时最多只能拥有两个 **强化**，存在于你装备的制造装备上。

守护 通常倾向于制作属性预算低、灵活的装备，这些装备可以随时轻松更换为其他强化。想了解更多关于专业和制造的通用信息，下面是一个专门的职业概览页面链接。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **守护 制造装备优先级**
- [[item:245771]] 搭配 [[item:245876]]
- [[item:244576]]/[[item:244569]] 搭配 [[item:240167]]
- 任何你尚未获得神话级的物品。

:::

- 带 [[item:245876]] 强化的 [[item:245771]] 是一个很棒的初始制作选择。尽管由于 乌拉特克 的咒术武器而并非永久毕业装备。
- [[item:244576]] 和 [[item:244569]] 的装备冲突最少。在这些装备上使用像 [[item:240167]] 这样的简单触发强化，会让它们非常有竞争力。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

1.

### 纹章使用

你将能够通过纹章升级你的装备。一旦你将某个部位升级到一定物品等级， [ 升级该部位的其他装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 到该物品等级就是免费的。

当你使用纹章升级时，你应该将其视为升级 **插槽** 而不是物品。

下面是你应该升级装备的部位优先级。如果你想要偏离这一点，必须有非常好的理由。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **守护 德鲁伊 纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 新增了毒石部分并更新了装备物品等级。
- **2026年10月8日：** 新增了基希克斯物品。
- **2026年9月1日：** 更新了大秘境套装原始部件。
- **2026年8月15日：** 更新了常见问题解答区块。
- **2026年8月12日：** 更新了虚空核心列表和最佳列表。
- **2026年8月10日：** 更新了来自地下城的装备说明。
- **2026年8月3日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 移除了Bloodmallet和旧饰品列表。
- **2026年3月14日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 添加了常见问题板块。已针对11.2.7版本进行审阅。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 装备列表已更新至11.1.5。
- **2025年3月1日：** 更新了大秘境标签页中的套装。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月18日：** 更新了塞什斯之冠的推荐，并添加到毕业列表中。
- **2024年12月15日：** 为11.0.5版本添加了塞什斯之冠板块。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月17日：** 在增强和削弱后更新了饰品和装备列表。
- **2024年9月9日：** 已更新至地心之战第1赛季开赛。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至地心之战前夕。
- **2024年5月9日：** 更新了装备列表。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月23日：** 更新了碎地猛击链接。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审阅和更新。
- **2023年11月23日：** 更新了饰品列表。
- **2023年11月21日：** 更新了毕业列表。
- **2023年11月6日：** 为10.2版本更新了毕业列表。
- **2023年9月4日：** 添加了新的毕业列表装备板块。
- **2023年7月25日：** 更新了借时还魂链接。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月26日：** 添加了时空漫游装备。
- **2023年5月18日：** 更新了饰品列表。
- **2023年5月6日：** 饰品调整后更新了BiS列表。
- **2023年5月1日：** 更新了10.1版本的新饰品和装备。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2023年1月13日：** 添加了美化部分。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面，你将找到你的 守护 德鲁伊 的最佳属性优先级。我们首先介绍属性优先级，然后深入探讨属性如何与你的专精和玩法互动的更复杂解释。我们的内容已针对《魔兽世界》12.1.5版本补丁更新。

1.

### 守护德鲁伊属性优先级

守护 德鲁伊 的属性优先级取决于你是追求生存能力还是伤害输出。

无论你优先考虑什么，物品等级高出10级或以上的装备几乎总是升级，因为属性会有大幅提升。

1.1.

#### 生存能力

装备等级

急速

全能

精通

暴击

护甲、敏捷和耐力被归为一类，因为它们通常同时出现在装备上，但任何一项“主”属性按每点计算都会比副属性更强。

1.2.

#### 伤害输出

急速

全能

暴击

精通

需要注意的是，所有副属性的价值都非常接近。这是一个粗略估计，因为你的属性顺序可能会根据你当前拥有的每种属性数量而略有不同。敏捷对于伤害输出也非常重要，通常会使物品等级最高的装备成为最佳选择。如果你想要真正准确地评估哪些属性最适合你，你应该用模拟工具模拟你的角色以获取属性权重。

1.

### 深入属性解析

**敏捷** 是你的主属性。它提高你的攻击强度，为你提供少量闪避，并由于 [[spell:192081]] 而转化为护甲。

**护甲** 减少你受到的物理伤害。守护者从 [[spell:5487]] 获得额外的护甲（和耐力）。

**全能** 减少你受到的伤害，增加你造成的伤害和治疗量。

**精通** （[[spell:155783]]）提高你的最大生命值和你受到的治疗量。它还提高你的攻击强度。

**急速** 为 守护 做很多事情。它提高你的近战攻击速度，提高 [[spell:77758]] 和 [[spell:8921]]（以及像 [[spell:1822]] 和 [[spell:1079]] 这样的流血效果）的跳动速度，减少全局冷却时间，并减少 [[spell:33917]]、[[spell:77758]] 和 [[spell:22842]] 的冷却时间。

**暴击** 提高你的暴击几率（造成双倍伤害）并提高闪避几率。

:::details 常见问题：作为 守护 德鲁伊 我应该堆什么属性？
简单来说，守护 的所有属性在强度方面都极为接近，应平等对待。没有断点或其他需要追求的目标；只需尽可能获取高物品等级即可。人们倾向于急速和全能，因为它们是“手感”最好的属性。如果你想最大化你的DPS，你应该始终模拟你的角色以获得最佳结果。

:::

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月23日：** 更新了属性说明。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 添加了常见问题板块。已针对11.2.7版本进行审阅。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面，我们列出了你的 守护 德鲁伊 能获得的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/guardian-druid-pve-tank-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

团队副本的最佳属性是急速和全能，所以我们将为此镶嵌宝石。你应该在一个插槽中使用 [[item:240983]]，其余宝石可以使用 [[item:240893]]。

大秘境的最佳属性也是急速和全能，所以在这种内容类型中相同的宝石也是最佳选择。

<em>我们强烈建议使用 Raidbots 模拟你角色的理想宝石和附魔，因为它们可能与我们的一般推荐有所不同。</em>

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243973]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>肩部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243963]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243981]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;<li>[[item:243974]]（更低的DPS，更高的移动速度）</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;<li>[[item:244643]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

你应该始终饮用 [[item:241325]]。

3.2.

#### 药水

你的属性药水应该是 [[item:241308]]。在你能用技能造成最多伤害的时候使用这些，很可能是在你的冷却期间和/或 [[spell:2825]]/[[spell:32182]] 期间。

你应该储备一些 [[item:271883]] 在生命值低时使用，如果队伍中有 术士，也拿他们的 [[item:5512]] 使用。不要将它们绑在一起，分开使用效果最好！

3.3.

#### 食物增益

无论是 [[item:255845]] 还是 [[item:255846]] 都是你最好的食物增益，不仅为你提供主属性或副属性，还提供耐力，而耐力只有从这些盛宴中才能获得。

确保也携带一些 [[item:242275]]，以防你没有盛宴可用。

3.4.

#### 强化符文

此外，如果负担得起，你应该使用 [[item:259085]] 来提高你的主属性。强化符文价格昂贵且死亡后消失，所以请明智而节制地使用它们！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已更新至至暗之夜第1赛季开赛。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 添加了腐蚀板块。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至地心之战前夕。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本添加了新的治疗药水。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月6日：** 调整后更新了附魔和消耗品。
- **2023年5月1日：** 为10.1版本添加了暗焰缠绕武器附魔，并更新了原初之石宝石说明。
- **2023年3月24日：** 更新了原初之石宝石推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到关于在《魔兽世界》12.1.5版本补丁中使用你的 守护 德鲁伊 挑战大秘境副本的技巧和建议。

1.

### 守护 德鲁伊 在 至暗之夜 第2赛季大秘境中的表现

在本指南中，我们将讨论如何在大秘境副本中充分发挥你的 守护 的潜力，包括最佳的角色配置方式、你的循环可能如何变化，以及最优化使用技能的技巧和窍门。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

守护 德鲁伊 擅长减少受到的物理伤害并平滑伤害承受。我们的AOE异常强大，拉的怪越多，我们就越强。守护 以相当强大的竞争者身份进入 至暗之夜 第2赛季，在其他坦克中表现突出。我们是大秘境中DPS最高的坦克之一，能够输出大量的团队治疗，同时拥有出色的防御能力与之匹配。我们独特的实用工具，如 [[spell:371905]]、[[spell:1126]]、[[spell:2782]] 和 [[spell:20484]] 在副本中极具价值。

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者大秘境天赋构建

2.1.

#### 推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 天赋

两者皆有 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 适用于 **高层大秘境冲层**.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/elunes-chosen.webp>) 艾露恩钦选者 的输出循环相比起 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊 利爪德鲁伊。明月普照 [[spell:204066]] 提供了一个非常强大的技能，可以极其频繁地使用。我们还从皎月呼唤 [[spell:429523]] 获得大量自我治疗，这使得痛击 [[spell:77758]] 更加重要。

总体而言，此构筑在AOE密集的副本中表现出色，特别是你能进行大规模拉怪的地方。

2.2.

#### 灵活天赋

- [[spell:370695]] 可以是一个灵活的点数。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMPwMjZWMLmxMWGY2MMaimZmlZmZmZZMDAAAAAADLzAW2mZwYWGATAAAAbGz8AALmBDGbWAYmBwA"
}
```
:::

:::details 来源计算器编码
```
#oB-Bf0UTTNhKKVAEl64atsldUkYl1jmW8rLM5U-BACgciwGWW0kkQqy74RnBlrCEKKHHxN-AAAA-RGKaYOkYQAI4iA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊 大秘境构筑

2.3.

#### 推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊 天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊 可以提供出色的总体伤害减免和爆发AOE伤害，此外在需要时还能输出略高的单体DPS。

总体而言，此构筑在拉怪规模较小（如3-5只怪）且首领构成更大挑战的副本中表现出色。

2.4.

#### 灵活天赋

- [[spell:370695]] 可以是1个或2个灵活的点数。

我们的天赋树相当灵活，根据你的游戏风格、偏好和情况有多种不同的选择。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CgGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmxsMmZMziZZmxMWGY2MMaimZmlZmZmZZMDAAAAAAzYZGAAAA0MLzyMzMAAWMm5BAWMDGwmFAwMbwA"
}
```
:::

:::details 来源计算器编码
```
#oB-Bf0UTTNhKKVAEl64atsldUkYl1jmW8rLM5U-BACciwGWW0kkQqy74RnBlrCKKHHxNbT-AAAA-QUEYaakEM4owCB-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断

[[spell:106839]] 打断法术施放，并阻止同系法术在4秒内再次施放。迎头痛击 有13码射程，从近战范围外施放会使你冲锋进入近战范围进行打断。注意虽然冲锋动画有行进时间，但打断在你使用技能时就已发生。它是 **强烈推荐** 使用焦点打断宏来完成此操作。

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 迎头痛击
```

这个宏会打断你的焦点目标（如果有），如果没有焦点目标则打断鼠标悬停目标，如果两者都没有则打断你的当前目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**.

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

3.2.

#### 眩晕与"打断"

[[spell:99]] 是你的“AOE停止”技能。它会立即迷惑你周围的所有目标。它对于阻止施法者非常有用，但请记住他们通常会在之后立即重新施法。

[[spell:102793]]可以用来防止怪物到处乱跑或被击飞。

[[spell:132469]] 可以用作额外的停止手段；它会将敌人击退，这可能会造成干扰，所以应该是最后的手段。它可以与 [[spell:102793]] 结合使用，以将怪物保持在相对相同的位置。

### 其他功能

3.3.

#### 其他功能

[[spell:2782]] 移除目标身上所有有害的诅咒和中毒效果。许多副本会施加这类效果，能够驱散它们是一项很棒的实用功能。

[[spell:2908]] 将移除单个敌人身上所有的狂暴效果。

[[spell:339]] 可以定身巡逻的敌人，防止他们进入与你的战斗或完全跳过他们。不过施放它会取消 [[spell:5487]]，所以不要在你正在拉怪时施放它。

[[spell:20484]] 在战斗中复活死亡的盟友。这需要30点怒气，但如果治疗者在战斗中死亡，它会很方便。

[[spell:8936]] 是单体治疗技能。施放它会取消 [[spell:5487]]。

[[spell:106898]] 主要用于室内或战斗中短时间的移动速度提升。它通常用于风筝或从一群怪移动到下一群怪，但它对于帮助朋友快速逃离危险的地面机制也很有用。

[[spell:371905]] 此天赋每消耗300点怒气就会在你周围造成一次巨大的AOE治疗爆发。

[[spell:372119]] 此天赋使你每20-30秒就能对任意一名团队成员进行一次强大的单体治疗。

1.

### 应对词缀

### 词缀：升腾

4.1.

#### 守护 德鲁伊 升腾词缀应对

**萨拉塔斯的交易：升腾** 会定期以波次形式生成一定数量的球体，需要在它们完成施法前以某种方式进行控制。每个成功阻止的球体都会为团队提供急速加成，因此处理它们是高度优先事项。

守护 可以利用 [[spell:99]] 和 [[spell:132469]]，如果瞄准正确，在球体开始生成时可以清除大量球体。

### 词缀：虚缚

4.2.

#### 守护 德鲁伊 虚空束缚词缀应对

**萨拉塔斯的交易：虚缚** 会周期性地召唤一个大型的虚空大使，它将开始施放[[spell:462508]]。这个敌人 **必须** 在施法完成前被击杀以阻止它，否则它会为附近的敌人提供显著的减伤。如果成功阻止，队伍将获得大量的全能和冷却缩减。

需要尽快击杀它，所以当它出现时优先攻击它。作为坦克，我们通常需要留着进攻性冷却技能用于拉怪，但如果你的队伍在对付这只怪物上有困难，你也可以把这些技能用在这里帮忙。

### 词缀：脉冲星

4.3.

#### 脉冲词缀应对指南——守护德鲁伊

**萨拉塔斯的交易：脉冲星** 会生成一个围绕每个玩家旋转的光球，需要由另一名玩家在光球消失前分担。每个光球将为队伍提供4%精通和2%吸血，可叠加，持续30秒。未被分担的光球会增加附近敌人的伤害输出，并降低他们受到的伤害。

守护可以使用[[spell:106898]]来帮助你和你的队伍快速收集这些东西。

### 词缀：吞噬

4.4.

#### 吞噬词缀应对指南——守护德鲁伊

**萨拉塔斯的交易：吞噬** 会对每名队伍成员施加一个减益效果，必须通过驱散或治疗来消除（但请记住这个 <em>不会</em>
吸收即将到来的治疗）。每驱散一个减益效果都会为队伍提供最大生命值和暴击，可叠加，持续30秒。任何被 <em>非</em>
清除的减益效果都会为附近的敌人恢复大量生命值。

我们总是点出清除腐蚀 [[spell:2782]]，可以用它来驱散一到两名队友身上的效果。从熊形态 [[spell:5487]] 变形离开也会移除该效果，因为在至暗之夜 至暗之夜 中为该效果添加了一个小幅度减速。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月12日：** 天赋更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 添加了词缀。
- **2026年3月14日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 添加了副本专属提示。
- **2024年9月9日：** 更新了狂怒之怒的说明。
- **2024年9月7日：** 已更新至地心之战第1赛季开赛。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月23日：** 更新了大秘境配装和介绍说明。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 更新了第3赛季的说明。
- **2023年9月4日：** 更新了大秘境配装和第2赛季关于主流玩法的说明。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月26日：** 添加了无实体注意事项。
- **2023年5月1日：** 更新了10.1的信息并移除了雷鸣效果。
- **2023年3月24日：** 更新了天赋树字符串。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月21日：** 更新了大秘境配置。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到大量实用的宏命令和插件，让你在《魔兽世界》12.1.5补丁中游玩守护德鲁伊时更加轻松。

1.

### 最佳宏

以下是游玩守护德鲁伊时最有用的宏命令。

1.1.

#### 复生

#### 复生宏

```wow-macro
#showtooltip 复生
/cast [@mouseover,help]复生;复生
```

这个宏会对你的鼠标悬停目标施放[[spell:20484]]，如果他们是友方玩家的话。否则，它会对你的当前目标施放复生。

1.2.

#### 清除腐蚀

#### 清除腐蚀宏

```wow-macro
#showtooltip 清除腐蚀
/cast [target=mouseover,help,nodead][target=target] 清除腐蚀
```

使用这个宏会对你的鼠标悬停目标施放[[spell:2782]]，如果他们是友方玩家且未死亡的话。否则，它会施放清除腐蚀。

1.3.

#### 保护祝福取消光环宏

#### 取消保护祝福光环宏

```wow-macro
#showtooltip 痛击
/cancelaura 保护祝福
/cast 痛击
```

这个宏非常实用。它允许你取消可能施放在你身上的[[spell:1022]]，让你能够继续攻击。它也很重要，因为当你处于保护祝福效果下时，小怪不会攻击你，而是会转而攻击仇恨列表中的下一个人（通常是输出职业）。建议将这个宏绑定到多个技能上。

1.4.

#### 实用的鼠标悬停宏

以下是几个允许你对鼠标悬停目标施放技能的宏。

#### 迎头痛击宏

```wow-macro
#showtooltip 迎头痛击
/cast [@mouseover,harm,nodead]迎头痛击;迎头痛击
```

#### 低吼宏

```wow-macro
#showtooltip 低吼
/cast [@mouseover,harm,nodead]低吼;低吼
```

#### 月火术宏

```wow-macro
#showtooltip 月火术
/cast [@mouseover,harm,nodead]月火术;月火术
```

#### 清除腐蚀宏

```wow-macro
#showtooltip 清除腐蚀
/cast [@mouseover,help]清除腐蚀;清除腐蚀
```

1.

### 最佳插件

暴风雪在让游戏无需插件也极具可玩性和功能性方面做得非常出色，因此目前没有推荐的插件。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月23日：** 更新了插件列表和宏命令。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对至暗之夜前夕进行审查。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已针对地心之战前夕进行审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 移除了损坏的野性之心宏。
- **2024年3月20日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已为10.1.5版本更新。添加了DoC宏。
- **2023年4月28日：** 已为10.1更新，移除了旧插件。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
