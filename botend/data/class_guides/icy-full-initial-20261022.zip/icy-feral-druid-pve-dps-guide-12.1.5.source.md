## 专精概览

Welcome to our Feral Druid guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Feral Druid in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Feral Mythic+ Resources

[NEW! Top Feral Talent Builds](<https://raider.io/specs/feral-druid/talents>)

[Top Feral Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/druid/feral>)

[Feral Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=druid--feral>)

[Popular Feral Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=druid--feral>)

1.

### Feral Druid Overview

Feral, the Melee DPS specialization for Druid, fights in [[spell:768]]. It
focuses on strong Physical attacks while maintaining Bleed effects, and has a
more measured combat flow built around resource management.

The gameplay loop is slower than many other melee, often having empty GCDs.
This gives you the time needed to plan around your dual resource system of Energy
that leads into Combo Points. These are then spent to apply powerful Bleed DoT
effects and cast high power finishing moves. As a Druid, it also provides the
[[spell:1126]] buff to increase your group's Versatility.

2.

### Feral Druid Performance Breakdown

Like any spec, Feral has some strengths and weaknesses. Below we've
evaluated it based on some key categories.

**Good Burst Damage Profile**

Feral in Midnight has a lot of its toolkit trimmed down, which is an acquired
taste. Despite that, with the right talent builds it can deal extremely competitive
single-target <em>and</em> AoE damage, even at higher target counts. Its biggest
weakness comes in its inflexibility, often having to make big sacrifices in either
single-target or AoE to lean strongly in one direction. Both [[spell:106951]]
and [[spell:391528]] are strong 2-minute (or 1-minute in some cases)
cooldowns, though Season 2 tuning and the new set shifted some of that power
elsewhere. While it can do well under the right circumstances, this inflexibility
hurts it in content that demands varied damage profiles.

**Strong Burst Single Target**

While Feral does have to specialize to build for pure single-target, optimized
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker builds currently deal strong boss damage. The
issue is that many bosses in The Venomous Abyss have a strong focus
on cleave, which Feral struggles to do efficiently. The extremely
large raid arenas however provide unique appeal from [[spell:106898]],
alongside the other standard Druid utility in [[spell:1126]],
[[spell:20484]] and [[spell:29166]].

**Strong Burst Tools and Uncapped AoE**

In Mythic+ Feral's inflexibility is slightly less punished, allowing builds
to reach a nice middle-ground that lets it focus on the demands of any given pull.
While it's not exceptional enough to shape the Meta itself, with the right
composition it can be very competitive. Using the combination of potent uncapped AoE
with [[spell:285381]] and its burst tools in [[spell:106951]],
[[spell:391528]] and [[spell:1243807]], it often has something
ready for each important pull. Lastly, it brings [[spell:1126]] - a
very high value group buff - and [[spell:20484]] for combat resurrections as
well.

**Versatile Toolkit**

Feral Druid still brings a wide range of more niche utility tools in Midnight.
While they're not <em>always</em> useful, when they are needed it's often quite
valuable. Having both [[spell:132469]] and [[spell:102793]] / [[spell:102359]]
can provide unique crowd control in a given season, alongside [[spell:99]]
for stops. In Season 2, the larger boss arenas and high movement requirements in
The Venomous Abyss also make 1-minute [[spell:106898]] very appealing raid
utility as well. On top of that, it brings [[spell:29166]] as a healer external,
alongside key group buffs in [[spell:1126]] and [[spell:20484]].

**Strong Active Defense Toolkit**

Feral comes with some very strong active defense tools in Midnight, but it
<em>does</em> suffer from fewer passive tools to stay healthy. That means when
navigating more difficult encounters, it **requires** you to be proactive and
have a plan to survive. Between [[spell:22812]] and [[spell:61336]]
there's some strong damage reduction available, and [[spell:5487]] is always
useful if those aren't ready. [[spell:319454]] can also be layered on top
for even more defense should it be needed. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw also provides
extra defensive tools, and enables the use of [[spell:22842]] in
[[spell:768]].

**Extremely High Mobility**

While Feral leans into more traditional movement tools compared to many melee,
what it does have is both potent and frequent. [[spell:768]] provides passive
movement speed at all times (while also removing any slows/roots when shapeshifting),
and [[spell:106839]] pulls double duty as a short charge/displacement counter.
With [[spell:1850]] (or [[spell:252216]]), [[spell:102401]] and
[[spell:106898]] added in, Feral rarely has a problem navigating even the
most punishing encounters.

3.

### Feral Druid in Midnight

### **Season 2**   Changes

3.1.

#### Midnight Patch 12.1.5 Content Guides

While Patch 12.1.5 brings no significant changes to Feral itself, it does
feature new endgame PvE content for you to dive into. Raid groups can take on
[Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) in a new single encounter instance to claim powerful loot, while
[Delves](<https://www.icy-veins.com/wow/delves-guide>) introduce the first Mega-Delve Labyrinth for you to explore! Make
sure to check out information on both new additions below.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

3.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
a Trinket, Ring, and Chest. Additionally, you will be able to upgrade items with 
[[item:280562]] starting October 20th. Weapons, Necks, and Trinkets can all 
be upgraded.

3.3.

#### Class Changes

Feral sees no changes with the release of Patch 12.1.5, although it did receive
numerous hotfixes throughout Season 2. Many of our recommendations remain the same
as before, though some new items sourced from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) have been added
to our gear list, which you can check out
on our [Feral Gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_catform.jpg>) Click for Previous Season 2 Changes
3.4.

#### Season 2 Feral Hotfixes

[Curse of Ula'tek Hotfixes](<https://worldofwarcraft.blizzard.com/en-gb/news/24296142>)

**Feral Druid**

- **October 1st**
  
  - Fixed an issue causing [[spell:391709]] to trigger incorrectly against a single target.
- **September 22nd**
  
  - [[spell:440120]] damage increased by 15%.
  - [[spell:1270592]] now increases Bleed damage by 10% (up from 8%).
- **September 2nd**
  
  - [[spell:5221]], [[spell:22568]] & auto-attack damage increased by 10%.
  - All ability damage increased by 5%.
  - [[spell:1263657]] now prefers targets not immune or taking less than 5% Physical damage.

While Feral has repeatedly received buffs and tuning improvements throughout
Season 2, none of them have really helped it claw itself back up in The Venomous
Abyss, and it still struggles simply due to encounter design. In Mythic+ many of
these changes have helped improve it, but mostly just keep it even with the curve
of other specializations instead of allowing it to break out or switch up builds.

3.5.

#### Patch 12.1 Feral Changes

The arrival of Season 2 brought a large number of changes for Feral, but
most were minor tweaks aimed at opening up some options within the tree. While
not wholly successful in fixing some of its flexibility problems, it has improved
many of the talents that were otherwise lacking or locked in.

[Curse of Ula'tek Development Notes](<https://us.forums.blizzard.com/en/wow/t/midnight-curse-of-ulatek-ptr-development-notes/2317811>)

**Feral Druid**

<em>Developers’ notes: Feral updates in Curse of Ula'tek are aimed at
	talent diversity. We'd like Chomp to be stronger for players who enjoy it,
	and we're adjusting some other talents to get their power closer and open up
	more build options. Much of its AOE damage comes from Rampant Ferocity, which
	it does not take in raid builds. To make it easier to take Rampant Ferocity
	in raid builds we are swapping its position with Merciless Claws in Gate 1.</em>

- All damage dealt increased by 3%.
- [[spell:385786]], [[spell:774]], [[spell:48438]] and
  	  [[spell:8936]] healing increased by 25%.
  
  - <em>Note: this is to offset the increase to players' base health in 12.1.</em>
- [[spell:231063]] & [[spell:391709]] have switched positions on the talent tree.
- [[spell:5221]] & [[spell:213764]] damage increased by 10%.
- [[spell:421432]] bonus damage per point increased to 60% (up from 50%).
- [[spell:1244544]] damage bonus reduced to 15% (down from 20%).
- [[spell:391347]] damage bonus increased to 20% (up from 15%).
- [[spell:391709]] damage increased by 25%.
- [[spell:1244258]] damage increased by 30%.
- [[spell:391881]] base chance to trigger reduced to 4% (down from 5%).
- [[spell:231063]] increases [[spell:5221]] & [[spell:213764]] damage by 25% (up from 20%).
- [[spell:1244532]] increases [[spell:22568]] damage by 8% (up from 2%) but maxes out at 6 stacks (down from 10).
- [[spell:384665]] increases [[spell:22568]] damage by 16% (up from 12%), and an additional 8% during [[spell:5217]] (down from 12%).

Not a great deal changes compared to the gameplay in Season 1, and talents
that were previously strong continue to be. It has, however, improved damage
overall, while also making it much easier to pick up cleave without significant
losses in single-target. The center and bottom of the tree have also seen a lot
of general improvements in terms of power, opening up a lot of options depending
on the situation.

:::

### Midnight   Changes Overview

3.6.

#### Feral Druid Changes in Midnight

With the release of Midnight, Feral sees some fairly significant changes, with
many previously core mechanics being impacted. Snapshotting in particular has been
simplified significantly, while the number of active buttons used has also been
reduced. While some parts remain similar to previous iterations, there are
definitely fewer things to pay attention to - for better or worse. Since these
changes have a fairly large impact on how the Spec operates, changes are broken
down into sections below.

3.6.1.

##### Rotation & Talent Changes

Feral saw some sweeping changes to snapshotting mechanics and how they relate
to Bleeds. Most notably, [[spell:319439]] has been removed and
[[spell:384667]] has been reworked, so the <em>primary</em> source of Bleed
amplification is [[spell:5217]]. This means there's a lot less debuff
juggling, and it's easier to execute.

Additionally, a few specific changes have been made in the tree:

- [[spell:106830]] and [[spell:202028]] have been removed from the tree.
- [[spell:1244258]] has been added as a high damage attack available at certain
  Energy thresholds.
- [[spell:274837]] has had a follow-up node added - either reducing its cooldown
  to 30 seconds with [[spell:1244544]], or converting it to AoE with [[spell:1243807]].
- [[spell:391548]] now reduces the cooldown of [[spell:102543]] to 1m30s.
- [[spell:1244532]] and [[spell:1244547]] added, providing bonuses
  from [[spell:1079]] in AoE.

3.6.2.

##### Feral Apex Talent - Unseen Predator

The new class feature in Midnight is Apex Talents, powerful 4-step talent nodes
that provide compounding benefits when taken. For Feral, [[spell:1263657]]
focuses on amplifying finishers, increasing damage dealt and triggering bonus
attacks:

- [[spell:1263657]] — [[spell:22568]] has a 15% chance per
    Combo Point spent to trigger [[spell:1271863]] or [[spell:1263903]],
    depending on targets nearby. Damage is reduced if fewer than 5 Combo Points and
    50 Energy were spent to activate.
- [[spell:1263658]] — has two points, increasing all damage you
    deal by 7.5% per point for 1 second per Combo Point spent when an Unseen Attack
    is triggered via [[spell:1263657]]. Extra attacks will extend the
    duration.
- [[spell:1263660]] — increases all [[spell:1079]] damage you deal
    by 30%. Additionally, casting [[spell:5217]] will cause your next two
    Combo Point generating attacks to trigger an Unseen Attack for its maximum
    damage.

The entire package is quite strong, buffing finishers that lie at the heart of
both builds. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker in particular gets great benefit from the
extra [[spell:1079]] multiplier, which also improves both trees significantly in
AoE. The effect is, however, mostly passive and happens through regular gameplay.

3.6.3.

##### Hero Talent Changes

While the spec saw some sweeping changes at its core, Hero Talents remain very
similar to how they were before. Some additional integration has been added to new
talent options, but their damage profile split remains the same. Below is a brief
overview of the changes:

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) **Druid of the Claw Changes -** <em>Click for Details</em>
  
  
  - [[spell:441846]] now increases the damage of [[spell:274837]] and [[spell:1244258]] by 25%.
  - [[spell:441845]] now increases damage abilities by 10% and Critical Strike chance by 5%.
  - [[spell:441835]] now has a 20% chance to activate (down from 25%).
  - **Three new talents:** [[spell:1271540]], [[spell:1271635]] and
    	  [[spell:1271839]].
  
  
  
    The changes to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw provide additional access to [[spell:441583]],
    while trying to still keep some value from Bleed effects via new talents. In
    particular, [[spell:441846]] has been made more appealing by amplifying
    both the new [[spell:1244258]] and [[spell:274837]], but is otherwise built in
    the same way as before: a focus on high-impact [[spell:22568]]
    enhancements.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) **Wildstalker Changes -** <em>Click for Details</em>
  
  
  - **Three new talents:** [[spell:1270592]], [[spell:1270586]] and
    	  [[spell:1270565]].
  
  
  
    As for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker, very little was changed about the tree,
    retaining its strong focus on Bleeds and DoT effects. New talents incorporate a
    stronger focus on [[spell:440120]] by adding a passive chance for it to
    trigger from [[spell:439531]], but it still remains a fairly simple
    passive tree.

3.6.4.

##### Utility & Defense

In both the utility and defensive department, Feral remains very similar to The
War Within, aside from the loss of [[spell:124974]]. In exchange, [[spell:319454]]
was turned into an active defense tool - increasing your maximum health by 30% if
used during [[spell:5487]]. The Midnight utility toolkit is also effectively
the same, bringing [[spell:132469]], [[spell:102793]] and
[[spell:99]], while still having [[spell:29166]] for your healers.

4.

### Basics of Feral Druid Gameplay

While previously Feral was cited as one of the more complex specs to get started
with due to its overlapping components, Midnight has significantly reduced some of
the requirements for management. It does have some unique aspects to get used to,
but its pace is generally slow enough to give you the time to think through your
decisions and navigate its methodical gameplay loop. Three core rules it operates
on are:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mount_jungletiger.jpg>) **Manage Energy**  
  
    Feral uses Energy that regenerates passively, or actively with tools such as
    [[spell:5217]]. This is spent on "generators" such as [[spell:5221]],
    which build Combo Points, used to fuel "finishers".
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_ferociousbite.jpg>) **Don't Waste Combo Points**  
  
    After building to 5, these are spent on "finishers", such as [[spell:1079]] and
    [[spell:22568]]. Try not to spend early, but <em>never</em> waste any
    by going above 5. These are your core damage dealing tools.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_ghoulfrenzy.jpg>) **Maintain Bleeds**  
  
    Managing Bleed effects is central to Feral, and they always need to be applied.
    [[spell:1822]] is a generator, and [[spell:1079]] is a finisher. Plan your resource
    cycles around having these up 100% of the time.

These rules give Feral a more measured gameplay feel, requiring you to
judge the flow of your two resources while making sure that you can always
maintain these DoT effects. As you get used to that cycle, you'll learn to identify
places where you have some to spare for high cost [[spell:22568]] casts
without risking uptime. While the various conditions can be overwhelming at first,
the slower pace and intuitive rules create a fluid, rewarding gameplay style that's
unique to Feral once you get the hang of it.

5.

### How to Gear Up as a Feral Druid

While we always recommend simming yourself for ideal results, we do provide a
dedicated Feral gearing page. We currently cover recommendations for
Season 2 gear to start off on the right foot when stepping into endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Confirmed gear list, adjusted weapon enchants, emphasized early weapon crafts & expanded FAQ about ideal early power off-pieces.
- **24 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Switched weapon enchant to Rite of the Hash'ey and expanded Potion section.
- **19 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Added disclaimer regarding uncertain gear recommendations due to Aqirbane Reliquary hotfixes.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **30 Jun. 2026 (this page):** Updated for 30th June tuning hotfixes.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7 with Sporefall gear.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7 with Omnium Folio recommendations.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **07 Apr. 2026 (this page):** Adjusted Raid performance to better reflect current representation.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Added note about Heirlooms in Midnight.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated with full Season 1 recommendations.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Season 1 - added Teas and additional Consumables for Mythic+.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for release of Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Season 1 release.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for release of Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for release of Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for release of Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for Midnight release.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Midnight release.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Updated for Midnight release.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Midnight release.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Midnight release.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight release.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Midnight release.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Midnight release.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Midnight release.
- **26 Feb. 2026 (this page):** Updated for Midnight release.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for new Class Tree talent gates.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for new Class Tree talent gates.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for new Class Tree talent gates.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for new Class Tree talent gates.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5 with Cartel Chip recommendations.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **03 Sep. 2025 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Shifted Haste slightly above Versatility in AoE.
- **03 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated to emphasize recommendations are with the new Tier Set.
- **28 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Added Mythic+ Utility Talent cheat sheet for use cases in each dungeon.
- **16 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated Trinket tier list to cover additional tuning.
- **12 Aug. 2025 (this page):** Updated to include Season 3 hotfix buffs.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated to account for D.I.S.C. hotfixes.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7 D.I.S.C. belt and adjusted BiS list slightly for double Gallywix weapon.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Confirmed Dinar recommendations for Turbo Boost release.
- **12 May 2025 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated following Corruption tuning.
- **12 May 2025 (this page):** Added note to highlight updated Cartel Chip and Corruption recommendations.
- **28 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Added individual dungeon tips.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.1.5 and added Cartel Chips section.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-liberation-of-undermine-raid-guide>)):** Updated for live releases of bosse and Gallywix tips.
- **16 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Fixed incorrect Wildstalker single target import codes.
- **03 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated Circe's Circlet and some trinket recommendations.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated to highlight strength of new ring following hotfixes.
- **17 Dec. 2024 (this page):** Updated to highlight strength of new ring following hotfixes.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7 for Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.7, added recommended tags.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.0.7, corrected Druid of the Claw tree link and added recommended tags.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.7, added recommended tags.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.7 with recommended tags.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Patch 11.0.7 with much simpler basic rotation section.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5, moved Mad Queen's Mandate to recommended.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5. Added some notes regarding Regrowth shapeshift macro.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Updated for Patch 11.0.5, separated hotfixes into its own section.
- **30 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-nerub-ar-palace-raid-guide>)):** Updated with appropriate builds and more recent tips for all bosses.
- **30 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Changed default loadout to Wildstalker ST to align with talent page.
- **30 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated single-target recommendation to Wildstalker.
- **30 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Switched single-target recommendation to Wildstalker.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated with Season 1 BiS lists.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Added note for Speed Blasphemite.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-nerub-ar-palace-raid-guide>)):** Page added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for War Within Season 1 release.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for recent Bloodtalons hotfix and Druid of the Claw recommendation.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for recent Bloodtalons hotfix and Druid of the Claw recommendation.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for recent Bloodtalons hotfix.
- **09 Sep. 2024 (this page):** Updated for recent Bloodtalons hotfix.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/feral-druid-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/feral-druid-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/feral-druid-mists-of-pandaria-remix-guide>)):** Page added.
- **13 May 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Format adjustment to move slider closer to rotation.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Season 4 and Awakened gear release.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Season 4 release.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 4, no gameplay changes but restructured page for readability.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Season 4, slight touch ups but no major changes to builds.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Season 4 with small talent changes.
- **22 Apr. 2024 (this page):** Updated for Season 4 release.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 10.2.5, no updates necessary.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5, highlighted Ashes of the Embersoul as equal to Witherbark's.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5, no changes necessary.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5, changed food recommendation to secondary food.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5, no changes necessary.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5, shifted recommendation to Convoke and added note regarding 2-minute trinkets.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5, moved Convoke to the primary button, added AoE opener switches.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5, moved Convoke build to recommended for single target.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5, no changes necessary.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5, no changes necessary.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5
- **10 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Restructured and updated for Patch 10.2.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated to remove Sporecloak recommendation, switched Toxic Thorn/Toxic Patch.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 10.2, small tweaks to pathing and switch to Convoke.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Added Innervate macro for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated link to Mythic+ hub.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2 and restructured the rotation tool.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2 with new builds.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Patch 10.2 talent changes.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Restructured for Patch 10.1.7, information remains the same.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Adjusted wording slightly to show Crit, Haste and Mastery all reach equality with gear.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7, changed recommended build to a more Rake focused one.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Restructured for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.7, small restructuring to some sections but same recommendations.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for Patch 10.1.5 and added Dire Fixation.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5 with megadungeon gear, and clarified crafting section.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5, small note about Gem alternatives.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Patch 10.1.5, moved Haste and Mastery to equal.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.5 and added Dire Fixation to build.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5, small tweaks and notes about Dire Fixation AoE.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Re-added Hybrid build, reworded some segments and also highlighted importance of Dire Fixation.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Patch 10.1.5 to include Dire Fixation.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **25 May 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Added section on Cataclysm Timewalking.
- **09 May 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated to account for Trinket changes.
- **09 May 2023 (this page):** Updated to highlight boss tips and Gear updates.
- **04 May 2023 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated to swap to Thrashing Claws.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1 and Season 2 release with new gear recommendations.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.1 for new enchants available.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1, small build changes and added new Affix details.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1 to include new Berserk changes and updated builds.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1 to include new Patch 10.1 changes and build options.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Patch 10.1 talent changes.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 10.1, slightly updated build due to new talent options.
- **29 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.1, no changes necessary.
- **29 Apr. 2023 (this page):** Updated for Patch 10.1 changes, added new highlight sections and expected performance.
- **24 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Primordial Gemstones hotfixes.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Primordial Stones hotfixes.
- **22 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **22 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated to account for Primordial Stone buffs.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated to account for Primordial Stones hotfix.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/feral-druid-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.0.7 with Onyx Annulet recommendations.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed and updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed and updated for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7.
- **29 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for new tree pathing.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Added some additional mouseover and talent macros.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Updated for Patch 10.0.5.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/feral-druid-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/feral-druid-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/feral-druid-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **20 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/feral-druid-patch-9-2-changes-analysis>)):** Cleaned up ready for Patch 9.2 launch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/feral-druid-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/feral-druid-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **17 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/feral-druid-patch-9-1-changes-analysis>)):** Page created with initial information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **03 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-crucible-of-storms-raid-guide>)):** Updated with notes for each boss.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **03 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-uldir-raid-guide>)):** Updated for patch 8.1 with disclaimer about information being unclear currently.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-uldir-raid-guide>)):** Updated for preliminary Uldir release.
- **11 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-uldir-raid-guide>)):** Page created (empty for now) in preparation for the eventual Uldir release.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Feral Druid leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Druid leveling guide](<https://www.icy-veins.com/wow/druid-leveling-guide>).

1.

### Feral Druid Leveling Guide for Midnight

Welcome to our Feral Druid Leveling Guide for
Midnight! This will help you in your journey to max level,
covering talents and abilities you should know about.

Feral Druid is extremely mobile, giving it the advantage
while questing of moving point-to-point quickly. It comes with a strong AoE toolkit
you get access to early, but as much of it is dealt over time, you may need to take
some care to avoid being overwhelmed. It's also well suited to dungeons for the
same reasons, though you may find your queue times are faster if you do so as
Guardian to tank.

1.1.

#### Leveling Gear Options

Item level is always more important than individual stats when leveling up. Always
choose the piece of gear with the highest item level. Items with Speed tertiary
stats can help speed up your leveling, especially during parts of extended time
spent indoors. Heirloom gear is also useful while leveling, allowing you to ignore a lot
of gearing for a large part of your leveling journey.

1.2.

#### Useful Leveling Consumables for Midnight

If you're looking for that extra boost to get through Midnight leveling and
catch up to endgame, there's a handful of items and enchants that can help speed
things up.

- [[item:191348]] — A Phial from [Dragonflight](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  which persists through death, giving bonus Speed for 30 minutes. If you're already
  geared, it's often about moving between pulls rather than a bit more damage.
- [[item:225592]] — A food item from [The War Within](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>),
  grants a large boost to Speed for 1 hour, but is lost on death.
- [[item:213746]] — If your gear has plenty of sockets, switch
  to this Algari Diamond and each of [The War Within](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)'s gem colors
  for extra speed.
- [[item:223653]] / [[item:223683]] / [[item:223725]] / [[item:223800]] —
  Switch all of your armor enchants over to extra Speed effects if you were previously
  using Avoidance or Leech.
- [[item:132516]] — A tried and true pickup for leveling, these are always
  nice to have to get through areas where you can't mount, and even work across water.
  These <em>can't</em> be activated while in combat though, and are cancelled when
  taking damage.
- [[item:109076]] — These can mitigate fall damage if you end up
  getting dismounted or need to get down from somewhere high without the ability to
  use [[spell:165962]], so are great for emergencies.

2.

### Leveling Talents

**等级 1–9：**During levels 1 to 9, you will not have activated the
Feral specialization and, as such, will have to spend the first 4 levels in Caster
form using [[spell:5176]] and [[spell:8921]]. After acquiring [[spell:768]]
at level 5, you can make use of [[spell:5221]]. When you reach Level 7, you can
then spend the Combo Points it generates on [[spell:22568]].

**等级 10 起：**

At Level 10, when you select the Feral specialization you will immediately gain
access to both [[spell:1822]] and [[spell:1079]], your core Bleed effects. These are
applied with Energy and Combo Points respectively, and should always be maintained
against targets. Your main Combo Point builder is [[spell:5221]] in single-target,
and [[spell:213764]] in AoE.

Your talents can be changed anywhere in the world as long as you are out of
combat. Be sure to explore various combinations of talents while leveling
to get a feel of the gameplay flow. We have provided a sample leveling path below
that balances core mechanics and complexity.

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Feral Leveling - Level 80 Starting Talents
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMDzMmZmZmNjtZ2mZmZegZGAAAA2CGGGzMqZMLjZmZMmBAAAAAAGYAAAAkxsMmZAALgZGgFGMAAAmZDA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMDzMmZmZmNjtZ2mZmZegZGAAAA2CGGGzMqZMLjZmZWGzMAAAAAAYgBAAAQzsMLzMzAAWAzMALMYAAAMzGGA"
}
```
:::

:::details 来源计算器编码
```
#nB-fTTOM0NhAl6ErssRkxd02qoIrp9al960z4I-kgfijKOhedEQScNMTLfi220mhdtKBpA-AAAA-YauQIYUQJB5IYA-
```

:::

2.1.

#### War Mode Talents for Leveling

In this section, we will rank the PvP talents best for
leveling and doing solo / small group PvE content. Below is a ranking of Feral
Druid-specific PvE talents.

1. Pick [[spell:203224]] first, provide additional
   burst to targets when applying your [[spell:1822]] effect since you always open
   from [[spell:5215]] with this.
2. **等级 30 起：**Pick either [[spell:202626]] or [[spell:236020]].
   The former grants movement speed and heals you when you Critically Strike, while
   the latter improves [[spell:22568]] damage via maximum health reduction.
3. **等级 40 起：**Either pick the option you didn't from the previous
   two, or [[spell:205673]]. This reduces the cooldown of [[spell:5217]]
   when you successfully interrupt, which helps with more frequent cooldown uses.

Other options are much more focused on enemy
control, which is more oriented around PvP gameplay, rather than killing
enemies more efficiently, so they are not recommended.

3.

### Leveling Rotation

To help with understanding what changes as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 71 起：**After reaching level 71 and unlocking Hero Talents,
we recommend playing with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw to gain access to
[[spell:441583]].

3.1.

#### Key Concepts

As you level up and populate the talent tree, Feral gains access to
additional tools to navigate the world outside of just its rotation. This section
will grow alongside the slider with each level.

- **Remember to Recuperate!** - Whenever you're low on health between pulls,
   you can use the [[spell:1231418]] ability available to all classes to
   quickly recover.
- **等级 1–9：****Reach Level 10 First** - Due to Feral only
   being unlocked as a talent specialization at Level 10, you should use the
   abilities provided to you in the intro quests until you are presented with the
   option.
- **等级 10 起：****Don't forget, you're a Cat!** - Feral <em>requires</em>
  [[spell:768]] to use its abilities, so always be shapeshifted!
- **等级 10 起：****But... also a Bear** - [[spell:5487]] is very
   durable, so shift if you're in a <em>really</em> bad situation.
- **等级 10–16：****Remember other Shapeshifts** - [[spell:783]]
   significantly increases movement speed while outdoors, so switch to this when
   moving between areas. You can even interact with objects and gather materials
   without canceling!
- **等级 17–19：****Remember other Shapeshifts** - [[spell:783]]
   increases movement speed while outdoors, so switch to this when moving between
   areas. This dynamically switches to [[spell:276012]] in water. Both of these
   forms can even interact with objects and gather materials  without cancelling!
- **等级 20 起：****Remember other Shapeshifts** - [[spell:783]]
   increases movement speed while outdoors, so switch to this when moving between
   areas. This dynamically switches to [[spell:276012]] in water, and
   [[spell:165962]] if out of combat. All of these forms can even interact with
   objects without cancelling!
- **等级 13 起：****Sneak up on enemies** - Try to always start
   combat from [[spell:5215]] to take advantage of the bonus to [[spell:1822]]
   from [[spell:390772]]. You can also use this to avoid combat if you just
   want to sneak past!
- **等级 30 起：****Use your self-healing** - [[spell:16974]]
   causes [[spell:8936]] to be instant after spending Combo Points, so remember
   to make use of this whenever you're in danger.

**等级 10 起：**3.2.

#### **等级 10 起：**Dynamic Priority List

Below is a sample priority list to keep track of which abilities to press.

1. **等级 1 起：**Make sure to always be in [[spell:768]].
2. **等级 1 起：**Enter [[spell:5215]] before opening on your target whenever possible.
3. **等级 1 起：**Open with [[spell:1822]] from stealth.
4. **等级 31 起：**Cast [[spell:106951]] on dangerous elites or large groups of enemies.
5. **等级 59 起：**Cast [[spell:391528]] on dangerous elites or large groups of enemies.
6. **等级 63 起：**Cast [[spell:22568]]**等级 71 起：** / [[spell:441583]] with [[spell:391881]] procs.
7. **等级 11 起：**Cast [[spell:5217]] on cooldown.
8. **等级 61 起：**Cast [[spell:1243807]] on cooldown, especially during AoE.
9. **等级 59–60：**Cast [[spell:274837]] on cooldown.
10. **等级 13 起：**Cast [[spell:285381]] at 5 Combo Points against multiple targets to apply [[spell:1079]].
11. **等级 1–12：**Apply [[spell:1079]] to any high health targets at 5 Combo Points if it is not already present.
12. **等级 13 起：**Apply [[spell:1079]] at 5 Combo Points in single target.
13. **等级 1 起：**Cast [[spell:22568]]**等级 71 起：** / [[spell:441583]] at 5 Combo Points.
14. **等级 65 起：**Cast [[spell:1244258]] on cooldown against one target.
15. **等级 1 起：**Maintain [[spell:1822]].
16. **等级 1 起：**Cast [[spell:213764]] to generate Combo Points against multiple targets.
17. **等级 1 起：**Cast [[spell:5221]] to generate Combo Points against one target.

**等级 10 起：**3.3.

#### **等级 10 起：**Survival Tools

**等级 10 起：**Feral has a handful of defensive tools available to deal
with overwhelming situations, so remember to make use of them if you're in
danger:

- **等级 10 起：**[[spell:5487]] is Feral's "tank mode", so if
    you're in a bad spot this will buff your defense significantly.
- **等级 10–28：**[[spell:22812]] has both a long duration and short
    cooldown, providing damage reduction. Not only is it off the GCD, but you can
    use it in any form, so it's always available in an emergency.
- **等级 29 起：**[[spell:22812]] has both a long duration and short
    cooldown, providing damage reduction. Not only is it off the GCD, but you can
    use it in any form, so it's always available in an emergency. When things are
    <em>really</em> dire, the much longer cooldown [[spell:61336]]
    gives a massive 50% reduction as well.
- **等级 10–25：**Sometimes it's just best to run away using either
    [[spell:1850]] to sprint away, or switching to [[spell:783]] if you're
    outdoors.
- **等级 26–37：**Sometimes it's just best to run away using either
    [[spell:252216]] to sprint away, or switching to [[spell:783]] if you're
    outdoors.
- **等级 38 起：**Sometimes it's just best to run away using either
    [[spell:252216]] or [[spell:106898]] to sprint away, or switching to
    [[spell:783]] if you're outdoors.
- **等级 15 起：**[[spell:390772]] causes [[spell:1822]] to stun
    your target for 4 seconds when used from stealth, giving you the opening
    advantage each pull.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Added note about Heirlooms in Midnight.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for new Class Tree talent gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **13 May 2024:** Format adjustment to move slider closer to rotation.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, no updates necessary.
- **06 Nov. 2023:** Reviewed for Patch 10.2, small tweaks to pathing and switch to Convoke.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated for Patch 10.1.5 and added Dire Fixation.
- **04 May 2023:** Updated to swap to Thrashing Claws.
- **01 May 2023:** Reviewed for Patch 10.1.
- **22 Mar. 2023:** Reviewed for Patch 10.0.7.
- **29 Jan. 2023:** Updated for new tree pathing.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Feral Druid in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Feral Druid

Welcome to our Easy Mode Page! This section is intended for players who are new
to the game or class, have no intentions of raiding Mythic difficulty, and want a
straightforward rundown of how the specialization plays without the overwhelming
priority details needed for optimal play.

Feral is often considered intimidating at first glance, due to having two
resources and multiple debuffs to maintain. In Midnight, things are a bit simpler,
and on this page we'll be breaking it down into steps that will hopefully make it
easier to grasp. At its most simple, there are three key rules the rotation is
built around:

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_chargepositive.jpg>)
   **Manage Energy**  
  
  	This regenerates passively, and [[spell:5217]] also grants you a large
  	amount when used. Spend this on "builder" spells to generate Combo Points. This
  	is spent on [[spell:5221]] in single-target, and [[spell:213764]] in AoE.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_ferociousbite.jpg>)
   **Don't Waste Combo Points**  
  
  	These are generated by your "builders", and have a cap of 5. They are spent on
  	"finishers", which spend all your Combo Points (and some Energy). Always maintain
  	[[spell:1079]], and otherwise spend with [[spell:22568]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_ghoulfrenzy.jpg>)
  **Maintain Bleeds**  
  
  	Feral has two Bleeds to maintain at all times. [[spell:1822]] is a "builder", and
  	is easy to keep up. [[spell:1079]] is a "finisher", and requires you to plan
  	around having enough Combo Points available to refresh.

The best approach to learning Feral starts with your resources. Knowing the ebb
and flow of Energy is the best foundation to have, as it sets the pace for the entire
rotation. After that, having a good feel for the cadence of your Combo Points
eases you into Bleed management, and once you mix them together you'll have
everything you need to play Feral comfortably!

While on this page we'll be breaking things down in a more digestible way, the
builds recommended will still mirror the most popular loadouts used in endgame.
There are some variations that can lower the execution requirements slightly, but
getting used to common playstyles will give you the best impression of how Feral
operates.

In Midnight Season 2, Feral plays as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker in single-target
and cleave situations, so it's the preferred pick in Raids. In AoE situations however,
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw comes out on top, so is played in Dungeons, Mythic+ and
Delves.

2.

### Beginner's Guide to Feral Druid in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker   Raid Build

2.1.

#### Single-Target Talents for Feral Druid

In Raids, Feral plays as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker, sacrificing some of its AoE
capabilities to focus on dealing as much damage to one target as possible. These
builds are focused around DoT effects, so maintaining Bleeds effectively is very
important. Since much of The Venomous Abyss features cleave, the build we've
provided includes some multi-target picks to suit it better.

The Hero Tree provides passive bonuses, so doesn't significantly alter the
rotation. It does, however, play [[spell:155580]], which adds [[spell:8921]]
as an extra DoT to maintain. It has [[spell:106951]] every 2 minutes,
[[spell:391528]] every 2 minutes, and [[spell:274837]] every 30 seconds
for burst cooldowns.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMGz2yYZsNjZmHYmBAAAgtgZzwYmRNjZZmZmZMmxAAAAAAwADAAAAAwsNzSzyMLbgZeAgFzgBAwMDAGA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9Vs8FGJ-kgijBKOfhQST58KFIWaYq22MmQBTbxF-AAAA-BEIcApJ4gRiCmF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw   Dungeon & Delve Build

2.2.

#### Mythic+ Talents for Feral Druid

With Mythic+ being more focused on AoE, Feral switches to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw
due to its better hybridizing for multi-target. This has a stronger focus on
[[spell:22568]], using [[spell:285381]] to apply [[spell:1079]] in AoE
and trigger [[spell:391709]].

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw also adds in [[spell:441583]] procs to empower
[[spell:22568]] further, alongside having [[spell:391881]]
procs to react to for instant, free Bite casts.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QT7cl9lMmHSV-kgijBKOfQST58KFIWaGYq22Mmgpt4aG-AAAA-EMQUYaGMgoQyyB-
```

:::

### Single-Target & AoE   Rotation Breakdown

2.3.

#### Beginner Feral Druid DPS Rotation

Before entering combat, always make sure to do the following:

- **Be in Cat Form -** [[spell:768]] is required to cast most Feral
    abilities, so always be shapeshifted.
- **Cast Group Buffs -** Use [[spell:1126]] to buff your party
    with Versatility.
- **Start from Stealth -** [[spell:5215]] improves your
    first [[spell:1822]] when you break stealth.

2.4.

#### Single Target Breakdown

In single-target, Feral is all about balancing its resources to maintain full
[[spell:1079]] uptime with as little investment as possible, so it can free up extra
Combo Points to cast [[spell:22568]]. Here's a brief breakdown of things to
keep in mind to get you started:

- **Spend Energy to Build Combo Points**  
  
  	Spend Energy on builders to reach 5 Combo Points, and avoid overcapping.  
  
  <em>Combo Point Builders</em> – [[spell:5221]], [[spell:1822]], [[spell:8921]] and [[spell:274837]].
- **Spend Combo Points Efficiently**  
  
  <em>Always</em> make sure to spend with a finisher when at 5 Combo Points.  
  
  <em>Priority</em> – [[spell:1079]] if it's missing, otherwise [[spell:22568]].
- **Maintain DoTs**  
  
  	Make sure [[spell:1822]], [[spell:8921]] and [[spell:1079]] are always applied to your target.  
  
  	Refresh these during [[spell:5217]] if possible to snapshot the effect.
- **Use Cooldowns**  
  
  	Cast [[spell:5217]] every 30 seconds followed by [[spell:274837]].  
  
  	Cast [[spell:106951]] paired with [[spell:391528]] every 2 minutes.

The best approach to learning Feral is to break things up into chunks. Each
component of the resource management game you master makes it easier to adjust to
the flow, and build an intuition on when to refresh. We recommend doing it in these
steps:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_catform.jpg>) **Feral Single-Target**
**Energy/Combo Point Management**

➜

**Bleed Uptime**

➜

**Cooldown Sequencing**

:::

2.5.

#### AoE Breakdown

In AoE, Feral uses [[spell:285381]] to apply [[spell:1079]] to all nearby
targets. This is used to trigger free [[spell:22568]] casts via
[[spell:391881]], which in turn activates [[spell:391709]]:

- **Spend Energy and Combo Points**  
  
  	Generate using [[spell:1822]] to apply Bleeds, otherwise [[spell:213764]] to 5 Combo Points.  
  
  	Finish with [[spell:285381]] to maintain [[spell:1079]], spend excess on [[spell:22568]].
- **React to Procs**  
  
  	Spend [[spell:391881]] procs immediately, provided [[spell:1079]]s are active.  
  
  	Always cast [[spell:441583]] with 5 Combo Points, again with Rips active.
- **Sync Your Cooldowns**  
  
  	Cast [[spell:5217]] every 30 seconds, and [[spell:1243807]] every 45 seconds.  
  
  	Cast [[spell:391528]] every minute. Line up [[spell:106951]] with it every 2 minutes.

While Feral follows similar principles in AoE, it's best to tackle the AoE
playstyle <em>after</em> getting a handle on single-target - it follows the same
basic ruleset, just with extra wrinkles. We advise the following:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_catform.jpg>) **Feral AoE**
**Resource Management**

➜

**[[spell:285381]] Uptime**

➜

**Reacting to Procs**

:::

2.5.1.

##### Apex Talent: ![Unseen Predator Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_druid_unseenpredator.jpg>) Unseen Predator

All builds spend four points in the Apex Talent, [[spell:1263657]], which
triggers additional strikes when using [[spell:22568]]. This provides good
extra damage throughout an encounter and buffs your other abilities, but is mostly
passive - there are no significant gameplay requirements to execute it properly
outside of the standard rotation. The only important thing to remember is that it
reinforces the goal of only spending at 5 Combo Points.

2.5.2.

##### Season 2 Tier Set

Season 2 of Midnight introduces the **Bark of the Enigmatic Dreamwatcher**,
available from different endgame content. This provides the following bonuses:

- [[spell:1296605]] – When [[spell:106951]] ends, you
  	deal 10% increased damage for 1 second per Combo Point spent during Berserk.
- [[spell:1296606]] – [[spell:106951]] lasts 10
  	seconds longer.

While both of these bonuses are certainly impactful during gameplay, there's
nothing unique that needs to be done to optimize them. Your [[spell:106951]]
duration is longer, and you have an extra incentive to cycle Combo Points efficiently,
but otherwise Feral still plays in the same way as without it.

### Survival Tools &   **Defensive Spells**

2.6.

#### Defensive Spells for Feral Druid

Feral has access to a variety of different active and passive survival tools,
giving it a lot of flexibility when dealing with incoming damage.

- **[[spell:22812]] -** provides a 30% damage reduction for 12 seconds (with
  [[spell:449191]]), on a 1-minute cooldown. This is Feral's consistent defense tool,
  and, due to the low cooldown, can be used liberally to reduce the incoming damage
  from dangerous attacks.
- **[[spell:61336]] -** grants 60% damage reduction (with [[spell:449191]])
  for 6 seconds. This is a backup defensive tool for the most dangerous damage
  events, or when [[spell:22812]] is not available.
- **[[spell:5487]] -** provides a significant increase to health and armor
  when active. While your damage tools are very limited while in this form, you can
  switch to this quickly without any cooldown, allowing you to survive a lethal hit
  then heal back up after.
- **[[spell:319454]] -** has a 2-minute cooldown, and if used during
  [[spell:5487]] increases your maximum health by 30% for 20 seconds. This persists
  even if you shapeshift out of it, making it a powerful additional defensive option
  that can be layered on top of other tools.
- **[[spell:377847]] -** this triggers [[spell:22842]]
  when you drop below 40% health, healing you for a large amount. This has a 120-second cooldown (90 with
  [[spell:1213597]]), and can save you in a pinch. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw
  can also cast Frenzied Regeneration in [[spell:768]] for the same
  effect, at the cost of 40 Energy and a 36-second cooldown.
- **[[spell:16974]] -** triggers from Combo Point spenders, and
  makes your next [[spell:8936]] cast instant. These can be used in empty globals
  to help keep yourself healthy.

### Gearing &   **Stat Priority**

2.7.

#### Feral Druid Stat Priorities

The most versatile Feral stat priority for different situations in
Midnight is as follows. For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>).

Agility

Mastery

Haste

Critical Strike

Versatility

Stat priorities will change based on other talents taken in different builds,
but, in general, this should serve you well.

2.8.

#### Gearing a Feral Druid

When it comes to gearing in Midnight Season 2, you want to
prioritize your Tier Set as quickly as possible. Due to how many different
options are available when it comes to gearing your character though, it's best to
jump over to our main [Gearing page](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)
for a more comprehensive breakdown on things to chase.

### Blizzard   Rotation Assist

2.9.

#### Blizzard Rotation Assist for Feral Druid

Added in The War Within, the Rotation Assist tool curated by Blizzard has
two modes: the first highlights action bar buttons with a recommended priority,
while the second provides a single keybind that automatically presses the
top priority ability on that same list, but with a 25% GCD penalty between
casts.

This provides a great starting point if you're just jumping into Feral and
want to get a general feel for the gameplay flow it has. It does, however, come
at a performance loss due to some limitations. Most importantly, the tool
will **not** use [[spell:106951]], racial abilities or on-use
trinkets - these all need to be cast manually by you if you use it. This also
extends to movement, defensive and crowd control abilities.

The tool will generally manage DoTs to a reasonable degree, and since Feral has
more downtime than average, the GCD penalty isn't as harsh as elsewhere. The lack
of cooldown use does mean you'll need to use these manually - in particular
before it opts to cast [[spell:391528]], but otherwise it's well suited
to both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw builds provided on
this page.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for release of Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for new Class Tree talent gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **03 Sep. 2025:** Updated to emphasize recommendations are with the new Tier Set.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7 with much simpler basic rotation section.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **30 Sep. 2024:** Switched single-target recommendation to Wildstalker.
- **09 Sep. 2024:** Updated for recent Bloodtalons hotfix.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4 with small talent changes.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, no changes necessary.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated for Patch 10.1.5 to include Dire Fixation.
- **01 May 2023:** Reviewed for Patch 10.1, slightly updated build due to new talent options.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Feral Druid in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Talents for Feral Druid in Midnight

Feral maintains a similar Hero Tree split in Midnight, but in Season 2 there's
a lot of overlap in both throughput and damage profiles. Both are tuned
extremely close together, and make use of many of the same talents. The only thing
that really separates them is a combination of flexibility and defense.
Our current recommendations depending on content are as follows.

- **Raid / Single Target -**
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw are both close in
  	single-target, and sport similar damage profiles. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker
  	has an easier time transitioning to low-target cleave though, which suits it
  	better to The Venomous Abyss.
- **Mythic+ / AoE -**
      Again, in AoE both trees have fairly similar damage, though ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw
  	takes advantage of the [[spell:1244532]] buff more, so it sacrifices
  	less priority damage. With its <em>slightly</em> lower execution requirement
  	paired with better defense, it edges out.

While both Hero Trees differ in the exact way they deliver their damage, their
throughput is extremely close to each other in almost all situations. They also
share similar cooldown windows, meaning either can be played in most content.
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker's ability to stretch some of its talent picks further when
cleave is introduced gives it the edge in raids, as most encounters in The Venomous
Abyss feature multiple targets. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw on the other hand is
easier to execute, and has a more robust defensive toolkit, suiting it well to
Mythic+. Below we have some import codes if you want to jump straight
in-game:

**Quick Start Import Codes:**

:::talents Raid / Cleave - Wildstalker
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMGz2yYZsNjZmHYmBAAAgtgZzwYmRNjZZmZmZMmxAAAAAAwADAAAAAwsNzSzyMLbgZeAgFzgBAwMDAGA"
}
```
:::

:::talents AoE / Mythic+ - Druid of the Claw
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::talents Raid / Single Target - Wildstalker
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYLY2MMmZUzYWmZmZGjZMAAAAAAMwAAAAAAMbzs0sMzyGYmHAYxMYAAMzAgB"
}
```
:::

:::talents Delves - Druid of the Claw
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZYmxMzMzsZsNz2MmZegZGAAAA2CmNDPgZG1MmlxMzMLjZYAAAAAAMwAAAAoZWmlZmZAALwMzAswgBAAwMbYA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Wildstalker

Raid/Cleave

recommended

Raid/Single-Target

recommended

Mythic+/AoE

Delves

Druid of the Claw

Raid/Single-Target

Raid/Cleave

Mythic+/AoE

recommended

Delves

recommended

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker Raid Cleave Talents

Due to the large number of encounters in The Venomous Abyss that feature 2-target
  cleave or add spawns, we've provided a dedicated cleave build for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker
  that's more suited to those encounters. Much like with single-target, there are
  <em>a lot</em> of options that can be swapped around depending on the encounter,
  so check the notes beneath the calculator.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker Raid Talents

In Midnight Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker single-target is very similar to
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw, though some swaps on the tree allow it to transition
  into low-target cleave slightly better. This makes it <em>just barely</em> the
  recommended choice, but check the Raid Cleave build for multi-target encounters.
  Finally, check the notes below the talent calculator for details on potential
  swaps.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker Mythic+ Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker keeps up much better in Season 2 when transitioning to
  AoE, focusing heavily on applying Bleeds to large groups of enemies. It has a
  <em>slightly</em> higher execution requirement to get the most out of it, and
  loses a touch more single-target compared to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw though.
  It's absolutely capable of high damage, with the only meaningful loss being
  defense.

### 天赋方案 0-3

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker Delve Talents

While slightly less suited to [Delves](<https://www.icy-veins.com/wow/delves-guide>) than its counterpart, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker
  can still build a decent loadout to tackle them in Season 2. Despite DoT effects
  being less front-loaded than the direct damage available to other builds, it's
  capable of dealing extremely good mass AoE, but its weaker defensive toolkit can
  limit how aggressively you can path through.

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw Single Target Raid Talents

In Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw is neck-and-neck with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker,
  in no small part thanks to the extra [[spell:106951]] duration provided by
  the Tier Set. Much like its counterpart, it has a large number of talents on the
  tree that are extremely similar in value, so in multi-target encounters we'd
  recommend instead using the Raid Cleave build provided. Check below the calculator
  for notes on some options.

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw Cleave Raid Talents

Due to the high number of cleave encounters present in The Venomous Abyss, we've
  provided a dedicated build that supports encounters with more variable target counts.
  Due to the number of specialist tools available to Feral, there's a lot of different
  options that are extremely close, so your decision will often be dictated by the
  encounter style. Check beneath the talent calculator for some extra notes.

### 天赋方案 1-2

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw Mythic+ Talents

In Season 2, while the damage difference between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker
  and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw has shrunk substantially, the defensive difference
  has not. The options available allow for smoother transitions between target
  counts, allowing it to navigate the Mythic+ landscape <em>slightly</em> better.
  Since it's also easier to execute with more defense, it's our **recommended
  choice**:

### 天赋方案 1-3

1.8.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw Delve Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw really shines in [Delves](<https://www.icy-veins.com/wow/delves-guide>) due to the huge
  survival benefits and on-demand AoE. Pair that with its front-loaded burst and
  [[spell:441824]], which rewards dropping combat, and you have a spec that
  can handle anything even the most dangerous Delves can throw at you.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMGz2yYZsNjZmHYmBAAAgtgZzwYmRNjZZmZmZMmxAAAAAAwADAAAAAwsNzSzyMLbgZeAgFzgBAwMDAGA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9Vs8FGJ-kjOifhQST58KFIWaY22w0S5iCYgxkqC-AAAA-BEIcApJ4gRiCmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYLY2MMmZUzYWmZmZGjZMAAAAAAMwAAAAAAMbzs0sMzyGYmHAYxMYAAMzAgB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9Vs8FGJ-kAjOifhhQST58KFIWa6Y22OOSw0WQ5C-AAAA-BEIcApJ4gRiCmF-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2MPw2YbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAAAwsNzWzyMLbwMzAswgBAwMDAGA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112WUTbl9l8JmqnDS-kgijBKOfQST58KFIWaGYq22Mmgpt4qF-AAAA-BEIeApJ4gRiCmF-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDzMzMjZmNjtZ2mZmZMzAAAAwWwsZ4BMzomxsYmZmZZMDDAAAAAgBAAAAAAMbzs1sNzyGYmBYhZYAAMzAgB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QTbl9lMmnyzZ-kjKOgifBedCEcNMQSTXq220mggdNLqA-AAAA-RGUIEMBg4RjGmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwghxYmZmxsxDsMz2MzMmZGAAAA2CmNDjZG1MmlZmZmxYGDAAAAAADMAAAAamlZZmZGAwCYmBYhBDAAgZ2wA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9l8FGZL-kAjOifhhQST58KJWa6Y22OOSw0ex6JD-AAAA-QCGokcIYUgp5CB-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2MPwyYbGzMmZAAAAYLY2MMmZUzYWmZmZGjZMAAAAAAMwAAAAoZWmlZmZAALgZGgFGMAAAmZDD"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9l8FGZL-kjOifQST58KJWaY22Sw0exCMQRwY1QB-AAAA-QCGokcIYUgp5CB-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QT7cl9lMmHSV-kgijBKOfQST58KFIWaGYq22Mmgpt4aG-AAAA-EMQUYaGMgoQyyB-
```

:::

### 天赋方案 1-3

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZYmxMzMzsZsNz2MmZegZGAAAA2CmNDPgZG1MmlxMzMLjZYAAAAAAMwAAAAoZWmlZmZAALwMzAswgBAAwMbYA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QT7cl9l8lnSV-kgijKOfhQST58KFIaeiYq22Sw0WgcND-AAAA-EMQUYaGMgoQyyB-
```

:::

### 天赋方案 0-0

The core is built similar to the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker single-target loadout,
  but the key swaps are variable depending on how many targets are present and
  for how long. A combination of these pick-ups can be used depending on how
  important cleave is in a given encounter.

- [[spell:285381]] and [[spell:391709]] are extremely worthwhile
    if there's any consistent cleave to be had on an encounter, so are first swaps
    for [[spell:449537]] and a point from [[spell:383352]].
- [[spell:391700]] against consistent 2-target fights (such as
    The Twin Fangs) is equally powerful.
- [[spell:391347]] and [[spell:391881]] push cleave even further
    if it's a <em>heavy</em> AoE encounter.
- Both of the above alongside [[spell:1244544]] can be switched around,
    with [[spell:390902]] and [[spell:391548]] as other
    picks depending on encounter timing.

### 天赋方案 0-1

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker's single-target is centered around DoT effects &
  Bleeds, so it picks up talents to enhance them. Notably, [[spell:391969]]
  to improve their tick frequency (and by extension more [[spell:439531]]
  procs), and [[spell:155580]] to incorporate [[spell:8921]].
  [[spell:106951]] and [[spell:391528]] combine for 2-minute burst,
  and all four points in [[spell:1263657]] are always taken. Notes about
  talent swap options are:

- Feral has <em>a lot</em> of talents that are all extremely similar in value.
    Some options are:
  
  - [[spell:390902]] is similar to [[spell:421432]], if you're
    	struggling to manage Energy correctly.
  - [[spell:391548]] can also be taken instead of either of the
    	above if 1-minute burst is more suited.
  - [[spell:449537]] & both points in [[spell:383352]] can
    	be dropped point-by-point, switching out for AoE in the top gate using
    	[[spell:285381]], [[spell:391709]] or [[spell:391700]],
    	in order of strength.
- [[spell:231063]], [[spell:1280316]] and [[spell:48484]]
    are all <em>very</em> close in value in the centre.
- [[spell:102543]] has weaker 2-piece scaling, so while
    there's synergy, it's not worth it.

### 天赋方案 0-2

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker has to sacrifice a little more of the tools it makes
  use of in single-target to build for AoE, but the loss isn't felt nearly as
  much in Season 2. Most importantly, [[spell:285381]], [[spell:391709]]
  and [[spell:391700]] all being consolidated into the first gate opens
  up space in the centre. Similar to single-target, it still combines
  [[spell:106951]] and [[spell:391528]] for 2-minute burst, but
  switches out [[spell:1244544]] for [[spell:1243807]]. Some extra
  talent notes are:

- [[spell:1244547]] is an option <em>provided you can consistently
    kill off enemies</em>. This relies on you chain pulling, and targets dying in a
    staggered fashion to roll the buff, so its inconsistencies keep it from being
    recommended.
- The large buffs to [[spell:1244532]] in Season 2 make it a good pick
    for evening out lost single-target in the transition to AoE. This kicks in as
    a solid gain around 3 targets, improving all the way to 6.
- [[spell:391347]] has also improved significantly in Season 2, scaling well
    into high target AoE.
- [[spell:390902]] can be switched out for [[spell:391548]]
    if a 1-minute cooldown timer is more favourable.

### 天赋方案 1-0

In single-target, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw makes sure to pick up as many talents
  as possible that enhance [[spell:22568]] - in particular
  [[spell:421432]]. One exception is [[spell:391881]], which interferes
  with the strength of [[spell:441583]] procs. It combines [[spell:106951]]
  with [[spell:391528]] for potent 2-minute burst, while also taking
  [[spell:1244544]] to line up with each [[spell:5217]] cast. Extra
  talent notes are:

- At the bottom of the tree, [[spell:390902]] is taken for ease
    of use. This <em>is flexible</em>, and can be switched out for
    [[spell:391969]] or [[spell:391347]] for cleave,
    [[spell:391548]] for 1-minute burst, or even [[spell:1244258]].
- [[spell:449537]] & both points in [[spell:383352]] can
    be dropped point-by-point, switching out for AoE in the top gate using
    [[spell:285381]], [[spell:391709]] or [[spell:391700]],
    in order of strength.

### 天赋方案 1-1

The core is built similar to the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw single-target loadout,
  though it sacrifices [[spell:421432]] to make room at the bottom of the tree.
  Some swaps are more important than others, depending on the number of targets
  present and how frequently they're active. Notes on picks are:

- [[spell:285381]] and [[spell:391709]] are extremely worthwhile
    if there's any consistent cleave to be had on an encounter, so are first swaps
    for [[spell:449537]] and a point from [[spell:383352]].
- [[spell:391700]] against consistent 2-target fights (such as
    The Twin Fangs) is equally powerful.
- [[spell:391347]] and [[spell:391881]] push cleave even further
    if it's a <em>heavy</em> AoE encounter.
- Both of the above alongside [[spell:1244544]] can be switched around,
    with [[spell:390902]] and [[spell:391548]] as other
    picks depending on encounter timing.

### 天赋方案 1-2

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw maintains the same build goals in Season 2, but has an
  easier time integrating [[spell:285381]] and [[spell:391709]] thanks
  to the shuffle up to the top gate. [[spell:391700]] and
  [[spell:207272]] combine to make [[spell:1822]] the builder of choice.
  [[spell:1244532]] has seen significant improvements, providing
  fallback priority damage to make up for single-target lost in the transition to
  AoE. Due to the number of options, some extra notes are:

- [[spell:1244547]] is an option <em>provided you can consistently
    kill off enemies</em>. This relies on you chain pulling, and targets dying in a
    staggered fashion to roll the buff, so its inconsistencies keep it from being
    recommended.
- [[spell:391347]] has improved significantly in Season 2, scaling well
    into high target AoE.
- [[spell:390902]] can be switched out for [[spell:391548]]
    if a 1-minute cooldown timer is more favourable.

The builds listed above are recommendations based on strength and popularity,
covering each area of content in endgame PvE. Each build has its own rotation to
execute, with unique aspects to master, with their own tricks up their sleeve to
assist your group in different encounters.

2.

### Omnium Folio

Introduced in [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), the Omnium Folio is a player power system
that provides a small number of performance boosting effects, unlocked through a
series of quests. These bonuses aren't related to any gear pieces, and are
always active on your character. Some provide additional damage, while others
grant some healing and extra defensive tools.

Below, we've listed recommendations on each of the five Runes, unlocked as you
complete the Folio quest chain:

- **Rune 1 –** [[spell:1279599]]
- **Rune 2 –** [[spell:1279603]]
- **Rune 3 –** [[spell:1287555]]
- **Rune 4 –** [[spell:1279612]]
- **Rune 5 –** [[spell:1279614]]

It's worth noting that the difference between most of these effects is very
minor. The fourth stat boosting Rune, however, can shift around depending on your
gear, so it's a good place to balance out stats if you're lacking any. Since both
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker lean toward different stats,
Haste, Mastery & Critical Strike can all be good options depending on your
gear balance.

3.

### Apex Talent: ![Unseen Predator Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_druid_unseenpredator.jpg>) Unseen Predator

The Feral Apex Talent, [[spell:1263657]], focuses on adding additional
damage to your finisher casts. These add even more incentive to cycle your resources
correctly, and are used in all builds currently:

- [[spell:1263657]] **first point –** [[spell:22568]] has a
    15% chance per Combo Point spent to trigger either [[spell:1271863]] or
    [[spell:1263903]], depending on targets nearby. Deals reduced damage if fewer
    than 5 Combo Points and 50 Energy were spent to trigger it.
- [[spell:1263658]] **second and third points –** increases all
    damage you deal by 7.5% per point for 1 second per Combo Point spent when an
    Unseen Attack is triggered via [[spell:1263657]]. Extra attacks will
    extend the duration.
- [[spell:1263660]] **fourth point –** increases all [[spell:1079]]
    damage you deal by 30%. Additionally, casting [[spell:5217]] will cause
    your next two Combo Point generating attacks to trigger an Unseen Attack at
    maximum strength.

The entire package is quite strong, buffing finishers through the bonus
damage, the DoT amplification of [[spell:1079]], and the follow-up buffs granted by
[[spell:1263658]]. Since the effect mostly happens from normal gameplay,
it simply acts as a pure throughput increase both in single-target and AoE, with
universal benefits for both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker and
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw.

4.

### Hero Talents

Feral has two Hero Talent choices that lean into different aspects of its core
playstyle, and alter your gameplay goals depending on which you pick.
These two Hero Talents are ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw

This tree grants access to [[spell:441583]], which is triggered via 
auto-attacks, massively empowering your next [[spell:22568]]. Specific
mechanics are:

- [[spell:441583]] deals AoE damage, triggered via your auto-attack
    procs & [[spell:441835]] during [[spell:106951]].
- [[spell:441846]] improves both [[spell:274837]]
    and [[spell:1244258]] damage.

This positions ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw as the more direct-damage focused
tree, focusing on [[spell:22568]] and extra burst. It also provides superior
defensive benefits, improving [[spell:5487]] and granting easier access to
[[spell:22842]].

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker

Conversely, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker focuses heavily on DoT effects and Bleeds in
the Feral toolkit. Most importantly, [[spell:439531]] will grow on targets
affected by [[spell:1822]] and [[spell:1079]], dealing Bleed damage and amplifying your
other abilities. Some specific mechanics are:

- [[spell:439868]] encourages [[spell:155580]],
    leaning into a heavier DoT playstyle.
- [[spell:440120]] causes additional AoE when you cast [[spell:22568]]
    on targets affected by [[spell:439531]], providing additional benefits
    to your finishers.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker is generally more single-target and low cleave oriented,
due to its heavy Bleed and DoT focus. With recent talent tree changes, it has an
easier time hybridizing, so it's more versatile than it previously was in Midnight.

5.

### PvP Talents (War Mode)

"War Mode" is an optional feature that enables open-world PvP
encounters that confer some benefits when active:

- Grants access to PvP talents in the open world.
- 10% increase in World Quest rewards at max level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of War Mode for leveling and PvE content, it is an optional
way to maximize your leveling speed and reward potential. However, you will open
yourself up to open-world PvP, so be aware of hostile enemy players who could
interfere with you; this is a risk you will have to decide on your own if you want
to take.

Generally, the selections are made to optimize your ability to kill enemies
faster, increasing your pace when moving through content.

- [[spell:203224]] can provide additional burst to targets when
  applying your [[spell:1822]] effect, and is a solid increase across the board
  when cycling between targets.
- [[spell:236020]] provides additional damage to your
  [[spell:22568]]. Value is mostly tied to the difficulty of the enemies you
  are encountering, and is especially valuable against high health elites.
- [[spell:202626]] increases the movement speed of you and
  nearby allies by 10%, and causes players to heal for 3% of their maximum
  health when they critically strike with an 8-second cooldown. This provides
  some additional speed and sustain passively.
- [[spell:205673]] causes successful interrupts with
  [[spell:106839]] to reduce the cooldown of [[spell:5217]],
  [[spell:106898]] and [[spell:61336]] by 10 seconds.
  This can be useful for moving around the world, and also provides extra burst
  windows.
- [[spell:305497]] can provide some use if in situations with extra enemies
  present, allowing you to deal additional damage back when being hit.

[[spell:213200]], [[spell:200931]], [[spell:236012]],
[[spell:203242]], and [[spell:236019]] on the other hand have very
limited PvE uses, being more focused on in-combat control and group assistance.
These are geared instead toward PvP encounters, so are not recommended for
open-world play.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Omnium Folio recommendations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for release of Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for new Class Tree talent gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **16 Mar. 2025:** Fixed incorrect Wildstalker single target import codes.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7 with recommended tags.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **30 Sep. 2024:** Updated single-target recommendation to Wildstalker.
- **09 Sep. 2024:** Updated for recent Bloodtalons hotfix and Druid of the Claw recommendation.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, slight touch ups but no major changes to builds.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, moved Convoke build to recommended for single target.
- **06 Nov. 2023:** Updated for Patch 10.2 with new builds.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, small restructuring to some sections but same recommendations.
- **10 Jul. 2023:** Re-added Hybrid build, reworded some segments and also highlighted importance of Dire Fixation.
- **01 May 2023:** Updated for Patch 10.1 to include new Patch 10.1 changes and build options.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Feral Druid in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Feral Druid Gameplay and Rotation Guide

Welcome to the Rotation section of our Feral Druid guide
that goes over everything you need to know about Feral gameplay in endgame Raids
and Mythic+!

Due to Feral having two different Hero Trees that dictate your
playstyle, below we have some quick-start recommendations on which to play and
where in Midnight Season 2:

- **Raid / Single Target -**
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw are both close in
  	single-target, but ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker transitions to cleave easier. Due to
  	how common that is in The Venomous Abyss, it's therefore recommended.
- **Mythic+ / AoE -**
      Again, in AoE both trees deal similar damage, though ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw
  	takes advantage of [[spell:1244532]] more to offset the priority
  	damage loss. It also has lower execution requirements and better defense, so
  	it edges out.

Both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker have never been closer
in terms of raw number tuning in Season 2. While the Tier Set has a <em>slight</em>
leaning toward ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw's [[spell:106951]] window, both trees
deal similar damage. The main thing that separates them is how easily they can
deal with different fight styles within the bounds of the talent tree, and small
differences in utility.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw

Raid / Single Target

Mythic+ / AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker

Raid / Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+ / AoE

Active Talents

Passive Talents

[[spell:391528]]

[[spell:1244544]]

[[spell:1243807]]

[[spell:391881]]

[[spell:155580]]

[[spell:1244258]]

### Single Target

1.1.

#### Feral Druid Single Target Rotation

Feral Druid is built around its resource economy in single-target, generating Combo Points by spending Energy, then consuming them with powerful Finishing moves. This alongside Bleed management forms the core of all Feral builds.

---

1. Cast [[spell:5217]] on cooldown – <em>Click for Details</em>
   
   
   - Aim to use alongside 5 Combo Points, or when 50 Energy below your cap.
2. Cast [[spell:106951]] on cooldown. Always cast alongside [[spell:5217]]
3. **适用条件：Focused Frenzy（启用）。** Cast [[spell:274837]] on cooldown. Always cast during [[spell:5217]]
4. **适用条件：Frantic Frenzy（启用）。** Cast [[spell:1243807]] on cooldown. Cast during [[spell:5217]] when possible
5. **适用条件：Chomp（启用）。** Cast [[spell:1244258]] on cooldown.
6. **适用条件：Apex Predator's Craving（启用）。** Cast [[spell:22568]] with an [[spell:391881]] proc
7. Cast [[spell:1079]] with 5 Combo Points if it's not active, or in Pandemic
     range – <em>Click for Details</em>
   
   
   - Aim to only apply/refresh this with [[spell:5217]] active when possible.
8. **适用条件：Convoke the Spirits（启用）。** 
   Cast [[spell:391528]]. **Always** line up with [[spell:106951]] and [[spell:5217]] – <em>Click for Details</em>
   
   
   - Make sure to have [[spell:1079]] active on your main target.
   - Aim to have as few Combo Points as possible.
9. **适用条件：Wildstalker（启用）。** 
   Cast [[spell:22568]] with 5 Combo Points and [[spell:1079]] applied – <em>Click for Details</em>
   
   
   - Try to have 50+ Energy available to trigger the bonus damage.
10. **适用条件：Druid of the Claw（启用）。** 
    Cast [[spell:441583]] / [[spell:22568]] with 5 Combo Points and [[spell:1079]] applied – <em>Click for Details</em>
    
    
    - Try to have 50+ Energy available to trigger the bonus damage.
11. Cast [[spell:1822]] if it's not active on your target, or within Pandemic range – <em>Click for Details</em>
    
    
    - If the DoT can be improved through a [[spell:5217]] snapshot, refresh it before the buff fades.
12. **适用条件：Lunar Inspiration（启用）。** 
    Cast [[spell:8921]] if it's not active on your target, or within Pandemic range – <em>Click for Details</em>
    
    
    - If the DoT can be improved through a [[spell:5217]] snapshot, refresh it before the buff fades.
13. Cast [[spell:5221]] to build Combo Points

---

Feral requires you to manage your Energy and Combo Points efficiently. While a little Energy waste isn't too bad, your goal should be avoiding <em>any</em> Combo Point waste, so watch out for bursts of generation with [[spell:1280316]] that can switch up your decision tree. [[spell:5221]] is your main generator, and you need to make sure you maintain your Bleeds in [[spell:1822]] and [[spell:1079]], ideally buffing them with [[spell:5217]].

1.2.

#### Single Target Rotation Notes & Tips

**适用条件：Druid of the Claw（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw, based on your selections in the tool above:

**适用条件：Wildstalker（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker, based on your selections in the tool above:

- [[spell:1079]] and [[spell:1822]] should be up at all times, aiming to snapshot during [[spell:5217]] windows.
- **适用条件：Lunar Inspiration（启用）。** [[spell:8921]] follows the same rules above with [[spell:155580]] taken.
- **适用条件：Convoke the Spirits（未启用）。** [[spell:106951]] should be cast on cooldown, synced with [[spell:5217]].
- **适用条件：Convoke the Spirits（启用）。** [[spell:106951]] is cast on cooldown, synced with [[spell:5217]]. <em>Always</em> cast [[spell:391528]] during this buff window overlap at low Combo Points. Make sure [[spell:1079]] will last the entire channel.
- **适用条件：Focused Frenzy（启用）。** [[spell:274837]] should be cast on cooldown. With [[spell:1244544]], align with every [[spell:5217]].
- **适用条件：Frantic Frenzy（启用）。** [[spell:1243807]] should be cast on cooldown. This lines up with every third [[spell:5217]], or can be held every minute to align with [[spell:106951]] at the cost of uses if it makes timers more favorable for add spawns.
- **适用条件：Chomp（启用）。** [[spell:1244258]] is used on cooldown every 20 seconds. Try to dump Energy just before its cooldown ends.
- **适用条件：Druid of the Claw（启用）。** [[spell:22568]] / [[spell:441583]] should <em>always</em> be cast with 50+ Energy to trigger the bonus damage.
- **适用条件：Wildstalker（启用）。** [[spell:22568]] should <em>always</em> be cast with 50+ Energy to trigger the bonus damage.
- **适用条件：Apex Predator's Craving（启用）。** [[spell:391881]] should be consumed as fast as possible to avoid wasting follow-up procs.

---

:::details FAQWhen Should I Refresh my Bleeds and DoTs?
Whenever they aren't active on your target, or if they're within their Pandemic timer and won't overwrite a stronger snapshot. If

[[spell:5217]]

is about to fade and you can snapshot a soon-to-be-expiring DoT, do so before it expires.

:::

:::details FAQDo I Always Spend at 5 Combo Points?
Yes.

[[spell:1263657]]

strongly incentivizes spending at 5 Combo Points to maximize the duration of the buff. Always aim to spend at 5 Combo Points, and with 50+ Energy when spending with

[[spell:22568]]

.

:::

:::details FAQWhat is Snapshotting?
Snapshotting is a Feral-specific mechanic, linked to

[[spell:5217]]

in Midnight. This causes DoTs and Bleeds applied while the buff is active to retain the damage increase for their entire duration. You should ideally refresh effects during this window, and avoid overwriting stronger DoTs before they expire.

:::

### AoE

1.3.

#### Feral Druid AoE Rotation

In AoE situations, Feral relies <em>heavily</em> on specific talents in its tree to convert single-target finishing moves into AoE attacks. [[spell:285381]] provides a way to apply [[spell:1079]] to multiple targets, and [[spell:22568]] triggers splash damage with [[spell:391709]]. Its playstyle is similar to single-target, but has some extra things to consider.

---

1. Cast [[spell:5217]] on cooldown – <em>Click for Details</em>
   
   
   - Aim to be 70 or more Energy below your cap when used.
2. **适用条件：Apex Predator's Craving（启用）；Wildstalker（启用）。** 
   Cast [[spell:22568]] with an [[spell:391881]] proc – <em>Click for Details</em>
   
   
   - Ideally with [[spell:1079]]s active to trigger [[spell:391709]].
3. **适用条件：Apex Predator's Craving（启用）；Druid of the Claw（启用）。** 
   Cast [[spell:441583]] / [[spell:22568]] with an [[spell:391881]] proc – <em>Click for Details</em>
   
   
   - Ideally with [[spell:1079]]s active to trigger [[spell:391709]].
4. Cast [[spell:106951]] on cooldown. Always cast alongside [[spell:5217]]
5. **适用条件：Frantic Frenzy（启用）。** Cast [[spell:1243807]] on cooldown. Cast during [[spell:5217]] when possible
6. **适用条件：Focused Frenzy（启用）。** Cast [[spell:274837]] on cooldown. Always cast during [[spell:5217]]
7. Cast [[spell:285381]] with 5 Combo Points if it's not active, or within Pandemic range
8. **适用条件：Convoke the Spirits（启用）。** 
   Cast [[spell:391528]] with [[spell:5217]] active – <em>Click for Details</em>
   
   
   - Cast this during [[spell:106951]], before [[spell:5217]] expires, and with as few Combo Points as possible.
   - Make <em>sure</em> to have [[spell:1079]]s active that will last the entire channel duration.
9. **适用条件：Druid of the Claw（启用）。** Cast [[spell:441583]] / [[spell:22568]] with 5 Combo Points, 50+ Energy and [[spell:1079]]s active
10. **适用条件：Wildstalker（启用）。** Cast [[spell:22568]] with 5 Combo Points and [[spell:1079]]s active
11. **适用条件：Druid of the Claw（启用）。** 
    Cast [[spell:213764]] during [[spell:106951]], or with a [[spell:263725]] proc – <em>Click for Details</em>
    
    
    - Prioritizing this as your generator during [[spell:106951]] is to fish for [[spell:441835]] procs.
12. Cast [[spell:1822]], cycling between targets
13. **适用条件：Wildstalker（启用）；Lunar Inspiration（启用）。** Cast [[spell:8921]], cycling between targets
14. Cast [[spell:213764]] to generate Combo Points and [[spell:1822]] is applied to all targets
15. **适用条件：Chomp（启用）。** Cast [[spell:1244258]] when out of Energy

---

**适用条件：Druid of the Claw（启用）。** Many of the rules that Feral plays by in single-target remain in multi-target situations. With [[spell:391700]], cycling [[spell:1822]] between targets is your ideal Combo Point builder, and [[spell:213764]] is your fallback once it's applied to nearby enemies. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw does, however, prioritize [[spell:213764]] during [[spell:106951]] to fish for [[spell:441835]] procs.

**适用条件：Wildstalker（启用）。** Many of the rules that Feral plays by in single-target remain in multi-target situations. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker, cycling [[spell:1822]] is your primary method of building Combo Points, utilizing [[spell:391700]] to rapidly apply it to multiple enemies. [[spell:213764]] is instead your fallback generator if you already have [[spell:1822]]s set up.

1.4.

#### AoE Rotation Notes & Tips

**适用条件：Druid of the Claw（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw, based on your selections in the tool above:

**适用条件：Wildstalker（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker, based on your selections in the tool above:

- [[spell:285381]] should always be taken to apply [[spell:1079]] in AoE. Maintain it on all targets at all times.
- **适用条件：Druid of the Claw（启用）。** [[spell:22568]] is used when [[spell:1079]]s are applied and with 5 Combo Points, triggering [[spell:391709]]. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw also has unpredictable [[spell:441583]] procs to manage, it's even more important to maintain your [[spell:1079]]s.
- **适用条件：Wildstalker（启用）。** [[spell:22568]] is used with 5 Combo Points when [[spell:1079]]s are applied, triggering [[spell:391709]].
- **适用条件：Apex Predator's Craving（启用）。** [[spell:391881]] procs trigger more frequently in AoE, so spend them quickly to trigger [[spell:391709]].

---

:::details FAQWhat Finisher do I Cast in AoE?
Always aim to have

[[spell:1079]]

applied via

[[spell:285381]]

at all times. Following that, excess resources are spent on

[[spell:22568]]

to trigger

[[spell:391709]]

.

:::

:::details FAQDo I Always Spend at 5 Combo Points?
Yes.

[[spell:1263657]]

strongly incentivizes spending at 5 Combo Points to maximize the duration of the buff. Always aim to spend at 5 Combo Points, and with 50+ Energy when spending with

[[spell:22568]]

.

:::

:::details FAQWhat is Snapshotting?
Snapshotting is a Feral-specific mechanic, linked to

[[spell:5217]]

in Midnight. This causes DoTs and Bleeds applied while the buff is active to retain the damage increase for their entire duration. You should ideally refresh effects during this window, and avoid overwriting stronger DoTs before they expire.

:::

### ST Opener

1.5.

#### Feral Druid Single Target Opener

Feral has a very quick single-target opening sequence in Midnight, setting Bleeds up quickly and starting [[spell:106951]].

---

[[spell:5215]]

Stealth

Pull

[[spell:1822]]

[[spell:5217]]

[[spell:106951]]

[[item:241288]]

**适用条件：Focused Frenzy（启用）。**

**适用条件：Focused Frenzy（启用）。**

[[spell:274837]]

**适用条件：Focused Frenzy（启用）。**

[[item:270175]]

**适用条件：Frantic Frenzy（启用）。**

**适用条件：Frantic Frenzy（启用）。**

[[spell:1243807]]

**适用条件：Frantic Frenzy（启用）。**

[[item:270175]]

[[spell:1079]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:391528]]

---

1. Cast [[spell:5215]] before combat starts
2. Cast [[spell:5217]] and open with [[spell:1822]]
3. Cast [[spell:106951]] 
   
   - Use [[item:241288]]
   - Use on-use trinkets such as [[item:270175]]
4. **适用条件：Frantic Frenzy（未启用）。** Cast [[spell:274837]]
5. **适用条件：Frantic Frenzy（启用）。** Cast [[spell:1243807]]
6. Cast [[spell:1079]]
7. **适用条件：Convoke the Spirits（启用）。** Cast [[spell:391528]]
8. **适用条件：Convoke the Spirits（启用）。** Cast [[spell:22568]]
9. Continue with normal ability priority.

---

**适用条件：Focused Frenzy（启用）；Convoke the Spirits（未启用）。** Casting your [[spell:5217]] while still in [[spell:5215]] applies a maximum strength [[spell:1822]] snapshot on the pull. [[spell:274837]] immediately builds 5 Combo Points for [[spell:1079]], allowing you to then transition into your regular rotation.

**适用条件：Frantic Frenzy（启用）；Convoke the Spirits（未启用）。** Casting your [[spell:5217]] while still in [[spell:5215]] applies a maximum strength [[spell:1822]] snapshot on the pull. [[spell:1243807]] immediately builds 5 Combo Points for [[spell:1079]], allowing you to then transition into your regular rotation.

**适用条件：Convoke the Spirits（启用）；Focused Frenzy（启用）。** Casting your [[spell:5217]] while still in [[spell:5215]] applies a maximum strength [[spell:1822]] snapshot on the pull. [[spell:274837]] immediately builds 5 Combo Points for [[spell:1079]], allowing you to instantly cast [[spell:391528]].

**适用条件：Convoke the Spirits（启用）；Frantic Frenzy（启用）。** Casting your [[spell:5217]] while still in [[spell:5215]] applies a maximum strength [[spell:1822]] snapshot on the pull. [[spell:1243807]] immediately builds 5 Combo Points for [[spell:1079]], allowing you to instantly cast [[spell:391528]].

### AoE Opener

1.6.

#### Feral Druid AoE Opener

The Feral AoE opener is flexible, depending on how fast you want to start cooldowns. Your first priority is casting [[spell:285381]] to apply [[spell:1079]]s, setting you up for [[spell:106951]].

---

[[spell:5215]]

See Note

Pull

[[spell:1822]]

[[spell:285381]]

[[spell:5217]]

[[item:241288]]

[[spell:106951]]

[[item:270175]]

**适用条件：Focused Frenzy（启用）。**

[[spell:274837]]

**适用条件：Frantic Frenzy（启用）。**

[[spell:1243807]]

**适用条件：Druid of the Claw（启用）。**

[[spell:441583]]

**适用条件：Wildstalker（启用）。**

[[spell:22568]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:391528]]

---

1. Cast [[spell:5215]] before combat starts
   
   - Optional - the stun can disrupt pull setup
2. Cast [[spell:1822]] on different targets until you reach 5 Combo Points
3. Cast [[spell:5217]] and immediately [[spell:285381]]
   
   - Use [[item:241288]]
4. Cast [[spell:106951]] 
   
   - Use on-use trinkets such as [[item:270175]]
5. **适用条件：Frantic Frenzy（未启用）。** Cast [[spell:274837]]
6. **适用条件：Frantic Frenzy（启用）。** Cast [[spell:1243807]]
7. **适用条件：Wildstalker（启用）。** Cast [[spell:22568]]
8. **适用条件：Druid of the Claw（启用）。** Cast [[spell:441583]]
9. **适用条件：Convoke the Spirits（启用）。** Cast [[spell:391528]]
10. Continue with normal ability priority.

---

**适用条件：Convoke the Spirits（启用）。** <em>Always</em> make sure to set up with [[spell:285381]] before entering into [[spell:106951]], buffed by your first [[spell:5217]]. These need to be active to make sure [[spell:391709]] triggers, especially during [[spell:391528]].

**适用条件：Convoke the Spirits（未启用）。** <em>Always</em> make sure to set up with [[spell:285381]] before entering into [[spell:106951]], buffed by your first [[spell:5217]]. These need to be active to make sure [[spell:391709]] triggers.

2.

### Midnight Season 2 Tier Set

Season 2 of Midnight introduces the **Bark of the Enigmatic Dreamwatcher**,
available from different endgame content. This provides the following bonuses:

- [[spell:1296605]] — When [[spell:106951]] ends, you
  	deal 10% increased damage for 1 second per Combo Point spent during Berserk.
- [[spell:1296606]] — [[spell:106951]] lasts 10
  	seconds longer.

Both of these bonuses are built around Feral's biggest burst window, extending
[[spell:106951]] while also providing a secondary buff that rewards resource
cycling during your cooldowns. This means that, while there are no specific rotational
changes it introduces, there's a heavier burden on making full use of your
Berserk windows.

<em>Note</em> – [[spell:102543]] instead provides
the same 10% damage buff, but for 0.75 seconds per Combo Point spent. This cancels
out most of the extra built-in synergy with the set, so it still remains the
weaker pick in Season 2.

2.1.

#### Feral Druid Mechanics Breakdown

In the below sections, we'll be covering the finer details of specific
  mechanics that drive Feral's gameplay loop. They dive into how your major
  cooldowns, rotational abilities and proc effects work. This is
  a more advanced section, aiming to help you get a better understanding of the
  <em>why</em> behind each button press.

3.

### Class and Spec Mechanics Explained

### Combo Points and Energy

3.1.

#### Combo Points and Energy

Feral Druid's core rotation is dictated by its dual resource system: Energy and
Combo Points. The first of these, Energy, has a base capacity of 100 (increased by
certain Talents), and refills at a rate of 11 Energy per second (increased by
Haste). This is used to fuel <em>every ability</em>, both your Combo Point generators,
and your Combo Point finishers.

Feral has a few different abilities to build Combo Points (called generators):
[[spell:5221]], [[spell:1822]], [[spell:213764]], [[spell:8921]] (with
[[spell:155580]]) and finally [[spell:274837]]. When used, these
generate at least 1 Combo Point, and with [[spell:159286]] taken can also
generate an additional one when they critically strike.

Finishing Moves (called finishers) spend <em>all</em> your Combo Points at
once, and often come with their own Energy cost. The more Combo Points spent, the
higher the damage (or stronger the effect), so always aim to cast with the cap of
5. Your most commonly used finishers are [[spell:1079]] / [[spell:285381]] to
apply powerful DoTs, and [[spell:22568]] for direct damage.

3.2.

#### Energy Pooling

Due to the slow generation of Energy for Feral, it often makes use of the
concept of "pooling" Energy. In practice, this means holding ability uses until
certain conditions are met, building up a reserve of resources, then spending to
maximize efficiency. Feral always has a natural amount of downtime in its
rotation, so planning these moments rather than being forced into a dry period is
usually better. It's also a good idea to bottom out your Energy levels right
before using [[spell:5217]], to give room for the burst of Energy it
generates.

[[spell:16864]] procs should be used as soon as possible (below 5
Combo Points) to avoid overwriting procs. With [[spell:236068]], this
allows you to sit on one charge, giving you some room to plan around the extra
free generator it enables.

### Bleeds, DoTs and Pandemic

3.3.

#### Bleeds and Damage Over Time Effects

Feral should always aim to have 100% uptime on both [[spell:1822]] and
[[spell:1079]], with additional DoTs included based on your talent build. This is
the core of your damage output, and creates the maintenance playstyle that Feral
is built around. Remember, if you're playing [[spell:391969]], all of
the below effects expire 25% faster!

- [[spell:1079]] — costs 20 Energy, but duration is dependent on how
  many Combo Points you apply it with. Aim to use 5 for the best Energy efficiency,
  and when you do so it lasts for 24 seconds.
- [[spell:1822]] — costs 35 Energy to apply, lasts for 15 seconds. Apply
  rotationally.
- [[spell:8921]] <em>(with [[spell:155580]])</em> — costs 40
  Energy, lasts for 18 seconds. Apply rotationally.

3.4.

#### When to Refresh Bleeds and Buffs

Feral benefits from the <em>Pandemic</em> effect on its DoTs, allowing you to
refresh specific DoT effects up to 30% early, and carry the remaining
duration into the next cast. This **does not** carry over any snapshotting
effects, which instead need to be present when the new DoT is applied.
The Pandemic timers are as follows:

- [[spell:1822]] – 4.5 seconds
- [[spell:1079]] – 7.2 seconds <em>(assuming 5 Combo Points)</em>
- [[spell:8921]] – 5.4 seconds

Note that these amounts are reduced by 25% with [[spell:391969]],
increasing their tick speed.

### Snapshotting

3.5.

#### Snapshotting

"Snapshotting" has long been a core pillar of Feral Druid gameplay, used to
power up your Bleed effects. In Midnight however, this has been significantly
pulled back, and only a handful of specific buffs maintain this behaviour.

Abilities that have the snapshot interaction with Bleeds, and which DoTs they
affect are:

- [[spell:5217]] — all DoT effects
- [[spell:390772]] — [[spell:1822]] (from [[spell:5215]])

[[spell:5217]] is the main activator for the majority of your Snapshotting,
so making use of the mechanic is a good deal simpler in Midnight. Just remember to
reapply Bleeds during this window, and avoid overwriting any empowered DoTs you've
previously snapshotted until they expire. Generally, the rule to follow is to only
ever overwrite a DoT effect if you will apply a **stronger** snapshot. If you
aren't currently able to do so, then wait until the initial Bleed expires to
reapply.

Tracking these is a little more difficult with the UI changes introduced in
Midnight, though it should be noted that the icon changes when a Bleed has been
applied under a snapshot effect. Your action bar will also switch over to the
empowered icon, highlighting that a stronger Bleed is available to be applied, so
these can both be used to assist your decision making.

### Ferocious Bite

3.6.

#### Ferocious Bite

[[spell:22568]] is your direct-damage finisher, and you should only
commit Combo Points to it **after** you have [[spell:1079]] (or [[spell:285381]])
active. When cast, make sure your current Rip has enough remaining time
to allow you to generate the Combo Points necessary to refresh it. Always try to
have 50+ Energy when using Ferocious Bite to amplify its damage (doubly so
if playing with [[spell:421432]]).

As covered in the rotation section, this is only something you commit to when
you have spare resources. While it can be appealing to see the big damage it deals,
losing uptime on DoTs is almost never worth the investment. [[spell:391881]]
procs, however, cause this to be <em>completely free</em>, and should be consumed
immediately. These procs **do** gain the bonus damage from extra Energy
consumption, but **do not** get increased further by [[spell:421432]].

3.6.1.

##### Rampant Ferocity

The above rules also apply to [[spell:391709]], causing it to be amplified
by additional Energy consumption. This talent makes it <em>even more important</em>
to have [[spell:1079]] applied to **all** nearby targets before committing to it,
as it only deals damage to enemies affected by the DoT.

3.6.2.

##### Ravage

As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw, you also gain access to [[spell:441583]] procs.
These follow <em>all</em> of the above rules, being functionally identical to
[[spell:22568]] in terms of how they scale. These should be consumed
as soon as possible to avoid overwriting procs (especially in AoE), but still try
to make sure you meet the Energy thresholds to maximize its damage.

### Feral Frenzy & Chomp

3.7.

#### Feral Frenzy

[[spell:274837]] should be used when you have 0-2 Combo Points, and
immediately followed with a finishing move. This means you both need the Energy
to cast it, and to use the follow-up Combo Point spender in quick succession.
Whenever possible, overlap this with [[spell:5217]]. It also comes with a
follow-up choice node:

- [[spell:1244544]] reduces the cooldown by 15 seconds, and increases
  damage dealt by 15%.
- [[spell:1243807]] is the AoE equivalent, blinking rapidly
  between targets and applying a strong Bleed.

Both of these nodes are strong either in single-target or AoE respectively,
and are picked up in every build to enhance Feral's burst toolkit. With
[[spell:1244544]], it is <em>always</em> paired with every [[spell:5217]]
cast, while [[spell:1243807]] is either held to align, or used with every
third cast, depending on your pull cadence or add spawns. Damage can also
be amplified through [[spell:441846]] when playing
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw.

3.8.

#### Chomp

New in Midnight, [[spell:1244258]] has a 20-second cooldown and no cost, dealing
high Physical damage to your target, and triple damage with a critical
strike. This can <em>only</em> be used after falling below 30% Energy, or within a
2-second window after meeting that threshold. When taken it should be cast whenever
available - ideally during [[spell:5217]], but don't hold it to align. Damage
is also amplified for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw via [[spell:441846]].

### Apex Talent

3.9.

#### Feral Druid Apex Talent – Unseen Predator

The Feral Apex Talent, [[spell:1263657]], focuses on adding additional
damage to your finisher casts. These add even more incentive to cycle your resources
correctly, and are used in all builds currently:

- [[spell:1263657]] **first point –** [[spell:22568]] has a
    15% chance per Combo Point spent to trigger either [[spell:1271863]] or
    [[spell:1263903]], depending on targets nearby. Deals reduced damage if fewer
    than 5 Combo Points and 50 Energy were spent to trigger it.
- [[spell:1263658]] **second and third points –** increases all
    damage you deal by 7.5% per point for 1 second per Combo Point spent when an
    Unseen Attack is triggered via [[spell:1263657]]. Extra attacks will
    extend the duration.
- [[spell:1263660]] **fourth point –** increases all [[spell:1079]]
    damage you deal by 30%. Additionally, casting [[spell:5217]] will cause
    your next two Combo Point generating attacks to trigger an Unseen Attack at
    maximum strength.

These will occur throughout your rotation, dealing direct damage and amplifying
all damage you deal in the brief window after it triggers. Due to the power being
weighted toward passive bonuses, there are very few rotational considerations
needed to maximize the effect. The only thing it does do is solidify the need to
spend at 5 Combo Points to avoid the penalty for spending too aggressively.

3.10.

#### Feral Druid Major Cooldowns

Throughout the talent tree, there are a variety of different cooldown options
that provide burst in different ways. Below, we'll be covering each of them, how
they impact the rotation, and how to use them.

4.

### Important Cooldowns for Feral Druid

### Berserk

4.1.

#### Berserk

[[spell:106951]] is Feral's major cooldown. This lasts for 15 seconds,
with a cooldown of 3 minutes (reduced to 2 minutes with
[[spell:391174]]). This provides a huge damage increase, so should
be used as close to on cooldown as possible, alongside other damage boosting
effects. While active, it provides several benefits:

- Generates 1 Combo Point every 1.5 seconds.
- All ability damage increased by 15%.
- Combo Point generating abilities generate 1 additional Combo Point.
- Up to 3 Combo Points can be stored above 5 as [[spell:405069]] stacks.
- Finishing Moves consume [[spell:405069]] stacks to refund the same
  amount of Combo Points.
- [[spell:102543]] — duration increased to 20
  seconds, and the Energy cost of [[spell:768]] abilities is reduced by 25% while
  active.
  
  - [[spell:391548]] additionally reduces Incarnation's cooldown to 90
    seconds.

While there are a lot of effects tied into it, the main impact is quite simple:
you deal **significantly** more damage, and have access to far more resources.
Feral's 2-minute burst windows are quite potent using this, and it should always
be lined up with [[spell:5217]] and [[spell:391528]] casts. While
it's active, spend more aggressively to take advantage of the flood of resources.

When upgraded to [[spell:102543]], you also get access to a
**single** use of [[spell:5215]] in combat each time you cast it. Use this
to apply an empowered [[spell:1822]] via [[spell:390772]].

### Tiger's Fury

4.2.

#### Tiger's Fury

[[spell:5217]] has a 30-second cooldown, is off the GCD, and instantly
generates 50 Energy when used. Additionally, all Feral ability damage is increased
by 15% for 10 seconds. This damage increase also <em>Snapshots</em> Bleed effects
applied while active, improving them for their full duration. There are a number
of Feral talents that interact with this:

- [[spell:202021]] – increases duration by 5 seconds, and the
  damage of Combo Point builders by 40% of your Haste.
- [[spell:449645]] – [[spell:5217]] grants 10%
  Haste and 25% increased Energy regen for 8 seconds.
- [[spell:391078]] – increases the duration by an additional 5 seconds.
- [[spell:391872]] – causes your next three Finishing Moves after
  casting to also restore 1 Combo Point. Additionally, the [[spell:5217]] damage
  snapshot applied to **Bleeds** is increased by 10%.
- [[spell:390902]] – increases the damage bonus by 6% per
  point spent.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw – [[spell:441824]] grants [[spell:441583]]
  when cast the first time each combat.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker – [[spell:439890]] increases [[spell:5221]],
  [[spell:1822]] & [[spell:213764]] Critical Strike chance for 6 seconds.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker – [[spell:440118]] applies a [[spell:439531]]
  when cast <em>and</em> when it expires.

[[spell:5217]] has a lot of presence on the Feral talent tree, and its
30-second timer dictates a lot of Feral's gameplay flow. Since it's off the GCD,
it's pressed as close to every 30 seconds as possible. When possible, aim to have
low Energy to make use of the refund, and apply fresh Bleeds to snapshot them if
they're about to expire. Try to keep this in cycle to maintain its alignment with
[[spell:106951]] and [[spell:391528]].

### Convoke the Spirits

4.3.

#### Convoke the Spirits

[[spell:391528]] is a 2-minute cooldown which, when used, casts
a quick succession of 16 Druid spells (free of cost) over 4 seconds. This can be
channelled while moving, but <em>is affected</em> by enemy interrupts. Out of the
wide pool of spells, Feral abilities are preferred, but a handful of casts during
the channel will be from other specializations. **If you aren't in melee range**
it will default to casting abilities that can be used from a distance. Some quick
notes about the abilities it casts are:

- [[spell:22568]] is the finisher in the Feral pool. This is considered
  a max Combo Point cast that **did** consume additional Energy, but is **not**
  increased further by [[spell:421432]].
- Any Combo Point generating ability will still generate a Combo Point for you.
- The "exceptional spell" it can cast is [[spell:274837]].
  
  - This **will** change to [[spell:1243807]] if taken.
- [[spell:8921]] <em>will</em> benefit from [[spell:155580]], but only if taken. It is also <em>always</em> in the pool.
- [[spell:774]], [[spell:8936]] and [[spell:5176]] are also in the pool.
- [[spell:384667]] <em>will</em> be consumed.
- [[spell:441583]] <em>will</em> be consumed.
- [[spell:391881]] will <em>not</em> be consumed.

Due to the damage multipliers granted while [[spell:106951]] and [[spell:5217]]
are active, this should <em>always</em> be cast during buff overlaps. All of their
cooldowns align naturally, so try not to drift them. Finally, in single-target and
<em>especially</em> AoE, make sure you have active [[spell:1079]]s that will last
the entire channel duration.

4.3.1.

##### Ashamane's Guidance

[[spell:391548]] is a follow-up node that, when paired with
[[spell:391528]], reduces the cooldown to one minute, the spell count to
12, and the channel duration to 3 seconds. While not always taken, when played its
cooldown should strictly be kept to its 1-minute timer, so as to avoid drifting it
away from [[spell:106951]].

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, added recommended tags.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **30 Sep. 2024:** Changed default loadout to Wildstalker ST to align with talent page.
- **09 Sep. 2024:** Updated for recent Bloodtalons hotfix and Druid of the Claw recommendation.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, no gameplay changes but restructured page for readability.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, moved Convoke to the primary button, added AoE opener switches.
- **06 Nov. 2023:** Updated for Patch 10.2 and restructured the rotation tool.
- **04 Sep. 2023:** Restructured for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5, small tweaks and notes about Dire Fixation AoE.
- **01 May 2023:** Updated for Patch 10.1 to include new Berserk changes and updated builds.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Feral Druid in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Feral Druid

Welcome to our Gear and BiS Page for Feral Druid for Midnight! 
Check this page to learn everything you need to know about gearing an
Feral Druid, including the BiS Gear from all sources, Raiding,
and Mythic+, information on the best Trinkets, Tier Sets, and much more.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system, allowing
you to increase the item level of gear along tracks relating to the level of
content it was obtained from. Harder content drops gear on higher level tracks, thus
reaching higher Item Levels. For more information, read up on our dedicated page
on how the [gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works in
Midnight.

The 12.1.5 update brings with it the release of [[item:280562]],
allowing 334 Weapons, Trinkets, and Necklaces to be upgraded all the way to 340
item level. Additionally, it brings the new boss Kith'ix, which drops powerful
new loot, with some big pick-ups on offer for Feral.

### Overall

The list below contains gear from <em>all possible endgame sources</em>, including Raids, Mythic+, Crafting, Delves and The Great Vault. It aims to provide the absolute best possible setup, but bear in mind that each **individual** item may not be the strongest in your particular gear setup. Tier pieces have the drop locations of ideal Catalyst pieces listed if they're stronger than the standard version.

Note that this gearset aims to strike a balance between Critical Strike, Mastery and Haste, as all three have similar value.

:::details FAQWhich Items Do I Use in the Catalyst?
In Midnight Season 2, the Catalyst now **retains the secondary stats and cantrips** of <em>any</em> item you convert. Therefore, it doesn't matter which slots you use to activate your set bonus, and instead what matters is the items you input.

The absolute best pieces currently available to Catalyze in each slot are:

- **Helm –** [[item:271875@JAAEAAAG2chN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **Shoulders –** [[item:271526@JAACAAgNyA]] from [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **Chest –** [[item:281236@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Gloves –** [[item:268234@JAACAAgNyA]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- **Legs –** [[item:268225@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

Similar to Season 1, your <em>number one priority</em> is to acquire the 4-piece bonus through any means to unlock **Catalyst Unbound** for Season 2.

:::

:::details FAQAre There Any High Priority Great Vault or Voidcore Items to Look Out For?
Any of the cantrip items available in Season 2 raids are extremely valuable, even if they aren't at item level 344 from Mythic. The following items are strongly worth considering even from a Heroic Vault, and are even worth using Voidcores on to obtain if you don't expect to progress Mythic quickly:

1. [[item:268215@JAAEAAAG2YhN]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
2. [[item:270175@JAACAAAG2A]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
3. [[item:270173@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271875@JAAEAAAG2chN]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

All three new [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) items are also quite strong, making it a good Voidcore candidate. Items in this pool are strong enough that if you <em>aren't</em> killing any Mythic bosses for higher vault rewards, you always have the option to pick up a Voidcore from your Great Vault if none of these show up.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240900]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268215@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

The gearset below contains the best items available from Mythic+, using gear only available from dungeons in the Season 2 pool, alongside your ideal Tier Set catalyst locations and Crafted items for Embellishments. Note that this is a list of the <em>best items available</em> from Mythic+ dungeons, **not** a strict list of what you should be using in Mythic+ content.

:::details FAQWhich Items Do I Use in the Catalyst?
In Midnight Season 2, the Catalyst now **retains the secondary stats and cantrips** of <em>any</em> item you convert. Therefore, it doesn't matter which slots you use to activate your set bonus, and instead what matters is the items you input.

The best **Dungeon only** pieces to Catalyze in each slot are:

- **Helm –** [[item:251140@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **Shoulders –** [[item:251223@JAACAAgNyA]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **Chest –** [[item:251159@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- **Gloves –** [[item:251124@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **Legs –** [[item:251130@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

Similar to Season 1, your <em>number one priority</em> is to acquire the 4-piece bonus through any means to unlock **Catalyst Unbound** for Season 2.

:::

:::details TipsWhich Dungeons Should I Farm?
All of Feral's strongest pieces are sourced from Raids in Season 2, but there are some worthwhile alternatives to hunt while you wait to get hold of them:

1. [[item:252258@JAACAAgNyA]] – [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
2. [[item:159617@JAACAAAOyA]] – [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
3. [[item:251124@JAACAAgNyA]] – [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
4. [[item:250228@JAACAAAOyA]] – [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:159317@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251149@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

The gearset below is your **raid** Best-in-Slot list, using gear from **only** raid drops, as well as ideal Tier Set pieces (or items to use in the Catalyst) and crafted items to activate Embellishment effects. Note that this is a list of the <em>best items available</em> within the Raid, **not** a strict list of what you should be using inside the raid.

:::details FAQWhich Items Do I Use in the Catalyst?
In Midnight Season 2, the Catalyst now **retains the secondary stats and cantrips** of <em>any</em> item you convert. Therefore, it doesn't matter which slots you use to activate your set bonus, and instead what matters is the items you input.

The best **Raid only** pieces to Catalyze in each slot are:

- **Helm –** [[item:271875@JAAEAAAG2chN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **Shoulders –** [[item:271526@JAACAAgNyA]] from [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **Chest –** [[item:281236@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Gloves –** [[item:268234@JAACAAgNyA]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- **Legs –** [[item:268225@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

Similar to Season 1, your <em>number one priority</em> is to acquire the 4-piece bonus through any means to unlock **Catalyst Unbound** for Season 2.

:::

:::details TipsWhat Are My Top Items To Chase?
Feral has some extremely high value cantrip picks available in The Venomous Abyss, with most of them coming from the final boss, Ula'tek. All of the items from the final two bosses are worth obtaining due to their increased item level, but some are particularly strong:

1. [[item:268215@JAAEAAAG2YhN]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
2. [[item:270175@JAACAAAG2A]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
3. [[item:270173@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271875@JAAEAAAG2chN]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240900]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268215@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Feral Druid

Feral generally seeks to use one on-use trinket that aligns with [[spell:106951]]
to empower its already powerful burst windows, and then one strong passive trinket
to go alongside it.

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Trinkets to Hunt in Midnight**
**On-Use -**

[[item:270175@JAACAAAG2A]]

**Passive -**

[[item:270173@JAACAAAG2A]]

or

[[item:281215@JAACAAAOyA]]

:::

You can click below to open a ranking chart for other trinkets, in case you've
picked something else up and are looking to check how it stacks up.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Feral Season 2 Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270175@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   This is by far the best on-use option available in Season 2, despite&#10;		   being on an awkward 1m30s cooldown. No other option comes close in&#10;		   power, so this is one of your big chase items. Always hold it to line&#10;		   up with your [[spell:106951]] windows.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270173@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   A relatively standard direct damage trinket, but comes with a higher&#10;		   max item level and deals extremely good single-target damage.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   New in Patch 12.1.5, this is <em>the strongest</em> passive AoE trinket.&#10;		   Since Feral has no way to activate the Guillotine Technique set, as soon&#10;		   as cleave is introduced Tendril evens out, and only gets better from&#10;		   there. Good for any situation with frequent add spawns, or in Mythic+&#10;		   dungeons.</p>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Triggers a variety of different stat boosting effects, and different&#10;		   buffs can overlap. While it does have a negative proc in the pool, it's&#10;		   a solid passive option, particularly useful in cleave, AoE and&#10;		   dungeons.</p>&#10;</li>&#10;<li>[[item:270165@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:159617@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Certainly not as strong as Voracious Heart, but it serves as an on-use&#10;		   alternative from Mythic+. The longer duration also allows it to blanket&#10;		   most of the extended [[spell:106951]] duration from the new Tier&#10;		   Set.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:273796@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Lines up with [[spell:106951]] to empower your burst windows, but&#10;		   the negative after-effect kicks in and blankets both the tail end of&#10;		   your cooldowns <em>and</em> the Tier Set payoff, making it slightly&#10;		   weaker than other on-use alternatives.</p>&#10;</li>&#10;<li>[[item:250228@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:250225@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Try to always use this on a target that will live long enough for you&#10;		   to stack up the Crit buff, otherwise most of its value is lost.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   While this is tuned well and Mastery is desirable, staying within the&#10;		   zone of the proc is extremely restrictive, especially in Season 2. Due&#10;		   to both the large arenas in raid encounters and the hectic movement in&#10;		   dungeons, your mileage may vary in reality when using it.</p>&#10;</li>&#10;<li>[[item:270166@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:248583@JAACAAAMyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Go to the Jan'alai altar in Zul'Aman to set this to <strong>Mastery</strong>.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Hold to line up with [[spell:106951]]. When using&#10;		   [[item:241288]], make sure to pot <em>before</em> using&#10;		   your trinket to avoid setting it to Crit.</p>&#10;</li>&#10;<li>[[item:265657@JAACAAAMyA]]</li>&#10;<li>[[item:251792@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>Click for Details</em></span>&#10;<span>&#10;		   This deals an <em>extremely</em> large amount of burst damage to your&#10;		   primary target when used, alongside some bonus AoE. While it struggles&#10;		   against other options due to it being a channel with a long cooldown,&#10;		   its unique potential to be useful to deal with key enemies means it&#10;		   might be worth looking at in certain edge cases in Season 2.</span>&#10;</li>&#10;<li>[[item:250259@JAACAAAOyA]]</li>&#10;<li>[[item:274493@JAACAAAMyA]]</li>&#10;<li>[[item:158374@JAACAAAOyA]]</li>&#10;<li>[[item:251785@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:246304@JAAIAAwt1ENMMYDH2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>Crafted Trinket Details</em></span>&#10;<span>&#10;		   While these trinket options aren't <em>bad</em>, Embellishments are&#10;		   stronger in Season 2 compared to before. That means the opportunity cost&#10;		   of using them is too high, and they've fallen even further behind than&#10;		   they already were.</span>&#10;</li>&#10;<li>[[item:246305@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246306@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246307@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:241340@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:251783@JAACAAAMyA]]</li>&#10;<li>[[item:274496@JAACAAAMyA]]</li>&#10;<li>[[item:274497@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores and Ascendant Venomstones

Season 2 brings forward the bonus roll system introduced in Season 1,
providing a way to target big ticket items:

**[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s** can be spent after completing endgame
dungeons or defeating raid bosses, granting you an item at random from its
respective loot table. Once an item has been received through Voidcore rolls,
it cannot appear again. In Season 2, **one** Voidcore is used to roll on
dungeon loot <em>or</em> individual raid bosses, granting loot equivalent to
the item level you'd receive from a weekly Great Vault reward.

One can be acquired each week from **Orin Straylight** next to the Catalyst,
following the release of Patch 12.1.5. Additionally, one can be selected from The
Great Vault instead of an item, provided you unlocked three total rewards.

3.1.

#### Recommended Nebulous Voidcore Usage for Feral Druid

Which item you should target is strongly influenced by what pieces you already
have access to, items available through the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), and what bosses
you have currently killed. While they are now more freely available following the
addition of weekly rewards in Patch 12.1.5, taking one from The Vault should be
treated as a <em>consolation prize</em> in the event that nothing better appears.

When it comes to <em>where</em> you should use Voidcore rolls when you do pick
one up however, the answer is quite simple:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Season 2 Voidcore Uses**
1. **Ula'tek** (Heroic/Mythic)
   
   - [[item:270175@JAACAAAG2A]]
   - [[item:268265@JAAGAAAG2MqNTpC]]
   - [[item:271875@JAAEAAAG2chN]]
   - [[item:268215@JAAEAAAG2YhN]]
2. **Kith'ix** (Heroic/Mythic)
   
   - [[item:281236@JAAEAAgNyEuN]]
   - [[item:281029@JAACAAgNyA]]
   - [[item:281215@JAACAAAOyA]]
3. **The Coiled Altar** (Heroic/Mythic)
   
   - [[item:270173@JAACAAAG2A]]

:::

:::details FAQWhen Should I Consider Voidcores From The Great Vault?
Now that the season has progressed and Voidcores are more freely available,
recommendations are more concrete. Although you now have access to more rolls, it's
still worth keeping in mind things that may make it less appealing to pick one
up:

- If you have yet to unlock your 4-piece bonus, acquiring that takes priority.
- If a key chase item from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) is offered, pick that up.
- Look out for individual key items offered from early Mythic boss kills (such
    as a trinket from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)), as they're offered at 6/6 Myth,
    saving crests and skipping the need to bonus roll for something useful.

The main thing to consider is that, while Bonus Rolls shrink the pool of things
that can be obtained on subsequent rolls (raising the chance of acquiring
chase items), getting the item you want out of the gate as a drop or from the vault
may avoid the need to invest additional Voidcores.

:::

3.2.

#### Ascendant Venomstones

Following the release of Patch 12.1.5, you can now acquire [[item:280562]],
allowing you to upgrade specific item slots all the way up to item level 340 (or
338 for crafted pieces). Using these follows a similar priority to your crest
usage:

1. **Weapon** first, always.
2. **On-Use Trinket** second, ideally [[item:270175@JAACAAgNyA]].
3. **Passive Trinket** third.
4. **Necklace** last.

You also want to prioritize Myth track items over Hero track pieces, unless you
don't expect to acquire a Myth track variant of the piece you're upgrading. The
exception to this is one of the most difficult items to obtain from Ula'tek
in The Venomous Abyss - [[item:270175@JAACAAgNyA]]. As this
is our strongest on-use option by far, it's worth the investment even on a lower
track.

4.

### Best Crafted Items for Feral Druid

Crafted gear provides one of the easiest ways to pick up high value items in a
season, allowing you to target key pieces to fill out your gearset. With the
release of Season 2, each craft requires two [[item:274476]].

Unless secondary stats are already assigned by the item, you should use
[[item:245783]] for Haste and Mastery.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_green.jpg>) **Feral Crafting Order**
**[[item:244569@JAAKAAwt1ENMMYDYwklI]]**

➜

**[[item:244576@JAAKAAwt1ENMMYDYwklI]]**

➜

**Optional Crafts**

:::

- **Note on Weapon Crafts** – while normally weapon crafts are good to fill
  gaps, the cantrip weapon ([[item:268215@JAAEAAAG2YhN]])
  is strong enough even when bonus rolled from Heroic, so burning two crafts is
  lower value than normal. If <em>you will not have access to this early</em> or
  you're unlucky with drops, crafting [[item:245771@JAAMAAwt1ENMMYzy1klIcYD]]
  and attaching [[item:273060]] is <em>always</em> the best choice.
- Craft **an off-piece** – we recommend [[item:244569@JAAKAAwt1ENMMYDYwklI]]
  in the Boots slot. Attach [[item:240167]] as your first Embellishment.
- Craft **another off-piece** – we recommend [[item:244576@JAAKAAwt1ENMMYDYwklI]]
  in the Wrist slot. Attach a second [[item:240167]] as your second Embellishment.

Following this, craft items based on gaps in your current gear.

:::details FAQAre the New Embellishments in Season 2 Good?
**Some of them**. In the lead-up to the release of Season 2 many were reduced
in power, and this hasn't changed in Patch 12.1.5:

- [[item:273060]] serves as a better [[item:245876]],
    making it the best weapon Embellishment, and our current go-to pick.
- [[item:273069]] provides a stacking Haste proc. This is <em>very</em>
    close in value to [[item:240167]], but is far enough behind that it
    can't be justified considering the latter also buffs allies.
- [[item:273066]] was hit by <em>enormous</em> nerfs, so isn't worth
    considering.
- [[item:270899]] also saw huge reductions, so isn't worth considering
    either.

:::

Once you have your two main Embellishment crafts, you should have a solid setup.
Your priority when optimizing your gear further should be toward crafting high item-level
pieces to cover holes in your gear setup. High priority candidates are jewelry
pieces, as while there are unique strong options available, they're <em>extremely</em>
contested this season.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will
have limited access to upgrade crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can
be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) to higher item levels. Crests are
limited to 100 per week, and upgrades cost 20 crests regardless of the slot. Due
to that, you should prioritize your usage of these on items you don't plan on
replacing any time soon, or specific slots that offer larger stat benefits:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_121_crest_myth.jpg>) **Feral Druid Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

These are not the only items worth upgrading, of course. They simply offer
the highest DPS gain early into the tier when your upgrade currency is limited.
Note that exceptions are possible, such as special cantrip items that have
additional procs attached to them, for example [[item:268265@JAAGAAAG2MqNTpC]].

5.1.

#### Adding Sockets to Gear

While all Rings and Necklaces come with one socket by default, three additional
sockets can be acquired on the Helmet, Belt and Bracer slots as a bonus when they
drop. These can also be added manually using the [[item:275707]]
consumable, which can be purchased using 6 [[item:258556]], the pity
currency from The Great Vault.

When using these, it's always best to put them on pieces you don't expect to
ever replace. This means Mythic items, or any crafted pieces in these slots, since
they can't have them added in any other way. Due to them being a very limited
currency, if you have these, it's best to plan long term before using any.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **24 Aug. 2026:** Confirmed gear list, adjusted weapon enchants, emphasized early weapon crafts & expanded FAQ about ideal early power off-pieces.
- **19 Aug. 2026:** Added disclaimer regarding uncertain gear recommendations due to Aqirbane Reliquary hotfixes.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Sporefall gear.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated with full Season 1 recommendations.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5 with Cartel Chip recommendations.
- **16 Aug. 2025:** Updated Trinket tier list to cover additional tuning.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **24 Jun. 2025:** Updated to account for D.I.S.C. hotfixes.
- **15 Jun. 2025:** Updated for Patch 11.1.7 D.I.S.C. belt and adjusted BiS list slightly for double Gallywix weapon.
- **12 May 2025:** Confirmed Dinar recommendations for Turbo Boost release.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5 and added Cartel Chips section.
- **03 Mar. 2025:** Updated Circe's Circlet and some trinket recommendations.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Dec. 2024:** Updated to highlight strength of new ring following hotfixes.
- **15 Dec. 2024:** Updated for Patch 11.0.7 for Cyrce's Circlet.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5, moved Mad Queen's Mandate to recommended.
- **09 Sep. 2024:** Updated with Season 1 BiS lists.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4 and Awakened gear release.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, highlighted Ashes of the Embersoul as equal to Witherbark's.
- **07 Nov. 2023:** Updated to remove Sporecloak recommendation, switched Toxic Thorn/Toxic Patch.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Restructured for Patch 10.1.7, information remains the same.
- **10 Jul. 2023:** Updated for Patch 10.1.5 with megadungeon gear, and clarified crafting section.
- **25 May 2023:** Added section on Cataclysm Timewalking.
- **09 May 2023:** Updated to account for Trinket changes.
- **01 May 2023:** Updated for Patch 10.1 and Season 2 release with new gear recommendations.
- **24 Mar. 2023:** Updated for Primordial Gemstones hotfixes.
- **22 Mar. 2023:** Updated to account for Primordial Stone buffs.
- **20 Mar. 2023:** Updated for Patch 10.0.7 with Onyx Annulet recommendations.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Feral Druid. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Feral Druid Stat Priority

Welcome to our Stat Priority page for Feral Druid in the
Midnight expansion! Here we'll quickly be going over the stats you should
aim for on gear, alongside any special considerations depending on your build.

In Season 2, both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw
have similar general stat priorities, but things shift slightly depending on
whether you're in single-target or AoE.

1.1.

#### Feral Druid Single-Target Stat Priority

A <em>general</em> stat priority for Feral in single target is as follows:

Agility

Mastery

Haste

Critical Strike

Versatility

In Midnight, Agility is much more valuable following the stat squish, meaning
that most of your gearing decisions are driven by item level once again.

Mastery, Haste and Critical Strike are all <em>very</em> similar in value,
and ideally you want to keep them balanced. Critical Strike and Haste both provide
resource smoothing through Energy regeneration and [[spell:159286]]. Mastery on
the other hand fuels your finisher and Bleed damage, and is recommended above
others as you want your [[item:241288]] to trigger this stat.

Versatility falls to the bottom of the pile with no special interactions, though
it does come with some defensive benefits. In Season 2, with the combination of
Venomcursed items and [[item:241288]], you ideally want to keep this
as low as possible, as it cannot be reduced below zero through any of these negative
procs.

1.2.

#### Feral Druid AoE Stat Priority

A <em>general</em> stat priority for Feral in AoE is as follows:

Agility

Mastery

Critical Strike

Haste

Versatility

Same as in single-target, Agility remains the most valuable stat you can have
on items, so most of your gearing decisions are driven by item level.

Mastery remains your top priority stat to amplify finishers and Bleeds, and
is also the stat you want to set [[item:241288]] to. Critical Strike
is second (especially for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw) to provide additional resource
smoothing through [[spell:159286]].

Haste falls slightly behind in AoE once you reach enough resources to sustain
your cycle, but it's still worth having a solid amount on your gear.

Versatility comes in last with no unique interactions, though it does provide
defensive benefits. Like in single-target, with the combination of
Venomcursed items and [[item:241288]], you want to aim for as little
as possible to avoid being punished by the downsides of these effects.

2.

### In-Depth Stat Breakdown

As a Feral Druid, **Agility** is your primary stat,
which should be present on all Leather gear you wear, alongside your weapon.
Individual stats provide the following benefits:

- **Agility**: provides you with Attack Power, increasing the damage of
  your Feral abilities and melee attacks.
- **Critical Strike**: increases the chance for your attacks to critically
  strike, dealing double damage. Additionally:
    
  
  - [[spell:159286]] grants an additional Combo Point when you critically
    	strike with a Combo Point generator.
- **Mastery**: improves [[spell:77493]], increasing all damage
  dealt by your Bleed effects. Additionally:
    
  
  - Increases the damage dealt by all direct damage finishing moves.
  - Increases the damage dealt by [[spell:391709]].
- **Haste**: increases your auto-attack speed and Energy regeneration.
  Additionally:
    
  
  - Increases the tick rate of your Bleed DoT effects.
  - Increases damage dealt by Combo Point generators by 40% of
    	your Haste percentage via [[spell:202021]].
- **Versatility**: increases all damage and healing you do (including trinkets
  and proc effects) by a flat amount. Additionally, reduces all damage you take by
  half of that amount.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where it will begin to offer less increase per point
gained, known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **03 Sep. 2025:** Shifted Haste slightly above Versatility in AoE.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4 release.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, no changes necessary.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Adjusted wording slightly to show Crit, Haste and Mastery all reach equality with gear.
- **10 Jul. 2023:** Updated for Patch 10.1.5, moved Haste and Mastery to equal.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Feral Druid, based on your [stat priority](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

The recommended choices for all content are:

- Use [[item:240983]] in your first socket.
  
  - Use [[item:240900]] in other sockets.
- With **5+ Sockets**, switch to [[item:240967]].
  
  - Use one of each colour to maximize the bonus - [[item:240900]],
      [[item:240892]], [[item:240908]], and [[item:240917]].

Depending on your stat balance, sockets are often the best place to fix any
gaps in your gear. Since Mastery, Haste, and Critical Strike are all competitive
for Feral, we recommend simming your character to see which stat is worth
prioritizing in your gem slots.

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td><strong>Main Hand</strong></td>&#10;<td>&#10;<ul>&#10;<li>&#10;[[item:273072]]<br/>&#10;   with [[item:243733]]&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Helm</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Shoulders</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Chest</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Legs</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Boots</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Rings</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Helm, Shoulder and Boot enchants are up to personal preference as they have no
direct impact on performance, but we recommend Avoidance picks on all slots for
the extra survivability.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

Flasks are a good way to adjust your secondary stats if you're lacking in a
particular area with your gear setup. You'll often want to stack either Haste or
Mastery depending on the content:

- [[item:241322]] – provides Mastery.
- [[item:241325]] – provides Haste.

You can also obtain a flask of your choice from a [[item:241319]],
provided by Alchemists.

3.2.

#### Potions

In Season 2, there are a few different options depending on your current gear:

- [[item:241288]] – generally strongest if you can trigger Mastery.
- [[item:271886]] – niche use in single-target as a pre-pot for [[spell:391528]].
- [[item:241308]] – if your gear isn't optimized for Recklessness.

Of the three, [[item:241288]] will generally be the strongest as
soon as your gear is set up to trigger a preferred stat. You may find in sims that,
with unbalanced gearsets, [[item:241308]] is preferred - this is normal
and you should follow the recommendation until your stats balance out to support
it.

Potions should always be paired with major cooldowns alongside
[[spell:2825]] / [[spell:32182]]. You can also obtain Fleeting versions of
any of these potions from a [[item:241285]], provided by Alchemists.

A note on [[item:241292]] is that, while it's technically
stronger, one wrong step will pacify you inside the void zone that it occasionally spawns.
It only takes 1-2 GCDs (or a cancelled [[spell:391528]]!) inside this to wipe
out the extra value, so using this potion generally isn't worth it.

[[item:271883]] is the current best healing potion. Using
this has a 5-minute cooldown, but multiple can be consumed in an extended boss
fight should it go on long enough. Additionally, Warlock's
[[item:5512]]s do not share a cooldown with other healing consumables.
Remember to use it as well if you are holding one!

3.3.

#### Food Buff

Agility remains the strongest stat in Season 2, so you should be
eating a [[item:255845]] or other primary stat Feast if possible. If
this isn't provided by your group, stick to [[item:242275]] personal food instead.

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s
to increase your primary stat. Remember: Augment Runes are expensive and disappear
on death, so use them wisely!

3.5.

#### Other Consumables

Alongside standard buff consumables, there are a handful of other items worth
keeping hold of - especially in Mythic+:

- [[item:188152]] — allows you to auto-interact with nearby Warlock [[spell:111771]]s.
- [[item:244639]] — grants a weaker 15% Haste [[spell:2825]]
  effect on your party when used. These are still affected by [[spell:57724]], so should
  only be used if you have no party member that provides it naturally.
- [[item:241303]] — Midnight's invisibility potion, which can
  be used to skip certain trash pulls in Mythic+. Bear in mind this <em>does</em>
  share a cooldown with your combat potion of choice.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **24 Aug. 2026:** Switched weapon enchant to Rite of the Hash'ey and expanded Potion section.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Season 1 - added Teas and additional Consumables for Mythic+.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **12 May 2025:** Updated following Corruption tuning.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Added note for Speed Blasphemite.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, changed food recommendation to secondary food.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5, small note about Gem alternatives.
- **01 May 2023:** Updated for Patch 10.1 for new enchants available.
- **24 Mar. 2023:** Updated for Primordial Stones hotfixes.
- **22 Mar. 2023:** Updated to account for Primordial Stones hotfix.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Feral Druid in World of Warcraft Patch 12.1.5.

1.

### Feral Druid in Mythic+ in Midnight Season 2

On this page, we will be covering how to get the most out of your Feral
Druid in Mythic+ dungeons, including the best way to build talents, any
rotational changes that you need to know, and tips and tricks to excel in
keystones.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our dedicated Mythic+ page below. You can also find
out more about the Mythic+ Meta on our Tier List page.

Feral Druids in Mythic+ deal strong sustained AoE, while also bringing potent
burst every two minutes. A large share of its damage in multi-target situations
comes from AoE Bleeds applied by [[spell:285381]], so unlike many other
specializations it avoids the target cap. Although it often has to sacrifice some
of its specialized single-target talents to make room for its AoE core, Feral can
still pull its weight when forced into boss encounters. Much like many seasons of
the past, in Season 2 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw is best suited to the asks of the
Mythic+ landscape, though ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker is much closer in terms of
throughput than it has been previously.

2.

### Best Mythic+ Talent Builds

In Season 2, while the Tier Set is great for both trees, it accentuates
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw's gameplan in Mythic+ slightly better. The front-loaded
nature of its damage profile paired with its added defensive tools make it the best
option. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker <em>can still be played</em> though, and the talent
tree restructure in particular helped ease some of its build limitations from
Season 1.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw    Recommended Choice

2.1.

#### Best Feral Druid Mythic+ Build - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw is the **recommended** tree due to the damage
it deals, its simplicity, and the added defense it provides. The only significant
change to the core Feral toolkit is the addition of [[spell:441583]] procs,
which simply replace [[spell:22568]] casts you would otherwise be using. The
improvements to [[spell:1244532]] in Season 2 also help to keep its priority
damage intact, even while switching to a more AoE-centric rotation.

It converts its single-target finishers into AoE via [[spell:285381]]
and [[spell:391709]], so rotationally it plays very similarly. The change
to the top of the talent tree also made it more comfortable to fit it in, while
also keeping [[spell:391700]] to push [[spell:1822]] as the general Combo
Point builder. It brings burst every two minutes (extended by the Tier Set bonus)
with [[spell:106951]] paired with [[spell:391528]], and smaller
bursts every 45 seconds with [[spell:1243807]].

2.1.1.

##### Talent Swap Options

Due to much of the tree seeing large improvements in Season 2, there are <em>a lot</em>
of options that perform close to each other. The build we have below is a broad
recommendation, but there's lots of room to customize based on dungeon or preference.

- [[spell:391548]] is taken to reduce [[spell:391528]] to a
  1-minute timer, but [[spell:390902]] can be switched to if these aren't
  favorable in a given dungeon.
- [[spell:1244532]] provides additional priority damage to make up for what
  you lose in your AoE rotation, but [[spell:231063]] is an alternative
  if you want to focus more on universal single-target.
- [[spell:1244547]] requires enemies to die frequently and for your group
  to chain pull to get value from it, but if you can consistently do so it's a great
  pickup.
- [[spell:29166]] is recommended for your healer, but if it's not needed you
  can switch over to [[spell:449193]].
- [[spell:132469]], [[spell:102793]] and [[spell:99]] are
  all strongly recommended for control tools.

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Mythic+ / AoE - Druid of the Claw
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QT7cl9lMmHSV-kgijBKOfQST58KFIWaGYq22Mmgpt4aG-AAAA-EMQUYaGMgoQyyB-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker    Alternative Build

2.2.

#### Alternative Feral Druid Mythic+ Build - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker saw vast improvements from the Season 2 talent shuffle,
making it far easier to enable its AoE finishers without sacrificing major talent
pickups. [[spell:285381]], [[spell:391709]] and [[spell:391700]]
are all mandatory pickups, allowing it to convert the majority of its single-target
abilities to multi-target throughput. It gives up slightly more single-target in
its builds than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw though, and has a higher execution
requirement to get the most out of it.

Similar to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw, it has high 2-minute burst (extended by
the Tier Set) during [[spell:106951]], while also having [[spell:391528]]
for a flurry of high damage attacks. [[spell:1243807]] completes the cooldown
options, dealing high AoE damage every 45 seconds, so it usually has something
available for every pull.

2.2.1.

##### Talent Swap Options

Similar to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw, there are a few talent options
available to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker within a small margin of each other.

- [[spell:390902]] is taken as a generalist pick, but [[spell:391548]]
  can be used if 1-minute timers are more favorable.
- [[spell:1244532]] provides additional priority damage to make up for what
  you lose in your AoE rotation, but [[spell:231063]] is an alternative
  if you want to focus more on universal single-target.
- [[spell:1244547]] requires enemies to die frequently and for your group
  to chain pull to get value from it, but if you can consistently do so it's a great
  pickup.
- [[spell:29166]] is recommended for your healer, but if it's not needed you
  can switch over to [[spell:449193]].
- [[spell:132469]], [[spell:102793]] and [[spell:99]] are
  all strongly recommended for control tools.

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Mythic+ / AoE - Wildstalker
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2MPw2YbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAAAwsNzWzyMLbwMzAswgBAwMDAGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2MPw2YbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAAAwsNzWzyMLbwMzAswgBAwMDAGA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112WUTbl9l8JmqnDS-kgijBKOfQST58KFIWaGYq22Mmgpt4qF-AAAA-BEIeApJ4gRiCmF-
```

:::

3.

### Dungeon Talent Swap Cheat Sheet

This section contains utility uses for the dungeons in the
	Season 2 pool.

For a quick reference of extra uses for your optional Feral utility
	talents, use the tool below to select a dungeon. Underneath, relevant picks will
	be highlighted alongside what they're used to counter.

<table>&#10;<tr>&#10;<th colspan="2">Dungeons</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></td>&#10;</tr>&#10;</table>

Based on the selection above, the following abilities have unique use cases:

![Remove Corruption Not Talented](<https://static.icy-veins.com/images/wow/classes/druid/icons/decurse.jpg>)**适用条件：Altar of Fangs（未启用）；Blinding Vale（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Temple of Sethraliss（未启用）；Murder Row（未启用）；Voidscar Arena（未启用）。**

![Remove Corruption Talented](<https://static.icy-veins.com/images/wow/classes/druid/icons/decurse.jpg>)**适用条件：Altar of Fangs（启用）；Blinding Vale（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Temple of Sethraliss（启用）；Voidscar Arena（启用）。**

‌

![Soothe not Talented](<https://static.icy-veins.com/images/wow/classes/druid/icons/soothe.jpg>)**适用条件：Altar of Fangs（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Murder Row（未启用）；Voidscar Arena（未启用）。**

![Soothe Talented](<https://static.icy-veins.com/images/wow/classes/druid/icons/soothe.jpg>)**适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Voidscar Arena（启用）。**

‌

![No Shapeshift uses](<https://static.icy-veins.com/images/wow/classes/druid/icons/cat.jpg>)**适用条件：Altar of Fangs（未启用）；Blinding Vale（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Ruby Life Pools（未启用）；Voidscar Arena（未启用）。**

![Shapeshift uses](<https://static.icy-veins.com/images/wow/classes/druid/icons/cat.jpg>)**适用条件：Altar of Fangs（启用）；Blinding Vale（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；Voidscar Arena（启用）。**

- **适用条件：Altar of Fangs（启用）。** [[spell:768]] shapeshift snare/root dispels:
  	  
  
  - Clears [[spell:1296069]] in the **Rav'i** boss encounter.
  - Clears [[spell:1310974]] from **The Writhing Coil**.
  - Clears [[spell:1294569]] from **Twinfang Harrowers**.
- **适用条件：Altar of Fangs（启用）。** [[spell:2782]] uses:
  	  
  
  - Dispels [[spell:1307571]] from **High Evolutionists**.
  - Dispels [[spell:1307567]] from **Ula'tek's Chosen**.
- **适用条件：Altar of Fangs（启用）。** [[spell:2908]] uses:
  	  
  
  - Dispels [[spell:1306338]] from **Ravenous Descendants**.
- **适用条件：Blinding Vale（启用）。** [[spell:768]] shapeshift snare/root dispels:
  	  
  
  - Clears [[spell:1238084]] from **Lashers** if you're hit in melee.
- **适用条件：Blinding Vale（启用）。** [[spell:2782]] uses:
  	  
  
  - Dispels [[spell:1250937]] from **Potatoad Matriarch**.
- **适用条件：Den of Nalorakk（启用）。** [[spell:768]] shapeshift snare/root dispels:
  	  
  
  - Clears [[spell:1309919]] from **Frigid Maulers**.
  - Clears [[spell:1241463]] from **Avatar of Determination**.
  - Clears [[spell:1263590]] from failed **Rimeshatter** soaks.
- **适用条件：Den of Nalorakk（启用）。** [[spell:2782]] uses:
  	  
  
  - Dispels [[spell:1238760]] applied by effigies summoned by **Spirits of Hunter**.
  - Dispels [[spell:1234233]] during **The Hoardmonger** boss fight.
- **适用条件：Den of Nalorakk（启用）。** [[spell:2908]] uses:
  	  
  
  - Dispels [[spell:1238053]] from **Territorial Matriarchs**.
  - Dispels [[spell:1246865]] from **Bonded Beasttamer**.
- **适用条件：King's Rest（启用）。** [[spell:768]] shapeshift snare/root dispels:
  	  
  
  - Clears [[spell:1294815]] from **Risen Hexers**.
  - Clears [[spell:106823]] applied by **Queen Patlaa**.
  - Clears [[spell:271563]] applied by **Embalming Fluids**.
  - Clears [[spell:12548]] applied by **Spectral Shaman**.
- **适用条件：King's Rest（启用）。** [[spell:2782]] uses:
  	  
  
  - Dispels [[spell:269972]] cast by **Risen Hexers**.
  - Dispels [[spell:270492]] cast by **Phantom Hex Priests**.
  - Dispels [[spell:106823]] from **Queen Patlaa**.
  - Dispels [[spell:271563]] from **Embalming Fluids**.
  - Dispels [[spell:267273]] cast during **The Council of Tribes** boss fight.
- **适用条件：King's Rest（启用）。** [[spell:2908]] uses:
  	  
  
  - Dispels [[spell:269976]] from **Shadow-Borne Champion**.
  - Dispels [[spell:1297763]] from **Queen Patlaa**.
- **适用条件：Murder Row（启用）。** [[spell:2782]] uses:
  	  
  
  - Dispels [[spell:1217973]] applied by **Corrupted Warlocks**.
  - Dispels [[spell:474515]] applied by **Street Sneaks**.
  - Dispels [[spell:1222795]] during the **Zaen Bladesorrow** boss fight.
- **适用条件：Murder Row（启用）。** [[spell:2908]] uses:
  	  
  
  - Dispels [[spell:1216970]] from **Keen Taskmasters**.
  - Dispels [[spell:1214922]] from **Wrathguard Flayers**.
- **适用条件：Ruby Life Pools（启用）。** [[spell:768]] shapeshift snare/root dispels:
  	  
  
  - Clears [[spell:373803]] from **Infused Whelps** if you're hit in melee.
- **适用条件：Temple of Sethraliss（启用）。** [[spell:2782]] uses:
  	  
  
  - Dispels [[spell:1293307]] cast by **Faithless Subjugators**.
  - Dispels [[spell:1308100]] applied by **Shrouded Fangs**.
  - Dispels [[spell:1308148]] applied by **Poisonous Vipers**.
  - Dispels [[spell:267027]] during the **Merektha** boss fight.
- **适用条件：Voidscar Arena（启用）。** [[spell:768]] shapeshift snare/root dispels:
  	  
  
  - Clears [[spell:1263982]] stacks in the **Charonus** boss encounter.
  - Clears [[spell:1249621]] from **Angry Krolusks**.
- **适用条件：Voidscar Arena（启用）。** [[spell:2782]] uses:
  	  
  
  - Dispels [[spell:1289265]] cast by **Agitated Voidscythes**.
  - Dispels [[spell:1226120]] during the **Atroxus** boss fight.
- **适用条件：Voidscar Arena（启用）。** [[spell:2908]] uses:
  	  
  
  - Dispels [[spell:1254826]] from **Dominated Brawlers**.
  - Dispels [[spell:1310319]] from **Longtooth Tuskarrs**.
  - Dispels [[spell:1249661]] from **Raging Raptors**.

4.

### Utility Kit and Abilities

This section covers key talents and abilities Feral has access to that
can be leveraged in Mythic+ situations.

### Crowd Control

4.1.

#### Interrupts and Crowd Control

Often, the most crucial part of any Mythic+ run (outside of your damage) is how
you intend to lock down dangerous enemy casts. Feral comes with some good options
for both single-target and AoE disruption:

4.1.1.

##### Single Target Crowd Control

**[[spell:106839]] –** Feral's interrupt, on a 15-second cooldown, with
a 13-yard range and a small charge attached. This should be used frequently to
disrupt dangerous casts, and can also be used to re-engage targets at range using
the charge. Be careful if using it from a distance though, to avoid charging into
something dangerous.

**[[spell:339]] –** a soft crowd control option, useful for locking
down enemies in situations where you want to keep them out of range. Remember they
can still cast and attack while rooted though. This can also be made instant with
[[spell:16974]] procs.

**[[spell:48484]] –** passively applied by your [[spell:1822]]
ability, slowing targets by 20% for 12 seconds. A very weak slow compared to equivalent
effects, but it's applied passively for kiting.

**[[spell:22570]] / [[spell:5211]] –** two talents that provide
point-and-click stuns to your target. While hard to justify on the talent tree,
these are always options if you need extra stops.

**[[spell:2637]] –** a hard crowd control limited to Beasts or Dragonkin,
with a 1.5-second cast time and a 30-yard range. When used, the target is put to
sleep for up to 40 seconds, but damage taken breaks the effect.

**[[spell:33786]] –** an emergency crowd control tool that banishes your
target for 6 seconds, making it unable to act while making it immune to all damage
and healing effects. This can be used to lock down a dangerous target briefly, but
its 1.5-second cast time and diminishing returns make it niche at best.

4.1.2.

##### AoE Crowd Control

**[[spell:102793]] –** locks enemies within the target area, pulling
them back to the center if they try to leave (or are forced out). This has good
synergy with [[spell:132469]], acting as a pseudo-mass grip by gathering
all enemies pushed to its center.

**[[spell:132469]] –** can push enemies back, interrupting casts. Can also
force targets out of ground effects.

**[[spell:99]] –** an AoE disorient effect, mostly used to
interrupt enemy casts. The low cooldown of this makes it incredibly useful for
large groups of enemies, but it does put you into [[spell:5487]],
so it comes with a damage loss. Remember that you can make use of [[spell:449193]]
to quickly re-enter [[spell:768]] using [[spell:5221]].

### Defense & Off-healing

4.2.

#### Defensive Tools

After control, you also need to consider how you are going to survive
in dungeons where damage intake can be extremely high. That means talents that are
often niche in raids really shine here, allowing you to make it through otherwise
lethal mechanics:

**[[spell:5487]] –** allows you to assume a Tank-oriented form when used,
granting access to [[spell:6795]] as a taunt effect. This can help in
emergencies, increasing your survival and allowing you to redirect pressure from
your tank. With [[spell:377842]] taken as well, it can act as a short
window of additional Health to survive potentially lethal mechanics.

**[[spell:22812]] –** your 1-minute cooldown defensive, providing 30%
damage reduction for 12 seconds (with [[spell:449191]] and [[spell:327993]]).
The low cooldown paired with the potent damage reduction makes this a tool to be
used liberally, in any situation you feel in danger.

**[[spell:61336]] –** is a huge cooldown that is best used for
making it through the most lethal mechanics. The massive 60% damage reduction
provided (with [[spell:449191]]) is excellent, but the 6-second duration paired
with a 3-minute cooldown means you need to plan wisely.

**[[spell:319454]] –** has a 2-minute cooldown, and when paired with
[[spell:5487]] grants a massive 30% health increase for 20 seconds. This persists
even when you shapeshift out, so is excellent for surviving lethal damage.

**[[spell:377847]] –** provides a perfect emergency heal
should you be caught off guard, or begin to bleed out over extended periods of
time. A great pick and should always be taken.

**![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) Druid of the Claw –** has access to [[spell:22842]]
even while in [[spell:768]], providing a large heal for a small Energy cost.
This is extremely strong if your Health is looking unstable.

4.3.

#### Off-healing Tools

Feral also has a small toolkit for helping out the group with healing, should
your healer be struggling:

**[[spell:16974]] –** allows you to cast [[spell:8936]] or
[[spell:339]] instantly following a finishing move used at 5 Combo
Points. This assists with off-healing, or provides emergency crowd control.

**[[spell:319454]] –** when cast outside of any shapeshift, this
applies an empowered [[spell:48438]] to your group. While the healing isn't
really strong enough to justify a 2-minute cooldown, it can help in an emergency.

### Dispels & Other Utility

4.4.

#### Dispels

Many dungeons have requirements for dispels to deal with certain mechanics, and
you cannot simply rely on the healer to cover them all. Feral has two
abilities that can be taken if needed:

**[[spell:2782]] –** removes both Curse and Poison debuffs from
a targeted ally with an 8-second cooldown. This is especially helpful if your
healer can't remove either of these effects themselves.

**[[spell:2908]] –** an offensive Enrage effect dispel. This has a 40-yard
range and a 10-second cooldown, and can be used in [[spell:768]]. Incredibly
valuable to any group in any dungeon that has Enrage effects.

4.5.

#### Other Utility

Lastly, Druids have some unique tools that are important to keep in mind
while navigating Mythic+:

**[[spell:1126]] –** provides 3% Versatility to your group, and is
brought by any Druid. This is increased to 6% on yourself with [[spell:1262034]].
Remember to buff this at the start of every dungeon (or if you or
an ally dies)!

The act of shapeshifting in or out of [[spell:768]] (or any of your other
shapeshift effects) will also break roots, which can be helpful when dealing with
certain mechanics.

**[[spell:449193]] –** a useful point due to the number of utility
options that force you out of [[spell:768]]. This means you can quickly get
back to dealing damage with a cast of [[spell:5221]], instead of manually shifting
and using up a GCD. A great comfort pick.

**[[spell:29166]] –** extremely useful to help your healer out, providing
extra Mana generated over a short period of time. With changes in Season 2 this
doesn't need much coordination to make use of, and can just be given to them
whenever they're looking dry on resources.

**[[spell:106898]] –** grants bonus movement speed to you and all allies
within 15 yards. This is useful for sticking to targets, helping allies avoid
dangerous effects, or getting to the next pull faster.

**[[spell:20484]] –** a combat resurrection effect, allowing you to revive
a player outside of the combat restrictions in the event of an unexpected
death. This requires you to leave [[spell:768]].

5.

### Dealing with Affixes

### Affix: Ascendant

5.1.

#### Ascendant Affix Management

**Xalatath's Bargain: Ascendant** will periodically spawn a number of orbs in
waves that need to be crowd-controlled in some way, before they complete a cast.
Each orb successfully stopped provides the group bonus Haste, so it is a high
priority to deal with.

Feral should make use of [[spell:99]] and [[spell:132469]],
which when aimed correctly can remove a huge number of orbs when they start
spawning.

### Affix: Voidbound

5.2.

#### Voidbound Affix Management

**Xalatath's Bargain: Voidbound** will periodically summon a large Void
Emissary that will begin to cast [[spell:462508]]. This enemy **must** be
killed before the cast completes to stop it, otherwise it provides significant
damage reduction to nearby enemies. If successfully stopped, the group is granted
a large amount of Versatility and cooldown reduction.

This needs to be killed off quickly, so ideally, having short, bursty cooldowns
like [[spell:5217]] or some Combo Points available when it spawns makes
things a lot easier for the group.

### Affix: Pulsar

5.3.

#### Pulsar Affix Management

**Xalatath's Bargain: Pulsar** spawns an orb that orbits each player, which
needs to be soaked by a separate player before they expire. Each orb will grant
the party 4% Mastery and 2% Leech, stacking, with a 30-second duration. Unsoaked
orbs will increase nearby enemies' damage done, and reduce their damage taken.

Feral has no specific utility to deal with this. Instead, you need to be
aware of your positioning both to make sure other players can soak up the orb
circling you, and so you can catch orbs from nearby players.

### Affix: Devour

5.4.

#### Devour Affix Management

**Xalatath's Bargain: Devour** applies a debuff to each party member, which
must be either dispelled or healed off (though bear in mind this <em>does not</em>
absorb incoming heals). Each debuff dispelled provides the group with maximum
health and Critical Strike, stacking, for 30 seconds. Any debuffs <em>not</em>
cleared will heal nearby enemies a large amount.

On these weeks, we recommend picking up [[spell:2782]]
to help your healer by removing it from yourself instantly. Shapeshifting out of
[[spell:768]] will also remove it, as a small slow has been added to the effect
in Midnight. Lastly, if that's not an option, [[spell:22842]] will
quickly cover a large amount of the healing requirement when healers are
struggling.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for release of Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for new Class Tree talent gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **28 Aug. 2025:** Added Mythic+ Utility Talent cheat sheet for use cases in each dungeon.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **28 Apr. 2025:** Added individual dungeon tips.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, corrected Druid of the Claw tree link and added recommended tags.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for War Within Season 1 release.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, shifted recommendation to Convoke and added note regarding 2-minute trinkets.
- **10 Nov. 2023:** Restructured and updated for Patch 10.2.
- **06 Nov. 2023:** Updated link to Mythic+ hub.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, changed recommended build to a more Rake focused one.
- **10 Jul. 2023:** Updated for Patch 10.1.5 and added Dire Fixation to build.
- **01 May 2023:** Updated for Patch 10.1, small build changes and added new Affix details.
- **20 Mar. 2023:** Reviewed and updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Feral Druid in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Feral Druid macros.

2.

### Feral Druid Macros

Macros are accessible through the /macro command in-game, and allow you to
create small scripts that will be executed when you press a keybind. These are
very useful for combining multiple actions into one, so a common example is
combining off-GCD trinkets with cooldowns within one press.

2.1.

#### Rebirth

#### Mouseover Combat Res

```wow-macro
#showtooltip
/stopcasting
/cast [@mouseover,help]Rebirth;Rebirth
```

This macro casts [[spell:20484]] on your mouseover target, if they are a
friendly player. Otherwise, it casts Rebirth on your current target.

2.2.

#### Remove Corruption

#### Mouseover Dispel

```wow-macro
#showtooltip
/cast [target=mouseover,help,nodead][target=target] Remove Corruption
```

Using this macro will cast [[spell:2782]] on your mouseover
target, if they are a friendly player and they are not dead. Otherwise, it
will cast Remove Corruption on your current target.

2.3.

#### Skull Bash Focus Interrupt

This will target your interrupt on your focus, so you do not need
to switch targets for a key cast. Note you need to set up your focus
beforehand with a /focus macro for this to work.

#### Focus Interrupt

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] Skull Bash
```

2.4.

#### Innervate Macros

Casting [[spell:29166]] quickly when a healer needs it has two options.
You can either opt to focus your assigned healer and cast on them with this
macro:

#### Focus Innervate

```wow-macro
#showtooltip
/cast [@focus,nodead], [@target,nodead] Innervate
```

Or use a mouseover macro and highlight them on your party/raid frames:

#### Mouseover Innervate

```wow-macro
#showtooltip
/cast [@mouseover,nodead], [@target,nodead] Innervate
```

Otherwise, both of these macros will default to casting on your current
target when used.

2.5.

#### Ursol's Vortex into Typhoon

This macro can be used as a cast sequence on the same keybind,
casting [[spell:102793]] into [[spell:132469]] sequentially to pseudo-grip
enemies in 2 key presses. The @cursor is to instantly place the
Vortex at your cursor, and can be removed if you want to manually
press it, or replace it with @player if you want to place it
underneath yourself:

#### Ursol's into Typhoon

```wow-macro
#showtooltip
/castsequence [@cursor] reset=20 Ursol's Vortex, Typhoon
```

3.

### Best Addons

Most of your UI needs can be met with some effort using the new Blizzard UI
options in Midnight, but if you're looking for some extra customization, below are
some popular choices.

3.1.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) is a complete replacement of the default
User Interface. It comes with almost everything you need to perform properly:
action bars, unit frames, cooldown timers, proc displays, etc.

3.1.1.

##### Boss Mods: Deadly Boss Mods or Bigwigs

Boss mods are addons that warn you about boss abilities and give you
live advice on how to handle some mechanics. We strongly recommend you to
get one such addon. At Icy Veins, we mostly use
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>),
the most popular boss mod. A good alternative is
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5. Added some notes regarding Regrowth shapeshift macro.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, no changes necessary.
- **06 Nov. 2023:** Added Innervate macro for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **29 Apr. 2023:** Reviewed for Patch 10.1, no changes necessary.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Added some additional mouseover and talent macros.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
