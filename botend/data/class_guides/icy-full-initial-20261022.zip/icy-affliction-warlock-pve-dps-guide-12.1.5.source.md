## 专精概览

Welcome to our Affliction Warlock guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as an Affliction Warlock in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Affliction Mythic+ Resources

[NEW! Top Affliction Talent Builds](<https://raider.io/specs/affliction-warlock/talents>)

[Top Affliction Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warlock/affliction>)

[Affliction Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warlock--affliction>)

[Popular Affliction Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warlock--affliction>)

1.

### Affliction Warlock Overview

Affliction Warlock excels at sustaining single-target and
multiple-target damage. Most of your damage comes from applying harmful damage
over time effects (DoTs). This allows them to effectively cleave on targets
spread around an area, something many specializations struggle with or cannot
do. Like the other Warlock specializations, Affliction Warlocks bring the
[[spell:111771]] ability to the raid, which can be an invaluable mobility
cooldown.

Versatile Damage Profile

Affliction Warlock damage can be adapted to most encounters, with access to
execute, hard swap, burst and funnel capabilities, on relatively short
cooldowns — generally every minute. The minor drawback is having to
dedicate either side of the 3rd gate towards ST or AoE.

Reliable Raid Choice

In Midnight, Affliction Warlock bring higher mobility and an overall
balanced talent setup that cover anything but heavy multi-target. The ramp up
has been substantially shortened and the hard swap capabilities are now on
pair with Destruction, while retaining generally better cooldowns.

Well rounded in Mythic+

Affliction in keys is a very fluid spec that plays well transitioning
between different target counts and has good enough burst and funnel
potential. The specialisation brings a balanced kit that sits in-between
Demonology better single target and Destruction stronger AoE past 11 targets,
without suffering from any ground targeted AoE shortcomings.

Beside that, Midnight brings to the Warlock class a lot of
utility, in the form of Banes and AoE curses, as well as one of the highest
survivability across all classes.

High Utility

[[spell:111771]]s are typically a must in a raid environment,
while [[spell:20707]]s and [[item:5512]]s provide nice quality
of life benefits for the entire raid.

However the situation is different in Dungeons, as the gateway is only
used for the occasional skips, Soulstones are a combat resurrection with a cast time,
and Healthstones are just slightly better potions.

Curses are in a better spot, offering AoE application and a stronger, but
timed, variant in Blights. Pets can also be considered part of the utility,
but realistically, it is just about using Felhunter for Spell Lock and Devour
Magic, unless a Dispel is badly needed from Imp.

Good Mobility

Affliction is a rather mobile spec outside of its cooldowns, especially for a Warlock.
Depending on the talent configuration, there are multiple procs that can
be saved for movement windows, alongside refreshing your DoTs.

Among the Best

Warlock's survivability in Midnight is exceptional. While the class lacks
immunity or damage reversal tools, the main mechanic is to buffer the
existing Health Pool with Overshielding from [[spell:108370]], mitigation
from [[spell:108415]], and active defensive spells like [[spell:108416]]
and [[spell:104773]].

2.

### Affliction Warlock in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

The patch features no Warlock changes and is instead focused on two new
endgame activities, a new Raid and the anticipated Labyrinth Mega-Delve. Make
sure to check the following links for further details:

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

This patch continues Season 2 storyline and gear progression, focusing on
quality of live improvements, new solo-focused content
with [Aqir Invasions](<https://www.icy-veins.com/wow/aqir-invasions-guide>), and much more! Make sure to visit our hub page
if you're curious what else awaits you with the 12.1.5 launch, and
beyond.

2.3.

#### Class Changes

Affliction Warlock received no changes for Patch 12.1.5, so the most recent changes to
the spec happened early into Season 2. Gear page has been updated with all the new
items from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>), as well as recommendations on how to use [[item:280562]]
once they become available.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 ChangesHide Patch 12.1 Changes
August 25 Hotfix brings several buffs to Affliction to bring it closer to
Destruction nominal performance, specifically in single-target and Raids
scenarios. While DoT damage has been also increased, Affliction is still
currently the third spec in terms of AoE damage.

[Midnight Hotfixes August 25](<https://us.forums.blizzard.com/en/wow/t/world-of-warcraft-midnight-hotfixes-august-25/2336376/68>)

**Warlock**

<em>Developers’ notes: We’re increasing the throughput of Affliction and
    Demonology by primarily focusing on their single-target tools with a
    secondary focus on their multi-target kit. Additionally, we’re
    considerably increasing the damage of Warlock demons so that they have a
    larger contribution to overall throughput. This should also help a bit
    more with aggro concerns during solo play.</em>

- Imp, Voidwalker, Sayaad, and Felhunter damage increased by
        350%.

**Affliction**

- Unstable Affliction damage increased by 15%. Does not apply to PvP
        combat.
- Hellcaller – Blackened Soul damage increased by 20%. Does not apply
        to PvP combat.
- Wrath of Nathreza damage increased by 35%. Does not apply to PvP
        combat.
- Shadow of Nathreza damage increased by 25%. Does not apply to PvP
        combat.
- Agony damage increased by 20%. Does not apply to PvP combat.
- Corruption damage increased by 15%. Does not apply to PvP
        combat.
- Hellcaller – Wither damage increased by 10%. Does not apply to PvP
        combat.

Heading towards Patch 12.1 Affliction Warlock received several changes
affecting both Hero and Spec trees, alongside bugfixes to the spec and the
baseline [[spell:108370]] which now offers a more substantial defensive
layer.

The changes relative to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller shift the use case towards
single target with priority damage, but at the time of writing are missing
the mark entirely, resulting in lower single target output
than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester and severely worse AoE and cleave by design.

[Curse of Ula'tek Patch Notes](<https://us.forums.blizzard.com/en/wow/t/2317811>)

**Hellcaller**

<em>Developers’ notes: We’re updating Blackened Soul to give Hellcaller
    a better tool for focusing damage into a priority target, increasing the
    overall flexibility of the hero talent tree rather than have it only
    excel in situations where multiple targets are present. However, we are
    keeping the functionality of Malevolence the same, so it remains a cool
    and impactful tool in Hellcaller’s toolkit.</em>

- Blackened Soul has been redesigned: If the target is
        afflicted with your Wither, casting Unstable Affliction
        increase its stack count by 1. Each time Wither gains a stack it has a
        chance to collapse, consuming a stack every 1 second to deal
        Shadowflame damage to its host until 1 stack remains.
- Mark of Peroth’arn has been redesigned: Damaging critical
        strikes dealt by Wither deal 215% damage instead of the usual 200%.
        Damaging critical strikes dealt by Blackened Soul deal 225% damage
        instead of the usual 200%.
- Blackened Soul damage increased by 45%.
- Wither damage increased by 25%.

Talent tree changes successfully address two major issues that
emerged with Midnight: Shard overflow in multitarget situations, with changes
to [[spell:1260264]] and the removal of [[spell:1260271]] and
the asymmetric value proposition in the third gate talents where right side
and [[spell:27243]] nodes were substantially more palatable
than [[spell:1259790]] options.

[Curse of Ula'tek Patch Notes](<https://us.forums.blizzard.com/en/wow/t/2317811/16>)

**Affliction**

<em>Developers’ notes: Patient Zero warps the damage profile of Seed of
    Corruption heavily. The specific use-case for Seed of Corruption as a
    tool is to supply damage in multi-target situations and having the
    ability to increase priority damage dilutes its identity. Hedonic Gorging
    is a new talent that hooks into the common throughline of health leech
    between Drain Life, Siphon Life, and Dark Harvest. The intention for this
    talent is for most of the throughput to reside in Siphon Life and Dark
    Harvest while the increase to Drain Life is meant to be smaller and a bit
    of flavor.</em>

- New Talent: Hedonic Gorging – Increases Drain Life damage by 10% and
        Siphon Life now increases the damage of Corruption by an additional
        10%. Dark Harvest channels 10% faster and deals 15% increased
        damage.
- Patient Zero has been removed.

<em>Developers’ notes: Nocturnal Yield doesn’t offer much choice when it
    comes to how a Warlock chooses to spend their Nightfall. Instead, it is
    usually best spent on Seed of Corruption, regardless of target count.
    This can have adverse effects on talents that benefit from Shadow Bolt or
    Drain Soul. We like the feeling of occasional free Seeds of Corruption
    though and are merging that functionality into Shard Instability. In
    place of Nocturnal Yield, we are introducing a new talent called
    Impetuous Wrath that will serve as another means of Affliction accessing
    additional priority damage.</em>

- New Talent Impetuous Wrath: Shadow Bolt, Drain Soul, and Malefic
        Grasp damage increased by 10% or 20% if the target is affected by
        Haunt. Dark Harvest damage increased by 10% or 20% if the target is
        affected by Haunt.
- Shard Instability has been redesigned – Damage dealt by Shadow Bolt
        or Drain Soul has a 20% chance to make your next Unstable Affliction or
        Seed of Corruption cost no Soul Shards and cast instantly.
- Nocturnal Yield has been removed.
- Haunt now increases your damage dealt to the target by 16% for 18
        seconds (was 12%).

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Summary for Affliction Warlock

The most prominent feature of the expansion are the Apex talents which will
be gradually available during leveling. These points exist separate from the
tree and have to be invested sequentially in order to unlock the later
points.

1. [[spell:1261984]]
2. [[spell:1261990]]
3. [[spell:1261992]]

These talents mostly provide background power and do not affect the
rotation itself. However, they are largely responsible for Affliction's
ability to hard swap targets in a short timeframe, and thus help round up
the spec's toolkit.

2.5.

#### Summary of Changes

- **Hero Talents** received minor baseline changes and an addition of a fourth column.  
  
  
   ► **Click to expand**
  
  
  2.5.1. 
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller
  
  
  
  
  - [[spell:440055]] was changed to
              support [[spell:1260264]] talent
  - New Talent: [[spell:1266799]] increase the damage of
              baseline shard spenders, doubled
              during [[spell:430014]]
  - New Talent: [[spell:1266805]] [[spell:445465]] has a chance to
              grant [[spell:430014]]
  - New Talent: [[spell:1266803]] [[spell:430014]] grants
              additional Haste and casting the ability adds more [[spell:445465]]
              stacks
  
  
    
  
  
  
  2.5.2. 
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester
  
  
  
  
  - [[spell:449638]] now triggers from [[spell:1257052]]
              since Soul Rot has been deprecated
  - New Talent: [[spell:1268884]] each Succulent Soul
              consumed has a chance to trigger [[spell:1239714]] for additional
              damage on all targets within 10 yards
  - New Talent: [[spell:1268889]] increase Mastery by a
              percentage which is doubled when [[spell:449614]] triggers
  - New Talent: [[spell:1268903]] increases duration and damage
              of [[spell:1268884]]
- Substantial changes happened to core/rotational **Affliction Warlock** spells.  
  
  
   ► **Click to expand**
  
  
  - [[spell:1259790]] is the baseline single target shard
              spender
  - [[spell:324536]] has been removed
  - [[spell:386997]], [[spell:278350]]
              and [[spell:205179]] have been removed as a
              consequence
  - [[spell:1257052]] is a new 1 minute cooldown that deals
              damage on every target affected by at least 1 baseline DoT
              effect
  - [[spell:980]] now has a maximum of 6 stacks and
              with [[spell:1260209]] the ramp time has been substantially
              lowered
  - To apply more than 1 [[spell:980]] per
              cast, [[spell:1259825]] has been introduced
  - [[spell:205180]] is a single target spell baseline that
              function as a damage amplification, and now has supporting talents
              such as [[spell:1261149]] and [[spell:1280733]]
  - [[spell:27243]] is the main AoE shard spender and has
              received supporting talents to increase its output in the likes
              of [[spell:196226]], [[spell:1260285]]
              and [[spell:1260271]]
  - [[spell:234876]] damage bonus has been quadrupled
- Few noteworthy changes also happened to Warlockutility spells.  
  
  
   ► **Click to expand**
  
  
  - [[spell:1714]] and [[spell:334275]] are now
              separate talents
  - [[spell:1265813]] has been added, allowing every curse to also
              affect enemies around 10 yards of the main target
  - Blights were introduced, offering a more powerful version of
              Curses, with a shorter duration and cooldown associated
  - [[spell:5484]] is now a choice node
              with [[spell:30283]] and has a new supporting talent
              in [[spell:1270255]], reducing its cooldown and affecting
              up to 10 targets
  - [[spell:755]] has been removed and its healing has been
              added to [[spell:234153]] with [[spell:1265810]]

3.

### Basics of Affliction Warlock Gameplay

Affliction Warlock is a spec centered around Damage over Time effects,
cooldown periods that require a setup to get the most out of them, and a
relative amount of pet management. At its core, the gameplay is about generating
and spending the Warlock's iconic resource: Soul Shards.

The fundamentals are simple: maintain [[spell:172]] and [[spell:980]]
on the target(s), spend your Soul Shards on [[spell:1259790]]s or
[[spell:27243]], and cast [[spell:232670]] in the
downtime. These three concepts outline everything in a condensed format.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_curseofsargeras.jpg>) **Keep Agony Rolling**  
  
  [[spell:980]] is the main source of Soul Shard generation for Affliction, so it is 
    important to try and maintain up to 4-5 Agonies rolling, depending on target count, 
    as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **Spend Those Soul Shards**  
   
    Warlock is a class designed around the idea of generating and spending resources. 
    As Affliction spending Soul Shards also reduces the cooldown of [[spell:1257052]] 
    via [[spell:453056]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) **Use your Short Cooldowns**  
  
  [[spell:48181]] and [[spell:1257052]] have short cooldown and should be casted as 
    much as possible, as those are powerful spells with reset or cooldown reduction 
    mechanics.

4.

### How to Gear Up as a Affliction Warlock

While we always recommend simming yourself for ideal results, we do provide a
dedicated Affliction gearing page. We currently cover recommendations for
the ongoing Season gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket list.
- **31 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated Hellcaller talents.
- **31 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation section.
- **31 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated Dungeon talent recommendations.
- **25 Aug. 2026 (this page):** Updated for August 25 Hotfixes.
- **16 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated BiS lists, embellishment and trinkets to account for a new profile and trinket tuning.
- **16 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated consumables to reflect new BiS lists.
- **11 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated Gems and FAQ sections.
- **11 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Changed Flask and updated Gems.
- **11 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated Talent choices.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Added Omnium Folio for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **30 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated Single target talent recommendations.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Tea section.
- **23 Mar. 2026 (this page):** Updated Mythic+ viability section.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated Trinket ranking to account for Gaze nerf.
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Expanded the Tier Set bonuses section.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Added a lv80 import for leveling to Midnight.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated talent tree for Midnight release.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Midnight Release.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Updated for Midnight release.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Midnight release.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated Rotations and added Apex sections for Midnight release.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated talent trees and added Apex section for Midnight release.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Added Apex for Midnight release.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Added an Apex section and updated talents for Midnight Release.
- **26 Feb. 2026 (this page):** Updated Performance and Apex sections for Midnight Release.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated talent trees for the changes to each gate unlock.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated talent trees for the changes to each gate unlock.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated talent trees for the changes to each gate unlock.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviwed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **22 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated weapon enchants.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated DISC socket recommendation following tuning.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7 and DISC.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Added a section for Combat Assistant.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Added a section for the Combat Assistant.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **04 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket recommendations.
- **19 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Updated talent recommendations.
- **04 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated BiS lists and trinket ranking.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7. and Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** Updated talents recommendations.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Reviewed for Patch 11.0.5.
- **25 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Re-done page layout, updating sections accordingly.
- **19 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5 and added a dungeon tooltip section.
- **12 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated weapon enchants and oils.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Added BiS lists for Season 1, updated trinket section.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated gems section, as the strategy changed.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated talent selection for Season 1 launch.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated talents recommendation for Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Updated Viability assessment to reflect Season 1 status.
- **26 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Added a Delve talents reccomendation.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Added a leveling playstyle section.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Added Pre-Season BiS list section.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Added Hero Talent sections and selectors.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated recommendations to feature Hero Trees.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated sections to account for Hero Talents.
- **21 Aug. 2024 (this page):** Updates strenghts/weaknesses and viability sections.
- **01 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Added a Oblivion-less talent variants.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/affliction-warlock-mists-of-pandaria-remix-guide>)):** Page updated for The War Within pre-patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **19 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/affliction-warlock-the-war-within-pve-guide>)):** Updated for The War Within pre-patch.
- **19 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **19 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/affliction-warlock-the-war-within-pve-guide>)):** Page Created.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/affliction-warlock-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Updated for Patch 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Season 4 launch.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Updated for Dragonflight Season 4.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket section for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **28 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated multitarget section after 4p fix.
- **24 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Removed outdated lines.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Embellishment recommendations updated after Undulating Sporecloak has been annihilated.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated Gear recommendations for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Talents updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Reformat of the page with BiS tables and section updates.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Restructured Talent section.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.7
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Talents updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated selector for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated talents for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for talent changes in Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated talents for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Added Patch 10.1.5 and updated the viability sections.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Phial recommendation after Corrupted Rage buff.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Reviewed talents for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for patch 10.1.
- **01 May 2023 (this page):** Added a new section for patch 10.1 and updated the viability section.
- **24 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated Onyx Annulet section to account for live hotfixes.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stones recommendations to account for the additional live hotfixes.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stones recommendations to account for 25% buff hotfix.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated talent tree for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/affliction-warlock-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Added Patch 10.0.7 new ring section. .
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Added Primordial Stones section for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Talents updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated talents for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated talent trees to reflect class and spec changes for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated talents for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Added Patch 10.0.7 and updated the viability sections.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Talents updated for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated talents for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for talent changes in Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Updated for Patch 10.0.5.
- **11 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated opener and Darkglare sections.
- **07 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated dungeon phial to a more reliable Phial of Tepid Versatility.
- **23 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated talent tree.
- **14 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Weapon Runes.
- **13 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated Embellishment recommendations.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Season 1 launch.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated selectors for the openers and priority lists.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/affliction-warlock-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/affliction-warlock-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/affliction-warlock-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **10 Mar. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-2-changes-analysis>)):** Updated to reflect the set bonus buff.
- **22 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-2-changes-analysis>)):** Updated to reflect Patch 9.2 launch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-1-changes-analysis>)):** Updated for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-1-changes-analysis>)):** Removed PTR disclaimer.
- **27 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-1-changes-analysis>)):** baseline changes, legendary and covenant recommendations updated.
- **05 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-1-changes-analysis>)):** Page created.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **14 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-the-eternal-palace-raid-guide>)):** Updated Boss Tips and Talent/Essences selection.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated after recent raid nerfs.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **11 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated with better talent choices, and more tips.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-uldir-raid-guide>)):** Updated for 8.1 Patch. Reviewed all talent suggestions.
- **30 Oct. 2018 ([Uldir page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-uldir-raid-guide>)):** Updated Uldir boss suggestions.
- **07 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-uldir-raid-guide>)):** Updated for Uldir.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Affliction Warlock leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Warlock leveling guide](<https://www.icy-veins.com/wow/warlock-leveling-guide>).

1.

### Affliction Warlock Leveling Guide for Midnight

Affliction Warlock being a DoT specialization offers a very
efficient leveling experience consisting of tagging multiple mobs with
either [[spell:980]] or [[spell:172]] while moving towards the next
target or area. The damage over time, coupled with the pet, is generally
strong enough to leave the targets severely weakened, if not outright dead, by
the time they can be finished off with AoE spells.

Curses, crowd controls, and pet off-tank can substantially reduce the amount
of incoming damage, promoting aggressive play, while all the personal
defensive cooldowns offer a degree of safety even when overpulling.

For bigger enemies, such as Elites or Rares, sustaining your Voidwalker is
usually the priority while slowly whittling them down, as the threat generated
by the pet cannot match heavy spender bursts.

1.1.

#### Leveling Gear Options

When leveling up, you should always choose the piece of loot with the
highest item level. If the item levels are equal, you should choose the piece
with stats that are most favorable to your specialization. If your current item
is an Heirloom, it should not be replaced.

While the most important aspect of Heirloom is the bonus Experience, to get
most out of their stats allocation, you want to prioritize Intellect, then
Haste, then Critical Strike. The reason behind this is that Haste generally offers a
smoother combat experience while increasing your DPS in a homogeneous way,
unlike Critical Strike, which is still important but less consistent by
nature.

Being able to cast faster offers the advantage of tagging mobs quicker and
overall has a nicer feeling when most of the actions complete quicker.

1.2.

#### Useful Leveling Consumables for Midnight

Listed below are several consumables that can be leveraged to quicken the
leveling process and are generically beneficial regardless of tuning.

The War Within enchants will still work throughout the leveling process,
and can help augmenting character speed. Prioritize the following:

- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

Combat potions give a burst of power and if anything its best to use them
before they become irrelevant at max level.

These consumables are mostly aimed at speeding up the traversal and navigation.

- [[item:109076]]
- [[item:132516]] or [[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]] or [[item:133576]]

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Affliction Level 80 Midnight Leveling
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAYMjZGNLmx2MzYWGAAwMzsMbzMzyYAgx2yADYAzwWghtBAAADAAAMmZYMzYGMzMzYYGjBAMAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAYMzMzoZxM2mZGzyAAAmZmlZbmZWGDAM2WGYADYG2CMsNAAAYAAAMzMmZYWmhZMmZmZMMjxAAGwA"
}
```
:::

:::details 来源计算器编码
```
#JE-ITVVUUHDPfiklbLMOJSD80kw01ZkdF1ZURB-JdKBIcLMy44spNQQCQM6wDS4DLMsyqA-AAAA-JEUocE0YAJQDzC-
```

:::

2.1.

#### War Mode Talents for Leveling

1. [[spell:221711]] stacks a damage reduction effect on enemies that
   are damaged by your [[spell:234153]]. You can reduce their damage by up
   to 25%, which is a large increase in your ability to survive and
   sustain.
2. [[spell:234877]] causes damage over time effects to strike an
   additional time for 20% of their original damage while active. This offers
   a little bit of extra burst damage on a short cooldown.
3. **等级 30 起：**[[spell:335052]] is great in multitarget
   as [[spell:1259790]] is now our hardest hitting damage over
   time.
4. **等级 49 起：**[[spell:248855]] should always be considered
   to expedite your whereabouts in closed spaces where mounts are not
   usable.
5. **等级 55 起：**[[spell:353753]] can offer further AoE burst
   when kiting targets around.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1 起：**Starting at Level 1, you only have one main attack
ability: [[spell:232670]].

1. **等级 11 起：**Maintain [[spell:980]] on the
   target. Prioritise it over [[spell:172]] when tagging mobs.
2. **等级 17 起：**Cast [[spell:48181]] on the main target.
3. **等级 13 起：**Spend shards on [[spell:1259790]]
   if there is 1 to 2 targets. Consider casting it on dying enemies to gain 1
   Shard in the process.
4. **等级 33 起：**Cast[[spell:1257052]] after having
   at least 1 dot applied to every targets you are in combat with.
5. **等级 2 起：**Use [[spell:172]] to tag and soften up multiple
   enemies whenever spamming a few shadow bolts will not kill them
   quicker.
6. **等级 37 起：**Cast [[spell:205180]]
   after having applied as many Damage over Time effects as possible.
7. **等级 15 起：**Cast [[spell:27243]] when there are 3 or
   more targets.

:::details TipsHealing Your Demon
Do not forget to keep your Demon healthy in combat
using [[spell:234153]] with [[spell:1265810]].

:::

:::details TipsDo Not Underestimate Curses!
With the introduction of [[spell:1265813]], Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:440057]] is unique to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and combines
  	the above two curses
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

:::

4.

### Pet Choice while Leveling

[[spell:688]] is your first available demon
but is best suited to Raid Environments. This pet is not particularly useful
for leveling, but you have no choice for the early levels.

If you are leveling alone, [[spell:697]]
can be a helpful choice while leveling up, as it takes a lot of the pressure
off you. Avoiding casting pushback can also increase leveling speed.

[[spell:691]] can be a good choice if
you are leveling in a group or venturing into dungeons. The extra interrupt
is helpful for dealing with troublesome caster mobs.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **02 Mar. 2026:** Added a lv80 import for leveling to Midnight.
- **26 Feb. 2026:** Updated talent tree for Midnight release.
- **10 Feb. 2026:** Updated talent trees for the changes to each gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviwed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Added a leveling playstyle section.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **24 Nov. 2023:** Removed outdated lines.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated talent tree for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Affliction Warlock in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Affliction Warlock

This section is intended for players who are new to the game or class, have
no intentions of raiding Mythic difficulty or want a more straightforward way to
play their specialization without being overwhelmed by the numerous priorities
and active abilities that need to be taken into consideration for optimal play.

Affliction is a specialization that revolves around maintaining damage over
time effects on your active targets. While it may not have many buttons, it
requires careful attention to cooldowns and uptimes, with the level of
complexity increasing with the number of targets. Despite that, it is a good
specialization for all levels of players, and you can streamline it to a simple
set of priorities. Listed below are three simple rules to help you understand 
the spec.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_curseofsargeras.jpg>) **Keep Agony Rolling**  
  
  [[spell:980]] is the main source of Soul Shard generation for Affliction, so it is 
    important to try and maintain up to 4-5 Agonies rolling, depending on target count, 
    as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **Spend Those Soul Shards**  
   
    Warlock is a class designed around the idea of generating and spending resources. 
    As Affliction spending Soul Shards also reduces the cooldown of [[spell:1257052]] 
    via [[spell:453056]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) **Use your Short Cooldowns**  
  
  [[spell:48181]] and [[spell:1257052]] have short cooldown and should be casted as 
    much as possible, as those are powerful spells with reset or cooldown reduction 
    mechanics.

2.

### Beginner's Guide to Affliction Warlock in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester   Beginner Talents

2.1.

#### Beginner All-Around Talents for Affliction Warlock

This build is optimized for ease of use while offering a setup that
works in any situation with no adjustments required, including Raid, Mythic+,
and even Delves. This is not the optimal choice in either single target or multi-target in
terms of output, but serves as a build that can help players become familiar with the
specialization at its core before moving on to more specialized builds from our Talents page.

[Affliction Warlock Talents and Builds Page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)

To import this all-rounder build directly in-game, click on the export button at the
bottom of the calculator:

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAgZmZGNLmxiZGzyAAAMjlZbmZWGDAM22GYADYGWCMsNAAAMDAAgZmxMjZ2mZMjxMzMjhZmxAAGwA"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPfhiklnELM028MTjchprrowwJbM-JKcdBILMy44sJS4ISSbCz7LMEqyS4pA-AAAA-HIOQ0AEUYhhCzC-
```

:::

### Affliction Warlock   Basic Rotation

2.2.

#### Single-Target Rotation

1. Maintain the [[spell:980]] DoT.
2. Maintain the [[spell:172]] DoT.
3. Cast [[spell:48181]] on cooldown.
4. Cast [[spell:1259790]] when you are at 5 Soul Shards (to avoid wasting
    Shards).
5. Cast [[spell:1257052]] on cooldown.
6. Cast [[spell:198590]] as a filler.

:::details FAQWhat Pets/Demons Should I Use?
In Dungeons and Mythic+, we recommend using/sacrificing the Felhunter, as
interrupt is invaluable for such environments. This of particular importance in
higher levels of Mythic+, as certain spells can cause wipes for the group.

In Raid environments, we recommend using the Imp, if the encounter requires
[[spell:89808]] to be used or there are frequent target swaps.

The Voidwalker is recommended for leveling, or for environments where you
plan to use [[spell:108503]], but do not need the interrupt from
Felhunter. Sacrificing a Voidwalker grants the [[spell:17767]] skill
to the player, a defensive cooldown that provides increased survivability to
the player.

The Succubus generally offers slightly higher damage than Imp or Felhunter,
and can be used if you prefer the visuals, or need a permanent 50% slow on a
single target.

:::

2.3.

#### Multi-Target Rotation

When at least two targets are stacked together, you should always use
[[spell:27243]] as the main shard spender and with
[[spell:108558]] procs. Keep [[spell:980]] applied to all targets
(up to 5) for Soul Shard generation and damage.

Try to react to [[spell:1260264]] procs so you can leverage
free [[spell:1259790]]s.

Remember to refresh [[spell:980]] within its pandemic window to be as
efficient as possible.

If targets are dying, use [[spell:198590]] to get an easy shard off them.

:::details TipsHealing Your Demon
Do not forget to keep your Demon healthy in combat
using

[[spell:234153]]

with

[[spell:1265810]]

.

:::

:::details TipsDo Not Underestimate Curses!
With the introduction of

[[spell:1265813]]

Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:440057]] is unique to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and combines
  	the above two curses
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

:::

2.3.1.

##### Apex Talent: ![Shadow of Nathreza Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_112_raidtrinkets_blobofswirlingvoid_gold.jpg>) Shadow of Nathreza

[[spell:1261984]] at any rank simply increase [[spell:48181]] damage
both directly and indirectly and requires no additional thoughts as it is
already one of the most valuable spells that should be casted on
cooldown.

2.3.2.

##### Season 2 Tier Set

Season 2 tier set bonuses provide passive damage increase and a bit more
priority damage in AoE.

### Affliction Warlock   Stat Priority

2.4.

#### Stat Priority for Affliction Warlock

Currently, you will want to prioritize secondary stats as follows.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>).

Item Level

Haste

Critical Strike

Mastery

Versatility

### Blizzard   Combat Assistant

2.5.

#### Combat Assistant For Affliction Warlock

The [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) is comprised of two main features:

- **Assisted Highlight:** Displays the next spell to be queued, in a
  adequately accurate rotation single target and limited capabilities in
  multitarget, best used to familiarize with the flow and cadence of the
  spec.
- **Single Button Assistant:** Enables use of a single input for multiple
  skills in the sequence prompted by the Assisted Highlight, at the
  expense of a longer base global cooldown (which accounts for an
  additional 5% to 10% dps loss).

**It is worth pointing out that these tools are accessibility features first
and foremost, and should not be considered a direct replacement to learn a
spec nor the logic behind it.**

The areas where the Combat Assistant struggle the most
for Affliction Warlock are:

- DoT uptime, since there is no supported logic for the Pandemic
  mechanic, especially aggravating in multitarget
- Multi-target in general, due how it considers all targets stacked
  regardless of the situation
- Cooldown usage, since it is either missing, or there is no preparation
  entering a given cooldown

2.6.

#### Combat Assistant Tips

- Cooldown alignment has to be done manually, especially considering
  racials, potions, and on-use equipment.
- DoTs should be refreshed within Pandemic range, as following the
  Combat Assistant blindly will result in much lower uptime.
- In situations with multiple targets far away, consider manually
  applying [[spell:172]] or [[spell:445465]] instead of
  using [[spell:27243]] when suggested.
- In general, try to maximize the amount of time spent casting,
  especially when using the Single Button Assistant, as downtime is one
  of the improvement areas at any stage of the game.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Added an Apex section and updated talents for Midnight Release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Added a section for the Combat Assistant.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated sections to account for Hero Talents.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated talents for Patch 10.1.5.
- **01 May 2023:** Reviewed for patch 10.1.
- **20 Mar. 2023:** Updated talents for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **23 Dec. 2022:** Updated talent tree.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Affliction Warlock in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Affliction Warlock

In Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester positions itself as the dominant
choice. The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller rework is sadly followed by poor tuning and thus is
not really that compelling of a choice for Affliction. Whilst there are still
some opportunities for personal preferences and situational adjustments, below are our
current recommendations:

- **Single Target**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester offers around 2% higher
    single-target, extending its lead when cleaving a small amount
    of targets, or when quick AoE burst is involved in
    encounters.
- **AoE**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester is better in any dungeon
    environment, as the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller rework has severely impacted its
    AoE capabilities.

**Quick Start Import Codes:**

:::talents Affliction Single-Target - Soul Harvester
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZ2mZmlxAAjllBGwEMDbBG2GAAAmBAAwMDzMjBzwMzMzMGMzMzAAmBG"
}
```
:::

:::talents Affliction AoE - Soul Harvester
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgx2yADYCmhtADbDAAAzAAAYmZMzwsxwYmZmZYYmZmBAMDMA"
}
```
:::

:::talents Affliction Delves - Soul Harvester
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgxyyADYAzwWghtBAAgZAAAMzMmZY2GjZwMzMMMzMzAAmBG"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Soul Harvester

Single-Target

recommended

Mythic+

recommended

Delves

Hellcaller

Mythic+

### 天赋方案 0-0

1.1.

#### Single-Target Talents

Affliction single-target as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester revolves around
spending shards aggressively to reduce the cooldown
on [[spell:1257052]] while trying to maintain high uptime
on [[spell:1261124]].

### 天赋方案 0-1

1.2.

#### AoE/Mythic+ Soul Harvester Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester in Mythic+ offers better overall damage and a
faster gameplay.

The Hero tree encourages players to spend shards fast and frequently,
to leverage [[spell:1257052]] casts as often as possible.

Due to Shard abundance, [[spell:198590]] shard sniping is not as
important, and instead using [[spell:686]]s can offer more
mobility.

### 天赋方案 0-2

1.3.

#### Delve Talents

Hero talents do not make much of a difference,
but ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester offers better defensives, plays more fluidly
and has better short burst loops, thanks
to [[spell:449637]], [[spell:449634]] and [[spell:449631]]
all triggering off [[spell:48181]] casts.

### 天赋方案 1-0

1.4.

#### AoE/Mythic+ Hellcaller Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller in dungeons is a 1-minute damage profile centered
around [[spell:430014]], with higher burst potential and an emphasis
on [[spell:980]] uptime on as many targets as possible, since the shard
generation is slower in comparison.

[[spell:1279521]] can be swapped for [[spell:1260209]] for
easier [[spell:980]] uptime at the expense of some damage overall.

[[spell:453080]] can be swapped with [[spell:198590]] for
more shard sniping.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZ2mZmlxAAjllBGwAmhtADbDAAAzAAAYmhZmxgZYmZmZGDmZmZAAzAD"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPSfgiklnoELM08MTtuw01JUUYkB-JKcdBILe2IUYkxxRTc4IzDEcEai6CTA-AAAA-HIOQ2AEQQhhCzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgx2yADYAzwWghtBAAgZAAAMzMmZY2YYMzMzMMMzMzAAmBG"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPSfiklnoELM028MTjchprTwwJbM-JKcdBILe2IUYgxxRTc4IzbEAaCLMUwC-AAAA-HIOQ2AEUQhhCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgxyyADYAzwWghtBAAgZAAAMzMmZY2GjZwMzMMMzMzAAmBG"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPSfiklnoELM028MTjchprTwwJbM-JKcdBILe2IUYgxxRTc4IayLMcEAqySA-AAAA-HIOQ2AEQQhhCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAmxsMLzMzyYAALwAziRjZAMbglBAAgBAAMzgxMzY2YYmZMzMmhZmZGAwMwA"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPfgiklnoELM028MTjehprTwwJbM-JKcdBILe2IUYgxxRc4IbEYCzDEMM06C-AAAA-IQSU2AIQYgxBzC-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

Introduced in [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), Omnium Folio is a new source of player
power that unlocks over the course of few weeks and offers a choice of small
but flexible bonuses that can be swapped at any time to match the desired
content. The selection of Runes can be tailored to offer throughput, or pivot
to survivability and utility.

The following list is the recommended guideline, point by point:

1. [[spell:1279599]]
2. [[spell:1279603]] or [[spell:1279604]]
3. [[spell:1287555]]
4. [[spell:1279609]]
5. [[spell:1279615]] and [[spell:1279614]] offer similar output

:::details FAQWhich Secondary Stat Rune is Best?
The default choice for Warlocks is

[[spell:1279609]]

. If you
have somehow managed to hit >35% Critical Strike chance and neglected Mastery
in the process, consider using

[[spell:1279612]]

.

:::

3.

### Apex Talent: ![Shadow of Nathreza Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_112_raidtrinkets_blobofswirlingvoid_gold.jpg>) Shadow of Nathreza

Available during the leveling in Midnight, these talents are separated from
the rest of the spec tree and require subsequent points investment in order
to unlock the later ranks.

1. [[spell:1261984]]
2. [[spell:1261990]]
3. [[spell:1261992]]

These talents bolster Haunt damage and damage amplification but do not
alter the use case of the spell, as such the standard behaviour of casting
the spell on cooldown is unaffected.

4.

### Hero Talents

Available at level 71 Hero talents are mutually exclusive trees you can
choose to slightly alter gameplay and visuals. Affliction Warlocks can choose
between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller is themed around Shadowflame damage and harder
hitting DoTs. [[spell:445465]] replaces [[spell:172]] and can generate a
second Shadowflame DoT effect in [[spell:440043]]. The Hero tree offers
a more methodical approach to shard expenditure with [[spell:430014]]
bolstering burst windows every minute.

In terms of utility [[spell:440057]] offers a debuff that is
relevant on both melee and caster enemies without the need to choose and is
especially relevant with [[spell:1265813]] being added in patch 12.0.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester identity lies in spending shards very
aggressively, in order to benefit from the various DoT effects triggered, and
generating more [[spell:108558]] procs
through [[spell:449637]].

As for utility [[spell:449701]] guarantees stronger Healthstones
without the need of Soulburn shards, [[spell:449703]] increase
the active mitigation, and [[spell:389623]]
brings [[spell:20707]] on par with alternative combat resurrection
spells.

5.

### PvP Talents (War Mode)

Under our Talents section, there is the option to enter "War Mode." Enabling
War Mode provides the following benefits:

- PvP talents enabled in the outdoor world
- 10% increase in World Quest rewards at maximum level
- 10% more experience gained while leveling
- Earn Conquest Points, which can reward gear every week

With the benefits of enabling War Mode for leveling and PvE content, you
should enable the feature. In most situations, this will allow maximum returns
despite the risks. You will make yourself available for open-world PvP, and the
possibility to be "ganked" while leveling or doing World Quests exists.

5.1.

#### Best War Mode Talents

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of both General PvP Talents
and Affliction Warlock-specific PvP talents.

1. [[spell:221711]] stacks a damage reduction effect on enemies that are
     damaged by your [[spell:234153]]. You can reduce their damage by up to 25%,
     which greatly increases your ability to survive and sustain.
2. [[spell:353753]] allows to burst targets by dragging them away from the
     marked location.
3. [[spell:248855]] increases your gateway's range by 20 yards and
     reduces the duration of the debuff placed on players using it by 15 seconds,
     making it a good choice when increased mobility is needed.
4. [[spell:212295]] summons a shield lasting 3 seconds and reflecting all
     harmful spells targeted at you.
5. [[spell:201996]] is only relevant when dealing with a lot of casting
     mobs.

1. [[spell:335052]] increase the target limit for
     [[spell:1259790]] to 3.
2. [[spell:201996]] guards a location for 20 seconds; any enemies that
     cast spells in the radius will take up to 5% of maximum Health as damage. This
     has a lot more limited use but can have absurd value in specific situations.
3. [[spell:212371]] can be handy in situations with high sustained damage
     intake. Combining this with [[spell:221711]] dramatically increases your
     survivability and sustainability and opens many doors for soloing difficult
     content.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **31 Aug. 2026:** Updated Dungeon talent recommendations.
- **11 Aug. 2026:** Updated Talent choices.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Added Omnium Folio for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **30 Mar. 2026:** Updated Single target talent recommendations.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated talent trees and added Apex section for Midnight release.
- **10 Feb. 2026:** Updated talent trees for the changes to each gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated talents recommendation for Season 1.
- **26 Aug. 2024:** Added a Delve talents reccomendation.
- **21 Aug. 2024:** Updated recommendations to feature Hero Trees.
- **01 Aug. 2024:** Added a Oblivion-less talent variants.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Talents updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7
- **10 Jul. 2023:** Updated talents for Patch 10.1.5.
- **01 May 2023:** Reviewed talents for Patch 10.1.
- **20 Mar. 2023:** Updated talents for Patch 10.0.7.
- **24 Jan. 2023:** Updated talents for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Affliction Warlock in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Affliction Warlock Gameplay and Rotation Guide

Welcome to our Rotation page for Affliction Warlocks. On this page, you will
find everything you need to know about actually playing the spec in Raiding
and Mythic+ scenarios.

If you have not already, please read the
[Spell Summary page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>). Knowing how each
spell/ability works in detail will greatly increase your understanding of the
topics discussed on this page.

2.

### Affliction Warlock Rotations

By selecting talents and Hero Talents below, the rotations in this guide will
update accordingly.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller

Single Target

AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:453080]]

[[spell:198590]]

[[spell:48181]]

[[spell:1257052]]

[[spell:205180]]

[[spell:1260264]]

[[spell:1261149]]

[[spell:196226]]

### Single Target

2.1.

#### Single Target Priority

Affliction Warlocks aim to apply a series of damage over time effects to targets, weaving in procs and managing Shards as a resource. Much of the optimization revolves around maintaining your active effects while ensuring you spend Soul Shards correctly.

1. **适用条件：Soul Harvester（启用）。** Maintain your [[spell:980]], and [[spell:172]] effects at all times.
2. **适用条件：Hellcaller（启用）。** Maintain your [[spell:980]], and [[spell:445465]] effects at all times.
3. Cast [[spell:1259790]] if you are at maximum Soul Shards.
4. **适用条件：Haunt（启用）。** Cast [[spell:48181]] whenever available.
5. **适用条件：Hellcaller（启用）。** Cast [[spell:430014]] on cooldown.
6. **适用条件：Soul Harvester（启用）。** Make sure to have 2 or less Soul Shards before casting [[spell:1257052]].
7. Cast [[spell:1257052]] whenever available with any periodic effect such as [[spell:172]], [[spell:980]] or [[spell:1259790]] active on target.
8. **适用条件：Shard Instability（启用）。** Use [[spell:1260264]] free [[spell:1259790]] within the buff window.
9. Cast [[spell:1259790]] to avoid capping shards.
10. **适用条件：Drain Soul（启用）。** Cast [[spell:198590]] as a filler.
11. **适用条件：Improved Shadow Bolt（启用）。** Cast [[spell:232670]] as a filler.

### AoE

2.2.

#### Multiple Targets Priority

1. **适用条件：Soul Harvester（启用）。** Maintain [[spell:980]] on up to 10 targets.
2. **适用条件：Hellcaller（启用）。** Maintain [[spell:980]] on up to 14 targets.
3. **适用条件：Soul Harvester（启用）。** Maintain [[spell:172]]. If there are 3+ targets stacked together, use [[spell:27243]] to apply and maintain Corruption.
4. **适用条件：Hellcaller（启用）。** Maintain [[spell:445465]]. If there are 3+ targets stacked together, use [[spell:27243]] to apply and maintain Wither.
5. **适用条件：Haunt（启用）。** Cast [[spell:48181]] whenever available on the primary target.
6. **适用条件：Hellcaller（启用）。** Cast [[spell:430014]] on cooldown.
7. **适用条件：Sow the Seeds（启用）；Summon Darkglare（启用）；Soul Harvester（启用）。** In 2 targets cast [[spell:1259790]] during [[spell:205180]]  on the second when you have 2 Succulent Shard.
8. **适用条件：Summon Darkglare（启用）。** Cast [[spell:1259790]] during [[spell:205180]] if there are only 2 targets.
9. Cast [[spell:1257052]] whenever available with any periodic effect such as [[spell:172]],[[spell:980]] or [[spell:1259790]] active on every target.
10. **适用条件：Sow the Seeds（启用）；Soul Harvester（启用）。** Cast [[spell:27243]] if already at 5 Soul Shards and 3 targets are close.
11. **适用条件：Sow the Seeds（启用）；Hellcaller（启用）。** Cast [[spell:27243]] if already at 5 Soul Shards and 3 targets are close.
12. **适用条件：Soul Harvester（启用）；Sow the Seeds（未启用）。** Cast [[spell:27243]] if already at 5 Soul Shards and at least 6 targets are close.
13. **适用条件：Hellcaller（启用）；Sow the Seeds（未启用）。** Cast [[spell:27243]] if already at 5 Soul Shards and at least 6 targets are close.
14. **适用条件：Soul Harvester（启用）；Sow the Seeds（启用）。** Cast [[spell:27243]] if above 2 shards before [[spell:1257052]] comes off cooldown and there are 2 targets.
15. **适用条件：Soul Harvester（启用）；Sow the Seeds（未启用）。** Cast [[spell:27243]] if above 2 shards before [[spell:1257052]] comes off cooldown and there are 6 targets.
16. **适用条件：Shard Instability（启用）。** Use [[spell:1260264]] free [[spell:1259790]] on dying targets if below 4 shards.
17. **适用条件：Shard Instability（启用）。** Use [[spell:1260264]] free [[spell:1259790]] on the primary target.
18. **适用条件：Drain Soul（启用）。** Cast [[spell:198590]] as a filler.
19. **适用条件：Improved Shadow Bolt（启用）。** Cast [[spell:232670]] as a filler.

### Opening Sequence

**适用条件：Haunt（启用）。**

[[spell:48181]]

**适用条件：Haunt（未启用）；Drain Soul（未启用）。**

[[spell:232670]]

[[spell:980]]

**适用条件：Soul Harvester（启用）。**

[[spell:172]]

**适用条件：Hellcaller（启用）。**

[[spell:445465]]

**适用条件：Hellcaller（启用）。**

[[spell:430014]]

**适用条件：Soul Harvester（启用）。**

[[spell:1259790]]

[[spell:246985]]

[[spell:246985]]

**适用条件：Hellcaller（启用）；Malefic Grasp（启用）。**

[[spell:1259790]]

**适用条件：Soul Harvester（启用）。**

[[spell:1257052]]

**适用条件：Hellcaller（启用）；Malefic Grasp（未启用）。**

[[spell:1257052]]

**适用条件：Summon Darkglare（启用）。**

[[spell:205180]]

[[item:270169]]

[[item:271886]]

[[spell:1259790]]

**适用条件：Malefic Grasp（启用）；Hellcaller（启用）。**

[[spell:1257052]]

**适用条件：Malefic Grasp（启用）；Hellcaller（启用）。**

[[spell:1259790]]

**适用条件：Soul Harvester（启用）；Drain Soul（启用）。**

[[spell:108558]]

[[spell:198590]]

**适用条件：Soul Harvester（启用）；Improved Shadow Bolt（启用）。**

[[spell:108558]]

[[spell:232670]]

**适用条件：Malefic Grasp（启用）。**

[[spell:1261149]]

[[spell:1259790]]

2.3.

#### Opening Sequence

1. **适用条件：Haunt（启用）。** Pre-cast [[spell:48181]].
2. **适用条件：Haunt（未启用）；Drain Soul（未启用）。** Pre-cast [[spell:232670]].
3. Apply [[spell:980]].
4. **适用条件：Soul Harvester（启用）。** Apply [[spell:172]].
5. **适用条件：Hellcaller（启用）。** Apply [[spell:445465]].
6. **适用条件：Hellcaller（启用）。** Cast [[spell:430014]].
7. **适用条件：Soul Harvester（启用）。** Cast [[spell:1259790]] until reaching 2 [[spell:246985]].
8. **适用条件：Shard Instability（启用）；Hellcaller（启用）。** Cast [[spell:1259790]] spending all  [[spell:246985]]
9. **适用条件：Soul Harvester（启用）。** Cast [[spell:1257052]].
10. **适用条件：Hellcaller（启用）；Shard Instability（未启用）。** Cast [[spell:1257052]].
11. **适用条件：Summon Darkglare（启用）。** Cast [[spell:205180]]
12. Use your trinkets and racials.
13. Spend all shards on [[spell:1259790]].
14. **适用条件：Malefic Grasp（启用）；Hellcaller（启用）。** Cast [[spell:1257052]].
15. **适用条件：Malefic Grasp（启用）；Hellcaller（启用）。** Spend all shards on [[spell:1259790]].
16. **适用条件：Soul Harvester（启用）；Drain Soul（启用）。** Cast [[spell:108558]] [[spell:198590]].
17. **适用条件：Soul Harvester（启用）；Improved Shadow Bolt（启用）。** Cast [[spell:108558]] [[spell:232670]].
18. **适用条件：Malefic Grasp（启用）。** Cast [[spell:1261149]] until the most recent [[spell:1259790]] has expired

:::details TipsDo Not Underestimate Curses!
With the introduction of

[[spell:1265813]]

Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:440057]] is unique to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and combines
  	the above two curses
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

:::

3.

### Midnight Season 2 Tier Set

Season 2 tier set bonuses are the following:

- [[spell:1296568]] increases the damage of
      both [[spell:172]] and [[spell:980]].
- [[spell:1296569]] enables the activation of
      several talents and effects tied to [[spell:1259790]] during
      AoE while spending Soul Shards on [[spell:27243]].

Both set bonuses are not particularly strong and designed to offer a
passive damage increase that do not alter the priorities or the decision
making in the gameplay.

4.

### Class and Spec Mechanics Explained

The following sections present an explanation of various mechanics
pertinent to the Affliction and the Warlock, alongside reasons as
to why abilities are used in a specific way.

### Pandemic Mechanic

4.1.

#### Pandemic and Learning to Efficiently Refresh DoTs

Pandemic is a hidden mechanic that allows you to refresh certain timed
effects early without penalty. You can refresh your DoT effects when they have
less than 30% of their maximum duration. This will add the new DoT's
maximum duration with the remaining duration of the current DoT.

For example, if you cast a fresh [[spell:980]] while your current one has a
duration of 3.5s, your new Agony will now have 21.5 seconds.

The Pandemic values for safe refreshes for your other DoTs are as follows:

- [[spell:980]]: 5.4 seconds
- [[spell:172]]: 4.2 seconds

When [[spell:264000]] is talented the values change as follows:

- [[spell:980]]: 4.5 seconds
- [[spell:172]]: 3.5 seconds

### Malefic Grasp

4.2.

#### Malefic Grasp

[[spell:1261149]] is perhaps one of the most difficult window of
opportunity to optimize. The premise is to maximize the amount of GCDs spent
with [[spell:1261149]] while simultaneously have the max amount
of [[spell:1259790]] hits.

In order to achieve that any other GCDs should be reduced as much as
possible, and that entails not moving unless strictly necessary and cut the
amount of [[spell:980]] refresh to the minimum. As such it is advised to
have full duration on [[spell:980]] with pandemic before
entering [[spell:205180]] as that will ensure no GCD spent
during [[spell:205180]] duration (or a single refresh required if talented
in [[spell:1279521]]).

Worth noting it is best to spend all available [[spell:1259790]]
before 8 seconds left on [[spell:205180]] in order to maximize the
damage extracted from both [[spell:1261149]] and [[spell:205180]]
damage amplification.

### Apex Talent

4.3.

#### Shadow of Nathreza

Affliction Warlock's Apex talent [[spell:1261984]] concept is to
augment [[spell:48181]] in multiple ways. Ranks 1 and 4 provide direct damage
contribution and allow the spell to cleave onto multiple nearby targets,
further solidifying its importance even in AoE scenarios. Rank 2 and 3
instead increase the damage amplification effect on the main target.

As a result, the talents themselves do not change how to interact
with [[spell:48181]] in the rotation, as it is already casted on cooldown in
basically every scenario.

5.

### Important Cooldowns for Affliction Warlock

### Darkglare

5.1.

#### Darkglare

[[spell:205180]] is the spec main cooldown featuring a baseline DoT
amplification effect which encourages pooling resources before entering this
window. The existence of supporting talent such as [[spell:1261149]]
further emphasise maximising the amount of GCDs spent strictly
on [[spell:1259790]] and [[spell:1261149]], and consequently
reducing the amount of time spent reapplying [[spell:48181]]
or [[spell:980]].

As such it is best to ensure a pandemic-extended duration on [[spell:980]]
before casting [[spell:205180]].

[[spell:205180]] baseline has a single target continuous cast,
and [[spell:1280733]] is required to enable 5 targets cleave.

### Dark Harvest

5.2.

#### Dark Harvest

[[spell:1257052]] by default should be casted on cooldown, making sure
to line it up before [[spell:205180]]. Talenting [[spell:453056]]
increase the frequency, especially during AoE with the ever
present [[spell:27243]] spam however is still beneficial to sync it
with [[spell:205180]].

While ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller does not directly influence [[spell:1257052]]
behaviour, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester [[spell:449638]] requires to go
down to 2 shards before casting [[spell:1257052]] in order to avoid
overcapping and wasting shards.

### Malevolence

5.3.

#### Malevolence

[[spell:430014]] is a rather straightforward cooldown which lines up
naturally with Affliction damage profile, and thus should be used in tandem
with [[spell:205180]] and [[spell:1257052]] when talented.

6.

### Affliction Warlock Important Notes

### Soul Shards

6.1.

#### Soul Shards

All Warlocks use Soul Shards as their primary resource. Properly managing
your Shards is crucial to success, as overcapping results in potential loss of
damage.

While by design the idea is to not think too much when to spend newly
acquired shards, it can also be said that there is not strictly a rush
associated in spending them, unless close to 5, and as a result the use case
is rather flexible.

Factors such as talent selection and encounter design can influence the
decision when to use Soul Shards and how to use them. Pooling resources can
be advantageous if and when:

- Entering cooldowns such as [[spell:205180]]
      or [[spell:430014]]
- Additional targets are about to enter the encounter
- A priority target enters or a burn phase is about to start

### Agony

6.2.

#### Agony

[[spell:980]] is by far your most important spell, as it is the sole
source of Soul Shard generation in the regular rotation. It also deals severe
sustained damage. The trade-off, however, is that [[spell:980]] has a
ramp-up period before it reaches full effectiveness. This means that if you
let
[[spell:980]] drop on one of your primary targets for any reason, you will
   hemorrhage DPS. Keeping careful track of your active [[spell:980]] casts
   an important priority and the most punishing failure to mess up.

### Demon Choice

6.3.

#### Demon Choice

After 9.2 changes, Sayaad (Succubus or Incubus) has a clear advantage in
terms of single target damage, assuming no frequent distant target swap. However,
pet choice is often dictated by the unique utility provided by each one: for
defensive dispel, and if there are regular swaps between distant targets, Imp
will provide the highest uptime. Use Felhunter whenever an interrupt or a purge
effect is required. Voidwalker can offer some additional AoE due to its torment
ability, but its most significant utility comes from a taunt. Succubus offers
further crowd control and permanent slow on a single target, which may be helpful
under certain situations.

### Movement

6.4.

#### Movement Management

While it is difficult to describe the best ways to position and move during a
dungeon or raid encounter, it is essential to your success as an Affliction
Warlock. [[spell:111771]] can be highly effective in many encounters and
is under-appreciated by many players and raid groups. Think of
[[spell:111771]] as a raid cooldown that can teleport your
entire raid group 40 yards. The potential this ability holds quickly becomes
clear. Ask your group if they want [[spell:111771]] anywhere specific; if
not used for your strategy, use it instead as a personal cooldown.

[[spell:980]] and [[spell:172]] can be refreshed when you need cover
movement. [[spell:108558]] has some potential on higher movement fights,
particularly with cleave, as the instant [[spell:232670]] procs
offer another global cooldown where you can move without losing DPS.

You can mitigate the need to move by positioning in locations central to
fight movement. For instance, if a boss is being kited in a circle, you should
stay inside the kite path to ensure minimal movement. You should also determine
how your [[spell:268358]] can make a fight easier for you. You can
trivialize many boss mechanics with a clever portal, which can free you up to
deal much more damage.

[[spell:385899]] used in conjunction with [[spell:111771]]
offers a quick way to cover large distances and can be used in a rush when
the need to reposition is immediate.

6.4.1.

##### Quiet Movement

Many players will unconsciously move during fights, despite it being
unnecessary. For example, sometimes the boss or adds will be moved by the tank a
couple of yards. Though you are still in range to cast, you subconsciously
mirror that movement, costing you global cooldowns. Consciously work to "quiet"
your movement and reduce unnecessary movement to a minimum. The best way to see
this in action is to take a video of your raid, then watch yourself play. Most
players will be surprised by the amount of wasted movement they commit. When you
are forced to move, make your path as direct and decisive as possible.

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **31 Aug. 2026:** Updated rotation section.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **17 Mar. 2026:** Expanded the Tier Set bonuses section.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated Rotations and added Apex sections for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added a section for Combat Assistant.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **25 Sep. 2024:** Re-done page layout, updating sections accordingly.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Added Hero Talent sections and selectors.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **28 Nov. 2023:** Updated multitarget section after 4p fix.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated selector for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Jan. 2023:** Updated opener and Darkglare sections.
- **11 Dec. 2022:** Updated selectors for the openers and priority lists.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Affliction Warlock in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Affliction Warlock

Welcome to our Gearing Page for Affliction Warlock. This section
will cover everything you need to know about equipping your character correctly.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Affliction Warlock. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces to Aim for?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

was changed to retain the base stats, and item level of the original item, which allows to acquire tier set bonuses while following a specific stat distribution. Listed below are the ideal items to catalyse, but be aware

**Chest and Legs**

are direct drops.

- Head: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:239031@JAACAAAG2A]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:271549@JAACAAgNyA]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Hands: [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: [[item:251160@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

Prioritise acquiring the tier set bonuses over ideal stat distribution since it is a higher DPS increase.

:::

:::details FAQWhat Items From the Great Vault Should I Pick?
Rare drops from raid and items that present the highest upgrade in

[Top Gear](<https://www.raidbots.com/simbot/topgear>)

sims should be prioritised. Listed below are few of the items to chase:

- [[item:271092]]: Best caster weapon due to item level alone
- [[item:271874@JAACAAAG2A]] and [[item:268265@JAACAAAG2A]], high item level items with strong cantrip effects
- [[item:270170@JAACAAgNyA]] is the best trinket this tier

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240898]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273649@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup from Dungeons for Affliction Warlock. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces to Aim for?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

was changed to retain the base stats, and item level of the original item, which allows to acquire tier set bonuses while following a specific stat distribution. Listed below are the ideal items to catalyse, but be aware

**Chest and Legs**

are direct drops.

- Head: [[item:251199@JAACAAgNyA]] from [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- Shoulders: [[item:239031@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:273785@JAACAAgNyA]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Hands: [[item:159247@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Legs: [[item:251160@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

Prioritise acquiring the tier set bonuses over ideal stat distribution since it is a higher DPS increase.

:::

:::details TipsWhich Dungeons Should Be Prioritised?
If your playtime is limited consider the following dungeons to farm:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): both weapons and a ring
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): trinket, belt, and neck
- [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): your second trinket

:::

:::details FAQIs There a Difference Between 2H Staves and 1H + Off Hand?
As long as the item level is the same, there is no difference between both, in terms of total amount of stats.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:251199@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:251137@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273649@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup from Raids for Affliction Warlock. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces to Aim for?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

was changed to retain the base stats, and item level of the original item, which allows to acquire tier set bonuses while following a specific stat distribution. Listed below are the ideal items to catalyse, but be aware

**Chest and Legs**

are direct drops.

- Head: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:268241]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- Chest: [[item:271549@JAACAAgNyA]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Hands: [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: [[item:271545@JAACAAgNyA]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

Prioritise acquiring the tier set bonuses over ideal stat distribution since it is a higher DPS increase.

:::

:::details TipsWhat Are the Most Important Drops from the Raid?
Listed below are the most significant drops worth prioritising.

- [[item:281215@JAACAAgNyA]]: Best trinket in general. Drops from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>).
- [[item:271092@JAACAAAG2A]]: Highest item level weapon. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:271874@JAACAAAG2A]]: Highest item level with good stats on a slot with a high stat budget. This drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240898]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270170@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Affliction Warlock

The following list provides a general ranking for all trinkets available
for players to better understand what may be more appealing. These rankings
assume each item at its highest possible item level, thus for direct or
immediate upgrade it is still best practice to sim your own character.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Affliction Warlock Trinkets**
**Best-In-Slot -**

[[item:273649@JAACAAgNyA]]

and

[[item:281215@JAACAAgNyA]]

**Runner Up Passive-**

[[item:270164@JAACAAgNyA]]

or

[[item:250224@JAACAAgNyA]]

**Runner Up Active-**

[[item:270170@JAACAAgNyA]]

or

[[item:273796@JAACAAgNyA]]

:::

Any trinket not shown on this list is generally considered worse than all
other trinkets available on this list.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Affliction Warlock Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAACAAgNyA]]</li>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169@JAACAAAG2A]]</li>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:158368@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) work as bonus loot and guarantee a drop
	from the loot table of a Boss or a Dungeon. While the drop in itself is
	random, each additional Voidcore spent will guarantee no duplicate until
	the whole list has been dropped.

3.1.

#### Recommended Nebulous Voidcore Usage for Affliction Warlock

Nebulous Voidcores are a valuable yet limited resource and whilst in
general should be used to bridge gaps in a player current gearset, it is
important to remember that how quickly an item can be guaranteed depends on
how many other items have been already dropped from that source.

Not all drops are equally impactful, so listed below is a generic priority
list on what to focus on:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore Targeting Priority**
1. Mythic-track [[item:271092@JAACAAAG2A]]
2. Mythic-track [[item:271874@JAACAAAG2A]]
3. Mythic-track weapons (1H or 2H);
4. Mythic-track trinkets (especially [[item:281215@JAACAAgNyA]]);
5. Tier set pieces missing from 2 or 4-piece bonus;
6. High-impact slots from your BiS list.

:::

3.2.

#### Ascendant Venomstones

[[item:280562]] return as a mean to upgrade your equipment in
Season 2. Listed below is the order of importance of equipment slots to
upgrade:

1. Mainhand Weapon is the most important
2. Offhand weapon
3. On-use trinket
4. Passive trinket
5. Neck item.

[[item:280562]] can also be used to upgrade bonus rolled
Heroic cantrip items from last 2 bosses to 340 item level.

4.

### Best Crafted Items for Affliction Warlock

Crafting gear main limiting factor remains the weekly rollout of Sparks,
necessary for high end items, as such it is important to understand how to
approach the topic.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Affliction Warlock Crafted Gear Priority**
1. The overall best combination is [[item:240167]] in the
     	Wrists slot and [[item:273059]] in the off-hand frill,
     	but that is in the context of fully geared characters, and thus should
     	be considered a long term strategy, better suited for players who do not
     	require the highest power gain immediately, but instead opt for the
     	least amount of recrafts and resource investment.
2. If immediate power is instead the focus, then crafting
     	a [[item:245770@JAAGAAwt1ENMMYD]]
     	with [[item:273060]] using 4 Sparks and Wrists
     	with [[item:240167]] at a lower item level provide the
     	highest dps jump.

:::

The missives used for each craft are the following:

- [[item:245786]] for Weapon and Wrists
- [[item:245783]] for any other slot

:::details FAQWhy Craft A Weapon First If It Is not Best-In-Slot?
Weapons provide the highest amount of primary stat, and especially the
first tier it is a very precious commodity. However crafted items cap 4 item
levels below fully Mythic upgraded alternatives, thus being somewhat limited
at the top end, assuming a player get access to that kind of gear.

:::

:::details FAQIs It Worth Recrafting for a Different Missive?
If the associated recrafting cost is not an issue, consider simming your
own character at any given point to get the best Missive at the moment.

**However**

keep in mind that, barred very unusual cases of extremely
skewed secondary stats distribution, changing stats will not provide a
substantial gain.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Adding Sockets to Gear

In Season 2 [[item:275707]] is available as a
trading option at six tokens from Great Vault, which can be used to add a
sockets to any Head, Waist, or Wrist item.

5.

### Crest Usage

Mistcrests are a seasonal limited currency with a cap that increases each
week and is used to upgrade items to their respective maximum level in each
reward track.

Due to how each item slot is designed, there is a difference in power, tied
to either specific effects or simply higher stats. As a result the following
sequence highlights the most valuable slots where to invest Mistcrests:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Affliction Warlock Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Neck**

➜

**Off-hand**

➜

**Shoulders/Gloves/Belt/Boots**

➜

**Rings**

➜

**Wrists/Back**

:::

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **31 Aug. 2026:** Updated trinket list.
- **16 Aug. 2026:** Updated BiS lists, embellishment and trinkets to account for a new profile and trinket tuning.
- **11 Aug. 2026:** Updated Gems and FAQ sections.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **17 Mar. 2026:** Updated Trinket ranking to account for Gaze nerf.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **24 Jun. 2025:** Updated DISC socket recommendation following tuning.
- **15 Jun. 2025:** Updated for Patch 11.1.7 and DISC.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **04 Apr. 2025:** Updated trinket recommendations.
- **04 Mar. 2025:** Updated BiS lists and trinket ranking.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7. and Cyrce's Circlet.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Added BiS lists for Season 1, updated trinket section.
- **21 Aug. 2024:** Added Pre-Season BiS list section.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4 launch.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated trinket section for Patch 10.2.5.
- **07 Nov. 2023:** Embellishment recommendations updated after Undulating Sporecloak has been annihilated.
- **06 Nov. 2023:** Updated Gear recommendations for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Reformat of the page with BiS tables and section updates.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **24 Mar. 2023:** Updated Onyx Annulet section to account for live hotfixes.
- **20 Mar. 2023:** Added Patch 10.0.7 new ring section. .
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Dec. 2022:** Updated Embellishment recommendations.
- **11 Dec. 2022:** Updated for Season 1 launch.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Affliction Warlock. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Affliction Warlock Stat Priority

The stat priority for a Affliction Warlock is as follows:

Item Level

Haste

Critical Strike

Mastery

Versatility

It is worth noting that our secondary stats are relatively close to
each other in value, so prioritizing item-level is generally considered the best approach,
especially as you approach hitting diminishing returns on the stat value you gain. A
more balanced stat distribution is preferable to stacking the two best stats to the point
where they diminish in value.

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. You should look for this stat in all
of your upgrades. It provides you with Spell Power, which increases the damage
of your spells.

**Mastery**, through [[spell:77215]] increases the
damage of your DoTs ([[spell:980]], [[spell:172]],
[[spell:27243]], and [[spell:1259790]]) and
[[spell:324536]]. Mastery does not affect your pets or Soul Shard
generation at all.

**Haste** influences the cast speed of your spells and increases
the number of ticks from your DoTs. This decreases the ramp-up damage
from [[spell:980]] as well. Haste also reduces the global cooldown and
scales with your pets. Since an increased number of DoT ticks also results in
more Soul Shards, we can look at Haste as the stat that has the most effect
on our resource generation.

**Critical Strike** increases your chance to critically hit with all
spells and abilities.

**Versatility** is a flat-out damage done increase and damage taken
reduction.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Affliction Warlock, based on your [stat priority](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

Socketable gems are divided in two categories: Epic and Rare. The former
offer a powerful effect but is limited to 1 equipped, whereas the latter
includes single or two secondaries stats combination gems.

Gems can be applied to a Helm, Bracer, or Belt via the
[[item:275707]] item from the Great Vault.

The Dazzling Diamond Epic gems of choice
are [[item:240983]]
or [[item:240967]]. The former is better until Mythic track
gear, at which point the latter performs better.

In terms of itemization, opting for Critical Strike gems yields the best
result, due how strong that secondary stat is for Warlocks in general. [[item:240898]]
is your best gem to pair with the [[item:240983]], while it is very
important to activate the full benefit of the [[item:240967]] by
equipping 4 different-coloured rare gems.

The four rare gems you should be looking to equip are:

- Peridots: [[item:240890]]
- Lapis: [[item:240914]]
- Amethysts: [[item:240898]]
- Garnets: [[item:240906]]

<em>It is highly recommended using [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) to sim your
character's ideal gems and enchants, as they might differ from general
recommendations.</em>

**Make sure to enable the checkboxes with "Always use" and "Only 4+
Colors" in the options.**

2.

### Best Enchants and Weapon Augments

Use [[item:243733]] as weapon oil.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

2.1.

#### Weapon Enchant Choice

Secondary stat weapon enchants may provide better value
 than [[item:244029]] but which one is best for you
 heavily depends on the rest of your gear. As such, depending on your current stat
 distribution, you may want to [sim yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) as your best secondary stat enchant
 may differ from the one listed above.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

For Season 2, [[item:241325]] is the default choice.

3.2.

#### Potions

[[item:241288]] should be the first choice if your gearset
has little to no Versatility, otherwise use [[item:241308]].

After acquiring [[item:270168]], [[item:271886]] becomes
a stronger choice, particularly in the last 5 seconds.

[[item:271883]] is the healing potion of choice.

3.3.

#### Food

[[item:242275]] and [[item:255846]] are the recommended food to
consume. You can simply buy whichever is the cheapest, or eat from a feast when it is
provided for the group.

Hearty version of food should be considered in situations where
wiping/dying is rather frequent, as those persists through death.

3.4.

#### Augment Rune

[[item:259085]] provide around 1% dps increase and
should be evaluated during progress, especially when close to pivotal
kills.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **16 Aug. 2026:** Updated consumables to reflect new BiS lists.
- **11 Aug. 2026:** Changed Flask and updated Gems.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Updated Tea section.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **22 Aug. 2025:** Updated weapon enchants.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **12 Sep. 2024:** Updated weapon enchants and oils.
- **09 Sep. 2024:** Updated gems section, as the strategy changed.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated Phial recommendation after Corrupted Rage buff.
- **24 Mar. 2023:** Updated Primordial Stones recommendations to account for the additional live hotfixes.
- **22 Mar. 2023:** Updated Primordial Stones recommendations to account for 25% buff hotfix.
- **20 Mar. 2023:** Added Primordial Stones section for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **07 Jan. 2023:** Updated dungeon phial to a more reliable Phial of Tepid Versatility.
- **14 Dec. 2022:** Updated Weapon Runes.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Affliction Warlock in World of Warcraft Patch 12.1.5.

1.

### Affliction Warlock in Mythic+ in Midnight Season 2

Mythic+ has become a large part of the World of Warcraft endgame. Still, the
sheer number of different variables has overwhelmed many players. The group
composition, weekly affixes, the item level of the group, the keystone level,
and the group's experience and comfort level are just several factors that will
influence how you approach each dungeon. The purpose of this page is to prepare
you for the key differences that set Mythic+ apart from the typical World of
Warcraft endgame experience, including talents and rotational anomalies that may
not be obvious at first glance.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

[Affliction Warlock](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-guide>)s are a solid ranged DPS spec, offering sustained
damage with frequent burn cycles. While the spec lacks immunity, the sound
mitigation and self-heal make it a versatile choice with a unique
toolkit comprised of Healthstones, Soulstones, Curses, skip-enabling
[[spell:111771]], AoE crowd control abilities such as [[spell:30283]]
and [[spell:5484]].

2.

### Best Mythic+ Talent Builds

### Mythic+ Talents

2.1.

#### Mythic+ Talents for Affliction Warlock

The following build offers more front-loaded damage, the ability to reach
maximum damage quicker, and better overall AoE.

To import the build directly in-game, click on the export button at the
bottom of the calculator:

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgx2yADYAzwWghtBAAgZAAAMzMmZY2YYMzMzMMMzMzAAmBG"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPSfiklnoELM028MTjchprTwwJbM-JKcdBILe2IUYgxxRTc4IzbEAaCLMUwC-AAAA-HIOQ2AEUQhhCzC-
```

:::

### Hellcaller Variant

2.2.

#### Hellcaller Mythic+ Talents for Affliction Warlock

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller offers a less flexible 1-minute burst damage profile built
around [[spell:430014]], and better single-target by comparison.

To import the build directly in-game, click on the export button at the
bottom of the calculator:

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAmxsMLzMzyYAALwAziRjZAMbglBAAgBAAMzgxMzY2YYmZMzMmhZmZGAwMwA"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPfgiklnoELM028MTjehprTwwJbM-JKcdBILe2IUYgxxRc4IbEYCzDEMM06C-AAAA-IQSU2AIQYgxBzC-
```

:::

3.

### Mythic+ Flexible Talents for Affliction Warlock

### Utility / Defensive Talent Swaps

3.1.

#### Utility / Defensive Flexible Talents

In regards to AoE stops [[spell:30283]] and [[spell:5484]] are
often interchangeable, and should be evaluated in situations where stun or
fear immunity targets are present and if faster cooldowns are more
important.

[[spell:710]] is a much more niche tool to take out an Aberration, Demon
or Elemental target from the fight for up to 30 seconds. It does not work on
bosses and in boss encounter most of the time major mechanics often present
targets immune to the spell.

[[spell:268358]] and [[spell:111771]] can be considered
repositioning tools, with the latter generally allowing specific route skips
and the former used personally to handle mechanics that would force otherwise
prolonged movements.

For [[spell:108416]] supporting talents, [[spell:386664]] reduces
the Health Loss and is mostly used in situation where staying above a certain
Health threshold is preferable, but in general is less applicable than its
alternative [[spell:386686]] which offers a faster cooldown and thus
more opportunities to mitigate damage.

Inversely, for [[spell:104773]] opting for [[spell:317138]]
makes the damage mitigation more substantial and is generally preferred as
the base cooldown is long enough that a reduction with [[spell:386659]]
should be only considered if a specific fight requires double mitigation in
less than 3 minutes.

### Damage Talents Swaps

3.2.

#### DPS Flexible Talents

The following alternatives represent a gradient between more single target
and more AoE and can be used to adjust the damage profile if one is preferred
over the other:

- [[spell:1311969]] can be swapped with [[spell:1279521]] while
  	running [[spell:196103]] for 3% better single-target and 1%
  	more AoE

The choice between [[spell:198590]] and [[spell:453080]] is
generally dictated by the chosen Hero Tree. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller with slower
shard generation, more low priority GCDs, and weaker single target receives
more benefits from [[spell:198590]], thanks to more
impactful [[spell:108558]] windows and the ability to snipe shards off
dying targets. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) Soul Harvester instead has a much easier way to
generate shards and guarantee free spenders casts, so being more busy and
often fighting against resource overflow mean [[spell:453080]] is
a better suit.

4.

### In-Depth Rotation Tips for Mythic+

While both single and multi-target rotations do not differ substantially
from the standard priority outlined in
[Rotation, Cooldowns, and Abilities page](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)
there are a few points worth noting:

- Due to the nature of pulls, with constantly dying targets, Affliction can
   use Soul Shard sniping using both [[spell:1259790]] and
   [[spell:198590]] when talented at collecting additional Soul Shards and
   squeezing extra damage throughout a full run.
- Maximize cooldown efficiency, aiming for the highest number of casts while
   not wasting activation on pulls about to die. In that situation, getting to 5
   shards and starting the next pull with max resources is better.
- [[spell:48181]] when talented, is always worth casting in any situation and is
   better cast on targets affected by [[spell:1259790]].
- [[spell:980]]'s shard generation has diminishing return past 4 targets,
   which means it is crucial to have it on up to 4 targets. Past that value, the
   damage gain is still worth the global cooldown. However, you should not
   prioritize it above spending shards or preparing/using cooldowns.

5.

### Utility Kit and Abilities

While damage is the more significant reason to bring an Affliction Warlock,
the class itself offers a noticeable amount of crowd control and various
supporting abilities:

- Recently reintroduced, the Curses can offer some advantages against specific
   dangerous enemies: [[spell:1714]] can reduce the group's interrupt
   requirements. At the same time, [[spell:702]] alleviates the incoming
   damage on the tank from auto attacks. Last but not least,
   [[spell:334275]] can slow targets when kiting is required.
- [[item:5512]]s have a 1-minute cooldown and heal for 25% of max
   health, allowing for an emergency heal for each player.
- [[spell:20707]]s offer a combat resurrection that you can use reactively
   and preemptively in the case of a death run.
- [[spell:111771]] offers the unique ability to skip certain parts of
   the map, depending on the dungeon in question, avoiding specific pulls.
- [[spell:30283]] helps alleviate pressure on the tank during big pulls as
   it is a 3-second AoE stun.
- [[spell:5484]] in its current iteration is especially strong as a
   short cooldown aoe interrupt when talenting
   into [[spell:1270255]].
- [[spell:5782]] and [[spell:710]] are both spammable crowd control abilities
   that can interrupt a cast in a pinch or temporarily remove a target from combat.

:::details TipsDo Not Underestimate Curses!
With the introduction of

[[spell:1265813]]

Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:440057]] is unique to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and combines
  	the above two curses
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

:::

:::details FAQHow to Best Use Blights?
Blights are much stronger version of Curses, at the expense of being tied to
a 2 minutes cooldown and lasting only 12 seconds. As such they should be
treated as a defensive cooldown for the party, in order to alleviate any
incoming damage, if applicable. Each Blight follows the same rules as their
correspective Curse:

- [[spell:1271748]] works on any attacks, reducing the frequency
  	and critical strike chance
- [[spell:1271802]] works on any cast that can be interrupted

:::

6.

### Dealing with Affixes

### Affix: Ascendant

6.1.

#### Ascendant Affix Management for Affliction Warlock

About every minute, Xal'atath will show up and summon a total of 10 Orbs of
Ascendance with a cast that needs to be interrupted. Any crowd-control or
interrupt spell will work:

- [[spell:30283]];
- [[spell:5484]] (capped to 10);
- [[spell:5782]];
- [[spell:6789]];
- Pet interrupts.

### Affix: Voidbound

6.2.

#### Voidbound Affix Management for Affliction Warlock

While in combat, Xal'atath summons a Void Emissary to empower nearby
enemies, which becomes the priority target and is best focused down.

### Affix: Pulsar

6.3.

#### Pulsar Affix Management for Affliction Warlock

While in combat, Xal'atath manifests pulsar orbs that tether and orbit
around players for 15 seconds. There is no particular suggestion for this
mechanic centered around just soaking those orbs, although the movement
reduction can be offset by [[spell:111400]].

### Affix: Devour

6.4.

#### Devour Affix Management for Affliction Warlock

Periodically, Xal'atath will cast a shield debuff on all 5 players, which
can either be removed by healing done or by dispelling. Healing abilities
such as [[spell:6789]] and [[item:5512]] can help removing the
shields if no other means to dispel them are available.

- [[spell:688]] [[spell:89808]] can dispel a single shield.

7.

### Pet Choice for Affliction Warlock

The Felhunter offers comparable single-target damage and an interrupt or
purge, but consider swapping to Imp if you need a dispel.

If you are using [[spell:108503]], we recommend sacrificing the
Felhunter to provide your group with an extra interrupt. Suppose you need an
extra cooldown to survive. In that case, you can also sacrifice a Voidwalker
before a difficult boss to access the [[spell:17767]] cooldown.

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **31 Aug. 2026:** Updated Hellcaller talents.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated talent trees for the changes to each gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **19 Sep. 2024:** Updated for Patch 11.0.5 and added a dungeon tooltip section.
- **09 Sep. 2024:** Updated talent selection for Season 1 launch.
- **19 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Restructured Talent section.
- **10 Jul. 2023:** Talents updated for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Talents updated for Patch 10.0.7.
- **24 Jan. 2023:** Talents updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Affliction Warlock in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Below are examples of useful macros; you can adapt them for whatever spell you deem fit.

1.1.

#### Pet Macros

These macros allow you to manage your demon, as playing with your Pet Stance
on Assist is the preferred way to play.

#### Pet Attack

```wow-macro
/petattack
```

This orders your demon to attack your target.

#### Pet Follow

```wow-macro
/petfollow
```

This orders your demon to follow you.

#### Pet Move

```wow-macro
/petmoveto
```

This orders your demon to move to a location specified by you. This macro
is especially useful for situations where you need your pet in a predetermined
position in order to accomplish a given task — such as an interrupt on a
otherwise out of range target — but can also be used to maximize Felguard
cleave/[[spell:89751]] damage, just be aware that any imparted commands will
also make your Dreadstalkers, Vilefiend (if talented) and Tyrant move,
resulting in a much bigger loss when used improperly.

1.1.1.

##### DoT Mouseover

#### Corruption Mouseover

```wow-macro
#showtooltip Corruption
/use [@mouseover,harm] [harm] Corruption
```

Casts [[spell:172]] on current mouseover target if hostile and alive,
else cast it on your current target.

Worth mentioning that Blizzard has added the ability to toggle all casts to
follow a mouseover logic in the control settings, however some abilities may
not function correctly, and thus it is still recommended to take the time and
make a macro for any ability with a mouseover use case.

1.1.2.

##### Banish Focus

#### Banish Focus

```wow-macro
#showtooltip Banish
/use [mod:shift,@focus] [] Banish
```

Cast [[spell:710]] on focus target by holding also shift, else cast
it on your current target.

1.1.3.

##### Soulstone Mouseover

#### Soulstone Mouseover

```wow-macro
#showtooltip Soulstone
/target [@mouseover] Soulstone
/use Soulstone
/targetlasttarget
```

Workaround macro for the current bug related to mouseover dead allies. The
Macro itself will target the mouseover in order to cast [[spell:20707]]
then target the previous target.

1.1.4.

##### Demonic Circle

#### Demonic Circle

```wow-macro
#showtooltip
/stopcasting
/use [mod:shift] Demonic Circle(Summon); [nomod] Demonic Circle: Teleport(Teleport)
```

Place the Demonic Circle while holding shift, or teleport to the circle
without any modifiers, while cancelling any ongoing casts. This saves you the
trouble (and the time!) of interrupting your spell cast manually.

1.1.5.

##### Shadowfury/Howl of Terror

#### Shadowfury/Howl of Terror

```wow-macro
#showtooltip
/use [known:Shadowfury,@cursor] Shadowfury; [known:Howl of Terror] Howl of Terror
```

Depending on the talent selected cast [[spell:30283]] at cursor
or [[spell:5484]] instead.

1.2.

#### Agony

#### Agony

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] [] Agony
```

Cast [[spell:980]] on mouseover, if on a enemy target that is still alive,
otherwise cast it on the current target.

1.3.

#### Haunt

#### Haunt

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] [] Haunt
```

Cast [[spell:48181]] at eligible mouseover target, otherwise on current
target.

2.

### Best Addons

2.1.

#### Generic Add-Ons for Warlocks

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
