## 专精概览

欢迎阅读我们的魔兽世界12.1.5补丁唤魔师 湮灭指南。在这里，你将学习如何在团队副本和大秘境中游玩唤魔师 湮灭：从最基础的内容到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

湮灭大秘境资源

[全新！顶级湮灭天赋构筑](<https://raider.io/specs/devastation-evoker/talents>)

[顶级湮灭大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/evoker/devastation>)

[湮灭大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=evoker--devastation>)

[热门湮灭队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=evoker--devastation>)

1.

### 唤魔师 湮灭概述

[唤魔师](<https://www.icy-veins.com/wow/evoker-class-overview-dragonflight>) 是一个高机动性的远程DPS，具有一些独特之处。首先，我们的射程限制在25码，但由于我们拥有在施法时移动的能力[[spell:358267]]，这很少成为问题。其次，唤魔师可以使用新的独特技能类型——强化技能；这些技能可以在引导一段额外时间后再释放，以改变其效果。

强大且多变的伤害

唤魔师 湮灭拥有非常强大的伤害输出能力，在除大规模AOE外的所有场合都表现出色，我们最大的优势在于能够以相对较低的单体目标损失为代价，选择大量可靠的顺劈伤害选项，让我们感觉不必为了刷数据而牺牲优先目标的伤害。

团队副本的极佳选择

唤魔师 湮灭可以说拥有远程施法者所能拥有的最强进攻工具组合，通过使用[[spell:358267]]我们能经常在移动中施法，我们几乎总能保持100%的输出时间来打出最大伤害。唯一的例外是我们被迫超出射程的情况，但这几乎总能通过事先的准备来避免。

地下城的不错选择

唤魔师 湮灭在大秘境中始终是一个小众选择，我们的伤害输出特性使我们希望怪物波次不超过5个目标，而这在地下城中经常超过。我们无法在不付出巨大单体目标代价的情况下获得高价值的极端AOE伤害，这使我们在特定地下城中非常出色，而在其他地下城中则非常疲软。

可靠的实用性

湮灭在团队副本中，特别是，拥有许多强大的实用性，[[spell:369459]]提供3%的额外治疗并充当法力电池。[[spell:370665]]配合新的[[spell:370888]]让你和你的盟友能在短时间内移动施法。[[spell:374227]]在团队副本战斗中有更多应用，新天赋[[spell:410352]]允许你单独吸收危险技能。这些在大秘境中并不完全适用，但仍有一些价值。一些更偏向大秘境的实用性是像[[spell:307974]]和[[spell:357214]]这样的技能，它们可以用作群体打断。

出色的防御能力

唤魔师 湮灭配合新的[[spell:410352]]天赋，如果操作得当基本是不死之身。配合[[spell:363916]]，任何以可预测模式到来的伤害几乎都能被变得完全无关紧要。

所有情况下的卓越机动性

湮灭是一个拥有你所需全部机动性的专精。正确使用[[spell:358267]] / [[spell:357210]]和[[spell:370665]]意味着你可以非常快速地行进很长距离，也让你能防止击退和推回成为问题。

1.

### 至暗之夜中的唤魔师 湮灭

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

此补丁将引入2项新的终局内容，第一项是新的基斯希克斯团队副本遭遇战，另一项是迷宫超级地下宝库的加入。请务必查看下方链接的专属指南。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

主要变化将来自基斯希克斯团队副本遭遇战的新物品。最值得注意的是一个饰品、一个戒指和一副手套。此外，你将能够从10月20日起使用[[item:280562]]升级物品。武器、项链和饰品都可以升级。

2.3.

#### 职业改动

不幸的是，12.1.5补丁没有唤魔师 湮灭的职业改动。然而，随着12.1.5的上线，我们也接近了[[item:280562]]的解锁。这些将允许你在一些限制条件下将你的武器栏、饰品栏和项链栏升级2次。请查看装备页面，以更深入地了解你首先应该升级什么，以及来自新团队副本的装备将有多大用处。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/classicon_evoker_devastation.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 近期职业改动

- [[spell:357211]]伤害提高10%。
- [[spell:1292322]]伤害提高25%。
- [[spell:357208]]伤害提高5%。
- [[spell:362969]]伤害提高50%。
- [[spell:1265867]]伤害提高50%。
- [[spell:370452]]伤害提高10%。

这些改动旨在实现两个目标：使塑焰者成为单体目标的明确首选，并使我们的巅峰天赋与1/4巅峰构建回到同一水平。这将让你可以选择其中任意一种，而不会有任何实质性的损失。

:::

### 至暗之夜改动概述

2.5.

#### 至暗之夜 湮灭 唤魔师总结

以下列出的改动反映了至暗之夜上线时对湮灭唤魔师所做的所有重大改动。如需了解较新的改动，请查看第2赛季标签页。

2.6.

#### 湮灭唤魔师的核心改动

- [[spell:1265867]]取代了旧的肆虐节点，这会使你的[[spell:359073]]将你的下一个[[spell:362969]]变为碧蓝横扫。使其造成额外75%的伤害，并命中所有附近敌人，而不是通常最多三个目标。
- [[spell:370452]]已重做，根据[[spell:359073]]的每个强化等级造成额外伤害，但不再施加受到伤害提高的减益效果

2.6.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者

[[spell:443328]]已被[[spell:444088]]取代，使你的精华消耗技能[[spell:356995]]或[[spell:357211]]消耗你部分[[spell:357208]]持续时间来对目标造成伤害，不再扩散和顺劈额外敌人。

2.6.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长

鳞长唯一相关的改动是湮灭天赋树中的新天赋[[spell:116297]]，这使你可以在首次施放后18秒内重新施放你的[[spell:357210]]。这意味着你将更频繁地施放深呼吸。

2.7.

#### 防御与功能性调整

- [[spell:374348]]已更改，使其成为[[spell:363916]]的升级，使其治疗量等于你的黑曜鳞片所减免的伤害量，这对塑焰者来说是30%，对鳞长来说是40%。
- 已添加[[spell:410352]]，使你在[[spell:357210]]中飞行时受到的所有伤害改为在10秒内以持续伤害效果的形式承受。
- [[spell:370888]]已重做，现在为你和你[[spell:370665]]的目标提供100%移动速度提高以及3秒内移动施法的能力。

1.

### 湮灭唤魔师玩法基础

湮灭的玩法非常流畅，由于各种天赋，你将始终施放某种技能，而该技能会与你的下一次施放产生互动。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_disintegrate.jpg>) **管理你的精华**
  
  
  
  
  湮灭的主要资源是精华，用于[[spell:356995]]和[[spell:357211]]，你要确保自己绝不会停留在最大精华值，以避免浪费回复时间。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_firebreath.jpg>) **管理你的强化技能**
  
  
  
  
  强化法术（[[spell:357208]]和[[spell:359073]]）是你短冷却时间、高价值的技能，在几乎每种情况下，你都希望在它们就绪时立即使用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_essenceburst.jpg>) **消耗你的精华迸发**
  
  
  
  
  [[spell:369297]]将使你免费使用你的精华技能裂解/葬火，确保在层数已满（最多2层）或精华本身已满时，不要使用会产生精华迸发的技能。

仅凭这些互动中的一小部分，你的战斗循环就有相当的深度，这使该专精成为一个更具操作性和趣味性的输出专精。

1.

### 如何为湮灭唤魔师配装

虽然我们始终建议你自行模拟以获得理想结果，但我们确实提供了专门的湮灭配装页面。我们目前涵盖了第2赛季装备的推荐，以便在至暗之夜终局内容发布时有一个良好的开端。一旦你获得了一些装备，你就需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 添加了Kithix团本掉落和升级列表。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年9月23日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 在数值调整后调整了天赋。
- **2026年9月23日（本页）：** 已针对9月22日的增益进行更新。
- **2026年8月30日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了毕业装备列表。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 添加了第2赛季列表。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已更新至第2赛季。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 为第2赛季调整了属性。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 添加了新的第2赛季天赋树。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为第2赛季进行了调整。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已更新至第2赛季。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已针对至暗之夜第2赛季进行更新。
- **2026年8月10日（本页）：** 添加了所有相关的第2赛季信息。
- **2026 年 6 月 30 日（本页）：** 添加了6月30日的更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 将Rotmire物品添加到毕业装备列表。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 添加了万法大全（Omnium Folio）部分。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了饰品部分和毕业装备列表。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月24日（本页）：** 为史诗难度发布进行了调整。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月3日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 添加了80级天赋字符串。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 移除了过时的信息。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为至暗之夜添加了新的天赋树。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 移除了部分章节，添加了至暗之夜赛季前的具体内容。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 添加了至暗之夜附魔/消耗品。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 对至暗之夜的属性优先级进行了小幅调整。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 调整了输出循环并添加了巅峰部分。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为至暗之夜赛季前添加了新的配装方案。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已为至暗之夜进行更新/调整。
- **2026年2月26日（本页）：** 添加了赛季前部分，移除了之前的内容。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为12.0.1添加了新的天赋树。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了装备部分，移除了上一层级部分。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 移除了过时的天赋。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 添加了新的天赋树。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 添加了新的部分，并移除了已精简的输出循环信息。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为12.0.1添加了新的天赋树配装方案。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 添加了新的法术和天赋。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 为12.0.1调整了天赋。
- **2026年2月10日（本页面）：** 添加了前夕部分，移除了之前的部分。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为至暗之夜前夕添加了新的升级天赋树。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为HT添加/调整了天赋部分。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 为新天赋添加/调整了内容。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 添加了常见问题解答块。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 添加了常见问题解答块。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 添加了搏击俱乐部、玩家住房抢先体验和至暗之夜入门页面参考。
- **2025年11月28日（本页）：** 添加了新的优势/劣势列表和11.2.7信息。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了S3毕业装备列表并添加了Dinar部分。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 添加了11.2.5补丁信息。
- **2025年9月7日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 移除了套装提及。
- **2025年9月6日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 小幅更新，添加了无套装专属部分。
- **2025年8月21日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 小幅更新了起手式。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 添加了S3毕业装备列表和Reshii部分。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 移除了腐蚀并添加了新的生命药水。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 添加了截断部分和塑焰者专属套装部分。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为11.2补丁更新了天赋。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 为11.2天赋改动调整了雷鸣咆哮。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 更新了天赋树。
- **2025年8月4日（本页面）：** 添加了11.2补丁信息。
- **2025年6月21日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了D.I.S.C部分。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 添加了D.I.S.C部分/调整了毕业装备列表。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 添加了战斗助手部分。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为11.1.7补丁更新。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 为11.1.7补丁更新。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 添加了战斗助手部分。
- **2025年6月15日（本页）：** 为11.1.7补丁进行了调整/审查。
- **2025年6月2日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 简化了塑焰者单体输出循环的措辞。
- **2025年5月31日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 小幅修复，移除了炽燃炼狱。
- **2025年4月30日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了Cartel Chip部分。
- **2025年4月30日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 在相关地下城中添加了Boss专属提示。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 添加了新的Dinar部分。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 添加了腐蚀部分和头盔附魔。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 为高层大秘境调整了构建。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为11.1.5对湮灭单体输出循环部分进行了小幅调整。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为11.1.5调整了推荐构建，使塑焰者优于湮灭。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 将主要构筑从SC调整为FS。
- **2025年4月21日（本页）：** 为11.1.5补丁调整/审核。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为11.1.0补丁调整天赋树。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 新增第2赛季BiS列表。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对 11.1.0 补丁进行审阅。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对 11.1.0 补丁进行审阅。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对 11.1.0 补丁进行审阅。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 更新了塑焰者天赋树的法术列表。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 为11.1.0补丁调整了输出循环和天赋树。
- **2025年2月24日（本页面）：** 新增了11.1.0补丁的改动内容。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年2月17日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为11.1.0补丁调整了输出循环。
- **2025年2月17日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 天赋和法术已更新至11.1.0补丁。
- **2024年12月21日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了关于赛尔西斯的措辞和宝石。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 新增了11.0.7版本的赛尔西斯之冠信息。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 针对11.0.7补丁进行小幅调整。
- **2024年12月15日（本页）：** 已针对11.0.7补丁进行审查。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 更新了天赋模拟器。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** 为多个首领新增了史诗难度专属提示。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 为大秘境新增了更多信息。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 针对11.0.5补丁进行了小幅改动。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 新增了团队副本和大秘境BiS列表。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** 页面已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 新增了地心之战第1赛季章节。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 新增了地心之战新章节。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 新增了第1赛季开始前和第1赛季的毕业装备清单。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 针对地心之战进行了审核和调整。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 针对地心之战进行了审核。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 针对地心之战进行了调整。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 针对地心之战进行了调整。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 针对地心之战进行了调整，新增了HT。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 针对地心之战进行了调整。
- **2024年8月21日（本页）：** 针对地心之战进行了调整。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/devastation-evoker-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 针对地心之战前夕进行了审核。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 针对地心之战前夕进行了审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 针对地心之战前夕进行了审核。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 针对地心之战前夕进行了审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 新增了新布局和龙炎爆发输出循环改动。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 针对地心之战前夕进行了审核和检查。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 针对地心之战前夕进行了审核。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 针对地心之战前夕调整了布局。
- **2024年7月23日（本页面）：** 针对地心之战前夕进行了调整。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/devastation-evoker-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/devastation-evoker-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月24日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了饰品信息。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了套装信息以进行优化。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 移除了已更改的药水和附魔措辞。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 为第4赛季进行了审阅。
- **2024年4月15日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 修正格式并补充了铸币列表。
- **2024年4月14日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 为第4赛季进行了更新。
- **2024年4月14日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了审阅。
- **2024年3月25日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对10.2.6版本进行审阅
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审核，新增了无限之眼专属信息。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 针对10.2.6补丁进行了审查。
- **2024年1月23日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 更改了副属性优先级说明。
- **2024年1月22日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 小幅措辞调整。
- **2024年1月17日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 针对药水和飘渺虔诚进行了调整。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年11月28日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 新增了巨型地下城专属链接。
- **2023年11月12日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 新增了护腿装饰信息，因为其价值不再随穿戴者数量递减。
- **2023年11月12日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了BiS列表。
- **2023年11月12日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 调整了副属性列表。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 新增了孢子披风削弱信息，并调整了其在装饰列表中的位置。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为10.2版本进行了审查。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 移除了错误的章节，调整了BiS列表/饰品/装饰。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 为10.2新增了炽燃头盔附魔。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 为10.2版本进行了审查。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 为10.2版本进行了审查。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为10.2版本进行了审查。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 针对10.2进行了审核。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 为10.2版本进行了审查。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 为10.2版本进行了审查。
- **2023年11月6日（本页）：** 为10.2版本进行了审查。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已为10.1.7版本审核。
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 为10.1.7新增了新布局。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已为10.1.7版本审核。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已为10.1.7版本审核。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已为10.1.7版本审核。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已为10.1.7版本审核。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已为10.1.7版本审核。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 新增了新模板。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已为10.1.7版本审核。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已为10.1.7版本审核。
- **2023年9月4日（本页）：** 已为10.1.7版本审核。
- **2023年7月15日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 调整了AOE专属天赋措辞。
- **2023年7月12日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 修复了天赋树。
- **2023年7月12日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 调整了饰品列表。
- **2023年7月12日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 新增了永恒黎明。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 针对10.1.5补丁进行了审查。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 针对10.1.5补丁进行了审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 更新了10.1.5补丁的天赋树。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 更新了10.1.5补丁的天赋树。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 更新了10.1.5的天赋行。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 更新了10.1.5补丁的天赋树。
- **2023年7月10日（本页）：** 针对10.1.5补丁进行了小幅改动。
- **2023年6月29日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 对第3章节进行了调整。
- **2023年6月29日（本页）：** 对第4章节进行了小幅改动。
- **2023年6月17日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 对第2、10和12章节进行了调整。
- **2023年5月16日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 新增了力量涌动和虹彩章节。输出循环切换已更新。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 已更新至第2赛季（装备、装饰、套装、饰品），并将黑曜石戒指章节移至页面底部。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 新增了腰带附魔（10.1补丁新增）。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 为10.1补丁更新了天赋树，为第2赛季更新了词缀信息。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为10.1补丁更新了两套天赋树并更新了法术信息。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已更新至10.1补丁的改动。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 为10.1补丁更新了天赋树。
- **2023年5月1日（本页）：** 将10.0.7版本改动替换为10.1版本改动。
- **2023年4月28日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为补丁10.1更新了天赋模拟器。
- **2023年4月3日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 修复了天赋树问题。
- **2023年3月30日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 天赋修复。
- **2023年3月30日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 天赋修复。
- **2023年3月25日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 更新了原始宝石推荐。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/devastation-evoker-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 新增了黑曜石戒指章节。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 新增了黑曜石戒指宝石章节。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 更新了烈焰之柱目标数量图表。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已更新至10.0.7天赋改动。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 新增了10.0.7改动。
- **2023年2月6日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 修复了拆解的错别字。
- **2023年2月3日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 更新了关于卡纳莱克斯的文本，更明确地说明了该物品带来的精通收益。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 更新了饰品列表，移除了暗月卡牌并新增了虚空治愈者的暗影宝石（根据10.5补丁的近期改动）。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月7日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 修复了烈焰之柱速查表，因为列和行显示不正确。新增了关于引导瓦解连锁施法的章节。
- **2022年12月21日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 更新了属性优先级，降低了暴击的价值。
- **2022年12月12日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 更新了大秘境词缀和功能列表的提示。
- **2022年12月12日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 新增了一个烈焰之柱速查表，清晰展示在不同目标数量下何时使用烈焰之柱。新增了一个关于套装对输出循环影响的小章节。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 更新了天赋树并包含了PvP天赋。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 已针对第1赛季更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 更新了大秘境天赋树。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 将天赋树从侧重伤害的单体/AOE改为团本和大秘境，并描述了在必要时可以做出的改动。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年11月21日（[传说物品](<https://www.icy-veins.com/wow/devastation-evoker-best-legendaries-shadowlands>)):** 将暴击改为急速。
- **2022年11月18日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 简化了页面并移除了升级时选择天赋的列表。
- **2022年11月18日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 更新了输出循环切换。包含了未选择不稳定天赋时的场景。
- **2022年11月18日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 已更新为表格格式。
- **2022年11月15日（[升级](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** 页面已添加。
- **2022年11月15日（[传说物品](<https://www.icy-veins.com/wow/devastation-evoker-best-legendaries-shadowlands>)):** 页面已添加。
- **2022年11月15日（[盟约与羁绊](<https://www.icy-veins.com/wow/devastation-evoker-best-covenants-soulbinds-and-conduits>)):** 页面已添加。
- **2022年11月15日（[装备页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** 页面已添加。
- **2022年11月15日（[插件页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** 页面已添加。
- **2022年11月15日（[附魔页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** 页面已添加。
- **2022年11月15日（[属性页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** 页面已添加。
- **2022年11月15日（[大秘境页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** 页面已添加。
- **2022年11月15日（[循环页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** 页面已添加。
- **2022年11月15日（[天赋页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** 页面已添加。
- **2022年11月15日（[法术页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** 页面已添加。
- **2022年11月15日（[简单模式页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** 页面已添加。
- **2022年11月15日（本页）：** 页面已添加。

显示更多

显示更少

:::

## 练级

在本页，你将找到我们的逐级 湮灭 唤魔师 练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[唤魔师 练级指南](<https://www.icy-veins.com/wow/evoker-leveling-guide>).

1.

### 湮灭 唤魔师 在 至暗之夜 中的练级指南

由于唤魔师拥有高额的爆发性AOE伤害，通过做任务和快速清理小怪来练级是一种非常快速且高效的方式，可以迅速通过各个区域。此外，拥有能够让你恢复生命值的短冷却防御技能（例如 [[spell:374348]]），意味着大规模拉怪的风险比其他一些专精要低。

用 [[spell:362969]] 标记尽可能多的小怪。一旦它们聚在一起，施放高阶的 [[spell:357208]]，然后连续施放 [[spell:357211]]。葬火是一个无上限的AOE技能，这意味着无论你拉了多少个目标，它们都会一起融化。

1.

### 升级装备选择

在练级过程中，大多数情况下你都应该优先选择物品等级最高的装备。但是，如果你的戒指或项链只有一条副属性而不是两条，那么可以破例。在这些罕见的情况下，选择物品等级较低的物品是可以接受的。

在选择传家宝物品时，我们推荐使用带有暴击和急速属性的物品，因为它们会在练级时略微改善你的游戏流畅度。

2.1.

#### 至暗之夜升级实用消耗品

消耗品在练级时能带来很大差异。一定要备好这些物品，让你的旅程尽可能顺畅。

- [[item:212283]]：你最好的增伤合剂。
- [[item:212265]]：它与你的合剂产生协同效应，提供巨大的伤害提升。
- [[item:244839]]

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 湮灭 80级 至暗之夜 练级
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzMDMDzgZghZMTjZmpZwyMmZmZmZmZGwMzYwMLzMDMAD2AMaYAMDAbYgZGMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzMzADzYmBMYMTjZmpZMWmxMzMz8AzMzAmxMzYmZZmZgBGDWglxox2AYGA2wAzMYYA"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscRRFLLbZYYluqqPkkoXpWejEgnm+WDHA-jNiMhDEgBCCfUJeJT6iqe4w2cAK1uyA-AAAA-TIQaAUGYEE44iB-
```

:::

1.

### 升级用战争模式天赋

在这里，你将找到关于用于练级以及进行单人或小队PVE内容的最佳PVP天赋的信息。

1. [[spell:378444]] 将允许你在敌人试图击退你时安全地施放法术。它在采集被风扫过的草药节点时也很有用。
2. 当你从一群敌人身边逃跑时，[[spell:378437]] 会很有用。它还可以帮助你避免被击晕减速。
3. 第三个PVP天赋在很大程度上是你的个人选择。我推荐 [[spell:370388]]，因为它在开放世界移动中很有用，例如当你处于战斗中无法骑乘巨龙时。

湮灭 唤魔师 的PVP天赋总体上收益不大，但可以通过让战斗不那么麻烦来略微加快你的练级过程。

1.

### 升级循环

为了在练级和学习专精时保持简单，使用滑块选择你的等级，观察练级循环随着每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1 起：**你练级时的基础循环如下：

**等级 1–64：**使用 [[spell:357208]]（1级）和 [[spell:359073]]，等级根据目标数量而定（1-2个目标为1级，3-4个目标为2级，5个以上目标为3级）。

**等级 65 起：**使用 [[spell:357208]]（1级）和 [[spell:359073]]，等级根据目标数量而定（1-2个目标为1级，3-4个目标为2级，5-6个目标为3级，7个以上目标为4级）。

**等级 1 起：**如果战斗目标超过1个，使用 [[spell:357210]]。

**等级 1 起：**将 [[spell:356995]] 作为你的精华消耗技能，除非如果你正在与超过4个目标战斗，那么使用 [[spell:357211]]。

**等级 10 起：**如果你没有足够的精华来施放 [[spell:356995]] 或 [[spell:357211]]，那么使用 [[spell:361469]]（针对1-2个目标）或 [[spell:362969]]（针对3个以上目标）。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月3日：** 添加了80级天赋字符串。
- **2026年3月2日：** 移除了过时的信息。
- **2026年2月26日：** 为至暗之夜添加了新的天赋树。
- **2026年2月10日：** 为12.0.1添加了新的天赋树。
- **2026年1月19日：** 为至暗之夜前夕添加了新的升级天赋树。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 为11.1.0补丁调整天赋树。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 更新了天赋模拟器。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 新增了地心之战新章节。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月25日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月12日：** 修复了天赋树。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月28日：** 为补丁10.1更新了天赋模拟器。
- **2023年4月3日：** 修复了天赋树问题。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 更新了天赋树并包含了PvP天赋。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 简化了页面并移除了升级时选择天赋的列表。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 快速入门

在本页，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩 湮灭 唤魔师，使用最简单的循环、天赋树、属性优先级、装备搭配等，且不牺牲性能。

1.

### 湮灭 唤魔师在 至暗之夜 中的基础知识

本页面面向刚接触游戏或该职业的玩家，他们没有进行史诗难度团队副本的打算，或者只是想要一种更直接的方式来游玩自己的专精，而不会被大量需要考虑的细节和主动技能所淹没。

湮灭的玩法非常流畅，由于各种天赋，你将始终施放某种技能，而该技能会与你的下一次施放产生互动。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_disintegrate.jpg>) **管理你的精华**
  
  
  
  
  湮灭的主要资源是精华，用于[[spell:356995]]和[[spell:357211]]，你要确保自己绝不会停留在最大精华值，以避免浪费回复时间。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_firebreath.jpg>) **管理你的强化技能**
  
  
  
  
  强化法术（[[spell:357208]]和[[spell:359073]]）是你短冷却时间、高价值的技能，在几乎每种情况下，你都希望在它们就绪时立即使用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_essenceburst.jpg>) **消耗你的精华迸发**
  
  
  
  
  [[spell:369297]]将使你免费使用你的精华技能裂解/葬火，确保在层数已满（最多2层）或精华本身已满时，不要使用会产生精华迸发的技能。

1.

### 湮灭 唤魔师 在 至暗之夜 中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 单体目标天赋

2.1.

#### 湮灭 唤魔师 新手单体目标天赋

此配装将用于单体目标情况。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzMDMDzwMgBjZaMzMNjx2wMzMzMzMzAmZmxYmZZmZgBGD2glxox2AYGA2wMYmBDD"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscFRRLLbZtYYluqqPkkoXpjWEfenrdmCB-jNiMhDgCCfUJJeeTR6iCe4w2A0ucKzA-AAAA-TIQaAUGYEE84iB-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 AOE天赋

2.2.

#### 湮灭 唤魔师 新手AOE和大秘境天赋

这是我们推荐用于所有非纯单体目标内容的配装。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGzMgBjZamZmpZmx2MMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscRRFLLbZYYluqqPkkoXpjWEfenrVmCHA-jNiMhDgCCfUJJeeVTR6ie4w2gA0cKzA-AAAA-TIQaAUGYEE84iB-
```

:::

### 湮灭 唤魔师 基础循环

2.3.

#### 新手 湮灭 唤魔师 输出循环

湮灭 的主要重点分为三个不同的循环方面。

1. 蓄力法术：这些是短冷却、高伤害的技能，还会与你的其他非蓄力技能产生有益的互动。
2. 精华消耗技能：这些是 [[spell:356995]] 和 [[spell:357211]]。你要确保精华永远不会溢出浪费。
3. 填充技能：这些是 [[spell:361469]] 和 [[spell:362969]]。这些技能不消耗任何资源，并会触发免费的精华消耗技能以及一系列其他有益效果，具体取决于你当前的天赋。

除了这三个职业核心方面之外，你还会有一些冷却时间较长的技能，你会想用它们来增加伤害；这个列表非常有限。

2.4.

#### 基础循环起手

优先级系统对于 [湮灭 唤魔师](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-guide>) 整体来说并不复杂，你大部分的施法时间将花在引导 [[spell:356995]] 上，并在冷却好时使用各种技能，然后在需要时用 [[spell:361469]] 进行填充。

- 预读 [[spell:361469]]。
- 施放 [[spell:357210]]
- 施放 [[spell:375087]]。
- 施放 [[spell:370452]]。
- 配合 [[spell:370553]] 施放 [[spell:357208]]。
- 以1级施放 [[spell:359073]]。
- 持续施放 [[spell:356995]] 直到你用尽精华。
- 施放 如果你用尽了精华，并且之前列出的技能都没有准备好使用，施放 [[spell:361469]]。

确保你玩得好的一个非常简单有效的方法是按冷却时间使用 [[spell:359073]]/[[spell:357208]]/[[spell:370452]]。这在几乎所有情况下都是正确的。

如果你是 鳞长，你会想按冷却时间使用 [[spell:357210]]。如果你选择了 塑焰者，你会想在施加 [[spell:357208]] 后使用 [[spell:443328]] 以避免充能溢出。

2.5.

#### 重要冷却技能

[[spell:375087]] —— 这是你唯一实质性的伤害冷却技能，它将使你的精通（[[spell:362980]]）无论目标当前生命值如何都能发挥全部效果，并让你的填充技能每次施放都能保证触发免费的精华消耗技能。每次你使用蓄力法术时，狂龙之怒的效果都会延长。

2.6.

#### AOE循环

唯一的真正区别在于，当你专注于AOE而不是单体目标时，你会引导蓄力法术 [[spell:357208]] 到最大等级，然后用 [[spell:362969]] 替换 [[spell:361469]]，用 [[spell:357211]] 替换 [[spell:356995]]。

2.6.1.

##### 巅峰天赋： ![Rising Fury Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_evoker_risingfury.jpg>) 冲天怒火

至暗之夜 为我们带来了新的巅峰天赋 [[spell:1271687]]，它在你的 [[spell:375087]] 内作为伤害增益。效果在之后会持续一小段时间，为你提供额外的 [[spell:369297]] 层数，使你能更频繁地施放精华消耗技能。

2.6.2.

##### 第2赛季套装

至暗之夜 第2赛季带来了我们的新套装，使我们的 [[spell:370452]] 总是像你处于最大蓄力等级时那样施放，这与 [[spell:370821]] 有不错的协同作用，意味着我们的天赋调整为总是点出碎裂星辰。

### 湮灭 唤魔师 防御法术

2.7.

#### 湮灭 唤魔师 的防御法术

[[spell:363916]] 是你的主要防御技能，将减少你受到的所有伤害30%。你可以点出此技能的第二层充能，这意味着你总是能为可预测的入伤窗口准备显著的减伤。

[[spell:374348]] 是另一个防御技能，当你施放 [[spell:363916]] 时会自动施加。这会使你在接下来8秒内受到的所有伤害的30%也以持续8秒的持续治疗（HoT）形式治疗你。这对于长时间的中高强度伤害非常有效，因为它会保持你的生命值池处于高位，降低你死亡的风险。

[[spell:410352]] 这将使你的 [[spell:357210]] 在你飞行时将所受的所有伤害转化为持续10秒的持续伤害（DoT）效果，这是一个非常强大的防御技能，可以在需要时让你承受巨大的伤害。

[[spell:374227]] 将为你和4名附近的盟友提供20%的AOE技能减伤，持续一小段时间。这在特定情况下会非常出色，特别是在大秘境中。

这些是 湮灭 唤魔师 的防御性实用天赋和技能，有关更多详细信息，我们建议你查看法术总结页面。

### 湮灭 唤魔师 属性优先级

2.8.

#### 湮灭 唤魔师 的属性优先级

湮灭 唤魔师 的一般属性优先级如下所示。这在很大程度上是一个粗略的指南，是为那些不希望对自己的角色进行模拟的玩家设计的。如果你正在模拟你的角色，请完全忽略此属性优先级，并遵循你的模拟结果！

装备等级

暴击

急速

精通

全能

关于本页呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>).

### 暴风雪战斗助手

2.9.

#### 湮灭 唤魔师 战斗助手

战斗助手在这个补丁中到来，有两个选项可用于改进你的循环并学习最大化你的伤害。

第一个是单键助手，它会以轻微的全局冷却惩罚不断将自己切换到循环中的下一个按键，这目前比你手动最佳操作该职业大约损失20%的DPS。

第二个是高亮助手，它会按照暴雪预设的最佳循环在你的动作条上高亮显示你要按下的下一个技能，然而由于它遵循的是暴雪的循环而不是SimCraft中更深度优化的变体，这仍然会导致大约10%的DPS损失。

我强烈建议在最初学习 湮灭 时使用这两个功能，它不会教你完美地操作，但它会给你一个坚实的基础，而且整体损失并不那么显著。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已针对至暗之夜第2赛季进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已为至暗之夜进行更新/调整。
- **2026年2月10日：** 为12.0.1调整了天赋。
- **2026年1月19日：** 为新天赋添加/调整了内容。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月7日：** 移除了套装提及。
- **2025年8月4日：** 更新了天赋树。
- **2025年6月15日：** 添加了战斗助手部分。
- **2025年4月21日：** 将主要构筑从SC调整为FS。
- **2025 年 2 月 24 日：** 为11.1.0补丁调整了输出循环和天赋树。
- **2024年12月15日：** 针对11.0.7补丁进行小幅调整。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 针对地心之战进行了调整。
- **2024年7月23日：** 针对地心之战前夕调整了布局。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月23日：** 更改了副属性优先级说明。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 更新了10.1.5补丁的天赋树。
- **2023年5月1日：** 为10.1补丁更新了天赋树。
- **2023年3月30日：** 天赋修复。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 天赋与构筑

在本页，你将找到在《魔兽世界》12.1.5补丁中你的 湮灭 唤魔师 的最佳天赋。我们还为各种类型的内容（如团本或大秘境）提供了默认天赋配装。如果你开启了战争模式，我们也为你准备了PVP天赋。

1.

### 至暗之夜 湮灭 唤魔师 的最佳天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 是第2赛季所有内容形式中 湮灭 的最佳英雄天赋，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 只有在纯单体目标场景中才能与之媲美。目前我们推荐以下：

- **团队副本 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 是每个Boss的首选，单体目标略好一些，而且每当增加一个额外目标时就会有巨大的收益，没有理由去玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 除非你真的喜欢那种玩法风格。
- **大秘境 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 目前在所有地下城中都会更好，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 只有在你达到8-9个目标时塑焰者才会领先，并且为此你需要在单体伤害上付出显著的损失。因此，强烈建议你坚持使用SC。

唤魔师 职业树提供了大量的实用选项，你可以挑选以适应任何情况下的需求。下面的天赋树是为追求最大伤害而设的基准配置，并以牺牲实用性为代价点出了一些非常微小的伤害收益。在你需要提供更多控制的情况下，我们建议从 [[spell:375520]] 和 [[spell:375554]] 中移除点数，投入到下面列出的天赋中。

- [[spell:372048]] 这个天赋在所有组队玩法中都很棒，与AOE眩晕配合使用以将其持续时间增加50%是非常强大的。
- [[spell:360806]] 这个天赋更小众一些，但有一些非常强大的用途。它可用于在地下城中将单个小怪从其群落中分离出来，从而实现独特的路线，并在需要时充当目标的硬控。
- [[spell:375528]] 这个天赋是另一个小众天赋，但在特定情况下非常好，因为它有助于更长的AOE控制循环并防止小怪移动。

**快速开始导入代码：**

:::talents 鳞长 团本/地下堡 -
```json
{
  "code": "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMbzMDMwYwGsMGN2GQmJAbYgZGMjHA"
}
```
:::

:::talents 鳞长 大秘境 -
```json
{
  "code": "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBGYMTjZmpZmZ2mZmZmZmZmZGwMzMzYmZbmZgBGD2glxox2AyMBYDzgZGM8AA"
}
```
:::

1.1.

#### 巅峰1或巅峰4

对于所有 鳞长 配装来说，1/4巅峰和4/4巅峰之间的差异基本上是不存在的。下面的推荐几乎都是选择巅峰1，因为它更容易操作，在多变的情况下也更加宽容。

要显示天赋树，请选择你想要游玩的英雄天赋和内容

鳞长

单体目标团队副本

推荐

团本顺劈/地下堡

推荐

秘境+

推荐

塑焰者

团队副本

秘境+

### 天赋方案 0-0

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 单体目标团本配装

此构筑在纯单体目标情况下是最优的。

### 天赋方案 0-1

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 团本顺劈和地下堡配装

这是我们推荐用于团本顺劈场景以及进行地下堡时的配装。

### 天赋方案 0-2

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 大秘境配装

此配装在进行大秘境时最强。

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 团本配装

这套天赋树可以用于团本，作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者。它仅在纯单目标场景中能与 鳞长 竞争，而在其他所有场景中都明显落后。在职业调整完成之前，我们不建议使用这套天赋，除非你非常喜欢 塑焰者 的玩法，即使这会带来明显的性能损失。

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 大秘境天赋

这套天赋树可用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 层数。它的 AoE 潜力远高于 鳞长，但代价是单体输出大幅下降。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGjxYGmBMYMTjZmpZM2GmZmZmZmZGwMmZGzMbzMDMwYwGsMGN2GAzAwGGYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcsFLLYYblqquPXkkopEWegjnvfmXDB-jNhiDMgCCEKUeefGIT7iw04Aeuy2KdA-AAAA-JQSUaACKYw4IzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMbzMDMwYwGsMGN2GAzAwGGYmBz4BA"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcsFLLYYblqquPXkkopEWegjnvfmXDB-jNhiDMgCCUVeefJJT7Qiw04Aeguy2KPcsA-A-JQSUaACKYw4IzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwgZGmBGYMTjZmpZmZ2mZmZmZmZmZGwMzMzYmZbmZgBGD2glxox2AYGA2wMYmBDPA"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcstFKYYblqquPXkkopEWegjndfmXDB-jNhiDMgCCLLUVeefST7iw04Aeguy2KPcsA-A-JQSUaACKYw4IzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGmZYGmBMYMTjZmJjxyYmZGmZmZGwMmZGzMbzMDmBmxMwCYBMDTgNwywAYmZGD"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcsFLLYYblqquPXkkopEWegjnvfmXDB-jNhiDMgCCEUeefJJT6Qiw0AeuyKPsIB-AAAA-IckUhpBIQYgxSB-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzYMzMzMzwMwMYMTzYmJjxywMzwYmZGwMmxYmZbmZwMwMmBWAbgZYCsBWGmBYmZYA"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcstFKLLYYblqquPXkkopEVejnfmXDB-jNhiDMgBLLUfJJKT6MQiw0AKeuyKPIB-AAAA-IekUhpBIQYgxSB-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

:::details 小贴士我何时应该选择星芒齐射而不是能量涌动？
湮灭 唤魔师 的第二赛季套装非常侧重于

[[spell:370452]]

，提高其伤害，并且无论蓄力等级如何都自动命中最大数量的目标。这使得它在 2 个目标时就能带来伤害提升，并且目标越多威力越大。代价是，如果不点能量涌动，生活质量会大幅下降。在 2 个目标时的收益大约为 1.5-2% DPS，这意味着在团本环境中使用能量涌动完全没问题，但在大秘境中你应该始终选择星芒齐射。

:::

1.

### 全知典籍

万卷全书是一种借用力量系统，于 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)
中引入，让你可以选择 5 种不同的“天赋”以获得小幅增益。其中大部分是小幅伤害提升，而防御节点提供的增益几乎可以忽略不计。

我们推荐以下选择。这些可以在任何时候更换，无需返回万卷全书：

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279609]]
- [[spell:1279614]]

1.

### 巅峰天赋： ![Rising Fury Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_evoker_risingfury.jpg>) 冲天怒火

湮灭 唤魔师 的新巅峰天赋是 [[spell:1271687]]，这是一种可叠加的急速和伤害提升，在我们使用 [[spell:375087]] 时激活。

激活狂龙之怒时从 1 层开始，你每 6 秒获得 4% 急速。这个急速增益最多可叠加 5 层，总计 20%。达到 5 层后，你还会获得 15% 的伤害提升，狂龙之怒结束后每层持续 4 秒。

当狂龙之怒结束时，你将获得 4 层 [[spell:1292322]]。此技能对 5 个目标造成伤害并赋予一层 [[spell:369297]]，你必须在狂龙之怒冷却时间再次可用之前消耗完这些层数。

1.

### 英雄天赋

从 71 级开始，你将可以从两个新的英雄天赋树中选择，对于 湮灭 来说是
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 非常注重通过英雄天赋 [[spell:444088]] 施加和消耗你的 [[spell:357208]]。这可以通过两种特定方式实现：如果你是单目标则施放 [[spell:356995]]，如果在进行 AoE 循环则施放 [[spell:357211]]。塑焰者 的玩法与你的常规循环相比没有太多调整，唯一明显的区别是你施放 [[spell:357208]] 的频率会高得多。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长 非常注重将 [[spell:357210]] 作为你循环的核心部分，并结合 湮灭 天赋树中的新天赋 [[spell:116297]]。鳞长 拥有几乎无限的机动性，每次施放 深呼吸 都会重置你的 [[spell:358267]] 冷却时间。它还通过核心技能 [[spell:401680]] 提供强化的分散顺劈，使每次蓄力施放（火焰吐息/永恒之涌）之后的奥术飞弹能够命中最多三个额外目标，总计最多四个。这使其成为一个非常强力的团本专精，唯一的缺点是缺乏高额的单体爆发伤害。

关于 [[spell:411165]] 或 [[spell:411164]]，你应该对自己的角色进行模拟以确定。[[spell:411164]] 在 [[spell:375087]] 延长方面有更宽容的玩法，即使有轻微损失我也推荐选择它。在你对这个专精非常熟悉之前，继续使用 [[spell:411164]]。

1.

### PvP天赋（战争模式）

选择战争模式会让你有资格参与开放世界 PvP，但也会给你带来以下好处：

- 满级的世界任务奖励提高10%（如果你是联盟则为30%）。
- 升级期间获得的经验值提高10%（如果你是联盟则为30%）。
- 允许你获得征服点数，以换取每周装备奖励。
- 允许你在开放世界中使用 PvP 天赋。

鉴于开启战争模式对升级和PvE内容的好处，我们建议你启用此功能，以最大化你的升级过程和满级后的奖励。然而，你会使自己有资格参与开放世界PvP，在升级或做世界任务时存在被“偷袭”的可能性。

唤魔师没有任何能提高你总伤害输出的 PvP 天赋。因此，你选择的 PvP 天赋完全取决于个人喜好。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月23日：** 在数值调整后调整了天赋。
- **2026年8月10日：** 已更新至第2赛季。
- **2026年6月15日：** 添加了万法大全（Omnium Folio）部分。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜赛季前添加了新的配装方案。
- **2026年2月10日：** 为12.0.1添加了新的天赋树配装方案。
- **2026年1月19日：** 为HT添加/调整了天赋部分。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 为11.2补丁更新了天赋。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 为11.1.5调整了推荐构建，使塑焰者优于湮灭。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025年2月17日：** 天赋和法术已更新至11.1.0补丁。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 针对地心之战进行了调整。
- **2024年7月23日：** 针对地心之战前夕进行了审核和检查。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审核，新增了无限之眼专属信息。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 针对10.2进行了审核。
- **2023年9月4日：** 新增了新模板。
- **2023年7月15日：** 调整了AOE专属天赋措辞。
- **2023年7月10日：** 更新了10.1.5补丁的天赋树。
- **2023年5月1日：** 为10.1补丁更新了两套天赋树并更新了法术信息。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年2月6日：** 修复了拆解的错别字。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 将天赋树从侧重伤害的单体/AOE改为团本和大秘境，并描述了在必要时可以做出的改动。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何优化你的 湮灭 唤魔师 在单目标和多目标情况下的输出循环。我们还有关于冷却时间、触发等的进阶部分，以便最大化你的 DPS。我们的所有内容均已更新至《魔兽世界》12.1.5 补丁。

1.

### 湮灭 唤魔师 玩法与输出循环指南

欢迎来到我们的 湮灭 唤魔师输出循环页面。在本页中，你将找到关于该专精在团本和大秘境场景中循环玩法所需了解的一切。

以下每个部分分别讲解了 湮灭 唤魔师 在不同目标数量下的输出循环。点击方框切换到所需的伤害类型。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者

团队副本

秘境+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长

团队副本

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

秘境+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:369459]]

[[spell:374968]]

[[spell:374227]]

[[spell:351338]]

[[spell:359073]]

[[spell:375087]]

[[spell:1265867]]

[[spell:369089]]

[[spell:375725]]

[[spell:375757]]

[[spell:411165]]

[[spell:411164]]

[[spell:1265802]]

[[spell:376888]]

[[spell:386283]]

[[spell:370781]]

[[spell:370839]]

[[spell:116297]]

[[spell:375777]]

[[spell:370821]]

[[spell:370867]]

### 鳞长单体目标详解

[[spell:361469]]

[[spell:357210]]

[[spell:375087]]

[[spell:359073]]

[[spell:357208]]

[[spell:356995]]

[[spell:357210]]

[[spell:359073]]

[[spell:356995]]

[[spell:357208]]

[[spell:356995]]

[[spell:361469]]

[[spell:369297]]

1.1.

#### 鳞长 单目标起手

1. 预读 [[spell:361469]]
2. 施放 [[spell:357210]]，在命中目标后立即取消
3. 施放 [[spell:375087]]
4. 施放 [[spell:359073]]
5. 以蓄力等级 1 施放 [[spell:357208]]
6. 持续施放 [[spell:356995]] 直到耗尽精华
7. 施放 [[spell:357210]]
8. 以蓄力等级 1 施放 [[spell:359073]]
9. 施放一次 [[spell:356995]]
10. 以蓄力等级 1 施放 [[spell:357208]]
11. 持续施放 [[spell:356995]] 直到耗尽精华
12. 施放 [[spell:361469]] 作为填充技能以产生 [[spell:369297]]
13. 按照下面列出的循环进行。

1.2.

#### 鳞长 单目标循环

1. 冷却完毕时施放 [[spell:357210]]，在消耗至少两层 [[spell:370781]] 后 7-8 秒施放其第二次
2. 始终以蓄力等级 1 施放 [[spell:357208]]
3. 始终以蓄力等级 1 施放 [[spell:359073]]
4. 施放 [[spell:356995]] 以消耗你的精华
5. 可用时施放 [[spell:1265867]]
6. 施放 [[spell:361469]] 作为填充技能
7. 如果没有 [[spell:358267]] 可用，施放 [[spell:362969]] 作为填充技能

1.3.

#### 无缚烈焰的使用

[[spell:1292322]] 的使用非常简单，在 [[spell:375087]] 结束时，当你完全叠加了 [[spell:1271788]]，你想在伤害和急速增益窗口内消耗全部 4 层。当你精华低于 4 且没有 [[spell:369297]] 层数时，你应该消耗一层。

### 鳞长 大秘境详解

[[spell:357210]]

[[spell:375087]]

[[spell:359073]]

[[spell:370553]]

[[spell:357208]]

[[spell:356995]]

[[spell:401680]]

[[spell:357211]]

[[spell:356995]]

[[spell:361469]]

[[spell:375801]]

[[spell:369939]]

[[spell:362969]]

[[spell:375801]]

[[spell:369939]]

[[spell:357208]]

[[spell:359073]]

1. 当敌人聚集后施放 [[spell:357210]]
2. 施放 [[spell:375087]]
3. 以等级 1 或匹配目标数量施放 [[spell:359073]]，每个蓄力等级分别对应 2/4/6 个目标。或者使用 [[spell:370553]]
4. 以等级 1 施放 [[spell:357208]]
5. 在施放蓄力技能后施放 [[spell:356995]] 以触发 [[spell:401680]]
6. 当与 5 个或更多目标战斗时施放 [[spell:357211]]，在 4 个或更少目标时切换到 [[spell:356995]]
7. 在 [[spell:375801]] 触发时施放 [[spell:361469]] 并消耗 [[spell:369939]]
8. 当你没有 [[spell:375801]] 或 [[spell:369939]] 时，施放 [[spell:362969]] 作为填充技能
9. 可用时立即施放 [[spell:357208]] 和 [[spell:359073]]，提升永恒之涌的等级以匹配目标数量。

1.4.

#### 无缚烈焰的使用

[[spell:1292322]] 的使用非常简单，在 [[spell:375087]] 结束时，当你完全叠加了 [[spell:1271788]]，你想在伤害和急速增益窗口内消耗全部 4 层。当你精华低于 4 且没有 [[spell:369297]] 层数时，你应该消耗一层。

### 塑焰者 单目标详解

[[spell:361469]]

[[spell:375087]]

[[spell:357208]]

[[spell:359073]]

[[spell:356995]]

[[spell:357208]]

[[spell:356995]]

1.5.

#### 塑焰者 起手

1. 预读 [[spell:361469]]
2. 施放 [[spell:375087]]
3. 以蓄力等级 1 施放 [[spell:357208]]
4. 以蓄力等级 1 施放 [[spell:359073]]
5. 施放两次 [[spell:356995]]
6. 以蓄力等级 1 施放 [[spell:357208]]
7. 持续施放 [[spell:356995]] 直到精华耗尽

1.6.

#### 塑焰者 循环

这将是一个简单的优先级列表，说明在起手之后你应该如何消耗你的全局冷却以造成最佳伤害。

1. 冷却完毕时施放 [[spell:357208]]，始终以蓄力等级 1
2. 冷却完毕时施放 [[spell:359073]]
3. 施放 [[spell:356995]] 作为你的精华消耗技能
4. 可用时施放 [[spell:1265867]]
5. 施放 [[spell:361469]] 作为填充技能
6. 如果在没有 [[spell:358267]] 激活的情况下需要移动施法，施放 [[spell:362969]]

1.7.

#### 无缚烈焰的使用

[[spell:1292322]] 的使用非常简单，在 [[spell:375087]] 结束时，当你完全叠加了 [[spell:1271788]]，你想在伤害和急速增益窗口内消耗全部 4 层。当你精华低于 4 且没有 [[spell:369297]] 层数时，你应该消耗一层。

### 塑焰者 大秘境详解

[[spell:375087]]

[[spell:357208]]

[[spell:444088]]

[[spell:357211]]

[[spell:356995]]

[[spell:361469]]

[[spell:357208]]

[[spell:369939]]

[[spell:359073]]

[[spell:357208]]

1. 冷却完毕时施放 [[spell:375087]]
2. 始终以蓄力等级 1 施放 [[spell:357208]] 以最大化 [[spell:444088]] 的伤害
3. 对 3 个及以上目标施放 [[spell:357211]]，在 2 个目标时切换到 [[spell:356995]]
4. 在每次 [[spell:357208]] 之间至少施放一次 [[spell:361469]] 以消耗 [[spell:369939]]
5. 当上述技能都不可用时施放 [[spell:359073]]
6. 可用时立即施放 [[spell:357208]]

1.8.

#### 无缚烈焰的使用

[[spell:1292322]] 的使用非常简单，在 [[spell:375087]] 结束时，当你完全叠加了 [[spell:1271788]]，你想在伤害和急速增益窗口内消耗全部 4 层。当你精华低于 4 且没有 [[spell:369297]] 层数时，你应该消耗一层。

:::details 常见问题我何时应该使用焚书而不是奥术飞弹？
在三个目标时，你的

[[spell:357211]]

将开始造成更高的总伤害。但请记住，如果你需要击杀优先目标，你应该施放

[[spell:356995]]

上。

:::

1.

### 至暗之夜 第2赛季套装

至暗之夜 第二赛季套装将我们的技能 [[spell:370452]] 变为一个更强大的被动效果。

1. [[spell:1296639]] — 将 [[spell:370452]] 造成的伤害提高 50%，并且在施放时视为已达到最大蓄力等级。
2. [[spell:1296640]] — [[spell:375777]] 每次触发时，额外减少你的蓄力法术 0.1 秒的剩余冷却时间。[[spell:359073]] 造成的伤害提高 10%。
3.

### 职业与专精机制详解

### 狂龙之怒的延长

3.1.

#### 狂龙之怒的延长

狂龙之怒的延长是通过在激活 [[spell:375087]] 冷却时间后施放蓄力法术（如 [[spell:357208]] 和 [[spell:359073]]）来实现的。这仅在点了 [[spell:375797]] 天赋时才可能。尽管狂龙之怒的持续时间不再有上限，但由于每次延长的收益递减，你不太可能超过 34 秒太多。

### 连环轰炸的顺劈

3.2.

#### 连环轰炸的顺劈

连环轰炸的顺劈是 鳞长 英雄天赋树特有的，通过将你的 [[spell:434300]] 减益效果分散到多个目标来实现。每次 [[spell:401680]] 的主目标都会获得自己的连环轰炸减益效果。你施放的每个精华技能都会延长所有激活的连环轰炸的持续时间，使你能够从 [[spell:441206]] 获得双倍的伤害和 [[spell:357210]] 的双倍冷却缩减。

### 巅峰天赋

3.3.

#### 巅峰天赋

湮灭 唤魔师 的新巅峰天赋是 [[spell:1271687]]，这是一种可叠加的急速和伤害提升，在我们使用 [[spell:375087]] 时激活。

激活狂龙之怒时从 1 层开始，你每 6 秒获得 4% 急速。这个急速增益最多可叠加 5 层，总计 20%。达到 5 层后，你还会获得 15% 的伤害提升，该提升持续到增益效果消失。

当狂龙之怒结束时，你的激昂 狂怒 将每层持续 4 秒，最多 20 秒。这实际上维持了之前的增益效果，此外每 4 秒还会为你提供一层 [[spell:369297]]。

1.

### 湮灭 唤魔师 的重要冷却时间

### [[spell:375087]]

4.1.

#### 狂龙之怒

[[spell:375087]] 是我们唯一的主要冷却时间，每 2 分钟可用一次。它赋予 [[spell:362980]] 完全的效果，并保证你所有的填充法术（[[spell:361469]] / [[spell:362969]] / [[spell:1265867]]）都会触发 [[spell:369297]]。在一场战斗中尽可能多地使用它非常重要。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 为第2赛季进行了调整。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 调整了输出循环并添加了巅峰部分。
- **2026年2月10日：** 添加了新的部分，并移除了已精简的输出循环信息。
- **2025年11月30日：** 添加了常见问题解答块。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月6日：** 小幅更新，添加了无套装专属部分。
- **2025年8月21日：** 小幅更新了起手式。
- **2025年8月4日：** 添加了截断部分和塑焰者专属套装部分。
- **2025年6月15日：** 添加了战斗助手部分。
- **2025年6月2日：** 简化了塑焰者单体输出循环的措辞。
- **2025年5月31日：** 小幅修复，移除了炽燃炼狱。
- **2025年4月21日：** 为11.1.5对湮灭单体输出循环部分进行了小幅调整。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025年2月17日：** 为11.1.0补丁调整了输出循环。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 针对地心之战进行了调整。
- **2024年7月23日：** 新增了新布局和龙炎爆发输出循环改动。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月22日：** 小幅措辞调整。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月29日：** 对第3章节进行了调整。
- **2023年6月17日：** 对第2、10和12章节进行了调整。
- **2023年5月16日：** 新增了力量涌动和虹彩章节。输出循环切换已更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 更新了烈焰之柱目标数量图表。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月7日：** 修复了烈焰之柱速查表，因为列和行显示不正确。新增了关于引导瓦解连锁施法的章节。
- **2022年12月12日：** 新增了一个烈焰之柱速查表，清晰展示在不同目标数量下何时使用烈焰之柱。新增了一个关于套装对输出循环影响的小章节。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年11月18日：** 更新了输出循环切换。包含了未选择不稳定天赋时的场景。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到《魔兽世界》12.1.5 中你的 湮灭 唤魔师 的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们应有尽有！

1.

### 湮灭 唤魔师 毕业装备指南

欢迎来到我们的 湮灭 唤魔师 至暗之夜 装备页面。查看此页面，了解关于为 湮灭 唤魔师 配装所需了解的一切，包括来自所有来源、团本和大秘境的毕业装备，以及关于最佳饰品、套装等信息。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

本列表包含来自所有来源的 湮灭 唤魔师 最高伤害输出配装方案。请记住，还有许多其他配装方案的表现也在误差范围之内。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，作为一名 湮灭 唤魔师，随着催化剂系统的改动，你希望将任何没有全能属性的物品催化成套装槽位，这使得定向刷取变得更有价值。你想要定向催化获取的具体物品如下。

- 头部：[[item:268230]] 来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- 肩部：[[item:268231]] 来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 胸部：[[item:271876]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手套：套装手套已经拥有不错的属性，所以我们不对这个槽位进行催化。
- 腿部：[[item:268237]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details 常见问题：如何处理宏伟宝库？
宏伟宝库在本赛季有两个重大改动：首先，当史诗团队副本物品作为奖励列出时，会自动升级到最高级别；其次是购买模糊虚空核心（额外拾取）的能力。这些改动使得每次做出最佳选择变得更加困难，但仍有一些高价值的目标需要你优先考虑。

你首先要追求的是你的套装奖励，通常这会是一件武器，但由于新的美化效果非常强大，强烈建议改为制作一件武器。

这里变得更加困难，并且在一定程度上取决于你所参与的内容等级。如果你不参与史诗团队副本内容，你可以对最后一个英雄难度首领使用额外拾取，奖励将是1/6史诗而不是英雄级别。这对于定向获取最终首领的咒术物品非常有效，你可以将拾取专精更改为 恩护，这样战利品表上只有3件物品，保证每次都能获得一件非常有价值的物品。

这些物品需要纹章才能完全升级，这可能会减缓你整体物品等级的提升速度，但这些物品的相对威力，特别是 [[item:268265]]，比任何其他项链都高出很多，毫无疑问值得使用纹章。请记住，这些物品在史诗难度掉落时会带有剧毒诅咒，并升级到9/6，而不是常规的6/6上限。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">基希伊克斯的解缚</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>护肩</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271504@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">基希伊克斯的解缚</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">基希伊克斯的解缚</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 秘境+

本列表包含来自大秘境的 湮灭 唤魔师 最高伤害输出配装方案。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。所以在决定附魔和升级之前，请花时间检查每件物品的价值，这在决定将额外拾取用在哪里时更为重要。

根据你的喜好选择次要属性。你的实际情况可能会有所不同。

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，作为一名 湮灭 唤魔师，随着催化剂系统的改动，你希望将任何没有全能属性的物品催化成套装槽位，这使得定向刷取变得更有价值。你想要定向催化获取的具体物品如下。

- 头部：[[item:251220]] 来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 肩部：[[item:239049]] 来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 胸部：[[item:273789]] 来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 手套：[[item:160213]] 来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 腿部：[[item:159375]] 来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details 小贴士：我应该刷哪些地下城？
有些地下城比其他地下城获得毕业物品的机会要大得多，如果你时间有限，我们推荐以下地下城。

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) 共有4件你想要的物品，包括你的武器。
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>) 有2件，包括一件毕业地下城饰品。
- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>) 有3件物品。

除了这3个地下城外，你自然会在其他地下城中填补其余槽位，但这些是配装的最佳起点。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:273781@JAACAAAOyA]]&#10;&#10;<div>[[item:240983]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>腰部</th><td>[[item:251155@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>护肩</th><td>[[item:271499@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271500@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAAAxA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271504@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAACAAAD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAOAAwt1wgNRDjexclIgBDH2A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 团队副本

本列表包含来自团队副本的 湮灭 唤魔师 最高伤害输出配装方案。一如既往，能给你带来最大提升的内容取决于你其余的装备。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

所以在选择从团队副本中额外拾取什么时要小心，确保你已经正确模拟了你的选择。

常见问题我需要哪些套装部件？

在 至暗之夜 第2赛季中，作为一名 湮灭 唤魔师，随着催化剂系统的改动，你希望将任何没有全能属性的物品催化成套装槽位，这使得定向刷取变得更有价值。你想要定向催化获取的具体物品如下。

- 头部：[[item:268230]] 来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- 肩部：[[item:268231]] 来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 胸部：[[item:271876]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手套：套装手套已经拥有不错的属性，所以我们不对这个槽位进行催化。
- 腿部：[[item:268237]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
  
  
  
  
  小贴士：我想从团队副本中定向获取哪些物品？

如果你不确定你需要专注于哪些物品以及你最大的提升在哪里，我们会为你详细分析。

- [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 掉落3件极其强大的物品：[[item:268265]]、[[item:271876]] 和 [[item:271092]]。所有这些物品都带有强大的咒术效果，极大地提升了它们的威力。
- [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) 掉落我们的一件毕业饰品，[[item:270164]]。
- [潮缚石窟](<https://www.icy-veins.com/wow/midnight-world-bosses-guide>) 掉落我们的另一件毕业饰品，[[item:270167]]。

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">基希伊克斯的解缚</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>护肩</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271504@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">基希伊克斯的解缚</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">基希伊克斯的解缚</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 湮灭 唤魔师 饰品推荐

我们建议当你获得这里列出的饰品时进行模拟，因为这不会是在每种情况下都适用的铁律。除了这些之外，你还可以使用其他饰品，但它们要差得多。

本赛季 湮灭 唤魔师 有几个强力饰品，其中三个明显优于其他：[[item:270164]]、[[item:270167]] 和 [[item:270168]]。

下面我们提供了一个排名图表，帮助你更好地了解这四个饰品以及更多饰品。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 湮灭 唤魔师 饰品排名
除非为了比较而指定了较低的物品等级，否则所有饰品都假定为大秘境物品等级。目的是在它们可获得的最高物品等级下比较饰品，让你了解它们的定位。我们不建议使用两个主动使用饰品，即使这些饰品在列表中的排名高于被动饰品。如需了解饰品对你自己角色表现的更准确信息，请 [模拟你的角色](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

本列表中定义的“层级”大约相当于0.5%的伤害输出，这意味着S级饰品比A级饰品好约0.5%，以此类推。本层级的饰品价值非常接近，因为它们整体上损失了很多威力，所以没有那两件毕业饰品也不会感觉太差。

<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]] 被动。团队副本掉落<li>&#10;<li>[[item:270168]] 主动使用。团队副本掉落</li>&#10;<li>[[item:270164]] 被动。团队副本掉落</li>&#10;<li>[[item:270167]] 被动。团队副本掉落</li>&#10;</li></li></ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td><ul>&#10;<li>[[item:250215]] 主动使用。地下城掉落</li>&#10;<li>[[item:250224]] 被动。地下城掉落</li>&#10;<li>[[item:273796]] 主动使用，这个饰品的随机属性选择在一定程度上降低了它的价值。地下城掉落</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169]] 主动使用。团队副本掉落</li>&#10;<li>[[item:273794]] 被动。地下城掉落</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 模糊虚空核心（额外拾取）和至尊剧毒石

12.0.5补丁引入的额外拾取系统将在第2赛季继续。
[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 是可以在地下城中或杀死特定团队副本首领后使用的物品，让你从该地下城或团队副本首领处获得一件保证的战利品。你从该战利品池中获得的物品是随机的，但如果你再次使用则不会获得重复物品，因此在特定地点再次使用它将让你有机会获得剩余物品中的另一件。

3.1.

#### 湮灭 唤魔师 推荐的模糊虚空核心使用方式

你想要的物品以及你追求它们的顺序将取决于几个因素，但主要是由你当前的装备和你期望在 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)中看到的奖励决定的。当我列出你想要定向获取的每个团队副本首领或地下城时，我会更深入地解释这些决定背后的原因。

如果你不会立即进入史诗团队副本，而将在英雄难度上花费相当多的时间，我 **强烈** 建议你将前3个宏伟宝库名额用于获取虚空核心，并将它们全部用在 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)上。[[item:268265]]、[[item:271876]] 和 [[item:271092]] 的价值比任何其他物品都高出很多，只有当你在史诗难度击杀这个首领时才会被替换。

如果你不参与团队副本内容，且将额外拾取全部用于地下城，那么你的首要任务应该是获得新的套装奖励。为此，最好的选择是 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>) ，因为它有3个套装槽位和2个非套装槽位的毕业物品，在那之后你应该专注于下面列出的地下城优先级。

你能有效定向获取的团队副本首领将取决于你公会当前的进度水平，下面的列表将按你能获得的最佳战利品总量排序。

- **剧毒深渊 - 乌拉特克**：这是一个后期进度首领，只有四件物品，你可以通过将拾取专精更改为 恩护 将其减少到3件。
  
  
  
  
  - [[item:268265]]
  - [[item:271876]]
  - [[item:271092]].
- **剧毒深渊 - 盘卷祭坛**：这是另一个后期进度首领，但有五件物品，其中三件是你的毕业清单的一部分。
  
  
  
  
  - [[item:268231]]（催化成套装）
  - [[item:268237]]（将此催化成套装）
  - [[item:268253]]
- **剧毒深渊 - 迷失的探险者**：这是一个中期进度首领，有四件物品，其中两件是你的毕业清单的一部分。
  
  
  
  
  - [[item:270164]]
  - [[item:268258]]

其余的团队副本首领更偏向于你不需要的物品，所以我建议避免对它们使用额外拾取，除非你已经拥有了其他所有物品。

你想要定向获取的地下城将完全基于你当前缺少哪些物品，以及哪些物品在史诗战利品轨道上能给你带来最大的提升。

- **毒牙祭坛**：这个地下城共有九件物品，其中四件是你的地下城毕业装备的一部分，包括你的武器。
  
  
  
  
  - [[item:273778]]
  - [[item:273792]]
  - [[item:273781]]
  - [[item:273789]]（催化成套装）
- **塞塔里斯神庙**：这个地下城共有10件物品，其中三件是你的地下城毕业装备。
  
  
  
  
  - [[item:159388]]
  - [[item:159375]]
  - [[item:158366]]
- **密谋小径**：这个地下城共有八件物品，其中两件是你的地下城毕业装备，包括一件饰品。
  
  
  
  
  - [[item:250215]]
  - [[item:251132]]

其余地下城中混杂了大量你不需要的战利品和你需要的物品，与团队副本建议一样，我会优先考虑前2个地下城，然后再担心其他的。

将这些列表作为基本指南，而不是你应该追求的最终目标，记住在你决定花费额外拾取之前要模拟你的角色和提升，因为我们的额外拾取数量有限。

3.2.

#### 晋升毒液石

正确使用你的 [[item:280562]] 与你使用纹章的方式非常相似，但有一个限制。所有专门从史诗剧毒深渊最后两个首领掉落的装备即使在正确的槽位上也无法升级。

1. 你的武器槽位是你的最高优先级，无论是双手武器还是你的主手，其次是副手。
2. 你的饰品槽位。
3. 你的项链槽位。

由于升级成本从上一赛季翻倍到现在需要10个剧毒石，你需要明智地选择升级什么以避免强迫自己去刷更多。一定要优先升级你的史诗轨道物品，而不是任何英雄轨道物品，除非是最终首领的团队副本战利品如 [[item:270168]]，如果你不期望很快获得史诗版本的话。

3.3.

#### 湮灭 唤魔师 最佳美化

美化是可以应用于制造装备的额外效果，可以作为基础效果或作为制作时的可选材料。根据所选的美化，这些可以显著提高制造物品的威力。

你同时只能激活两个美化。

这些是湮灭的最佳美化，比最接近的替代方案高出近0.5%的伤害输出。

你将使用的第一个美化是 [[item:273060]]，一个武器/副手制作，当它触发时会给你大量随机次要属性，这使它目前远远是最好的美化。第二个美化是 [[item:240167]]，一个护甲制作，会召唤一个法力飞龙，暂时增益你和一名盟友，提高你的主属性。在下面的部分中，我们将把制作选择分为两个特定类别：基于进度的，然后是你最终的最佳部件。

1.

### 湮灭 唤魔师 最佳进度制造物品

专业装备对于填补槽位和确保你使用正确的属性进行配装非常有用。湮灭 目前优先考虑暴击，然后是精通/急速，同时力求完全避免全能。此外，你可以在你的制造物品之间总共使用最多两个美化，这进一步增强了你的伤害输出！

本节重点介绍以最优化的顺序制作物品，以获得即时、高效且有效的威力提升。你在这里制作的一些物品最终不会成为你终局毕业装备清单的一部分，需要被替换。但我们仍然会制作它们，因为它们是从你的火花和迷雾纹章中获得伤害输出的极其有效的方式。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **湮灭 制造装备优先级**
- [[item:245770@JAAKAAgIvYTNbWiViUZM]] 搭配 [[item:273060]]。如果你获得史诗法杖则跳过此步骤。如果你获得史诗单手武器，那么制作制造法杖仍然是正确的选择，因为纹章效率更高。
- 升级等级最高的护甲槽位（最好不是套装）搭配 [[item:240167]]。
- [[item:244584@JAAKAAgIvYTNbWCYwYlI]] 搭配 [[item:240167]]，如果你仍在使用制造武器，则从你的武器上移除美化。
- 任何你尚未获得神话级的物品。

:::

:::details 常见问题：为什么先制作武器，即使它不是毕业装备？
武器是预算最高的部位，且随装等提升的收益极高，因此制作这件装备能在早期为你提供最大的DPS提升，同时徽记的使用效率也很高。你实际上花费80个迷雾徽记覆盖了相当于2个部位的战力提升，尽管你确实需要花费2次制作所需的火花才能达成。本赛季我们开局就有大量火花可用，因此花费这些火花的机会成本很低。

:::

:::details 常见问题：第二次制作除了使用带[[item:240167]]的[[item:244584@JAAKAAgIvYTNbWCYwYlI]]之外，还有其他选择吗？
你也可以选择制作手套/腰带/鞋子部位，因为这些部位的属性预算比护腕更高，让你花费徽记制作装备获得的整体价值更大。

:::

:::details 常见问题：为什么使用[[item:240167]]？
我们选择使用

[[item:240167]]

，因为算上给盟友提供的主属性，它目前是预算最高的美化。

:::

:::details 常见问题：有哪些部位要避免制作？
你应该尽量避免在套装部位制作装备，除非你已经拥有完整套装。装备完整套装比制作装备更强，否则你实际上会浪费一个火花！

:::

4.1.

#### 终局毕业制作装备推荐 湮灭 唤魔师

本节重点介绍将永久装备在角色身上的制作装备，因为它们是毕业装备。之后，你应该用剩余的火花获得尽可能高的DPS提升。这不是赛季初期给角色配装最有效的方式！

如果你想要优化徽记和火花效率的更好路线，请查看进度标签页。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **湮灭 制造装备优先级**
- 带[[item:273060]]的[[item:245769@JAAKAAwt1ENMMYzmlYlI]]。
- 带[[item:240167]]的[[item:244584@JAAKAAwt1ENMMYz_lYlI]]，任何你还没有达到神话级轨道的装备。

:::

:::details 常见问题：为什么制作手腕和披风而不是其他护甲部位？
我们制作手腕

[[item:244584]]

因为披风和手腕都是预算最低的部位，这意味着我们不会受到制作装备较低装等的显著影响，同时仍能获得美化带来的全部收益。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

这是湮灭最强的美化，比最接近的替代方案[[item:245876]]高出近0.5%的DPS，是毕业装备中的必备之选。

4.2.

#### 为装备添加插槽

头盔、腰带和护腕可以使用[[item:275707]]消耗品添加插槽，如果你在宏伟宝库中没有选择任何奖励就可以获得它。不选择奖励会获得代币，其中六个可以兑换[[item:275707]]物品，允许你为上述装备添加插槽，如果它是在第2赛季获得的。

1.

### 纹章使用

赛季初期，你获取徽记的机会将受到每周上限的严重限制。在此期间，你在花费
[秘境雾崖](<https://www.wowhead.com/currency=3446>) 和 [英雄迷雾徽记](<https://www.wowhead.com/currency=3445>)时要尽可能高效。你可以使用这些货币 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 提升到更高的装等。我们建议花时间考虑每次升级的最大收益以及你替换每件装备的可能性，然后再选择徽记的花费对象。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **湮灭 唤魔师 徽记升级优先级**
**武器（主手）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

这个优先级在绝大多数情况下都是正确的，但一如既往会有例外，对于带有特殊效果或触发的装备尤其如此。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 添加了Kithix团本掉落和升级列表。
- **2026年8月30日：** 调整了毕业装备列表。
- **2026年8月10日：** 添加了第2赛季列表。
- **2026年6月15日：** 将Rotmire物品添加到毕业装备列表。
- **2026年4月20日：** 调整了饰品部分和毕业装备列表。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 移除了部分章节，添加了至暗之夜赛季前的具体内容。
- **2026年2月10日：** 调整了装备部分，移除了上一层级部分。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 调整了S3毕业装备列表并添加了Dinar部分。
- **2025年8月4日：** 添加了S3毕业装备列表和Reshii部分。
- **2025年6月21日：** 调整了D.I.S.C部分。
- **2025年6月15日：** 添加了D.I.S.C部分/调整了毕业装备列表。
- **2025年4月30日：** 调整了Cartel Chip部分。
- **2025年4月21日：** 添加了新的Dinar部分。
- **2025 年 2 月 24 日：** 新增第2赛季BiS列表。
- **2024年12月21日：** 调整了关于赛尔西斯的措辞和宝石。
- **2024年12月15日：** 新增了11.0.7版本的赛尔西斯之冠信息。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 新增了团队副本和大秘境BiS列表。
- **2024年8月21日：** 新增了第1赛季开始前和第1赛季的毕业装备清单。
- **2024年7月23日：** 针对地心之战前夕进行了审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月24日：** 调整了饰品信息。
- **2024年4月22日：** 调整了套装信息以进行优化。
- **2024年4月15日：** 修正格式并补充了铸币列表。
- **2024年4月14日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月28日：** 新增了巨型地下城专属链接。
- **2023 年 11 月 12 日：** 调整了BiS列表。
- **2023 年 11 月 12 日：** 新增了护腿装饰信息，因为其价值不再随穿戴者数量递减。
- **2023年11月7日：** 新增了孢子披风削弱信息，并调整了其在装饰列表中的位置。
- **2023年11月6日：** 移除了错误的章节，调整了BiS列表/饰品/装饰。
- **2023年9月4日：** 为10.1.7新增了新布局。
- **2023年7月12日：** 新增了永恒黎明。
- **2023年7月12日：** 调整了饰品列表。
- **2023年7月10日：** 针对10.1.5补丁进行了审查。
- **2023年5月1日：** 已更新至第2赛季（装备、装饰、套装、饰品），并将黑曜石戒指章节移至页面底部。
- **2023年3月20日：** 新增了黑曜石戒指章节。
- **2023年2月3日：** 更新了关于卡纳莱克斯的文本，更明确地说明了该物品带来的精通收益。
- **2023年1月24日：** 更新了饰品列表，移除了暗月卡牌并新增了虚空治愈者的暗影宝石（根据10.5补丁的近期改动）。
- **2022年12月11日：** 已针对第1赛季更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的湮灭 唤魔师的最佳属性优先级。我们首先呈现属性优先级，然后深入解释属性如何与你的专精和玩法互动。我们的内容已针对《魔兽世界》12.1.5补丁更新。

1.

### 湮灭 唤魔师 属性优先级

湮灭 唤魔师的一般属性优先级为：

装备等级

暴击

急速

精通

全能

装等通常比拥有最佳次要属性更好，珠宝和饰品除外。

:::details 常见问题：湮灭 唤魔师有急速上限吗？
我们没有急速的硬上限，但急速直接关系到我们的

[[spell:375087]]

持续多长时间，因为你每次施放

[[spell:357208]]

或

[[spell:359073]]

持续时间就会延长。没有硬性断点保证额外延长，但更多的急速会让你在犯错时有更大的容错空间。

:::

需要注意的是，次要属性在30%之后每点价值会递减，这意味着需要更多的次要属性点数才能获得1%。这不是一个追求的目标，但当你开始超过这些阈值时要注意。在这些点上，你会看到每点次要属性的价值降低。一如既往，模拟你的角色会提供更详细的信息，告诉你在何时更换装备以获得不同的次要属性是明智的。

1.

### 深入属性解析

**智力** 是你的主属性。你应该在所有升级中寻找该属性。它为你提供法术强度，增加你法术的伤害。

**精通** ([[spell:362980]])根据目标当前的生命值提高你的法术伤害。目标生命值越高，你从[[spell:362980]]获得的收益就越大。在[[spell:375087]]期间，当你选择了[[spell:376888]]天赋时，你会自动获得[[spell:362980]]的全部收益。

**暴击** 提高你的技能造成200%伤害的几率。当你选择了[[spell:370845]]天赋时，这会提高到220%。

**急速** 提高你的施法速度（包括强化法术）和你的周期性效果的跳数频率。

**全能** 增加你造成的所有伤害和治疗，并减少你受到的所有伤害。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 为第2赛季调整了属性。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 对至暗之夜的属性优先级进行了小幅调整。
- **2026年2月10日：** 移除了过时的天赋。
- **2025年11月30日：** 添加了常见问题解答块。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对 11.1.0 补丁进行审阅。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 针对地心之战进行了审核。
- **2024年7月23日：** 针对地心之战前夕进行了审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023 年 11 月 12 日：** 调整了副属性列表。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月21日：** 更新了属性优先级，降低了暴击的价值。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 附魔与消耗品

在本页，我们列出了你的湮灭 唤魔师可以获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

湮灭 唤魔师的最佳属性是暴击和急速，所以我们将为此镶嵌宝石。

你应该在一个插槽中使用[[item:240967]]。然后，确保你在其他插槽中各有一颗每种类型的宝石以最大化暴击伤害效果，理想情况下是[[item:240906]]、[[item:240890]]、[[item:240898]]和[[item:240914]]。用[[item:240906]]填满剩余插槽。

1.

### 最佳附魔和武器强化

你应该始终使用[[item:243733]]。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:244007]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:243991]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240133]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</tr></table>

1.

### 最佳消耗品

合剂、食物、药水甚至油类等消耗品可以显著提升你的实力，值得在进行任何有挑战性的内容时使用。如果金币不是问题，你可以选择始终使用它们！

3.1.

#### 合剂

你应该根据你较低的属性使用这两种合剂之一。

- [[item:241325]] - 如果你需要更多急速
- [[item:241326]] - 如果你的暴击非常低

3.2.

#### 战斗药水

我们在至暗之夜中使用的战斗药水是[[item:241288]]或[[item:241292]]。鲁莽药水会提高你最高的次要属性同时降低你最低的，你的装备套装可以有0全能，这意味着你可以完全抵消这个药水的负面效果。狂野放纵提供大量智力，但会在你脚下随机生成使你平和的圆圈，这些圆圈生成后有1.5秒的宽限期，你可以在其中移动而不被沉默，这使得这个药水非常适合湮灭。不会发生。

3.3.

#### 食物增益

作为湮灭 唤魔师，你会想要使用你能获得的最佳主属性食物。目前，如果可用的话，这将是[[item:255845]]盛宴。如果盛宴不可用，或者放置了次要属性盛宴，那么你应该使用[[item:242275]]个人食物。

3.4.

#### 强化符文

如果你在推进过程中负担得起，你应该使用强化符文，尤其是在接近击杀时。它提供可观的智力提升。我们不建议一直使用，因为它们通常相当昂贵。使用当前最好的符文大约能带来1%的DPS提升。第2赛季有以下强化符文可用：

- [[item:259085]]

3.5.

#### 治疗药水

第2赛季带来了更强的治疗药水[[item:271883]]，你应该使用这个而不是较弱的版本。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已更新至第2赛季。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 添加了至暗之夜附魔/消耗品。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 移除了腐蚀并添加了新的生命药水。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 添加了腐蚀部分和头盔附魔。
- **2025 年 2 月 24 日：** 已针对 11.1.0 补丁进行审阅。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 针对地心之战进行了审核和调整。
- **2024年7月23日：** 针对地心之战前夕进行了审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 移除了已更改的药水和附魔措辞。
- **2024年4月14日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月17日：** 针对药水和飘渺虔诚进行了调整。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2新增了炽燃头盔附魔。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 新增了腰带附魔（10.1补丁新增）。
- **2023年3月25日：** 更新了原始宝石推荐。
- **2023年3月20日：** 新增了黑曜石戒指宝石章节。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的湮灭 唤魔师挑战大秘境地下城的提示和建议。

1.

### 湮灭 唤魔师在至暗之夜第2赛季的大秘境中

在本指南中，我们将讨论如何在大秘境地下城中充分发挥你的唤魔师的潜力，包括设置角色的最佳方式、你的输出循环可能如何变化，以及最优化使用技能的提示和技巧。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

1.

### 最佳大秘境天赋配置

由于当前 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长在DPS的所有方面都遥遥领先，强烈建议你在任何等级的秘钥中避免使用塑焰者。鳞长的单体/顺劈输出明显更好，只在目标数量极高的情况下才会落后。

### 大秘境天赋配置—— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) 鳞长

这个天赋树将作为所有秘钥的最佳构建，因为它几乎没有牺牲单体DPS，而是以[[spell:375757]]的形式获得了非常可观的顺劈和AOE提升。如果你想追求高AOE伤害构建，你可以从[[spell:371038]]中取出两点，将两点都放入[[spell:369089]]，或放入一点到[[spell:370455]]，充能爆破比不稳定略好，但需要你积极围绕它进行操作以最大化其价值。

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGzMgBjZamZmpZmx2MMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscRRFLLbZYYluqqPkkoXpjWEfenrVmCHA-jNiMhDgCCfUJJeeVTR6ie4w2gA0cKzA-AAAA-TIQaAUGYEE84iB-
```

:::

### 大秘境天赋配置—— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者

这个天赋树可用于塑焰者的每周秘钥。它可以在与鳞长相似的水平上进行游戏，但由于天赋点花费的灵活性差得多，整体上较弱。如果你想专注于单体，这将花费相当可观的AOE，反之亦然。因此，我们只在你真正喜欢塑焰者的玩法时才推荐使用这个。

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAz8ADmZMzwMwMYMTjZmJjxyMzMzwYmZGwMmZGzMLzMDmBmxMwCYDMDTgNwywAYmZYA"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscRRFLLbZKYYluqqPkkoXpjWegEfnrhmA-jNiMDhLLgBCfUJJVTQ6iewOuA0ILzsA-AAAA-Iqkk5wQoBoYwSA-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和阻止

3.1.

#### 打断

[[spell:351338]]是你的"打断"，也是你在大秘境中最重要的实用技能。用来打断敌人的施法以造福团队，尤其是坦克。它是 **强烈推荐** 使用焦点打断宏来完成此操作。

#### 静默宏

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 镇压
```

这个宏将会：

- 打断你的焦点目标，如果你有的话
- 打断鼠标悬停目标，如果你没有焦点目标
- 如果你两者都没有，根据暴风雪的默认目标选择来打断目标

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**.

#### 焦点 鼠标指向

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你焦点目标的施法。这样，你总是能够在冷却完毕时打断，或与团队其他成员协调打断。

3.2.

#### 眩晕与“停手”

湮灭有三个主要的AOE打断技能。

[[spell:357210]]在天赋点出[[spell:371032]]时是一个冷却时间很短的3秒昏迷。我们不会留着它作为打断使用，因为它是核心DPS循环的一部分。然而，它提供了大量免费的控制。

[[spell:357214]]会将你面前的敌人击退，打断法术并重新定位怪物。

[[spell:307974]]会将你周围的敌人击向空中并稍微远离你。这对于打断一组施法很有用。

### 其他功能

3.3.

#### 其他功能

[[spell:370665]]可以帮助你重新定位——以及盟友——同时在天赋点出[[spell:370888]]时，为你和你的营救目标提供短时间的移动施法增益。

[[spell:374968]]让你的整个队伍额外使用一次他们的位移技能，我们的是[[spell:358267]]，当你需要快速穿过区域时这会非常有帮助。

1.

### 应对词缀

至暗之夜的第2赛季只有四个重要的词缀提供任何反制手段：萨拉塔斯的交易。这些每周轮换，同一时间只有一个生效。许多大秘境词缀，如残暴或强韧，只是给钥石添加一个被动效果，除了这四个以萨拉塔斯为主题的季节性例外：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：会生成三波球体，需要打断或驱散。[[spell:357214]]和[[spell:307974]]在这里效果很好。[[spell:357210]]在作为DPS循环的一部分使用时也会自然获得一些。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：会生成一个虚空大使小怪，需要集火并打断。如果你知道这会发生，确保积攒精华以准备爆发它。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：球体会在玩家周围生成并绕着他们转。你有15秒时间吸收所有这些以给你的团队增益。[[spell:360995]]会立即将你传送到盟友身边，让你立即吸收他们的球。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有队伍成员都会受到治疗吸收效果的影响。你可以用[[spell:365585]]和[[spell:374251]]移除它。

解决后，每个词缀都会为你的团队提供一个增益。正确处理它们会加快你的地下城进度，并防止敌方小怪和首领获得增益。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 添加了新的第2赛季天赋树。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 添加了新的天赋树。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月30日：** 在相关地下城中添加了Boss专属提示。
- **2025年4月21日：** 为高层大秘境调整了构建。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 为大秘境新增了更多信息。
- **2024年9月9日：** 新增了地心之战第1赛季章节。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 更新了10.1.5补丁的天赋树。
- **2023年5月1日：** 为10.1补丁更新了天赋树，为第2赛季更新了词缀信息。
- **2023年3月30日：** 天赋修复。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月12日：** 更新了大秘境词缀和功能列表的提示。
- **2022年12月11日：** 更新了大秘境天赋树。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 宏与插件

在本页，你将找到许多有用的宏和插件，让你在《魔兽世界》12.1.5补丁中玩你的湮灭 唤魔师时更加轻松。

1.

### 最佳宏

1.1.

#### 翡翠之花鼠标悬停

这个宏会对你的鼠标悬停目标施放[[spell:355913]]；如果他们不是友方目标（或已死亡的友方目标），它会改为对自己施放。

#### 翡翠之花鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 翡翠之花
```

1.2.

#### 营救鼠标悬停

这个宏会对你的鼠标悬停目标施放[[spell:370665]]；如果他们不是友方目标（或已死亡的友方目标），它会尝试改为对你的当前目标施放。

#### 营救鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 营救
```

1.3.

#### 青翠之拥鼠标悬停

这个宏会对你的鼠标悬停目标施放[[spell:360995]]；如果他们不是友方目标（或已死亡的友方目标），它会改为对自己施放。

#### 青翠之拥鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 青翠之拥
```

1.4.

#### 灼烧之焰鼠标悬停

这个宏会对你的鼠标悬停目标施放[[spell:374251]]；如果他们不是友方目标（或已死亡的友方目标），它会改为对自己施放。

#### 灼烧之焰鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 灼烧之焰
```

1.

### 湮灭唤魔师专属宏

2.1.

#### 配合饰品使用 火焰吐息与 变换

此宏在你按下时会正常释放 火焰吐息，但如果你按住Shift，它会先使用你的第一个饰品栏位（栏位13，第二个饰品栏位改为14），然后在同一个公共冷却内释放 火焰吐息。

#### 配合饰品使用 火焰吐息与 变换

```wow-macro
#showtooltip 火焰吐息
/use [mod:shift] 13
/cast 火焰吐息
```

1.

### 最佳插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

3.1.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

3.2.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

3.2.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

3.2.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

3.2.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

3.3.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

3.3.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

3.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

3.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对 11.1.0 补丁进行审阅。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 针对地心之战前夕进行了审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 针对10.1.5补丁进行了审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::
