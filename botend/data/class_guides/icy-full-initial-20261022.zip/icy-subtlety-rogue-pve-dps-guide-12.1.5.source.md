## 专精概览

Welcome to our Subtlety Rogue guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Subtlety Rogue in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Subtlety Mythic+ Resources

[NEW! Top Subtlety Talent Builds](<https://raider.io/specs/subtlety-rogue/talents>)

[Top Subtlety Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/rogue/subtlety>)

[Subtlety Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=rogue--subtlety>)

[Popular Subtlety Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=rogue--subtlety>)

1.

### Subtlety Rogue Overview

Subtlety Rogue is all about combining as many buffs and effects as
possible into a short but hectic burst window. After that burst window is over
the pacing slows down until the next window.

Defensively, Subtlety is immensely powerful and can survive mechanics other
classes struggle with. While at the same time, they can control enemies to
limit the amount of damage the group or tank takes in a Mythic+ environment.

Powerful Bursts and Solid All-Rounder

The damage profile Subtlety Rogue possesses is incredibly powerful. It houses burst on a 90 second
cooldown in both AoE and single-target situations alongside strong short cooldowns. However in between
those powerful cooldowns the damage is rather lackluster, and when dealing with specifically 2 or 3
targets it struggles to keep up with the rest of the pack.

Prime Pick to Burst Raids Down

Subtlety Rogue is a great choice for any raid environment, due to its potent
cooldown burst and its incredible survivability. It is one of the best
specs to put on bursting down a set of adds or a specific damage phase of a
boss, such as a shield needing to be broken by damage, due to the big on-demand-burst
the spec offers.

Rogue's unique raid buff/debuff, [[spell:381637]], is very
useful for reducing the overall damage taken throughout the fight.

Snipes and Stealth, What Else?

Subtlety boasts solid DPS in all scenarios of Mythic+, as their burst damage can
quickly neutralize dangerous packs and/or mobs often before they get the chance
to do their mechanic. Or, at the very least, before they get to cast it a second time.

Rogue in general has a kit that excels at controlling or locking down a
enemies in dungeons, with abilities like [[spell:6770]], [[spell:2094]], and
[[spell:408]]. It is also one of the two classes in the game that has
access to a group stealth ability in [[spell:114018]], which also
happen to massively increase movement speed thanks to [[spell:382507]].

Not Exactly the Worst Handyman Around

Subtlety has access to many different utility spells, like [[spell:381637]],
[[spell:5761]], [[spell:114018]], or [[spell:6770]]. While few of these
find consistent applications in raid environments, a Rogue who knows how to use all the
tricks of their trade can help make any Mythic+ run feel a lot easier and safer.

The unique raid buff/debuff may not always apply to all enemy mechanics, but a damage
reduction that applies to the entire raid is incredibly helpful.

Last Rogue Standing

Rogues are the kings of staying alive, and Subtlety even has an upper hand on the
other rogue specs. Thanks to [[spell:31230]], [[spell:1966]], [[spell:31224]]
as well as Subtlety specific defensive talents like [[spell:382514]] and [[spell:428486]]
you will generally be one of the last few people standing, allowing you to clutch
out boss or trash kills even when things go awry.

Having [[spell:5277]] ready when a tank dies and you can safely tank a
trash pack for another 10 seconds can save runs, and while Rogue tends to
struggle with high sustained damage over time, you have numerous tools at your
disposal to stay alive until the very end.

Now You See Me, Now You Don't

Subtlety has solid mobility, having access to a low-cooldown [[spell:2983]]
that makes you run faster than a mounted character, as well as being able to use
[[spell:36554]] to quickly get out of harms way, or connect with an enemy that is
far away from you.

It is also possible to jump to friendly targets allowing flexibility
in how you move around the battlefield to avoid dangerous attacks. The main drawback of
Rogue's mobility is when you have to run somewhere alone with no targets to use
[[spell:36554]] on.

2.

### Subtlety Rogue in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 offers a few notable bugfixes for Subtlety Rogue, but the
main focus of the patch are two new pieces of endgame content; one for Raid groups, and one
for [Delves](<https://www.icy-veins.com/wow/delves-guide>). Make sure to check out both the information on the new Kith'ix Raid encounter,
as well as the new exciting Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

You can now upgrade your items through the new [[item:280562]] which 
gives you additional item levels on your trinket, weapons and necklaces! For Subtlety Rogue
the new trinket [[item:281215]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) is exceptionally strong 
in AoE situations, but fairly lackluster in single-target.

2.3.

#### Class Changes

There are very few class changes for Subtlety Rogue coming into patch 12.1.5, the main changes come in the form of 
    some seemingly small bugfixes. They have a large numerical impact on the spec but it does not look like anything
    changes for talents or in terms of gameplay.

- [[spell:382017]] and [[spell:382504]] no longer apply their effects twice to everything.
- [[spell:382524]], [[spell:121471]] and [[spell:426591]] no longer benefit from any shadow damage amplification
              talents if the initial hit was a shadow damage spell.
- [[spell:426591]] now correctly echos [[spell:280719]] damage.

Not launching alongside patch 12.1.5 but merely a week before, there was a tuning
    pass that buffed ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster, turning it into a viable hero talent for AoE
    scenarios. However, for most raid encounters, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker is still
    looking to be the best choice, as well as in high Mythic+ keys where you will likely
    still see ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker reign supreme due to the increased priority-target
    damage it brings compared to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_shadowdance.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class TuningHide Patch 12.1 Class Tuning
[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Subtlety Rogue**

<em>Developers' notes: We've made some updates to Subtlety's resource economy in Curses of Ula'tek, 
        including the removal of a double-generation bug that made the desired intent and combat feel unclear. 
        Base effect rate and Energy generation of Shadow Techniques are being increased to make moments outside 
        of Shadow Dance feel less starved, while preserving the same proc rate and combo point generation within 
        Shadow Dance. Energy generation should still grow during cooldowns, but not nearly as drastically as before.</em>

- **Class**
  
  
  - [[spell:381623]] is now a choice talent – Players may now choose between the
            existing version, which casts automatically at low Energy in addition to being
            usable actively, and a new version that must be cast actively.
  - Atrophic Poison now reduces damage dealt by 4% (was 3%).
  - Atrophic Poison duration increased to 60 seconds (was 10 seconds).
            Duration remains unchanged in PvP combat.

- **Subtlety**
  
  
  - Goremaw’s Bite has been redesigned – Lash out at your target and 2 additional nearby enemies, 
            inflicting Shadow damage and causing them to Bleed over 14 seconds. 20% of all damage from 
            Finishing Moves is repeated as Shadow, split evenly among affected enemies.
  - Shadowcraft has been updated - While Shadow Dance is active, your Shadow Techniques triggers 
            25% more frequently and generates 1 additional combo point.
  - All damage dealt increased by 2%. This does not apply to PvP combat.
  - The First Dance now increases Shadow Dance duration by 4 seconds (was 3 seconds).
  - Relentless Strikes now generates 4 Energy per combo point spent on finishing moves (was 5 Energy).
  - Shadow Techniques' base effect frequency has been increased by 40%.
  - Shadow Techniques' Energy generation has been increased to 5 (was 4).
  - Lingering Shadow now also applies to Shuriken Storm.
  - Shadow Dance's tooltip has been updated to include its threat reduction effect.
  - Apex Talent: Ancient Arts now considers the total damage of Secret Technique when creating a shadow clone, instead of only its initial hit.
  - Fixed an issue that caused Secret Technique damage from secondary hits to be attributed to summoned pets instead of the attacking Rogue.
  - Some talents have changed positions in the talent tree.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Summary for Subtlety Rogue

Due to the enormous amount of changes, they have been broken up into sections to
make it easier to digest how Subtlety Rogue is different this expansion. Note that in
addition to these changes, there were also many changes to overall tuning of
spells. Most of these changes are intended to make the specialization more intuitive
and less confusing, while maintaining the burst centric [[spell:185313]] focused
gameplay the spec is known for.

- Here are the most impactful changes to the baseline **Subtlety Rogue** spells.  
  
  
   ► **Click to expand**
  
  
  - Thematically Subtlety now has more of a focus on shadow clones.
  - Flagellation has been removed.
  - Symbols of Death has been removed.
  - Rupture has been removed.
  - The cooldown reduction per combo point spent on [[spell:185313]] and [[spell:280719]] has been removed.
  - [[spell:121471]] now doubles combo points generated rather than always filling them to full.
  - The combo point refund part of [[spell:426594]] has been partially moved over to the 4th Apex talent.
  - Several new/reworked talents like [[spell:185314]] and [[spell:381988]] make Haste a more desirable stat.
- The **Hero Talents** have had some minor updates.  
  
  
   ► **Click to expand**
  
  
  2.5. 
  
  ### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster
  
  
    
  
  
  
  - [[spell:441367]] no longer cleaves [[spell:196819]] or [[spell:185438]].
  - [[spell:1276679]] allows [[spell:197835]] to proc [[spell:441146]].
  - [[spell:441321]] is stronger but now caps out at 5 stacks.
  
  
  
  
  2.6. 
  
  ### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker
  
  
    
  
  
  
  - [[spell:457052]] can now only be moved while the [[spell:457058]] buff is active.
  - [[spell:457058]] can now be triggered by [[spell:196819]]s at 5 or more combo points instead of at exactly 7.
  - [[spell:1272989]] makes Critical Strike a good stat when it previously was not for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker.
- Additionally there has been a couple of changes to our **Utility Spells**.  
  
  
   ► **Click to expand**
  
  
  - [[spell:1267182]] makes [[spell:5938]] longer range and cheaper to use whenever a de-enrage is required.
  - While most other specializations have lost defensive talents or spells Subtlety did not and also gained a new
                  one with [[spell:1267220]].

These changes massively simplify the specialization, allowing for new and returning player to enjoy it without needing to
        extensively study a guide like this, which was nearly required in the previous iteration. Its still centered around 
        casting [[spell:185313]] and doing big bursts, but a lot of extra bloated buttons and passives were culled.

2.7.

#### Apex Talents for Subtlety Rogue: Ancient Arts

As we journey and level throughout Midnight, we will gain access to
    our new Apex Talents: [[spell:1268932]], [[spell:1268936]], and
    [[spell:1268939]]. At first glance, or if you are new to Subtlety Rogue,
    the tooltips might look confusing. But in practice, they are very straightforward.

- [[spell:1268932]] makes it so our combo point generators
          sometimes spawn a clone that deal extra shadow damage
- [[spell:1268936]] adds passive shadow damage and generates
          additional [[spell:196912]] stacks whenever a clone appears
- [[spell:1268939]] adds a buff that triggers if you ever
          end up with 5 or more [[spell:196912]] **after** casting a combo point generating ability
          
  
  - The buff adds a shadowy glow near the middle of the screen,
                and makes your next finisher do more damage via a clone, as well as
                refund combo points.

A more in-depth explanation and how the new Apex Talent impacts the
    rotation can be found on the rotation page:

[Subtlety Rogue Rotation and Cooldowns](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)

3.

### Basics of Subtlety Rogue Gameplay

Subtlety Rogue is a spec that deals with multiple different resources and several
different cooldowns. The core concept of the specialization is to stack as many effects and buffs
as possible to deal massive burst damage in a short timeframe.

The bare basics of Subtlety can be described using the following three concepts.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_eviscerate.jpg>) **Manage your Combo Points**  
  
      Subtlety is all about Combo Point spender abilities like [[spell:196819]], these 
      deal more damage the more Combo Points you have, so you want to use them while at the
      maximum of 7 Combo Points and not generating more until you have casted a spender.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_findweakness.jpg>) **Plan Ahead**  
   
      The main Subtlety cooldown [[spell:185313]], while strong by itself really
      amplify all of the other cooldowns, so do not cast it immediately when it is ready,
      patience is key.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_shadowdance.jpg>) **Combine Cooldowns**  
  
      When cooldowns like [[spell:280719]], [[spell:426591]] or [[spell:121471]]
      become available combine them with your previously stored [[spell:185313]] charges for
      massive bursts!

4.

### How to Gear Up as a Subtlety Rogue

While we always recommend simming yourself for ideal results, we do provide a
dedicated Subtlety gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **23 May 2026 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated talent build descriptions.
- **03 May 2026 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for May 5th Tuning.
- **03 May 2026 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for May 5th Tuning.
- **03 May 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for May 5th Tuning.
- **03 May 2026 (this page):** Updated for May 5th Tuning.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **23 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for Midnight Mythic Release.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Midnight Mythic Release.
- **23 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Midnight Mythic Release.
- **23 Mar. 2026 (this page):** Reviewed for Midnight Mythic Release.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Midnight Season 1
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for Midnight Season 1
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Midnight Season 1
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight Season 1
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Midnight Season 1
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Midnight Season 1
- **16 Mar. 2026 (this page):** Reviewed for Midnight Season 1
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Midnight.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for Midnight.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Midnight.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Midnight.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Midnight.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Midnight.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Midnight.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Midnight.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Midnight.
- **26 Feb. 2026 (this page):** Reviewed for Midnight.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Midnight.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Updated for Midnight.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Midnight.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for Midnight.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Updated for Midnight.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 (this page):** Updated for Midnight.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated for Midnight.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Midnight.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Midnight.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Midnight.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **06 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated to be written with Tier-Set in mind.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Updated for Patch 11.1
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Patch 11.1
- **24 Feb. 2025 (this page):** Updated for Patch 11.1
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **23 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.5.
- **23 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.5.
- **23 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Patch 11.0.5.
- **23 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **22 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for The War Within.
- **22 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **22 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Updated for The War Within.
- **22 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **22 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for The War Within.
- **22 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **22 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **22 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for The War Within.
- **22 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for The War Within.
- **22 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/subtlety-rogue-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed and Updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed and Updated for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed and Updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed and Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed and Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Reviewed and Updated for The War Within pre-patch.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/subtlety-rogue-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for Season 4
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Season 4
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Season 4
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Season 4
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Season 4
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 4
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Season 4
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Season 4
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Season 4
- **22 Apr. 2024 (this page):** Reviewed for Season 4
- **20 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **24 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed and Updated.
- **24 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated to add Shadowdust Talent Builds.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed and Updated after Sporecloak Nerf.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed and Updated for patch 10.2.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Reviewed and Updated for patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed and Updated for patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed and Updated for patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and Updated for patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed and Updated for patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed and Updated for patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed and Updated for patch 10.2.
- **06 Nov. 2023 (this page):** Reviewed and Updated for patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Added BiS item tables and reformatted page.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reformated talent tables and descriptions.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Page updated and reviewed for Patch 10.1.7.
- **25 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Added slider for leveling rotation.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Page updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Page updated for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Page updated for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Page updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Small recommended talent updates.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Page updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Page updated for Patch 10.1.5.
- **11 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Changed recommended talent to Flagellation over Dark Brew.
- **11 May 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Changed recommended talent to Flagellation over Dark Brew.
- **11 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Changed recommended talent to Flagellation over Dark Brew.
- **09 May 2023 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Added notes about how to spend sparks in Season 2 along with few other updates.
- **09 May 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Added the new talent build with Aberrus tier set.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Page updated for Patch 10.1 and added notes about Eranog ring and Onyx Annulet.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Page reviewed and updated for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Page reviewed and updated for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Page reviewed and updated for Patch 10.1.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page reviewed and updated for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Page reviewed and updated for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Page reviewed and updated for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Page reviewed and updated for Patch 10.1.
- **01 May 2023 (this page):** Page reviewed and updated for Patch 10.1.
- **29 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Page reviewed and updated for Patch 10.1.
- **06 Apr. 2023 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated recommended Primordial gems.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/subtlety-rogue-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Page updated and reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Page reviewed and updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Reviewed for Patch 10.0.7.
- **14 Feb. 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated recommended single-target talent build.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Page updated for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Changed Shadowstep macro conditionals and reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Changed a few recommended enchants and Phial recommendation and reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated stat recommendations and reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated talents and reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page updated and reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Page updated and reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Page updated for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Page updated and reviewed for Patch 10.0.5.
- **13 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Added recommended Embellishments.
- **17 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Small updates to ability priority list.
- **17 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Fixed import string for single-target spec.
- **17 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Added multi-target ability priority list and updated single-target.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Vault of the Incarnates launch.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Small changes to weapon enchants.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Small update to recommended single-target stats.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated talent recommendations.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Added mention of Cold Blood usage.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated recommended talents.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **31 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/subtlety-rogue-best-legendaries-shadowlands>)):** Added Invigorating Shadowdust as recommended Legendary for Venthyr.
- **31 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/subtlety-rogue-best-covenants-soulbinds-and-conduits>)):** Changed recommended raiding Covenant to Venthyr.
- **31 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-castle-nathria-raid-guide>)):** Changed recommended build to Venthyr along with Invigorating Shadowdust.
- **31 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-sanctum-of-domination-raid-guide>)):** Changed recommended build to Venthyr along with Invigorating Shadowdust.
- **31 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Changed recommended build to Venthyr along with Invigorating Shadowdust.
- **31 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page updated with Venthyr build opener.
- **31 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Changed recommended Raiding talent build and added comments on possible talent choices on certain rows.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/subtlety-rogue-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/subtlety-rogue-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/subtlety-rogue-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/subtlety-rogue-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **02 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/subtlety-rogue-patch-9-1-changes-analysis>)):** Page updated for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/subtlety-rogue-patch-9-1-changes-analysis>)):** Page updated for Patch 9.1's release.
- **17 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/subtlety-rogue-patch-9-1-changes-analysis>)):** Page Created.
- **22 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-ny-alotha-raid-guide>)):** Updated Major Essence recommendation for N'Zoth.
- **14 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-ny-alotha-raid-guide>)):** Page updated with new Essence recommendations for bosses.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **10 Sep. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-the-eternal-palace-raid-guide>)):** Page updated with some tips and talent choices.
- **12 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-the-eternal-palace-raid-guide>)):** Added tips to most of the bosses.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Crucible of Storms and no changes are necessary.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Crucible of Storms and no changes are necessary.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** Updated for Patch 8.1.
- **25 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** Added talent recommendations for Mythic.
- **10 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** Small updates because of changes made to the bosses.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** Changed formatting on the page.
- **31 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** Page updated with short description of bosses and recommended Talents.
- **11 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** Page added (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Subtlety Rogue leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Rogue leveling guide](<https://www.icy-veins.com/wow/rogue-leveling-guide>).

1.

### Subtlety Rogue Leveling Guide for Midnight

Unfortunately, Rogue has often been cited as the single worst class to level
in World of Warcraft. Fret not, however, as it is still more than capable of
dealing with the leveling journey just fine, even if it will take you a
little longer than your friends who may have chosen a different class than you.
Once you hit max-level, you will surpass them in no time and be thankful you
spent the time to pick Rogue!

Unfortunately, Rogue has often been cited as the single worst class to level
in World of Warcraft. However, they are still more than capable of handling the
leveling journey by themselves, even if it might not be the fastest class.

One of the biggest strengths of Rogue during leveling is its ability to simply
sneak past many nuisances. With clever use of [[spell:2094]], [[spell:1856]],
[[spell:6770]] and other CC abilities, you can often loot important quest items
and then simply Vanish to disappear without having to kill a single enemy.

[[spell:1231418]] is a channeled heal you can use on yourself
outside of combat that was recently added, it comes in very handy while
leveling if you end up at low health with [[spell:185311]] on cooldown. 
Whenever your [[spell:5277]] is ready you can pull as many mobs as possible
and try to AoE them down as you will be dodging all of their attacks and simply
take no damage!

For the most part your damage outside of [[spell:185313]] is very mediocre,
so try to make the most out of the windows where you have it active.

1.1.

#### Leveling Gear Options

The general rule, even at max level, is always equip the higher item level
piece. The exception to this is that you need a dagger in your mainhand. Rings, Necklaces, and <em>certain</em>
trinkets can also be exceptions as there is no primary stat on rings and necklaces, and certain
trinket effects overpower the gain you get from more primary stat. While
leveling, it is almost always better to just default to equipping the highest
item level pieces you have access to. Heirloom gear is also useful while leveling, allowing you to ignore a lot
of gearing for a large part of your leveling journey.

1.2.

#### Useful Leveling Consumables in Midnight

Here are some examples of consumables that can dramatically improve leveling flow by 
noticeably increase mobility or damage.

- [[item:109076]]
- [[item:132516]] or [[item:212268]] (Requires Level 71)
- [[item:168412]]
- [[item:219905]] (Requires Level 75, but other "Drums" from previous expansions will work at lower levels)
- [[item:225592]] (Requires Level 75)

2.

### Leveling Talents

If you a returning player just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), you can find a Level 80
import string right below. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Subtlety Level 80 Midnight Leveling
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMYwMzMzYMbzMzM2mZmxDMzYAzsMAAAAMYMgxwwADYhFiNMDYmBzA"
}
```
:::

**等级 10 起：**

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTmZbZMmZMwMzMzYMbzwYbbmZmZmZAjZWGAAAAGMGwY2MMwAzCL0iNMDYmBzYYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FhpLPNMdcSNCpIDdFQ6DkXkTMsLihBhWWVc-AYjDEXM9qY9dWdBmVQwhxABhkqrbbaC-AAAA-BIOgQRzQhBTgwF-
```

:::

2.1.

#### War Mode Talents for Leveling

In this section, we will rank the PvP talents best for
leveling and doing solo / small group PvE content. Below is a ranking of Subtlety
Rogue-specific PvE talents.

1. [[spell:197000]] Sprint has 50% reduced cooldown and 50% reduced duration.
2. [[spell:198675]] — Whenever Stealth is active, you apply a debuff to
   nearby enemies that causes them to take an additional 5% damage from your next
   Shadowstrike. Stacks up to 8 times. This is nothing special, but still a slight
   damage boost.
3. [[spell:269513]] — Finishing move that leaps you up in the air
   and casts an [[spell:196819]] that deals 10% more damage.
4. The third choice does not matter much as none of them provide benefits for
   PvE situations. Use any of them that you feel suitable.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 3 起：**Cast [[spell:1784]] if you want to get to a
quest objective without fighting all enemies or before engaging enemies.

**等级 1–1：**Prior to level 10, the only damage dealing abilities you have access to are: [[spell:1752]], [[spell:196819]] at level 2, and [[spell:8676]] at level 7.

1. Cast [[spell:196819]] once you have 5+ Combo Points to spend them.
2. Use [[spell:1752]] to build up Combo Points.

1. **等级 10 起：**Make sure you always have 
   [[spell:315584]] buff applied.
2. **等级 11 起：**Make sure you always have
   [[spell:3408]] buff applied.
3. **等级 13 起：**Use [[spell:121471]] either on cooldown or
   save it for elite enemies.
4. **等级 37 起：**Use [[spell:426591]] as often as possible.
5. **等级 9–17：**Use 4+ Combo Points to keep up
   [[spell:315496]] at all times. After you unlock [[spell:51667]] at lvl 18
   you never need manually cast it.
6. **等级 22 起：**Cast [[spell:185313]] as a DPS cooldown as often
   as possible.
7. **等级 25 起：**Cast [[spell:280719]] to spend your Combo
   Points on cooldown. Ideally while [[spell:185313]] is active.
8. **等级 12 起：**Cast [[spell:196819]] to spend your Combo
   Points when fighting a single enemy.
9. **等级 74 起：**Cast [[spell:196819]] to spend your Combo
   Points while you have [[spell:441423]] active regardless of how many enemies you are fighting.
10. **等级 14 起：**Cast [[spell:319175]] to spend your Combo
    Points when fighting 2 or more enemies.
11. **等级 12 起：**Cast [[spell:53]] to generate Combo Points when fighting a single enemy. If you are in [[spell:1784]]
    or have [[spell:185313]] active use [[spell:185438]] instead.
12. **等级 11 起：**Cast [[spell:197835]] to generate Combo
    Points when fighting 2+ enemies.

3.1.

#### Utility Spells

Subtlety Rogues have a ton of tools available to them that makes fighting
multiple enemies at once easier, or just simply getting away from a sticky
situation.

- [[spell:1766]] allows you to interrupt an enemy
  that is casting a spell. Use this whenever possible to interrupt enemies to
  take less damage while leveling.
- [[spell:185311]] lets you heal 20% of your
  max Health over 4 seconds. Use this is if your Health is dropping low or between
  mob pulls.
- [[spell:6770]] lets you control any Humanoid,
  Beast, Demon, or Dragon for up to 60 seconds. Use this to keep a single enemy
  from joining the fight before you open on a group of enemies from Stealth. This
  crowd control breaks when the enemy takes damage. To avoid breaking your Sap,
  either lure the other enemies away or do not use any AoE spells.
- [[spell:408]] can be used to stun a single
  opponent for up to 8 seconds. Use this to interrupt a dangerous cast or to simply
  not take damage from an enemy. Some NPCs might be immune to stuns.
- [[spell:5277]] increases your chance to
  dodge incoming melee and ranged attacks by 100% for 10 seconds. Use this to
  your advantage by doing larger pulls whenever Evasion is ready. Note that you
  can only dodge if you are facing the enemy.
- [[spell:1856]] removes you from sight. This resets
  combat with everything that you were currently fighting, making it a strong
  cooldown when leveling. Whether it is just to escape certain death or to get rid
  of pesky enemies that you do not want to deal with, make sure to use Vanish
  to your advantage.
- [[spell:2094]] allows you to control an enemy
  for up to 60 seconds. This can be used from Stealth or outside of it. The crowd-
  control breaks when you deal damage like Sap does, so make sure to lure enemies
  away or avoid using area-of-effect abilities.
- [[spell:31224]] removes and makes you
  immune to magical effects for 5 seconds. This allows you to potentially remove
  damage over time effects that could break your [[spell:1784]], allow you to
  take less damage, or simply avoid certain crowd control or damaging effects.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1
- **26 Feb. 2026:** Reviewed for Midnight.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **22 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **24 Nov. 2023:** Reviewed and Updated.
- **06 Nov. 2023:** Reviewed and Updated for patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **25 Jul. 2023:** Added slider for leveling rotation.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Subtlety Rogue in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Subtlety Rogue

This section is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

Subtlety, when you boil it down, is about building combo points 
and spending them to deal damage. Most of the complexity lies in
using the plethora of cooldowns available as effectively as possible,
which might not always be pressing them the moment they come of cooldown.
Here are some quick rules to follow when starting and learning the basics:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_eviscerate.jpg>) **Manage your Combo Points**  
  
      Subtlety is all about Combo Point spender abilities like [[spell:196819]], these 
      deal more damage the more Combo Points you have, so you want to use them while at the
      maximum of 7 Combo Points and not generating more until you have casted a spender.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_findweakness.jpg>) **Plan Ahead**  
   
      The main Subtlety cooldown [[spell:185313]], while strong by itself really
      amplify all of the other cooldowns, so do not cast it immediately when it is ready,
      patience is key.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_shadowdance.jpg>) **Combine Cooldowns**  
  
      When cooldowns like [[spell:280719]], [[spell:426591]] or [[spell:121471]]
      become available combine them with your previously stored [[spell:185313]] charges for
      massive bursts!

2.

### Beginner's Guide to Subtlety Rogue in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster   Single-Target Talents

2.1.

#### Single-Target Talents

You can easily import the talent tree below into the game by clicking 'Export Talents'.

:::talents Raid / Single Target - Trickster
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMjZgZmZGzMbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzGL0mNMDYmBzYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMjZgZmZGzMbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzGL0mNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBWg5hirrTk0ABZD-AAAA-BIOiQZzQhBTgwF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster   Multi-Target Talents

2.2.

#### Multi-Target (Mythic+/Delve) Talents

You can import the talent tree below into the game by clicking 'Export Talents'.

:::talents Raid / Mythic+ / AoE - Trickster
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-BIOgQRzQhBTgwF-
```

:::

### Subtlety Rogue   Basic Rotation

2.3.

#### Beginner Subtlety Rogue DPS Rotation

Before entering combat, always remember to apply the following effects.

- **Apply Poisons, enter Stealth and Tricks**  
  
    Apply [[spell:315584]] and [[spell:381637]].  
  
    Cast [[spell:1784]].  
  
    Cast [[spell:57934]] on your Tank right before you engage.

2.4.

#### Single Target Rotation

Subtlety is all about generating and spending combo points effectively while
    combining all of its various cooldowns together for big burst windows.

- **Spenders**  
  
  [[spell:280719]] or [[spell:196819]] should be used when you have **7** combo points
- **Generators**  
  
  Whenever you do not have 7 combo points, you should be casting [[spell:185438]] if
  you are inside [[spell:185313]], and otherwise [[spell:53]].
- **Utilizing your Cooldowns**  
  
  [[spell:426591]] should be cast whenever it is available.  
  
  [[spell:121471]] should be cast right after [[spell:426591]].  
  
  Cast [[spell:185313]] whenever [[spell:280719]] is ready and you
  have **7** combo points.
- **Aligning Cooldowns**  
  
  Every [[spell:121471]] wants to have 2 [[spell:185313]] inside of it, which
  means that even when [[spell:280719]] and [[spell:185313]] is available, if 
  the [[spell:121471]] is less than 10 seconds away you want to hold off and wait.

2.5.

#### AoE Rotation

In AoE/Multi Target situations Subtlety plays very similar to how it does in Single
    Target, the main exception is casting the AoE spender and the AoE generator instead of
    the Single Target ones. Because the AoE generator gives 1 combo point per target 
    hit you get significantly more combo points, which means you get to cast more spenders.

- **Spenders**  
  
  [[spell:280719]] or [[spell:319175]] should be used when you have **7** combo points  
  
  [[spell:441423]] is an empowered version of [[spell:196819]] from the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster Hero Talent
  which should be cast whenever it available, even in AoE, there is a macro that automatically does it linked below.
- **Generators**  
  
  Whenever you do not have 7 combo points, you should be casting [[spell:197835]].
- **Utilizing your Cooldowns**  
  
  [[spell:426591]] should be cast whenever it is available.  
  
  [[spell:121471]] should be cast right after [[spell:426591]].  
  
  Cast [[spell:185313]] whenever [[spell:280719]] is ready and you
  have **7** combo points.
- **Aligning Cooldowns**  
  
  Every [[spell:121471]] wants to have 2 [[spell:185313]] inside of it, which
  means that even when [[spell:280719]] and [[spell:185313]] is available, if 
  the [[spell:121471]] is less than 10 seconds away you want to hold off and wait.

You can macro [[spell:441423]] together with your [[spell:319175]] button and it will automatically
cast it for you whenever it is ready, the macro looks like this:

#### Coup de Grace + Black Powder

```wow-macro
#showtooltip Black Powder
/cast Coup de Grace
/cast Black Powder
```

2.5.1.

##### Apex Talents

The last Apex Talent [[spell:1268939]] will sometimes give you a buff, which you can see by a shadowy glow 
near the middle of the screen. When that happens, your next Combo Point Spender will deal additional damage 
and you will get your Combo Points refunded, allowing you to cast another spender right away. The other two Apex
talents do not have any noticeable impact on the rotation.

2.5.2.

##### Season 2 Tier Set

During Season 2 of Midnight you will have access to these following Tier Set Bonuses.

- [[spell:1296592]]
- [[spell:1296593]]

The energy cost reduction from the 2-piece of the Season 2 tier set
    bonus allows practically every global outside of [[spell:185313]]
    to be filled with either a [[spell:53]] or a [[spell:197835]],
    leading to the spec having less downtime in the rotation. The damage buffs
    are also good to give the spells a bit more oomph.

The 4-piece effect allows [[spell:382524]] to also affect [[spell:196819]]
    and [[spell:319175]], which makes this talent mandatory. The set effect does
    not alter how the rotation plays, but the second half of your [[spell:121471]] is now
    gonna be stronger than the first half due to this.

### Subtlety Rogue   Defensive Spells

2.6.

#### Defensive Spells for Subtlety Rogue

Subtlety has pretty weak passive defense, therefore it relies on 
    using the active abilities for the vast majority of its defense.

**[[spell:1966]] -** provides a 40% damage reduction to AoE
abilities with a very short cooldown and short uptime. It does have a
very minor energy cost, but because of the abundance of energy as Subtlety
that does not matter much. Basically anytime you feel like you are in danger,
cast this.

**[[spell:31224]] -** grants immunity to magical effects on a 2
minute cooldown, allowingyou to stay inside deadly AoE zones or remove extremely 
dangerous debuffs from yourself.

**[[spell:185311]] -** provides a quite weak healing over time 
effect to yourself with a 30 second cooldown. This spell has an energy cost 
and costs a global cooldown, making it relatively weak and mostly reserved
for the most dire of situations.

**[[spell:5277]] -** grants 100% chance to dodge melee attacks on a 2
minute cooldown. This is extremely niche as it usually does not work on
AoE effects in dungeons or raid, but on the few rare occasions where it
does it is powerful.

**[[spell:31230]] -** allows you to survive when you should
otherwise have died on a 6 minute cooldown. This is not an active ability
but it is an insanely powerful defensive tool to be aware of.

### Subtlety Rogue   Stat Priority

2.7.

#### Stat Priority for Subtlety Rogue

The general stat priority for a Subtlety Rogue is as follows. 
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>).

Item Level

Mastery

Haste (to 700+)

Versatility

Critical Strike

Due to [[spell:185314]] Subtlety has Haste breakpoints (or "caps") after which the value
of Haste drops. For Season 2, the amount of Haste to aim for is somewhere between 700 and 1100
for both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker. Unlike season 1 the breakpoint is not as
strict so anywhere in that range is acceptable.

### Blizzard   Combat Assistant

2.8.

#### Combat Assistant and One-Button-Rotation

The Combat Assistant and the One-Button-Rotation are currently
not very good for Subtlety Rogue. 
Using the One-Button-Rotation is around 10% less DPS than doing
the rotation above in Single-Target situations and upwards of 15% in 
Multi-Target AoE situations.

Using The Combat Assistant does not incur the GCD penalty associated with 
the One-Button-Rotation, which makes the difference much less pronounced 
and not that bad to use.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1
- **26 Feb. 2026:** Reviewed for Midnight.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **06 Sep. 2025:** Updated to be written with Tier-Set in mind.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **23 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed and Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed and Updated for patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Page updated for Patch 10.1.5.
- **11 May 2023:** Changed recommended talent to Flagellation over Dark Brew.
- **01 May 2023:** Page reviewed and updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Page updated for Patch 10.0.5.
- **17 Dec. 2022:** Added multi-target ability priority list and updated single-target.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Subtlety Rogue in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Subtlety Rogue

For Season 2, Subtlety has a bit more flexibility and balance again when it comes to
choosing its Hero Talent tree. Our current recommendations are as follows:

- **Single-Target -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker provides the strongest single-target
      damage.
- **AoE -** Both hero talents are viable: ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster provides more burst,
      while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker provides better single-target damage, priority-target damage,
      and better sustained AoE DPS, which is often more desirable in high keys.

If you are not yet familiar with how Subtlety Rogue plays, then we
    recommend starting out with the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster talent tree below for AoE/Mythic+,
    as there are more intricacies to playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker.

**Quick Start Import Codes:**

:::talents Single-Target - Deathstalker
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::talents Weekly Mythic+ - Trickster
```json
{
  "code": "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAziWoFbYGwMDmxA"
}
```
:::

:::talents High-key Mythic+ - Deathstalker
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::talents Delves - Trickster
```json
{
  "code": "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAziWoFbYGwMDmxA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Deathstalker

Raid/Single-Target

Recommended

Mythic+/AoE

high-keys

Trickster

Raid/Single-Target

Mythic+/AoE

weekly-keys

Delves

Recommended

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker Raid Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker deals very high damage in single-target situations, as well
as strong priority-target damage in AoE. If you have not yet acquired the [[spell:1296593]]
set bonus de-select [[spell:382524]] and put that point in [[spell:245687]].

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker Mythic+ Build

The talent [[spell:457055]] combined with [[spell:457058]] allows ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker to
deal massive damage to the big priority-target, while still fielding strong AoE as well.

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster Raid Build

The powerful burst of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster can be very useful in specific boss fights,
however, the single-target is lacking compared to the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker raid build.

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster Mythic+ Build

The powerful burst of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster is very useful for taking down packs of
mobs quickly. However the single-target and priority damage is lacking compared to the
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker setup, which is why a lot of high Mythic+ runs are utilizing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker.

### 天赋方案 1-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster Delve Build

Our go-to Delve build, which happens to be the exact same build as the Trickster Mythic+ one.
It offers a good mix of burst damage and survivability. For more information about how
Delves work and what to expect, check out our [Delve](<https://www.icy-veins.com/wow/delves-guide>) page!

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dqUZdlBWk5hiT0ABZaiUqD-AAAA-GIOQaAEIogBFmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-GIOQaAEIogBFmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzGL0mNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dqUZdlBWk5R0ABhirjcaSC-AAAA-BIOiQZzQhBTgwF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-BIOgQRzQhBTgwF-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-BIOgQRzQhBTgwF-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), it provides 
    some very small performance-enhancing options. A couple of these bonuses increase throughput, 
    while others are more defensively oriented.

We recommend you pick the following bonuses:

- Node 1:[[spell:1279599]]
- Node 2:[[spell:1279604]]
- Node 3:[[spell:1287555]]
- Node 4:[[spell:1279612]]
- Node 5:[[spell:1279615]]

3.

### Apex Talent: ![Ancient Arts Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_nightblade.jpg>) Ancient Arts

These are the new talent added in Midnight, they are located below the specialization talent tree and are immensely powerful.
    All four of the talents focus on shadowy clones that spawn when you interact with [[spell:196912]] in different ways.
    While the tooltips might look complicated, especially if you are not very familiar with how [[spell:196912]] works
    (you can read an in-depth explanation of how those work on the Rotation page), but in practice Ancient Arts are fairly
    straightforward.

1. [[spell:1268932]] — Whenever something expends (consumes/uses) your [[spell:196912]] stacks, there is a 
           chance that a shadow clone will spawn and deal additional damage based on what spell expended those stacks.
2. [[spell:1268936]] — Passively increases all shadow damage dealt, and also makes it so when a shadow clone 
           spawns from [[spell:1268932]] or [[spell:280719]] you gain a stack of [[spell:196912]].
3. [[spell:1268939]] — If you have 5 or more stacks of [[spell:196912]] left after casting a combo point 
           generator you will activate a buff. This buff makes your next combo point finisher also expend your [[spell:196912]]
           stacks, which means you get a full set of combo points back right after using a finisher. This will also trigger a 
           shadow clone from [[spell:1268932]] that will deal damage based on the finisher used.

These Apex Talents allows us to utilize our [[spell:196912]] more efficiently during our burst windows and cast finishers like 
    [[spell:196819]] back-to-back without needing to use any combo point generators in between. You also get passively more damage and 
    passively more combo points through the [[spell:196912]] stacks generated by [[spell:1268936]] which helps smooth out the rotation.

4.

### Hero Talents for Subtlety Rogue

Starting from level 71 Hero Talents are a set of mutually exclusive trees you can choose between which slightly
    alter the gameplay and identity of the spec. For Subtlety Rogue the choice is between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster
    and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Tricksters theme is based around deception. In game this takes the form of talents like [[spell:441403]] 
    increasing the duration of [[spell:57934]] to an hour instead of mere seconds, striking with an [[spell:441146]]
    at times as well as spawning a huge cloud of smoke through [[spell:441429]].

In terms of gameplay the Hero Tree is very much focused around big burst windows with [[spell:121471]] and [[spell:280719]],
    allowing Subtlety Rogue to truly shine in situations that demand big on-demand damage.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker

Tracking down and focusing on a single target is what ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker is all about. Its central mechanic [[spell:457052]]
    is tied to a specific target and allows you to prioritize a lot of your damage straight into that enemy even in AoE scenarios thanks to [[spell:457055]]. 
    Talents like [[spell:457057]] make it very hard for your target to escape you and [[spell:457034]] is an excellent defensive option for
    when your enemy decides to fight back.

This hero tree is all about managing [[spell:457052]], putting it on the right targets at the right time. Once all the stacks of the
    mark has been used up the big payoff is [[spell:457058]], which makes your next [[spell:196819]] do enormous damage.

5.

### PvP Talents (War Mode)

If you choose to, you can enable "War Mode." Enabling War Mode provides
the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at maximum level.
- 15% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of both General PvP Talents
and Subtlety Rogue-specific PvP talents.

1. [[spell:269513]] is just a stronger [[spell:196819]].
2. [[spell:198675]] — Whenever Stealth is active, you apply a debuff to
   nearby enemies that causes them to take an additional 5% damage from your next
   Shadowstrike. Stacks up to 8 times. This is nothing special, but still a slight
   damage boost.
3. Only two of the Honor Talents increase our DPS while outdoors, so the last
   choice is up to you on which one you think suits you the best.

[[spell:198952]], [[spell:207736]], [[spell:197899]],
[[spell:212182]], [[spell:221622]], [[spell:354661]], [[spell:354406]],
[[spell:207777]] and [[spell:197000]] have limited use in PvE content
in terms of increasing your damage in the open-world.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **03 May 2026:** Updated for May 5th Tuning.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Reviewed for Midnight Mythic Release.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **23 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed and Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **24 Nov. 2023:** Updated to add Shadowdust Talent Builds.
- **06 Nov. 2023:** Reviewed and Updated for patch 10.2.
- **04 Sep. 2023:** Reformated talent tables and descriptions.
- **10 Jul. 2023:** Small recommended talent updates.
- **11 May 2023:** Changed recommended talent to Flagellation over Dark Brew.
- **09 May 2023:** Added the new talent build with Aberrus tier set.
- **01 May 2023:** Page reviewed and updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **14 Feb. 2023:** Updated recommended single-target talent build.
- **24 Jan. 2023:** Page updated and reviewed for Patch 10.0.5.
- **17 Dec. 2022:** Fixed import string for single-target spec.
- **11 Dec. 2022:** Updated recommended talents.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **31 Oct. 2022:** Changed recommended Raiding talent build and added comments on possible talent choices on certain rows.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Subtlety Rogue in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Subtlety Rogue Gameplay and Rotation Guide

Welcome to our Rotation page for Subtlety Rogues. On this page, you will
find everything you need to know about playing the spec in Raiding
and Mythic+ scenarios.

Subtlety Rogue is a 90-second spec. Every 90 seconds, you will use [[spell:121471]] combined with
2 [[spell:185313]]s. Getting as much out of these burst windows as possible is the key to playing 
Subtlety Rogue effectively.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster

Single-Target/AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker

Single-Target/AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

[[spell:426591]]

[[spell:381623]]

### Single Target Rotation

Always start the fight in [[spell:1784]] and with [[spell:315584]] and [[spell:381637]] applied.

1. **适用条件：Goremaw's Bite（启用）。** Cast [[spell:426591]] whenever it is ready, right before your other cooldowns.
2. **适用条件：Trickster（启用）。** Cast [[spell:185313]] when you have 6 or more combo points and [[spell:280719]] is ready or [[spell:121471]] is active.
3. **适用条件：Deathstalker（启用）。** Cast [[spell:185313]] when you have 2 or fewer combo points and [[spell:280719]] is ready or [[spell:121471]] is active.
4. Cast [[spell:121471]] during [[spell:185313]].
5. **适用条件：Deathstalker（启用）。** Cast [[spell:196819]] with 6 or more combo points when [[spell:457058]] is active.
6. Cast [[spell:280719]] during [[spell:185313]] with 6 or more combo points.
7. **适用条件：Trickster（启用）。** Cast [[spell:441423]] with 6 or more combo points.
8. Cast [[spell:196819]] with 6 or more combo points.
9. Cast [[spell:185438]] whenever you can, otherwise cast [[spell:53]] to build combo points.

**适用条件：Deathstalker（启用）。** Make sure to always start the fight off with a [[spell:185438]] to apply [[spell:457052]].

You always want to use two of [[spell:185313]]s during your [[spell:121471]] so do not cast it when [[spell:121471]] has less than 10 seconds left of its cooldown.

**适用条件：Thistle Tea（启用）。** You do not need to actively use [[spell:381623]], its optimal to have it automatically activate when you have low energy.

**适用条件：Trickster（启用）。** You want to make sure you always have [[spell:1268939]] active when casting [[spell:280719]]. The way to achieve this is to not cast any finishers a couple of seconds right before you intend to [[spell:185313]] to make sure you have a couple of extra [[spell:196912]] stacked up. You can continue casting [[spell:53]]s at full combo points to not overcap on energy. You can read more about how to setup before your [[spell:185313]]s below to ensure this happens.

**适用条件：Deathstalker（启用）。** You want to make sure you always have [[spell:1268939]] active on your [[spell:457058]]s during [[spell:185313]]. This means that if you do not have [[spell:1268939]] active you can press another [[spell:185438]] to ensure it procs, even when you have full combo points. You can read more about how to setup before your [[spell:185313]]s below to ensure this happens.

[[spell:1856]] can be used at any point whenever [[spell:185313]] is not active. Make sure to follow it up with a [[spell:185438]].

### Multi Target (AoE) Rotation

Always start the fight in [[spell:1784]] and with [[spell:315584]] and [[spell:381637]] applied.

1. **适用条件：Goremaw's Bite（启用）。** Cast [[spell:426591]] whenever it is ready, right before your other cooldowns.
2. **适用条件：Trickster（启用）。** Cast [[spell:185313]] when you have 6 or more combo points and [[spell:280719]] is ready or [[spell:121471]] is active.
3. **适用条件：Deathstalker（启用）。** Cast [[spell:185313]] when you have 2 or fewer combo points and [[spell:280719]] is ready or [[spell:121471]] is active.
4. Cast [[spell:121471]] during [[spell:185313]].
5. Cast [[spell:280719]] during [[spell:185313]] with 6 or more combo points.
6. **适用条件：Deathstalker（启用）。** Cast [[spell:196819]] with 6 or more combo points when [[spell:457058]] is active
7. **适用条件：Trickster（启用）。** Cast [[spell:441423]] with 6 or more combo points.
8. Cast [[spell:319175]] with 6 or more combo points.
9. Cast [[spell:197835]] to build combo points.

**适用条件：Deathstalker（启用）。** Make sure to always start the fight off with a [[spell:185438]] to apply [[spell:457052]].

You always want to use two of [[spell:185313]]s during your [[spell:121471]] so do not cast it when [[spell:121471]] has less than 10 seconds left of its cooldown.

**适用条件：Thistle Tea（启用）。** You do not need to actively use [[spell:381623]], its optimal to have it automatically activate when you have low energy.

You want to make sure you always have [[spell:1268939]] active when casting [[spell:280719]]. The way to achieve this is to not cast any finishers a couple of seconds right before you intend to [[spell:185313]] to make sure you have a couple of extra [[spell:196912]] stacked up. You can continue casting [[spell:197835]]s at full combo points to not overcap on energy. You can read more about how to setup before your [[spell:185313]]s below to ensure this happens.

[[spell:1856]] can be used at any point whenever [[spell:185313]] is not active to trigger [[spell:385722]].

### Opener

[[spell:1784]]

[[spell:185438]]

[[spell:196819]]

[[spell:1856]]

[[spell:185438]]

[[spell:426591]]

**适用条件：Deathstalker（启用）。**

[[spell:196819]]

[[spell:121471]]

[[item:270175]]

[[item:241308]]

[[spell:33697]]

[[spell:274738]]

**适用条件：Trickster（启用）。**

[[spell:185313]]

[[spell:280719]]

**适用条件：Deathstalker（启用）。**

[[spell:185313]]

[[spell:197835]]

**适用条件：Deathstalker（启用）。**

[[spell:280719]]

At any point more than 20 seconds before the fight use [[spell:185313]] once to activate [[spell:470347]].

1. [[spell:1784]]
2. [[spell:185438]]
3. [[spell:196819]]
4. [[spell:1856]]
5. [[spell:185438]]
6. [[spell:426591]]
7. **适用条件：Deathstalker（启用）。** [[spell:196819]]
8. [[spell:121471]]
9. Any on-use stat trinket (eg: [[item:270175]]) , [[item:241308]] and any stat racial you might have (eg: [[spell:33697]]/[[spell:274738]]/[[spell:26297]])
10. **适用条件：Trickster（启用）。** [[spell:185313]] + [[spell:280719]]
11. **适用条件：Deathstalker（启用）。** [[spell:185313]] + [[spell:197835]]
12. **适用条件：Deathstalker（启用）。** [[spell:280719]]
13. Continue on with your regular rotation.

**适用条件：Deathstalker（启用）。** If you get a lot of [[spell:196912]] procs you might end up with full combo points by the time you reach the [[spell:185313]]+[[spell:197835]] step, in which case you would [[spell:185313]]+[[spell:280719]] instead.

### Assisted Highlight & Single-Button Assistant

The **Single-Button Assistant** system offers an easy introduction into the spec and its many buttons, but it comes at a cost. Due to the increase of the Global Cooldown you will naturally do lower DPS already. The One-Button rotation is also missing out on some of the finer nuances of the rotation in order to make it more accessible for players who have just started their journey into the game.

So even when using the **Assisted highlight** feature, you will be trailing a little behind those who have already mastered the ins and outs of the spec. That being said, the DPS difference compared to the most complex and detailed rotational gameplay is not as big as you might think.

You can expect to do ~10% less DPS than you would do with perfect rotational gameplay, so if you want to get your bearings before moving on to the Beginner DPS Rotation, using the Assisted Highlight or even the Single-Button Assistant is a great starting point for beginners.

2.

### Midnight Season 2 Tier Set

During Season 2 of Midnight you will have access to these following Tier Set Bonuses:

- [[spell:1296592]]
- [[spell:1296593]]

The energy cost reduction from the 2-piece of the Season 2 tier set
    bonus allows practically every global outside of [[spell:185313]]
    to be filled with either a [[spell:53]] or a [[spell:197835]],
    leading to the spec having less downtime in the rotation. The damage buffs
    are also good to give the spells a bit more oomph.

The 4-piece effect allows [[spell:382524]] to also affect [[spell:196819]]
    and [[spell:319175]], which makes this talent mandatory. The set effect does
    not alter how the rotation plays, but the second half of your [[spell:121471]] is now
    gonna be stronger than the first half due to this.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Subtlety Rogue
kit, we have compiled a more detailed explanation on individual parts of the rotation and their 
mechanics as well as your most powerful cooldowns and how to best utilize them.

### Setting up for Shadow Dance

3.1.

#### Setting up for Shadow Dance

The most impactful optimization for Subtlety right now is making sure
        you always have [[spell:1268939]] active for its most powerful abilities.
        A lot of the time this will happen naturally during play but sometimes it 
        has to be forced with an additional combo point generator, even at full combo 
        points, to ensure that it is up. One way to minimize the number of times you have to cast that additional 
        generator is to enter your [[spell:185313]]s with the correct buffs and 
        stacks active. The ideal setup depends on your hero talent:

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster: You want to buff [[spell:280719]], and since it is the first spell you 
        want to cast in [[spell:185313]], you want to enter it with the right setup.
        Make sure to have 7 combo points, 5 or more stacks of [[spell:196912]] and [[spell:1268939]] 
        active before you enter [[spell:185313]]. The exception to this rule is during the second
        half of [[spell:121471]], where you just want to cast it as soon as possible when the first
        [[spell:185313]] runs out.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker: There is a lot more flexibility here. The underlying idea is to make sure 
        that [[spell:457058]] is **ALWAYS** buffed by [[spell:1268939]] during
        [[spell:185313]]. Which spell you cast first can vary depending on your buffs when you enter
        [[spell:185313]]. Here are some examples of setups that accomplish this, though there are other
        valid combinations.

- Full combo points + 1 stack of [[spell:457052]] + 4-5 stacks of [[spell:196912]].
- No combo points + [[spell:457058]] active + 5 or more stacks of [[spell:196912]].
- Full combo points + [[spell:457058]] active + [[spell:1268939]] active.

All of these [[spell:457058]] optimizations are centered around single-target or low target count
            cleave. Since [[spell:457058]] has no impact on high target count situations you should instead follow
            the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster rules listed above for multi-target/AoE situations.

### Combo Points & Energy

3.2.

#### Combo Points and Energy

As a Rogue, most of your abilities need Energy to be used. Your Energy bar
    has a default capacity of 100 Energy and refills at a rate of 10 Energy per second.
    With [[spell:14983]] the cap is instead 200 Energy. Your Energy regeneration is
    increased by:

- Haste (Haste on items + Haste-enhancing buffs).
- The [[spell:58423]] passive, which guarantees your finishers
      restore 5 Energy per Combo Point.
- [[spell:196912]], which awards 5 Energy every time it
      procs. It also procs more significantly often during [[spell:185313]] thanks to [[spell:426594]].
- [[spell:14983]] if selected.

The way Subtlety Rogue currently plays there is no need manage or think about your energy. 
    Outside of [[spell:185313]] there will not be enough energy to cast a spell every single global, that is completely fine and normal. 
    Conversely when [[spell:185313]] is up you can spam all of your globals thanks to the extra combo points you generate
    and spend via [[spell:58423]] and the multitude of [[spell:196912]] stacks you generate.

### [[spell:196912]]

3.3.

#### Shadow Techniques

This is the source of what might seem like "random" extra combo points one might get when just
        starting to play Subtlety. These are a stacking buff you get on your character which makes your
        next combo point builder generate additional combo points based on how many stacks of the buff you have.
        It is worth noting however that the game will never spend these stacks to put you above your maximum combo 
        points, instead the stacks of the buff will be kept. Every time the effect is triggered and you gain a stack 
        you also gain 5 energy.

The buff stacks up from passively auto-attacking as well as from [[spell:1268936]]. However the passive
        generation from auto-attacks are not as random as the tooltip suggests. While it averages out to 28% like the tooltip 
        says it actually works like this:

1. Your 1st attack has a 0% chance to proc it
2. Your 2nd attack has a 50% chance to proc it
3. Your 3rd attack has a 100% chance to proc it
4. If the 2nd attack did not proc it, the 3rd has a 100% chance to proc it.
5. Whenever it procs it starts over from the beginning.

When [[spell:426594]] says it "triggers 25% more frequently" it instead has a 100% chance to proc on the second attack.
        Since such a large share of the combo points generated by the spec comes from [[spell:196912]] the [[spell:426594]] 
        is practically required as it doubles the combo points per trigger.

### Apex Talents: Ancient Arts

3.4.

#### Apex Talents: Ancient Arts

3.4.1.

##### Explaining how the talent works

To understand Ancient Arts you must first understand how [[spell:196912]] works, which you can read about in the section right next to this one.

The first Apex talent, [[spell:1268932]], is fairly straightforward. Whenever something expends (consumes/uses) [[spell:196912]] stacks, there is 
        a chance that you will spawn a clone that deals additional shadow damage. This chance is 15% per [[spell:196912]] stack by default but the talent
        [[spell:382506]], which you always select, increases the chance to 20% per stack, so if you expend 5 or more [[spell:196912]] stacks you have a 100%
        chance to spawn the clone.

The second Apex talent, [[spell:1268936]], increases all shadow damage dealt, and also makes it so whenever you spawn a clone you will get 1 stack of 
        [[spell:196912]]. This includes [[spell:1268932]] clones and [[spell:280719]] clones. It also benefits from [[spell:426594]], so
        whenever you cast [[spell:280719]] during [[spell:185313]] you get a total of 4 [[spell:196912]] stacks.

The third and last Apex talent, [[spell:1268939]], is the one that has the most impact on the rotation. Whenever you cast a combo point generator
        ([[spell:185438]], [[spell:53]] or [[spell:197835]]) and you have 5 or more [[spell:196912]] stacks left **afterwards** the buff 
        activates. The buff has a shadowy glow indicator near the center of your screen in-game to notify you that it is active, and what it does is that your 
        next combo point spender will expend your [[spell:196912]] stacks, just like a builder would, which effectively means you get your combo points refunded
        without needing to cast a builder, allowing you to cast another finisher right afterwards. This also synergizes with and activates [[spell:1268932]], which then
        spawns a clone that deals damage based on your finisher.

4.

### Important Cooldowns for Subtlety Rogue

### [[spell:121471]]

4.1.

#### Shadow Blades

[[spell:121471]] is our most important cooldown. Its available every 90 seconds
    and while it is active your combo point generating abilities generate twice as many 
    combo points and every attack deals an additional 20% extra damage as shadow damage.

Because of this every cast of [[spell:121471]] wants to be accompanied by 2 casts
    of [[spell:185313]], as stacking multiple damage cooldowns at the same time leads to
    more damage. This is also the perfect time to be using other damage increase effects such
    as your potion or any racial buffs you may have ([[spell:33697]] as an example).

### [[spell:185313]]

4.2.

#### Shadow Dance

[[spell:185313]] is your "bread and butter" cooldown, and your damage
output relies heavily on proper usage. Shadow Dance has 1 charge, or 2 when
talented into [[spell:394930]], each with a 20 second recharge. Its baseline duration
is 6 seconds.

However, the talent [[spell:185314]] extends it based on the amount of
Haste stat your character has. So any buffs like [[spell:2825]] or [[spell:10060]]
will not increase the duration, but an on-use trinket like [[item:249344]] will.

It can also be extended by the [[spell:382505]] talent, in a raid encounter this effect will 
only ever occur at the start of the fight. But increasing the duration of [[spell:185313]] is so 
powerful, its often worth considering anyway unless the fight is very long.

In Mythic+ however, this effect can occur very often, and it is often wise
to wait a few seconds or two with engaging the mobs, especially if this 6
second window is close to being completed.

Generally you want to be casting [[spell:185313]] when [[spell:280719]] is ready,
    which should be nearly on cooldown. Though the cooldown of [[spell:280719]] is 25 seconds, it
    can get reduced by Haste.

Due to [[spell:185314]] increasing the length of dance by such a variable amount its recommended
    to always cast abilities with as little time in between them as possible. This includes having one or multiple
    macros to make sure the first spell cast inside [[spell:185313]] is casted immediately and not 0.2 seconds later.
    You can find these in our macro guide:

[Subtlety Rogue Addons and Macros](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)

4.3.

#### Defensive Utility

Rogues have the some of the best defensive capabilities in the game, which makes them
    a solid candidate for soaking required mechanics and dealing with heavy
    incoming damage.

- [[spell:1966]] reduces AoE damage taken by 40% for 6 seconds for only 25
      Energy. When talented into [[spell:79008]], it also reduces all other
      damage by 20%. This is one of the most overpowered abilities in the game and a
      huge asset on fights with heavy group damage.
- [[spell:31224]] removes all non-physical debuffs, followed by
      5 seconds where all spells will miss. Cloak can be used for intercepting in
      boss fight mechanics or be used for damage gains, such as staying in and hitting
      the boss during an AoE that you would otherwise have to avoid.
- [[spell:31230]] is a talent that allows you to escape lethal damage
      once every 6 minutes. The damage cannot exceed more than twice your maximum
      Health. Cheat Death is great for soaking mechanics that pierce immunities and
      damage reductions as it guarantees your survival. It is also great for
      encounters with bursty damage that might take you by surprise, as you get a
      free get-out-of-jail free card once every 6 minutes.
- [[spell:185311]] provides a minor amount of healing on a very
      short cooldown. Useful for an extra bit of healing if you are low on Health
      or you are out of range of a healer.
- [[spell:5277]] provides a 20% damage reduction when talented into
      [[spell:79008]] and another 15% reduction against magic if talented into
      [[spell:457034]] as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker. 
      This is a very respectable cooldown but often gets 
      overshadowed by the power of [[spell:1966]]. The dodge mechanic is really 
      helpful in solo content but very niche in group settings.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **03 May 2026:** Updated for May 5th Tuning.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1
- **26 Feb. 2026:** Reviewed for Midnight.
- **10 Feb. 2026:** Updated for Midnight.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **23 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed and Updated for patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Page reviewed and updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Page updated and reviewed for Patch 10.0.5.
- **17 Dec. 2022:** Small updates to ability priority list.
- **11 Dec. 2022:** Added mention of Cold Blood usage.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **31 Oct. 2022:** Page updated with Venthyr build opener.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Subtlety Rogue in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Subtlety Rogue

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, with harder content dropping gear that can be upgraded further.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Subtlety Rogue. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2 catalyzing an item causes it to retain the stats it had beforehand, this means that the best tier pieces depends on what items you can get to put in the catalyst. Here are the best items to catalyze into tier:

- Helmet - [[item:271875@JAAEAAAG2chN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders - [[item:268246@JAACAAAG2A]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Chest - [[item:251159@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Gloves - [[item:268234@JAACAAgNyA]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- Legs - [[item:268225@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details FAQCan I use a Non-Dagger as my Off-Hand Weapon?
No, Always use a dagger in off-hand. The reason for this is that

[[spell:196912]]

activates more often with a dagger due to the faster attack speed of daggers. Because of this, using a non-dagger loses out on roughly 10% of all of your energy and combo points.

:::

:::details FAQWhere should I spend my Nebulous Voidcores (Bonus rolls)?
The last boss of the raid, Ula'tek. It drops 4 exceptionally strong items all of which are best in slot. So it is recommended to select the Voidcores (Bonus rolls) from your vault until you have acquired all of these 4 items.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271510@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271511]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271508@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251194@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAIAAwt1ENMMYDYwA]]&#10;&#10;<div>[[item:240167]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271093@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237837@JAAIAAwt1ENMcYzy1A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup with farmable gear from Season 2 Mythic+ Dungeons. Keep in mind that there are many other setups that perform within the margin of error.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2 catalyzing an item causes it to retain the stats it had beforehand, this means that the best tier pieces depends on what items you can get to put in the catalyst. Here are the best items to catalyze into tier:

- Helmet - [[item:251140@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Shoulders - [[item:251223@JAACAAgNyA]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Chest - [[item:251159@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Gloves - [[item:251124@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs - [[item:251130@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): Practically every item from this dungeon is good, and it has the best non-raid on-use: [[item:250215@JAACAAgNyA]].
- [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Mostly solid items and the passive trinket [[item:250259@JAACAAgNyA]] is strong.
- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): It contains a non-unique dagger with an additional damage proc, [[item:275070@JAACAAgNyA]], and a bunch of high haste items for the breakpoint.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271510@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:159317@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271509@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251194@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Bracers</th><td>[[item:251135@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Trinket</th><td>[[item:250259@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:275070@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:275070@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup, only using gear from the Venomous Abyss Raid.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2 catalyzing an item causes it to retain the stats it had beforehand, this means that the best tier pieces depends on what items you can get to put in the catalyst. Here are the best items to catalyze into tier:

- Helmet - [[item:271875@JAAEAAAG2chN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders - [[item:268246@JAACAAAG2A]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Chest - [[item:268235@JAACAAgNyA]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- Gloves - [[item:268234@JAACAAgNyA]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- Legs - [[item:268225@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:271093]]: A high ilevel dagger with a solid damage effect. Drops from the last boss [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- [[item:270175]]: Our best active trinket. Drops from the last boss [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- [[item:268265]]: A neck that a stat proc in addition to also having an extra socket. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271510@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271511]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271508@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:268240@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271093@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268264@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Subtlety Rogue

There are a great number of Trinkets available for Subtlety, and we will always want
  to play a combination of a powerful on-use trinket to align with our [[spell:121471]], and there are 
  two of those this season: [[item:270175]] and [[item:250215]].
  Alongside that on-use we want a passive trinket providing potent secondary stat buffs or raw damage procs.

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Subtlety Rogue Trinkets**
**On-Use -**

[[item:270175]]

or, alternatively,

[[item:250215]]

**Passive -**

[[item:270165]]

or, alternatively,

[[item:270173]]

for pure single-target.

:::

There are quite a few other valuable trinkets out there, so make sure to click on our
  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Subtlety Rogue Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Subtlety</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]</li>&#10;<li>&#10;&#10;&#10;[[item:270173]] - <span><em>Click for Details</em></span>&#10;<span>This trinket is exceptionally strong in pure single-target but gets worse whenever there are additional targets.&#10;      </span>&#10;</li>&#10;<li>[[item:270165]]</li>&#10;<li>&#10;&#10;&#10;[[item:281215]] - <span><em>Click for Details</em></span>&#10;<span>This trinket is exceptionally strong in Mythic+ scenarios but not that impressive on single-target.&#10;      </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270168]]</li>&#10;<li>[[item:274493]]</li>&#10;<li>&#10;&#10;&#10;[[item:248583]] - <span><em>Click for Details</em></span>&#10;<span>By going to the different shrines in Zul'Aman you can adjust what stats the proc gives you. You want it to give you Mastery.&#10;      </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:265657]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>&#10;&#10;&#10;[[item:159617]] - <span><em>Click for Details</em></span>&#10;<span>An alternative to [[item:270175]] or [[item:250215]] if you haven't gotten one of them yet.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:273796]] - <span><em>Click for Details</em></span>&#10;<span>An alternative to [[item:270175]] or [[item:250215]] if you haven't gotten one of them yet.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250225]]</li>&#10;<li>[[item:158374]]</li>&#10;<li>[[item:241340]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:251785]]</li>&#10;<li>[[item:251783]]</li>&#10;<li>[[item:274496]]</li>&#10;<li>[[item:274497]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:246307]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:246305]]</li>&#10;<li>[[item:246306]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

- [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) is an item you are able to select instead of picking an item in 
      your vault each week. They are similar to the old "bonus roll" system from way back in the day, 
      effectively allowing you to target items from a specific boss or dungeon. Which item you 
      receive when you use them is random, however once the Voidcore has granted you an item you 
      will not be able to acquire it again. This means that the next time you use one you will get 
      one of the other items available from that loot pool. The items gained from these will 
      be corresponding to the vault ilvl of the content you are doing, so for example if you
      use one on the last boss of the raid on Heroic you will get a 1/6 Myth track item.
- At the start of the patch the only way to receive the [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s are 
      to select them from your weekly vault, however as of Patch 12.1.5 there is now also 
      weekly quest that awards one every week.

3.1.

#### Recommended Voidcore (Bonus Rolls) Usage for Subtlety Rogue

Which item you want to chase after depends heavily on the items you already have
  and whether you are expecting to kill certain bosses on
  Mythic difficulty, as you do not want to waste your Voidcores on items you may be able to
  get on a higher difficulty track in a few weeks. The priority is as follows:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)  
   
   [[item:271093]]   
   
   [[item:270175]]   
   
   [[item:268265]]   
   
   [[item:271875]]   
   
     All of these items drop from the last boss of the raid, Ula'Tek.
2. [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)  
   
     This boss drops a plethora of good items, including [[item:270173]].
3. Remaining BiS List items

:::

3.2.

#### Ascendant Venomstone

Using your [[item:280562]]s follows a similar priority list as using your Crests:

1. Mainhand weapon
2. On-use trinket (ideally [[item:270175]])
3. Passive trinket
4. Necklace
5. Offhand Weapon

4.

### Best Crafted Items for Subtlety Rogue

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose the exact
secondary stats you want.

During the early stages of the season your ability to craft items will be
  severely time-gated. Because of this we highly recommend crafting a **Mainhand Weapon** as soon 
  as possible, unless you know for sure you can get one elsewhere. When you have acquired a good weapon,
  start working on your other Embellished Items, and after that focus on crafting whatever piece you
  currently have at the lowest item-level.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Subtlety Crafted Gear Priority**
- [[item:237837]] with [[item:273060]]
- [[item:244576]] with [[item:240167]]
- Any item you do not have on Myth track yet.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Subtlety Rogue

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

As there is a lot of competition for Embellishments, you will have to pick
and choose the two strongest ones for your overall DPS output. Most of them provide
very similar DPS benefits, even if the effects are entirely different. The two best
choices for this are:

- For Raid: [[item:273060]] on a weapon and [[item:240167]] on another
  crafted item like Belt or Wrists.
- For Mythic+: [[item:273060]] on a weapon and [[item:240167]] on another
  crafted item like Belt or Wrists.

It is recommended to sim yourself to find out what works best, and if you
also play the other two Rogue specs, you might want to pick Embellishments that work
well for all of them.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you up to 6 tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since gaining new crests are capped each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, and/or those that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Subtlety Rogue Crest Upgrade Priority**
**Weapon (Mainhand)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

These are not the only items worth upgrading, of course. They simply offer
the highest DPS gain early into the tier when your upgrade currency is limited.
Note that exceptions are possible, such as special items that have additional
procs attached to them.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Reviewed for Midnight Mythic Release.
- **16 Mar. 2026:** Reviewed for Midnight Season 1
- **26 Feb. 2026:** Reviewed for Midnight.
- **10 Feb. 2026:** Updated for Midnight.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed and Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **07 Nov. 2023:** Reviewed and Updated after Sporecloak Nerf.
- **06 Nov. 2023:** Reviewed and Updated for patch 10.2.
- **04 Sep. 2023:** Added BiS item tables and reformatted page.
- **10 Jul. 2023:** Page updated for Patch 10.1.5.
- **09 May 2023:** Added notes about how to spend sparks in Season 2 along with few other updates.
- **01 May 2023:** Page updated for Patch 10.1 and added notes about Eranog ring and Onyx Annulet.
- **20 Mar. 2023:** Page updated and reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Page updated for Patch 10.0.5.
- **13 Jan. 2023:** Added recommended Embellishments.
- **11 Dec. 2022:** Updated for Vault of the Incarnates launch.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Subtlety Rogue. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Subtlety Rogue Stat Priority

We do not recommend fretting over stat priorities, as simming 
your gear is a far more objective and accurate way of determining 
the best gear for <em>your</em> character.

Item Level

Mastery

Haste (to 700+)

Versatility

Critical Strike

Due to [[spell:185314]] Subtlety has Haste breakpoints (or "caps") after which the value
of Haste drops. For Season 2, the amount of Haste to aim for is somewhere between 700 and 1100
for both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker. Unlike season 1 the breakpoint is not as
strict so anywhere in that range is acceptable.

Critical Strike is less impactful because of [[spell:457058]], which already has the crit guaranteed.
  Despite that, the [[item:268265]] neck from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) is still exceptional because the amount of
  stats on it is insane.

:::details FAQDoes the Subtlety stat priority change on multi-target?
Mastery gains even more value in Multi-Target situations.

:::

2.

### In-Depth Stat Breakdown

**Agility** is your primary statistic. You should look for it in all
of your upgrades. It provides you with Attack Power, which determines the
damage your abilities do.

**Mastery** increases the damage of your combo point finishers through
[[spell:76808]].

**Critical Strike** increases your chance to critically hit with
all spells and abilities. Critical strikes deal double damage by default, but several 
effects can increase your crit damage, and make critical strikes even stronger,
for example: [[spell:382508]].

**Versatility** simply increases damage done and damage reduces taken.

**Haste** increases your Energy regeneration, attack speed, the duration of [[spell:185313]] through 
[[spell:185314]] and reducing the cooldown of [[spell:280719]]. 
Increased attack speed generates extra Combo Points via [[spell:196912]].

:::details FAQIs there a Haste cap for Subtlety Rogue?
Yes, due to

[[spell:185314]]

Haste is very strong if it gets you one additional spell casted inside

[[spell:185313]]

and not very strong otherwise. The recommended Haste values give three additional globals
inside

[[spell:185313]]

with a little bit of leeway. It also reduces the cooldown of

[[spell:280719]]

to roughly
align with the cooldown of

[[spell:185313]]

.

:::

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 May 2026:** Updated talent build descriptions.
- **03 May 2026:** Updated for May 5th Tuning.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight.
- **10 Feb. 2026:** Updated for Midnight.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed and Updated for patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Page updated for Patch 10.1.5.
- **01 May 2023:** Page reviewed and updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated stat recommendations and reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Small update to recommended single-target stats.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Subtlety Rogue, based on your [stat priority](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should use [[item:240983]] in one socket. Then, the 
rest of the sockets can be filled in based on what your character needs the most. 
Generally you would use the Haste and Mastery/Critical Strike ones
([[item:240890]] or [[item:240892]]) until you
reach the Haste breakpoint. Afterwards, fill the remaining slots with
[[item:240908]] or [[item:240898]].

However, the choice of gems is highly dependent on the specific gear you're wearing.
Each of the four secondary stats can easily be your highest-performing stat depending on
the stats provided by your equipped items, and as a result the choice of gems and ring enchants
can vary a lot. We highly recommend simming yourself to find out the best set of gems
for your specific character and setup.

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Main Hand</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]] and [[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Off Hand</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]] and [[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Whether you choose to enchant your gear with Avoidance, Leech, or Speed is
up to you. Leech will allow you to gain some additional passive healing while
you do damage, Avoidance reduces the damage taken by Area-of-Effect spells,
similar to [[spell:1966]], and Speed simply increases your movement speed. For
Raid progression movement speed is often underrated and can be a minor DPS
increase if it allows you to reach your target faster.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

If you have yet to reach the Haste breakpoint you should be using [[item:241325]], 
otherwise use [[item:241322]].

3.2.

#### Potions

The best general stat potion is [[item:241308]]. At first glance [[item:241292]] 
might look like it is better but the downside from it makes it near impossible to use as a melee,
especially in boss encounters or M+ scenarios.

In AoE situations with AoE talent setups it is better to use [[item:241288]] instead, however
    **only if you get mastery from it**. As it increases your highest secondary stat you need to have
    your stats configured in a way that makes sure you get mastery from it, if you do not then stick to using
    [[item:241308]].

Make sure to also carry at least a few [[item:271883]]s to heal yourself
in dire situations.

3.3.

#### Food Buff

The recommended food is [[item:255846]] or [[item:242275]].

3.4.

#### Augment Rune

The best augment rune is [[item:259085]].

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Reviewed for Midnight Mythic Release.
- **16 Mar. 2026:** Reviewed for Midnight Season 1
- **26 Feb. 2026:** Reviewed for Midnight.
- **10 Feb. 2026:** Updated for Midnight.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed and Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed and Updated for patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Page updated for Patch 10.1.5.
- **01 May 2023:** Page reviewed and updated for Patch 10.1.
- **06 Apr. 2023:** Updated recommended Primordial gems.
- **20 Mar. 2023:** Page reviewed and updated for Patch 10.0.7.
- **24 Jan. 2023:** Changed a few recommended enchants and Phial recommendation and reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Small changes to weapon enchants.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Subtlety Rogue in World of Warcraft Patch 12.1.5.

1.

### Subtlety Rogue in Mythic+ in Midnight Season 2

The playstyle of Subtlety in Mythic+ revolves around huge burst windows with [[spell:185313]] and [[spell:121471]]. 
    You are also using [[spell:197835]] to generate more Combo Points than you normally would in
    a single-target scenario, which leads to more finishing moves overall.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Subtlety in Mythic+ offers fairly low sustained AoE damage. To compensate for that it
does have very strong cooldowns that can be used on bosses or high-priority targets that
need to be taken out quickly or have much higher health pools than the surrounding
enemies. You can play this as either Hero Talent spec, depending on your preference, but 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster reigns supreme damage-wise in lower Mythic+.

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) **Trickster**    Mythic+ / AoE

2.1.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster Mythic+ Talents for Subtlety Rogue in Midnight

This is the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster build for Subtlety, that offers immense burst, both on AoE and on Single-Target.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-BIOgQRzQhBTgwF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) **Deathstalker**    Mythic+ / AoE

2.2.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker Mythic+ Talents for Subtlety Rogue in Midnight

This is the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker AoE build for Subtlety. It offers slightly more priority damage than the 
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster alternative but with slightly less burst.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dqUZdlBW4R0ABJaaiijkRC-AAAA-GIOQaAEIogBFmF-
```

:::

2.3.

#### Flexible Utility Talents

Rogues as a whole ain't got too many utility talent points that’s flexible depending on the situation up ahead, 
    but there are a few points that can be moved based on preference:

- [[spell:5938]] and its accompanying [[spell:1267182]] if there are no Enrage effects to dispel.
- [[spell:423701]] if you want a stronger slow (its actually the strongest consistent slow in the game at 72%!)
- [[spell:423662]] if you know you will need a shorter cooldown of your [[spell:114018]].
- [[spell:193546]] if none of the above apply.
- [[spell:200733]] and [[spell:1776]] are mutually exclusive with each other. Generally [[spell:200733]] is
          better as an AoE stop is more valuable than an additional single-target one.

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts, Stuns and Stops

[[spell:1766]] is your, well, "kick". You will interrupt your targeted enemy, or,
when using a Focus-Macro, the target you set up as your focus.

#### Focus Kick

```wow-macro
#showtooltip Kick
/cast [@focus,exists,nodead][] Kick
```

This macro will kick your focus target if you have one, and your target if you have no focus
target. We recommend keeping both the macro and a regular kick cast on your bars,
as you may have multiple targets to interrupt, and the macro always prioritizes the
focus target.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**, or setting the "Focus Target" hotkey in the game's
keybinding settings.

#### Focus Mouseover

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly, so that you
are always able to kick it on cooldown, or in coordination with the rest of your
group.

3.2.

#### Stunning and "Stops"

[[spell:6770]] and [[spell:2094]] can be useful to hard-crowd control
 mobs in a single trash pack. You can also use it right before the
tank is pulling, as [[spell:379005]] applies a damage reduction debuff
to the target when Sap breaks.

With [[spell:200733]] talented [[spell:2094]] will hit all enemies
    in proximity to your target. This allows you to stop all of them from finishing 
    their casts all at once which is a very powerful effect.

[[spell:1776]] (if talented) can be used to disrupt enemies from casting otherwise
uninterruptible spells. This requires you to stand in front of the enemy, but
can be used in many situations to keep enemies from using some of their most lethal
abilities. Some abilities go on cooldown once used, so disrupting them
with Gouge, [[spell:408]], or [[spell:2094]] will keep these mobs from
re-casting these abilities for a while.

[[spell:1856]] can be also used to [[spell:1833]] an enemy that
can only be stopped, not interrupted. It is also possible to do this with [[spell:185313]]
but not recommended unless absolutely necessary since it costs you a lot of damage.

### Other Utility

3.3.

#### Other Utility

[[spell:114018]] projects AoE [[spell:1784]] around you. It
is important to note, however, that in the current expansion, there is a much
greater number of enemies who can detect through Stealth or Invisibility, whom
you will need to be on the lookout for.

Subtlety Rogues also have the option to talent into [[spell:382507]], this allows you
to use shroud as a massive speed boost to your team even when you are not trying to sneak past
mobs. This is especially powerful in indoor dungeons with long sections of running where you cannot mount.
However as of Midnight taking this talent comes at the cost of an extremely good defensive talent,
[[spell:428486]], which leads it to be significantly more niche than before.

[[spell:1725]] helps set up Shroud-skips and keeps patrolling trash
packs in place for 10 seconds. Make sure to force enemies to look away from you,
to allow you to stealth past them.

[[spell:1966]], [[spell:31224]], [[spell:5277]],
[[spell:185311]] and [[spell:31230]] form a very powerful set of
defensive cooldowns and are one of the biggest reasons for Rogue's strength in
Mythic+.

[[spell:57934]] is not exceptionally great normally. However, any
kind of support that helps your tank keep aggro on all enemies is encouraged.
Sadly it is a choice-node with [[spell:379005]].

[[spell:5938]] can be used to dispel **Enrage** effects.

[[spell:5761]] and [[spell:381637]] are both useful in
Mythic+, but with the heavier emphasis on trash mobs, [[spell:5761]] is likely
to win out in most keys. However a lot of high end players will opt to use [[spell:381637]]
to give a slight extra edge against bosses that one-shot them in extremely high keys.

4.

### Dealing with Affixes

Season 2 of Midnight only has four significant Affixes that offer any kind
of counterplay, called Xal'ataths Bargains, and they rotate every week, with only
one of them being active at a time. Many of the other affixes like Fortified or
Tyrannical simply add a passive effect to the keystone, with four exceptions
that are seasonally themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. Unfortunately Rogue has almost no way of dealing with this.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn that
  needs to be focus-targeted and interrupted.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around the members of your group
  and you need to soak the orbs.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb. You can remove this with [[spell:31224]] or racials like 
  [[spell:20594]]. You can use [[spell:185311]] if these are unavailable to you, 
  to help get rid of the debuff faster. Health potions or Healthstones also work well if your 
  healer is out of resources.

Each of the affixes provides a different set of beneficial effects once it is dealt
with, and while they are very powerful, they are not something you play around
in a specific way. The most important part is to not let any of them buff the enemy
trash or bosses.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1
- **26 Feb. 2026:** Reviewed for Midnight.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Page updated for Patch 10.1.5.
- **11 May 2023:** Changed recommended talent to Flagellation over Dark Brew.
- **01 May 2023:** Page reviewed and updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated talents and reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated talent recommendations.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Subtlety Rogue in World of Warcraft Patch 12.1.5.

1.

### Best Macros

At certain haste thresholds, it can be very tight to fit in all of
your spells into [[spell:185313]] due to [[spell:185314]].
For example if the duration of [[spell:185313]] is 7.2 seconds, you only
have 0.2 seconds of leeway for your last spell. This is why using a macro can
be very useful to minimize any delays from needing to press multiple different
buttons at the same time.

#### Shadow Dance Macro for Trickster

```wow-macro
#showtooltip Shadow Dance
/cast Shadow Dance
/cast Secret Technique
```

If you are playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker, which prefers to enter
[[spell:185313]] on low combo points you unfortunately cannot
macro [[spell:185313]] and [[spell:185438]] together. This is due to
a bug that makes it so you must wait ~0.2 seconds after pressing
[[spell:185313]] before you can use [[spell:185438]].

However, because of [[spell:382528]], it is acceptable to use
this macro instead of having that small delay:

#### Shadow Dance Macro for Deathstalker

```wow-macro
#showtooltip Shadow Dance
/cast Shadow Dance
/cast Shuriken Storm
```

While there might be some situations where you want to hold your
[[spell:441423]] for a specific burst window, this will mostly work just
fine. You can bind this button as your [[spell:319175]] button and it will
automatically cast [[spell:441423]] instead whenever it is ready.

#### Combined Coup de Grace + Black Powder

```wow-macro
#showtooltip Black Powder
/cast Coup de Grace
/cast Black Powder
```

In case you wish to have a less busy time pressing buttons in the opener/burst
sequence you can macro your on-use trinket and potion alongside [[spell:121471]].

#### Shadowblades + Trinket + Pot

```wow-macro
#showtooltip Shadow Blades
/cast Shadow Blades
/use 13
/use 14
/use Light's Potential
```

#### Mouseover Shadowstep

```wow-macro
#showtooltip Shadowstep
/cast [target=mouseover,exists,noharm] Shadowstep
```

This macro is a spammable mouseover [[spell:36554]]. It will not cast
Shadowstep until you mouseover a friendly target, meaning that you can
spam it in scenarios where you need to Shadowstep a friendly target, for example.

2.

### Best Addons

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.1.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.2.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.2.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.2.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.2.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.3.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.3.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.3.4.

##### TankMD

[TankMD](<https://www.curseforge.com/wow/addons/tankmd>) is a new addon 
  that was previously a WeakAura. It allows you to automatically target the tank of the 
  group with your [[spell:57934]] spell without needing a mouseover, focus target, swapping target
  or anything of that sort.

2.4.

#### Specific Addons for Subtlety Rogues

Currently, we feel that there is no need for additional addons to play an
Subtlety Rogue to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1
- **26 Feb. 2026:** Reviewed for Midnight.
- **10 Feb. 2026:** Updated for Midnight.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **29 Apr. 2023:** Page reviewed and updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Changed Shadowstep macro conditionals and reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
