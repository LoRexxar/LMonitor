## 专精概览

Welcome to our Windwalker Monk guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Windwalker Monk in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Windwalker Mythic+ Resources

[NEW! Top Windwalker Talent Builds](<https://raider.io/specs/windwalker-monk/talents>)

[Top Windwalker Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/monk/windwalker>)

[Windwalker Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=monk--windwalker>)

[Popular Windwalker Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=monk--windwalker>)

1.

### Windwalker Monk Overview

The Windwalker specialization is a melee DPS spec that focuses on using
Energy, converting it into Chi, and using that Chi to deal damage.
Windwalker is an incredibly mobile spec that has spent periods of time at the highest level of Raids, Mythic+, and PvP, although rarely more than one at the same time.

Dependable Damage

Windwalker's damage profile changes with your Hero Talent choice.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan

brings a more consistent and high-AoE damage capable profile, while

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials

is more focused on burst damage and low-target cleave. This offers some nice flexibility, and both options can be very useful
in different situations as their raw DPS output is fairly competitive.

Reliable Raider

Windwalker's damage profiles and high mobility make it very well
suited for raids. Windwalker can flexibly adjust to different cooldown periods and swap easily between single target and AoE situations.
While not typically the highest DPS spec, Windwalker's output should be strong enough
to make it worth bringing at all raid difficulties. The main drawbacks of Windwalker are that it lacks damage mitigation
against constant damage and it lacks an immunity or other utility that are useful in Raids.

Strong but Squishy

12.1 is bringing a shift into a more AoE-focused playstyle, maximizing the uses of

[[spell:101546]]

in single target, cleave, and AoE situations. This is likely leading Windwalker to be one of the strongest AoE damage specs in the game. However, the continued struggle with survivability may keep it from quite reaching the “meta” level of the highest Mythic+.

Non-Unique Utility

Windwalker has struggled with utility for a while. At face value,

[[spell:116844]]

is one of the best area-denial spells
in the game,

[[spell:119381]]

is a reliable AoE stun,

[[spell:115078]]

can function as an enrage dispel or
long term CC, the spec can dispel Poison and Disease effects with

[[spell:115450]]

, and it brings a physical damage increasing
debuff with

[[spell:8647]]

. However, most of these tools are for all Monks and not just Windwalker. This makes it hard
to justify bringing a Windwalker "just" for the utility unless it offers the DPS to match or the other two Monk specs are struggling more.

Defensively Dependent

Windwalker only has 2 defensive, with

[[spell:1243287]]

having been turned into a
function of

[[spell:388917]]

, rather than its own defensive ability.

[[spell:388917]]

and

[[spell:122470]]

can be rotated to help mitigate large damage attacks.
Windwalker also has nearly unparalleled mobility, allowing it to get out of dangerous situations
better than most other specs. Windwalker lacks self-healing and damage
mitigation outside of the defensive cooldowns, even with buffs to this in 12.1, which keeps it from being rated higher.

Magnificent Mobility

It is difficult to find a spec or a class that can move faster and farther than a Windwalker. Multiple charges
of

[[spell:109132]]

, combined with

[[spell:449582]]

,

[[spell:116841]]

, and

[[spell:101545]]

, allow Windwalker to move
around the battlefield better than nearly anyone else.

[[spell:101643]]

also allows Windwalker to get back to a point instantly to avoid some mechanics, or simply
get back to dealing damage.

2.

### Windwalker Monk in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 offers no meaningful changes to Windwalker Monk other than the additional gear 
that comes from [Kith'ix](<https://www.wowhead.com/npc=267861>) and the item level boosting Venomcores.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

The main focus of the patch are 2 new pieces of endgame content instead, one for Raid groups, and one
for [Delves](<https://www.icy-veins.com/wow/delves-guide>). Make sure to check out both the information on the new Kith'ix Raid encounter,
as well as the new exciting Labyrinth Mega-Delve!

2.3.

#### Class Changes

Windwalker received no changes for Patch 12.1.5. However, there 
will be changes to the Overall and Raid-based gear recommendations on our 
[gear](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>) page. We also have a list of 
high-value items to spend your first [[item:280562]] on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/monk_ability_fistoffury.jpg>) Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Changes

Season 2 is finally here, and along with the new PvE and PvP endgame content
that will be available August 18th. Blizzard has released a plethora of changes
to the open world, player UI, and existing systems.

2.5.

#### Class Changes

Windwalker received many class changes going from 12.0.7 
into 12.1. Although most of these didn’t have significant 
impacts on <em>how</em> the spec plays, it does move some damage 
around into different sources and from single target into 
AoE. It also brings ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials into 
a much stronger position when compared to previously in Midnight.

- Melee auto-attack damage increased by 30%.
- [[spell:1272694]] damage reduced by 30%.
- [[spell:100784]] damage increased by 50%.
- [[spell:100780]] damage increased by 200%.
- [[spell:451823]] damage increased by 30%.
- [[spell:1272678]] now increases damage during [[spell:1249625]] by 5% (down from 10%).
- [[spell:1261703]] increases Critical Strike damage by 5%/10% (down from 10%/20%).
- [[spell:116670]] healing increased by 25%.
- [[spell:1266719]] healing increased by 25%.
- [[spell:322101]] healing increased by 25%.
- [[spell:443028]] damage reduced by 25%.
- [[spell:442743]] increases the damage of [[spell:113656]] and [[spell:101546]] by 30% (up from 10%).
- [[spell:121817]] increases Stamina by 5%.
- [[spell:388664]] increased from 3% damage reduction to 7% damage reduction.
- [[spell:101546]] buffed by 38%.
- [[spell:152175]] buffed by 30%.
- [[spell:392979]] buffed by 95%.

:::

2.6.

#### Midnight Changes for Windwalker Monk

With Midnight, there are a large amount of changes
to Windwalker Monks, both for the Spec itself as well as changes to the Monk
class in general. The main goal behind these changes is to prune the excessive 
number of buffs and mechanics that you could track but largely ignored and to shift 
damage back into the base abilities.

As a result of these changes, a lot of skills have been pruned or re-designed, and we
have outlined the most impactful changes below, highlighting how they affect your regular
gameplay compared to the version of Windwalker that you might already be used to. Fret not,
however, as the rotational gameplay loop is still very similar to the one that Windwalker
has relied on for years, so even if you are returning to the game with Midnight after a longer break,
you won't feel lost!

2.6.1.

##### Apex Talent: Tigereye Brew

:::details
[[spell:1261703]] is the new Apex talent node and is a callback to 
Windwalker's original damage cooldown, although mostly in name only. As the tooltip 
suggests, during combat you generate stacks that are then spent when you cast [[spell:1249625]] 
to increase your chance to Crit. Outside of combat it stacks back up to 10 very quickly, or 
will maintain its stacks if you are already at or above 10.

Generally you do not have to play around this buff, as you should be naturally using 
[[spell:1249625]] frequently enough to not need to worry about the cap of 20 stacks. The primary 
way that this buff affect's your thought process is that it lessens the incentive to use both 
charges of [[spell:1249625]] back-to-back because the second use will have very few stacks. 
Most of the time, spreading them out is a reasonable choice to make, but sometimes you will still 
want to use them one after the other. This talent can be taken and ignored outside of the more extreme 
min-maxing situations that may be figured out as time goes on.

After the first talent point, the other three are passive damage increases that don't change anything.

:::

2.6.2.

##### Hero Talent Changes

:::details
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials is mostly the same as The War Within, except with the addition of 
[[spell:123904]] as a button you press so that you can then press [[spell:443028]]. 
Activating [[spell:443294]] has also been added to [[spell:1249625]] instead of [[spell:433082]] 
which will take some getting used to.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan has also remained mostly the same, but has seen much of its Hero tree simplified. 
Windwalker no longer has to track how much Energy you've spent in order to maximize your [[spell:450615]], 
[[spell:1272821]] has been simplified and the Shadow buff that provided considerable AoE has been 
moved to a separate talent node with [[spell:1262612]].

:::

2.6.3.

##### Rotational Aspects

For the most part, the core playstyle and priority has changed very little, with the 
design focus being on cutting out excess rather than changing what was already there. 
Because of this, the general playstyle and button pressing remains largely the same 
from The War Within, just with fewer buffs to track or ignore.

2.6.4.

##### Cooldown Adjustments

:::details
The largest changes to Windwalker is that [[spell:137639]] has been replaced with 
[[spell:1249625]], [[spell:123904]] has been moved strictly into the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials 
talent tree, and the large haste buff from [[spell:388661]] has been removed.

[[spell:1249625]] functions almost identically to [[spell:451463]] except it is now a cooldown that you can use. 
Because it has two stacks and a variable cooldown, able to be 60, 70, 80, or 90-seconds, [[spell:1249625]] provides an 
enormous amount of flexibility in how often you use your cooldown. [[spell:1249625]] can pivot between 1-minute, 90-second, 2-minute, 
and 3-minute cooldown usage easily with minor changes to the talents. However, with the loss of things like [[spell:388661]],
Windwalker lacks some of its burst capability that many people will have been used to from The War Within. 
This is largely the new norm for most specs, but it will be quite different at first.

:::

2.6.5.

##### AoE DPS

:::details
With the changes for Midnight, most of Windwalker's AoE damage profile is squeezed into [[spell:113656]] and [[spell:433082]]. 
[[spell:101546]] is very week compared to other abilities and will rarely be used, even in AoE. Because of this, 
Windwalker will likely be considerably weak in AoE, even compared to The War Within.

:::

3.

### Basics of Windwalker Monk Gameplay

Windwalker Monk is a spec about managing resources and abilities with cooldowns at the same time.
The primary concern for us is to use [[spell:100780]] to convert Energy into Chi for
abilities like [[spell:107428]] and [[spell:113656]]
with as little of a delay as possible while not capping your Energy or Chi.

Windwalker will inherently have more resources than you can use on those two abilities,
so we will need to learn how to adequately incorporate enough [[spell:100784]] into
the rotation so as to not overflow with Chi, but not so much that you don't have the Chi
necessary to cast [[spell:107428]] and [[spell:113656]] as soon as they are available.

The Windwalker Monk Mastery, [[spell:115636]], forces us to prepare and
think several steps ahead, since they will want to avoid using [[spell:100784]] or [[spell:100780]]
back to back, rather trying to weave them artfully between other abilities in order to get the
maximum damage possible.

To keep things simple, you can use these three main ideas to condense Windwalker Monk into something a 
bit more digestible.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_healthsphere.jpg>)**Manage Energy and Chi**  
  
    Resources are normally the biggest limiting factor in what abilities you can press and when. 
    You want to make sure you have enough Chi for the hardest hitting abilities like [[spell:107428]]
    and [[spell:113656]] while dumping excess strategically through [[spell:100784]] and 
    [[spell:101546]]. You will want to do this all without repeating the same ability back-to-back so that you continue to benefit from Windwalker’s Mastery and [[spell:196740]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/monk_ability_fistoffury.jpg>) **Keep Abilities on Cooldown**  
   
    Windwalker’s hardest hitting abilities have cooldowns that restrict how often you can use them. 
    You want to use them every chance you can, so making sure you have enough resources to use them 
    when they’re ready is essential.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_roundhousekick.jpg>) **React to Procs**  
  
    Windwalker has several procs that give you additional casts of some abilities, reacting 
    to them quickly while weaving them into your play enough that you can still manage your 
    resources and use abilities when they’re available is what keeps Windwalker from being 
    exactly the same pull after pull.

4.

### How to Gear Up as a Windwalker Monk

While we always recommend simming yourself for ideal results, we do provide a
dedicated Windwalker gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5, added Ascendant Voidstone section and Kithix gear.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Midnight Patch 12.1.5, no changes for Windwalker, added links to new content.
- **25 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated Weapon Enchant recommendation, moved Sapling trinket down to B.
- **25 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated Weapon Enchant recommendation.
- **25 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated Priority to add note about Celestial Conduit and Zenith Stomp.
- **11 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Updated for Midnight Patch 12.1, redid talent build.
- **11 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1, new gear list and updated information on crafting and coins.
- **11 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Midnight Patch 12.1, no changes needed.
- **11 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1, adjusted to new healing potion.
- **11 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Midnight Patch 12.1, clarified stat priority.
- **11 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 2, updated talent builds.
- **11 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 2, updated rotation and priority for Season 2 tier set.
- **11 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 2, updated talent builds.
- **11 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Midnight Patch 12.1, no changes needed.
- **11 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed and updated for Midnight Patch 12.1.
- **11 Aug. 2026 (this page):** Updated for Midnight Patch 12.1, added patch changes, removed S1 things.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7, added Neck/Ring/Belt to Overall and Raid BiS lists.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and Updated for Patch 12.0.7, added timeline for opener.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7, added information on the Omnium Folio.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated and reviewed for Patch 12.0.7.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed and Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Added additional option to craft Loa ring.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1, added WDP/SotW no cancel macro.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Midnight Season 1, added note about Sanguithorn Tea.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Midnight Season 1, moved Haste above Critical Strike.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1, thankfully very little needs to change
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated priority and openers, added more details about choices.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Midnight Season 1. No changes necessary.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1, no changes needed.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1. Added section about March 17 tuning.
- **12 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated with new content and structure for Midnight Season 1.
- **12 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Midnight Season 1, added note about Tier set.
- **12 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **04 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated embellishment recommendations to Darkmoon Sigil: Hunt.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed and updated for Midnight release. Expanded leveling to 90.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed and updated for Midnight release, all new gearlists.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Midnight release, added "Burst" macro, updated to new format.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for Midnight release, all new enchants and consumables.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed and updated for Midnight, removed mentions of the Pre-Patch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight release, brand new Rotation format and added Apex talent block.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for Midnight release, new talent builds and format.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Updated for Midnight, added Tigereye Brew Apex talent.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Midnight release, added Apex notes.
- **26 Feb. 2026 (this page):** Updated for the Midnight release. Updated Performance estimates and added Apex Talent information.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed and updated for Midnight pre-patch, updated leveling talents and path.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed and updated for Midnight pre-patch, very few changes required.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Midnight pre-patch, updated Don't Cancel macro to newer version.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for the Midnight pre-patch, adjusted enchantment and gem recommendations.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed and updated for Midnight Pre-Patch, adjusted stat priority.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight pre-patch, removed S3 mentions, talent changes are done through includes.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for 12.0.1 moving from PTR to Live.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for 12.0.1 moving from PTR to Live.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed and updated for Midnight pre-patch, added new spells, removed old spells.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed and Updated for Midnight Pre-Patch, a surprisingly few amount of changes necessary.
- **10 Feb. 2026 (this page):** Updated for the Midnight Pre-Patch, new format and updates for all the changes with the new expansion.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and updated for Midnight pre-patch, mostly format changes and additional sections.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed and Updated for Midnight Pre-Patch, added section for Hero Talents, no other changes necessary.
- **13 Dec. 2025 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Fixed leveling slider.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for 11.2.7, added FAQ about stat caps.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 11.2.7, added the few FAQs.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7, adjusted Strengths and Weaknesses to new format, added link to Midnight Page.
- **14 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Fixed a typo with SEF usage.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for 11.2.5, no changes needed.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5, added sections on Puzzling Cartel Chips and expanded section on gear upgrades.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for 11.2.5, no changes needed.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for 11.2.5, no changes needed.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for 11.2.5, no changes needed.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 11.2.5, no changes needed.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for 11.2.5, no changes needed.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for 11.2.5, no changes needed.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for 11.2.5, no changes needed
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5, added information about Legion Remix and Turbo Boost.
- **07 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Removed note about not having tier set for Easy choices. No other changes required.
- **21 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Fixed issue with image blocks messing up talents and utility.
- **16 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated trinket rankings for Week 1 tuning.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 11.2, no real changes needed, but I'm sure the talent tree will break.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2, added section on Reshii Wraps, updated gear and trinket lists for Season 3.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 11.2, no real changes needed.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for 11.2, added new healing potion.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 11.2, no changes needed.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2, no real changes needed, Mythic+ tips commented out, split up talent builds even though they're the same.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for 11.2, very few changes needed, all done with the includes.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2, no real changes yet.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 11.2, no real changes needed.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Patch 11.2, no real changes.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2, added section about minimal spec changes.
- **01 Jul. 2025 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Fixed leveling pathing again, added back Hero talent order.
- **22 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for DISC Belt tuning.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 11.1.7, it's not currently broken so no changes needed.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7, added section on DISC belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7, added section on Rotation Assist.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Patch 11.1.7, added information about the rotation assist.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7, added section on rotation assist and DISC belt.
- **22 May 2025 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated corruption recommendation again for Echoing Void not being good.
- **18 May 2025 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated corruption recommendation.
- **10 May 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Finished/remade Dinar section.
- **27 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Added Mythic+ Tips.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 11.1.5, removed "Congratulations" section, I'm sure the leveling order will break for some reason.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated and reviewed for 11.1.5, added Jastor ring to Dinar section and un-commended-out(?) Dinar section.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5, added Corruption section for whenever we get that.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5, no changes needed.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5, no changes needed.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed and Updated for Patch 11.1.5, no changes needed. Mythic+ tips to follow.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5, no changes needed.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5, no changes necessary.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated and reviewed for Patch 11.1.5, added includes for talents.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5, no major changes needed, referenced 14 April changes to ShadoPan.
- **24 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated trinket and BiS lists for trinket tuning.
- **24 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for March 25 tuning changes, added additional talent options to talent builds.
- **17 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-liberation-of-undermine-raid-guide>)):** Added Gallywix and other tips, adjusted talent recommendations to allow for cleave.
- **16 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Added flowchart for crafting.
- **06 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated Circlet gem recommendation.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1, Changed ring enchant.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Updated for Patch 11.1, Changed stat priority.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated for 11.1, commented out dungeon tips for now, changed Oblivion to Pulsar, gave both SP and CotC talent setup
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1, added rotation information for Conduit and Heart windows.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for 11.1, added Conduit talent information.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Updated for Patch 11.1, added Slicing Winds and changed Dance of the Wind.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Patch 11.1, Updated stat priority.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1, added changes and removed old sections.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **22 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Added Mythic+ tips for each dungeon.
- **22 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 (this page):** Added 11.0.5 changes.
- **10 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Fixed an outdated Augment Rune section.
- **09 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed and updated trinket recommendations.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for The War Within Season 1, added Embellishment recommendations.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **27 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Added Delves talent build.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed and updated for The War Within Launch, minor formatting changes.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed and updated for The War Within Launch, totally redone.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed and updated for The War Within Launch, minor word changes.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed and updated for The War Within Launch, updated all recommendations.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed and updated for The War Within Launch, no changes needed.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and updated for The War Within Launch, changed the "includes".
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed and updated for The War Within Launch, changed the "includes".
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed and updated for The War Within Launch, added Hero Talents.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed and updated for The War Within Launch, minor word changes.
- **21 Aug. 2024 (this page):** Reviewed and updated for The War Within Launch, minor word changes.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/windwalker-monk-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Updated with new leveling path for TWW Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed and updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed and updated for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed and updated for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed and updated for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed and updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed and updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed and updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for TWW Pre-Patch
- **17 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed and updated for The War Within pre-patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/windwalker-monk-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/windwalker-monk-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed for Season 4, updated BiS lists, tier information, and added Bullion.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Season 4, no changes necessary.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Season 4, no changes necessary.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Season 4, no changes necessary.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Season 4, no changes necessary.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 4, removed information about S3 tier bonus.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Season 4, no changes necessary.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Season 4, no changes necessary.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Season 4, no changes necessary.
- **22 Apr. 2024 (this page):** Reviewed for Season 4, added information about spending Bullion.
- **28 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Fixed talent tree link
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6, no changes necessary.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6, no changes necessary.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6, no changes necessary.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6, no changes necessary.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6, no changes necessary.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6, no changes necessary.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6, no changes necessary.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6, no changes necessary.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6, no changes necessary.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6, no changes necessary.
- **14 Feb. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Swapped Blue Silken Lining in for best embellishment recommendations.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **30 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated BiS Lists
- **19 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Fixed link problem with Borrowed Time weapon.
- **11 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Sporecloak nerf, embellishment recommendations have been redone.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated and Reviewed for Patch 10.2, updated tier information, BiS lists, and embellishment recommendations.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Updated and Reviewed for Patch 10.2, no changes necessary.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated and Reviewed for Patch 10.2, updated enchant recommendations.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Updated and Reviewed for Patch 10.2, updated talent recommendation.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated and Reviewed for Patch 10.2, updated talent recommendation.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated and Reviewed for Patch 10.2, updated priorities and tier set information.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated and Reviewed for Patch 10.2, updated talent recommendations.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Updated and Reviewed for Patch 10.2, updated talent recommendation.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated and Reviewed for Patch 10.2, updated talent string
- **06 Nov. 2023 (this page):** Updated and Reviewed for Patch 10.2, changed "viability".
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for 10.1.7 and new format.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **01 Sep. 2023 ([Legendaries](<https://www.icy-veins.com/wow/windwalker-monk-best-legendaries-shadowlands>)):** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated and Reviewed for Patch 10.1.5, added information on unique items in Dawn of the Infinites dungeon.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 (this page):** Updated and Reviewed for Patch 10.1.5, added information about 10.1.5 Changes.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed and Updated for Patch 10.1, formatting changes, updated BiS gearsets, and more.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed and updated for Patch 10.1, moved Primordial Stones section and added Shadowflame enchant.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 10.1, no changes necesssary.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed and Updated for Patch 10.1, removed Thundering.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1, moved Rising Sun Kick higher in the priority.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1, no changes needed currently.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 10.1, no changes needed.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Patch 10.1, no changes necessary.
- **01 May 2023 (this page):** Updated for 10.1, added necessary new H1 sections.
- **30 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Updated and Reviewed for Patch 10.1, no changes necessary.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/windwalker-monk-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.7, added Primordial Stones section.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Reviewed for Patch 10.0.7, added section for spec changes.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1, added gear from Vault of the Incarnates.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 1, added notes about the Vault of the Incarnates tier bonuses.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch, added initial dungeon gear.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch, added Thundering information, removed Shadowlands things.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch, removed Shadowlands stuff.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch, added ST and AoE Talents.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch, removed Shadowlands things.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/windwalker-monk-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/windwalker-monk-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/windwalker-monk-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/windwalker-monk-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/windwalker-monk-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/windwalker-monk-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **28 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/windwalker-monk-patch-9-1-changes-analysis>)):** Added information on new Legendaries and Covenant recommendations.
- **17 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/windwalker-monk-patch-9-1-changes-analysis>)):** Page created.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **14 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-the-eternal-palace-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **22 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-the-eternal-palace-raid-guide>)):** Updated some encounter talents and tips.
- **16 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-the-eternal-palace-raid-guide>)):** Updated guide to mention the presence of Aberrations.
- **10 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **17 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-crucible-of-storms-raid-guide>)):** Guide updated with further tips.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-uldir-raid-guide>)):** Added content.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Windwalker Monk leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Monk leveling guide](<https://www.icy-veins.com/wow/monk-leveling-guide>).

1.

### Windwalker Monk Leveling Guide for Midnight

Windwalker is often considered to be one of the best specs to level with in World of Warcraft. 
The mixture of nearly unparalleled mobility, ample control abilities, and an (often) instant-kill spell 
in [[spell:322109]] makes Windwalker very easy to level.

Windwalkers are able to group up many targets, stun them with [[spell:119381]], and then AoE them down.
Alternatively you can simply focus on a single target and use a spell like [[spell:122470]]
to redirect damage back to that target. Many people find that Windwalker leveling is a
flexible and easy process compared to some other specs.

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level but two secondary stats on it
instead of one.

When using Heirloom items, we recommend using those with Critical Strike
and Haste, as they will slightly improve the gameplay flow while leveling.

1.2.

#### Useful Leveling Consumables for Midnight

When Leveling up from 80-90 in the Midnight Expansion in particular, there are a lot of
consumables that can help ease the process, aside from the "regular" PvE
consumables mentioned further below.

- [[item:132516]] — Massive movement speed boost that works when
  Mounts do not, and much faster than ground mounts.
- [[item:109076]] — Lets you glide off of ledges and cover vast
  distances quickly.
- [[item:168412]] — Do not forget this Mount Equipment to
  make your mounts faster on the ground.
- [[item:172063]] — An incredible amount of movement speed from a Food.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Windwalker Level 80 Midnight Leveling
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzMD2GGYmZ2mZGAAAAAAAAAAAYZYEmxywAmxwMjBzGmBLzEAwmZ2mZgxMAA2AAmlmZmZBYYgZAwYxMgBA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzMDYMGmZmtZmBAAAAAAAAAAAWGGhZYYAzYYmZmhZbYGsMTAAbmZbMjxYGAAbAwsMLNzMzCwAYmBgxyMDYAD"
}
```
:::

:::details 来源计算器编码
```
#NE-pJNTIzvoSZYYAuYPNE4hCz4W9lkcs12GnGI-pMoSAATBCERex4qaSldNo1q7TJcV0hE-AAAA-HoIBRow4YhpJAA-*
```

:::

2.1.

#### War Mode Talents for Leveling

In this section, we will rank the PvP talents best for
leveling and doing solo / small group PvE content. Below is a ranking of 
Windwalker Monk-specific PvE talents.

1. [[spell:287503]] is very useful for a small added burst as you go
   between targets.
2. [[spell:342928]] is very useful for survivability and for added
   damage.
3. [[spell:287681]] is an incredibly strong PvP talent that makes pulling
   large groups significantly easier.

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider 
to select your level, and watch as the leveling rotation grows with each 
level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

The Windwalker Monk rotation is based on a priority system. Use the highest
ability on the list as soon as it is available. This list assumes you have access
to many talents, so simply remove the ones you don't have. It is also set up for
AoE pulls, as Windwalker is very capable of doing so.

1. **等级 10 起：**[[spell:322109]]
2. **等级 29 起：**[[spell:152175]]
3. **等级 29 起：**[[spell:392983]]
4. **等级 11 起：**[[spell:113656]]
5. **等级 11 起：**[[spell:107428]]
6. **等级 2 起：**[[spell:100784]]
7. **等级 7 起：**[[spell:101546]]
8. **等级 1 起：**[[spell:100780]]

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Updated for Midnight Patch 12.1, redid talent build.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed and Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed and updated for Midnight release. Expanded leveling to 90.
- **10 Feb. 2026:** Reviewed and updated for Midnight pre-patch, updated leveling talents and path.
- **13 Dec. 2025:** Fixed leveling slider.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for 11.2.5, no changes needed.
- **04 Aug. 2025:** Reviewed for Patch 11.2, no real changes needed, but I'm sure the talent tree will break.
- **01 Jul. 2025:** Fixed leveling pathing again, added back Hero talent order.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7, it's not currently broken so no changes needed.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5, removed "Congratulations" section, I'm sure the leveling order will break for some reason.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed and updated for The War Within Launch, minor formatting changes.
- **23 Jul. 2024:** Updated with new leveling path for TWW Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Windwalker Monk in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Windwalker Monk

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Windwalker Monks are a melee DPS specialization that is viable in all
situations, providing strong priority and AoE damage, as well as having
smooth and relatively easy to execute rotations.

Throughout the fight, you will need to manage Energy and Chi, your two
resources in order to get as many uses of your abilities as possible. You will
have to make sure not to cap and waste either of these resources while also
keeping enough in store to allow immediate use of your abilities, as delaying
some can cost you considerable DPS.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_healthsphere.jpg>)
  **Manage Energy and Chi**  
  
    Resources are normally the biggest limiting factor in what abilities you can press and when. 
    You want to make sure you have enough Chi for the hardest hitting abilities like [[spell:107428]]
    and [[spell:113656]] while dumping excess strategically through [[spell:100784]] and 
    [[spell:101546]]. You will want to do this all without repeating the same ability back-to-back so that you continue to benefit from Windwalker’s Mastery and [[spell:196740]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/monk_ability_fistoffury.jpg>) **Keep Abilities on Cooldown**  
   Windwalker’s hardest hitting abilities have cooldowns that restrict how often you can use them. You want to use them every chance you can, so making sure you have enough resources to use them when they’re ready is essential.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_roundhousekick.jpg>) **React to Procs**  
  
    Windwalker has several procs that give you additional casts of some abilities, reacting to them quickly while weaving them into your play enough that you can still manage your resources and use abilities when they’re available is what keeps Windwalker from being exactly the same pull after pull.

2.

### Beginner's Guide to Windwalker Monk in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan   Single-Target Talents

2.1.

#### Beginner Single-Target Talents for Windwalker Monk

This build is ideal for beginners for pure single-target situations.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AgZZWamZmFAMwMDAjlBwA+A"
}
```
:::

:::details 来源计算器编码
```
#NE-GHIJNTpuzSZnQRZBMchh5ZGU9Fkks12G3oG-pBCEMNToAAScmnRVv8WCxST3HYIZbiCS-AAA-FGUYcgoYhpJQCA-*
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan   AoE Talents

2.2.

#### Beginner Mythic+ and Delves Talents for Windwalker Monk

This is our recommended build for beginners in AoE scenarios. This works well for AoE
Fights in Raids, as well as Mythic+ and Delves.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMYMYbmZ2mxAAAAAAAAAAAALDzEmhhBMjhZmZGmthZYWmJAgFzsNGGzMDAgNAYWmlmZmZBYYgZGAYZMgBM"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzEIMSZnQRdhBMchh5ZGU9Fkks12G3oG-pBCEMoAASTcmnRUVvy8C1ST3XI5arhC-AAAA-FGUYcgoYhpJQCA-*
```

:::

### Windwalker Monk   Basic Rotation

2.3.

#### Single-Target Rotation

The single-target Windwalker Monk rotation is based on a priority system.

1. [[spell:322109]]
2. [[spell:152175]]
3. [[spell:392983]]
4. [[spell:113656]]
5. [[spell:467307]]
6. [[spell:107428]]
7. [[spell:100784]]
8. [[spell:100780]]

2.4.

#### AoE Rotation

Against multiple enemies, the rotation is also based on a priority system.

1. [[spell:322109]]
2. [[spell:152175]]
3. [[spell:392983]]
4. [[spell:113656]]
5. [[spell:467307]]
6. [[spell:107428]]
7. [[spell:100784]]
8. [[spell:101546]]
9. [[spell:100780]]

2.4.1.

##### Apex Talent: ![Tigereye Brew Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_tigereyebrandy.jpg>) Tigereye Brew

[[spell:1261703]] is the new Apex talent node and is a callback to 
Windwalker's original damage cooldown, although mostly in name only. As the tooltip 
suggests, during combat you generate stacks that are then spent when you cast [[spell:1249625]] 
to increase your chance to Crit. Outside of combat it stacks back up to 10 very quickly, or 
will maintain its stacks if you are already at or above 10.

Generally you do not have to play around this buff, as you should be naturally using 
[[spell:1249625]] frequently enough to not need to worry about the cap of 20 stacks. The primary 
way that this buff affects your thought process is that it lessens the incentive to use both 
charges of [[spell:1249625]] back-to-back because the second use will have very few stacks. 
Most of the time, spreading them out is a reasonable choice to make, but sometimes you will still 
want to use them one after the other. This talent can be taken and ignored outside of the more extreme 
min-maxing situations that may be figured out as time goes on.

2.4.2.

##### Season 2 Tier Set

Windwalker's Season 2 Tier set bonuses: 
[[spell:1296621]] and [[spell:1297033]] are very strong and cause you to want to use [[spell:101546]] after [[spell:113656]].

### Windwalker Monk   Defensive Spells

2.5.

#### Defensive Spells for Windwalker Monk

[[spell:122470]] is the only baseline defensive ability. This is often
used as an offensive ability due to the damage being redirected back to your target.
However, until you know you can comfortably use this offensively, it is always
recommended that you only use it defensively. Very frequently, using it defensively
is very similar to using it offensively.

[[spell:388917]] while active, reduce the damage you take from
all sources while also increasing your maximum health.

### Windwalker Monk   Stat Priority

2.6.

#### Stat Priority for Windwalker Monk in Midnight

The general stat priority for a Windwalker
Monk is seen below. This is very much a rough guideline and is
designed for players who do not wish to sim their character. If you are simming
your character, please disregard this stat priority completely and follow your
sim! For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>).

Agility

Haste

Critical Strike

Mastery

Versatility

### Blizzard   Combat Rotation Assistant

2.7.

#### Combat Rotation Assistant for Windwalker Monk

If you would like a more convenient option when first gaining the feel for the
Windwalker Monk rotation, there is also a [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) available from
the spellbook. This assistant can perform a simplified version of the damage rotation
and only requires you to use a single keybind. However, making use of this assistant
comes at the cost of an increased cooldown between abilities on every press. This results 
in a 15-30% DPS loss in simulations but may still be a net improvement if you are 
inexperienced with a "fully manual" playstyle.

Note, however, that even with this assistant's help, you **must** still use
your defensive abilities manually, as well as your key offensive cooldown of
[[spell:123904]].

Sadly, the otherwise-rosy portrayal of the combat assistant above assumes that
it is working as it should. Unfortunately, at this time the assistant is not capable
of pausing during a channeled ability like [[spell:113656]]. This means that it is 
recommended to use the following Macro as a button in place of just dragging the button 
from your spellbook to your bars.

```wow-macro
#showtooltip
/stopmacro [channeling]
/cast Single-Button Assistant
```

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Reviewed and updated for Midnight Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **12 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release, added Apex notes.
- **10 Feb. 2026:** Reviewed and Updated for Midnight Pre-Patch, a surprisingly few amount of changes necessary.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for 11.2.5, no changes needed
- **07 Sep. 2025:** Removed note about not having tier set for Easy choices. No other changes required.
- **04 Aug. 2025:** Updated for Patch 11.2, no real changes.
- **15 Jun. 2025:** Updated for Patch 11.1.7, added information about the rotation assist.
- **21 Apr. 2025:** Updated and reviewed for Patch 11.1.5, added includes for talents.
- **24 Feb. 2025:** Updated for Patch 11.1, Updated stat priority.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Reviewed and updated for The War Within Launch, minor word changes.
- **23 Jul. 2024:** Reviewed and updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, no changes necessary.
- **28 Mar. 2024:** Fixed talent tree link
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, no changes necessary.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated and Reviewed for Patch 10.2, updated talent string
- **04 Sep. 2023:** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **01 May 2023:** Reviewed for Patch 10.1, no changes necessary.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Windwalker Monk in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Windwalker Monk

In Season 2, thanks to a few recent changes, Windwalker finally has a bit more 
talent variation than before. The main differences now depend on what Hero talents you're playing.

- **Single-Target -** Both hero talents are very similar and it is 
    generally recommended to use the one that you are most comfortable with. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan 
    likely has a slightly lower maximum, but is significantly simpler and less punishing to play. 
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials has a slightly higher ceiling but is noticeably more difficult 
    to use, and mistakes tend to be more punishing.
- **AoE -** Similar to single target, both hero talents are very similar in strength and 
    the players performance and comfort can make the difference between the two. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan should 
    be a safer pick for newer players or for people playing in PUG groups where careful planning isn't as 
    common. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials has the best chance to shine in groups where things are planned 
    in advance to maximize everyone's performance, like in a high-level or MDI-type situation.

In pure single target scenarios, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan is ahead of
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials, while also doing a decent 
amount of cleave damage, or easily swapping into a few more cleave-focused talents. Due to this, 
we recommend playing it on all boss fights this tier. In AoE encounters,
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan is ahead due to its more flexible cooldowns, 
simpler gameplay loop, and AOE damage.

**Quick Start Import Codes:**

:::talents Windwalker Raids - Shado-Pan
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GmhlZGbzAAAAAAAAAAAAsMMCzwwAmZGmZmZY2GmhZZmAAWMz2MjZmZmBAwGAMLzSzMzsAgBmZAYsMAGwFA"
}
```
:::

:::talents Windwalker Mythic+ - Conduit of the Celestials
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYEmhhBMjhZmZGmNMDzyMBAswsxMmZmZAAsYmlZZMBAAmZGAzAMWGDYmZ2M"
}
```
:::

:::talents Windwalker Delves - Conduit of the Celestials
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYEmhhBMjhZmZGmNMDzyMBAswsxMmZmZAAsYmlZZMBAAmZGAzAMWGDYmZ2M"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Shado-Pan

Raid

recommended

Mythic+

weekly-keys

Delves

Conduit of the Celestials

Raid

advanced

Mythic+

high-keys

Delves

recommended

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Raid Talents

This **single-target** build is very straightforward, and both cleave and AoE are totally ignored here.
Many raid fights are either wholly or predominantly single-target. In many
cases, even if a fight has AoE moments like add spawns, if those add spawns are
not especially important or dangerous, playing a single-target build can be
optimal.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Mythic+ Talents

**Mythic+** builds are optimized for completing Mythic+ dungeons as
quickly as possible. **Open-World and Delve** builds are often variants of this, as
these disciplines also contain a healthy mixture of single-target and AoE, both of which
ought to be optimized.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan Delve Talents

**[Delves](<https://www.icy-veins.com/wow/delves-guide>)** builds are generally the same damage profile as Mythic+,
so the talent build is the same.

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials Raid Talents

**Single-Target** builds are straightforward. They do as much
damage to a single target as possible. Cleave and AoE are totally ignored here.
Many raid fights are either wholly or predominantly single-target. In many
cases, even if a fight has AoE moments like add spawns, if those add spawns are
not especially important or dangerous, playing a single-target build can be
optimal, even on such fights.

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials Mythic+ Talents

**Mythic+** builds are optimized for completing Mythic+ dungeons as
quickly as possible. **Open-World and Delve** builds are often variants of this, as
these disciplines also contain a healthy mixture of single-target and AoE, both of which
ought to be optimized

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials Delve Talents

**[Delves](<https://www.icy-veins.com/wow/delves-guide>)** builds are generally the same damage profile as Mythic+,
so the talent build is the same.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GmhlZGbzAAAAAAAAAAAAsMMCzwwAmZGmZmZY2GmhZZmAAWMz2MjZmZmBAwGAMLzSzMzsAgBmZAYsMAGwFA"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTUpzIMSZnQRZdBMchh5ZGU9Fkks12G3oG-pBCEMNToAAScmnRVv8WCxST3HY4IZrRCS-AA-FGUYcgoYhpJQCA-*
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYAMGbzMz2MAAAAAAAAAAAALDzEmhhBMjhZmZGmNMDzyMBAsYmtZmxMzMDAgNAYWmlmZmZBgZgZGAYZMgBM"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzEIMSZnQRdhBMchh5ZGU9lkct12G3oG-pBCEMoAASTcimnORUVv8CSWC1ST3XYL-AAAA-FGUYcgoYhpJQCA-*
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYAMGbzMz2MAAAAAAAAAAAALDzEmhhBMjhZmZGmNMDzyMBAsYmtZmxMzMDAgNAYWmlmZmZBgZgZGAYZMgBM"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzEIMSZnQRdhBMchh5ZGU9lkct12G3oG-pBCEMoAASTcimnORUVv8CSWC1ST3XYL-AAAA-FGUYcgoYhpJQCA-*
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYM2GmhlZmZbGAAAAAAAAAAAglhRYGGGwMzwMzMDz2wMMLzEAwiZ2mZMjZmBAwiZWmlxEAAADgZAGLDgZmZxFA"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTUpzIMSZnQRZdBMchh5ZGU9Fkks12G3oG-pBCEMNToAAScmnRUVv8CxST3HY4IZrRCS-AA-EMQowIRZhpBQAC-*
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYEmhhBMjhZmZGmNMDzyMBAswsxMmZmZAAsYmlZZMBAAmZGAzAMWGDYmZ2M"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzIMoouwDSZnYBEchh5Zu2qabj7LJp2I-pBCEMoAASTimnORUVv8WaAxSTXI5KbL-AAAA-EMQowIRZhpJQAC-*
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZYEmhhBMjhZmZGmNMDzyMBAswsxMmZmZAAsYmlZZMBAAmZGAzAMWGDYmZ2M"
}
```
:::

:::details 来源计算器编码
```
#NE-JNTpzIMoouwDSZnYBEchh5Zu2qabj7LJp2I-pBCEMoAASTimnORUVv8WaAxSTXI5KbL-AAAA-EMQowIRZhpJQAC-*
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio was a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend you pick the following bonuses, but as you
can freely switch between them at any time, feel free to experiment with other options
yourself if you feel you do not get enough mileage out of the recommended options:

- Row 1:[[spell:1279599]] for all content
- Row 2:[[spell:1279604]]
- Row 3:[[spell:1287555]]
- Row 4:[[spell:1279609]] as a default, best to sim your character for other options
- Row 5:[[spell:1279614]]

3.

### Apex Talent: ![Tigereye Brew Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_tigereyebrandy.jpg>) Tigereye Brew

Midnight introduces new Apex Talents, unlocked between Level 80 and 90. Windwalker Monk gets:

1. [[spell:1261703]]
2. [[spell:1261844]]
3. [[spell:1261849]]

[[spell:1261703]] is the new Apex talent node and is a callback to 
Windwalker's original damage cooldown, although mostly in name only. As the tooltip 
suggests, during combat you generate stacks that are then spent when you cast [[spell:1249625]] 
to increase your chance to Crit. Outside of combat it stacks back up to 10 very quickly, or 
will maintain its stacks if you are already at or above 10.

Generally you do not have to play around this buff, as you should be naturally using 
[[spell:1249625]] frequently enough to not need to worry about the cap of 20 stacks. The primary 
way that this buff affect's your thought process is that it lessens the incentive to use both 
charges of [[spell:1249625]] back-to-back because the second use will have very few stacks. 
Most of the time, spreading them out is a reasonable choice to make, but sometimes you will still 
want to use them one after the other. This talent can be taken and ignored outside of the more extreme 
min-maxing situations that may be figured out as time goes on.

After the first talent point, the other three are passive damage increases that don't change anything.

4.

### Hero Talents

Windwalker gets to pick between two distinct Hero Talent choices:
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials. These are available at level 71 
and are mutually exclusive.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan can be described as "baseline" Windwalker, with no additional buttons 
or mechanics that you need to worry about. This Hero Talent tree is focused around 
increasing the power of the base kit that Windwalker has to work with.

The tree does add the damage source of [[spell:450615]], which are 
additional strikes of damage when you cast abilities like [[spell:113656]] or 
[[spell:107428]], and [[spell:101546]] during [[spell:1249625]]. These are 
further augmented into AoE damage with [[spell:1262612]] and become a 
decently large source of additional damage.

This Hero Talent tree is recommended for beginners, as none of the talents or [[spell:450615]]
change how the spec is played at all.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials leans heavily into the lore of Monks and Windwalker, 
leveraging the assistance of the August Celestials to provide additional power. This Hero Talent 
tree comes with the familiar spell of [[spell:123904]] and [[spell:443028]] and is 
generally considered to be noticeably more complex and different from ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan.

Playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials revolves around managing the windows of [[spell:443294]] 
that are generated when [[spell:1249625]], [[spell:443028]], [[spell:392983]], or [[spell:152175]] 
are used. These buff windows dramatically increase the speed that the spec plays, with faster channeling of [[spell:113656]], 
and dramatically reduced cooldown times on abilities. Learning how to balance and manage these buff windows is essential 
to maximizing the power of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials and contribute to the belief that it is both more complicated and faster 
than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan.

5.

### PvP Talents (War Mode)

War Mode offers several benefits for you in the open world.

- PvP talents enabled in the outdoor world.
- At least 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP, and
the possibility of being "ganked" while leveling or doing World Quests exists.

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of all PvP Talents for
Windwalker Monk

1. [[spell:357633]] grants you and allies affected by
   [[spell:157411]] an effect that makes them immune to slow and snare
   effects once every 30 seconds.
2. [[spell:342928]] doubles the healing of [[spell:322101]] and
   provides an extra Chi when used.
3. [[spell:201769]] increases the range of your [[spell:116095]]
   to 10 yards.
4. [[spell:287503]] grants you 30% Haste upon attacking a new target with
   [[spell:100780]]. This can happen once every 30 seconds per target.
5. [[spell:233759]] grants you an additional spell which prevents
   your target from using their weapons for 6 seconds.
6. [[spell:287681]] causes [[spell:113656]] to deal full damage to all
   targets hit and reduce their movement speed by 90%. It additionally grants you
   100% Parry chance during the channel.
7. [[spell:201372]] causes [[spell:101545]] to increase
   the movement speed of allies in its path by 30%. This applies to yourself.
   It also increases Flying Serpent Kick's cooldown by 10 seconds.
8. [[spell:450432]] reduces the cooldown of [[spell:322109]]
   by 60 seconds if you kill a player with it.
9. [[spell:247483]] generates stacks of Tigereye Brew whenever you
   spend 3 Chi. Using these stacks makes your attacks bypass armor but deal
   slightly less damage for 2 seconds per stack.

[[spell:287681]], [[spell:342928]], and
[[spell:287503]] are the three talents that will benefit you
the most when doing PvE content. They grant you sustainability, as well as
survivability.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Updated for Midnight Season 2, updated talent builds.
- **15 Jun. 2026:** Updated for Patch 12.0.7, added information on the Omnium Folio.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1. No changes necessary.
- **26 Feb. 2026:** Updated for Midnight release, new talent builds and format.
- **10 Feb. 2026:** Updated for 12.0.1 moving from PTR to Live.
- **19 Jan. 2026:** Reviewed and Updated for Midnight Pre-Patch, added section for Hero Talents, no other changes necessary.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for 11.2.5, no changes needed.
- **04 Aug. 2025:** Reviewed for Patch 11.2, no real changes yet.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5, no changes necessary.
- **24 Mar. 2025:** Updated for March 25 tuning changes, added additional talent options to talent builds.
- **24 Feb. 2025:** Updated for 11.1, added Conduit talent information.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **27 Aug. 2024:** Added Delves talent build.
- **21 Aug. 2024:** Reviewed and updated for The War Within Launch, changed the "includes".
- **23 Jul. 2024:** Reviewed and updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, no changes necessary.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, no changes necessary.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated and Reviewed for Patch 10.2, updated talent recommendations.
- **04 Sep. 2023:** Updated for 10.1.7 and new format.
- **10 Jul. 2023:** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **01 May 2023:** Reviewed for Patch 10.1, no changes needed currently.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch, added ST and AoE Talents.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Windwalker Monk in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Windwalker Monk Gameplay and Rotation Guide

Welcome to our Rotation page for Windwalker Monks. On this page,
you will find everything you need to know about actually playing the spec in
Raiding and Mythic+ scenarios.

Each of the sections below explain the rotation for different environments.
Click the boxes to switch to the desired situation.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan

Single-Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Multi-Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials

Single-Target

Multi-Target

Active Talents

Passive Talents

[[spell:392983]]

[[spell:152175]]

[[spell:433082]]

[[spell:1250042]]

[[spell:451524]]

[[spell:325201]]

[[spell:1250566]]

[[spell:1249832]]

[[spell:392982]]

### Windwalker Monk Single-Target Priority

Windwalker Monk plays around a priority list, not a set rotation. Following this priority list, you'll be focused on juggling ability cooldowns, resources, and [[spell:115636]] based on an order of power. This means with each GCD we go top to bottom on a list, and press the button with the current highest value as long as it is not the same as the previous ability.

**适用条件：Shado-Pan（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan focuses most of its damage in an even spread of most abilities, relying on consistent pressure. With the changes for Midnight, the main functional change for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan is that you no longer have to track your Energy spent or additional buffs, so the priority is played more consistently and smoothly.

**适用条件：Conduit of the Celestials（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials focuses on managing the additional abilities of [[spell:123904]] and [[spell:443028]], plus the effects from the [[spell:443294]] buff. This buff dramatically increases how quickly your abilities come off of cooldown and how quickly you channel [[spell:113656]] to load as much damage into the cooldown window as you can.

---

1. **适用条件：Shado-Pan（启用）。** Cast [[spell:152175]] during its grace period
2. **适用条件：Conduit of the Celestials（启用）。** Cast [[spell:152175]] during its grace period AND the cooldown of [[spell:123904]] is longer than 10 seconds
3. Cast [[spell:1272694]] if low on Chi OR [[spell:1249625]] is about to run out OR if channeling [[spell:443028]]
4. [[spell:443028]] if if no active [[spell:443294]] from [[spell:152175]] or [[spell:392983]]. Cancel with next GCD.
5. **适用条件：Conduit of the Celestials（启用）。** Cast [[spell:113656]] if [[spell:443294]] has less than 1 second remaining.
6. Cast [[spell:100780]] with: less than 4 Chi, less than 2 stacks of [[spell:116768]], about to cap energy, AND not during [[spell:1249625]]
7. **适用条件：Conduit of the Celestials（启用）。** Cast [[spell:443028]]
8. **适用条件：Conduit of the Celestials（启用）。** Cast [[spell:123904]]
9. Cast [[spell:113656]]
10. **适用条件：Whirling Dragon Punch（启用）；Shado-Pan（启用）。** Cast [[spell:152175]]
11. **适用条件：Strike of the Windlord（启用）。** Cast [[spell:392983]]
12. **适用条件：Whirling Dragon Punch（启用）；Conduit of the Celestials（启用）。** Cast [[spell:152175]] if the cooldown of [[spell:123904]] is longer than 10 seconds
13. Cast [[spell:100784]] if not enough Chi to cast [[spell:113656]]
14. **适用条件：Rushing Wind Kick（启用）。** Cast [[spell:1250566]]
15. **适用条件：Dance of Chi-Ji（启用）；Revolving Whirl（启用）。** Cast [[spell:101546]] with [[spell:286585]] AND Season 2 4-piece bonus, [[spell:1297033]]
16. Cast [[spell:107428]] with [[spell:2825]] AND without [[spell:325201]]
17. **适用条件：Conduit of the Celestials（启用）。** Cast [[spell:101546]] with Season 2 4-piece bonus, [[spell:1297033]]
18. Cast [[spell:107428]]
19. Cast [[spell:100784]] with 2x [[spell:116768]] stacks
20. Cast [[spell:100784]] with [[spell:116768]] OR [[spell:1249625]] active
21. **适用条件：Shado-Pan（启用）。** Cast [[spell:101546]] with [[spell:1249625]] AND more than 4 Chi
22. **适用条件：Dance of Chi-Ji（启用）；Revolving Whirl（启用）。** Cast [[spell:101546]] with [[spell:1249625]] AND a [[spell:325201]] proc
23. Cast [[spell:322109]]
24. Cast [[spell:100780]] if any of the above are available and you do not have enough Chi
25. Cast [[spell:100784]] with 1x [[spell:116768]] stack
26. **适用条件：Dance of Chi-Ji（启用）；Revolving Whirl（启用）。** Cast [[spell:101546]] with a [[spell:325201]] proc
27. **适用条件：Slicing Winds（启用）。** Cast [[spell:433082]]
28. Cast [[spell:100780]] without overcapping Chi
29. Cast [[spell:100784]]

### Windwalker Monk Multi-Target Priority

Windwalker Monk plays around a priority list, not a set rotation. Following this priority list, you'll be focused on juggling both ability cooldowns and resources based on an order of power. This means with each GCD we go top to bottom on a list, and press the button with the current highest value as long as it is not a repeat of the previous ability.

**适用条件：Shado-Pan（启用）。** The transition to AoE for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan is rather simple with very minor changes to the priority. Much of the increased AoE damage comes naturally from [[spell:1262612]] as it splashes Nature damage to all enemies around you.

**适用条件：Conduit of the Celestials（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials changes very little when shifting to AoE damage, as most of the damage comes from the additional casts of [[spell:113656]] that you get with the cooldown reduction brought by [[spell:443294]].

---

This multi-target priority requires at least 2 targets.

1. **适用条件：Conduit of the Celestials（启用）。** Cast [[spell:113656]] if [[spell:443294]] has less than 1 second remaining.
2. **适用条件：Whirling Dragon Punch（启用）；Shado-Pan（启用）。** Cast [[spell:152175]]
3. **适用条件：Whirling Dragon Punch（启用）；Conduit of the Celestials（启用）。** Cast [[spell:152175]] if the cooldown of [[spell:123904]] is longer than 10 seconds
4. Cast [[spell:1272694]] if low on Chi OR [[spell:1249625]] is about to run out OR if channeling [[spell:443028]]
5. [[spell:443028]] if if no active [[spell:443294]] from [[spell:152175]] or [[spell:392983]]. Cancel with next GCD.
6. Cast [[spell:100780]] if not enough Chi to cast [[spell:113656]]
7. Cast [[spell:113656]]
8. Cast [[spell:101546]] with Season 2 4-piece bonus, [[spell:1297033]]
9. Cast [[spell:100780]] with: less than 4 Chi, less than 2 stacks of [[spell:116768]], about to cap energy, AND not during [[spell:1249625]]
10. Cast [[spell:107428]] to enable [[spell:152175]]
11. **适用条件：Rushing Wind Kick（启用）。** Cast [[spell:1250566]] without [[spell:1297033]] active
12. **适用条件：Conduit of the Celestials（启用）。** Cast [[spell:107428]] with [[spell:443294]] active AND no [[spell:1297033]]
13. **适用条件：Shado-Pan（启用）。** Cast [[spell:101546]] with [[spell:1249625]] AND at least 5 targets
14. Cast [[spell:107428]] without [[spell:1297033]] AND [[spell:2825]] OR [[spell:1249625]]
15. **适用条件：Obsidian Spiral（启用）。** Cast [[spell:100784]] during [[spell:1249625]] AND [[spell:107428]] on cooldown
16. Cast [[spell:101546]]
17. Cast [[spell:100784]] with [[spell:116768]]
18. Cast [[spell:100780]] if any of the above are available and you do not have enough Chi
19. **适用条件：Shadowboxing Treads（启用）。** Cast [[spell:100784]]
20. Cast [[spell:107428]]
21. **适用条件：Shadowboxing Treads（未启用）。** Cast [[spell:100784]]

### Windwalker Monk Opener

**适用条件：Conduit of the Celestials（启用）；Slicing Winds（启用）。**

[[spell:433082]]

[[spell:100780]]

[[item:193701@JAAIAAQkCYHKvbRLfA]]

**适用条件：Conduit of the Celestials（启用）。**

[[spell:123904]]

[[spell:1249625]]

[[spell:1249625]]

[[spell:1272694]]

**适用条件：Conduit of the Celestials（启用）；Strike of the Windlord（启用）。**

[[spell:392983]]

[[spell:113656]]

[[spell:107428]]

[[spell:113656]]

**适用条件：Whirling Dragon Punch（启用）。**

[[spell:152175]]

**适用条件：Shado-Pan（启用）；Strike of the Windlord（启用）。**

[[spell:392983]]

**适用条件：Shado-Pan（启用）；Slicing Winds（启用）。**

[[spell:433082]]

**适用条件：Shado-Pan（启用）。** The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan opener aims to get stronger abilities like [[spell:113656]] and [[spell:107428]] on cooldown as quickly as possible so that you can use it more often. Generally, this opener follows the priority closer than openers often do.

**适用条件：Conduit of the Celestials（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials runs a very prescribed sequence of abilities that tends to fall toward the middle of the length of most openers. The goal for this opener is to maximize the uptime of [[spell:443294]] while using the hardest hitting abilities and as often as possible.

**适用条件：Conduit of the Celestials（启用）。** This opener also doubles as a guide for maximizing each time these cooldowns are available and should be followed basically any time you use  [[spell:123904]] and [[spell:443028]]. The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials opener is longer and more planned out than Windwalker is often used to, but with the different overlapping mechanics, it is what is necessary to minimize waste and maximize potential.

Like any opener, for Windwalker, if you are starting the pull with more than the normal Chi, then you can cut out a [[spell:100780]] as necessary.

---

**适用条件：Shado-Pan（启用）。** <center>**This opener is the same for single target and AoE.**</center>

**适用条件：Conduit of the Celestials（启用）。** <center>**This opener is the same for single target and AoE.**</center>

1. **适用条件：Conduit of the Celestials（启用）；Slicing Winds（启用）。** Precast [[spell:433082]] before combat
2. Cast [[spell:100780]]
3. **适用条件：Conduit of the Celestials（启用）。** Cast [[spell:123904]]
4. Cast [[spell:1249625]] with potions, racials and trinkets (stat buffs go before [[spell:1249625]] to buff [[spell:1272694]])
5. **适用条件：Conduit of the Celestials（启用）；Strike of the Windlord（启用）。** Cast [[spell:392983]]
6. Cast [[spell:113656]]
7. Cast [[spell:107428]]
8. Cast [[spell:113656]] if [[spell:107428]] reset its cooldown
9. **适用条件：Whirling Dragon Punch（启用）。** Cast [[spell:152175]]
10. **适用条件：Shado-Pan（启用）；Strike of the Windlord（启用）。** Cast [[spell:392983]]
11. **适用条件：Shado-Pan（启用）；Slicing Winds（启用）。** Cast [[spell:433082]]
12. Continue with normal priority.

**适用条件：Conduit of the Celestials（启用）。** Make sure to not cast your [[spell:443028]] too early so you don't overlap the [[spell:443294]] buff you get with the one that you got from [[spell:392983]] or [[spell:152175]]. Delaying [[spell:443028]] is not much of an issue wince you'll likely send the second charge of [[spell:1249625]] right after the first one wears off.

2.

### Midnight Season 2 Tier Set

Windwalker's Season 2 Tier set bonuses: 
[[spell:1296621]] and [[spell:1297033]] are incredibly strong and should be aimed for as quickly as possible. Rotationally, once you have the 4-piece bonus, you’ll want to make sure to use [[spell:101546]] after you finish casting [[spell:113656]] and before you would cast [[spell:107428]] anytime there is more than 1 target.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Windwalker Monk
kit, we have compiled a more detailed explanation on individual parts of our rotation, from
important rotational mechanics that you need to pay attention to, to cooldowns and how to use them, so you can
reach your full potential when playing Windwalker.

### Manage Energy and Chi

3.1.

#### Manage Energy and Chi

Outside of big Haste cooldowns,
Windwalker's damage is restricted by how many resources we can
generate and spend. This means that sitting at the Energy cap
or generating more Chi than you have space for typically results
in lost damage potential. Your focus is balancing having enough
Chi for spenders and using [[spell:100784]] just enough to prevent
overcapping without using it too much and not having the Chi
you need when a bigger spender becomes available.

During major cooldowns, you will often have more Energy and Chi
than you can use due to the GCD and cooldowns of Chi spenders,
making avoiding the caps less impactful, but still something to be aware of.

### Keep Abilities on Cooldown

3.2.

#### Keep Abilities on Cooldown

With most of our Chi
spenders having their own cooldowns, it is important to reduce
the amount of time that these harder-hitting abilities are
sitting off cooldown without being used. There will, inevitably,
be overlaps where you'll have to choose what to press based on
the priority list. A key part of playing Windwalker recognizing
that one of these situations is approaching and trying to have
enough Chi for what you need to do.

### React to Procs

3.3.

#### React to Procs

Windwalker has several procs that
you'll need to manage in order to maximize damage potential.
The main ones are [[spell:325201]] and [[spell:100784]].
Both of these can stack to 2 so that you don't need to immediately
use them. However, you will want to avoid risking overstacking, as
that is lost damage potential. These procs can play an integral part
in helping you balance your resources while still benefitting from
[[spell:115636]]. They can also throw off what you were planning,
so being able to react intelligently and quickly is important.

4.

### Important Cooldowns for Windwalker Monk

### [[spell:1249625]]

4.1.

#### Zenith

[[spell:1249625]] doesn't provide any provide any direct damage increase without 
the addition of the Apex Talents of [[spell:1261703]]. However, it does reduce 
the cost of all of your Chi spenders by 1 and increases the cooldown 
reduction provided by [[spell:100784]] by an additional second. When you press 
the button it resets the cooldown of [[spell:107428]] and provides you an 
additional 2 Chi to use right away.

While [[spell:1249625]] is active, [[spell:100784]] becomes free, so it is your 
primary filler in order to get [[spell:107428]] and [[spell:113656]] back 
from cooldown as quickly as possible. This also means that you can 
very quickly feel like you have too much Chi if you're also using [[spell:100780]] too often.
Due to getting your cooldowns back faster, it is even more important to 
have the Chi that you need to cast them right away.

If talented into [[spell:1249832]] then [[spell:100784]] generates a Chi 
rather than consuming one. This causes it to function as both your 
primary filler and primary Chi-builder. [[spell:100780]] can be used in 
between [[spell:100784]]s to add a stack of Teachings of the Monastery 
for the ensuing [[spell:100784]]. This can result in overcapping your 
Chi at times, but this is preferable to casting nothing.

[[spell:1249625]] has two stacks, so you do not need to use it as soon as 
it is available but can plan its use for the best possible time.
Through talents, [[spell:1249625]] can have a cooldown that takes 60, 70, 80, 
or 90-seconds to return. With two possible stacks, this means you 
can safely use it based on when you get the most value out of it, 
during a high-damage phase of a fight, a time with many targets to 
hit, or during large buffs like Bloodlust or with your trinkets.

### [[spell:443028]]

4.2.

#### Celestial Conduit

[[spell:443028]] is a powerful ability to use, but the most powerful 
aspect of it is that it adds the [[spell:443294]] buff. However, 
because this buff can also come from using [[spell:392983]] or 
[[spell:152175]], you need to stagger these uses for maximum benefit. 
This generally means using [[spell:443028]] spaced out between casts of 
[[spell:392983]] or [[spell:152175]]. This attempts to insure 
maximum uptime and value.

The instance of [[spell:443294]] that is triggered from using 
[[spell:1249625]] stacks with the version of [[spell:443294]] that comes 
from [[spell:443028]], [[spell:392983]], or [[spell:152175]]. 
However, the instance of [[spell:443294]] that is generated from 
[[spell:443028]] does not stack with the instance that comes from 
[[spell:392983]] or [[spell:152175]].

This means that you can cast [[spell:1249625]] when you already have 
[[spell:443294]] up, and you should because they stack 
very well. You want to try and avoid casting [[spell:443028]] 
if you already have the buff that comes from [[spell:392983]] or 
[[spell:152175]] and visa versa.

### [[spell:123904]]

4.3.

#### Invoke Xuen, the White Tiger

With the changes in Midnight [[spell:123904]] is mainly a 
button you press so that you can then channel [[spell:443028]] afterwards. 
This means that you'll want to plan ahead slightly so that you are not 
wasting a GCD summoning Xuen when you want to be dealing damage.

There is a large window after casting [[spell:123904]] 
where you're able to cast [[spell:443028]]. Because balancing the 
above [[spell:443294]] buff generally means a somewhat strict 
sequence of abilities, you will want to avoid deviating much from the 
above opener, even if it's the middle of a fight.

### [[spell:322109]]

4.4.

#### Touch of Death

[[spell:322109]] seems like a straightforward ability to use but attempting to 
min/max it can lead to losing damage rather than gaining it. With the change to 
Fatal Touch in Midnight, it no longer provides a damage increase after using it.

While this generally means that you'll want to use it as soon as its available 
and you have space to press it without delaying another ability, it also means that 
you CAN try to use it right before the target dies when your target has less health 
than your maximum health so that it deals 100% of your health rather than just the 
35% of your maximum health that it deals if you use it on a target that is at 15% health or lower.

This is a very small window and [[spell:322109]] can sometimes have a delay 
before being usable if you just swap to a target to try and hit it with [[spell:322109]]. 
This delay can be the difference between making or missing the very small window. 
Missing the window generally means that you don't get [[spell:322109]] off and thus 
lose damage that you would have done if you had cast it sooner.

### [[spell:122470]]

4.5.

#### Touch of Karma

[[spell:122470]] is, first and foremost, a defensive ability. Its primary use is to absorb some 
damage in order to lessen the damage that you are dealt. However, the secondary function of 
[[spell:122470]] is that some of the damage that the shield absorbs is redirected back to the 
target that you cast the spell on. This means that [[spell:122470]] can be used offensively 
if you do not need its defensive value.

Most fights in most content have times where you will be taking damage and can cleanly use 
[[spell:122470]] for both its defensive and offensive value. However, sometimes the damage 
you are taking isn't enough to necessitate a defensive cooldown like [[spell:122470]]. 
In these situations it is, technically, optimal to find some damage that you can then 
absorb and redirect. This can be done through standing in some damage effect on the 
ground, or in extreme situations, casting Provoke on a target and taking a few smacks.

Needing to Provoke a target to get the benefit from [[spell:122470]] should be used as a 
last resort and only ever be done with the express permission of your tanks and healers as 
you're often likely to get killed once the shield ends without direct intervention.

Do this at your own risk.

### [[spell:388917]]

4.6.

#### Fortifying Brew

[[spell:388917]] increases your maximum health, so it also increases the damage that 
[[spell:322109]] deals and that [[spell:122470]] can absorb. Because of this, using 
[[spell:388917]] before you use [[spell:322109]] or [[spell:122470]] is a damage increase. 
This can be used to further improve your defense in a time of need, but it also has 
the secondary effect of increasing the amount of damage that is redirected back to the target.

If you are not going to need the defensive value of [[spell:388917]] on its own, like if large 
damage intake is more frequent and you need to stagger your defensive cooldowns, then you can 
stack them together for added benefit. Just be sure to use [[spell:388917]] BEFORE using 
[[spell:322109]] or [[spell:122470]] as both snapshot on use.

A real good way to use this is to find a way to use [[spell:388917]] then 
[[spell:122470]] at a time when you'll also be able to use [[spell:322109]] during 
the duration of [[spell:388917]]. This gets you both benefits for one use. If you're 
already going to use it for DPS purposes, then you might as well be efficient about it.

### [[spell:1261703]]

4.7.

#### Apex Talent: Tigereye Brew

[[spell:1261703]] is the new Apex talent node and is a callback to 
Windwalker's original damage cooldown, although mostly in name only. As the tooltip 
suggests, during combat you generate stacks that are then spent when you cast [[spell:1249625]] 
to increase your chance to Crit. Outside of combat it stacks back up to 10 very quickly, or 
will maintain its stacks if you are already at or above 10.

Generally you do not have to play around this buff, as you should be naturally using 
[[spell:1249625]] frequently enough to not need to worry about the cap of 20 stacks. The primary 
way that this buff affects your thought process is that it lessens the incentive to use both 
charges of [[spell:1249625]] back-to-back because the second use will have very few stacks. 
Most of the time, spreading them out is a reasonable choice to make, but sometimes you will still 
want to use them one after the other. This talent can be taken and ignored outside of the more extreme 
min-maxing situations that may be figured out as time goes on.

After the first talent point, the other three are passive damage increases that don't change anything.

:::details FAQWhen do I Ignore the Mastery: Combo Strikes?
Since

[[spell:100784]]

has lower damage than other abilities that cost Chi, you do not have to
prioritize it over

[[spell:107428]]

. As such, you very rarely need
to

[[spell:100784]]

twice in a row. If you are not running

[[spell:196740]]

, there is also very little
incentive to get the Mastery benefit on a very low hitting ability such as

[[spell:100780]]

. Therefore you can easily use

[[spell:100780]]

twice in a row
when setting up AoE, or any other combination of spells.
If you are using

[[spell:196740]]

then you will want to avoid repeating the same ability twice.

:::

:::details FAQAm I Supposed to Have Downtime?
**Yes!**

Windwalker naturally has downtime in the rotation and has just
about always been this way. Most energy based specs are like this. While
gaining Haste will increase your energy regen, it is still not currently
a very desirable stat. Learn to use the downtime to plan what’s happening in the future.
How much or how little downtime you have can depend on your Hero Talents, gear, what content you're
doing, and several other factors. As long as you're following the priority as you should, some downtime
is acceptable.

:::

:::details FAQShould I Hold FoF For a Few Seconds to Use RSK On Cooldown?
Generally the safe bet is to delay nothing. However, the best choice
in this situation is to make sure that you have 5 Chi ready to use with
both abilities back to back with minimal delay. You can then hold

[[spell:113656]]

for roughly 1-2 GCDs to get

[[spell:107428]]

off first: any more of a difference between
the two cooldowns and you are better off using

[[spell:113656]]

first.
This can apply to any situation where things will line up. However, it is important to understand
that there are other situations that can ripple out from delaying one ability for another, so it is
very easy for this right choice to spiral quickly. This is why it is generally advised to avoid delays
as much as possible.

:::

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Aug. 2026:** Updated Priority to add note about Celestial Conduit and Zenith Stomp.
- **11 Aug. 2026:** Updated for Midnight Season 2, updated rotation and priority for Season 2 tier set.
- **15 Jun. 2026:** Reviewed and Updated for Patch 12.0.7, added timeline for opener.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated priority and openers, added more details about choices.
- **12 Mar. 2026:** Reviewed for Midnight Season 1, added note about Tier set.
- **26 Feb. 2026:** Updated for Midnight release, brand new Rotation format and added Apex talent block.
- **10 Feb. 2026:** Updated for 12.0.1 moving from PTR to Live.
- **19 Jan. 2026:** Reviewed and updated for Midnight pre-patch, mostly format changes and additional sections.
- **30 Nov. 2025:** Reviewed for 11.2.7, added the few FAQs.
- **14 Oct. 2025:** Fixed a typo with SEF usage.
- **05 Oct. 2025:** Reviewed for 11.2.5, no changes needed.
- **04 Aug. 2025:** Updated for 11.2, very few changes needed, all done with the includes.
- **15 Jun. 2025:** Updated for Patch 11.1.7, added section on Rotation Assist.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5, no changes needed.
- **24 Feb. 2025:** Updated for Patch 11.1, added rotation information for Conduit and Heart windows.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed and updated for The War Within Launch, changed the "includes".
- **23 Jul. 2024:** Reviewed and updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, removed information about S3 tier bonus.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, no changes necessary.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated and Reviewed for Patch 10.2, updated priorities and tier set information.
- **04 Sep. 2023:** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **01 May 2023:** Updated for Patch 10.1, moved Rising Sun Kick higher in the priority.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1, added notes about the Vault of the Incarnates tier bonuses.
- **28 Nov. 2022:** Updated for Dragonflight launch, removed Shadowlands stuff.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Windwalker Monk in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Windwalker Monk

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, with harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains one of the highest DPS setups from all sources for Windwalker Monk. **For Windwalker Monk, nearly every piece that doesn’t have Versatility on it is a viable “BiS” piece. Do not take this list as the only option as there are hundreds or thousands of combinations all within a very small margin of each other.**

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
With the changes in Midnight Season 2 allowing catalyzed pieces to retain their stats, there are MANY more potentially BiS items. This means that any piece that has a mix of Critical Strike, Haste, or Mastery can be catalyzed and is a contender for the best setup. It also means that you may see a range of gear, enchants, and gems being used by top players as they follow their sims to adjust to the gear they have.

Ideally, you will want to catalyze Hands and Legs as they are the tier pieces with Versatility as a secondary stat from the token. As long as the pieces don't have Versatility they are safe to catalyze to maintain your 4-piece bonus.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) inheriting the secondary stats and special effects of the original item, players now have massive flexibility in acquiring tier pieces with ideal stats **in all five** slots. assuming that you are **both** raiding and running Mythic+ as necessary, catalyze the following gear:

- **Helm** - [[item:271875]] ([Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>))
- **Shoulders** - [[item:251223]] ([Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>))
- **Chest** - [[item:268235]] ([Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>))
- **Gloves** - [[item:251124]] ([Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>))
- **Legs** - [[item:268225]] ([The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>))

:::

:::details FAQWhat Do I Pick From the Great Vault?
The [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) has up to nine slots of items you can choose from every week, based on what content you have done on your character. This also impacts the item levels of each slot, with ![Mythic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-mythic.png>)Mythic raid bosses awarding fully upgraded Myth track gear! However, this wide variety of potential item levels also makes it hard to provide blanket recommendations. In addition, players may instead select either a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) or Tokens of Merit that can be exchanged for a [[item:275707]]. The power of these alternatives should not be underestimated, even if they may feel a bit "boring" in comparison.

Although you should always simulate your options in a given vault's rewards (including the value of an extra socket on pieces you'll keep for the rest of the season), here is a basic priority to follow on selecting rewards:

1. (First Vault only) claim Tokens of Merit for a [[item:275707]] or a piece of your tier set if available.
2. If you will be raiding the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) on at least **![Heroic](<https://static.icy-veins.com/images/wow/large_icons/dungeon-journal-heroic.png>)Heroic**, select a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) to bonus roll items from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) **as Brewmaster**. Do so until you have obtained all the pieces.
3. Choose the highest reward track items that can complete your tier set, ideally those that match our Catalyst recommendations for Windwalkers.
4. Select the highest item level pieces with minimal Versatility, those from the best-in-slot lists below, or additional [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s/[[item:275707]]s depending on your character's goals.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271519@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271520@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271517@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271518@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271522@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268215@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This list contains one of the highest DPS setups from Mythic+ dungeons for Windwalker Monk. **For Windwalker Monk, nearly every piece that doesn’t have Versatility on it is a viable “BiS” piece. Do not take this list as the only option as there are hundreds or thousands of combinations all within a very small margin of each other.**

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces Do I Want?
With the changes in Midnight Season 2 allowing catalyzed pieces to retain their stats, there are MANY more potentially BiS items. This means that any piece that has a mix of Critical Strike, Haste, or Mastery can be catalyzed and is a contender for the best setup. It also means that you may see a range of gear, enchants, and gems being used by top players as they follow their sims to adjust to the gear they have.

Ideally, you will want to catalyze Hands and Legs as they are the tier pieces with Versatility as a secondary stat from the token. As long as the pieces don't have Versatility they are safe to catalyze to maintain your 4-piece bonus.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) inheriting the secondary stats and special effects of the original item, players now have massive flexibility in acquiring tier pieces with ideal stats **in all five** slots. assuming that you are **only** running Mythic+ as necessary, catalyze the following gear:

- **Helm** - [[item:251140]] ([Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>))
- **Shoulders** - [[item:251223]] ([Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>))
- **Chest** - [[item:251159]] ([Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>))
- **Gloves** - [[item:251124]] ([Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>))
- **Legs** - [[item:268225]] ([The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>))

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): Drops a very strong weapon and a Best-in-Slot on-use trinket.
- [The Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Drops the strongest passive trinket.
- [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>): Drops good boots and chest.
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): Drops the most strong items, with Head, Neck, Hands, and Legs all being good choices.
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): Drops a strong ring and shoulders worth catalyzing.
- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): Drops a strong ring.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271519@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271520@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:159301@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nexus-king-salhadaar-raid-guide-in-manaforge-omega" rel="noopener noreferrer">Nexus King Salhadaar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271517@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271518@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:239656@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Feet</th><td>[[item:251153@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271522@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273796@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250214@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273783@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains one of the highest DPS setups from Raid for Windwalker Monk. **For Windwalker Monk, nearly every piece that doesn’t have Versatility on it is a viable “BiS” piece. Do not take this list as the only option as there are hundreds or thousands of combinations all within a very small margin of each other.**

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
With the changes in Midnight Season 2 allowing catalyzed pieces to retain their stats, there are MANY more potentially BiS items. This means that any piece that has a mix of Critical Strike, Haste, or Mastery can be catalyzed and is a contender for the best setup. It also means that you may see a range of gear, enchants, and gems being used by top players as they follow their sims to adjust to the gear they have.

Ideally, you will want to catalyze Hands and Legs as they are the tier pieces with Versatility as a secondary stat from the token. As long as the pieces don't have Versatility they are safe to catalyze to maintain your 4-piece bonus.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) inheriting the secondary stats and special effects of the original item, players now have massive flexibility in acquiring tier pieces with ideal stats **in all five** slots. assuming that you are **only** raiding, catalyze the following gear:

- **Helm** - [[item:271875]] ([Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>))
- **Shoulders** - [[item:268246]] ([Vashnik the Malignant](<https://www.icy-veins.com/wow/vashnik-raid-guide>))
- **Chest** - [[item:268235]] ([Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>))
- **Gloves** - [[item:251124]] ([Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>))
- **Legs** - [[item:268234]] ([Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>))

:::

:::details TipsWhich Raid Drops Are Most Important To Windwalkers?
The following items are the ones you should seek out first; some of them may be highly contested by other specializations, particularly in offensive trinkets:

- [[item:268215]]: This weapon drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), the final boss of the [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>), and is your BiS piece. Only a few specializations can equip it, allowing you to avoid crafting a weapon. What's more, when bonus rolled on Heroic with a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>), this item will drop in its Myth-track variant; on Mythic, it will instead be "elevated" with an additional 10 item levels.
- [[item:268265]]: This necklace from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) is unique in many ways, being purely statted with Critical Strike, a second socket, and two cantrip effects that further empower your player. It is far and away the best accessory available to you.
- [[item:270175]]: A potent on-use trinket from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) that not only provides static Critical Strike, but also on-demand Agility and raw Physical damage. This choice was truly made for a Windwalker.
- [[item:270173]]: Not one, but both of your best-in-slot trinkets come from this raid. Due to its elevated item level (and optional synergy with a very rare one-handed weapon), this is one of them.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271519@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271520@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271517@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271518@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAAGAAgBycDNW-E]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271522@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAGAAgBycDNW-E]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAAGAAgBycDNW-E]]&#10;&#10;<a href="https://www.icy-veins.com/wow/windwalker-monk-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268215@JAAGAAgBycDNW-E]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Windwalker Monk

There are a great number of Trinkets available for Windwalker, and we will generally want
  to play a combination of a powerful on-use trinket like [[item:270175]] for 90-second cooldown 
  cycles, [[item:273796]] for 2-minute cooldown cycles,
  and a passive trinket providing potent secondary stat buffs or raw damage procs. Make sure to consider
  [macro](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-macros-addons>)ing
  your on-use trinket to your [[spell:1249625]] cast!

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Windwalker Monk Trinkets**
**On-Use -**

[[item:270175]]

for 90-second cooldown cycles,

[[item:273796]]

for 2-minute cooldown cycles

**Passive -**

[[item:270173]]

,

[[item:250259]]

, or

[[item:270164]]

:::

There are quite a few other valuable trinkets out there, so make sure to click on our
  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Windwalker Monk Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp"/></span> Shado-Pan and <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp"/></span> Conduit of the Celestials</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]] — An incredibly strong trinket, even before considering that it can go up to 344 if you get it from Mythic. When playing Conduit of the Celestials this trinket only gets even stronger.</li>&#10;<li>[[item:270173]] — Boosted to S-tier because it has the highest item level of any passive trinket, but a very strong trinket even at the same item level as others.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]] — A very strong trinket that is even stronger when playing Conduit of the Celestials due to its 90-second cooldown.</li>&#10;<li>[[item:273796]] — The strongest 2-minute trinket that comes from dungeons, so the best avaible on-use dungeon trinket if you're playing Shado-Pan.</li>&#10;<li>[[item:250225]] — A strong trinket that doesn't quite scale as well as the others into multi-target situations.</li>&#10;<li>[[item:270164]] — The strongest passive trinket in AOE situations, it's one you'll see many people using.</li>&#10;<li>[[item:270165]] — Dramatically promoted to A tier after it has proven to be one the best passive trinkets available.</li>&#10;<li>[[item:281215]] — Added in 12.1.5, it has everything we want in a trinket and can be one of the strongest passive trinkets available for your character depending on the rest of your character's stats.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270168]]</li>&#10;<li>[[item:159617]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;0&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:241340]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:270166]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Patch 12.1 continues the bonus roll system that was initially introduced in Patch
12.0.7. Notably, bonus rolling on a Heroic raid boss will grant you the item at 1/6 Myth
track, so you can acquire some of the later raid gear quite early, as long as you commit
additional crests to upgrade it.

**[Nebulous Voidcores](<https://www.wowhead.com/currency=3418>)** can be spent after finishing a dungeon or killing
a raid boss, and will grant you a random from the dungeon's or boss's loot table.
Once an item has been looted through a Voidcore roll, it cannot appear again when you
bonus roll on the same boss or dungeon again.

After 8 weeks, you will also be granted one additional Voidcore for free from
**Orin Straylight** in Silvermoon, next to The Catalyst. This happens with the launch of
Patch 12.1.5.

3.1.

#### Recommended Nebulous Voidcore Usage for Windwalker Monks

Which item you want to chase after depends heavily on the items you have already acquired
  through i.e. the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), or whether you expect to down certain bosses on
  Mythic difficulty to get them on 9/6 Mythic itemlevel.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Mythic [[item:268215]]
2. Mythic [[item:270175]]
3. Remaining BiS List items

:::

On a new character, we recommend doing dungeons that drop a large amount of tier-slots like
chest+legs+shoulders from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>), where you can also pick up some good trinkets
even if your roll "fails". The tier-slot items you can catalyze to quickly get multiple
Myth Track tier items, without having to rely on the Great Vault. [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
also drops good items, including a weapon, ring, and neck, which will see great use. The
best choice ultimately depends on the gear you've already gotten from your Great Vaults
and potential Mythic raid bosses.

3.2.

#### Ascendant Venomstones

Using your [[item:280562]] follows a similar priority list as using your Crests:

1. Your Weapon is the highest priority
2. Your on-use trinket
3. Your passive trinket
4. Your neck piece

You will also want to prioritize Myth track items over Hero track ones, unless
  you do not expect to get a Myth track variant of said item. I.e. it is fine to upgrade a
  Hero track [[item:270175]] or [[item:270168]] if you do not expect to kill
  Mythic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) anytime soon.

4.

### Best Crafted Items for Windwalker Monk

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose the exact
secondary stats you want.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

As you will be focused on bonus rolling Heroic Ula’tek, this takes care of your 2-handed weapon slot. This 
means that you can go directly to crafting your best two embellishments.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Windwalker Crafted Gear Priority**
- Any two leather pieces with [[item:240167]], preferably Bracers and Cloak as they are the lowest “budget” slots. If you are planning to eventually kill Mythic Coiled Altar, then  you may want to craft in Bracers and Boots, as Coiled Altar drops a 344 item level back piece.

:::

4.1.

#### Best Embellishments for Windwalker Monk

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

As there is a lot of competition for Embellishments, you will have to pick
and choose the two strongest ones for your overall DPS output. Most of them provide
very similar DPS benefits, even if the effects are entirely different. The two best
choices for this are:

- For Raid: [[item:240167]] on two leather pieces, preferably Bracers and Cloak as they are the lowest “budget” slots.
- For Mythic+: [[item:240167]] on two leather pieces, preferably Bracers and Cloak as they are the lowest “budget” slots.

It is recommended to sim yourself to find out what works best, and if you
also play the other 2 Monk specs, you might want to pick Embellishments that work
well for all of them.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Windwalker Monk Crest Upgrade Priority**
**Weapon (Mainhand)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

➜

**Cloak/Bracers**

:::

These are not the only items worth upgrading, of course. They simply offer
the highest DPS gain early into the tier when your upgrade currency is limited.
Note that exceptions are possible, such as special items that have additional
procs attached to them.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5, added Ascendant Voidstone section and Kithix gear.
- **25 Aug. 2026:** Updated Weapon Enchant recommendation, moved Sapling trinket down to B.
- **11 Aug. 2026:** Updated for Patch 12.1, new gear list and updated information on crafting and coins.
- **15 Jun. 2026:** Updated for Patch 12.0.7, added Neck/Ring/Belt to Overall and Raid BiS lists.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Added additional option to craft Loa ring.
- **12 Mar. 2026:** Updated with new content and structure for Midnight Season 1.
- **04 Mar. 2026:** Updated embellishment recommendations to Darkmoon Sigil: Hunt.
- **26 Feb. 2026:** Reviewed and updated for Midnight release, all new gearlists.
- **10 Feb. 2026:** Reviewed and updated for Midnight pre-patch, very few changes required.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5, added sections on Puzzling Cartel Chips and expanded section on gear upgrades.
- **16 Aug. 2025:** Updated trinket rankings for Week 1 tuning.
- **04 Aug. 2025:** Updated for Patch 11.2, added section on Reshii Wraps, updated gear and trinket lists for Season 3.
- **22 Jun. 2025:** Updated for DISC Belt tuning.
- **15 Jun. 2025:** Updated for Patch 11.1.7, added section on DISC belt.
- **10 May 2025:** Finished/remade Dinar section.
- **21 Apr. 2025:** Updated and reviewed for 11.1.5, added Jastor ring to Dinar section and un-commended-out(?) Dinar section.
- **24 Mar. 2025:** Updated trinket and BiS lists for trinket tuning.
- **16 Mar. 2025:** Added flowchart for crafting.
- **06 Mar. 2025:** Updated Circlet gem recommendation.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Oct. 2024:** Reviewed and updated trinket recommendations.
- **09 Sep. 2024:** Updated for The War Within Season 1, added Embellishment recommendations.
- **21 Aug. 2024:** Reviewed and updated for The War Within Launch, totally redone.
- **23 Jul. 2024:** Reviewed and updated for The War Within pre-patch.
- **07 May 2024:** Updated for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, updated BiS lists, tier information, and added Bullion.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, no changes necessary.
- **14 Feb. 2024:** Swapped Blue Silken Lining in for best embellishment recommendations.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **30 Nov. 2023:** Updated BiS Lists
- **19 Nov. 2023:** Fixed link problem with Borrowed Time weapon.
- **11 Nov. 2023:** Updated for Sporecloak nerf, embellishment recommendations have been redone.
- **06 Nov. 2023:** Updated and Reviewed for Patch 10.2, updated tier information, BiS lists, and embellishment recommendations.
- **04 Sep. 2023:** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated and Reviewed for Patch 10.1.5, added information on unique items in Dawn of the Infinites dungeon.
- **01 May 2023:** Reviewed and Updated for Patch 10.1, formatting changes, updated BiS gearsets, and more.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1, added gear from Vault of the Incarnates.
- **28 Nov. 2022:** Updated for Dragonflight launch, added initial dungeon gear.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Windwalker Monk. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Windwalker Monk Stat Priority

The stat priority for Windwalker Monks can depend slightly on the encounter type
and your character's gear but generally Haste, Critical Strike, and Mastery are all very close and may pull ahead of 
each other depending on your other gear.

Agility

Haste

Critical Strike

Mastery

Versatility

2.

### In-Depth Stat Breakdown

**Agility** is your primary statistic. You should look for it in all
of your upgrades. It provides you with Attack Power, which determines the
damage your abilities do.

**Versatility** increases all your damage and healing done, and decreases
all damage taken.

**Critical** provides an increased chance on most of your spells to deal
double damage. Keep in mind this will not affect the damage from
[[spell:322109]] and [[spell:122470]].

**Haste** provides you with increased attack speed and
Energy regeneration, and reduces the cooldown of your
[[spell:113656]] and [[spell:107428]].

**Mastery** ([[spell:115636]]) causes your abilities
to deal increased damage (the amount depends on your amount of Mastery) when
they are not used two or more times in a row. For example, using
[[spell:100784]] and [[spell:100780]] gives both of them the
damage bonus, but if you use Tiger Palm twice in a row, the second Tiger Palm
will no longer benefit from the increase.

:::details FAQDoes Windwalker Have Any Stat Caps?
There are no "recommended stat levels" or "breakpoint of X stat" or "required"
amount of any stats. This is an outdated way to think about stats for most specs and
simply is not relevant to the spec.

Simming your own char will always be more accurate and therefore recommended.

:::

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Reviewed for Midnight Patch 12.1, clarified stat priority.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1, moved Haste above Critical Strike.
- **26 Feb. 2026:** Reviewed and updated for Midnight, removed mentions of the Pre-Patch.
- **10 Feb. 2026:** Reviewed and updated for Midnight Pre-Patch, adjusted stat priority.
- **30 Nov. 2025:** Reviewed for 11.2.7, added FAQ about stat caps.
- **05 Oct. 2025:** Reviewed for 11.2.5, no changes needed.
- **04 Aug. 2025:** Reviewed for Patch 11.2, no changes needed.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5, no changes needed.
- **24 Feb. 2025:** Updated for Patch 11.1, Changed stat priority.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed and updated for The War Within Launch, no changes needed.
- **23 Jul. 2024:** Reviewed and updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, no changes necessary.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, no changes necessary.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated and Reviewed for Patch 10.2, updated talent recommendation.
- **04 Sep. 2023:** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **01 May 2023:** Reviewed for Patch 10.1, no changes necesssary.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Windwalker Monk, based on your [stat priority](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should use [[item:240983]] in one socket. Then, the 
rest of the sockets can be filled in based on what your character needs the most. I.e. if you
already have a lot of Mastery and Crit on your Gear, you'll want more Haste, and
vice versa. To match your current gear, you'll then want to play gems providing your lowest
stat, with the best options for each combo being:

- Haste/Critical Strike ([[item:240890]])
- Haste/Mastery ([[item:240892]])
- Mastery/Critical Strike ([[item:240898]])
- Mastery/Haste ([[item:240900]])
- Critical Strike/Haste ([[item:240906]])
- Critical Strike/Mastery ([[item:240908]])

The choice of gems is highly dependent on your gear. Haste, Critical Strike, or Mastery 
can easily be your highest simming stat depending on the current gear
you are wearing, and as a result, the choice of gems and ring enchants
can vary a lot.

2.

### Best Enchants and Weapon Augments

You will want to use [[item:243733]] in all content and situations.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]] or [[item:243986]] depending on other stats</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</tr></table>

3.

### Optimal Consumables

Consumables substantially increase the power of your character for a limited time. Any
time you are challenging yourself with difficult content, it is advisable that you buff
yourself with Flasks, Food, Potions, and Weapon Oils.

3.1.

#### Flasks and Potions

[[item:241325]] is the recommended choice for all content.

3.2.

#### Potions

For your DPS potion, use [[item:241288]] in all situations.

Make sure to also carry [[item:271883]] to heal yourself.

3.3.

#### Food Buff

You should eat the Feasts to increase your Agility; [[item:255846]].
Keep a few [[item:242275]] in your inventory as well, in case no feast is
available to you.

3.4.

#### Augment Rune

While expensive, [[item:259085]]s can also be used for a
small amount of extra Agility. Consider keeping a few on hand for times when
you need to eke out every bit of possible damage.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Aug. 2026:** Updated Weapon Enchant recommendation.
- **11 Aug. 2026:** Updated for Patch 12.1, adjusted to new healing potion.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1, added note about Sanguithorn Tea.
- **26 Feb. 2026:** Updated for Midnight release, all new enchants and consumables.
- **10 Feb. 2026:** Updated for the Midnight pre-patch, adjusted enchantment and gem recommendations.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for 11.2.5, no changes needed.
- **04 Aug. 2025:** Updated for 11.2, added new healing potion.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **22 May 2025:** Updated corruption recommendation again for Echoing Void not being good.
- **18 May 2025:** Updated corruption recommendation.
- **21 Apr. 2025:** Updated for Patch 11.1.5, added Corruption section for whenever we get that.
- **24 Feb. 2025:** Updated for Patch 11.1, Changed ring enchant.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **10 Oct. 2024:** Fixed an outdated Augment Rune section.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed and updated for The War Within Launch, updated all recommendations.
- **23 Jul. 2024:** Reviewed and updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, no changes necessary.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, no changes necessary.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated and Reviewed for Patch 10.2, updated enchant recommendations.
- **04 Sep. 2023:** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **01 May 2023:** Reviewed and updated for Patch 10.1, moved Primordial Stones section and added Shadowflame enchant.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7, added Primordial Stones section.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Windwalker Monk in World of Warcraft Patch 12.1.5.

1.

### Windwalker Monk in Mythic+ in Midnight Season 2

The playstyle of Windwalker Monk in Mythic+ is all about using as many 
[[spell:113656]] as you can. In addition to simply casting [[spell:113656]] 
every time that it is available, you want to cast things like [[spell:107428]] , [[spell:100784]], and [[spell:101546]] in order to reduce the cooldown of [[spell:113656]] through the 
[[spell:392993]] and [[spell:261917]] talents. This covers maximizing 
your single target and AoE damage.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Windwalker Monk in Mythic+ provides strong group utility through spells like [[spell:116844]] 
and [[spell:119381]]. Although it has struggled with damage compared to the top specs in the past, Windwalker should 
be able to contend at most key levels and there are regularly Windwalkers pushing for top titles every season. 
You can play this as either Hero Talent spec, depending on your preference,
although Shado-Pan is generally recommended due to higher AoE potential and easier play. Conduit of the Celestials can be stronger in experienced hands and with well timed pulls.

2.

### Best Mythic+ Talent Builds

### Standard Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan

This is our recommended build for most Mythic+ scenarios. While the performance between
both standard builds is very similar to one another, this ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan version is a bit
easier to execute, and thus recommended for your weekly-key runs.

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYAMGbzMz2MAAAAAAAAAAAALDzEmxywAmxwMzMDz2wMMLzEAwiZ2mZGzMzMAA2AgZZWamZmFAMwMDAswAGwA"
}
```
:::

:::details 来源计算器编码
```
#NE-JLYamQRThnHIQkyOBI4CDzzsV12G3XQSStR-pBCEMoAASTcimnORUVv8CSWC1ST3XYL-AAAA-FGUYcgoYhpJQCA-*
```

:::

### Advanced Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials

This is our alternative advanced build for higher-end Mythic+ scenarios. It is a bit
more difficult to execute well than its ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/shado-pan.webp>) Shado-Pan counterpart,
but the performance can be higher if you're able to play it well.

:::talents 天赋构筑
```json
{
  "code": "C0QAAAAAAAAAAAAAAAAAAAAAAMzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAswsxMmZmZAAsYmlZZMBAAmxAYGgxyAYmZ2M"
}
```
:::

:::details 来源计算器编码
```
#NE-GHIJNTpuzSZnQRZBMchh5ZGU9Fkks12G3oG-pBCEMoAASTimnORUVv8WaAxSTXI5KbL-AAAA-EMQowIRZhpJQAC-*
```

:::

3.

### Utility Kit and Abilities

### Interrupts

3.1.

#### Interrupts

[[spell:116705]] is your "kick" and your most important bit of utility in
Mythic+, used to stop enemy casts for the benefit of the group and especially
the tank. It is **highly recommended** to use a Focus Kick macro for this.

#### Focus Kick Macro

```wow-macro
#showtooltip Spear Hand Strike
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Spear Hand Strike
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

#### Focus Mouseover Macro

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

### Stuns and Stops

3.2.

#### Stuns and "Stops"

[[spell:119381]] is your "AoE stop". It will knock **down** all targets in a generous radius, stopping
their casts.

[[spell:116844]] is one of the most useful abilities in the game when it comes to controlling enemies. It
interrupts casts and allows them to be positioned better.

[[spell:115078]] is a useful long CC that is used to isolate targets so that they aren't involved in the fight. It can
also be used as an interrupt if the other options aren't available.

### Other Utility

3.3.

#### Other Utility

[[spell:115450]] is a useful ability to help remove any poison or disease debuffs that may be present.

[[spell:8647]] is a debuff that all Monks provide that increases the physical damage that targets 
take. This is applied automatically to any target that is hit. Particularly useful in Physical comps!

[[spell:116841]] can be used as a speed boost or as a way to break free from movement impairing effects,
for yourself, or other players.

[[spell:157411]] provides a movement speed increase in an aura around the Windwalker. While
rarely directly beneficial, it can add up to a few seconds saved in dungeons where you cannot
mount up, and also helps players move out of dangerous effects a tiny bit faster.

Its rare that it will be essential, but [[spell:116095]] can provide a 50% slow to a target, in addition to 
Windwalker's incredible other control abilities, every little bit can help.

[[spell:101643]] can be used to jump over many mechanics and other things on the ground by placing 
your spirit in one place and then teleporting to it after that place is safe.

4.

### Dealing with Affixes

Season 2 of Midnight only has four significant Affixes that offer any kind
of counterplay, called Xal'ataths Bargains. These rotate every week, with only
one of them being active at a time. Many of the Mythic+ affixes, like Fortified or
Tyrannical, simply add a passive effect to the keystone, with these four exceptions
that are seasonally themed after Xal'atah.

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Windwalker Monk

Windwalkers have a large number of abilities on hand that can counter the
[[spell:403766]] casts from the orbs this affix generates. Among these
are your [[spell:116705]], [[spell:115078]],
and even [[spell:116844]] or [[spell:119381]]. However, you may want to
avoid overcommitting resources to stopping this affix in favor of still having them
available for the traditional trash pulls of a dungeon; choose your tools carefully.

### Affix: Voidbound

4.2.

#### Voidbound Affix Management for Windwalker Monk

Void Emissaries spawned when this affix triggers only have 1 HP, with their
health otherwise being an absorb. This means that your [[spell:322109]] can
instantly be used on them, dealing its full amount of damage and significantly
negating their danger. With the frequency of these spawns, you will be able to
cast Touch of Death on most. This does mean you will not have access to
the ability for "regular" moments of the dungeon.

### Affix: Pulsar

4.3.

#### Pulsar Affix Management for Windwalker Monk

You are **unable** to gather the [[spell:1216858]] orbiting your character
on your own. It **must** be walked into by another player. In addition, these
Pulsars will always orbit clockwise; take advantage of this and your own mobility
to quickly gather another player's Pulsar that is in melee range to avoid disrupting
enemy positioning too much.

### Affix: Devour

4.4.

#### Devour Affix Management for Windwalker Monk

[[spell:440313]]'s absorb can be removed after receiving 53% of your
maximum health in healing, or instantly with [[spell:115450]]. If you have talented
into [[spell:388812]] as well, consider dispelling yourself and using an
instant cast of [[spell:116670]] to help out another player if there are not
enough dispels to go around.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Updated for Midnight Season 2, updated talent builds.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1, thankfully very little needs to change
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Reviewed for Midnight pre-patch, removed S3 mentions, talent changes are done through includes.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for 11.2.5, no changes needed.
- **21 Aug. 2025:** Fixed issue with image blocks messing up talents and utility.
- **04 Aug. 2025:** Reviewed for Patch 11.2, no real changes needed, Mythic+ tips commented out, split up talent builds even though they're the same.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **27 Apr. 2025:** Added Mythic+ Tips.
- **21 Apr. 2025:** Reviewed and Updated for Patch 11.1.5, no changes needed. Mythic+ tips to follow.
- **24 Feb. 2025:** Updated for 11.1, commented out dungeon tips for now, changed Oblivion to Pulsar, gave both SP and CotC talent setup
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Added Mythic+ tips for each dungeon.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **17 Jul. 2024:** Reviewed and updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, no changes necessary.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, no changes necessary.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated and Reviewed for Patch 10.2, updated talent recommendation.
- **04 Sep. 2023:** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **01 May 2023:** Reviewed and Updated for Patch 10.1, removed Thundering.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch, added Thundering information, removed Shadowlands things.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Windwalker Monk in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Windwalker Monk macros.

1.1.

#### Generic Macros for Monks

1.1.1.

##### Detox Mouseover Macro

#### Detox Mouseover Macro

```wow-macro
#showtooltip Detox
/cast [@mouseover,help,nodead] Detox;Detox
```

Using this macro will cast
[[spell:218164]]
on your mouseover
target, if they are a friendly player and they are not dead. Otherwise, it
will cast Detox on your current target.

1.1.2.

##### Tiger's Lust Mouseover Macro

#### Tiger's List Mouseover Macro

```wow-macro
#showtooltip Tiger's Lust
/cast [@mouseover,help,nodead] Tiger's Lust;Tiger's Lust
```

Using this macro will cast [[spell:116841]] on your mouseover
target, if they are a friendly player and they are not dead. Otherwise, it
will cast Tiger's Lust on your current target.

1.2.

#### Specific Macros for Windwalker Monks

Thankfully, Windwalker is not a spec that requires macros to perform, 
but there are some that can be helpful.

1.2.1.

##### No Cancelling Macro

#### No Cancelling Channels

```wow-macro
#showtooltip Tiger Palm
/cast [nochanneling][channeling:Spinning Crane Kick] Tiger Palm
```

The macro allows you to spam the next ability even during the channels for
[[spell:113656]], [[spell:117952]], and [[spell:443028]]
 channel without it being cancelled. Change [[spell:100780]] with 
 the ability you want the macro to work with.

For [[spell:152175]] and [[spell:392983]] you need a specific 
macro to use them on the same button. If you keep them as separate buttons then 
use the one above. To use them on the same keybinding then use the one below.

#### WDP/SotW No Cancelling

```wow-macro
#showtooltip [known:392983] Strike of the Windlord; Whirling Dragon Punch
/stopmacro [channeling:Fists of Fury]
/stopmacro [channeling:Celestial Conduit]
/cast [known:152175] Whirling Dragon Punch
/cast [known:392983] Strike of the Windlord
```

1.2.2.

##### "Burst" Macro

#### Zenith, Trinket, & Potion

```wow-macro
#showtooltip Zenith
/use [pet][known:450615]13
/use [mod:shift,pet][mod:shift,known:450615]item:245898
/use [mod:shift,pet][mod:shift,known:450615]item:241308
/cast Zenith
```

This Macro uses your on-use stat trinket and potions in the 
correct order to allow your [[spell:1272694]] from casting [[spell:1249625]]
to be affected by the stat buffs as well.

2.

### Best Addons

2.1.

#### Generic Addons for Monks

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.4.4.

##### Omen Threat Meter

[Omen Threat Meter](<https://www.curseforge.com/wow/addons/omen-threat-meter>)
is the most popular addon for displaying the current threat levels on your
target. We recommend you to use it to avoid taking aggro when the tank is still building
up threat on an enemy.

2.5.

#### Specific Addons for Windwalker Monks

Currently, we do not believe that you need any additional addons to play your
specialisation to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Reviewed for Midnight Patch 12.1, no changes needed.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1, added WDP/SotW no cancel macro.
- **26 Feb. 2026:** Reviewed for Midnight release, added "Burst" macro, updated to new format.
- **10 Feb. 2026:** Reviewed for Midnight pre-patch, updated Don't Cancel macro to newer version.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2, no real changes needed.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed and updated for The War Within Launch, minor word changes.
- **23 Jul. 2024:** Reviewed and updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, no changes necessary.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, no changes necessary.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated and Reviewed for Patch 10.2, no changes necessary.
- **04 Sep. 2023:** Updated and Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated and Reviewed for Patch 10.1.5, no changes necessary.
- **30 Apr. 2023:** Updated and Reviewed for Patch 10.1, no changes necessary.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
