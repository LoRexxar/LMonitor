## 专精概览

Welcome to our Holy Priest guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to heal as a Holy Priest in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your output.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Holy Mythic+ Resources

[NEW! Top Holy Talent Builds](<https://raider.io/specs/holy-priest/talents>)

[Top Holy Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/priest/holy>)

[Holy Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=priest--holy>)

[Popular Holy Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=priest--holy>)

1.

### Holy Priest Overview

Holy Priest is a fantastic reactive healer. With a response to almost all damage types, there is always a tool on
hand to deal with the situation and keep you thinking while you play.

Healing as a Holy Priest revolves around the chosen talents and the two Holy Words, [[spell:34861]] and
[[spell:2050]]. Outside of these, the bulk of your spell casts are the Mana-efficient
[[spell:33076]] alongside the variety of "filler" spells used to reduce the cooldown of our strong Holy Words.
[[spell:200183]] combined with [[spell:64843]] gives Holy Priest two easy-to-use cooldowns, which can be
invaluable to keeping your allies alive.

To properly play a healing role, you will need more than just class-specific information. To better understand
healing in general, we recommend that you read our [healing guide](<https://www.icy-veins.com/wow/healing-guide>).

Reactive Healer

Holy Priest is primarily a reactive healer, excelling during periods of sustained damage taken by utilising a multitude of
short-cooldown spells. Although limited by a lack of burst healing, you will have tools to heal your group through
almost every situation.

Sustained Throughput

Holy Priest thrives in progression raiding, offering reliable sustained healing and solid raid cooldowns such as
[[spell:64843]] and [[spell:200183]]. With many short-cooldown abilities and the ability to provide respectable
single-target and AoE healing, it is a versatile addition to any raid team.

All-rounder

Holy Priest is a solid all-round healer in Mythic+ content and is more than capable of healing effectively in all but
the most cutting-edge groups. As the difficulty increases, it becomes more important to plan ahead with cooldown usage
to help counter periods of high burst damage.

Niche Utility

Holy Priest provides many key tools for any raid, making it a desirable spec. However, most of these are not
Holy-specific, but are available to all Priests. The most useful are [[spell:10060]], [[spell:21562]],
and [[spell:8122]]. In Mythic+, situational usefulness can also come from
[[spell:453]], or [[spell:9484]]. As a Holy Priest, the primary unique contribution is access to the
life-saving external [[spell:47788]].

Layered Defenses

Holy Priest survivability comes from a combination of abilities. Individually, they are not strong, but together you can
survive significant damage. Holy uses a combination of [[spell:19236]], [[spell:108945]],
[[spell:2061]] with [[spell:193063]], and [[spell:586]] with [[spell:373446]]. Using two of these
at once is often enough to survive any scary moments.

Limited Mobility

As a Holy Priest, mobility will be one of the toughest challenges to overcome, particularly because this spec has no
movement displacement ability for traveling short distances quickly. For sustained movement over long periods, we have
[[spell:121536]], but this ability does not provide any burst movement.

Because of this, you may sometimes need to
rely on external movement abilities from other specs to compensate for the lack of mobility. You can also choose a race
with a mobility racial ability, such as Void Elf's [[spell:256948]], Goblin's [[spell:69070]], or
Dracthyr for [[spell:131347]].

2.

### Holy Priest in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 brings no significant changes to Holy Priest. This patch focuses on two new pieces of endgame
    content: one for Raid groups and one for [Delves](<https://www.icy-veins.com/wow/delves-guide>). The new Kith'ix Raid encounter drops two notable items
    for Holy Priests, neither of which are Best in Slot, but both are competitive upgrades if you are still running a
    lower track. The armour item is [[item:281235]] and the healing trinket is
    [[item:280835]]. The Critical Strike trinket [[item:281215]] only triggers from
    dealing damage, which Holy Priest does not deal often enough to maximise the trinket's uptime, making it a poor
    choice. The new Labyrinth Mega-Delve gives you the opportunity to choose an item for a particular slot and is great
    at also filling out any slots you have a lower track item in.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

Patch 12.1.5 introduces the ability to obtain [[item:280562]]. You will be able to use these on
    fully upgraded 6/6 Hero-track and Myth-track Weapons, Necks, and Trinkets to further upgrade them to a higher
    Ascended item level. Mistcrests are also uncapped, allowing you to obtain an unlimited amount to upgrade and craft
    gear. Our 12.1.5 Patch Hub has all the details on these changes and more.

2.3.

#### Class Changes

The only change to Holy Priest in Patch 12.1.5 is two talents swapping places, [[spell:1246517]] and
    [[spell:1215275]]. While our [talent](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>) builds have been
    updated to reflect this change, it does not alter any builds as Holy Celerity is a strong talent, so both talents
    continue to be taken in their relevant builds.

[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Holy Priest**

- [[spell:1215275]] and [[spell:1246517]] have swapped positions on the specialization tree.
              
  
  - <em>Developers' notes: Ultimate Serenity is a powerful tool for Holy priests, specifically in M+. We
                  are moving it up in the talent tree to reduce the amount of investment required for Holy priests to take
                  it so that it enables more choice amongst talents beyond the second gate.</em>

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_guardianspirit.jpg>) Click for Previous Season 2 Changes
Holy Priest received several reductions in Patch 12.1 to the mana cost of key spells and increases to the healing
    of some abilities, along with some mechanical changes to how [[spell:1262755]] functions. The main gameplay
    implication is [[spell:1262755]] becomes more important to press when it is active, and is more reliably
    available due to triggering each time you cast [[spell:2050]].

[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Holy Priest**

- [[spell:453845]] has been slightly redesigned: Creating a [[spell:120517]] increases healing done by
              2% for 10 seconds, stacking up to 4 times.
- [[spell:64843]] has been updated: Now additionally grants [[spell:47788]] while channelled.
                
  
  - <em>Developers' notes: We are adding a benefit to channelling Divine Hymn to make it easier to use. If
                    you already have Guardian Spirit active on yourself, Divine Hymn will add 5 seconds to its duration. If
                    Divine Hymn's channelling is ended early, it will remove whatever time is remaining from the amount that it
                    added.</em>
- All healing increased by 16%.
- [[spell:200183]] now reduces the mana cost of Holy Words by 70% (was 50%).
- [[spell:2061]] mana cost reduced by 10%.
- [[spell:596]] mana cost reduced by 10%.
- [[spell:33076]] healing increased by 20%.
- Oracle: [[spell:1246799]] healing increased by 30%.
- Apex Talent: [[spell:1262755]] healing increased by 15%.
- Apex Talent: [[spell:1262755]] mana cost reduced by 30%.
- Apex Talent: [[spell:1262760]] (Rank 3) has been updated: [[spell:200183]] no longer upgrades
              [[spell:2061]] to [[spell:1262755]]. [[spell:2050]] now has a 100% chance to upgrade your
              next [[spell:2061]] to [[spell:1262755]].
                
  
  - <em>Developers' notes: We want to address Benediction's performance by spreading its availability
                    beyond Apotheosis and Prayer of Mending. Additionally, we are increasing the throughput of Benediction, so
                    its impact is felt and contributes more to Holy's overall throughput. Lastly, we want to further lessen
                    how expensive the rotation of Holy is by specifically targeting Flash Heal and Prayer of Healing.</em>

:::

### Midnight   Changes Overview

Compared to many specs, the changes to Holy Priest in Midnight are not as dramatic. Some of our baseline
    defensive abilities have been moved to the class tree, and with the removal of multiple active abilities from the
    class tree, there are ample points to pick up all of the throughput talents. Your remaining points can be spent to
    enhance your defensive abilities or to choose some utility talents. The Holy tree has seen less change overall, and
    is very similar to The War Within, with the notable exception of [[spell:1246517]]. Additionally, as you
    level up there are new hero talents for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle, and the new [[spell:1262755]]
    Apex Talents.

2.4.

#### Benediction Apex Talent

Leveling up grants you additional talent points you can use to unlock the Benediction Apex Talent, which
    provides the following benefits as you put points into it:

- **First Point:** [[spell:1262755]] causes [[spell:33076]] bounces to periodically transform
        your next cast of [[spell:2061]] into [[spell:1262755]], increasing the healing done and triggering a
        [[spell:238136]].
- **Second and Third Points:** [[spell:1262758]] increases all healing done, and further increases the healing of
        [[spell:238136]].
- **Fourth Point:** [[spell:1262760]] causes each pulse of [[spell:64843]] to trigger [[spell:238136]].
        Casting [[spell:2050]] upgrades your next [[spell:2061]] to [[spell:1262755]].

**How it works:** The periodic [[spell:1262755]] procs are triggered by regularly casting
    [[spell:33076]]. When triggered, [[spell:2061]] is replaced with [[spell:1262755]] for your next
    cast, doing increased healing and triggering a [[spell:238136]]. Due to the added healing,
    [[spell:1262755]] is a high-value spell to use and should be prioritised as part of your rotation whenever it
    triggers.

2.5.

#### Hero Talent Changes

With [[spell:120517]] being removed from the Priest class tree, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon has seen a bit of a shuffle in its
    talent placements, with the first talent in the tree now [[spell:120517]]. Much of the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon tree remains
    the same, with the continued focus on empowering [[spell:120517]] and providing regular buffs to [[spell:2061]] and
    [[spell:596]]. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon continues to play much the same as The War Within, with the exception of
    [[spell:1247178]] which enables usage of [[spell:596]] to consume [[spell:109186]].

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle has seen the most change with the primary focus of the tree in The War Within
    **Premonition** being removed. Replacing this are numerous talents that focus on enhancing
    [[spell:33076]]. This includes the new [[spell:1248423]] for an additional charge of Prayer of Mending
    which is a fantastic quality of life improvement to the spec, especially when paired with the other new talent
    [[spell:1246799]].

Prompt Prognosis was the Season 3 set bonus from The War Within, granting a sizeable heal
    on the target you cast [[spell:33076]] on. This talent helps reduce one of the weaknesses of the
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle tree, which is its reduced spot-healing.

The other talent of note is [[spell:1246802]] which carries
    over the Piety effect from the old Premonition system. Due to how Holy Priest Mastery [[spell:77485]]
    works, this is a solid improvement to our healing which naturally results in a considerable amount of overhealing.

2.6.

#### Playstyle Changes

The playstyle of Holy Priest remains very similar in Midnight. There is still a heavy focus on using your Holy
    Words [[spell:2050]] and [[spell:34861]] as much as you can, along with your short cooldown
    spells like [[spell:33076]], and for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon, [[spell:120517]]. Between your short cooldown spells,
    you heal your group with [[spell:2061]], [[spell:596]], and sometimes [[spell:132157]] depending on
    the talents you have taken and the style of damage coming in. Our powerful cooldowns [[spell:64843]] and
    [[spell:200183]] have not seen any major changes.

Notable talents that have been removed include **Renew, Heal, Lightwell, Shadowfiend, and Symbol of Hope**. Some other more
    situational spells have also been removed: **Power Word: Shield, Power Word: Life, Divine Star, and Divine
    Word.**

The healing amount and mana costs of most spells have also been rebalanced in an attempt to try and put more focus
    on active healing spells and reducing the amount of healing that passive talents contribute to your overall throughput.
    This does not have an impact on your playstyle beyond making it feel better when you use direct healing spells like
    [[spell:596]] as it comparatively does more healing than passive spells like [[spell:139]] procs.

[[spell:1246517]] is a notable new talent, which grants additional power to [[spell:2050]] and
    causes it to heal nearby allies for a portion of the amount it heals your primary target. It also causes
    [[spell:2050]] to gain some benefit from talents that would normally affect [[spell:34861]]
    such as [[spell:596]] reducing the cooldown of [[spell:2050]].

The trade-off is that while
    talented into [[spell:1246517]] you are unable to cast [[spell:34861]]. This talent aims to land
    somewhere between the functionality of the two Holy Words offering a simpler, single button that performs similar
    amounts of healing.

[Holy Priest Rotation](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)

2.7.

#### Survivability and Utility Changes

There are no major changes to survivability or utility in this patch besides some defensive abilities like
    [[spell:19236]] and [[spell:586]] being added as talents in the class tree. Some minor changes have been
    made to various talents including [[spell:64129]] which can also trigger from [[spell:33076]], and
    [[spell:9484]] which now works on Aberrations alongside Undead.

3.

### Basics of Holy Priest Gameplay

Holy Priest is classed as a reactive healer, meaning you will primarily be reacting to damage your allies take and
then casting the appropriate spells from your toolkit to respond to that damage. While this healing style does make Holy
Priest one of the easier healers to pick up, getting your head around the number of healing spells available can take
some time. When learning Holy Priest you should consider these three key aspects.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_serendipity.jpg>) **Use Holy Words First**  
  
    Holy's core feature is [[spell:63733]] which causes most of your abilities to reduce the cooldown of
    [[spell:2050]] and [[spell:34861]]. To make the most of this cooldown reduction, prioritise casting
    your Holy Words before abilities such as [[spell:2061]] and [[spell:596]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_prayerofmendingtga.jpg>) **Regularly Use Short Cooldowns**  
   
    Holy's short cooldown abilities that should be used regularly to maintain optimal healing output and mana efficiency.
    [[spell:33076]] is the most prominent, and should be used when available not only for its mana efficient
    healing, but also to trigger our Apex Talent [[spell:1262755]]. As the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Hero Talent you should
    use its [[spell:120517]] ability regularly to fully maximise Archon's potential.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_surgeoflight.jpg>) **React to Surge of Light Procs**  
  
    Consuming [[spell:109186]] not only reduces its mana cost, but also makes your next related spell cast instant
    allowing you to cast while moving. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon this is even more important due to several talents which
    increase the potency of spells that consume [[spell:109186]], such as [[spell:1247178]] which allow you to
    consume Surge of Light with [[spell:596]].

4.

### How to Gear Up as a Holy Priest

While we always recommend simming yourself for ideal results, we do provide a
dedicated Holy gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **17 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Fixed a the Oracle Mythic+ build export.
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **25 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated builds with the latest theorycrafting.
- **25 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated rotation to match talent build updates.
- **25 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated builds with the latest theorycrafting.
- **25 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated builds with the latest theorycrafting.
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for trinket hotfixes.
- **17 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated builds for upcoming hotfixes.
- **16 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Fixed broken Archon Lightweaver build.
- **12 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Clarified information regarding bonus rolls.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Fixed broken Archon Lightweaver build.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated builds & rotation advice for upcoming hotfixes.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **30 Jun. 2026 (this page):** Updated for Patch 12.0.7 Holy Word hotfix.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.7 with Sporefall gear.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.7 and Omnium Folio.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7 features.
- **23 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Update ring enchant suggestion following Patch 12.0.5 fixes.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated for Patch 12.0.5, including stat DR thresholds.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **31 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Improved rotation explanation for some talents.
- **31 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated flex talents.
- **25 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated trinket rankings with latest theorycrafting and hotfixes.
- **24 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Removed mention of teas after hotfixes.
- **24 Mar. 2026 (this page):** Expanded on key Holy Priest features.
- **22 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated trinket rankings with latest theorycrafting and fixes.
- **22 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Added some mana management tips for raiding.
- **22 Mar. 2026 (this page):** Updated with the lack of tuning changes.
- **21 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 12.0.5.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated with trinket hotfixes.
- **17 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Fixed an incorrect talent layout.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **05 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Streamlined the talent tree and added more tips.
- **05 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Added more Midnight addons.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Midnight launch.
- **26 Feb. 2026 (this page):** Updated for Midnight launch.
- **24 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated again for Midnight launch.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated again for Midnight pre-patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated again for Midnight pre-patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated again for Midnight pre-patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated again for Midnight pre-patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 (this page):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Midnight pre-patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Reviewed for Patch 11.2.7.
- **11 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Clarified stat priorities.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Reviewed for Patch 11.2.5.
- **09 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Rotational fixes and improvements.
- **09 Sep. 2025 (this page):** Updated for Patch 11.2 hotfixes.
- **15 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated due to hotfixes.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **13 May 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated Puzzling Cartel Chip Section.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **15 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated with hotfix information.
- **15 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated with latest hotfix information.
- **15 Apr. 2025 (this page):** Updated with latest hotfix information.
- **25 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Updated with latest hotfix information.
- **25 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated with latest hotfix information.
- **25 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated with latest hotfix information.
- **25 Mar. 2025 (this page):** Updated with latest hotfix information.
- **23 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reformatted the page.
- **21 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Updated some tips and talents.
- **21 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Improved descriptions of some spells.
- **18 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Improved dungeon tips for Season 2.
- **15 Mar. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated weakauras.
- **15 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Clarified some Season 2 talent choices.
- **15 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Expanded on some advice to make it clearer.
- **13 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Improved trinket recommendations.
- **10 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Added and updated boss tips.
- **26 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** More Patch 11.1 consumable updates.
- **26 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Improved talent descriptions.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated due to hotfixes.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Updated with Patch 11.1 talent changes.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 11.1.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated Cyrce's Circlet information based on buffs and TC work.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Added mention of Cyrce's Circlet
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **21 Nov. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Improved gear recommendations.
- **31 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated with some additional useful Macros.
- **22 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.5 and added more tips.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **10 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Improved tips and talent suggestions for all bosses.
- **15 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Removed pre-season gear.
- **10 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Added more tips.
- **10 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Streamlined some of the rotation advice.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **28 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Improved talent and rotation advice.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Patch 11.0.2.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/holy-priest-the-war-within-pve-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/holy-priest-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **18 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/holy-priest-the-war-within-pve-guide>)):** Added Page.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/holy-priest-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **23 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** More Dragonflight Season 4 trinket updates.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 (this page):** Updated for Dragonflight Season 4.
- **29 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Patch 10.2.6.
- **29 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.2.6.
- **29 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.6 talent changes.
- **29 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 10.2.6.
- **29 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Patch 10.2.6.
- **29 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 10.2.6.
- **29 Mar. 2024 (this page):** Updated for Patch 10.2.6.
- **17 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.2.6.
- **17 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.2.6.
- **17 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.6.
- **17 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **13 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated BiS list.
- **13 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Season 3 Tier set clarifications.
- **08 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** More 10.2 updates including Sporecloak recommendation change.
- **08 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Added more consumable advice.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated with Patch 10.2 changes.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated with Patch 10.2 changes.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated with Patch 10.2 changes.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated with Patch 10.2 changes.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated with Patch 10.2 changes.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated with Patch 10.2 changes.
- **06 Sep. 2023 (this page):** Removed some duplicate information.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.1.7 including new Best in Slot lists.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **12 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Fixed an issue with the talent tree displaying incorrectly.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **16 May 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Minor updates including Sporecloak bug.
- **08 May 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Fixed some broken talent suggestions.
- **08 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Improved talent suggestions ready for Season 2.
- **08 May 2023 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated talent trees and explanations for Season 2.
- **08 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Improved talent suggestions to include more passives.
- **07 May 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated with latest hotfix changes.
- **07 May 2023 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Fixed a talent tree missing a talent.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated with initial Patch 10.1 information.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.1 including Onyx Annulet section.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.1 with new affixes and talent changes.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Patch 10.1.
- **01 May 2023 (this page):** Updated for Patch 10.1.
- **29 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Added some additional macros.
- **31 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Further Patch 10.0.7 updates.
- **31 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Further Patch 10.0.7 updates.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/holy-priest-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7.
- **27 Feb. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Talent tree update.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for patch 10.0.5 talent changes.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for patch 10.0.5 talent changes.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for patch 10.0.5 talent changes.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **21 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Added some missing trinkets.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated Stat Gain per Rating and Stat DR Thresholds.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/holy-priest-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/holy-priest-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/holy-priest-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **22 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/holy-priest-patch-9-2-changes-analysis>)):** Page updated for Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/holy-priest-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/holy-priest-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **19 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/holy-priest-patch-9-1-changes-analysis>)):** Page created.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **14 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-crucible-of-storms-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-the-eternal-palace-raid-guide>)):** This page has been reviewed for Patch 8.3 and no changes are necessary.
- **21 Sep. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-the-eternal-palace-raid-guide>)):** Added more boss tips and updated talent suggestions.
- **28 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-the-eternal-palace-raid-guide>)):** Updated various recommendations after the first Mythic week.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **23 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-crucible-of-storms-raid-guide>)):** Added more tips for both bosses.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-crucible-of-storms-raid-guide>)):** Guide added.
- **08 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** Minor changes to boss advice.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** Added Battle of Dazar'alor tips for Holy Priest.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** Updated for Patch 8.1.
- **25 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** Updated some talent suggestions.
- **31 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** Page added.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Holy Priest leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Priest leveling guide](<https://www.icy-veins.com/wow/priest-leveling-guide>).

1.

### Holy Priest Leveling Guide for Midnight

While Holy Priest is more than capable of leveling, Priests generally level as Shadow as it provides superior
damage, which significantly speeds up the questing process. That said, when venturing into Dungeons and PVP
Battlegrounds, Holy Priest is a fun change of pace and does a great job at keeping your allies alive.

1.1.

#### Leveling Gear Options

Gearing is quite simple as a leveling Holy Priest, especially with the high value of Intellect. Your focus should be on
obtaining as much Intellect on gear as possible, which means typically prioritising item level. Intellect increases the
amount of damage your spells do as well as how much healing they do. Secondary stats provide a similar benefit but
significantly less power while leveling and can largely be ignored.

As a Priest, your weapon's contribution to your damage and healing is through the Intellect it provides. Focusing on
wearing the weapon combination, either staff or main-hand/off-hand, with the most total Intellect should be your
priority. When using Heirloom items, we recommend using those with Critical Strike and Haste, as they will slightly improve the
gameplay flow while leveling.

1.2.

#### Useful Leveling Consumables for Midnight

While endgame enchants and consumables are often disabled or heavily scaled during early leveling, there are still
several items that can be used to make the process smoother, faster, and less frustrating.

The War Within enchants will still work throughout the leveling process, and can be a cheap way to add small boosts
of power. Enchants that grant haste or speed are particularly valuable early on when gear upgrades are sparse.
Prioritise the following.

- [[item:223674]] (helps as you lose haste while leveling)
- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

[[item:212265]] - Combat potions that remain usable at lower levels can significantly speed up difficult
pulls, elite quests, or story encounters. Stock a small supply for moments where burst damage, healing or survivability
matters. Be sure to use these before you get to max level content!

[[item:241305]] - Having a small stack of health potions reduces reliance on cooldowns and
self-healing, especially during early levels when defensive toolkits are incomplete. These are particularly helpful for
soloing elite quests or accidental overpulls.

Certain consumables can dramatically improve leveling flow.

- [[item:109076]]
- [[item:132516]] or [[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]] or [[item:133576]]

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80 import string for you. You can
follow the point-by-point allocation of the below tree once you start gaining levels in Midnight.

:::talents Holy Priest Level 80 Midnight Leveling
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAMMzsMmxMzYMzALzMzMAAAAmZsNDGPwM2MGjZDmpAYmFMEGWGgBYxMmFAmxMMzgZAMjBA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAMMzsMmxMzYMzALzMzMAAAAmZsNDmZmxmxYMbwMFAzsghwYWGgxALmxsAwMmxMzgZAmZMwA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhlvABNOUXikstHKKQxiqawwIJdmOUcRA-ghiEQRZfjkNOSYeQVsMVl6AB56yEoMB-AAAA-CEMYkow0AUgscA-
```

:::

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

3.1.

#### Damage Rotation

**等级 1–9：**Starting at Level 1, you only have [[spell:585]], so just spam this for now.

1. **等级 13 起：**At 13 you get [[spell:88625]], which hits reasonably hard but also disorients the
     target. Its cooldown is reduced by casting [[spell:585]], so despite it having a 1-minute cooldown, you will often be
     able to cast it much sooner.
2. **等级 31 起：**[[spell:200183]] is available at level 51. When cast, this talent provides you with
     increased cooldown reduction applied to [[spell:88625]] when casting [[spell:585]].
3. **等级 16 起：**[[spell:10060]] is another major cooldown added to your kit you should use to squeeze
     out more damage when needed.
4. **等级 10 起：**[[spell:14914]], is a high priority damage spell to cast**等级 17 起：** both
     single target and in AoE thanks to [[spell:372307]].
5. **等级 10 起：**[[spell:132157]] is your first and only spammable AoE spell, which takes over as your
     priority for 3 or more enemies.
6. **等级 2–9：**[[spell:589]] is your first damage over time spell. This should be put up on
     nearly every mob you fight and can be very helpful for tagging enemies quickly or grouping them up.
7. **等级 10 起：**[[spell:585]] is your filler spell for 1 or 2 enemies when nothing else is available to cast.

**等级 22 起：**Most of the time, while questing, you will be grouping numerous enemies up using
[[spell:528]] and then using AoE spells to kill them all together. Use [[spell:8122]] to stop enemies
attacking you if you ever pull too much or need to get away from them. **等级 64 起：**You can also use
[[spell:586]] utilising the [[spell:1250378]] talent to distract enemies while you kill them.

**等级 12 起：**To improve your mobility, you can use this macro to cast [[spell:121536]] on yourself,
granting you a speed boost: **/cast [@player] Angelic Feather**.**等级 52 起：** When you are out of
Angelic Feather charges, you can cast [[spell:33076]] on yourself for a short speed boost thanks to
[[spell:64129]].

**等级 6 起：**At level 6, you learn [[spell:21562]]; make sure you keep this buff up on yourself
and allies at all times.

**等级 15 起：**3.2.

#### **等级 15 起：**Healing Rotation

**等级 15 起：**Once you reach Level 15, you will be able to queue for dungeons. This route is most suited for
a healing spec like Holy Priest. As mentioned earlier in the guide, it is suggested that if you plan on questing through your
levels, you will find it much faster to spec Shadow for most or all of your leveling journey. To get a full
understanding of the complete kit and how to fully utilise it, have a look at our
[rotation page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>).
A summary of our casting priority can also be found below:

- **等级 11 起：**[[spell:2050]] on an injured ally.
- **等级 15–67：**[[spell:34861]] when most of your group is injured.
- **等级 81 起：**[[spell:1262755]] when available.
- **等级 11 起：**[[spell:33076]] on an injured ally.
- **等级 3 起：**[[spell:2061]] for regular healing.
- **等级 10 起：**[[spell:132157]] while moving and healing is required.
- **等级 1 起：**Continue your damage rotation above when no healing is required.

**等级 10 起：**At level 10, you also gain our baseline Mastery ability, [[spell:77485]]. This does
not change your playstyle much at all; it just provides some extra healing from your spells in the form of a
heal-over-time (HoT) effect.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **05 Mar. 2026:** Streamlined the talent tree and added more tips.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated again for Midnight pre-patch.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **28 Aug. 2024:** Improved talent and rotation advice.
- **21 Aug. 2024:** Updated for Patch 11.0.2.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **29 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **12 Jul. 2023:** Fixed an issue with the talent tree displaying incorrectly.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **08 May 2023:** Fixed some broken talent suggestions.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **27 Feb. 2023:** Talent tree update.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **24 Jan. 2023:** Updated for patch 10.0.5 talent changes.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Holy Priest in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Holy Priest

This page is intended for players who are new to the game or class, have no
intentions of raiding Mythic difficulty, or simply want a more straightforward
way to play their specialisation without being overwhelmed by the numerous
subtleties and active abilities that need to be taken into consideration for
optimal play.

Holy Priest has a versatile healing toolkit which, through various talent builds, can swap from being suited to
AoE/raid healing to capable single-target healing. Many Holy Priest spells require standing still to cast, which
requires some forward thinking to play optimally, meaning periods of heavy movement can sometimes be punishing and
should be planned. When learning Holy Priest you should consider these three key aspects.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_serendipity.jpg>) **Use Holy Words First**  
  
    Holy's core feature is [[spell:63733]] which causes most of your abilities to reduce the cooldown of
    [[spell:2050]] and [[spell:34861]]. To make the most of this cooldown reduction, prioritise casting
    your Holy Words before abilities such as [[spell:2061]] and [[spell:596]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_prayerofmendingtga.jpg>) **Regularly Use Short Cooldowns**  
   
    Holy's short cooldown abilities that should be used regularly to maintain optimal healing output and mana efficiency.
    [[spell:33076]] is the most prominent, and should be used when available not only for its mana efficient
    healing, but also to trigger our Apex Talent [[spell:1262755]]. As the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Hero Talent you should
    use its [[spell:120517]] ability regularly to fully maximise Archon's potential.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_surgeoflight.jpg>) **React to Surge of Light Procs**  
  
    Consuming [[spell:109186]] not only reduces the mana cost, but also makes your next related spell cast instant
    allowing you to cast while moving. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon this is even more important due to several talents which
    increase the potency of spells that consume [[spell:109186]], such as [[spell:1247178]] which allow you to
    consume Surge of Light with [[spell:596]].

2.

### Beginner's Guide to Holy Priest in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle   Raid Talents

2.1.

#### Beginner Raid Talents for Holy Priest

These are currently the easiest talent choices to perform in raid content. Note that some of the suggestions
    sacrifice a bit of performance for ease of use, but overall, the difference is not great.

You can easily import the talent tree below by clicking 'Export Talents.'
    and then importing it in-game.

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTBwMLYIMmtBYMwiZmZBgZMzYMMzAMzMgB"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOVXikrstHKKRoqGMMSSmmCEFWA-ghZfYei6GJRbcekmq4UskSwBCi55ZZC-AAAA-CEMYkow0AUgscE-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle   Dungeon Talents

2.2.

#### Beginner Mythic+ and Delve Talents for Holy Priest

For Mythic+ and Delves, we suggest ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle for its simplicity and flexibility. However, for
    [Delves](<https://www.icy-veins.com/wow/delves-guide>) specifically, we highly suggest you do them as Shadow instead of Holy due to the increased damage
    output as Shadow. If you still choose to do them alone, as Holy, or are doing them in a group as Holy, then use this
    build.

You can easily import the talent tree below by clicking 'Export Talents.' and then importing it in-game.

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAghxsMMjZGDzwYZmZmBAAAwYmlZwMzM2MmZMgZKAmZBDhxsNAjBWMmZBgZMzYMYGgZmBMA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZfYeGJRdekmq4Usk648sMB-AAAA-CEMYkow0AUgscE-
```

:::

### Holy Priest   Basic Rotation

2.3.

#### Raid Healing for Holy Priest

Raid healing is primarily focused on AoE group healing, as outlined below. A lot of your decision-making will be
    based on incoming damage and the cooldowns you have available. Holy Priest is best played using our short cooldown
    spells like [[spell:2050]] and [[spell:33076]] as often as practical. Do not think of these as
    cooldowns to save for an unknown future situation; use these regularly to benefit from their high healing and lower
    mana cost.

Below is the basic priority you should follow in raids. You should not cast a spell that will mostly overheal, so
    keep this in mind while working through the priority list and skip an item if there is likely to be significant
    overhealing.

Note that the below rotation information is valid with or without the current tier set.

1. [[spell:2050]] on an injured ally.
2. [[spell:33076]] on cooldown.
3. [[spell:1262755]] for general purpose healing.
4. [[spell:2061]] for general purpose healing.
5. [[spell:585]] an enemy when no healing is required.
6. [[spell:132157]] if you need to move and no healing is required.

[[spell:1262755]], [[spell:2061]] and [[spell:132157]] will be the majority of your casts whenever your
    short-cooldown spells are unavailable. Many of your [[spell:1262755]] and [[spell:2061]] casts will be
    instant thanks to [[spell:109186]]. When there is nothing to heal, you should be casting [[spell:585]] or
    [[spell:132157]] as they have a chance to generate additional stacks of [[spell:109186]].
    [[spell:33076]] does not require much thought, casting it on an injured ally is best.

[[spell:200183]] should be used whenever available to help counter heavy raid-wide damage. During Apotheosis
    your rotation does not change, but you will notice [[spell:2050]] is available much more often. It is
    important during Apotheosis not to cap your charges of [[spell:2050]] by casting it as soon as it is
    available.

[[spell:64843]] should be used during a period of heavy raid-wide damage. Keep in mind, however, that your raid
    leader may instruct you to use it at a very specific time.

The Season 2 tier set is largely a passive bonus. The set bonus has no major gameplay implications and encourages
    you to cast [[spell:33076]] as often as possible.

2.4.

#### Dungeon Healing for Holy Priest

Dungeon healing is primarily focused on triage healing, which is prioritising your allies who are in the most
    danger first. A lot of your decision-making will be based on incoming damage and the cooldowns you have available.
    It is better to use your cooldowns early and often than it is to save them for unknown future situations.

Below is the basic priority you should follow in dungeons. You should not cast a spell that will mostly overheal,
    so keep this in mind as you work through the priority list and skip an item if there is likely to be significant
    overheal.

1. [[spell:2050]] on an injured ally.
2. [[spell:33076]] preferably on an injured ally.
3. [[spell:1262755]] on an injured ally.
4. [[spell:2061]] on an injured ally.
5. Deal damage when no healing is required:
           
   
   1. [[spell:88625]].
   2. [[spell:14914]].
   3. [[spell:132157]] for 3 or more targets.
   4. [[spell:585]] for 1 or 2 targets.

For heavy damage, use either [[spell:64843]] or [[spell:200183]] and continue your normal rotational
    priority. Because Apotheosis increases the amount of cooldown reduction your abilities provide,
    [[spell:2050]] will be available much more often and should be used as it is ready. If this is still not
    enough, you also have access to [[spell:47788]].

Dealing with damage while in dungeons is often overlooked by healers. While any additional damage is beneficial to
    your group, it should not come at the cost of keeping your group alive, which is your main priority. [[spell:14914]]
    is your main damage-dealing ability. When Holy Fire is on cooldown, [[spell:585]] is the best spell to cast as it costs
    very little Mana and has a chance to trigger [[spell:109186]].

2.4.1.

##### Important Spells and Tips

Regardless of the content you are tackling, you should be aware of a few basic
    abilities.

- [[spell:527]] is used in most content, as many enemies will place Magic or Disease debuffs on your allies,
        which can be removed by casting Purify on the affected ally. It is commonly referred to as **Dispel**.
- [[spell:21562]] is a group-wide buff that lasts for 60 minutes or until death and provides an
        additional 5% Stamina. Apply this before getting started on a dungeon or boss.
- [[spell:19236]] is an active defensive ability with a 90-second cooldown. It heals you for a portion
        of your maximum health and also increases your maximum health for some time; it should be used when your own life
        is in danger.

While we have a larger section dedicated to walking through common mistakes and how to avoid them, a couple are
    worth mentioning now. These focus on our two most valuable resources: Mana and time.

Mana is very easy to waste without realising it. The most common way is spamming inefficient spells during
    downtime or periods of low healing. Stick to [[spell:132157]] or [[spell:585]] if you want to remain active during
    these periods, as both of these spells also have a chance to trigger [[spell:109186]]. Casting DPS spells
    outside of Holy Nova and Smite, when Mana is going to be a concern, is also a way to accidentally consume additional
    Mana without realising it.

Time is a bit more difficult to quantify, but one really easy thing you can do to get yourself more healing time
    in both dungeons and raids is to focus on minimizing your movement to maximise the time that can be spent casting
    spells with a cast time. For those periods when you do have to move, you can rely on the array of instant cast
    spells available to us, including [[spell:33076]], [[spell:2050]], [[spell:34861]],
    and instant healing from consuming stacks of [[spell:109186]].

2.4.2.

##### Cooldowns

As a Holy Priest, you have three baseline cooldowns. Here is how you should
    use them.

- [[spell:64843]] should be used during periods of very intense damage.
- [[spell:200183]] should also be used during periods of very intense damage.
- [[spell:47788]] should be used depending on many factors, including your group's instructions.
        If you do not have to save Guardian Spirit for a specific event, then just use it as a "life-saver" on the tank or
        another ally who needs it.

2.4.3.

##### Apex Talent: ![Benediction Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_priest_holywordlife.jpg>) Benediction

The periodic [[spell:1262755]] procs are triggered by regularly casting [[spell:33076]]. When
    triggered, [[spell:2061]] is replaced with [[spell:1262755]] for your next cast, increasing the healing done
    and triggering a [[spell:238136]]. Due to the added healing, [[spell:1262755]] is a high-value spell to
    use and should be prioritised as part of your rotation whenever it triggers.

### Holy Priest   Stat Priority

2.5.

#### Stat Priority for Holy Priest

Currently, Intellect is your highest-rated stat. As such, you should prioritise item level when comparing
gear to wear. With two items of the same item level, you will want to prioritise stats as follows for raids.

Critical Strike

Mastery

Versatility

Haste

For dungeon content, the priority is:

Critical Strike

Versatility

Haste

Mastery

For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>).

### Blizzard   Combat Assistant

2.6.

#### Should I Use The Combat Assistant Feature?

The Combat Assistant for healers does not help you heal. Instead, it provides a basic 1-button damage-dealing
    rotation that adjusts slightly depending on your talents. Be mindful that it
    does not take into account whether you are moving or not. So you would need
    to manually cast a spell if you are trying to deal damage while moving, and the Combat Assistant's
    suggestion has a cast time. The Combat Assistant will also not suggest long-cooldown spells such as [[spell:120517]] or
    [[spell:200183]].

The basic rotation involves using [[spell:88625]] on cooldown; [[spell:14914]] regularly; for single
    target, filling the gaps with [[spell:585]]; for many targets, using [[spell:132157]].

It is important to note that the Combat Assistant is not a replacement for understanding your class and its
    mechanics. It is a tool to help you improve your damage output without having to focus on multiple extra buttons, and is
    a solid alternative for adding damage without adding more things to think about when healing.

For basic information on how this new feature works, please visit our [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) guide.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **25 Aug. 2026:** Updated builds with the latest theorycrafting.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **15 Mar. 2025:** Expanded on some advice to make it clearer.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **29 Mar. 2024:** Updated for Patch 10.2.6.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **08 May 2023:** Improved talent suggestions to include more passives.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **24 Jan. 2023:** Updated for patch 10.0.5 talent changes.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Holy Priest in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Holy Priest

Holy Priest has two Hero talents that have completely different points of focus.
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon adds the spell [[spell:120517]] to your arsenal which brings
with it an increase in [[spell:109186]] procs to react to, along with
[[spell:1247178]] to give you another spell to consume them with.
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle is a simpler choice, centered around increasing the healing from
the passive sources of healing like [[spell:139]] and [[spell:33076]],
while also adding some spot-healing capability through [[spell:1246799]].

- **Raid Healing** - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle is currently the stronger choice as it provides more constant healing
    capability. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon is competitive but has much more of its healing inside the [[spell:200183]] and
    [[spell:120517]] windows which can lead to higher overheal.
- **Dungeon Healing** - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle are both
    viable options for dungeon healing. While Archon has improved burst healing,
    doing so in a 5-man environment can consume a lot more Mana. The sustained healing
    throughput from Oracle makes it a strong choice, especially as Oracle also excels
    at dealing more damage itself, which is quite useful to help beat the Mythic+ timer.

Aside from Hero talents, the other major differentiator between builds is which
Holy tree capstone talents are taken. [[spell:1246517]] is popular as it
has great synergy with the rest of the tree and simplifies the healing rotation
while providing similar output to the other options. [[spell:471504]] is a solid
passive healing increase. [[spell:392988]] is not a strong increase, but is
readily accessible if you are taking one of the other two previously mentioned capstones.
[[spell:390992]] is the other capstone worth mentioning as it changes your
gameplay to bolster the cycle of [[spell:596]] getting buffed by your
single-target spells. Currently Lightweaver is tuned to do a similar amount of healing
as other options, but requires more mana and is less forgiving of mistakes,
so it is generally avoided.

**Quick Start Import Codes:**

:::talents Holy Priest Raid - Oracle Easy Mode
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTBwMLYIMmtBYMwiZmZBgZMzYMMzAMzMgB"
}
```
:::

:::talents Holy Priest Raid - Archon
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwwsMDzMzMMDzYAzUAgZWMDziBAGD2MzMLAaGzMGDzMbLDwAGA"
}
```
:::

:::talents Holy Priest Delves & M+ - Oracle
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAgZmxsMMjZGDzwYZmZmBAAAwYmlZwMzM2MmZMgZKAmZBDhxsNAjBWMzMLAMjZGjBzAMzMgB"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Oracle

Raid

recommended

Mythic+/Delve

mythic+

Archon

Raid

Mythic+ Lasting Words

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Raid Build

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Raid Build focuses on a lot of passive healing from [[spell:33076]] talents and direct
healing from [[spell:1246799]]. You then fill in the gaps between all your [[spell:2050]] and
[[spell:33076]] casts with [[spell:2061]] and it's buffed version, [[spell:1262755]] whenever it
triggers. Combined with the healing from [[spell:139]], [[spell:77489]] and [[spell:1246802]], ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle
provides a significant amount of consistent raid-wide healing with low overheal. This build is more mana efficient than
a [[spell:390992]] build.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Mythic+ Talents

The main reason for going ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle is a combination of personal defence, damage output and consistent
healing.

For [Delves](<https://www.icy-veins.com/wow/delves-guide>), we highly suggest you do them as Shadow instead of Holy due to the increased damage output
as Shadow. If you still choose to do them alone as Holy, or are doing them in a group as Holy, then use this build.
The most worthwhile change is for Delves, where you should drop [[spell:391161]], or if solo,
[[spell:73325]], and then talent into [[spell:205364]]. Dominate Mind can be exceptionally useful in
Delves to take control of an enemy to not only deal additional damage but also to absorb damage that would otherwise
hit you and your allies.

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Raid Build

The Raid ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Build is centered around large [[spell:109186]]-buffed
[[spell:596]] casts thanks to [[spell:1247178]], alongside the consistent healing from
[[spell:2050]], and [[spell:1262755]]. [[spell:120517]] should be paired up with [[spell:200183]] or
[[spell:64843]] for powerful raid healing whenever possible.

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Mythic+ Lasting Words Talents

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Lasting Words build provides an alternative to the Oracle builds with slightly weaker overall
throughput. It provides consistent bursts of healing with each [[spell:120517]] cast and the additional
[[spell:109186]] procs are great for party triage and contribute to even more [[spell:2050]] casts.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTBwMLYIMmtBYMwiZmZBgZMzYMMzAMzMgB"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOVXikrstHKKRoqGMMSSmmCEFWA-ghZfYei6GJRbcekmq4UskSwBCi55ZZC-AAAA-CEMYkow0AUgscE-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAgZmxsMMjZGDzwYZmZmBAAAwYmlZwMzM2MmZMgZKAmZBDhxsNAjBWMzMLAMjZGjBzAMzMgB"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZfYeGJRdekmq4Usk648sMxwwsA-AAAA-CEMYkow0AUgscE-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwwsMDzMzMMDzYAzUAgZWMDziBAGD2MzMLAaGzMGDzMbLDwAGA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOVXikrstHKKRoqGJMMSSmmEFWA-gZabfYeikmoq4GJRVs08k6ABx88EoMB-AAAA-DIMg0IY4IhBQxS-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAMMzsMgZmZYmZGLzMzMAAAAGzsMDmZmxmxMjBMTBAmZzMMbGAYMYzMjFANjZGjBzstMADYA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZabfjkSTUVYceUsk6ABx88EoMB-AAAA-DIMi0Ic4IhBQxS-
```

:::

### 天赋方案 0-0

1.5.

#### Flexible Talents

The **Holy Priest** tree has several talent points or groups of talent points that can be moved around without
    affecting the core playstyle:

- [[spell:419110]] should be your default choice over [[spell:372370]] going into every encounter.
        The only time Gales of Song is worth taking is if for some reason you have planned **every single one** of your
        casts more than 3 minutes apart.
- It is a healing loss to swap out [[spell:1215265]] for either [[spell:392988]] or [[spell:391186]].

The **Class Tree** has some flexibility, and there are multiple different talents you can change around
    depending on the encounter and your personal preference. The following are all great candidates to be situationally
    removed without altering your playstyle:

- [[spell:390632]] can be dropped if there are no diseases to dispel.
- [[spell:528]] can also be dropped if there are no diseases to dispel and no magic debuffs to purge.
- [[spell:341167]] can be dropped if the encounter doesn't have anything for [[spell:527]] or
        [[spell:32375]].
- [[spell:390676]] can be dropped if you really need another point, as it's the lowest value throughput
        talent.
- [[spell:108945]] or a point in [[spell:390667]] are the lowest impact talents to drop if you need
        an extra point in the bottom third of the tree.

In place of them, there are several talents that are situationally useful and can be taken:

- [[spell:64129]] can be taken for extra mobility and survivability on movement-heavy encounters.
- [[spell:108942]] to remove snares.
- [[spell:238100]] for more survivability.
- [[spell:8122]] for extra crowd control.

In general it is not a good idea to talent into [[spell:1246549]] as it removes [[spell:132157]] as a
    spammable filler spell.

### 天赋方案 1-0

1.6.

#### Flexible Talents

The **Holy Priest** tree has several talent points or groups of talent points that can be moved around without
  affecting the core playstyle:

- [[spell:1215245]] can be swapped for [[spell:1215241]] if you are unable to make use of the extra
      [[spell:200183]] duration.
- [[spell:449874]] gives roughly the same benefit as [[spell:454001]] and can be freely
      swapped depending on your preference, provided you can make use of the extended [[spell:200183]] duration.
- [[spell:453726]] can be swapped for [[spell:453729]] if you can find a way to exploit the
      added duration with [[spell:391124]]. If you do this, you should also consider taking [[spell:196707]] by
      dropping either [[spell:390977]] or [[spell:1247166]].
- [[spell:419110]] should be your default choice over [[spell:372370]] going into every encounter.
      The only time Gales of Song is worth taking is if for some reason you have planned **every single one** of your
      casts more than 3 minutes apart.

The **Class Tree** has some flexibility, and there are multiple different talents you can change around
  depending on the encounter and your personal preference. The following are all great candidates to be situationally
  removed without altering your playstyle:

- [[spell:390632]] can be dropped if there are no diseases to dispel.
- [[spell:528]] can also be dropped if there are no diseases to dispel and no magic debuffs to purge.
- [[spell:341167]] can be dropped if the encounter doesn't have anything for [[spell:527]] or
      [[spell:32375]].
- [[spell:390676]] can be dropped if you really need another point, as it's the lowest value throughput
      talent.
- [[spell:108945]] or a point in [[spell:390667]] are the lowest impact talents to drop if you need
      an extra point in the bottom third of the tree.

In place of them, there are several talents that are situationally useful and can be taken:

- [[spell:64129]] can be taken for extra mobility and survivability on movement-heavy encounters.
- [[spell:108942]] to remove snares.
- [[spell:459559]] for more range.
- [[spell:8122]] for extra crowd control.

In general it is not a good idea to talent into [[spell:1246549]] as it removes [[spell:132157]] as a
  spammable filler spell.

### 天赋方案 1-1

1.7.

#### Flexible Talents

The **Class Tree** has limited flexibility without dropping important defensive and throughput talents.

The **Holy Tree** doesn't have many potential talent change options that don't affect your overall healing
output and playstyle.

For [Delves](<https://www.icy-veins.com/wow/delves-guide>), we highly suggest doing them as Shadow. If you are choosing to stay Holy, you should do them as
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle.

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your output, while others are more defensive in nature.

We recommend you pick the following bonuses, but as you can freely switch between them at any time, feel free to
experiment with other options yourself if you feel you do not get enough mileage out of the recommended options:

- Tier 1: [[spell:1279599]]
- Tier 2: [[spell:1279603]]
- Tier 3: [[spell:1287555]]
- Tier 4: [[spell:1279609]]
- Tier 5: [[spell:1279614]]

[[spell:1279599]] is a better choice than [[spell:1279596]]. For the defensive node, you
should choose either [[spell:1279603]] or [[spell:1279604]]. For the final node, while we suggest
[[spell:1279614]] as it provides a bit more reliable healing, they all provide approximately the same amount of
value so it is largely personal preference which one you run with.

3.

### Apex Talent: ![Benediction Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_priest_holywordlife.jpg>) Benediction

The Holy Priest apex talent is [[spell:1262755]], which provides the following benefits as you put points into
it.

- [[spell:1262755]] (1 point): [[spell:33076]] bounces periodically transform your next cast of
    [[spell:2061]] into [[spell:1262755]], increasing the healing done and triggering a
    [[spell:238136]].
- [[spell:1262758]] (2 points): Increases all healing done, and further increases the healing of
    [[spell:238136]].
- [[spell:1262760]] (1 point): Causes each pulse of [[spell:64843]] to trigger [[spell:238136]].
    After casting [[spell:2050]], your next [[spell:2061]] is upgraded to [[spell:1262755]].

**How it works:** The periodic [[spell:1262755]] procs are triggered by regularly casting
[[spell:33076]]. When triggered, [[spell:2061]] is replaced with [[spell:1262755]] for your next
cast, doing increased healing and triggering a [[spell:238136]]. Due to the added healing,
[[spell:1262755]] is a high value spell to use and should be prioritised as part of your rotation whenever it
triggers.

:::details TCDoes ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Trigger [[spell:1262755]] More than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Due to More [[spell:33076]]?
No,

[[spell:1262755]]

triggers at a normalised rate, meaning the procs per minute should not differ between the
two Hero talents. This is true as long as you cast

[[spell:33076]]

regularly. For both Hero talents it is
important to cast

[[spell:33076]]

as often as possible to maximise the number of

[[spell:1262755]]

procs.

:::

4.

### Hero Talents

Starting at level 71, Hero Talents allow players the ability to shape and focus their 
gameplay by picking one of two mutually exclusive options. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle 
and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon are the options given to Holy Priest.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon has a focus on buffing your [[spell:120517]] casts. The additional stronger [[spell:109186]]
procs are excellent at improving our triage healing capabilities including the ability to bolster our group healing
through [[spell:1247178]] enabling [[spell:596]] to consume [[spell:109186]]. Finally, the additional
healing during [[spell:200183]] further improves our ability to react to heavy group damage.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle focuses around regular usage of [[spell:33076]] to generate constant healing to your group
through increased healing to Prayer of Mending, [[spell:139]] and [[spell:1246802]]. Oracle also provides single-target
triage through [[spell:1246799]].

5.

### PvP Talents (War Mode) for Holy Priest

In the open world, you can go into "War Mode." Enabling War 
Mode provides the following benefits:

- PvP talents enabled in the outdoor world.
- Increase in World Quest rewards at maximum level.
- More experience gained while levelling.
- Earn Conquest Points, which can be spent on PvP gear.

With the benefits of enabling War Mode for levelling and PvE content, it is recommended enabling the feature to
maximize your levelling and rewards at maximum level if you are comfortable with PvP. However, you will make yourself
available for open-world PvP, and the possibility of being attacked by other players while levelling or doing World
Quests exists.

In this section, we will rank the PvP talents best for levelling and doing solo / small group PvE content. Below is a
ranking of [Holy Priest](<https://www.icy-veins.com/wow/holy-priest-pve-healing-guide>)-specific PvE talents.

- [[spell:1256245]] can be used to avoid dangerous attacks.
- [[spell:196162]] is great for rapidly removing dangerous debuffs.
- The final choice is typically [[spell:357481]] for solo content, or [[spell:215982]] if doing
    world content with a group.

6.

### Changelog

:::details 历史更新记录
- **17 Oct. 2026:** Fixed a the Oracle Mythic+ build export.
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **25 Aug. 2026:** Updated builds with the latest theorycrafting.
- **17 Aug. 2026:** Updated builds for upcoming hotfixes.
- **16 Aug. 2026:** Fixed broken Archon Lightweaver build.
- **12 Aug. 2026:** Fixed broken Archon Lightweaver build.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 and Omnium Folio.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Updated flex talents.
- **17 Mar. 2026:** Fixed an incorrect talent layout.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated again for Midnight pre-patch.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **15 Apr. 2025:** Updated with latest hotfix information.
- **25 Mar. 2025:** Updated with latest hotfix information.
- **15 Mar. 2025:** Clarified some Season 2 talent choices.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **29 Mar. 2024:** Updated for Patch 10.2.6.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Updated with Patch 10.2 changes.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **08 May 2023:** Updated talent trees and explanations for Season 2.
- **07 May 2023:** Fixed a talent tree missing a talent.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **24 Jan. 2023:** Updated for patch 10.0.5 talent changes.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Holy Priest, depending on the type of damage your group
is receiving. We also have advanced sections about cooldowns, procs, etc.
in order to minmax your healing output and your mana efficiency. All our
content is updated for World of Warcraft Patch
12.1.5.

1.

### Holy Priest Gameplay and Rotation Guide

Welcome to our Holy Priest Rotation section. Here you will learn everything you need to know about
properly healing as a Holy Priest in Raiding and Mythic+ scenarios.

Healing is primarily based on your ability to react to the damage that the group takes, and as such, there is no set
rotation. Rather, you must understand what spells are best suited to the different situations that can occur during an
encounter.

:::details TipsHow Do I Heal While Moving?
Movement in encounters is unavoidable. Thankfully though, most encounters are scripted in a reasonably predictable
manner, allowing you to not only plan your positioning ahead, but sometimes, eliminate movement entirely. Utilising

[[spell:109186]]

procs to cast instant heals, as well as using instant cast spells

[[spell:33076]]

and

[[spell:2050]]

can help you heal while moving. If you have no instant casts available, you can also use

[[spell:132157]]

to generate

[[spell:109186]]

procs while moving.

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon

Raid

Mythic+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle

Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:88625]]

[[spell:596]]

[[spell:120517]]

[[spell:14914]]

[[spell:1246549]]

[[spell:1247178]]

[[spell:1246799]]

[[spell:390992]]

[[spell:1246517]]

[[spell:392988]]

[[spell:372307]]

[[spell:372616]]

### Raid Healing Rotation

Raid healing is primarily focused on group healing and priority triage on targets that may be in danger of death. The next section outlines the priority you should follow in raids. You should not cast a spell that will mostly overheal, so keep this in mind as you work through the priority list. Skip an item if there is likely to be significant overheal.

**适用条件：Halo（启用）。** **Important:** When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon, you should aim to use [[spell:120517]] just before either [[spell:64843]] or [[spell:200183]]. While this won't always be possible, do not hold [[spell:120517]] for longer than 30-seconds or it will result in a noticeable reduction in healing done.

[[spell:200183]] and [[spell:64843]] are powerful cooldowns you should be using regularly. For more information on how and when to use them, see the Major Cooldowns section below.

1. **适用条件：Ultimate Serenity（未启用）。** [[spell:34861]] when a cluster of your raid is injured.
2. [[spell:2050]] on an injured ally.
3. **适用条件：Divine Image（启用）；Holy Word: Chastise（启用）。** [[spell:88625]] to trigger [[spell:392988]].
4. **适用条件：Prompt Prognosis（启用）。** [[spell:33076]] on cooldown, preferably on an injured ally.
5. **适用条件：Prompt Prognosis（未启用）。** [[spell:33076]] on cooldown, usually on melee.
6. **适用条件：Spiritwell（启用）；Prayer of Healing（启用）。** [[spell:596]] with 1 or more stacks of [[spell:109186]]
7. [[spell:1262755]] on an injured ally.
8. **适用条件：Lightweaver（启用）；Prayer of Healing（启用）。** [[spell:596]] with 1 or more stacks of [[spell:390992]]
9. **适用条件：Prayer of Healing（启用）；Spiritwell（未启用）。** [[spell:2061]] with 1 or more stacks of [[spell:109186]]
10. **适用条件：Prayer of Healing（启用）。** [[spell:596]] for general purpose group healing.
11. **适用条件：Prayer of Healing（启用）。** [[spell:2061]] in an emergency on an ally near death.
12. **适用条件：Prayer of Healing（未启用）。** [[spell:2061]] on an injured ally.
13. [[spell:132157]] while moving or when little healing is required.
14. [[spell:585]] an enemy when no healing is required.

**适用条件：Lightweaver（启用）；Spiritwell（启用）。**

:::details FAQShould I Cast Prayer of Healing Without Lightweaver or Surge of Light?
No, you should not. If you do not have either

[[spell:390992]]

or

[[spell:109186]]

, you should instead cast a

[[spell:2061]]

or

[[spell:1262755]]

to trigger a new

[[spell:390992]]

buff for your next

[[spell:596]]

.

:::

Your general goal while healing is casting as many short-cooldown spells as possible. [[spell:2050]], [[spell:34861]], and [[spell:33076]] — despite all having a cooldown — should be thought of as rotational spells and cast almost as soon as they are available. Using lower priority spells when one of your Holy Words is available is considered a mistake as it wastes mana and does less healing. An example of this mistake would be casting [[spell:2061]] instead of [[spell:2050]]; [[spell:596]] instead of [[spell:34861]].

Some tips for utilising your talents:

- **适用条件：Spiritwell（启用）；Prayer of Healing（启用）。** With ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon's talent [[spell:1247178]], you should aim to use all of your [[spell:109186]] procs on [[spell:596]]. This maximizes the healing output from [[spell:453799]] and also makes the most of the mana reduction from [[spell:109186]].
- **适用条件：Halo（启用）。** With ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon, [[spell:120517]] should be paired with your major cooldowns [[spell:200183]] and [[spell:64843]] as much as possible. See the cooldowns section below for more details on maximizing their usage.
- **适用条件：Lightweaver（启用）；Prayer of Healing（启用）。** [[spell:1262755]] is used to generate [[spell:390992]] stacks. These stacks should then be spent on [[spell:596]] for increased healing. You should generate enough Lightweaver just from your Benediction casts, casting [[spell:2061]] without the [[spell:109186]] buff wastes mana.
- **适用条件：Prompt Prognosis（启用）。** With ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle, [[spell:33076]] should be cast on injured allies where possible to make the most of [[spell:1246799]]. You should not delay your cast of [[spell:33076]] if you are at maximum charges to wait for an injured ally. Instead, cast [[spell:33076]] once to get it on cooldown immediately.
- **适用条件：Empyreal Blaze（启用）。** [[spell:372616]] increases your damage output significantly at the cost of fewer [[spell:109186]] procs due to [[spell:14914]] being unable to trigger [[spell:109186]]. You should stick to [[spell:585]] as your primary damage dealing ability if healing is your primary focus.

1.1.

#### Mana Management Tips

If you're struggling with mana on longer encounters, here are some quick tips to help improve your efficiency without sacrificing too much healing done.

Make the most of our efficient cooldown abilities. These should be thought of as rotational spells and used as often as possible when your raid is injured. This includes:

- **适用条件：Halo（未启用）。** Longer cooldowns [[spell:64843]] and [[spell:200183]].
- **适用条件：Halo（启用）。** Longer cooldowns [[spell:64843]], [[spell:200183]], and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archons [[spell:120517]].
- **适用条件：Ultimate Serenity（未启用）。** Short cooldown spells [[spell:2050]], [[spell:34861]] and [[spell:33076]].
- **适用条件：Ultimate Serenity（启用）。** Short cooldown spells [[spell:2050]] and [[spell:33076]].

**适用条件：Spiritwell（启用）。** Prioritise using your [[spell:109186]] casts on [[spell:596]] as often as possible. Surge of Light provides a mana cost reduction to spells that consume it, helping you do more healing using less mana.

**适用条件：Spiritwell（启用）。** Only use [[spell:2061]] if someone is in danger of death and you have nothing else available such as [[spell:47788]] to save them.

Cast plenty of [[spell:132157]] and [[spell:585]] whenever your allies don't need healing. Not only does this help by triggering more [[spell:109186]], but it also saves you mana you may ordinarily use on casts into healthy allies that will overheal.

### Mythic+ Rotation

Dungeon healing is primarily focused on casting your short-cooldown spells regularly. A lot of your decision-making will be based on incoming damage and the cooldowns you have available. It is better to use your cooldowns early and often, rather than save them for unknown future situations.

Below is the priority you should follow in dungeons. You should not cast a spell that will result in mostly overhealing; keep this in mind as you work through the priority list. Skip an item if there is likely to be significant overhealing.

1. [[spell:64843]] for large amounts of group-wide damage.
2. [[spell:200183]] with 0 or 1 charge of each Holy Word.
3. **适用条件：Ultimate Serenity（未启用）。** [[spell:34861]] when a cluster of allies are injured.
4. [[spell:2050]] on an injured ally.
5. **适用条件：Halo（启用）。** [[spell:120517]] when most of your allies are injured.
6. **适用条件：Holy Word: Chastise（启用）；Divine Image（启用）。** [[spell:88625]] to trigger [[spell:392988]]
7. [[spell:1262755]] on an injured ally.
8. **适用条件：Prompt Prognosis（启用）。** [[spell:33076]] on cooldown, preferably on an injured ally.
9. **适用条件：Prompt Prognosis（未启用）。** [[spell:33076]] on cooldown, usually on melee.
10. **适用条件：Spiritwell（未启用）。** [[spell:2061]] with 1 or more stacks of [[spell:109186]]
11. **适用条件：Spiritwell（启用）；Prayer of Healing（启用）。** [[spell:596]] with 1 or more stacks of [[spell:109186]].
12. **适用条件：Prayer of Healing（启用）；Lightweaver（未启用）。** [[spell:596]] for general purpose healing.
13. **适用条件：Prayer of Healing（未启用）。** [[spell:2061]] for general purpose healing.
14. **适用条件：Prayer of Healing（启用）；Lightweaver（启用）。** [[spell:596]] with 1 or more stacks of [[spell:390992]] for general purpose healing.
15. **适用条件：Prayer of Healing（启用）；Lightweaver（启用）。** [[spell:2061]] with less than 4 stacks of [[spell:390992]].
16. **适用条件：Holy Word: Chastise（启用）。** [[spell:88625]] an enemy when no healing is required.
17. **适用条件：Empyreal Blaze（启用）。** [[spell:14914]] an enemy when no healing is required.
18. **适用条件：Lightburst（未启用）。** [[spell:132157]] while moving or when little healing is required.
19. [[spell:585]] an enemy when no healing is required.

### Damage

When your focus is raid healing, your only damage spells should be [[spell:585]] or [[spell:132157]]. They both cost very little Mana and have a chance to generate [[spell:109186]] procs. [[spell:109186]] procs are not only a healing increase, but also assist with movement and mana conservation. If an encounter demands damage over healing, and you find Mana is not a problem, then you can go ahead and use the full damage rotation.

Dealing with damage while in dungeons is often overlooked by healers. While any additional damage is beneficial to your group; it should not come at the cost of keeping your group alive, which is your main priority. [[spell:14914]] is your main damage dealing ability when paired with [[spell:372307]] and [[spell:372616]].

Damage spell priority:

1. **适用条件：Halo（启用）。** [[spell:120517]]
2. [[spell:14914]]
3. **适用条件：Holy Word: Chastise（启用）。** [[spell:88625]]
4. **适用条件：Lightburst（未启用）。** [[spell:132157]] (4+ enemies)
5. **适用条件：Lightburst（未启用）。** [[spell:585]] (1-3 enemies)
6. **适用条件：Lightburst（启用）。** [[spell:132157]]
7. **适用条件：Lightburst（启用）。** [[spell:585]]

2.

### Midnight Season 2 Tier Set

The Season 2 tier set is largely a passive bonus. The set bonus has no major gameplay implications and encourages you
to cast [[spell:33076]] as often as possible to maximise the amount of additional healing the set bonus
provides through the stat buff and additional [[spell:139]]s.

3.

### Class and Spec Mechanics Explained

### Holy Words and [[spell:63733]]

3.1.

#### Holy Words

Casting your Holy Words as often as possible is an important part of playing Holy Priest. Each Holy Word gains
    cooldown reduction through [[spell:63733]] when an associated spell is cast, allowing you to cast them even more frequently:

- [[spell:2050]] - 6 seconds each from [[spell:2061]].
- [[spell:34861]] - 6 seconds from [[spell:596]].
- [[spell:88625]] - 4 seconds each from [[spell:585]] and [[spell:132157]].

When talented into [[spell:390994]] you also gain cooldown reduction from additional spells:

- [[spell:2050]] - 4 seconds from [[spell:33076]].
- [[spell:34861]] - 4 seconds from [[spell:120517]].
- [[spell:88625]] - 4 seconds from [[spell:14914]].

When talented into [[spell:1246517]], anything that would ordinarily trigger cooldown reduction for
    [[spell:34861]] instead reduces the cooldown of [[spell:2050]].

There are multiple ways to further increase the cooldown reduction you gain from casting spells:

- [[spell:200183]] - While this buff is active, you gain 3 times as much cooldown reduction to all Holy Words.
- [[spell:196985]] - When talented, you gain 10% increased cooldown reduction to all Holy Words per point.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archons [[spell:453828]] - When talented, provides Holy Word cooldown reduction when consuming [[spell:109186]].

While you do not need to actively manage this mechanic in any way, it is
    very important that you are aware of its existence and that you constantly
    monitor the remaining cooldowns of your Holy Words so that you can use them
    as soon as they become available.

### [[spell:77489]]

3.2.

#### Mastery: Echo of Light

[[spell:77485]] is a passive ability that causes your direct healing spells to leave a heal over time
    effect on the target. This effect lasts for 4 seconds and heals for a percentage of the original heal. The amount
    healed is increased by your Mastery stat. Successive applications of this HoT stack and will extend the duration of
    the HoT for a short period. Mastery healing is never lost by successive casts on the same target, the additional
    casts just make the Echo of Light healing ticks stronger.

There is no benefit in tracking this buff, as there are no interactions with it worth cluttering your UI with
    the additional icons.

[[spell:77485]] also increases the amount that your [[spell:139]]s tick for.

The talent [[spell:390967]] slightly increases the healing Mastery does, while also increasing the
    healing done by [[spell:139]].

[Holy Priest Stat Priority](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)

### [[spell:392988]]

3.3.

#### Divine Image

When talented into [[spell:392988]], your playstyle should not really change whether or not you have a Naaru
    active. You still want to emphasize casting whatever suits your current situation, and the Naaru will mirror that
    appropriately. The only exception to this is [[spell:88625]], which can be used right before periods of
    intense healing to provide an added burst.

The only worthwhile minor playstyle adjustment that can be made to better utilise [[spell:392988]] is to
    ensure you try to cast [[spell:33076]] on a tightly grouped clump of allies, as the bounce radius of
    [[spell:196813]] is quite small. This is most often the melee DPS in your raid, and is not a significant enough
    gain to worry about if doing so will delay your [[spell:33076]] casts.

Below shows you most of the common spells that will trigger [[spell:392988]] to try and cast a similar spell.

<table>&#10;<tr>&#10;<th>Your Spell</th>&#10;<th>[[spell:392988]]</th>&#10;<th>Your Spell</th>&#10;<th>[[spell:392988]]</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<ul>&#10;<li>[[spell:2061]]</li>&#10;<li>[[spell:2050]]</li>&#10;<li>[[spell:19236]]</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196809]]</td>&#10;<td>&#10;<ul>&#10;<li>[[spell:596]]</li>&#10;<li>[[spell:34861]]</li>&#10;<li>[[spell:120517]]</li>&#10;<li>[[spell:64843]]</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196810]]</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<ul>&#10;<li>[[spell:33076]]</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196813]]</td>&#10;<td rowspan="3">&#10;<ul>&#10;<li>[[spell:585]]</li>&#10;<li>[[spell:14914]]</li>&#10;<li>[[spell:88625]]</li>&#10;<li>[[spell:32379]]</li>&#10;</ul>&#10;</td>&#10;<td rowspan="3">[[spell:196811]]</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<ul>&#10;<li>-</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196816]]</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<ul>&#10;<li>[[spell:132157]]</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196812]]</td>&#10;</tr>&#10;</table>

### [[spell:1262755]] Apex Talent

3.4.

#### Benediction Apex Talent

In Midnight, we gained the Benediction Apex Talent, which provides the following benefits as you put points into
    it:

- [[spell:1262755]] (1 point): [[spell:33076]] bounces periodically transform your next cast of
        [[spell:2061]] into [[spell:1262755]], increasing the healing done and triggering a
        [[spell:238136]].
- [[spell:1262758]] (2 points): Increases all healing done, and further increases the healing of
        [[spell:238136]].
- [[spell:1262760]] (1 point): Causes each pulse of [[spell:64843]] to trigger [[spell:238136]].
        After casting [[spell:2050]], your next [[spell:2061]] is upgraded to [[spell:1262755]].

The periodic [[spell:1262755]] procs are triggered by regularly casting [[spell:33076]]. When
    triggered, [[spell:2061]] is replaced with [[spell:1262755]] for your next cast, increasing the healing done
    and triggering a [[spell:238136]]. Due to the added healing, [[spell:1262755]] is a high value spell to
    use and should be prioritised as part of your rotation whenever it triggers.

:::details TCDoes ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Trigger [[spell:1262755]] More than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Due to More [[spell:33076]]?
No,

[[spell:1262755]]

triggers at a normalised rate, meaning the procs per minute should not differ between
    the two Hero talents. This is true as long as you cast

[[spell:33076]]

regularly. For both Hero talents it
    is important to cast

[[spell:33076]]

as often as possible to maximise the number of

[[spell:1262755]]

procs.

:::

### Other Talents

3.5.

#### Other Talents

3.5.1.

##### Lightweaver

With [[spell:390992]] talented the goal is to alternate between [[spell:2061]] and
    [[spell:596]], utilising the buff that [[spell:2061]] generates to amplify the [[spell:596]]
    casts. Ideally, you should not be casting [[spell:596]] without having the [[spell:390992]] buff
    active. If playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon with [[spell:1247178]] talented, try to keep a charge of
    [[spell:390992]] so you can consume your next [[spell:109186]] with a Lightweaver buffed
    [[spell:596]].

3.5.2.

##### Miracle Worker

[[spell:235587]] provides you with an additional charge of both [[spell:2050]] and
    [[spell:34861]]. When playing with Miracle Worker, you still want to avoid capping at 2 charges to
    maximize the cooldown reduction provided by casting your other spells. Exceptions to this are when there are large
    amounts of damage upcoming in the very near future, in which case it can be beneficial to sit on 2 charges for a
    very short period of time.

3.5.3.

##### Epiphany

[[spell:414553]] has a lot of potential that is often missed by many Holy Priests. Ensuring you have a good way
    to track when [[spell:33076]] is ready is essential to maximizing the value of the talent.

You can further maximize the value of [[spell:414553]] by trying to avoid casting two holy words
    ([[spell:2050]] or [[spell:34861]]) back-to-back when you get an Epiphany proc, and casting
    [[spell:33076]] instead.

3.5.4.

##### Further Talent Reading

For more information on the synergy between various talents, as well as
    deciding which talents you can change around and why, check out the Holy Priest
    Talents page.

[Holy Priest Talents](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)

4.

### Important Cooldowns for Holy Priest

### [[spell:200183]]

4.1.

#### Apotheosis

[[spell:200183]] is a major cooldown you want to be pressing as often as possible. There are several talents
    that improve Apotheosis:

- [[spell:1215245]] increases duration of Apotheosis.
- [[spell:1215241]] improves the burst healing of Apotheosis making it more potent and increasing your mobility.
- [[spell:392988]] has no direct interactions, but more Holy Words make Divine Image a more effective talent.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon's [[spell:453917]] increases healing done while Apotheosis is active.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon's [[spell:454001]] is great at granting an extra few seconds of Apotheosis uptime
        per minute.

Because [[spell:200183]] also increases the Holy Word cooldown reduction gained from casting abilities, it amplifies
    the priority of some spells during Apotheosis to help get Holy Words back off cooldown quickly:

- [[spell:33076]] - When talented into [[spell:390994]] and [[spell:392988]], Prayer of
        Mending becomes a high priority cast. Due to the number of Holy Word casts during [[spell:200183]], if you are
        talented into [[spell:414553]], the resets on Prayer of Mending cooldowns are frequent.
- [[spell:2061]] - When talented into ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon's [[spell:453828]] and with a
        [[spell:109186]] proc, Flash Heal is a high priority due to the additional cooldown reduction.
- [[spell:120517]] - Due to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon's [[spell:453783]], Halo either just before, or during
        [[spell:200183]] is important for the additional [[spell:109186]] procs. This is in addition to the extra healing
        from ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon's [[spell:453845]].

While not always possible due to how things line up, an ideal usage of [[spell:200183]] with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon would look like:

1. [[spell:34861]] - if talented, to get it off cooldown.
2. [[spell:2050]] - to get it off cooldown.
3. [[spell:88625]] - if talented, to get it off cooldown.
4. [[spell:33076]] - to get it off cooldown.
5. [[spell:120517]] - to start generating [[spell:109186]] procs and start stacking [[spell:453845]].
6. [[spell:200183]] - getting back a charge of each Holy Word.
7. [[spell:10060]] - if you do not need to use it at a specific time.
8. Resume normal rotation.

### [[spell:64843]]

4.2.

#### Divine Hymn

[[spell:64843]] is a major cooldown that heals all nearby allies, pulsating healing as it channels. It is
    best used when your group is taking a large amount of damage and you need to heal everyone quickly. Keep in mind
    that the spell is channelled, so you cannot move or perform other actions while casting it, though you do gain
    [[spell:47788]] for the duration of Divine Hymn to help you survive some incoming damage.

When raiding, your raid leader will generally assign you to use this spell at a certain time in the fight to
    counter a heavy burst of damage. If this is the case, make sure your spell is available at that time. Otherwise, you
    should simply try to find a moment when using this spell is beneficial. Most often, this will happen during a period
    of very intense raid damage.

While doing Mythic+ dungeons, [[spell:64843]] is commonly used just before damage hits your group, as the
    healing it does isn't strong enough to completely counter the highest AoE damage abilities. This is typically timed
    so the last second or two of Divine Hymn is while your group is taking damage. That way you fully stack up the
    Divine Hymn buff on all of your allies, but are still able to triage heal anyone near death.

There are two main talents that impact your usage of [[spell:64843]]:

- [[spell:419110]] - Reduces the cooldown of Divine Hymn, allowing for more frequent usage.
- [[spell:372370]] - Each time Divine Hymn pulses, it places some stacks of [[spell:33076]] on nearby allies.

To see which of these talents we recommend using, refer to our dedicated talent build section!

[Holy Priest Talents and Builds](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)

### [[spell:47788]]

4.3.

#### Guardian Spirit

[[spell:47788]] is one of the most useful tools you can bring to a raid. Using it places a buff on the
    target, which lasts for 10 seconds and increases all healing received by the target by 60%. If the target receives a
    killing blow during this time, they will not die and instead be healed for 40% of their maximum health, consuming
    the Guardian Spirit effect.

While you can use this on any raid member who is about to die and whom you have no other means of saving, it is
    by far better used on a tank that is about to take a large amount of damage. You should make sure to communicate
    with the tank and other healers to ensure that you do not use multiple powerful cooldowns at the same time.

You can also use this spell to allow tanks (or other players) to survive an ability that should otherwise
    have been avoided, either as part of your raid's strategy or to recover from a mistake.

Keep in mind that your raid leader may assign you to use this spell for a specific event in the encounter.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Aug. 2026:** Updated rotation to match talent build updates.
- **10 Aug. 2026:** Updated builds & rotation advice for upcoming hotfixes.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Improved rotation explanation for some talents.
- **22 Mar. 2026:** Added some mana management tips for raiding.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated again for Midnight pre-patch.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **09 Sep. 2025:** Rotational fixes and improvements.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **15 Apr. 2025:** Updated with hotfix information.
- **21 Mar. 2025:** Improved descriptions of some spells.
- **26 Feb. 2025:** Improved talent descriptions.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **10 Sep. 2024:** Streamlined some of the rotation advice.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **29 Mar. 2024:** Updated for Patch 10.2.6 talent changes.
- **17 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **13 Nov. 2023:** Season 3 Tier set clarifications.
- **06 Nov. 2023:** Updated with Patch 10.2 changes.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Holy Priest in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Holy Priest

Welcome to our Gear and BiS Page for Holy Priest for Midnight. Check this page to learn everything you need to know
about gearing a Holy Priest, including the BiS Gear from all sources, such as Raiding and Mythic+; information on the
best Trinkets; Tier Sets; and more.

Due to the wide variety of gear providing secondary stats that are all very close in value for us and augments such
as sockets or tertiary stats, there is no certain Best in Slot list. This page aims to guide you toward the best
possible items, particularly in trinket slots.

For regular item slots not used by tier or trinket/weapon effects, you will want to focus on item level
while keeping the following in mind:

- **Socket** — Around 6 item levels.
- **Leech** — Around 6 item levels.
- **Avoidance** — Around 4 item levels.

:::details TCDoes the Value of Leech Drop as I Gain More?
The value of Leech drops off the more you get. It is quite valuable up until you reach 2-3 items with it; then, the
value can drop off quite significantly. Focus on prioritising item level if you reach this much Leech from your gear.

:::

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list is a good example of the Best in Slot Gear for Holy Priest from all sources in Midnight Season 2.

Note that there is no such thing as a singular, all-encompassing "BiS". The best items vary per character and situation, and there are many items that are essentially equivalent in terms of HPS, namely when we are just shuffling secondary stats around. We will list one "BiS" item per slot, sometimes two if we feel there is a significant difference.

:::details FAQWhich Tier Set Pieces Do I Want?
Due to being able to catalyst an item to tier and keep its attributes, there is now no specific slots you should be aiming to get tier in. Your priority remains getting to 4pc as soon as possible, and then from there using your additional catalyst charges to better itemise those slots. Specifically of note is the

[[item:271874@JAAGAAwF0YhNYYD]]

from

[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

which can be catalysed into a tier helm while keeping the Mastery effect, making it an extremely powerful item. Below is a list of the suggested items to catalyst for each slot.

<table> <tr> <th>Slot</th> <th>Item</th> <th>Source</th> </tr> <tr> <td>Helm</td> <td>[[item:271874@JAAGAAwF0YhNYYD]]</td> <td><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td> </tr> <tr> <td>Shoulders</td> <td>Tier Token, don't catalyst</td> <td><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td> </tr> <tr> <td>Chest</td> <td>[[item:268221@JAAEAAwF0YjM]]</td> <td><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a> in <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></td> </tr> <tr> <td>Hands</td> <td>[[item:268243@JAAEAAwF0ghN]]</td> <td><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td> </tr> <tr> <td>Legs</td> <td>[[item:159234@JAAEAAAg0YjM]]</td> <td><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td> </tr> </table>

:::

:::details TipsWhy Do You Suggest Crafting an Off-Hand Even Though It's Not Best-In-Slot?
It is not strictly Best-In-Slot, but it is very close and a great choice for being efficient with your Mistcrests early in your gearing journey. If you are able to get an off-hand at Myth level, it will be a slight upgrade over the crafted one, but the crafted one is still a very good option if you want to save your Mistcrests for other items.

:::

:::details FAQWhat to Get From The Great Vault?
Due to changes in how bonus rolls work in Season 2, presuming you are likely to clear Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in the first couple of weeks, you should choose [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) from your first 3 vaults. This enables you to bonus roll Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) which will reward a 1/6 Myth-track item. All 3 items from this boss have powerful effects and are best-in-slot, so this method allows you to access all 3 as soon as possible.

Once you have obtained those powerful items from Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), you can focus on completing the rest of your gear progression. In general, your priority should be obtaining your 4-set tier bonus as soon as possible, then picking upgrades from the more impactful slots like Weapon and Trinkets. In the event your vault doesn't have a significant upgrade, you can target gear by taking a bonus roll and using it on the associated raid boss to try and obtain the desired item.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271555@JAACAAAG2A]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:239649@JAAKAAwt1wgNRDzViAGM]]&#10;&#10;<div>[[item:240910]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270164@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAKAAwt1wgNRDzViAGM]]&#10;&#10;<div>[[item:240910]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:270162@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268263@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the Best in Slot Gear for Holy Priest from Midnight Season 2 Mythic+ dungeons.

Note that this BiS List is for items **from** dungeons. We are separating the BiS lists by **gear sources**. This is the list you can chase when you want to improve your gear **for raiding** by collecting gear from dungeons only.

There is no such thing as a singular, all-encompassing "BiS". The best items vary per character and situation, and there are many items that are essentially equivalent in terms of HPS, namely when we are just shuffling secondary stats around. We will list one "BiS" item per slot, sometimes two if we feel there is a significant difference, but ultimately, BiS will continue to change as more content becomes available to you.

:::details FAQWhich Tier Set Pieces Do I Want?
Due to being able to catalyst an item to tier and keep its attributes, there is now no specific slots you should be aiming to get tier in. Your priority remains getting to 4pc as soon as possible, and then from there using your additional catalyst charges to better itemise those slots. Below is a list of the suggested items to catalyst for each slot.

<table> <tr> <th>Slot</th> <th>Item</th> <th>Source</th> </tr> <tr> <td>Helm</td> <td>[[item:159236@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td> </tr> <tr> <td>Shoulders</td> <td>[[item:239031@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td> </tr> <tr> <td>Chest</td> <td>[[item:239032@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td> </tr> <tr> <td>Hands</td> <td>[[item:159247@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td> </tr> <tr> <td>Legs</td> <td>[[item:159234@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td> </tr> </table>

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend focusing on the following dungeons to try and obtain decent rings while also passively picking up other gear pieces.

- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): A good Crit/Mastery ring and several other high-Crit items.
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): A good Crit/Mastery ring.
- [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>): A good Vers/Crit ring.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271555@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAAEAAgNygjM]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:159259@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250214@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Bracers</th><td>[[item:159263@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:193761@JAAMAAQkCYHKvbRLfYjM4ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the Best in Slot Gear for Holy Priest from Midnight Season 2 raids.

Note that this BiS List is for items **from** raid. We are separating the BiS lists by **gear sources**. This is the list you can chase when you want to improve your gear **for raiding** by collecting gear from Raid only.

Note that there is no such thing as a singular, all-encompassing "BiS". The best items vary per character and situation, and there are many items that are essentially equivalent in terms of HPS, namely when we are just shuffling secondary stats around. We will list one "BiS" item per slot, sometimes two if we feel there is a significant difference, but ultimately, BiS will continue to change as more content becomes available to you.

:::details FAQWhich Tier Set Pieces Do I Want?
Due to being able to catalyst an item to tier and keep its attributes, there is now no specific slots you should be aiming to get tier in. Your priority remains getting to 4pc as soon as possible, and then from there using your additional catalyst charges to better itemise those slots. Specifically of note is the

[[item:271874]]

from

[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

which can be catalysed into a tier helm while keeping the Mastery effect, making it an extremely powerful item. Below is a list of the suggested items to catalyst for each slot.

<table> <tr> <th>Slot</th> <th>Item</th> <th>Source</th> </tr> <tr> <td>Helm</td> <td>[[item:271874@JAAEAAgNyQWN]]</td> <td><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td> </tr> <tr> <td>Shoulders</td> <td>Tier Token, don't catalyst</td> <td><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td> </tr> <tr> <td>Chest</td> <td>[[item:268221@JAACAAgNyA]]</td> <td><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a> in <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></td> </tr> <tr> <td>Hands</td> <td>[[item:268243@JAAEAAgNyQWN]]</td> <td><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td> </tr> <tr> <td>Legs</td> <td>[[item:268236@JAAEAAgNyQWN]]</td> <td><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></td> </tr> </table>

:::

:::details TipsWhich Raid Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:271092@JAACAAAG2A]]: A weapon with a bonus stat proc. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:268265@JAACAAAG2A]]: An extremely strong Neck with a bonus socket. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:271874@JAAEAAgByYVN]]: A strong helm with a bonus stat proc, can be catalyst to tier keeping the proc. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271555@JAACAAAG2A]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268232@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268218@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270162@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></div></td></tr><tr><th>Bracers</th><td>[[item:268228@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268263@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Holy Priest

This Trinket Tier List is based on the best attributes to improve your Raid performance, unless otherwise mentioned.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Holy Priest Trinkets**
**Best-In-Slot -**

[[item:270162@JAAEAAgNygjM]]

and

[[item:270164@JAAEAAgNygjM]]

**Runner Up -**

[[item:270167@JAAEAAgNygjM]]

or

[[item:250214@JAAEAAgNygjM]]

:::

There are lots of other competitive options out there, be sure to see the full rankings below.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Holy Priest Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270162@JAAEAAgNygjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164@JAAEAAgNygjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAMAAQkCYHKvbRLfYjM4ID]] (Crit Trained)</li>&#10;<li>[[item:250214@JAAEAAgNygjM]]</li>&#10;<li>[[item:270167@JAAEAAgNygjM]]</li>&#10;<li>[[item:280835@JAAEAAgNygjM]]</li>&#10;<li>[[item:270169@JAAEAAgNygjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215@JAAEAAgNygjM]]</li>&#10;<li>[[item:273796@JAAEAAgNygjM]]</li>&#10;<li>[[item:264507@JAACAAgIyA]]</li>&#10;<li>[[item:250248@JAAEAAgNygjM]]</li>&#10;<li>[[item:249809@JAAEAAgByYVN]]</li>&#10;<li>[[item:251792@JAACAAgMyA]]</li>&#10;<li>[[item:248583@JAACAAgMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAAEAAgNygjM]]</li>&#10;<li>[[item:250254@JAAEAAgNygjM]]</li>&#10;<li>[[item:250255@JAAEAAgNygjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Due to the large number of trinkets available, if you do not see a trinket listed above, you can presume it is
  D-tier or lower.

:::

:::details TipsHow Should I Most Effectively Use [[item:270162@JAAEAAgNygjM]]?
[[item:270162@JAAEAAgNygjM]]

is a very strong trinket that provides a significant absorb when used
well. You should aim to be using it as close to on-cooldown as possible, preferably 5 seconds before an upcoming damage
event. Not using this trinket regularly will result in a loss of healing.

:::

You can view a complete list of trinket rankings on the [QE Live](<https://questionablyepic.com/live/trinkets?spec=holypriest>) tool.

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

In Season 2, [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) are available to take from the Great Vault instead of a loot option.
[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) guarantees loot from your target boss or dungeon. While the specific item is random, you'll
never receive duplicates, each new voidcore guarantees a different drop until you've collected everything available from
that source.

3.1.

#### Recommended Nebulous Voidcore Usage for Holy Priest

Your Nebulous Voidcores are a valuable resource for targeting gear that would otherwise elude you. Your voidcore
strategy should prioritize closing gaps in your current setup, keeping in mind what you have already obtained. Spending
voidcores on items you can access through higher difficulty content in the coming weeks is generally inefficient. Here
is what you should focus on:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore Targeting Priority**
1. The 3 unique items from Heroic Ula'tek all drop as 1/6 Myth, use your first 3 rolls here.
2. Mythic-track offhand.
3. Mythic-track trinkets like [[item:270162@JAAEAAgNygjM]].
4. High-impact slots from your BiS list.

:::

:::details TipsWhy use bonus rolls on a Heroic boss?
The reason behind prioritising your first 3 bonus rolls on Heroic Ula'tek is that all 3 items that drop from it are
extremely powerful and when obtained through the bonus roll are Myth track. These items will not be replaced all season,
until you finally kill Ula'tek on Mythic difficulty and have access to the slightly more powerful 9/6 Myth versions of
the same items.

:::

3.2.

#### Ascendant Venomstones

Your [[item:280562]] should follow this prioritization order:

1. Weapon
2. Trinkets
3. Necklace

4.

### Best Crafted Items for Holy Priest

Crafting gear yourself or commissioning profession items is a great way to augment your character's power.

As a Holy Priest we highly suggest crafting an off-hand early, ideally with saved up Myth Mistcrests from the first few
weeks of the season. While this off-hand is not strictly best-in-slot, it is very powerful and extremely efficient use of
your resources early on. Not only does it provide a huge amount of Intellect, but it also increases your healing output
by utilising one of your 2 embellishments on your crafted weapon.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Holy Priest Crafted Gear Priority**
- **Early Power Spike:** [[item:245769@JAAIAAwt1wgNRDzViA]] with [[item:245876]] if you do not already have a Mythic-track offhand.
- **Early Power Spike:** Highest upgrade armour slot with [[item:240167]] for your second embellishment.
- **Eventual BiS:** [[item:239649@JAAKAAwt1wgNRDzViAGM]] with [[item:240167]].
- **Eventual BiS:** [[item:239648@JAAKAAwt1wgNRDzViAGM]] with [[item:240167]] once you have a fully upgraded Mythic-track Off-Hand.
- Any item you do not have on Mythic-track yet.

:::

**Heroic Raiders** that don't have access to a reliable source of Myth crests, and are unlikely to be clearing the
raid on Heroic within the first few weeks, should alter their crafting strategy to prioritise the power spike from a
weapon. If you have plenty of Myth crests, you can craft the offhand suggested above, and then any one-handed Myth
weapon. If you are lacking Myth crests, your first craft should be a 2-handed staff. The embellishment for crafting
either weapon should be [[item:245876]].

:::details TipsWhy Do I Craft Items I Will Be Replacing?
When crafting early in a season, your goal is to get to 2 embellishments quickly, and to prioritise items that give
you the most stats for your crest and spark investment. Later in the season, you are still trying to keep 2
embellishments but as you have access to better items in those high budget slots, you should focus on moving your
embellishments to lower budget slots such as wrist and waist.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Holy Priest

Even though we cannot craft the most powerful items, we can still craft gear with embellishments, making them more
powerful than a typical item of that item level.

As a Holy Priest, you have a few options for your two embellished slots, depending on what gear you currently have.
You should use these crafted items to make up for any gaps in your gearing process or slots you need in particular.

You can also stack two of most embellished effects, which doubles the effects but not how often it procs.

The below breaks down your choice into two categories: Progression and End-Game. If you are starting out your
progression journey, you should focus on items that are the most efficient when spending Crests. The End-Game setup is
ideal for when you are specifically just concerned about crafting the best items possible at end-game availability
without taking into account efficiency.

4.2.

#### Adding Sockets to Gear

In the event you don't want any of your great vault options, and the bonus rolls are no longer appealing to you, you
can instead obtain tokens. Using 6 of these tokens you can purchase the consumable [[item:275707]] allowing
you to add a socket to any Helmet, Belt, or Bracers obtained during Season 2.

5.

### Crest Usage

Once you have upgraded a slot to a certain item level, upgrading other items of that slot to that item level is free.
When you upgrade with Crests, you should think of it as upgrading slots and not items. Additionally, since Crests are a
limited resource, you will want to obtain the highest item-level possible before upgrading a given slot, as this means
you will spend fewer Crests on that slot in total.

We see many players, even at a high level, mess up their upgrade priorities, and upgrading prematurely. Getting this
right will put you far ahead of most players.

Below is the slot priority you should upgrade your items in. If you ever want to deviate from this, you should have a
very good reason.

1. Weapons
2. Trinkets
3. Helm/Chest/Legs
4. Rings and Necks
5. Shoulders/Gloves/Belt/Boots
6. Cloaks and Bracers

Note that exceptions are possible, such as special items that have more Item Level scaling than their slot would imply.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **17 Aug. 2026:** Updated for trinket hotfixes.
- **12 Aug. 2026:** Clarified information regarding bonus rolls.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Sporefall gear.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **25 Mar. 2026:** Updated trinket rankings with latest theorycrafting and hotfixes.
- **22 Mar. 2026:** Updated trinket rankings with latest theorycrafting and fixes.
- **17 Mar. 2026:** Updated with trinket hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **15 Aug. 2025:** Updated due to hotfixes.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **13 May 2025:** Updated Puzzling Cartel Chip Section.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **13 Mar. 2025:** Improved trinket recommendations.
- **24 Feb. 2025:** Updated due to hotfixes.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **17 Dec. 2024:** Updated Cyrce's Circlet information based on buffs and TC work.
- **15 Dec. 2024:** Added mention of Cyrce's Circlet
- **21 Nov. 2024:** Improved gear recommendations.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **15 Sep. 2024:** Removed pre-season gear.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **23 Apr. 2024:** More Dragonflight Season 4 trinket updates.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **17 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **13 Nov. 2023:** Updated BiS list.
- **08 Nov. 2023:** More 10.2 updates including Sporecloak recommendation change.
- **06 Nov. 2023:** Updated with Patch 10.2 changes.
- **04 Sep. 2023:** Updated for Patch 10.1.7 including new Best in Slot lists.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **16 May 2023:** Minor updates including Sporecloak bug.
- **01 May 2023:** Updated with initial Patch 10.1 information.
- **31 Mar. 2023:** Further Patch 10.0.7 updates.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **21 Dec. 2022:** Added some missing trinkets.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Holy Priest. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Holy Priest Stat Priority

Welcome to our Stat Priority page for Holy Priest in the
Midnight expansion! Here we'll quickly be going over the stats you should
aim for on gear, alongside any special considerations depending on your build.

1.1.

#### Raid Stat Priority

Critical Strike

Mastery

Versatility

Haste

When raiding, our secondaries are all similar in value. We do get slightly more value from Critical Strike, but you
should not completely neglect Versatility or Mastery as they're still strong throughput stats.

1.2.

#### Mythic+ Stat Priority

Critical Strike

Versatility

Haste

Mastery

When healing dungeons, you want to maximize your throughput in short fights. Since
you can drink quite often, raw throughput stats are important. Damage-reducing stats also
gain in importance as they allow you to survive things you usually cannot in the highest
Mythic keystone dungeons.

2.

### In-Depth Stat Breakdown

To help you understand how each stat affects your 
performance, we've provided a detailed breakdown below. These are
not listed in order of stat priority, for that please 
refer to the sections above.

**Intellect** is your primary stat. You should 
look for this stat in all of your upgrades. It provides you with
Spell Power, which increases the power of your healing spells.

**Mastery** ([[spell:77485]]) causes each one of your direct heals to place a HoT on the target,
healing for a percentage of the initial heal over 4 seconds. Successive applications of this HoT stack. It also
increases the healing done by [[spell:139]].

**Critical Strike** doubles the effects of your heals, which also benefits your Mastery.

**Haste** lowers the cast time of your heals, as well as your global cooldown. It also reduces the cooldown of
[[spell:33076]], as well as increasing the healing of [[spell:139]] (by granting additional ticks).

**Versatility** increases the damage and healing you deal, as well as reducing the damage you take. This makes it
a strong all-around stat for both survivability and throughput.

**Leech** allows you to passively self-heal for a percentage of the healing/damage of each spell you cast. Due to
its great scaling and the prevalence of enemy mechanics that hurt everyone in the group, it ends up doing a lot of
<em>free</em> healing that would, otherwise, need to be covered by Mana from yourself or the other healers in your
group.

**Avoidance** reduces the damage you take from various area-of-effect damage sources. The value of this can vary a
lot depending on the fight, but in general, it will be a net positive.

**Speed** slightly increases the speed at which your character moves. This can be useful when trying to dodge
encounter mechanics or when repositioning with your group, but is not as noticeable as other stats.

2.1.

#### Leech and Avoidance

While we provide stat preference lists, **swapping gear 
to higher item level items — and their higher total
stats — should usually provide a larger upgrade than 
using lower item level items with better stats**.

The exception to this rule are items with important 
tertiary stats, Leech, and Avoidance, all of which should still
be used ahead of other items without them unless the 
difference in item level is around 6 or above.

2.2.

#### Stat Gain Per Rating

In order to get 1% benefit from each stat, you need different amounts of stat rating. This means some stats naturally
scale better than others, even before diminishing returns kick in from having too much of a certain stat relative to
others.

1. Critical Strike - 46 rating per 1%
2. Versatility - 54 rating per 1% damage/healing increase / 0.5% damage taken reduction
3. Mastery - ～50.6 rating per 1%
4. Haste - 44 rating per 1%
5. Leech - 69 rating per 1%
6. Avoidance - 36.8 rating per 1%
7. Speed - 11.5 rating per 1%

2.3.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5, including stat DR thresholds.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **24 Feb. 2026:** Updated again for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **11 Oct. 2025:** Clarified stat priorities.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated Stat Gain per Rating and Stat DR Thresholds.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Holy Priest, based on your [stat priority](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You will have two categories of gems to choose from: Rare or Epic. The Rare gems
are either just a single stat or a combination of two secondary stats on one gem.
The Epic gems are significantly stronger, but you can only use one at a
time for your entire character.

As a Holy Priest, you should utilise the [[item:240983]]
as your Epic gem of choice and stack [[item:240910]] in all
other gem sockets.

:::details FAQWhat Gems Are Used With Jewelcrafting Embellishments?
Certain crafted items get more benefit from having gems of all colors. Use
the list below to maximize your colors while ensuring you have an
[[item:240983]] socketed. In total, there are four distinct
colors for Rare gems: Peridot (Haste), Garnet (Critical Strike), Amethyst (Mastery),
and Lapis (Versatility). To best optimize your gems you should use gems with Critical
Strike and Versatility on them.

- Peridot: [[item:240890]]
- Garnet: [[item:240910]]
- Amethyst: [[item:240898]]
- Lapis: [[item:240914]]

:::

2.

### Best Enchants and Weapon Augments

For your temporary weapon oil, you should use [[item:243733]] for
all content.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best</th>&#10;<th>Alternative</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>[[item:243951]]</td>&#10;<td>[[item:243949]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:244021]]</td>&#10;<td>[[item:244018]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;<td>[[item:244003]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240155]]</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>[[item:243983]]</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>[[item:243957]]</td>&#10;<td>[[item:243986]]</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>[[item:244029]]</td>&#10;<td>[[item:243971]]</td>&#10;</tr>&#10;</table>

While our suggested tertiary stat enchants for maximum throughput are Leech,
using Speed enchants is also a good option given Holy Priest's limited mobility.

3.

### Optimal Consumables

Consumables substantially increase the power of your character for a limited time. Any
time you are challenging yourself with difficult content, it is advisable that you buff
yourself with Flasks, Food, Potions, and Weapon Oils.

3.1.

#### Flask

For Season 2, you should use one of the following, depending
on which stat you need more of.

- [[item:241326]] - Critical Strike (More Healing)
- [[item:241320]] - Versatility (Defensive Option)

3.2.

#### Potions

[[item:241308]] is your default potion and should be paired with
[[spell:200183]] or [[spell:64843]] to get the most out of it.
[[item:241288]] is another competitive throughput option, and you
can use it instead if it is cheaper to craft or buy. While the Mana potions
[[item:241301]] and [[item:241294]] are available
alternatives, they do not restore enough mana to be worth using over the stat potions.

From Season 2 you now have access to [[item:271883]] 
which is a significant upgrade over [[item:241305]] from Season 1.

3.3.

#### Food Buff

As a Holy Priest you can use any Feast or Master-level food to get the most
optimal results. This includes any of the highest secondary or primary stat
food buffs. Below are some examples:

- [[item:255846]] - Intellect Feast
- [[item:255845]] - Intellect Feast
- [[item:242275]] - Intellect Personal Food
- [[item:255847]] - Intellect Personal Food

If you want cheaper food, you can also use [[item:242283]] or
[[item:242287]].

Depending on the level of progression content, you can also choose to
craft Hearty versions of most food, which gives the exact same effect, but the
buff now persists through death. This costs 5 normal food to produce 1 hearty
version.

3.4.

#### Augment Rune

You should aim to use an Augment Rune to get a boost of Intellect during
any progression content. For Season 2 the following Augment Runes
are available:

- [[item:259085]] (Consumable version)

3.5.

#### Other Consumables

In addition to the above items, you should also always have the following
in your bags for Raiding and Mythic+ environments as a Holy Priest.

- [[item:188152]] - Reusable item that will auto-click a
    nearby Warlock Gateway.
- [[item:244639]] - Provides a weaker [[spell:2825]] effect
    for the group that can be useful in Mythic+ dungeons without a class to provide
    it naturally.
- [[item:269586]] - Castable Battle Resurrection item that can be
    used in combat, even as a non-engineer.
- [[item:241303]] - Invisibility potion that can be used
    instead of a [[item:212265]] to skip trash in certain Mythic+
    dungeon routes.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 Apr. 2026:** Update ring enchant suggestion following Patch 12.0.5 fixes.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **24 Mar. 2026:** Removed mention of teas after hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **23 Mar. 2025:** Reformatted the page.
- **26 Feb. 2025:** More Patch 11.1 consumable updates.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **17 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **08 Nov. 2023:** Added more consumable advice.
- **06 Nov. 2023:** Updated with Patch 10.2 changes.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **07 May 2023:** Updated with latest hotfix changes.
- **01 May 2023:** Updated for Patch 10.1 including Onyx Annulet section.
- **31 Mar. 2023:** Further Patch 10.0.7 updates.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Holy Priest in World of Warcraft Patch 12.1.5.

1.

### Holy Priest in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Priest in Mythic+ dungeons, including the
best way to set up your character, how your rotation may change, and tips and tricks for using your abilities most
optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you can read more about it on our dedicated
Mythic+ page. To learn more about the Mythic+ Meta, check out our Mythic+ Tier List.

Holy Priest has several main draws that make it an attractive spec to play for Mythic+ content in
Midnight. For example, Holy Priest has multiple strong
cooldowns in [[spell:47788]] and [[spell:200183]]; reliable
single-target damage; hefty group healing potential; and a straightforward, reactive playstyle. [[spell:10060]]
can also be a strong boost to your group's damage, if coordinated well with a DPS.

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle M+ Talents

2.1.

#### Recommended ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle Mythic+ Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) Oracle is the recommended spec for Mythic+ as it provides consistent group healing through
    [[spell:33076]] and [[spell:1246799]]. The different talent choices are primarily to make use of
    [[spell:33076]] and [[spell:1246517]] for increased group healing and to help spread
    [[spell:139]]s.

**Be sure to make use of the 'Export Talents' button to import the best build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAghxsMmZMzYYGYZmZmBAAAwYmlZwMzM2MmZMgZKAmZBDhxsNAjBWMmZBgZMzYMYGgZmBMA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZfYeGJRbcekmqUsk648sMB-AAAA-CEMYkow0AUgscE-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon M+ Talents

2.2.

#### Alternative ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon Mythic+ Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon is a competitive alternative for Mythic+ as it provides consistent bursts of healing with each
    [[spell:120517]] cast. The different talent choices are primarily to make use of [[spell:120517]] for both damage and
    healing. The additional [[spell:109186]] procs are great for party triage and contributes to even more
    [[spell:2050]] casts.

Overall, this build provides reliable on-demand healing with [[spell:120517]] becoming a powerful short
    cooldown.

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAMMzsMgZmZYmZGLzMzMAAAAGzsMDmZmxmxMjBMTBAmZzMMbGAYMYzMjFANjZGjBzstMADYA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZabfjkSTUVYceUsk6ABx88EoMB-AAAA-DIMi0Ic4IhBQxS-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts, Stuns, and Stops

Holy Priest has no Interrupt. Instead, you are limited to Stuns and Stops.

[[spell:8122]] is your "AoE stop". When cast, it will immediately cause all nearby enemies to be feared
    and unable to attack back. This fear is often broken nearly immediately in Mythic+ due to the amount of damage the
    enemies receive; however, it still functions to stop enemy casts.

The cooldown can be reduced by talenting into
    [[spell:196704]]. When talented into ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon's [[spell:453918]], it will be cast a second
    time shortly after the first cast, acting as a second AoE stop. It should also be noted that many enemies are immune
    to fear, particularly Undead and mini-boss enemies.

[[spell:88625]] is your single-target "stop". We recommend using this in the same way as you would
    [[spell:8122]], except that it only affects one enemy.

[[spell:9484]] can be used to disable a single Undead or Aberration for 50 seconds. Several dungeons have
    dangerous Undead and Aberrations which are good candidates for Shackle Horror. Damage taken will remove this
    effect.

[[spell:605]] and [[spell:205364]] temporarily control an enemy, which allows you to move, attack,
    and cast some of their abilities. This can be beneficial in some dungeons, as specific enemies have valuable spells
    that can buff your party or debuff enemies.

### Other Utility

3.2.

#### Other Utility

[[spell:527]] will dispel all magic effects from one party member with a short cooldown. It will also remove
    all diseases when talented into [[spell:390632]]. This ability is used frequently in Mythic+, and there are
    multiple important spells throughout the dungeons that it should be used on to make encounters easier and prevent
    deaths.

[[spell:528]] is an offensive dispel, also known as a "purge". This removes one magical buff from an
    enemy.

[[spell:32375]] acts as both [[spell:527]] and [[spell:528]], but is limited to magical effects on 5
    friendly and 5 enemy targets. This is most often used to remove dangerous magical debuffs from multiple party
    members but also has some use in purging dangerous magical buffs from multiple enemies.

[[spell:453]] provides a unique buff reducing the distance at which an enemy will aggro onto you and your
    allies. This has fairly niche usage but can be used in some scenarios to avoid having to pull a pack of enemies and
    instead walk right past them.

[[spell:73325]] has a lot of uses, especially when coordinated with your group. In particular, it can be
    coordinated with your tank to remove them from danger and create distance between them and the enemies they're
    fighting.

### Damage Output

3.3.

#### Damage Output

As a healer, despite your role focus being to keep everyone alive through your healing and utility, any spare
    time you get should be spent on providing additional damage. Be mindful that only [[spell:585]] costs very little
    Mana; the other spells can start to become taxing on your Mana, so particularly on some longer tyrannical bosses,
    you may need to reduce your damage output a little by sticking to the slightly weaker hitting Smite casts.

Damage spell priority for 4+ targets:

1. [[spell:88625]]
2. [[spell:14914]]
3. [[spell:132157]]

Damage spell priority for 1-3 targets:

1. [[spell:88625]]
2. [[spell:14914]]
3. [[spell:132157]] when talented into [[spell:1246549]]
4. [[spell:585]]

For more information about the Holy Priest healing rotation in Mythic+, refer back to the [Rotation, Cooldowns, and Abilities](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>) page.

[Holy Priest Rotation and Cooldowns](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)

4.

### Dealing with Affixes

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Holy Priest

Periodically, orbs of cosmic energy will spawn near your group. As a
    Holy Priest, you can use the following spells to get
    rid of these orbs:

- [[spell:8122]] - Your best option where possible.
- [[spell:32375]] - Capped at 5 targets.
- [[spell:88625]] - Usually best to save this for something else.
- [[spell:528]] - As a last resort.

### Affix: Voidbound

4.2.

#### Voidbound Affix Management for Holy Priest

When the Voidbound affix spawns, you can assist by changing this to
    your primary DPS target in-between healing your group.

### Affix: Pulsar

4.3.

#### Pulsar Affix Management for Holy Priest

Be sure to pay attention to these orbs and try to move near other players prior to them spawning to speed up
    collection. Everyone in the group should help soak the orbs. It is completely reasonable during periods of high
    healing to ask your group to soak them without you, as a lot of your healing spells require you to stand still.

### Affix: Devour

4.4.

#### Devour Affix Management for Holy Priest

When [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>) is present that week, you should always be prepared to use
    [[spell:32375]] or [[spell:527]] to dispel [[spell:440313]] as often as you can on your party. You can also
    remove this with racials such as [[spell:20594]]. If any debuffs aren't dispelled by your or your party members,
    focus first on clearing the squishiest targets first, and the tank last. You can also use [[spell:19236]]
    to help clear your own debuff if needed.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **25 Aug. 2026:** Updated builds with the latest theorycrafting.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated again for Midnight pre-patch.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **25 Mar. 2025:** Updated with latest hotfix information.
- **18 Mar. 2025:** Improved dungeon tips for Season 2.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Updated for Patch 11.0.5 and added more tips.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **29 Mar. 2024:** Updated for Patch 10.2.6.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **08 May 2023:** Improved talent suggestions ready for Season 2.
- **01 May 2023:** Updated for Patch 10.1 with new affixes and talent changes.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Holy Priest in World of Warcraft Patch 12.1.5.

1.

### Best Macros

For the Holy Priest Macros we collaborated with Elvenbane, moderator for
[Warcraft Priests](<https://discord.gg/warcraftpriests>) and author of
their popular [Useful Macro Templates](<https://us.forums.blizzard.com/en/wow/t/useful-macro-templates/42937>)
 guide.

We highly suggest that all of your healing spells, as well as other utility spells that can be cast on allies
(such as [[spell:47788]] and [[spell:527]]), be easily accessible. This can be done either through using the
in-game Click-to-Cast option, macros or by addons such as Clique. This will allow you to much more easily cast them on
raid members as swiftly as possible.

1.1.

#### Basic Healing Macro

This macro is the basis of all of your healing and buff spell macros. You
simply replace **SPELL** with the spell you want that should be cast on a
friendly unit including healing spells and dispels. It works as follows:

- **Holding Alt:** Self Cast.
- **Mouseover Friend:** Cast on Mouseover.
- **Target Friend:** Cast on Target.
- **Target Enemy Targeting Friend:** Cast on Enemy's Target.
- **Default casting Behaviour:** Casts as if there was no macro, and
  generates the tooltip.

#### Basic Healing Macro

```wow-macro
#showtooltip
/cast [mod:alt,@player] [@mouseover,help,nodead] [help] [@targettarget,help,nodead] [] SPELL
```

1.2.

#### Self-Casting Angelic Feather Macro

This is a really handy macro that casts [[spell:121536]] under the
player using the new @player shorthand.

#### Self-Casting Angelic Feather Macro

```wow-macro
#showtooltip
/cast [@player] Angelic Feather
/stopspelltarget
```

1.3.

#### Holy Word: Sanctify Under Cursor

This macro allows you to cast [[spell:34861]] under your cursor
immediately, saving you another mouse click. Keep in mind, however, that it can be
difficult to accurately judge where Sanctify will land without the targeting
reticle.

#### Holy Word: Sanctify Under Cursor Macro

```wow-macro
#showtooltip
/cast [@cursor] Holy Word: Sanctify
/stopspelltarget
```

1.4.

#### Cancelling Spirit of Redemption

Sometimes you will want to cancel [[spell:20711]] early. To easily do this, use the macro below:

#### Cancel Spirit of Redemption Macro

```wow-macro
/cancelform Spirit of Redemption
```

1.5.

#### Power Infusion Mouseover Macro

This macro will cast [[spell:10060]] on the target you are currently mousing over, if it is a friendly target
and not dead. Otherwise, it will cast Power Infusion on your current target, and finally yourself if no valid target is
found.

#### Power Infusion Mouseover Macro

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead] [@focus,help,nodead] [] Power Infusion
/cast [@player] Power Infusion
```

1.6.

#### Leap of Faith Mouseover Macro

This macro will cast [[spell:73325]] on the target you are currently mousing over, if it is a
friendly target and not dead. Otherwise, it will cast Leap of Faith on your current target.

#### Leap of Faith Mouseover Macro

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead] [] Leap of Faith
```

1.7.

#### Shackle Horror Focus Macro

This macro allows you to not only cast [[spell:9484]] on your target but also
set it as a focus so you can keep an eye on the shackle and recast it if needed.

- **Holding Shift:** Clear focus.
- **Holding Alt:** Set focus and cast [[spell:9484]] on focus.
- **Default Casting Behaviour:** Casts as if there was no macro, and
  generates the tooltip.

#### Shackle Horror Focus Macro

```wow-macro
#showtooltip
/focus [mod:alt,@focus,dead] [mod:alt,@focus,noexists]
/clearfocus [@focus,dead] [mod:alt,@focus,noexists] [mod:shift]
/cast [mod:alt,@focus,exists] [] Shackle Horror
```

1.8.

#### Basic Damage & Healing Macro

This is a basic mouseover macro for combining offensive and healing spells into one button. You simply replace
**HELP_SPELL** with the healing spell you want to cast, and **HARM_SPELL** with the offensive spell you want to
cast.

#### Basic Healing & Damage Macro

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead] HELP_SPELL; [@mouseover,harm,nodead] [harm] HARM_SPELL; HELP_SPELL
```

You can also flip them around if you would prefer the offensive spell to be displayed over the healing spell.

#### Basic Damage & Healing Macro

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] HARM_SPELL; [@mouseover,help,nodead] [help] HELP_SPELL; HARM_SPELL
```

2.

### Best Addons

Listed below are some recommended Addons for Holy Priest.

2.1.

#### Twintop's Resource Bar

[Twintop's Resource Bar](<https://www.curseforge.com/wow/addons/twintops-insanity-bar>) for Holy Priest
allows you to easily track your current mana and health, remaining Apotheosis buff with ending indication, and Surge of
Light procs. The bar also has features allowing you to track the status of [[spell:2050]],
[[spell:34861]], and [[spell:88625]] along with your [[spell:390992]] stacks.

[观看原文视频](<https://static.icy-veins.com/images/wow/classes/priest/holy-addons-trb.webm>)

<em>Twintop's Resource Bar in action</em>

2.2.

#### Raid Frame Addons

Raid frame addons help you keep track of your party or raid members' health, buffs, and debuffs. Blizzard includes
customisable raid frames as part of the game. There are also popular addons that build on top of this and provide you
with more options and customisation when using the default raid frames.

It is also popular for players to choose a raid frame replacement addon which overhaul the display and configuration
of their party and raid frames. Popular choices include 
[Grid2](<https://www.curseforge.com/wow/addons/grid2>) and [VuhDo](<https://www.curseforge.com/wow/addons/vuhdo>).

2.3.

#### Click-to-Cast Addons

To easily cast spells on your allies by using mouse-clicks, Click-to-Cast allows you to cast spells by simply
clicking on a unit frame, rather than targeting and then casting. Blizzard includes a built-in Click-to-Cast option, but
many players prefer to use addons for more customisation and ease of use. Popular addon choices include 
[Clicked](<https://www.curseforge.com/wow/addons/clicked>) and [Clique](<https://www.curseforge.com/wow/addons/clique>).

2.4.

#### Generic Addons for Priests

2.4.1.

##### Boss Mods: Deadly Boss Mods or Bigwigs

Boss mods are addons that warn you about boss abilities and give you
live advice on how to handle some mechanics. We strongly recommend you to
get one such addon. At Icy Veins, we mostly use
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>),
the most popular boss mod. A good alternative is
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

2.4.2.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) is a useful addon that allows you to track the cooldowns of other raid
members, as well as providing you with a wealth of other useful raid information.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **21 Mar. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **05 Mar. 2026:** Added more Midnight addons.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **15 Mar. 2025:** Updated weakauras.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **31 Oct. 2024:** Updated with some additional useful Macros.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **29 Apr. 2023:** Added some additional macros.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
