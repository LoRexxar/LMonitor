## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5补丁戒律 牧师指南。在这里，你将学习如何在团队副本和大秘境地下城中作为戒律 牧师进行治疗。我们涵盖了从基础到极限优化手法的所有内容，以最大化你的治疗输出。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

戒律大秘境资源

[全新！顶级戒律天赋构建](<https://raider.io/specs/discipline-priest/talents>)

[顶级戒律大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/priest/discipline>)

[戒律大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=priest--discipline>)

[热门戒律队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=priest--discipline>)

1.

### 戒律 牧师概述

[戒律 牧师](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-guide>) 依赖通过造成伤害来治疗玩家（多亏了[[spell:81749]]被动），但也有传统的治疗和护盾法术。通过造成伤害进行治疗使戒律牧师能够在履行全职治疗者职责的同时为团队的DPS做出贡献。

平衡治疗和输出伤害起初可能难以掌握，但通过研究和练习，戒律可以成为最有成就感的专精之一。

[观看原文视频](<https://www.youtube.com/embed/ZvNB6c0QPL4?si=bi98pvfQpiJbL87k>)

稳定的输出能力

戒律 牧师通过[[spell:81749]]提供强大而稳定的治疗，并通过[[spell:17]]、[[spell:238063]]和[[spell:62618]]大幅提升有效生命值。这使戒律牧能够在原始HPS以及通过减伤或护盾缓解伤害方面做出重要贡献。

顶尖表现者

戒律 牧师提供非常强大的总体治疗输出，同时在团队副本环境中其他方面也提供惊人的价值。由于戒律的所有伤害几乎不消耗任何机会成本，在某些场景中戒律可以提供大量DPS，而其他治疗者则被迫使用公共冷却时间进行治疗。戒律牧还带来[[spell:10060]]，为其自身强大的DPS提供额外加成。

此外，戒律 牧师可以提供[[spell:238063]]和[[spell:62618]]多种形式的减伤，以及多次使用强大的外部减伤技能[[spell:33206]]。

最后，戒律还带来[[spell:10060]]——这是所有牧师都有的技能——为团队中的一名DPS提供显著的伤害提升。

中游表现

戒律 牧师目前在大秘境内容中处于尚可的位置。虽然它目前不是最高层数钥匙的首选治疗者，但它能够轻松完成每周的钥匙。凭借可靠的伤害贡献和稳定的AoE治疗，戒律能够跟上大多数必要的治疗检查，同时为团队贡献可观的DPS。

小众但极其强大

虽然 戒律牧师 的功能性可以非常强大，但它往往也非常小众。

[[spell:8122]] 和 [[spell:10060]] 是唯二被非常频繁使用的技能。[[spell:9484]] 和 [[spell:205364]] 则小众得多，使用率极低，但当它们能够发挥作用时，它们是非常强大的工具，可以完善我们的功能性工具箱。如果一场战斗中有一个机制可以被[[spell:32375]]轻松化解，那么它会非常强大，但在近期的战斗中这类战斗相当有限。

最后，[[spell:453]] 偶尔会在大秘境中使用，以在特定路线上跳过某些怪物群，其价值与[[spell:114018]]相当，但没有6分钟的冷却时间。

低于平均水平

牧师的生存能力，特别是 戒律牧师，历来是该职业的主要弱点之一。虽然我们有一些可用的工具，但我们的整体防御能力比平均水平要弱得多。

[[spell:19236]] 是我们的主要防御性冷却技能，它只是在短时间内提高你的最大生命值，并治疗等量的生命值。这与大多数职业不同，后者会获得强大的防御能力，提供强大的减伤效果。

除此之外，我们还有一些小幅减伤的选择。[[spell:373446]] 在你施放[[spell:586]]时提供10%的减伤，[[spell:193063]] 在你对自己施放[[spell:2061]]时提供额外的10%减伤。

将所有这些效果结合起来，你将能够扛过必要的机制，但这需要对多个小效果进行微操管理，才能达到大多数战斗的最低防御能力要求。

极差的机动性

机动性是 牧师 挣扎的另一个领域。我们唯一的真正机动性工具是 [[spell:121536]]，它只是在短时间内提供中等的移动速度提升。除此之外，[[spell:64129]] 也是可用的，但作为一名 戒律牧师，[[spell:17]] 往往是我们实际治疗循环的一部分，所以将其用于机动性会很困难。

没有像[[spell:1953]]这样的位移机动性选项，许多战斗和机制要么需要牧师近乎完美的站位和操作，要么需要外部来源的协助，比如来自唤魔师的[[spell:370665]]，才能解决。

1.

### 戒律 牧师 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5补丁带来了两种新形式的内容：一个单Boss团本和一个全新的迷宫巨型地下堡。请查看我们关于这两个新内容的指南，链接如下：

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

主要的改动将来自Kith'ix团队副本的新物品。最值得注意的是一个饰品、一个戒指和一件腿部装备。此外，从10月20日起，你将能够使用[[item:280562]]升级物品。武器、项链和饰品都可以升级。

2.3.

#### 职业改动

不幸的是，进入12.1.5补丁后，戒律牧师没有收到任何职业改动。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_rapture.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1职业改动 隐藏12.1职业改动
12.1补丁引入了大量对游戏风格有重大影响的职业改动。以下是你进入新赛季需要了解的内容摘要：

[12.1补丁说明](<https://us.forums.blizzard.com/en/wow/t/midnight-curse-of-ulatek-ptr-development-notes/2317811>)

**戒律 牧师:**

- 开发者笔记：对于乌拉泰克的诅咒中的戒律，我们的改动旨在降低该专精对触发效果的依赖以实现有效治疗，改善稳定伤害来源，并改善英雄天赋的平衡性。我们认为该专精过于依赖暗影抚慰和虚空之盾的触发效果来实现有效治疗，因此我们正在将暗影抚慰更新为快速治疗的被动升级，并添加一种确定性的方式来获得虚空之盾。此外，惩击尽管频繁施放，但伤害贡献很低，因此我们正在提高其伤害并更新天赋树，以便更容易获取强效惩击。
- [[spell:186263]]：已更新为 [[spell:2061]] 的被动升级
- [[spell:1253593]]：通过[[spell:8092]]添加了确定性的获取方式。牌组大小也增加到4以作为补偿。虚空之盾的吸收效果也被削弱，以将强度转移到该专精的其他部分。此外，提供虚空之盾的增益效果现在可以叠加到2层，以防止你快速连续施放心灵震爆和[[spell:47540]]并从两者都获得触发时丢失一个触发的情况。
- [[spell:81749]] 的缩放已被调整，使其在超过5个目标后衰减得更厉害。
- [[spell:1253724]]：现在是一个单点天赋（原为2点），增益效果的持续时间现在是4秒而不是2秒。
- [[spell:373427]]：被削弱了30%，大大降低了宠物体系的强度。
- [[spell:585]]：伤害提高了40%。此外，[[spell:450405]] 的伤害进一步提高了25%，[[spell:450612]] 从50%提高到75%，导致虚空冲击的治疗量大幅增加。
- [[spell:47540]] 不再施加救赎，因此纯粹以防御性方式施放（除了传播持续伤害效果之外）的游戏风格已经行不通了。

:::

:::details 显示8月18日的修正隐藏8月18日的修正
[8月18日的修正](<https://us.forums.blizzard.com/en/wow/t/class-tuning-incoming-%E2%80%93-august-18/2336820>)

**戒律 牧师:**

- 开发者笔记：我们正在降低戒律 牧师的伤害输出，并通过救赎来补偿这一点，以不影响他们的总体治疗量，因为与其他治疗者相比，他们的伤害一直表现过高。同时，我们正在提高熵能裂隙的伤害，以尽量减少这对虚空编织者地下城可行性的冲击，并帮助维持高伤害作为其优势之一。
- 所有伤害降低30%。不影响PvP战斗。
- [[spell:447444]] 伤害提高20%/
- [[spell:81749]] 现在将46%的伤害转化为治疗（原为32%）。不影响PvP战斗。
- [[spell:1253593]] 现在反射10%的吸收伤害（原为15%）。

正如开发者在蓝帖中所述，这些改动旨在降低戒律令人难以置信的单体目标DPS，而不影响他们的治疗。这些改动基本上不会改变我们的治疗量。

考虑到这一点，这些改动不会导致任何推荐天赋选择或游戏决策的改变。

:::

:::

### 至暗之夜改动概述

2.4.

#### 戒律 牧师在 至暗之夜 中的重大改动

进入至暗之夜时，开发者已经推出了大量针对治疗者的总体改动，目标是减少游戏中的冷却技能数量、降低爆发治疗，并总体上拉平和减缓治疗节奏。以下是关于他们对戒律 牧师进入至暗之夜的目标的引用。

[至暗之夜 测试服开发笔记](<https://eu.forums.blizzard.com/en/wow/t/midnight-alpha-test-development-notes/590289>)

开发者笔记：这些改动的主要目的是整合和移除冷却技能及伤害/治疗修正，使基础法术施放感觉更加强力。通过移除异端、暗影盟约和若干辅助天赋，我们可以专注于心灵震爆、苦修和暗影言：痛造成稳定可靠的伤害，这样你就能以更稳定的节奏获得可观的爆发治疗。福音布道也被重新设计为在团队副本中快速为盟友施加救赎的方式，提供了一种更迅速的方式来启动你的范围治疗。结果应该是一种更流畅的游戏体验，需要更少的规划和光环监控，但仍然保留深度。

考虑到这一点，以下是进入至暗之夜时需要注意的主要游戏性改动列表。

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者已被重新设计，不再有任何需要维持的主动技能。取而代之的是，你获得一层额外的[[spell:47540]]充能和若干其他被动收益。
- [[spell:472433]]已被重新设计。它不再简单地延长你的活跃[[spell:81749]]，而是立即施放一个[[spell:194509]]，然后使你接下来的2次光辉成为瞬发。这极大地简化了你在团队副本中的启动序列，因为带有两层光辉充能的福音布道可以非常快速地单独覆盖15个救赎。
- [[spell:200829]]已被添加到我们的职业天赋树中，以填补[[spell:139]]之前所占据的相同定位。这使我们能够拥有一个比[[spell:2061]]更廉价的瞬发[[spell:81749]]施加者。
- 所有宠物，如暗影魔和控心师，都不再是主动技能，而是通过各种触发条件召唤这些宠物的被动效果。[[spell:34433]] 是一个新的天赋，可以在对斩杀目标命中[[spell:32379]]时召唤一个宠物。[[spell:123040]] 是一个天赋，当你施放[[spell:472433]]时召唤一个控心师。最后，[[spell:451234]] 现在会在你的[[spell:447444]]结束时召唤一个虚空幽灵。
- 由于你的所有宠物不再是主动按钮，[[spell:314867]]已被移除，并被[[spell:1250293]]中简单的被动暗影伤害和治疗提升所取代。
- [[spell:421453]] 和 [[spell:62618]] 现在共享一个抉择节点，迫使你每次只能选择其中一个。

2.5.

#### 至暗之夜中牧师戒律专精的顶级天赋

戒律牧师的顶级天赋“掌控黑暗”共有4个等级，包含三种不同的效果。第一个[[spell:1253590]]使你在施放[[spell:47540]]后，下一个[[spell:17]]有30%的几率转化为[[spell:1253593]]。这个护盾比普通护盾强得多，并且会溅射到另外两名附近的盟友身上。你的第二和第三级“掌控黑暗”[[spell:1253845]]是简单的被动节点，每级都会提高你的整体[[spell:81749]]治疗量以及所有暗影伤害。最后，你的第四级“掌控黑暗”[[spell:1253827]]会使你的[[spell:1253593]]吸收量的一定百分比在吸收时反射为伤害。这个伤害会通过[[spell:81749]]转化为治疗，使得这个天赋极其强大。

1.

### 戒律牧师基础玩法

戒律牧师的玩法风格会因版本调整而逐个补丁变化，取决于我们使用的具体流派。有些流派，比如本赛季的
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者流派，极其侧重伤害/[[spell:81749]]，你总输出的75-80%将来自救赎，而在其他一些赛季中，调整更偏向于你的直接治疗法术，如[[spell:2061]]/[[spell:186263]]和[[spell:17]]。无论使用哪种流派，戒律牧师的核心玩法都是平衡你的伤害全局冷却和救赎施加全局冷却，以最大化你的输出。

戒律牧师的基础可以用以下三个概念来描述。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_penance.jpg>) **不要浪费苦修层数**
  
  
  
  
  与[[spell:47540]]相关的巨大力量和其他触发效果，使得尽可能频繁地施放它变得极其重要。确保你 **绝不** 保留多层可用的苦修层数，将从苦修施放本身为你提供可观的输出，帮助触发更多[[spell:1253593]]，并通过你的2件套套装效果缩短[[spell:8092]]的冷却时间，从而带来更多虚空之盾的触发。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_plea_yellow.jpg>) **不要过度使用施加器**
  
  
  
  
  许多新手玩家会陷入不够信赖他们的[[spell:81749]]的陷阱，很快又回到要么疯狂刷直接治疗，要么过度施加救赎，认为自己需要积极“治疗”而不是按填充型DPS技能。这不仅极其消耗法力值，会导致你很快遇到法力值问题，而且戒律需要在这两者之间保持微妙的平衡。真正进行输出并利用你已激活的救赎，而不是急着施加更多救赎，这一点极其重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_priest_voidshield.jpg>) **虚空之盾的重要性**
  
  
  
  
  许多人没有意识到[[spell:1253593]]的伤害有多高。许多新手玩家只会施放虚空之盾，以为吸收量就是这个法术的全部价值。它不仅是一个出色的救赎施加器，可以同时对3个目标施加救赎，它反射的伤害还会带来大量的救赎治疗。因此，在某些情况下，等到队伍先承受一些伤害后再施放虚空之盾是合理的，这样所有反射的救赎治疗就不会全部变成过量治疗。

1.

### 如何为戒律牧师配装

请查看我们专门的戒律配装页面。我们目前涵盖了第二赛季装备的推荐，以便在赛季上线后立即开始配装。在你获取了一些装备后，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 针对12.1.5补丁发布进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 针对12.1.5补丁发布进行了更新。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 根据最近仪式石的削弱更新了装饰建议。
- **2026年8月18日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 修正了错别字。
- **2026年8月18日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 修复了遗漏的过时引用。
- **2026年8月18日（本页）：** 更新了额外的8月18日修正说明。
- **2026 年 8 月 17 日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 修复了福音序列格式并添加了团队副本Boss信息。
- **2026年8月17日（本页）：** 添加了赛季前的职业平衡调整。
- **2026年8月16日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 根据最近的饰品平衡调整调整了饰品建议。
- **2026年8月16日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 用新的盘绕岛食物替换了虚空编织者食物建议
- **2026年8月11日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 各种格式和拼写错误修复。
- **2026年8月11日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 为苦修无引导宏添加了说明。
- **2026年8月11日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 各种格式修复。
- **2026年8月11日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 各种格式修复。
- **2026年8月11日（本页）：** 添加了虚空之盾可叠加至2层充能的说明，并修复了一个失效链接。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 针对第二赛季发布进行了更新。
- **2026年8月10日（本页）：** 针对第二赛季发布进行了更新。
- **2026年7月15日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 更新了附魔/宝石建议。
- **2026年7月15日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 更新了属性建议。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 更新了12.0.7孢子坠落装备。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 针对12.0.7补丁和全知全书进行了更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月20日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 修复了BiS列表中物品的视觉着色问题。
- **2026年5月20日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 添加了真言术：工具箱的提及。
- **2026年5月20日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 更新了页面格式，使其与其他指南更加一致。
- **2026年5月20日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 修复了小的格式问题，并调整了一些高级部分的顺序。
- **2026年5月20日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 修复了不正确的地下堡天赋构筑。
- **2026年5月20日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 修复了标题拼写错误，并扩展了一般游戏玩法描述。
- **2026年5月4日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 更新了属性优先级，以反映进一步的序列优化。
- **2026年5月4日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 为一些高级主题添加了章节。
- **2026年5月4日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 添加了虚空之盾牌组系统的提及。
- **2026年5月4日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 修复了对过时天赋的不正确提及。
- **2026年5月4日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 添加了一些遗漏的提及
- **2026年5月4日（本页）：** 更新了团队副本表现，以反映最近的削弱。
- **2026年4月22日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 根据最近的职业平衡调整更新了装饰和BiS列表建议。
- **2026年4月22日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 修复了福音布道描述中的错误。
- **2026年4月22日（本页）：** 将视频链接更换为12.0.5版本视频。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月26日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 热修后更新了饰品推荐。
- **2026年3月26日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 更新了武器附魔推荐。
- **2026年3月26日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 套装bug修复后修正了爆发输出循环序列。
- **2026年3月24日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 热修后移除了关于茶的提及。
- **2026年3月21日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 根据来自正式服务器的更优数据更新了饰品推荐。
- **2026年3月21日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 即将到来的职业平衡调整后更新了天赋推荐。
- **2026年3月21日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 即将到来的职业平衡调整后更新了天赋推荐。
- **2026年3月21日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 即将到来的职业平衡调整后更新了天赋推荐。
- **2026年3月21日（本页）：** 为即将到来的职业平衡调整进行了更新。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 为第一赛季 至暗之夜 发布进行了更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 已为第1赛季发布进行更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 凝视削弱后更新了饰品推荐。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已为第1赛季发布进行更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 为第一赛季发布进行了更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 为第一赛季发布进行了审查。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已为第1赛季发布进行更新。
- **2026年3月16日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为第1赛季发布进行更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 为第一赛季 至暗之夜 发布进行了审查。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 为第一赛季 至暗之夜 发布进行了更新。
- **2026年3月16日（本页面）：** 为 至暗之夜 第一赛季发布进行了更新。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 添加了从80级开始的天赋导入代码。
- **2026年3月2日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 修复了食物推荐错误。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 为 至暗之夜 发布进行了更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（本页）：** 为 至暗之夜 发布进行了更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 将束缚亡灵更新为束缚恐惧
- **2026年2月10日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 为职业门槛解锁的改动更新了天赋树。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 将束缚亡灵更新为束缚恐惧
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（本页面）：** 将束缚亡灵更新为束缚恐惧
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（本页）：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 为11.2.7补丁更新。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 添加了迪纳尔部分。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年8月14日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 更新页面以包含纳克西斯之王指令饰品信息。
- **2025 年 8 月 10 日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 添加了遗漏的饰品并更新了专业制造推荐。
- **2025 年 8 月 10 日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 修复了 神谕者 输出循环中套装复选框的问题。
- **2025 年 8 月 10 日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 修复了页面上的一些错别字。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 为第三赛季发布进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 为11.2补丁进行了更新。
- **2025年6月17日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 更新了D.I.S.C推荐。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 为11.1.7补丁更新。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 添加了D.I.S.C腰带的信息。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 添加了战斗助手信息。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 添加了战斗助手部分。
- **2025年6月15日（本页）：** 为11.1.7补丁进行了更新。
- **2025年5月12日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 更新了令人费解的Cartel Chip部分。
- **2025年5月12日（[解放安德迈页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 更新了少数几个史诗团本首领的爆发时间轴。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 为11.1.5添加了令人费解的Cartel Chip部分。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 添加了腐蚀附魔部分。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 添加了关于11.1后平衡调整的提及。
- **2025年4月3日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 小幅错别字修复。
- **2025年4月2日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 格式修复。
- **2025年4月1日（[解放安德迈页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 更新以包含一些天赋调整，并添加了更多首领。
- **2025年4月1日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 添加了更多关于大秘境中 神谕者 的信息。
- **2025年4月1日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 近期平衡调整后进行了更新。
- **2025年3月24日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 饰品平衡调整后进行了更新。
- **2025年3月24日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 戒律 削弱后进行了更新。
- **2025年3月24日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 添加了描述如何根据首领伤害模式调整你的输出窗口的部分。
- **2025年3月24日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 戒律 削弱后进行了更新。
- **2025年3月16日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 将Premo宏更新为略微更稳定的版本。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 修复了屠杀炼金锅上错误的天赋代码。
- **2025年3月16日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 更新了输出循环以反映福祸技能队列交互的移除。
- **2025年3月13日（[解放安德迈页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 在每个示例爆发时间轴下方添加了Viserio链接。添加了初步的史诗团本首领计划。
- **2025年3月11日（[解放安德迈页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 第一周后更新了剩余的英雄难度时间轴和信息。
- **2025年3月3日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 调整了NoChanneling宏。
- **2025年3月3日（[解放安德迈页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 为团本发布进行了更新。
- **2025年3月2日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 修复了格式问题。
- **2025年3月1日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 根据近期平衡调整更新了头环推荐。
- **2025年3月1日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 近期平衡调整后进行了更新。
- **2025年3月1日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 根据近期平衡调整进行了更新。
- **2025年3月1日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 将天赋代码更换为11.1天赋。
- **2025年3月1日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 根据近期平衡调整进行了更新。
- **2025年3月1日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 近期平衡调整后进行了更新。
- **2025年3月1日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 近期平衡调整后进行了更新。
- **2025年3月1日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 近期平衡调整后进行了更新。
- **2025年2月28日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 为洞察技能队列宏添加了说明。
- **2025年2月25日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 修复了页面上失效的链接。
- **2025年2月25日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 修复了 神谕者 输出循环中的小错别字。
- **2025年2月25日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 修复了错误的天赋代码。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 更换了武器附魔/为 神谕者 添加了替代消耗品。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 进入11.1后略微更新了属性优先级。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（本页面）：** 已针对11.1补丁进行更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 根据进一步的理论研究更新了塞尔希的头环信息。
- **2024年12月16日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 塞尔希的头环加强后进行了更新。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 添加了塞尔希的头环部分。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 添加了提及塞壬岛补丁无改动的部分。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 添加了讨论使用型饰品使用的部分。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 添加了推荐的WeakAura和Grid2配置文件。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 添加了额外的史诗团本首领提示。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 移除了一些过时的引用。
- **2024年10月21日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 更新了终极忏悔使用部分。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 添加了灵活点数和一些额外的天赋讨论。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 添加了提及新补丁无改动的部分。
- **2024年9月17日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 英雄难度周后更新了团本指南。
- **2024年9月14日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 添加了安苏雷克女王英雄难度的示例时间轴。
- **2024年9月11日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 重新排列了天赋推荐顺序，并添加了关于bender bug的说明。
- **2024年9月10日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 为 神谕者 添加了命运编织者输出循环切换。
- **2024年9月10日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 添加了澄清宠物爆发时间轴的部分。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 为第一赛季发布更新了页面。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 更新了食物和宝石推荐。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 为第一赛季发布更新了页面。
- **2024年9月9日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 为第一赛季发布进行了更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月26日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 更换了胸甲附魔推荐。
- **2024年8月26日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 修复了团本代码导入问题。
- **2024年8月22日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 平衡调整后更新了美化装备。
- **2024年8月22日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 重新格式化页面以便于阅读。
- **2024年8月22日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 修复了大秘境天赋树链接到旧补丁天赋的问题。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 为地心之战发布进行了更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 为地心之战发布进行了更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 为地心之战发布进行了审查。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 为地心之战发布进行了更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 为地心之战发布进行了更新。
- **2024年8月21日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 为地心之战发布进行了更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 为地心之战发布进行了更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 为地心之战发布进行了更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 为地心之战发布进行了更新。
- **2024年8月21日（本页）：** 为地心之战发布进行了更新。
- **2024年7月23日（[地心之战](<https://www.icy-veins.com/wow/discipline-priest-the-war-within-pve-guide>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/discipline-priest-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月18日（[地心之战](<https://www.icy-veins.com/wow/discipline-priest-the-war-within-pve-guide>)):** 添加了页面。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/discipline-priest-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 为第4赛季进行了更新。
- **2024年4月22日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 为第4赛季进行了更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 为第4赛季进行了更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月27日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月27日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对10.2.6版本进行审阅
- **2024年3月27日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 为10.2.6补丁进行了审查并更新了食物推荐。
- **2024年3月27日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对10.2.6版本进行审阅
- **2024年3月27日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对10.2.6版本进行审阅
- **2024年3月27日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对10.2.6版本进行审阅
- **2024年3月27日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.6版本进行审阅
- **2024年3月27日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已针对10.2.6版本进行审阅
- **2024年3月27日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对10.2.6版本进行审阅
- **2024年3月27日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对10.2.6版本进行审阅
- **2024年3月27日（本页）：** 已针对10.2.6版本进行审阅
- **2024年1月16日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 调整了梦境虔诚附魔的措辞。
- **2024年1月16日（本页）：** 修复了近期改动部分。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年11月11日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 修复了治疗药水的提及。
- **2023年11月11日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 移除了过时的提及。
- **2023年11月11日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 修复了小的循环问题。
- **2023年11月7日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 为10.2补丁更新了页面。
- **2023年11月7日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 添加了额外的说明。
- **2023年11月7日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已更新至 10.2 补丁。
- **2023年11月7日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 移除了过时的参考资料。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对10.2版本进行更新
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 添加了关于10.2版本新武器附魔和头盔附魔的说明。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 为10.2版本进行了审查。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已针对10.2版本进行更新
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已针对10.2版本进行更新
- **2023年11月6日（本页）：** 已针对10.2版本进行更新
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 针对10.1.7补丁进行了审查。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 针对10.1.7补丁进行了审查。
- **2023年9月4日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 针对 10.1.7 补丁进行了审阅
- **2023年8月10日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 更新了输出循环以反映狂想曲的热修。
- **2023年8月10日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 在狂想曲和虚空之盾热修后进行了更新。
- **2023年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 更新了大秘境天赋推荐，并更新了团本的措辞。
- **2023年7月19日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 修复了格式问题。
- **2023年7月12日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 修复了天赋树问题。
- **2023年7月12日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 更新为新的页面格式。
- **2023年7月11日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 更新了永恒印记推荐部分。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 更新了10.1.5版本的天赋推荐。
- **2023年7月10日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 针对10.1.5补丁进行了更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 针对10.1.5补丁进行了更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 更新了天赋推荐。
- **2023年7月10日（本页）：** 针对10.1.5补丁进行了审查。
- **2023年5月6日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 根据热修/调整更新了附魔和药水推荐。
- **2023年5月6日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 更新以包含第二赛季地下城特定天赋选择。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 热修后更新了原初石推荐。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 为10.1补丁进行了审查。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 为10.1补丁进行了审查。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已为10.0.7补丁更新。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 为10.1补丁进行了审查。
- **2023年5月1日（本页）：** 为10.1补丁进行了审查。
- **2023年3月21日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月21日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月21日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已针对10.0.7补丁进行审核。
- **2023年3月21日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月21日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月22日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 添加了冰冷明晰药水取消光环宏。
- **2023年1月22日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 更新了10.0.5补丁的天赋推荐。
- **2023年1月22日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 更新了输出循环以反映10.0.5的改动和天赋变动。
- **2023年1月22日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 更新了10.0.5补丁的天赋推荐。
- **2023年1月22日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 更新了法术列表以反映10.0.5的改动。
- **2023年1月22日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 更新了10.0.5补丁的天赋推荐。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 更新了光晕/星辰坠落宏以适配斯科夫。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 移除了页面上遗漏的光芒之力提及。
- **2022年12月11日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 重新格式化页面以利用配装切换功能。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 修复了天赋模拟器大秘境链接。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 将暗影魔移到了正确的位置并添加了圣光之焰。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/discipline-priest-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/discipline-priest-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/discipline-priest-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年5月31日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对 9.2.5 补丁审核本页面。
- **2022年2月22日（[9.2版本分析](<https://www.icy-veins.com/wow/discipline-priest-patch-9-2-changes-analysis>)):** 为9.2补丁更新了页面。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/discipline-priest-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/discipline-priest-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月14日（[9.1 补丁分析](<https://www.icy-veins.com/wow/discipline-priest-patch-9-1-changes-analysis>)):** 更新页面以反映9.1补丁的上线。
- **2021年6月29日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 针对9.1补丁进行了更新。
- **2021年6月7日（[9.1 补丁分析](<https://www.icy-veins.com/wow/discipline-priest-patch-9-1-changes-analysis>)):** 添加了新的盟约橙装。
- **2021年5月4日（[9.1 补丁分析](<https://www.icy-veins.com/wow/discipline-priest-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2021年3月9日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 已针对 9.0.5 补丁审核。
- **2021年2月4日（[DPS指南](<https://www.icy-veins.com/wow/discipline-priest-pve-dps-guide>)):** 页面已添加。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月7日（[永恒宫殿页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-the-eternal-palace-raid-guide>)):** 添加了永恒王宫团本建议页面。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月12日（[达萨罗之战页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** 同行评审后更新了页面。
- **2019年5月12日（[风暴熔渣页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-crucible-of-storms-raid-guide>)):** 使用正式服数据而非测试服数据更新了攻略。
- **2019年4月16日（[风暴熔渣页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年1月20日（[达萨罗之战页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** 为戒律牧师添加了达萨罗之战的提示。
- **2018年9月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-uldir-raid-guide>)):** 更新了天赋选择的格式。
- **2018年8月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-uldir-raid-guide>)):** 添加了奥迪尔团本建议页面。

显示更多

显示更少

:::

## 练级

在此页面上，你将找到我们的逐级戒律牧师升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[牧师升级指南](<https://www.icy-veins.com/wow/priest-leveling-guide>).

1.

### 戒律牧师升级指南（适用于至暗之夜）

虽然作为治疗者升级是可行的，但单人游戏时通常比切换到暗影专精要慢得多。不过，如果你能接受较慢的升级体验，仍然可以选择以戒律牧师的身份进行升级。此外，作为治疗者升级可以让你轻松进入地下城队列，因为治疗者角色通常需求量很大，排队时间非常短。

1.1.

#### 升级装备选择

以戒律牧师身份升级时，始终选择可获得的最高物品等级装备。在升级装备上寻找特定属性并不重要，因为当你获得同部位的另一件装备时，很可能存在相当大的物品等级差距。

升级过程中，传家宝是一种选择，可以让你穿着的装备随你的等级提升而提升，而无需在升级过程中不断用任务或地下城掉落的装备替换。

1.2.

#### 至暗之夜升级实用消耗品

升级期间，将一些附魔调整为专注于移动速度，有助于减少从一个任务到另一个任务之间的非战斗时间。以下是值得考虑的移动速度附魔列表。

- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

此外，还有各种消耗品可以在升级过程中提供机动性或战斗力方面的帮助。以下是建议在至暗之夜发布前获取的物品列表：

- [[item:109076]] - 这些物品可以快速穿越地形，特别是在无法骑马的情况下。
- [[item:132516]] - 这些物品能大幅提升移动速度，让你在地面上快速移动很长距离。
- [[item:219905]] - 如果你和能提供[[spell:2825]]或类似效果的人一起升级，这些物品就没必要了，但在无法获得该效果的情况下，这些物品每10分钟能提供一次可靠的加速。
- [[item:212250]] - 隐身药水可以用来跳过那些你不需要为任务击杀的怪物区域，从而加快你的升级速度。
- [[item:172063]] 或 [[item:133576]] - 这两种食物在你击杀敌人时都会提供大量的移动速度加成。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 戒律 80级 至暗之夜 升级
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsYMzGjxYmZMbsNzMzMzAAAAAAAAAAgBLzgZmZwYmBbmmpZAzAAAYbWAGbGAAGDzYwMYmBjmB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsgZ2YMGzMjZzsNzMzMzAAAAAAAAAAgZYZGMzMDGzMYz0MNDMzAAAMbzyCYsZAAYMmZMYGMzgRzwA"
}
```
:::

:::details 来源计算器编码
```
#AE-WBAkNighObqKKHsoteVuUdZNOZYWkkKYaKA-bcdA0yw69AdlsEFRV9rJswUSy4ZIIBB-AAAA-RYWUKESMEQEY4A-
```

:::

2.1.

#### 升级用战争模式天赋

1. [[spell:356085]]是一个可切换的技能，可以让你获得10%的法术伤害和[[spell:81749]]治疗加成，或者治疗法术法力值消耗降低15%。升级时保持在伤害提升状态将带来可观的伤害输出和生存能力提升。
2. [[spell:391297]]在单人挑战确实对你造成大量伤害的内容时，能提供相当可观的伤害提升。如果你是与他人组队，或者内容足够简单以至于你不会受到大量伤害，请随意用其他天赋替换此天赋。
3. [[spell:1218211]]使你和所有拥有你[[spell:81749]]的盟友的伤害提高15%，持续8秒。这对于小队世界内容非常有用，在这种情况下，为你的小队提供伤害输出增益比通过上述三个天赋中的任何一个来小幅提升你自己的伤害更有价值。
4.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

1. **等级 4 起：**如果你的生命值开始下降，对自己施放[[spell:17]]。
2. **等级 18 起：**冷却时间一到就施放[[spell:10060]]。
3. **等级 2 起：**除非目标会在持续性伤害造成显著效果前死亡，否则保持对所有目标施加[[spell:589]]。
4. **等级 28 起：**如果目标生命值低于20%，施放[[spell:32379]]。小心不要用这个法术杀死自己。
5. **等级 11 起：**冷却时间一到就施放[[spell:47540]]。
6. **等级 5 起：**冷却时间一到就施放[[spell:8092]]。
7. **等级 1 起：**施放[[spell:585]]作为填充技能。

从15级开始，你可以通过游戏内的组队查找器排队进入地下城。以下是地下城中治疗法术的一般优先级列表：

1. **等级 4 起：**如果单个玩家正在承受伤害，冷却时间一到就施放[[spell:17]]。
2. **等级 15 起：**当可用且有多个玩家同时需要救赎时，施放[[spell:194509]]。
3. **等级 3 起：**当你的[[spell:81749]]治疗不足，需要直接治疗某人时，施放[[spell:2061]]。

在你的被动救赎治疗或护盾不足的情况下，你可以依靠一些冷却技能。以下是承受大量伤害时可以使用的冷却技能列表：

1. **等级 19 起：**用[[spell:194509]]为全队施加救赎后，对敌人施放[[spell:421453]]。
2. **等级 35 起：**如果发生了大量伤害，施放[[spell:472433]]以获得即时治疗和救赎覆盖。
   **等级 37 起：**对坦克或另一名承受大量单体伤害的玩家施放[[spell:33206]]。

除了这些基础技能外，还有一个被动效果对于理解以戒律牧师身份升级至关重要。

[[spell:81749]]使你的伤害法术治疗所有带有救赎效果的目标。关键是你要进行伤害输出以利用已施加的救赎，而不是陷入不断刷直接治疗的习惯。按照上面的治疗法术优先级列表施加救赎，然后一旦所有承受伤害的玩家都有了救赎，就按照伤害法术优先级列表进行输出。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对第二赛季发布进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为第一赛季 至暗之夜 发布进行了更新。
- **2026年3月2日：** 添加了从80级开始的天赋导入代码。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战发布进行了更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月27日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月12日：** 修复了天赋树问题。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月21日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页面中，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩戒律牧师，使用最简单的输出循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 戒律牧师基础

本页面面向刚接触游戏或该职业的玩家，他们不打算参与史诗难度团队副本，或者只是想要一种更直接的方式来游玩他们的专精，而不会被为实现最优游玩所需考虑的众多细节和主动技能所淹没。

戒律牧师依靠造成伤害来治疗玩家（通过[[spell:81749]]），但也拥有传统的治疗和吸收法术，用于救赎不足的情况。通过造成伤害进行治疗使他们能够为团队的伤害输出做出贡献，同时仍能履行全职治疗者的职责。

根据戒律当前的设计，有一些规则需要遵循，这将帮助你更容易地学习这个专精。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_penance.jpg>) **不要浪费苦修层数**
  
  
  
  
  与[[spell:47540]]相关的巨大力量和其他触发效果，使得尽可能频繁地施放它变得极其重要。确保你 **绝不** 保留多层可用的苦修层数，将从苦修施放本身为你提供可观的输出，帮助触发更多[[spell:1253593]]，并通过你的2件套套装效果缩短[[spell:8092]]的冷却时间，从而带来更多虚空之盾的触发。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_plea_yellow.jpg>) **不要过度使用施加器**
  
  
  
  
  许多新手玩家会陷入不够信赖他们的[[spell:81749]]的陷阱，很快又回到要么疯狂刷直接治疗，要么过度施加救赎，认为自己需要积极“治疗”而不是按填充型DPS技能。这不仅极其消耗法力值，会导致你很快遇到法力值问题，而且戒律需要在这两者之间保持微妙的平衡。真正进行输出并利用你已激活的救赎，而不是急着施加更多救赎，这一点极其重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_priest_voidshield.jpg>) **虚空之盾的重要性**
  
  
  
  
  许多人没有意识到[[spell:1253593]]的伤害有多高。许多新手玩家只会施放虚空之盾，以为吸收量就是这个法术的全部价值。它不仅是一个出色的救赎施加器，可以同时对3个目标施加救赎，它反射的伤害还会带来大量的救赎治疗。因此，在某些情况下，等到队伍先承受一些伤害后再施放虚空之盾是合理的，这样所有反射的救赎治疗就不会全部变成过量治疗。

1.

### 戒律牧师在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者团本天赋

2.1.

#### 戒律牧师新手团本天赋

这套配装是团本中直接且简单的配装。专注于冷却时间一到就使用[[spell:47540]]和[[spell:8092]]造成伤害并循环触发[[spell:1253593]]。需要治疗时使用[[spell:194509]]施加[[spell:81749]]。只需注意不要过度使用[[spell:17]]/[[spell:2061]]/[[spell:200829]]，因为如果你不小心很容易耗尽法力值。

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMGWmZmBDmZbmtZmZmxMDAAAAAAAAAgZYZGMzMDzYmBMNTzMAzsghwYWGgxgFAAYMmZMYGgZmBYA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWghkANObdeiqstuHKKVoRnGMMSSmmCFWA-bcdeAoqq9los8kFGadhNwwxBi4I5wwE-AAAA-CEMYkow0AUgscA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者大秘境天赋

2.2.

#### 戒律牧师新手大秘境天赋

这套配装是你在大秘境内容中的主要配装。专注于冷却时间一到就施放[[spell:47540]]和[[spell:8092]]造成伤害并循环触发[[spell:1253593]]。[[spell:186263]]并将你的[[spell:47540]]目标切换到盟友，将帮助你在需要时应对单体治疗情况。

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGgZA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAacoqq9lskFGadhNQwwxBi4IJ6E-AAAA-CEMYkow0AUgscA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者地下堡天赋

2.3.

#### 戒律牧师新手地下堡天赋

这套配装是你在地下堡内容中的主要配装。用你的[[spell:447444]]和[[spell:1280137]]打出大伤害窗口，范围清除中等规模的敌人群。务必在此内容中大量使用[[spell:205364]]，带上你能找到的最强敌人为你作战，因为它们造成的伤害通常比你自己还高。此外，大量使用[[spell:586]]来利用[[spell:1250378]]，将仇恨从自己身上移开，这样你就可以花更多时间输出伤害，少担心自己的生命条。

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgBbzgZmZGGzMYz0MxgZGAAgZb2WAjNDAAjZmZmBzgZGMCmB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPLukC-bcdeAaoqq9ls8AlFGiF8SckMQYYgwAK-AAAA-FIikwAMUY8wSgC-
```

:::

### 戒律牧师基础输出循环

2.4.

#### 戒律牧师基础玩法

戒律牧师依靠施加[[spell:81749]]然后造成伤害，通过救赎将伤害转化为一部分治疗。通过[[spell:47540]]、[[spell:2061]]或[[spell:186263]]（特别是在大秘境中）进行直接治疗，以及[[spell:17]]或我们的顶峰天赋[[spell:1253593]]提供的强大吸收效果，构成了其余的治疗量。

2.5.

#### 团队治疗

在团队副本中，你通常应该尽量卡好冷却时间使用[[spell:47540]]。[[spell:17]]很强力，但你要确保每次施放都能提供良好的价值，因为如果你过度使用它们，你很快就会耗尽法力值。确保你使用了获得的每一次[[spell:1253593]]触发效果。

将这些与轮换你的[[spell:194509]]层数结合起来，你就能持续输出非常可观的治疗量（HPS）。在考虑使用我们的主要冷却技能[[spell:472433]]时，你需要围绕重大伤害事件来规划你的使用时机。尽量确保你有[[spell:194509]]层数可以配合布道使用。

2.6.

#### 地下城治疗

你的地下城治疗重点将主要围绕卡好冷却时间施放[[spell:47540]]。借助像[[spell:440742]]这样的天赋以及苦修本身的被动效果，你能获得强大的单体治疗和可观的[[spell:81749]]治疗。此外，每次施放都有机会触发[[spell:1253593]]，它目前是你技能库中最强的法术。经常轮换苦修以获得更多虚空之盾施放机会非常重要。卡好冷却时间施放[[spell:8092]]同样重要，因为它也能触发虚空之盾。

此外，[[spell:186263]]是地下城内容中协助单体治疗的主要治疗量手段。转为防御性地施放苦修、施放一些暗影暗言术：痛以及一些虚空之盾将是你主要的单体治疗方法。

2.7.

#### 顶点天赋

在大多数情况下，我们的顶峰天赋非常容易运用。一旦触发后增益效果会持续相当长的时间，只需确保在施放下一个[[spell:47540]]之前利用好可用的施放机会，以免浪费触发效果。除此之外，请记住虚空之盾的主要目标及其额外目标都会获得救赎效果。

2.8.

#### 救赎施加方式

- [[spell:200829]]是一个瞬发的单体[[spell:81749]]施加技能，并附带一个小型直接治疗效果。使用祈求的最大好处是它可以在移动中施放。
- [[spell:17]]是一个瞬发的单体救赎施加技能，并附带一个相当强力的护盾。虽然这是对单个目标施加救赎的非常强力的选择，但它有冷却时间。
- [[spell:1253593]]是真言术：盾的升级版本，对3个目标而不是一个目标施加护盾。从施加救赎的角度来看，非常重要的一点是，被虚空之盾击中的所有三个目标都会获得救赎效果。
- [[spell:2061]]是一个1.5秒施法时间的单体救赎施加器，附带一个中等大小的单体治疗。由于它比恳求消耗更多法力值，还需要站桩施法，除了少数情况外，它不会像你的主要施加器那样频繁使用。第一个让它获得显著优势的情况是当法术的单体治疗部分变得关键时。另一种情况是利用其他天赋，如[[spell:109186]]或[[spell:368275]]。当快速治疗升级为[[spell:186263]]时，它仍然施加救赎，并作为单体施加器发挥作用。
- [[spell:194509]]是一个2秒施法时间的多目标救赎施加技能，并附带一个可观的治疗。真言术：耀对5个人施加救赎，但持续时间缩短。这在团队副本中用于在重大伤害事件前获得大范围覆盖，或在大秘境中快速为整个小队施加救赎非常有用。

2.9.

#### 冷却技能

- 福音
  
  
  
  
  - 在地下城内容中，[[spell:472433]]在施放时会立即为你的整个队伍恢复可观的生命值。此外，它会使你接下来两次施放[[spell:194509]]变为瞬发。这个增益效果持续时间无限，所以你可以根据需要保留那些耀的施放，这使其成为一个应对高移动性战斗的强大工具。
  - 在团队副本内容中，这个工具是我们所称的“预铺”的主要启动手段。这个概念将在下一节中描述。
  - 布道还会根据你天赋选择激活[[spell:197862]]或[[spell:1280137]]。这要么在一段时间内强化你所有的治疗和吸收效果，要么召唤一个宠物持续一小段时间，既能造成伤害，又能与[[spell:373427]]等其他天赋互动（如果点出了的话）。
- 终极苦修
  
  
  
  
  - 虽然这个法术的冷却时间长达4分钟，但它也非常强大。当进攻性施放时，它会向随机敌人投掷闪电，造成可观的伤害，如果小队身上有救赎效果，这些伤害将转化为大量[[spell:81749]]治疗。当防御性施放时，它会向受伤的盟友投掷闪电，直接治疗他们。
  - 在团队副本中，你几乎总是会进攻性地使用它，并配合下面描述的完整预铺流程，以确保正确的救赎覆盖。与在团队副本中的使用方式类似，在地下城内容中它也几乎只被进攻性使用，但不需要完整的预铺流程就能发挥作用。不过仍要确保在施放前通过[[spell:194509]]为小队施加救赎。
- 真言术：障
  
  
  
  
  - 与[[spell:421453]]共享一个选择节点，意味着你必须在两者之间选择其一。在持续时间内承受的伤害足够显著的任何场景中，真言术：障都可以非常强大。
  - 请记住，它需要小队和/或团队成员能够在护罩下集合才能从中受益，因此在某些战斗中即使伤害值得使用也很难使用。虽然我们默认推荐终极苦修，但请留意切换到真言术：障的好时机。
- 痛苦压制
  
  
  
  
  - 为单个目标提供非常高的伤害减免。在坦克身上或在受到大量持续伤害效果的玩家身上使用它可以产生显著影响。当你使用天赋[[spell:373035]]时，你将拥有大量额外的痛苦压制施放机会，所以请确保你经常使用它，而不是一直保留着最大层数。

2.9.1.

##### 第2赛季套装

我们的两件套奖励[[spell:1296577]]非常强大。它既将[[spell:47540]]的伤害和治疗量提高20%，还会使每次苦修施放减少心灵震爆2秒冷却时间。这之所以非常强大有几个原因。首先，心灵震爆现在在施放时会触发[[spell:1253593]]。由于这个套装直接提高了你的心灵震爆频率（CPM），它也同时提高了你的虚空之盾频率。此外，在游玩虚空编织者时，这极大地增加了你接触[[spell:447444]]的机会，这是一次巨大的威力提升。尽快获得这个两件套非常重要。

我们的四件套奖励[[spell:1296578]]虽然不如我们的两件套奖励那样强大和有影响力，但仍然通过在施放心灵震爆后增加下一个虚空之盾的大小来为我们的输出提供有意义的提升。

### 戒律牧师属性优先级

2.10.

#### 戒律牧师属性优先级

属性优先级如下 **在同等物品等级装备之间做选择时**。有关此页面上呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>).

急速

精通

暴击

全能

### 暴风雪战斗助手

2.11.

#### 戒律牧师战斗助手

自11.1.7补丁以来，魔兽世界推出了一个令人惊叹的无障碍功能——战斗助手。虽然我称赞它是一个无障碍选项，但它对治疗者的实用性值得怀疑。战斗助手永远不会推荐，或者在一键循环的情况下，也不会推荐任何冷却技能或治疗技能。对于戒律，它遵循以下非常简单的优先级列表：

1. 在你的当前目标身上保持暗影言术：痛
2. 在可用时施放[[spell:8092]]
3. 在可用时施放[[spell:47540]]
4. 施放[[spell:585]]

总的来说，这个功能的最佳使用场景可能是进行开放世界内容或地下堡， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者.

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月18日：** 修复了遗漏的过时引用。
- **2026年8月10日：** 针对第二赛季发布进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月20日：** 修复了标题拼写错误，并扩展了一般游戏玩法描述。
- **2026年5月4日：** 添加了一些遗漏的提及
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月21日：** 即将到来的职业平衡调整后更新了天赋推荐。
- **2026年3月16日：** 为第一赛季 至暗之夜 发布进行了更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 添加了战斗助手部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月24日：** 戒律 削弱后进行了更新。
- **2025年3月1日：** 近期平衡调整后进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战发布进行了更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月27日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月10日：** 更新了大秘境天赋推荐，并更新了团本的措辞。
- **2023年7月10日：** 更新了天赋推荐。
- **2023年5月1日：** 为10.1补丁进行了审查。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月22日：** 更新了10.0.5补丁的天赋推荐。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将了解你的戒律牧师在魔兽世界12.1.5补丁中的最佳天赋。我们还为团队副本或大秘境等不同类型的内容提供了默认天赋构建。如果你开启了战争模式进行游戏，我们也为你准备了PvP天赋。

1.

### 至暗之夜中戒律牧师的最佳天赋

随着12.1版本的改动， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者获得了大量加强，因此表现非常出色。然而，在大秘境地下城中仍然存在一些重要的单体治疗需求，这是它所吃力的。因此，我们目前的建议是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 在团队副本和地下堡内容中使用虚空编织者， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 在大秘境内容中使用神谕者。如果地下城中的单体治疗需求最终并非我们吃力的痛点，且虚空编织者表现良好，我们将更新我们的建议。

- **团队副本 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者能永久性地输出大量纯粹的救赎治疗量。由于新套装减少了[[spell:8092]]的冷却时间，你对[[spell:447444]]的覆盖率非常高。因此，你获得显著强化的[[spell:450405]]的机会大大增加。然而，这个专精最大的弱点是移动。所以在移动要求非常高的情况下，可能会出现 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者更好的情况。 **虚空编织者从新的两件套奖励中获得了显著的收益，在拥有它之前可能会感觉较弱。**
- **大秘境 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者是我们为大秘境内容推荐的构建，因为它具有卓越的单体治疗能力。通过轮换虚空之盾的触发效果，利用[[spell:440742]]带来的更容易使用的2层防御性[[spell:47540]]，并且不再那么依赖刷填充性输出法术来提供治疗量，你在需要时能更轻松地推动单体治疗。

**快速开始导入代码：**

:::talents 虚空编织者团队副本
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtFwYzAAwYMzYwMYmBjgB"
}
```
:::

:::talents 神谕者大秘境
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGBzA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

虚空编织者

团队副本

推荐

秘境+

地下堡

推荐

神谕者

团队副本

秘境+

每周大秘境钥匙

高层大秘境

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者团队副本构建

这个构建在任何时候都能输出极高的纯粹治疗量。由于新套装减少了[[spell:8092]]的冷却时间，你对[[spell:447444]]的覆盖率极高，几乎持续不断的使用带来了非常可观的永久性治疗量（HPS）。然而，这个构建在移动方面很吃力，因为[[spell:450405]]在这个构建中占了我们技能频率（CPM）的很大比例。因此，虽然基于潜在输出它是我们团队副本内容的默认推荐，但有可能 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者会在该专精难以正常发挥作用的情况下被使用。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者大秘境构建

虽然这个构建能输出大量纯粹治疗量，但这种输出不如 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者替代方案灵活。虽然你可以轻松推动大量救赎治疗，但大秘境内容中的单体治疗需求往往更难跟上。此外，在大秘境中经常只有少数目标同时需要治疗。虚空编织者缺乏任何方法来真正向这些目标推动额外的救赎治疗，因为基于目标数量的救赎增益在5个目标之前没有任何效果，而你在大秘境中永远不会超过5个目标。因此，这个构建不推荐用于大秘境内容，但在你只是寻求纯粹的群体（AoE）输出的情况下仍可能被使用。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者地下堡构建

这个构建推荐用于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 内容，无论是单人还是组队。虚空编织者天赋树能够在输出惊人伤害的同时让你和你的小队存活下来。

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者团队副本构建

这个构建将作为团队副本内容的替代选项。虽然其输出远不及虚空编织者具有竞争力，但它的好处是机动性极强，你大部分重要的施放都没有施法时间。这可以使该专精在移动频繁或机制复杂的困难战斗中执行起来简单得多。然而，需要注意的是，与虚空编织者近乎无限的法力值相比，这个构建的法力经济要差得多。

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者大秘境构建

这是你大秘境内容的默认推荐天赋构建。凭借其非常灵活的输出，它可以应对各种不同的伤害模式。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzYmBMNTzMYmBAAY2mtFwYzAAwYMzYwMYmBjgB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWghkANObdeiqstuHKKVoRnGMMSSmmCFWA-bcdeAoqq9los8AlFGadhFUMgwwxB5wA-AAAA-FIikwAMUY8wSgC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgZYZGMzMzwYmBbmmJGMzAAAMbz2CYsZAAYMzMjBzgZGMCmB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAaoqq9ls8AlFGiF8SckMQYYgwAK-AAAA-FIikwAMUY8wSgC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgBbzgZmZGGzMYz0MxgZGAAgZb2WAjNDAAjZmZmBzgZGMCmB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPLukC-bcdeAaoqq9ls8AlFGiF8SckMQYYgwAK-AAAA-FIikwAMUY8wSgC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMGWmZmBDmZbmtZmZmxMDAAAAAAAAAgZYZGMzMDzYmBMNTzMAzsghwYWGgxgFAAYMmZMYGgZmBYA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWghkANObdeiqstuHKKVoRnGMMSSmmCFWA-bcdeAoqq9los8kFGadhNwwxBi4I5wwE-AAAA-CEMYkow0AUgscA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGgZA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAacoqq9lskFGadhNQwwxBi4IJ6E-AAAA-CEMYkow0AUgscA-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

我们建议你在最初的几周内选择以下增益，但由于你可以随时自由切换，请自行尝试其他选项，如果你觉得推荐的选项效果不够好：

- 第1周：[[spell:1279599]]
- 第2周：[[spell:1279603]]
- 第3周：[[spell:1287555]]
- 第4周：[[spell:1279612]]
- 第5周：[[spell:1279614]]

1.

### 巅峰天赋： ![Master the Darkness Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_nullstone_void.jpg>) 掌控黑暗

戒律牧师的顶峰天赋“掌控黑暗”总共有4个等级，包含3种不同的效果。第一个[[spell:1253590]]，使你在施放[[spell:47540]]后，下一个[[spell:17]]有几率被转化为[[spell:1253593]]。这个护盾会溅射到附近另外两名盟友。你的掌控黑暗的第二和第三级[[spell:1253845]]，是简单的被动节点，每级都提升你的整体[[spell:81749]]治疗量和所有暗影伤害。最后，你的掌控黑暗的第四级[[spell:1253827]]，使你的[[spell:1253593]]数值在被吸收时有百分比反弹为伤害。这个伤害能通过[[spell:81749]]贡献治疗，使这个天赋非常强大。这最后一点还使[[spell:8092]]能强制触发虚空之盾，为你提供在需要时获得触发效果的途径。

从循环的角度来看，这个天赋使用起来并不特别困难。每当你获得触发效果时，在施放下一个[[spell:47540]]之前使用它，以确保不浪费潜在的触发。此外，你可以延迟施放以配合重大伤害事件，从而利用反弹伤害贡献救赎治疗。

:::details 深入解析虚空之盾
虚空之盾触发机制的具体运作方式基于一个四张卡牌的 **牌库系统**。所以虽然在宏观层面上看起来像是随机（RNG），但触发是有一定可预测性的。想象你有一个牌库，里面有4张牌。其中一张牌写着“虚空之盾触发”，另外三张写着“不触发”。每当你施放苦修时，你就从牌库中抽一张牌。这会持续到牌库抽空，届时你会获得一个牌面分布相同的新牌库。这意味着你每四次苦修施放必定获得一次虚空之盾触发，但你无法预测在这四次中的哪一次会发生。此外，在默认界面下没有任何方法来追踪你在牌库中的位置。

随着牌库系统这样运作，你可以体验到随机（RNG）的两个极端。在新牌库的第一次施放中获得触发，然后在下一个牌库的最后一次施放中获得触发，这会让你在这两次触发之间有6次不触发的苦修施放。这是该系统下你能遇到的最长的无触发连段。此外，在第一个牌库的最后一张牌获得虚空之盾触发，紧接着在第二个牌库的第一张牌获得触发，这会让你获得两次连续的触发，两侧各有三次不触发的施放。

理解这个牌库系统的工作方式，可以让你在战斗中对何时可能获得触发有一定程度的潜意识追踪，从而让你对这个原本基于随机的效果获得少量的控制。

:::

1.

### 英雄天赋

从71级开始，英雄天赋允许玩家通过选择两个互斥选项中的一个来塑造和聚焦他们的游戏玩法。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者是提供给戒律牧师的选项。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者

天赋树的起始节点[[spell:1248423]]，为苦修提供了一个额外层数，为你的输出提供了大量的灵活性和控制力。其他节点如[[spell:440662]]、[[spell:1272359]]、[[spell:1246799]]以及极其强大的[[spell:440742]]都强化了苦修的威力。

神谕者也通过[[spell:440662]]和[[spell:440681]]为[[spell:17]]提供了一些不错的加成。将其与戒律天赋树上的节点如[[spell:390786]]和[[spell:238135]]结合起来，经常按下真言术：盾能带来显著的价值。

神谕者与戒律的新顶峰天赋配合得非常好，因为[[spell:1253593]]继承了[[spell:17]]的修正效果。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者完全专注于[[spell:447444]]。施放[[spell:8092]]会创建一个对其中所有敌人造成伤害的裂隙。当你施放[[spell:47540]]时，这个裂隙会增强，变得更大更强。在裂隙持续期间，你的惩击会转化为[[spell:450405]]，这是一个威力大得多的版本。当裂隙结束时，它会坍缩并造成大量爆发伤害，这可以转化为可观的治疗量。

虚空编织者 还会提供 [[spell:451234]]，这是一个在裂隙消失后召唤的宠物。该宠物的攻击会通过 [[spell:81749]] 为盟友治疗，并且与 戒律 天赋树中的天赋如 [[spell:373427]] 和 [[spell:1240364]] 配合良好。

该英雄天赋树还通过 [[spell:1266883]] 为 [[spell:8092]] 提供了非常大的增益。综合上述所有效果，这棵天赋树将大量强度注入到心灵震爆这个技能中，但结果是当它处于冷却时你可能会感觉相当虚弱。与……不同，该专精也缺乏强大的单体治疗选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者.

1.

### PvP天赋（战争模式）

在 至暗之夜 中，仍然可以选择进入“战争模式”。启用战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于在这个资料片中启用战争模式对PvE内容的收益微乎其微，不建议启用该功能。战争模式由于其提供的额外经验值获取，仍然是升级时的一个有吸引力的选择。

在本节中，我们将对最适合升级和进行单人/小队PvE内容的PvP天赋进行排名。以下是 戒律 牧师 专属PvP天赋的排名。如需了解在竞技PvP环境（而非开放世界）中什么更有价值的信息，请查看我们的PvP指南。

1. [[spell:356085]] 是一个可切换的技能，可为你提供10%的法术强度提升和 [[spell:81749]] 治疗效果，或者15%的治疗法术法力消耗降低。在升级时将其保持在伤害提升模式将带来可观的DPS和生存能力收益。
2. [[spell:1218211]]使你和所有拥有你[[spell:81749]]的盟友的伤害提高15%，持续8秒。这对于小队世界内容非常有用，在这种情况下，为你的小队提供伤害输出增益比通过上述三个天赋中的任何一个来小幅提升你自己的伤害更有价值。
3. 你的第三个选择非常灵活，因为其余选项并没有提供太多原始DPS价值。根据防御/治疗价值，选择你觉得有趣的即可。
4.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月18日：** 修正了错别字。
- **2026年8月11日：** 各种格式修复。
- **2026年8月10日：** 针对第二赛季发布进行了更新。
- **2026年6月15日：** 针对12.0.7补丁和全知全书进行了更新。
- **2026年5月20日：** 修复了不正确的地下堡天赋构筑。
- **2026年5月4日：** 添加了虚空之盾牌组系统的提及。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月21日：** 即将到来的职业平衡调整后更新了天赋推荐。
- **2026年3月16日：** 为第一赛季 至暗之夜 发布进行了审查。
- **2026年2月26日：** 为 至暗之夜 发布进行了更新。
- **2026年2月10日：** 为职业门槛解锁的改动更新了天赋树。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月10日：** 修复了页面上的一些错别字。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年4月1日：** 近期平衡调整后进行了更新。
- **2025年3月1日：** 近期平衡调整后进行了更新。
- **2025年2月25日：** 修复了错误的天赋代码。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 添加了灵活点数和一些额外的天赋讨论。
- **2024年9月11日：** 重新排列了天赋推荐顺序，并添加了关于bender bug的说明。
- **2024年9月10日：** 添加了澄清宠物爆发时间轴的部分。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月26日：** 修复了团本代码导入问题。
- **2024年8月22日：** 修复了大秘境天赋树链接到旧补丁天赋的问题。
- **2024年8月21日：** 为地心之战发布进行了更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月27日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月7日：** 移除了过时的参考资料。
- **2023年11月7日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月10日：** 在狂想曲和虚空之盾热修后进行了更新。
- **2023年7月19日：** 修复了格式问题。
- **2023年7月12日：** 更新为新的页面格式。
- **2023年7月10日：** 针对10.1.5补丁进行了更新。
- **2023年5月6日：** 更新以包含第二赛季地下城特定天赋选择。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月22日：** 更新了10.0.5补丁的天赋推荐。
- **2022年12月11日：** 修复了天赋模拟器大秘境链接。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何根据你的团队所承受的伤害类型来优化 戒律 牧师 的输出循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以最大化你的治疗输出和法力效率。我们所有的内容均已更新至《魔兽世界》12.1.5补丁。

1.

### 戒律 牧师 游戏玩法与输出循环指南

戒律 专精严重依赖通过造成伤害来进行治疗，这要归功于 [[spell:81749]] 被动技能。我们将在此 [详细说明](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities#atonement>)，但现在你只需要记住，作为 戒律，造成伤害是治疗不可分割的一部分。

在接下来的章节中，我们将探讨你应该使用哪些技能来造成伤害（以产生救赎治疗），以及如何处理单体和范围治疗。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者

团队副本

大秘境

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者

团队副本

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

大秘境

主动天赋

被动天赋

[[spell:421453]]

[[spell:62618]]

[[spell:472433]]

[[spell:1253590]]

[[spell:123040]]

[[spell:373427]]

[[spell:390832]]

### 团队副本 - 福音布道起手

**适用条件：神谕者（启用）；虚空编织者（启用）。**

[[spell:589]]

**适用条件：神谕者（启用）；虚空编织者（启用）。**

[[spell:17]]

**适用条件：神谕者（启用）；虚空编织者（启用）。**

[[spell:2061]]

**适用条件：神谕者（启用）；虚空编织者（启用）。**

[[spell:472433]]

**适用条件：神谕者（启用）；虚空编织者（启用）。**

[[spell:194509]]

[[spell:194509]]

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

[[spell:32379]]

**适用条件：神谕者（启用）；虚空编织者（启用）。**

**适用条件：神谕者（启用）；虚空编织者（启用）。**

[[spell:8092]]

**适用条件：神谕者（启用）；虚空编织者（启用）。**

[[spell:47540]]

**适用条件：神谕者（启用）；虚空编织者（启用）。**

[[spell:280749]]

**适用条件：神谕者（启用）；虚空编织者（启用）。**

**适用条件：神谕者（启用）。**

[[spell:47540]]

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

[[spell:32379]]

**适用条件：Inescapable Torment（启用）；Expiation（启用）。**

**适用条件：神谕者（启用）。**

[[spell:585]]

[[spell:47540]]

[[spell:17]]

**适用条件：虚空编织者（启用）。**

[[spell:450405]]

[[spell:47540]]

1.1.

#### 福音布道起手序列

当你拥有 [[spell:472433]] 可用，并希望将该冷却技能用于特定的伤害事件时，由于当前 [[spell:81749]] 的加成机制，该技能的实际使用相当灵活。因此，以下是一个你可以遵循的通用循环，但并非详尽无遗，具体使用方式可能因场景而异。

---

> 当有触发效果可用时，所有 [[spell:17]] 的施放都可以视为 [[spell:280749]] 的施放

1. **适用条件：神谕者（启用）；虚空编织者（启用）。** 如果你的 [[spell:589]] 会在你的起手窗口结束前消失，则刷新它
2. **适用条件：神谕者（启用）；虚空编织者（启用）。** 施放一个 [[spell:17]]
3. **适用条件：神谕者（启用）；虚空编织者（启用）。** 施放一个 [[spell:2061]]
4. **适用条件：神谕者（启用）；虚空编织者（启用）。** 施放 [[spell:472433]]
5. **适用条件：神谕者（启用）；虚空编织者（启用）。** 根据所需覆盖范围施放 [[spell:194509]] 1-2次
6. **适用条件：Inescapable Torment（启用）；Expiation（启用）。** 施放 [[spell:32379]]
7. **适用条件：神谕者（启用）；虚空编织者（启用）。** 施放 [[spell:8092]]
8. **适用条件：神谕者（启用）；虚空编织者（启用）。** 施放 [[spell:47540]]
9. **适用条件：神谕者（启用）；虚空编织者（启用）。** 施放 [[spell:280749]]
10. **适用条件：神谕者（启用）。** 施放 [[spell:47540]]
11. **适用条件：Inescapable Torment（启用）；Expiation（启用）。** 施放 [[spell:32379]]
12. **适用条件：神谕者（启用）。** 持续施放 [[spell:585]] 直到 [[spell:47540]]/[[spell:17]] 再次可用
13. **适用条件：虚空编织者（启用）。** 持续施放 [[spell:450405]] 直到 [[spell:47540]] 再次可用

:::details 常见问题为什么我们的团队副本起手循环中只有一次 快速治疗 施放？
[[spell:368275]]

会导致

[[spell:2061]]

施加

[[spell:81749]]

同时作用于你的目标和你自己。这意味着你可以用一个GCD的代价获得2次救赎效果。因此，你应该避免在起手阶段早期为自己施加救赎，以确保从这次施放中获得最大收益。

:::

### 团队副本 - 终极苦修起手

[[spell:589]]

[[spell:17]]

[[spell:2061]]

[[spell:194509]]

[[spell:8092]]

[[spell:421453]]

[[spell:280749]]

[[spell:47540]]

**适用条件：虚空编织者（启用）。**

[[spell:450405]]

[[spell:17]]

**适用条件：神谕者（启用）。**

[[spell:47540]]

**适用条件：神谕者（启用）。**

[[spell:585]]

[[spell:47540]]

[[spell:17]]

**适用条件：虚空编织者（启用）。**

[[spell:450405]]

[[spell:47540]]

[[spell:127399]]

1.2.

#### 终极苦修起手

[[spell:421453]] 起手的目标是在施放该法术前获得足够数量的 [[spell:81749]] 效果。在团队副本中，你对终极苦修的所有使用都应针对敌人以通过救赎进行治疗，而非直接治疗盟友。

:::details 常见问题终极苦修如何选择目标？
其目标选择基于你作为玩家的当前目标。如果你在施放该法术时选中了一个敌人，它将优先对敌人发射所有飞弹。反之，如果你在施放时选中了一个盟友，它将优先直接治疗盟友。

:::

---

> 当有触发效果可用时，所有 [[spell:17]] 的施放都可以视为 [[spell:280749]] 的施放

1. 刷新你的 [[spell:589]] 以确保其持续整个起手阶段。
2. 施放 [[spell:17]]
3. 施放 [[spell:2061]]
4. 施放两次 [[spell:194509]]
5. 施放 [[spell:8092]]
6. 施放 [[spell:421453]] - 在升空过程中施放 [[spell:280749]]。详情请参阅下方进阶部分。
7. 施放 [[spell:47540]]
8. **适用条件：虚空编织者（启用）。** 施放3次 [[spell:450405]]
9. 施放 [[spell:17]]
10. **适用条件：神谕者（启用）。** 施放 [[spell:47540]]
11. **适用条件：神谕者（启用）。** 持续施放 [[spell:585]] 直到 [[spell:47540]]/[[spell:17]] 再次可用
12. **适用条件：虚空编织者（启用）。** 持续施放 [[spell:450405]] 直到 [[spell:47540]]/[[spell:127399]] 再次可用

### 大秘境输出循环

**适用条件：神谕者（启用）。** 作为 戒律 牧师 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 在大秘境中非常依赖两个主要技能：[[spell:280749]] 和 [[spell:47540]]。为两者搭配多样的增益效果，尽可能频繁地施放虚空之盾对于你的潜在输出至关重要。由于虚空之盾由 苦修 施放和 [[spell:8092]] 施放触发，尽可能接近冷却即施放两者对于整体的虚空之盾CPM至关重要。此外，由于本赛季的新套装效果，施放 苦修 还能为你提供心灵震爆的冷却缩减，从而进一步增加心灵震爆的施放次数。除了这个基本的游戏循环外，你大部分时间会将苦修用于进攻，但得益于 [[spell:440742]]，如果某个特定的人需要帮助，你可以轻松地将 苦修 直接施放在盟友身上。只需记住这样做会牺牲 [[spell:589]] 的扩散。此外，当需要帮助人们应对沉重的单体治疗需求时，[[spell:1252215]] 可用。以下是大秘境中应遵循的通用优先级列表。请记住，大秘境是一个非常动态的环境，期望你能够对即将到来的伤害做出反应并进行规划，而不是简单地遵循固定的输出循环

**适用条件：虚空编织者（启用）。** 作为 戒律 牧师 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 在大秘境中尽可能围绕 [[spell:81749]] 进行游戏，并依靠 [[spell:447444]] 和 [[spell:450405]] 提供强大输出。尽可能接近冷却地施放 [[spell:47540]] 和 [[spell:8092]] 以获得尽可能多的 [[spell:280749]] 触发，这既提供了大量输出，也提供了良好的救赎覆盖。由于第2赛季套装效果，你能更频繁地使用裂隙，从而在任何时候都能维持稳定的HPS。[[spell:186263]] 将弥补许多救赎无法覆盖的单体治疗弱点。以下是大秘境中应遵循的通用优先级列表。请记住，大秘境是一个非常动态的环境，期望你能够对即将到来的伤害做出反应并进行规划，而不是简单地遵循固定的输出循环

---

1. 如果 [[spell:589]] 不在你的当前目标身上，则施放它
2. **适用条件：虚空编织者（启用）。** 施放 [[spell:8092]] 以解锁 [[spell:447444]] 并触发 [[spell:280749]]
3. **适用条件：神谕者（启用）。** 施放 [[spell:8092]] 以造成少量爆发伤害并触发 [[spell:280749]]
4. 如果可用，施放 [[spell:47540]]
5. 如果可用，施放 [[spell:1253593]]
6. **适用条件：Expiation（启用）。** 施放 [[spell:32379]]
7. **适用条件：虚空编织者（启用）。** 持续施放 [[spell:450405]] 直到上述任一法术可用
8. 如果某位玩家需要单体治疗且救赎不足，施放 [[spell:186263]]
9. **适用条件：神谕者（启用）。** 如果没有其他可用技能/没有人处于危险中，施放 [[spell:585]]

---

除了上述优先级列表外，你还有可用的冷却技能（[[spell:472433]]、[[spell:421453]] 和 [[spell:33206]]）：

- [[spell:472433]] - 福音布道在大秘境中完成了两件事：通过其施放时的初始治疗使为团队施加救赎变得更加容易，同时使未来的 [[spell:194509]] 施放变为瞬发，并激活 [[spell:197862]] 为你提供治疗和吸收效果的临时增益。如果你发现自己需要立即为团队提供救赎覆盖或需要治疗增益，请随时使用这个技能。它的冷却时间为1分30秒，你应该相当频繁地使用它，所以不要陷入将其保留太久的常见陷阱。
- **适用条件：神谕者（启用）。** [[spell:421453]] - Uppies 是游戏中冷却时间最长的技能之一，为4分钟，其强度并不完全与之成正比。你主要将此技能用作填补空档的冷却技能，当你没有其他可用技能时使用。其一般用法是在团队身上有救赎效果时，以敌人为目标以从救赎治疗中获益。它还能提供一个非常大的个人护盾，使你也可以将其作为一个主要的防御技能使用。
- **适用条件：虚空编织者（启用）。** [[spell:421453]] - Uppies 是游戏中冷却时间最长的技能之一，为4分钟，如果使用得当则威力惊人。关于作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 使用该法术的一点是，[[spell:450612]] 对 [[spell:47540]] 的增益也适用于 Uppies。因此，确保在施放 Uppies 前施放 [[spell:8092]] 并开启 [[spell:447444]] 以使其发挥全部威力至关重要。该法术的一般用法是在团队身上有救赎效果时，以敌人为目标以从救赎治疗中获益。它同样能提供一个非常大的个人护盾，使你也可以将其作为一个主要的防御技能使用。
- [[spell:33206]] - 在点出 [[spell:373035]] 后，你在整个大秘境中有非常多的 痛苦压制 充能可用。鉴于该法术的强大，请确保你经常将其用于任何承受显著单体伤害的目标。也不要害怕在情况需要时对自己使用它，因为你自身的防御技能相当疲软。

1.

### 至暗之夜 第2赛季套装

本赛季的2件套套装效果 [[spell:1296577]] 至关重要。由于有如此多的强度通过 [[spell:447444]] 与 [[spell:8092]] 挂钩，当 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 和 [[spell:1253593]] 适用于两种专精时，更多的心灵震爆施放次数威力惊人。虽然围绕套装效果进行游戏并不复杂，通常只是比没有套装时稍微快一点按技能，但输出上的差异是巨大的。

新的4件套套装效果 [[spell:1296578]] 在施放心灵震爆后为我们的虚空之盾提供了可观的增益，这与我们其余的游戏策略契合得很好。虽然这是一个不错的增益，但其影响力不如2件套套装效果。

1.

### 戒律 牧师 的重要冷却技能

### [[spell:472433]]

3.1.

#### 福音

在地下城内容中，[[spell:472433]]在施放时会立即为你的整个队伍恢复可观的生命值。此外，它会使你接下来两次施放[[spell:194509]]变为瞬发。这个增益效果持续时间无限，所以你可以根据需要保留那些耀的施放，这使其成为一个应对高移动性战斗的强大工具。

在团队副本内容中，这个工具是我们所称的“起手”的主要推动因素。然而，本赛季在我们建议如何关注你所知的“起手”方面有些不同。详情请查看下方“精通你的 戒律 牧师”部分中关于救赎的内容。

布道还会根据你天赋选择激活[[spell:197862]]或[[spell:1280137]]。这要么在一段时间内强化你所有的治疗和吸收效果，要么召唤一个宠物持续一小段时间，既能造成伤害，又能与[[spell:373427]]等其他天赋互动（如果点出了的话）。

### [[spell:421453]]

3.2.

#### 终极苦修

虽然该法术的冷却时间长达4分钟，但它同样威力惊人。当进攻性施放时，它会向随机敌人发射飞弹，造成可观的伤害，如果团队身上有救赎效果，这将转化为大量的 [[spell:81749]] 治疗。当防御性施放时，它会向受伤的盟友发射飞弹，直接治疗他们。

在地下城和团队副本内容中，你几乎总是希望进攻性地使用该法术。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者，在地下城中可能存在非常小众的场景让你想防御性地使用它，但这种情况很少见。此外，作为 虚空编织者，[[spell:307334]] 对 [[spell:47540]] [[spell:81749]] 治疗的增益确实对终极苦修的救赎治疗有效。因此，作为 虚空编织者，你应该始终尝试在裂隙窗口期间使用该法术以最大化其输出潜力，除非你专门将其作为填补空档的工具以过渡到下一个 [[spell:447444]]。

### [[spell:62618]]

3.3.

#### 真言术：障

真言术：障与 [[spell:421453]] 共享一个抉择节点，这意味着你必须二选一。在持续时间内承受的伤害足够显著的任何场景中，真言术：障都可以非常强大。请记住，它需要团队和/或团队成员能够在护罩下集合堆叠才能从中获益，因此在某些战斗中即使伤害量证明值得使用，它也很难使用。虽然我们默认推荐终极苦修，但请留意适合切换到真言术：障的良好时机。

### [[spell:33206]]

3.4.

#### 痛苦压制

痛苦压制 是一个作用于单体目标的非常强大的减伤技能。将其用于坦克或身上有大量持续伤害效果的玩家可以产生显著影响。当你点出天赋 [[spell:373035]] 时，你将有大量额外的 痛苦压制 施放次数可用，因此请确保经常使用它，而不是仅仅保留最大充能。

1.

### 剧毒深渊中 戒律 牧师 的配装、提示与技巧

<table>&#10;<tr>&#10;<th colspan="2" style="text-align: center">团队副本难度</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<strong>英雄团队副本</strong>&#10;</td>&#10;<td>&#10;<strong>史诗团队副本</strong>&#10;</td>&#10;</tr>&#10;</table>

### 盘魂者内克扎莉

4.1.

#### 盘魂者内克扎莉

4.1.1.

##### 伤害模式分解与起手目标

**适用条件：Heroic Raid（启用）。**

<em>即将推出！</em>

**适用条件：Mythic Raid（启用）。**

<em>即将推出！</em>

以下是你可以用于这场Boss战的冷却计划示例：

**适用条件：Heroic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3470;Difficulty:Heroic;Name:Nek'zali

time:1;ph:1;tag:PLAYER;spellid:194509;

time:2;ph:1;tag:PLAYER;spellid:472433;

time:2;ph:1;tag:PLAYER;spellid:194509;

time:37;ph:1;tag:PLAYER;spellid:194509;

time:64;ph:1;tag:PLAYER;spellid:194509;

time:78;ph:1;tag:PLAYER;spellid:421453;

time:79;ph:1;tag:PLAYER;spellid:194509;

time:96;ph:1;tag:PLAYER;spellid:472433;

time:96;ph:1;tag:PLAYER;spellid:194509;

time:117;ph:1;tag:PLAYER;spellid:194509;

time:146;ph:1;tag:PLAYER;spellid:194509;

time:199;ph:1;tag:PLAYER;spellid:472433;

time:199;ph:1;tag:PLAYER;spellid:194509;

time:47;ph:1.5;tag:PLAYER;spellid:472433;

time:47;ph:1.5;tag:PLAYER;spellid:194509;

time:74;ph:1.5;tag:PLAYER;spellid:194509;

time:96;ph:1.5;tag:PLAYER;spellid:194509;

time:142;ph:1.5;tag:PLAYER;spellid:194509;

time:142;ph:1.5;tag:PLAYER;spellid:472433;

time:164;ph:1.5;tag:PLAYER;spellid:194509;

time:233;ph:2;tag:PLAYER;spellid:472433;

time:233;ph:2;tag:PLAYER;spellid:194509;

time:273;ph:2;tag:PLAYER;spellid:194509;

time:273;ph:2;tag:PLAYER;spellid:421453;

time:323;ph:2;tag:PLAYER;spellid:472433;

time:323;ph:2;tag:PLAYER;spellid:194509;

time:373;ph:2;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3470;Difficulty:Mythic;Name:Nek'zali

time:2;ph:1;tag:PLAYER;spellid:472433;

time:2;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:194509;

time:69;ph:1;tag:PLAYER;spellid:194509;

time:70;ph:1;tag:PLAYER;spellid:194509;

time:70;ph:1;tag:PLAYER;spellid:421453;

time:92;ph:1;tag:PLAYER;spellid:472433;

time:92;ph:1;tag:PLAYER;spellid:194509;

time:43;ph:1.5;tag:PLAYER;spellid:194509;

time:81;ph:1.5;tag:PLAYER;spellid:472433;

time:81;ph:1.5;tag:PLAYER;spellid:194509;

time:103;ph:1.5;tag:PLAYER;spellid:194509;

time:171;ph:2;tag:PLAYER;spellid:472433;

time:171;ph:2;tag:PLAYER;spellid:194509;

time:212;ph:2;tag:PLAYER;spellid:194509;

time:213;ph:2;tag:PLAYER;spellid:421453;

time:213;ph:2;tag:PLAYER;spellid:194509;

time:260;ph:2;tag:PLAYER;spellid:194509;

time:261;ph:2;tag:PLAYER;spellid:472433;
```

:::

要在游戏中使用上述冷却技能示例，你需要
[Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
插件来为你朗读备注并在战斗中提供警报。如果你不熟悉 Northern Sky Raid Tools 插件以及如何配合备注使用它，Viserio 提供了一个很棒的指南 [此处](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
介绍如何导入所提供的备注。

**适用条件：Heroic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-nekzali-the-soulcoiler-heroic-nekzali-heroic-wcp-cds-0sv8kwn>) .

**适用条件：Mythic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-nekzali-the-soulcoiler-mythic-nekzali-mythic-wcp-cds-olml7bm>) .

### 陵寝哨兵

4.2.

#### 陵寝哨兵

4.2.1.

##### 伤害模式分解与起手目标

**适用条件：Heroic Raid（启用）。**

<em>即将推出！</em>

**适用条件：Mythic Raid（启用）。**

<em>即将推出！</em>

以下是你可以用于这场Boss战的冷却计划示例：

**适用条件：Heroic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3445;Difficulty:Heroic;Name:Sentinels

time:15;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:1;tag:PLAYER;spellid:421453;

time:46;ph:1;tag:PLAYER;spellid:472433;

time:46;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:2;tag:PLAYER;spellid:194509;

time:47;ph:2;tag:PLAYER;spellid:194509;

time:68;ph:2;tag:PLAYER;spellid:194509;

time:90;ph:2;tag:PLAYER;spellid:472433;

time:90;ph:2;tag:PLAYER;spellid:194509;

time:15;ph:3;tag:PLAYER;spellid:194509;

time:47;ph:3;tag:PLAYER;spellid:194509;

time:68;ph:3;tag:PLAYER;spellid:194509;

time:90;ph:3;tag:PLAYER;spellid:472433;

time:90;ph:3;tag:PLAYER;spellid:194509;

time:14;ph:4;tag:PLAYER;spellid:194509;

time:15;ph:4;tag:PLAYER;spellid:194509;

time:15;ph:4;tag:PLAYER;spellid:421453;

time:47;ph:4;tag:PLAYER;spellid:194509;

time:68;ph:4;tag:PLAYER;spellid:194509;

time:91;ph:4;tag:PLAYER;spellid:472433;

time:91;ph:4;tag:PLAYER;spellid:194509;

time:14;ph:5;tag:PLAYER;spellid:194509;

time:47;ph:5;tag:PLAYER;spellid:194509;

time:68;ph:5;tag:PLAYER;spellid:194509;

time:91;ph:5;tag:PLAYER;spellid:472433;

time:91;ph:5;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3445;Difficulty:Mythic;Name:Sentinels

time:15;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:1;tag:PLAYER;spellid:421453;

time:46;ph:1;tag:PLAYER;spellid:472433;

time:46;ph:1;tag:PLAYER;spellid:194509;

time:16;ph:2;tag:PLAYER;spellid:194509;

time:47;ph:2;tag:PLAYER;spellid:194509;

time:68;ph:2;tag:PLAYER;spellid:194509;

time:90;ph:2;tag:PLAYER;spellid:472433;

time:90;ph:2;tag:PLAYER;spellid:194509;

time:15;ph:3;tag:PLAYER;spellid:194509;

time:47;ph:3;tag:PLAYER;spellid:194509;

time:68;ph:3;tag:PLAYER;spellid:194509;

time:90;ph:3;tag:PLAYER;spellid:472433;

time:90;ph:3;tag:PLAYER;spellid:194509;

time:14;ph:4;tag:PLAYER;spellid:194509;

time:15;ph:4;tag:PLAYER;spellid:194509;

time:15;ph:4;tag:PLAYER;spellid:421453;

time:47;ph:4;tag:PLAYER;spellid:194509;

time:68;ph:4;tag:PLAYER;spellid:194509;

time:91;ph:4;tag:PLAYER;spellid:472433;

time:91;ph:4;tag:PLAYER;spellid:194509;

time:115;ph:5;tag:PLAYER;spellid:194509;

time:148;ph:5;tag:PLAYER;spellid:194509;

time:169;ph:5;tag:PLAYER;spellid:194509;

time:192;ph:5;tag:PLAYER;spellid:472433;

time:192;ph:5;tag:PLAYER;spellid:194509;
```

:::

要在游戏中使用上述冷却技能示例，你需要
[Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
插件来为你朗读备注并在战斗中提供警报。如果你不熟悉 Northern Sky Raid Tools 插件以及如何配合备注使用它，Viserio 提供了一个很棒的指南 [此处](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
介绍如何导入所提供的备注。

**适用条件：Heroic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-entombed-sentinels-heroic-entombed-sentinels-heroic-wcp-cds-9p0kboo>) .

**适用条件：Mythic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-entombed-sentinels-mythic-entombed-sentinels-mythic-wcp-cds-n77u0hf>) .

### 迷失的探险者

4.3.

#### 迷失的探险者

4.3.1.

##### 伤害模式分解与起手目标

**适用条件：Heroic Raid（启用）。**

<em>即将推出！</em>

**适用条件：Mythic Raid（启用）。**

<em>即将推出！</em>

以下是你可以用于这场Boss战的冷却计划示例：

**适用条件：Heroic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3497;Difficulty:Heroic;Name:Explorers

time:2;ph:1;tag:PLAYER;spellid:472433;

time:2;ph:1;tag:PLAYER;spellid:194509;

time:19;ph:1;tag:PLAYER;spellid:194509;

time:20;ph:1;tag:PLAYER;spellid:421453;

time:21;ph:1;tag:PLAYER;spellid:194509;

time:50;ph:1;tag:PLAYER;spellid:194509;

time:20;ph:2;tag:PLAYER;spellid:194509;

time:38;ph:2;tag:PLAYER;spellid:472433;

time:38;ph:2;tag:PLAYER;spellid:194509;

time:59;ph:2;tag:PLAYER;spellid:194509;

time:85;ph:2;tag:PLAYER;spellid:194509;

time:115;ph:2;tag:PLAYER;spellid:194509;

time:5;ph:3;tag:PLAYER;spellid:472433;

time:5;ph:3;tag:PLAYER;spellid:194509;

time:20;ph:3;tag:PLAYER;spellid:194509;

time:40;ph:3;tag:PLAYER;spellid:194509;

time:59;ph:3;tag:PLAYER;spellid:194509;

time:95;ph:3;tag:PLAYER;spellid:472433;

time:95;ph:3;tag:PLAYER;spellid:194509;

time:115;ph:3;tag:PLAYER;spellid:194509;

time:115;ph:3;tag:PLAYER;spellid:421453;

time:116;ph:3;tag:PLAYER;spellid:194509;

time:144;ph:4;tag:PLAYER;spellid:194509;

time:164;ph:4;tag:PLAYER;spellid:194509;

time:185;ph:4;tag:PLAYER;spellid:472433;

time:185;ph:4;tag:PLAYER;spellid:194509;

time:209;ph:4;tag:PLAYER;spellid:194509;

time:239;ph:4;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

<em>即将推出！</em>

要在游戏中使用上述冷却技能示例，你需要
[Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
插件来为你朗读备注并在战斗中提供警报。如果你不熟悉 Northern Sky Raid Tools 插件以及如何配合备注使用它，Viserio 提供了一个很棒的指南 [此处](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
介绍如何导入所提供的备注。

**适用条件：Heroic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-the-lost-explorers-heroic-turtles-heroic-wcp-cds-n7fmpzo>) .

**适用条件：Mythic Raid（启用）。**

### 万毒邪祟者瓦什尼克

4.4.

#### 万毒邪祟者瓦什尼克

4.4.1.

##### 伤害模式分解与起手目标

**适用条件：Heroic Raid（启用）。**

<em>即将推出！</em>

**适用条件：Mythic Raid（启用）。**

<em>即将推出！</em>

以下是你可以用于这场Boss战的冷却计划示例：

**适用条件：Heroic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3455;Difficulty:Heroic;Name:Vashnik

time:3;ph:1;tag:PLAYER;spellid:472433;

time:3;ph:1;tag:PLAYER;spellid:194509;

time:33;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:421453;

time:54;ph:1;tag:PLAYER;spellid:194509;

time:79;ph:1;tag:PLAYER;spellid:194509;

time:99;ph:1;tag:PLAYER;spellid:472433;

time:99;ph:1;tag:PLAYER;spellid:194509;

time:119;ph:1;tag:PLAYER;spellid:194509;

time:129;ph:1;tag:PLAYER;spellid:194509;

time:144;ph:1;tag:PLAYER;spellid:194509;

time:163;ph:1;tag:PLAYER;spellid:194509;

time:190;ph:1;tag:PLAYER;spellid:472433;

time:190;ph:1;tag:PLAYER;spellid:194509;

time:204;ph:1;tag:PLAYER;spellid:194509;

time:218;ph:1;tag:PLAYER;spellid:194509;

time:247;ph:1;tag:PLAYER;spellid:194509;

time:280;ph:1;tag:PLAYER;spellid:472433;

time:280;ph:1;tag:PLAYER;spellid:194509;

time:295;ph:1;tag:PLAYER;spellid:194509;

time:297;ph:1;tag:PLAYER;spellid:421453;

time:298;ph:1;tag:PLAYER;spellid:194509;

time:331;ph:1;tag:PLAYER;spellid:194509;

time:372;ph:1;tag:PLAYER;spellid:472433;

time:372;ph:1;tag:PLAYER;spellid:194509;

time:384;ph:1;tag:PLAYER;spellid:194509;

time:415;ph:1;tag:PLAYER;spellid:194509;

time:445;ph:1;tag:PLAYER;spellid:194509;

time:456;ph:1;tag:PLAYER;spellid:194509;

time:464;ph:1;tag:PLAYER;spellid:472433;

time:464;ph:1;tag:PLAYER;spellid:194509;

time:499;ph:1;tag:PLAYER;spellid:194509;

time:528;ph:1;tag:PLAYER;spellid:194509;

time:540;ph:1;tag:PLAYER;spellid:194509;

time:555;ph:1;tag:PLAYER;spellid:472433;

time:555;ph:1;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3455;Difficulty:Mythic;Name:Vashnik

time:3;ph:1;tag:PLAYER;spellid:472433;

time:3;ph:1;tag:PLAYER;spellid:194509;

time:33;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:194509;

time:34;ph:1;tag:PLAYER;spellid:421453;

time:54;ph:1;tag:PLAYER;spellid:194509;

time:74;ph:1;tag:PLAYER;spellid:194509;

time:99;ph:1;tag:PLAYER;spellid:472433;

time:99;ph:1;tag:PLAYER;spellid:194509;

time:119;ph:1;tag:PLAYER;spellid:194509;

time:129;ph:1;tag:PLAYER;spellid:194509;

time:144;ph:1;tag:PLAYER;spellid:194509;

time:159;ph:1;tag:PLAYER;spellid:194509;

time:190;ph:1;tag:PLAYER;spellid:472433;

time:190;ph:1;tag:PLAYER;spellid:194509;

time:204;ph:1;tag:PLAYER;spellid:194509;

time:218;ph:1;tag:PLAYER;spellid:194509;

time:242;ph:1;tag:PLAYER;spellid:194509;

time:280;ph:1;tag:PLAYER;spellid:472433;

time:280;ph:1;tag:PLAYER;spellid:194509;

time:295;ph:1;tag:PLAYER;spellid:194509;

time:297;ph:1;tag:PLAYER;spellid:421453;

time:298;ph:1;tag:PLAYER;spellid:194509;

time:326;ph:1;tag:PLAYER;spellid:194509;

time:372;ph:1;tag:PLAYER;spellid:472433;

time:372;ph:1;tag:PLAYER;spellid:194509;

time:384;ph:1;tag:PLAYER;spellid:194509;

time:410;ph:1;tag:PLAYER;spellid:194509;

time:445;ph:1;tag:PLAYER;spellid:194509;

time:456;ph:1;tag:PLAYER;spellid:194509;

time:464;ph:1;tag:PLAYER;spellid:472433;

time:464;ph:1;tag:PLAYER;spellid:194509;

time:528;ph:1;tag:PLAYER;spellid:194509;

time:540;ph:1;tag:PLAYER;spellid:194509;

time:555;ph:1;tag:PLAYER;spellid:472433;

time:555;ph:1;tag:PLAYER;spellid:194509;
```

:::

要在游戏中使用上述冷却技能示例，你需要
[Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
插件来为你朗读备注并在战斗中提供警报。如果你不熟悉 Northern Sky Raid Tools 插件以及如何配合备注使用它，Viserio 提供了一个很棒的指南 [此处](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
介绍如何导入所提供的备注。

**适用条件：Heroic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-vashnik-the-malignant-heroic-vashnik-heroic-wcp-cds-hesput1>) .

**适用条件：Mythic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-vashnik-the-malignant-mythic-vashnik-mythic-wcp-cds-3qbcsvb>) .

### 斯索拉克

4.5.

#### 斯索拉克

4.5.1.

##### 伤害模式分解与起手目标

**适用条件：Heroic Raid（启用）。**

<em>即将推出！</em>

**适用条件：Mythic Raid（启用）。**

<em>即将推出！</em>

以下是你可以用于这场Boss战的冷却计划示例：

**适用条件：Heroic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3420;Difficulty:Heroic;Name:Sszorak

time:13;ph:1;tag:PLAYER;spellid:472433;

time:13;ph:1;tag:PLAYER;spellid:194509;

time:44;ph:1;tag:PLAYER;spellid:194509;

time:64;ph:1;tag:PLAYER;spellid:194509;

time:65;ph:1;tag:PLAYER;spellid:421453;

time:65;ph:1;tag:PLAYER;spellid:194509;

time:96;ph:1;tag:PLAYER;spellid:194509;

time:112;ph:1;tag:PLAYER;spellid:472433;

time:112;ph:1;tag:PLAYER;spellid:194509;

time:126;ph:1;tag:PLAYER;spellid:194509;

time:147;ph:1;tag:PLAYER;spellid:194509;

time:156;ph:1;tag:PLAYER;spellid:194509;

time:182;ph:1;tag:PLAYER;spellid:194509;

time:205;ph:1;tag:PLAYER;spellid:472433;

time:205;ph:1;tag:PLAYER;spellid:194509;

time:212;ph:1;tag:PLAYER;spellid:194509;

time:234;ph:1;tag:PLAYER;spellid:194509;

time:255;ph:1;tag:PLAYER;spellid:194509;

time:266;ph:1;tag:PLAYER;spellid:194509;

time:296;ph:1;tag:PLAYER;spellid:472433;

time:296;ph:1;tag:PLAYER;spellid:194509;

time:320;ph:1;tag:PLAYER;spellid:194509;

time:337;ph:1;tag:PLAYER;spellid:194509;

time:338;ph:1;tag:PLAYER;spellid:194509;

time:338;ph:1;tag:PLAYER;spellid:421453;

time:373;ph:1;tag:PLAYER;spellid:194509;

time:388;ph:1;tag:PLAYER;spellid:472433;

time:388;ph:1;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

即将推出！

要在游戏中使用上述冷却技能示例，你需要
[Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
插件来为你朗读备注并在战斗中提供警报。如果你不熟悉 Northern Sky Raid Tools 插件以及如何配合备注使用它，Viserio 提供了一个很棒的指南 [此处](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
介绍如何导入所提供的备注。

**适用条件：Heroic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-sszorak-heroic-sszorak-heroic-wcp-cds-1ozm7ml>) .

**适用条件：Mythic Raid（启用）。**

### 双子毒牙

4.6.

#### 双子毒牙

4.6.1.

##### 伤害模式分解与起手目标

**适用条件：Heroic Raid（启用）。**

<em>即将推出！</em>

**适用条件：Mythic Raid（启用）。**

<em>即将推出！</em>

以下是你可以用于这场Boss战的冷却计划示例：

**适用条件：Heroic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3421;Difficulty:Heroic;Name:Twin Fangs

time:39;ph:1;tag:PLAYER;spellid:194509;

time:40;ph:1;tag:PLAYER;spellid:472433;

time:54;ph:1;tag:PLAYER;spellid:194509;

time:71;ph:1;tag:PLAYER;spellid:194509;

time:107;ph:1;tag:PLAYER;spellid:194509;

time:120;ph:1;tag:PLAYER;spellid:194509;

time:139;ph:1;tag:PLAYER;spellid:472433;

time:139;ph:1;tag:PLAYER;spellid:194509;

time:209;ph:1;tag:PLAYER;spellid:194509;

time:222;ph:1;tag:PLAYER;spellid:194509;

time:240;ph:1;tag:PLAYER;spellid:472433;

time:240;ph:1;tag:PLAYER;spellid:194509;

time:277;ph:1;tag:PLAYER;spellid:194509;

time:290;ph:1;tag:PLAYER;spellid:194509;

time:308;ph:1;tag:PLAYER;spellid:194509;

time:379;ph:1;tag:PLAYER;spellid:472433;

time:379;ph:1;tag:PLAYER;spellid:194509;

time:391;ph:1;tag:PLAYER;spellid:194509;

time:410;ph:1;tag:PLAYER;spellid:194509;

time:446;ph:1;tag:PLAYER;spellid:194509;

time:459;ph:1;tag:PLAYER;spellid:194509;

time:478;ph:1;tag:PLAYER;spellid:472433;

time:478;ph:1;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

即将推出！

要在游戏中使用上述冷却技能示例，你需要
[Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
插件来为你朗读备注并在战斗中提供警报。如果你不熟悉 Northern Sky Raid Tools 插件以及如何配合备注使用它，Viserio 提供了一个很棒的指南 [此处](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
介绍如何导入所提供的备注。

**适用条件：Heroic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-the-twin-fangs-heroic-the-twin-fangs-heroic-wcp-cds-voia9cc>) .

**适用条件：Mythic Raid（启用）。**

### 盘卷祭坛

4.7.

#### 盘卷祭坛

4.7.1.

##### 伤害模式分解与起手目标

**适用条件：Heroic Raid（启用）。**

<em>即将推出！</em>

**适用条件：Mythic Raid（启用）。**

<em>即将推出！</em>

以下是你可以用于这场Boss战的冷却计划示例：

**适用条件：Heroic Raid（启用）。**

:::details 冷却技能示例
输入你的角色名称以用于个人备注：

```
EncounterID:3429;Difficulty:Heroic;Name:Coiled Altar

time:1;ph:1;tag:PLAYER;spellid:472433;

time:4;ph:1;tag:PLAYER;spellid:194509;

time:46;ph:1;tag:PLAYER;spellid:194509;

time:79;ph:1;tag:PLAYER;spellid:194509;

time:80;ph:1;tag:PLAYER;spellid:421453;

time:80;ph:1;tag:PLAYER;spellid:194509;

time:127;ph:1;tag:PLAYER;spellid:472433;

time:127;ph:1;tag:PLAYER;spellid:194509;

time:18;ph:2;tag:PLAYER;spellid:194509;

time:51;ph:2;tag:PLAYER;spellid:194509;

time:103;ph:2;tag:PLAYER;spellid:472433;

time:103;ph:2;tag:PLAYER;spellid:194509;

time:136;ph:2;tag:PLAYER;spellid:194509;

time:187;ph:2;tag:PLAYER;spellid:194509;

time:4;ph:2.5;tag:PLAYER;spellid:472433;

time:4;ph:2.5;tag:PLAYER;spellid:194509;

time:19;ph:2.5;tag:PLAYER;spellid:194509;

time:3;ph:3;tag:PLAYER;spellid:194509;

time:6;ph:3;tag:PLAYER;spellid:421453;

time:6;ph:3;tag:PLAYER;spellid:194509;

time:35;ph:3;tag:PLAYER;spellid:194509;

time:64;ph:3;tag:PLAYER;spellid:194509;

time:97;ph:3;tag:PLAYER;spellid:194509;

time:97;ph:3;tag:PLAYER;spellid:472433;

time:128;ph:3;tag:PLAYER;spellid:194509;
```

:::

**适用条件：Mythic Raid（启用）。**

即将推出！

要在游戏中使用上述冷却技能示例，你需要
[Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>)
插件来为你朗读备注并在战斗中提供警报。如果你不熟悉 Northern Sky Raid Tools 插件以及如何配合备注使用它，Viserio 提供了一个很棒的指南 [此处](<https://wowutils.com/viserio-cooldowns/guide/nsrt-guide>)
介绍如何导入所提供的备注。

**适用条件：Heroic Raid（启用）。**

更喜欢直接在 wowutils 上查看备注？请查看上述备注的公开版本 [此处](<https://wowutils.com/viserio-cooldowns/library/venomous-abyss-the-coiled-altar-heroic-the-coiled-altar-heroic-wcp-cds-p4nxq3p>) .

**适用条件：Mythic Raid（启用）。**

### 乌拉特克

4.8.

#### 乌拉特克

4.8.1.

##### 伤害模式分解与起手目标

**适用条件：Heroic Raid（启用）。**

<em>即将推出！</em>

**适用条件：Mythic Raid（启用）。**

<em>即将推出！</em>

以下是你可以用于这场Boss战的冷却计划示例：

**适用条件：Heroic Raid（启用）。**

即将推出！

**适用条件：Mythic Raid（启用）。**

即将推出！

1.

### 选读：精通你的 戒律 牧师

虽然我们到目前为止给出的指导方针将使你作为 戒律 牧师 表现出非常不错的表现，但如果你想充分发挥角色的潜力，还有一些细节需要注意。

5.1.

#### 当前救赎的加成机制现状

[[spell:81749]] 包含一项缩减机制，当激活的救赎目标超过5个时，每多一个救赎的效益会降低。开发者的本意是让救赎在大秘境中或在较低救赎数量时也能产生显著影响，同时在团本中高数量时保持平衡。然而，经过反复调整，这一缩减机制现在变得极其极端，以至于超过某个数量后再施加更多救赎纯粹是为了覆盖面，几乎不会真正提升你的总输出，如下图所示。

[
![Discipline Atonement Healing Graph](<https://static.icy-veins.com/images/wow/classes/priest/diminishing_value_of_atonements.png>)
](<https://static.icy-veins.com/images/wow/classes/priest/diminishing_value_of_atonements.png>)

通过加入 [[spell:8092]] 强制触发 [[spell:1253593]]，以及新的两件套套装奖励增加心灵震爆的施放次数，你的每分钟施法次数（CPM）得到提升，你只需按冷却时间按下按键并把 [[spell:194509]] 施放在即将到来的伤害事件上，就能自然维持相当数量的救赎。除此之外，通过 [[spell:200829]] 或 [[spell:2061]] 等技能刻意施加更多救赎，除了偶尔为了从 [[spell:368275]] 中获益而施放一次外，代价都非常高昂。这些施放不仅法力效率极低，而且在许多情况下甚至无法提升HPS，因为正如我上面提到的，你消耗的是GCD来换取覆盖面，而不是更多的治疗吞吐量。

这使得 戒律 处于一个尴尬的境地。虽然该专精历来侧重于铺垫达到20个救赎的大爆发，并在这些窗口期内打出巨量治疗，但现在我们发现自己更倾向于保持在较低的救赎数量，因为这样效率更高。

**总结：虽然如果出于覆盖面需要，你仍然可以爆发到20个救赎，但要明白这样做仅仅是为了覆盖面。你这样做几乎不会获得更多的HPS。**

5.2.

#### 苦修的快速施放（Clipping）作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者

在游玩 虚空编织者 时，[[spell:450405]] 强大到令人难以置信，尽管它是一个“填充”技能，但其价值却超过了许多现有技能。例如，在斩杀阶段，虚空冲击比 [[spell:32379]] 更强，实际上将这个核心技能挤成了一个移动中的GCD技能，而不是一个真正的循环按键。不幸的是，这对 [[spell:47540]] 在一定程度上也是如此。

跳读你的 苦修 施放，让你能更快回到虚空冲击的施放，更容易维持你的 [[spell:1253724]] 层数，并且通过更好地利用法术排队系统可能获得少量时间，从而带来实际的HPS提升，而不是让技能完整引导。请记住，在某些情况下让技能完整引导仍然是正确的；即当你同时拥有 [[spell:373180]] 触发效果和 [[spell:198068]] 触发效果可用时。

你是否这样做完全取决于你自己，因为这是一个相当细微的优化，但它确实是一个提升。

5.3.

#### 团本中优化福音的使用

虽然默认推荐的团本爆发循环是先施放福音，然后接两个瞬发的希望圣言，但在希望圣言之前或之后施放福音的HPS差异微乎其微。因此，你可以根据增益效果的瞬发部分何时最有价值，轻松调整希望圣言的确切位置。如果你使用希望圣言应对的机制需要大量移动，请随意先施放福音，然后对那个事件使用两个瞬发。然而，如果你可以安全地站着不动，毫无问题地硬读两个希望圣言，并且你知道你的下一个希望圣言施放会从瞬发中获益更多，那么请随意在福音之前硬读它们以保留增益效果。

5.4.

#### 终极苦修

在施放 [[spell:421453]] 时，在你的施法结束之后、实际技能的引导开始之前，有一小段时间你会飘向空中。在此期间，你可以施放一个瞬发技能而不会取消终极苦修的引导。这通常用于在你通常什么都不做的时候施放一个 [[spell:17]]。这是一个非常重要且需要意识到并加以利用的机制。

以下视频展示了这一机制的实际操作：

[观看原文视频](<https://static.icy-veins.com/images/wow/classes/priest/UppiesFreeCastWebm.webm>)

<em>终极苦修免费GCD示例</em>

5.5.

#### 优化虚空之盾的使用

[[spell:1253593]] 占我们当前输出的极大比例，因此了解如何利用它非常重要。如果你不理解卡牌系统是如何工作的，请在继续之前阅读以下TC部分。

:::details 深入解析虚空之盾
虚空之盾触发的具体方式是基于四张牌的 **牌库系统**系统。所以虽然在宏观上看像是随机数生成（RNG），但触发是有一定可预测性的。想象你有一副4张牌的牌组。其中一张牌写着“虚空之盾触发”，另外3张写着“不触发”。每次你施放 苦修，你就从牌组中抽一张牌。这会持续到牌组抽空，届时你会获得一副牌面分布相同的新牌组。这意味着你每4次 苦修 施放必然获得一次虚空之盾触发，但你无法预测这4次中的哪一次会触发。此外，使用默认界面无法追踪你在牌组中的位置。

由于卡牌系统的工作方式，你可以体验到两种极端的随机情况。在新牌组的第一次施放就触发，紧接着在下一副牌组的最后一次施放触发，会让你在这两次触发之间有6次没有触发的苦修施放。这是该系统下你能遇到的最长的无触发连击。此外，在第一副牌组的最后一张牌触发虚空之盾，紧接着在第二副牌组的第一张牌触发，会让你获得连续两次触发，两侧各有3次无触发的施放。

理解这个牌库系统的工作方式，可以让你在战斗中对何时可能获得触发有一定程度的潜意识追踪，从而让你对这个原本基于随机的效果获得少量的控制。

:::

顺便提一下，在游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 时，特别是由于 [[spell:433905]] 的存在，当你自己身上没有激活的护盾时，给自己施放虚空之盾会带来HPS提升，因为自身护盾的增益大小也会通过反射转化为更多的 [[spell:81749]] 治疗。

5.6.

#### 个人减伤技能的使用

- [[spell:19236]] —— 这是我们主要的防御技能之一，治疗我们并提升我们的最大生命值，使我们在濒死时能承受更大的伤害。无论何时你预计要承受一次你担心无法存活的巨大伤害，或者仅仅是在生命值降低时，都可以使用它。
- [[spell:586]] / [[spell:373446]] —— 渐隐术，与半透明影像结合后，变成一个短冷却时间的小型减伤。鉴于我们的防御技能总体较弱，在有伤害输出时经常使用它非常重要。许多玩家难以有效利用这一点，尽管这是我们技能库中为数不多的防御技能之一。
- [[spell:193063]] —— 这是我们工具箱中另一个在危险时刻前提供减伤的选择。由于它在我们团本爆发循环中的使用，你很可能在大多数高伤害时刻已经激活了它，但在大秘境中可能需要多加考虑。请注意，对另一个目标施放 [[spell:2061]] 会通过 [[spell:368275]] 为你自己提供减伤。

5.7.

#### 圣光涌动的决策

由于 [[spell:109186]] 只减少 [[spell:2061]] 50%的法力消耗，所以会出现你不想使用触发效果的情况。如果 快速治疗 的治疗以及该施放附带的 [[spell:81749]] 的后续治疗都严重过量治疗，那么不消耗触发效果以节省法力可能更好。这高度取决于你的法力消耗和当时的治疗需求，但要注意不要在没有先考虑该施放的有效性的情况下就立即使用每一个圣光涌动触发。

5.8.

#### 能量灌注

由于大多数天赋构建都包含 [[spell:373466]]，该技能在对盟友施放时会给予你 [[spell:10060]]，所以你绝不要对自己施放这个技能。虽然在某些小众情况下你可能想在大秘境的高压治疗检查中对自己使用 能量灌注，但 **绝大多数** 情况下，你的施放应该与DPS玩家的冷却技能对齐，以帮助最大化他们的伤害输出。

5.9.

#### 救赎

- 虽然我们通过造成伤害来产生治疗，但其计算方式并不简单。例如，增加我们伤害和治疗的东西（例如，全能）将会 **非** 双重加成。这是因为此类增益只有治疗部分会修正救赎。
- 降低我们造成伤害的机制不会影响救赎的治疗效果。例如，一些团队副本首领有受到伤害降低99%的阶段；戒律牧师造成的伤害仍会通过救赎全额治疗。话虽如此，免疫效果会完全阻止我们的伤害，这也意味着阻止了我们的救赎治疗。
- 增加我们造成伤害的外部增益也不会影响我们的救赎治疗。只有一个外部增益会影响救赎治疗——来自恶魔猎手的 [[spell:255260]]。
- 一旦救赎施加到友方目标身上，治疗生效的范围就非常远。你很少会遇到你的救赎超出范围的战斗场地，除非战斗机制将你和目标分隔开。
- 伤害饰品和种族技能不会通过救赎产生治疗（除非它们增加我们基础技能的伤害）。
- AOE伤害效果，例如 [[spell:132157]] 和 [[spell:373427]] 会通过救赎产生治疗，但仅在第一次伤害判定时生效。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月17日：** 修复了福音序列格式并添加了团队副本Boss信息。
- **2026年8月11日：** 各种格式修复。
- **2026年8月10日：** 针对第二赛季发布进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月20日：** 修复了小的格式问题，并调整了一些高级部分的顺序。
- **2026年5月4日：** 为一些高级主题添加了章节。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月26日：** 套装bug修复后修正了爆发输出循环序列。
- **2026年3月16日：** 已为第1赛季发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月10日：** 修复了 神谕者 输出循环中套装复选框的问题。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 添加了战斗助手信息。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年4月3日：** 小幅错别字修复。
- **2025年4月2日：** 格式修复。
- **2025年4月1日：** 添加了更多关于大秘境中 神谕者 的信息。
- **2025年3月24日：** 添加了描述如何根据首领伤害模式调整你的输出窗口的部分。
- **2025年3月16日：** 更新了输出循环以反映福祸技能队列交互的移除。
- **2025 年 3 月 2 日：** 修复了格式问题。
- **2025年3月1日：** 近期平衡调整后进行了更新。
- **2025年2月25日：** 修复了 神谕者 输出循环中的小错别字。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 更新了终极忏悔使用部分。
- **2024年9月10日：** 为 神谕者 添加了命运编织者输出循环切换。
- **2024年9月9日：** 为第一赛季发布进行了更新。
- **2024年8月22日：** 重新格式化页面以便于阅读。
- **2024年8月21日：** 为地心之战发布进行了更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月27日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月11日：** 修复了小的循环问题。
- **2023年11月7日：** 添加了额外的说明。
- **2023年11月7日：** 为10.2补丁更新了页面。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月10日：** 更新了输出循环以反映狂想曲的热修。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了审查。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月22日：** 更新了输出循环以反映10.0.5的改动和天赋变动。
- **2022年12月11日：** 重新格式化页面以利用配装切换功能。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在这个页面上，你将找到魔兽世界12.1.5版本中你的 戒律 牧师 的最佳装备、饰品和毕业（BiS）物品推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们应有尽有！

1.

### 戒律 牧师 毕业装备指南

欢迎来到我们的 戒律 牧师 装备与毕业页面。查看此页面，了解关于为 戒律 牧师 配装所需知道的一切，包括来自所有来源的毕业装备、团队副本和大秘境、最佳饰品、套装等信息。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

1.

### 英雄天赋

### 虚空编织者

### 总体

此列表包含 戒律 牧师 在 至暗之夜 第2赛季的毕业装备。请记住，还有许多其他装备与这里提供的装备在误差范围内相当，并且包含任何三级属性可能会打乱整个推荐，但这个列表是你应该寻找什么的良好起点/目标。

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，催化剂将保留你催化物品的属性和效果。我们在下面列出了每个部位最值得催化的物品：

- 头部：[[item:271874@JAAEAAgNyQWN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 肩部：[[item:268241@JAACAAAG2A]]，来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 胸部：[[item:251139@JAACAAAG2A]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 手部：[[item:268243@JAACAAgNyA]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 腿部：[[item:271554@JAACAAAG2A]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

:::

:::details 常见问题：我早期应该从我的宝库拿什么？
随着第2赛季的开始，

[混沌虚空核心](<https://www.wowhead.com/currency=3418>)

现在可以代替一件装备从你的宝库中领取（赛季第一周除外）。此外，在团队副本中将这些额外次数花在英雄难度首领身上，会为你提供升级轨道上1/6的史诗级物品。此外，团队副本的最终首领掉落3件极其强大的特殊物品，包括一件武器，因为这些首领是布甲治疗的唯一掉落来源。因此，建议是在你能领取的前3周从宝库领取额外次数，并在英雄难度对最终首领使用额外次数，直到你拥有全部3件物品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:239649@JAACAAQ0wA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双子毒牙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAACAAQ0wA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>副手</th><td>[[item:159667]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含仅由大秘境中可获取的装备组成的毕业装备配置。

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，催化剂将保留你催化物品的属性和效果。我们在下面列出了每个部位最值得催化的物品：

- 头部：[[item:251232@JAAEAAgNyQWN]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 肩部：[[item:239031@JAACAAAG2A]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸部：[[item:251139@JAACAAAG2A]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 手部：来自的[[item:159247@JAACAAgNyA]] [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 腿部：[[item:251160@JAACAAAG2A]] 来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

:::

:::details 常见问题：我早期应该从我的宝库拿什么？
以下是早期应该优先刷以获得良好即时升级的地下城列表：

- 夺目谷 让你能够获得 [[item:250214]]，这是地下城中你比较有价值的饰品选择之一。
- 密谋小径 让你能够获得另一个不错的饰品 [[item:250215]]，以及一些其他不错的装备，比如一件高急速的胸甲，这是早期非常棒的催化剂目标。
- 任何掉落武器的地下城都是高优先级。武器上的具体属性远不如仅仅获得一把装等更高的武器来让你过渡，直到你通过推荐的额外次数策略获得史诗级匕首。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:251232@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>项链</th><td>[[item:251173@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>腰部</th><td>[[item:193691@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>脚部</th><td>[[item:251219@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>护腕</th><td>[[item:251127@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:159636@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

此列表包含由第2赛季团队副本装备组成的毕业装备配置。

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，催化剂将保留你催化物品的属性和效果。我们在下面列出了每个部位最值得催化的物品：

- 头部：[[item:271874@JAAEAAgNyQWN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 肩部：[[item:268241@JAACAAAG2A]]，来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 胸部：来自[[item:271558@JAAEAAAG2wYN]] [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 手部：[[item:268243@JAACAAgNyA]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 腿部：[[item:271554@JAACAAAG2A]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

:::

:::details 常见问题：我最想要哪些团队副本物品？
以下是从团队副本中需要优先获取的最重要物品列表：

- [[item:271092@JAACAAAG2A]]：我们的毕业武器。此物品掉落自 乌拉特克。你可以在赛季早期通过使用大宝库获得的代币，在英雄难度对 乌拉特克 使用额外次数来以史诗装等获得它。
- [[item:271874@JAACAAAG2A]]：一顶极其强大的特殊头部装备，同样掉落自 乌拉特克。你可以在赛季早期通过使用大宝库获得的代币，在英雄难度对 乌拉特克 使用额外次数来以史诗装等获得它。
- [[item:268265@JAACAAAG2A]]：一件极其强大的特殊项链，掉落自 乌拉特克。你可以在赛季早期通过使用大宝库获得的代币，在英雄难度对 乌拉特克 使用额外次数来以史诗装等获得它。
- [[item:270162]]：一件非常强大的治疗饰品，掉落自团队副本的第一个首领。
- [[item:270167]]：另一件非常强大的饰品，掉落自巢穴首领 [尼姆瑞莎·唤波者](<https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双子毒牙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></div></td></tr><tr><th>护腕</th><td>[[item:268228@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>副手</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

### 神谕者

### 总体

此列表包含 戒律 牧师 在 至暗之夜 第2赛季的毕业装备。请记住，还有许多其他装备与这里提供的装备在误差范围内相当，并且包含任何三级属性可能会打乱整个推荐，但这个列表是你应该寻找什么的良好起点/目标。

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，催化剂将保留你催化物品的属性和效果。我们在下面列出了每个部位最值得催化的物品：

- 头部：[[item:271874@JAACAAAG2A]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 肩部：[[item:268241@JAACAAgNyA]] 来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 胸甲：来自的[[item:251139@JAACAAgNyA]] [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 手部：[[item:268243@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 腿部：来自的 [[item:281235@JAACAAgNyA]] [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

:::

:::details 常见问题：我早期应该从我的宝库拿什么？
随着第2赛季的开始，

[混沌虚空核心](<https://www.wowhead.com/currency=3418>)

现在可以代替一件装备从你的宝库中领取（赛季第一周除外）。此外，在团队副本中将这些额外次数花在英雄难度首领身上，会为你提供升级轨道上1/6的史诗级物品。此外，团队副本的最终首领掉落3件极其强大的特殊物品，包括一件武器，因为这些首领是布甲治疗的唯一掉落来源。因此，建议是在你能领取的前3周从宝库领取额外次数，并在英雄难度对最终首领使用额外次数，直到你拥有全部3件物品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:239649@JAACAAQ0wA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双子毒牙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:281235@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAACAAQ0wA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>副手</th><td>[[item:159667]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含仅由大秘境中可获取的装备组成的毕业装备配置。

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，催化剂将保留你催化物品的属性和效果。我们在下面列出了每个部位最值得催化的物品：

- 头部：[[item:251232@JAAEAAgNyQWN]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 肩部：[[item:239031@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸甲：来自的[[item:251139@JAACAAgNyA]] [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 手部：来自的[[item:159247@JAACAAgNyA]] [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 腿部：[[item:251160@JAACAAgNyA]] 来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

:::

:::details 常见问题：我应该刷哪些地下城？
以下是早期应该优先刷以获得良好即时升级的地下城列表：

- 夺目谷 让你能够获得 [[item:250214]]，这是地下城中你比较有价值的饰品选择之一。
- 密谋小径 让你能够获得另一个不错的饰品 [[item:250215]]，以及一些其他不错的装备，比如一件高急速的胸甲，这是早期非常棒的催化剂目标。
- 任何掉落武器的地下城都是高优先级。武器上的具体属性远不如仅仅获得一把装等更高的武器来让你过渡，直到你通过推荐的额外次数策略获得史诗级匕首。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:251232@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>项链</th><td>[[item:251173@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>腰部</th><td>[[item:193691@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>脚部</th><td>[[item:251219@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>护腕</th><td>[[item:251127@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:159636@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

此列表包含由第1赛季团队副本装备组成的毕业装备配置。

:::details 常见问题我需要哪些套装部件？
在 至暗之夜 第2赛季中，催化剂将保留你催化物品的属性和效果。我们在下面列出了每个部位最值得催化的物品：

- 头部：[[item:271874@JAACAAAG2A]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 肩部：[[item:268241@JAACAAgNyA]] 来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 胸甲：来自的[[item:271558@JAACAAgNyA]] [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 手部：[[item:268243@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- 腿部：来自的 [[item:281235@JAACAAgNyA]] [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

:::

:::details 常见问题：我早期应该从我的宝库拿什么？
以下是从团队副本中需要优先获取的最重要物品列表：

- [[item:271092@JAACAAAG2A]]：我们的毕业武器。此物品掉落自 乌拉特克。你可以在赛季早期通过使用大宝库获得的代币，在英雄难度对 乌拉特克 使用额外次数来以史诗装等获得它。
- [[item:271874@JAACAAAG2A]]：一顶极其强大的特殊头部装备，同样掉落自 乌拉特克。你可以在赛季早期通过使用大宝库获得的代币，在英雄难度对 乌拉特克 使用额外次数来以史诗装等获得它。
- [[item:268265@JAACAAAG2A]]：一件极其强大的特殊项链，掉落自 乌拉特克。你可以在赛季早期通过使用大宝库获得的代币，在英雄难度对 乌拉特克 使用额外次数来以史诗装等获得它。
- [[item:270162]]：一件非常强大的治疗饰品，掉落自团队副本的第一个首领。
- [[item:270167]]：另一件非常强大的饰品，掉落自巢穴首领 [尼姆瑞莎·唤波者](<https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双子毒牙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:281235@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></div></td></tr><tr><th>护腕</th><td>[[item:268228@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>副手</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 戒律 牧师 饰品推荐

虽然有大量饰品可供选择，但以下是 戒律 牧师 需要优先获取的最高优先级选项。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **戒律 牧师 饰品**
**使用型 -**

[[item:270162]]

**被动 -**

[[item:270167]]

:::

想看看你拥有的饰品排名如何？请查看下面的完整图表！

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 戒律 牧师 饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270167]]</li>&#10;<li>[[item:270162]]</li>&#10;<li>[[item:280835]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270169]] - 这个饰品非常强，可以与前两个饰品竞争，但仅限于其可能的提升装等时。在相同装等下，另外两个将会领先。&#10;     </li>&#10;<li>[[item:281215]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:251792]]</li>&#10;<li>[[item:248583@JAACAAgMyA]] （设置为急速）</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270603]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:249343]]</li>&#10;<li>[[item:249341]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250256]]</li>&#10;<li>[[item:250215]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250248]]</li>&#10;<li>[[item:268292]]</li>&#10;<li>[[item:250255]]</li>&#10;<li>[[item:250254@JAACAAgNyA]]</li>&#10;<li>[[item:193718@JAAIAAQkCYHKvbRLfA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250224]]</li>&#10;<li>[[item:270161]]</li>&#10;<li>[[item:270170]]</li>&#10;<li>[[item:273794]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:158368]]</li>&#10;<li>[[item:270171]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

:::details 常见问题：饰品的伤害对 [[spell:81749]] 有效吗？
无效。外部伤害效果（饰品/种族技能/附魔/美化等）不提供任何治疗收益。

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>)可以用来对团队副本首领或地下城的额外掉落进行额外次数抽取。从赛季后期开始，你每周会收到两个。对团队副本首领或特定地下城的掉落表进行额外次数抽取将消耗一个。你将从使用地点获得的物品是随机的，但一旦你从该掉落表中获得了特定物品，你就不会再获得它。因此，可能需要几周/几次尝试才能获得你想要的特定物品，但只要有足够的尝试，你最终是保证会获得它的。

虽然直接购买 [朦胧虚空核心](<https://www.wowhead.com/currency=3418>) 的能力将一直锁定到赛季后期，但你将有能力通过你的 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>).

4.1.

#### 戒律 牧师 推荐的虚无虚空核心使用方法

在第2赛季中，对英雄难度团队副本首领使用额外次数将提供升级轨道上1/6的史诗物品，而不是英雄物品。这意味着你可以早期获得强大物品，而这些首领在史诗难度下通常极难击杀。具体来说，团队副本的最终首领有3件强大的特殊物品，构成了布甲治疗的整个掉落表。其中一件是主手武器。因此，我们建议在赛季前3个宝库领取虚无虚空核心，并使用它们在英雄难度对团队副本的最终首领进行额外次数抽取，直到你拥有全部3件物品。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 史诗 [[item:271092]]
2. 史诗 [[item:271874]]
3. 史诗 [[item:268265]]
4. 毕业列表中的任何剩余物品。

:::

1.

### 晋升毒液石

使用你的 [[item:280562]] 时，你应该优先考虑你的武器，因为它们是你的最高预算选择。请记住，如果你已经从史诗 乌拉特克 获得了344装等的匕首或项链，你无法进一步升级它们，但你可能从英雄难度额外次数抽取的任何普通史诗轨道版本都可以升级。以下是你的一般优先顺序：

1. 主手武器
2. 副手
3. 饰品
4. 项链
5.

### 戒律牧师的制造装备与强化

由于赛季初期你的制造能力在很大程度上受到火花获取和高阶纹章获取的时间限制，你需要确保早期制造的物品具有高价值。因为我们会通过额外拾取来获取一件史诗级附魔武器的主手武器，所以在大多数情况下我们不希望制造武器。因此，你的一般优先顺序如下：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **戒律制造装备优先级**
- [[item:245769@JAAKAAwt1wgNRDTWiscN]]搭配[[item:273060]]
- 任何你尚未获得史诗级品质的高价值部位，附上[[item:240167]]。
- 任何你尚未获得史诗级品质的物品

:::

请注意，虽然这样做会浪费火花，但如果你在早期的额外拾取策略中运气不佳，在前一两次拾取中没有获得史诗级附魔武器，你也可以制造一件主手武器作为临时过渡。纹章方面没有问题，因为当你最终获得那把附魔匕首时，它会自动抵扣你花费的火花成本，你只是浪费了2个火花。是否这样做在很大程度上取决于你的具体情况以及你通过额外拾取获得物品的顺序。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

6.1.

#### 戒律牧师的最佳强化

强化是特殊效果，要么默认存在于制造装备上，要么可以在制造过程中添加到制造装备上。一个角色可以同时 **装备两个** 任何时候装备的美化。

我们目前推荐为你的最终毕业配置制造以下两种强化：

- 在配装过程中，将[[item:273060]]用在任何主手或副手制造装备上。
- 将[[item:240167]]用在2件不同的物品上。初期你可以将其用在任何接受该强化的制造装备上，但最终毕业配置会将其放在护腕和披风等低价值部位。

6.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

在赛季初期，当你获取纹章的渠道有限时，例如
[秘境雾崖](<https://www.wowhead.com/currency=3446>)，高效使用它们非常重要。这将使你尽可能优化赛季初期的战斗力。以下是各部位战斗力预算的总体优先级列表，应当作为使用纹章升级的优先目标。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **戒律牧师纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**戒指/项链**

➜

**肩部/手套/腰带/靴子**

:::

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 针对12.1.5补丁发布进行了更新。
- **2026年8月18日：** 根据最近仪式石的削弱更新了装饰建议。
- **2026年8月16日：** 根据最近的饰品平衡调整调整了饰品建议。
- **2026年8月11日：** 各种格式和拼写错误修复。
- **2026年8月10日：** 针对第二赛季发布进行了更新。
- **2026年6月15日：** 更新了12.0.7孢子坠落装备。
- **2026年5月20日：** 修复了BiS列表中物品的视觉着色问题。
- **2026年4月22日：** 根据最近的职业平衡调整更新了装饰和BiS列表建议。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月26日：** 热修后更新了饰品推荐。
- **2026年3月21日：** 根据来自正式服务器的更优数据更新了饰品推荐。
- **2026年3月16日：** 凝视削弱后更新了饰品推荐。
- **2026年3月16日：** 已为第1赛季发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 添加了迪纳尔部分。
- **2025年8月14日：** 更新页面以包含纳克西斯之王指令饰品信息。
- **2025年8月10日：** 添加了遗漏的饰品并更新了专业制造推荐。
- **2025年8月4日：** 为第三赛季发布进行了更新。
- **2025年6月17日：** 更新了D.I.S.C推荐。
- **2025年6月15日：** 添加了D.I.S.C腰带的信息。
- **2025年5月12日：** 更新了令人费解的Cartel Chip部分。
- **2025年4月21日：** 为11.1.5添加了令人费解的Cartel Chip部分。
- **2025年3月24日：** 饰品平衡调整后进行了更新。
- **2025年3月1日：** 根据近期平衡调整更新了头环推荐。
- **2025年2月25日：** 修复了页面上失效的链接。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月17日：** 根据进一步的理论研究更新了塞尔希的头环信息。
- **2024年12月16日：** 塞尔希的头环加强后进行了更新。
- **2024年12月15日：** 添加了塞尔希的头环部分。
- **2024年10月21日：** 添加了讨论使用型饰品使用的部分。
- **2024年9月9日：** 为第一赛季发布更新了页面。
- **2024年8月22日：** 平衡调整后更新了美化装备。
- **2024年8月21日：** 为地心之战发布进行了更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。

显示更多

显示更少

:::

## 属性优先级

在本页面中，你将找到戒律牧师的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法相互作用。我们的内容已针对《魔兽世界》12.1.5版本更新。

1.

### 戒律牧师属性优先级

我们所有的副属性在价值上都非常接近。由于装备上智力的缩放以及副属性价值的接近程度，在配装方面，追求尽可能高的物品等级是推荐的玩法。

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者属性优先级

属性优先级如下 **在同等物品等级装备之间做选择时**.

急速（直到1800等级）

精通

暴击

全能

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者属性优先级

属性优先级如下 **在同等物品等级装备之间做选择时**.

急速

精通

暴击

全能

对于神谕者，我们所有的属性在价值上都相当接近，所以你应该避免将任何单一属性堆叠到收益递减临界点以上。

1.

### 深入属性解析

**智力** 是你的主属性。确保你穿戴的所有装备（饰品和珠宝除外）都带有智力，因为每一点智力都会提升你伤害和治疗的效果。

**急速** 减少你的法术施法时间，降低[[spell:17]]、[[spell:8092]]和[[spell:47540]]的冷却时间，减少你的全局冷却时间等等。此外，它还增加你的[[spell:34433]]/[[spell:123040]]可以进行的攻击次数，以及[[spell:589]]的跳数。

**精通** （[[spell:271534]]）提升你对救赎目标的治疗量。请注意，此 **确实** 适用于你的救赎治疗，而不仅仅是你的直接治疗。

**暴击** 使你的伤害法术和治疗法术有几率使其效果翻倍。也就是说，值得注意的是，它不会在[[spell:81749]]治疗上产生双重加成（救赎治疗无法暴击；它们只治疗造成的伤害量，而这部分是唯一可以暴击的部分）。

**全能** 是简单的伤害和治疗量提升。此外，它还提供少量的受到伤害降低效果。

**吸血** 根据你造成的伤害和治疗事件为你提供自我治疗。这种免费的自我恢复可以减少在大规模伤害事件中你和其他治疗者需要花在治疗你身上的法力值和全局冷却时间，让你能更专注于需要治疗的人。由于这是一个三级属性而非二级属性，它不会经常出现，但出现时依然强大。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对第二赛季发布进行了更新。
- **2026年7月15日：** 更新了属性建议。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月4日：** 更新了属性优先级，以反映进一步的序列优化。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为第一赛季发布进行了审查。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月24日：** 戒律 削弱后进行了更新。
- **2025年3月1日：** 根据近期平衡调整进行了更新。
- **2025 年 2 月 24 日：** 进入11.1后略微更新了属性优先级。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战发布进行了更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月27日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月21日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面中，我们列出了你的戒律牧师可以获取的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

在至暗之夜中，你将有两类宝石可供选择：稀有或史诗。稀有宝石要么是单个属性，要么是两种副属性的组合。史诗宝石要强大得多，但你的整个角色一次只能使用一个。

宝石可以通过来自宝库的[[item:275707]]物品镶嵌到头盔、护腕或腰带上。

你应该首先使用一个[[item:240983]]。这提供大量的主属性。之后，所有剩余的插槽都应使用[[item:240892]]。

1.

### 最佳附魔和武器强化

只要有可能，你应该使用[[item:243733]]作为你的武器油。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244003]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240155]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 药剂

关于药剂，你应该使用[[item:241325]]。

3.2.

#### 药水

作为通用推荐，[[item:241308]]是你的最佳选择。然而，当你以 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者身份游玩时，[[item:241288]]是一个有效的替代选择。鲁莽可以在单个爆发窗口内给你更多总输出，但使用时需要小心，因为它不能与[[spell:10060]]或嗜血/英勇窗口同时使用，否则你很容易达到急速过高导致该属性严重贬值的水平。因此，对于虚空编织者 specifically，如果你想要一个独立于现有爆发技能之外的额外冷却技能，鲁莽是你的最佳选择；如果你想将其与现有爆发窗口叠加，圣光潜力是你的最佳选择。

关于法力药水，如果你要使用一瓶的话，应该是[[item:241294]]。然而，战斗药水的强度意味着你应该 **绝不** 使用法力药水。

关于治疗药水，使用[[item:271883]]。

3.3.

#### 食物

对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者，你应该在可用时使用[[item:275265]]或[[item:275266]]（或[[item:275258]]作为个人食物替代品）。

对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者，你应该在可用时使用[[item:255845]]或[[item:255846]]（或[[item:242275]]作为个人食物替代品）。

3.4.

#### 强化符文

你应该尽可能使用[[item:259085]]。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月16日：** 用新的盘绕岛食物替换了虚空编织者食物建议
- **2026年8月10日：** 针对第二赛季发布进行了更新。
- **2026年7月15日：** 更新了附魔/宝石建议。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月20日：** 更新了页面格式，使其与其他指南更加一致。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月26日：** 更新了武器附魔推荐。
- **2026年3月24日：** 热修后移除了关于茶的提及。
- **2026年3月16日：** 为第一赛季发布进行了更新。
- **2026年3月2日：** 修复了食物推荐错误。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 添加了腐蚀附魔部分。
- **2025年3月1日：** 近期平衡调整后进行了更新。
- **2025 年 2 月 24 日：** 更换了武器附魔/为 神谕者 添加了替代消耗品。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 更新了食物和宝石推荐。
- **2024年8月26日：** 更换了胸甲附魔推荐。
- **2024年8月21日：** 为地心之战发布进行了更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月27日：** 为10.2.6补丁进行了审查并更新了食物推荐。
- **2024年1月16日：** 调整了梦境虔诚附魔的措辞。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月11日：** 修复了治疗药水的提及。
- **2023年11月6日：** 添加了关于10.2版本新武器附魔和头盔附魔的说明。
- **2023年9月4日：** 针对10.1.7补丁进行了审查。
- **2023 年 7 月 11 日：** 更新了永恒印记推荐部分。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月6日：** 根据热修/调整更新了附魔和药水推荐。
- **2023年5月1日：** 热修后更新了原初石推荐。
- **2023年3月21日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5版本中使用你的戒律牧师挑战大秘境地下城的技巧和建议。

1.

### 戒律牧师在至暗之夜第2赛季大秘境中的表现

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者大秘境构建

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者大秘境天赋

这个构建是你大秘境内容的主要构建。该构建专注于通过[[spell:81749]]冷却施放[[spell:47540]]以获得治疗量，同时提供[[spell:1253593]]的触发效果。同时拥有[[spell:238135]]和[[spell:390786]]来强化护盾，使虚空之盾每次施放都成为一个强大的技能。这使得该构建能够通过苦修目标选择、虚空之盾目标选择、基础真言术：盾以及[[spell:186263]]，让你对治疗的去向有高度控制。

**请务必使用"导出天赋"按钮将此构建直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGgZA"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAacoqq9lskFGadhNQwwxBi4IJ6E-AAAA-CEMYkow0AUgscA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者大秘境构建

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者大秘境天赋

这个构建是大秘境内容的替代构建。在你能够非常频繁使用的每个[[spell:447444]]窗口中提供非常强大的输出。此外，你仍然点出了永恒屏障，所以你的虚空之盾每次施放仍然提供可观的输出。这个构建最大的弱点是机动性，因为你需要花费大量时间施放[[spell:450405]]。

**请务必使用"导出天赋"按钮将此构建直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CAQAAAAAAAAAAAAAAAAAAAAAAADsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgZYZGMzMzwYmBbmmJGMzAAAMbz2CYsZAAYMzMjBzgZGMCmB"
}
```
:::

:::details 来源计算器编码
```
#AE-BUWZJLBace268EVZbdPUUqQNYYkkMNPFKsA-bcdeAaoqq9ls8AlFGiF8SckMQYYgwAK-AAAA-FIikwAMUY8wSgC-
```

:::

1.

### 大秘境深度输出循环提示

由于[[spell:1253593]]无论使用哪种构建都是我们总输出的重要组成部分，加上我们的新套装在每次[[spell:47540]]施放时为[[spell:8092]]提供冷却缩减，冷却好了就施放苦修绝对至关重要。

虽然你需要利用[[spell:186263]]来协助处理单体点刷治疗需求，但在你本可以更长时间依赖核心法术的情况下过早切换到刷暗影恢复，是戒律牧师在大秘境中遇到法力值问题的最大原因之一。在开始刷暗影恢复之前，尽量先循环使用你其他可用的法术以及你的两个[[spell:33206]]充能。

1.

### 功能技能与能力

### 打断、昏迷和控制

4.1.

#### 打断、昏迷和阻止

戒律牧师没有打断能力，就像大多数治疗者一样。

[[spell:8122]]赋予我们恐惧一群敌人的能力。这是我们唯一的群体控制手段，因此利用它来打断或干扰大群敌人使其具有极高的价值。

[[spell:9484]]提供了一个潜在的单体控制。始终留意亡灵/异种生物敌人来使用这个控制技能。

[[spell:205364]]赋予我们短时间内控制一个敌人的能力。在大多数情况下，这不会提供显著的价值，但过去曾有过地下城或团队副本敌人拥有极其强大的法术，我们可以通过使用这些能力来施放它们。

### 其他功能

4.2.

#### 其他功能

[[spell:528]]允许我们驱散敌人目标身上的增益效果和效果。在许多情况下这很有价值，因为各种敌人身上的增益效果可以通过增加伤害使他们更具威胁性，或通过减少伤害使他们更难被击杀。

[[spell:390632]]将我们的默认魔法驱散改为同时移除疾病效果。这有多大用处很大程度上取决于你正在进行的内容，但在有疾病效果施加在盟友身上的情况下，这种功能可以具有巨大的价值。

[[spell:32375]]可能是我们最强大的功能之一。一次施放就能从一整队盟友或一群敌人身上移除魔法减益效果的能力极其强大。多年来，地下城和团队副本中的许多机制都被这个法术简化了，未来很可能也会如此。

[[spell:10060]]是我们天赋树中可用的一个极其强大的法术。这个技能允许我们以两分钟的冷却时间为一名玩家提供显著的急速增益，最常用于盟友DPS玩家，特别是在考虑[[spell:373466]]的情况下。

[[spell:21562]]虽然不是最有趣的功能，但在许多情况下非常有价值。始终保持你的团队身上有这个增益效果。

1.

### 地下城专属技巧

本节专注于牧师专属的技巧和提示，以帮助应对特定地下城的首领和小怪。

### 天赋选择速查表

要快速了解使用哪些天赋，请查看下表中的地下城和词缀，并查看你应该确保加入构建的建议功能天赋列表。你也可以使用
[大秘境功能](<https://www.curseforge.com/wow/addons/mythic-plus-utility-mpu>)
插件来提醒你切换到各种天赋。

一旦第2赛季正式开始，我们将更新本节，加入针对小怪机制和首领的具体技巧，以及作为戒律牧师如何最好地应对它们。请稍后再来查看！

<table>&#10;<tr>&#10;<th>地下城</th>&#10;<th>词缀</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=148" rel="noopener noreferrer">萨拉塔斯的交易：扬升</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=158" rel="noopener noreferrer">萨拉塔斯的交易：虚缚</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=162" rel="noopener noreferrer">萨拉塔斯的交易：脉冲</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=160" rel="noopener noreferrer">萨拉塔斯的交易：吞噬</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></td>&#10;<td></td>&#10;</tr>&#10;</table>

基于以上选择，你应该使用以下职业天赋：

![Improved Purify not Talented](<https://static.icy-veins.com/images/wow/classes/priest/purify_disease.jpg>)**适用条件：萨拉塔斯的交易：吞噬（未启用）；毒牙祭坛（未启用）；诸王之眠（未启用）。**

![Improved Purify Talented](<https://static.icy-veins.com/images/wow/classes/priest/purify_disease.jpg>)**适用条件：萨拉塔斯的交易：吞噬（启用）；毒牙祭坛（启用）；诸王之眠（启用）。**

![Mass Dispel not Talented](<https://static.icy-veins.com/images/wow/classes/priest/mass_dispel.jpg>)**适用条件：萨拉塔斯的交易：升腾者（未启用）；萨拉塔斯的交易：吞噬（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；密谋小径（未启用）；红玉新生法池（未启用）；塞塔里斯神庙（未启用）。**

![Mass Dispel Talented](<https://static.icy-veins.com/images/wow/classes/priest/mass_dispel.jpg>)**适用条件：萨拉塔斯的交易：升腾者（启用）；萨拉塔斯的交易：吞噬（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；红玉新生法池（启用）；塞塔里斯神庙（启用）。**

![Phantasm not Talented](<https://static.icy-veins.com/images/wow/classes/priest/phantasm.jpg>)**适用条件：萨拉塔斯的交易：吞噬（未启用）；毒牙祭坛（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；红玉新生法池（未启用）；致盲之谷（未启用）；虚空之痕竞技场（未启用）。**

![Phantasm Talented](<https://static.icy-veins.com/images/wow/classes/priest/phantasm.jpg>)**适用条件：萨拉塔斯的交易：吞噬（启用）；毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）；致盲之谷（启用）；虚空之痕竞技场（启用）。**

- **适用条件：萨拉塔斯的交易：吞噬（启用）；毒牙祭坛（启用）；诸王之眠（启用）。** [[spell:390632]]
- **适用条件：萨拉塔斯的交易：升腾者（启用）；萨拉塔斯的交易：吞噬（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；红玉新生法池（启用）；塞塔里斯神庙（启用）。** [[spell:32375]]
- **适用条件：萨拉塔斯的交易：吞噬（启用）；毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）；致盲之谷（启用）；虚空之痕竞技场（启用）。** [[spell:108942]]
- **适用条件：萨拉塔斯的交易：虚空束缚（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者以获得[[spell:451840]]
- **适用条件：萨拉塔斯的交易：吞噬（未启用）；萨拉塔斯的交易：虚空束缚（未启用）；萨拉塔斯的交易：升腾者（未启用）；毒牙祭坛（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；密谋小径（未启用）；红玉新生法池（未启用）；塞塔里斯神庙（未启用）；致盲之谷（未启用）；虚空之痕竞技场（未启用）。** 没有特定的天赋建议。

5.1.

#### 拉维

- 技巧即将添加！

5.2.

#### 扭缠盘蛇

- 技巧即将添加！

5.3.

#### 祖尔加

- 技巧即将添加！

5.4.

#### 小怪

- 技巧即将添加！

5.5.

#### 囤宝狂人

- 技巧即将添加！

5.6.

#### 寒冬哨兵

- 技巧即将添加！

5.7.

#### 纳洛拉克

- 技巧即将添加！

5.8.

#### 小怪

- 技巧即将添加！

5.9.

#### 黄金风蛇

- 技巧即将添加！

5.10.

#### 殓尸者姆沁巴

- 技巧即将添加！

5.11.

#### 部族议会

- 技巧即将添加！

5.12.

#### 始皇达萨

- 技巧即将添加！

5.13.

#### 小怪

- 技巧即将添加！

5.14.

#### 凯斯媞亚·魔力之心

- 技巧即将添加！

5.15.

#### 赞恩·刃悲

- 技巧即将添加！

5.16.

#### 歼灭者萨祖克斯

- 技巧即将添加！

5.17.

#### 利希尔·烬怒

- 技巧即将添加！

5.18.

#### 小怪

- 技巧即将添加！

5.19.

#### 梅莉杜莎·寒妆

- 技巧即将添加！

5.20.

#### 柯姬雅·焰蹄

- 技巧即将添加！

5.21.

#### 基拉卡与厄克哈特·风脉

- 技巧即将添加！

5.22.

#### 小怪

- 技巧即将添加！

5.23.

#### 阿德里斯和阿斯匹克斯

- 技巧即将添加！

5.24.

#### 米利克萨

- 技巧即将添加！

5.25.

#### 加瓦兹特

- 技巧即将添加！

5.26.

#### 塞塔里斯的化身

- 技巧即将添加！

5.27.

#### 小怪

- 技巧即将添加！

5.28.

#### 光明众花

- 技巧即将添加！

5.29.

#### 圣光猎手伊库兹

- 技巧即将添加！

5.30.

#### 护光者鲁伊亚

- 技巧即将添加！

5.31.

#### 兹欧凯特

- 技巧即将添加！

5.32.

#### 小怪

- 技巧即将添加！

5.33.

#### 塔兹拉尔

- 技巧即将添加！

5.34.

#### 阿特洛苏斯

- 技巧即将添加！

5.35.

#### 煞戎努斯

- 技巧即将添加！

5.36.

#### 小怪

- 技巧即将添加！

5.37.

#### 大秘境配装

你可能会看到戒律牧师在团队副本内容和大秘境内容配装之间的主要区别是，通常情况下，戒律玩家可能会更倾向于优先考虑全能作为副属性，因为它提供伤害减免。

这确实是以一些HPS为代价的，因为全能是我们对实际治疗贡献最差的属性。这主要只在非常高层的大秘境中相关，我们不建议在绝大多数情况下模仿这种做法。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对第二赛季发布进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月21日：** 即将到来的职业平衡调整后更新了天赋推荐。
- **2026年3月16日：** 已为第1赛季发布进行更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 将束缚亡灵更新为束缚恐惧
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月1日：** 根据近期平衡调整进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 移除了一些过时的引用。
- **2024年9月9日：** 为第一赛季发布更新了页面。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月27日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月11日：** 移除了过时的提及。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对10.1.7补丁进行了审查。
- **2023年7月10日：** 更新了10.1.5版本的天赋推荐。
- **2023年5月1日：** 为10.1补丁进行了审查。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月22日：** 更新了10.0.5补丁的天赋推荐。
- **2022年12月11日：** 移除了页面上遗漏的光芒之力提及。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页面中，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5版本中游玩戒律牧师时更加轻松。

1.

### 最佳宏

我们强烈建议将你所有的治疗法术，以及其他可以施放在团队成员身上的法术（例如[[spell:1706]]，用于防止坠落伤害），都整合到鼠标悬停宏中。这些宏将使你更容易对团队成员施放它们。作为创建鼠标悬停宏的替代方案，你可以使用 [Clique](<https://www.curseforge.com/wow/addons/clique>).

下面是一个鼠标悬停宏的示例。只需将 [[spell:17]] 替换为你想使用的法术名称：

#### 通用鼠标悬停宏示例

```wow-macro
#showtooltip 真言术：盾
/cast [target=mouseover,help,nodead][]真言术：盾
```

如果你的鼠标悬停目标是友方目标且未死亡，这将对鼠标悬停目标施放 [[spell:17]]。否则，将对你的当前目标施放。

1.1.

#### 苦修 宏

强烈建议将进攻性与防御性 [[spell:47540]] 组件分开。你可以使用带修饰键的宏，或使用两个独立的绑定键配合 harm/help 修饰键。

**仅对敌方：**

#### 仅进攻性 苦修

```wow-macro
#showtooltip 苦修
/cast [harm] 苦修
```

**仅对友方：**

#### 仅防御性 苦修

```wow-macro
#showtooltip 苦修
/cast [@mouseover,help] 苦修
```

1.2.

#### 无引导宏

由于 [[spell:47540]] 的运作方式，当你在其引导期间尝试排队另一个法术时，可能会意外打断最后一发飞弹。为避免这种情况，请对特定法术应用以下条件，通常是对你影响最大的 [[spell:585]]。这适用于任何法术，而不仅仅是惩击。这里只是以惩击为例。

**注意：目前的建议是故意裁剪 苦修 的引导以获得最佳游戏表现。因此，在这个补丁中你可能不应使用此宏。请查看输出循环页面了解更多信息。**

#### 无引导示例

```wow-macro
#showtooltip 惩击
/cast [nochanneling:penance] 惩击
```

1.3.

#### 天堂之羽 宏

这是一个非常方便的宏，使用 @player 简写在玩家脚下施放 [[spell:121536]]。

#### 天堂之羽 宏

```wow-macro
#showtooltip 天堂之羽
/cast [@player] 天堂之羽
/stopspelltarget
```

1.

### 最佳插件

以下是 戒律 牧师 的一些推荐插件。

2.1.

#### 团队框架的替代选择

Grid2 是我们推荐的团队框架插件，提供大量自定义选项，同时性能极其出色。该插件最大的缺点是入门门槛较高，因为学习起来并不简单，但一旦掌握会非常有成就感。

EllesmereUI 是一个非常受欢迎的完整界面套件，开箱即用就具备扎实的自定义性和性能。该插件还包含自定义团队框架。如果你想要一个几乎无需额外努力的完整界面方案，这是一个非常好的选择，远胜于坚持使用默认界面。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 为苦修无引导宏添加了说明。
- **2026年8月10日：** 针对第二赛季发布进行了更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月20日：** 添加了真言术：工具箱的提及。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为第1赛季发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月16日：** 将Premo宏更新为略微更稳定的版本。
- **2025年3月3日：** 调整了NoChanneling宏。
- **2025 年 2 月 28 日：** 为洞察技能队列宏添加了说明。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 添加了推荐的WeakAura和Grid2配置文件。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战发布进行了审查。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月27日：** 已针对10.2.6版本进行审阅
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月21日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月22日：** 添加了冰冷明晰药水取消光环宏。
- **2022年12月11日：** 更新了光晕/星辰坠落宏以适配斯科夫。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
