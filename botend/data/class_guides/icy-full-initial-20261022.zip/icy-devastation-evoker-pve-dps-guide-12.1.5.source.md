## 专精概览

Welcome to our Devastation Evoker guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Devastation Evoker in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Devastation Mythic+ Resources

[NEW! Top Devastation Talent Builds](<https://raider.io/specs/devastation-evoker/talents>)

[Top Devastation Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/evoker/devastation>)

[Devastation Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=evoker--devastation>)

[Popular Devastation Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=evoker--devastation>)

1.

### Devastation Evoker Overview

[Evokers](<https://www.icy-veins.com/wow/evoker-class-overview-dragonflight>) are a highly mobile ranged DPS with a couple unique aspects. Firstly, we are
limited to a 25 yard range, but this rarely becomes an issue due to having the ability to move while
casting with [[spell:358267]]. Secondly, Evokers have access to the new and unique spell type, Empowered spells; these can
be channeled for an additional period of time before releasing in order to alter what they do.

Powerful and Versatile Damage

Devastation Evoker has a very strong damage profile that excels in every situation except mass AoE, with our greatest strength
coming from being able to take a lot of solid cleave options with relatively low single-target loss,
allowing us to feel like we aren't ruining our priority damage just to pad.

Exceptionally Good Choice for Raid

Devastation Evoker has arguably the best offensive toolkit possible on a ranged caster, having regular access
to casting while moving from using [[spell:358267]], we pretty much always have 100% uptime on our ability to do
maximum damage. The only exception to this is situations where we are forced out of range, but this can almost
always be prevented by preparation beforehand.

A Decent Choice for Dungeons

Devastation Evoker will always be a niche pick for mythic+, our damage profile leads to us wanting
pulls that do not go far beyond 5 targets which they very frequently do in dungeons. Our inability to access
high value extreme AoE damage without enormous cost to our priority makes us great for specific dungeons and
incredibly weak for others.

Solid Utility

Devastation in raid, specifically, has a lot of potent utility [[spell:369459]] providing 3% more healing
as well as acting as a mana battery. [[spell:370665]] with the new [[spell:370888]] allowing you and your
ally to cast while moving for a short period. [[spell:374227]] having a lot more applications in raid encounters,
the new talent [[spell:410352]] allowing you to soak dangerous abilities solo. These do not translate
as to Mythic+ but still have some value. Some of the more Mythic+ specific utilities are abilities
like [[spell:307974]] and [[spell:357214]] which can be used as AoE interrupts.

Great Defensives

Devastation Evoker is essentially unkillable if played well with the new [[spell:410352]] talent.
Between this and [[spell:363916]] any kind of damage coming in a predictable pattern can be made
almost completely irrelevant.

Exceptional Mobility in All Situations

Devastation is a spec with all the mobility you will ever need. Correctly using [[spell:358267]] / [[spell:357210]]
and [[spell:370665]] means you can travel significant distances very quickly, also allowing you to
prevent knockbacks and pushbacks from being a problem.

2.

### Devastation Evoker in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

This patch will introduce 2 new pieces of endgame content, the first being the
new Kith'ix Raid encounter and the other being the addition of the Labyrinth
Mega-Delve. Make sure to check out our dedicated guides linked below.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
a Trinket, Ring, and Gloves. Additionally, you will be able to upgrade items with 
[[item:280562]] starting October 20th. Weapons, Necks, and Trinkets can all 
be upgraded.

2.3.

#### Class Changes

Unfortunately there are no class changes for Devastation Evoker with Patch 12.1.5. 
However, with the launch of 12.1.5, we've also drawn close to the unlocking of [[item:280562]].
These will allow you to upgrade your weapon slots trinket slots and neck slot by 2
upgrades with a few limitations. Check out the gear page for a more in-depth breakdown
of what you will want to upgrade first, as well as how useful the gear from the new
raid will be.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/classicon_evoker_devastation.jpg>) Click for Previous Season 2 Changes
2.4.

#### Recent Class Changes

- [[spell:357211]] damage increased by 10%.
- [[spell:1292322]] damage increased by 25%.
- [[spell:357208]] damage increased by 5%.
- [[spell:362969]] damage increased by 50%.
- [[spell:1265867]] damage increased by 50%.
- [[spell:370452]] damage increased by 10%.

These changes help accomplish 2 things: Making Flameshaper the clear winner on single-target,
and bringing our Apex talent back to level ground with the 1/4 Apex build. This will allow
you to choose either one without any real loss.

:::

### Midnight   Changes Overview

2.5.

#### Midnight Summary for Devastation Evoker

The changes listed below reflect all major changes made to Devastation Evoker for the 
launch of Midnight. For more recent changes, please see the Season 2 tab.

2.6.

#### Core Changes to Devastation Evoker

- [[spell:1265867]] replaces the old Lay Waste node, This causes 
  your [[spell:359073]] to change your next [[spell:362969]]
  into Azure Sweep. Making it deal 75% additional damage and hitting all nearby enemies 
  instead of the regular maximum of three.
- [[spell:370452]] has been reworked
  to deal additional damage for each empower level of [[spell:359073]], but it 
  no longer applies an increased damage taken debuff

2.6.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper

[[spell:443328]] has been replaced by [[spell:444088]] causing your Essence spenders 
        [[spell:356995]] or [[spell:357211]] to a consume some of your [[spell:357208]] duration to deal 
        damage to the target, no longer spreading and cleaving additional enemies.

2.6.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander

The only relevant change to Scalecommander is the new talent [[spell:116297]] in the 
        Devastation tree, this allows you to re-cast your [[spell:357210]] within 18 seconds after 
        the initial cast. This means you will be casting deep breath much more regularly.

2.7.

#### Defensive and Utility Adjustments

- [[spell:374348]] has been changed to act as an upgrade on [[spell:363916]]
          making it heal for the same amount of damage your Obsidian Scales mitigates, this is 30% 
          for Flameshaper or 40% for Scalecommander.
- [[spell:410352]] has been added, making all damage you take while flying in [[spell:357210]] 
          be taken as a damage over time effect over a 10 second period instead.
- [[spell:370888]] has been reworked and now grants you and the target you [[spell:370665]] 100% 
          increased movenet speed and the ability to cast while moving 3 seconds.

3.

### Basics of Devastation Evoker Gameplay

Devastation's playstyle is very fluid, where you will always
be casting something which interacts with your next cast due to various
talents.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_disintegrate.jpg>) **Manage your Essence**  
  
    Devastation's primary resource is Essence which is spent on [[spell:356995]] 
    and [[spell:357211]] you want to make sure you are never sitting at the maximum 
    Essence to avoid losing regeneration time.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_firebreath.jpg>) **Manage your Empowers**  
  
    Empower spells ([[spell:357208]] and [[spell:359073]]) are your 
    short cooldown, high value abilities that you will want to be hitting as 
    soon as they are ready in nearly every situation.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_essenceburst.jpg>) **Spend your Essence Burst**  
  
  [[spell:369297]] will grant you a free usage of your essence abilities 
    Disintegrate/Pyre, make sure you are not using abilities that will generate 
    Essence burst when you are capped on charges (maximum of 2) or 
    capped on Essence itself.

There is a good amount of depth in your combat rotation from
just a few of these interactions, making this a more involved and interesting
DPS specialization to play.

4.

### How to Gear Up as a Devastation Evoker

While we always recommend simming yourself for ideal results, we do provide a
dedicated Devastation gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added Kithix raid loot and Upgrade lists.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **23 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Adjusted talents post tuning.
- **23 Sep. 2026 (this page):** Updated for September 22nd buffs.
- **30 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted BiS lists.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added Season 2 Lists.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Season 2.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Adjusted stats for Season 2.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Added new season 2 Talent trees.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Adjustments made for Season 2.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated for Season 2.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Updated for Midnight Season 2.
- **10 Aug. 2026 (this page):** Added all relevant Season 2 information.
- **30 Jun. 2026 (this page):** Added June 30th updates.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added Rotmire items to BiS list.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Added Omnium Folio section.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted trinket section and BiS list.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **24 Mar. 2026 (this page):** Adjustments made for Mythic release.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **03 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Added level 80 talent string.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Removed outdated info.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Added new talent tree for Midnight.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Removed sections, added Midnight pre season specifics.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Added Midnight enchants/consumables.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Minor adjustment to Stat prio for Midnight.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Adjusted rotations and added apex Section.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Added new loadouts for Midnight Pre-season.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Updated/Adjusted for Midnight.
- **26 Feb. 2026 (this page):** Added Pre-Season section, removed previous.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Added new talent tree for 12.0.1.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted gear section removed previous tier section.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Removed outdated talent.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Added new talent trees.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Added new sections and removed pruned rotation info.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Added new talent tree loadouts for 12.0.1.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Added New spells and talents.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Adjusted Talents for 12.0.1.
- **10 Feb. 2026 (this page):** Added Pre-Patch section, removed previous sections.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Added new leveling tree for Midnight pre-patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Added/Adjusted Talent section for HT.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Added/Adjusted for new talents.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Added Faqblock.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Added Faqblock.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Added Brawler's Guild, Player Housing EA and Midnight intro page reference.
- **28 Nov. 2025 (this page):** Added New Strengths/Weaknesses listings and 11.2.7 information.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted S3 BiS list and added Dinar section.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Added Patch 11.2.5 information.
- **07 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Removed tier set mentions.
- **06 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Minor update adding no-tier specific section.
- **21 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Minor update to opener.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added S3 BiS lists and Reshii section.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Removed Corruption and added new Health pot.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Added Clipping section and FS specific tier set section.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated talents for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Adjusted Fulminous roar for talent change 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Updated talent trees.
- **04 Aug. 2025 (this page):** Added Patch 11.2 information.
- **21 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted D.I.S.C section.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added D.I.S.C section/adjusted BiS list.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Added Combat Assistant section.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Added Combat assistant section.
- **15 Jun. 2025 (this page):** Adjusted/Reviewed for Patch 11.1.7.
- **02 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Simplified wording on FS ST rotation.
- **31 May 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Minor fix removal of Raging Inferno.
- **30 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted Cartel Chip Section.
- **30 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Added boss specific tips for dungeons where relevant.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added New Dinar Section.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Added Corruption section and Helmet enchant.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Adjusted build for high end m+.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Minor Adjustment to SC ST rotation section for 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Adjusted recommended builds to favour FS over SC for 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Adjusted primary builds to be FS instead of SC.
- **21 Apr. 2025 (this page):** Adjusted/Reviewed for Patch 11.1.5.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Adjusted talent trees for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added BiS lists for Season 2.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Updated Spell list for Flameshaper tree.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Adjusted rotation and talent trees for patch 11.1.0.
- **24 Feb. 2025 (this page):** Added changes for patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Adjusted rotation for patch 11.1.0.
- **17 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Talents and spells updated for Patch 11.1.0.
- **21 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted wording and gems for Cyrces.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added Cyrces Circlet information for 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Minor adjustments for patch 11.0.7.
- **15 Dec. 2024 (this page):** Reviewed for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Updated Talent Calculator.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** Added Mythic specific tips to multiple bosses.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Added more info to mythic+.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Minor changes added for Patch 11.0.5.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added Raid and M+ BiS Lists.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-nerub-ar-palace-raid-guide>)):** Page added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Section added for Season 1 TWW.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** New Section added for TWW.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added pre S1 and S1 BiS lists.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed and Adjusted for TWW.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for TWW.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Adjusted for TWW.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Adjusted for TWW.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Adjusted for TWW Added HT's.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Adjsuted for TWW.
- **21 Aug. 2024 (this page):** Adjustments made for TWW.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/devastation-evoker-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for TWW Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Rewviewed for TWW Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for TWW Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for TWW Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** New Layout and Dragonrage rotation changes added.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed and checked for TWW Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for TWW Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Adjusted layout for TWW Pre-Patch.
- **23 Jul. 2024 (this page):** Adjustments made for TWW Pre-patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/devastation-evoker-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/devastation-evoker-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **24 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted trinket information.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted tier set information for optimisation.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Removed changed flask and enchant wordings.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Reviewed for Season 4.
- **15 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Formatting fix and addition to Bullion list.
- **14 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Season 4.
- **14 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Season 4.
- **25 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6, added Eye of Infinity specific information.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **23 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Changed secondary stat priority breakdown.
- **22 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Minor wording adjustments.
- **17 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Adjustment for Potions and Wafting Devotion.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **28 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added specific megadungeon links.
- **12 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added Legguards embellishment now that its no longer reduced value per wearer.
- **12 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted BiS list.
- **12 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Adjusted secondary stat listings.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added information about Sporecloak nerf and adjusted its position in Embellishment list.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Removed incorrect sections adjusted BiS lists/Trinket/Embellishments.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Added Incandescent helm enchant for 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 (this page):** Reviewed for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added new layout for 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Added new Template.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Reviewed for Patch 10.1.7.
- **15 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** AoE specific talent wording adjustment.
- **12 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Talent tree fix.
- **12 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Adjusted trinket list.
- **12 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added Dawn of the Infinite.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.1.5
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated talent tree for patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated talent trees for Patch 10.1.5
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Updated talent rows for 10.1.5
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Updated talent trees for patch 10.1.5.
- **10 Jul. 2023 (this page):** Minor changes for Patch 10.1.5.
- **29 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Adjustments made to section 3.
- **29 Jun. 2023 (this page):** Minor change to section 4.
- **17 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Adjustments made to sections 2, 10 and 12.
- **16 May 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Included sections for Power Swell and Iridescence. Rotation switches have been updated.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Season 2 (Gear, Embelisments, Tier, Trinkets) and moved Onyx Annulet section to the bottom of the page.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Added belt enchant (new for Patch 10.1).
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated talent tree for Patch 10.1 and affix information for Season 2.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated both talent trees for Patch 10.1 and updated spell information.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Updated with Patch 10.1 changes.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Updated talent trees for Patch 10.1.
- **01 May 2023 (this page):** Replaced 10.0.7 Changes with 10.1 Changes.
- **28 Apr. 2023 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Updated talent calculator for Patch 10.1.
- **03 Apr. 2023 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Fixed talent tree issues.
- **30 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Talent fix.
- **30 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Talent fix.
- **25 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Updated Primordial Gems recommendations.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/devastation-evoker-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Added Onyx Annulet Section.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Added Onyx Annulet Gem Section.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated Pyre Target Count Chart.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Updated with 10.0.7 talent changes.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Added 10.0.7 Changes.
- **06 Feb. 2023 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Fixed typo for Unravel.
- **03 Feb. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Updated text for Kharnalex to be more explict on the Mastery benefits the item has.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Updated trinket list where darkmoon deck has been removed and Voidmenders Shadowgem has been added (with the recent changes in patch 10.5).
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **07 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Fixed Pyre cheat sheet as the columns and rows were displaying incorrectly. Added section for disintegrate chain casting.
- **21 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Updated stat priority to lower the value of Critical Strike.
- **12 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated M+ Tips for affixes and utility list.
- **12 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Added a Pyre cheat sheet table to clearly show when you use pyre on different target counts. Added a small section about the tier set impact on rotation.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Updated talent tree and included PvP talents.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated M+ talent tree.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Changed talent trees from damage focused ST/AoE to Raiding and Mythic+ with descriptions of changes that can be made when necessary.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **21 Nov. 2022 ([Legendaries](<https://www.icy-veins.com/wow/devastation-evoker-best-legendaries-shadowlands>)):** Changed Critical Strike to Haste.
- **18 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Simplified page and removed list of talents to select as you level.
- **18 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation switches. Included scenarios where you do not have the Volatility talent selected.
- **18 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Updated to table format.
- **15 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/devastation-evoker-leveling-guide>)):** Page added.
- **15 Nov. 2022 ([Legendaries](<https://www.icy-veins.com/wow/devastation-evoker-best-legendaries-shadowlands>)):** Page added.
- **15 Nov. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/devastation-evoker-best-covenants-soulbinds-and-conduits>)):** Page added.
- **15 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot>)):** Page added.
- **15 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-macros-addons>)):** Page added.
- **15 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gems-enchants-consumables>)):** Page added.
- **15 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>)):** Page added.
- **15 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-mythic-plus-tips>)):** Page added.
- **15 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-rotation-cooldowns-abilities>)):** Page added.
- **15 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spec-builds-talents>)):** Page added.
- **15 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-spell-summary>)):** Page added.
- **15 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-easy-mode>)):** Page added.
- **15 Nov. 2022 (this page):** Page added.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Devastation Evoker leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Evoker leveling guide](<https://www.icy-veins.com/wow/evoker-leveling-guide>).

1.

### Devastation Evoker Leveling Guide for Midnight

Due to the high burst AoE damage Evokers are capable of, leveling from questing and
bursting mobs is a very quick and efficient way to get through the zones.
Additionally, having short cooldown defensives that enable you to recover
health, such as [[spell:374348]], means mass pulling is less riskier than
some other specs.

Tag as many mobs as you need to with [[spell:362969]]. Once they are
grouped, cast a high rank [[spell:357208]] and then spam [[spell:357211]]. Pyre
being an uncapped AoE means that no matter how many targets you pull, they will
all melt down together.

2.

### Leveling Gear Options

In most cases while leveling, you want to prioritize the gear with the
highest item level. However, make an exception if you have a ring or neck
with only one secondary stat instead of two. In these rare cases, selecting the
item with the lower item level is acceptable.

When choosing Heirloom items, we recommend using those with Critical Strike
and Haste, as they will slightly improve your gameplay flow while leveling.

2.1.

#### Useful Leveling Consumables for Midnight

Consumables can make a big difference when leveling. Be sure to pick these
up to make your journey as smooth as possible.

- [[item:212283]]: Your best damage-increasing flask.
- [[item:212265]]: This synergises with your flask to give a massive damage boost.
- [[item:244839]]

3.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Devastation Level 80 Midnight Leveling
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzMDMDzgZghZMTjZmpZwyMmZmZmZmZGwMzYwMLzMDMAD2AMaYAMDAbYgZGMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzMzADzYmBMYMTjZmpZMWmxMzMz8AzMzAmxMzYmZZmZgBGDWglxox2AYGA2wAzMYYA"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscRRFLLbZYYluqqPkkoXpWejEgnm+WDHA-jNiMhDEgBCCfUJeJT6iqe4w2cAK1uyA-AAAA-TIQaAUGYEE44iB-
```

:::

4.

### War Mode Talents for Leveling

Here, you will find information on the best PvP talents
for leveling and doing solo or small group PvE content.

1. [[spell:378444]] will allow you to safely cast spells while enemies
   are trying to knock you back. It can also be useful for picking up Windswept Herbalism nodes.
2. [[spell:378437]] can be useful when you are running away from a
   pack of enemies. It can also help you avoid slowing down by Daze.
3. The third PvP talent is largely your personal choice. I would recommend
   [[spell:370388]], as it is useful for open world mobility, such as when you
   are in combat and cannot Dragon ride.

Devastation Evoker PvP talents do not provide much 
of a gain overall, but can slightly speed up your leveling process by making 
combat less troublesome.

5.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider 
to select your level, and watch as the leveling rotation grows with each 
level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1 起：**Your basic rotation whilst leveling will be as follows:

**等级 1–64：**Use [[spell:357208]] (at level 1) and [[spell:359073]]
at the level relevant to the target count (level 1 for 1-2 targets, level 2 for
3-4 targets, level 3 for 5+ targets).

**等级 65 起：**Use [[spell:357208]] (at level 1) and [[spell:359073]]
at the level relevant to the target count (level 1 for 1-2 targets, level 2 for
3-4 targets, level 3 for 5-6 targets, level 4 for 7+ targets).

**等级 1 起：**Use [[spell:357210]] if fighting more than 1 target.

**等级 1 起：**Use [[spell:356995]] as your Essence spender, unless
If you are fighting more than 4 targets, then use [[spell:357211]].

**等级 10 起：**If you do not have enough Essence to cast [[spell:356995]]
or [[spell:357211]], then use [[spell:361469]] (for 1-2 targets) or [[spell:362969]]
(for 3+ targets).

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **03 Mar. 2026:** Added level 80 talent string.
- **02 Mar. 2026:** Removed outdated info.
- **26 Feb. 2026:** Added new talent tree for Midnight.
- **10 Feb. 2026:** Added new talent tree for 12.0.1.
- **19 Jan. 2026:** Added new leveling tree for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Adjusted talent trees for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated Talent Calculator.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** New Section added for TWW.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **25 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **12 Jul. 2023:** Talent tree fix.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **28 Apr. 2023:** Updated talent calculator for Patch 10.1.
- **03 Apr. 2023:** Fixed talent tree issues.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated talent tree and included PvP talents.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Simplified page and removed list of talents to select as you level.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Devastation Evoker in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Devastation Evokers in Midnight

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Devastation's playstyle is very fluid, where you will always
be casting something which interacts with your next cast due to various
talents.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_disintegrate.jpg>) **Manage your Essence**  
  
    Devastation's primary resource is Essence which is spent on [[spell:356995]] 
    and [[spell:357211]] you want to make sure you are never sitting at the maximum 
    Essence to avoid losing regeneration time.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_firebreath.jpg>) **Manage your Empowers**  
  
    Empower spells ([[spell:357208]] and [[spell:359073]]) are your 
    short cooldown, high value abilities that you will want to be hitting as 
    soon as they are ready in nearly every situation.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_essenceburst.jpg>) **Spend your Essence Burst**  
  
  [[spell:369297]] will grant you a free usage of your essence abilities 
    Disintegrate/Pyre, make sure you are not using abilities that will generate 
    Essence burst when you are capped on charges (maximum of 2) or 
    capped on Essence itself.

2.

### Beginner's Guide to Devastation Evoker in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander   Single-Target Talents

2.1.

#### Beginner Single-Target Talents for Devastation Evoker

This build will be used in single-target situations.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzMDMDzwMgBjZaMzMNjx2wMzMzMzMzAmZmxYmZZmZgBGD2glxox2AYGA2wMYmBDD"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscFRRLLbZtYYluqqPkkoXpjWEfenrdmCB-jNiMhDgCCfUJJeeTR6iCe4w2A0ucKzA-AAAA-TIQaAUGYEE84iB-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander   AoE Talents

2.2.

#### Beginner AoE and Mythic+ Talents for Devastation Evoker

This is our recommended build for all content that is not exclusively single target.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGzMgBjZamZmpZmx2MMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscRRFLLbZYYluqqPkkoXpjWEfenrVmCHA-jNiMhDgCCfUJJeeVTR6ie4w2gA0cKzA-AAAA-TIQaAUGYEE84iB-
```

:::

### Devastation Evoker   Basic Rotation

2.3.

#### Beginner Devastation Evoker DPS Rotation

The primary focus for Devastation is split into three different rotational
aspects.

1. Empowered spells: These are short cooldown, high damage
   abilities that will also give beneficial interactions with your other
   non-Empowered abilities.
2. Essence spenders: These are [[spell:356995]] and
   [[spell:357211]]. You want to ensure that you never overcap your Essence
   and let it go to waste.
3. Filler abilities: These are [[spell:361469]] and
   [[spell:362969]]. These abilities cost nothing and will proc free Essence
   spenders as well as an assortment of other beneficial effects, depending on
   your current talents.

Beyond these three core aspects of the class, you will have certain longer
cooldown abilities that you will want to use to increase your damage; this
list is very limited.

2.4.

#### Basic Rotation Opener

The priority system for [Devastation Evoker](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-guide>) is not very complicated
as a whole, the majority of your time casting will be spent channeling
[[spell:356995]] and using an assortment of abilities off cooldown
then filling in with [[spell:361469]] where needed.

- Pre cast [[spell:361469]].
- Cast [[spell:357210]]
- Cast [[spell:375087]].
- Cast [[spell:370452]].
- Cast [[spell:357208]] with [[spell:370553]].
- Cast [[spell:359073]] at rank 1.
- Cast [[spell:356995]] until you run out of Essence.
- Cast If you run out of Essence and none of the previously listed abilities are ready to be used, cast [[spell:361469]].

A very simple and effective way to ensure you are playing well is
sending [[spell:359073]]/[[spell:357208]]/[[spell:370452]]
on cooldown. This will end up being correct in nearly every situation.

If you are Scalecommander, you will want to send [[spell:357210]] on Cooldown.
If you chose Flameshaper instead, you will want to use [[spell:443328]] after
applying [[spell:357208]] to avoid overcapping charges.

2.5.

#### Major Cooldowns

[[spell:375087]] — this is your only substantial damage cooldown,
which will give your Mastery ([[spell:362980]]) full effectiveness
regardless of the target's current health, and will let your filler abilities
give you guaranteed free Essence spenders on each cast. The effect of
Dragonrage is extended each time you use an Empowered spell.

2.6.

#### AoE Rotation

The only real difference is when you focus exclusively on AoE instead of
single target is that you will be max channeling the Empowered spell
[[spell:357208]], and then replace [[spell:361469]] with [[spell:362969]] and
[[spell:356995]] with [[spell:357211]].

2.6.1.

##### Apex Talent: ![Rising Fury Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_evoker_risingfury.jpg>) Rising Fury

Midnight gives us the new Apex Talent [[spell:1271687]] which serves as 
a damage steroid inside your [[spell:375087]]. The effect persists for a short 
duration afterwards granting you additional stacks of [[spell:369297]] allowing 
you to cast your Essence spenders more frequently.

2.6.2.

##### Season 2 Tier Set

Midnight Season 2 brings our new tier set, making our 
[[spell:370452]] always cast as if you were at max empower level, this has 
decent synergy with [[spell:370821]] meaning our talents adjust to always 
take Shattering Star.

### Devastation Evoker   Defensive Spells

2.7.

#### Defensive Spells for Devastation Evoker

[[spell:363916]] is your main defensive, which will reduce all damage
you take by 30%. You can talent into a second charge of this, meaning you can
always have a significant damage reduction for predictable incoming damage
windows.

[[spell:374348]] is another defensive that is automatically applied when 
you cast [[spell:363916]]. This causes 30% of all
damage you take over the next 8 seconds also heal you in the form of a HoT with
the same 8-second duration. This is very potent for long periods of medium-high
damage, as it will keep your health pool high and limit your risk of
dying.

[[spell:410352]] this will cause your [[spell:357210]] to turn all damage taken
while you are flying into a DoT effect lasting 10 seconds, this is a very potent defensive and will 
allow you to soak massive hits when needed.

[[spell:374227]] will give you and 4 nearby allies a 20% damage reduction from
AoE abilities for a short duration. This can be situationally amazing,
particularly in Mythic+.

These are the defensive utility talents and abilities for Devastation
Evoker, for more details, we recommend you check out the Spell Summary page.

### Devastation Evoker   Stat Priority

2.8.

#### Stat Priority for Devastation Evoker

The general stat priority for a Devastation
Evoker is seen below. This is very much a rough guideline and is 
designed for players who do not wish to sim their character. If you are simming 
your character, please disregard this stat priority completely and follow your 
sim!

Item Level

Critical Strike

Haste

Mastery

Versatility

For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>).

### Blizzard   Combat Assistant

2.9.

#### Combat Assistant for Devastation Evoker

The Combat Assistant arrives this patch with two options which can be used to 
improve your rotation and learn to maximise your damage.

The first is the one-button assistant which will constantly shift itself to 
the next button in your rotation with a minor global cooldown penalty, this is 
currently about a 20% DPS loss over playing the class optimally by your own hand.

The second is the highlight assistant which will highlight the next ability 
you want to press on your action bars in order to follow blizzards pre-set optimal 
rotation, this does not have the global cooldown penalty that the one-button assistant does
however due to following blizzards rotation instead of the more heavily optimised 
variant in simcraft, this will still lead to a roughly 10% DPS loss.

I highly recommend using both of these when initially learning Devastation, 
it will not teach you to play perfectly but it will give you a strong foundation 
to work from with the overall losses not being that significant.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated/Adjusted for Midnight.
- **10 Feb. 2026:** Adjusted Talents for 12.0.1.
- **19 Jan. 2026:** Added/Adjusted for new talents.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **07 Sep. 2025:** Removed tier set mentions.
- **04 Aug. 2025:** Updated talent trees.
- **15 Jun. 2025:** Added Combat assistant section.
- **21 Apr. 2025:** Adjusted primary builds to be FS instead of SC.
- **24 Feb. 2025:** Adjusted rotation and talent trees for patch 11.1.0.
- **15 Dec. 2024:** Minor adjustments for patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Adjsuted for TWW.
- **23 Jul. 2024:** Adjusted layout for TWW Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **23 Jan. 2024:** Changed secondary stat priority breakdown.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated talent trees for patch 10.1.5.
- **01 May 2023:** Updated talent trees for Patch 10.1.
- **30 Mar. 2023:** Talent fix.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Devastation Evoker in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Devastation Evoker

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander is the best Hero Talent for Devastation in every form
of content for Season 2, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper only being comparable in pure
single-target scenarios. Currently we recommend the following:

- **Raid -**  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander is the choice for every boss, with
  slightly better single target and an enormous gain any time an additional target
  is added there is no reason to play ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper unless you really
  enjoy the playstyle.
- **Mythic+ -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander will be better for all dungeons
  currently, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper only pulling ahead once you reach 8-9 targets 
  nd having to take a significant loss to your single-target damage to achieve this.
  Therefore it is highly recommended you stick with SC.

The Evoker class tree has plenty of utility options you can pick and choose to
suit your needs in any situation. The trees below serve as a baseline profile
for maximum damage, and spec into some very minor damage gains at the cost of utility.
For scenarios where you want to provide greater control, we would recommend
taking points out of [[spell:375520]] and [[spell:375554]] to put them in the talents listed below.

- [[spell:372048]] this talent is great in all group play, being paired
  with an AoE stun to increase its duration by 50% is incredibly powerful.
- [[spell:360806]] this talent is a bit more niche but has some very powerful uses.
  Tt can be used to split individual mobs from their pack in dungeons, allowing for 
  unique routes, and can function as a hard CC on a target if needed.
- [[spell:375528]] this talent is another niche one but situationally
  very good, as it can help with longer AoE CC rotations and to prevent mobs from moving.

**Quick Start Import Codes:**

:::talents Scalecommander Raid/Delves -
```json
{
  "code": "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMbzMDMwYwGsMGN2GQmJAbYgZGMjHA"
}
```
:::

:::talents Scalecommander Mythic+ -
```json
{
  "code": "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBGYMTjZmpZmZ2mZmZmZmZmZGwMzMzYmZbmZgBGD2glxox2AyMBYDzgZGM8AA"
}
```
:::

1.1.

#### Apex 1 or Apex 4

The difference between running 1/4 Apex and 4/4 Apex is essentially non-existent for all Scalecommander builds.
The recommendations below are nearly all picking Apex 1, as it is easier to play and much more forgiving in variable situations.

to display the talent tree please select the hero talent & content you would like to play

Scalecommander

Single-Target Raid

Recommended

Raid Cleave/Delve

Recommended

Mythic+

Recommended

Flameshaper

Raid

Mythic+

### 天赋方案 0-0

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander Single-Target Raid Build

This build is optimal for pure single-target situations.

### 天赋方案 0-1

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander Raid Cleave and Delve Build

This is our recommended build for cleave scenarios in raids and when doing delves.

### 天赋方案 0-2

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander Mythic+ Build

This build will be strongest for doing Mythic+.

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Raid Build

This tree can be used for raiding as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper. It can only compete with
Scalecommander in pure single-target scenarios and is substantially behind everywhere else.
We would not recommend playing this until tuning happens, or because you prefer the
playstyle of Flameshaper even if it comes at a significant performance loss.

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper Mythic+ Build

This tree can be used for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper keys. It has much higher AoE potential
than Scalecommander but suffers a significant ST loss as the trade-off.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGjxYGmBMYMTjZmpZM2GmZmZmZmZGwMmZGzMbzMDMwYwGsMGN2GAzAwGGYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcsFLLYYblqquPXkkopEWegjnvfmXDB-jNhiDMgCCEKUeefGIT7iw04Aeuy2KdA-AAAA-JQSUaACKYw4IzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMbzMDMwYwGsMGN2GAzAwGGYmBz4BA"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcsFLLYYblqquPXkkopEWegjnvfmXDB-jNhiDMgCCUVeefJJT7Qiw04Aeguy2KPcsA-A-JQSUaACKYw4IzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZwgZGmBGYMTjZmpZmZ2mZmZmZmZmZGwMzMzYmZbmZgBGD2glxox2AYGA2wMYmBDPA"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcstFKYYblqquPXkkopEWegjndfmXDB-jNhiDMgCCLLUVeefST7iw04Aeguy2KPcsA-A-JQSUaACKYw4IzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZGmZYGmBMYMTjZmJjxyYmZGmZmZGwMmZGzMbzMDmBmxMwCYBMDTgNwywAYmZGD"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcsFLLYYblqquPXkkopEWegjnvfmXDB-jNhiDMgCCEUeefJJT6Qiw0AeuyKPsIB-AAAA-IckUhpBIQYgxSB-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzYMzMzMzwMwMYMTzYmJjxywMzwYmZGwMmxYmZbmZwMwMmBWAbgZYCsBWGmBYmZYA"
}
```
:::

:::details 来源计算器编码
```
#7W-RRSUZcstFKLLYYblqquPXkkopEVejnfmXDB-jNhiDMgBLLUfJJKT6MQiw0AKeuyKPIB-AAAA-IekUhpBIQYgxSB-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

:::details TipsWhen Do I Take Star Salvo Instead of Power Swell?
Devastation Evoker's Season 2 tier set focus heavily on

[[spell:370452]]

,
increasing its damage, and automatically making it hit the maximum amount of targets
regardless of Empower level. This leads to it becoming a damage increase at 2 targets, and
gaining more power with more targets p resent. The trade-off for this is a large quality
of life hit when speccing out of Power Swell. The gain at 2 targets is roughly 1.5-2% DPS,
which means you should be fine playing with Power Swell in a raid environment, but you should
always be taking Star Salvo in Mythic+.

:::

2.

### Omnium Folio

The Omnium Folio is a borrowed power system that was introduced in [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>) 
which lets you choose 5 different "Talents" for minor gains. The majority of these are small 
damage increases with the defensive nodes providing an almost irrelevant gain.

We recommend the following choices. These can be swapped at any point without returning to the 
Omnium Folio:

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279609]]
- [[spell:1279614]]

3.

### Apex Talent: ![Rising Fury Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_evoker_risingfury.jpg>) Rising Fury

The new Apex Talent for Devastation Evoker is [[spell:1271687]],
a stackable Haste and damage increase that activates when we use
[[spell:375087]].

Starting with 1 stack when you activate Dragonrage, you will receive
4% Haste every 6 seconds. This Haste buff stacks up to
5 stacks for a total of 20%. Upon reaching 5 stacks you will also gain 
a 15% damage increase, which persists for 4 seconds per stack once Dragonrage 
ends.

When Dragonrage expires you will receive 
4 charges of [[spell:1292322]]. This ability deals damage to 5 targets and 
grants a stack of [[spell:369297]], and you have until your Dragonrage cooldown 
becomes available again to spend these charges.

4.

### Hero Talents

Starting at level 71 you will be able to choose from two new Hero talent trees, for Devastation these are 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper focuses heavily on applying and consuming your 
[[spell:357208]] with the hero talent [[spell:444088]]. This can be done in two 
specific ways by casting [[spell:356995]] if you are single targetting or 
[[spell:357211]] when doing your AoE rotation. The Flameshaper playstyle does not 
offer many adjustments from your regular rotation with the only noticeable 
difference being you will cast [[spell:357208]] much more frequently.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander focuses heavily on making [[spell:357210]] 
a core part of your rotation coupled with the new [[spell:116297]] talent in the 
Devastation tree. Scalecommander has almost limitless mobility with constant 
resets of your [[spell:358267]] cooldown each time you cast Deep Breath. It also comes with 
enhanced spread cleave with its core ability [[spell:401680]], 
allowing each Disintegrate following an empower cast (Fire Breath/Eternity Surge) to hit up to three
additional targets for a maximum of four. This makes for a very potent raid 
spec that only suffers from a lack of high single target burst damage.

On the topic of [[spell:411165]] or [[spell:411164]], you will want to sim
your character to be sure. [[spell:411164]] has a more forgiving playstyle when it comes
to your [[spell:375087]] extends, and I would recommend taking it, even if it is a minor loss.
Continue using [[spell:411164]] until you are very comfortable with the spec.

5.

### PvP Talents (War Mode)

Opting into War Mode makes you eligible for open-world PvP, but also grants
you the following benefits:

- World Quests at maximum level have 10% increased rewards (30% if you are
  Alliance).
- You gain 10% increased Experience while leveling (30% if you are Alliance).
- Allows you to earn Conquest Points towards weekly gear rewards.
- Grants you to use PvP talents in the open-world.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended that you enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself eligible for open-world PvP, and
the possibility of being "ganked" while leveling or doing World Quests exists.

There are no PvP talents for Evokers that increase your total damage output.
Therefore, the PvP talents you choose are entirely up to personal preference.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **23 Sep. 2026:** Adjusted talents post tuning.
- **10 Aug. 2026:** Updated for Season 2.
- **15 Jun. 2026:** Added Omnium Folio section.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Added new loadouts for Midnight Pre-season.
- **10 Feb. 2026:** Added new talent tree loadouts for 12.0.1.
- **19 Jan. 2026:** Added/Adjusted Talent section for HT.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated talents for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Adjusted recommended builds to favour FS over SC for 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Feb. 2025:** Talents and spells updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Adjusted for TWW.
- **23 Jul. 2024:** Reviewed and checked for TWW Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6, added Eye of Infinity specific information.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for 10.2.
- **04 Sep. 2023:** Added new Template.
- **15 Jul. 2023:** AoE specific talent wording adjustment.
- **10 Jul. 2023:** Updated talent trees for Patch 10.1.5
- **01 May 2023:** Updated both talent trees for Patch 10.1 and updated spell information.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **06 Feb. 2023:** Fixed typo for Unravel.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Changed talent trees from damage focused ST/AoE to Raiding and Mythic+ with descriptions of changes that can be made when necessary.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Devastation Evoker in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Devastation Evoker Gameplay and Rotation Guide

Welcome to our Rotation page for Devastation Evokers. On this
page, you will find everything you need to know about rotational gameplay for the spec 
in Raiding and Mythic+ scenarios.

Each of the sections below explain the rotation for Devastation Evoker at
different target counts. Click the boxes to switch to the desired damage
type.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper

Raid

Mythic+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander

Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:369459]]

[[spell:374968]]

[[spell:374227]]

[[spell:351338]]

[[spell:359073]]

[[spell:375087]]

[[spell:1265867]]

[[spell:369089]]

[[spell:375725]]

[[spell:375757]]

[[spell:411165]]

[[spell:411164]]

[[spell:1265802]]

[[spell:376888]]

[[spell:386283]]

[[spell:370781]]

[[spell:370839]]

[[spell:116297]]

[[spell:375777]]

[[spell:370821]]

[[spell:370867]]

### Single-Target Breakdown for Scalecommander

[[spell:361469]]

[[spell:357210]]

[[spell:375087]]

[[spell:359073]]

[[spell:357208]]

[[spell:356995]]

[[spell:357210]]

[[spell:359073]]

[[spell:356995]]

[[spell:357208]]

[[spell:356995]]

[[spell:361469]]

[[spell:369297]]

1.1.

#### Scalecommander Single-Target Opener

1. Pre-cast [[spell:361469]]
2. Cast [[spell:357210]] canceling it as soon as you hit your target
3. Cast [[spell:375087]]
4. Cast [[spell:359073]]
5. Cast [[spell:357208]] at Empower level 1
6. Cast [[spell:356995]] until you run out of Essence
7. Cast [[spell:357210]]
8. Cast [[spell:359073]] at Empower level 1
9. Cast [[spell:356995]] once
10. Cast [[spell:357208]] at Empower level 1
11. Cast [[spell:356995]] until you run out of Essence
12. Cast [[spell:361469]] as your filler to generate [[spell:369297]]
13. Follow the rotation outlined below.

1.2.

#### Scalecommander Single-Target Rotation

1. Cast [[spell:357210]] on cooldown, followed by its second cast 7-8 seconds later after you have spent a minimum of two charges of [[spell:370781]]
2. Cast [[spell:357208]] always at Empower level 1
3. Cast [[spell:359073]] always at Empower level 1
4. Cast [[spell:356995]] to spend your Essence
5. Cast [[spell:1265867]] when available
6. Cast [[spell:361469]] as your filler
7. Cast [[spell:362969]] as your filler if you have no [[spell:358267]] available

1.3.

#### Unbound Flame Usage

[[spell:1292322]] usage is very simple, at the end of [[spell:375087]] when you are fully stacked on [[spell:1271788]] you want to spend all 4 of your charges inside the damage and haste amp window. You want to be spending a charge when you are below 4 essence and have no [[spell:369297]] stacks.

### Mythic+ Breakdown for Scalecommander

[[spell:357210]]

[[spell:375087]]

[[spell:359073]]

[[spell:370553]]

[[spell:357208]]

[[spell:356995]]

[[spell:401680]]

[[spell:357211]]

[[spell:356995]]

[[spell:361469]]

[[spell:375801]]

[[spell:369939]]

[[spell:362969]]

[[spell:375801]]

[[spell:369939]]

[[spell:357208]]

[[spell:359073]]

1. Cast [[spell:357210]] once the enemies are grouped
2. Cast [[spell:375087]]
3. Cast [[spell:359073]] at rank 1 or matching the target count, 2/4/6 targets for each Empower level. Or with [[spell:370553]]
4. Cast [[spell:357208]] at rank 1
5. Cast [[spell:356995]] after casting your empowers to trigger [[spell:401680]]
6. Cast [[spell:357211]] when you are fighting 5 or more targets, on 4 or less switch to [[spell:356995]]
7. Cast [[spell:361469]] with [[spell:375801]] procs and to consume [[spell:369939]]
8. Cast [[spell:362969]] as your filler when you have no [[spell:375801]] or [[spell:369939]]
9. Cast [[spell:357208]] and [[spell:359073]] as soon as they are available, upranking Eternity Surge to match targets.

1.4.

#### Unbound Flame Usage

[[spell:1292322]] usage is very simple, at the end of [[spell:375087]] when you are fully stacked on [[spell:1271788]] you want to spend all 4 of your charges inside the damage and haste amp window. You want to be spending a charge when you are below 4 essence and have no [[spell:369297]] stacks.

### Single-Target Breakdown for Flameshaper

[[spell:361469]]

[[spell:375087]]

[[spell:357208]]

[[spell:359073]]

[[spell:356995]]

[[spell:357208]]

[[spell:356995]]

1.5.

#### Flameshaper Opener

1. Pre-cast [[spell:361469]]
2. Cast [[spell:375087]]
3. Cast [[spell:357208]] at Empower level 1
4. Cast [[spell:359073]] at Empower level 1
5. Cast [[spell:356995]] twice
6. Cast [[spell:357208]] at Empower level 1
7. Cast [[spell:356995]] until out of Essence

1.6.

#### Flameshaper Rotation

This will be a simple priority list of how you should be spending your gcds after your opener to deal optimal damage.

1. Cast [[spell:357208]] on cooldown, always at Empower level 1
2. Cast [[spell:359073]] on cooldown
3. Cast [[spell:356995]] as your Essence spender
4. Cast [[spell:1265867]] when available
5. Cast [[spell:361469]] as your filler
6. Cast [[spell:362969]] if you have to cast whilst moving without [[spell:358267]] active

1.7.

#### Unbound Flame Usage

[[spell:1292322]] usage is very simple, at the end of [[spell:375087]] when you are fully stacked on [[spell:1271788]] you want to spend all 4 of your charges inside the damage and haste amp window. You want to be spending a charge when you are below 4 essence and have no [[spell:369297]] stacks.

### Mythic+ Breakdown for Flameshaper

[[spell:375087]]

[[spell:357208]]

[[spell:444088]]

[[spell:357211]]

[[spell:356995]]

[[spell:361469]]

[[spell:357208]]

[[spell:369939]]

[[spell:359073]]

[[spell:357208]]

1. [[spell:375087]] is sent on cooldown
2. [[spell:357208]] is always cast at empower level 1 to maximize the damage of [[spell:444088]]
3. [[spell:357211]] on everything 3 targets or above, switch to [[spell:356995]] at 2 targets
4. [[spell:361469]] cast at least once between every [[spell:357208]] to consume [[spell:369939]]
5. [[spell:359073]] cast when you have none of the above available
6. Cast [[spell:357208]] as soon as it is available

1.8.

#### Unbound Flame Usage

[[spell:1292322]] usage is very simple, at the end of [[spell:375087]] when you are fully stacked on [[spell:1271788]] you want to spend all 4 of your charges inside the damage and haste amp window. You want to be spending a charge when you are below 4 essence and have no [[spell:369297]] stacks.

:::details FAQWhen Should I use Pyre Instead of Disintegrate?
At three targets your

[[spell:357211]]

will start doing more total damage.
But remember that if you need to kill a priority target, you should be casting

[[spell:356995]]

instead.

:::

2.

### Midnight Season 2 Tier Set

The Midnight Season 2 Tier set turns our ability [[spell:370452]] to a more powerful
passive.

1. [[spell:1296639]] — Increases the damage dealt
   by [[spell:370452]] by 50% and casts as if you had reached maximum empower level.
2. [[spell:1296640]] — [[spell:375777]] reduces the remaining 
   cooldown of your empower spells by an additional 0.1 seconds each time the effect occurs. [[spell:359073]] 
   deals 10% increased damage.

3.

### Class and Spec Mechanics Explained

### Dragonrage Extending

3.1.

#### Dragonrage Extending

Dragonrage extending is achieved by casting Empowered spells, such as
[[spell:357208]] and [[spell:359073]], after activating your
[[spell:375087]] cooldown. This is only possible when talented into
[[spell:375797]]. Despite Dragonrage no longer having a cap on its duration,
you are unlikely to go much beyond 34 seconds due to the diminishing returns
on each extension.

### Bombardment Cleaving

3.2.

#### Bombardment Cleaving

Bombardment cleaving is specific to the Scalecommander Hero Talent tree
and is done by spreading your [[spell:434300]] debuff to multiple targets.
The primary target of each [[spell:401680]] gets its own Bombardments
debuff. Each Essence ability you cast will extend the duration of all active bombardments, 
allowing you to get twice as much damage dealt and twice as much cooldown reduction on [[spell:357210]] 
from [[spell:441206]].

### Apex Talents

3.3.

#### Apex Talents

The new Apex Talent for Devastation Evoker is [[spell:1271687]],
a stackable Haste and damage increase that activates when we use
[[spell:375087]].

Starting with 1 stack when you activate Dragonrage, you will receive
4% Haste every 6 seconds. This Haste buff stacks up to
5 stacks for a total of 20%. After reaching 5 stacks, you will also 
receive a 15% damage increase that persists until the buff wears off.

When Dragonrage expires, your Rising Fury will remain for 4 seconds per
stack, up to a maximum of 20 seconds. This effectively maintains the previous
buffs, in addition to granting you a charge of [[spell:369297]] every
4 seconds.

4.

### Important Cooldowns for Devastation Evoker

### [[spell:375087]]

4.1.

#### Dragonrage

[[spell:375087]] is our only major cooldown, available every 2 minutes. It grants full 
effectiveness of [[spell:362980]] and guarantees all of your fillers spells
([[spell:361469]] / [[spell:362969]] / [[spell:1265867]]) will proc [[spell:369297]].
It is important to get as many uses of this in a fight as you can.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Adjustments made for Season 2.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Adjusted rotations and added apex Section.
- **10 Feb. 2026:** Added new sections and removed pruned rotation info.
- **30 Nov. 2025:** Added Faqblock.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **06 Sep. 2025:** Minor update adding no-tier specific section.
- **21 Aug. 2025:** Minor update to opener.
- **04 Aug. 2025:** Added Clipping section and FS specific tier set section.
- **15 Jun. 2025:** Added Combat Assistant section.
- **02 Jun. 2025:** Simplified wording on FS ST rotation.
- **31 May 2025:** Minor fix removal of Raging Inferno.
- **21 Apr. 2025:** Minor Adjustment to SC ST rotation section for 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Feb. 2025:** Adjusted rotation for patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Adjusted for TWW.
- **23 Jul. 2024:** New Layout and Dragonrage rotation changes added.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **22 Jan. 2024:** Minor wording adjustments.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **29 Jun. 2023:** Adjustments made to section 3.
- **17 Jun. 2023:** Adjustments made to sections 2, 10 and 12.
- **16 May 2023:** Included sections for Power Swell and Iridescence. Rotation switches have been updated.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated Pyre Target Count Chart.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **07 Jan. 2023:** Fixed Pyre cheat sheet as the columns and rows were displaying incorrectly. Added section for disintegrate chain casting.
- **12 Dec. 2022:** Added a Pyre cheat sheet table to clearly show when you use pyre on different target counts. Added a small section about the tier set impact on rotation.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **18 Nov. 2022:** Updated rotation switches. Included scenarios where you do not have the Volatility talent selected.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Devastation Evoker in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Devastation Evoker

Welcome to our Devastation Evoker Gear page for
Midnight. Check this page to learn everything
you need to know about gearing a Devastation Evoker, including the
BiS Gear from all sources, Raiding, and Mythic+, information on the best 
Trinkets, Tier Sets, and much more.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Devastation Evoker. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 as a Devastation Evoker with the changes to the catalyst system, you will want to catalyze any items without versatility into tier slots making targetted farming much more valuable. The specific items you will want to target for catalyzing are as follows.

- Helmet: [[item:268230]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- Shoulders: [[item:268231]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Chest: [[item:271876]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Gloves: The tier gloves already have good stats so we do not catalyze this slot.
- Legs: [[item:268237]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details FAQWhat to do with the Great Vault?
The Great Vault has two new major changes coming with this season, first being that Mythic raid itemsare automatically upgraded to the maximum when listed as a reward, and the other being the ability to buy Nebulous Voidcores (Bonus Rolls). These changes make it a bit more difficult to make the best choice every single time but there are still some high value things you wil want to prioritize first.

The first thing you will want to be chasing is your tier bonus, normally this would be a weapon but with how strong the new embellishment is it is highly recommended to craft a weapon instead.

This is where it becomes abit more difficult and somewhat dependant on the level of content you are doing,if you are not participating in mythic raid content you can use a bonus roll on the last heroic boss andthe rewards will be 1/6 mythic instead of on the heroic track. This can be very powerful for targetting the cantrip items on the final boss, you can change your loot spec to Preservation and only have 3 items on the loot table making it guaranteed to get a very valuable item each time.

These items will require crests to fully upgrade which may slow down your overall ilvl progression but the relative power of these items, particularly [[item:268265]] is substantially higher than any other neck and is worth the crest usage without a doubt. Keep in mind that these items when droppedat mythic difficulty will be VenomCursed and upgraded to 9/6 instead of the regular 6/6 maximum

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Unbinding of Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271504@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Unbinding of Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Unbinding of Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup from mythic+ for Devastation Evoker.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). so take the time to check the value of each item before committing to enchanting and upgrading, even more important when deciding where to bonus roll.

secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2 as a Devastation Evoker with the changes to the catalyst system, you will want to catalyze any items without versatility into tier slots making targetted farming much more valuable. The specific items you will want to target for catalyzing are as follows.

- Helmet: [[item:251220]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Shoulders: [[item:239049]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Chest: [[item:273789]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Gloves: [[item:160213]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Legs: [[item:159375]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I be Doing?
Some dungeons have a much better chance of giving you a BiS item than others, if you are limited on time we recommend the following.

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) has 4 total items you want including your weapon.
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>) has 2 including a BiS dungeon trinket.
- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>) has 3 items.

Other than these 3 you will naturally fill in the rest of your slots across other dungeons, but these serve as the best starting point for gearing.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:273781@JAACAAAOyA]]&#10;&#10;<div>[[item:240983]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Waist</th><td>[[item:251155@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271499@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271500@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAAAxA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271504@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAACAAAD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAOAAwt1wgNRDjexclIgBDH2A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup from raid sources for Devastation Evoker. As always what gives you the biggest upgrade will depend on the rest of your gear

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). 

So be sure to take care when choosing what to bonus roll from the raid, make sure you have simmed your options correctly.

 

FAQWhich Tier Set Pieces Do I Want?  

For Midnight Season 2 as a Devastation Evoker with the changes to the catalyst system, you will want to catalyze any items without versatility into tier slots making targetted farming much more valuable. The specific items you will want to target for catalyzing are as follows. 

- Helmet: [[item:268230]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- Shoulders: [[item:268231]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Chest: [[item:271876]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Gloves: The tier gloves already have good stats so we do not catalyze this slot.
- Legs: [[item:268237]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

  TipsWhich items do i want to target from raid?  

If you are unsure about what items you need to focus on and where your biggest upgrades are, we will break it down for you. 

- [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) drops 3 incredibly powerful items, [[item:268265]],[[item:271876]] and [[item:271092]]. All of these items come with powerful cantrip effects that hugely increase their power.
- [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) drops 1 of our BiS trinkets, [[item:270164]].
- [Tidebound Grotto](<https://www.icy-veins.com/wow/midnight-world-bosses-guide>) drops our other BiS trinket, [[item:270167]].

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Unbinding of Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271504@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Unbinding of Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAMAAwt1wgNRDjexclIgBD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devastation-evoker-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Unbinding of Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Devastation Evoker

We would recommend simming the trinkets listed here when you acquire them as it
will not be an ironclad rule of what is BiS in every situation. There are other trinkets you can use 
beside these but they are quite significantly worse.

There are a few strong trinkets for Devastation Evoker this season with three that are a cut 
above the rest: [[item:270164]], [[item:270167]] and [[item:270168]].

Below we will have a ranking chart to help you get a better understanding of these four trinkets and several more.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Devastation Evoker Trinket Rankings
All trinkets are assumed to be Mythic+ item level unless a lower item level is 
    specified for the sake of comparison. The idea is to compare trinkets at 
    their maximum obtainable item level to give you an idea of where things are 
    placed. We do not suggest using two on use trinkets even if the trinkets 
    are ranked higher than passive trinkets on this list. For more accurate 
    information on how trinkets perform relative to each other for your own 
    character, please [sim your character](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

A "Tier" as defined by this list is around 0.5% DPS, meaning that S-Tier 
    Trinkets are around 0.5% better than A-Tier Trinkets, and so on. This tier trinkets are very close in calue as they have overall lost a lot of power, so not having the 2 BiS trinkets won't feel as bad.

<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]] Passive. Raid drop<li>&#10;<li>[[item:270168]] On use. Raid drop</li>&#10;<li>[[item:270164]] passive. Raid drop</li>&#10;<li>[[item:270167]] passive. Raid drop</li>&#10;</li></li></ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td><ul>&#10;<li>[[item:250215]] on use. Dungeon drop</li>&#10;<li>[[item:250224]] passive. Dungeon drop</li>&#10;<li>[[item:273796]] on use, the random stat choice on this trinket diminishes its value somehwat. Dungeon drop</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169]] on use. Raid drop</li>&#10;<li>[[item:273794]] passive. Dungeon drop</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and and Ascendant Venomstones

The bonus roll system introduced in Patch 12.0.5 is continuing for Season 2.
[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) are items that can be used in dungeons or after killing a
specific raid boss, and let you gain a guaranteed piece of loot from that dungeon
or raid boss. The item you get from within that loot pool is random, but you can not
get a duplicate item if you roll again, so using it again in a specific place will give
you another chance on the remaining items.

3.1.

#### Recommended Nebulous Voidcore Usage for Devastation Evoker

The items you want and the order in which you want to pursue them will depend on a
few factors, but primarily it will be decided by your current gear and the rewards you
are expecting to see in your [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>). I will go into a little deeper
reasoning behind the decisions as i list each raid boss or dungeon you wish to target.

If you are not going to be stepping into mythic raiding immediately and will spend
a decent amount of time on heroic, i **Highly** recommend spending your first 3
great vaults on taking voidcores and spending them all on [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
[[item:268265]], [[item:271876]]and [[item:271092]]
are worth substantially more than any other items and would only be replaced when you kill
this boss on mythic.

If you are someone who does not participate in raid content and will be spending bonus
rolls exclusively in dungeons then your first priority should be getting your new tier set bonus.
For this the best choice is [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>) as it has 3 tier slots and 2
non tier slot BiS items, after that you should focus on the dungeon priority listed below.

The raid bosses you will be able to effectively target will be dependant on your guilds current level of progression,
the list below will be ordered by the total amount of optimal loot you can receive.

- **The Venomous Abyss - Ula'tek**: This is a late progression boss that has only four items, you can turn this into 3 by changing your loot spec to Preservation.
  
  - [[item:268265]]
  - [[item:271876]]
  - [[item:271092]].
- **The Venomous Abyss - The Coiled Altar**: This is another late progression boss but with five items, three of which are part of your BiS list.
  
  - [[item:268231]] (Catalyst into tier)
  - [[item:268237]] (Catalyst this into tier)
  - [[item:268253]]
- **The Venomous Abyss - The Lost explorers**: This is a mid tier progression boss that has four items, with two being part of your BiS list.
  
  - [[item:270164]]
  - [[item:268258]]

The rest of the raid bosses are much more weighted towards items you do not need so
i recommend avoiding bonus rolling them unless you have everything else.

The dungeons you want to target will be exclusively based upon what items you are
currently missing and what will give you the biggest gain when getting them on the Mythic 
loot track.

- **Altar of Fangs**: This dungeon has nine total items with four of them being a part of your dungeon bis, including your weapon.
  
  - [[item:273778]]
  - [[item:273792]]
  - [[item:273781]]
  - [[item:273789]] (Catalyst into tier)
- **Temple of Sethraliss**: This dungeon has 10 total items with three of them being a part of your dungeon bis.
  
  - [[item:159388]]
  - [[item:159375]]
  - [[item:158366]]
- **Murder Row**: This dungeon has eight total items with two of them being your dungeon bis, including a trinket.
  
  - [[item:250215]]
  - [[item:251132]]

The rest of the dungeons have a ton of loot you do not want mixed in with the items you do,
as with the raid recommendation i would prioritise the first 2 dungeons before worrying 
about the others.

Use these lists as a basic guide and not the be all end all of what you should be chasing,
remember to sim your character and the upgrades before you commit to spending your bonus rolls as we only 
have a limited amount of them.

3.2.

#### Ascendant Venomstones

Using your [[item:280562]] correctly follows very similarly to what you would do with your crests but with 
one limitation. All gear that drops specifically from the final 2 bosses in Mythic Venomous Abyss can not be upgraded 
even if it is in the correct slot.

1. Your Weapon slots are your highest priority, either a two handed or your Mainhand followed by your Offhand
2. Your trinket slots.
3. Your Neck slot.

With the upgrade cost doubling from last season to now 10 Venomstones, you will want to choose wisely 
what you upgrade to avoid forcing yourself into farming more. Be sure to prioritize your Myth track items over any 
Heroic track with the exception of end boss raid loot such as [[item:270168]] if you are not expecting 
to get the Mythic variant any time soon.

3.3.

#### Best Embellishments for Devastation Evoker

Embellishments are additional effects that can be applied to crafted gear, either as a baseline or 
as an optional reagant when crafting. These can significantly improve the power of a crafted item depending on 
the Embellishment chosen.

You may only have two embellishments active at a time.

These are Devastations best Embellishments being nearly .5% dps better than the closest alternative.

The first embellishment that you will be using is [[item:273060]], a weapon/offhand
craft that will grant you a large amount of a random secondary when it procs making it currently by
far the best Embellishment. The second embellishment is [[item:240167]],an armor craft 
that will spawn a mana wyrm which buffs both you and an ally temporarily increasing your Primary stat.
In the section Below we will break down the crafting choices into two specific categories: Progression based and then your final optimal pieces.

4.

### Best Progression based Crafted Items for Devastation Evoker

Profession gear can be extremely useful to help fill in slots and ensure you are
gearing with the correct stats. Devastation currently prioritises Crit and 
then Mastery/Haste while aiming to avoid Versatility entirely. Additionally, you can use up to two 
embellishments in total between your crafted pieces which further augment 
your DPS!

This section focuses on crafting items in the most optimal order to gain 
immediate, efficient and effective power gains. Some of the items you 
make here will not be a part of your final Best-in-Slot gear list in the 
endgame and will need to be replaced. We will be crafting them anyway 
though as they are an incredibly effective way to get DPS from your 
Sparks and Mistcrests.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Devastation Crafted Gear Priority**
- [[item:245770@JAAKAAgIvYTNbWiViUZM]] with
  [[item:273060]]. Skip this if you get a Mythic Staff. If you 
  get a Myth 1H then it is still correct to make the crafted staff due 
  to crest efficiency.
- Highest upgrade Armour Slot (ideally not tier) with [[item:240167]].
- [[item:244584@JAAKAAgIvYTNbWCYwYlI]] with [[item:240167]],
  removing the Embellishment from your weapon if you are still using a 
  crafted weapon.
- Any item you do not have on Myth track yet.

:::

:::details FAQWhy Craft a Weapon First if it is Not Best-in-Slot?
Weapons are the highest budget slot and scale extremely well with item
    level, so making this item provides the largest boost to your DPS early
    while being Crest efficient. You are effectively spending 80 Mistcrests to
    cover 2 slots worth of power, although you do need to spend 2 crafts worth
    of sparks to get there. This season we have a large number of sparks
    available to start the season with so spending these sparks has low
    opportunity cost.

:::

:::details FAQAny Alternatives to [[item:244584@JAAKAAgIvYTNbWCYwYlI]] with [[item:240167]] for the Second Craft?
You could instead opt to craft in your gloves/belt/boots slots as these slots
    have a higher stat budget than bracers making the crests you spend to craft the items
    give you greater overall value.

:::

:::details FAQWhy Use [[item:240167]]?
We opt to use

[[item:240167]]

as it is currently the
    highest budget embellishment when including the Primary Stat granted to an
    ally.

:::

:::details FAQAny Slots to Avoid Crafting For?
You should try to avoid crafting in Tier Set slots unless you already
    have the full Tier Set. Equipping the full Tier Set is more powerful than
    the crafted item so you would effectively be losing out on a Spark!

:::

4.1.

#### Best Crafted Items for End-Game Devastation Evoker

This section focuses on crafting items that will be permanently equipped 
to your character as they are Best-in-Slot. After that, you should use 
any of your remaining Sparks to get the highest DPS increase possible. 
This is not the most effective way to gear your character at the start of 
a season!

Check out the Progression tab if you want the better path for optimising
efficient crests and sparks.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Devastation Crafted Gear Priority**
- [[item:245769@JAAKAAwt1ENMMYzmlYlI]] with [[item:273060]].
- [[item:244584@JAAKAAwt1ENMMYz_lYlI]] with [[item:240167]],
          Any item you do not have on Myth track yet.

:::

:::details FAQWhy Craft Wrists and Cloak instead of other armor slots?
We are crafting the wrists

[[item:244584]]

because
both Cloak and Wrists are the lowest budget slots meaning we are not significantly
affected by the lower item level of the crafted items while still getting
the full benefit of the Embellishments.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

This is Devastations best Embellishment being nearly .5% dps better than the closest alternative [[item:245876]] making it 
a must have in your BiS gear.

4.2.

#### Adding Sockets to Gear

Sockets can be added to Helmets, Belts and Bracers with 
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if it was acquired in Season 2.

5.

### Crest Usage

Early on in the season your access to crests is going to be severely limited by the weekly cap. 
During this period you will want to be as efficient as possible when spending 
[Myth Mistcrest](<https://www.wowhead.com/currency=3446>) and [Hero Mistcrest](<https://www.wowhead.com/currency=3445>). You can use these 
currencies to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) to higher item levels. We 
suggest taking the time to consider what is both the biggest gain per upgrade and how likely you are 
to replace each item before choosing what to spend your crests on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Devastation Evoker Crest Upgrade Priority**
**Weapon (Mainhand)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

This priority will be correct the vast majority of the time but as always there will be exceptions,
this is often the case for items that have special effects or procs attached to them.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Added Kithix raid loot and Upgrade lists.
- **30 Aug. 2026:** Adjusted BiS lists.
- **10 Aug. 2026:** Added Season 2 Lists.
- **15 Jun. 2026:** Added Rotmire items to BiS list.
- **20 Apr. 2026:** Adjusted trinket section and BiS list.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Removed sections, added Midnight pre season specifics.
- **10 Feb. 2026:** Adjusted gear section removed previous tier section.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Adjusted S3 BiS list and added Dinar section.
- **04 Aug. 2025:** Added S3 BiS lists and Reshii section.
- **21 Jun. 2025:** Adjusted D.I.S.C section.
- **15 Jun. 2025:** Added D.I.S.C section/adjusted BiS list.
- **30 Apr. 2025:** Adjusted Cartel Chip Section.
- **21 Apr. 2025:** Added New Dinar Section.
- **24 Feb. 2025:** Added BiS lists for Season 2.
- **21 Dec. 2024:** Adjusted wording and gems for Cyrces.
- **15 Dec. 2024:** Added Cyrces Circlet information for 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Added Raid and M+ BiS Lists.
- **21 Aug. 2024:** Added pre S1 and S1 BiS lists.
- **23 Jul. 2024:** Reviewed for TWW Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **24 Apr. 2024:** Adjusted trinket information.
- **22 Apr. 2024:** Adjusted tier set information for optimisation.
- **15 Apr. 2024:** Formatting fix and addition to Bullion list.
- **14 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **28 Nov. 2023:** Added specific megadungeon links.
- **12 Nov. 2023:** Adjusted BiS list.
- **12 Nov. 2023:** Added Legguards embellishment now that its no longer reduced value per wearer.
- **07 Nov. 2023:** Added information about Sporecloak nerf and adjusted its position in Embellishment list.
- **06 Nov. 2023:** Removed incorrect sections adjusted BiS lists/Trinket/Embellishments.
- **04 Sep. 2023:** Added new layout for 10.1.7.
- **12 Jul. 2023:** Added Dawn of the Infinite.
- **12 Jul. 2023:** Adjusted trinket list.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5
- **01 May 2023:** Updated for Season 2 (Gear, Embelisments, Tier, Trinkets) and moved Onyx Annulet section to the bottom of the page.
- **20 Mar. 2023:** Added Onyx Annulet Section.
- **03 Feb. 2023:** Updated text for Kharnalex to be more explict on the Mastery benefits the item has.
- **24 Jan. 2023:** Updated trinket list where darkmoon deck has been removed and Voidmenders Shadowgem has been added (with the recent changes in patch 10.5).
- **11 Dec. 2022:** Updated for Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Devastation Evoker. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Devastation Evoker Stat Priority

The general stat priority for Devastation Evoker is:

Item Level

Critical Strike

Haste

Mastery

Versatility

Item Level will typically be better than having optimal secondary stats,
except for Jewelry and Trinkets.

:::details FAQIs There a Haste Cap for Devastation Evoker?
There is no hard cap on Haste for us, but Haste directly ties into how long our

[[spell:375087]]

will last as each time you cast

[[spell:357208]]

or

[[spell:359073]]

the duration will extend. There are no hard breakpoints to guarantee an extra extension, but
more Haste will give you more leniency on making errors.

:::

Something to note is that secondary stats diminish in value per point after 30%,
meaning it takes more secondary stat points to gain 1%. This is
not a goal to aim for, but just something to be mindful of when you start to go beyond
these thresholds. At these points you will see less value per point of secondary stats.
As always, simming your character will give more detailed information on where it is advisable
to change your gear for different secondary stats.

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. You should look for this stat in all
of your upgrades. It provides you with Spell Power, which increases the damage
of your spells.

**Mastery** ([[spell:362980]]) increases the damage of your
spells based on the current health of your target. The higher the health of the
target, the more benefit from [[spell:362980]] you get. You will
automatically get the full benefit from [[spell:362980]] during [[spell:375087]]
when the [[spell:376888]] talent is picked.

**Critical Strike** increases your chance for your abilities to deal
200% damage. This is increased to 220% when the [[spell:370845]] talent is
picked.

**Haste** increases your spell casting speed (including Empowered Spells)
and the tick rate of your periodic effects.

**Versatility** increases all your damage and healing done, and decreases
all damage taken.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Adjusted stats for Season 2.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Minor adjustment to Stat prio for Midnight.
- **10 Feb. 2026:** Removed outdated talent.
- **30 Nov. 2025:** Added Faqblock.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for TWW.
- **23 Jul. 2024:** Reviewed for TWW Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **12 Nov. 2023:** Adjusted secondary stat listings.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **21 Dec. 2022:** Updated stat priority to lower the value of Critical Strike.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Devastation Evoker, based on your [stat priority](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

The best stats for Devastation Evoker is Crit and Haste, so
that is what we will be gemming for.

You should use [[item:240967]] in one socket. Then, you
should ensure you have one gem of each type in other sockets to max out the
Critical damage effect, ideally [[item:240906]], [[item:240890]],
[[item:240898]], and [[item:240914]]. Fill in the
remaining sockets with [[item:240906]].

2.

### Best Enchants and Weapon Augments

You should be using [[item:243733]] at all times.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;<tr>&#10;<td>Helm</td>&#10;<td>[[item:244007]]</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:243991]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240133]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</tr></table>

3.

### Optimal Consumables

Consumables such as Flasks, Food, Potions, even Oils can increase your power by
a noticeable margin and are worth utilizing anytime you are doing challenging
content. If gold isn't a concern, you can choose to always use them!

3.1.

#### Flask

You should use one of these two flasks depending on what your lower stat is.

- [[item:241325]] - If you need more Haste
- [[item:241326]] - If you have very low Crit

3.2.

#### Combat Potion

The combat potions that we will be using throughout Midnight is [[item:241288]] or
[[item:241292]]. Potion of Recklessness will increase your highest secondary whilst 
also decreasing your lowest, you can have 0 Versatility on your gear set meaning you can entirely negate 
the negative part of this potion.
Rampant Abandon grants a large amount of Intellect but will randomly spawn circles underneath your feet
that will pacify you, there is a 1.5 second grace period after these spawn where you can move out of them
without getting silenced making this potion great for Devastation.
will not occur.

3.3.

#### Food Buff

As a Devastation Evoker you will want to use the best primary stat food 
  available to you. Currently this would be the [[item:255845]] feast 
  if available. If the feast is not available, or if the secondary stat feast is 
  placed, then you should use [[item:242275]] personal food.

3.4.

#### Augment Rune

You should use an Augment Rune if you can afford it during Progression, especially when 
  you get close to a kill. It provides a sizeable boost to Intellect. We do not 
  recommend using at all times, as they are often quite expensive. Using the current best 
  rune is approximately a 1% DPS gain. For Season 2 the following Augment
  Rune is available:

- [[item:259085]]

3.5.

#### Healing Potions

Season 2 brings a more powerful healing potion [[item:271883]] 
you will want to use this instead of the weaker version.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Season 2.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Added Midnight enchants/consumables.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Removed Corruption and added new Health pot.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Added Corruption section and Helmet enchant.
- **24 Feb. 2025:** Reviewed for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed and Adjusted for TWW.
- **23 Jul. 2024:** Reviewed for TWW Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Removed changed flask and enchant wordings.
- **14 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **17 Jan. 2024:** Adjustment for Potions and Wafting Devotion.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Added Incandescent helm enchant for 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Added belt enchant (new for Patch 10.1).
- **25 Mar. 2023:** Updated Primordial Gems recommendations.
- **20 Mar. 2023:** Added Onyx Annulet Gem Section.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Devastation Evoker in World of Warcraft Patch 12.1.5.

1.

### Devastation Evoker in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Evoker in
Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

2.

### Best Mythic+ Talent Builds

Due to the current state of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander being so far ahead in
all aspects of DPS, it is HIGHLY recommended that you avoid Flameshaper in
keys at all levels. Scalecommander has substantially better Single-Target/Cleave,
and only loses out at extremely high target counts.

### Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/scalecommander.webp>) Scalecommander

This tree will serve as the best build for all keys, as it sacrifices next to no ST DPS
for a very substantial cleave and AoE gain in the form of [[spell:375757]]. If you 
want to push for a high AoE damage build you can take both points out of [[spell:371038]]
to put both into [[spell:369089]] or 1 into [[spell:370455]], Charged Blast 
is very slightly better than Volatility but requires you to actively play around it in order
to maximize its value.

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZgZYGzMgBjZamZmpZmx2MMzMzMzMzAmxMGzMLzMDMwYwGsMGN2GAzAwGGYmBDD"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscRRFLLbZYYluqqPkkoXpjWEfenrVmCHA-jNiMhDgCCfUJJeeVTR6ie4w2gA0cKzA-AAAA-TIQaAUGYEE84iB-
```

:::

### Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) Flameshaper

This tree can be used for Flameshaper weekly keys. It can be played at a somewhat
similar level to Scalecommander, but is weaker overall due to much less flexibility
in where you can spend your talent points. If you want to focus on single-target, it is going to
cost a fairly substantial amount of AoE, and vice versa. We would therefore
only recommend playing this if you really enjoy the Flameshaper playstyle.

:::talents 天赋构筑
```json
{
  "code": "CsbBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAz8ADmZMzwMwMYMTjZmJjxyMzMzwYmZGwMmZGzMLzMDmBmxMwCYDMDTgNwywAYmZYA"
}
```
:::

:::details 来源计算器编码
```
#7W-SUscRRFLLbZKYYluqqPkkoXpjWegEfnrhmA-jNiMDhLLgBCfUJJVTQ6iewOuA0ILzsA-AAAA-Iqkk5wQoBoYwSA-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns, and Stops

3.1.

#### Interrupts

[[spell:351338]] is your "kick" and your most important bit of utility in
Mythic+. Use to stop enemy casts for the benefit of the group, especially
the tank. It is **highly recommended** to use a Focus Kick macro for this.

#### Quell Macro

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Quell
```

This macro will:

- Kick your focus target, if you have one
- Kick the Mouseover target, if you have no Focus target
- If you have neither of those, Kick the target based on Blizzard's default targeting

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

#### Focus Mouseover

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly. This way, you
are always able to kick on cooldown or in coordination with the rest of your
group.

3.2.

#### Stuns and "Stops"

Devastation has three main AoE stop abilities.

[[spell:357210]] is a 3-second stun on a very 
short cooldown when talented into [[spell:371032]].
We do not hold this to use as a stop, as it is part of our 
core dps rotation. However, it provides a lot of free crowd control.

[[spell:357214]] will knock enemies in front 
of you back, interrupting spells and repositioning mobs.

[[spell:307974]] will knock enemies around you up 
into the air and slightly away from you. This is useful for interrupting 
groups of casts.

### Other Utility

3.3.

#### Other Utility

[[spell:370665]] can help reposition yourself — as well as an ally
— while also providing a short duration cast while moving buff to you and 
your Rescue target when talented into [[spell:370888]].

[[spell:374968]] allows your entire party an additional 
use of their movement-based abilities, ours being [[spell:358267]] 
this can be very helpful when needing to move through areas quickly.

4.

### Dealing with Affixes

Season 2 of Midnight only has four significant Affixes that offer any kind
of counterplay: Xal'ataths Bargains. These rotate every week, with only
one of them being active at a time. Many of the Mythic+ affixes, like Fortified or
Tyrannical, simply add a passive effect to the keystone, with these four exceptions
that are seasonally themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. [[spell:357214]] and [[spell:307974]] work great here.
  [[spell:357210]] will also naturally get some when used as part of your DPS rotation.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn that
  needs to be focus-targeted and interrupted. If you know this is happening,
  make sure to pool Essence to get ready to burst it.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and circle
  around them. You have 15 seconds to soak all of these to buff your group. [[spell:360995]] will instantly 
  jump you to an ally allowing you to soak their orb instantly.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb. You can remove this with [[spell:365585]] and [[spell:374251]].

When resolved, each of these affixes provides your group with a buff. Dealing with them correctly 
will speed up your dungeons and prevent the enemy trash and bosses from receiving the buffs instead.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Added new season 2 Talent trees.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Added new talent trees.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **30 Apr. 2025:** Added boss specific tips for dungeons where relevant.
- **21 Apr. 2025:** Adjusted build for high end m+.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Added more info to mythic+.
- **09 Sep. 2024:** Section added for Season 1 TWW.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated talent tree for patch 10.1.5.
- **01 May 2023:** Updated talent tree for Patch 10.1 and affix information for Season 2.
- **30 Mar. 2023:** Talent fix.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **12 Dec. 2022:** Updated M+ Tips for affixes and utility list.
- **11 Dec. 2022:** Updated M+ talent tree.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Devastation Evoker in World of Warcraft Patch 12.1.5.

1.

### Best Macros

1.1.

#### Emerald Blossom on Mouseover

This macro will cast [[spell:355913]] on your mouseover target; if
they are not a friendly target (or a dead friendly target) it will cast on yourself
instead.

#### Emerald Blossom Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Emerald Blossom
```

1.2.

#### Rescue on Mouseover

This macro will cast [[spell:370665]] on your mouseover target; if
they are not a friendly target (or a dead friendly target) it will attempt
to cast it on your current target instead.

#### Rescue Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Rescue
```

1.3.

#### Verdant Embrace on Mouseover

This macro will cast [[spell:360995]] on your mouseover target; if
they are not a friendly target (or a dead friendly target) it will cast on yourself
instead.

#### Verdant Embrace Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Verdant Embrace
```

1.4.

#### Cauterizing Flame on Mouseover

This macro will cast [[spell:374251]] on your mouseover target; if
they are not a friendly target (or a dead friendly target) it will cast on yourself
instead.

#### Cauterizing Flame Mouseover

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] Cauterizing Flame
```

2.

### Specific Macros for Devastation Evokers

2.1.

#### Fire Breath with Trinket on Shift

This macro will cast Fire Breath as normal when you press it, but if you
press shift it will use your first trinket slot (slot 13, change to 14 for
second trinket slot) and then cast Fire Breath in the same GCD.

#### Fire Breath with Trinket on Shift

```wow-macro
#showtooltip Fire Breath
/use [mod:shift] 13
/cast Fire Breath
```

3.

### Best Addons

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

3.1.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

3.2.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

3.2.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

3.2.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

3.2.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

3.3.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

3.3.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

3.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

3.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Rewviewed for TWW Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **15 Nov. 2022:** Page added.

Show more

Show less

:::
