## 专精概览

欢迎来到我们的《魔兽世界》12.1.5补丁 邪恶 死亡骑士 指南。在这里，你将学习如何在团队副本和大秘境地下城中作为 邪恶 死亡骑士 进行游戏：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

邪恶 大秘境资源

[全新！顶级 邪恶 天赋构建](<https://raider.io/specs/unholy-death-knight/talents>)

[顶级 邪恶 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/death-knight/unholy>)

[邪恶 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=death-knight--unholy>)

[热门 邪恶 团队组合](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=death-knight--unholy>)

1.

### 邪恶 死亡骑士 概述

邪恶 死亡骑士 利用瘟疫和召唤的亡灵仆从造成高额单体伤害。我们的AOE依赖于宠物顺劈、二次方 [[spell:207317]] 伤害、疾病和 [[spell:55090]] 顺劈。我们的核心循环涉及保持我们的持续伤害效果、召唤大量亡灵仆从，以及使用在远程非常有效的攻击造成直接伤害。我们也是游戏中最肉的职业之一，这在所有PvE内容中都非常有用！

爆发良好，远程灵活

邪恶 死亡骑士 的伤害曲线侧重于每1.5分钟一次的大爆发窗口，以及每45秒一次的小爆发。它拥有从远程造成良好伤害的出色能力，但在切换目标时会有些吃力，因为宠物需要移动过去并施加瘟疫。我们拥有强大的斩杀能力，并在

[[spell:2825]]

在首领生命值低于35%时使用。

单体强劲，远程灵活

邪恶 死亡骑士 是团队副本中拥有高单体伤害的可靠选择。我们良好的斩杀能力、生存能力和远程有效性使我们成为优秀的DPS选择。我们有死亡之握，在非常特定的战斗中很好用，但缺乏合适的团队增益。

伤害与生存兼备

邪恶 死亡骑士 在大秘境中造成良好的单体伤害，并辅以良好的AOE。我们依靠高伤害输出在大秘境中获得一席之地，因为我们的团队功能性通常不足。

[[spell:49576]]

和

[[spell:51052]]

虽然不错但还不够。尽管如此，我们高生存能力是一个不错的优势，只要我们的伤害具有竞争力，它确实能让我们推进非常高的层数。

表现不佳

邪恶 死亡骑士 缺少大量非常有用的实用技能。我们拥有

[[spell:49576]]

，这有时非常有用，但除此之外我们缺乏强大的团队和小队增益。

[[spell:51052]]

是一个不错的防御性魔法冷却技能，而且我们确实有配合

[[spell:207167]]

的打断。然而与其他职业相比，除非我们的死亡之握是某个特定战斗的硬性要求，否则我们不会因为强大的实用技能而被带上。

顶级生存能力

邪恶 死亡骑士 可以说是游戏中最好的防御专精，与 冰霜 死亡骑士 并列。

[[spell:206967]]

,

[[spell:48263]]

,

[[spell:391571]]

和

[[spell:454842]]

只是我们众多被动防御天赋中的一小部分。此外，我们还有

[[spell:49998]]

，在我们陷入困境时可以轻松地将我们治疗回来，使我们即使在最可怕的情况下也能存活下来。毫不意外，邪恶 死亡骑士 在团本中所有输出专精里死亡次数排名第4少。

相当缓慢

邪恶 死亡骑士 因缺乏机动性而相当出名。它历来是一个非常缓慢的专精，更注重避免位移，而非快速移动。然而，邪恶 有选择使用

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士

来获得

[[spell:444010]]

的选项，显著增加了我们的机动机会。这对专精的整体机动性产生了巨大影响。邪恶 不在最顶端，但也不在最底端！

1.

### 邪恶 死亡骑士 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5 版本对 邪恶 死亡骑士没有任何改动，但这并不意味着没有新内容可用。作为赛季中期的补丁，它的新内容确实有点少。但别担心，仍然有新的团队副本；新的基图伊克斯战斗，以及对于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 来说，还有全新的迷宫巨型地下堡！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

随着全新的基图伊克斯团队副本和迷宫巨型地下宝库的推出，它们为 邪恶 死亡骑士提供了新的装备来源。基图伊克斯掉落的物品极其强大，人人都在追求。除此之外，在10月20日这些内容上线后，我们还可以使用[[item:280562]]来升级我们的武器、饰品和项链。

2.3.

#### 职业改动

12.1.5 版本到目前为止对 邪恶 DK 没有任何改动。

因此，我们的
[天赋](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>) 推荐和
[输出循环](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>) 优先级没有任何变化。不过新团队副本和迷宫地下堡提供了新的装备推荐，详见我们的
[装备](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>) 页面。我们还提供了一份高价值物品清单，供你决定如何花费你的第一批[[item:280562]]。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_unholypresence.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1版本职业平衡调整 隐藏12.1版本职业平衡调整
- **邪恶 12.1 改动**
  
  
  
  
  邪恶 在12.1补丁中获得了大量改动，我们的技能和天赋都经过了重大调整。我们已在下面总结了这些改动，并重点标出了最重要的部分：
  
  
  
  
  - [[spell:42650]]已被重做。它最初召唤八个[[spell:275430]]，但在30秒持续时间内会改变我们所有新的[[spell:275430]]召唤。每当我们本应召唤一个食尸鬼时，现有的8个食尸鬼会改为施放[[spell:1294264]]（单体目标）或[[spell:1300330]]（AOE）。这在不改变玩法的情况下显著降低了我们的最大召唤数量。
  - [[spell:210128]]已更名为[[spell:1256813]]。当你控制3个[[spell:390196]]时，牺牲它们以召唤一个[[spell:1256813]]，持续15秒，施放连锁的冰霜闪电。这是一个有趣的新宠物，强调堆叠[[spell:390196]]的生成。
  - [[spell:343294]]现在消耗最多三层[[spell:1254252]]，而不是[[spell:1247378]]的层数。将[[spell:1247378]]的使用恢复为仅限于技能本身，简化了使用方式并避免了尴尬的情况（比如因为你当时不想使用[[spell:343294]]的层数而捏着[[spell:1247378]]不放）。
  - [[spell:1240996]]在切换到新目标时现在会保留其持续时间，使其传播更加流畅。此外，瘟疫持续时间的延长效果被略微削弱。
  - [[spell:434237]]的自动攻击伤害提高了1400%，这里没有重大影响，但这个数字确实大得惊人。
  - [[spell:390259]]不再根据[[spell:77515]]来延长次级食尸鬼的持续时间。
  - 暴风雪试图重新分配我们的伤害以降低对冷却技能的依赖，但未能成功做到这一点。
  
  
  
  
  总的来说，邪恶获得了一个新的召唤物以及略微重做的伤害分布。[[spell:343294]]的改动对你的输出循环优先级影响最大，因为它的使用现在与你的[[spell:1247378]]优先级脱钩了。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜 中 邪恶 死亡骑士 的改动

邪恶 死亡骑士 在 至暗之夜 中经历了一次重大重做。自军团再临以来一直是专精核心的[[spell:197147]]现已移除，取而代之的是以召唤随从为核心的游戏循环。我们的瘟疫受到了更多重视，新增了一种名为[[spell:1240996]]的纯单体疾病，以及天赋中更多的疾病互动。我们的AOE现在与[[spell:43265]]脱钩，转而通过标准的[[spell:55090]]进行被动顺劈。最后，我们有一个新的核心循环技能[[spell:1247378]]，我们用它来召唤和牺牲食尸鬼。

邪恶 死亡骑士 的手感在某些方面与之前的资料片相似。我们保持了[[spell:85948]]、[[spell:55090]]和[[spell:47541]]的核心循环，但现在还会时不时按下[[spell:1247378]]。我们的AOE循环变化最大，因为它现在与我们的单体循环非常相似。引入了[[spell:1271974]]（现在是[[spell:1271974]]），它创造了一个基于我们瘟疫持续时间的巨型爆发按钮。总的来说，输出循环变得更简单了，技术表达的机会也更少了。

2.5.

#### 新顶点天赋

我们在专精天赋树中获得了三个新天赋，可以在从80级升到90级时点出。这些天赋通常非常强大，显著增强[[spell:42650]]，并在你的[[spell:1240996]]跳动时自动发出[[spell:1247378]]。

2.5.1.

##### 腐化

[[spell:1247378]]召唤一个次级食尸鬼扑向你的目标，造成直接伤害然后爆炸造成AOE伤害。我们有几个新天赋以各种方式增强这种互动：

- [[spell:1241858]]使你的永久食尸鬼在你施放腐化时暂时造成更多伤害（多个效果可以叠加）。
- [[spell:1254552]]使腐化的爆炸效果延长你的瘟疫持续时间，并立即将疾病在该持续时间内本应造成的部分伤害结算。还会将我们的瘟疫应用于未受影响的目标——与我们的瘟疫有很好的协同作用，是瘟疫持续时间延长和施加的来源。这个技能大大减少了我们通常使用的[[spell:77575]]数量。
- [[spell:210128]]将你腐化的食尸鬼复活为一个[[spell:390196]]。还会增加我们法师
  
  
  - 的主要召唤来源和伤害提升。
- [[spell:377580]]给予你一层额外的腐化充能并提高其伤害——额外的充能提供了一些很好的灵活性，使你既能更有效地使用该技能，又能以更像爆发的方式消耗充能。例如，配合[[spell:210128]]，你可以在你的[[spell:63560]]期间召唤两个亡者魔导师，造成不错的AOE爆发。
- [[spell:276023]]在你用[[spell:55090]]召唤食尸鬼时减少[[spell:1247378]]的冷却时间。
- [[spell:343294]]自动消耗所有[[spell:1247378]]层数并使用它们。这实际上消除了在斩杀阶段需要施放腐化的需求。
- [[spell:1271974]]使用时给予一层腐化充能。

所有这些互动使[[spell:1247378]]成为一个重要的法术，对你的伤害有巨大影响。

2.5.2.

##### 溃烂之伤的移除

[[spell:197147]]现在已完全从邪恶 死亡骑士中移除。[[spell:85948]]现在不再对敌人施加减益效果，而是对你施加增益[[spell:1254252]]（每次脓疮打击2-3层，最多叠加8次）。这些层数被[[spell:55090]]消耗，召唤一个次级食尸鬼。这在换目标和准备阶段有显著帮助，因为当你更换目标时，你自己身上的层数会保留。此外，随着我们召唤大量亡灵随从，我们更能体验到死灵法师的幻想。随着溃烂之伤的移除，我们也失去了一些标志性技能，如[[spell:207289]]和[[spell:275699]]。

2.5.3.

##### 瘟疫

至暗之夜引入了[[spell:1240996]]瘟疫，通过我们的[[spell:77575]]或[[spell:1247378]]配合[[spell:1254552]]施加，它只对一个敌人造成伤害（可以通过天赋点出[[spell:390283]]以降低效果对第二个敌人造成伤害），并且是我们新的[[spell:49530]]触发来源。当它附着的目标死亡时，它还有一个有趣的互动，触发爆炸并将瘟疫传播到新目标。这使得瘟疫在AOE中很容易保持，并呈现出一些有趣的场景，你会得到连锁反应效果，大量敌人接连死亡。

天赋树中还有更多与瘟疫互动的天赋。[[spell:47541]]和[[spell:207317]]现在默认延长[[spell:191587]]和[[spell:1240996]]的持续时间。[[spell:55090]]根据你的瘟疫造成额外伤害，[[spell:455397]]现在提高瘟疫跳动频率，新的[[spell:1254552]]天赋延长持续时间并根据你的瘟疫伤害造成伤害。我们有一个新的[[spell:1271974]]天赋与我们的瘟疫互动，允许你消耗它们以造成剩余伤害100%的巨额爆发。当我们按下[[spell:63560]]时，你的下一个[[spell:77575]]会变成这个瘟疫技能。你会得到这样的游戏循环：施放黑暗突变，尽可能延长你的瘟疫持续时间，然后消耗它们造成巨额爆发伤害。特别是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因能通过[[spell:434143]]的瘟疫持续时间延长有效地做到这一点。

2.5.4.

##### AOE 重做

至暗之夜见证了[[spell:207311]]天赋的重做，不再提供射程（[[spell:55090]]现在默认为30码），而是成为我们的AOE启动器。每当我们使用天灾打击时，我们简单地顺劈到一个额外的目标，最多4个（配合[[spell:1242604]]为6个）额外目标。这完全不需要[[spell:43265]]。不再有坦克走出你地面AOE的烦恼，你可以直接跟上去持续造成大量伤害。缺点是我们在AOE中具有自然的预热性质，理想情况下你需要连锁拉怪来保持层数（它们只持续12秒）。这在配合 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因时不是问题，它通过[[spell:1280658]]天赋立即获得最大层数。

我们还获得了新的[[spell:1241705]]技能，它使我们的次级食尸鬼在[[spell:63560]]期间获得爪击范围攻击能力。这是我们宠物的一个很好的额外AoE组成部分，以前这是专属给我们的法师和主要宠物的。它使[[spell:42650]]成为一个更强的AoE冷却技能，因为次级食尸鬼的召唤，并赋予[[spell:327082]]更多AoE价值！

[[spell:43265]]在AOE中处于一个奇怪的位置，我们的技能组中几乎没有剩余的互动。它在非常大的拉怪中造成尚可的伤害，并且与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因（通过[[spell:1234559]]和[[spell:434033]]）仍有一些协同作用。此外，我们现在有一个配合[[spell:1282565]]的天赋，当你使用[[spell:455397]]时会自动施放它。然而总的来说，无论天赋选择如何，按下它都不值得。它现在主要具有[[spell:273952]]的实用价值。

2.5.5.

##### 远程有效性

在 至暗之夜 中，我们从远程位置有效得多。[[spell:55090]]默认为30码，我们失去了很多以前从留在近战范围中获益的天赋。[[spell:49530]]现在由[[spell:1240996]]命中触发，而不是近战攻击，[[spell:377440]]现在基于你的随从召唤运作。我们只需要进入近战范围打出[[spell:85948]]，然后就可以跑动几秒钟而只损失极小的伤害。我们确实失去了近战挥击（我们伤害的2%），并且我们的宠物被召唤时需要跑得更远一些。除此之外，我们可以在任何战斗的相当大一部分时间里假装自己是远程职业。

2.6.

#### 英雄天赋

我们的英雄天赋各获得了三个新天赋。这些天赋通常影响不大，与我们过去的一些套装奖励类似。

2.7.

#### 职业树改动

死亡骑士职业天赋树也看到了一些小改动。[[spell:337957]]、[[spell:1266818]]和[[spell:1266819]]都被添加了。一些不错的防御技能，以及一个点出[[spell:48743]]的前置（这是非常需要的，否则我们从不点这个天赋）。[[spell:343294]]已移至专精天赋树并被重做以增强我们的随从和瘟疫，[[spell:327574]]则被完全移除。

我们还对天赋树中的一些节点位置进行了调整。[[spell:276079]]作为与[[spell:221562]]的选择节点处于一个好得多的位置。[[spell:212552]]在天赋树中上移了更多，现在与[[spell:391546]]互为选择。[[spell:374265]]现在也是一个2点天赋。总的来说，我们能更多地接触到某些天赋，天赋树中也有了更多选择。[[spell:49998]]和[[spell:389682]]被略微削弱，所以我们失去了一些防御能力，但总体而言并不算多。

1.

### 邪恶 死亡骑士 玩法基础

邪恶 死亡骑士 是一个关于管理你的资源并通过正确的冷却管理来最大化你爆发潜力的专精。这个专精专注于通过如[[spell:77575]]等法术对敌人造成强大的持续伤害，同时积攒一支[[spell:42650]]来歼灭敌人。

邪恶的玩法围绕着增益管理、正确的资源使用和持续伤害的覆盖率展开。这三个关键点可以描述如下。

- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_festeringscythe.jpg>)
  **保持你的增益**
  
  
  
  
  确保保持你的[[spell:455397]]增益（通过按下[[spell:85948]] → [[spell:455397]]）。此外，管理你的[[spell:1254252]]层数，确保你永远不会在0层时[[spell:55090]]。用[[spell:85948]]构建层数，用[[spell:55090]]消耗。
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_runic_corruption.jpg>)
  **资源管理**
  
  
  
  
  邪恶有两种资源：符文和符文能量。管理它们对于最大化你的DPS和避免资源枯竭至关重要。优先消耗你的符文（始终保持三个在回复中），然后避免符文能量溢出。
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_dread_plague.jpg>)
  **瘟疫覆盖率**
  
  
  
  
  邪恶拥有强大的瘟疫，我们会将它们施加到目标身上。保持这些瘟疫始终存在至关重要，尤其是[[spell:1240996]]。它们是你伤害的主要来源，无论直接还是间接。

1.

### 作为 邪恶 死亡骑士 如何获取装备

虽然我们始终建议你自己进行模拟以获得理想结果，但我们确实提供了专门的邪恶配装页面。我们目前涵盖了第二赛季装备的推荐，以便在至暗之夜终局内容发布时有一个良好的开端。在你获得一些装备后，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 针对12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 针对12.1.5进行了更新。
- **2026年10月5日（本页）：** 在凋零瘟疫削弱后调整性能评级。
- **2026年9月30日（本页）：** 在凋零瘟疫修复后调整性能评级。
- **2026年9月25日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 将默认天赋选择更新为包含灵魂收割。
- **2026年9月23日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 将默认选择更新为萨莱因。
- **2026年9月23日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 将推荐的单体团本构建更新为萨莱因。
- **2026年9月23日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 将推荐构建更新为凋零瘟疫。
- **2026年9月8日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 更新建议施放脓疮打击的层数。
- **2026年9月8日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 修复宏描述顺序。
- **2026年9月8日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 从精通中移除亡者指挥官的互动，这些在12.1中已被移除。
- **2026年9月8日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 针对12.1补丁进行了审查。
- **2026年9月8日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 根据热修复更新优先级列表。
- **2026年9月8日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 移除亡者指挥官的精通互动，这在12.1中已被移除。
- **2026年9月8日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 根据瘟疫和墓地目标数量的变化更新循环。
- **2026年9月8日（本页）：** 将亡者指挥官的改动添加到12.1改动中。
- **2026年9月7日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 热修复后审查并更新了装备。
- **2026年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 将推荐的大秘境构建更新为萨莱因随从流。
- **2026年9月4日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 将推荐的单体团本构建更新为骑手流。
- **2026年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 将新手团本构建更新为骑手流。
- **2026年8月25日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 澄清了凋零瘟疫的使用方法。
- **2026年8月24日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 更新为推荐凋零瘟疫构建。
- **2026年8月24日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新为推荐萨莱因。
- **2026年8月24日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 团本和大秘境更新为萨莱因。
- **2026年8月20日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 所有内容更新为凋零爆发。
- **2026年8月20日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 所有内容更新为凋零爆发。
- **2026年8月20日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 所有内容更新为凋零爆发。
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 新增了最佳制造物品章节。
- **2026年8月13日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 扩展了饰品梯队列表。
- **2026年8月13日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了凋零瘟疫的使用方法。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已根据12.1版本的毕业装备和饰品进行更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已为12.1补丁更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已用12.1版本构筑进行更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已用12.1版本构筑进行更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已根据12.1版本的改动进行更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年7月29日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已为12.1补丁更新，加入了灵魂收割者的使用说明。
- **2026年7月29日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年7月29日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 针对12.1补丁进行了审查。
- **2026年7月29日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已根据12.1版本的改动更新了输出循环。
- **2026年7月29日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已为12.1补丁更新，加入了新的输出循环和起手式。
- **2026年7月29日（本页）：** 已根据12.1版本的改动进行更新。
- **2026年7月8日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了在AOE场景中的符文能量优先级。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已根据12.0.7版本更新，加入了孢子化装备。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 将默认药水更换为鲁莽。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已为12.0.7版本更新。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已为12.0.7补丁更新，加入了全能属性的选择。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（本页）：** 已根据12.0.7版本的改动进行更新。
- **2026年6月6日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 更新了大秘境天赋配置，点出了食尸鬼狂乱。
- **2026年6月6日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了符文能量与符文的优先级。
- **2026年6月6日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋配置，点出了食尸鬼狂乱。
- **2026年6月6日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 更新了在大秘境天赋配置中使用食尸鬼狂乱。
- **2026年5月24日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 修正了一处装备掉落位置的笔误。
- **2026年5月20日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 根据新的毕业装备列表格式修复了符文锻造内容。
- **2026年5月2日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 澄清了凋零的使用方式。
- **2026年4月28日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 更新了推荐的戒指附魔。
- **2026年4月28日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 更新了大秘境天赋配置，点出了死亡循环。
- **2026年4月28日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新了大秘境和团队副本的天赋配置。
- **2026年4月28日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 更新了大秘境天赋配置，点出了死亡循环。
- **2026年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 将大秘境天赋配置从憎恶更换为其他天赋。
- **2026年4月22日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新为在团队副本使用血性狂乱，在大秘境不点憎恶。
- **2026年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 更新为在团队副本使用血性狂乱，在大秘境不点憎恶。
- **2026年4月21日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 澄清了凋零的使用方式和符文能量的优先级。
- **2026年4月21日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 将团队副本天赋更换为石像鬼。
- **2026年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 将团队副本天赋更换为石像鬼。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 根据新的12.0.5天赋树更新了升级天赋。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 添加了新的涡轮加速物品。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对12.0.5进行审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对12.0.5进行审阅。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 更新了12.0.5版本的毕业属性分配。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 更新了12.0.5补丁的天赋配置。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已根据12.0.5版本的改动更新了输出循环。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 针对12.0.5更新了天赋。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已根据12.0.5版本的改动进行更新。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 更新了12.0.5版本的天赋和起手式。
- **2026年4月20日（本页）：** 已根据12.0.5版本的改动进行更新。
- **2026年4月10日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 澄清了药水的使用方式。
- **2026年4月10日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 澄清了鲁莽的价值。
- **2026年4月6日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新了天赋推荐的措辞，并增加了更多鲜血盟约相关内容。
- **2026年4月2日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 更新天赋配置为点出2个亵渎者，而非食尸鬼之爪。
- **2026年4月2日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新天赋配置为点出2个亵渎者，而非食尸鬼之爪。
- **2026年3月29日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 移除了单键助手的主要冷却时间功能。
- **2026年3月29日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 移除了单键助手的主要冷却时间功能。
- **2026年3月28日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 解决了最佳项链来源的一个问题。
- **2026年3月22日（本页）：** 添加了首个英雄难度周的削弱和增强信息。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已为至暗之夜第1赛季更新，加入了新的天赋配置。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已为第1赛季更新，加入了新的毕业装备和饰品推荐。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 更新了食物推荐，并添加了茶类。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 对最佳属性分配进行了小幅更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已为至暗之夜第1赛季更新，加入了新的天赋配置和词缀提示。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 添加了套装部分。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新了团队副本天赋，点出了邪恶狂乱。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月12日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已为至暗之夜第1赛季更新，加入了死亡之握宏。
- **2026年3月12日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已为至暗之夜第1赛季更新，加入了新的天赋配置。
- **2026年3月12日（本页）：** 已为至暗之夜第1赛季更新，加入了新的评分和第1赛季的改动。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 添加了80级构筑。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已为至暗之夜更新，加入了新的天赋。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已为至暗之夜更新，加入了赛季前的毕业装备。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已为至暗之夜更新，加入了新的宏复制内容。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已为至暗之夜更新，加入了新的附魔、宝石和消耗品。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已为至暗之夜更新，加入了新的属性分配示例。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已为至暗之夜更新，加入了新的最佳天赋配置。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已为至暗之夜更新，加入了新的天赋配置、输出循环和终极天赋说明。
- **2026年2月26日（本页）：** 已针对至暗之夜进行更新。
- **2026年2月13日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对至暗之夜进行更新。
- **2026年2月11日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新为在团队副本中推荐天启骑士。
- **2026年2月11日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 在单体目标中更换为天启骑士。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 更新为在2个目标时使用死亡缠绕。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已为至暗之夜前夕更新，将毕业装备调整为符合新的属性优先级，并加入了午夜升级物品。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 添加了关于大秘境中天启符文的说明。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 根据新的鲜血盟约天赋配置更新了属性权重。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 更新了12.0.1版本的天赋配置。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已为12.0.1补丁更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新了12.0.1版本的天赋，点出了鲜血盟约。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 更新了12.0.1版本的起手式。
- **2026年2月10日（本页面）：** 添加了12.0.1版本的改动。
- **2026年2月2日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 在起手式中加入了一次死亡缠绕。
- **2026年2月2日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 在起手式中加入了一次死亡缠绕。
- **2026年1月25日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新为在2个目标时使用死亡缠绕。
- **2026年1月22日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 更新了宝石和戒指附魔的推荐。
- **2026年1月22日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新了团队副本和大秘境的天赋。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已为至暗之夜更新，更换了最佳符文锻造，并加入了升级用消耗品。
- **2026年1月19日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（本页）：** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 为11.2.7补丁更新。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已为11.2.7补丁进行审查和更新，将棱彩提升到饰品梯队列表的更高位置。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 添加了急速常见问题解答。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已为11.2.7补丁进行审查和更新。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已为11.2.7补丁进行审查和更新，主要修复了语法问题。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对11.2.7补丁进行审核和更新。
- **2025年11月30日（本页面）：** 已更新，加入了新的优势与劣势部分以及11.2.7的更新内容。
- **2025年11月28日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 在输出循环页面添加了常见问题解答。
- **2025年10月28日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 修复了一个失效的优先级列表，并更新了部分措辞。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 为11.2.5补丁更新。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 新增可疑的卡特尔筹码。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 为11.2.5补丁更新。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 已为11.2.5版本更新。
- **2025年9月14日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式。
- **2025年9月7日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 修复了一个饰品的错别字和列表问题。
- **2025年9月7日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 澄清了在伤口层数饱和时使用收割的时机。
- **2025年8月25日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了死亡缠绕与传染的目标数量。
- **2025年8月18日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 在2目标顺劈时，将牺牲的第一个点数换为鲜血圣印。
- **2025年8月14日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业饰品。
- **2025 年 8 月 10 日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 添加了天启骑士疾病天赋配置。
- **2025 年 8 月 10 日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 添加了天启骑士疾病天赋配置。
- **2025年8月7日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 修复漏洞后更新了天启的使用方式。
- **2025年8月7日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 修复漏洞后更新了天启的使用方式。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 11.2重做后更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 为11.2版本更新。更新了毕业装备，新增了披风和新饰品。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 为11.2版本更新，大幅提高了暴击的属性价值。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 随11.2版本更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为11.2版本更新。改进了选择框，新增了天赋并更新了输出循环。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 随11.2重做更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 添加了11.2的改动。
- **2025年6月27日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 进行了少量措辞更新。
- **2025年6月27日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 将溃烂之触部分移至输出循环板块，并改进了一些关于伤口和符文能量的措辞。同时添加了毕业装备的使用方式。
- **2025年6月27日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 重新组织了页面以提高清晰度。
- **2025年6月27日（本页）：** 修复了图片板块无法正常显示的问题。
- **2025年6月23日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 在调整后更新了最佳D.I.S.C.效果。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 添加了D.I.S.C.腰带。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 移除了头盔附魔的免责声明。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 修正了错别字并阐明了属性优先级。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 将天赋添加到图片板块中以提高可读性。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 添加了更多图片板块以提高可读性，并修复了一些小问题。同时添加了关于战斗助手的章节。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 修正了一个PvP天赋的错别字。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 在削弱后更新了鲜血鲜血的百分比数值。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 修正了过时的措辞，为提高可读性添加了图片板块，并添加了关于新战斗助手的章节。
- **2025年6月15日（本页）：** 添加了11.7的改动。
- **2025年5月14日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 将暮纹作为通用推荐更换，并添加了关于制作武器升华的信息。
- **2025年4月27日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 更新了卡特尔筹码的措辞。
- **2025年4月27日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 在大秘境中，在溃烂之伤前添加了3次吸血打击。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 移除了“恭喜你升到80级”这一部分。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 添加了腐蚀附魔推荐。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** 添加了一些更多提示。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 更新了推荐天赋。
- **2025年4月21日（本页）：** 添加了与11.5版本相关的职业调整。
- **2025年4月14日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 添加了详尽的地下城提示。
- **2025年4月14日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了天启在AOE输出循环中的使用方式。
- **2025年4月7日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式，加入了延后召唤憎恶体。
- **2025年4月2日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 在调整后更新了饰品。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了提示和天赋配置。
- **2025年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 更新了大秘境天赋。
- **2025年3月16日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 阐明了大秘境输出循环。
- **2025年3月16日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新了萨莱因团本天赋，并将推荐的大秘境配置更换为萨莱因。
- **2025年3月3日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 在削弱后更新了毕业装备。
- **2025年3月1日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 在加强后更新了套装段落。
- **2025年3月1日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 将食物更换为精通急速。
- **2025年3月1日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 在套装加强后更新了天赋。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业配装列表、饰品梯队列表、装饰、制造推荐和套装部分。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 阐明了萨莱因萨莱因在AOE中死亡缠绕的使用方式。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 扩展了萨莱因萨莱因的配置。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对11.1版本审查并更新。
- **2025年2月24日（本页面）：** 添加了11.1版本改动并清理了指南链接章节。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年2月20日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1版本审查并更新。
- **2025年2月20日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对11.1版本审查并更新。
- **2025年2月20日（本页）：** 已针对11.1版本审查并更新。
- **2024年12月18日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 在新的模拟数据出炉后更新了塞尔西的宝石。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 在增强后更新了毕业配装列表以包含塞尔西的头冠。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 针对11.0.7版本更新，添加了塞尔西的头冠。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对11.0.7版本审查并更新。
- **2024年12月15日（本页）：** 已针对11.0.7版本审查并更新。
- **2024年10月27日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 确保在点出天赋时亵渎的措辞正确。
- **2024年10月26日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 解决了团本毕业装备列表中的一个问题。
- **2024年10月26日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 阐明了巨魔之灾的寒冰锁链寒冰锁链优先级。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** 添加了更详细的提示。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 添加了溃烂镰刀的玩法内容。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 添加了镰刀配置。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 添加了11.0.5的说明。
- **2024年10月5日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业饰品。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/unholy-death-knight-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/unholy-death-knight-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/unholy-death-knight-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 为第4赛季更新，包括金币优先级和新的毕业装备列表。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了审查，将腿部附魔更换为光耀套件。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 为第4赛季更新，更改了提到的原始属性数值，并阐明了大秘境中属性等值的优先级。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季更新，添加了所有新饰品的详细使用方式。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 为第4赛季进行了审查，无需更改。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 为第4赛季更新，主要更改了理想的属性分配。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月20日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已针对10.2.6版本更新。
- **2024年3月20日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（本页）：** 已针对10.2.6版本进行审阅
- **2024年2月14日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 添加了溃烂之触玩法的详细说明。
- **2024年1月30日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 更新了伤口大秘境配置。
- **2024年1月30日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新了伤口大秘境配置。
- **2024年1月23日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 在改动后更新了菲莱拉兹的优先级。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年12月20日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 对单体目标优先级进行了少量澄清。
- **2023年12月12日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 在起手式中添加了传说装备。
- **2023年12月12日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 更新了大秘境配置。
- **2023年12月12日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 澄清了起手式中黑暗转化和召唤石像鬼的位置。
- **2023年12月2日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 更新了伤口输出循环部分。
- **2023年11月29日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 在传说装备公布后更新了毕业装备。
- **2023年11月24日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 在起手式部分添加了宏。
- **2023年11月22日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 更新了永恒黎明的掉落位置，以区分上层和下层。
- **2023年11月15日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 将灰烬添加到团本毕业装备中，并在主动饰品列表中将其上移。
- **2023年11月12日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 更新了食物推荐。
- **2023年11月12日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 澄清了邪恶起手式中黑暗转化和召唤石像鬼在同一行。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 在孢子披风削弱后更新了毕业装备列表和美化推荐。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 为10.2版本更新。添加了新的头部附魔，并将所有属性附魔更换为精通。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 为10.2版本更新，添加了关于宠物属性继承延迟以及原始属性对镜像触发影响的讨论。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 为10.1.7版本更新。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 为10.1.7补丁进行了复查和更新。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 为10.1.7版本更新。
- **2023年8月31日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 为10.1.7补丁进行了复查和更新。
- **2023年7月21日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 在详细饰品使用部分添加了镜像。
- **2023年7月20日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 更新了毕业饰品和项链。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 更新了饰品毕业装备，并添加了永恒黎明的装备提示。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 添加了10.1.5的改动。
- **2023年6月25日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 起手式中从最多4个凋零缠绕改为正好3个。
- **2023年6月25日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 对起手式进行了少量更新。
- **2023年6月14日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 添加了更详细的饰品和种族技能时间轴。
- **2023年5月24日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 解决了起手式无法正常显示的问题。
- **2023年5月10日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 谜题削弱后更新了饰品毕业推荐。
- **2023年5月8日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 改动后更新了毕业列表和饰品优先级。
- **2023年5月3日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 在起手式中加入了枯萎凋零，并扩充了冷却技能使用章节，加入枯萎凋零。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 为10.1补丁进行了复查。
- **2023年5月1日（本页）：** 为10.1补丁进行了复查。
- **2023年4月30日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 为10.1版本进行了审阅和更新。
- **2023年4月30日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 为10.1版本进行了审阅和更新。
- **2023年4月30日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 为10.1版本进行了审阅和更新。
- **2023年4月30日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 为10.1版本进行了审阅和更新。
- **2023年4月30日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已针对10.1版本进行审查和更新。
- **2023年4月30日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已针对10.1版本进行审查和更新。
- **2023年4月29日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1版本进行审查和更新。
- **2023年4月29日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 为10.1版本进行了审阅和更新。
- **2023年4月29日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 为10.1版本进行了审阅和更新。
- **2023年4月29日（本页）：** 已为10.1更新。
- **2023年4月15日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 扩充了疾病流派循环。
- **2023年4月12日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 10.0.7加强后更新了天赋。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/unholy-death-knight-best-legendaries-shadowlands>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 加入了原初石宝石推荐。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 为10.0.7版本更新了天赋。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.7版本更新了循环。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 为10.0.7更新了天赋。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已为10.0.7补丁更新。
- **2023年3月20日（本页）：** 加入了10.0.7的改动。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/unholy-death-knight-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/unholy-death-knight-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/unholy-death-knight-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月20日（[9.2版本分析](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-2-changes-analysis>)):** 已审核并批准用于9.2补丁。
- **2022年1月19日（[9.2版本分析](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-2-changes-analysis>)):** 已根据最新的职业调整进行更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-1-changes-analysis>)):** 用最近的热修复进行了更新。
- **2021年6月29日（[9.1 补丁分析](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-1-changes-analysis>)):** 创建了页面。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月17日（[永恒宫殿页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-the-eternal-palace-raid-guide>)):** 添加了更多关于艾萨拉女王的信息。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 对天赋选择进行了细微改动。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月19日（[风暴熔渣页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** 添加了史诗难度的技巧。
- **2019年4月16日（[奥杜尔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月16日（[达萨罗之战页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月16日（[风暴熔渣页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年2月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 略微更新了首领战天赋推荐。
- **2019年2月18日（[达萨罗之战页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 修正了首领顺序。
- **2019年2月8日（[达萨罗之战页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了天赋推荐。
- **2019年1月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了天赋推荐。
- **2019年1月22日（[达萨罗之战页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** 加入了达萨罗之战的邪恶死亡骑士建议初版。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年9月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** 添加了奥杜尔中所有首领的信息。
- **2018年8月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** 已添加页面（目前为空）。

显示更多

显示更少

:::

## 练级

在此页面上，你将找到我们的逐级邪恶死亡骑士练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[死亡骑士升级指南](<https://www.icy-veins.com/wow/death-knight-leveling-guide>).

1.

### 邪恶死亡骑士练级指南：至暗之夜

邪恶死亡骑士练级速度很快，既能对多目标施加持续伤害，又能快速爆发秒杀大群敌人，而且在达到71级后，通过[[spell:444008]]成为机动性最强的练级职业之一。此外，该专精通过[[spell:178819]]和[[spell:49998]]的触发效果拥有出色的自我恢复能力，在你一波接一波地AoE清理敌人时保持健康。

理想的玩法是使用[[spell:77575]]拉到多个敌人，用[[spell:85948]]叠加[[spell:1254252]]层数，然后用[[spell:55090]]和[[spell:207317]]顺劈清理敌人。

1.1.

#### 升级装备选择

升级时，物品等级总是比单项属性更重要。始终选择物品等级最高的装备。带有速度副属性的物品可以帮助加快你的升级速度，尤其是在长时间室内活动期间。传家宝装备在升级时也很有用，可以让你在升级旅程的大部分时间里忽略大量配装需求。

1.2.

#### 符文锻造选择

当你获得刻符选项时，务必使用[[spell:53344]]，因为它能最大程度加快练级速度！你也可以使用[[spell:326977]]在击杀怪物后获得不错的速度加成。[[spell:327082]]也很有用，但主要用于较高等级需要与怪物战斗更长时间时。

1.3.

#### 至暗之夜升级实用消耗品

在至暗之夜中，你可以使用一些消耗品来加快练级速度。[[item:225592]]是一种极好的食物，能显著提升你的移动速度，改善练级过程。[[item:109076]]值得一提，因为当你无法使用飞行坐骑时，它可以成为一种高效的交通工具。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 邪恶80级至暗之夜练级
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMDDzmZmZa2MzYMjBAAAAAAAgZGmZAwyMmZ2mZGjZAMLGGAMLgGLYAzAAzMjZAmZGGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZmZGDzmZmZa2MzMjZMAAAAAAAAMzwMDAWmxMz2MzYMDYzsYYgBmFGasgBMDAMzMmBYmZYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYVVPTfBhAGGbZpkEhKwlSyU01lggciqc4B-RSTfdOPHvQcgVBkBVk0Y4FEwIIICqEC-AAAA-OQMEoYIohZBISB-
```

:::

2.1.

#### 升级用战争模式天赋

本节将介绍邪恶死亡骑士练级内容的PvP天赋。

- [[spell:356512]]是唯一提供额外输出增益的PvP天赋。
- [[spell:410301]]提供了一些不错的防御收益。

**等级 1 起：**3.

### **等级 1 起：**升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–9：**刚开始时，你只有两个主要攻击技能：[[spell:316239]]和[[spell:47541]]。

- **等级 1–10：**[[spell:316239]]是你的主要符文消耗技能。
- **等级 27 起：**[[spell:42650]]应尽可能频繁使用，最好用在较难对付的怪物上，因为该冷却技能能带来大量单体爆发伤害。
- **等级 67 起：**当你从[[spell:63560]]获得免费使用机会时，或当目标生命值低于35%时，使用[[spell:343294]]。
- **等级 11 起：**使用[[spell:77575]]对所有目标施加[[spell:191587]]，并对主目标施加[[spell:1240996]]。
- **等级 17 起：**尽可能多地使用[[spell:1247378]]。
- **等级 21 起：**[[spell:63560]]可以在冷却完毕时使用。不过，你也应该确保在面对更多怪物或更难对付的敌人时保留它可用。
- **等级 13 起：**当你至少有一层[[spell:1254252]]时，使用[[spell:55090]]。
- **等级 11–12：**使用[[spell:85948]]作为你的符文消耗技能。
- **等级 1–17：**使用[[spell:47541]]消耗你的符文能量。
- **等级 18 起：**在1-3个目标时，使用[[spell:47541]]消耗符文能量。
- **等级 18 起：**当有4个以上目标时，使用[[spell:207317]]。
- **等级 13 起：**使用[[spell:85948]]来叠加[[spell:1254252]]层数。在你有0层时使用它。

在练级过程中，你会解锁一些被动技能，这些技能可以改变你的游戏风格和循环。

- **等级 19 起：**[[spell:49530]]同时影响[[spell:47541]]和[[spell:207317]]，大幅强化它们。这些触发效果应尽快使用，以确保你不会覆盖当前的触发效果！
- **等级 18 起：**[[spell:178819]]在练级时非常强大，让你在连续拉怪时能够轻松治疗并保持高血量。每次你击杀一个怪物，你的下一个[[spell:49998]]将免费使用，并多恢复相当于你10%生命值的治疗量。

**等级 10 起：**3.1.

#### **等级 10 起：**防御和效用技能

- **等级 14 起：**[[spell:48707]]是一个非常强大的魔法护盾，在吸收魔法伤害时还能产生符文能量。只要有魔法伤害就应该使用它，以利用符文能量的生成。
- **等级 9 起：**[[spell:49039]]是一个对升级来说相对强大的技能，因为它为你提供大量吸血。使用这个冷却技能来利用治疗效果，并尽量将其与高AOE或爆发组合配合使用。
- **等级 18 起：**[[spell:48792]]是一个出色的防御冷却技能，应在必要时使用，以保证你能从一个怪群移动到另一个怪群。
- **等级 19 起：**[[spell:61999]]在单人升级时无法使用，但如果你决定以副本组队的方式升级，它在副本队伍中非常出色。
- **等级 9 起：**[[spell:343257]]是你为数不多的移动速度冷却技能之一，因此在升级时非常有用。其次要效果在升级场景中不太有用，除了那个防止你被减速超过一定限度的被动效果。
- **等级 36 起：**[[spell:212552]]是一个不错的额外加速效果，我们会尽可能利用它。
- **等级 8 起：**[[spell:49576]]将你的目标拉向你，让你可以立即开始攻击。对加快升级过程非常有用。
- **等级 20 起：**[[spell:47528]] 是你的打断技能，非常适合用来打断施法怪物，能显著减少它们对你造成的伤害！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月8日：** 更新建议施放脓疮打击的层数。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月29日：** 已为12.1补丁更新，加入了灵魂收割者的使用说明。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 根据新的12.0.5天赋树更新了升级天赋。
- **2026年3月16日：** 已为至暗之夜第1赛季更新，加入了新的天赋配置。
- **2026年3月2日：** 添加了80级构筑。
- **2026年2月26日：** 已为至暗之夜更新，加入了新的天赋。
- **2026年2月13日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 更新为在2个目标时使用死亡缠绕。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月4日：** 11.2重做后更新。
- **2025年6月27日：** 进行了少量措辞更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 移除了“恭喜你升到80级”这一部分。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月27日：** 确保在点出天赋时亵渎的措辞正确。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5版本中轻松游玩邪恶死亡骑士，使用最简单的循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 邪恶死亡骑士基础

本页面向刚接触游戏或职业的玩家，或只是希望以更直接的方式游玩自己的专精，而不想被实现最佳输出所需的众多细节和主动技能所淹没的玩家。

邪恶的玩法围绕增益效果的管理、资源的合理使用以及瘟疫的保持。学习该专精时需要遵循的三条快速规则是：

- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_festeringscythe.jpg>)
  **保持你的增益**
  
  
  
  
  确保保持你的[[spell:455397]]增益（通过按下[[spell:85948]] → [[spell:455397]]）。此外，管理你的[[spell:1254252]]层数，确保你永远不会在0层时[[spell:55090]]。用[[spell:85948]]构建层数，用[[spell:55090]]消耗。
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_runic_corruption.jpg>)
  **资源管理**
  
  
  
  
  邪恶有两种资源：符文和符文能量。管理它们对于最大化你的DPS和避免资源枯竭至关重要。优先消耗你的符文（始终保持三个在回复中），然后避免符文能量溢出。
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_dread_plague.jpg>)
  **瘟疫覆盖率**
  
  
  
  
  邪恶拥有强大的瘟疫，我们会将它们施加到目标身上。保持这些瘟疫始终存在至关重要，尤其是[[spell:1240996]]。它们是你伤害的主要来源，无论直接还是间接。

1.

### 邪恶死亡骑士新手指南：至暗之夜

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士团队副本天赋

2.1.

#### 邪恶死亡骑士新手团本天赋

这是你在团队副本战斗中的首选配置。

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mZmZa2MzMjZAAAAAAAAgZGGDAWmxMz2MzYmZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVFYgGxNUko015diigA-RSTdfHOPruwGBKQko0A5BGGEIIwIatB-AAAA-AeERphowgJQwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因大秘境与地下堡

2.2.

#### 邪恶死亡骑士新手地下堡与大秘境天赋

这是你在地下堡或大秘境中的首选配置。

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMjBGYGbassAYbwGGwMAMmZGzgZGMjxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-TCIQUJAxwBDmmF-
```

:::

### 邪恶死亡骑士基础循环

2.3.

#### 邪恶死亡骑士循环

邪恶死亡骑士是一个近战输出专精，提供强大的单体和AoE输出能力。

你在整场战斗中的主要目标是使用[[spell:85948]]为自己叠加[[spell:1254252]]层数（确保不超过8层），然后用[[spell:55090]]/[[spell:433901]]消耗这些层数。同时使用[[spell:85948]] -> [[spell:455397]]维持镰刀增益。确保使用[[spell:47541]]（单体）或[[spell:207317]]（AoE）来消耗[[spell:49530]]的触发效果并消耗符文能量。此外，你应该通过使用[[spell:77575]]来保持你的瘟疫[[spell:191587]]和[[spell:1240996]]的持续时间。最后，确保在你的[[spell:63560]]期间尽可能多地使用[[spell:1247378]]。

我们的第2赛季套装强化了我们的[[spell:390196]]和[[spell:1256813]]宠物。2件套使它们施放更强大的[[spell:198407]]和[[spell:1297091]]技能。4件套使这些新技能对生命值低于35%的敌人伤害提高130%，提升我们的斩杀能力。

:::details 常见问题：哪个种族最适合邪恶死亡骑士？
所有种族的DPS差距都在1%以内，所以选择对你的整体DPS影响很小。不过，巨魔通常总体最佳，略优于熊猫人和兽人。

:::

2.3.1.

##### 邪恶死亡骑士基础循环

1. 当目标生命值低于35%或你从[[spell:63560]]获得免费使用时，施放[[spell:343294]]。
2. 施放[[spell:77575]]以在目标身上保持你的[[spell:191587]]和[[spell:1240996]]。
3. 使用[[spell:455397]]在自己身上保持增益效果。
4. 在你的[[spell:63560]]期间使用[[spell:1247378]]。
5. 当你有[[spell:49530]]触发效果或[[spell:1242158]]激活时，使用[[spell:47541]]。当与3个以上敌人战斗时使用[[spell:207317]]（在[[spell:1242158]]期间为4个以上）。
6. 当你的[[spell:1254252]]层数为0时，使用[[spell:85948]]来叠加它。
7. 当你有任何[[spell:1254252]]层数时，使用[[spell:55090]]。
8. 使用[[spell:47541]]。当与3个以上敌人战斗时使用[[spell:207317]]。

2.3.2.

##### 起手式

1. 使用[[spell:77575]]
2. 使用[[spell:85948]]2次。
3. 使用[[spell:42650]] + [[spell:63560]] + 药水 + 饰品 + 种族技能
4. 使用[[spell:1247378]]
5. 使用[[spell:1242174]]2次。
6. 使用[[spell:1247378]]
7. 使用[[spell:343294]]

2.3.3.

##### 多目标循环

单体和AoE之间的唯一区别在于使用[[spell:207317]]。当你与3个或更多目标战斗时，用它代替[[spell:47541]]。在[[spell:1242158]]期间，在4个以上目标时使用（会转化为[[spell:383269]]技能）。

2.3.4.

##### 巅峰天赋： ![Forbidden Knowledge Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_dungeon_thenecroticwake_nalthor.jpg>) 禁断知识

邪恶死亡骑士在至暗之夜中从80级升到90级时，将获得[[spell:1242158]]巅峰天赋。第一级在你施放[[spell:42650]]后提供30秒的增益，将你的[[spell:47541]]转化为[[spell:1242174]]，将你的[[spell:207317]]转化为[[spell:383269]]。这些新技能是基础技能的强化版本，特别是为[[spell:47541]]增加了AoE效果。对循环的影响是，[[spell:1242174]]在AoE中最多可用于3个目标，而[[spell:47541]]最多只可用于2个目标。

第2级和第3级（[[spell:1256565]]）在施放[[spell:1247378]]时提供精通，并叠加一层[[spell:1254252]]。循环中需要的[[spell:85948]]次数略少，但其他方面没有太大变化。

第4级（[[spell:1256566]]）使[[spell:1240996]]有20%的几率以100%的效果触发[[spell:1247378]]，显著增加循环中触发的[[spell:1247378]]总数。

2.3.5.

##### 冷却技能

邪恶死亡骑士拥有三个冷却技能。

- [[spell:42650]]应尽量卡冷却使用。它们通常是你到达首领后使用的第一个技能。确保每1.5分钟与[[spell:63560]]对齐使用。
- [[spell:63560]]应尽量卡冷却使用。确保每1.5分钟与[[spell:42650]]对齐使用。
- [[spell:43265]]应仅用于配合[[spell:273952]]天赋减缓敌人，或在你使用[[spell:1290864]]时使用（3个以上目标）。

### 邪恶死亡骑士属性优先级

2.4.

#### 邪恶死亡骑士属性优先级

目前，你应该按以下顺序优先考虑属性。请记住，物品等级在大多数情况下通常都是最优的！如需了解本页所呈现内容的更多信息，请查看我们的主指南
[属性优先级页面](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>).

暴击

精通

急速

全能

这可能因你角色的装备而异，所以请务必自行模拟，以找到你的属性优先级。通常，精通和暴击比全能和急速有价值得多，应优先考虑。不过，也不要为了追求这些特定属性而损失大量物品等级！

### 暴风雪战斗助手

2.5.

#### 邪恶死亡骑士战斗助手

《地心之战》11.1.7版本为游戏中所有专精引入了战斗助手功能。它以两种工具的形式呈现，可用于辅助你的循环。辅助高亮功能会点亮你接下来应该使用的法术，帮助你确定需要按下哪个按钮。单键助手会为你提供一个按钮，自动按下相应的法术。
**单键助手每次按下时会有0.2秒的公共冷却时间惩罚，人为地减慢你的循环**。这种惩罚意味着使用单键助手时，你的DPS总是低于完美执行循环时所能达到的水平。

那么这些助手能打出的循环有多好呢？如果我们假设你能完美地使用冷却技能，使用辅助高亮时的DPS大约会低5-10%。使用单键助手时，这个数字大约是15%。请注意，这是与绝对最优操作相比。对循环不太熟悉的玩家使用这些助手时，损失可能会明显更小，甚至可能获得提升。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月8日：** 根据瘟疫和墓地目标数量的变化更新循环。
- **2026年9月4日：** 将新手团本构建更新为骑手流。
- **2026年8月24日：** 团本和大秘境更新为萨莱因。
- **2026年8月20日：** 所有内容更新为凋零爆发。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月29日：** 已为12.1补丁更新，加入了新的输出循环和起手式。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年6月6日：** 更新了在大秘境天赋配置中使用食尸鬼狂乱。
- **2026年4月28日：** 更新了大秘境天赋配置，点出了死亡循环。
- **2026年4月22日：** 更新为在团队副本使用血性狂乱，在大秘境不点憎恶。
- **2026年4月21日：** 将团队副本天赋更换为石像鬼。
- **2026年4月20日：** 更新了12.0.5版本的天赋和起手式。
- **2026年3月29日：** 移除了单键助手的主要冷却时间功能。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月12日：** 已为至暗之夜第1赛季更新，加入了新的天赋配置。
- **2026年2月26日：** 已为至暗之夜更新，加入了新的天赋配置、输出循环和终极天赋说明。
- **2026 年 2 月 11 日：** 在单体目标中更换为天启骑士。
- **2026年2月10日：** 更新了12.0.1版本的起手式。
- **2026年2月2日：** 在起手式中加入了一次死亡缠绕。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月7日：** 修复漏洞后更新了天启的使用方式。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月27日：** 重新组织了页面以提高清晰度。
- **2025年6月15日：** 修正了过时的措辞，为提高可读性添加了图片板块，并添加了关于新战斗助手的章节。
- **2025年4月21日：** 更新了推荐天赋。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季更新，主要更改了理想的属性分配。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023 年 12 月 12 日：** 澄清了起手式中黑暗转化和召唤石像鬼的位置。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月25日：** 对起手式进行了少量更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月29日：** 为10.1版本进行了审阅和更新。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到魔兽世界12.1.5补丁中你的邪恶死亡骑士的最佳天赋。我们还为各种内容类型（如团队副本或大秘境）提供了默认天赋构建。如果你开启了战争模式，我们也为你提供了PvP天赋。

1.

### 邪恶死亡骑士的最佳至暗之夜天赋

欢迎来到邪恶死亡骑士天赋指南。在这里，我们将讨论与你天赋选择相关的所有事项，提供最佳可用构建，以及关于替代选择和潜在天赋更换的详细信息。

邪恶死亡骑士在天赋方面有两种略有不同的风格可供选择：瘟疫流或随从流。随从流构建与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士，并且也可以与
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因搭配，用于我们推荐的大秘境天赋构建。这些构建选择了诸如[[spell:1256813]]和[[spell:1241705]]之类的天赋。瘟疫流通常使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因配合[[spell:1271974]]天赋，以真正发挥持续伤害（DoT）的力量。

对于单体目标的团队副本战斗，我们推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士随从流构建。对于大秘境，我们推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因宠物流构建。

**快速开始导入代码：**

:::talents 邪恶单体目标
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTjZmxYGDAAAAAAAAzDMMGAsMDzsZmxMzYgBmxiGLbA2GsBgZAMzMzMmBzMYmZMA"
}
```
:::

:::talents 邪恶大秘境/地下堡
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMjBGYGbassAYbwGGwMAMmZGzgZGMjxA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

萨莱因

团队副本

推荐

大秘境 腐溃流

推荐

大秘境 萨莱因宠物流

天启骑士

团队副本

秘境+

地下堡

推荐

### 天赋方案 0-0

1.1.

#### 团本天赋

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因随从流构建是团队副本的替代方案。它非常注重随从伤害，包括[[spell:1256813]]、[[spell:1238900]]以及我们通过这些天赋召唤的随从。它易于操作，并能造成大量爆发伤害。

为了获得更好的AoE爆发，选择[[spell:455135]]代替[[spell:207272]]。这会在单体目标上损失百分之几的伤害，但会增加大量顺劈伤害。如果你想要更多顺劈，还可以选择[[spell:1290864]]代替[[spell:377587]]。这样你就运行了完整的萨莱因宠物流大秘境构建。

### 天赋方案 0-1

1.2.

#### 萨莱因腐溃流构建

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因大秘境构建与我们的团队副本构建相似，但它更偏向AoE，同时不会牺牲太多单体目标伤害。有些人不带[[spell:343294]]和[[spell:377514]]来运行它，但我们建议改为牺牲[[spell:390270]]和[[spell:377587]]。

### 天赋方案 0-2

1.3.

#### 萨莱因宠物流构建

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因大秘境构建使用与骑士流构建相同的随从天赋，但将骑士英雄天赋替换为萨莱因。

### 天赋方案 1-0

1.4.

#### 团本天赋

这是我们推荐的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士团队副本随从流构建。它非常注重随从伤害，包括[[spell:1256813]]、[[spell:1238900]]以及我们通过骑士召唤的随从。它易于操作，并能造成大量爆发伤害。

[[spell:444072]]和[[spell:444069]]的DPS相近，但狂怒整体略占优势，这就是我们推荐它的原因。

为了获得更好的AoE爆发，选择[[spell:455135]]代替[[spell:207272]]。这会在单体目标上损失百分之几的伤害，但会增加大量顺劈伤害。如果你想要更多顺劈，还可以选择[[spell:1290864]]代替[[spell:377587]]。这样你就运行了完整的骑士流大秘境构建。

### 天赋方案 1-1

1.5.

#### 大秘境天赋

大秘境对AoE伤害的重视程度要高得多。因此，我们牺牲一些单体DPS来获得AoE能力。不过，我们不会走极端，保留一些对单体仍有价值的天赋，以保持良好的平衡。最终这成为我们单体骑士流构建的一个小变体，选择[[spell:455135]]和[[spell:1290864]]代替[[spell:377592]]和[[spell:207272]]。

### 天赋方案 1-2

1.6.

#### 地下堡天赋

的玩法 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 非常适合我们的骑士流地下城构建，它在单体和AoE之间取得了良好的平衡！

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTjZmxYGDAAAAAAAAzDMMGAsMDzsZmxMzYgBmxiGLbA2GsBgZAMzMzMmBzMYmZMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVabhiqrCMQj4IHKS66QRQOB-RSTdfHOPruwGBKQko0YFuxx5BGIIoJC-AAAA-JgMpCTDQgwgxhF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMGDz2MzMTzyMzYMjBAAAAAAAg5BGDDAWmhZ2MzYMjBGYGbassAYbwGGwMAmZmZGzgZGMmxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ02CFXBEYgGxRWo01higcC-RSTdfHOPruwGBIQko0kFuxx5BGIIoJC-AAAA-JiIpCTDQgwgxhF-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMjBGYGbassAYbwGGwMAMmZGzgZGMjxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-TCIQUJAxwBDmmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mZmZa2MzMjZAAAAAAAAgZGGDAWmxMz2MzYmZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVFYgGxNUko015diigA-RSTdfHOPruwGBKQko0A5BGGEIIwIatB-AAAA-AeERphowgJQwwC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMDYzsYYgBmNGasgBMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-AeERphowgJQwwC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMDYzsZYgBmNGasgBMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-AeERphowgJQ4wC-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

我们建议你在最初的几周内选择以下增益，但由于你可以随时自由切换，请自行尝试其他选项，如果你觉得推荐的选项效果不够好：

- 第1周：[[spell:1279599]]
- 第2周：[[spell:1279604]]
- 第3周：[[spell:1287555]]
- 第4周：[[spell:1279609]]
- 第5周：[[spell:1279614]]

1.

### 巅峰天赋： ![Forbidden Knowledge Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_dungeon_thenecroticwake_nalthor.jpg>) 禁断知识

邪恶死亡骑士在至暗之夜中从80级升到90级时，可以解锁[[spell:1242158]]巅峰天赋。第一层在你施放[[spell:42650]]后提供30秒的增益，将你的[[spell:47541]]变为[[spell:1242174]]，将你的[[spell:207317]]变为[[spell:383269]]。这些新能力是基础版本的强大版本，特别是为[[spell:47541]]增加了AoE效果。对循环的影响是，[[spell:1242174]]在AoE中最多对5个目标使用（[[spell:47541]]最多只对3个目标使用）。

第2层和第3层（[[spell:1256565]]）在施放[[spell:1247378]]时提供精通，并叠加一层[[spell:1254252]]。循环中需要的[[spell:85948]]略少一些，但其他方面变化不大。

第4级（[[spell:1256566]]）使[[spell:1240996]]有20%的几率以100%的效果触发[[spell:1247378]]，显著增加循环中触发的[[spell:1247378]]总数。

保持良好的[[spell:1240996]]和[[spell:455397]]覆盖率对于充分发挥这个天赋至关重要。此外，你的宠物必须设置为协助模式才能正常运作。

1.

### 英雄天赋

英雄天赋在71级解锁，是互斥的天赋树，你可以选择来略微改变玩法。邪恶死亡骑士可以在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士英雄天赋专注于仆从伤害，召唤天启骑士对你的敌人造成大量伤害。在托尔班的寒冰锁链方面，你有少量的循环更新，你需要尽快爆发掉它们，并且你需要停留在莫格莱尼的[[spell:43265]]中以获得5%的伤害提升。除此之外，主要好处来自于[[spell:444010]]，这是一个对死亡骑士来说非常棒的机动性技能！

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因英雄天赋更专注于瘟疫伤害和通过[[spell:433901]]、[[spell:47541]]和[[spell:207317]]加成的直接伤害。此外，它通过[[spell:434237]]能力具有有趣的二次缩放机制，并且可以使用[[spell:1271974]]，这是一个有趣且值得尝试的天赋。主要的循环差异是引入了[[spell:433901]]，我们可以在[[spell:63560]]窗口中大量使用它。我们还会尝试在黑暗突变窗口之间触发它，以维持[[spell:433925]]增益。

1.

### 循环

天赋可以并且通常会改变你的循环或为你的优先级添加新技能。要更详细地了解在最佳天赋下你的循环会是什么样子，请查看下面链接的循环页面。

[邪恶DK循环与冷却](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)

1.

### PvP天赋（战争模式）

PvP天赋是可在PvP内容中使用的特定天赋。我们可以在开放世界PvP中利用这些天赋来获得一些不错的增益。

- 户外世界中启用的PvP天赋。
- 升级时获得的经验值和任务奖励提高15%。

考虑到开启战争模式在升级和 PvE 内容中的好处，建议开启此功能以在满级时最大化你的升级速度和奖励。不过，你会使自己成为开放世界 PvP 的目标，在升级或做世界任务时存在被"偷袭"的可能性。

在下面，我们将对最适合用于升级以及进行单人或小队PvE内容的PvP天赋进行排名。

1. [[spell:288855]]为你恢复目标受到的[[spell:1240996]]伤害量的10%。对PvE来说其实无关紧要。
2. [[spell:77606]] 在你的敌人身上放置一个减益效果，当他们施放消耗法力的法术时激活。它允许你在一段时间内使用相同的法术。在 PvE 内容中没有用处。
3. [[spell:356520]] - 你的[[spell:1247378]]现在会对目标施加坏疽伤口，在接下来的15秒内吸收其受到的所有治疗的8%（最多3层）。在PvE内容中没什么用。
4. [[spell:210128]] - 消耗30点符文能量，将附近的尸体复活为僵尸。僵尸会缓慢走向你的目标，如果到达目标就会爆炸并眩晕区域内的所有敌人。在PvE内容中有一定用处的眩晕技能。
5. [[spell:1281529]]在你的[[spell:275430]]死亡时为你恢复其最大生命值的5%（约为你生命值的2.5%）。[[spell:49998]]按下时会牺牲所有活跃的食尸鬼。在AoE中是一个不错的额外续航，但有DPS上的缺点，因为你可能会失去次级食尸鬼的覆盖率。
6. [[spell:47476]] 沉默你的目标4秒。不如直接使用 [[spell:221562]]（它会替换该天赋），是一个相当无用的 PvE 天赋。
7. [[spell:356512]]使你的[[spell:47541]]额外造成一次你瘟疫伤害的25%，并将目标减速45%，持续3秒。是一个有用的PvE天赋，因为它能提升DPS。
8. [[spell:202727]]为被[[spell:43265]]击中的任何目标添加一个吸收护盾，吸收量为伤害量的100%。基本没用。
9. [[spell:410301]] 在你按下 [[spell:49998]] 时提供4秒的25%物理伤害减免。可靠的防御提升！
10. [[spell:410320]] 将 [[spell:48707]] 的冷却时间缩短10秒，并允许你对盟友使用它。这是一个很好的防御提升，因为它允许更多的反魔法护罩使用。

[[spell:356512]]是一个可靠的选择，因为它能带来不错的DPS提升。在PvE中没有其他天赋对我们有多大帮助，主要是PvP选择。对于第二和第三个选择，我们没有太多可选的。[[spell:410301]]通常是最佳选择，因为它能提供不错的防御收益，[[spell:410320]]是一个小的防御收益！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月23日：** 将推荐构建更新为凋零瘟疫。
- **2026年9月23日：** 将推荐的单体团本构建更新为萨莱因。
- **2026年9月4日：** 将推荐的单体团本构建更新为骑手流。
- **2026年8月24日：** 更新为推荐萨莱因。
- **2026年8月20日：** 所有内容更新为凋零爆发。
- **2026年8月10日：** 已用12.1版本构筑进行更新。
- **2026年6月15日：** 已为12.0.7补丁更新，加入了全能属性的选择。
- **2026年6月6日：** 更新了大秘境天赋配置，点出了食尸鬼狂乱。
- **2026年4月28日：** 更新了大秘境和团队副本的天赋配置。
- **2026年4月22日：** 更新为在团队副本使用血性狂乱，在大秘境不点憎恶。
- **2026年4月21日：** 将团队副本天赋更换为石像鬼。
- **2026年4月20日：** 针对12.0.5更新了天赋。
- **2026年4月6日：** 更新了天赋推荐的措辞，并增加了更多鲜血盟约相关内容。
- **2026年4月2日：** 更新天赋配置为点出2个亵渎者，而非食尸鬼之爪。
- **2026年3月16日：** 更新了团队副本天赋，点出了邪恶狂乱。
- **2026年2月26日：** 已为至暗之夜更新，加入了新的最佳天赋配置。
- **2026 年 2 月 11 日：** 更新为在团队副本中推荐天启骑士。
- **2026年2月10日：** 更新了12.0.1版本的天赋，点出了鲜血盟约。
- **2026年1月22日：** 更新了团队副本和大秘境的天赋。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 已为11.2.7补丁进行审查和更新。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月18日：** 在2目标顺劈时，将牺牲的第一个点数换为鲜血圣印。
- **2025年8月10日：** 添加了天启骑士疾病天赋配置。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 修正了一个PvP天赋的错别字。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月16日：** 更新了萨莱因团本天赋，并将推荐的大秘境配置更换为萨莱因。
- **2025年3月1日：** 在套装加强后更新了天赋。
- **2025 年 2 月 24 日：** 扩展了萨莱因萨莱因的配置。
- **2025年2月20日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 添加了镰刀配置。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审查，无需更改。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月30日：** 更新了伤口大秘境配置。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023 年 12 月 12 日：** 更新了大秘境配置。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 为10.1.7补丁进行了复查和更新。
- **2023年8月31日：** 为10.1.7补丁进行了复查和更新。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月29日：** 为10.1版本进行了审阅和更新。
- **2023年4月12日：** 10.0.7加强后更新了天赋。
- **2023年3月20日：** 为10.0.7更新了天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面中，你将学习如何在单体目标和多目标情况下优化你的邪恶死亡骑士的循环。我们还有关于冷却、触发等高级章节，以最大限度地提高你的DPS。我们所有的内容都已更新至魔兽世界12.1.5补丁。

1.

### 邪恶死亡骑士玩法与循环指南

欢迎来到我们的邪恶死亡骑士循环页面。在这里，我们将介绍你需要知道的一切，以便在团队副本和大秘境场景中最佳地发挥你的专精。

在下方选择天赋和英雄天赋后，本指南中的循环将会相应更新。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士

团队副本

秘境+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因

团队副本

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

秘境+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:1271974]]

[[spell:343294]]

[[spell:377580]]

[[spell:377514]]

[[spell:455397]]

[[spell:1254552]]

[[spell:1290864]]

### 邪恶死亡骑士详解

1.1.

#### 邪恶死亡骑士详解

邪恶死亡骑士依赖于符文和符文能量的双资源系统。符文会随时间被动充能，并用于[[spell:85948]]、[[spell:55090]]和[[spell:1247378]]等技能。消耗符文会产生符文能量，我们将其用于[[spell:47541]]和[[spell:207317]]等技能。此外，我们通过[[spell:77575]]和[[spell:1247378]]（配合[[spell:1254552]]）在敌人身上维持瘟疫。

循环归结为以下几点：

- 管理我们通过[[spell:85948]]和[[spell:55090]]积累和消耗的[[spell:1254252]]层数。
- 通过使用[[spell:85948]] -> [[spell:455397]]来管理你的[[spell:455397]]增益。
- 通过使用[[spell:77575]]来管理你的瘟疫。
- 通过在单体目标上使用[[spell:47541]]、在AoE上使用[[spell:207317]]来管理你的资源。
- 在[[spell:63560]]期间尽可能使用你的[[spell:1247378]]。
- 当你通过[[spell:63560]]获得免费触发，或目标生命值低于35%时，使用你的[[spell:343294]]。
- 尽可能使用你的冷却技能，并始终将它们对齐（[[spell:42650]]和[[spell:63560]]）。

### 单体输出循环

[[spell:77575]]

[[spell:85948]]

[[spell:455397]]

[[item:241288]]

[[item:249344]]

[[spell:42650]]

[[spell:63560]]

[[spell:1247378]]

[[spell:47541]]

[[spell:47541]]

**适用条件：Putrid Echoes（启用）。**

[[spell:1247378]]

**适用条件：Reaping（启用）。**

[[spell:343294]]

**适用条件：Blightfall（启用）；Reaping（启用）。**

[[spell:1271974]]

1.2.

#### 邪恶死亡骑士单体目标起手

起手式是你在与敌人交战时使用的一系列固定技能。记住它有助于你以最优的方式开始你的循环。

1. 使用[[spell:77575]]。
2. 使用2次[[spell:85948]]。
3. 使用[[spell:42650]] + [[spell:63560]] + 饰品 + 种族技能 + 药水
4. 使用[[spell:1247378]]。
5. 使用2次[[spell:47541]]。
6. **适用条件：Putrid Echoes（启用）。** 使用[[spell:1247378]]。
7. **适用条件：Reaping（启用）。** 在按下[[spell:63560]]6秒后使用[[spell:343294]]。
8. **适用条件：Blightfall（启用）；Reaping（启用）。** 在[[spell:343294]]增益即将到期前使用[[spell:1271974]]。

关于饰品的时机，你可以在所有起手中直接将它们与[[spell:42650]]做成宏。如果你运气好获得[[spell:10060]]，在施放[[spell:42650]]时请求它。

**适用条件：Blightfall（启用）。** 在起手中[[spell:343294]]（点了Blightfall天赋）的时机是为了在[[spell:63560]]结束后消耗[[spell:1271974]]时，让瘟疫伤害减益效果重叠。

1.3.

#### 邪恶死亡骑士单体目标循环优先级

下面的列表代表了你的循环优先级，不包括实际的冷却技能。冷却技能的使用会单独讨论，但你通常可以假设你总是想尽可能频繁地使用你的冷却技能！

1. 使用[[spell:42650]]和[[spell:63560]]的冷却时间。
2. **适用条件：Blightfall（启用）。** 在[[spell:343294]]即将结束前使用[[spell:1242616]]，随后使用[[spell:1247378]]
3. **适用条件：Blightfall（启用）；Reaping（未启用）。** 在[[spell:63560]]即将结束前使用[[spell:1242616]]，随后使用[[spell:1247378]]
4. 使用[[spell:77575]]来维持目标身上的瘟疫。
5. **适用条件：Festering Scythe（启用）。** 如果[[spell:455397]]的增益即将到期或已经消失，则使用它。
6. **适用条件：Reaping（启用）。** 如果敌人生命值低于35%，使用[[spell:343294]]。如果你触发了[[spell:377514]]，在[[spell:63560]]之后约6秒施放此技能。
7. 如果你的[[spell:63560]]增益处于激活状态，则使用[[spell:1247378]]。
8. 当你有[[spell:49530]]触发、[[spell:1242158]]激活，或者你正在使用时，使用[[spell:47541]] ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因并且拥有超过50点符文能量。
9. 如果你没有[[spell:1254252]]层数，则使用[[spell:85948]]。
10. 如果你至少有1层[[spell:1254252]]，则使用[[spell:55090]]。
11. 使用[[spell:47541]]。

现在，我们将把这个优先级列表扩展成更详细的描述！

- 尽可能多地使用你的冷却技能。每45秒使用一次[[spell:63560]]，每90秒使用一次[[spell:42650]]，并始终对齐它们。
- **适用条件：Blightfall（启用）。** 在[[spell:343294]]结束时使用[[spell:1242616]]，随后接一个[[spell:1247378]]以重新施加你的瘟疫并利用生成的充能。
- **适用条件：Blightfall（启用）；Reaping（未启用）。** 在[[spell:63560]]结束时使用[[spell:1242616]]，随后接一个[[spell:1247378]]以重新施加你的瘟疫并利用生成的充能。
- 通过利用[[spell:77575]]来保持目标身上的瘟疫。你的瘟疫不仅造成伤害，还是你重要的[[spell:49530]]和[[spell:1256566]]触发的来源，因此保持它们常驻至关重要。
- **适用条件：Soul Reaper（启用）；Blightfall（未启用）。** 使用[[spell:343294]]。要么在目标生命值低于35%时使用。如果你从[[spell:63560]]获得了[[spell:377514]]的免费使用，在[[spell:63560]]之后约6秒使用它。确保在使用灵魂收割时始终至少有3层[[spell:1254252]]。
- **适用条件：Blightfall（启用）。** 使用[[spell:343294]]，要么在目标生命值低于35%时（在[[spell:63560]]期间），要么当你从[[spell:63560]]获得了[[spell:377514]]的免费使用时。使用[[spell:1271974]]时，你希望将此技能带来的瘟疫伤害易伤debuff与你第一次[[spell:1256813]]的结束重叠。保留[[spell:343294]]直到[[spell:63560]]之后约6秒，在[[spell:343294]]的debuff窗口结束时使用[[spell:1271974]]。在斩杀阶段，在黑暗突变期间尽快使用免费的[[spell:343294]]，这样你可以在15秒后获得一次新的使用，以与使用Blightfall时的结束重叠。确保在使用灵魂收割时始终有3层[[spell:1254252]]。
- **适用条件：Festering Scythe（启用）。** 使用[[spell:455397]]来保持自己身上的增益。这提供的提高的跳动频率增加了[[spell:49530]]和[[spell:1256566]]的触发几率。由于这种互动，确保此增益始终维持是绝对至关重要的。
- 使用[[spell:47541]]来消耗你的[[spell:49530]]触发，或在[[spell:1242158]]期间作为高优先级使用，或者当你正在玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因且拥有超过50符文能量时。[[spell:49530]]是一个强大的触发，你不想浪费任何一个。如果你点出了[[spell:276023]]，你可以允许自己在消耗之前叠加两层充能。然而，大多数时候，你只需尽快使用它们以避免任何潜在的浪费。此外，[[spell:47541]]在[[spell:1242158]]期间获得大量价值，因为它会转化为[[spell:1242174]]，造成显著更高的伤害。
- **适用条件：Soul Reaper（未启用）；Reaping（未启用）。** 使用[[spell:85948]]来为自己叠加[[spell:1254252]]层数。我们希望始终保持在2到4层之间，以便在被迫离开近战范围时有一些灵活性。
- **适用条件：Reaping（未启用）。** 使用[[spell:85948]]来为自己叠加[[spell:1254252]]层数。我们希望始终保持在2到4层之间，以便在被迫离开近战范围时有一些灵活性。当你的目标进入斩杀范围（生命值低于35%）时，值得保持至少3层[[spell:1254252]]，这样你总是有足够的层数来获得[[spell:343294]]的全部收益。
- **适用条件：Reaping（启用）。** 使用[[spell:85948]]来为自己叠加[[spell:1254252]]层数。我们希望始终保持在2到4层之间，以便在被迫离开近战范围时有一些灵活性。当你的目标进入斩杀范围（生命值低于35%），或者在施放[[spell:63560]]之前，值得确保你始终有至少3层[[spell:1254252]]，这样你总是有足够的层数来获得[[spell:343294]]的全部收益。
- 使用[[spell:55090]]来消耗你的[[spell:1254252]]层数。这与[[spell:85948]]同步使用，以将你的层数保持在健康的水平。你通常会升到2-4层，然后使用天灾打击降回0层。
- 当你没有其他事可做时，使用[[spell:47541]]作为你的填充法术！

当你想在单体输出循环中造成范围伤害时，你实际上不需要改变太多。如果小怪被拉到了你当前目标的上方，你只需使用[[spell:55090]]将你的疾病扩散到它们身上。如果你要接战新的一波怪，你首先使用[[spell:77575]]来施加你的瘟疫。你的天灾打击默认会顺劈，所以主要的决策在于使用[[spell:47541]]还是[[spell:207317]]。通常，你在3个以上目标时切换到凋零缠绕（在[[spell:1242158]]期间为4个以上目标），但有时如果你想要进行优先级伤害，你会继续使用凋零缠绕。

### 多目标循环

[[spell:77575]]

[[spell:85948]]

[[spell:455397]]

[[item:241288]]

[[item:249344]]

[[spell:42650]]

[[spell:63560]]

[[spell:1247378]]

**适用条件：Putrid Echoes（启用）。**

[[spell:207317]]

[[spell:207317]]

**适用条件：Putrid Echoes（启用）。**

[[spell:1247378]]

**适用条件：Reaping（启用）。**

[[spell:343294]]

1.4.

#### 邪恶死亡骑士的多目标起手式

1. 使用[[spell:77575]]。
2. 使用2次[[spell:85948]]。
3. 使用[[spell:42650]] + [[spell:63560]] + 饰品 + 种族技能 + 药水
4. 使用[[spell:1247378]]
5. 使用2次[[spell:207317]]。
6. **适用条件：Putrid Echoes（启用）。** 使用[[spell:1247378]]。
7. **适用条件：Reaping（启用）。** 使用[[spell:343294]]。

关于饰品的时机，你可以在所有起手中直接将它们与[[spell:42650]]做成宏。如果你运气好获得[[spell:10060]]，在施放[[spell:42650]]时请求它。

1.5.

#### 邪恶死亡骑士的多目标循环优先级

邪恶死亡骑士的多目标循环与单体相比有大量相同的优先级。主要区别在于，当我们面对4个以上目标时（在[[spell:1242158]]期间为6个以上目标），我们使用[[spell:207317]]而不是[[spell:47541]]。

1. 使用[[spell:42650]]和[[spell:63560]]的冷却时间。
2. **适用条件：Blightfall（启用）。** 在[[spell:63560]]结束时使用[[spell:1242616]]，随后接上[[spell:1247378]]
3. 使用[[spell:77575]]来维持目标身上的瘟疫。
4. **适用条件：Cycle of Death（启用）。** 在与3个以上敌人战斗时使用[[spell:43265]]。
5. **适用条件：Festering Scythe（启用）。** 如果[[spell:455397]]的增益即将到期或已经消失，则使用它。
6. **适用条件：Reaping（启用）。** 如果有任何敌人生命值低于35%，或者你触发了从[[spell:63560]]获得的[[spell:377514]]效果，则使用[[spell:343294]]。
7. **适用条件：Reaping（未启用）。** 如果有任何敌人生命值低于35%，则使用[[spell:343294]]。
8. 当你触发 [[spell:49530]] 或 [[spell:1242158]] 处于激活状态，或你正在输出时，使用 [[spell:207317]]。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因且拥有超过50符文能量时。在与少于4个目标战斗时使用[[spell:47541]]（在[[spell:1242158]]期间为6个目标）。
9. 如果你的[[spell:63560]]激活，则使用[[spell:1247378]]。
10. 如果你的[[spell:1254252]]层数为3或更少，则使用[[spell:85948]]。
11. 如果你至少有1层[[spell:1254252]]，则使用[[spell:55090]]。
12. 使用[[spell:207317]]。在与少于4个目标战斗时使用[[spell:47541]]（在[[spell:1242158]]期间为6个目标）。

现在，我们将把这个优先级列表扩展成更详细的描述！

- 尽可能多地使用你的冷却技能。每45秒使用一次[[spell:63560]]，每45秒使用一次[[spell:42650]]，并始终对齐它们。
- **适用条件：Blightfall（启用）。** 在[[spell:63560]]结束时使用[[spell:1242616]]，随后接一个[[spell:1247378]]以重新施加你的瘟疫并利用生成的充能。
- 通过利用[[spell:77575]]来保持目标身上的瘟疫。[[spell:1247378]]配合[[spell:1254552]]也可以使用，但你通常会选择使用爆发，因为你的腐化打击优先用于冷却技能伤害。
- 在与3个以上敌人战斗时使用[[spell:43265]]，以最大化你在[[spell:63560]]期间使用的[[spell:1247378]]数量。要么在窗口期间尽可能多地使用它们以获得尽可能多的冷却缩减，要么在你还没有达到3层[[spell:1247378]]时稍微提前使用它们。
- 施放 [[spell:343294]]。在任意目标生命值低于 35% 时，或当你通过 [[spell:377514]] 获得来自 [[spell:63560]] 的免费使用时使用。最好“点杀”低生命值的小怪，以自动消耗你的 [[spell:1254252]] 层数。
- 在[[spell:1242158]]期间使用[[spell:207317]]，或用来消耗你的[[spell:49530]]触发。[[spell:49530]]是一个强大的触发，你不想浪费任何一个。如果你点出了[[spell:276023]]，你可以允许自己在消耗之前叠加两层充能。然而，大多数时候，你只需尽快使用它们以避免任何潜在的浪费。我们只在[[spell:1242158]]期间优先消耗符文能量（在突然触发之外），其他时候溢出是可以的。在与少于3个目标战斗时使用[[spell:47541]]（在[[spell:1242158]]期间为4个目标），因为它会造成更多伤害。
- 使用[[spell:85948]]来为自己叠加[[spell:1254252]]层数。我们希望始终保持在4到6层之间，以便在被迫离开近战范围时有一些灵活性。我们也在其增益消失时将[[spell:455397]]作为高优先级使用。通常，你必须主动追踪并重新施加这个增益！
- 使用[[spell:55090]]来消耗你的[[spell:1254252]]层数。这与[[spell:85948]]同步使用，以将你的层数保持在健康的水平。你会升到4-6层，然后使用天灾打击降回3层。
- 当你没有其他事可做时，使用[[spell:207317]]作为你的填充法术！在与少于4个目标战斗时（在[[spell:1242158]]期间为6个目标），我们使用[[spell:47541]]而不是[[spell:207317]]，因为它会造成更多伤害。

### 额外概念

1.6.

#### 额外概念

本节更深入地探讨了你需要考虑的循环方面的内容。

1.7.

#### 禁断知识期间的循环

当[[spell:1242158]]激活时，我们的优先级会略有变化。我们的符文能量消耗技能在这里被我们的顶峰天赋强化，思路是尽可能地利用这一点。因此，使用[[spell:1242174]]在我们的优先级列表上变得更高！基本上，你一有机会就使用[[spell:1242174]]，无论是通过将符文能量提升到30以上，还是获得一个[[spell:49530]]的触发（并且符文能量在15以上）。

1.8.

#### 吸血打击钓鱼

在使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因英雄天赋时，保持[[spell:433925]]增益是一个需要掌握的重要方面。我们在[[spell:63560]]窗口期间快速叠加此增益7次（由于无限的[[spell:433901]]），然后目标是将其延长到我们的下一个黑暗突变窗口（在那里我们可以再次轻松维持它）。黑暗突变本身持续约20-35秒，所以我们实际上只需要在两次使用之间获得一次触发来跨越10-25秒的间隔！这里的关键是，如果你即将失去增益，要消耗所有的符文能量以最大化获得触发的几率！

这里需要注意的是，[[spell:43265]]在单体中不值得使用，即使有[[spell:434033]]、[[spell:1234559]]或[[spell:1290864]]。这个天赋不够强大，不足以让你按下死亡凋零，即使是为了获得延长效果。

1.

### 至暗之夜 第2赛季套装

我们的第2赛季套装强化了我们的[[spell:390196]]和[[spell:1256813]]宠物。2件套使它们施放更强大的[[spell:198407]]和[[spell:1297091]]技能。4件套使这些新技能对生命值低于35%的敌人伤害提高130%，提升我们的斩杀能力。

1.

### 职业与专精机制详解

本节深入探讨了邪恶死亡骑士的机制，涵盖了我们使用的资源以及一些高级主题，这些主题在试图更深入地理解循环时可能有用。

### 符文与符文能量

3.1.

#### 符文

你总共有6个符文，默认情况下可用。你的一些技能有符文消耗，每当你使用消耗一个或多个符文的技能时，那些符文会立即开始充能。符文充能所需的确切时间取决于你拥有多少急速。

每当消耗一个符文时，你会获得10点符文能量（下文详述）。

最多可以有3个符文同时处于充能状态。因此，最好让至少3个符文处于冷却状态，以在整场战斗中最大化充能速率。

3.2.

#### 符文能量

符文能量是一种类似于怒气的资源，它在脱离战斗时会衰减，但在战斗中不会衰减。如上所述，消耗符文每花费一个符文会产生10点符文能量，这是产生符文能量的主要方式，尽管一些技能也有助于此。你的符文能量上限为100点。

作为邪恶死亡骑士，决定是否优先使用符文还是符文能量是一个棘手的决定。我们会溢出资源，通常需要二选一。通常，你希望在单体中避免符文溢出（超过3个），在范围伤害中避免符文能量溢出（超过100）。

### 巅峰天赋

3.3.

#### 巅峰天赋

邪恶死亡骑士在至暗之夜中从80级升到90级时，可以解锁[[spell:1242158]]巅峰天赋。第一层在你施放[[spell:42650]]后提供30秒的增益，将你的[[spell:47541]]变为[[spell:1242174]]，将你的[[spell:207317]]变为[[spell:383269]]。这些新能力是基础版本的强大版本，特别是为[[spell:47541]]增加了AoE效果。对循环的影响是，[[spell:1242174]]在AoE中最多对5个目标使用（[[spell:47541]]最多只对3个目标使用）。

第2层和第3层（[[spell:1256565]]）在施放[[spell:1247378]]时提供精通，并叠加一层[[spell:1254252]]。循环中需要的[[spell:85948]]略少一些，但其他方面变化不大。

第4级（[[spell:1256566]]）使[[spell:1240996]]有20%的几率以100%的效果触发[[spell:1247378]]，显著增加循环中触发的[[spell:1247378]]总数。

保持良好的[[spell:1240996]]和[[spell:455397]]覆盖率对于充分发挥这个天赋至关重要。此外，你的宠物必须设置为协助模式才能正常运作。

### 符文腐蚀

3.4.

#### 符文腐蚀

[[spell:51462]]在我们消耗符文能量时有几率触发。它也可以在我们消耗[[spell:49530]]和[[spell:178819]]时触发。无论急速如何，触发总会总共恢复0.9个符文。触发也可以叠加，将任何新的持续时间添加到之前的剩余持续时间上。这一切的意思是你不需要关注这个过程。

:::details TC我需要围绕符文腐蚀的触发来操作吗？
不需要。触发会相互叠加。如果你获得另一个触发，任何剩余的持续时间都会简单地添加到新的触发上。

:::

### 瘟疫

3.5.

#### 瘟疫

[[spell:191587]]是一个暗影伤害的持续伤害效果（DoT），通过使用[[spell:77575]]或配合[[spell:1254552]]的[[spell:1247378]]施加到目标身上。这是我们的范围瘟疫。

[[spell:1240996]]是一个仅限单体目标的持续伤害效果（只能施加到一个目标），施加方式与[[spell:191587]]相同。这也是我们[[spell:49530]]和[[spell:1256566]]触发的来源。

### 反魔法护罩

3.6.

#### 反魔法护罩的使用

[[spell:48707]]吸收你受到的所有魔法伤害的100%，最多为最大生命值的30%，持续5秒，并根据其吸收的伤害量为你提供符文能量。

虽然这个技能具有惊人的生存能力，让你经常可以从各种团队伤害机制中几乎不受伤害，但它对你的DPS也有很大的好处。

确实，如果你吸收了大量魔法伤害，你获得的符文能量远非可以忽略不计。因此，你应该始终尝试利用反魔法护罩来提升你在整场战斗中的符文能量生成。最好的方法是知道什么时候会有团队伤害攻击到来，并在那时开启反魔法护罩。然后，简单地享受额外的符文能量（别忘了消耗它）。

话虽如此，对于开荒内容，我们完全建议首先将[[spell:48707]]保留用于减轻魔法伤害，然后再考虑如何使用它来提升你的DPS。

1.

### 邪恶死亡骑士的重要冷却技能

### 冷却技能时机

4.1.

#### 冷却技能时机

在团队副本中，我们总是尽可能地将我们的冷却技能组合使用。这效果很好，因为它们都以45秒的周期对齐。一个4分钟Boss战的冷却技能计划如下所示：

- 00:00 — [[spell:42650]] + [[spell:63560]]
- 00:45 — [[spell:63560]]
- 01:30 — [[spell:42650]] + [[spell:63560]]
- 02:15 — [[spell:63560]]
- 03:00 — [[spell:42650]] + [[spell:63560]]
- 03:45 — [[spell:63560]]

由于一切完美对齐，这是 **至关重要** 你应该在冷却技能一好就立刻使用。任何延迟都意味着你的1.5分钟爆发窗口将被延迟，可能会让你错过大量价值。

在大秘境中，核心在于冷却时间的效率。把冷却技能留着“等下一大波怪”而浪费掉大量价值太容易了。一般规则是尽可能多地使用你的冷却技能，尤其是当你单独使用 [[spell:63560]] 时。这是提升你在大秘境中 DPS 最简单的方法！

### 黑暗突变

4.2.

#### 黑暗突变

[[spell:63560]] 会使你的食尸鬼变形 15 秒，使其 爪击 技能能顺劈宠物附近的所有敌人。如果你点了 [[spell:377514]] 天赋，你还能无视目标生命值免费获得一次 [[spell:343294]]！此外，[[spell:63560]] 会通过 [[spell:390259]] 天赋大幅强化你的仆从！

你应该在冷却好时就使用这个技能。每第二次与[[spell:42650]]对齐。此外，在进入你的[[spell:63560]]窗口时带有高层数的[[spell:1254252]]（6-8层）是一个好主意，这样你可以花更多时间召唤宠物进行大爆发，而花更少时间用[[spell:85948]]来叠层数。

### 腐化

4.3.

#### 腐化

[[spell:1247378]]召唤并牺牲一个[[spell:275430]]来打击目标，然后爆炸造成范围伤害。它通过天赋获得额外效果，主要是[[spell:1254552]]使其也能在你的瘟疫尚未施加时施加它们，以及通过[[spell:1256813]]召唤一个[[spell:390196]]。

最佳地使用[[spell:1247378]]是一个相对困难的优化过程。这里需要考虑的主要方面是你通过[[spell:390259]]获得的对这个技能的巨大增益。因此，我们希望将我们的使用集中在我们的[[spell:63560]]窗口内。在游戏玩法上，这意味着你希望在[[spell:63560]]期间积极地使用你的充能。不要在你的黑暗突变结束后的窗口（在下一个窗口之前）使用充能（即使有3层）。你理想情况下应该在每个黑暗突变窗口开始时带有2次[[spell:1247378]]。

:::details TC为什么我的腐化伤害这么低？
这通常是由于你的触发几率过低导致的

[[spell:1256566]]

天赋触发率低，而这是由于

[[spell:1240996]]

和

[[spell:455397]]

维持率低造成的。此外，如果你的宠物没有设置为协助模式，你获得的随机触发实际上无法正常运作。

:::

### 瘟疫降临

4.4.

#### 瘟疫降临

[[spell:1271974]]是一个有趣的技能，与你的瘟疫有很强的协同作用。一旦你使用了[[spell:63560]]，你的[[spell:63560]]就会变成[[spell:1271974]]。这个新技能会消耗目标及其周围所有目标身上的所有瘟疫，一次性造成剩余伤害的100%的大爆发。

Blightfall的目标相对简单，将你的持续伤害效果（DoT）叠加到尽可能高的持续时间，然后消耗它们，同时尽可能多地保持增益激活。实际上，在单体中，这通常意味着你在[[spell:63560]]接近结束时使用[[spell:1271974]]，此时你的饰品增益仍然激活。然后你延迟使用[[spell:343294]]来重叠这次使用。

### 枯萎凋零

4.5.

#### 枯萎凋零

[[spell:43265]]通常不值得为了其伤害而使用。与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因的[[spell:434033]]和[[spell:1234559]]有协同作用，但这两个天赋都不够强大，不足以让你值得按下死亡凋零。

[[spell:1290864]]确实创造了[[spell:1247378]]和[[spell:43265]]的强大反馈循环。在使用这个天赋时，在范围伤害场景（3个以上目标）中使用死亡凋零以获得腐化的冷却缩减是值得的。否则，你主要使用它来配合[[spell:273952]]进行减速。你可以将其叠加在自身之上，这意味着在大秘境中，你在起手式中使用[[spell:1247378]]之后会使用双重死亡凋零，以连续获得大量充能。

使用[[spell:1290864]]时，你按以下方式使用它：如果你在进入冷却技能时带有3层[[spell:1247378]]，则在使用完所有腐化充能后使用[[spell:43265]]。如果你在接近冷却技能窗口时没有最大层数的[[spell:1247378]]，则在窗口之前使用[[spell:43265]]以达到最大层数。

[[spell:1234559]]会增加其伤害，但当你计算时，平均只增加40%。

### 亡者大军

4.6.

#### 亡者大军

[[spell:42650]]召唤几个食尸鬼在你身边战斗15秒。如果点出天赋，它还会召唤一个[[spell:390196]]。最后，通过[[spell:1242158]]顶峰天赋，它将[[spell:47541]]转化为[[spell:1242174]]，将[[spell:207317]]转化为[[spell:383269]]，持续30秒。这是一个重要的冷却技能，在任何情况下都会成为我们总伤害的重要组成部分。

在[[spell:42650]]期间，你不能再召唤更多[[spell:275430]]。取而代之的是，本应召唤食尸鬼的技能会让现有的食尸鬼施放[[spell:1294264]]（单体）或[[spell:1300330]]（范围伤害）。

[[spell:288853]]在这个冷却技能期间额外召唤一个憎恶，持续30秒。憎恶有一个范围疾病光环，使敌人受到你的仆从的伤害提高20%。

[[spell:49206]]在这个冷却技能期间额外召唤一个石像鬼，持续25秒。石像鬼以一个根据你消耗的符文能量量而增加伤害的攻击来攻击你的目标。激励在宠物出场时优先消耗符文能量。

1.

### 邪恶死亡骑士战斗助手

《地心之战》11.1.7版本为游戏中所有专精引入了战斗助手功能。它以两种工具的形式呈现，可用于辅助你的循环。辅助高亮功能会点亮你接下来应该使用的法术，帮助你确定需要按下哪个按钮。单键助手会为你提供一个按钮，自动按下相应的法术。
**单键助手每次按下时会有0.2秒的公共冷却时间惩罚，人为地减慢你的循环**。这种惩罚意味着使用单键助手时，你的DPS总是低于完美执行循环时所能达到的水平。

那么这些助手能打出多好的循环呢？如果我们假设你能完美地使用你的冷却时间，辅助高亮大约会损失5%的DPS。使用单键助手时，这个数字大约是15%。请记住，这是与绝对最优操作相比。循环经验不足的玩家使用助手时，损失可能会明显更小，甚至可能有所提升。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月25日：** 将默认天赋选择更新为包含灵魂收割。
- **2026年9月23日：** 将默认选择更新为萨莱因。
- **2026年9月8日：** 根据热修复更新优先级列表。
- **2026年8月25日：** 澄清了凋零瘟疫的使用方法。
- **2026年8月13日：** 更新了凋零瘟疫的使用方法。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月29日：** 已根据12.1版本的改动更新了输出循环。
- **2026年7月8日：** 更新了在AOE场景中的符文能量优先级。
- **2026年6月15日：** 已为12.0.7版本更新。
- **2026年6月6日：** 更新了符文能量与符文的优先级。
- **2026年5月2日：** 澄清了凋零的使用方式。
- **2026年4月21日：** 澄清了凋零的使用方式和符文能量的优先级。
- **2026年4月20日：** 已根据12.0.5版本的改动更新了输出循环。
- **2026年3月29日：** 移除了单键助手的主要冷却时间功能。
- **2026年3月16日：** 添加了套装部分。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 已为12.0.1补丁更新。
- **2026年2月2日：** 在起手式中加入了一次死亡缠绕。
- **2026年1月25日：** 更新为在2个目标时使用死亡缠绕。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025年11月28日：** 在输出循环页面添加了常见问题解答。
- **2025年10月28日：** 修复了一个失效的优先级列表，并更新了部分措辞。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月14日：** 更新了起手式。
- **2025年9月7日：** 澄清了在伤口层数饱和时使用收割的时机。
- **2025 年 8 月 25 日：** 更新了死亡缠绕与传染的目标数量。
- **2025年8月7日：** 修复漏洞后更新了天启的使用方式。
- **2025年8月4日：** 为11.2版本更新。改进了选择框，新增了天赋并更新了输出循环。
- **2025年6月27日：** 将溃烂之触部分移至输出循环板块，并改进了一些关于伤口和符文能量的措辞。同时添加了毕业装备的使用方式。
- **2025年6月15日：** 添加了更多图片板块以提高可读性，并修复了一些小问题。同时添加了关于战斗助手的章节。
- **2025年4月27日：** 在大秘境中，在溃烂之伤前添加了3次吸血打击。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月14日：** 更新了天启在AOE输出循环中的使用方式。
- **2025年4月7日：** 更新了起手式，加入了延后召唤憎恶体。
- **2025年3月16日：** 阐明了大秘境输出循环。
- **2025 年 2 月 24 日：** 阐明了萨莱因萨莱因在AOE中死亡缠绕的使用方式。
- **2025年2月20日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月26日：** 阐明了巨魔之灾的寒冰锁链寒冰锁链优先级。
- **2024年10月21日：** 添加了溃烂镰刀的玩法内容。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季更新，添加了所有新饰品的详细使用方式。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年2月14日：** 添加了溃烂之触玩法的详细说明。
- **2024年1月23日：** 在改动后更新了菲莱拉兹的优先级。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年12月20日：** 对单体目标优先级进行了少量澄清。
- **2023 年 12 月 12 日：** 在起手式中添加了传说装备。
- **2023年12月2日：** 更新了伤口输出循环部分。
- **2023年11月24日：** 在起手式部分添加了宏。
- **2023 年 11 月 12 日：** 澄清了邪恶起手式中黑暗转化和召唤石像鬼在同一行。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月21日：** 在详细饰品使用部分添加了镜像。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月25日：** 起手式中从最多4个凋零缠绕改为正好3个。
- **2023年6月14日：** 添加了更详细的饰品和种族技能时间轴。
- **2023年5月24日：** 解决了起手式无法正常显示的问题。
- **2023年5月3日：** 在起手式中加入了枯萎凋零，并扩充了冷却技能使用章节，加入枯萎凋零。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月29日：** 已针对10.1版本进行审查和更新。
- **2023年4月15日：** 扩充了疾病流派循环。
- **2023年3月20日：** 为10.0.7版本更新了循环。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到《魔兽世界》12.1.5版本中邪恶死亡骑士的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章升级装备的建议，我们一应俱全！

1.

### 邪恶死亡骑士毕业装备指南

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含邪恶死亡骑士来自所有来源的最高DPS配置。请注意，还有许多其他配置的表现在误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择和你拥有的装备，你下一个最佳装备在某些方面可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第二赛季中，催化一件装备会保留其副属性（以及物品等级）。这为我们在优化装备分配时提供了更大的灵活性。因此，我们希望使用以下部件：

- 头部：[[item:281239@JAACAAQ42A]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 肩膀：[[item:251138]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 胸部：[[item:268222]]，来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 手套：[[item:271475]]，来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- 腿部：[[item:271878]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details 常见问题我应该优先选择哪些物品？
有几件物品在你的毕业装备中优先级非常高，你希望从宏伟宝库和虚空核心使用中优先获取：

- [[item:268213]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：毕业武器，装等更高且带有额外效果，使其比任何其他选择都更强。
- [[item:270175]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：更高物品等级的毕业主动使用饰品。
- [[item:268265]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业的项链，物品等级更高并带有额外效果。
- [[item:270173]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：毕业的被动饰品，与我们的毕业武器协同。
- [[item:281029]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业的戒指，带有额外效果。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:281239@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271473@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271477@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[spell:327082]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

此列表包含邪恶死亡骑士来自大秘境来源的最高DPS配置。这不是你的最佳配置 **，而是** 仅限大秘境 **来自** 大秘境的。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第二赛季中，催化一件装备会保留其副属性（以及物品等级）。从大秘境中，我们希望催化以下部件：

- 头部 - [[item:251126]]
- 肩部 - [[item:251138]]
- 胸部 - [[item:268222]]
- 手部 - [[item:159413]]
- 腿部 - [[item:273776]]

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：可靠的武器、护肩、头盔和一个还不错的饰品。
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：毕业戒指和一个可靠的项链。
- [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)：不错的腰带和鞋子。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271474@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAAEAAAj1gjM]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271473@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:239656@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>脚部</th><td>[[item:159412@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271477@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273797@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:251134@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[spell:327082]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

此列表包含邪恶死亡骑士来自团队副本来源的最高DPS配置。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，催化一件装备会保留其副属性（和物品等级）。来自团队副本，我们想要催化以下装备：

- 头部 - [[item:281239@JAACAAQ42A]]
- 肩部 - [[item:268226]]
- 胸部 - [[item:268222]]
- 手部 - 套装部件
- 腿部 - [[item:271878]]

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:268213]]：毕业武器，装等更高且带有额外效果，使其比任何其他选择都更强。
- [[item:270175]]：更高物品等级的毕业主动使用饰品。
- [[item:268265]]：更高物品等级且带有额外效果的毕业项链。
- [[item:270173]]：与我们毕业武器协同的毕业被动饰品。
- [[item:281029]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业的戒指，带有额外效果。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:281239@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271473@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271477@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[spell:327082]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 第2赛季邪恶死亡骑士饰品推荐

邪恶死亡骑士偏好一个主动饰品和一个被动饰品的组合。对于主动饰品，[[item:270175]]是我们目前的最佳选择，与我们1.5分钟的冷却时间有极佳的协同作用。由于掉落自最终首领，它的装等也更高。

对于被动饰品，[[item:270173]]是我们应对低目标数量场景的最佳选择。它是一个直接伤害的被动饰品，与我们的毕业武器[[item:268213]]有协同作用。在AOE场景中，[[item:270165]]会比断头台技法更好。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **邪恶死亡骑士饰品**
**使用型 -**

[[item:270175]]

或者，作为替代，

[[item:273797]]

**被动 -**

[[item:270173]]

或者，作为替代，

[[item:270165]]

:::

还有不少其他有价值的饰品，所以请务必点击我们的排名图表，看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看邪恶死亡骑士饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;&#10;&#10;[[item:270175]] - <span><em>点击查看详情</em></span>&#10;<span>目前最好的主动使用饰品，与我们1.5分钟的冷却时间协同良好。它比第二好的主动饰品领先近4%，因此没有真正的争议。&#10;       </span>&#10;&#10;&#10;&#10;[[item:270173]] - <span><em>点击查看详情</em></span>&#10;<span>低目标数量时的最佳被动饰品。其伤害触发效果实在太强了，尤其是与我们的毕业武器[[item:268213]]搭配时。&#10;       </span>&#10;&#10;&#10;&#10;[[item:281215]] - <span><em>点击查看详情</em></span>&#10;<span>AoE场景下最好的被动属性饰品。凭借其高触发率，在低目标数量下它接近于断头台的表现，但在多目标场景中更为出色，在大秘境内容中尤其有效。&#10;       </span>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:249343]]（298 物品等级）</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:246305]]</li>&#10;<li>[[item:241340]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:193762@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273796]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:246307]]</li>&#10;<li>[[item:270163]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

至暗之夜的12.0.5版本引入了一个新的、但似曾相识的系统： [混沌虚空核心](<https://www.wowhead.com/currency=3418>)
允许你定向获取特定首领或地下城的战利品。使用它可保证从该来源掉落一件物品，不过具体是哪件仍然是随机的。然而，一旦你以这种方式获得了一件物品，未来的使用将优先考虑你尚未从该物品池中收集到的物品。

[[item:268552]]可以强化已经达到最高物品等级的英雄和史诗难度装备，以及完全升级的光辉锻造物品。它提供类似过往涡轮加速升级的额外威力提升，但只能应用于武器和饰品。

3.1.

#### 虚无核心推荐

从特定地下城或首领处获得一件有保障的战利品非常有用。总体而言，我们推荐将其用于团队副本首领，因为这样可以获得更高物品等级的装备。我们推荐将其用于以下首领（如果你还没有指定的物品的话）。务必自行模拟，以找到最适合你角色装备和属性的选择！

- [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 适用于[[item:268213]]和[[item:270173]]。
- [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 适用于[[item:270175]]、[[item:271878]]和[[item:268265]]。

3.2.

#### 至高毒石推荐

优先升级装备相对简单：从你的武器开始，然后是你的饰品，最后升级你的项链。

1.

### 邪恶死亡骑士最佳制造物品

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

决定制造什么是一项困难的任务。我们的毕业制造物品是靴子和护腕，都带有暴击精通和[[item:240167]]。然而，早期制造一把双手武器通常是目前最大的提升，并且是使用你纹章的更高效方式。它虽然落后我们的毕业装备不少，但仍然能提供强大的早期提升。大多数人通常会先制造一把双手武器。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **邪恶死亡骑士制造装备优先级**
- [[item:237828@JAAMAAwt1ENMMYDYwclIcYD]]搭配[[item:240167]]
- 任何你还没有达到神话品质的物品。如果你还没有2个装饰效果，请使用[[item:240167]]制造。
- [[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]搭配[[item:240167]]

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 邪恶死亡骑士最佳装饰效果

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

由于衬饰的竞争非常激烈，你必须为你整体的DPS输出挑选出最强的两个。大多数衬饰提供的DPS收益非常相似，即使效果完全不同。对此最佳的两个选择是：

- 团队副本：在制造的靴子和制造的护腕上使用[[item:240167]]。
- 大秘境：在制造的靴子和制造的护腕上使用[[item:240167]]。

一个强力的替代方案是在制造的双手武器上使用[[item:245876]]或[[item:273060]]。这在赛季初期尤其强大，因为它让你能获得一把高装等的武器（武器是每个装等点数收益最高的部位）。因此，务必考虑在赛季早期制造一把双手武器。

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

[秘境雾崖](<https://www.wowhead.com/currency=3446>) 是一种你可以用来升级装备的货币。每件装备都属于特定的升级路线，可以升级到特定的最高等级。如果你看到一件物品显示史诗 3/6，这意味着它总共可以升级3次以达到史诗 6/6。由于纹章每周获取量有限，且升级不同物品花费的纹章数量相同，你应该优先将纹章用于那些你近期不打算更换，或能带来最大收益的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **邪恶死亡骑士纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子/戒指**

:::

这些只是通常最值得升级的物品。不要盲目遵循此优先级，因为有时你会想优先升级其他装备。务必自行模拟，以确定当前的最佳选择。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 针对12.1.5进行了更新。
- **2026年9月7日：** 热修复后审查并更新了装备。
- **2026年8月17日：** 新增了最佳制造物品章节。
- **2026年8月13日：** 扩展了饰品梯队列表。
- **2026年8月10日：** 已根据12.1版本的毕业装备和饰品进行更新。
- **2026年6月15日：** 已根据12.0.7版本更新，加入了孢子化装备。
- **2026年5月24日：** 修正了一处装备掉落位置的笔误。
- **2026年5月20日：** 根据新的毕业装备列表格式修复了符文锻造内容。
- **2026年4月20日：** 添加了新的涡轮加速物品。
- **2026年3月28日：** 解决了最佳项链来源的一个问题。
- **2026年3月16日：** 已为第1赛季更新，加入了新的毕业装备和饰品推荐。
- **2026年2月26日：** 已为至暗之夜更新，加入了赛季前的毕业装备。
- **2026年2月10日：** 已为至暗之夜前夕更新，将毕业装备调整为符合新的属性优先级，并加入了午夜升级物品。
- **2025年11月30日：** 已为11.2.7补丁进行审查和更新，将棱彩提升到饰品梯队列表的更高位置。
- **2025 年 10 月 5 日：** 新增可疑的卡特尔筹码。
- **2025年9月7日：** 修复了一个饰品的错别字和列表问题。
- **2025年8月14日：** 更新了毕业饰品。
- **2025年8月4日：** 为11.2版本更新。更新了毕业装备，新增了披风和新饰品。
- **2025年6月23日：** 在调整后更新了最佳D.I.S.C.效果。
- **2025年6月15日：** 添加了D.I.S.C.腰带。
- **2025年5月14日：** 将暮纹作为通用推荐更换，并添加了关于制作武器升华的信息。
- **2025年4月27日：** 更新了卡特尔筹码的措辞。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月2日：** 在调整后更新了饰品。
- **2025年3月3日：** 在削弱后更新了毕业装备。
- **2025年3月1日：** 在加强后更新了套装段落。
- **2025 年 2 月 24 日：** 更新了毕业配装列表、饰品梯队列表、装饰、制造推荐和套装部分。
- **2024年12月18日：** 在新的模拟数据出炉后更新了塞尔西的宝石。
- **2024年12月17日：** 在增强后更新了毕业配装列表以包含塞尔西的头冠。
- **2024年12月15日：** 针对11.0.7版本更新，添加了塞尔西的头冠。
- **2024年10月26日：** 解决了团本毕业装备列表中的一个问题。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年10月5日：** 更新了毕业饰品。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季更新，包括金币优先级和新的毕业装备列表。
- **2024年3月20日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月29日：** 在传说装备公布后更新了毕业装备。
- **2023年11月22日：** 更新了永恒黎明的掉落位置，以区分上层和下层。
- **2023年11月15日：** 将灰烬添加到团本毕业装备中，并在主动饰品列表中将其上移。
- **2023年11月7日：** 在孢子披风削弱后更新了毕业装备列表和美化推荐。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 为10.1.7版本更新。
- **2023年7月20日：** 更新了毕业饰品和项链。
- **2023年7月10日：** 更新了饰品毕业装备，并添加了永恒黎明的装备提示。
- **2023年5月10日：** 谜题削弱后更新了饰品毕业推荐。
- **2023年5月8日：** 改动后更新了毕业列表和饰品优先级。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月30日：** 为10.1版本进行了审阅和更新。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页中，你将找到你的邪恶死亡骑士的最佳属性优先级。我们首先介绍属性优先级，然后深入探讨这些属性如何与你的专精和游戏玩法互动的更复杂解释。我们的内容已更新至《魔兽世界》12.1.5补丁。

1.

### 邪恶死亡骑士属性优先级

在团队副本和大秘境中，邪恶死亡骑士的副属性优先级如下：

暴击

精通

急速

全能

邪恶主要追求暴击、精通和急速的良好平衡。重要的是，这三种属性明显优于全能。

通常，装等较高的装备比装等较低的装备提升更大，即使后者的属性更好。

1.

### 深入属性解析

**力量** 是你的主要属性。你应该在所有升级中寻找它。它为你提供攻击强度，决定了你技能的伤害。

**精通**，通过[[spell:77515]]，提升你的暗影和仆从伤害。此外，它还提升你的疾病和仆从的暴击伤害。由于暴击伤害的互动，我们通过精通获得了更高阶的加成。这反过来使得精通和暴击都成为我们的强力属性。

**急速** 将提升你的攻击速度和符文恢复速度。它还会降低你的公共冷却时间。对于你的宠物，它会提升它们的攻击速度以及能量恢复速度，使它们更频繁地使用技能。

**暴击** 提高你所有法术和技能的暴击几率。暴击默认造成双倍伤害，但有多种效果可以提高你的暴击伤害，使暴击更加强力。

**全能** 增加你造成的所有伤害和治疗，并减少你受到的所有伤害。

对于邪恶，你的宠物和仆从会继承你的属性。提升你的急速会让它们攻击更快、能量恢复更快。暴击会提升它们的暴击几率，等等。属性会动态地更新到宠物身上，这意味着你获得的新增益也会应用到你当前拥有的任何宠物身上。这意味着你无需担心在召唤任何仆从之前先施加增益！然而，重要的是要认识到这种继承并非瞬间完成！宠物需要0到5秒的时间才能真正从我们这里继承属性（无论是获得还是失去属性时都是如此）。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月8日：** 从精通中移除亡者指挥官的互动，这些在12.1中已被移除。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月29日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 更新了12.0.5版本的毕业属性分配。
- **2026年4月10日：** 澄清了鲁莽的价值。
- **2026年3月16日：** 对最佳属性分配进行了小幅更新。
- **2026年2月26日：** 已为至暗之夜更新，加入了新的属性分配示例。
- **2026年2月10日：** 根据新的鲜血盟约天赋配置更新了属性权重。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 添加了急速常见问题解答。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 为11.2版本更新，大幅提高了暴击的属性价值。
- **2025年6月15日：** 修正了错别字并阐明了属性优先级。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季更新，更改了提到的原始属性数值，并阐明了大秘境中属性等值的优先级。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本更新，添加了关于宠物属性继承延迟以及原始属性对镜像触发影响的讨论。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月30日：** 为10.1版本进行了审阅和更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的邪恶死亡骑士可以使用的最佳宝石、附魔、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

我们推荐将[[item:240983]]作为你的史诗宝石，然后将[[item:240906]]或[[item:240908]]作为你的非史诗宝石，优先选择你装备上最少的属性。也就是说，如果你装备上已经有很多急速，就镶嵌提供更多精通的宝石，反之亦然。

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>肩部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[spell:327082]] + [[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::details 常见问题：不同的符文熔炉附魔有什么作用？
- [[spell:327082]]：与你召唤的所有[[spell:275430]]有很强的协同作用，是所有内容中最好的符文。
- [[spell:53344]]：不错的力量和治疗效果，但比[[spell:327082]]差几个百分点。
- [[spell:53343]]：这个符文更适合冰霜死亡骑士，因为邪恶不造成冰霜伤害。
- [[spell:326805]]：为[[spell:49998]]提供一个小的斩杀效果和一个小的免死机制。这个符文熔炉更多用于PvP而非PvE内容。
- [[spell:326855]]：对法系职业提供少量防御，使其更偏向于PvP场景。
- [[spell:62158]]：这个符文主要是一个防御性选择，不用于邪恶。
- [[spell:326977]]：有时用于升级，因为它提供移动速度、急速，并在你击杀敌人时恢复生命值。

:::

1.

### 最佳消耗品

你可以消耗多种不同的临时物品来提升你在地下城和团队副本中的实力。以下是关于所有你想要使用物品的全面概述！

3.1.

#### 合剂

使用[[item:241326]]作为你的首选。你通常需要在所有内容中使用[[item:241326]]或[[item:241322]]中的一个。选择取决于你当前的属性，不幸的是这并不明显。如果你有很多精通而暴击不多，破碎残阳可能最好。如果你有很多暴击而精通不多，魔导师更好。你需要自己进行模拟以获得最适合你角色的最准确结果，但上述指南在99%的情况下都能很好地指导你。

3.2.

#### 药水

我们有一些药水选项可以使用，但我们推荐[[item:241288]]作为你在所有内容中的常用药水。

你还应该确保备有足够的[[item:271883]]！这些治疗药水在你需要快速治疗自己、帮助你的治疗者以及确保你存活下来时非常出色。

3.3.

#### 食物增益

在至暗之夜中，你可以选择主属性食物或副属性食物。对于邪恶死亡骑士，主属性是最佳选择。这意味着你要么吃一顿大餐，如[[item:255846]]或[[item:255845]]。如果你的队伍或团队不提供大餐，你可以吃[[item:255847]]或[[item:242275]]作为替代。

3.4.

#### 强化符文

此外，如果负担得起，你应该使用 [[item:259085]] 来提高你的主属性。强化符文价格昂贵且死亡后消失，所以请明智而节制地使用它们！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月29日：** 已为12.1补丁更新。
- **2026年6月15日：** 将默认药水更换为鲁莽。
- **2026年4月28日：** 更新了推荐的戒指附魔。
- **2026年4月20日：** 已针对12.0.5进行审阅。
- **2026年4月10日：** 澄清了药水的使用方式。
- **2026年3月16日：** 更新了食物推荐，并添加了茶类。
- **2026年2月26日：** 已为至暗之夜更新，加入了新的附魔、宝石和消耗品。
- **2026年2月10日：** 添加了关于大秘境中天启符文的说明。
- **2026年1月22日：** 更新了宝石和戒指附魔的推荐。
- **2026年1月19日：** 已为至暗之夜更新，更换了最佳符文锻造，并加入了升级用消耗品。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 移除了头盔附魔的免责声明。
- **2025年4月21日：** 添加了腐蚀附魔推荐。
- **2025年3月1日：** 将食物更换为精通急速。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审查，将腿部附魔更换为光耀套件。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023 年 11 月 12 日：** 更新了食物推荐。
- **2023年11月6日：** 为10.2版本更新。添加了新的头部附魔，并将所有属性附魔更换为精通。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月30日：** 为10.1版本进行了审阅和更新。
- **2023年3月20日：** 加入了原初石宝石推荐。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的邪恶死亡骑士挑战大秘境地下城的技巧和建议。

1.

### 邪恶死亡骑士在至暗之夜第2赛季大秘境中的表现

在本指南中，我们将讨论如何在大秘境地下城中充分发挥你的邪恶死亡骑士的潜力，包括如何最佳地设置你的角色、你的循环可能如何变化，以及最优化使用技能的技巧和窍门。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

1.

### 最佳大秘境天赋配置

邪恶死亡骑士在大秘境中有多种多样的天赋构筑，既提供独特的游戏风格，也提供不同的伤害模式。我们推荐使用基于仆从的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因构筑在大秘境中使用，因为它同时带来强大的单体和AOE伤害。

你也可以选择使用[[spell:1271974]]瘟疫构筑，或者
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士。骑士构筑能带来略高的爆发伤害，以及更好的机动性（配合[[spell:444010]]）。

### 骑士仆从

2.1.

#### 骑士仆从构筑

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) 天启骑士构筑与我们的单体骑士构筑非常相似，将[[spell:377587]]和[[spell:207272]]替换为[[spell:455135]]和[[spell:1290864]]。结果是一个多用途构筑，同时带来高单体伤害和可观的AOE能力。

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMDYzsYYgBmNGasgBMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-AeERphowgJQwwC-
```

:::

### 萨莱因仆从

2.2.

#### 萨莱因仆从构筑

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因构筑与我们的单体萨莱因构筑非常相似，将[[spell:377587]]和[[spell:207272]]替换为[[spell:455135]]和[[spell:1290864]]。结果是一个多用途构筑，同时带来高单体伤害和可观的AOE能力。

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMjBGYGbassAYbwGGwMAMmZGzgZGMjxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-TCIQUJAxwBDmmF-
```

:::

### 萨莱因凋零

2.3.

#### 萨莱因腐溃流构建

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因构筑非常注重瘟疫伤害，点出了[[spell:1271974]]天赋。凋零是一个非常有趣的天赋，其核心是积累大量的瘟疫持续时间，然后消耗它们以获得巨大的爆发伤害。

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAg5BGDDAWmhZ2MzYMjBGYGLassAYbwGGwMAmZmZGzgZGMjxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVFYgGxVko01diigAsA-RSTdfOHPHByauqwISQoE6JIIuxxpBGA-AAAA-JgIpCTDQgwgxhF-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断、昏迷和控制

[[spell:47528]] 是你的“打断”，也是你在大秘境中最重要的功能性技能，用于打断敌人的施法，使团队尤其是坦克受益。它是 **强烈推荐** 使用焦点打断宏来完成此操作。

#### 心灵冰冻 鼠标指向

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 心灵冰冻
```

这个宏会打断你的焦点目标（如果有），如果没有焦点目标则打断鼠标悬停目标，如果两者都没有则打断你的当前目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**.

#### 焦点 鼠标指向

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

3.2.

#### 眩晕与"打断"

[[spell:207167]] 是你的“AOE打断”。你致盲前方锥形范围内的所有目标，使其迷惑5秒。这是阻止一大群小怪施法的绝佳方式，尤其是当该施法免疫常规打断时。

[[spell:221562]]是你的单体昏迷技能，持续5秒。在我们的天赋配置中不是常见的选择，但它仍然是一种有用的控制工具。

[[spell:49576]]既可以帮助聚怪，也可以打断施法。记住，你需要将怪物移动一定距离才能真正打断它，这样你就不会在怪物已经贴近你时使用[[spell:49576]]。

[[spell:49576]]同时也是防御技能。配合[[spell:454822]]，它能对你使用的目标提供减伤。在首领战或小首领战中减免伤害时很有用。

啃咬是你的宠物昏迷技能，使目标昏迷1秒（在[[spell:63560]]期间为2秒）。不占用公共冷却时间，是非常有用的快速打断。

### 其他功能

3.3.

#### 其他功能

[[spell:61999]] 是一个战斗复活技能，你可以用它让死去的队友复活，即使在战斗中也可以！

[[spell:207167]]、[[spell:45524]]和[[spell:43265]]配合[[spell:273952]]都能降低被击中敌人的移动速度，使我们能够帮助任何想要风筝怪物的坦克。

[[spell:111673]]允许你在大秘境中控制一个亡灵敌人。这只是邪恶在紧急情况下使用的控制工具。控制一个亡灵敌人会失去你的主要宠物，从而损失大量伤害。如果必须这样做以帮助队伍免于灭团，那就做吧。

#### 控制亡灵

```wow-macro
#showtooltip 控制亡灵
/target pet
/script PetDismiss()
/cast 控制亡灵
```

1.

### 应对词缀

至暗之夜 第2赛季提供了四个独特的词缀，我们可以根据自身技能组合以不同程度应对它们。它们每周轮换，同一时间只有一个处于激活状态。它们也是唯一处于激活状态且需要你专门处理的词缀。

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将出现三波球体，需要被打断或阻止。[[spell:207167]] 是你处理这些球体最有效的工具，[[spell:47528]] 和 [[spell:49576]] 负责处理任何残留的球体。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：一个 虚空大使 小怪将会出现，需要被设为焦点目标并打断。只需切换到新的小怪并集火将其击杀。如果你知道它即将出现，考虑保留你的冷却技能以便快速处理它。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：球体将出现在玩家周围并绕着他们旋转。你有15秒时间吸收所有这些球体来增益你的团队。使用你的位移技能如 [[spell:212552]] 和 [[spell:343257]] 来快速吸收它们。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有小队成员都将受到治疗吸收效果的影响。你可以用 [[spell:48707]] 预先免疫。然而，这意味着你将错过护盾移除时获得的增益。或者，通过使用 [[spell:49998]] 和治疗药水/治疗石（如果需要）来帮助你的治疗者移除护盾。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月8日：** 针对12.1补丁进行了审查。
- **2026年9月4日：** 将推荐的大秘境构建更新为萨莱因随从流。
- **2026年8月24日：** 更新为推荐凋零瘟疫构建。
- **2026年8月20日：** 所有内容更新为凋零爆发。
- **2026年8月10日：** 已用12.1版本构筑进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年6月6日：** 更新了大秘境天赋配置，点出了食尸鬼狂乱。
- **2026年4月28日：** 更新了大秘境天赋配置，点出了死亡循环。
- **2026年4月22日：** 将大秘境天赋配置从憎恶更换为其他天赋。
- **2026年4月20日：** 更新了12.0.5补丁的天赋配置。
- **2026年4月2日：** 更新天赋配置为点出2个亵渎者，而非食尸鬼之爪。
- **2026年3月16日：** 已为至暗之夜第1赛季更新，加入了新的天赋配置和词缀提示。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 更新了12.0.1版本的天赋配置。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月10日：** 添加了天启骑士疾病天赋配置。
- **2025年8月4日：** 随11.2版本更新。
- **2025年6月15日：** 将天赋添加到图片板块中以提高可读性。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月14日：** 添加了详尽的地下城提示。
- **2025年3月16日：** 更新了大秘境天赋。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月30日：** 更新了伤口大秘境配置。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月30日：** 已针对10.1版本进行审查和更新。
- **2023年3月20日：** 为10.0.7版本更新了天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一些有用的宏和插件，以便在《魔兽世界》12.1.5补丁中使用你的邪恶死亡骑士时让游戏更轻松。

1.

### 最佳宏

1.1.

#### 死亡骑士通用宏

1.1.1.

##### 复活盟友

#### 复活盟友

```wow-macro
#showtooltip 复活盟友
/cast [@mouseover,help][@target]复活盟友
```

如果你的鼠标悬停目标是一名友方玩家，此宏会对其施放[[spell:61999]]。否则，它会对你的当前目标施放复活盟友。

1.1.2.

##### 心灵冰冻

#### 心灵冰冻

```wow-macro
#showtooltip 心灵冰冻
/cast [@focus,harm,nodead][] 心灵冰冻
```

此宏允许你打断你的焦点目标（如果你有的话），如果没有，则简单地打断你的当前目标。

1.2.

#### 邪恶死亡骑士专属宏

#### 爆发鼠标悬停

```wow-macro
#showtooltip 爆发
/cast [target=mouseover,exists] 爆发; 爆发
```

这个宏会在你的鼠标悬停目标上施放[[spell:77575]]。

#### 死亡之握 鼠标指向

```wow-macro
#showtooltip 死亡之握
/cast [target=mouseover,exists] 死亡之握; 死亡之握
```

此宏将对你的鼠标指向目标施放 [[spell:49576]]。

#### 解散宠物

```wow-macro
/petdismiss
```

这个宏允许你解散宠物，这在地下城中可能是必需的，以避免你的宠物意外引到怪物。

#### 死亡凋零光标宏

```wow-macro
#showtooltip 枯萎凋零
/cast [@cursor] 枯萎凋零
```

#### 反魔法领域光标宏

```wow-macro
#showtooltip 反魔法领域
/cast [@cursor] 反魔法领域
```

这些宏允许你快速在光标位置放置你的[[spell:43265]]或[[spell:51052]]。

#### 心灵冰冻 鼠标指向

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 心灵冰冻
```

此宏允许你使用鼠标指向进行打断，避免不得不切换目标来打断。

#### 焦点 鼠标指向

```wow-macro
/focus [@mouseover]
```

此宏支持使用鼠标指向快速设置焦点目标。

1.2.1.

##### 宠物宏

控制你的宠物是优化你的DPS和游戏体验的好方法，这里有一些有用的宏！

#### 宠物移动

```wow-macro
/petmoveto
```

#### 宠物跟随

```wow-macro
/petfollow
```

让你的宠物攻击你当前的目标有时非常有用。通常当你切换目标时，你也想让宠物跟着切换，以最大化你的爆发伤害。这在你的宠物“卡住”攻击其他目标时也有帮助，比如副本里的训练假人（确实会发生）。

#### 宠物攻击

```wow-macro
/petattack
```

重新召唤宠物有时是让它回到你身边的最后手段。这个宏会在你有宠物时解散它，在你没有宠物时复活它。注意不要频繁刷这个宏，因为它可能会不小心解散你的宠物两次，导致你需要等待30秒才能再次召唤它。

#### 宠物重新召唤

```wow-macro
/script PetDismiss()
/cast [nopet] 亡者复生
/petfollow
```

1.2.2.

##### 控制亡灵

在副本中控制亡灵生物通常会对邪恶专精造成很大的DPS下降。然而，有时为了强力控制（CC）是必要的。下面的宏会自动解散被控制的宠物，然后立即控制它：

#### 控制亡灵

```wow-macro
#showtooltip 控制亡灵
/target pet
/script PetDismiss()
/cast 控制亡灵
```

1.

### 最佳插件

2.1.

#### 死亡骑士通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月8日：** 修复宏描述顺序。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已针对12.0.5进行审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月12日：** 已为至暗之夜第1赛季更新，加入了死亡之握宏。
- **2026年2月26日：** 已为至暗之夜更新，加入了新的宏复制内容。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 已针对11.2.7补丁进行审核和更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1版本审查并更新。
- **2024年12月15日：** 已针对11.0.7版本审查并更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年4月30日：** 为10.1版本进行了审阅和更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
