## 专精概览

Welcome to our Protection Paladin guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to tank as a Protection Paladin in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your survivability.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Protection Mythic+ Resources

[NEW! Top Protection Talent Builds](<https://raider.io/specs/protection-paladin/talents>)

[Top Protection Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/paladin/protection>)

[Protection Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=paladin--protection>)

[Popular Protection Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=paladin--protection>)

1.

### Protection Paladin Overview

As a Protection Paladin, you can expect to perform the role of a solid and
reliable tank. In general, your damage intake will be relatively smooth, with
many attacks being blocked by your shield or softened by your strong active
mitigation. No other tank class has quite the array of tricks up their sleeve that a Paladin does.

Good Damage, Not the Best but More Than Suitable

Protection Paladins can switch their talents to focus on single-target damage (Raiding) or
AoE damage (Mythic+), with their playstyle barely changing between the two. The big damage
cooldown (

[[spell:384376]]

) is frequently available and utilising your Holy Power effectively
gives you greater cooldown availability. Compared to other tanks, their damage is lower but in a generalist
sense it is more than sufficient for keeping threat and dealing a decent amount of damage for a tank.

More Than Capable For Every Fight In Mythic

Protection Paladin, like any tank, can handle every fight on Mythic difficulty. However,
they shine the most in fights where they can completely negate or trivialise mechanics
with

[[spell:642]]

or

[[spell:204018]]

. At the time of writing
there does not look to be any core mechanics which can be completely negated. If this changes
this will be updated and the performance score updated to reflect that.

Strong Utility and Interrupts

Protection Paladins are a consistent high end choice for Mythic+. While they may not
always be the best pick, they are very strong in this content due to bringing a wide array
of utility (see Utility section), a steady stream of interrupts (

[[spell:375576]]

/

[[spell:31935]]

/

[[spell:96231]]

), and can AoE taunt while being immune to all
damage with

[[spell:204077]]

.

The Undisputed Champion Of Group Utility

Protection Paladins offer numerous strong utility options. You can:

- Remove Poison and Diseases with [[spell:213644]]
- Clear root and slow effects with [[spell:1044]]
- Give other players immunity from Physical damage ([[spell:1022]]) or Magic damage
  ([[spell:204018]])
- Provide external damage reduction to other players with [[spell:6940]]
- Heal other players with spare Holy Power with [[spell:85673]] or save them from being at
  dangerously low health with [[spell:633]]

In a majority of dangerous scenarios you have a tool that can help your group!

Planning Required to Survive End Game Content

A slight increase for Season 2 on Protection Paladin defensiveness with [[spell:385438]] becoming an
option that you can realistically pick in the talent tree.

However, Protection Paladins are still **heavily reliant** on good cooldown planning as they have one of the lowest
health pools out of all tank specializations. With good planning they come out on top in most dangerous
scenarios, however if you go into a piece of challenging content without a good plan you can expect to
see yourself asking for a Combat Res.

However this is not all doom and gloom, Protection Paladins do have frequent access to their defensive cooldowns,
with [[spell:31850]] being readily available to the point where
you can use them rotationally. Making this aspect of cooldown planning almost trivial.

[[spell:86659]] has been made more readily available with 2 charges and a shorter cooldown
and [[spell:642]] is more infrequent but also more powerful
at preventing even the hardest-hitting bosses and trash pulls. These will require some more thought as
to when and where you use them.

[[spell:642]] can even prevent all damage, with the exception of a few rare scenarios where
damage is ignoring such immunity effects, and with [[spell:204077]] it can also act as an AoE taunt!

Additionally, the new Apex Talents will prevent any situation where you are without Holy Power to have
[[spell:53600]] active.

Without the Horse You Are the Cart

Protection Paladin mobility is done in bursts with [[spell:190784]], but that's all
the mobility we have. Once the charges are used up, we have no way of moving quickly
from point A to point B, and even something as simple as killing things quite quickly
and moving between trash packs in Mythic+ is a much slower affair than it is
for other tanks.

In scenarios where heavy movement is required, Protection Paladins will find themselves
either falling behind the rest of the group or needing external mobility tools to assist them.

2.

### Protection Paladin in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 contains two new pieces of content: a single-boss raid where every item has a bonus 
effect making it very desirable for all raiders, and the new mega-delve, where you are able 
to pick specific gear slots to obtain, even on Myth track!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) acts as an escalation to the progression of Season 2 in
Midnight, with the story surrounding Ula'tek and the Amani culminating in a new one-boss
raid, access to ascended item levels, multiple sources of catch up gear,
and access to an infinite number of Mistcrests to upgrade it. Make sure to check out our
patch hub for all the information on what is new, or has been updated with Patch 12.1.5.

2.3.

#### Class Changes

Protection Paladin sadly didn't receive any changes for Patch 12.1.5, so the most recent
updates can be found by clicking the dropdown below. That being said, the new gear and
[[item:280562]] led to some changes on our [gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>),
so make sure to head over there to be up-to-date on all the new information!

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_divineshield.jpg>) Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Class Changes

Patch 12.1 brings a large rebalance to the Protection Paladin spec tree where you are now 
able to comfortably pick up all of the key defensive talents without the opportunity cost 
of losing damage. You are able to pick [[spell:204018]], [[spell:385438]] and 
[[spell:379021]] through standard pathing through the tree. A great change for Protection Paladin 
cooldown consistency!

There have also been some improvements to Single Target damage but at the cost of some burst AoE.

Check the [Talents](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>) and 
 [Gear](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>) Guides for more information.

2.5.

#### Talent Changes

[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

Developers' notes: With these changes we're intending to reduce the opportunity cost associated with 
	taking Sentinel and broadening the suite of defensive talent options. We're also transferring some power 
	out of strong cooldown windows and into baseline throughput, with the goal of reducing associated threat 
	pain points and improving the feel of combat outside of cooldowns.

The following is a short list of the changes mentioned in this Patch:

- **Talent Reshuffle:** Several talents have moved within the tree allowing you to pick 
  talents such as [[spell:385438]] without sacrificing damage. [[spell:53376]] has been removed.
  [[spell:393114]], [[spell:377053]], and [[spell:1238903]] have all been
  redesigned, and [[spell:1301732]] is introduced as a new talent.
- **Defensive Buffs:** [[spell:393114]] now grants
  20% maximum Health while active and no longer cancels when the cheat death aspect triggers. 
  [[spell:377053]] provides 10% damage reduction, and additional buffs to
  to [[spell:209389]], [[spell:1245891]], and [[spell:1244019]]. A subtle change has happened with
  [[spell:86659]] where it now has an internal cooldown preventing you from using both charges 
  at the same time.
- **Single Target Damage Increases:** Core rotational abilities have been
  significantly buffed, with [[spell:53600]],
  [[spell:20271]], [[spell:31935]], [[spell:26573]] and
  [[spell:53595]] all receiving sizeable damage increases.
- **AoE Damage Nerfs:** Several of Protection Paladin's strongest burst AoE
  talents have been toned down, with [[spell:429826]],
  [[spell:431625]], [[spell:433718]], and
  [[spell:1260429]] all recieving varying degrees of toning down.

:::

### Midnight   Changes Overview

2.6.

#### Midnight Changes for Protection Paladin

Midnight is here and with it comes a large amount of changes! Many talents have been removed 
with new talents being added to replace them, new Hero Talents have been added but the core rotation 
for Protection Paladins have not changed much. The main rotational piece you are likely to notice is 
that [[spell:24275]] is now a passive ability and will replace [[spell:20271]] when you are 
in [[spell:384376]], [[spell:387174]] has been removed, and [[spell:86659]] is now a 
3 minute cooldown.

The core Paladin Talent Tree looks very similar to how it was in The War Within. The Protection Talent Tree 
has had a bit of a shake up with the left side of the tree focusing more on [[spell:31935]] and the right 
side focusing on [[spell:26573]]. These changes complement the spells rather than changing how they function. 
The end result is that the rotation has not really changed, so you do not need to worry about learning how to play 
Protection Paladin all over again!

2.7.

#### New Apex Talents

Apex Talents are new talents at the end of the Protection Talent Tree which you can unlock from Level 81 with points being 
awarded to you at Levels 81, 84, 87 and 90. These are all passive effects which for Protection Paladins will give you more rotational 
Holy Power to spend and increase damage.

[[spell:1267211]] (2nd and 3rd Point) specifically synergise well with [[spell:375576]] as you can 
rotationally trigger the effects of [[spell:1267203]] (1st Point) through casting [[spell:20271]] and the free casts of [[spell:31935]] 
via [[spell:355098]] will trigger the Holy Power regenerative effects.

Finally [[spell:1267215]] (4th Point) will make every cast of [[spell:31935]] benefit from the effects of Vanguard giving it bonus damage and 
Holy Power generation while [[spell:384376]] is active. This in reality would essentially give you an endless supply of Holy Power during [[spell:384376]].

2.8.

#### Hero Talent Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith is functionally identical to how it played in The War Within however the Tier Set 
Bonus which made it a powerhouse in Season 3 has been removed and added in as a Hero Talent at a lower power level.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar has been made a bit stronger, it is now hooked to [[spell:375576]] (as [[spell:387174]] has been removed) 
which may not sound like a big change but [[spell:31935]] now contributes to a larger potion of your total damage and the Templar 
Tree adds to that power even more!

2.9.

#### Survivability Changes

There are a few changes in this department. A short cooldown defensive ability has been removed (Eye of Tyr), but two core changes 
have been added to make Protection Paladins defensively very powerful in Midnight.

- Mastery has changed to focus on Block and Spell Block. Very high levels of Mastery will be required to guarantee a Spell Block which 
  will not be achievable until much later in the expansion.
- [[spell:86659]] is now a 3 minute cooldown (down from 5) and has two charges!

2.10.

#### Damage Output Changes

Earlier it was mentioned that [[spell:31935]] contributes more DPS. This is primarily though [[spell:469883]] which adds a 
DoT to targets hit which has been significantly buffed from ~57% of the damage over 5 seconds to 100%. If we add that to [[spell:375576]] being a
core ability for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar to activate [[spell:429826]] and [[spell:384376]] having a fixed 1 minute cooldown (which matches Toll)
you have a very clear burst DPS window. This is all before we mention [[spell:1260429]] which is a new Hero Talent for Templars which makes 
[[spell:375576]] cast two more times at 150% power. With all of these combined the DPS output of Protection Paladins should be in a better place than 
it was in The War Within.

3.

### Basics of Protection Paladin Gameplay

Tanking, in general, means a lot of pressure to not only do damage and thus
threat to make sure things are attacking you but also about surviving those
attacks. As a Protection Paladin, this generally means generating as much Holy
Power as possible, so you can spend it on [[spell:53600]] to
reduce damage intake. There can be moments where damage taken is higher
and you will want to supplement this with another cooldown should, these
would be scenarios such as pulling a large amount of enemies or bosses.

When broken down, Protection Paladin will follow these three simple rules.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_lightoftheprotector.jpg>) **Generate and Use Holy Power**  
  
    Holy Power is your core resource and has a limit of 5. Abilties will generate 
    them largely 1 at a time meaning that you can methodically plan out what your next few 
    moves will be based on the limit that you have. A good rule to follow is that 
    if you are at 5 Holy Power you should be spending it.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_shieldofvengeance.jpg>) **Keep Shield of the Righteous Active**  
  
    Keeping [[spell:53600]] active is the core of how you stay alive 
    as a Protection Paladin. Not only does it provide you with defensive benefits directly, it will also 
    generate a stack of [[spell:321136]] making [[spell:85673]] free after 
    three casts. Even if you do not need to extend the duration of [[spell:53600]] it still 
    has defensive benefits.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_innerfire.jpg>) **Stay in your Consecreation**  
  
  [[spell:26573]] has many talents that impact the benefits of it, the core talent 
    being [[spell:379021]] which will give you damage reduction while you are 
    inside of it. As you move don't forget to place [[spell:26573]] down again.

4.

### How to Gear Up as a Protection Paladin

While we always recommend simming yourself for ideal results, we do provide a
dedicated Protection gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Included new items from Kithix and item upgrading recommendations for Ascendant Venomstones.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated stat breakpoints for Mastery and Block.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **21 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Added Font of Venomous Rage to trinket recommendations.
- **21 Sep. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated recommendations for Lightsmith.
- **21 Sep. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated openers for Instruments of the Divine.
- **21 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated talent recommendations for Lightsmith.
- **21 Sep. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated Talent Recommendations for Lightsmith.
- **11 Sep. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated PvP Talent Recommendations.
- **11 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated PvP Talent recommendation.
- **04 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Fix incorrect ring location.
- **18 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated Talents.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated gear recommendations with first batches of changes to items.
- **18 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated Talent recommendations and corrected an issue with Quickened Invocations being chosen.
- **18 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated Talent Recommendations.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated Talents for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated Gear Recommendations for Season 2 in Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Patch 12.1 with new health potion.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1 and added Opener Timeline.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated Talents for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated Talent Descriptions for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated Talents for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated Mastery values with up to date modelling on the breakpoints to reach 100% block.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **23 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Added crafting recommendation of shield for non Mythic raiders.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Removed references to tea as these are no longer usable inside of instances.
- **23 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated stat priorities to show a defensive stat priority in addition to a standard priority.
- **23 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated default M+ Talent to pick Final Stand.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 (this page):** Updated for Midnight 12.0.1.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.5. Added Cartel Chip recommendations. Adjusted when to replace DISC belt.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated Stat Priorities for each hero talent. Added specific Mastery thresholds for 100% Block.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.2. Removed corruption section as this no longer works in Season 3 and changed Healing Potion to the new Invigorating Healing Potion.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.2. Lowered the Rotational Priority of Avenger's Shield.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for Patch 11.2. Lowered Avenger's Shield Priority in the Rotation.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **13 May 2025 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated Cartel Chip Recommendations.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-liberation-of-undermine-raid-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **18 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-liberation-of-undermine-raid-guide>)):** Gallywix tips added.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated Cyrce's Circlet information. It's been buffed and is now really worth using. It's BiS!
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Added Cyrce's Circlet section. TLDR: If you've got 636/639 its not BiS. Otherwise gem recommendations are on the page.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-nerub-ar-palace-raid-guide>)):** Typo fix on queen tips.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **26 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated Talents and Rotation Ability Unlocks.
- **22 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-nerub-ar-palace-raid-guide>)):** More tips added and adjusted talent builds with recent lightsmith buffs making it better on a few more encounters.
- **22 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Dungeon specific tips have been added!
- **22 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for 11.0.5 with the Talent Tree rework.
- **22 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated for 11.0.5 with the Talent Tree rework.
- **22 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 (this page):** Reviewed for Patch 11.0.5.
- **07 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Fixed issue with picking Hero Talents and updating rotations.
- **28 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updates for Trinkets.
- **28 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Clarify that Punishment also triggers from Avenger's Shield.
- **28 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Fixes for table headers.
- **16 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated Vantus rune information.
- **16 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-nerub-ar-palace-raid-guide>)):** Ansurek Tips added.
- **16 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated buttons for Hero talents and added default options on page load.
- **16 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Clarification on stat priority.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for The War Within Launch with Hero Talent Choices to level 80 and an updated rotation.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated with your Pre Season BiS for The War Within Launch. Further updates to come closer to Season 1.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for The War Within Launch.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated with new gems, enchants, and consumables for The War Within Launch.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for The War Within Launch.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for The War Within Launch with new checkboxes for different talents and hero talents.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for The War Within Launch and added Hero Talents.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated for The War Within Launch and added all Hero Talent spells.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for The War Within Launch.
- **21 Aug. 2024 (this page):** Updated for The War Within Launch.
- **19 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated Talents for The War Within Launch.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/protection-paladin-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **19 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **18 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/protection-paladin-the-war-within-pve-guide>)):** Page added.
- **17 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/protection-paladin-mists-of-pandaria-remix-guide>)):** Moved Tireless Spirit to generic meta gem recomendtations.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/protection-paladin-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Cleaned up historical references. Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Updated for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Tidy up of talent descriptions and removed dated references.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Rephrased defensive cooldown section.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **28 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated Dawn of the Infinite links to be specific to their keystone dungeons.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated the page to account for the nerfs to Sporecloak. The Embelishment recommendations have been changed to account for this.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Season 3.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 10.2. Added WeakAura recommendations for Protection Paladins.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Added helm enchant and new healing potion.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Season 3.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 (this page):** Updated for Season 3.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated gear layout. Added BiS list.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Removed references to Seraphim.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated talent tree layout.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Replaced 10.1.5 Changes with 10.1.7 Changes.
- **14 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated Weapon Enchants and Flask recommendations. Weapon Enchants to be more explict on the two choices, both choices are fairly close in terms of throughput however. Flask has been changed to Tepid Versility due to the increased prevalance of external damage sources.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated Onyx Annulet section to note when you replace this ring. Added 10.1.5 item section.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated Onyx Annulet and Primordial Gems section, and when you should consider replacing it.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated talent tree for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated talent trees for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated talent trees for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Replaced 10.1 Changes with 10.1.5 Changes.
- **06 May 2023 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Talent fix.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated talent calculator for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Moved Onyx Annulet section to the bottom of the page (It's still good for damage!). Updated gear, trinkets, and embelishments for Season 2.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Added belt enchant (New in Patch 10.1) and reviewed for Season 2.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated talent tree for Patch 10.1 and affix information for Season 2.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Added Shield of the Righteous to rotation priority list for clarity. Reviewed for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated spells for Patch 10.1 Changes.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated talent trees for Patch 10.1 and included Shield of the Righteous to rotation priority list.
- **01 May 2023 (this page):** Replaced 10.0.7 Changes with 10.1 Changes.
- **03 Apr. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Added clarification for Blessed Hammer/Hammer of the Righteous.
- **25 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated Primordial Gems recommendations.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/protection-paladin-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Added Onyx Annulet section.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Added Onyx Annulet and Primordial Gems section.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated talent builds for Patch 10.0.7. Added Turn Evil usage.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Removed Of Dusk and Dawn section as it has been reworked in Patch 10.0.7 to be passive.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated both talent builds and talents for Patch 10.0.7 Changes.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated spells for Patch 10.0.7 Changes.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated both talent builds and talents for Patch 10.0.7 Changes.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7 Changes.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated leveling tree to show correct talents per level.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Added a small section to talk about tier set impact on rotation.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **23 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated to be in tables. Separated out Auras & of Dusk and Dawn into their own sections.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/protection-paladin-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/protection-paladin-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/protection-paladin-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **18 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/protection-paladin-patch-9-2-changes-analysis>)):** Updated based on latest PTR build.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/protection-paladin-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/protection-paladin-patch-9-1-changes-analysis>)):** Updated for 9.1.5.
- **18 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/protection-paladin-patch-9-1-changes-analysis>)):** Removed PTR references.
- **29 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/protection-paladin-patch-9-1-changes-analysis>)):** Added initial content.
- **13 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **14 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **26 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** Updated and added Mythic tips.
- **13 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** Updated Za'qul Main tank and Off tank Essence recommendations.
- **12 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** Updated Essence recommendations.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** Added Eternal Palace advice for Protection Paladins.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **12 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-crucible-of-storms-raid-guide>)):** Updated and added Mythic mode.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-crucible-of-storms-raid-guide>)):** Guide added.
- **05 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** Added Mythic advice for BoD.
- **29 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** Updated BoD advice according to live mechanics.
- **20 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** Added BoD advice for Protection Paladins.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** Major revisions, and Mythic added.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** Added initial boss by boss outline for Uldir.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Protection Paladin leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Paladin leveling guide](<https://www.icy-veins.com/wow/paladin-leveling-guide>).

1.

### Protection Paladin Leveling Guide for Midnight

Leveling as a tank is very forgiving. You can consistently pull all of the enemies you need 
for a quest objective in one big clump and comfortably survive it leading to a faster questing experience.

As a tank you are also priviledged to fast queue times for dungeons if you want a break from questing. They 
give a large chunk of experience when you complete them and help reinforce your end game playstyle as open world questing 
is not consistently challenging.

Another minor advantage you have as a Paladin while leveling is that you can safely fall from great heights by using 
[[spell:642]] just before landing to avoid all of the fall damage!

One final tip before we go into the guide is use [[spell:1231418]] after you 
have left combat and are at low health. It is faster than healing yourself up if you do 
not have Holy Power for [[spell:85673]].

1.1.

#### Leveling Gear Options

When leveling up, you should always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level but two secondary stats on it
instead of one.

When using Heirloom items priortise items with Haste. These items scale with your 
level meaning that you will not need to replace them as you level.

1.2.

#### Useful Leveling Consumables for Midnight

When leveling in Midnight, many of the consumables you used throughout
the War Within will continue to be valuable. You may opt to change 
your secondary stat enchants to speed variants such as [[item:223725]] (Bracer)
and [[item:223800]] (Cloak) and use the speed food buff [[item:225592]].

Using [[item:212265]]s as you fight your way through quests will also speed up your leveling journey 
and always having a combat flask active such as [[item:212283]].

[[item:109076]] can be a lifesaver when jumping off large cliffs
or when you want to cover a long distance.

[[item:132516]] are a highly recommended item for leveling. They provide an
extremely large movement speed increase. It is a bonus comparable to what
you get when flying. It is highly recommended you stock up on these items when
leveling.

The Gunshoes will not let you stop moving as
long as they are active. Using this macro twice will click the buff off and
allow you to stop.

#### Gunshoes Macro

```wow-macro
#showtooltip
/use Gunshoes
/cancelaura Gunshoes
```

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Protection Level 80 Midnight Leveling
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiKuxxYjbFEU1NQSC1LD-YOAJwMVkBilXuHQf6ausElQJIUEKZDkG-AAAA-bYWUoEcAQMxQAB-
```

:::

2.1.

#### War Mode Talents for Leveling

1. [[spell:199542]] increases the duration of
   [[spell:190784]] by 2 seconds, which means you can travel a lot further
   per Steed charge, allowing you to quickly get between two
   places. Note, however, that it does cause you to knock back enemies that get
   close to you, which can be a negative aspect if you are trying to gather
   them up to AoE.
2. **等级 20 起：**[[spell:210341]] makes [[spell:53600]] deal
   30% more damage at the cost of less Armor granted. This is generally fine for
   outdoor content since tanks usually do not struggle to survive in outdoor
   content.
3. **等级 22 起：**[[spell:207028]] for additional damage on a single target or 
   [[spell:228049]] to have two more immunity charges available in addition to 
   [[spell:642]].

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

Protection Paladin rotation is a priority system, which means you do not have
a strict rotation, but rather, when two abilities become available at the same
time, you prioritize which one to press according to the rotation below.

**等级 1–9：**When you first create your Paladin, you will
only have one ability available to you: [[spell:35395]]. Once you reach
level 10, you can officially specialize in Protection.

1. **等级 10 起：**Cast [[spell:26573]]
2. **等级 26 起：**Cast [[spell:375576]].
3. **等级 71 起：**Cast [[spell:429826]]
4. **等级 10 起：**Cast [[spell:20271]] to generate Holy
   Power. This will be [[spell:24275]] if you are under the effects of [[spell:384376]]
5. **等级 10 起：**Cast [[spell:53600]] when you have
   3 Holy Power (or more).
6. **等级 11 起：**Cast [[spell:31935]] to deal damage to
   multiple targets, this spell goes highest in priority for damage against 3+ targets.
7. **等级 10–12：**Cast [[spell:35395]].
8. **等级 13–13：**Your [[spell:35395]] will now become
   [[spell:53595]] or [[spell:204019]].
9. **等级 14 起：**Cast
   [[spell:53595]]/[[spell:204019]].

**等级 2–90：**Active mitigation comes into play most of the
time when leveling since we get [[spell:53600]] already at level
2. This means that we can spend our Holy Power on dealing AoE damage while also
reducing physical damage taken by increasing our Armor.

**等级 10 起：**Starting at Level 10, the Dungeon Finder opens
up, and you can now queue up and test your tanking capabilities. Tanking at
this level should not be too complicated, but it can definitely be very
frustrating as other players will generally try to rush through it since it is
such a low level. This means you may not learn a lot about tanking the first few
dungeons, but keep playing, and you will learn while leveling.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Sep. 2026:** Updated PvP Talent Recommendations.
- **18 Aug. 2026:** Updated Talents.
- **10 Aug. 2026:** Updated Talents for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **26 Oct. 2024:** Updated Talents and Rotation Ability Unlocks.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch with Hero Talent Choices to level 80 and an updated rotation.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated talent calculator for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated leveling tree to show correct talents per level.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Protection Paladin in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Protection Paladin in Midnight

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Protection Paladin follows three simple rules:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_lightoftheprotector.jpg>) **Generate and Use Holy Power**  
  
    Holy Power is your core resource and has a limit of 5. Abilties will generate 
    them largely 1 at a time meaning that you can methodically plan out what your next few 
    moves will be based on the limit that you have. A good rule to follow is that 
    if you are at 5 Holy Power you should be spending it.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_shieldofvengeance.jpg>) **Keep Shield of the Righteous Active**  
  
    Keeping [[spell:53600]] active is the core of how you stay alive 
    as a Protection Paladin. Not only does it provide you with defensive benefits directly, it will also 
    generate a stack of [[spell:321136]] making [[spell:85673]] free after 
    three casts. Even if you do not need to extend the duration of [[spell:53600]] it still 
    has defensive benefits.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_innerfire.jpg>) **Stay in your Consecreation**  
  
  [[spell:26573]] has many talents that impact the benefits of it, the core talent 
    being [[spell:379021]] which will give you damage reduction while you are 
    inside of it. As you move don't forget to place [[spell:26573]] down again.

Protection Paladins are tanks with a very versatile skill set. In general,
your damage intake varies depending on whether or not
[[spell:53600]] is active. It is important to get
comfortable and not panic just because you get low on health, as you have
great
tools to get yourself out of low-health situations. No other tank class has
quite the array of tricks and utility up their sleeve that a Paladin does.

2.

### Beginner's Guide to Protection Paladin in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith   Single-Target Talents

2.1.

#### Beginner Single-Target Talents for Protection Paladin

This build is what you would use when you are fighting a Raid Boss which is on its own, Bosses that 
have infrequent add spawns, or Open World content. If there are going to be multiple enemies consitently we would 
recommend the AoE and Mythic+ build instead.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents Raid / Single Target - Lightsmith
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYGzMzMz2yYMLzilZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZDDAGzwYAwMDAmZAjF"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYGzMzMz2yYMLzilZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZDDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAZmIyAxy7TXzCXE4EqQBhCpbgu8JID-AAAA-OQURYhpBYQQBkE-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith   Dungeon Talents

2.2.

#### Beginner AoE and Mythic+ Talents for Protection Paladin

This is our recommended build for AoE scenarios. This works well for AoE 
Fights in Raids, as well as most Mythic+. It can work in all scenarios but some of the talents will have no 
benefit if there are not many targets available.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents AoE / Mythic+ - Lightsmith (Weekly Keys)
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-OQURYhpBYQQBkE-
```

:::

### Protection Paladin   Basic Rotation

2.3.

#### Beginner Protection Paladin Rotation

The main goal of your rotation is to generate
[[spell:53600]] charges while also maintaining Consecration
uptime. It acts more as a priority system rather than a strict rotation due 
to the high availability of most of the spells.

- **Cooldowns:** Use [[spell:384376]], followed by [[spell:375576]] and [[spell:429826]] 
  when they are available.
- [[spell:26573]] should be used when you are not standing in it due to moving to a new location or it has timed out for 
  damage reduction.
- To spend Holy Power use [[spell:53600]] when you are at 3-5 Holy Power to prevent
  overcapping on Holy Power. If you are below 50% Health use [[spell:85673]] instead to stay alive!
- Generating Holy Power will be priortised in this order: [[spell:24275]], [[spell:20271]]
  [[spell:31935]] (if you have a [[spell:1268810]] proc from the Apex Talent), [[spell:53595]] / [[spell:204019]]
- If everything else is on cooldown you will then use [[spell:31935]] or [[spell:26573]] just to refresh the duration.

Note that the above-mentioned points do not cover how to use your defensive spells rotationally, visit the defensive spells 
portion of this guide for more information on those.

2.3.1.

##### Apex Talent: ![Glory of the Vanguard Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_12al_armyoflight_defense_shield01.jpg>) Glory of the Vanguard

When you cast [[spell:20271]] / [[spell:24275]] you will have a chance to gain [[spell:1268810]] (this buff is guaranteed 
when you have [[spell:384376]] active). This will lead to increased Holy Power generation, especially when you have [[spell:384376]] active 
you will find yourself casting [[spell:53600]] more often (**Casting this has no GCD meaning you can cast it and another spell**).

2.4.

#### Paladin Auras

Default to using [[spell:465]]. If there is a Holy Paladin in your group use [[spell:32223]] instead.

2.4.1.

##### Season 2 Tier Set

The tier set bonus for Season 2 has no impact on the rotation for Protection Paladin, gaining more damage 
to enemies inside of your [[spell:26573]].

### Protection Paladin   Defensive Spells

2.5.

#### Defensive Spells for Protection Paladin

[[spell:53600]] and [[spell:85673]] are
your two active mitigation abilities (though [[spell:85673]] is a heal,
so it does not really mitigate damage). Since [[spell:53600]] is off
the Global Cooldown, it is easy to fit in whenever best suited to reduce
physical
damage intake without upsetting your rotation. However, due to
[[spell:85673]], being on the global cooldown, it is likely to
delay your rotation when you use it. There is no issue with this if the healing will
save your life.

[[spell:53600]] uptime is relatively high under normal play
scenarios. Your aim will be to have it as close to 100% as your gear/talents
will allow.

However, if you have low amounts of haste, you will want to pay
attention to not overcapping the buff. It can be extended for 3x the base duration
4.5s x 3 = 13.5s. If you are above 9-second duration, try to avoid pressing
[[spell:53600]] unless you are about to go over 5 Holy Power.

Due to the strength of [[spell:53600]], it is best to try
to use these cooldowns in a plan based on the damage you anticipate to take.

- [[spell:86659]] should be used before a period of high
  damage intake or when your healers are unable to heal you for a while.
- [[spell:31850]] is best used to bypass deadly encounter
  mechanics or to save your life in critical moments **or** at the 
  start of an encounter before you get your first [[spell:53600]].
- [[spell:384376]] increases damage done and
  healing done by
  20%, as well as 20% critical strike chance. This is a good offensive
  cooldown, but also very useful defensively for self-healing.
- [[spell:633]] should be used as an emergency reactive cooldown
  to top yourself off when you have dropped low on health. Note that you can
  also use it to save other raid members.
- [[spell:642]] can be used to clear debuffs or avoid fatal damage
  as you are immune to damage for its duration. [[spell:204077]] turns Divine
  Shield into a usable tank cooldown that makes you immune to damage while also
  forcing all enemies to attack you; without the Final Stand talent, however,
  the boss will not attack you and instead move to the next target on the threat
  table.

### Protection Paladin   Stat Priority

2.6.

#### Stat Priority for Protection Paladin

Currently, item level is by far the most important aspect of gearing, 
secondary stats are quite close together in value, but in an optimal gearing 
scenario where you have equal item level choices, you would want to prioritize 
as stated below. For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>).

1. Haste
2. Mastery
3. Versatility = Critical Strike

### Blizzard   Combat Assistant

2.7.

#### Combat Assistant Viability for Protection Paladins

The [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) one-button rotation mode added with 11.1.7 is a significant 
decrease in throughput compared to playing with a normal rotation, this is due to the rotation 
currently used and the additional delay it imposes on your abilities while in use.

As of writing the assisted rotation does not use [[spell:85673]] or [[spell:384376]]. 
Therefore it may lead to scenarios where you will want to self heal but not have the Holy Power 
available leading to potential survival concerns, it also deals significantly 
less damage than a standard rotation (Approximately ~40% less DPS).

We recommend avoiding its use for now, and instead to follow the rotational advice 
present on this page.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **21 Sep. 2026:** Updated Talent Recommendations for Lightsmith.
- **18 Aug. 2026:** Updated Talent Recommendations.
- **10 Aug. 2026:** Updated Talents for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2. Lowered Avenger's Shield Priority in the Rotation.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **28 Sep. 2024:** Fixes for table headers.
- **16 Sep. 2024:** Clarification on stat priority.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated talent trees for Patch 10.1.5.
- **01 May 2023:** Updated talent trees for Patch 10.1 and included Shield of the Righteous to rotation priority list.
- **03 Apr. 2023:** Added clarification for Blessed Hammer/Hammer of the Righteous.
- **20 Mar. 2023:** Updated both talent builds and talents for Patch 10.0.7 Changes.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Protection Paladin in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Protection Paladin

Historically ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar has been the defacto Damage Hero Tree and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith has been more 
defensive-oriented one. This season has mixed it up with buffs to [[spell:26573]] in addition to Protection 
Paladin damage in general. This has led to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith now being both a defensive
and offensive oriented option, which makes it a better choice in most content. Our
current recommendations are as follows:

- **Raid -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith
- **Mythic+ -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith

While both Hero Talents share similar damage profiles, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith pulls ahead in terms of raw damage. 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar can offer higher burst in very short windows, but most encounters do not
work that way, so you will default to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith for pretty much every
type of content. You may opt to use ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar for chill content such as 
Weekly Keys or Delves where you can properly leverage its burst output.

**Quick Start Import Codes:**

:::talents Raid / Single Target - Lightsmith
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYGzMzMz2yYMLzilZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZDDAGzwYAwMDAmZAjF"
}
```
:::

:::talents AoE / Mythic+ - Lightsmith (Weekly Keys)
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::talents AoE / Mythic+ - Lightsmith (High Keys)
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsNLjZMzMzMLLjxYWmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::talents Delves - Templar
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWGzYmZmZW2GjZZWmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Lightsmith

Single-Target

recommended

Mythic+

weekly-keys

Mythic+

high-keys

Templar

Mythic+

beginner-friendly

Delves

### 天赋方案 0-0

1.1.

#### Single-Target Talents

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith build offers high Single Target damage and all of the core talents for survivability.
The scenarios where you would use this are primarily Raiding on a boss fight that does not have consistent add spawns or
open world content where you are fighting 1-3 enemies. If you are looking for a build that helps with Cleave DPS scenarios
we would recommend the Mythic+ Talents.

For more damage you can opt to swap [[spell:1245891]] for [[spell:1277162]], however you will need to be mindful of your
Holy Power when making this swap as you will spend more with [[spell:53600]] in exchange for more damage.

### 天赋方案 0-1

1.2.

#### Weekly Key Mythic+ Talents (Lightsmith)

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith build uses [[spell:1245979]] for an easier time
to have [[spell:53600]] uptime between pulls.

### 天赋方案 0-2

1.3.

#### High Keys Mythic+ Talents (Lightsmith)

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith build replaces [[spell:1245979]] with [[spell:1301732]] for
increased healing potential, and [[spell:1244070]] for [[spell:378405]] for more healing..

### 天赋方案 1-0

1.4.

#### Weekly Key Mythic+ Talents (Templar)

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar build uses [[spell:1245979]] for an easier time
to have [[spell:53600]] uptime between pulls.

### 天赋方案 1-1

1.5.

#### Delve Talents

These talents are exactly the same as the Mythic+ talents due to the content damage profile being the same. If you do not need [[spell:204077]] you can swap this
for additional damage by picking up [[spell:378762]].

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYGzMzMz2yYMLzilZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZDDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAZmIyAxy7TXzCXE4EqQBhCpbgu8JID-AAAA-OQURYhpBYQQBkE-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-CDGIJKV5knpB4ARRddlt1lo5Z1NQSyDEEVF-YAZcmeREBDklILuOvfA18IhSbTogQRCE-AAAA-AGU4ASyCTTgARF-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-OQURYhpBYQQBkE-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiKuxZFEU1VSKwD1YjLD-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-bYWUoEcAQMxQAB-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiKuxZFEU1VSKwD1YjLD-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-bYWUoEcAQMxQAB-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>). This system 
grants you one new rune to select per week for 5 weeks and will increase your throughput slightly. 
It is not a big borrowed power system but a minor enhancement.

Our recommendation would be the below options for most content in game. You can freely 
swap between the options on each row for specific pieces of content. For example the Week 4 row may 
change based on your specific gear situation at the time:

- Week 1:[[spell:1279596]]
- Week 2:[[spell:1279604]]
- Week 3:[[spell:1287555]]
- Week 4:[[spell:1279609]] (Damage) / [[spell:1279612]] (Defensive)
- Week 5:[[spell:1279616]]

3.

### Apex Talent: ![Glory of the Vanguard Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_12al_armyoflight_defense_shield01.jpg>) Glory of the Vanguard

New in Midnight are Apex Talents which sit at the end of the Protection talent tree. These are unlocked 
at Levels 81, 84, 87 and 90, and are all passive effects which impact your rotation when they trigger.

They all revolve around the  buff (triggered by [[spell:20271]]), which adds additional effects to [[spell:31935]].

- First Point ([[spell:1267203]]): Enables [[spell:1268810]] to deal additional damage to enemies between you and the target.
- Second and Third Points ([[spell:1267211]]): [[spell:1268810]] generates Holy Power when consumed.
- Fourth Point ([[spell:1267215]]): **Every cast** of [[spell:31935]] while you have [[spell:384376]] has 
  the effects of [[spell:1268810]] (Holy Power + Additional Damage), you also gain some bonus AoE damage to [[spell:53600]].

4.

### Hero Talents

Protection Paladin gets to pick between the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar 
and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith Hero Talents from Level 71.

The recommendation in Season 2 would be towards ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar talent builds.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar is focused around big bursts of damage. Every time you use [[spell:375576]]
you will be able to cast [[spell:429826]]. As these have a 1 minute cooldown it pairs perfectly 
with [[spell:384376]] (with [[spell:204074]] talented) to create very frequent high 
damage burst windows.

This Hero Talent tree offers a very methodolical rotation flow for Protection Paladin and creates 
an exciting moment of gameplay every minute when all of the abilities are available.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith is more utility focused as the focus of this Hero Talent is applying 
[[spell:227817]] / [[spell:432472]] to players. [[spell:227817]] provide a damage 
absorb shield to the player, and [[spell:432472]] gives bonus damage or healing to the player. Every 
time you cast the Bulwark/Weapon you will also provide lesser versions to other players too making a well timed 
[[spell:227817]] a small group absorb shield benefiting your healer in Mythic+!

You will also never need to worry about Weapon Oils again as you gain access to [[spell:433568]] 
where you can imbue your main hand weapon with a much stronger buff that is only available for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith Paladins!

5.

### PvP Talents (War Mode)

Opting into War Mode makes you eligible for open-world PvP but also grants
you the following benefits:

- World Quests at maximum level have 10% increased rewards (30% if you are
  Alliance).
- You gain 10% increased Experience while leveling (30% if you are
  Alliance).
- Allows you to earn Conquest Points towards weekly gear rewards.
- Grants you the use of PvP talents in the open-world.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended that you enable the feature to maximize your leveling and rewards
at maximum level. However, you will make yourself eligible for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

This list is going to be assuming you care little about actual PvP combat,
and focuses rather on optimal talents for outdoor PvE, such as World Questing
and Leveling.

- [[spell:210341]] makes [[spell:53600]] deal
  30% more damage at the cost of less Armor granted. This is generally fine for
  outdoor content since tanks usually do not struggle to survive in it.
- [[spell:199542]] increases the duration of
  [[spell:190784]] by 2 seconds, which means you can travel a lot further
  per Steed charge, allowing you to quickly get between two
  places. Note, however, that it does cause you to knock back enemies that get
  close to you, which can be a negative aspect if you are trying to gather
  them up to AoE.
- [[spell:207028]] for additional damage on a single target or 
  [[spell:228049]] to have two more immunity charges 
  available in addition to [[spell:642]].

Talents, such as [[spell:377043]] and [[spell:215652]],
do what [Protection Paladin](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-guide>)s already do very well with either
[[spell:1044]] or [[spell:31935]].
Shield of Virtue most importantly makes Avenger's Shield silence players, as
it does not do it normally, but it will silence targets around it as well and
has very limited use.

Most other talents are either very weak or benefit players around you
instead and are very limited in use.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **21 Sep. 2026:** Updated talent recommendations for Lightsmith.
- **11 Sep. 2026:** Updated PvP Talent recommendation.
- **18 Aug. 2026:** Updated Talent recommendations and corrected an issue with Quickened Invocations being chosen.
- **10 Aug. 2026:** Updated Talents for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Updated default M+ Talent to pick Final Stand.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Updated for 11.0.5 with the Talent Tree rework.
- **28 Sep. 2024:** Clarify that Punishment also triggers from Avenger's Shield.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch and added Hero Talents.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Tidy up of talent descriptions and removed dated references.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Updated talent tree layout.
- **10 Jul. 2023:** Updated talent trees for Patch 10.1.5.
- **06 May 2023:** Talent fix.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated both talent builds and talents for Patch 10.0.7 Changes.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Protection Paladin, depending on the type of damage you will be tanking.
We also have advanced sections about cooldowns, procs, etc. in order to maximize your
survivability and DPS. All our content is updated for World of Warcraft Patch
12.1.5.

1.

### Protection Paladin Gameplay and Rotation Guide

The Protection Paladin rotation is based on a priority system. The main goal
with your rotation is to generate Holy Power that you can spend on
[[spell:53600]] charges while also maintaining
[[spell:26573]] uptime. In addition to this rotation, you
will have to make use of your [[spell:53600]]
(and to a lesser extent, your [[spell:85673]]) to stay alive.

:::details FAQShould I Play Defensively or Offensively?
The basic answer is that if you are doing progression, or are on a character you do not
feel comfortable playing offensively with yet, you should play defensively. As you
start to get more comfortable on your Paladin, you should start looking at DPS a bit more and play a
more mixed style, where you start pushing DPS while slowly giving up
survivability.

Once you feel completely comfortable with the encounter and you
will not hold your raid back, you can then fully optimize for DPS. This point is different
for every person, as it depends on your group, your character, your gear, and
your skill level.

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar

Single Target

Single Target (Large Boss Model)

AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Single Target (Large Boss Model)

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:53595]]

[[spell:204019]]

[[spell:1267215]]

(Final Apex Point)

[[spell:155145]]

(Blood Elf)

[[spell:1277162]]

### Opener

**适用条件：Blessed Hammer（启用）。**

[[spell:26573]]

[[spell:204019]]

[[spell:62124]]

[[spell:384376]]

[[spell:375576]]

**适用条件：Templar（启用）。**

[[spell:429826]]

**适用条件：Lightsmith（启用）；Instrument of the Divine（启用）。**

[[spell:53600]]

**适用条件：Lightsmith（启用）；Instrument of the Divine（未启用）。**

[[spell:53600]]

**适用条件：Instrument of the Divine（启用）。**

[[spell:1241288]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:31935]]

**适用条件：Instrument of the Divine（未启用）。**

[[spell:1241288]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。**

[[spell:53600]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:53600]]

**适用条件：Instrument of the Divine（未启用）。**

[[spell:1241288]]

**适用条件：Instrument of the Divine（启用）。**

[[spell:1241288]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。**

[[spell:31935]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:31935]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。**

[[spell:53600]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:53600]]

**适用条件：Instrument of the Divine（未启用）。**

[[spell:1241288]]

**适用条件：Instrument of the Divine（未启用）。**

[[spell:1241288]]

**适用条件：Instrument of the Divine（启用）。**

[[spell:1241288]]

**适用条件：Instrument of the Divine（启用）。**

[[spell:1241288]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:31935]]

[[spell:53600]]

1.1.

#### Rotation for the pull as a Protection Paladin

When you start a pull you have a few priorities to manage. First and foremost you need to set your [[spell:53600]] up and then manage your Holy Power. The below sequence should ensure you do not have more than 5 Holy Power (to prevent wasted Holy Power), maintain [[spell:53600]] and deal optimal damage.

---

1. **适用条件：Blessed Hammer（启用）。** **Before the pull:** Pre-place [[spell:26573]] if you are pulling the enemy to you, cast [[spell:204019]] to generate 1 Holy Power and pull the enemy with [[spell:62124]].
2. **适用条件：Hammer of the Righteous（启用）。** **Before the pull:** Pre-place [[spell:26573]] if you are pulling the enemy to you and pull the enemy with [[spell:62124]].
3. [[spell:384376]]
4. [[spell:375576]]
5. **适用条件：Templar（启用）。** [[spell:429826]]
6. **适用条件：Lightsmith（启用）；Instrument of the Divine（启用）。** [[spell:53600]]
7. **适用条件：Lightsmith（启用）；Instrument of the Divine（未启用）。** [[spell:53600]]
8. **适用条件：Instrument of the Divine（启用）。** [[spell:1241288]]
9. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:31935]]
10. **适用条件：Instrument of the Divine（未启用）。** [[spell:1241288]]
11. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。** [[spell:53600]]
12. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:53600]]
13. **适用条件：Instrument of the Divine（未启用）。** [[spell:1241288]]
14. **适用条件：Instrument of the Divine（启用）。** [[spell:1241288]]
15. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。** [[spell:31935]]
16. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:31935]]
17. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。** [[spell:53600]]
18. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:53600]]
19. **适用条件：Instrument of the Divine（未启用）。** [[spell:1241288]]
20. **适用条件：Instrument of the Divine（未启用）。** [[spell:1241288]]
21. **适用条件：Instrument of the Divine（启用）。** [[spell:1241288]]
22. **适用条件：Instrument of the Divine（启用）。** [[spell:1241288]]
23. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:31935]]
24. [[spell:53600]]
25. **适用条件：Blessed Hammer（启用）。** [[spell:204019]]
26. **适用条件：Blessed Hammer（启用）；Glory of the Vanguard (Final Apex Point)（未启用）。** [[spell:204019]]
27. **适用条件：Hammer of the Righteous（启用）。** [[spell:53595]]
28. **适用条件：Hammer of the Righteous（启用）；Glory of the Vanguard (Final Apex Point)（未启用）。** [[spell:53595]]
29. [[spell:31935]]
30. [[spell:53600]]
31. **适用条件：Arcane Torrent (Blood Elf)（启用）。** [[spell:155145]]

### Single Target Rotation

1.2.

#### Single Target Rotation Priority Order

Outside of your opener you want to follow a priority order of abilities. Priortising abilities higher in the list as they come off cooldown.

---

1. [[spell:384376]]
2. **适用条件：Lightsmith（启用）。** [[spell:432472]] if you do not have [[spell:384376]] active
3. [[spell:375576]]
4. **适用条件：Templar（启用）。** [[spell:429826]]
5. [[spell:26573]] if you are not standing in it
6. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）。** [[spell:31935]] if [[spell:1268810]] is active
7. [[spell:53600]] when you are between 3 and 5 Holy Power
8. [[spell:1241288]] / [[spell:20271]]
9. **适用条件：Blessed Hammer（启用）。** [[spell:204019]]
10. **适用条件：Hammer of the Righteous（启用）。** [[spell:53595]]
11. [[spell:31935]]
12. **适用条件：Arcane Torrent (Blood Elf)（启用）。** [[spell:155145]]
13. **适用条件：Templar（启用）。** [[spell:85673]] if you have a charge of [[spell:321136]] and are below 50% Health
14. **适用条件：Lightsmith（启用）。** [[spell:85673]] if you have a charge of [[spell:321136]]
15. [[spell:26573]] if everything else is on cooldown to refresh the duration

### AoE Rotation

1.3.

#### AoE Rotation Priority Order

Outside of your opener you want to follow a priority order of abilities. Priortising abilities higher in the list as they come off cooldown.

---

1. [[spell:384376]]
2. **适用条件：Lightsmith（启用）。** [[spell:432472]] if you do not have [[spell:384376]] active
3. [[spell:375576]]
4. **适用条件：Templar（启用）。** [[spell:429826]]
5. [[spell:26573]] if you are not standing in it
6. [[spell:31935]] if [[spell:1268810]] is active
7. [[spell:53600]] when you are between 3 and 5 Holy Power
8. [[spell:31935]]
9. [[spell:1241288]] / [[spell:20271]]
10. **适用条件：Blessed Hammer（启用）。** [[spell:204019]]
11. **适用条件：Hammer of the Righteous（启用）。** [[spell:53595]]
12. **适用条件：Arcane Torrent (Blood Elf)（启用）。** [[spell:155145]]
13. **适用条件：Templar（启用）。** [[spell:85673]] if you have a charge of [[spell:321136]] and are below 50% Health
14. **适用条件：Lightsmith（启用）。** [[spell:85673]] if you have a charge of [[spell:321136]]
15. [[spell:26573]] if everything else is on cooldown to refresh the duration

2.

### Midnight Season 2 Tier Set

The tier set bonus for Season 2, [[spell:1296658]] and [[spell:1296659]],
focuses on improving your damage focusing on enemies being inside of [[spell:26573]] (which they should be by default).

This set focuses around improving your damage through Critical Strikes. The [[spell:1296658]] increases 
your chance to crit enemies inside your [[spell:26573]] by 5% and the [[spell:1296659]] simplified makes
[[spell:204019]] / [[spell:53595]] and [[spell:20271]] deal 20% additional Holy damage (which can crit for 40% additional damage).

From a pure DPS perspective this would shift stat weights towards Critical Strike to capitalise on the double damage component of the 4 set.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Protection Paladin 
kit, we have compiled a more detailed explanation these specifics to help improve your mastery 
on both tanking in general and playing Protection Paladin.

### Threat Generation & Taunting

3.1.

#### Threat Generation & Taunting

**Threat** is the basis of how you keep enemies attacking you. This is achieved through a function 
of damaging enemies to make yourself the most threatening target to them.

Attacks will generate **1 point of threat per point of damage**. For tanks this is increased to 
**10.5 points of threat per point of damage**. This in reality means that as long as your DPS are not doing 
more than 9.5 times your damage you will keep threat away from them. This sounds pretty high (and it is) but 
some DPS specs can do egregious amounts of burst DPS in their cooldown windows and grab threat instead of you. 
In scenarios like this you will want to use your own cooldowns to keep up!

Each individual enemy has their own threat table based on damage they have taken from individual players.

:::details FAQWhat about healing?
The rules on how healing threat are not very consistent but in general
if you are healing another player it will generate threat, if you are a healer
any healing you do will generate threat, **if you heal yourself it will not generate
threat**, and finally for some strange reason if you use a healing potion it
will generate threat.

Healing threat is split across all enemies in range.

:::

3.2.

#### Threat Generation

So how do we generate threat effectively as a tank? This is quite simple, just do DPS. Play 
your rotation as you are expected to and you should not have many difficulties outside of the 
rare scenario of a DPS doing very high amounts of burst damage. In these scenarios we also have 
**Taunt Abilities** to help us out.

3.3.

#### Taunting

[[spell:62124]] is your taunting ability. It only works on a
single target and has an 8-second cooldown, forcing the target to attack you
for 3 seconds (even if you currently have an immunity effect active), putting
you on top of the mob's threat table, and causing you to generate **8 times
more threat for 3 seconds** (this is multiplied on the original modifier of 9.5x).

### Active Mitigation

3.4.

#### Active Mitigation for Protection Paladins

[[spell:53600]] and [[spell:85673]] are your two active
mitigation abilities (though Word of Glory is a heal, so it does not really
<em>mitigate</em> damage).

3.5.

#### Shield of the Righteous

[[spell:53600]] is your main damage mitigation ability. It
costs 3 Holy Power, and each cast grants you a 4.5-second buff that increases
your Armor (the amount of Armor is increased by your Strength). Shield of the
Righteous deals damage to all enemies directly in front of you and does not
require a target to cast.

Shield of the Righteous is off the global cooldown, so you can easily fit it
in together with your normal rotation. The exact timing for when to use it
depends greatly on your circumstances, but in general, you should aim to have
it active nearly all of the time in combat and when 
that is not possible you should utilise downtime in combat to your advantage to pool 
Holy Power for example when you are tanking in a raid and do not have threat of the boss.

You want to never cap out at 5 Holy Power while using a Holy Power generating ability, but
you also want to avoid using [[spell:53600]] when at 3 Holy
Power, as you may not have time to build up the Holy Power again should you
need it right after each other.

3.6.

#### Word of Glory

[[spell:85673]] costs 3 Holy Power and is a small heal which is
increased by your missing health.

Given its cost of Holy Power, you should wait to use Word of Glory until
your health is at a comfortably low level (around 30-50% health) to gain the
highest possible benefit from it without dying. Every 3 casts of
[[spell:53600]] will give you a charge of [[spell:321136]] that makes your next
Word of Glory free to cast. You can have a maximum of two [[spell:321136]] charges at a time.

Your general aim should be to only use [[spell:85673]] when it is free with [[spell:321136]].

If you are playing **Lightsmith** you will want to use your [[spell:321136]] 
charges a bit more liberally as they give cooldown reduction to your Hero Talent ability.

**Optional:** [[spell:315924]] can be used in scenarios where 
you need to help your healer(s) and you will effectively become another healer to support them. 
It will allow you to gain the scaling buff to the heal based on missing HP on other players but 
comes at a cost of not being able to use [[spell:53600]] for damage instead. 
This also poses an additional risk of **running out of mana** as if you heal other players 
too much you will not have the mana to do your standard rotation and may die as a result.

### Auras

3.7.

#### Auras as a Protection Paladin

There are three auras available to use, and only one can be active 
at a time for your entire group. **They will not stack with each other**. 
If you have multiple Paladins in the group it can be beneficial for you to 
use a different aura each. In general this will be a Priority system of:

- Holy Paladin will want to use [[spell:465]].
- The second Paladin will use [[spell:32223]] (this makes [[spell:190784]] faster).
- If there is a silence effect you cannot negate then the second/third paladin should use [[spell:317920]].

What do the auras do?:

- [[spell:465]]: When active, this Aura will reduce the damage
  everyone in range takes by 3%. This Aura will be used by default, the only
  exceptions to this are when you have multiple Paladins in the group, where one
  will use another Aura to ensure you all benefit from multiple Auras. In the
  scenario you have a Holy Paladin in the group, they should use
  [[spell:465]] as their [[spell:31821]] will empower it to make it
  stronger.
- [[spell:32223]]: When active, this will increase all mounted speed by
  20% for all players in range. Interestingly, this also applies to
  [[spell:190784]]. This Aura will primarily be used when you are
  mounted.
- [[spell:317920]] will reduce the duration of interrupt and silence 
  effects by 30%.

### Apex Talents

3.8.

#### Apex Talents for Protection Paladin

With Midnight comes the addition of Apex talents. Each specialization will have access
to new talents, and Protection Paladin will gain [[spell:1267203]]. This is a set of passive
abilities which increase in power as you spend more points into it.

- [[spell:1267203]] First Point: [[spell:20271]] has a chance to grant you Vanguard which will cause your next
  [[spell:31935]] to deal damage to all enemies between you and the target.
- [[spell:1267211]] Second Point: When Vanguard is consumed you will gain 1 Holy Power. [[spell:20271]] deals 10% more damage.
- [[spell:1267211]] Third Point: Holy Power increased to 3 and damage increased to 20%.
- [[spell:1267215]] Final Point: After Vanguard is consumed [[spell:53600]] will deal 20% increased damage
  to the primary target and deal some AoE damage. During [[spell:384376]] every cast of [[spell:31935]]
  will benefit from Vanguard.

What this means in reality is that casts of [[spell:20271]] / [[spell:24275]] will give you the Vanguard buff. This makes 
[[spell:31935]] generate up to 3 Holy Power which means you can instantly cast [[spell:53600]] afterwards. During [[spell:384376]]
you will have very high amounts of Holy Power Generation due to casting [[spell:375576]] with it and the free [[spell:31935]]s you get every 5 
seconds from [[spell:355098]].

4.

### Important Cooldowns for Protection Paladin

### [[spell:642]]

[[spell:642]] is one of the most powerful defensive cooldowns 
in the game as it makes you immune to nearly everything (there are a select 
few boss abilities which ignore immunity effects). However it has one major 
drawback.

If you are under the effects of an immunity effect you will be ignored by 
enemies until the effect is over. However there are ways around this.

- The [[spell:204077]] talent will force a taunt effect on every enemy around 
  you for the duration of [[spell:642]].
- You can use [[spell:62124]] to force the enemy to attack you for the 
  short fixate period while the taunt is active. (You will need to cancel the [[spell:642]]
  before this effect ends to ensure they do not attack someone else briefly using 
  a macro such as [this one](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons#divine-shield>)).
- If the effect you are trying to negate is being casted directly on you and the cast 
  has started it will finish on you. Apply [[spell:642]] when the cast has started and 
  remove [[spell:642]] once it has resolved.
- You can also just use [[spell:642]] to remove harmful debuffs that are on you 
  by applying and removing [[spell:642]] instantly with a cancelaura macro (linked above).

One final note about [[spell:642]] is that if there is a mechanic which 
targets a random player. If you are immune to the effect before the target picking process 
begins you will be completely ignored as a potential target. This can be beneficial in some scenarios 
but in others it can be harmful as it will go to another player instead.

### [[spell:1022]]

[[spell:1022]] lets you pull many of the same tricks on
other players (since you can cast it on any raid member). It removes many
Physical DoTs and bleeds. In a raid team with several Paladins, this can
eliminate the danger from an otherwise complicated mechanic.

In addition, mobs that fixate on a random player often ignore that the
target is in fact immune from Blessing of Protection. This is particularly
helpful when the mob targets a caster or healer, as it can allow them to skip
kiting a mob and maintain their full DPS/HPS output.

Finally, Blessing of Protection frequently bypasses the target-selection
mechanics the same way Divine Shield does. Casting Blessing of Protection on a
player before the target-selection process can ensure that they do not get
chosen. This can allow them to move to locations that would otherwise be
dangerous to themselves or the raid.

### [[spell:204018]]

[[spell:204018]] is functionally the same as [[spell:1022]] 
but for magical abilities. It shares the same cooldown as [[spell:1022]].
It does not remove debuffs like [[spell:642]] (Physical/Magical) or 
[[spell:1022]] (Physical only) does.

### [[spell:633]]

[[spell:633]] is essentially a massive heal with a very long
cooldown. It will heal you (or a targeted ally) for your maximum health, with a
10-minute cooldown. It is best used as an emergency heal, either for yourself
or another raid member

You should prefer to use [[spell:85673]] to heal yourself in these scenaios , 
but if it is for another player you should use [[spell:633]] to save their life.

### [[spell:384376]]

[[spell:384376]] increases both damage done and
healing done by 20%. This also changes [[spell:20271]] into [[spell:24275]], giving
you even more damage. When talented you will also gain 20% critical
strike chance to all Paladin abilities.

### [[spell:385438]]

[[spell:385438]] replaces [[spell:384376]]. [[spell:385438]] will start
with 15 stacks of Divine Resolve. Each stack gives you 2% maximum health and reduces
your damage taken by 2% for 20 seconds. After 5 seconds, you will lose 1 stack per second,
but spending 3 Holy Power will prevent a stack from being lost. You retain the other
bonuses of [[spell:384376]] with [[spell:385438]] (increased damage, crit, and
changing [[spell:20271]] into [[spell:24275]]).

The component of the incresed critical strike being retained with Sentinel is new 
for Patch 12.1 making [[spell:385438]] no longer a DPS loss to obtain.

### Damage Mitigation Cooldowns

Protection Paladins have access to two damage mitigation cooldowns with 
[[spell:31850]] (short cooldown) and [[spell:86659]]
(longer cooldown).

- [[spell:86659]] provides you with a 50% damage
  reduction for 8 seconds on a 3-minute cooldown. You should use this before a
  period of large damage.
- [[spell:31850]] is another powerful defensive ability with a
  1.5-minute cooldown and an 8-second duration. It reduces all damage taken by 20%
  while it is active, and it causes the first killing blow against you to
  heal you up to 12% of your maximum health instead of killing you (the latter
  effect consumes the Ardent Defender). This ability is best used to bypass
  deadly encounter mechanics or to save your life in critical moments. It also
  allows you to play at low health and still be safe.

You should not be afraid to use [[spell:31850]] as it is regularly available, 
however your usage of [[spell:86659]] should be a bit more planned out 
as it is not as readily available. You can gain a second charge of [[spell:86659]]
with [[spell:1246481]] making it more readily available.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **21 Sep. 2026:** Updated openers for Instruments of the Divine.
- **10 Aug. 2026:** Reviewed for Patch 12.1 and added Opener Timeline.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2. Lowered the Rotational Priority of Avenger's Shield.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **07 Oct. 2024:** Fixed issue with picking Hero Talents and updating rotations.
- **16 Sep. 2024:** Updated buttons for Hero talents and added default options on page load.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch with new checkboxes for different talents and hero talents.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Rephrased defensive cooldown section.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Removed references to Seraphim.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Added Shield of the Righteous to rotation priority list for clarity. Reviewed for Patch 10.1.
- **20 Mar. 2023:** Removed Of Dusk and Dawn section as it has been reworked in Patch 10.0.7 to be passive.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Added a small section to talk about tier set impact on rotation.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Protection Paladin in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Protection Paladin

Welcome to our Gear and BiS Page for Protection Paladin for
Midnight Season 2. Check this page to learn everything
you need to know about gearing a Protection Paladin, including the
BiS Gear from all sources, Raiding, and Mythic+, information on the best Trinkets,
Tier Sets, and much more.

Generally speaking, you will prioritize an item level upgrade over an
"optimal" item at a lower item level as your survival is heavily reliant on
Strength and Stamina. If you have a choice on the same item level, the alternative
will likely, in generic circumstances, not make a difference defensively. We recommend
just simming the choice and doing whatever helps you do more damage.

There are exceptions to this rule and encounter specific situations
where a stat is massively devalued. You should keep an eye on the raid
encounter guides to be aware of this. Similarly, certain Mythic+ key levels
and dungeons require a slightly different gearing path. We linked the
related guides below, but generally, we will add a note here as
well.

:::details FAQCan I Sim Myself As A Tank?
Offensively, yes, you can. SimulationCraft supports Protection Paladin DPS,
and this is the recommended way to determine if an item, enchant, gem or talent is an
upgrade for your damage output.

Defensively, no. It is not recommended to sim tanks for defense in general.
There are simply too many factors and variables that go into accurately
modeling a tanking situation, and there is no single metric that will tell you
"this item or talent will make you more tanky." For example, something can
reduce your overall damage taken but not improve your ability to survive spike
damage, two factors of tanking which will vary in importance depending on the
encounter. You will be much better off following the recommendations of a guide
with respect to defensive gearing than you will by following sims.

It is also worth noting that when evaluating offensive gear options, the
simulation assumes optimal play. If you are not seeing similar levels of DPS
gain to your sim, you may need to review some aspect of your gameplay to assess
where areas for improvements are. We would recommend uploading some gameplay to
Warcraft Logs as it becomes an easier platform to review in isolation.

:::

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the Best in Slot Gear from any source in Midnight Season 2. It serves as a reference to what is currently the highest-performing gear available to Protection Paladin from all sources.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). What is BiS right now may not be the same as the below as this would be an example of an end game setup, and serve as guidance of what items to target.

:::details FAQWhich Tier Set Pieces Do I Want?
In this season you retain the bonuses from the item you Catalyze meaning that all 5 tier pieces are on the table. For the items you are specifically targeting to Catalyse these would be:

- Helmet: [[item:281239@JAAGAAgsSYjMhbD]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>).
- Shoulders: [[item:251138]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>).
- Chest: [[item:268222@JAAEAAgsSghN]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) (9/6 Myth).
- Gloves: [[item:268220@JAAEAAgsSYjM]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>).
- Legs: [[item:271878@JAAEAAgsSghN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) (9/6 Myth).

:::

:::details FAQWhat to Get From The Great Vault?
You have two options with the Great Vault. You have the standard thinking and the optimised thinking. The Standard thinking would be to opt for any item from the Last 2 bosses if you have killed them on

**Mythic**

as they will be 9/6 Myth. Next, other items from

**Mythic raids**

will appear as 6/6 Myth in the vault. Finally, Heroic kills will yield 1/6 Myth from the vault. This is a change with Season 2. From the optimised thinking you can opt to pick a Bonus Roll from the vault each week and exclusively target a boss which yields multiple good drops (

[Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

,

[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

). For this to work you should

**not obtain items**

through conventional means (winning the roll or having it distributed to you) as you can potentially get a duplicate from your Bonus Roll.

**This method should only be used by structured teams that have agreed to use this methodology for their loot.**

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271465@JAAGAAgsSYjMhbD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271466@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAgsSghN]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAAEAAgsSghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271463@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271464@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAAEAAgsSghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271468@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268196@JAAEAAgsSgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the Best in Slot Gear from Mythic+ in Midnight Season 2. It serves as a reference to what is currently the highest-performing gear available to players from dungeons only.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). What is BiS right now may not be the same as the below as this would be an example of an end game setup, and serve as guidance of what items to target.

:::details FAQWhich Tier Set Pieces Do I Want?
In this season you retain the bonuses from the item you Catalyze meaning that all 5 tier pieces are on the table. For the items you are specifically targeting to Catalyse these would be:

- Helmet: [[item:239050@JAAEAAgsSYjM]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>).
- Shoulders: [[item:251138@JAAEAAgsSYjM]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>).
- Chest: [[item:193753@JAAMAAQkCYHKvbRLfIrE2ID]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>).
- Gloves: [[item:159413@JAAEAAgsSYjM]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>).
- Legs: [[item:159435@JAAEAAgsSYjM]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>).

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): This dungeon features a lot of high impact gear slots; Weapon, Trinket, Ring, and some Catalysable pieces for Tier.
- [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>): Features the shield that you will want to farm.
- [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): Has a wide variety of loot that is deisrable to catalyse.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271465@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271466@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:273781@JAAEAAgsSgjM]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Waist</th><td>[[item:159418@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271463@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271464@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271468@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:159459@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250259@JAAEAAgsSgjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:250245@JAAEAAgsSgjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251218@JAAEAAgsSgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251150@JAAEAAgsSgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span></div></td></tr></tbody></table>

### Raid

This list contains the Best in Slot Gear from Raids in Midnight Season 2. It serves as a reference to what is currently the highest-performing gear available to players from raids only.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). What is BiS right now may not be the same as the below as this would be an example of an end game setup, and serve as guidance of what items to target.

:::details FAQWhich Tier Set Pieces Do I Want?
In this season you retain the bonuses from the item you Catalyze meaning that all 5 tier pieces are on the table. For the items you are specifically targeting to Catalyse these would be:

- Helmet: [[item:281239@JAAGAAgsSYjMhbD]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>).
- Shoulders: [[item:271444@JAAEAAgsSYjM]] from Trash Mobs with Haste and Mastery.
- Chest: [[item:268222@JAAEAAgsSghN]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) (9/6 Myth).
- Gloves: [[item:268220@JAAEAAgsSYjM]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>).
- Legs: [[item:271878@JAAEAAgsSghN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) (9/6 Myth).

:::

:::details TipsWhich Raid-Items Do I Want Most?
There are a lot of good items from the various raids. Below you can find a few which you should prioritize first.

- [[item:268209@JAAEAAgsSYjM]]: Weapon with a special effect. Once you obtain [[item:270173@JAAEAAgsSYjM]] it will start to cleave.
- [[item:270173@JAAEAAgsSYjM]]: To enable the above weapon.
- [[item:268265@JAAEAAgsSYjM]]: Special neck that everybody will want.
- If you are a Mythic raider the last 2 bosses will give you 9/6 Myth Items. This would be Chest, Legs, Weapon, Trinkets and Belt.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271465@JAAGAAgsSYjMhbD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271466@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAgsSghN]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAAEAAgsSghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271463@JAAEAAgsSYjM]]&#10;&#10;<div><span>Trash Drop with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271464@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAAEAAgsSghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271468@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> with <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268249@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268196@JAAEAAgsSgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Protection Paladin

As a Protection Paladin or any tank in general your trinket slots can be a powerful tool
to solve an issue defensively. In many scenarios your class toolkit (Defensive cooldowns)
will cover these needs entirely and you can lean towards more offensive trinkets 
which will be ranked below. In the scenarios where you do need that additional defensive
layer there will be a "Defensive" tier which details trinkets of value for these purposes.

With Midnight Protection Paladin now works on a 1 minute cycle, therefore on use trinkets
that can work on this cycle will perform better as it will line up with [[spell:384376]]
and [[spell:375576]]. Meaning 1/2/3 Minute cooldown trinkets will be preferred over 1.5
minute trinkets.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Protection Paladin Trinkets**
**On-Use -**

[[item:270175@JAAEAAgsSYjM]]

**Passive -**

[[item:270173@JAAEAAgsSYjM]]

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>)  	Click for Protection Paladin Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270175]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168]] - <span><em>Click for Details</em></span>&#10;<span>This trinket can provide an overwhelming amount of burst damage which is especially useful for fights with damage amplification phases &#10;		   or burst DPS checks such as <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> or <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a>. The 4 minute cooldown may look unappealing but the amount of damage &#10;		   it can provide makes up for that.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164]] - <span><em>Click for Details</em></span>&#10;<span>The buff from this trinket is pretty good, but you have no control over which secondary stat gets buffed or when it gets buffed. The high &#10;		   proc rate counters this.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215]] - <span><em>Click for Details</em></span>&#10;<span>Stacking Critical Strike with a very high uptime.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270602]] - <span><em>Click for Details</em></span>&#10;<span>This trinket gives you a large amount of Strength every minute. It lines up perfectly with our cooldowns with one big downside... &#10;		   You need to do PvP. As it is a PvP item, it will have a fixed item level and will be outscaled by fully upgraded Hero Track trinkets and any Myth &#10;		   trinket on this list.</span>&#10;<li>&#10;&#10;&#10;[[item:273796]] - <span><em>Click for Details</em></span>&#10;<span>Random secondary stats on a 2 minute cooldown. Will line up for every other use of [[spell:384376]] but could roll Mastery making it &#10;		   not very powerful. It also has a downside of reducing that secondary stat afterwards which would be when you are falling out of [[spell:385438]].</span>&#10;</li>&#10;<li>[[item:158367]]</li>&#10;<li>&#10;&#10;&#10;[[item:250259]] - <span><em>Click for Details</em></span>&#10;<span>A simple passive damage trinket with Strength on it.</span>&#10;</li>&#10;</li></ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>Defensive Trinkets</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270160]] - <span><em>Click for Details</em></span>&#10;<span>1m30s big absorb shield. It's arguably the best option available for something that is both controlable &#10;		   and you can incorporate into a cooldown plan.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250245]] - <span><em>Click for Details</em></span>&#10;<span>Random absorbs. When seeking defensive trinkets you want it to solve an issue which this does not facilitate as you &#10;		   cannot control when the effects occur.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270174]] - <span><em>Click for Details</em></span>&#10;<span>A strange trinket that gives you a flat amount of Mastery but only gives you the Strength when it procs, so you are actively weaker &#10;		   as a tank until it triggers. On average any other trinket would give you more of a Defensive gain due to the passive Strength (which is armour, and &#10;		   more damage so your rotational absorbs are stronger).</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Bonus Rolls are here to stay in Season 2. You now only need to use one Voidcore to Bonus Roll any item 
(was previously 2 for Raid Items, 1 for any other source). They have changed slightly in how you acquire them:

- **From the start of Season 2:** You are able to obtain a Voidcore from the Great Vault as a reward option.
- **From Week 8 of Season 2:** You can purchase 1 Voidcore per week.

3.1.

#### Recommended Nebulous Voidcore Usage for Protection Paladin

Your primary goal with the Voidcores are to get hard to obtain items such as 
trinkets as they have high levels of competition from the DPS in your group. 
However, if you do not have a Weapon or Shield yet those are also good options to chase. 
You should also take into consideration potential power to meet your goals in game, for example 
if your guild has not killed Mythic Belo'ren there is no value in you having multiple Voidcores 
spare as that can provide you with the power required to kill the boss that reset. You will 
get 2 more the reset after. The general priority is as follows:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Myth Track [[item:268209]]
2. Myth Track [[item:270173]]
3. Myth Track Shield (if you do not have a Crafted Shield)
4. Remaining BiS List items

:::

3.2.

#### Ascendant Venomstones

[[item:280562]] will upgrade your 6/6 Hero/Myth items to 8/6 Hero/Myth.
These will **not work** for items that drop at 9/6 Myth from Coiled Altar and Ulatek
Mythic. Your priority order of upgrades will follow the same order as your crest priority order:

1. Mainhand Weapon as the highest priority.
2. Your on-use trinket for Damage or your Shield for Defensiveness.
3. Your passive trinket.
4. Your necklace.

You will also want to prioritize Myth track items over Hero track ones. Additionally, 
if you are not killing Coiled Altar or Ulatek on Mythic any time soon it is more than fine to 
upgrade the Heroic **Bonus Rolled** variants of these items as the power gain will be much 
larger than an alternative Mythic or Heroic piece.

4.

### Best Embellishments for Protection Paladin

Generally speaking you want to have [[item:240167]] on your two embelished items.

However, if you are not expecting to receive a Mythic Weapon or Shield in the first few weeks this will change your priority 
of embellishments as you cannot put [[item:240167]] on a crafted weapon.

The below section will have more details on what to craft and when you will replace them.

5.

### Best Crafted Items for Protection Paladin

Crating items at the start of the Season is focused on your progression goals. At the start of a Season it is always best 
to craft a **weapon** as they are scarce and not readily available for a few weeks. They are also crest neutral if you obtain a 1/6 Myth 
weapon as a replacement. We will then focus on obtaining our embelished items.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Protection Paladin Crafting Order**
Any strength 1 hand weapon made with Myth crests such as

[[item:237839]]

with

[[item:245876]]

If you are

**not**

a Mythic raider

[[item:237831]]

with

[[item:240167]]

Once you have a Myth Track Weapon/Shield:

[[item:237834]]

with

[[item:240167]]

Once you have replaced both the Weapon and Shield: Craft a pair of

[[item:237828]]

with

[[item:240167]]

.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

5.1.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

6.

### Crest Usage

Completing end-game activities in Midnight will reward you with Crests. Once you have upgraded a slot to a certain item
level, **upgrading other items of that slot to that item level is free**.

We recommend **not** upgrading pieces using Myth crests in the first few weeks of 
Midnight Season 2. The reason for this is due to the crest upgrade costs in Midnight have increased 
meaning that you can upgrade fewer items per week. As a result, if at all possible, you have an incentive to 
strategically game your upgrades, and craft Myth-track embellishment items first.

**Crest Optimisation Tip:** If you are not crafting a Weapon/Shield try to get a Strength 2 Hand Weapon (Ret Loot Spec) and upgrade that 
to make upgrading the Weapon and Shield free.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Protection Paladin Crest Upgrade Priority**
**Weapon**

/

**Shield**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜ Other Armour/Sim Recommendation

:::

7.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Included new items from Kithix and item upgrading recommendations for Ascendant Venomstones.
- **21 Sep. 2026:** Added Font of Venomous Rage to trinket recommendations.
- **04 Sep. 2026:** Fix incorrect ring location.
- **18 Aug. 2026:** Updated gear recommendations with first batches of changes to items.
- **10 Aug. 2026:** Updated Gear Recommendations for Season 2 in Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Added crafting recommendation of shield for non Mythic raiders.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5. Added Cartel Chip recommendations. Adjusted when to replace DISC belt.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **13 May 2025:** Updated Cartel Chip Recommendations.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Dec. 2024:** Updated Cyrce's Circlet information. It's been buffed and is now really worth using. It's BiS!
- **15 Dec. 2024:** Added Cyrce's Circlet section. TLDR: If you've got 636/639 its not BiS. Otherwise gem recommendations are on the page.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **28 Sep. 2024:** Updates for Trinkets.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated with your Pre Season BiS for The War Within Launch. Further updates to come closer to Season 1.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **28 Nov. 2023:** Updated Dawn of the Infinite links to be specific to their keystone dungeons.
- **07 Nov. 2023:** Updated the page to account for the nerfs to Sporecloak. The Embelishment recommendations have been changed to account for this.
- **06 Nov. 2023:** Updated for Season 3.
- **04 Sep. 2023:** Updated gear layout. Added BiS list.
- **10 Jul. 2023:** Updated Onyx Annulet section to note when you replace this ring. Added 10.1.5 item section.
- **01 May 2023:** Moved Onyx Annulet section to the bottom of the page (It's still good for damage!). Updated gear, trinkets, and embelishments for Season 2.
- **20 Mar. 2023:** Added Onyx Annulet section.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Protection Paladin. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Protection Paladin Stat Priority

If you ever worry about dying too quickly, we recommend gearing defensively with the
following stat priority.

Haste

Versatility

Mastery

Critical Strike

Offensively, the stat priority for Protection Paladins is as follows:

Haste

Critical Strike

Versatility

Mastery

It is important to take into account that the value of your secondary stats
are all extremely close in terms of value, and item level is by far the most
important aspect of gear upgrades. In most cases, this stat priority is only
really useful comparing when you have two items of the same item level.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Evaluating your stat priority**
The stat priority shown above may differ from results from simulations 
  as your current gear situation may show that other stats are better.
  For the best results it is recommended to regularly sim your upgrades.

:::

2.

### In-Depth Stat Breakdown

**Haste** reduces your global cooldown and the cooldowns of most of the
abilities that are part of your rotation. Haste's main task is to increase
[[spell:53600]] uptime, to generally smooth damage intake,
and make you more predictable to heal. At ～20% Haste, you will have more than
enough rotational Holy Power to achieve very high uptimes on
Shield of the Righteous. At ～25-30% Haste, you will be able to cast [[spell:85673]]
without fear of dropping Shield of the Righteous uptime. Once you are at this
level of Haste, you will want to start looking to maximise the benefits of other stats over Haste.

**Mastery**, thanks to [[spell:76671]], increases your
chance to block attacks and your attack power. Mastery also allows you to block spells and periodic damage
at a rate of 2x to your block. Finally, Mastery increases your attack power which
will improve the damage of your abilities but not damage that comes from external
sources such as trinkets or enchants.

:::details FAQIs There A Specific Amount of Mastery I Should Have?
In Midnight several talents which specifically targeted increasing Block chance has been removed.
However the Mastery has been changed to now give 1% Phys Block and 2% Magic Block per percent of Mastery. With
purely stacking mastery it is **impossible to obtain 100% block** due to Diminishing Returns. The maximum
amount you can obtain at 9200 Mastery Rating (the max amount you can have, having more than this will just be ignored):

- **93.72% Spell Block**. Increased to 94.24% with [[spell:462854]].
- **78.31% Physical Block** Increased to 78.86% with [[spell:462854]].

:::

**Versatility** increases all damage and healing done as well as
reducing damage taken. Versatility gives you slightly more damage reduction
per point than Mastery, and it will also be active outside of
[[spell:26573]]. However, it is not as strong as
Mastery due to missing out on block chance as well.

**Critical Strike** increases your damage and healing output
and also gives you Parry, as you get 1 Parry from for every 1 point of
Critical Strike. Critical Strike does very little for you defensively outside
of the parry increasing, which can increase the frequency at which
[[spell:85043]] can trigger. It is worth noting that in scenarios
where Physical attack from multiple sources is happening (Mythic+), parry
becomes a very valuable defensive stat.

**Strength** increases the Armor gained from
[[spell:53600]], your attack power, and your parry chance
(by a small amount).

Against most encounters, you need to have a decent
amount of health in order to give yourself the chance to be healed before a
subsequent attack kills you. In addition to this **minimum amount of
Stamina**, we feel that Stamina remains quite valuable for Protection
Paladins. However, most of your Stamina is innately found on your gear, but
it is always a good option to have additional Stamina available, should it
temporarily be necessary through trinkets, enchants, and gemming (in that
order). As you become more comfortable determining the amount of
survivability needed for each encounter, you can shift some of that Stamina
into other stats.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated stat breakpoints for Mastery and Block.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated Mastery values with up to date modelling on the breakpoints to reach 100% block.
- **23 Mar. 2026:** Updated stat priorities to show a defensive stat priority in addition to a standard priority.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated Stat Priorities for each hero talent. Added specific Mastery thresholds for 100% Block.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Protection Paladin, based on your [stat priority](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should use a [[item:240983]] in your first
available gem socket, and fill every other with [[item:240892]]. While
there are many other Eversong diamond options and secondary stat gems available, these two
provide the best benefits.

2.

### Best Enchants and Weapon Augments

[[item:243733]] as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar or [[spell:433568]] as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Head</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:244643]]</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244017]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>or [[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

Use [[item:241326]] as a general-use flask in all content types.

3.2.

#### Potions

[[item:241308]] should be your combat potion of choice.

You should use [[item:271883]] for in-combat healing.
Healing potions do not share a cooldown with [[item:5512]]s, so you can use both
independently if you can access a Warlock.

3.3.

#### Food Buff

Use [[item:242274]] (secondary stat)
as your food buff of choice if a Feast is not available.

If a [[item:255846]] (primary stat) / [[item:242273]] (secondary
stat) is provided by the group, use them instead. **Either are fine.**

When deciding what food type to use it would be advisable to sim both options to
identify which one is better for you. Primary Stat (Strength) and Highest Secondary
Stat options are available for both feasts and personal food buffs.

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s to increase your primary stat. 
Augment Runes will be expensive until the final Season of the expansion, and disappear on death, so use them wisely!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1 with new health potion.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Removed references to tea as these are no longer usable inside of instances.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2. Removed corruption section as this no longer works in Season 3 and changed Healing Potion to the new Invigorating Healing Potion.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **16 Sep. 2024:** Updated Vantus rune information.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated with new gems, enchants, and consumables for The War Within Launch.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Added helm enchant and new healing potion.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **14 Jul. 2023:** Updated Weapon Enchants and Flask recommendations. Weapon Enchants to be more explict on the two choices, both choices are fairly close in terms of throughput however. Flask has been changed to Tepid Versility due to the increased prevalance of external damage sources.
- **10 Jul. 2023:** Updated Onyx Annulet and Primordial Gems section, and when you should consider replacing it.
- **01 May 2023:** Added belt enchant (New in Patch 10.1) and reviewed for Season 2.
- **25 Mar. 2023:** Updated Primordial Gems recommendations.
- **20 Mar. 2023:** Added Onyx Annulet and Primordial Gems section.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Protection Paladin in World of Warcraft Patch 12.1.5.

1.

### Protection Paladin in Mythic+ in Midnight Season 2

Protection Paladins are very strong in Mythic+ due to their self-and group
healing, dispels, utility, and with their ability to lock down caster mobs
with [[spell:31935]]. While we lack the ability to force move
enemies around, we make up for it in utility.

If you want to learn more about Mythic+ during The War Within in general
or Protection Paladin's place in the overall rankings, see our overviews below.

2.

### Best Mythic+ Talent Builds

### Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar

2.1.

#### Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar will offer you good burst DPS in weekly keys with
[[spell:429826]] and [[spell:375576]] being available for every pull. It also
provides an overall more laid back experience in keys.

**Use the 'Export Talents' button to import the best build directly into your game.**

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiKuxxYjbFEU1NQSC1LD-YOAJwMVkBilXuHQf6ausElQJIUEKZDkG-AAAA-bYWUoEcAQMxQAB-
```

:::

### Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith

2.2.

#### Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) Lightsmith is the go to for higher keys this season. It both provides more overall damage than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) Templar
and synergises with the Tier Set bonus through [[spell:26573]].

**Use the 'Export Talents' button to import the best build directly into your game.**

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-OQURYhpBYQQBkE-
```

:::

2.3.

#### Talent Swap Options

The main talent swap you can do in these trees is to change [[spell:1245979]] to [[spell:1301732]] to gain more effective health from the overheal effect. 
As you get more comfortable with the spec you will not need to worry about your [[spell:53600]] uptime, alternatively you could opt to ignore this 
choice node and pick up [[spell:378285]] for more DPS or [[spell:378405]] for more healing.

In some dungeons you may want to change some talent points for additional utility. The talents you can swap in the Paladin Tree would be [[spell:204054]]
or a point in [[spell:385427]] for nodes such as [[spell:146956]], [[spell:10326]], [[spell:387791]].

What you could swap into with these points would include:

1. If the dungeon Features non elite Undead monsters you can pick up [[spell:10326]] to have an instant kill ability when they are below 30% HP.
2. [[spell:204054]] for an AoE slow to help with kiting enemies.
3. If the dungeon does not require [[spell:204018]], you can swap this choice node to [[spell:378425]].

3.

### Utility Kit and Abilities

### Interrupts, Stuns, and Stops

3.1.

#### Interrupts, Stuns, and Stops

- [[spell:31935]] is one of the strongest abilities in our toolkit
  for Mythic+. Not only does it interrupt, but it will also silence enemies that
  can be silenced for 3 seconds. This allows you to almost fully lock down any
  caster by yourself, especially if they can be stunned by
  [[spell:853]] as well, and let the rest of the group deal with
  another caster.
- [[spell:96231]] is another interrupt option for enemies in melee range.
- [[spell:853]] is a long single-target stun that can be used
  often with the [[spell:234299]] talent. This can be used to make
  enemies non-threatening for a couple of seconds or prevent them from moving
  if they may want to.
- [[spell:115750]] can be used to disorient enemies within 10 yards.
  This can be used as an AoE interrupt for crowd-controllable casting enemies.
- [[spell:10326]] fears an Undead, Aberration, or Demon target within 20
  yards for up to 40 sec. If they are a non elite enemy and are below 30% HP they will instantly be killed!

### Other Utility

3.2.

#### Other Utility

- [[spell:391054]] allows you to combat res a party member.
- [[spell:465]] reduces all damage taken by your group by 3%.
- [[spell:213644]] can remove all Poison and Disease effects
  from a group member. [[spell:213644]] has value in every dungeon apart from Dawnbreaker and Stonevault.
  It can also be used to deal with the [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>) affix.
- [[spell:1022]]/[[spell:204018]] and
  [[spell:6940]] are amazing tools in dungeons to help your group
  survive both dangerous affixes as well as abilities.
- [[spell:1022]] has two additional benefits on top of providing
  the target immunity to Physical damage. It will remove any Bleed effect on the target,
  and make them lose threat temporarily on enemies that deal Physical damage. Very helpful
  for the Fury Warrior who popped all cooldowns before you even put down [[spell:26573]]!
- [[spell:305394]] will help with negating slows/roots on your party, but, more importantly,
  also apply [[spell:1044]] to yourself when cast on others.
- [[spell:85673]] and [[spell:633]] are not only self-heal
  abilities, but can be used on group members to great effect as well
  to help the healer.

4.

### Dealing with Affixes

This section has Protection Paladin-specific tips for dealing with the various affixes of Mythic+.

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Protection Paladin

[[spell:115750]] is our only AoE stop that will deal with the orbs. If you are a Blood Elf, [[spell:28730]] will also
work as an AoE dispel. Single target options are also available in the form of [[spell:853]], [[spell:96231]], and [[spell:31935]].

### Affix: Voidbound

4.2.

#### Voidbound Affix Management for Protection Paladin

The Void Emissary always spawns on you and just needs to be killed. You will not need to take any different talents for
this affix, use your best damaging buttons available at the time to deal with this affix.

### Affix: Pulsar

4.3.

#### Pulsar Affix Management for Protection Paladin

Pick up orbs. Run around with [[spell:190784]] or [[spell:305394]].

If you need to move out of your [[spell:26573]], be sure to put down a new one as you are moving.

### Affix: Devour

4.4.

#### Devour Affix Management for Protection Paladin

[[spell:213644]] to dispel it. [[spell:85673]] with [[spell:321136]] or [[spell:633]] to heal it off.

**Do not use [[spell:642]] to remove it, as the group will not gain a stack of [[spell:465136]].**

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **21 Sep. 2026:** Updated recommendations for Lightsmith.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Dungeon specific tips have been added!
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **19 Aug. 2024:** Updated Talents for The War Within Launch.
- **19 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Season 3.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated talent tree for Patch 10.1.5.
- **01 May 2023:** Updated talent tree for Patch 10.1 and affix information for Season 2.
- **20 Mar. 2023:** Updated talent builds for Patch 10.0.7. Added Turn Evil usage.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Protection Paladin in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Protection Paladin macros.

1.1.

#### Generic Macros for Paladins

Most of the macros for Paladins revolve around allowing you to use your
utility spells on your mouseover target.

1.1.1.

##### Blessing Mouseover Macros

#### Mouseover Blessing of Protection

```wow-macro
#showtooltip Blessing of Protection
/stopcasting
/cast [@mouseover, help, nodead] Blessing of Protection
```

#### Mouseover Blessing of Freedom

```wow-macro
#showtooltip Blessing of Freedom
/stopcasting
/cast [@mouseover, help, nodead] Blessing of Freedom
```

#### Mouseover Blessing of Sacrifice

```wow-macro
#showtooltip Blessing of Sacrifice
/stopcasting
/cast [@mouseover, help, nodead] Blessing of Sacrifice
```

These macros allow you to cast your various hand spells on the target you
are
currently mousing over. Stopcasting is in place to ensure that you do not delay
casting any of these spells due to a cast already in progress.

1.1.2.

##### Lay on Hands Mouseover Macro

#### Lay on Hands Macro

```wow-macro
#showtooltip Lay on Hands
/stopcasting
/cast [@mouseover, help, nodead] Lay on Hands
```

This macro will cast [[spell:633]] on the target you are currently
mousing over.

1.1.3.

##### Word of Glory Mouseover Macro

#### Word of Glory Macro

```wow-macro
#showtooltip Word of Glory
/stopcasting
/cast [@mouseover, help, nodead] Word of Glory
```

This macro will cast [[spell:85673]] on the target you are currently
mousing over. If you want to add a failsafe into the macro where it will
cast on yourself if your mouseover target is not friendly, the below macro
covers this.

#### Word of Glory Macro with Failsafe

```wow-macro
#showtooltip Word of Glory
/stopcasting
/cast [@mouseover, help, nodead] [] Word of Glory
```

1.1.4.

##### Intercession (Combat Res) Mouseover Macro

#### Combat Res Macro

```wow-macro
#showtooltip Intercession
/stopcasting
/cast [@mouseover, dead, exists] Intercession
```

This macro will cast [[spell:391054]] on the target you are currently
mousing over.

1.1.5.

##### Mouseover Cleanse Toxins Macro

#### Dispel Macro

```wow-macro
#showtooltip Cleanse Toxins
/cast [@mouseover, help, nodead] Cleanse Toxins
```

This macro will cast [[spell:213644]] on the target you are
currently mousing over. If you want to add a failsafe into the macro where it will
cast on yourself if your mouseover target is not friendly, the below macro
covers this.

#### Dispel Macro with Failsafe

```wow-macro
#showtooltip Cleanse Toxins
/cast [@mouseover, help, nodead] [] Cleanse Toxins
```

1.1.6.

##### Divine Shield

#### Divine Shield Macro

```wow-macro
#showtooltip Divine Shield
/stopcasting
/cast Divine Shield
```

This macro will stop your current spell cast and cast
[[spell:642]], ensuring that your invulnerability is not delayed
at all.

1.1.7.

##### Rebuke

#### Focus Interrupt Macro

```wow-macro
#showtooltip Rebuke
/stopcasting
/cast [@focus,exists][] Rebuke
```

This macro will stop your current spell cast and cast [[spell:96231]] on
your focus target, if you have one. Otherwise, it will cast Rebuke on your
current target.

1.2.

#### Specific Macros for Protection Paladins

1.2.1.

##### Divine Shield Cancelaura Macro

#### Divine Shield Cancelaura Macro

```wow-macro
#showtooltip Divine Shield
/stopcasting
/cast Divine Shield
/cancelaura [noknown:Final Stand] Divine Shield
```

This macro allows you to cancel your [[spell:642]] (by pressing
it a second time). This is useful for when you want to use Divine Shield to
quickly get rid of a debuff, but want to continue tanking the boss (make sure
you use taunt to make the boss fixate you as you know, if you have Divine
Shield, the boss will attack the next target on the threat list without the
fixate).

The addition of [noknown:Final Stand] makes the macro not cancel [[spell:642]]
if you have [[spell:204077]] talented.

You can always add both [[spell:1022]] as well as
[[spell:204018]] to the same macro to cover more bases.
This means that if you use any of the spells that might make mobs not target
you, you can always press the same button to remove its effect. And since
Divine Shield can not be cast on you when you have [[spell:25771]]
you are safe to use this macro:

#### All Immunity Cancelaura Divine Shield Macro

```wow-macro
#showtooltip Divine Shield
/stopcasting
/cast Divine Shield
/cancelaura [noknown:Final Stand] Divine Shield
/cancelaura Blessing of Protection
/cancelaura [known:Blessing of Spellwarding] Blessing of Spellwarding
```

Note that it does NOT matter in what order these abilities are, and the
game will not directly cancel Divine Shield right after casting it if only
pressed once. Be careful if you have to repeatedly click
[[spell:642]] in an emergency during global cooldown, as if you
keep pressing it after you cast Divine Shield you will drop it instantly.

2.

### Best Addons

2.1.

#### Generic Addons for Paladins

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.4.4.

##### Omen Threat Meter

[Omen Threat Meter](<https://www.curseforge.com/wow/addons/omen-threat-meter>)
is the most popular addon for displaying the current threat levels on your
target. We recommend you to use it to check on your current threat levels and
ensure that you are not being overtaken in aggro.

2.4.5.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) is a useful addon that allows you to track the cooldowns of other raid
members, as well as providing you with a wealth of other useful raid information.

2.4.6.

##### Cooldown Manager Addons

You have two popular options for cooldown manager customisation addons
[ArcUI](<https://www.curseforge.com/wow/addons/arc-ui>) and 
[Better Cooldown Manager](<https://www.curseforge.com/wow/addons/bettercooldownmanager>). These addons offer additional 
customisation of the Cooldown Manager by allowing you to create more bars and customise specifically what spells are tracked on 
which bar.

2.4.7.

##### Clique

[Clique](<https://www.curseforge.com/wow/addons/clique>) allows you to
bind specific spells to be cast as mouseover casts on unit frames. This can be
very useful for casting [[spell:85673]], [[spell:633]],
[[spell:6940]], and [[spell:1022]] without
changing your target.

2.5.

#### Specific Addons for Protection Paladins

Currently, we do not believe that you need any additional addons to play your
specialisation to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within Launch.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2. Added WeakAura recommendations for Protection Paladins.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
