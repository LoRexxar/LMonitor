## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Azortharion。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-guide>)
- [练级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)

## 专精概览

欢迎来到我们的魔兽世界12.1.5版本野兽控制猎人指南。在这里，你将学习如何在团队副本和大秘境中玩好野兽控制猎人：从最基础的内容到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

野兽控制大秘境资源

[全新！顶级野兽控制天赋构筑](<https://raider.io/specs/beast-mastery-hunter/talents>)

[顶级野兽控制大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/hunter/beast-mastery>)

[野兽控制大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=hunter--beast-mastery>)

[热门野兽控制队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=hunter--beast-mastery>)

1.

### 野兽控制猎人概述

野兽控制猎人是一个机动性极高的远程DPS专精。它是游戏中唯一

一个能够在移动中完全执行输出循环的远程专精。

这使得它在应对团队副本机制和

副本机制时非常有用，因为它可以在没有伤害惩罚的情况下完成这些操作。它也

相对容易上手。如果你喜欢简单但有效的远程

玩法风格，且几乎不受移动限制，你可能会觉得

野兽控制很有趣！

扎实的基线

野兽控制拥有不错的单体和大规模AoE能力，但顺劈能力较差，并且在同一套构筑中很难同时兼顾单体和AoE。它的30秒爆发周期（或者更确切地说，缺乏爆发）在团队副本的许多战斗中尤其拖后腿，但在大秘境中表现尚可。

表现平平

野兽控制在至暗之夜中拥有30秒的爆发周期，并且为了打出像样的AoE伤害而牺牲了不少单体DPS。它的整体调整水平一般，虽然任何团队副本阵容都需要一名猎人，因为

[[spell:257284]]

，但野兽控制本身并不算出色。

需要大波次

野兽控制 拥有非常强大的范围伤害，但需要非常大的一波怪才能真正发挥。它的单体和优先目标伤害只是“还行”，但如果围绕这一点来构建，总体上它是一个相当不错的大秘境专精。

表现平平

我们为团队带来的是平庸的实用性。1分钟冷却的眩晕/AoE打断，以及

[[spell:19577]]

一个常规冷却时间的远程打断。我们AoE打断的灵活性和冷却时间都很一般。

[[spell:257284]]

在团队副本中是必备的，但在大秘境的非Boss战中并不特别强。

强力主动防御，脆弱被动防御

野兽控制 拥有数个强大的主动防御技能，使其能够有效减轻大量伤害。然而，它的被动防御相对较弱，使其在高伤害环境中依赖于时机和正确使用冷却技能来生存。在持续受到高强度 DoT 的“腐蚀”伤害环境中表现不佳。因此，猎人通常比其他职业需要更多的外部治疗。技能上限相对较高，而技能下限相对较低。猎群领袖 尤其在防御方面较弱。

魔兽世界中最强的远程机动性

我们是整个游戏中唯一一个能够同时拥有近乎完全不受限制的移动能力和输出的远程专精。例外的是

[[spell:392060]]

确实需要我们每30秒站立不动1秒，因为

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠

。我们可以使用能提供高达8%额外被动移动速度加成的宠物，我们有

[[spell:781]]

/

[[spell:109215]]

可以快速覆盖长距离，并且

[[spell:186257]]

可以作为额外的机动性手段使用。

1.

### 野兽控制猎人在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本为第二赛季新增了两个终局内容。

基斯希克斯的解放是一个新的团队副本首领战，而金多詹迷宫

是一个新的巨型地下堡。我们关于这两者的指南链接在下方。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

12.1.5版本是一个赛季中期的内容补丁。它还带来了

[[item:280562]]，一种用于升级你的武器、

饰品和项链至物品等级340的新货币。其他所有新增内容都在下方的

补丁中心页面。

2.3.

#### 职业改动

野兽控制在12.1.5版本中没有实质性职业改动，该专精

的玩法与12.1版本完全相同。

在我们的 [配装](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>) 页面上，来自基斯希克斯团队副本的

催化后的[[item:281238]]是我们新的

毕业（BiS）手套，并且有一份新的清单说明应该把你的第一批

[[item:280562]]花在哪里。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_beastmastery.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 12.1版本改动

12.1版本在新赛季之外带来了相当多的内容。

有一个新区域可供探索，新的稀有怪和宝藏可供猎取，以及

大量新的住宅和幻化奖励可供收集。暴风雪还

更新了许多现有系统，并添加了生活质量

方面的改进。

:::details 显示12.1职业改动 隐藏12.1职业改动
2.5.

#### 职业改动

野兽控制在第二赛季中大体保持不变。它的爆发被削弱了，而

其基础伤害得到了提升。[[spell:115939]]变得更加宽容，并且

[[spell:193455]]通过套装效果，现在即使在

AoE中也是一个更强力的按键。

该 [全知典籍](<https://www.icy-veins.com/wow/omnium-folio-guide>) 借力系统延续到了第二赛季，并且它

同时影响你的天赋选择和装备。你可以在我们

专门的 [天赋](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>) 和

[配装](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>) 指南中找到详细信息。

- [[spell:378442]]已被移除。
- [[spell:1265052]]更名为[[spell:1265052]]并进行了重新设计。
  
  
  
  
  你的宠物的[[spell:17253]]、[[spell:16827]]和[[spell:49966]]造成的伤害
  
  
  
  
  提高了100%。
- [[spell:392053]]已被重新设计。[[spell:34026]]
  
  
  
  
  的暴击伤害提高了15%。这对
  
  
  
  
  [[spell:19574]]驱动的爆发是一个巨大的削弱，因为它过去能提高所有宠物暴击
  
  
  
  
  打击伤害35%。
- [[spell:407412]]现在使[[spell:217200]]的周期性伤害加成
  
  
  
  
  提高幅度降低至33%（原为50%）。
- [[spell:378207]]的伤害已减半。
- [[spell:115939]]的持续时间延长至10秒（原为8秒），现在
  
  
  
  
  使你的宠物攻击附近的敌人，造成所造成伤害的55%（原为
  
  
  
  
  40%），并且不再能被取消。
- [[spell:468701]]现在使[[spell:193455]]的暴击
  
  
  
  
  打击伤害提高20%（原为50%）。
- [[spell:378244]]现在使[[spell:193455]]的伤害提高10%
  
  
  
  
  （原为35%）。
- [[spell:120679]]的召唤物现在可以在冷却
  
  
  
  
  管理器中被追踪。
- [[spell:217200]]的伤害提高了25%，然后被降低了12%。
  
  
  
  
  [[spell:34026]]伤害提高20%。[[spell:193455]]伤害
  
  
  
  
  提高20%，随后再提高30%。自动射击伤害提高20%，
  
  
  
  
  远程自动射击伤害提高600%。
- **猎群领袖:** [[spell:472639]]现在会提高你的
  
  
  
  
  下一个[[spell:193455]]100%的伤害（原为200%），并且现在持续1分钟（原为20
  
  
  
  
  秒）。当你开始团队副本首领战或大秘境
  
  
  
  
  地下城时，它会被取消。[[spell:1264797]]现在会提高[[spell:193455]]的加成
  
  
  
  
  25%（原为50%）。
- **黑暗游侠:** [[spell:467749]]伤害提高300%。
  
  
  
  
  [[spell:430715]]的[[spell:466930]]伤害降低40%，并且
  
  
  
  
  [[spell:1277565]]现在会正确提高[[spell:430715]]的
  
  
  
  
  伤害。[[spell:442419]]的召唤物现在可以在冷却时间
  
  
  
  
  管理器中被追踪。
- **套装：** **2件套：** [[spell:217200]]使你的宠物
  
  
  
  
  额外触发一次[[spell:199530]]，效果为50%。 **4件套：**
  [[spell:199530]]使你的下一个[[spell:193455]]要么获得
  
  
  
  
  每层30%效果的[[spell:115939]]加成，要么对你的
  
  
  
  
  目标额外造成每层20%的伤害，最多叠加4次。

:::

:::

### 至暗之夜改动概述

2.6.

#### 野兽控制 猎人在至暗之夜中的改动

至暗之夜资料片为所有猎人专精带来了巨大改动，主要

侧重于精简和简化技能体系的各个方面。

2.6.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠

- 自动射击不再触发[[spell:378769]]。
- [[spell:217200]]有50%几率获得
  
  
  
  
  [[spell:378769]]，而[[spell:34026]]有20%几率。
- 在你激活[[spell:19574]]后，狂野怒火按钮本身
  
  
  
  
  会变成
  
  
  
  
  [[spell:392060]]，一个强力的施法技能，激活
  
  
  
  
  [[spell:378769]]，并打断/沉默所有命中的目标1秒。

2.6.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖

- 提高集中值回复，每次自动攻击获得2点集中值。
- 熊的伤害被削弱了40%，使其相对于
  
  
  
  
  其他野兽更加平衡。过去，我们经常需要特别注意围绕
  
  
  
  
  熊进行优化。现在，野兽更加平衡，这意味着你不必
  
  
  
  
  太担心接下来会出现哪一种。
- 我们TWW第三赛季4件套的机制[[spell:201430]]回归了，但它只
  
  
  
  
  会在你激活后首次使用[[spell:34026]]时触发
  
  
  
  
  [[spell:19574]]。这意味着每30秒，大约有8
  
  
  
  
  秒的时间，你最好祈祷小怪不在移动、不在台阶上、不在
  
  
  
  
  你上方、不在你下方、不在你侧面，也不在你身后。

2.7.

#### 输出与游戏机制改动

- [[spell:272795]]作为机制已完全移除。
  
  
  
  
  [[spell:257944]]现在也是纯粹的暴击加成。换句话说，不再
  
  
  
  
  需要使用[[spell:217200]]来维持增益。
- [[spell:1264359]]是一个新的天赋技能，造成大量范围伤害
  
  
  
  
  并激活[[spell:115939]]10秒。由于它有
  
  
  
  
  8秒冷却时间，只要可用就按下，就能
  
  
  
  
  永久保持[[spell:115939]]。
- [[spell:19574]]现在是固定的30秒冷却时间。它的初始
  
  
  
  
  伤害提高了，而其伤害增益部分被下调至20%，原先为
  
  
  
  
  30%.
- [[spell:378442]]已被重新设计，现在可以使用宠物
  
  
  
  
  [[spell:199530]]来帮助传播你的[[spell:217200]]持续伤害效果，作用于
  
  
  
  
  AoE中也是一个更强力的按键。
- 新的巅峰天赋，
  
  
  
  
  [[spell:1273043]],
  
  
  
  
  [[spell:1273065]]和[[spell:1273145]]（三个天赋
  
  
  
  
  共用一个名字），除了提供一些被动伤害外，还会使[[spell:217200]]/
  
  
  
  
  [[spell:193455]]，以及[[spell:466930]]来增益你下一个技能的伤害
  
  
  
  
  [[spell:34026]]，鼓励你在每次杀戮命令之间穿插一个“填充”技能。

2.8.

#### 巅峰天赋

至暗之夜引入了新的巅峰天赋，在80级至90级之间解锁。野兽

控制专精获得：

1. [[spell:1273043]]
2. [[spell:1273065]]
3. [[spell:1273145]]

它们使[[spell:19574]]造成可观的一部分伤害，而不是

仅仅是一个被动伤害增益。最后一个点数也鼓励你不要连续

使用两次[[spell:34026]]；你应该始终在中间使用一个填充技能，

比如[[spell:217200]]或[[spell:193455]]。

2.9.

#### 生存能力改动

- 猎人的最大生命值比之前提高了2%。
- [[spell:109304]]的冷却时间现在固定为1分钟，不再是可变的
  
  
  
  
  （且通常更短）。
- [[spell:186265]]的冷却时间在天赋支持下现在为2:00，从
  
  
  
  
  2:30.
- [[spell:186265]]在天赋支持下现在可以提供50%的伤害减免，
  
  
  
  
  从30%提高。
- [[spell:53480]]现在是一个外部防御技能，可以对
  
  
  
  
  你自己或任何友方目标使用，使其受到的伤害降低15%，持续10秒，
  
  
  
  
  但他们受到伤害的50%将由你的宠物承担。如果你的宠物
  
  
  
  
  生命值低于25%，它会提前结束。
- [[spell:388035]]现在是3%的被动伤害减免，不再是
  
  
  
  
  一个主动防御冷却技能。

2.10.

#### 功能性改动

- [[spell:257284]]现在是对单体目标的通用3%伤害提升。
  
  
  
  
  这基本上保证了猎人在每个团队副本中的位置。它
  
  
  
  
  在大秘境中也是对团队的增益，尽管效果要弱得多
  
  
  
  
  那里。
- [[spell:147362]]现在可以打断目标施法5秒，从
  
  
  
  
  1.
- [[spell:187650]]现在能使目标减速70%，持续4秒，触发时机是在
  
  
  
  
  使目标减速70%，持续4秒。
- [[spell:19577]]现在是我们唯一的眩晕/控制技能。一个抉择节点可以
  
  
  
  
  将其冷却时间缩短至40秒，或使其成为1秒的范围眩晕。
  
  
  
  
  [[spell:462033]]、[[spell:236776]]和[[spell:186387]]
  
  
  
  
  都已移除。
- [[spell:195645]]和[[spell:5116]]的减速效果分别为25%和
  
  
  
  
  提高了25%和10%。
- [[spell:472729]]现在是职业天赋树节点，不再
  
  
  
  
  依附于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖英雄天赋。它是一个抉择节点，与
  
  
  
  
  [[spell:459460]]同为抉择，后者延长[[spell:109248]]的眩晕
  
  
  
  
  1秒。
- [[spell:459466]]已移除。
- [[spell:213691]]已移除。
- [[spell:459533]]已移除。
- [[spell:321468]]已被移除。

2.11.

#### 杂项改动

- [[spell:186257]]的初始"超级"速度爆发现在在天赋影响下
  
  
  
  
  持续时间翻倍。
- [[spell:53351]]已被移除，并成为射击专精独有技能。
- 使用[[spell:147362]]/[[spell:187707]]成功打断现在
  
  
  
  
  提供30点集中值，比之前的10点更多，但使用宁神射击进行驱散
  
  
  
  
  [[spell:19801]] 不再提供集中值。

总体而言，我们获得了防御能力和机动性，而在功能性

方面，我们失去了一些东西（比如移动怪物的能力），但

获得了其他东西（更强的标记、更流畅的群体眩晕、更强的打断和

打断时更多的集中值返还）。我们认为这些改动总体上是积极的！

1.

### 野兽控制 猎人基础玩法

野兽控制 猎人是一个同时管理增益、冷却和宠物的专精，

基础循环很简单，专注于消耗集中值，

因为你没有主动产生集中值的手段。

你大部分时间将用于施放[[spell:34026]]和

[[spell:217200]]，在两者之间交替，并确保两者都不达到两层充能，同时

用[[spell:193455]]填充。该专精的快速总结可以在

下方列表中找到。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_bestialdiscipline.jpg>) **保持施法**
  
  
  
  
  尽可能多地施放技能比每次都按出完美技能更重要，
  
  
  
  
  每次点击按钮，而空闲等待时间是阻碍大多数玩家的最关键因素
  
  
  
  
  达成DPS目标的最大因素。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_beastmastery.jpg>) **在杀戮命令之间插入射击**
  
  
  
  
  [[spell:217200]]和[[spell:193455]]（以及[[spell:466930]]，作为
  
  
  
  
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠）每层都会使你的下一个 [[spell:34026]] 增强 30%
  
  
  
  
  通过 [[spell:1273145]]。利用这一点来应对每一次 杀戮命令
  
  
  
  
  是必须的，无论单体还是群体战斗。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_sickem.jpg>) **在群体战斗中保持狂野鞭笞冷却完毕就用**
  
  
  
  
  除了作为你[[spell:115939]]的来源（使你所有
  
  
  
  
  宠物技能造成群体伤害）之外，这个技能本身也造成大量伤害。
  
  
  
  
  只要目标超过1个，就严格按冷却时间使用，不要延迟。
  
  
  
  
  目标上。

1.

### 如何为野兽控制 猎人配装

我们专门的野兽控制配装页面涵盖了第2赛季装备，从你的

首次升级一直到完整的毕业清单。我们仍然建议

通过模拟自己来获得理想答案。一旦你获得了一些装备，你将

需要相应的消耗品、宝石和附魔来搭配这些新

物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年9月30日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 在饰品排名中将共鸣咆哮石提升至B级，将瓦什尼克的血腥怨恨和虚空处决指令降至C级，将黎明之根的树苗降至D级。
- **2026年9月30日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 修复了胸甲工具提示显示两个毒咒效果的问题。
- **2026年9月15日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 澄清了液体光泽是大秘境药水，而鲁莽药水在其他所有场合仍是首选。
- **2026年9月7日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 添加了液体光泽的预饮药时机。
- **2026年9月7日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 将猎群领袖的群体起手式拆分为大秘境和团队副本版本。
- **2026年9月7日（本页）：** 将伤害评分提升至3，大秘境评分提升至4，并重写了这两个部分。
- **2026年9月4日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 在饰品排名中将毒怒之泉提升至S级。
- **2026年9月4日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 将总体毕业清单饰品更新为守护者沸腾核心。
- **2026年9月4日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 移除了倒刺射击鼠标悬停宏。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 将团队副本毕业清单的靴子更新为无畏旅者的靴子，戒指更新为巅峰蛮勇者的爪击之戒。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 将大秘境毕业清单的武器更新为罪灼连弩，戒指更新为充能砂岩指环。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 将总体毕业清单更新为永恒尖牙之冠和龙响护手。
- **2026年8月30日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 大秘境和地下堡的猎群领袖构筑现在选择狩猎刺激而非血腥狂乱。表现相同，但集中值回复更高，使循环更流畅。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 将武器附魔更新为哈什之仪。
- **2026年8月24日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 将武器附魔更新为哈什之仪。
- **2026年8月24日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了当野性狂乱在兽群撕裂消失前就绪时保留狂野鞭笞的说明。
- **2026年8月24日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 狂野鞭笞现在是猎群领袖群体起手式的第一施放技能，也是其优先列表的首位，排在倒刺射击之前。野性狂乱召唤的巅峰宠物会在1.5秒后施放它自己的野性狂乱，且不会继承之前已激活的兽群撕裂效果，因此狂野鞭笞必须在野性狂乱之后使用，那次攻击才能产生顺劈效果。
- **2026年8月22日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 添加了关于制作护腿的说明。
- **2026年8月22日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 添加了猎群领袖团队副本群体/顺劈构筑，选择狩猎刺激而非训练专家。
- **2026年8月21日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 根据近期的即时修正更新了猎群领袖单体构筑。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 在盖博的无底袋削弱后更新了虚空核心的额外掉落优先级。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 将总体毕业清单的戒指和靴子更新为与大秘境配置一致，因为团队副本有足够的顺劈伤害，为单体配装没有意义。
- **2026年8月18日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了团队副本构筑的效用天赋。
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了饰品梯队排行。
- **2026 年 8 月 17 日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 万卷集配置现在选择虚空污染之壳而非自我修复。
- **2026年8月16日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 重做了制造建议，更正了团队副本物品列表中贪婪的 乌拉特克 之心和盖博的无底袋条目，并添加了赛季开始时的虚空核心和纹章建议。
- **2026年8月15日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 根据最新的平衡调整更新了饰品梯队排行和团队副本毕业饰品。
- **2026年8月15日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 黑暗游侠的大秘境构筑现在选择杀戮顺劈而非锋利无比。
- **2026年8月15日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 根据4件套增益更新了套装部分。
- **2026年8月15日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 黑暗游侠的大秘境构筑现在选择杀戮顺劈而非锋利无比。
- **2026年8月15日（本页面）：** 更新了4件套效果：兽群撕裂效果提高30%，每层伤害提高20%。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了虚空核心的额外掉落优先级。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 将团队副本毕业手套更新为来自尼姆瑞莎·唤波者的催化漩涡狂怒之握。
- **2026年8月12日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 添加了催化剂和大秘库常见问题解答及插槽部分，修正了催化剂掉落位置，并更新了团队副本毕业头盔和手套的来源。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 地下堡构筑现在选择紧急药膏而非荒野医术。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 修复了黑暗游侠地下堡构筑的天赋链接。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已为12.1补丁更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年7月16日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 更新了传家宝属性建议。
- **2026年7月16日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 修正了熊之坚韧和上升气流的描述，移除了野兽控制专属异种宠物表格，并更新了资料片引用。
- **2026年7月16日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 添加了饰品速查表并澄清了制作指南。
- **2026年7月16日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 更新了武器和靴子的附魔推荐，并修复了附魔工具提示链接。
- **2026年7月16日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 澄清了暴击与急速的经验法则。
- **2026年7月16日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了猎群领袖大秘境天赋构筑。
- **2026年7月16日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 将凶暴冲锋的长度修正为30码。
- **2026年7月16日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 澄清了英雄天赋指南和团队副本群体构筑说明。
- **2026年7月16日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 将狂野鞭笞和哀恸之箭添加到技能术语表，并将技能表格按字母顺序排列。
- **2026年7月16日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 更新了猎群领袖大秘境天赋构筑。
- **2026年7月16日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 将推荐的非嗜血宠物更新为阿基里。
- **2026年7月16日（本页）：** 澄清了致死一击的来源和表现概述。
- **2026年6月17日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 根据实际数据优于模拟结果，更新了推荐的第一周卷集符文。
- **2026年6月16日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 修正了大秘境毕业装备列表中的靴子。
- **2026年6月16日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 澄清了武器附魔的选择。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月21日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 简化了倒刺射击在猎群领袖单体目标中的优先级细节，因为经过测试发现围绕集中值水平进行操作并不是一个稳定的DPS提升，不值得费心去跟踪。
- **2026年4月29日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在黑暗游侠的AOE中，添加了说明：如果黑箭在凶暴野兽/野性呼唤（Bestial Wrath）之前处于冷却状态，则黑箭是激活兽群撕咬的最高优先级。
- **2026年4月28日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了哀恸之箭使用的措辞，澄清了即使你不小心错过了最佳时机，在每次野性呼唤期间使用它都是值得的。
- **2026年4月27日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 循环更新。
- **2026年4月27日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了黑暗游侠单体目标天赋构筑。
- **2026年4月25日（本页）：** 更新了野兽控制的专精表现评估。
- **2026年4月23日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 更新了戒指附魔。
- **2026年4月23日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 修正了猎群领袖大秘境构筑的问题。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月10日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了猎群领袖的输出循环。
- **2026年4月8日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 毕业装备列表和饰品层级列表更新。
- **2026年4月5日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 略微更新了野兽控制黑暗游侠的输出循环和起手式。
- **2026年4月4日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在起手式中加入了谜题盒。
- **2026年4月3日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了猎群领袖的大秘境构筑。
- **2026年4月3日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了猎群领袖的大秘境构筑。
- **2026年4月2日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠的AOE循环小幅更新。
- **2026 年 3 月 31 日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 对兽王黑暗游侠的AOE起手式进行了小幅更新。
- **2026年3月25日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了大秘境装备毕业列表。
- **2026年3月24日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了黑暗游侠的输出循环。
- **2026年3月23日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了英雄天赋描述。
- **2026年3月22日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了两个大秘境构筑。
- **2026年3月22日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了两个单体目标构筑和两个大秘境构筑。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月4日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了终局内容的专业制造推荐。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（本页）：** 已更新至至暗之夜 12.0.1。
- **2026年2月11日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠起手式更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 更新了80级的属性递减收益数值。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2025年12月4日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 添加了野性呼唤与阿莱兹/棱镜的宏命令。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 澄清了黑暗游侠的最佳药水和棱镜使用时机。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月22日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了黑暗游侠的大秘境构筑，将战争命令换成了野性呼唤以进一步平滑狂乱值的管理，获得约2.5%的AOE提升、约2%的优先目标提升，但在此过程中损失了约1%的单体目标伤害。
- **2025年9月22日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 扩展了兽王黑暗游侠多目标上DOT的价值，并澄清了这其实并没有那么难做到，伙计们。
- **2025年9月22日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了黑暗游侠的大秘境构筑，将战争命令换成了野性呼唤以进一步平滑狂乱值的管理，获得约2.5%的AOE提升、约2%的优先目标提升，但在此过程中损失了约1%的单体目标伤害。
- **2025年9月21日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠的AOE循环更新，涉及倒刺射击和杀戮命令的优先级。
- **2025年9月17日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了大秘境英雄天赋推荐。
- **2025年9月17日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠循环小幅更新。
- **2025年9月17日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境英雄天赋推荐。
- **2025年9月13日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了兽王黑暗游侠的大秘境构筑。
- **2025年9月13日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了兽王黑暗游侠的大秘境构筑。
- **2025年9月12日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了饰品层级列表和毕业装备列表。
- **2025年9月12日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 大幅更新/简化了单体目标中倒刺射击的使用方式。
- **2025年9月10日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 更新了黑暗游侠的属性优先级。
- **2025年9月10日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 循环更新，发现在使用野性呼唤时不要过于激进可以获得小幅收益。单体目标天赋构筑也根据这种打法进行了更新。
- **2025年9月10日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了单体目标构筑，并添加了团本AOE构筑。
- **2025年9月9日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠的进一步循环更新。
- **2025年9月9日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 正式将推荐的单体目标构筑切换为黑暗游侠。
- **2025年9月8日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为黑暗游侠添加了关于倒刺射击、野性呼唤和饰品使用的小型极致优化。
- **2025年9月7日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了毕业戒指。
- **2025年9月7日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 属性优先级措辞更新。
- **2025年9月7日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 黑暗游侠的AOE循环和起手式修正。
- **2025年9月6日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了毕业装备列表和饰品层级列表，以包含黑暗游侠的专属内容。
- **2025年9月6日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 小幅更新了属性优先级并重新整理了页面。
- **2025年9月6日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 略微更新了非多目标构筑与多目标构筑以及黑暗游侠的措辞。
- **2025年9月6日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了黑暗游侠的起手，并将黑暗游侠单体目标方案设为默认显示；不过，在9月9日之前不应使用该方案。
- **2025年9月6日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了黑暗游侠的构筑以及大秘境构筑描述的构筑推荐和措辞。本页将在9月9日改为推荐黑暗游侠用于单体目标。
- **2025年9月6日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 更新了推荐的单体目标构筑。在9月9日之前这不会是正确的。
- **2025年9月3日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 非多目标构筑中进行了1点天赋的替换，损失0.2%伤害，但我相信这样玩起来手感好得多，且犯错空间更小。
- **2025年9月3日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 非多目标构筑中进行了1点天赋的替换，损失0.2%伤害，但我相信这样玩起来手感好得多，且犯错空间更小。
- **2025年9月2日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 饰品层级列表和毕业装备更新。
- **2025年8月31日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 起手式更新以及关于双重兽群奔袭/野性呼唤保留的澄清。
- **2025年8月17日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 循环更新和澄清。
- **2025年8月16日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 根据调整更新了饰品层级列表。
- **2025年8月16日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于保留野性呼唤以获取DPS收益的信息。
- **2025年8月8日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于在带头冲锋期间配合4件套效果保留杀戮命令以施放嚎兽的说明。
- **2025年8月6日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 非多目标天赋更新。
- **2025年8月5日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** AOE循环和起手式变更。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月25日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了切换到1分钟血性迸发构筑的说明，该构筑列在基础单体目标构筑下方。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 基于对静电充能高估其实际表现的进一步分析，再次更新了泰坦圆盘推荐。
- **2025年6月24日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了单体目标天赋构筑。长话短说，新的静电充能最优泰坦圆盘与一群乌鸦存在强大的负向联动。放弃一群乌鸦选择蛇行韵律的DPS损失，要小于放弃静电充能选择另一个泰坦圆盘的损失。
- **2025年6月23日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 基于最新的在线修正更新了泰坦圆盘推荐。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月20日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在单体目标循环中添加了一个约提升+0.3% DPS的小型循环极致优化。
- **2025年5月13日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了代币推荐的顺序。
- **2025年5月10日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 略微更新了纸牌屋和印记的措辞/代币推荐状态。
- **2025年5月9日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了腐蚀附魔与谜之卡特尔芯片代币部分。
- **2025年5月9日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 更新了腐蚀附魔部分。
- **2025年5月9日（本页）：** 更新了最佳专精部分。
- **2025年4月29日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 将倒刺射击助手放在了更显眼的位置。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 添加了可用代币购买的物品列表。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 添加了腐蚀附魔信息。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月29日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了大秘境饰品层级列表中克赞之眼的位置。
- **2025 年 3 月 25 日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 针对3月25日的更新进行了更新。
- **2025年3月25日（本页）：** 针对3月25日的更新进行了更新。
- **2025年3月18日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了推荐的大秘境模拟路线/大秘境模拟Pastebin。
- **2025年3月18日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了新天赋的循环默认设置。
- **2025年3月18日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了关于嗜血/1分钟单体变体构建可行性的说明。
- **2025年3月17日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了关于即兴海克斯起搏器的措辞。
- **2025年3月17日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了大秘境推荐天赋构建。
- **2025年3月17日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境和团队副本AOE的推荐天赋构建。
- **2025年3月14日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 单体目标起手变更。
- **2025年3月9日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 大幅重写并简化了循环。
- **2025年3月9日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了黑暗游侠单体目标天赋构建。
- **2025年3月7日（[解放安德迈页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 根据实际数据更新了构建。
- **2025年3月4日（[解放安德迈页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2024年12月29日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了安苏雷克女王构建。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了关于瑟尔崔指环现在提升至物品等级658的内容。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年11月4日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 移除了为狂野怒火保留的枯萎火焰。
- **2024年10月31日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了关于野兽控制黑暗游侠大秘境中可以灵活选择天赋的说明。
- **2024年10月31日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了关于野兽控制黑暗游侠大秘境中可以灵活选择天赋的说明。
- **2024年10月30日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 倒刺射击的AOE优先级小幅调整。
- **2024年10月30日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 新增黑暗游侠单体目标构建，并针对最新热修复重新测试了所有构建。
- **2024年10月30日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 更新了最新热修复内容。
- **2024年10月30日（本页）：** 根据热修复更新了最佳专精部分。
- **2024年10月26日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了各Boss的天赋构建。
- **2024年10月26日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了英雄天赋顺序。
- **2024年10月26日（本页）：** 恢复了最佳专精部分。
- **2024年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了英雄天赋推荐和信息。
- **2024年10月25日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 对两个循环进行了小幅更新。
- **2024年10月25日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 对单体构建进行了小幅更新，提升约0.5% DPS。
- **2024年10月22日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年10月9日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 进一步更新了10月8日热修复后的天赋构建。
- **2024年10月8日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了10月8日热修复后的天赋构建。
- **2024年10月8日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了默认天赋选择。
- **2024年10月8日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 更新了10月8日热修复后的天赋构建。
- **2024年10月8日（本页）：** 根据更新后的10月8日热修复更新了“最佳猎人专精”部分。
- **2024年10月2日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 新增了更具体的饰品使用信息。
- **2024年9月27日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新了阿拉卡拉提示。
- **2024年9月24日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 更新了一件毕业戒指。
- **2024年9月13日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 新增了关于双黎明之线衬里无效及其解决方法的说明。
- **2024年9月13日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 更新并澄清了一些提示。
- **2024年9月10日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 精简了专业制造推荐，按团队副本和大秘境分类，并重新格式化。移除了免责声明。修复了毕业列表中的一些不一致之处。
- **2024年9月10日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 对黑暗游侠单体目标起手进行了小幅更新。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 为猎群领袖新增了AOE和单体目标的独立属性优先级。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 单体目标起手更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月30日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[大秘境页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 为地心之战第1赛季准备的初步更新。
- **2024年8月30日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 为第1赛季准备的初步更新。
- **2024年8月30日（本页）：** 为第1赛季准备的初步更新。
- **2024年8月27日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 在赛季前毕业列表中新增了关于制造装备的说明。
- **2024年8月26日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 根据Yanix的APL更新，更新了单体目标循环中的夺命射击优先级，+0.5% DPS。
- **2024年8月24日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 新增了地下堡推荐构建。
- **2024年8月23日（本页）：** 重新引入了关于地心之战中最佳猎人专精的部分。
- **2024年8月22日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月22日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已针对地心之战进行更新。
- **2024年8月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已针对地心之战进行更新。
- **2024年8月22日（[装备页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月22日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月22日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月22日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月22日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月22日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月22日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月22日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月22日（本页）：** 已针对地心之战进行更新。
- **2024年8月1日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 简化了凶暴野兽的循环使用。起手进行了小幅调整。
- **2024年7月24日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 根据最新的APL更新更新了循环和起手。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[宠物页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[WeakAuras页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋构建。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月26日（[地心之战](<https://www.icy-veins.com/wow/beast-mastery-hunter-the-war-within-pve-guide>)):** 更新了6月25日的改动内容。
- **2024年6月18日（[地心之战](<https://www.icy-veins.com/wow/beast-mastery-hunter-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月29日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** 更新了宝石匠宝石推荐。
- **2024年5月20日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** 根据正式服强度等级更新了宝石匠宝石排名。
- **2024年5月17日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** 根据近期改动和新信息更新了宝石匠和齿轮宝石推荐。
- **2024年5月16日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** 根据近期对部分宝石匠宝石的削弱更新了推荐。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月11日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 新增了一个宏，用于在你忘记或需要快速召唤宠物时提供帮助。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 为第4赛季进行了更新。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2023年12月6日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 更新了大秘境构建。
- **2023年12月4日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 根据近期改动更新了新构建。
- **2023年11月18日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 对AOE/大秘境构建进行了小幅更新。DPS相同，但手感更好。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.2版本进行更新
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对10.2版本进行更新
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对10.1.7补丁更新
- **2023年8月16日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 重构了页面。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行审查。
- **2023年5月22日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的腿部附魔，因为发现微光护甲片并不像之前认为的那样提供耐力。
- **2023年5月13日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的食物和腿部附魔。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 为10.1补丁进行了复查。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 在模拟更新以及发现新的强力组合后，更新了推荐的宝石。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 根据一系列热修复再次更新了推荐的宝石。
- **2023年3月21日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 根据3月21日的增益更新了黑曜石指环信息。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年2月22日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 更新并澄清了最佳宝石和附魔。
- **2023年2月20日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 新增了关于可提升野兽控制猎人DPS的雕文信息。
- **2023年1月24日（[9.2版本分析](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-2-changes-analysis>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[9.1 补丁分析](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 新增了倒刺射击鼠标指向宏。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月4日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的药剂。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 更新了最佳药水/药剂的推荐和描述。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月4日（[盟约与羁绊](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** 由于APL更新和顶级掠食者bug修复，再次更新了最佳共鸣技能。
- **2022年11月3日（[盟约与羁绊](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** 更新了最优导灵器。
- **2022年10月27日（[盟约与羁绊](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** 更新了通用盟约推荐。
- **2022年10月27日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-castle-nathria-raid-guide>)):** 更新了推荐的盟约和羁绊。
- **2022年10月27日（[统御圣所页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** 更新了推荐的盟约和羁绊。
- **2022年10月27日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 更新了推荐的盟约和羁绊。
- **2022年10月26日（[传说物品](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-legendaries-shadowlands>)):** 更新了单体目标最佳传说装备。
- **2022年10月26日（[盟约与羁绊](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** 更新了格里恩的描述和竞争力等级。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/beast-mastery-hunter-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[统御圣所页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-2-changes-analysis>)):** 添加了关于套装加成如何影响凶猛食欲导灵器的信息。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** 更新了对所有盟约专属传说装备的看法，并在改动中加入了7月13日的猎人增强。
- **2021年6月10日（[9.1 补丁分析](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** 添加了关于温西尔专属传说装备的信息。
- **2021年5月12日（[9.1 补丁分析](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** 添加了关于4个新盟约专属传说装备的信息。
- **2021年5月10日（[9.1 补丁分析](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[达萨罗之战页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2019年8月23日（[永恒宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 为更多首领添加了提示。
- **2019年8月10日（[永恒宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 更新了一些提示，并为奥戈佐亚和女王之庭添加了两条非常重要的提示。
- **2019年7月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 为英雄难度的大多数首领添加了提示。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 为乌纳特添加了野兽控制提示。
- **2019年5月1日（[风暴熔渣页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 为不朽者卡加斯添加了野兽控制提示。
- **2019年4月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** 本页面已针对风暴熔炉进行审查，无需更改。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对风暴熔炉进行审查，无需更改。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为达萨罗之战中的野兽控制 猎人添加了首领提示。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** 为史诗难度的古尔丹添加了提示。
- **2018年9月18日（[奥杜尔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** 为前5个首领添加了更多提示，现在其中一些以史诗难度为重点。
- **2018年9月7日（[奥杜尔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** 为除古尔丹外的所有首领添加了更详细的内容。
- **2018年9月2日（[奥杜尔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** 添加了内容。
- **2018年8月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** 目前页面为空。

显示更多

显示更少

:::

## 练级

在本页中，你将找到我们的逐级 野兽控制 猎人 升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[猎人升级指南](<https://www.icy-veins.com/wow/hunter-leveling-guide>).

1.

### 野兽控制 猎人针对至暗之夜的升级指南

野兽控制 猎人，得益于能够将其宠物用作

坦克，是一个出色的做任务升级专精。该专精能够像

坦克一样经常拉大量

怪物，多亏了[[spell:34477]]/[[spell:459546]]，同时造成远

高于坦克的伤害。

抓一只狂野宠物并用

[[spell:217200]]/[[spell:193455]].

拉怪。当它们聚在一起后，使用[[spell:1264359]] →

[[spell:19574]] → [[spell:34026]]的连招将它们爆发击杀！

1.1.

#### 升级装备选择

升级时，始终选择物品等级最高的

装备。此规则的唯一例外是，如果你有一个戒指或项链的

物品等级略低，但有两个副属性而不是一个。

在使用传家宝物品时，以及在其他装备之间做选择时，我们

建议尽可能优先选择精通，然后是暴击。

1.2.

#### 至暗之夜升级实用消耗品

特别是在至暗之夜资料片中从80级升到90级时，

有许多消耗品可以帮助缓解这一过程，除了

“常规”PvE消耗品外，还有很多消耗品可以帮助你更轻松地完成升级过程。

- [[item:132516]] — 巨大的移动速度提升，在
  
  
  
  
  坐骑无法使用时也能使用，并且比地面坐骑快得多。
- [[item:109076]] — 让你从悬崖边滑翔出去并快速
  
  
  
  
  跨越遥远的距离。
- [[item:168412]] — 不要忘记这个坐骑装备，
  
  
  
  
  它能让你的坐骑在地面上更快。
- [[item:172063]] — 一份食物带来的惊人移动速度提升。
  
  
  
  
  食物。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，请随着等级提升，按照

随着你升级，逐点分配下方天赋树。练级

输出循环部分有一个滑块，可以显示你每个等级的输出循环。

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsBzwQDbAAYGmZmlHYGzMzMjZGMzYmxMzYGzYbmZMjZGYyAAAAAAAAgxMzMgZWAsMzCYbAYA"
}
```
:::

:::details 来源计算器编码
```
#9D-QqBgEETAPMMHZUpCOOLiikeISSFoWHy1ocE-JmGNc0sUIiaOAOU8x5J9AAUdSBJuxgA-AAAA-PIMEAg0QxQoIzC-
```

:::

1.

### 升级循环

为了在升级和学习专精时保持简单，请使用滑块

选择你的等级，并观察升级输出循环随每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

1. **等级 46 起：**[[spell:34477]]会将你的
   
   
   
   
   [[spell:217200]]、[[spell:193455]]等产生的所有仇恨/威胁
   
   
   
   
   转移到你的宠物身上。所以你可以激活它，用倒刺射击和眼镜蛇射击打几个怪，然后
   
   
   
   
   看着它们涌向你的宠物进行范围伤害。从48级开始，它还会降低
   
   
   
   
   你的宠物受到的伤害，并兼具宠物防御技能的作用。这个技能是
   
   
   
   
   以野兽控制升级被认为如此优秀的重要原因之一！
2. **等级 5 起：**在大量拉怪时使用[[spell:136]]来保持你的宠物
   
   
   
   
   健康。
3. **等级 23 起：**在AOE时，使用[[spell:1264359]]来保持
   
   
   
   
   你的宠物身上的[[spell:115939]]。
4. **等级 37 起：**在开怪和即将出现的怪物身上使用[[spell:19574]]
   
   
   
   
   在15秒持续时间的大部分时间内存活。
5. **等级 11 起：**使用[[spell:34026]]，冷却好就用。
6. **等级 15 起：**使用[[spell:217200]]以避免其达到2
   
   
   
   
   层充能。
7. **等级 19 起：**使用[[spell:193455]]作为填充技能。
8. **等级 1–10：**连续使用[[spell:185358]]。
9. **等级 1–10：**使用[[spell:56641]]作为填充技能。
10.

### 最佳升级宠物

所有宠物造成相同的伤害，但它们的实用性和特殊

技能各不相同。绝对最佳的升级宠物是

[裂蹄牛](<https://www.wow-petopia.com/family.php?id=clefthoof>).

它们承受的物理伤害比任何其他宠物都更少

并且受到的治疗比任何其他宠物都更多。我们建议你将其专精设置为

设置为 **狂野** 以充分利用这额外的治疗效果。任何裂蹄牛都可以，

而且当你达到10级时有很多可供选择，所以请查看

链接，找到你最喜欢的，然后去狩猎吧！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 更新了传家宝属性建议。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月30日：** 为第1赛季准备的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。

显示更多

显示更少

:::

## 快速入门

在本页面，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩野兽控制 猎人，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，而不牺牲性能。

1.

### 野兽控制 猎人 的基础

本节面向刚接触游戏或该职业的玩家，他们

无意参与史诗难度团队副本，或只是希望以更

简单直接的方式进行专精输出，而不被

为追求最优输出所需考虑的众多优先级和主动技能

所淹没。

野兽控制 的操作相当简单，是理想的专精，适合

刚接触团队副本，或刚接触魔兽世界的玩家来说，是理想的专精。它是最受欢迎的

专精之一，曾出现在多次世界首杀中。

野兽控制 基本上就是关于按你的 [[spell:34026]] 和

[[spell:217200]]，其他时候用[[spell:193455]]填充。

在AOE战斗中，你同样需要卡好冷却时间使用[[spell:1264359]]，并且你的主要

爆发技能[[spell:19574]]也要积极地卡好冷却时间使用。这里唯一的

真正细节是，在单体战斗中你绝不能连续使用两次[[spell:34026]]。

在单体目标上背靠背使用。

以下是三条快速的经验法则，能帮助你在使用

该专精时得心应手。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_bestialdiscipline.jpg>) **保持施法**
  
  
  
  
  尽可能多地施放技能比每次都按出完美技能更重要，
  
  
  
  
  每次点击按钮，而空闲等待时间是阻碍大多数玩家的最关键因素
  
  
  
  
  达成DPS目标的最大因素。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_beastmastery.jpg>) **在杀戮命令之间插入射击**
  
  
  
  
  [[spell:217200]]和[[spell:193455]]（以及[[spell:466930]]，作为
  
  
  
  
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠）每层都会使你的下一个 [[spell:34026]] 增强 30%
  
  
  
  
  通过 [[spell:1273145]]。利用这一点来应对每一次 杀戮命令
  
  
  
  
  是必须的，无论单体还是群体战斗。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_sickem.jpg>) **在群体战斗中保持狂野鞭笞冷却完毕就用**
  
  
  
  
  除了作为你[[spell:115939]]的来源（使你所有
  
  
  
  
  宠物技能造成群体伤害）之外，这个技能本身也造成大量伤害。
  
  
  
  
  只要目标超过1个，就严格按冷却时间使用，不要延迟。
  
  
  
  
  目标上。

1.

### 猎人的野兽控制在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖单体天赋

2.1.

#### 猎人的野兽控制单体天赋

这套配置是我们 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖单体配装，用于

大多数团队副本战斗。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYGzsYmZMjZwYaGAAAAwMAAAMmZGgZ2gNYWAbDAD"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFHIJWYYaccegkkmuuy248ADFFHLruG-AADFGHQQSUacgikqwyy048+AFHJLNdC-AAAA-BCEGIUw4ARZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖AoE天赋

2.2.

#### 猎人的野兽控制地下城天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖的秘境配装，以及

以AOE为主的玩法中的最优配置。它基于对真实

大秘境地下城环境的模拟，不仅看哪种配置能打出最高的DPS，还看

在团队中哪种配置能更快地通关地下城。有些配置能打出更多

AOE伤害，但它们在单体目标上损失的输出远多于在AOE上获得的，

反之亦然。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbAYWAbDAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AACCDEFGHQSUYacegikoqs0248+AHNB-AAAA-BCEGIUw4ARZhpJ-
```

:::

2.3.

#### 猎人的野兽控制功能性天赋考量

并非所有功能性天赋都适用于每个地下城。我们创建这些

天赋配置时的假设是，你不会非常勤快地

按地下城逐个更换天赋。然而，我们的目标是确保你

不会因为缺少某个特定地下城的关键天赋而处于劣势。

这意味着我们偶尔会舍弃一些在特定情况下才有用的选择。

- 你的'灵活'天赋点，按我们建议的可舍弃顺序为：
  
  
  
  
  可牺牲的：
  
  
  
  
  - [[spell:34477]]只影响你的个人仇恨，所以对我们来说相当弱。
    
    
    
    
    对我们而言。
  - [[spell:459983]]
  - [[spell:459517]]只在某些地下城中有用，
    
    
    
    
    在其他地下城中则毫无价值。

### 野兽控制基础循环

2.4.

#### 猎人的野兽控制基础循环

请将其视为最重要的施法优先级列表。如果不确定，

直接施放优先级最高的法术即可。你的循环中不应有

任何'空窗期'。与其犹豫1秒再施放正确的法术，

而不是犹豫1秒后才施放正确的技能。随着你水平的提高，这

优先级会成为你的第二天性。

1. 尽可能使用[[spell:19574]]。它能大幅提升你的所有伤害，
   
   
   
   
   而且其自身的伤害也很可观。
2. 面对两个及以上目标时，尽可能使用[[spell:1264359]]。绝不要只
   
   
   
   
   对单个目标使用它。
3. 尽可能使用[[spell:34026]]。
4. 尽可能使用[[spell:217200]]。
5. 将[[spell:193455]]作为'填充技能'使用，即只在更重要的技能
   
   
   
   
   都不可用时才使用它。

2.4.1.

##### 巅峰天赋：自然盟友

你的巅峰天赋为你的玩法增加了一条规则。你应该尽量避免

连续使用两次[[spell:34026]]，始终在其间穿插一次[[spell:217200]]或

[[spell:193455]]。这在AOE和单体战斗中都适用。

2.4.2.

##### 第2赛季套装

2件套效果使[[spell:217200]]额外触发一次[[spell:199530]]，而

4件套效果使你的每次[[spell:199530]]都能叠加[[spell:1299389]]，在

你的下一个

[[spell:193455]]上，最多叠加4层。当你拥有3层或以上时，你应该

优先使用眼镜蛇射击而非[[spell:217200]]。

### 野兽控制防御技能

2.5.

#### 猎人的野兽控制防御法术

[[spell:109304]]是你主要的自我治疗技能，冷却时间为1分钟。

当你的生命值低于50%时使用它，以减轻治疗者的压力！

[[spell:186265]]是你的免疫技能。它可以用来完全

免疫大多数针对你的法术的伤害和效果。当你被指派使用时，

或者在危急时刻，如果你担心即将到来的机制会杀死你，就使用它！

它也能提供30-50%的减伤，尽管它通常不用于

单纯的减伤目的。

[[spell:264735]]是我们除了灵龟守护外最强的防御技能，

提供30-40%的减伤，有2层充能，每层冷却时间为1.5分钟。

用它来减免高伤害机制造成的伤害。要最优地使用这个

技能，就需要 **提前**在大量伤害到来之前使用它。

[[spell:5384]]是一个非常独特的猎人技能。它可以用来消除

仇恨和战斗，也可以用来打断针对你的施法。如果你看起来已经死亡，

怪物通常会在施法中途停止施法！

拥有[[spell:459517]]天赋时，它还会驱散你身上的所有中毒

和疾病效果。

### 野兽控制最佳宠物

2.6.

#### 猎人的野兽控制最佳宠物

关于宠物最重要的一点是，**它们的基础DPS都相同**。

基础DPS**。差异来自于功能性、防御能力以及

它们追上移动目标的速度。

首先，你需要弄清楚你是否需要使用

[[spell:2825]]/[[spell:32182]] 在你的队伍中。只有猎人、法师、唤魔师、

和萨满祭司可以使用嗜血，所以如果队伍里没有这些职业的其他人，

那就得靠你了！

如果你确实需要 [[spell:2825]]，你需要使用任意 **狂野**

宠物，因为它们自带 [[spell:264667]] 嗜血能力。使用 [这个网站](<https://www.wow-petopia.com/abilities.php>) 来寻找一只酷炫的

狂野系宠物用于开嗜血！

如果你 **不会** 需要开嗜血，那么最好的宠物是 [阿其里虫](<https://www.wow-petopia.com/family.php?id=aqiri>) 设置为

**坚韧系**。它们 +30% 的被动移动速度意味着它们花在追赶移动目标上的时间更少，

相比其他宠物能带来小幅的 DPS 提升。

话虽如此，这个加成相当小，如果你不需要

开嗜血，你基本上可以使用任何你喜欢的宠物。坚韧系

作为你的默认宠物专精是理想选择，因为它能提供生存能力。

### 野兽控制 属性优先级

2.7.

#### 野兽控制 猎人 的属性优先级

野兽控制 猎人 的总体属性优先级如下所示。

这在很大程度上只是一个粗略的指南，专为那些不想

对自己的角色进行模拟的玩家设计。如果你在模拟你的角色，请完全忽略这个

属性优先级，按照你的模拟结果来！

关于本页呈现内容的更多信息，请查看我们的主要

[属性优先级页面](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>).

物品等级通常能胜过装备上更好的副属性。

精通

暴击

急速

全能

### 暴风雪战斗助手

2.8.

#### 战斗助手 & 单键模式

游戏提供了游戏内“战斗助手”的选项，它有两种

模式：一个会建议下一个施放法术的循环助手，以及一个

「一键模式」，它会在你进行时自动为你执行这套输出循环

只是反复按一个键，它会自动为你执行这个循环。

这些工具对于新手来说可能很有价值，因为它们提供了一个合理的

“最低”水平的表现。对于 野兽控制 猎人 来说，仅仅

使用循环助手相比完美操作（几乎没人能做到）会损失约 1-2% 的 DPS。

在此基础上再使用单键模式，总损失会达到

约 9-12%。

显然，使用这些工具无法达到巅峰表现，但如果你愿意为了

操作简便而承受上述 DPS 损失，这值得考虑。

不要让游戏里、论坛上或 Discord 里的任何人

告诉你使用这些工具有什么内在的不对！

暴风雪 创建它们是有原因的，而游戏是为了好玩，无论

对你来说这意味着什么。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 将推荐的非嗜血宠物更新为阿基里。
- **2026年7月16日：** 更新了猎群领袖大秘境天赋构筑。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月6日：** 更新了推荐的单体目标构筑。在9月9日之前这不会是正确的。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了最新热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年10月8日：** 更新了10月8日热修复后的天赋构建。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月30日：** 为第1赛季准备的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年12月6日：** 更新了大秘境构建。
- **2023年12月4日：** 根据近期改动更新了新构建。
- **2023年11月18日：** 对AOE/大秘境构建进行了小幅更新。DPS相同，但手感更好。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 已针对10.1.7补丁更新
- **2023年8月16日：** 重构了页面。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在这个页面上，你将找到魔兽世界 12.1.5 版本中你的 野兽控制 猎人 的最佳天赋。我们还为团队副本或大秘境等不同类型的内容提供了默认天赋构建。如果你开启了战争模式，我们也为你准备了 PvP 天赋。

1.

### 至暗之夜 中 野兽控制 猎人 的最佳天赋

野兽控制 在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 所有内容中都使用 猎群领袖。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 更肉，但在所有情况下伤害都远远落后，而且

想要打出最佳表现也需要付出多得多的努力。我们在下面提供了 黑暗游侠 的构建

给那些偏好这种玩法风格的玩家，但我们不推荐你使用它。

- **单体目标 -** 对于纯单体目标的场景，
  
  
  
  
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 是我们的选择。
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 又是 猎群领袖。它在整体上拥有最佳的伤害，
  
  
  
  
  虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 明显更肉，但这并不
  
  
  
  
  足以证明它带来的 DPS 损失和循环复杂性是值得的。

**快速开始导入代码：**

:::talents 野兽控制 单体目标 - 猎群领袖
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwwMsBAgZYMzyMDzYmhhZGjZGzMjZMziZmxMmBjpZAAAAAzAAAwYmZAmZjxGMLgtBgB"
}
```
:::

:::talents 野兽控制 团队副本 AoE/顺劈 - 猎群领袖
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGmZmlZGzMzMjZGMzYmhZGzYmFzMjZMDGTzAAAAAAAAgxMzAMzGZDmFw2AwA"
}
```
:::

:::talents 野兽控制 大秘境 - 猎群领袖
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbEwsA2GAA"
}
```
:::

:::talents 野兽控制 探宝 - 猎群领袖
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGMGzYmhx0AAAAAAAAAzMGDYmNCWmZBsNAA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

猎群领袖

单体目标

推荐

团队副本 AoE/顺劈

推荐

秘境+

推荐

地下堡

推荐

黑暗游侠

单体目标

秘境+

地下堡

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖单体天赋

这套配置是我们 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 单体构建，用于纯单体目标场景。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 团队副本 AoE/顺劈天赋构建

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 用于有小怪或第二个目标的团队副本首领的构建。它保留了我们大秘境构建中的完整 [[spell:115939]] 组合，并选择 [[spell:257944]] 而非训练专家，在保持双目标不变的情况下提升了单体伤害。团队副本中大部分首领都有可以顺劈的目标，所以这是你在大部分战斗中会使用的构建。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 大秘境天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 大秘境构建。它基于模拟真实大秘境副本中的条件，不仅看什么能打出最高的 DPS，还看在队伍中实际什么能更快地通关副本。有些构建能打出更高的 AoE 伤害，但它们在 AoE 上获得的收益都比不上在单体上损失的，反之亦然。

1.3.1.

##### 猎人的野兽控制功能性天赋考量

并非所有功能型天赋都与每个副本相关。我们创建这些天赋构建时的假设是，你不会非常勤快地根据每个副本更换天赋。然而，目标是永远不要因为缺少某个对特定副本有巨大影响的天赋而处于劣势。这意味着我们偶尔会省略一些有用的备选天赋。

- 你的“灵活”天赋点，按我们推荐的最可舍弃顺序排列为：
  
  
  
  
  - [[spell:34477]] 只影响你的个人威胁值，所以对我们来说相当弱。
  - [[spell:459983]]
  - [[spell:459517]] 只在某些副本中有用，在其他副本中毫无价值。

### 天赋方案 0-3

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 探宝天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 用于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)的构建。它与我们的大秘境天赋构建类似，但在职业天赋树的选择上有所不同，更适合由宠物坦怪的单人游玩。

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 单体目标天赋

这套配置是我们 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 单体构建，用于大多数团队副本战斗。

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 大秘境天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 用于大秘境和其他以 AoE 为焦点的内容的构建。它基于模拟真实大秘境副本中的条件，不仅看什么能打出最高的 DPS，还看在队伍中实际什么能更快地通关副本。有些构建能打出更高的 AoE 伤害，但它们在 AoE 上获得的收益都比不上在单体上损失的，反之亦然。

1.6.1.

##### 猎人的野兽控制功能性天赋考量

并非所有功能型天赋都与每个副本相关。我们创建这些天赋构建时的假设是，你不会非常勤快地根据每个副本更换天赋。然而，目标是永远不要因为缺少某个对特定副本有巨大影响的天赋而处于劣势。这意味着我们偶尔会省略一些有用的备选天赋。

- 你的“灵活”天赋点，按我们推荐的最可舍弃顺序排列为：
  
  
  
  
  - [[spell:34477]] 只影响你的个人威胁值，所以对我们来说相当弱。
  - [[spell:459983]]
  - [[spell:459517]] 只在某些副本中有用，在其他副本中毫无价值。

### 天赋方案 1-2

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 探宝天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 用于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)的构建。它与我们的大秘境天赋构建类似，但在职业天赋树的选择上有所不同，更适合由宠物坦怪的单人游玩。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYGzsYmZMjZwYaGAAAAwMAAAMmZGgZ2gNYWAbDAD"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFHIJWYYaccegkkmuuy248ADFFHLruG-AADFGHQQSUacgikqwyy048+AFHJLNdC-AAAA-BCEGIUw4ARZhpJ-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGmZmlZGzMzMjZGMzYmhZGzYmFzMjZMDGTzAAAAAAAAgxMzAMzGsBzCYbAYA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFHIJWYYaccegkkmuuy248ADFFHLruG-AADEFGHQQSUYacegikoqs0248+AHNdC-AAAA-BCEGIUw4ARZhpJ-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbAYWAbDAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AACCDEFGHQSUYacegikoqs0248+AHNB-AAAA-BCEGIUw4ARZhpJ-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGMGzYmhx0AAAAAAAAAzMGDYmNALzsA2GAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIMMOOPQSSTUXXZbeffgiikoSVXD-AACCDEFGHQSUYacegikoqs0248+AHNB-AAAA-BCEGIUw4ARZhpJ-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYsAAgZ8AjZWegZYGzMmhZGDzYmZMjZWMzMmxMYMNDAAAAYGAAAGzMDmZAZDmFw2AwA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFHIJWYYaccegkkmuuy248ADFFHLruG-AACDFGHQSUacgikoqwyy04+AFHJLNdC-AAAA-AGIYgow4ApyCTD-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAYzsNwAGwMsFYsAAgZGzMziZYmZGMjZmZYGzMjZmZsNzMmxMsMmmBAAAAMDAAAegxYYmBEwsA2GAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AABDEFGHSUacegiqswyy024+AFHJLNB-AAAA-AGIcgow4ApyCTD-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAYzsNwAGwMsFYsAAgZGzMziZYGzwMjZmZYGzMjZmZwYMjZGGTDAAAAwMAAAMzYMMzACWmZBsNAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIMMOOPQSSTUXXZbeffgiikoSVXD-AABDEFGHSUacgioqswyy024+AFHJLNB-AAAA-AGIcgow4ApyCTD-
```

:::

上面列出的构建是热门推荐，

涵盖了适合每种终局内容风格的各种不同配装。

每个天赋构建都会有其自己的循环，并且还可以针对

特定类型的内容进一步调整，以更好地造福你的队伍。

1.

### 全知典籍

万卷典籍是 至暗之夜 中引入的“借用力量”系统，

[12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)在完成一段简短的任务线后，

会提供一些中等强度的自定义选项。

其中一些加成会影响你的伤害输出，但也有防御

和机动性选项可供选择。

你的典籍进度会带入第2赛季。选择这些加成：

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279612]]。这个是最
  
  
  
  
  灵活的，可能会随着你装备的属性需求而改变，就像你的合剂
  
  
  
  
  或武器附魔一样。精通是一个稳妥的“永远不会错”的选择。
- [[spell:1279614]]

1.

### 巅峰天赋：自然盟友

至暗之夜引入了新的巅峰天赋，在80级至90级之间解锁。野兽

控制专精获得：

1. [[spell:1273043]]
2. [[spell:1273065]]
3. [[spell:1273145]]

这些加成使 [[spell:19574]] 造成可观的一段伤害，而不是

仅仅是一个被动伤害增益。最后一个点数也鼓励你不要连续

使用两次[[spell:34026]]；你应该始终在中间使用一个填充技能，

比如[[spell:217200]]或[[spell:193455]]。

1.

### 野兽控制 猎人 的英雄天赋

英雄天赋在71级解锁，是互斥的天赋树，你可以

选择以略微改变玩法和视觉效果。野兽控制 猎人 可以在

之间 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 为你提供

[[spell:466930]]，它造成大量伤害。你会经常从它那里获得触发

来自 [[spell:34026]] 和

[[spell:217200]]

这使它可以在任何时间对任何目标使用。这些触发并不是

特别高的优先级，大多介于 [[spell:34026]] 和

[[spell:217200]] 之间。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 可以被认为是

“多了一个额外按键的 野兽控制”，大多数情况下。当你激活

[[spell:19574]] 时，该按键本身会变成 [[spell:392060]]，

它造成大量伤害并为你提供 [[spell:466930]] 触发。

在防御方面， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 提供 [[spell:430709]]，这

非常出色，因为它让我们极其容易获得

[[spell:264735]]，几乎全程可用。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 是我们最简单的英雄天赋，在

玩法

趣味性方面几乎没有增加任何内容。偶尔，你的 [[spell:34026]] 会触发一只

野兽，通过 [[spell:471876]]。这些野兽只是造成伤害，或者

提高你造成的伤害。此外，你的第一个 [[spell:34026]] 在

[[spell:19574]] 之后会召唤一个 [[spell:201430]]，一排宠物对

范围内的所有目标造成大量范围

伤害。我们在循环页面上更详细地介绍了它的用法

页面。

在防御方面， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 为我们提供 [[spell:472707]]，它能增强

我们 [[spell:264735]] 的效果。不太好。

1.

### PvP天赋（战争模式）

**这些选择适用于开启战争模式的开放世界PvE内容，不适用于

真正的PvP。**

战争模式为你在开放世界中提供了多项好处。

- 户外世界中启用的PvP天赋。
- 在最高等级时，世界任务奖励至少提高 10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于开启战争模式对升级和PvE内容的好处，

建议启用该功能，以在满级时最大化你的升级速度和奖励。

但是，你将被标记为开放世界PvP状态，并且

在升级或进行世界任务时存在被“偷袭”的可能性。

- [[spell:356976]]使你和你的宠物免疫恐惧和恐惧
  
  
  
  
  效果，在[[spell:19574]]激活期间，附近的友方宠物获得10%
  
  
  
  
  攻击速度。
- [[spell:203235]] 是升级和开放世界内容中非常有价值的加速效果。
  
  
  
  
  世界内容。
- [[spell:356707]] 会换出你兽栏中的一只坚韧或狡诈宠物
  
  
  
  
  并将当前宠物收回以恢复其最大生命值的30%，这能在
  
  
  
  
  战斗不利时救它一命。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月30日：** 大秘境和地下堡的猎群领袖构筑现在选择狩猎刺激而非血腥狂乱。表现相同，但集中值回复更高，使循环更流畅。
- **2026年8月22日：** 添加了猎群领袖团队副本群体/顺劈构筑，选择狩猎刺激而非训练专家。
- **2026年8月21日：** 根据近期的即时修正更新了猎群领袖单体构筑。
- **2026年8月18日：** 更新了团队副本构筑的效用天赋。
- **2026年8月17日：** 万卷集配置现在选择虚空污染之壳而非自我修复。
- **2026年8月15日：** 黑暗游侠的大秘境构筑现在选择杀戮顺劈而非锋利无比。
- **2026年8月12日：** 修复了黑暗游侠地下堡构筑的天赋链接。
- **2026年8月12日：** 地下堡构筑现在选择紧急药膏而非荒野医术。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 澄清了英雄天赋指南和团队副本群体构筑说明。
- **2026年6月17日：** 根据实际数据优于模拟结果，更新了推荐的第一周卷集符文。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月27日：** 更新了黑暗游侠单体目标天赋构筑。
- **2026年4月23日：** 修正了猎群领袖大秘境构筑的问题。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年4月3日：** 更新了猎群领袖的大秘境构筑。
- **2026年3月23日：** 更新了英雄天赋描述。
- **2026 年 3 月 22 日：** 更新了两个单体目标构筑和两个大秘境构筑。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月22日：** 更新了黑暗游侠的大秘境构筑，将战争命令换成了野性呼唤以进一步平滑狂乱值的管理，获得约2.5%的AOE提升、约2%的优先目标提升，但在此过程中损失了约1%的单体目标伤害。
- **2025年9月17日：** 更新了大秘境英雄天赋推荐。
- **2025年9月13日：** 更新了兽王黑暗游侠的大秘境构筑。
- **2025年9月10日：** 更新了单体目标构筑，并添加了团本AOE构筑。
- **2025年9月9日：** 正式将推荐的单体目标构筑切换为黑暗游侠。
- **2025年9月7日：** 黑暗游侠的AOE循环和起手式修正。
- **2025年9月6日：** 更新了黑暗游侠的构筑以及大秘境构筑描述的构筑推荐和措辞。本页将在9月9日改为推荐黑暗游侠用于单体目标。
- **2025年9月3日：** 非多目标构筑中进行了1点天赋的替换，损失0.2%伤害，但我相信这样玩起来手感好得多，且犯错空间更小。
- **2025年8月6日：** 非多目标天赋更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月25日：** 更新了切换到1分钟血性迸发构筑的说明，该构筑列在基础单体目标构筑下方。
- **2025年6月24日：** 更新了单体目标天赋构筑。长话短说，新的静电充能最优泰坦圆盘与一群乌鸦存在强大的负向联动。放弃一群乌鸦选择蛇行韵律的DPS损失，要小于放弃静电充能选择另一个泰坦圆盘的损失。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月18日：** 更新了关于嗜血/1分钟单体变体构建可行性的说明。
- **2025年3月17日：** 更新了大秘境和团队副本AOE的推荐天赋构建。
- **2025年3月9日：** 更新了黑暗游侠单体目标天赋构建。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月31日：** 更新了关于野兽控制黑暗游侠大秘境中可以灵活选择天赋的说明。
- **2024 年 10 月 30 日：** 新增黑暗游侠单体目标构建，并针对最新热修复重新测试了所有构建。
- **2024年10月26日：** 更新了英雄天赋顺序。
- **2024年10月25日：** 对单体构建进行了小幅更新，提升约0.5% DPS。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年10月9日：** 进一步更新了10月8日热修复后的天赋构建。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月30日：** 为第1赛季准备的初步更新。
- **2024年8月24日：** 新增了地下堡推荐构建。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 更新了大秘境天赋构建。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面中，你将学习如何在单体和多目标情况下优化你的 野兽控制 猎人 的循环。我们还提供了关于冷却时间、触发等内容的进阶章节，以最大化你的DPS。我们所有内容均已更新至《魔兽世界》12.1.5补丁。

1.

### 野兽控制 猎人 玩法与循环指南

欢迎来到我们的 野兽控制 猎人 循环页面。在本

页面中，你将找到关于在团队副本和大秘境场景中实际操作该专精所需了解的一切

内容。

这里的循环，除了更具体的起手式外，是以

**条件优先级列表**的形式呈现的。基本上，对于你施放的每一个技能，

你应该施放你能施放的最高优先级技能，**前提是其

条件已满足。** 施放该技能后，你应该从

优先级列表的顶部重新开始，并重复此过程。

下面的按钮可用于在精选的 **单体目标**

和 **AoE/大秘境** 配装。你也可以使用下面的开关来添加或

移除你可能也在使用的个别天赋。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠

单体目标

群体伤害

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:1264359]]

[[spell:468701]]

[[spell:115939]]

[[spell:424558]]

[[spell:199532]]

[[spell:407412]]

[[spell:468695]]

[[spell:1265044]]

[[spell:1296632]]

### 单体输出循环

1.1.

#### 野兽控制 猎人 单体起手式

确保 [[spell:257284]] 在你的主目标身上生效。

---

**适用条件：黑暗游侠（启用）。**

[[spell:217200]]

[[item:241288]]

[[spell:217200]]

[[spell:19574]]

[[spell:34026]]

[[spell:466930]]

[[spell:34026]]

**适用条件：猎群领袖（启用）。**

[[spell:217200]]

[[item:241288]]

[[spell:217200]]

[[spell:19574]]

[[spell:34026]]

**适用条件：猎人 野兽控制 12.1职业套装4件套（启用）。**

[[spell:193455]]

[[spell:217200]]

[[spell:34026]]

---

1. **适用条件：黑暗游侠（启用）。** [[spell:217200]]
2. **适用条件：黑暗游侠（启用）。** 使用你的药水、主动饰品、种族技能等。
3. **适用条件：黑暗游侠（启用）。** [[spell:217200]]
4. **适用条件：黑暗游侠（启用）。** [[spell:19574]]
5. **适用条件：黑暗游侠（启用）。** [[spell:34026]]
6. **适用条件：黑暗游侠（启用）。** [[spell:466930]]
7. **适用条件：黑暗游侠（启用）。** [[spell:34026]]
8. **适用条件：黑暗游侠（启用）。** 继续按照下面描述的优先级列表进行。
9. **适用条件：猎群领袖（启用）。** [[spell:217200]]
10. **适用条件：猎群领袖（启用）。** 使用你的药水、主动饰品、种族技能等。
11. **适用条件：猎群领袖（启用）。** [[spell:217200]]
12. **适用条件：猎群领袖（启用）。** [[spell:19574]]
13. **适用条件：猎群领袖（启用）。** [[spell:34026]]
14. **适用条件：猎群领袖（启用）；猎人 野兽控制 12.1职业套装4件套（启用）。** [[spell:193455]]
15. **适用条件：猎群领袖（启用）。** [[spell:217200]]
16. **适用条件：猎群领袖（启用）。** [[spell:34026]]
17. **适用条件：猎群领袖（启用）。** 继续按照下面描述的优先级列表进行。

1.2.

#### 野兽控制 猎人 单体优先级列表

以下是描述 野兽控制 猎人 最佳单体循环的优先级系统。

1. **适用条件：猎群领袖（启用）。** 如果 [[spell:19574]] 即将冷却完毕，或者即将达到2层充能，则施放 [[spell:217200]]。
2. **适用条件：猎群领袖（启用）。** 施放 [[spell:19574]]，冷却好就用。
3. **适用条件：狂野鞭笞（启用）；猎群领袖（启用）。** 如果目标多于1个，则施放 [[spell:1264359]]。
4. **适用条件：猎群领袖（启用）。** 如果 [[spell:471876]] 已就绪，则施放 [[spell:34026]]。
5. **适用条件：猎群领袖（启用）。** 在 [[spell:1273145]] 增益下施放 [[spell:34026]]，但如果 [[spell:19574]] 将在3秒内出现，或者 [[spell:471876]] 将在4秒内出现且你只剩下一层充能，则保留一层充能。
6. **适用条件：猎群领袖（启用）；猎人 野兽控制 12.1职业套装4件套（启用）。** 在 [[spell:1299389]] 达到4层时施放 [[spell:193455]]。
7. **适用条件：猎群领袖（启用）；蛇形打击（启用）。** 施放 [[spell:217200]]，冷却好就用。
8. **适用条件：猎群领袖（启用）；蛇形打击（未启用）。** 在集中值低于75时，或即将达到2层充能时，施放 [[spell:217200]]。
9. **适用条件：猎群领袖（启用）。** 施放 [[spell:193455]]，除非 [[spell:19574]] 距离冷却完毕不到一个全局冷却时间。
10. **适用条件：蛇鳞箭袋（启用）；锯齿伤口（启用）；血腥狂乱（启用）；黑暗游侠（启用）。** 如果 [[spell:19574]] 即将冷却完毕，则施放 [[spell:217200]]。
11. **适用条件：黑暗游侠（启用）。** 施放 [[spell:19574]]，冷却好就用。
12. **适用条件：黑暗游侠（启用）。** 在 [[spell:430715]]（[[spell:19574]] 的前10秒）期间施放 [[spell:466930]]，除非 [[spell:34026]] 即将达到2层充能。
13. **适用条件：黑暗游侠（启用）。** 在 [[spell:1273145]] 增益下施放 [[spell:34026]]，但如果 [[spell:19574]] 将在4秒内出现，则保留一层充能。
14. **适用条件：黑暗游侠（启用）。** 当 [[spell:430715]] 距离过期不到2个全局冷却时间时，施放 [[spell:392060]]。
15. **适用条件：黑暗游侠（启用）；猎人 野兽控制 12.1职业套装4件套（启用）。** 在 [[spell:1299389]] 达到4层时施放 [[spell:193455]]。
16. **适用条件：黑暗游侠（启用）；杀手眼镜蛇（启用）。** 在 [[spell:19574]] 期间施放 [[spell:193455]]，除非 [[spell:217200]] 快要达到2层充能。
17. **适用条件：黑暗游侠（启用）。** 施放 [[spell:466930]]。
18. **适用条件：黑暗游侠（启用）。** 施放 [[spell:217200]]，冷却好就用。
19. **适用条件：黑暗游侠（启用）。** 施放 [[spell:193455]]，除非 [[spell:19574]] 距离冷却完毕不到一个全局冷却时间。

### AOE循环

**适用条件：黑暗游侠（启用）。** 1.3.

#### **适用条件：黑暗游侠（启用）。** 野兽控制 猎人 AOE起手式

**适用条件：黑暗游侠（启用）。** 确保 [[spell:257284]] 在你的主目标身上生效。

**适用条件：黑暗游侠（启用）。**

---

**适用条件：黑暗游侠（启用）。**

[[spell:466930]]

[[item:241288]]

[[spell:19574]]

**适用条件：狂野鞭笞（启用）。**

[[spell:1264359]]

[[spell:34026]]

[[spell:217200]]

[[spell:34026]]

[[spell:466930]]

[[spell:34026]]

**适用条件：黑暗游侠（启用）。**

---

1. **适用条件：黑暗游侠（启用）。** [[spell:466930]]
2. **适用条件：黑暗游侠（启用）。** 使用你的药水、主动饰品、种族技能等。
3. **适用条件：黑暗游侠（启用）。** [[spell:19574]]，如果前一个 [[spell:466930]] 激活了 [[spell:115939]]。如果没有，则先施放 [[spell:1264359]]。
4. **适用条件：黑暗游侠（启用）；狂野鞭笞（启用）。** [[spell:1264359]]
5. **适用条件：黑暗游侠（启用）。** [[spell:34026]]
6. **适用条件：黑暗游侠（启用）。** [[spell:217200]]
7. **适用条件：黑暗游侠（启用）。** [[spell:34026]]
8. **适用条件：黑暗游侠（启用）。** [[spell:466930]]
9. **适用条件：黑暗游侠（启用）。** [[spell:34026]]
10. **适用条件：黑暗游侠（启用）。** 继续按照下面描述的优先级列表进行。

**适用条件：猎群领袖（启用）。** 1.4.

#### **适用条件：猎群领袖（启用）。** 大秘境AoE起手手法 野兽控制 猎人

**适用条件：猎群领袖（启用）。** 确保 [[spell:257284]] 在你的主目标身上生效。

**适用条件：猎群领袖（启用）。** 在大秘境的AoE起手时，我们要在开怪瞬间几乎立刻按下 [[spell:1264359]]，同时确保我们的宠物不会拉到过多仇恨。然后我们进入常规基础循环，直到 [[spell:1264359]] 距离冷却结束大约还有1.5秒（1个公共冷却）。届时我们 [[spell:19574]] 接 [[spell:1264359]]，打出持续2秒的爆发性AoE伤害。这应该发生在开怪前几秒使用的 [[item:271886]] 药水效果持续到一半左右的时候。具体提前使用药水的时机取决于拉怪聚集所需的时间，但在实际操作中，跑到怪堆路上时喝药水就可以了。

**适用条件：猎群领袖（启用）。**

---

**适用条件：猎群领袖（启用）。**

[[item:271886]]

6s

拉怪

**适用条件：狂野鞭笞（启用）。**

[[spell:1264359]]

[[spell:217200]]

[[spell:34026]]

[[spell:193455]]

[[spell:34026]]

[[spell:19574]]

**适用条件：狂野鞭笞（启用）。**

[[spell:1264359]]

**适用条件：猎群领袖（启用）。**

---

1. **适用条件：猎群领袖（启用）；狂野鞭笞（启用）。** [[spell:1264359]]
2. **适用条件：猎群领袖（启用）。** [[spell:217200]]
3. **适用条件：猎群领袖（启用）。** [[spell:34026]]
4. **适用条件：猎群领袖（启用）。** [[spell:193455]]
5. **适用条件：猎群领袖（启用）。** [[spell:34026]]
6. **适用条件：猎群领袖（启用）。** [[spell:19574]]
7. **适用条件：猎群领袖（启用）；狂野鞭笞（启用）。** [[spell:1264359]]
8. **适用条件：猎群领袖（启用）。** 继续按照下面描述的优先级列表进行。

**适用条件：猎群领袖（启用）。** 1.5.

#### **适用条件：猎群领袖（启用）。** 团队副本AoE起手手法 野兽控制 猎人

**适用条件：猎群领袖（启用）。** 在团队副本战斗中有开怪倒计时，而且不需要提前聚怪就能正常爆发，所以我们正常起手，在 [[spell:1264359]] 之前立刻使用药水。

**适用条件：猎群领袖（启用）。**

---

**适用条件：猎群领袖（启用）。**

[[spell:217200]]

[[spell:217200]]

[[item:241288]]

**适用条件：狂野鞭笞（启用）。**

[[spell:1264359]]

[[spell:19574]]

[[spell:34026]]

[[spell:193455]]

[[spell:34026]]

**适用条件：猎群领袖（启用）。**

---

1. **适用条件：猎群领袖（启用）。** [[spell:217200]]
2. **适用条件：猎群领袖（启用）。** [[spell:217200]]
3. **适用条件：猎群领袖（启用）。** 使用你的药水、主动饰品、种族技能等。
4. **适用条件：猎群领袖（启用）；狂野鞭笞（启用）。** [[spell:1264359]]
5. **适用条件：猎群领袖（启用）。** [[spell:19574]]
6. **适用条件：猎群领袖（启用）。** [[spell:34026]]
7. **适用条件：猎群领袖（启用）。** [[spell:193455]]
8. **适用条件：猎群领袖（启用）。** [[spell:34026]]
9. **适用条件：猎群领袖（启用）。** 继续按照下面描述的优先级列表进行。

1.6.

#### AoE优先级列表 野兽控制 猎人

以下是描述 野兽控制 猎人 最优AoE循环的优先级系统。

1. **适用条件：猎群领袖（启用）；狂野鞭笞（启用）；Beast Cleave（启用）。** 在 [[spell:19574]] 之后立刻施放 [[spell:1264359]]，或在 [[spell:115939]] 未激活时的任何时候使用。
2. **适用条件：猎群领袖（启用）。** 如果 [[spell:217200]] 即将达到2层充能时使用。
3. **适用条件：猎群领袖（启用）；狂野鞭笞（启用）。** 在 [[spell:115939]] 激活期间，卡冷却时间使用 [[spell:19574]]。
4. **适用条件：猎群领袖（启用）；狂野鞭笞（未启用）。** 施放 [[spell:19574]]，冷却好就用。
5. **适用条件：猎群领袖（启用）；狂野鞭笞（启用）。** 卡冷却时间使用 [[spell:1264359]]，但如果 [[spell:19574]] 在 [[spell:115939]] 失效前就绪，则先保留。
6. **适用条件：猎群领袖（启用）；Master Handler（启用）。** 卡冷却时间使用 [[spell:34026]]，在4个或更多目标时或 [[spell:471876]] 就绪时忽略 [[spell:1273145]]。
7. **适用条件：猎群领袖（启用）；Master Handler（未启用）。** 在拥有 [[spell:1273145]] 增益效果时施放 [[spell:34026]]。
8. **适用条件：猎群领袖（启用）；猎人 野兽控制 12.1职业套装4件套（启用）；Beast Cleave（启用）。** 在 [[spell:1299389]] 和 [[spell:115939]] 同时激活时施放 [[spell:193455]]。
9. **适用条件：猎群领袖（启用）。** 施放 [[spell:217200]]，冷却好就用。
10. **适用条件：猎群领袖（启用）；狂野鞭笞（启用）。** 施放 [[spell:193455]]，除非 [[spell:1264359]] 距离冷却结束不到一个公共冷却。
11. **适用条件：猎群领袖（启用）；狂野鞭笞（未启用）。** 施放 [[spell:193455]]。
12. **适用条件：黑暗游侠（启用）；Beast Cleave（启用）。** 当 [[spell:115939]] 即将失效且 [[spell:19574]] 即将冷却就绪时施放 [[spell:466930]]。如果命中3个或更多目标，将获得 [[spell:115939]]。
13. **适用条件：黑暗游侠（启用）；Beast Cleave（未启用）。** 在 [[spell:19574]] 即将冷却就绪时，对3个或更多目标施放 [[spell:466930]]。
14. **适用条件：黑暗游侠（启用）；Beast Cleave（启用）。** 在 [[spell:115939]] 激活期间施放 [[spell:19574]]。
15. **适用条件：黑暗游侠（启用）；Beast Cleave（未启用）。** 施放 [[spell:19574]]，冷却好就用。
16. **适用条件：黑暗游侠（启用）；狂野鞭笞（启用）；Beast Cleave（启用）。** 在 [[spell:19574]] 之后立刻施放 [[spell:1264359]]，或在 [[spell:115939]] 未激活时的任何时候使用。否则，如果 [[spell:19574]] 在 [[spell:115939]] 失效前就绪，则先保留。
17. **适用条件：黑暗游侠（启用）；狂野鞭笞（启用）；Beast Cleave（未启用）。** 卡冷却时间使用 [[spell:1264359]]。
18. **适用条件：黑暗游侠（启用）。** 在拥有 [[spell:1273145]] 增益效果时施放 [[spell:34026]]，但如果 [[spell:19574]] 在5秒内出现，则保留一层充能。
19. **适用条件：黑暗游侠（启用）。** 如果 [[spell:217200]] 即将达到2层充能时使用。
20. **适用条件：黑暗游侠（启用）。** 在 [[spell:430715]] 期间施放 [[spell:466930]]。
21. **适用条件：黑暗游侠（启用）。** 在 [[spell:430715]] 距离失效不到一个公共冷却时施放 [[spell:392060]]。
22. **适用条件：黑暗游侠（启用）。** 施放 [[spell:217200]]。
23. **适用条件：黑暗游侠（启用）。** 施放 [[spell:466930]]。
24. **适用条件：黑暗游侠（启用）。** 施放 [[spell:392060]]。
25. **适用条件：黑暗游侠（启用）。** 施放 [[spell:193455]]。
26.

### 至暗之夜 第2赛季套装

至暗之夜 第2赛季职业套装确实会影响我们的循环。2件套使

[[spell:217200]] 额外触发一次效果为50%的 [[spell:199530]]。

4件套使每次 [[spell:199530]] 增加一层 [[spell:1299389]]，最多4

层。

在单体目标下每层提供20%额外的 眼镜蛇射击 伤害，并且在

[[spell:115939]] 激活期间，该 眼镜蛇射击 转而受益于Beast Cleave

效果为30%。

当你拥有3层 [[spell:217200]] 时，在 [[spell:193455]] 之前使用

使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖，或在拥有4层时 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠.

1.

### 职业与专精机制详解

为了更好地说明野兽的具体用法和好处

专精 猎人 技能体系的具体用法和优势，我们整理了关于循环各个

部分的更详细说明，从你需要关注的

重要循环机制，到冷却技能及其使用方式，让你能够充分发挥

游玩 野兽控制 猎人 的全部潜力。

### [[spell:201430]]

3.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 Stampede

当游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 野兽控制 猎人，你的第一个

在每次 [[spell:19574]] 之后施放的 [[spell:34026]] 将生成一个

Stampede，一条约30码长冲向目标的野兽"直线"。它

在7秒内对其中所有敌人造成大量伤害。瞄准和定位

在许多情况下是关键。首先，你应该调整角色站位，使

这条直线不仅穿过怪物当前所在位置，如果它们

在移动， **还要穿过你认为它们可能去往的位置**。这对于

充分利用

Stampede至关重要。把它想象成你用画笔挥出一笔，

刷怪，你需要用这个单体刷怪覆盖尽可能多的小怪

怪物。

### 巅峰天赋

3.2.

#### 自然盟友巅峰天赋

我们巅峰天赋的最后一个节点确实有一些你应该

了解的循环机制。它鼓励你绝不要连续施放两个 [[spell:34026]]，

相反，你应该始终尝试在两者之间穿插另一个技能，

以最大化该30%增益效果的覆盖时间。

除此之外，[[spell:1273145]] 的初始层数会

使 [[spell:19574]] 造成可观的伤害。这不会改变

我们的循环优先级，但值得了解。

1.

### 野兽控制 猎人 重要冷却技能

### [[spell:19574]]

4.1.

#### 狂野怒火

[[spell:19574]] 是我们唯一的冷却技能。它有30秒冷却时间，

15秒持续时间，是我们许多英雄天赋

机制的载体。

它本身就造成大量伤害，并在持续期间将你所有伤害提高20%。

持续时间。除此之外，像 [[spell:199532]] 这样的多个天赋，

[[spell:1232739]]、[[spell:321530]]、[[spell:459693]] 和

[[spell:193532]] 等多个天赋还能进一步放大它。

你绝大部分伤害都是在这些 [[spell:19574]] 窗口期内打出的。

4.2.

#### 狂野怒火对英雄天赋的影响

对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖中，[[spell:19574]] 会激活你的

[[spell:471876]]，使你的下一个 [[spell:34026]] 召唤

一只野兽。此外，你 [[spell:19574]] 内的第一个 杀戮命令 也会

发射一个 [[spell:201430]]。这是一条约30码长冲向目标的野兽"直线"，

冲向你目标的野兽，并且在你按下杀戮命令时被放置

放置。

因为这个效果是在你施放第一个

[[spell:34026]]（在[[spell:19574]]期间）时放置的且不会移动，并且因为

它是一条从你的角色位置出发的长直线，

瞄准和定位这条直线至关重要，尤其是在AoE情况下。

你要让Stampede覆盖尽可能多的

目标，并尽可能长时间地覆盖。

对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠中，[[spell:19574]] 按钮会给你一个

[[spell:466930]] 触发，激活后变为 [[spell:392060]]。

你可以使用一次哀恸箭，它造成大量伤害并给你一个

[[spell:466930]]触发。我们想在[[spell:430715]]时使用它

增益（即

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 终极天赋）即将结束时，偷放另一个

[[spell:466930]]进入该窗口。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月7日：** 将猎群领袖的群体起手式拆分为大秘境和团队副本版本。
- **2026年8月24日：** 狂野鞭笞现在是猎群领袖群体起手式的第一施放技能，也是其优先列表的首位，排在倒刺射击之前。野性狂乱召唤的巅峰宠物会在1.5秒后施放它自己的野性狂乱，且不会继承之前已激活的兽群撕裂效果，因此狂野鞭笞必须在野性狂乱之后使用，那次攻击才能产生顺劈效果。
- **2026年8月24日：** 添加了当野性狂乱在兽群撕裂消失前就绪时保留狂野鞭笞的说明。
- **2026年8月15日：** 根据4件套增益更新了套装部分。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 将凶暴冲锋的长度修正为30码。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026 年 5 月 21 日：** 简化了倒刺射击在猎群领袖单体目标中的优先级细节，因为经过测试发现围绕集中值水平进行操作并不是一个稳定的DPS提升，不值得费心去跟踪。
- **2026年4月29日：** 在黑暗游侠的AOE中，添加了说明：如果黑箭在凶暴野兽/野性呼唤（Bestial Wrath）之前处于冷却状态，则黑箭是激活兽群撕咬的最高优先级。
- **2026年4月28日：** 更新了哀恸之箭使用的措辞，澄清了即使你不小心错过了最佳时机，在每次野性呼唤期间使用它都是值得的。
- **2026年4月27日：** 循环更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月10日：** 更新了猎群领袖的输出循环。
- **2026年4月5日：** 略微更新了野兽控制黑暗游侠的输出循环和起手式。
- **2026年4月4日：** 在起手式中加入了谜题盒。
- **2026年4月2日：** 黑暗游侠的AOE循环小幅更新。
- **2026年3月31日：** 对兽王黑暗游侠的AOE起手式进行了小幅更新。
- **2026年3月24日：** 更新了黑暗游侠的输出循环。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026 年 2 月 11 日：** 黑暗游侠起手式更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 澄清了黑暗游侠的最佳药水和棱镜使用时机。
- **2025年9月22日：** 扩展了兽王黑暗游侠多目标上DOT的价值，并澄清了这其实并没有那么难做到，伙计们。
- **2025年9月21日：** 黑暗游侠的AOE循环更新，涉及倒刺射击和杀戮命令的优先级。
- **2025年9月17日：** 黑暗游侠循环小幅更新。
- **2025年9月12日：** 大幅更新/简化了单体目标中倒刺射击的使用方式。
- **2025年9月10日：** 循环更新，发现在使用野性呼唤时不要过于激进可以获得小幅收益。单体目标天赋构筑也根据这种打法进行了更新。
- **2025年9月9日：** 黑暗游侠的进一步循环更新。
- **2025年9月8日：** 为黑暗游侠添加了关于倒刺射击、野性呼唤和饰品使用的小型极致优化。
- **2025年9月6日：** 更新了黑暗游侠的起手，并将黑暗游侠单体目标方案设为默认显示；不过，在9月9日之前不应使用该方案。
- **2025年8月31日：** 起手式更新以及关于双重兽群奔袭/野性呼唤保留的澄清。
- **2025年8月17日：** 循环更新和澄清。
- **2025年8月16日：** 添加了关于保留野性呼唤以获取DPS收益的信息。
- **2025年8月8日：** 添加了关于在带头冲锋期间配合4件套效果保留杀戮命令以施放嚎兽的说明。
- **2025年8月5日：** AOE循环和起手式变更。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月20日：** 在单体目标循环中添加了一个约提升+0.3% DPS的小型循环极致优化。
- **2025年4月29日：** 将倒刺射击助手放在了更显眼的位置。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月18日：** 更新了新天赋的循环默认设置。
- **2025年3月14日：** 单体目标起手变更。
- **2025年3月9日：** 大幅重写并简化了循环。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年11月4日：** 移除了为狂野怒火保留的枯萎火焰。
- **2024 年 10 月 30 日：** 倒刺射击的AOE优先级小幅调整。
- **2024年10月25日：** 对两个循环进行了小幅更新。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年10月8日：** 更新了默认天赋选择。
- **2024年10月2日：** 新增了更具体的饰品使用信息。
- **2024年9月10日：** 对黑暗游侠单体目标起手进行了小幅更新。
- **2024年9月9日：** 单体目标起手更新。
- **2024年8月30日：** 为第1赛季准备的初步更新。
- **2024年8月26日：** 根据Yanix的APL更新，更新了单体目标循环中的夺命射击优先级，+0.5% DPS。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年8月1日：** 简化了凶暴野兽的循环使用。起手进行了小幅调整。
- **2024年7月24日：** 根据最新的APL更新更新了循环和起手。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。

显示更多

显示更少

:::

## 装备选择

在本页面，你将找到《魔兽世界》12.1.5版本中野兽控制猎人的最佳装备、饰品和毕业配装推荐。从制造装备到如何使用你的纹章来升级装备的建议，我们一应俱全！

1.

### 野兽控制猎人毕业配装指南

欢迎来到我们为野兽控制猎人准备的装备与毕业配装页面，适用于

至暗之夜第2赛季。查看本页面，了解你需要知道的

关于为野兽控制猎人配装的一切，包括毕业

配装（来自所有渠道）、团队副本和大秘境，以及最佳饰品、套装

等信息，更多内容。

至暗之夜资料片带来了大规模的属性压缩，降低了

游戏中几乎所有内容的属性和数值，包括物品等级和装备

上的属性。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统

让你

沿着与获取物品来源相关的轨道提升装备物品等级，

物品，更难的内容掉落的装备可以升级到更高的物品

等级。

欲了解更多信息，请阅读我们专门介绍

[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 如何运作以及

在 至暗之夜 资料片中有什么变化的专页。

### 总体

本列表包含至暗之夜第2赛季每个部位的最佳装备，来自所有渠道。

有许多不同的配装方案在误差范围内表现相当。本方案尽可能选择团队副本装备，因为它们比碰运气从 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)获取正确的秘境装备更容易获得。当没有同样强力的团队副本替代品时，才会选择秘境装备。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题：我在转化器中使用哪些物品？
转化器现在会保留你所转化物品的副属性和任何被动效果，因此放入的物品比使用哪个部位来完成套装更重要。你最需要的是精通，其次是单体用急速或大秘境用暴击。

不要因此拖延套装效果。没有4件套的两周代价远高于稍微错误的副属性，而且你可以在本赛季晚些时候转化一件更好的装备。

以下是最佳的转化物品：

- 头盔：[[item:268230@JAACAAgNyA]]，来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- 肩膀：[[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 胸甲：[[item:271876@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手套：[[item:281238@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 腿部：[[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 常见问题：从宏伟宝库中获取什么？
选择 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 几乎每周都如此。例外情况是当宝库提供了你从某个首领或地下城想要的最后一件装备时，因为在那里拿取意味着你再也不需要对那个渠道使用额外拾取。

虚空核心可以对一个团队副本首领或一个大秘境地下城进行额外拾取，并给你一件你之前从未从中拾取过的物品。英雄难度团队副本首领和大秘境提供1/6神话，史诗团队副本首领提供6/6神话，后期首领提供9/6。

有两点使其比看起来更强大。物品等级在你使用虚空核心时决定，而非在你拾取时决定，因此你可以保留一个直到你遇到值得使用的史诗首领。而且从宝库取出的装备仍留在额外拾取池中，所以一件你本来就要替换的装备可能会在之后浪费你一次拾取。

值得用骰子的Boss列在本页下方的“虚无核心”部分。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268207@JAAEAAAG2wYN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

本列表包含至暗之夜第2赛季每个部位的最佳装备，来自至暗之夜第2赛季大秘境。这适用于不打算过多参与团队副本内容的玩家。

有许多不同的配装方案在误差范围内表现相当。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题：我在转化器中使用哪些物品？
转化器现在会保留你所转化物品的副属性和任何被动效果，因此放入的物品比使用哪个部位来完成套装更重要。你最需要的是精通，其次是单体用急速或大秘境用暴击。

不要因此拖延套装效果。没有4件套的两周代价远高于稍微错误的副属性，而且你可以在本赛季晚些时候转化一件更好的装备。

以下是最佳的地下城掉落用于转化：

- 头盔：[[item:159374@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 肩膀：[[item:251131@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 胸甲：[[item:158355@JAACAAgNyA]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 手套：[[item:193752@JAAKAAQkCYHKvbRLfYjM]]，来自 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- 腿部：[[item:159375@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你游戏时间有限，我们建议刷以下地下城：

- [夺目谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：毕业饰品
- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：毕业靴子和戒指
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：毕业武器、披风和戒指
- [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)：毕业饰品
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：毕业项链

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271493@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271490@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271491@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271495@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271680@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

本列表包含至暗之夜第2赛季每个部位的最佳装备，来自至暗之夜第2赛季团队副本。它与我们的总体毕业列表非常相似，因为该列表也偏向于团队副本装备，但在这种情况下，完全不包含任何秘境装备。

有许多不同的配装方案在误差范围内表现相当。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题：我在转化器中使用哪些物品？
转化器现在会保留你所转化物品的副属性和任何被动效果，因此放入的物品比使用哪个部位来完成套装更重要。你最需要的是精通，其次是单体用急速或大秘境用暴击。

不要因此拖延套装效果。没有4件套的两周代价远高于稍微错误的副属性，而且你可以在本赛季晚些时候转化一件更好的装备。

以下是最佳的团队副本掉落用于转化。如果你也打秘境，秘境装备可以胜过其中任何一件：

- 头盔：[[item:268230@JAACAAgNyA]]，来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- 肩膀：[[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 胸甲：[[item:271876@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手套：[[item:281238@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 腿部：[[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团长提交一份高优先级装备列表，或只是想专注于最重要的首领和装备，我们已为你准备好！

- [[item:268207]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业武器，以及剧毒诅咒。
- [[item:268265]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业项链，以及剧毒诅咒。大多数专精都需要它，所以请做好竞争准备。
- [[item:281215]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业饰品。
- [[item:270175]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业饰品。
- [[item:281238]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业手套。
- [[item:281029]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业戒指。
- [[item:268252]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)：毕业戒指。
- [[item:268249]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)：总体列表上的毕业戒指。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268207@JAAEAAAG2wYN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 野兽控制猎人饰品推荐

我们在饰品选择上相当灵活。

[[item:281215]]搭配[[item:270175]]是

我们的最佳配置，不过。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **野兽控制猎人饰品**
**最佳——**

[[item:281215]]

- 

[[item:270175]]

:::

还有许多其他有价值的饰品，所以请务必

点击我们的排名图表，看看它们是否值得装备。请注意，你

不希望拥有超过1个使用型饰品。你几乎可以将

“使用时触发”的饰品被单独排名，与其他饰品区分开来。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看野兽控制猎人饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]：使用型</li>&#10;<li>[[item:281215]]</li>&#10;<li>[[item:159617]]：使用型</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:250215]]：使用型</li>&#10;<li>[[item:273796]]：使用型</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:250225]]：使用型</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797]]：使用型</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:241340]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:158374]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]：使用型。由于其巨大的爆发伤害，通常表现优于其模拟数值，如果放置得当，可以胜过其他饰品。想想伤害增幅、优先目标等等。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

- [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 是一种新的货币，可用于对某些
  
  
  
  
  在特定地下城和物品上使用“骰子”。使用后将会 **保证** 掉落
  
  
  
  
  来自该渠道，但你获得的装备是随机的。不过，你会受到
  
  
  
  
  保护免于重复。在一个首领或地下城上使用足够多次，你就
  
  
  
  
  **保证** 获得你想要的装备。

你通过 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 获得它们，通过拒绝物品奖励，这

需要从任何渠道解锁三个奖励槽（甚至1层地下堡！）。通过

补丁12.1.5上线时，你还能从奥林处免费获得一个额外的虚空核心

斯特拉维尔，他可以在银月城的转化器旁边找到。

3.1.

#### 野兽控制 猎人的推荐朦胧虚空核心用法

显然，这个问题的直接答案就是使用

虚空核心来升级你尚未获得的最佳装备。这取决于

你的角色，但我们会为你列出一些最重要的物品

野兽控制 猎人来说最重要的装备，目标是你可以直接沿着

列表往下看，追逐你看到的第一个你还没有的装备。

为一个你可能从即将到来的团本首领处获得的装备进行额外拾取可能是个坏

主意，这取决于你如何看待“现在的战力”与“以后的战力”。

总的来说，你最好的选择是进行 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 在 **英雄难度**。它有几件高影响力的毕业装备，所以即使你没有

立刻拾取到你的毕业武器，你仍然会获得良好的价值。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 用于[[item:268207]]，
   
   
   
   
   [[item:271876]]、[[item:268265]]和
   
   
   
   
   [[item:270175]]
2. [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 用于[[item:281238]]，
   
   
   
   
   [[item:281215]]和[[item:281029]]
3. 此时，赛季已经过去很多周了，你的装备将会
   
   
   
   
   参差不齐。我们建议使用
   
   
   
   
   [Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>)
   
   
   
   
   来模拟你的最佳额外拾取。

:::

3.2.

#### 晋升毒液石

[[item:280562]]是一种新的升级货币，随着

补丁12.1.5一同到来。每次升级花费10个，它们只能用于你的武器、你的

饰品和项链，让你将这些装备升级到340物品等级。只有

完全升级的英雄级或史诗级装备，或最高

品质的制造装备，才能用它们升级。使用它们的优先级与

你的纹章类似：

1. 你的武器是最高优先级。
2. 你的饰品。
3. 你的项链。

用其他你不常用的史诗级装备来填充。例外

是你不指望在短期内获得史诗级的装备。如果

你没有在史诗难度击杀 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)，那么升级一件英雄级的

[[item:281215]]是没问题的，例如。

1.

### 野兽控制 猎人的最佳制造装备

你可以拥有两个装饰，它们是来自

制造装备的特殊效果。先制造哪一个取决于你有多看重赛季

开局几周的战力。

制造一件像[[item:265337]]这样的武器，使用

[[item:273060]]和暴击/精通，是一次出色的

短期战力提升。缺点是即使你制造了它，你最好的额外拾取

目标仍然很可能是英雄难度的 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)，它有相当大的

几率给你一件史诗级的[[item:268207]]，这将会

最终让你的制造武器变得过时。

另一种选择是制造你真正的毕业装备，即

[[item:244581]]和[[item:244584]]，使用

[[item:240167]]和暴击/精通。如果你非常不走运，没有在

合理的时间内额外拾取到一件史诗武器，你可能会后悔这个选择，因为你将会

被卡在321物品等级的武器上好几周。

护甲套装是更好的长期选择，因为它是你真正的毕业装备，

而制造武器迟早会被一件史诗级掉落所取代。

如果你想要在第一周就获得战力，先制造武器仍然是一个真正的选择，

在第一周。

制造[[item:244582]]是一个很好的短期护甲

制造选择，如果你永远不会在史诗难度击杀 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

以获得344腿甲，那它就是永久选择。

:::details **野兽控制 猎人制造部位优先级**
**武器 → 项链/戒指 → 其他所有部位 → 披风/护腕**

:::

理想情况下，你应该模拟你的特定角色的

最佳属性，但暴击/精通很可能是你的最佳选择，使用

[[item:245789]].

有关制造装备的更多信息，你可以访问我们的

[专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 为装备添加插槽

头盔、腰带和护腕可以掉落带有插槽的，你也可以自己添加一个

使用[[item:275707]]。它花费六个

[[item:258556]]，这是 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 为通关奖励给你的货币。

只要你解锁了三个奖励栏位，你就可以直接获得六个。

奖励栏位解锁。

把它们留给你不打算更换的装备，比如史诗级装备或你的

两个制造部位，因为制造的腰带或护腕无法通过其他

方式获得插槽。

1.

### 纹章使用

你将能够通过徽章升级你的物品，例如

[秘境雾崖](<https://www.wowhead.com/currency=3446>)。一旦你将某个部位升级到特定物品等级，

**将该栏位的其他物品升级到该物品等级就是免费的**.

当你使用纹章升级时，你应该将其视为升级

**插槽** 而不是物品。

由于纹章是有限的资源，你希望在升级某个部位时获得

尽可能高的物品等级 **之前** ，因为这样

意味着你在该部位总共花费的纹章会更少。如果你完全

有能力打一个+10地下城，例如，那么去升级

一个+9地下城的装备将是一个非常糟糕的主意，因为你刚刚浪费了20个纹章，这些纹章本可以

通过在+10刷该部位来节省下来。

我们看到大量玩家，即使在高水平，也搞错了他们的升级

优先级并过早升级。做对这一点会让你远远领先于

大多数玩家。

以下是你应该升级装备的部位优先级。如果你想要

偏离这一点，你应该有一个非常好的理由。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **野兽控制 猎人纹章升级优先级**
**武器**

→

**饰品**

→

**头盔/胸甲/腿甲**

→

**肩部/手套/腰带/靴子**

→

**戒指/项链**

→

**披风/护腕**

:::

请注意，例外是可能的，例如某些特殊装备的物品等级成长

高于其部位所暗示的。

1.

### 评估升级

在本页及我们指南的其他地方，我们经常提到

在Raidbots上模拟自己的重要性。这是因为每个角色都是

独特的，你所拥有的每一件装备都可能改变什么是最好的

现在为你。

虽然我们确实为装备和饰品提供建议，但这些并非完整的

替代品来自模拟你自己。真正优化你角色的唯一方法

达到那种程度的方法就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年9月30日：** 修复了胸甲工具提示显示两个毒咒效果的问题。
- **2026年9月30日：** 在饰品排名中将共鸣咆哮石提升至B级，将瓦什尼克的血腥怨恨和虚空处决指令降至C级，将黎明之根的树苗降至D级。
- **2026年9月4日：** 将总体毕业清单饰品更新为守护者沸腾核心。
- **2026年9月4日：** 在饰品排名中将毒怒之泉提升至S级。
- **2026年8月31日：** 将总体毕业清单更新为永恒尖牙之冠和龙响护手。
- **2026年8月31日：** 将大秘境毕业清单的武器更新为罪灼连弩，戒指更新为充能砂岩指环。
- **2026年8月31日：** 将团队副本毕业清单的靴子更新为无畏旅者的靴子，戒指更新为巅峰蛮勇者的爪击之戒。
- **2026年8月24日：** 将武器附魔更新为哈什之仪。
- **2026年8月22日：** 添加了关于制作护腿的说明。
- **2026年8月18日：** 将总体毕业清单的戒指和靴子更新为与大秘境配置一致，因为团队副本有足够的顺劈伤害，为单体配装没有意义。
- **2026年8月18日：** 在盖博的无底袋削弱后更新了虚空核心的额外掉落优先级。
- **2026年8月17日：** 更新了饰品梯队排行。
- **2026年8月16日：** 重做了制造建议，更正了团队副本物品列表中贪婪的 乌拉特克 之心和盖博的无底袋条目，并添加了赛季开始时的虚空核心和纹章建议。
- **2026年8月15日：** 根据最新的平衡调整更新了饰品梯队排行和团队副本毕业饰品。
- **2026年8月14日：** 将团队副本毕业手套更新为来自尼姆瑞莎·唤波者的催化漩涡狂怒之握。
- **2026年8月14日：** 更新了虚空核心的额外掉落优先级。
- **2026年8月12日：** 添加了催化剂和大秘库常见问题解答及插槽部分，修正了催化剂掉落位置，并更新了团队副本毕业头盔和手套的来源。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 添加了饰品速查表并澄清了制作指南。
- **2026年6月16日：** 修正了大秘境毕业装备列表中的靴子。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月8日：** 毕业装备列表和饰品层级列表更新。
- **2026年3月25日：** 更新了大秘境装备毕业列表。
- **2026 年 3 月 17 日：** 为至暗之夜第一赛季更新。
- **2026年3月4日：** 更新了终局内容的专业制造推荐。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年9月12日：** 更新了饰品层级列表和毕业装备列表。
- **2025年9月7日：** 更新了毕业戒指。
- **2025年9月6日：** 更新了毕业装备列表和饰品层级列表，以包含黑暗游侠的专属内容。
- **2025年9月2日：** 饰品层级列表和毕业装备更新。
- **2025年8月16日：** 根据调整更新了饰品层级列表。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月24日：** 基于对静电充能高估其实际表现的进一步分析，再次更新了泰坦圆盘推荐。
- **2025年6月23日：** 基于最新的在线修正更新了泰坦圆盘推荐。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月13日：** 更新了代币推荐的顺序。
- **2025年5月10日：** 略微更新了纸牌屋和印记的措辞/代币推荐状态。
- **2025年5月9日：** 更新了腐蚀附魔与谜之卡特尔芯片代币部分。
- **2025年4月21日：** 添加了可用代币购买的物品列表。
- **2025年3月29日：** 更新了大秘境饰品层级列表中克赞之眼的位置。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月17日：** 更新了关于即兴海克斯起搏器的措辞。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月17日：** 更新了关于瑟尔崔指环现在提升至物品等级658的内容。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月24日：** 更新了一件毕业戒指。
- **2024年9月13日：** 新增了关于双黎明之线衬里无效及其解决方法的说明。
- **2024年9月10日：** 精简了专业制造推荐，按团队副本和大秘境分类，并重新格式化。移除了免责声明。修复了毕业列表中的一些不一致之处。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月30日：** 为第1赛季准备的初步更新。
- **2024年8月27日：** 在赛季前毕业列表中新增了关于制造装备的说明。
- **2024年8月22日：** 已针对地心之战进行更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将了解你的野兽控制 猎人的最佳属性优先级。我们首先介绍属性优先级，然后深入探讨属性如何与你的专精和玩法互动的更复杂解释。我们的内容已针对《魔兽世界》12.1.5补丁更新。

1.

### 野兽控制 猎人属性优先级

猎人野兽控制的属性优先级分为纯

单体目标和大秘境两种情况，如下所示：

1.1.

#### 单体目标属性优先级

精通

急速

暴击

全能

在纯单体目标下，急速比暴击略好。然而，对于

综合用途而言，暴击比急速强得多。

1.2.

#### 大秘境属性优先级

精通

暴击

全能

急速

请记住，某项属性相对于其他属性越少，它

往往就越强。属性优先级是基于平衡所有属性并考察

各属性从设定起点起的成长强度，同时参考

该专精模拟得分最高的装备配置，以及分析是哪种属性优先级

达到了那个效果。

1.

### 深入属性解析

**敏捷** 是你的主属性。它为你提供攻击强度，

这决定了你所有技能造成的伤害。

**精通**，通过[[spell:76657]]，提高了

你自己以及在更大程度上，你召唤的所有宠物和生物的伤害。

这包括你的主要宠物、凶暴野兽等。

**急速** 提高你的攻击速度和集中值回复，

将你的公共冷却时间从1.5秒缩短至最低0.75秒，并缩短

你的[[spell:34026]]和[[spell:217200]]技能的冷却时间。

:::details 常见问题：猎人野兽控制有急速阈值吗？
野兽控制没有急速阈值。急速在AOE中完全无用，虽然在纯单体目标下它比暴击略好，但我们推荐暴击 → 急速作为通用全内容玩法的经验法则。

:::

**暴击** 提高你所有

法术和技能的暴击几率，使其造成双倍伤害。许多野兽控制

天赋依赖于暴击，包括但不限于

[[spell:459552]]和[[spell:392053]]。

**全能** 提高你造成的所有伤害和治疗，并降低

你受到的所有伤害。

2.1.

#### 属性递减收益

每项属性都有一个上限，超过该上限后，每点获得的提升

将开始减少；这些被称为收益递减点。一旦你

达到了

这些数值，属性将逐渐变得不那么有价值，并可能落后于

其他选择。当前的阈值如下：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 澄清了暴击与急速的经验法则。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 更新了80级的属性递减收益数值。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月10日：** 更新了黑暗游侠的属性优先级。
- **2025年9月7日：** 属性优先级措辞更新。
- **2025年9月6日：** 小幅更新了属性优先级并重新整理了页面。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 为猎群领袖新增了AOE和单体目标的独立属性优先级。
- **2024年8月30日：** 为第1赛季准备的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的猎人野兽控制所能获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你应该在一个插槽中使用[[item:240983]]，并在

其他所有插槽中使用[[item:240898]]。虽然还有其他

选择适用于

你的海精宝石以及稀有宝石，但这两者将为你提供

最高的

各类内容中的DPS收益。

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

你可以使用多种临时物品来提升你在地下城

和团队副本中的实力。

3.1.

#### 合剂

最好的药水通常是

[[item:241322]]。话虽如此，最好将合剂视为

另一件容易更换的装备，根据你的具体装备

情况，4种副属性合剂中的任何一种都可能是最优的。要真正做到极致优化

这一点，你需要进行模拟。

3.2.

#### 药水

你想要哪种DPS药水取决于你正在挑战的内容。

- [[item:241288]]是默认选择，提供大量
  
  
  
  
  你最高的副属性，持续30秒，应与你的爆发技能同步使用。
  
  
  
  
  请注意，该药水的效果取决于你最好的属性（精通）在
  
  
  
  
  你使用药水时是否确实是最高的。如果你在配装过程中的
  
  
  
  
  这一阶段并非如此，请改用[[item:241308]]。它也受益于
  
  
  
  
  你最低的属性（通常是全能）接近于0，因为
  
  
  
  
  这意味着你不会受到任何削减。
- [[item:271886]]是大秘境的选择，在开怪前使用预药水。
  
  
  
  
  它的全能属性会在持续时间内逐渐增加，因此当
  
  
  
  
  你的起手爆发在怪群聚拢后开始时效果最强。具体时机请参阅大秘境页面。
  
  
  
  
  确切的时机。

确保携带[[item:271883]]。

它有5分钟冷却时间，能恢复你大部分生命值；在万不得已时使用，

尽可能优先使用你的个人减伤技能。

3.3.

#### 食物增益

你能吃到的最佳食物来自

[[item:255846]]或[[item:255845]]盛宴。最佳

非盛宴食物是[[item:242747]]。"丰盛的"这部分很重要，因为

这种食物在死亡后仍然保留，我们强烈建议学习

[烹饪](<https://www.icy-veins.com/wow/professions-cooking>) 来轻松制作你自己的丰盛食物，因为它无法

可在拍卖行直接购买。

3.4.

#### 强化符文

在至暗之夜中，最佳强化符文是

[[item:259085]]，但每次使用可能非常昂贵

开怪或

每个地下城都使用可能非常昂贵，除非你财力雄厚，否则请节约使用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月15日：** 澄清了液体光泽是大秘境药水，而鲁莽药水在其他所有场合仍是首选。
- **2026年8月24日：** 将武器附魔更新为哈什之仪。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 更新了武器和靴子的附魔推荐，并修复了附魔工具提示链接。
- **2026年6月16日：** 澄清了武器附魔的选择。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月23日：** 更新了戒指附魔。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月9日：** 更新了腐蚀附魔部分。
- **2025年4月21日：** 添加了腐蚀附魔信息。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月30日：** 为第1赛季准备的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已为10.2.5版本进行更新。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月22日：** 更新了推荐的腿部附魔，因为发现微光护甲片并不像之前认为的那样提供耐力。
- **2023年5月13日：** 更新了推荐的食物和腿部附魔。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月23日：** 根据一系列热修复再次更新了推荐的宝石。
- **2023年3月23日：** 在模拟更新以及发现新的强力组合后，更新了推荐的宝石。
- **2023年3月21日：** 根据3月21日的增益更新了黑曜石指环信息。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年2月22日：** 更新并澄清了最佳宝石和附魔。
- **2023年2月20日：** 新增了关于可提升野兽控制猎人DPS的雕文信息。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了推荐的药剂。
- **2022年12月11日：** 更新了最佳药水/药剂的推荐和描述。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的猎人野兽控制挑战大秘境地下城的提示和建议。

1.

### 猎人野兽控制在至暗之夜第2赛季的大秘境

在本指南中，我们将讨论如何在大秘境中充分利用你的 猎人

大秘境地下城，包括如何最佳地配置你的角色、你的

循环可能会变化，以及在最

优方式使用技能的提示和技巧。

猎人野兽控制的伤害曲线非常"平滑"，

每次开怪和每个Boss的DPS大致相同。这使它

非常可靠，但缺乏某些其他专精所能达到的高爆发峰值。

它非常容易上手，且完全可移动施法，使其可能是整个游戏中

最适合"拿起就玩"的专精。

如果你不熟悉大秘境及其相关的一般机制，你可以

在我们下方专门的大秘境页面上阅读更多信息。

1.

### 最佳大秘境天赋配置

野兽控制 在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 大秘境中的猎群领袖。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠更耐打，但在所有情况下伤害都远远落后，

而且要打出最优输出也需要多得多的精力。我们为那些

更喜欢这种玩法的人提供了黑暗游侠构筑，但我们不推荐

你使用它。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 大秘境天赋

2.1.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖大秘境天赋构筑：野兽控制猎人

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 大秘境的猎群领袖构筑以及

以AOE为主的玩法中的最优配置。它基于对真实

大秘境地下城环境的模拟，不仅看哪种配置能打出最高的DPS，还看

在团队中哪种配置能更快地通关地下城。有些配置能打出更多

AOE伤害，但它们在单体目标上损失的输出远多于在AOE上获得的，

反之亦然。

2.2.

#### 猎人的野兽控制功能性天赋考量

并非所有功能性天赋都适用于每个地下城。我们创建这些

天赋配置时的假设是，你不会非常勤快地

按地下城逐个更换天赋。然而，我们的目标是确保你

不会因为缺少某个特定地下城的关键天赋而处于劣势。

这意味着我们偶尔会舍弃一些在特定情况下才有用的选择。

- 你的'灵活'天赋点，按我们建议的可舍弃顺序为：
  
  
  
  
  可牺牲的：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]]只在某些地下城中有用，
    
    
    
    
    在其他地下城中则毫无价值。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbAYWAbDAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AACCDEFGHQSUYacegikoqs0248+AHNB-AAAA-BCEGIUw4ARZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 大秘境天赋

2.3.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 大秘境天赋构筑，适用于 野兽控制 猎人

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 大秘境构筑，以及

以AOE为主的玩法中的最优配置。它基于对真实

大秘境地下城环境的模拟，不仅看哪种配置能打出最高的DPS，还看

在团队中哪种配置能更快地通关地下城。有些配置能打出更多

AOE伤害，但它们在单体目标上损失的输出远多于在AOE上获得的，

反之亦然。

2.4.

#### 猎人的野兽控制功能性天赋考量

并非所有功能性天赋都适用于每个地下城。我们创建这些

天赋配置时的假设是，你不会非常勤快地

按地下城逐个更换天赋。然而，我们的目标是确保你

不会因为缺少某个特定地下城的关键天赋而处于劣势。

这意味着我们偶尔会舍弃一些在特定情况下才有用的选择。

- 你的'灵活'天赋点，按我们建议的可舍弃顺序为：
  
  
  
  
  可牺牲的：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]]只在某些地下城中有用，
    
    
    
    
    在其他地下城中则毫无价值。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAYzsNwAGwMsFYsAAgZGzMziZYmZGMjZmZYGzMjZmZsNzMmxMsMmmBAAAAMDAAAegxYYmBEwsA2GAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AABDEFGHSUacegiqswyy024+AFHJLNB-AAAA-AGIcgow4ApyCTD-
```

:::

在开怪前约6秒使用药水 [[item:271886]]。它的精通

会随持续时间提升，所以提前嗑药意味着最后15秒与

你的开场 [[spell:19574]] 相吻合。实际上，只要在你跑向

开怪的路上嗑药就很好。

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断

[[spell:147362]] 是你的“打断”，也是你在

大秘境中最重要的功能性技能，用于打断敌人施法以造福团队，尤其是

坦克。它是 **强烈推荐** 使用焦点打断宏来完成此操作。

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 反制射击
```

这个宏会打断你的焦点目标（如果你有焦点目标），鼠标指向目标（如果你有

焦点目标），以及你的当前目标（如果两者都没有）。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用

**鼠标悬停设为焦点宏**.

```wow-macro
/focus [@mouseover]
```

确保你的界面能清晰显示焦点目标的施法，这样你

才能随时在冷却完毕时打断它，或与团队的其他成员配合

打断。

3.2.

#### 眩晕与"打断"

[[spell:19577]] 是你第二重要的功能性技能，是你的

单体“打断”，用于阻止那些通常无法被正常打断的施法。我们

建议以与你的反制射击相同的方式使用它，使用相同的宏

（当然，把反制射击换成胁迫）。配合一个天赋，它

也可以是一个群体打断。

[[spell:109248]] 可以在混乱时刻用来拯救你的坦克，通过

帮助他们风筝怪物并拉开距离。

[[spell:187650]] 可以作为额外的打断技能，与

[[spell:19577]] 一起使用，但它的弹道飞行时间较慢，你需要

靠近目标才能在大多数可眩晕的施法结束前命中它。

### 其他功能

3.3.

#### 其他功能

[[spell:5384]] 不仅可以用来脱离仇恨，还可以

使你身上的某些施法和引导失效。在某些情况下，这些机制只会

重新选择团队中的其他人，但偶尔该机制会被

完全消除，并带来巨大收益。如果你注意到有施法或效果作用于你，尝试

用 [[spell:5384]] 应对！点出 [[spell:459517]] 天赋后，它还会

移除你身上所有的中毒和疾病效果。

[[spell:19801]] 可以驱散敌方目标身上有益的激怒和魔法效果

，这经常很有用，而我们的构筑已经点出了

[[spell:459983]]。在某些地下城中，你可能会选择更换

你的默认天赋来获取 [[spell:109248]] 或 [[spell:199483]]。

[[spell:187698]] 可以通过减速怪物来帮助你的坦克风筝。

如果你的坦克死亡，条件反射般地放下一个 焦油陷阱 是很好的，因为它能

让其他人有更好的机会风筝并存活下来。

1.

### 应对词缀

本节包含 猎人 专属的应对各种词缀的技巧

大秘境的。

### 词缀：升腾

4.1.

#### 升腾词缀应对指南，适用于 野兽控制 猎人

对密集的球体群使用 [[spell:19577]] 等群体控制技能

以尽可能多地消灭它们。对于剩下的单个球体，你可以使用 [[spell:187650]] 和你的

打断剩下的单个目标。

### 词缀：虚缚

4.2.

#### 虚空束缚词缀应对指南，适用于 野兽控制 猎人

这里没什么特别要说的。利用你扎实的切换目标

能力，尽快集火击杀 虚空大使。

### 词缀：脉冲星

4.3.

#### 脉冲星词缀应对指南，适用于 野兽控制 猎人

开启 [[spell:186257]] 并利用你出色的机动性四处冲刺

以尽快拾取尽可能多的球体。

### 词缀：吞噬

4.4.

#### 吞噬词缀应对指南，适用于 野兽控制 猎人

[[spell:5384]] 的中毒/疾病驱散（通过 [[spell:459517]]）是

驱散移除 [[spell:440313]] 所需类型效果的来源。你也可以

用 [[spell:109304]] 治疗掉它，但那会消耗一个GCD。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年9月7日：** 添加了液体光泽的预饮药时机。
- **2026年8月15日：** 黑暗游侠的大秘境构筑现在选择杀戮顺劈而非锋利无比。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 更新了猎群领袖大秘境天赋构筑。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月3日：** 更新了猎群领袖的大秘境构筑。
- **2026 年 3 月 22 日：** 更新了两个大秘境构筑。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月22日：** 更新了黑暗游侠的大秘境构筑，将战争命令换成了野性呼唤以进一步平滑狂乱值的管理，获得约2.5%的AOE提升、约2%的优先目标提升，但在此过程中损失了约1%的单体目标伤害。
- **2025年9月17日：** 更新了大秘境英雄天赋推荐。
- **2025年9月13日：** 更新了兽王黑暗游侠的大秘境构筑。
- **2025年9月6日：** 略微更新了非多目标构筑与多目标构筑以及黑暗游侠的措辞。
- **2025年9月3日：** 非多目标构筑中进行了1点天赋的替换，损失0.2%伤害，但我相信这样玩起来手感好得多，且犯错空间更小。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月18日：** 更新了推荐的大秘境模拟路线/大秘境模拟Pastebin。
- **2025年3月17日：** 更新了大秘境推荐天赋构建。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月31日：** 更新了关于野兽控制黑暗游侠大秘境中可以灵活选择天赋的说明。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月25日：** 更新了英雄天赋推荐和信息。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年10月8日：** 更新了10月8日热修复后的天赋构建。
- **2024年9月27日：** 更新了阿拉卡拉提示。
- **2024年9月13日：** 更新并澄清了一些提示。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月30日：** 为地心之战第1赛季准备的初步更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5补丁中游玩你的 野兽控制 猎人 时更加轻松。

1.

### 最佳宏

1.1.

#### 猎人通用宏

1.1.1.

##### TankMD 插件 + 宏

这会自动为团队中的坦克施放误导，无需

选择目标或设置焦点或任何其他操作。安装插件，设置好宏，你就

万事大吉了。

1. 获取 [TankMD
   
   
   
   
   插件]([https://www.curseforge.com/wow/addons/tankmd](<https://www.curseforge.com/wow/addons/tankmd>)).
2. 设置这个宏：

#### TankMD 误导 宏

```wow-macro
#showtooltip 误导

/click TankMDButton1
```

1.1.2.

##### 焦点鼠标指向宏

严肃大秘境必备的宏。将你的鼠标指向目标设置为

焦点目标，并为其标记绿色标记（除非它已被

其他标记标记过），这样你就可以用下面的宏打断它。

#### 焦点鼠标指向宏

```wow-macro
/focus [@mouseover,harm,exists,nodead][@target,harm,exists,nodead]

/tm [@mouseover,harm,exists,nodead][@target,harm,exists,nodead] 4
```

1.1.3.

##### “自动打断/眩晕”宏

这个宏会自动对随机的正在施法的目标使用你的打断

，无需选择目标、鼠标指向或焦点。我们喜欢它用于

较低层/不协调的钥匙。看到施法？按下宏。第三个宏做同样的

事情，不过是针对 [[spell:19577]]。

#### 自动打断宏（反制射击）

```wow-macro
#showtooltip 反制射击

/cast [@focus,exists,nodead,harm] 反制射击

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast 反制射击

/target focus

/clearfocus

/startattack
```

#### 自动打断宏（口袭）

```wow-macro
#showtooltip 压制

/cast [@focus,exists,nodead,harm] 压制

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast 压制

/target focus

/clearfocus

/startattack
```

#### 自动眩晕宏（胁迫）

```wow-macro
#showtooltip 

/cast [@focus,exists,nodead,harm] 胁迫

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast 胁迫

/target focus

/clearfocus

/startattack
```

请注意，如果你设置了焦点目标，它会优先打断焦点目标。如果你希望

它优先选择鼠标悬停目标，只需将"focus"替换为"mouseover"即可。

1.1.4.

##### 逃脱停止施法宏

这个宏会打断像[[spell:56641]]这样的施法并强制执行

[[spell:781]]，但它不会取消像[[spell:257044]]或

[[spell:1261193]]这样你可以在中途[[spell:781]]的引导法术。

#### 逃脱停止施法宏

```wow-macro
#showtooltip 逃脱

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/use 逃脱
```

1.1.5.

##### 地面目标技能的光标宏

这些宏跳过了使用时的绿色目标圈放置步骤

我们将其用于从[[spell:1543]]到陷阱的所有技能

再到[[spell:109248]]和[[spell:260243]]。

只需将光标放在你想要的位置即可。

#### 光标宏（冰冻陷阱）

```wow-macro
#showtooltip

/use [@cursor]冰冻陷阱
```

#### 光标宏（焦油陷阱）

```wow-macro
#showtooltip

/use [@cursor]焦油陷阱
```

#### 光标宏（束缚射击）

```wow-macro
#showtooltip

/use [@cursor]束缚射击
```

#### 光标宏（乱射）

```wow-macro
#showtooltip

/use [@cursor]乱射
```

#### 光标宏（照明弹）

```wow-macro
#showtooltip

/use [@cursor]照明弹
```

1.1.6.

##### 宠物"重置"宏

当你从悬崖跳下且确实希望宠物跟随你时，这个宏非常有用。

宠物被动和宠物跟随可以让宠物更快地"瞬移"到你身边。

[[spell:1850]]这行确保你的宠物尽可能快地回到你身边。

怪物。

#### 宠物"重置"宏

```wow-macro
/petpassive

/petfollow

/use 急奔
```

1.1.7.

##### 宠物嘲讽宏

在大秘境中，有时在强力小怪释放坦克大招之前嘲讽它们很有用，

这可以帮助保住坦克的性命。你需要使用

甲虫、野猪、Carapid（仅野兽控制）、熔火犬（仅野兽控制）、机械、鳞蜥、

可选择页岩兽（仅限野兽控制）或海龟，因为它们拥有50%减伤，其冷却时间为1分钟

50%伤害减免。

#### 宠物嘲讽宏

```wow-macro
#showtooltip

/use [@mouseover,exists,harm][@focus,exists,harm]低吼

/use 鳞墙

/use Harden Carapace

/use Bristle

/use Bulwark

/use Obsidian Skin

/use Defense Matrix

/use Solid Shell

/use Shell Shield
```

1.1.8.

##### 鼠标悬停宁神射击

对鼠标悬停的敌人使用宁神射击，如果没有有效的悬停目标

则对当前目标使用。

#### 鼠标悬停宁神射击

```wow-macro
#showtooltip

/use [@mouseover,exists,harm,nodead][]宁神射击
```

1.1.9.

##### 灵龟守护取消光环宏

默认游戏中你可以再次按下灵龟守护来取消它，但

其中内置了一个"宽限"期。这个宏跳过宽限期，让你

可以立即激活然后取消灵龟守护。如果你是

那种狂按灵龟守护的玩家，请不要使用这个宏，此宏需要你

用一次按键来有意地激活/取消！

#### 灵龟守护取消光环宏

```wow-macro
#showtooltip 灵龟守护

/stopcasting

/stopcasting

/use 灵龟守护

/cancelaura 灵龟守护
```

1.1.10.

##### 鼠标悬停多重射击

主要用于射击，该专精希望对目标使用[[spell:2643]]

目标使用[[spell:257621]]来激活技巧射击，或者

分散其标记。它没有nochanneling条目，因为射击

专精会故意用[[spell:2643]]来截断[[spell:257044]]的末尾。

#### 鼠标悬停多重射击

```wow-macro
#showtooltip 多重射击

/use [@mouseover,exists,harm,nodead][]多重射击

/petattack

/petassist
```

1.2.

#### 野兽控制宏

我们建议将petassist宏写入野兽控制的进攻性技能中，以确保它

始终处于协助模式。我们还建议对那些强制宠物

开始攻击特定目标（[[spell:34026]]）或鼓励你

让宠物处于特定位置（[[spell:1264359]]，用于

[[spell:115939]]站位）的技能使用/petattack。

1.2.1.

##### 狂野怒火取消光环潜行宏

如果你从[[spell:19574]]起手，

在猎群领袖中使用[[spell:199483]]/[[spell:114018]]，可能会出现故障

导致你的[[spell:471876]]出错并无法生成，严重

影响你的DPS。这个宏可以确保这种情况不会发生。

#### 狂野怒火取消光环潜行宏

```wow-macro
#showtooltip

/cancelaura 潜伏帷幕

/cancelaura 伪装

/use 狂野怒火
```

1.2.2.

##### 黑蚀箭取消光环潜行宏 + 鼠标悬停

[[spell:466930]]和[[spell:378769]]触发时也会出现同样的问题。此外，

这个宏会优先对鼠标悬停的敌人使用[[spell:466930]]。

在很多情况下，你可以对次要目标[[spell:466930]]但无法

对主目标使用，这个宏对此至关重要。有时

由于站位限制，对当前目标以外的目标[[spell:466930]]也是最优选择，

位置限制，比如如果你的主要目标是优先目标，但是

当前处于AOE范围之外。nochanneling元素是射击专精的补充，

只是防止这个施法取消[[spell:257044]]。

#### 黑蚀箭取消光环潜行宏 + 鼠标悬停

```wow-macro
#showtooltip 黑蚀箭

/cancelaura 潜伏帷幕

/cancelaura 伪装

/stopmacro [channeling:Rapid Fire]

/use [@mouseover,exists,harm][]黑蚀箭
```

1.2.3.

##### 自动召唤宠物杀戮命令宏

如果你没有召唤宠物，这个宏会召唤/复活你的宠物，否则

它只是一个普通的[[spell:34026]]宏。设置Call Pet X的编号

到你默认使用的宠物上。当我们团队中使用嗜血时，我们进去并

修改

宏为嗜血宠物的编号，这样如果我们死在大秘境中并按下杀戮命令，它

就会召唤正确的宠物。省去了思考的麻烦。请注意，复活部分

在你的宠物单位实际不存在时并不100%可靠，这可能发生在

你尝试复活然后取消施法的情况下。因此，你仍然应该有

[[spell:982]]单独绑定。

#### 自动召唤宠物杀戮命令宏

```wow-macro
#showtooltip 杀戮命令

/petassist

/petattack

/cast [@pet,dead] 复活宠物;

/cast [@pet,noexists,mod:shift] 复活宠物; 

/cast [@pet,noexists] 召唤宠物 1;

/cast 杀戮命令
```

1.

### 最佳插件

2.1.

#### 猎人通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可能值得看看在没有任何额外插件的情况下你能走多远，也许你甚至会享受不必每个补丁都花数小时更新和重新配置界面的感觉。

2.2.

#### 用户界面

2.2.1.

##### EllesmereUI

[EllesmereUI](<https://www.curseforge.com/wow/addons/ellesmereui>)
是对默认用户界面的完整替换。它极其用户友好，设置和掌握所需时间非常少。它还已经配备了几乎你需要的一切：单位框体、团队框体、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，使你的界面完全按照你想要的样式呈现。EllesmereUI简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松追踪基础减益效果和在战斗中快速选择新目标至关重要。虽然一些界面替换自带姓名板，但它们通常功能有限且偶尔有故障。下面列出了一些不错的替代方案。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是由
[plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发的插件，该作者以众多超级有用的插件闻名，例如
[Auctionator](<https://www.curseforge.com/wow/addons/auctionator>),
[Baganator](<https://www.curseforge.com/wow/addons/baganator>),
[Chattynator](<https://www.curseforge.com/wow/addons/chattynator>)等等。他们现在已经开发了一款非常可定制的姓名板插件，提供了大量关于减益效果、状态颜色、图标、材质等的选项。它绝对值得一看，尤其是如果你因为任何原因在使用Plater时遇到问题的话。

2.5.

#### 伤害统计插件

2.5.1.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.6.

#### 野兽控制猎人专用插件

目前，我们认为没有必要使用额外的插件来玩

野兽控制 猎人的全部潜力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月4日：** 移除了倒刺射击鼠标悬停宏。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年12月4日：** 添加了野性呼唤与阿莱兹/棱镜的宏命令。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月30日：** 为第1赛季准备的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月11日：** 新增了一个宏，用于在你忘记或需要快速召唤宠物时提供帮助。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 新增了倒刺射击鼠标指向宏。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
