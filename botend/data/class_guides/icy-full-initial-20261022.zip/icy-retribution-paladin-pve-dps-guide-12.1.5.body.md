## 专精概览

欢迎来到我们为《魔兽世界》12.1.5 补丁编写的 惩戒 圣骑士 指南。在这里，你将学习如何在团队副本和 Mythic+ 地下城中扮演 惩戒 圣骑士：从入门到最大化你的 DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

惩戒 Mythic+ 资源

[新！顶级 惩戒 天赋构建](<https://raider.io/specs/retribution-paladin/talents>)

[顶级 惩戒 Mythic+ 玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/paladin/retribution>)

[惩戒 Mythic+ 热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=paladin--retribution>)

[热门 惩戒 队伍组合](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=paladin--retribution>)

1.

### 惩戒 圣骑士 概述

惩戒 是 圣骑士 的近战 DPS 专精。它可以使用 圣骑士 众所周知的各种实用工具，包括备受追捧的光环，以及一些非常强大的防御和治疗技能。由于其强大的职业幻想和优秀的全能实用工具，惩戒 是游戏中最受欢迎的专精之一。

稳定的输出能力

惩戒 的爆发技能冷却时间非常短，

[[spell:255937]]

冷却时间为 30 秒，而

[[spell:384376]]

冷却时间为 60 秒。在更侧重 30 秒或 60 秒冷却的构建之间也有合理的灵活性。这使你几乎可以为任何伤害窗口或新的一波敌人准备冷却技能，大部分伤害在前几秒内打出。惩戒 在其爆发窗口中也有相当数量的被动顺劈伤害，因为其大多数重要冷却技能都会造成范围伤害。总体而言，在大多数情况下，与其他职业相比，它能打出稳定的伤害。

不错的能力

惩戒 具有合理的团队副本可行性。作为一名 圣骑士，它可以带来一个有用的团队增益

[[spell:465]]

，尽管其他圣骑士专精往往更受青睐担任该职责。其伤害构成对于团队副本而言相当扎实，在团队副本中它拥有出色的爆发冷却期间被动顺劈伤害，转火目标时损失的伤害很少，并且可以在不损失太多单体伤害的情况下采用范围伤害天赋构建。

稳定的冷却时间

惩戒在大秘境中表现出色，其短冷却时间在这里是一大优势。能够在每一场新的小怪战斗中都拥有爆发伤害是一大利器。惩戒的天赋允许你选择不需要在单体和范围伤害之间做出严重取舍的构建，同时仍然允许你在必要时调整为更多单体伤害。

多种选择，特定用途

惩戒拥有大量功能性技能，例如

[[spell:1022]]

,

[[spell:1044]]

,

[[spell:6940]]

，以及

[[spell:633]]

。然而，这些技能的实用性很大程度上取决于内容——在大秘境中，这些是拥有许多可能用途的强大选择，但在团队副本中它们往往用处少得多。在需要圣骑士功能性的场合，惩戒很少被认为是为了功能性而带的最佳选择，因为你在PvE中无法获得其他圣骑士专精所拥有的强大技能，例如

[[spell:204018]]

.

扎实的生存能力

惩戒拥有相当数量的减伤和治疗手段，例如

[[spell:403876]]

,

[[spell:184662]]

，以及

[[spell:633]]

，此外还拥有完全免疫

[[spell:642]]

提供的完全免疫。这给了你应对手法的工具，但由于我们的被动减伤和治疗要么是情境性的要么相对较弱，玩惩戒在更困难的内容中仍然需要你充分利用所有可用技能。

勉强够用

惩戒的机动性基本上只有一个技能，

[[spell:190784]]

。这对于大多数需要常规移动速度爆发的情况来说已经足够了，但确实还有不足之处。例如，惩戒是唯一一个在没有外部帮助的情况下无法应对反复击退效果的近战输出职业。不过惩戒确实比其他近战拥有更多的远程技能，这在一定程度上弥补了这一弱点，因为即使脱离首领的近战范围你仍然可以输出伤害。

1.

### 惩戒 圣骑士在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1补丁带来了基希伊克斯的解放新团队副本、一个新的超大型地下宝库，以及更多装备升级和额外奖励次数的选择。有关这两个新PvE内容的更多信息，请务必查看我们的专属指南。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

12.1.5补丁带来了一个新的单首领团队副本，拥有新的毕业装备，以及一个针对拥有[[item:280562]]的物品的全新升级系统。还有一大批新的生活质量改进、新的入侵活动，以及各种你可能感兴趣的其他改动。

2.3.

#### 职业改动

惩戒 圣骑士在12.1.5补丁中没有任何改动。:(

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_bladeofjustice.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 职业改动

惩戒在12.1补丁中进行了大量改动，主要是将伤害从冷却时间转移到持续伤害上，以及一些生活质量方面的调整。

- [[spell:1261113]]现在允许[[spell:267344]]和[[spell:402912]]各自额外叠加一层。
- [[spell:267344]]现在使[[spell:184575]]的伤害提高80%（原为150%）。
- [[spell:184575]]的伤害提高40%。
- [[spell:383327]]的伤害提高15%。
- [[spell:53385]]的伤害提高39%。
- [[spell:384376]]现在使造成的伤害和暴击几率提高15%（原为20%）。
- [[spell:406646]]的伤害提高50%。
- [[spell:406647]]的伤害提高50%。
- [[spell:20271]]的伤害提高50%。
- [[spell:24275]]的伤害提高50%。
- [[spell:375576]]的[[spell:20271]]现在造成提高50%的伤害（原为100%）。
- [[spell:1261159]]的伤害降低25%。
- [[spell:19750]]的治疗量提高25%。
- [[spell:85673]]的治疗量提高25%。
- [[spell:156322]]的治疗量提高25%。
- [[spell:267344]]不再被额外的天怒攻击触发。
- 在点出[[spell:404542]]天赋时，额外的天怒攻击不再产生神圣能量。
- [[spell:404542]]现在使自动攻击速度提高15%（原为降低20%）。
- [[spell:343527]]的作用范围半径增加至10码，并且现在包含目标的碰撞半径（原为8码）。
- [[spell:231663]]的减益效果现在持续18秒（原为15秒）。
- [[spell:429826]]的伤害降低30%。
- [[spell:429826]]现在消耗3点神圣能量（原为5点）。

:::

### 至暗之夜改动概述

2.5.

#### 至暗之夜中惩戒 圣骑士的改动

随着至暗之夜的发布，惩戒的专精天赋树结构得到了彻底重做，天赋、技能和英雄天赋也有许多改动。主要改动在以下章节中进行了详细拆解和说明。

2.6.

#### 顶点天赋

惩戒的新巅峰天赋[[spell:1261113]]专注于[[spell:267344]]和[[spell:402912]]，在它们触发时提供更大的伤害提升和额外效果。这个加成基本上可以视为被动的，但现在最好优先消耗触发效果，以尽量减少加成效果被浪费的机会。

2.7.

#### 英雄天赋改动

两个英雄天赋在至暗之夜中都增加了一些新天赋，但它们与之前的运作方式仍然非常相似。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士新增了[[spell:198137]]作为被动天赋，在施放[[spell:375576]]后触发。同时，增强[[spell:431625]]的天赋被略微削弱，并增加了一些额外天赋来模仿地心之战第3赛季套装的部分效果。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱新增了一些具有相当基础被动效果的新天赋。更重要的是，它对旧效果进行了一些重新设计，使[[spell:431377]]的整体覆盖率大幅降低，并新增了[[spell:1263782]]，大幅增强了[[spell:24275]]的威力。这些改动使[[spell:384376]]对于
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱.

2.8.

#### 产生技能的改动

[[spell:24275]]已作为独立技能被移除。取而代之的是，[[spell:20271]]在[[spell:384376]]期间现在会升级为[[spell:24275]]，并继承[[spell:20271]]从各种天赋和效果中获得的所有增益。[[spell:405278]]不再增加[[spell:20271]]提供的神圣能量。[[spell:404542]]已改为降低攻击速度，但现在每次命中都会提供神圣能量，并且可以与[[spell:462854]]配合使用。[[spell:355098]]不再定期自动施放[[spell:20271]]，而是使后续的施放变为连续施放两次。总体而言，这些改动略微减少了你能产生的神圣能量总量，但让你对神圣能量的产生方式有了更多控制。

2.9.

#### 冷却技能的改动

[[spell:458359]]被削弱，不再能触发额外的[[spell:384376]]持续时间。[[spell:384392]]被重新设计为在[[spell:384376]]的基础上提供额外的可叠加急速效果，而不是完全取代固定伤害和暴击的提升。[[spell:343527]]加入了最终清算的效果，但现在是60秒冷却时间。惩戒现在不再那么侧重于30秒的冷却间隔，但在其1分钟的冷却窗口中拥有更强的威力。

1.

### 惩戒 圣骑士游戏基础

惩戒的游戏方式围绕着管理你的神圣能量，并最大化技能的冷却时间和公共冷却时间展开。它有时可以是反应性的，但通常提前规划好几个技能的施放顺序会非常有帮助，以避免不小心浪费神圣能量，尤其是在爆发冷却期间。

神圣能量产生方式有两种主要选择。[[spell:404542]]通常更受欢迎，它包含更多被动的神圣能量产生，但有时在循环中会出现空档。[[spell:406646]]是另一种选择，通常对其神圣能量产生有更多控制，但通常稍微弱一些。

惩戒 圣骑士的循环可以分解为以下三个主要概念：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_malkorok_blightofyshaarj_yellow.jpg>) **消耗神圣能量**
  
  
  
  
  惩戒的主要资源是神圣能量，你需要尽可能频繁地消耗它。在已经有4或5点神圣能量的情况下继续施放产生能量的技能来浪费神圣能量，会让你损失大量伤害。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_artofwar.jpg>) **使用你的触发效果**
  
  
  
  
  像[[spell:267344]]这样的触发效果由于[[spell:1261159]]的存在而需要被消耗。这些不一定需要立即消耗，但通常应该优先处理以避免不小心浪费它们。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_paladin_executionsentence.jpg>) **正确利用冷却技能**
  
  
  
  
  惩戒的大部分伤害集中在爆发冷却窗口中。按正确顺序使用技能固然重要，但在战斗中知道何时施放它们——例如为了重要的伤害增幅或新的一波小怪刷新而保留几秒——可以大幅提升你的伤害。

1.

### 作为惩戒 圣骑士如何获取装备

虽然我们始终建议你自行模拟以获得理想结果，但我们确实提供了一个专属的惩戒配装页面。我们目前涵盖了第二赛季装备的推荐，以便在至暗之夜终局内容发布时有一个良好的开端。在你获取了一些装备后，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月25日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对热修复进行更新。
- **2026年8月25日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 更新了附魔推荐。
- **2026年8月25日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已更新构筑。
- **2026年8月25日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对热修复进行更新。
- **2026年8月25日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对热修复进行更新。
- **2026年8月25日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对热修复进行更新。
- **2026年8月25日（本页）：** 已针对热修复进行更新。
- **2026年8月11日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月11日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月11日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月11日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月11日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月11日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月11日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月11日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月11日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月11日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月11日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月23日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已更新推荐。
- **2026年4月23日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新说明。
- **2026年4月23日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已更新推荐。
- **2026年4月23日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已更新推荐。
- **2026年4月23日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已更新优先级。
- **2026年4月23日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新推荐的团队副本天赋。
- **2026年4月23日（本页）：** 已更新改动讨论。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月24日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新推荐。
- **2026年3月24日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已更新推荐。
- **2026年3月24日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已更新推荐。
- **2026年3月24日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已更新构筑。
- **2026年3月24日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已更新优先级。
- **2026年3月24日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新构筑并添加了推荐的团队副本天赋。
- **2026年3月24日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已更新构筑。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对热修复进行更新。
- **2026年3月17日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对热修复进行更新。
- **2026年3月17日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对热修复进行更新。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对热修复进行更新。
- **2026年3月17日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对热修复进行更新。
- **2026年3月17日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对热修复进行更新。
- **2026年3月17日（本页）：** 已针对热修复进行更新。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月5日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已添加至暗之夜天赋导入。
- **2026年3月5日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新装备和专业制造推荐。
- **2026年3月5日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 更新了附魔推荐。
- **2026年3月5日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已更新优先级。
- **2026年3月5日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新天赋构筑。
- **2026年3月5日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已更新天赋构筑。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（本页）：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（本页面）：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年8月15日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新饰品推荐。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年7月5日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新D.I.S.C.推荐。
- **2025年7月5日（[解放安德迈页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** 已更新构筑。
- **2025年7月5日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新构筑。
- **2025年7月5日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已更新构筑。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 为11.1.7补丁更新。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年4月4日（[解放安德迈页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** 已更新构筑。
- **2025年4月3日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新装备推荐。
- **2025年4月3日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已添加构筑详情。
- **2025年3月18日（[解放安德迈页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** 已更新提示。
- **2025年3月3日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已更新讨论。
- **2025年3月3日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已更新讨论。
- **2025年3月3日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新构筑。
- **2025年2月27日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新装备推荐。
- **2025年2月27日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已更新优先级。
- **2025年2月27日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新天赋讨论。
- **2025年2月27日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已更新循环章节。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对11.1补丁进行审核。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对11.1补丁进行审核。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对11.1补丁进行审核。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对11.1补丁进行审核。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（本页面）：** 已针对11.1补丁进行更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年1月1日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新饰品推荐。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年10月8日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对热修复进行更新。
- **2024年10月8日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对热修复进行更新。
- **2024年10月8日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对热修复进行更新。
- **2024年10月8日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对热修复进行更新。
- **2024年9月25日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了提示和配装。
- **2024年9月25日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 更新了地下城提示。
- **2024年9月25日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 为小众配装添加了额外细节。
- **2024年9月25日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 添加了额外配装。
- **2024年9月25日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已更新构筑。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对热修复进行更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对热修复进行更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对热修复进行更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月28日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 更新了美化推荐。
- **2024年8月28日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 调整了起手循环。
- **2024年8月28日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 添加了地下堡配装。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[地心之战](<https://www.icy-veins.com/wow/retribution-paladin-the-war-within-pve-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/retribution-paladin-mists-of-pandaria-remix-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/retribution-paladin-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/retribution-paladin-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（本页）：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对10.2.6版本更新。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对10.2.6版本更新。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 已针对10.2.6版本更新。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年11月28日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 添加了新的传说物品并调整了饰品推荐。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 为10.2版本进行了审查。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 为10.1.7补丁添加了毕业装备列表并全面改版了页面格式。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已为10.1.7版本审核。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已为10.1.7版本审核。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 为10.1.7补丁更新了天赋配装和技能讨论。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已为10.1.7版本审核。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已为10.1.7版本审核。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 为10.1.7补丁更新了格式和技能描述。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 为10.1.7补丁更新了配装和循环。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年8月10日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 更新了所有推荐。
- **2023年8月10日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 更新了属性推荐和说明。
- **2023年8月10日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 更新了优先级列表，添加了饰品说明。
- **2023年8月8日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 更新了天赋配装和说明。
- **2023年8月7日（本页）：** 更新了所有章节。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月24日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对大灾变时空漫游进行更新，并为纯单体添加了口袋铁砧。
- **2023年5月24日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 更新了天赋和词缀提示。
- **2023年5月24日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 更新了单体与全程顺劈混合配装。
- **2023年5月6日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对饰品和T30次要属性变更进行更新。
- **2023年5月6日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 简化了页面并将措辞改为默认已点出关键天赋。
- **2023年5月6日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 神圣之钟不再会引到战斗中或中立的敌人。
- **2023年5月6日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已将圣殿骑士单体天赋配装更新为使用狂热者的热忱而非忏悔。
- **2023年5月6日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已根据推荐天赋将愤怒之锤更新为T30顺劈优先级，并更新了神圣圣能管理。
- **2023年5月2日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 更新了团队副本和地下城装备，并添加了大秘境美化。
- **2023年5月2日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已将愤怒之锤更新为顺劈场景下的T30优先级。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已更新至10.1补丁。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已更新至10.1补丁。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已更新至10.1补丁。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已更新至10.1补丁。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已更新至10.1补丁。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已更新至10.1补丁。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已更新至10.1补丁。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已更新至10.1补丁。
- **2023年5月1日（本页）：** 已更新至10.1补丁。
- **2023年4月5日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 原始石更新。
- **2023年4月5日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 更新了复仇之盾的持续时间。
- **2023年4月5日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 为最新热修更新了各种描述。
- **2023年3月21日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已为10.0.7补丁更新。
- **2023年3月21日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月21日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已为10.0.7补丁更新。
- **2023年3月21日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月21日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已为10.0.7补丁更新。
- **2023年3月21日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已为10.0.7补丁更新。
- **2023年3月21日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已为10.0.7补丁更新。
- **2023年3月21日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月21日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已为10.0.7补丁更新。
- **2023年3月21日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已为10.0.7补丁更新。
- **2023年3月21日（本页）：** 已为10.0.7补丁更新。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月17日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 在踏蹄小神像修复后重新添加了它。
- **2023年1月17日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 更新了属性优先级。
- **2023年1月17日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 更新了2分钟天赋。
- **2023年1月17日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 更新了天赋。
- **2023年1月17日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 复仇之盾的冷却时间现为90秒。
- **2023年1月17日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 更新了天赋和属性。
- **2022年12月16日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 移除了踏蹄小神像，因为它无法正确命中团队副本首领。
- **2022年12月16日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 添加了第二个主动饰品——狂乱伤恸火炬。
- **2022年12月13日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 添加了备选的全能药水。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季大秘境掉落列表进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 添加了备选药水和药剂选项。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 更新了循环和注意事项。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已将单体天赋更新为清算。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 十字军圣印不再影响盟友。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 更新了天赋和循环。
- **2022 年 12 月 11 日（本页）：** 十字军圣印不再影响盟友。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月24日（[升级](<https://www.icy-veins.com/wow/retribution-paladin-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/retribution-paladin-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/retribution-paladin-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/retribution-paladin-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[装备页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[属性页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[统御圣所页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[大秘境页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[天赋页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[法术页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（本页）：** 已为巨龙时代前夕更新。
- **2022年4月13日（[9.2版本分析](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-2-changes-analysis>)):** 已针对套装变更进行更新。
- **2022年3月2日（[9.1 补丁分析](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-1-changes-analysis>)):** 已针对9.2团队副本开放进行更新。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-2-changes-analysis>)):** 已审核并批准用于9.2补丁。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月14日（[9.1 补丁分析](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-1-changes-analysis>)):** 已用正式服信息更新。
- **2021年5月20日（[9.1 补丁分析](<https://www.icy-veins.com/wow/retribution-paladin-patch-9-1-changes-analysis>)):** 页面已填充初步信息。
- **2020年11月10日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-ny-alotha-raid-guide>)):** 已针对执行命令和最终清算的改动更新页面。
- **2020年10月13日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年4月11日（[永恒宫殿页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-the-eternal-palace-raid-guide>)):** 更新了天赋和精华推荐。
- **2020年1月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-the-eternal-palace-raid-guide>)):** 已针对8.3补丁进行更新。
- **2019年8月5日（[永恒宫殿页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-the-eternal-palace-raid-guide>)):** 已针对史诗难度进行更新。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-crucible-of-storms-raid-guide>)):** 添加了史诗难度注意事项。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** 复仇之怒已作为可行天赋加入。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** 复仇之怒已作为可行天赋加入。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年3月11日（[达萨罗之战页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页已针对8.1.5补丁进行审查，无需更改。
- **2019年2月17日（[达萨罗之战页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了史诗难度推荐。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2018年12月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** 针对恩佐斯和祖尔调整了天赋建议。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** 已针对8.1进行更新。
- **2018年11月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** 添加了奥迪尔史诗难度天赋推荐和提示。更新了数个普通/英雄难度首领的天赋推荐。
- **2018年9月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-uldir-raid-guide>)):** 添加了奥迪尔开放的内容。

显示更多

显示更少

:::

## 练级

在本页，你可以找到我们的惩戒圣骑士逐级练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[圣骑士 升级指南](<https://www.icy-veins.com/wow/paladin-leveling-guide>).

1.

### 惩戒圣骑士练级指南：至暗之夜

惩戒圣骑士是一个拥有大量爆发性范围伤害冷却技能的专精。独自做任务时最好一次性对付大群敌人，或者在组队地下城中打出高额范围伤害。你需要用[[spell:20271]]这样的远程技能尽可能多地吸引敌人仇恨，将他们聚在一起，然后使用[[spell:384376]]和[[spell:255937]]这样的冷却技能迅速将他们全部消灭。

1.1.

#### 升级装备选择

一般来说，你应该在升级过程中装备你捡到的最高物品等级装备。惩戒比任何特定的次要属性组合都更看重力量，而且随着你继续升级，你通常会非常快地替换掉任何装备。

传家宝物品可以帮助你的练级体验，因为它们能提升经验值获取并随你的等级自动提升。

1.2.

#### 至暗之夜升级实用消耗品

如果你愿意花钱，像[[item:212283]]和[[item:212265]]这样的常规药剂和药水可以让战斗稍微轻松一些。否则，像[[item:132516]]和[[item:109076]]这样的物品可以提高你的移动速度，让你移动更快并无需坐骑即可飞行，这在室内穿行或跨越大缺口时很有用。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 惩戒80级至暗之夜练级
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANLLzMzyMzMzMAAAAAAzUGGMjtxsNMzmZY8AzgxGbDAAgZ02YMDAYDwAAmhBGmZWwyMYMjZMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANLLzMzyMzMzMAAAAAAzUGzgZsNzsNMzmZY8AzgxGbDAAgZm2mZ2mBAsBYAAzwMYYmZBLzgxMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-VI1Eyzvcd36AdaKe56qZgmqGbUUqnHaRrkC-EFBiaAxIoR5gHgmGIKkurhpHMsPLnkF-AAAA-bYWUoEcAQMxQAJ-
```

:::

2.1.

#### 升级用战争模式天赋

战争模式天赋的所有选项都不会影响你的惩戒练级速度。你可以随意选择任何你想要的。

1.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–9：**创建你的圣骑士时，你只有一个技能：[[spell:35395]]。这是你第一个神圣能量生成技能。在2级时，你将解锁[[spell:53600]]，你第一个神圣能量消耗技能。在3级时，你获得[[spell:20271]]。[[spell:26573]]在6级解锁。在9级时，你学会职业技能[[spell:62124]]，一个8秒冷却、30码范围的嘲讽。当你不再拥有远程伤害技能时，使用这个远程嘲讽来拉更多怪物。在10级时你可以正式专精惩戒并获得[[spell:85256]]。从现在起你需要换成双手武器。否则，你将无法使用你的新技能。和[[spell:53600]]说再见吧，因为你再也不会在它身上浪费神圣能量了。

1. **等级 1–9：**只要你拥有不超过4点神圣能量，就尽量卡着冷却时间使用[[spell:35395]]。
2. **等级 2–9：**当你拥有3个或更多 神圣 值后，施放 [[spell:53600]]。
3. **等级 3–9：**施放 [[spell:20271]]，冷却好就用。
4. **等级 6–9：**施放 [[spell:26573]]。

**等级 10 起：**从10级开始，你可以使用游戏内的组队查找器排队进入地下城。请始终以DPS身份排队，这样你才能在地下城环境中获得适当的训练，来练习你在当前等级的 惩戒 技能循环。要深入了解如何使用这套 惩戒 技能循环，尤其是在达到更高等级时，请查看我们的 [循环页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-rotation-cooldowns-abilities>)，但我们在下面添加了一个简短版本：

1. **等级 23–65：**施放 [[spell:384376]]。
2. **等级 61 起：**施放 [[spell:343527]]。
3. **等级 10 起：**按照下面的优先级列表执行，直到你至少拥有3点 神圣 值。
   
   
   
   
   - **等级 51 起：**如果你的 神圣 值少于或等于2点，施放 [[spell:255937]]。
   - **等级 26 起：**施放[[spell:375576]]。
   - **等级 10 起：**施放 [[spell:24275]]。
   - **等级 11 起：**施放 [[spell:184575]]。
   - **等级 10 起：**施放 [[spell:20271]]。
   - **等级 10–41：**施放[[spell:35395]]。
   - **等级 41 起：**施放 [[spell:406647]] / [[spell:406646]]。
4. **等级 10 起：**一旦你达到3点或更多 神圣 值，你需要切换到下面的第二个优先级列表，用于消耗 神圣 值。
   
   
   
   
   - **等级 70 起：**可用时施放 [[spell:429826]]。
   - **等级 13 起：**面对2个或更多目标时施放 [[spell:53385]]。
   - **等级 10–19：**面对单个目标时施放 [[spell:85256]]。
   - **等级 19 起：**面对单个目标时施放 [[spell:383327]]。
5.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月23日：** 已更新推荐。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月5日：** 已添加至暗之夜天赋导入。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行审核。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月21日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将向你展示如何在《魔兽世界》12.1.5补丁中轻松游玩 惩戒 圣骑士，使用最简单的循环、天赋树、属性优先级、装备配置等，且不牺牲性能。

1.

### 至暗之夜 中 惩戒 圣骑士 的基础

本页面面向刚接触游戏或该职业的玩家，他们没有进行史诗难度团队副本的打算，或者只是想要一种更直接的方式来游玩自己的专精，而不会被大量需要考虑的细节和主动技能所淹没。

在游玩 惩戒 时，有几件基本的事情需要记住：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_malkorok_blightofyshaarj_yellow.jpg>) **消耗神圣能量**
  
  
  
  
  惩戒 的主要资源是 神圣 值，你需要尽可能频繁地消耗它。当你已经达到4点或5点时，继续使用生成 神圣 值的技能来浪费资源，会让你损失大量伤害。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_artofwar.jpg>) **使用你的触发效果**
  
  
  
  
  像[[spell:267344]]这样的触发效果由于[[spell:1261159]]的存在而需要被消耗。这些不一定需要立即消耗，但通常应该优先处理以避免不小心浪费它们。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_paladin_executionsentence.jpg>) **正确利用冷却技能**
  
  
  
  
  惩戒的大部分伤害集中在爆发冷却窗口中。按正确顺序使用技能固然重要，但在战斗中知道何时施放它们——例如为了重要的伤害增幅或新的一波小怪刷新而保留几秒——可以大幅提升你的伤害。

惩戒 是一个近战DPS专精，游戏风格相对容易掌握。惩戒 最大的优点是其直观的游戏风格，有着非常容易理解的游戏循环和不算太多的按键绑定。

1.

### 至暗之夜 中 惩戒 圣骑士 新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 单体天赋

2.1.

#### 新手 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 惩戒 圣骑士 的 圣殿骑士 单体天赋

此构筑专注于纯单体输出，没有任何仅用于顺劈或AOE的额外天赋。你可以使用“复制导出字符串”按钮将此构筑直接导入游戏中。

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAAAMz02Mz2MAgNADAGzwMYGzMbYbGMMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJarSB-EQFBZiaIEoqCMyhlOJNthpHLrsNMsPP-AAAA-bYWCQMpQJw4QAJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 地下城天赋

2.2.

#### 新手 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 惩戒 圣骑士 的 圣殿骑士 顺劈/地下城天赋

此构筑在保持相当强的优先目标伤害的同时，也选择了一些选项以在AOE中表现更好。你可以使用“复制导出字符串”按钮将此构筑直接导入游戏中。

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAMz02Mz2MAgNADAGzwAzYmZDLzghxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3ONddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-bYWAQMpQJw4QAJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 单体天赋

2.3.

#### 新手 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 惩戒 圣骑士 的 烈日先驱 单体天赋

此构筑专注于纯单体输出，没有任何仅用于顺劈或AOE的额外天赋。你可以使用“复制导出字符串”按钮将此构筑直接导入游戏中。

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJarSB-EQFBZiaIEoqCMyhlOJNNvhpHLrsNMsP-AAAA-WaYUIEKOCYMEJA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 地下城天赋

2.4.

#### 新手 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 惩戒 圣骑士 的 烈日先驱 顺劈/地下城天赋

此构筑在保持相当强的优先目标伤害的同时，也选择了一些选项以在AOE中表现更好。你可以使用“复制导出字符串”按钮将此构筑直接导入游戏中。

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-WaYIEKUOCYMEJA-
```

:::

### 惩戒 圣骑士 基础循环

2.5.

#### 惩戒 圣骑士 新手循环

惩戒 圣骑士没有固定的技能循环。相反，你的目标是确保高优先级的冷却技能尽可能频繁地使用，同时确保在 神圣 值溢出之前使用 神圣 值消耗技能。

1. 尽可能频繁地使用你的主要冷却技能，如 [[spell:255937]] 和 [[spell:375576]]。
2. 对单体目标使用 [[spell:383327]]，对2个以上目标使用 [[spell:53385]] 来消耗 神圣 值。
3. 使用 [[spell:184575]]、[[spell:20271]] 和 [[spell:24275]] 来生成 神圣 值。你应该优先使用 [[spell:184575]]。

2.5.1.

##### 巅峰天赋： ![Light Within Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_holyfire_buff.jpg>) 心之光

惩戒 的顶级天赋 [[spell:1261113]] 会增强 [[spell:267344]] 触发的效果。当你拥有两层 [[spell:267344]] 时，你应该尽快使用 [[spell:184575]]，即使是在4点 神圣 值时，但在5点时应优先消耗。

2.5.2.

##### 第2赛季套装

第2赛季套装效果提高了 [[spell:408459]] 的触发几率，并在消耗触发效果后提高其他 神圣 值消耗技能的伤害。为了最佳使用，你需要在单体目标上消耗 [[spell:408459]] 后穿插 [[spell:53385]] 施放，在AOE中消耗 [[spell:383327]] 后穿插施放。

### 惩戒 圣骑士 防御技能

2.6.

#### 惩戒 圣骑士 的防御技能

惩戒 有许多可用的防御选项。以下是你经常会使用的主要技能列表。

- [[spell:642]] - 防止所有伤害并移除大多数有害效果，持续8秒。同时会施加 [[spell:25771]]。
- [[spell:403876]] - 使你受到的所有伤害降低20%，持续8秒。同时会施加来自 [[spell:184662]] 的吸收效果。
- [[spell:633]] - 为目标恢复相当于你最大生命值的治疗量。同时会施加 [[spell:25771]]。
- [[spell:1022]] - 防止所有物理伤害并移除大多数有害的物理效果，持续8秒。同时会施加 [[spell:25771]]。

### 惩戒 圣骑士 属性优先级

2.7.

#### 惩戒 圣骑士 的属性优先级

对于上述天赋构筑，你应该按以下顺序优先考虑属性。有关本页内容的更多信息，请查看我们的主
[属性优先级页面](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>).

装备等级

精通

急速

暴击

全能

### 暴风雪 战斗辅助

2.8.

#### 惩戒 圣骑士 的战斗辅助

游戏内有两个相关系统来帮助玩家战斗：辅助高亮和单键助手。

2.9.

#### 辅助高亮

该系统通过在动作条上高亮 暴风雪 建议你使用的下一个技能来工作。如果你刚接触该专精，还不完全熟悉其循环优先级，这可能对你很有用。该工具并不总是推荐每种情况下最理想的技能，但作为 惩戒，严格遵循它与理论上最理想的玩法相比，只会造成非常微小的伤害差异。

2.10.

#### 单键助手

这使你可以通过持续按下一个按钮来执行相同的推荐辅助循环，代价是全局冷却时间显著增加。对于 惩戒 来说，这是一个巨大的伤害损失，因为 惩戒 是一个高度重视频繁施放技能的专精，例如像 [[spell:384392]] 这样提供大量急速的效果。除非出于无障碍需求，我们不建议在其他情况下使用此功能。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月25日：** 已针对热修复进行更新。
- **2026年8月11日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月24日：** 已更新构筑。
- **2026 年 3 月 17 日：** 已针对热修复进行更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月5日：** 已更新天赋构筑。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年7月5日：** 已更新构筑。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年2月27日：** 已更新循环章节。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年10月8日：** 已针对热修复进行更新。
- **2024年9月25日：** 已更新构筑。
- **2024年9月9日：** 已针对热修复进行更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 为10.1.7补丁更新了配装和循环。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月6日：** 已根据推荐天赋将愤怒之锤更新为T30顺劈优先级，并更新了神圣圣能管理。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月21日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月17日：** 更新了天赋和属性。
- **2022年12月11日：** 更新了天赋和循环。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到《魔兽世界》12.1.5补丁中你的 惩戒 圣骑士 的最佳天赋。我们还为各种类型的内容（如团队副本或大秘境）提供了默认天赋构筑。如果你开启了战争模式，我们也为你提供了PVP天赋。

1.

### 惩戒 圣骑士 的最佳 至暗之夜 天赋

惩戒 可以在 [[spell:404542]] 和 [[spell:406646]] 之间选择，以获得不同类型的 神圣 值生成方式。目前，[[spell:404542]] 明显强于 [[spell:406646]]，因此本页推荐的所有构筑都将使用 [[spell:404542]]，但如果你想玩另一种风格，则不需要额外更换天赋。

对于英雄天赋，两者都是各有侧重的强力选择。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 拥有更强的单体伤害和更好的防御能力。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 在 [[spell:384376]] 期间拥有更强的爆发力，以及更好的持续顺劈伤害。

- **单体目标 -** 两者在单体目标上都可行， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 略占优势。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 在搭配 [[spell:10060]] 时通常表现更好。
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 在低目标数量的顺劈中表现明显更好，但在大量目标时差距较小。对于爆发AOE，
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 强得多。

在实践中，根据具体情况使用两种英雄天赋树都是最佳选择，但这里推荐的默认构筑使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱，因为它是一个更好的全能选择，特别是考虑到剧毒深渊中持续顺劈的突出地位。

**快速开始导入代码：**

:::talents 惩戒 单体目标 - 烈日先驱
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAYWmtZmZrBBAAsAYAwYGmBzYmZDYmZYMjBD"
}
```
:::

:::talents 惩戒 AOE - 烈日先驱
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBBAAsAYAwYGGYGzMbAzMDjZMYA"
}
```
:::

:::talents 惩戒 探索 - 圣殿骑士
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGjZmBAAAAAYmyYGMjtZmthZ2mxYMzwM2YDAAgZm2mZ2mBAsBYAAzwAzYGbYZGMmxMGMA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

圣殿骑士

单体/团队副本构筑

顺劈/大秘境构筑

探索/开放世界

烈日先驱

团队副本/单体目标

推荐

顺劈/大秘境

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 单体天赋

此构筑最适合纯单体目标的情况。改用 [[spell:1260429]] 和 [[spell:379391]] 将提供一些额外的被动顺劈伤害。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 顺劈/地下城天赋

此构筑放弃了最差的单体天赋，以换取更强的AOE选项。在大秘境中，关于伤害的主要选择是你想优先考虑单体伤害还是AOE伤害。如果想要更多AOE，唯一现实的选择是 [[spell:382536]]，它将替代 [[spell:204979]]。将 [[spell:343527]] 换成 [[spell:458359]] 也会让你的冷却更加平滑，因为它们永远不会错开，并且在与拉怪策略未知或非主流的坦克组队时更容易使用。

### 天赋方案 0-2

1.3.

#### 探索和开放世界天赋

这套天赋最适合短时间多目标战斗以及频繁地在敌人之间移动。对于敌人存活超过几秒的长时间持续战斗，例如更高等级的 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)大秘境，应改用常规的大秘境天赋。

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 单体天赋

这套天赋最适合纯单目标场景。可惜的是，
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 在单目标方面没有真正的替换选择。

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 顺劈/大秘境天赋

这套天赋舍弃了最差的单目标天赋，换取更强的AOE选择。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 在通过天赋替换获取更多单目标或AOE伤害方面没有真正的选择。将[[spell:343527]]替换为[[spell:458359]]也能让你的冷却时间更加平滑，因为它们永远不会失步，并且在与采用非传统拉怪策略的坦克配合时更容易使用。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAAAMz02Mz2MAgNADAGzwMYGzMbYbGMMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJarSB-EQFBZiaIEoqCMyhlOJNthpHLrsNMsPP-AAAA-bYWCQMpQJw4QAJ-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAMz02Mz2MAgNADAGzwAzYmZDLzghxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3ONddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-bYWAQMpQJw4QAJ-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGjZmBAAAAAYmyYGMjtZmthZ2mxYMzwM2YDAAgZm2mZ2mBAsBYAAzwAzYGbYZGMmxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3ONddN0sAl2hqGbUUqnnSRgUMK-EQFBZiaIEoqCMyhOJvhpHLrMMsGlrNH-AAAA-bYWAQMpQJw4QAJ-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAANbbzMzywMDAAAAAAzUGzwMjtxsNMz2MGjxwMWYbAYWmtZmZrBAAAWAMAYMDzgZMzsBMzMMmxgB"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJarSB-EQFBZiaIEoqCMyhlOJNNvhpHLrsNMsP-AAAA-WaYUIEKOCYMEJA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-WaYIEKUOCYMEJA-
```

:::

以上列出的天赋是热门推荐，涵盖了适合各种终局游戏内容的不同配置。每个天赋构筑都有自己的输出循环，也可以针对特定类型的内容进行进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

万卷书是至暗之夜中引入的一个系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

我们推荐每个等级选择以下增益：

- 第1层：[[spell:1279599]]
- 第2层：[[spell:1279604]]
- 第3层：[[spell:1287555]]
- 第4层：[[spell:1279612]]
- 第5层：[[spell:1279614]]

1.

### 巅峰天赋： ![Light Within Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_holyfire_buff.jpg>) 心之光

惩戒的巅峰天赋是[[spell:1261113]]。它为[[spell:267344]]或[[spell:402912]]提供额外效果，提高下一次[[spell:184575]]施放的伤害，并使其造成额外的AOE伤害。它还会在[[spell:384376]]期间提高神圣能量消耗技能的伤害。在拥有2层时优先使用[[spell:184575]]是一次可观的伤害提升。

1.

### 惩戒 圣骑士英雄天赋

惩戒有两套英雄天赋树， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士和
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱。它们各自拥有不同的视觉效果和玩法，增强核心的惩戒天赋和技能。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士在施放[[spell:255937]]后让你能够使用[[spell:429826]]，这是一个独立的神圣能量消耗技能，能造成可观的AOE伤害。它还有额外的增益效果，例如[[spell:198137]]和[[spell:431625]]，可以被动地造成额外的AOE伤害。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱在施放[[spell:255937]]时触发[[spell:431377]]，这是一种强大的持续伤害效果，激活期间提供额外增益。它还通过[[spell:1263782]]等天赋显著增强[[spell:24275]]的威力。

1.

### PvP天赋（战争模式）

战争模式是一个可选功能，可在开放世界中启用跨阵营PvP战斗。启用战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

考虑到开启战争模式在升级和 PvE 内容中的好处，建议开启此功能以在满级时最大化你的升级速度和奖励。不过，你会使自己成为开放世界 PvP 的目标，在升级或做世界任务时存在被"偷袭"的可能性。

没有任何战争模式天赋会影响惩戒的开放世界PvE内容。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月25日：** 已针对热修复进行更新。
- **2026年8月11日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月23日：** 已更新推荐的团队副本天赋。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月24日：** 已更新构筑并添加了推荐的团队副本天赋。
- **2026 年 3 月 17 日：** 已针对热修复进行更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月5日：** 已更新天赋构筑。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年7月5日：** 已更新构筑。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月3日：** 已添加构筑详情。
- **2025年3月3日：** 已更新构筑。
- **2025年2月27日：** 已更新天赋讨论。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年10月8日：** 已针对热修复进行更新。
- **2024年9月25日：** 添加了额外配装。
- **2024年9月9日：** 已针对热修复进行更新。
- **2024年8月28日：** 添加了地下堡配装。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年8月8日：** 更新了天赋配装和说明。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月24日：** 更新了单体与全程顺劈混合配装。
- **2023年5月6日：** 已将圣殿骑士单体天赋配装更新为使用狂热者的热忱而非忏悔。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月21日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月17日：** 更新了天赋。
- **2022年12月11日：** 已将单体天赋更新为清算。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页，你将学习如何在单目标和多目标场景中优化你的惩戒 圣骑士的输出循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以最大化你的DPS。我们的所有内容均已针对《魔兽世界》12.1.5补丁更新。

1.

### 惩戒 圣骑士玩法与循环指南

欢迎来到我们的惩戒圣骑士循环页面。在这里你将了解更多关于单目标和多目标场景下的循环优先级，这些将在团队副本和大秘境中应用。

以下各节说明了不同环境下的循环。点击方框切换到所需场景。目前，单目标和大秘境天赋之间没有循环差异。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱

团队副本与大秘境

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士

团队副本与大秘境

神圣能量天赋

冷却时间天赋

[[spell:404542]]

[[spell:406646]]

[[spell:343527]]

[[spell:458359]]

### 起手式

[[spell:184575]]

**适用条件：Radiant Glory（未启用）。**

[[spell:282113]]

[[item:241288]]

**适用条件：Execution Sentence（启用）。**

[[spell:343527]]

[[spell:255937]]

**适用条件：圣殿骑士（启用）。**

[[spell:429826]]

**适用条件：烈日先驱（启用）。**

[[spell:383327]]

**适用条件：烈日先驱（启用）。**

[[spell:383327]]

[[spell:53385]]

[[spell:375576]]

1.1.

#### 惩戒 圣骑士起手式

起手时，你需要按照此处列出的顺序施放技能，然后再进入常规循环优先级。你的起手式在单目标和AOE场景中是相同的。

1. 施放 [[spell:184575]]。
2. **适用条件：Radiant Glory（未启用）。** 施放 [[spell:384376]]。
3. 使用[[item:241288]]和任何主动使用饰品。
4. **适用条件：Execution Sentence（启用）。** 施放 [[spell:343527]]。
5. 施放[[spell:255937]]。
6. **适用条件：圣殿骑士（启用）。** 施放[[spell:429826]]。
7. **适用条件：烈日先驱（启用）。** 施放[[spell:383327]]。
8. **适用条件：烈日先驱（启用）。** 施放 [[spell:383327]]（AoE 时用 [[spell:53385]]）。
9. 施放[[spell:375576]]。
10. 继续按常规优先级执行。

你在起手阶段的目标应该是在冷却技能之前开始积攒 神圣 力量，然后开始你的爆发窗口。

### 单体目标

惩戒 的循环遵循优先级，如下所列。从列表顶部开始向下查找，直到找到满足所有条件的技能，那就是当前情况下最佳的施放选择。

1. **适用条件：Radiant Glory（未启用）。** 施放 [[spell:384376]]。
2. **适用条件：Execution Sentence（启用）。** 施放 [[spell:343527]]。
3. **适用条件：圣殿骑士（启用）。** 如果可以通过使用 [[spell:255937]] 来施放 [[spell:429826]]，则施放它。
4. **适用条件：圣殿骑士（启用）。** 在以下任一条件下，配合 [[spell:425518]] 触发效果施放 [[spell:429826]]：
   
   
   
   
   - [[spell:384376]]或[[spell:343527]]已激活且即将结束。
   - [[spell:432626]] 增益未激活且 [[spell:384376]] 即将冷却完毕。
   - 触发效果即将过期，或你的目标即将死亡。
5. 配合 [[spell:383327]] 触发的 [[spell:1306161]] 效果以及 5 层 神圣 力量施放 [[spell:53385]]。
6. 如果你拥有5点神圣能量，施放[[spell:383327]]。
7. 施放[[spell:255937]]。
8. 施放[[spell:375576]]。
9. **适用条件：圣殿骑士（启用）。** 在拥有2层[[spell:267344]]时施放[[spell:184575]]。
10. **适用条件：烈日先驱（启用）。** 在拥有2层[[spell:267344]]且[[spell:384376]]未激活时施放[[spell:184575]]。
11. **适用条件：烈日先驱（启用）。** 在拥有2层充能时施放[[spell:24275]]。
12. 在从[[spell:383327]]获得[[spell:1306161]]触发效果时，施放[[spell:53385]]。
13. 施放[[spell:383327]]。
14. **适用条件：烈日先驱（启用）。** 施放 [[spell:24275]]。
15. 施放 [[spell:184575]]。
16. **适用条件：圣殿骑士（启用）。** 施放 [[spell:24275]]。
17. 施放 [[spell:20271]]。
18. **适用条件：圣殿骑士打击（启用）。** 施放[[spell:406646]]或[[spell:406647]]。
19. **适用条件：圣殿骑士打击（未启用）；十字军打击（未启用）。** 施放[[spell:35395]]。

### 群体伤害

惩戒 的循环遵循优先级，如下所列。从列表顶部开始向下查找，直到找到满足所有条件的技能，那就是当前情况下最佳的施放选择。

1. **适用条件：Radiant Glory（未启用）。** 施放 [[spell:384376]]。
2. **适用条件：Execution Sentence（启用）。** 施放 [[spell:343527]]。
3. **适用条件：圣殿骑士（启用）。** 如果可以通过使用 [[spell:255937]] 来施放 [[spell:429826]]，则施放它。
4. **适用条件：圣殿骑士（启用）。** 在以下任一条件下，配合 [[spell:425518]] 触发效果施放 [[spell:429826]]：
   
   
   
   
   - [[spell:384376]]或[[spell:343527]]已激活且即将结束。
   - [[spell:432626]] 增益未激活且 [[spell:384376]] 即将冷却完毕。
   - 触发效果即将过期，或你的目标即将死亡。
5. 在拥有5点神圣值，并由[[spell:53385]]触发的[[spell:1306161]]效果时施放[[spell:383327]]。
6. 如果你拥有5点神圣能量，施放[[spell:53385]]。
7. 施放[[spell:255937]]。
8. 施放[[spell:375576]]。
9. **适用条件：圣殿骑士（启用）。** 在拥有2层[[spell:267344]]时施放[[spell:184575]]。
10. **适用条件：烈日先驱（启用）。** 在拥有2层[[spell:267344]]且[[spell:384376]]未激活时施放[[spell:184575]]。
11. **适用条件：烈日先驱（启用）。** 在拥有2层充能时施放[[spell:24275]]。
12. **适用条件：烈日先驱（启用）。** 如果你拥有[[spell:387170]]激活，施放[[spell:383327]]。
13. **适用条件：圣殿骑士（启用）。** 在从[[spell:53385]]获得[[spell:1306161]]触发效果时，施放[[spell:383327]]。
14. 施放[[spell:53385]]。
15. **适用条件：烈日先驱（启用）。** 施放 [[spell:24275]]。
16. 施放 [[spell:184575]]。
17. **适用条件：圣殿骑士（启用）。** 施放 [[spell:24275]]。
18. 施放 [[spell:20271]]。
19. **适用条件：圣殿骑士打击（启用）。** 施放[[spell:406646]]或[[spell:406647]]。
20. **适用条件：圣殿骑士打击（未启用）；十字军打击（未启用）。** 施放[[spell:35395]]。

AOE循环背后的思路与单目标基本相同。在2个或更多目标时应切换到AOE循环。

1.

### 至暗之夜 第2赛季套装

第2赛季套装效果提高了[[spell:408459]]的触发几率，并在消耗触发效果后提高其他神圣能量消耗技能的伤害。为了最佳利用它，你应在单目标消耗[[spell:408459]]后穿插[[spell:53385]]的施放，在AOE时穿插[[spell:383327]]的施放。

1.

### 职业与专精机制详解

### 资源管理

3.1.

#### 资源管理

玩惩戒时你需要管理两种资源， **神圣能量**
和 **时间**。你的大部分伤害来自产生和消耗神圣能量，提高这一循环的效率将相应提高你的伤害。为了优化神圣能量的产生，你需要考虑产能技能的冷却时间以及提供它的周期性效果，例如[[spell:404542]]。

应当时刻注意尽量减少神圣值的浪费。你不会希望在已经拥有5点时继续产生神圣值，仅仅是为了让某个技能进入冷却；在使用产生者技能以达到5点之前，你需要考虑自己是否会在一个GCD内获得神圣值。以目前的设计，浪费是不可避免的，尤其是在有像[[spell:1263782]]这样的效果时，所以请尽量减少可避免的浪费，同时意识到某些浪费是不可避免的。

目前惩戒比历史上更愿意以较高的优先级消耗神圣能量，这是由于被动产生神圣能量的速率很高。除了尽可能快地让[[spell:255937]]等技能进入冷却，以及在2层时消耗[[spell:267344]]触发效果外，你可以简单地尽快消耗神圣能量。

### 巅峰天赋

3.2.

#### 巅峰天赋

惩戒 的顶级天赋 [[spell:1261113]] 会增强 [[spell:267344]] 触发的效果。当你拥有两层 [[spell:267344]] 时，你应该尽快使用 [[spell:184575]]，即使是在4点 神圣 值时，但在5点时应优先消耗。

1.

### 惩戒 圣骑士重要冷却技能

### [[spell:384376]]

4.1.

#### 复仇之怒

[[spell:384376]]提高所有技能的伤害和暴击几率，因此应在其他冷却技能之前使用。它还会将[[spell:20271]]转化为[[spell:24275]]，升级其效果。配合[[spell:384392]]，它提供可叠加的急速增益，但叠加此效果不再像过去那样需要优先于所有其他技能，因为伤害和暴击加成是固定的。

### [[spell:343527]]

4.2.

#### 处决宣判

[[spell:343527]]造成初始AOE伤害，然后在10秒后根据对所有初始命中目标造成的伤害对主目标造成伤害。在AOE时，其持续期间应继续正常使用AOE技能。应在其他造成可观伤害的冷却技能（如[[spell:255937]]）之前使用它。

### 饰品

4.3.

#### 饰品使用

你将使用两种类型的主动饰品：仅造成伤害的饰品和提供属性增益的饰品。对于提供属性增益的饰品，使用方式很直接；你应该配合[[spell:384376]]使用它们，除非战斗会在[[spell:384376]]冷却完毕前结束，且它们的冷却时间不能自然对齐。你可以通过交替使用冷却周期来使用多个主动属性饰品。

对于主动伤害饰品，使用方式取决于饰品。[[spell:384376]]不会增强饰品伤害，但会提高该伤害的暴击几率。对于饰品的瞬时主动伤害，你需要确保在[[spell:384376]]期间使用它。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月25日：** 已针对热修复进行更新。
- **2026年8月11日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月23日：** 已更新优先级。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月24日：** 已更新优先级。
- **2026 年 3 月 17 日：** 已针对热修复进行更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月5日：** 已更新优先级。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月3日：** 已更新讨论。
- **2025年2月27日：** 已更新优先级。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月25日：** 为小众配装添加了额外细节。
- **2024年9月9日：** 已针对热修复进行更新。
- **2024年8月28日：** 调整了起手循环。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年8月10日：** 更新了优先级列表，添加了饰品说明。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月6日：** 神圣之钟不再会引到战斗中或中立的敌人。
- **2023年5月6日：** 简化了页面并将措辞改为默认已点出关键天赋。
- **2023年5月2日：** 已将愤怒之锤更新为顺劈场景下的T30优先级。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年4月5日：** 更新了复仇之盾的持续时间。
- **2023年3月21日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 更新了循环和注意事项。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页，你将找到《魔兽世界》12.1.5中你的惩戒 圣骑士的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章升级装备的建议，我们都为你准备好了！

1.

### 惩戒 圣骑士毕业装备指南

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 使用纹章系统，让你可以根据获得物品的来源沿特定路线提升装备物品等级，更难的内容会掉落可以升级到更高物品等级的装备。欲了解更多信息，请阅读我们关于
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

本列表包含至暗之夜第2赛季来自任何来源的毕业物品。虽然这是理论上的最佳列表，但对你角色来说最好的物品通常会因当前装备的其他物品而有所不同。

本列表仅供参考，但我们始终建议通过 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)来确认。根据你实际拥有的具体装备，某些部位的最佳装备可能与此列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中催化物品的方式有所不同，因为物品会保留其原有的属性和效果。这意味着物品的原始来源非常重要。以下是每个部位值得催化的强力物品：

- **头部** - [[item:281239]] 来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **护肩** - [[item:251138]] 来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **胸部** - [[item:268222]] 来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **手套** - [[item:251214]] 来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- **腿部** - [[item:271878]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details 常见问题：从大秘库中选择什么？
最重要的选择是神话路线的武器。获得该武器后，或者如果你没有获得，饰品或6/6神话物品是不错的选择，否则你可能想要选择额外的重掷机会。

与其从大秘库中选择一件物品，你也可以选择拿一个 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)。这让你可以对任何地下城或首领进行额外拾取，并获得该物品的 1/6 神话品质版本，用于英雄难度团队副本和 10 层以上大秘境，或用于神话难度团队副本的 6/6 神话品质。关于额外拾取策略的详情，请参阅下文。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271465@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271464@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268245@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271468@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251513@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">珠宝加工</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAKAAwt1ENMMYjVi4IN]]&#10;&#10;<div>[[item:240892]][[item:251490]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

此列表包含 至暗之夜 第 2 赛季大秘境的毕业（BiS）物品。虽然这是一份理论上的最佳列表，但最适合你角色的物品通常会因当前装备的其他物品而有所不同。

本列表仅供参考，但我们始终建议通过 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)来确认。根据你实际拥有的具体装备，某些部位的最佳装备可能与此列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中催化物品的方式有所不同，因为物品会保留其原有的属性和效果。这意味着物品的原始来源非常重要。以下是每个部位值得催化的强力物品：

- **头部** - [[item:251126]] 来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **护肩** - [[item:251138]] 来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **胸部** - [[item:193753@JAAIAAQkCYHKvbRLfA]] 来自 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- **手套** - [[item:251214]] 来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- **腿部** - [[item:273776]] 来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>), [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>), [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：掉落武器和实用的饰品。
- **武器**：任意 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>), [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)，以及 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) 掉落属性优秀的武器。
- **饰品**: [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>), [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)，以及 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>) 拥有地下城中最好的饰品选择。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271465@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271464@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:273777@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271468@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251513@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">珠宝加工</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:193762@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAKAAwt1ENMMYjVi4IN]]&#10;&#10;<div>[[item:240892]][[item:251490]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:193755@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

此列表包含 至暗之夜 第 2 赛季团队副本的毕业（BiS）物品。虽然这是一份理论上的最佳列表，但最适合你角色的物品通常会因当前装备的其他物品而有所不同。

本列表仅供参考，但我们始终建议通过 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)来确认。根据你实际拥有的具体装备，某些部位的最佳装备可能与此列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中催化物品的方式有所不同，因为物品会保留其原有的属性和效果。这意味着物品的原始来源非常重要。以下是每个部位值得催化的强力物品：

- **头部** - [[item:281239]] 来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **护肩** - 职业套装代币来自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **胸部** - [[item:268222]] 来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **手套** - [[item:268220]] 来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- **腿部** - [[item:271878]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的首领和物品，以下是最佳选择：

- [[item:268213@JAACAAAG2A]]：我们的毕业武器。掉落自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).
- [[item:270175@JAACAAAG2A]]：最好的主动使用饰品。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270173@JAACAAAG2A]]：最好的被动饰品。同样来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271465@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271464@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268245@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271468@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251513@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">珠宝加工</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAKAAwt1ENMMYjVi4IN]]&#10;&#10;<div>[[item:240892]][[item:251490]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/retribution-paladin-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 惩戒 圣骑士 饰品推荐

本赛季可用的强力饰品非常少，较强的团队副本饰品远远优于其他饰品。也有一些不错的主动使用饰品可用，通过使用不同的冷却时间套装，多个饰品可以一起使用。

你的理想组合是：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **惩戒 圣骑士 饰品**
**主动 -**

[[item:270175@JAACAAAG2A]]

**被动 -**

[[item:270173@JAACAAAG2A]]

:::

还有相当多的其他选择可用，详见下文。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 惩戒 圣骑士 饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270173@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<span>需要 [[item:268213@JAACAAAG2A]] 的套装加成才能在顺劈/AOE 中发挥最大威力。</span>&#10;</li>&#10;<li>[[item:270175@JAACAAAG2A]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:270165@JAACAAgNyA]]</li>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:193762@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:250228@JAACAAgNyA]]</li>&#10;<li>[[item:270163@JAACAAgNyA]]</li>&#10;<li>[[item:158367@JAACAAgNyA]]</li>&#10;<li>[[item:250229@JAACAAgNyA]]</li>&#10;<li>[[item:273797@JAACAAgNyA]]</li>&#10;<li>[[item:250245@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250238@JAACAAgNyA]]</li>&#10;<li>[[item:273795@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

12.1 补丁延续了 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)系统，让你可以通过为某个首领的掉落表中指定的物品进行拾取，来定向获取特定物品，且不会重复之前已拾取的物品。 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)可以通过从大秘库中获取（代替常规物品），或者在赛季后期定期获得。[[item:280562]] 会将英雄或神话品质武器、饰品和项链的物品等级各提高 6 点，最高至物品等级 340。

3.1.

#### 惩戒 圣骑士 的虚无核心使用建议

额外拾取的理想使用方式是针对最后两个首领，因为它们掉落的所有物品的基础物品等级都高于本赛季的任何其他掉落。然而，大多数玩家需要一段时间才能击败它们，所以在赛季初期，你最好将拾取机会用于其他内容。

- 对于大秘境： [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>) 没有任何长期毕业（BiS）的物品，但它拥有最小的掉落表，包含一件武器和一个不错的饰品，所以如果你在赛季初期在地下城中使用额外拾取，它对你来说可能具有最高的平均价值。
- 对于团队副本： [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 和 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)的物品几乎全是毕业（BiS）装备，值得在神话难度进行拾取。在英雄难度拾取会掉落神话品质的战利品，但物品等级上限较低。

在第 2 赛季，有些物品比任何同类物品都要强大得多，比如 [[item:268213@JAACAAAG2A]] 和 [[item:270173@JAACAAAG2A]]，这使得额外拾取变得更加复杂。虽然这些也可以通过英雄难度进行拾取，但在较低难度拾取它们各有利弊。简单讨论一下你的相关选择：

- 在赛季初期，使用额外拾取需要你放弃一件大秘库物品。虽然你为此牺牲的通常不会是什么有用的东西，但在某些情况下，从大秘库拿一件物品比一次拾取更有价值。例如，如果你正在凑齐 [[item:268213@JAACAAAG2A]] 的套装加成，或者你正在获取一件 6/6 神话品质的武器而你还没有神话武器。在某些情况下，即使你想拾取的物品已经在你的大秘库中，你可能还是想选择额外拾取，因为同一个首领身上还有其他你想要的物品。
- 如果你能够在神话难度击败 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 或 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) ，就在那里使用你的拾取机会。
- 如果你不能击杀所有首领，但能击杀少数首领的神话难度和所有首领的英雄难度，你的拾取选择很大程度上取决于你是否有额外的纹章可花以及你是否有神话武器。在英雄难度拾取
  [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 直到你同时获得 [[item:268213@JAACAAAG2A]] 和 [[item:270173@JAACAAAG2A]]，这将给你一件武器和一个饰品，在你开始击杀神话难度 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)之前都是毕业（BiS）装备，平均需要 4 次拾取，最坏情况需要 5 次。然而，这还需要你为每件拾取的物品花费至少 80 个神话纹章来完全升级。拾取像 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>) 或 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
  这样的早期首领也是一个替代方案，不需要花费纹章，因为首领的额外拾取掉落已经是 6/6 升级过的。当你选择一个首领进行拾取时，你需要坚持拾取直到获得武器。
- 在拾取 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)时，你可以将拾取专精设置为 神圣 来从你的掉落池中移除两个饰品。如果你想要通过单次拾取获得有保证的升级，这是一个不错的策略，因为 [[item:270168@JAACAAAG2A]] 几乎是一件无用的物品，但 [[item:270175@JAACAAAG2A]] 是我们最好的饰品之一，所以从长远来看，最好在获得它之后再将拾取专精切换为 神圣。
- [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 掉落一些毕业的咒术物品，但其效果不如来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 或 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)的物品效果强大。你仍然需要为戒指和头盔拾取它，但不要将其优先于其他两个首领。

3.2.

#### 晋升毒液石

在选择要升级的物品时，通常模拟是最简单的方法，但作为默认优先级，你的武器应该是首要任务，其次是饰品，最后是项链。理想情况下，你想升级神话品质的物品而不是英雄难度的，但请记住，你需要将它们完全升级到 6/6，然后才能使用 [[item:280562]] 进一步提升。

1.

### 惩戒 圣骑士 最佳制造物品

专业技能是填补装备栏位、自定义物品副属性以及为物品添加特殊效果的有用方式。虽然你应该模拟你的选择来检查哪种最适合你的装备配置，但一个不错的默认选择是 [[item:245783]]。

在赛季初期，制造一件 **双手武器** 是一个强有力的选择，如果你使用
[秘境雾崖](<https://www.wowhead.com/currency=3446>) 将其升级到 331 物品等级，因为武器提供的提升远大于任何其他装备栏位。这需要花费 4 个 [[item:274476]] 而不是 2 个，但这绝对值得。不过，如果你打算在有武器掉落的首领身上使用额外拾取，你应该跳过制造武器。一旦你拾取或制造了武器，其他美化物品就是下一个优先事项。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **惩戒 制造装备优先级**
- **可选**：[[item:237846]] 搭配 [[item:273060]]
- [[item:251513@JAAGAAwt1ENMMYD]]
- 任何带有 [[item:251490]] 的低物品等级栏位
- 任何尚未达到神话品质的栏位

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 惩戒 圣骑士 最佳美化

对于 惩戒，你有几种具有竞争力的美化组合：

- [[item:251513@JAAGAAwt1ENMMYD]] 加上另一件带有 [[item:251490]] 的物品
- 两件带有 [[item:240167]] 和/或 [[item:273069]] 的物品
- 武器上的 [[item:273060]]

这些选项中的大多数你可以混搭 - 例如你可以使用带有 [[item:273060]] 的武器加上 [[item:251513@JAAGAAwt1ENMMYD]] 或另一个带有 [[item:240167]] 的栏位。然而，[[item:251490]] 如果没有 [[item:251513]] 就不会有任何效果。

[[item:240167]] 和 [[item:273069]] 的强度与 [[item:251513@JAAGAAwt1ENMMYD]] 搭配 [[item:251490]] 提升其效果非常接近，根据你具体的装备配置，两种组合都可能略微更优。[[item:251513@JAAGAAwt1ENMMYD]] 是这里的默认推荐，因为在拥有全套毕业装备时它更强。[[item:273060]] 是如果你早期制造武器时的最佳武器美化选择，但长期来看弱于护甲美化选项。

使用 [[item:251513]] 时，你应该使用 [[item:240892]] 作为副属性宝石，以最大化其触发效果的威力。

由于制造装备的物品等级上限略低于神话品质物品，你最终会想将护甲美化用于力量相对较低的栏位。护腕是后期制造的良好选择，但请记住这是一个最终的最佳栏位 - 对于你的第一次或前两次制造，护腕是最差的选择，因为你希望为影响较大的栏位获得高物品等级的装备。

4.2.

#### 为装备添加插槽

你可以使用 [[item:275707]] 消耗品为头盔、腰带和护腕添加插槽，这个消耗品是你在不从大秘库选择物品时获得的。不选择物品会奖励你代币，其中六个可以兑换一个 [[item:275707]] 物品，允许你为上述装备添加插槽，前提是它们是在第 2 赛季获得的。

1.

### 纹章使用

装备可以使用纹章升级。赛季初期这些相当有限，所以你会想优先升级最重要的栏位。对于 惩戒，它们是：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **惩戒 圣骑士 纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲/首饰**

➜

**肩部/手套/腰带/靴子**

:::

1.

### 评估升级

由于可能的装备组合数量庞大，通用的属性优先级或毕业（BiS）列表无法完整说明如何为你的角色配装。相反，你应该使用 [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 来更好地了解更换不同物品将如何影响你的角色。特别是对于 惩戒，你会经常发现随着装备升级，不同属性的价值会大幅波动，因此使用更客观的指标来帮助你做出配装决策是无价的。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月25日：** 已针对热修复进行更新。
- **2026年8月11日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月23日：** 已更新说明。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月24日：** 已更新推荐。
- **2026 年 3 月 17 日：** 已针对热修复进行更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月5日：** 已更新装备和专业制造推荐。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月15日：** 已更新饰品推荐。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年7月5日：** 已更新D.I.S.C.推荐。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月3日：** 已更新装备推荐。
- **2025年2月27日：** 已更新装备推荐。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2025年1月1日：** 已更新饰品推荐。
- **2024年12月17日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年8月28日：** 更新了美化推荐。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月28日：** 添加了新的传说物品并调整了饰品推荐。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 为10.1.7补丁添加了毕业装备列表并全面改版了页面格式。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月24日：** 已针对大灾变时空漫游进行更新，并为纯单体添加了口袋铁砧。
- **2023年5月6日：** 已针对饰品和T30次要属性变更进行更新。
- **2023年5月2日：** 更新了团队副本和地下城装备，并添加了大秘境美化。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月21日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月17日：** 在踏蹄小神像修复后重新添加了它。
- **2022年12月16日：** 添加了第二个主动饰品——狂乱伤恸火炬。
- **2022年12月16日：** 移除了踏蹄小神像，因为它无法正确命中团队副本首领。
- **2022年12月11日：** 已针对巨龙时代第1赛季大秘境掉落列表进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面中，你将找到你的 惩戒 圣骑士 的最佳属性优先级。我们首先展示属性优先级，然后深入探讨这些属性如何与你的专精和游戏玩法相互作用的更复杂解释。我们的内容已针对《魔兽世界》12.1.5 补丁更新。

1.

### 惩戒 圣骑士 属性优先级

没有任何属性断点是你需要专门针对任何属性或任何流派追求的。你的总体属性优先级如下：

装备等级

精通

急速

暴击

全能

如上所述，这些优先级应仅被视为一般指南。在许多配装情况下，这里排名较低的属性最终可能比排名较高的属性更有价值。使用模拟来帮助确定你的装备将始终是更好的方法，因为随着你更换装备，属性的相对价值可能会发生显著变化。

1.

### 深入属性解析

**力量** 提高你所有技能的伤害，通常会是比任何副属性更高的优先级属性。因此，物品等级通常会胜过任何其他属性比较，因为在所有非首饰栏位上，力量都会随着物品等级显著增加。

**急速** 很有价值，因为它通过 [[spell:404542]] 提供资源生成，并减少所有主要 神圣 力量生成技能的冷却时间。

**全能** 提高所有造成的伤害并降低受到的伤害。它与任何天赋或技能都没有天生的协同效应，但随着你获得更多的其他副属性，它会变得更有价值。值得注意的是，全能还能提高饰品和物品其他伤害效果所造成的伤害，当这些效果占你总伤害较大比例时，这可能使其更有价值。

**暴击** 确实能从像 [[spell:406154]] 这样的天赋中获得一些价值，这些天赋能提高暴击所造成的伤害量。[[spell:267344]] 也有更高的几率从暴击的近战攻击中触发，这使得暴击比单纯的伤害提升本身更有价值。对于
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 来说，由于 [[spell:431551]]，它在 AoE 中也略微更有价值。

**精通** 提高你所有造成 神圣 伤害的技能的伤害。这包括造成神圣打击或光辉伤害的技能，因为就 [[spell:267316]] 而言，它们也被视为 神圣。它还使 [[spell:20271]] 在施放时有几率造成额外的 神圣 伤害，并且这个几率可以通过许多天赋提高。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月24日：** 已更新推荐。
- **2026 年 3 月 17 日：** 已针对热修复进行更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行审核。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年8月10日：** 更新了属性推荐和说明。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月21日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月17日：** 更新了属性优先级。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面中，我们列出了你的 惩戒 圣骑士 可以获得的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/retribution-paladin-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你通常会在第一个插槽中使用一个 [[item:240983]]，在其他插槽中使用 [[item:240892]]。虽然还有许多其他宝石可用，但这种组合在所有类型的游戏中都能提供最高的性能收益。

1.

### 最佳附魔和武器强化

[[item:243733]] 是最好的武器油。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>[[item:273072]]</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:244007]]</td>&#10;</tr>&#10;<tr>&#10;<td>肩部</td>&#10;<td>[[item:243991]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:244641]]</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>[[item:243953]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>[[item:243957]]</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

通常，[[item:241322]] 是最好的药剂。然而，其他副属性药剂是备选方案，具体取决于你装备提供的属性。你需要自己模拟来确定另一种药剂是否更好，但魔导师合剂在大多数情况下都能很好地为你服务。

3.2.

#### 药水

最好的药水是 [[item:241288]]。然而，它需要通过拥有接近 0 的全能以及不将急速作为你最高的副属性来将其负面影响降到最低。如果这两点中任何一点适用于你，[[item:241308]] 可能是一个更强的选择。

[[item:271883]] 是你治疗药水的最佳选择。使用它有 5 分钟的冷却时间，但如果首领战斗持续足够长，可以消耗多个。此外，术士 的 [[item:5512]] 不与其他治疗消耗品共享冷却时间。如果你带着一个，记得也使用它！

3.3.

#### 食物增益

[[item:242275]] 和其他类似的增加力量的食物是最好的食物。如果放置了盛宴，我们建议吃盛宴，因为它除了主属性或副属性外还提供耐力。

3.4.

#### 强化符文

如果你想（并且买得起）使用它们，[[item:259085]] 是最佳选择。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月25日：** 更新了附魔推荐。
- **2026年8月11日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月23日：** 已更新推荐。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月24日：** 已更新推荐。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月5日：** 更新了附魔推荐。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行审核。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年8月10日：** 更新了所有推荐。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年4月5日：** 原始石更新。
- **2023年3月21日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月13日：** 添加了备选的全能药水。
- **2022年12月11日：** 添加了备选药水和药剂选项。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5 补丁中使用你的 惩戒 圣骑士 挑战大秘境地下城的技巧和建议。

1.

### 惩戒圣骑士在至暗之夜第2赛季的史诗钥石地下城中

在本攻略中，我们将讨论如何在史诗钥石地下城中充分发挥你的惩戒圣骑士的实力，包括最佳的角色配装方式、你的输出循环可能如何变化，以及如何最有效地使用你的技能的技巧与窍门。

如果你对史诗钥石地下城及其相关的一般机制不熟悉，可以在下方的专用史诗钥石页面阅读更多信息。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士配装

2.1.

#### 最佳史诗钥石 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 惩戒圣骑士的圣殿骑士天赋配装

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士的瞬发爆发和单体伤害通常强于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱拥有更强的瞬时爆发和单体伤害，但持续性顺劈伤害较差。它还拥有更强的防御性选择。

这套配装舍弃了最弱的单体天赋，换取了更强的范围伤害选择。在史诗钥石地下城中，伤害方面的主要选择只是在于你想要优先考虑单体伤害还是范围伤害。若想获得更强的范围伤害，唯一现实的选择是[[spell:382536]]，它将取代[[spell:204979]]。将[[spell:343527]]换成[[spell:458359]]也会让你的冷却时间更加平滑，因为它们永远不会错开，而且在与采用非常规拉怪策略或路线的坦克配合时更容易使用。

**使用'导出天赋'按钮将最佳构建直接导入你的游戏中。**

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAMz02Mz2MAgNADAGzwAzYmZDLzghxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3ONddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-bYWAQMpQJw4QAJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱配装

2.2.

#### 最佳史诗钥石 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 惩戒圣骑士的烈日先驱天赋配装

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱在较长的战斗中对多个目标拥有比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士更强的顺劈伤害，但爆发窗口之间的冷却时间更长，生存能力也更差。

这套配装舍弃了最弱的单体天赋，换取了更强的范围伤害选择。在史诗钥石地下城中，伤害方面的主要选择只是在于你想要优先考虑单体伤害还是范围伤害。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱没有真正增加范围伤害的选择。将[[spell:343527]]换成[[spell:458359]]也会让你的冷却时间更加平滑，因为它们永远不会错开，而且在与采用非常规拉怪策略的坦克配合时更容易使用。

**使用'导出天赋'按钮将最佳构建直接导入你的游戏中。**

:::talents 天赋构筑
```json
{
  "code": "CYEAAAAAAAAAAAAAAAAAAAAAAAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBAAAWAMAYMDDMjZmNgZmhxMGMA"
}
```
:::

:::details 来源计算器编码
```
#GB-EVI1yzcfd3MNddN0wsAl2hqGbUUqnnJqSRA-EQFBZiaIEoqCMyhlOJvhpHLrsNMsvGF-AAAA-WaYIEKUOCYMEJA-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和阻止

3.1.

#### 打断、昏迷和阻止

- [[spell:96231]]是你常规的短冷却打断技能。如果你需要打断法术施放，优先使用它。
- [[spell:853]]是一个单体昏迷技能，持续时间长达6秒。经常使用它来昏迷那些你无法用[[spell:96231]]打断施法的怪物。
- [[spell:115750]]可以用来迷惑10码范围内的敌人。这可以用作对可被群体控制的施法敌人的范围打断。
- [[spell:255937]]持续5秒，是一个非常强力的范围昏迷技能，但仅对恶魔和亡灵敌人有效。
- [[spell:10326]]恐惧20码内的一个亡灵、异种或恶魔目标，持续时间最长可达40秒。

### 其他功能

3.2.

#### 其他功能

- [[spell:391054]]允许你在战斗中复活一名队友。
- 激活[[spell:465]]，使你的小队受到的所有伤害降低3%。
- [[spell:213644]]可以移除一名小队成员身上的所有中毒和疾病效果。
- [[spell:1022]]移除流血和其他物理伤害效果。此外，它使你的目标在10秒内免疫物理伤害和有害效果。它通常用于因输出伤害或治疗而从坦克手中抢到仇恨的小队成员。
- [[spell:6940]]使一名小队成员受到的伤害降低30%，但你将承受被减免伤害的100%。它持续12秒，或者直到转移的伤害会使你的生命值降至20%以下。与你的坦克和治疗者沟通，规划好何时使用这个技能。
- [[spell:1044]]移除并免疫移动受限效果，持续8秒。
- [[spell:633]]治疗一个友方目标，治疗量相当于你的最大生命值。
- [[spell:85673]]在必要时也可以用作治疗技能，但由于它消耗神圣值，如果你施放过于频繁，将会损失大量伤害。

1.

### 应对词缀

本节包含针对惩戒处理史诗钥石地下城中各种词缀的专属技巧。

### 词缀：升腾

4.1.

#### 惩戒圣骑士的攀升词缀应对

[[spell:115750]]是我们唯一能处理这些球的范围控制技能。必要时你也可以使用单体控制和打断技能，如[[spell:853]]和[[spell:96231]]。

### 词缀：虚缚

4.2.

#### 惩戒圣骑士的虚空束缚词缀应对

在虚空大使出现时全力集火击杀它即可。你不需要为此更换任何天赋。

### 词缀：脉冲星

4.3.

#### 惩戒圣骑士的脉冲词缀应对

在环绕其他玩家的球出现时去承担它们。尽量为这种情况保留一层[[spell:190784]]充能。

### 词缀：吞噬

4.4.

#### 惩戒圣骑士的吞噬词缀应对

[[spell:213644]]和像[[spell:85673]]及[[spell:633]]这样的治疗技能可以用来移除这个减益效果。[[spell:1044]]也能移除它，并且可以与[[spell:305394]]配合对另一名玩家使用，一次性移除你们两人的减益效果。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月25日：** 已更新构筑。
- **2026年8月11日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月23日：** 已更新推荐。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月24日：** 已更新构筑。
- **2026 年 3 月 17 日：** 已针对热修复进行更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月3日：** 已更新讨论。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年10月8日：** 已针对热修复进行更新。
- **2024年9月25日：** 更新了地下城提示。
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 为10.1.7补丁更新了天赋配装和技能讨论。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月24日：** 更新了天赋和词缀提示。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月21日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月17日：** 更新了2分钟天赋。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页，你将找到许多有用的宏和插件，帮助你在《魔兽世界》12.1.5补丁中更轻松地游玩你的惩戒圣骑士。

1.

### 最佳宏

欢迎来到我们的插件与宏页面。在这里，我们将介绍一些实用的插件，你可以通过更信息丰富的界面来提升游戏体验，同时提供一些常用的惩戒圣骑士宏。

1.1.

#### 圣骑士通用宏

这些宏可以让你使用鼠标悬停宏对小队成员施放祝福类法术。如果你的光标悬停在一个友方目标上，它们会将技能施放在该目标上。否则，技能将正常施放在你的目标或你自己身上。

#### 保护祝福宏

```wow-macro
#showtooltip 保护祝福
/cast [@mouseover,noharm,exists] [] 保护祝福
```

#### 自由祝福宏

```wow-macro
#showtooltip 自由祝福
/cast [@mouseover,noharm,exists] [] 自由祝福
```

#### 牺牲祝福宏

```wow-macro
#showtooltip 牺牲祝福
/cast [@mouseover,noharm,exists] [] 牺牲祝福
```

1.1.1.

##### 代祷鼠标悬停宏

#### 代祷宏

```wow-macro
#showtooltip 代祷
/cast [@mouseover,dead,exists] [] 代祷
```

1.1.2.

##### 圣疗术鼠标指向宏

#### 圣疗术宏

```wow-macro
#showtooltip 圣疗术
/stopcasting
/cast [@mouseover,noharm,exists] [] 圣疗术
```

1.1.3.

##### 清毒术鼠标悬停宏

#### 清毒术宏

```wow-macro
#showtooltip 清毒术
/cast [@mouseover,noharm,exists] [] 清毒术
```

1.1.4.

##### 责难焦点宏

#### 责难焦点宏

```wow-macro
#showtooltip 责难
/cast [@focus,harm,nodead] [] 责难
```

这个宏会在你将敌人设为焦点时对你的焦点目标施放[[spell:96231]]，否则会对你的当前目标施放。

1.

### 最佳插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.1.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.2.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.2.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.2.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.2.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.3.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.3.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行审核。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月21日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
