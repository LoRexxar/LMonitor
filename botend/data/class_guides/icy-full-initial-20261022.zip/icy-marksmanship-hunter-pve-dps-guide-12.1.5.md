## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Azortharion。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-guide>)
- [练级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)

## 专精概览

欢迎来到我们关于魔兽世界12.1.5补丁的射击 猎人指南。在这里，你将学习如何在团队副本和大秘境地下城中作为一名射击 猎人进行游戏：从最初入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

射击大秘境资源

[全新！顶级射击天赋构建](<https://raider.io/specs/marksmanship-hunter/talents>)

[顶级射击大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/hunter/marksmanship>)

[射击大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=hunter--marksmanship>)

[热门射击队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=hunter--marksmanship>)

1.

### 射击 猎人概述

射击 猎人是一个机动性较强的远程DPS专精，专注于

施法缓慢但威力强大的受冷却时间限制的技能，例如

[[spell:19434]]和[[spell:257044]]。射击猎人是

以伤害为核心的狙击手，拥有出色的爆发伤害、机动性和

灵活性。

强力顺劈，急剧衰减

射击在单体团队顺劈方面非常出色，能在1-4个目标上造成强大的爆发伤害。目标越多效果越差，超过8个目标后伤害会急剧下降，因为有硬性目标上限，这对大秘境来说是不利的。

非常适合本次团本

射击拥有出色的单体、2-4目标顺劈、爆发和斩杀能力。几乎所有在本次团本中非常重要的方面都具备，使其成为最强的团本专精之一。

有上限的AoE，优先伤害弱

射击的伤害随目标增多而变差，超过8个目标后急剧下降，这在大秘境中很常见。即使正好是8个目标，上限本应让它最强的时候，它的AoE也不领先于其他专精。它的单体和低目标数顺劈很扎实，但优先伤害很差，而大秘境正是通过大波次进行的，使其成为大秘境整体表现较弱的专精之一。

表现平平

我们为团队带来的是平庸的实用性。1分钟冷却的眩晕/AoE打断，以及

[[spell:474421]]

一个常规冷却时间的远程打断。我们AoE打断的灵活性和冷却时间都很一般。

[[spell:257284]]

在团队副本中是必备的，但在大秘境中并不特别强。

强力主动防御，脆弱被动防御

射击拥有多个强大的主动防御技能，能够有效减轻大量伤害。然而，其被动防御相对较弱，依赖于时机把握和正确使用冷却技能才能在高伤害环境中存活。在持续跳伤害的"腐蚀"伤害场景中表现较差，面对不断跳动的强力持续伤害时尤为吃力。因此，猎人通常比其他职业更需要外部治疗，技能上限相对较高，而技能下限相对较低。

高潜力，但高技能门槛

虽然射击约有40%的时间在施放使你无法移动的法术，但在何时施放这些法术方面相当灵活。因为

[[spell:19434]]

有两层充能，可以在移动时延迟使用，只要你不浪费充能上限，你就没有任何损失。利用这一点可以使射击在实践中成为一个机动性相当强的专精。

1.

### 射击 猎人在至暗之夜中的变化

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本为第二赛季新增了两个终局内容。

基斯希克斯的解放是一个新的团队副本首领战，而金多詹迷宫

是一个新的巨型地下堡。我们关于这两者的指南链接在下方。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

12.1.5版本是一个赛季中期的内容补丁。它还带来了

[[item:280562]]，一种用于升级你的武器、

饰品和项链至物品等级340的新货币。其他所有新增内容都在下方的

补丁中心页面。

2.3.

#### 职业改动

12.1.5补丁移除了[[spell:1277548]]，并用一个新天赋

[[spell:1319016]]取而代之。实际上，主要

区别在于[[spell:257044]]不再为你消耗[[spell:260240]]，

所以作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 你需要在触发效果前再次消耗掉它

[[spell:257044]]之前消耗掉触发效果，就像第1赛季那样，除非[[spell:288613]]已激活，而

作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠你只需按冷却时间施放[[spell:257044]]即可。

[[spell:1319016]]对你的循环没有任何改变，是一个纯粹的

被动增益。

- 新天赋：[[spell:1319016]]。[[spell:19434]]暴击现在
  
  
  
  
  会造成[[spell:260309]]流血效果，伤害为造成伤害的20%
  
  
  
  
  而非10%。在一次暴击[[spell:19434]]之后的4秒内，
  
  
  
  
  每当你的一个技能命中时，目标还会受到额外的流血伤害
  
  
  
  
  伤害时，还会受到额外的流血伤害。
- [[spell:1277548]] 已被移除。[[spell:257044]] 不再发射
  
  
  
  
  [[spell:185358]]，在其引导开始和结束时各发射一次，因此它不再
  
  
  
  
  自身消耗[[spell:260240]]。这在循环中具有重大意义
  
  
  
  
  输出循环有重大影响，详见我们的输出循环页面。

我们的 [循环](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>) 页面已

针对12.1.5补丁进行了更新。在我们的

[配装](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>) 页面上，催化

来自基斯希克斯团队副本的 [[item:281238]] 是我们的新毕业

手套，此外还有一份新的清单，说明应将你的第一个

[[item:280562]]花在哪里。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_marksmanship.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 12.1版本改动

12.1版本在新赛季之外带来了相当多的内容。

有一个新区域可供探索，新的稀有怪和宝藏可供猎取，以及

大量新的住宅和幻化奖励可供收集。暴风雪还

更新了许多现有系统，并添加了生活质量

方面的改进。

:::details 显示12.1职业改动 隐藏12.1职业改动
2.5.

#### 职业改动

射击 在三个 猎人 中获得了远超其他两系的大规模重做

专精

在第2赛季中。[[spell:212431]] 作为一个完全不同的技能回归，

[[spell:257044]] 再次造成可观伤害，而 [[spell:19434]] 则

遭到削弱。

该 [全知典籍](<https://www.icy-veins.com/wow/omnium-folio-guide>) 借力系统延续到了第二赛季，并且它

同时影响你的天赋选择和装备。你可以在我们

专门的 [天赋](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>) 和

[配装](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>) 指南中找到详细信息。

- [[spell:212431]] 现在持续3秒，每1秒
  
  
  
  
  目标会因 火焰 伤害而爆炸，对8码内所有敌人造成该伤害的50%。
  
  
  
  
  作用于8码范围内。超过5个目标时伤害降低。
- 新天赋：[[spell:473520]]。[[spell:212431]] 现在可在
  
  
  
  
  3秒内施放第二次使用，并会吸收目标身上之前
  
  
  
  
  来自你目标身上先前[[spell:212431]]的伤害。这是一个选择
  
  
  
  
  [[spell:1301406]] 构成抉择节点。
- [[spell:473520]] 现在是 [[spell:1301406]]，并使
  
  
  
  
  [[spell:212431]] 获得 [[spell:194595]]。
- 燃烧弹药现在是火力密度，并使
  
  
  
  
  [[spell:389019]] 影响额外1个 [[spell:19434]]。
- [[spell:471369]]现在使[[spell:212431]]持续1
  
  
  
  
  1秒，这意味着它会额外爆炸一次造成伤害。
- [[spell:389019]] 现在使 [[spell:257044]] 提高你下一次
  
  
  
  
  [[spell:19434]] 的伤害，提高20%。
- [[spell:473523]] 现在使 [[spell:257044]] 伤害提高10%
  
  
  
  
  并使其有30%几率获得 [[spell:194595]]。
- [[spell:378769]] 现在使 [[spell:19434]] 有10%几率
  
  
  
  
  **使你的下一个 [[spell:19434]] 获得 [[spell:378769]]。**
- [[spell:470945]] 不再影响 [[spell:185358]]。
- 以下天赋已被移除：[[spell:473370]] 和
  
  
  
  
  [[spell:471363]].
- [[spell:473369]] 现在是一个1点天赋，提高
  
  
  
  
  [[spell:19434]] 的伤害5%（原为10%），[[spell:257044]] 的伤害10%（原为20%）。
  
  
  
  
  [[spell:378767]] 现在使 [[spell:19434]] 的冷却时间缩短1秒
  
  
  
  
  （原为2秒）。[[spell:459802]] 现在是一个2点天赋。
- 部分天赋在天赋树第二层中移动位置，以便
  
  
  
  
  更容易获取 [[spell:212431]]，且
  
  
  
  
  [[spell:474456]]/[[spell:474440]] 节点不再
  
  
  
  
  需要路径点才能到达 [[spell:288613]]。
- **巅峰天赋：** [[spell:1273129]]（等级2）现在提高
  
  
  
  
  你技能的暴击伤害5%/10%，并提高你远程技能的伤害
  
  
  
  
  3%/6%。[[spell:1273128]]（等级3）现在使 [[spell:466872]] 还会
  
  
  
  
  使你对该目标的下一个 [[spell:257044]] 的伤害提高20%，
  
  
  
  
  在 [[spell:19434]] 加成的基础上。
- **黑暗游侠:** [[spell:1277565]] 已被重新设计为固定
  
  
  
  
  提高10%的 [[spell:53351]] 和 [[spell:466932]] 伤害，现在
  
  
  
  
  正确提高 [[spell:430715]] 的伤害
- **黑暗游侠:** [[spell:466932]] 在可用时不再高亮
  
  
  
  
  自身
- **黑暗游侠:** [[spell:466932]] 的直接伤害降低了
  
  
  
  
  40%，随后提高了25%
- **黑暗游侠:** [[spell:467749]] 伤害提高300%，且
  
  
  
  
  [[spell:430715]] 的 [[spell:466932]] 伤害降低40%
- **黑暗游侠:** 黑暗仆从召唤物现在可以在冷却
  
  
  
  
  管理器中被追踪。
- **哨兵:** [[spell:1253825]] 现在只会造成1秒的冷却
  
  
  
  
  缩减效果作用于 [[spell:19434]]（原为2秒）。[[spell:1253601]]
  
  
  
  
  持续时间延长至16秒（原为12秒）。
- **调整：** [[spell:19434]], [[spell:257044]],
  
  
  
  
  [[spell:185358]]、[[spell:257620]] 和 [[spell:53351]]
  
  
  
  
  的伤害均提高了20%，此后又进行了进一步调整：
  
  
  
  
  [[spell:257044]] +20%, [[spell:185358]] +15%, [[spell:53351]] +25%,
  
  
  
  
  [[spell:56641]] +50%, [[spell:260243]] +20%, [[spell:257620]]
  
  
  
  
  +80% 然后 -20%，所有伤害 +5%。自动射击伤害提高20%，且
  
  
  
  
  远程自动射击伤害提高600%。[[spell:212431]] 在重新设计后进行了两次调整，
  
  
  
  
  分别为15%和100%，现在只会对
  
  
  
  
  附近其他敌人造成其伤害50%的爆炸。
- **套装：** **2件套：** [[spell:212431]] 持续时间延长1秒
  
  
  
  
  且伤害提高5%。 **4件套：** [[spell:19434]] 和
  
  
  
  
  [[spell:257044]] 伤害提高5%。每次 [[spell:212431]]
  
  
  
  
  造成爆发伤害时，[[spell:19434]] 和
  
  
  
  
  [[spell:257044]] 的冷却时间缩短0.5秒。
- **错误修正：** [[spell:459802]] 现在正确提高
  
  
  
  
  [[spell:212431]] 的伤害。[[spell:212431]] 的范围伤害不再
  
  
  
  
  从精通、暴击伤害加成和瞄准中获得双倍收益，不再
  
  
  
  
  命中其自身的主要目标，并且如果主要目标
  
  
  
  
  被它杀死仍会触发。[[spell:378769]] 现在以预期的几率从
  
  
  
  
  [[spell:19434]] 触发，[[spell:470945]] 不再阻挡或消耗
  
  
  
  
  这些触发效果。

:::

:::

### 至暗之夜改动概述

2.6.

#### 射击 猎人 在 至暗之夜 中的改动

至暗之夜资料片为所有猎人专精带来了巨大改动，主要

侧重于精简和简化技能体系的各个方面。

2.6.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠

- 自动射击不再触发[[spell:378769]]。
- [[spell:257044]] 现在必定获得
  
  
  
  
  [[spell:378769]].
- 在你激活 [[spell:288613]] 后，百发百中按钮本身会变为
  
  
  
  
  [[spell:392060]]，一个强力的施法技能，激活
  
  
  
  
  [[spell:378769]]，并打断/沉默所有命中的目标1秒。

2.6.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵

- [[spell:466872]] 被 [[spell:1253601]] 取代，且强大
  
  
  
  
  得多。
- [[spell:450373]] 现在是一个固定10%的吸收护盾，当你
  
  
  
  
  获得 [[spell:1253601]] 触发时即可获得。
- 集中值上限提高至125。
- 与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 类似，在激活 [[spell:288613]] 后，
  
  
  
  
  稳固射击按钮变成 [[spell:1264902]]，该技能会发射一道发光的
  
  
  
  
  飞轮，在敌人之间弹跳时造成大量范围伤害。一个抉择节点
  
  
  
  
  可以让这个飞轮为我们提供 [[spell:194595]]。

2.7.

#### 输出与游戏机制改动

- [[spell:260367]] 已被移除，因此 [[spell:19434]] 的
  
  
  
  
  施法时间大幅延长，基础值为 2.5 秒。在 [[spell:288613]] 期间，
  
  
  
  
  该时间缩短至 1.5 秒。其伤害已获得增强以作补偿，但
  
  
  
  
  总体而言，预计射击专精的玩法将更偏向狙击手风格，节奏更慢、更注重
  
  
  
  
  射击 在 至暗之夜 中的“手感”。
- 所有与 [[spell:212431]] 相关的天赋均已移除。我们保留了
  
  
  
  
  [[spell:1301406]]，它现在由 [[spell:260243]] 触发。
- 其他被移除的天赋包括 [[spell:384790]]，
  
  
  
  
  [[spell:474296]]，以及当然还有
  
  
  
  
  [[spell:471427]].

2.8.

#### 巅峰天赋

至暗之夜 引入了新的巅峰天赋，在 80 至 90 级之间解锁。

射击 获得了：

1. [[spell:1273132]]
2. [[spell:1273129]]
3. [[spell:1273128]]

它们使 [[spell:257044]] 在引导期间将 [[spell:19434]] 的冷却时间缩短 5

秒。

2.9.

#### 生存能力改动

- 猎人的最大生命值比之前提高了2%。
- [[spell:109304]]的冷却时间现在固定为1分钟，不再是可变的
  
  
  
  
  （且通常更短）。
- [[spell:186265]]的冷却时间在天赋支持下现在为2:00，从
  
  
  
  
  2:30.
- [[spell:186265]]在天赋支持下现在可以提供50%的伤害减免，
  
  
  
  
  从30%提高。
- [[spell:53480]]现在是一个外部防御技能，可以对
  
  
  
  
  你自己或任何友方目标使用，使其受到的伤害降低15%，持续10秒，
  
  
  
  
  但其承受伤害的 50% 将由你的宠物承担。对于 射击 来说，
  
  
  
  
  如果你没有宠物，宠物部分就不存在了。
- [[spell:388035]]现在是3%的被动伤害减免，不再是
  
  
  
  
  一个主动防御冷却技能。

2.10.

#### 功能性改动

- [[spell:257284]]现在是对单体目标的通用3%伤害提升。
  
  
  
  
  这基本上保证了猎人在每个团队副本中的位置。它
  
  
  
  
  在大秘境中也是对团队的增益，尽管效果要弱得多
  
  
  
  
  那里。
- [[spell:147362]]现在可以打断目标施法5秒，从
  
  
  
  
  1.
- [[spell:187650]]现在能使目标减速70%，持续4秒，触发时机是在
  
  
  
  
  使目标减速70%，持续4秒。
- [[spell:474421]] 现在是我们唯一的击晕/打断技能。一个抉择节点要么
  
  
  
  
  将其冷却时间缩短至40秒，或使其成为1秒的范围眩晕。
  
  
  
  
  [[spell:462033]]、[[spell:236776]]和[[spell:186387]]
  
  
  
  
  都已移除。
- [[spell:195645]]和[[spell:5116]]的减速效果分别为25%和
  
  
  
  
  提高了25%和10%。
- [[spell:472729]]现在是职业天赋树节点，不再
  
  
  
  
  依附于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖英雄天赋。它是一个抉择节点，与
  
  
  
  
  [[spell:459460]]同为抉择，后者延长[[spell:109248]]的眩晕
  
  
  
  
  1秒。
- [[spell:459466]]已移除。
- [[spell:213691]]已移除。
- [[spell:459533]]已移除。
- [[spell:321468]]已被移除。

2.11.

#### 杂项改动

- [[spell:186257]]的初始"超级"速度爆发现在在天赋影响下
  
  
  
  
  持续时间翻倍。
- [[spell:53351]] 现在专属于 射击 天赋树。
- 使用[[spell:147362]]/[[spell:187707]]成功打断现在
  
  
  
  
  提供30点集中值，比之前的10点更多，但使用宁神射击进行驱散
  
  
  
  
  [[spell:19801]] 不再提供集中值。

总体而言，我们获得了防御能力和机动性，而在功能性

方面，我们失去了一些东西（比如移动怪物的能力），但

获得了其他东西（更强的标记、更流畅的群体眩晕、更强的打断和

打断时更多的集中值返还）。我们认为这些改动总体上是积极的！

1.

### 射击 猎人 基础玩法

射击 猎人 是一个关于冷却时间管理、保持技能覆盖和循环流畅度的专精。

你要尽可能频繁地施放你的高伤害技能，例如 [[spell:19434]]，

[[spell:257044]]，并尽可能频繁地使用[[spell:53351]]。在这两者之间

技能（它们都有独立的冷却时间）之间，你要通过

使用 [[spell:185358]] 作为消耗技能、[[spell:56641]] 作为填充和

产生技能来管理你的集中值。当你施放 [[spell:19434]] 时，你的下一个

[[spell:185358]]/[[spell:257620]] 将造成显著提高的

伤害，因此你会有一个相当稳定的循环，即一个

[[spell:260240]] 产生技能后紧跟一个消耗技能。

在 [[spell:288613]] 期间——你激动人心的主要冷却技能——一切

都会大幅加速，你将疯狂连发 [[spell:19434]] 和

[[spell:257044]]，它们的冷却时间已缩短。这个冷却技能带来的

主要好处是暴击几率显著提高（更多暴击）以及暴击

伤害提高（更强的暴击）。由于这些以及其他机制，暴击是 射击 的一项重要属性

其他机制。

在AoE中，你需要为所有目标激活[[spell:257621]]增益效果

瞄准和急速火焰施法。这通过在每次施法之间穿插至少一次

[[spell:257620]]来实现，

在每一次[[spell:19434]]和[[spell:257044]]施放之间，即使在[[spell:288613]]期间也是如此。

最优秀的 射击 猎人非常擅长在实战中

以及在激烈的移动战中（这会阻止 [[spell:19434]] 的施放）处理这些事情，

并应对各种机制。他们总是知道接下来该施放什么，并且对

自己的集中值水平和冷却时间状态时刻保持清晰的意识。为了进一步

精简，射击 可以用以下几点简要概括。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_snipertraining.jpg>) **用光你的所有精确瞄准**
  
  
  
  
  每一发 [[spell:19434]] 和 [[spell:257044]] 都会赋予
  
  
  
  
  [[spell:260240]]，而我们希望用掉所有这些精确射击触发效果
  
  
  
  
  在我们再次施放瞄准射击之前。如果你有了一层，就不要施放瞄准射击
  
  
  
  
  作为 哨兵，也要在急速 火焰 之前花掉它们，除非
  
  
  
  
  百发百中已经开启。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_steadyshot.jpg>) **保持施法**
  
  
  
  
  尽可能多地施放技能比每次都按出完美技能更重要，
  
  
  
  
  每次点击按钮，而空闲等待时间是阻碍大多数玩家的最关键因素
  
  
  
  
  玩家偏离他们的伤害目标。[[spell:56641]] 是你填补空档的方式，而且
  
  
  
  
  它可以在移动中施放，所以没有理由浪费一个公共冷却。

1.

### 如何为 射击 猎人 配装

我们专门的 射击 配装页面涵盖了第 2 赛季的装备，

首次升级一直到完整的毕业清单。我们仍然建议

通过模拟自己来获得理想答案。一旦你获得了一些装备，你将

需要相应的消耗品、宝石和附魔来搭配这些新

物品。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 14 日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在有两个或更多目标时激活九头蛇之相，哨兵 现在即使有精确瞄准也会按冷却时间施放急速 火焰。
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年9月30日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 修复了胸甲工具提示显示两个毒咒效果的问题。
- **2026年9月7日（本页）：** 将伤害评分提升至 3.5，团队副本评分提升至 4，并重写了这两个部分。
- **2026 年 9 月 2 日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 将总体和团队副本毕业列表中的饰品更新为剧毒之怒源泉。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 将总体毕业列表中的戒指更新为充能砂岩指环。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 将总体和团队副本毕业列表中的靴子更新为鲁莽旅者之靴。
- **2026年8月31日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 将自动目标切换多重射击宏替换为鼠标悬停多重射击宏。
- **2026年8月31日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 澄清了鼠标悬停多重射击和打断引导的相关说明。
- **2026 年 8 月 31 日（本页）：** 澄清了急速 火焰 的精确瞄准消耗建议。
- **2026 年 8 月 29 日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 将剧毒之怒源泉提升至 S 级，因为它的模拟结果被低估了。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 将武器附魔更新为哈什之仪。
- **2026年8月24日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 将武器附魔更新为哈什之仪。
- **2026年8月24日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 将液体光泽添加为长战斗中的第二瓶药水，用于斩杀阶段。
- **2026年8月24日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 将液体光泽添加为战斗中的第二瓶药水，在斩杀阶段百发百中开启前约 10 秒使用。
- **2026年8月24日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在单体目标战斗中，月光飞轮现在在百发百中剩余约 5 秒时掷出，以便全部 7 次弹跳都落在百发百中期间。
- **2026年8月24日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在 哨兵 单体目标优先级列表中，将急速 火焰 移至精确瞄准消耗技能之上。基础循环相同，但更易解析/阅读。
- **2026年8月22日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 添加了关于制作护腿的说明。
- **2026年8月22日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 指出了唯一一个仍然值得进行的急速 火焰 打断引导操作。
- **2026年8月22日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 根据最近的在线修正更新了急速 火焰 的建议。只有 哨兵 仍然会打断引导，且仅在范围伤害场景中。
- **2026年8月22日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 奥术射击 在百发百中期间不再有单独的规则。
- **2026年8月22日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 大秘境和地下堡的 哨兵 配装现在选择开放 火焰 而非观星者。
- **2026年8月22日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 大秘境和地下堡的 哨兵 配装现在选择命中目标而非黑曜石箭头。
- **2026年8月22日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 急速 火焰 不再需要先消耗精确瞄准。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 在盖博的无底袋削弱后更新了虚空核心的额外掉落优先级。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 将总体毕业列表中的靴子更新为烁能胫甲。
- **2026年8月18日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 添加了目标切换多重射击宏。
- **2026年8月18日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了延迟百发百中最多 15 秒以与爆炸射击对齐的说明。
- **2026年8月18日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了在按下百发百中前切换到没有标记的目标的说明。
- **2026年8月18日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在急速火焰、瞄准射击和精准射击消耗优先级中，加入了通过哨兵的印记和侦察兵印记进行目标选择的功能。
- **2026年8月18日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在多重射击优先级条目中链接了目标切换多重射击宏。
- **2026年8月18日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了团队副本构筑的效用天赋。
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了饰品梯级榜，并将备选被动饰品改为守护者的沸腾核心。
- **2026 年 8 月 17 日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 万卷集配置现在选择虚空污染之壳而非自我修复。
- **2026年8月16日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 重做了制造建议，更正了团队副本物品列表中贪婪的 乌拉特克 之心和盖博的无底袋条目，并添加了赛季开始时的虚空核心和纹章建议。
- **2026年8月16日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在 哨兵 范围伤害起手式中，添加了用多重射击打断急速 火焰 结尾的说明。
- **2026年8月16日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 如果优先目标存在，则从范围伤害优先级和起手式中移除了将爆炸射击分散到两个目标上的操作。发现这并不会加快大秘境的通关速度，因为其优先目标伤害损失，尽管它能小幅提升范围伤害/双目标 DPS。
- **2026年8月16日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 大秘境和地下堡的 哨兵 配装现在选择观星者而非开放 火焰，由于急速 火焰 打断引导现在更频繁地消耗精确瞄准，这是一个小幅提升。
- **2026年8月15日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 根据最新的平衡性调整更新了饰品梯级榜。
- **2026年8月15日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在单体目标优先级中添加了用多重射击打断急速 火焰 结尾的说明，并澄清了两发箭矢都受益于精确瞄准。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了虚空核心的额外掉落优先级。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 将团队副本毕业手套更新为来自尼姆瑞莎·唤波者的催化漩涡狂怒之握。
- **2026年8月13日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在范围伤害优先级中添加了用多重射击打断急速 火焰 结尾的说明。
- **2026年8月12日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 添加了催化剂和大秘库常见问题解答及插槽部分，修正了催化剂掉落位置，并更新了团队副本毕业头盔和手套的来源。
- **2026年8月12日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 澄清了在范围伤害优先级中，急速 火焰 需要技巧射击处于激活状态。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 地下堡构筑现在选择紧急药膏而非荒野医术。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了地下堡配装的职业树，点出了牢不可破的羁绊（为了宠物）。
- **2026年8月11日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 澄清了范围伤害优先级中爆炸射击的目标选择。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已为12.1补丁更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年7月16日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 更新了传家宝属性建议。
- **2026年7月16日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 更正了熊之坚韧和上升气流的描述，移除了异宠表格，并更新了资料片相关引用。
- **2026年7月16日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 修正了套装常见问题解答中的内容，并更新了项链推荐说明。
- **2026年7月16日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔推荐，并修正了附魔提示链接。
- **2026年7月16日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 阐明了爆发模式和功能说明。
- **2026年7月16日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 修正了乱射的冷却时间，并阐明了双重射击的使用方法。
- **2026年7月16日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 阐明了英雄天赋构筑指南。
- **2026年7月16日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 修正了瞄准射击的施法时间，将爆炸射击、哀恸箭和月光飞轮加入术语表，并将技能表按字母顺序排列。
- **2026年7月16日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 将百发百中加入新手优先级列表。
- **2026年7月16日（本页）：** 重做了输出概述。
- **2026年6月17日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了毕业项链。
- **2026年6月17日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 根据实际数据优于模拟结果，更新了推荐的第一周卷集符文。
- **2026年6月16日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 澄清了武器附魔的选择。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月29日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于在削减射程单体目标中以2层充能高优先级使用瞄准射击的说明。
- **2026年5月21日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了哨兵团队副本AOE构筑的指南。
- **2026年5月7日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了哨兵团队副本AOE构筑。
- **2026年5月6日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了哨兵大秘境构筑。在所有大秘境场景中仍然非常差。
- **2026年5月4日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 针对数值调整进行了更新。
- **2026年4月27日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 循环更新与简化。起手更新。
- **2026年4月25日（本页）：** 更新了野兽控制的专精表现评估。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月9日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠起手修复。
- **2026年4月7日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了光之连队战旗的天梯榜排名。
- **2026 年 3 月 31 日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了针对Vaelgor和Ezzorak的天赋构筑说明。
- **2026年3月25日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了大秘境装备毕业列表。
- **2026年3月25日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了基础团队副本AOE构筑。
- **2026年3月22日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 添加了急速阈值信息。
- **2026年3月22日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 将哨兵大秘境构筑中哨兵天赋树里的暮光安魂曲替换为潜行与突袭，模拟表现相同，但能带来极小的机动性收益。
- **2026年3月22日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 将哨兵大秘境构筑中哨兵天赋树里的暮光安魂曲替换为潜行与突袭，模拟表现相同，但能带来极小的机动性收益。
- **2026年3月21日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了大秘境装备毕业列表。
- **2026年3月19日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 更新为推荐吸血附魔而非闪避。更新了宝石建议。
- **2026年3月19日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了地下堡构筑。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 修复了导致乱射在某些条件下不出现在起手循环中的错误。对哨兵AOE循环进行了小幅更新。
- **2026年3月17日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 为多头蛇构筑添加了简单说明。更新了多头蛇构筑以增加更多AOE。修复了单体构筑的错误。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了哨兵大秘境构筑。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月4日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了终局内容的专业制造推荐。
- **2026年3月3日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对月光飞轮的起手说明。
- **2026年3月3日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了天赋构筑并添加了黑暗游侠构筑。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（本页）：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月23日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了80级的属性递减收益数值。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月14日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 更新了属性优先级，特别是将暴击开始变得次优的临界点明确化。
- **2025年9月2日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 饰品层级列表和毕业装备更新。
- **2025年9月2日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了黑暗游侠大秘境天赋构筑，特别是功能性天赋选择。
- **2025年9月2日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了黑暗游侠大秘境天赋构筑，特别是功能性天赋选择。
- **2025年8月28日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 围绕爆炸射击使用的单体循环更新。
- **2025年8月27日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 更新了黑暗游侠AOE的属性优先级。
- **2025年8月27日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 扩展了关于1.5分钟和1分钟构筑的理由说明。
- **2025年8月27日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** AOE方面的小幅循环说明与编辑。
- **2025年8月27日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 扩展了关于1.5分钟和1分钟构筑的理由说明。
- **2025年8月27日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 进一步简化了循环。
- **2025年8月26日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了关于黑暗游侠大秘境中在鹰眼视觉和精准射击之间切换的说明。
- **2025年8月26日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了关于黑暗游侠大秘境中在鹰眼视觉和精准射击之间切换的说明。移除了关于专注瞄准的说明，因为强化流线型即使在纸面上也是等效的，实际表现更好。更新了团队副本AOE构筑。
- **2025年8月25日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于循环bug的信息。
- **2025年8月25日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了单体目标上爆炸射击的使用方式，以更好地适配强化流线型配置。
- **2025年8月25日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 将单体目标天赋默认选择更新为强化流线型而非专注瞄准。
- **2025年8月20日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于因移动需求将专注瞄准更换为强化流线型的说明。
- **2025年8月19日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 从黑暗游侠AOE中移除了填充性多重射击。
- **2025年8月18日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠单体起手的小幅更新（更明确地要求在进入百发百中前消耗精确瞄准层数）。
- **2025年8月17日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠单体循环的小幅说明/简化。哨兵AOE的小幅说明。
- **2025年8月15日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 针对数值调整更新了饰品天梯榜。简化为单一列表。
- **2025年8月15日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了AOE循环。
- **2025年8月13日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠单体起手的小幅改动。
- **2025年8月12日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 在天梯榜中添加了初步的、基于推测的诅咒石像饰品，因为它暂时无法进行模拟。
- **2025年8月12日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了单体循环。
- **2025年8月12日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 黑暗游侠的极小单体天赋更新。
- **2025年8月11日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了大秘境饰品天梯榜。
- **2025年8月11日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了大秘境构筑推荐。
- **2025年8月11日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠单体目标的重大循环更新，能带来相当可观的额外DPS。
- **2025年8月11日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋构筑推荐。
- **2025年8月9日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了饰品天梯榜和毕业列表。
- **2025年8月9日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 更新了属性优先级。
- **2025年8月8日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了大秘境装备毕业列表。
- **2025年8月8日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了默认的黑暗游侠单体天赋选择。
- **2025年8月8日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了团队副本单体循环的默认功能性天赋选择。
- **2025年8月7日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 进一步的起手更新迭代。
- **2025年8月7日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 将S3单体构筑更新为与S2四件套构筑相同！
- **2025年8月6日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 发送了大秘境职业天赋树更新。
- **2025年8月6日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** AOE循环的重大更新，特别是哨兵AOE起手。
- **2025年8月6日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 黑暗游侠S2四件套天赋和大秘境职业天赋树更新。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月23日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 基于最新的在线修正更新了泰坦圆盘推荐。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月26日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 添加了关于齐射与欧恩哈拉之风的说明。
- **2025年5月17日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了团队副本AOE构筑以点出乱射，因为团队副本中的大多数AOE都是非常短暂的。
- **2025年5月15日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了哨兵大秘境构筑以点出欧恩哈拉之风，因为有证据表明它已被修复，现在在大秘境中能正常工作。
- **2025年5月15日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了黑暗游侠AOE起手。
- **2025年5月15日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了哨兵大秘境构筑以点出欧恩哈拉之风，因为有证据表明它已被修复，现在在大秘境中能正常工作。
- **2025年5月14日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了贾斯托钻石的购买顺序，并补充了更多关于其"毕业装备"地位的说明。
- **2025年5月9日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了腐蚀附魔与谜之卡特尔芯片代币部分。
- **2025年5月9日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 更新了腐蚀附魔部分。
- **2025年5月9日（本页）：** 更新了最佳专精部分。
- **2025年5月7日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了循环中关于四件套双重利用的措辞，使其作用和工作方式更加清晰。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 添加了可用代币购买的物品列表。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 添加了腐蚀附魔信息。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了天赋页面上默认的黑暗游侠大秘境构筑，主要是为了消除困惑。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年4月4日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 非常小幅的循环更新与说明。
- **2025年4月4日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了哨兵大秘境构筑以考虑欧恩哈拉之风存在bug的情况。
- **2025年4月2日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了大秘境天赋构筑。
- **2025年4月2日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了哨兵大秘境天赋构筑，添加了关于欧恩哈拉之风存在bug的说明。
- **2025年4月2日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 回退了昨天对单体构筑的改动。用新的大秘境构筑进行了更新。
- **2025年4月1日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 根据最近的模拟更新，更新了单体天赋构筑。
- **2025年3月30日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 添加了关于小型目标猎人可行性的说明。
- **2025年3月30日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 添加了关于小型目标猎人可行性的说明。
- **2025年3月29日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了大秘境饰品层级列表中克赞之眼的位置。
- **2025 年 3 月 25 日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了一行无论其他状态如何都使用爆炸射击的低优先级备选方案。
- **2025 年 3 月 25 日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 针对3月25日的在线修复进行了更新。
- **2025 年 3 月 25 日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 针对3月25日的更新进行了更新。
- **2025年3月25日（本页）：** 针对3月25日的更新进行了更新。
- **2025年3月18日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了推荐的大秘境模拟路线Pastebin。更新了大秘境天赋构筑。为其添加了关于乱射的说明。
- **2025年3月18日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了关于四件套和精准爆破的循环细节。在某些地方更新了措辞以使其更清晰。
- **2025年3月18日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋构筑。为其添加了关于乱射的说明。
- **2025年3月14日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新默认设置以假设拥有四件套。
- **2025年3月14日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新默认设置以假设拥有四件套。
- **2025年3月13日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 根据最新改动和APL优化进行了新的模拟，更新了饰品排行榜和毕业装备列表。
- **2025年3月7日（[解放安德迈页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 根据实际数据更新了构建。
- **2025年3月4日（[解放安德迈页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年3月4日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 输出循环改进。除非选择了特定天赋，否则已将夺命射击从AOE优先级和单体优先级中移除。
- **2025年3月4日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 添加了关于有无4件套时大秘境天赋变化的说明，并暂时更新了默认推荐。
- **2025年2月27日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 根据近期模拟工具的发展，更新了哨兵大秘境天赋配置。
- **2025年2月27日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 对与奥术射击、瞄准射击及爆炸射击使用相关的输出循环进行了重大更新。
- **2025年2月27日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 根据近期模拟工具的发展，更新了哨兵大秘境天赋配置。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年1月13日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 进一步区分了黑暗游侠和哨兵的单体输出循环差异。
- **2025年1月8日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 起手式小幅补充。
- **2024年12月27日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 更新以考虑黑暗游侠的Bug及其导致的强度飙升。
- **2024年12月27日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 黑暗游侠的起手式和输出循环小幅更新。
- **2024年12月27日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新以考虑黑暗游侠的Bug及其导致的强度飙升。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了关于瑟尔崔指环现在提升至物品等级658的内容。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月31日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 输出循环大改，特别是针对黑暗游侠。
- **2024年10月30日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（本页）：** 根据热修复更新了最佳专精部分。
- **2024年10月26日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 单体输出循环重大更新。
- **2024年10月26日（本页）：** 恢复了最佳专精部分。
- **2024年10月23日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 在一切仍处于Bug状态期间，更新为黑暗游侠作为默认推荐。
- **2024年10月22日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年10月10日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 对饰品排行榜进行了小幅更新。
- **2024年10月10日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了疯狂女王的指令的使用方式。
- **2024年10月8日（本页）：** 根据更新后的10月8日热修复更新了“最佳猎人专精”部分。
- **2024年10月7日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了射击黑暗游侠单体配置。
- **2024年10月2日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 新增了更具体的饰品使用信息。
- **2024年9月28日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了大秘境天赋配置——一点天赋的替换。
- **2024年9月28日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋配置——一点天赋的替换。
- **2024年9月27日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新了阿拉卡拉提示。
- **2024年9月24日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在AOE输出循环中添加了月蚀期间快速积攒火焰的策略。
- **2024年9月17日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 更新了毕业装备列表中的饰品选择。
- **2024年9月17日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于主动使用型饰品的起手式说明。
- **2024年9月15日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 基于新方法更新了猎人饰品排行榜，对于团本排行榜，还更新了指南其他页面中讨论的新单体推荐配置。
- **2024年9月15日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于主动使用型饰品的说明。
- **2024年9月14日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了团本AOE配置，并在几个首领战中将单体推荐换成了黑暗游侠。
- **2024年9月14日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 简化了单体输出循环，特别是瞄准射击的使用。
- **2024年9月14日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 在页面中添加了团本AOE配置。更新了单体配置。
- **2024年9月13日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 新增了关于双黎明之线衬里无效及其解决方法的说明。
- **2024年9月13日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 在有了英雄难度经验后，重新审视了每个首领的最佳配置并做出了一些改动。
- **2024年9月13日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 更新并澄清了一些提示。
- **2024年9月13日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 添加了哀恸之箭会重置快速火焰冷却时间的说明，更新了起手式。
- **2024年9月10日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 添加了关于移动速度宝石的说明，并总体上更新了宝石配置推荐。
- **2024年9月10日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 明确了多重射击在仅2个目标时就取代了奥术射击。简化了稳固集中输出循环。
- **2024年9月10日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 对单体天赋进行了小幅更新（一点天赋的改动带来0.2%的DPS提升）。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了点出哀恸之箭后的起手式。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 地心之战第1赛季的初步更新。
- **2024年9月9日（本页）：** 地心之战第1赛季的初步更新。
- **2024年9月3日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 地心之战第1赛季的初步更新。
- **2024年8月27日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 在赛季前毕业列表中新增了关于制造装备的说明。
- **2024年8月23日（本页）：** 重新引入了关于地心之战中最佳猎人专精的部分。
- **2024年8月22日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月22日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对地心之战进行更新。
- **2024年8月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对地心之战进行更新。
- **2024年8月22日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月22日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月22日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月22日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月22日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月22日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月22日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月22日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月22日（本页）：** 已针对地心之战进行更新。
- **2024年7月31日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 简化了稳固集中优化。这会影响单体起手式、输出循环和AOE输出循环。
- **2024年7月25日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了单体天赋配置。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月26日（[地心之战](<https://www.icy-veins.com/wow/marksmanship-hunter-the-war-within-pve-guide>)):** 更新了6月25日的改动内容。
- **2024年6月18日（[地心之战](<https://www.icy-veins.com/wow/marksmanship-hunter-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月29日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** 更新了宝石匠宝石推荐。
- **2024年5月20日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** 根据正式服强度等级更新了宝石匠宝石排名。
- **2024年5月17日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** 根据近期改动和新信息更新了宝石匠和齿轮宝石推荐。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月11日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 添加了一个不打断快速火焰的宏。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 为第4赛季进行了更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 为第4赛季进行了更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 为第4赛季进行了更新。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 已针对10.2.6版本更新。
- **2024年2月14日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐的大秘境默认天赋配置。
- **2024年2月14日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 更新了推荐的大秘境默认天赋配置。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（本页）：** 已为10.2.5版本进行更新。
- **2023年12月4日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋。
- **2023 年 11 月 27 日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对10.2版本进行更新
- **2023年11月6日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对10.2版本进行更新
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.2版本进行更新
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对10.2版本进行更新
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已针对10.2版本进行更新
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对10.2版本进行更新
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对10.2版本进行更新
- **2023年11月6日（本页）：** 已针对10.2版本进行更新
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 重构了页面并针对10.1.7版本进行了更新。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年6月27日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 额外的天赋改动，并将精钢陷阱设为单体默认天赋。
- **2023年6月27日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 更新了天赋配置。
- **2023年6月26日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了单体配置以适应新的数值调整。
- **2023年6月3日（本页）：** 更新了关于专精可行性的简介，并更新了优势与劣势。
- **2023年5月25日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐配置，将套装加成设为默认假设。
- **2023年5月22日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的腿部附魔，因为发现微光护甲片并不像之前认为的那样提供耐力。
- **2023年5月19日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了页面布局，并添加了一个不依赖冷却时间的替代配置。
- **2023年5月15日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 添加了关于精钢陷阱以及何时可能需要使用它的说明。
- **2023年5月12日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的食物和腿部附魔。
- **2023年5月12日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 阐明了AOE以及有4件套加成时单体天赋的变化。
- **2023年5月9日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 添加了关于配置在有4件套套装加成时如何变化的说明。
- **2023年5月8日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐的单体天赋配置，点出了稳固集中。
- **2023年5月4日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐的AOE/大秘境天赋配置。这很可能是一个临时改动，直到新的套装更加普及。
- **2023年5月4日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 更新了推荐的AOE天赋配置。这很可能是一个临时改动，直到新的套装更加普及。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 为10.1补丁进行了复查。
- **2023年5月1日（本页）：** 为10.1补丁进行了复查。
- **2023年4月11日（本页）：** 更新了专精排名以考虑新的削弱。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 在模拟更新以及发现新的强力组合后，更新了推荐的宝石。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 根据一系列热修复再次更新了推荐的宝石。
- **2023年3月21日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 根据3月21日的增益更新了黑曜石指环信息。
- **2023年3月21日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 针对10.0.7版本天赋大调整更新了天赋。
- **2023年3月21日（本页）：** 更新了不同伤害类型的专精排名。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/marksmanship-hunter-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年2月16日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 修复了天赋顺序中的一个问题。
- **2023年2月15日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境配置中的功能性天赋。
- **2023年1月30日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 对天赋替换进行了小幅更新。
- **2023年1月25日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 添加了一个增压乱射宏。
- **2023年1月25日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 在发现一个模拟Bug后，再次更新了天赋配置。为稳固集中添加了替代方案。将哀恸之箭的“替换”天赋改为了靶心。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 针对10.0.5版本的相关改动更新了页面。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 针对10.0.5版本的相关改动更新了页面。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 针对10.0.5版本的相关改动更新了页面。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月21日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 修复了关于为弹药类天赋需要替换哪个天赋的错误说明。
- **2023年1月17日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐的单体天赋配置。
- **2023年1月17日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 更新了推荐的单体天赋配置。
- **2023年1月6日（[宠物页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** 添加页面。
- **2023年1月4日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的药剂。
- **2022年12月23日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐配置，以反映无误愿景已修复且值得再次使用。
- **2022年12月23日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 天赋更新。
- **2022年12月18日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐天赋配置，以反映无误愿景存在Bug。
- **2022年12月16日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 添加了说明：配合九头蛇的撕咬，你不需要手动使用毒蛇钉刺。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 更新了最佳药水/药剂的推荐和描述。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 根据近期的增强，更新了推荐的单体天赋配置。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已针对巨龙时代第1赛季进行更新。
- **2022 年 12 月 11 日（本页）：** 针对最新的增强更新了专精可行性。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月24日（[升级](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/marksmanship-hunter-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/marksmanship-hunter-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/marksmanship-hunter-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[属性页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[统御圣所页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[天赋页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[法术页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（本页）：** 已为巨龙时代前夕更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月12日（[9.1 补丁分析](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** 更新了对所有盟约专属传说装备的看法，并在改动中加入了7月13日的猎人增强。
- **2021年6月10日（[9.1 补丁分析](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** 添加了关于温西尔专属传说装备的信息。
- **2021年5月12日（[9.1 补丁分析](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** 添加了关于4个新盟约专属传说装备的信息。
- **2021年4月25日（[9.1 补丁分析](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[达萨罗之战页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2019年8月23日（[永恒宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 为更多首领添加了提示。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 添加了针对乌纳特的射击技巧。
- **2019年5月1日（[风暴熔渣页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 添加了针对不眠者议会的射击技巧。
- **2019年4月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** 本页面已针对风暴熔炉进行审查，无需更改。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对风暴熔炉进行审查，无需更改。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年3月22日（[达萨罗之战页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了史诗难度吉安娜的技巧。
- **2019年2月20日（[达萨罗之战页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为史诗难度的多个首领添加了首领技巧。
  
  
  
  
  - 添加了风暴之墙阻截战（史诗）的技巧。
  - 添加了拉斯塔哈大王（史诗）的技巧。
  - 添加了机械师的魔像（史诗）的技巧。
  - 添加了丰裕之台（史诗）的技巧。
  - 添加了被选者议会（史诗）的技巧。
- **2019年2月5日（[达萨罗之战页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为玉火大师（史诗）添加了首领技巧并调整了天赋推荐。
- **2019 年 2 月 3 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了光明冠军和格林（史诗）的首领攻略提示。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了达萨罗之战中猎人射击的首领攻略提示。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** 为奥迪尔史诗难度中每个首领添加了更多针对射击的具体实用提示。
- **2018年9月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** 为奥迪尔的开放添加了更多内容。

显示更多

显示更少

:::

## 练级

在本页，你将找到我们的逐级猎人射击升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[猎人升级指南](<https://www.icy-veins.com/wow/hunter-leveling-guide>).

1.

### 至暗之夜的猎人射击升级指南

猎人射击的特点是其前置伤害和

优秀的范围伤害

能力。它在地下城中表现最为出色，但也是一个不错的任务

升级专精，核心思路是在敌人接近你之前将其击杀，通常使用一套

强力的[[spell:19434]]接[[spell:257044]]接[[spell:53351]]

连招。

选择一只野兽系（最好是 [鳞甲蜥蜴](<https://www.wow-petopia.com/family.php?id=scalehide>)）宠物

与 [[spell:34477]] 和 [[spell:263865]] 搭配使用。在

标记

尽可能多的小怪之前激活它们，通常使用[[spell:185358]]和

[[spell:257620]]，然后看着小怪蜂拥向你的宠物。利用

宠物

来自[[spell:263865]]的伤害减免，并利用射击的强力爆发

伤害，在小怪杀死你的宠物之前将其击杀。

这里有一个你可以用于[[spell:34477]]的实用宏。你可以

通过在聊天框输入'/m'来创建宏。新建一个宏，命名为"MD"，然后

把这段内容放进去：

```wow-macro
#showtooltip
/use 误导
/use 鳞墙
```

如果你使用的是拥有鳞甲护盾以外防御技能的其他宠物，

只需将'鳞甲护盾'替换为相应的技能名称即可。

1.1.

#### 升级装备选择

升级时，始终选择物品等级最高的

装备。此规则的唯一例外是，如果你有一个戒指或项链的

物品等级略低，但有两个副属性而不是一个。

在使用传家宝物品时，以及在其他装备之间做选择时，我们

建议尽可能优先堆叠暴击，因为它是我们最强的

属性。

1.2.

#### 至暗之夜升级实用消耗品

特别是在至暗之夜资料片中从80级升到90级时，

有许多消耗品可以帮助缓解这一过程，除了

“常规”PvE消耗品外，还有很多消耗品可以帮助你更轻松地完成升级过程。

- [[item:132516]] — 巨大的移动速度提升，在
  
  
  
  
  坐骑无法使用时也能使用，并且比地面坐骑快得多。
- [[item:109076]] — 让你从悬崖边滑翔出去并快速
  
  
  
  
  跨越遥远的距离。
- [[item:168412]] — 不要忘记这个坐骑装备，
  
  
  
  
  它能让你的坐骑在地面上更快。
- [[item:172063]] — 一份食物带来的惊人移动速度提升。
  
  
  
  
  食物。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，请随着等级提升，按照

随着你升级，逐点分配下方天赋树。练级

输出循环部分有一个滑块，可以显示你每个等级的输出循环。

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwGMwMGNWGAzgNAAAAAAAAwMmxM2mxMzYmBmMGmZbxMzMzMzMzsxMbDzMAAgxMzMAMjNsMDwGzsMDA"
}
```
:::

:::details 来源计算器编码
```
#+D-PqAgDDSNOLLGYTpBMMKiikeHRREoWHu1lcE-SJPOZYXqKCK8bro2AQzElBCEIooLGFO-AAAA-ZauYkAUgQJAZ4A-
```

:::

1.

### 升级循环

为了在升级和学习专精时保持简单，请使用滑块

选择你的等级，并观察升级输出循环随每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

1. **等级 46 起：**大量使用[[spell:34477]]将你产生的所有
   
   
   
   
   威胁转移给你的宠物。
2. **等级 78 起：**在你的第一个技能之后使用[[spell:1264902]]
   
   
   
   
   [[spell:19434]]之后立即使用[[spell:288613]]。一旦激活，
   
   
   
   
   这个按钮会出现在你百发百中按钮的位置。
3. **等级 53 起：**可用时使用[[spell:260243]]。将其放置在
   
   
   
   
   尽可能多的敌人上方的地面上！
4. **等级 43 起：**在大规模拉怪或困难精英怪时使用[[spell:288613]]
   
   
   
   
   怪物。
5. **等级 5 起：**在大量拉怪时使用[[spell:136]]来保持你的宠物
   
   
   
   
   健康。
6. **等级 27 起：**冷却完毕时使用[[spell:212431]]。
7. **等级 13 起：**可用时使用[[spell:257044]]。
8. **等级 11 起：**可用时使用[[spell:19434]]。 **等级 15 起：**务必消耗你的[[spell:260240]]层数来
   
   
   
   
   [[spell:185358]]/[[spell:257620]]上！
9. 连续使用[[spell:185358]]。
   
   
   
   
   **等级 10 起：**使用[[spell:257620]]
   
   
   
   
   如果有4个或更多目标时改为使用！
10. **等级 1 起：**使用[[spell:56641]]作为填充技能，并用于
    
    
    
    
    产生集中值。
11.

### 最佳升级宠物

所有宠物造成相同的伤害，但它们的实用性和特殊

能力。对于射击猎人来说，宠物相当弱，我们主要将它们

用作聚集小怪的"锚点"，而不是自己去聚怪。最适合此

用途的宠物是 [鳞甲蜥蜴](<https://www.wow-petopia.com/family.php?id=scalehide>)。它们

拥有一个持续1分钟的伤害减免技能[[spell:263865]]，你应该

将其绑定到你的[[spell:34477]]宏中。

野兽系宠物还自带[[spell:264667]]，这是一个嗜血效果。

当你战斗超过三十秒时，应尽可能频繁地使用此技能

秒时，应尽可能频繁地使用它。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 更新了传家宝属性建议。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 地心之战第1赛季的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月16日：** 修复了天赋顺序中的一个问题。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩猎人射击，使用最简单的输出循环、天赋树、属性优先级、装备配置等，且不牺牲性能。

1.

### 猎人射击基础

本节面向刚接触游戏或该职业的玩家，他们

无意参与史诗难度团队副本，或只是希望以更

简单直接的方式进行专精输出，而不被

为追求最优输出所需考虑的众多优先级和主动技能

所淹没。

射击非常适合那些喜欢狙击手玩法风格的玩家，拥有

比大多数专精更远的射程和大量的爆发性范围伤害。

射击的核心循环是通过你的来生成[[spell:260240]]

主要高伤害技能如[[spell:19434]]和[[spell:257044]]来产生

[[spell:260240]]，然后将这些[[spell:260240]]消耗在[[spell:185358]]

（单体目标）、[[spell:257620]]（3个以上目标，或2个以上且有

[[spell:470945]]时）或[[spell:466932]]

（在游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠英雄天赋时持续使用）。除了这个

循环外，你还有一个用于产生集中值和瞄准射击冷却缩减的填充技能

[[spell:56641]]，以及其他基本上按冷却使用的

技能，如[[spell:212431]]和[[spell:260243]]。

这里有两条快速的经验法则，可以帮助你在进行

该专精时得心应手。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_snipertraining.jpg>) **用光你的所有精确瞄准**
  
  
  
  
  每一发 [[spell:19434]] 和 [[spell:257044]] 都会赋予
  
  
  
  
  [[spell:260240]]，而我们希望用掉所有这些精确射击触发效果
  
  
  
  
  之前施放另一个瞄准射击。将它们消耗在奥术射击上，或在有多个目标时消耗在
  
  
  
  
  多重射击上。也要在快速火焰之前消耗它们，
  
  
  
  
  除非百发百中已激活。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_steadyshot.jpg>) **保持施法**
  
  
  
  
  尽可能多地施放技能比每次都按出完美技能更重要，
  
  
  
  
  每次点击按钮，而空闲等待时间是阻碍大多数玩家的最关键因素
  
  
  
  
  玩家偏离他们的伤害目标。[[spell:56641]] 是你填补空档的方式，而且
  
  
  
  
  它可以在移动中施放，所以没有理由浪费一个公共冷却。

1.

### 至暗之夜中猎人射击新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵单体天赋

2.1.

#### 猎人 射击单体天赋

这套配置是我们 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵单体输出构筑。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLmxMzYGMmmxgx2yMzMzMzMzswMLDmBAAMmZGDgZstBDwGzsNjB"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEGHIUWWYYaceiikssw0268ADFFHLruG-AEGPgkosw048ABFJNRV5CT2GX3H4QRS-AAAA-BEIMQYcAJRZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵地下城天赋

2.2.

#### 猎人射击地下城天赋构筑

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵大秘境构筑，以及

以AOE为主的玩法中的最优配置。它基于对真实

大秘境地下城环境的模拟，不仅看哪种配置能打出最高的DPS，还看

在团队中哪种配置能更快地通关地下城。有些配置能打出更多

AoE能力，但它们在AoE上获得的收益都不及单体输出的损失，反之

亦然。

2.3.

#### 猎人射击功能性天赋考量

- 你的'灵活'天赋点，按我们建议的可舍弃顺序为：
  
  
  
  
  可牺牲的：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]]只在某些地下城中有用，
    
    
    
    
    在其他地下城中则毫无价值。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmx2MmZGzwyYaGDmlttZmZmZmZmZhZWGmBAAwDMGDAzYDMAbMz2MG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMeEJRZhpx5BCKSaiqyFmMttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 猎人射击基础输出循环

2.4.

#### 猎人射击基础输出循环

请将其视为最重要的施法优先级列表。如果不确定，

直接施放优先级最高的法术即可。你的循环中不应有

任何'空窗期'。与其犹豫1秒再施放正确的法术，

而不是"思考"1秒钟然后再施放正确的法术。随着你技术的提升，这种

优先级会成为你的第二天性。

1. 施放[[spell:212431]]。
2. 施放[[spell:260243]]。确保将其放置
   
   
   
   
   在合适的位置以获得最佳AoE覆盖。
3. 可用时施放[[spell:288613]]。这是你的主要冷却技能，
   
   
   
   
   它主要提升你技能的伤害，具体来说是
   
   
   
   
   在激活期间你可以施放的[[spell:19434]]和[[spell:257044]]的数量。
   
   
   
   
   在你打算施放[[spell:257044]]之前使用它。当
   
   
   
   
   [[spell:204089]]天赋被使用时（基本上是全程），尽量
   
   
   
   
   将你战斗中的最后一次百发百中留到目标生命值低于20%时使用。
4. 施放 [[spell:53351]] 以在目标生命值低于20%时消耗 [[spell:260240]]
   
   
   
   
   生命值。
5. 在拥有 [[spell:260240]] 时施放 [[spell:185358]]。这通过
   
   
   
   
   你角色周围的蓝色箭头图形来指示，并且在每次
   
   
   
   
   单独的 [[spell:19434]] 和 [[spell:257044]] 之后必定触发。在3个及以上目标时，施放
   
   
   
   
   [[spell:257620]] 代替，或在2个及以上目标时配合
   
   
   
   
   [[spell:470945]].
6. 施放 [[spell:257044]]。
7. 施放 [[spell:1264902]]。一旦激活急速射击，此技能会替换你的 [[spell:288613]]
   
   
   
   
   按钮，并且只能使用一次。它会赋予你一次
   
   
   
   
   瞬发的 [[spell:19434]]，通常紧接着就会射出。
8. 施放 [[spell:19434]]。
9. 当你无法施放以上任何技能时，施放 [[spell:56641]] 作为填充技能。

2.4.1.

##### 巅峰天赋： ![Take Aim Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_efficiency.jpg>) 蓄力瞄准

你的顶级天赋对你的玩法没有影响。它们只是被动地提高你的

被动造成伤害，最佳的利用方式是执行“基线”

循环能最好地利用它们。

2.4.2.

##### 第2赛季套装

至暗之夜 第2赛季套装对我们的循环有细微影响。它会

延长你的 [[spell:212431]] 的持续时间（因此也增加伤害），

并使那些跳数每次减少 [[spell:19434]] 和

[[spell:257044]] 0.5秒的冷却时间。在两个或更多目标时，由于

[[spell:473520]] 会为你连续提供两个 [[spell:212431]]，我们倾向于

将它们施放在两个不同的目标上（除非有优先目标），

因为我们希望最大化这个冷却缩减效果。伤害是

与在1个目标上施放两个相同的，但由于冷却缩减随

通过 <em>跳数</em>缩放，分散施放更好。

### 射击 猎人 防御技能

2.5.

#### 射击 猎人 的防御技能

[[spell:109304]]是你主要的自我治疗技能，冷却时间为1分钟。

当你的生命值低于50%时使用它，以减轻治疗者的压力！

[[spell:186265]]是你的免疫技能。它可以用来完全

免疫大多数针对你的法术的伤害和效果。当你被指派使用时，

或者在危急时刻，如果你担心即将到来的机制会杀死你，就使用它！

它也能提供30-50%的减伤，尽管它通常不用于

单纯的减伤目的。

[[spell:264735]]是我们除了灵龟守护外最强的防御技能，

提供30-40%的减伤，有2层充能，每层冷却时间为1.5分钟。

用它来减免高伤害机制造成的伤害。要最优地使用这个

技能，就需要 **提前**在大量伤害到来之前使用它。

[[spell:5384]]是一个非常独特的猎人技能。它可以用来消除

仇恨和战斗，也可以用来打断针对你的施法。如果你看起来已经死亡，

怪物通常会在施法中途停止施法！

拥有[[spell:459517]]天赋时，它还会驱散你身上的所有中毒

和疾病效果。

### 射击 猎人 属性优先级

2.6.

#### 射击 猎人 的属性优先级

射击 猎人 的一般属性优先级如下所示。

关于本页呈现内容的更多信息，请查看我们的主要

[属性优先级页面](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>).

暴击

精通

全能

急速

暴击是我们最强的属性，精通紧随其后。在理想情况下，

你拥有的每件装备上都有暴击，精通作为第二属性。

全能明显落后于精通。

### 暴风雪战斗助手

2.7.

#### 战斗助手 & 单键模式

游戏提供了游戏内“战斗助手”的选项，它有两种

模式：一个会建议下一个施放法术的循环助手，以及一个

「一键模式」，它会在你进行时自动为你执行这套输出循环

只是反复按一个键，它会自动为你执行这个循环。

这些工具对于新手来说可能很有价值，因为它们提供了一个合理的

“最低”表现水平。对于 射击 猎人，仅使用

与完美操作相比，使用循环助手会损失约6-10%的DPS（这

在此基础上再使用单键模式，总损失会达到

损失约为13-15%。

显然，使用这些工具无法达到巅峰表现，但如果你愿意为了

操作简便而承受上述 DPS 损失，这值得考虑。

不要让游戏里、论坛上或 Discord 里的任何人

告诉你使用这些工具有什么内在的不对！

暴风雪 创建它们是有原因的，而游戏是为了好玩，无论

对你来说这意味着什么。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月22日：** 急速 火焰 不再需要先消耗精确瞄准。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 将百发百中加入新手优先级列表。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月27日：** 进一步简化了循环。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 地心之战第1赛季的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月14日：** 更新了推荐的大秘境默认天赋配置。
- **2024年1月15日：** 已为10.2.5版本进行更新。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月27日：** 更新了天赋配置。
- **2023年5月4日：** 更新了推荐的AOE天赋配置。这很可能是一个临时改动，直到新的套装更加普及。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 针对10.0.5版本的相关改动更新了页面。
- **2023年1月17日：** 更新了推荐的单体天赋配置。
- **2022年12月23日：** 天赋更新。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到《魔兽世界》12.1.5版本中 射击 猎人 的最佳天赋。我们还针对团队副本或大秘境等不同类型的内容提供了默认天赋配置。如果你开启了战争模式进行游戏，我们也为你准备了PvP天赋。

1.

### 射击 猎人 的最佳 至暗之夜 天赋

射击 在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 所有内容中都使用 哨兵，无一例外。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 稍微更肉一些，但 哨兵 伤害更高，而且远

更容易上手。我们在下面为那些偏好黑暗游侠的玩家提供了构筑

玩法风格或主题幻想。

- 单体目标： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 在所有情况下都被使用，尽管它
  
  
  
  
  比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 略微不那么肉。它只是在
  
  
  
  
  每项指标上都表现更好，而且也更容易上手。
- AOE：就像在单体目标中一样， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 是到处通用的选择。
  
  
  
  
  它在每个目标数量上都有最好的DPS，而且更容易上手。虽然它比
  
  
  
  
  生存能力略逊于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 稍微差一点的生存能力，但这在
  
  
  
  
  冲击绝对最高层数钥匙之前不会显现，即便如此，你通常也能依靠你的
  
  
  
  
  队友来帮助你存活，从而可以倾泻 哨兵 优越的DPS。

1.1.

#### 关于坚韧与狡诈的取舍

[[spell:474456]] 和狡诈是我们版本的宠物。你可以在

5%额外生命值加3%伤害减免，或8%移动速度加

[[spell:53271]] 之间选择，后者是一个你可以对自己或对

任何其他人使用的自由效果。两者对你的伤害都没有任何帮助。

我们的配置默认使用 [[spell:474456]]。在12.1.5版本中，选择坚韧或狡诈是DPS

选择坚韧或狡诈会造成损失，幅度为0.6%至1.7%，具体取决于

具体情况，损失幅度在0.6%到1.7%之间。如果你在做任何被认为具有“竞争性”

的内容——在我们看来，就是任何你认为有挑战性的内容——

那么这个损失是值得承受的。话虽如此，如果你只是想造成最大伤害，

以下是每个配置需要替换的天赋：

- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 单体目标 -** 换到 [[spell:378769]] 以
  
  
  
  
  获得约0.6%的DPS提升。
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 团队副本顺劈 -** 换到
  
  
  
  
  [[spell:471428]] 以获得约1.3%的DPS提升。
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 大秘境与地下堡 -** 换到
  
  
  
  
  [[spell:471428]] 以获得约1.4%的DPS提升。
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 单体目标 -** 换到
  
  
  
  
  [[spell:389019]] 以获得约1.4%的DPS提升。
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 大秘境与地下堡 -** 换到
  
  
  
  
  [[spell:389019]] 以获得约1.7%的DPS提升。

**快速开始导入代码：**

:::talents 射击 单体目标 - 哨兵
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGzYZAjZwGAAAAAAAAYGzYmFzYmZMDGTzYwYbZmZmZmZmZWYmlBzAAAGzMjBwM22gBYjZ2mxAA"
}
```
:::

:::talents 射击 团队副本AOE/顺劈 - 哨兵
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGQmBbAAAAAAAAgZMjZWMjZmxMYMNjBz222MzMzMzMzswMLDzAAAMmZGAMjtNYA2YmtZMA"
}
```
:::

:::talents 射击 大秘境 - 哨兵
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGQmBbAAAAAAAAgZMzMjtZMzMmhlx0MGMLbbzMzMzMzMzCzsMMDAAgHYMGAmxGYA2YmtZMA"
}
```
:::

:::talents 射击 地下堡 - 哨兵
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGzYZAjZwGAAAAAAAAYGzMzgxMzYmhx0wgZZbbmZmZmZmZWwsNMDAAwMjxAwM2wyMAbMz2MG"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

哨兵

单体目标

推荐

团队副本 AoE/顺劈

推荐

秘境+

推荐

地下堡

推荐

黑暗游侠

单体目标

秘境+

地下堡

### 天赋方案 0-0

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵单体天赋

这套配置是我们 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 单体目标配置。它保留了 [[spell:260243]] 和 [[spell:212431]]，第2赛季套装就是围绕它们构建的，并专注于生成和消耗 [[spell:260240]]。在团队副本中，只要需要纯单体目标，我们建议使用此配置。

### 天赋方案 0-1

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 团队副本AOE/顺劈天赋配置

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 针对顺劈密集型战斗的配置。它围绕 [[spell:470945]] 构建，选取了如九头蛇和 [[spell:378913]] 等高效的AOE天赋，在本质上只是执行单体循环的同时打出优秀的顺劈伤害。由于团队副本顺劈内容如此之多，这就是你在大部分战斗中会使用的配置。

### 天赋方案 0-2

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 大秘境天赋配置

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 针对大秘境及其他以AOE为核心内容的配置。它基于模拟真实大秘境副本中的条件，不仅看什么能打出最多DPS，更看什么在团队中能真正更快地通关副本。有些配置能打出更多AOE伤害，但它们在AOE上获得的收益都少于在单体上损失的，反之亦然。

我们在AOE中使用 [[spell:257621]]，将 [[spell:185358]] 换成 [[spell:257620]] 以使我们的技能造成AOE伤害。你也可以在那些绝大部分是单体但仍偶尔有顺劈和爆发AOE的团队副本战斗中使用此配置，尽管这不是一个可以轻率做出的决定，因为凑AOE数据很少是提高团队成功率的最有效方式。

1.5.

#### 猎人射击功能性天赋考量

- 你的“灵活”天赋点，按我们建议的“最可牺牲”顺序为：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] 只在某些副本中有用，在其他副本中毫无价值。

### 天赋方案 0-3

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 地下堡天赋配置

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 针对 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)的构建。它与我们的大秘境天赋构建类似，但在职业天赋树的选择上有所不同，更适合由宠物坦怪的单人游玩。

### 天赋方案 1-0

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 单体目标天赋

这套配置是我们 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 单体目标配置，用于那些绝大部分为纯单体、没有聚集小怪或AOE机会的首领。

### 天赋方案 1-1

1.8.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 大秘境天赋构建

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 用于大秘境和其他以 AoE 为焦点的内容的构建。它基于模拟真实大秘境副本中的条件，不仅看什么能打出最高的 DPS，还看在队伍中实际什么能更快地通关副本。有些构建能打出更高的 AoE 伤害，但它们在 AoE 上获得的收益都比不上在单体上损失的，反之亦然。

1.9.

#### 猎人射击功能性天赋考量

- 你的“灵活”天赋点，按我们建议的“最可牺牲”顺序为：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] 只在某些副本中有用，在其他副本中毫无价值。

### 天赋方案 1-2

1.10.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 探宝天赋构建

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 用于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)的构建。它与我们的大秘境天赋构建类似，但在职业天赋树的选择上有所不同，更适合由宠物坦怪的单人游玩。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLmxMzYGMmmxgx2yMzMzMzMzswMLDmBAAMmZGDgZstBDwGzsNjB"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEGHIUWWYYaceiikssw0268ADFFHLruG-AEGPgkosw048ABFJNRV5CT2GX3H4QRS-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLmxMzYGMmmxgZbbbmZmZmZmZWYmlhZAAAGzMDAmx2GMAbMz2MG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEGHIUWWYYaceiikssw0268ADFFHLruG-AEFNeEJRZhpx5BCKSaiqyFmMttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmx2MmZGzwyYaGDmlttZmZmZmZmZhZWGmBAAwDMGDAzYDMAbMz2MG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMeEJRZhpx5BCKSaiqyFmMttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmBjZmxMDjphBzy22MzMzMzMzsgZbYGAAgZGjBgZshlZA2YmtZMA"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHLLMMNOPRRSTWWYaeffgiikoSVXD-AEFMeEJRZhpx5BCKSaiqyF2MttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYWAAAAAAAAAzYGzsYGzMjZwYaGDGbLzYmZmZmZWYmlBDAAwYmZMzMDIbwAsxMbzMD"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEGHIUWWYYaceiikssw0268ADFFHLruG-AEGPgksw048ABFJNRV5CT2Wn3H4QxRS-AAAA-AGIYgow4ApyCTD-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYWAAAAAAAAAzYmZGbzYmZMDLjpZMYW2MjZmZmZmZhZWGmBAAwDMGzMzMgAGgNmZZGD"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMiksw048ABFJNRV5CTm2Wn3HoQRS-AAAA-AGIYgow4ApyCTD-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYWAAAAAAAAAzYmZGMmZGzMMmGGMLbmxMzMzMzsgZbYGAAgZGjZmZGQwyMAbMzyMG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHLLMMNOPRRSTWWYaeffgiikoSVXD-AEFMiksw048ABFJNRV5Cbm2Wn3HoQRS-AAAA-AGIYgow4ApyCTD-
```

:::

上面列出的构建是热门推荐，

涵盖了适合每种终局内容风格的各种不同配装。

每个天赋构建都会有其自己的循环，并且还可以针对

特定类型的内容进一步调整，以更好地造福你的队伍。

1.

### 全知典籍

万卷典籍是 至暗之夜 中引入的“借用力量”系统，

[12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)在完成一段简短的任务线后，

会提供一些中等强度的自定义选项。

其中一些加成会影响你的伤害输出，但也有防御

和机动性选项可供选择。

你的典籍进度会带入第2赛季。选择这些加成：

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279609]]。这个是最
  
  
  
  
  灵活的，可能会随着你装备的属性需求而改变，就像你的合剂
  
  
  
  
  或武器附魔。暴击是一个安全的“永远不会差”的选择，但如果你有大量
  
  
  
  
  （1300+）的
  
  
  
  
  ，你可能会考虑改用精通（或者用模拟器模拟一下）。
- [[spell:1279614]]

1.

### 巅峰天赋： ![Take Aim Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_efficiency.jpg>) 蓄力瞄准

至暗之夜 引入了新的巅峰天赋，在 80 至 90 级之间解锁。

射击 获得：

1. [[spell:1273132]]
2. [[spell:1273129]]
3. [[spell:1273128]]

[[spell:1273132]] 使 [[spell:257044]] 的伤害提高25%，并且每一发

它发射的射击会使 [[spell:19434]] 的冷却时间缩短0.5秒，整个引导下来

持续施法期间最多5秒。[[spell:1273129]]提高暴击

技能的暴击伤害提高5%，远程技能的伤害提高3%，

在第二点时提升至10%和6%。[[spell:1273128]] 使

[[spell:466872]]也会提高你下一次[[spell:257044]]的伤害

对目标造成的伤害提高20%。

1.

### 射击 猎人 英雄天赋

英雄天赋在71级解锁，是互斥的天赋树，你可以

选择会略微改变玩法和视觉效果。射击 猎人 可以选择

之间 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 会将你天赋中的 [[spell:53351]] 技能替换为

[[spell:466932]]，该技能造成大量伤害。除了对生命值高于80%或低于20%的目标可以免费

可对生命值高于80%或低于20%的目标使用（冷却时间为10秒），你

还会经常触发 [[spell:378769]]，让你可以在任何时候对任何目标

使用它。[[spell:257044]] 必定触发，而 [[spell:19434]]

有20%的几率使你的下一个 [[spell:19434]] 触发一次。

当你开启 [[spell:288613]] 时，百发百中按钮会变成

[[spell:392060]]，这是一个非常强大的技能，使用后还会免费触发一次

[[spell:466932]] 使用时触发。我们一旦没有

[[spell:466932]] 触发即将到来时，通常在

[[spell:257044]] → [[spell:466932]] 连招之后立即施放它。

在防御方面， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 提供 [[spell:430709]]，这

简直太棒了，因为它让我们能极其轻松地获得

[[spell:264735]]，几乎全程可用。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 是我们最简单的英雄天赋，在玩法

趣味性或复杂度方面几乎没有任何增加，只是将 [[spell:466872]] 替换为

[[spell:1253601]]，这个技能在各方面都更加强大。此外，

当你激活 [[spell:288613]] 时，百发百中按钮本身会

变成 [[spell:1264902]]，这是一个使用后造成大量伤害的填充技能。

使用。我们只能使用一次它，所以在单体目标上，我们会在剩余约5

秒时施放[[spell:288613]]（因为它的弹射在单体目标上需要很长时间才能完成），而在范围伤害上，则在百发百中结束前立即施放（因为它的弹射在范围伤害上很快就能完成）。

在防御方面， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 为我们提供 [[spell:450373]]，它几乎

持续触发，并提供大量被动耐打能力。

1.

### PvP天赋（战争模式）

**这些选择适用于开启战争模式的开放世界PvE内容，不适用于

真正的PvP。**

战争模式为你在开放世界中提供了多项好处。

- 户外世界中启用的PvP天赋。
- 在最高等级时，世界任务奖励至少提高 10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于开启战争模式对升级和PvE内容的好处，

建议启用该功能，以在满级时最大化你的升级速度和奖励。

但是，你将被标记为开放世界PvP状态，并且

在升级或进行世界任务时存在被“偷袭”的可能性。

- [[spell:1219162]]允许你在移动时施放[[spell:19434]]
  
  
  
  
  在[[spell:186257]]期间，它延长了较慢的后半段
  
  
  
  
  延长4秒。
- [[spell:203235]] 是升级和开放世界内容中非常有价值的加速效果。
  
  
  
  
  世界内容。
- [[spell:1217102]]使你所有射击的射程提高30%
  
  
  
  
  在[[spell:288613]]和[[spell:260243]]期间，这对于大型精英怪很有用
  
  
  
  
  尤其有用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月22日：** 大秘境和地下堡的 哨兵 配装现在选择命中目标而非黑曜石箭头。
- **2026年8月22日：** 大秘境和地下堡的 哨兵 配装现在选择开放 火焰 而非观星者。
- **2026年8月18日：** 更新了团队副本构筑的效用天赋。
- **2026年8月17日：** 万卷集配置现在选择虚空污染之壳而非自我修复。
- **2026年8月16日：** 大秘境和地下堡的 哨兵 配装现在选择观星者而非开放 火焰，由于急速 火焰 打断引导现在更频繁地消耗精确瞄准，这是一个小幅提升。
- **2026年8月12日：** 更新了地下堡配装的职业树，点出了牢不可破的羁绊（为了宠物）。
- **2026年8月12日：** 地下堡构筑现在选择紧急药膏而非荒野医术。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 阐明了英雄天赋构筑指南。
- **2026年6月17日：** 根据实际数据优于模拟结果，更新了推荐的第一周卷集符文。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026 年 5 月 21 日：** 更新了哨兵团队副本AOE构筑的指南。
- **2026年5月7日：** 更新了哨兵团队副本AOE构筑。
- **2026年5月6日：** 更新了哨兵大秘境构筑。在所有大秘境场景中仍然非常差。
- **2026年5月4日：** 针对数值调整进行了更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 更新了针对Vaelgor和Ezzorak的天赋构筑说明。
- **2026年3月25日：** 更新了基础团队副本AOE构筑。
- **2026 年 3 月 22 日：** 将哨兵大秘境构筑中哨兵天赋树里的暮光安魂曲替换为潜行与突袭，模拟表现相同，但能带来极小的机动性收益。
- **2026年3月19日：** 更新了地下堡构筑。
- **2026 年 3 月 17 日：** 为多头蛇构筑添加了简单说明。更新了多头蛇构筑以增加更多AOE。修复了单体构筑的错误。
- **2026年3月16日：** 更新了哨兵大秘境构筑。
- **2026年3月3日：** 更新了天赋构筑并添加了黑暗游侠构筑。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年1月23日：** 更新了80级的属性递减收益数值。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月2日：** 更新了黑暗游侠大秘境天赋构筑，特别是功能性天赋选择。
- **2025年8月27日：** 扩展了关于1.5分钟和1分钟构筑的理由说明。
- **2025年8月26日：** 更新了关于黑暗游侠大秘境中在鹰眼视觉和精准射击之间切换的说明。移除了关于专注瞄准的说明，因为强化流线型即使在纸面上也是等效的，实际表现更好。更新了团队副本AOE构筑。
- **2025 年 8 月 25 日：** 将单体目标天赋默认选择更新为强化流线型而非专注瞄准。
- **2025年8月12日：** 黑暗游侠的极小单体天赋更新。
- **2025年8月11日：** 更新了大秘境天赋构筑推荐。
- **2025年8月8日：** 更新了团队副本单体循环的默认功能性天赋选择。
- **2025年8月7日：** 将S3单体构筑更新为与S2四件套构筑相同！
- **2025年8月6日：** 黑暗游侠S2四件套天赋和大秘境职业天赋树更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月26日：** 添加了关于齐射与欧恩哈拉之风的说明。
- **2025年5月17日：** 更新了团队副本AOE构筑以点出乱射，因为团队副本中的大多数AOE都是非常短暂的。
- **2025年5月15日：** 更新了哨兵大秘境构筑以点出欧恩哈拉之风，因为有证据表明它已被修复，现在在大秘境中能正常工作。
- **2025年4月21日：** 更新了天赋页面上默认的黑暗游侠大秘境构筑，主要是为了消除困惑。
- **2025年4月4日：** 更新了哨兵大秘境构筑以考虑欧恩哈拉之风存在bug的情况。
- **2025年4月2日：** 回退了昨天对单体构筑的改动。用新的大秘境构筑进行了更新。
- **2025年4月1日：** 根据最近的模拟更新，更新了单体天赋构筑。
- **2025年3月30日：** 添加了关于小型目标猎人可行性的说明。
- **2025年3月25日：** 针对3月25日的在线修复进行了更新。
- **2025年3月18日：** 更新了大秘境天赋构筑。为其添加了关于乱射的说明。
- **2025年3月14日：** 更新默认设置以假设拥有四件套。
- **2025年3月4日：** 添加了关于有无4件套时大秘境天赋变化的说明，并暂时更新了默认推荐。
- **2025年2月27日：** 根据近期模拟工具的发展，更新了哨兵大秘境天赋配置。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月27日：** 更新以考虑黑暗游侠的Bug及其导致的强度飙升。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月23日：** 在一切仍处于Bug状态期间，更新为黑暗游侠作为默认推荐。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024 年 10 月 7 日：** 更新了射击黑暗游侠单体配置。
- **2024年9月28日：** 更新了大秘境天赋配置——一点天赋的替换。
- **2024年9月14日：** 在页面中添加了团本AOE配置。更新了单体配置。
- **2024年9月10日：** 对单体天赋进行了小幅更新（一点天赋的改动带来0.2%的DPS提升）。
- **2024年9月9日：** 地心之战第1赛季的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月25日：** 更新了单体天赋配置。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月14日：** 更新了推荐的大秘境默认天赋配置。
- **2024年1月15日：** 已为10.2.5版本进行更新。
- **2023年12月4日：** 更新了大秘境天赋。
- **2023年11月27日：** 更新了大秘境天赋。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 重构了页面并针对10.1.7版本进行了更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月27日：** 额外的天赋改动，并将精钢陷阱设为单体默认天赋。
- **2023年6月26日：** 更新了单体配置以适应新的数值调整。
- **2023年5月25日：** 更新了推荐配置，将套装加成设为默认假设。
- **2023年5月19日：** 更新了页面布局，并添加了一个不依赖冷却时间的替代配置。
- **2023年5月15日：** 添加了关于精钢陷阱以及何时可能需要使用它的说明。
- **2023年5月12日：** 阐明了AOE以及有4件套加成时单体天赋的变化。
- **2023年5月9日：** 添加了关于配置在有4件套套装加成时如何变化的说明。
- **2023年5月8日：** 更新了推荐的单体天赋配置，点出了稳固集中。
- **2023年5月4日：** 更新了推荐的AOE/大秘境天赋配置。这很可能是一个临时改动，直到新的套装更加普及。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月21日：** 针对10.0.7版本天赋大调整更新了天赋。
- **2023年2月15日：** 更新了大秘境配置中的功能性天赋。
- **2023年1月30日：** 对天赋替换进行了小幅更新。
- **2023年1月25日：** 在发现一个模拟Bug后，再次更新了天赋配置。为稳固集中添加了替代方案。将哀恸之箭的“替换”天赋改为了靶心。
- **2023年1月24日：** 针对10.0.5版本的相关改动更新了页面。
- **2023年1月21日：** 修复了关于为弹药类天赋需要替换哪个天赋的错误说明。
- **2023年1月17日：** 更新了推荐的单体天赋配置。
- **2022年12月23日：** 更新了推荐配置，以反映无误愿景已修复且值得再次使用。
- **2022年12月18日：** 更新了推荐天赋配置，以反映无误愿景存在Bug。
- **2022年12月16日：** 添加了说明：配合九头蛇的撕咬，你不需要手动使用毒蛇钉刺。
- **2022年12月11日：** 根据近期的增强，更新了推荐的单体天赋配置。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面中，你将学习如何在单目标和多目标情况下优化你的 射击 猎人 的输出循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以最大化你的DPS。所有内容均已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 射击 猎人 玩法与输出循环指南

欢迎来到我们的 射击 猎人输出循环页面。在本

页面中，你将找到关于在团队副本和大秘境场景中实际操作该专精所需了解的一切

内容。

这里的循环，除了更具体的起手式外，是以

**条件优先级列表**的形式呈现的。基本上，对于你施放的每一个技能，

你应该施放你能施放的最高优先级技能，**前提是其

条件已满足。** 施放该技能后，你应该从

优先级列表的顶部重新开始，并重复此过程。

下面的按钮可用于在精选的 **单体目标**

和 **AoE/大秘境** 配装方案中，额外提供一套 **九头蛇顺劈** 配装方案，位于

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 之下。你还可以使用下方的开关来添加或移除

你可能也在使用的单个天赋。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠

单体目标

群体伤害

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

九头蛇顺劈

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:212431]]

[[spell:53351]]

[[spell:260243]]

[[spell:473520]]

[[spell:1301406]]

[[spell:257621]]

[[spell:470945]]

[[spell:1296634]]

[[spell:378769]]

### 单体输出循环

1.1.

#### 射击 猎人 单目标起手

确保 [[spell:257284]] 在你的主目标身上生效。

---

**适用条件：黑暗游侠（启用）。**

[[spell:19434]]

2.5s

拉怪

[[spell:466932]]

**适用条件：爆炸射击（启用）。**

[[spell:212431]]

**适用条件：爆炸射击（启用）；不稳定扳机（启用）。**

[[spell:212431]]

**适用条件：弹幕（启用）。**

[[spell:260243]]

[[spell:288613]]

[[item:241288]]

[[spell:19434]]

[[spell:466932]]

**适用条件：哨兵（启用）。**

[[spell:19434]]

2.5s

拉怪

**适用条件：爆炸射击（启用）。**

[[spell:212431]]

**适用条件：爆炸射击（启用）；不稳定扳机（启用）。**

[[spell:212431]]

**适用条件：弹幕（启用）。**

[[spell:260243]]

[[spell:288613]]

[[item:241288]]

[[spell:257044]]

[[spell:185358]]

[[spell:19434]]

[[spell:185358]]

---

1. **适用条件：黑暗游侠（启用）。** 在战斗开始前约2.5秒施放 [[spell:19434]]。
2. **适用条件：黑暗游侠（启用）。** [[spell:466932]]
3. **适用条件：黑暗游侠（启用）；爆炸射击（启用）。** [[spell:212431]]
4. **适用条件：黑暗游侠（启用）；爆炸射击（启用）；不稳定扳机（启用）。** [[spell:212431]]
5. **适用条件：黑暗游侠（启用）；弹幕（启用）。** [[spell:260243]]
6. **适用条件：黑暗游侠（启用）。** [[spell:288613]]，与你的药水、主动饰品、种族技能等一起使用。
7. **适用条件：黑暗游侠（启用）。** [[spell:19434]]
8. **适用条件：黑暗游侠（启用）。** [[spell:466932]]
9. **适用条件：黑暗游侠（启用）。** 继续按照下面描述的优先级列表进行。
10. **适用条件：哨兵（启用）。** 在战斗开始前约2.5秒施放 [[spell:19434]]。
11. **适用条件：哨兵（启用）；爆炸射击（启用）。** [[spell:212431]]
12. **适用条件：哨兵（启用）；爆炸射击（启用）；不稳定扳机（启用）。** [[spell:212431]]
13. **适用条件：哨兵（启用）；弹幕（启用）。** [[spell:260243]]
14. **适用条件：哨兵（启用）。** [[spell:288613]]，与你的药水、主动饰品、种族技能等一起使用。
15. **适用条件：哨兵（启用）。** [[spell:257044]]
16. **适用条件：哨兵（启用）。** [[spell:185358]]
17. **适用条件：哨兵（启用）。** [[spell:19434]]
18. **适用条件：哨兵（启用）。** [[spell:185358]]
19. **适用条件：哨兵（启用）。** 继续按照下面描述的优先级列表进行。

1.2.

#### 射击 猎人 单目标优先级列表

以下是描述 射击 猎人 最佳单目标输出循环的优先级系统。

1. **适用条件：哨兵（启用）；爆炸射击（启用）；不稳定扳机（启用）。** 尽量卡着冷却时间施放 [[spell:212431]]。得益于 [[spell:473520]]，你可以连续施放两次，并且应该这样做。
2. **适用条件：哨兵（启用）；爆炸射击（启用）；战术换弹（启用）。** 尽量卡着冷却时间施放 [[spell:212431]]，除非 [[spell:194595]] 已经在生效。
3. **适用条件：哨兵（启用）；弹幕（启用）。** 尽量卡着冷却时间施放 [[spell:260243]]。
4. **适用条件：哨兵（启用）。** 尽量卡着冷却时间施放 [[spell:288613]]，但将整场战斗中的最后一次留给30层 [[spell:204089]]。如果 [[spell:212431]] 即将冷却完毕，可以延迟最多15秒，以便在进入 [[spell:288613]] 之前立刻施放爆炸射击。
5. **适用条件：哨兵（启用）。** 在你按下 [[spell:288613]] 之前，切换到一个尚未带有 [[spell:1253601]] 的目标—— <em>点击查看详情</em>
   
   
   
   
   [[spell:470943]] 使 [[spell:288613]] 在你按下它时对你当前选中的目标施加 [[spell:1253601]]，所以对已经带有标记的目标按下 [[spell:288613]] 会浪费它。
6. **适用条件：哨兵（启用）。** 在 [[spell:288613]] 剩余约5秒时施放 [[spell:1264902]]。
7. **适用条件：哨兵（启用）；九头蛇形态（未启用）。** 在 [[spell:288613]] 期间，当你没有 [[spell:260240]] 时施放 [[spell:19434]]。
8. **适用条件：哨兵（启用）；九头蛇形态（启用）。** 在 [[spell:288613]] 期间，当你没有 [[spell:260240]] 且只有一个目标存活时施放 [[spell:19434]]。
9. **适用条件：哨兵（启用）；九头蛇形态（未启用）。** 如果你没有 [[spell:260240]] 可消耗，或者 [[spell:288613]] 正在生效，则尽量卡着冷却时间施放 [[spell:257044]]。
10. **适用条件：哨兵（启用）；九头蛇形态（启用）。** 如果你没有 [[spell:260240]] 可消耗，或者 [[spell:288613]] 正在生效，或者有多个目标存活，则尽量卡着冷却时间施放 [[spell:257044]]。
11. **适用条件：夺命射击（启用）；哨兵（启用）。** 施放[[spell:53351]]以消耗[[spell:260240]]。
12. **适用条件：夺命射击（启用）；夺命射击（启用）；哨兵（启用）。** 每当[[spell:378769]]触发时，施放[[spell:53351]]以消耗[[spell:260240]]。
13. **适用条件：哨兵（启用）；九头蛇形态（启用）。** 在多于一个目标时，施放[[spell:257620]]而非[[spell:185358]]以消耗[[spell:260240]]，除非你在集火一个优先目标。
14. **适用条件：哨兵（启用）。** 施放[[spell:185358]]以消耗[[spell:260240]]。
15. **适用条件：哨兵（启用）。** 施放[[spell:19434]]，冷却完毕即用，除非你在集火一个优先目标，否则优先选择带有[[spell:1253601]]的目标。
16. **适用条件：哨兵（启用）。** 施放[[spell:1264902]]。
17. **适用条件：哨兵（启用）。** 施放[[spell:56641]]。
18. **适用条件：黑暗游侠（启用）。** 如果你拥有[[spell:260240]]，则施放[[spell:466932]]。
19. **适用条件：Explosive Shot（启用）；黑暗游侠（启用）；Unstable Trigger（启用）。** 尽量卡着冷却时间施放 [[spell:212431]]。得益于 [[spell:473520]]，你可以连续施放两次，并且应该这样做。
20. **适用条件：Explosive Shot（启用）；黑暗游侠（启用）；Tactical Reload（启用）。** 尽量卡着冷却时间施放 [[spell:212431]]，除非 [[spell:194595]] 已经在生效。
21. **适用条件：黑暗游侠（启用）；弹幕（启用）。** 尽量卡着冷却时间施放 [[spell:260243]]。
22. **适用条件：黑暗游侠（启用）。** 在[[spell:288613]]期间，如果没有[[spell:260240]]，且[[spell:466932]]已就绪，则施放[[spell:19434]]；或者当[[spell:19434]]即将达到2层充能时施放。
23. **适用条件：黑暗游侠（启用）。** 尽量卡着冷却时间施放 [[spell:288613]]，但将整场战斗中的最后一次留给30层 [[spell:204089]]。如果 [[spell:212431]] 即将冷却完毕，可以延迟最多15秒，以便在进入 [[spell:288613]] 之前立刻施放爆炸射击。
24. **适用条件：黑暗游侠（启用）。** 在你按下[[spell:288613]]之前，切换到一个尚未带有[[spell:466872]]的目标—— <em>点击查看详情</em>
    
    
    
    
    [[spell:470943]]使[[spell:288613]]对你按下时所选中的目标施加[[spell:466872]]，因此对一个已被标记的目标按下[[spell:288613]]会浪费它。
25. **适用条件：黑暗游侠（启用）。** 施放[[spell:257044]]，冷却完毕即用。
26. **适用条件：黑暗游侠（启用）。** 施放[[spell:392060]]，冷却完毕即用。
27. **适用条件：黑暗游侠（启用）；Aspect of the Hydra（启用）。** 在多于一个目标时，施放[[spell:257620]]而非[[spell:185358]]以消耗[[spell:260240]]，除非你在集火一个优先目标。
28. **适用条件：黑暗游侠（启用）。** 施放[[spell:185358]]以消耗[[spell:260240]]。
29. **适用条件：黑暗游侠（启用）。** 施放[[spell:19434]]，冷却完毕即用。
30. **适用条件：黑暗游侠（启用）。** 施放[[spell:466932]]。
31. **适用条件：黑暗游侠（启用）。** 施放[[spell:56641]]。

### AOE循环

1.3.

#### 射击猎人AoE起手

确保 [[spell:257284]] 在你的主目标身上生效。

**适用条件：Trick Shots（启用）。**

---

**适用条件：黑暗游侠（启用）；Trick Shots（启用）。**

[[spell:19434]]

2.5s

拉怪

**适用条件：爆炸射击（启用）。**

[[spell:212431]]

**适用条件：弹幕（启用）。**

[[spell:260243]]

[[spell:19434]]

[[spell:466932]]

[[spell:288613]]

[[item:241288]]

[[spell:257044]]

[[spell:19434]]

[[spell:466932]]

**适用条件：哨兵（启用）；Trick Shots（启用）。**

[[spell:19434]]

2.5s

拉怪

**适用条件：爆炸射击（启用）。**

[[spell:212431]]

**适用条件：Explosive Shot（启用）；猎人射击12.1职业套装4件套（启用）；Unstable Trigger（启用）。**

[[spell:212431]]

**适用条件：弹幕（启用）。**

[[spell:260243]]

[[spell:288613]]

[[item:241288]]

[[spell:257620]]

[[spell:257044]]

[[spell:257620]]

[[spell:19434]]

**适用条件：Trick Shots（启用）。**

---

1. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 在战斗开始前约2.5秒施放 [[spell:19434]]。
2. **适用条件：黑暗游侠（启用）；Explosive Shot（启用）；Trick Shots（启用）。** [[spell:212431]]
3. **适用条件：黑暗游侠（启用）；Volley（启用）；Trick Shots（启用）。** [[spell:260243]]
4. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** [[spell:19434]]
5. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** [[spell:466932]]
6. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** [[spell:288613]]，与你的药水、主动饰品、种族技能等一起使用。
7. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** [[spell:257044]]
8. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** [[spell:19434]]
9. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** [[spell:466932]]
10. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 继续按照下面描述的优先级列表进行。
11. **适用条件：哨兵（启用）；Trick Shots（启用）。** 在战斗开始前约2.5秒施放 [[spell:19434]]。
12. **适用条件：哨兵（启用）；Explosive Shot（启用）；Trick Shots（启用）。** [[spell:212431]]
13. **适用条件：哨兵（启用）；Explosive Shot（启用）；猎人射击12.1职业套装4件套（启用）；Unstable Trigger（启用）；Trick Shots（启用）。** 对第二个目标施放[[spell:212431]]
14. **适用条件：哨兵（启用）；Volley（启用）；Trick Shots（启用）。** [[spell:260243]]
15. **适用条件：哨兵（启用）；Trick Shots（启用）。** [[spell:288613]]，与你的药水、主动饰品、种族技能等一起使用。
16. **适用条件：哨兵（启用）；Trick Shots（启用）。** [[spell:257620]]
17. **适用条件：哨兵（启用）；Trick Shots（启用）。** [[spell:257044]]
18. **适用条件：哨兵（启用）；Trick Shots（启用）。** [[spell:257620]]
19. **适用条件：哨兵（启用）；Trick Shots（启用）。** [[spell:19434]]
20. **适用条件：哨兵（启用）；Trick Shots（启用）。** 继续按照下面描述的优先级列表进行。

**适用条件：Trick Shots（未启用）。** 没有[[spell:257621]]时，单体和AoE起手是一样的，所以请参阅单体部分了解更多信息！

1.4.

#### 射击猎人AoE优先级列表

**适用条件：Trick Shots（启用）。** 以下是描述射击猎人最优AoE循环的优先级系统。

**适用条件：Trick Shots（未启用）。** 没有[[spell:257621]]时，单体和AoE循环是一样的，所以请参阅单体部分了解更多信息！

**适用条件：Aspect of the Hydra（启用）。** Hydra Cleave是团本顺劈天赋：它选取高效的AoE天赋并执行单体循环，从2个目标起将[[spell:260240]]消耗在[[spell:257620]]上。

1. **适用条件：哨兵（启用）；Explosive Shot（启用）；Trick Shots（启用）；Unstable Trigger（启用）。** 施放[[spell:212431]]。拥有[[spell:473520]]时，你可以连续施放两次。除非有优先目标，否则将它们分散到两个目标上。
2. **适用条件：哨兵（启用）；Explosive Shot（启用）；Tactical Reload（启用）；Trick Shots（启用）。** 施放[[spell:212431]]，除非[[spell:194595]]已经存在。
3. **适用条件：哨兵（启用）；Volley（启用）；Trick Shots（启用）。** 尽量卡着冷却时间施放 [[spell:260243]]。
4. **适用条件：哨兵（启用）；Trick Shots（启用）。** 尽量卡着冷却时间施放 [[spell:288613]]，但将整场战斗中的最后一次留给30层 [[spell:204089]]。如果 [[spell:212431]] 即将冷却完毕，可以延迟最多15秒，以便在进入 [[spell:288613]] 之前立刻施放爆炸射击。
5. **适用条件：哨兵（启用）；Trick Shots（启用）。** 在你按下 [[spell:288613]] 之前，切换到一个尚未带有 [[spell:1253601]] 的目标—— <em>点击查看详情</em>
   
   
   
   
   [[spell:470943]] 使 [[spell:288613]] 在你按下它时对你当前选中的目标施加 [[spell:1253601]]，所以对已经带有标记的目标按下 [[spell:288613]] 会浪费它。
6. **适用条件：哨兵（启用）；Trick Shots（启用）。** 如果[[spell:288613]]即将结束，则施放[[spell:1264902]]。
7. **适用条件：哨兵（启用）；Trick Shots（启用）。** 施放[[spell:257620]]以消耗[[spell:260240]]，或在[[spell:257621]]未激活时激活它。请使用宏页面上的鼠标悬停多重射击宏。始终优先对尚未带有[[spell:1253601]]的目标使用它。
8. **适用条件：哨兵（启用）；Trick Shots（启用）。** 在[[spell:257621]]激活时，施放[[spell:257044]]，冷却完毕即用。
9. **适用条件：哨兵（启用）；Trick Shots（启用）。** 在[[spell:257621]]激活时，施放[[spell:19434]]，冷却完毕即用，除非你在集火一个优先目标，否则优先选择带有[[spell:1253601]]的目标。只有当你的主目标也被标记时，[[spell:257621]]的弹射才会消耗[[spell:1253601]]。
10. **适用条件：哨兵（启用）；Trick Shots（启用）。** 施放[[spell:1264902]]。
11. **适用条件：哨兵（启用）；Trick Shots（启用）。** 施放[[spell:56641]]。
12. **适用条件：黑暗游侠（启用）；Explosive Shot（启用）；Trick Shots（启用）；Unstable Trigger（启用）。** 施放[[spell:212431]]。拥有[[spell:473520]]时，你可以连续施放两次。除非有优先目标，否则将它们分散到两个目标上。
13. **适用条件：黑暗游侠（启用）；Explosive Shot（启用）；Tactical Reload（启用）；Trick Shots（启用）。** 施放[[spell:212431]]，除非[[spell:194595]]已经存在。
14. **适用条件：黑暗游侠（启用）；Volley（启用）；Trick Shots（启用）。** 尽量卡着冷却时间施放 [[spell:260243]]。
15. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 在[[spell:257621]]激活时，如果[[spell:19434]]即将达到2层充能，则施放它。
16. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 如果你拥有[[spell:260240]]，则施放[[spell:466932]]。
17. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 在[[spell:257621]]未激活时，施放[[spell:257620]]以激活它。
18. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 尽量卡着冷却时间施放 [[spell:288613]]，但将整场战斗中的最后一次留给30层 [[spell:204089]]。如果 [[spell:212431]] 即将冷却完毕，可以延迟最多15秒，以便在进入 [[spell:288613]] 之前立刻施放爆炸射击。
19. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 在你按下[[spell:288613]]之前，切换到一个尚未带有[[spell:466872]]的目标—— <em>点击查看详情</em>
    
    
    
    
    [[spell:470943]]使[[spell:288613]]对你按下时所选中的目标施加[[spell:466872]]，因此对一个已被标记的目标按下[[spell:288613]]会浪费它。
20. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 在[[spell:257621]]激活时，施放[[spell:257044]]。
21. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 如果[[spell:466932]]未就绪，则施放[[spell:392060]]。
22. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 施放[[spell:257620]]以消耗[[spell:260240]]。
23. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 在[[spell:257621]]激活时，施放[[spell:19434]]，冷却完毕即用。
24. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 施放[[spell:466932]]。
25. **适用条件：黑暗游侠（启用）；Trick Shots（启用）。** 施放[[spell:56641]]。
26.

### 至暗之夜 第2赛季套装

至暗之夜 第2赛季套装对我们的循环有细微影响。它会

延长你的 [[spell:212431]] 的持续时间（因此也增加伤害），

并使那些跳数每次减少 [[spell:19434]] 和

[[spell:257044]] 0.5秒的冷却时间。在两个或更多目标时，由于

[[spell:473520]] 会为你连续提供两个 [[spell:212431]]，我们倾向于

将它们施放在两个不同的目标上（除非有优先目标），

因为我们希望最大化这个冷却缩减效果。伤害是

与在1个目标上施放两个相同的，但由于冷却缩减随

通过 <em>跳数</em>缩放，分散施放更好。

1.

### 职业与专精机制详解

为了更好地说明的

射击猎人技能体系的具体用法和收益，我们编写了更详细的说明，涵盖

循环的各个部分，从你需要关注的重要循环机制

到冷却技能及其使用方法，以便你能

在游玩射击猎人时发挥全部潜力。

### 弹无虚发

3.1.

#### 弹无虚发

[[spell:260240]]是你施放后获得的一个增益，

并且通过[[spell:473385]]天赋，[[spell:19434]]和[[spell:257044]]

也能获得。

它使[[spell:185358]]和[[spell:257620]]造成的伤害提高50%，

伤害

并使消耗降低60%集中值。

除了想要伤害和资源加成之外，消耗

[[spell:260240]]还能为我们的[[spell:466872]]充能，

它会根据天赋大幅强化[[spell:19434]]和[[spell:257044]]，

并且在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵

拥有强化[[spell:1253601]]时效果更强。

因为[[spell:260240]]不会叠加（或者更准确地说，你不能

在不浪费部分层数的情况下获得两层），我们 **总是** 希望消耗

我们的[[spell:260240]]消耗技能（以下称为PS消耗技能），再使用

下一个[[spell:19434]]。最简单的方法就是每次

施放[[spell:19434]]后立即接一个PS消耗技能。

[[spell:257044]]会给予[[spell:260240]]，所以

每次施放[[spell:257044]]后也要接一个PS消耗技能。作为

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵，在施放前也要先消耗你的[[spell:260240]]

[[spell:257044]]，除非[[spell:288613]]已激活。作为

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠，无论如何都直接施放[[spell:257044]]即可，冷却完毕即用。

在范围伤害中，这还有额外的便利，即激活[[spell:257621]]

紧接着用那些瞄准射击和急速射击消耗它之后。只需遵循

施放[[spell:19434]]和[[spell:257044]]后都接上一个

[[spell:257620]]

在AoE中，我们一举两得：[[spell:260240]]被消耗，

[[spell:257621]]被激活。

### 「精准射击」顶层天赋

3.2.

#### 「精准射击」顶层天赋

[[spell:1273132]]使[[spell:257044]]能够缩短5秒，作用对象为

为[[spell:19434]]的冷却时间减少5秒。

拥有[[spell:470945]]且范围内有第二个目标时，这一效果翻倍至10

秒。[[spell:1273128]]在此基础上追加了第二个效果。你的

[[spell:466872]]现在还会使你对该目标的下一个

[[spell:257044]]伤害提高20%，而不仅仅是下一个

[[spell:19434]]。两者都没有对你提出新的要求。它们都已「内嵌」

在上面列出的循环之中。

1.

### 射击猎人重要冷却技能

### [[spell:288613]]

4.1.

#### 百发百中

[[spell:288613]]是我们的主要冷却技能。它的冷却时间为90秒或2分钟，

冷却时间，取决于你选择 [[spell:260404]] 还是

[[spell:474738]]。它持续17秒。激活期间，它会提高你的

10%的暴击几率和20%的暴击伤害，如果你

承受了[[spell:474738]]，效果翻倍，并且它会加快你的主要

[[spell:19434]]和[[spell:257044]]的冷却恢复速度，同时

还会缩短前者的施法时间。

它还会大幅提高生成[[spell:466872]]的几率

的几率，当我们消耗[[spell:260240]]时，甚至会

在你按下它时免费激活[[spell:466872]]。

[[spell:288613]]让我们在所有方面都变得更强，而且因为我们最擅长

的事情是“用[[spell:19434]]/[[spell:257044]]打出大量伤害”，所以

一条非常好的

拇指规则是始终尝试在之前立即施放[[spell:288613]]

[[spell:257044]]。这确保我们尽可能多地花费时间

处于[[spell:288613]]中施放我们最强力的技能。

在5分钟以上的战斗中，你可以使用两瓶药水，而且它们不一定是同一瓶。

[[item:241288]]是你的首选/标准药水。然而，一旦[[spell:204089]]在

战斗的斩杀阶段叠加起来，你已经拥有大量暴击

了，所以第二瓶[[item:241288]]的价值就低得多，而

改用[[item:271886]]。它会在持续时间内逐步提升全能效果，所以为了

要在正确时机达到全能峰值，请提前约10秒使用它，时间参照你的

斩杀[[spell:288613]]前约10秒使用它。

4.1.1.

##### 英雄天赋对百发百中的影响

对于两者 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠, [[spell:288613]]'s

按钮在按下后会变成另一个按钮；[[spell:1264902]]

或[[spell:392060]]分别对应哨兵和黑暗游侠。此外，

，而是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 对于黑暗游侠，激活[[spell:288613]]还会给你一次免费的

[[spell:466932]]触发。

[[spell:1264902]]是一个填充技能，它会给我们一次[[spell:194595]]触发，并造成大量伤害。

值得注意的是，它的弹射效果在单体目标上造成伤害的速度比在范围伤害上慢得多。所以，在单体目标上我们

更倾向于在[[spell:288613]]剩余约5秒时施放它。在范围伤害上，我们就在它

[[spell:288613]]过期前直接释放。

[[spell:392060]]则要稍微复杂一些。因为

[[spell:288613]]和[[spell:392060]]都会给你一次[[spell:466932]]

触发，而且因为我们不想覆盖这些触发效果，我们希望在

我们没有即将到来的触发效果时施放两者。实际上，这意味着我们

我们通常会在用尽其他方式后立即使用[[spell:392060]]

以保证的方式生成它（例如[[spell:257044]]）。

### [[spell:260243]]

4.2.

#### 乱射

[[spell:260243]]是一个天赋技能，45秒冷却，主要

与范围伤害相关。它其实是一个相当简单的技能，但关于它的使用和价值存在一些常见的

关于其使用和价值的误解。

本质上，由于我们在上一节中解释过的[[spell:260240]]机制的性质，

如上一节所述，尽管 [[spell:260243]] 让我们

[[spell:257621]]，我们实际上很少会利用到

这个“免费的”[[spell:257621]]。因为我们倾向于使用那些

[[spell:19434]]和[[spell:257044]]都提供[[spell:260240]]的天赋，

我们 **在获得怒气时就立刻** 需要在所有这些施放之间穿插使用一个技巧射击消耗技能。因此，

即使[[spell:257621]]永久激活，我们的打法实际上也大同小异；

消耗[[spell:260240]]的需求如此紧迫，而且

[[spell:257620]]也提供的所有[[spell:257621]]

算是一个

意外之喜。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月14日：** 在有两个或更多目标时激活九头蛇之相，哨兵 现在即使有精确瞄准也会按冷却时间施放急速 火焰。
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月31日：** 澄清了鼠标悬停多重射击和打断引导的相关说明。
- **2026年8月24日：** 在 哨兵 单体目标优先级列表中，将急速 火焰 移至精确瞄准消耗技能之上。基础循环相同，但更易解析/阅读。
- **2026年8月24日：** 在单体目标战斗中，月光飞轮现在在百发百中剩余约 5 秒时掷出，以便全部 7 次弹跳都落在百发百中期间。
- **2026年8月24日：** 将液体光泽添加为战斗中的第二瓶药水，在斩杀阶段百发百中开启前约 10 秒使用。
- **2026年8月22日：** 奥术射击 在百发百中期间不再有单独的规则。
- **2026年8月22日：** 根据最近的在线修正更新了急速 火焰 的建议。只有 哨兵 仍然会打断引导，且仅在范围伤害场景中。
- **2026年8月18日：** 在多重射击优先级条目中链接了目标切换多重射击宏。
- **2026年8月18日：** 在急速火焰、瞄准射击和精准射击消耗优先级中，加入了通过哨兵的印记和侦察兵印记进行目标选择的功能。
- **2026年8月18日：** 添加了在按下百发百中前切换到没有标记的目标的说明。
- **2026年8月18日：** 添加了延迟百发百中最多 15 秒以与爆炸射击对齐的说明。
- **2026年8月16日：** 如果优先目标存在，则从范围伤害优先级和起手式中移除了将爆炸射击分散到两个目标上的操作。发现这并不会加快大秘境的通关速度，因为其优先目标伤害损失，尽管它能小幅提升范围伤害/双目标 DPS。
- **2026年8月16日：** 在 哨兵 范围伤害起手式中，添加了用多重射击打断急速 火焰 结尾的说明。
- **2026年8月15日：** 在单体目标优先级中添加了用多重射击打断急速 火焰 结尾的说明，并澄清了两发箭矢都受益于精确瞄准。
- **2026年8月13日：** 在范围伤害优先级中添加了用多重射击打断急速 火焰 结尾的说明。
- **2026年8月12日：** 澄清了在范围伤害优先级中，急速 火焰 需要技巧射击处于激活状态。
- **2026年8月11日：** 澄清了范围伤害优先级中爆炸射击的目标选择。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 修正了乱射的冷却时间，并阐明了双重射击的使用方法。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月29日：** 添加了关于在削减射程单体目标中以2层充能高优先级使用瞄准射击的说明。
- **2026年4月27日：** 循环更新与简化。起手更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月9日：** 黑暗游侠起手修复。
- **2026 年 3 月 17 日：** 修复了导致乱射在某些条件下不出现在起手循环中的错误。对哨兵AOE循环进行了小幅更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月3日：** 针对月光飞轮的起手说明。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月28日：** 围绕爆炸射击使用的单体循环更新。
- **2025年8月27日：** AOE方面的小幅循环说明与编辑。
- **2025 年 8 月 25 日：** 更新了单体目标上爆炸射击的使用方式，以更好地适配强化流线型配置。
- **2025 年 8 月 25 日：** 添加了关于循环bug的信息。
- **2025年8月20日：** 添加了关于因移动需求将专注瞄准更换为强化流线型的说明。
- **2025年8月19日：** 从黑暗游侠AOE中移除了填充性多重射击。
- **2025年8月18日：** 黑暗游侠单体起手的小幅更新（更明确地要求在进入百发百中前消耗精确瞄准层数）。
- **2025年8月17日：** 黑暗游侠单体循环的小幅说明/简化。哨兵AOE的小幅说明。
- **2025年8月15日：** 更新了AOE循环。
- **2025年8月13日：** 黑暗游侠单体起手的小幅改动。
- **2025年8月12日：** 更新了单体循环。
- **2025年8月11日：** 黑暗游侠单体目标的重大循环更新，能带来相当可观的额外DPS。
- **2025年8月8日：** 更新了默认的黑暗游侠单体天赋选择。
- **2025年8月7日：** 进一步的起手更新迭代。
- **2025年8月6日：** AOE循环的重大更新，特别是哨兵AOE起手。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月15日：** 更新了黑暗游侠AOE起手。
- **2025年5月7日：** 更新了循环中关于四件套双重利用的措辞，使其作用和工作方式更加清晰。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年4月4日：** 非常小幅的循环更新与说明。
- **2025年3月25日：** 添加了一行无论其他状态如何都使用爆炸射击的低优先级备选方案。
- **2025年3月18日：** 更新了关于四件套和精准爆破的循环细节。在某些地方更新了措辞以使其更清晰。
- **2025年3月14日：** 更新默认设置以假设拥有四件套。
- **2025年3月4日：** 输出循环改进。除非选择了特定天赋，否则已将夺命射击从AOE优先级和单体优先级中移除。
- **2025年2月27日：** 对与奥术射击、瞄准射击及爆炸射击使用相关的输出循环进行了重大更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025年1月13日：** 进一步区分了黑暗游侠和哨兵的单体输出循环差异。
- **2025年1月8日：** 起手式小幅补充。
- **2024年12月27日：** 黑暗游侠的起手式和输出循环小幅更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月31日：** 输出循环大改，特别是针对黑暗游侠。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月26日：** 单体输出循环重大更新。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年10月10日：** 更新了疯狂女王的指令的使用方式。
- **2024年10月2日：** 新增了更具体的饰品使用信息。
- **2024年9月24日：** 在AOE输出循环中添加了月蚀期间快速积攒火焰的策略。
- **2024年9月17日：** 添加了关于主动使用型饰品的起手式说明。
- **2024年9月15日：** 添加了关于主动使用型饰品的说明。
- **2024年9月14日：** 简化了单体输出循环，特别是瞄准射击的使用。
- **2024年9月13日：** 添加了哀恸之箭会重置快速火焰冷却时间的说明，更新了起手式。
- **2024年9月10日：** 明确了多重射击在仅2个目标时就取代了奥术射击。简化了稳固集中输出循环。
- **2024年9月9日：** 更新了点出哀恸之箭后的起手式。
- **2024年9月3日：** 地心之战第1赛季的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月31日：** 简化了稳固集中优化。这会影响单体起手式、输出循环和AOE输出循环。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到魔兽世界12.1.5中你的射击猎人的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们应有尽有！

1.

### 射击猎人毕业装备指南

欢迎来到我们的射击猎人装备与毕业页面，

至暗之夜第2赛季。查看本页面，了解你需要知道的

了解关于为射击猎人配装的一切，包括毕业装备

配装（来自所有渠道）、团队副本和大秘境，以及最佳饰品、套装

等信息，更多内容。

至暗之夜资料片带来了大规模的属性压缩，降低了

游戏中几乎所有内容的属性和数值，包括物品等级和装备

上的属性。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统

让你

沿着与获取物品来源相关的轨道提升装备物品等级，

物品，更难的内容掉落的装备可以升级到更高的物品

等级。

欲了解更多信息，请阅读我们专门介绍

[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 如何运作以及

在 至暗之夜 资料片中有什么变化的专页。

### 总体

本列表包含至暗之夜第2赛季每个部位的最佳装备，来自所有渠道。

有许多不同的配装方案在误差范围内表现相当。本方案尽可能选择团队副本装备，因为它们比碰运气从 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)获取正确的秘境装备更容易获得。当没有同样强力的团队副本替代品时，才会选择秘境装备。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题：我在转化器中使用哪些物品？
转化器现在会保留你所转化物品的副属性和任何被动效果，所以你放进去的物品比你使用哪个部位来完成套装更重要。暴击和精通是你最需要的属性。

不要因此拖延套装效果。没有4件套的两周代价远高于稍微错误的副属性，而且你可以在本赛季晚些时候转化一件更好的装备。

以下是最佳的转化物品：

- 头盔：[[item:268230@JAACAAgNyA]]，来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- 肩膀：[[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 胸甲：[[item:271876@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手套：[[item:281238@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 腿部：[[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 常见问题：从宏伟宝库中获取什么？
选择 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 几乎每周都如此。例外情况是当宝库提供了你从某个首领或地下城想要的最后一件装备时，因为在那里拿取意味着你再也不需要对那个渠道使用额外拾取。

虚空核心可以对一个团队副本首领或一个大秘境地下城进行额外拾取，并给你一件你之前从未从中拾取过的物品。英雄难度团队副本首领和大秘境提供1/6神话，史诗团队副本首领提供6/6神话，后期首领提供9/6。

有两点使其比看起来更强大。物品等级在你使用虚空核心时决定，而非在你拾取时决定，因此你可以保留一个直到你遇到值得使用的史诗首领。而且从宝库取出的装备仍留在额外拾取池中，所以一件你本来就要替换的装备可能会在之后浪费你一次拾取。

值得用骰子的Boss列在本页下方的“虚无核心”部分。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240914]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268207@JAAEAAAG2wYN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

本列表包含至暗之夜第2赛季每个部位的最佳装备，来自至暗之夜第2赛季大秘境。这适用于不打算过多参与团队副本内容的玩家。

有许多不同的配装方案在误差范围内表现相当。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题：我在转化器中使用哪些物品？
转化器现在会保留你所转化物品的副属性和任何被动效果，所以你放进去的物品比你使用哪个部位来完成套装更重要。暴击和精通是你最需要的属性。

不要因此拖延套装效果。没有4件套的两周代价远高于稍微错误的副属性，而且你可以在本赛季晚些时候转化一件更好的装备。

以下是最佳的地下城掉落用于转化：

- 头盔：[[item:159374@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 肩膀：[[item:251131@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 胸甲：[[item:158355@JAACAAgNyA]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 手套：[[item:193752@JAAKAAQkCYHKvbRLfYjM]]，来自 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- 腿部：[[item:159375@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你游戏时间有限，我们建议刷以下地下城：

- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：毕业头盔、腿部、鞋子和戒指
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：毕业武器、肩甲、披风、戒指和饰品
- [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)：毕业胸甲和饰品
- [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)：毕业手套
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：毕业项链

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271493@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271490@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271491@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271495@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271680@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

本列表包含至暗之夜第2赛季每个部位的最佳装备，来自至暗之夜第2赛季团队副本。它与我们的总体毕业列表非常相似，因为该列表也偏向于团队副本装备，但在这种情况下，完全不包含任何秘境装备。

有许多不同的配装方案在误差范围内表现相当。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题：我在转化器中使用哪些物品？
转化器现在会保留你所转化物品的副属性和任何被动效果，所以你放进去的物品比你使用哪个部位来完成套装更重要。暴击和精通是你最需要的属性。

不要因此拖延套装效果。没有4件套的两周代价远高于稍微错误的副属性，而且你可以在本赛季晚些时候转化一件更好的装备。

以下是最佳的团队副本掉落用于转化。如果你也打秘境，秘境装备可以胜过其中任何一件：

- 头盔：[[item:268230@JAACAAgNyA]]，来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- 肩膀：[[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 胸甲：[[item:271876@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手套：[[item:281238@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 腿部：[[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团长提交一份高优先级装备列表，或只是想专注于最重要的首领和装备，我们已为你准备好！

- [[item:268207]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业武器，以及剧毒诅咒。
- [[item:268265]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业项链，以及剧毒诅咒。大多数专精都需要它，所以请做好竞争准备。
- [[item:270175]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业主动使用型饰品。
- 来自[[item:270168]]的 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业饰品。
- [[item:281215]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：在你拥有344装等的剧毒狂怒之泉之前，这是最好的饰品。
- [[item:281238]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业手套。
- [[item:268252]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)：毕业戒指。
- [[item:281029]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业戒指。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240914]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268207@JAAEAAAG2wYN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 猎人 射击饰品推荐

作为射击，我们想要一个强大的主动使用型饰品来配合我们的

[[spell:288613]]，也就是[[item:270175]]。此外，我们选择[[item:270168]]。

尽管剧毒狂怒之泉严格来说是一个主动使用型饰品，但它并不特别受益于与

[[spell:288613]]一起使用，

因为它自身就能造成伤害，这使它可以与乌拉特克贪婪之心搭配使用。在特定战斗中正确使用剧毒狂怒之泉，其表现可以远超模拟结果，尤其是在有伤害加成的情况下。

在你拥有344装等的剧毒狂怒之泉之前，请使用[[item:281215]]。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **射击猎人饰品**
**毕业搭配 -**

[[item:270175]]

和

[[item:270168]]

**备选方案 -**

[[item:281215]]

和

[[item:270173]]

:::

还有许多其他有价值的饰品，所以请务必

点击我们的排名图表，看看它们是否值得装备。通常同时装备两个主动使用型饰品是不好的，但剧毒狂怒之泉不是一个提供属性加成的主动使用型饰品，这意味着它不太在乎与我们的[[spell:288613]]叠加，并且之后可以安全使用。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看射击猎人饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]：使用型</li>&#10;<li>[[item:270168]]：主动使用。与乌拉特克贪婪之心搭配为毕业选择。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]]：如果你无法获得344装等的剧毒狂怒之泉，这是最好的替代品。</li>&#10;<li>[[item:270173]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159617]]：主动使用，如果你不打史诗难度的乌拉特克，这是乌拉特克贪婪之心的最佳替代品。</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:273796]]：使用型</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250225]]：使用型</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:158374]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:250259]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]：使用型</li>&#10;<li>[[item:273797]]：使用型</li>&#10;<li>[[item:241340]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

- [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 是一种新的货币，可用于对某些
  
  
  
  
  在特定地下城和物品上使用“骰子”。使用后将会 **保证** 掉落
  
  
  
  
  来自该渠道，但你获得的装备是随机的。不过，你会受到
  
  
  
  
  保护免于重复。在一个首领或地下城上使用足够多次，你就
  
  
  
  
  **保证** 获得你想要的装备。

你通过 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 获得它们，通过拒绝物品奖励，这

需要从任何渠道解锁三个奖励槽（甚至1层地下堡！）。通过

补丁12.1.5上线时，你还能从奥林处免费获得一个额外的虚空核心

斯特拉维尔，他可以在银月城的转化器旁边找到。

3.1.

#### 射击猎人推荐的虚空核心使用方案

显然，这个问题的直接答案就是使用

虚空核心来升级你尚未获得的最佳装备。这取决于

你的角色，但我们会为你列出一些最重要的物品

射击 猎人，目标是你可以直接走下去

列表往下看，追逐你看到的第一个你还没有的装备。

为一个你可能从即将到来的团本首领处获得的装备进行额外拾取可能是个坏

主意，这取决于你如何看待“现在的战力”与“以后的战力”。

总的来说，你最好的选择是进行 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 在 **英雄难度**。它有几件高影响力的毕业装备，所以即使你没有

立刻拾取到你的毕业武器，你仍然会获得良好的价值。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 用于[[item:268207]]，
   
   
   
   
   [[item:268265]], [[item:271876]],
   
   
   
   
   [[item:270175]]和[[item:270168]]
2. [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 用于[[item:281238]]，
   
   
   
   
   [[item:281029]]和[[item:281215]]
3. 此时，赛季已经过去很多周了，你的装备将会
   
   
   
   
   参差不齐。我们建议使用
   
   
   
   
   [Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>)
   
   
   
   
   来模拟你的最佳额外拾取。

:::

3.2.

#### 晋升毒液石

[[item:280562]]是一种新的升级货币，随着

补丁12.1.5一同到来。每次升级花费10个，它们只能用于你的武器、你的

饰品和项链，让你将这些装备升级到340物品等级。只有

完全升级的英雄级或史诗级装备，或最高

品质的制造装备，才能用它们升级。使用它们的优先级与

你的纹章类似：

1. 你的武器是最高优先级。
2. 你的[[item:270175]]。
3. 你的另一个饰品。
4. 你的项链。

用其他你不常用的史诗级装备来填充。例外

是你不指望在短期内获得史诗级的装备。如果

你没有在史诗难度击杀 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)，那么升级一件英雄级的

[[item:270175]].

1.

### 射击猎人最佳制造物品

你可以拥有两个装饰，它们是来自

制造装备的特殊效果。先制造哪一个取决于你有多看重赛季

开局几周的战力。

制造一件像[[item:265337]]这样的武器，使用

[[item:273060]]和暴击/精通，是一次出色的

短期战力提升。缺点是即使你制造了它，你最好的额外拾取

目标仍然很可能是英雄难度的 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)，它有相当大的

几率给你一件史诗级的[[item:268207]]，这将会

使你的制造武器失效。

另一种选择是制造你真正的毕业装备，即

[[item:244581]]和[[item:244584]]，使用

[[item:240167]]和暴击/精通。如果你非常不走运，没有在

在史诗难度中额外拾取

一件合理的武器

时间内，你可能会后悔这个选择，因为你将不得不连续数周使用一件321装等的武器

数周。

护甲套装是更好的长期选择，因为它是你真正的毕业装备，

而制造武器迟早会被一件史诗级掉落所取代。

如果你想要在第一周就获得战力，先制造武器仍然是一个真正的选择，

在第一周。

制造[[item:244582]]是一个很好的短期护甲

制造选择，如果你永远不会在史诗难度击杀 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

以获得344腿甲，那它就是永久选择。

:::details **射击 猎人 打造部位优先级**
**武器 → 项链/戒指 → 其他所有部位 → 披风/护腕**

:::

理想情况下，你应该模拟你的特定角色的

最佳属性，但暴击/精通很可能是你的最佳选择，使用

[[item:245789]].

有关制造装备的更多信息，你可以访问我们的

[专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 为装备添加插槽

头盔、腰带和护腕可以掉落带有插槽的，你也可以自己添加一个

使用[[item:275707]]。它花费六个

[[item:258556]]，这是 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 为通关奖励给你的货币。

只要你解锁了三个奖励栏位，你就可以直接获得六个。

奖励栏位解锁。

把它们留给你不打算更换的装备，比如史诗级装备或你的

两个制造部位，因为制造的腰带或护腕无法通过其他

方式获得插槽。

1.

### 纹章使用

你将能够通过徽章升级你的物品，例如

[秘境雾崖](<https://www.wowhead.com/currency=3446>)。一旦你将某个部位升级到特定物品等级，

**将该栏位的其他物品升级到该物品等级就是免费的**.

当你使用纹章升级时，你应该将其视为升级

**插槽** 而不是物品。

由于纹章是有限的资源，你希望在升级某个部位时获得

尽可能高的物品等级 **之前** ，因为这样

意味着你在该部位总共花费的纹章会更少。如果你完全

有能力打一个+10地下城，例如，那么去升级

一个+9地下城的装备将是一个非常糟糕的主意，因为你刚刚浪费了20个纹章，这些纹章本可以

通过在+10刷该部位来节省下来。

我们看到大量玩家，即使在高水平，也搞错了他们的升级

优先级并过早升级。做对这一点会让你远远领先于

大多数玩家。

以下是你应该升级装备的部位优先级。如果你想要

偏离这一点，你应该有一个非常好的理由。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **射击 猎人 升级纹章优先级**
**武器**

→

**饰品**

→

**头盔/胸甲/腿甲**

→

**肩部/手套/腰带/靴子**

→

**戒指/项链**

→

**披风/护腕**

:::

请注意，例外是可能的，例如某些特殊装备的物品等级成长

高于其部位所暗示的。

1.

### 评估升级

在本页及我们指南的其他地方，我们经常提到

在Raidbots上模拟自己的重要性。这是因为每个角色都是

独特的，你所拥有的每一件装备都可能改变什么是最好的

现在为你。

虽然我们确实为装备和饰品提供建议，但这些并非完整的

替代品来自模拟你自己。真正优化你角色的唯一方法

达到那种程度的方法就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年9月30日：** 修复了胸甲工具提示显示两个毒咒效果的问题。
- **2026年9月2日：** 将总体和团队副本毕业列表中的饰品更新为剧毒之怒源泉。
- **2026年8月31日：** 将总体和团队副本毕业列表中的靴子更新为鲁莽旅者之靴。
- **2026年8月31日：** 将总体毕业列表中的戒指更新为充能砂岩指环。
- **2026年8月29日：** 将剧毒之怒源泉提升至 S 级，因为它的模拟结果被低估了。
- **2026年8月24日：** 将武器附魔更新为哈什之仪。
- **2026年8月22日：** 添加了关于制作护腿的说明。
- **2026年8月18日：** 将总体毕业列表中的靴子更新为烁能胫甲。
- **2026年8月18日：** 在盖博的无底袋削弱后更新了虚空核心的额外掉落优先级。
- **2026年8月17日：** 更新了饰品梯级榜，并将备选被动饰品改为守护者的沸腾核心。
- **2026年8月16日：** 重做了制造建议，更正了团队副本物品列表中贪婪的 乌拉特克 之心和盖博的无底袋条目，并添加了赛季开始时的虚空核心和纹章建议。
- **2026年8月15日：** 根据最新的平衡性调整更新了饰品梯级榜。
- **2026年8月14日：** 将团队副本毕业手套更新为来自尼姆瑞莎·唤波者的催化漩涡狂怒之握。
- **2026年8月14日：** 更新了虚空核心的额外掉落优先级。
- **2026年8月12日：** 添加了催化剂和大秘库常见问题解答及插槽部分，修正了催化剂掉落位置，并更新了团队副本毕业头盔和手套的来源。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 修正了套装常见问题解答中的内容，并更新了项链推荐说明。
- **2026年6月17日：** 更新了毕业项链。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月7日：** 更新了光之连队战旗的天梯榜排名。
- **2026年3月25日：** 更新了大秘境装备毕业列表。
- **2026年3月21日：** 更新了大秘境装备毕业列表。
- **2026 年 3 月 17 日：** 为至暗之夜第一赛季更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月4日：** 更新了终局内容的专业制造推荐。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年9月2日：** 饰品层级列表和毕业装备更新。
- **2025年8月15日：** 针对数值调整更新了饰品天梯榜。简化为单一列表。
- **2025年8月12日：** 在天梯榜中添加了初步的、基于推测的诅咒石像饰品，因为它暂时无法进行模拟。
- **2025年8月11日：** 更新了大秘境饰品天梯榜。
- **2025年8月9日：** 更新了饰品天梯榜和毕业列表。
- **2025年8月8日：** 更新了大秘境装备毕业列表。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月23日：** 基于最新的在线修正更新了泰坦圆盘推荐。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月14日：** 更新了贾斯托钻石的购买顺序，并补充了更多关于其"毕业装备"地位的说明。
- **2025年5月9日：** 更新了腐蚀附魔与谜之卡特尔芯片代币部分。
- **2025年4月21日：** 添加了可用代币购买的物品列表。
- **2025年3月29日：** 更新了大秘境饰品层级列表中克赞之眼的位置。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月13日：** 根据最新改动和APL优化进行了新的模拟，更新了饰品排行榜和毕业装备列表。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月17日：** 更新了关于瑟尔崔指环现在提升至物品等级658的内容。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年10月10日：** 对饰品排行榜进行了小幅更新。
- **2024年9月17日：** 更新了毕业装备列表中的饰品选择。
- **2024年9月15日：** 基于新方法更新了猎人饰品排行榜，对于团本排行榜，还更新了指南其他页面中讨论的新单体推荐配置。
- **2024年9月13日：** 新增了关于双黎明之线衬里无效及其解决方法的说明。
- **2024年9月9日：** 地心之战第1赛季的初步更新。
- **2024年8月27日：** 在赛季前毕业列表中新增了关于制造装备的说明。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。

显示更多

显示更少

:::

## 属性优先级

在本页中，你将找到你的射击 猎人的最佳属性优先级。我们首先介绍属性优先级，然后深入解释这些属性如何与你的专精和玩法相互作用。我们的内容已针对《魔兽世界》12.1.5补丁更新。

1.

### 射击 猎人 属性优先级

射击 猎人所有流派的属性优先级如下

如下：

暴击

精通

全能

急速

暴击是首选属性，精通紧随其后。全能落后较多

，而急速是你最差的属性，差距相当明显。

请记住，某项属性相对于其他属性越少，它

往往就越强。属性优先级是基于平衡所有属性并考察

各属性从设定起点起的成长强度，同时参考

该专精模拟得分最高的装备配置，以及分析是哪种属性优先级

达到了那个效果。

1.

### 深入属性解析

**敏捷** 是你的主属性。它为你提供攻击强度，

这决定了你所有技能造成的伤害。

**精通**，通过[[spell:193468]]，使你获得提升的

所有技能的伤害，并增加你的最大射击距离。

**急速** 提高你的自动攻击速度和集中值回复，降低

你的全局冷却时间从1.5秒降低至最低0.75秒，并降低

你的[[spell:19434]]技能的冷却时间。

:::details 常见问题：射击 猎人有急速阈值吗？
射击 猎人没有急速阈值。

:::

**暴击** 提高你所有法术和技能的

暴击几率。暴击默认造成双倍伤害，但有若干

效果可以提高你的暴击伤害，使暴击更加强力。

**全能** 提高你造成的所有伤害和治疗，并降低

你受到的所有伤害。

2.1.

#### 属性递减收益

每项属性都有一个上限，超过该上限后，每点获得的提升

将开始减少；这些被称为收益递减点。一旦你

达到了

这些数值，属性将逐渐变得不那么有价值，并可能落后于

其他选择。当前的阈值如下：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 22 日：** 添加了急速阈值信息。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行审查。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月14日：** 更新了属性优先级，特别是将暴击开始变得次优的临界点明确化。
- **2025年8月27日：** 更新了黑暗游侠AOE的属性优先级。
- **2025年8月9日：** 更新了属性优先级。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 地心之战第1赛季的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已为10.2.5版本进行更新。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的射击 猎人可以获取的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

如果你的装备上有5个或更多插槽，你应该使用

```
[[item:240967]] in one socket. Then, you
```

你应该确保在其他插槽中每种类型的宝石各有一个，以最大化

暴击效果，最好是

[[item:240890]]/[[item:240898]]/

[[item:240914]]/

[[item:240908]]。其余插槽用

[[item:240908]].

如果你的装备上没有5个或更多插槽，你应该使用

在一个插槽中使用[[item:240983]]，并在

其余插槽中使用[[item:240908]]。

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

3.1.

#### 合剂

最好的药水通常是

[[item:241326]]。话虽如此，最好将合剂仅仅视为

另一件容易更换的装备，根据你的具体装备

情况，4种副属性合剂中的任何一种都可能是最优的。要真正做到极致优化

这一点，你需要进行模拟。

3.2.

#### 药水

射击在大多数5分钟以上的战斗中使用两种不同的DPS药水。

- [[item:241288]]是默认选择，提供大量
  
  
  
  
  你最高的副属性，持续30秒，应与你的爆发技能同步使用。
  
  
  
  
  请注意，这个药水对你最强的属性（暴击）在你使用药水时
  
  
  
  
  是否确实是最高的非常敏感。如果你在装备成型过程的
  
  
  
  
  这一点上并非如此，请改用[[item:241308]]。它还
  
  
  
  
  非常受益于你最低的属性（通常是全能）接近于0，
  
  
  
  
  因为这意味着你不会受到任何降低效果的影响。
- [[item:271886]]是战斗中的第二瓶药水，用于斩杀
  
  
  
  
  阶段。到那时[[spell:204089]]已经为你提供了大量暴击，以至于
  
  
  
  
  再喝一瓶[[item:241288]]对你帮助甚微。光华药水会在
  
  
  
  
  30秒内逐步叠加全能，所以请在你开启斩杀技能[[spell:288613]]前约10秒饮用。

确保携带[[item:271883]]。

它有5分钟冷却时间，能恢复你大部分生命值；在万不得已时使用，

尽可能优先使用你的个人减伤技能。

3.3.

#### 食物增益

你能吃到的最佳食物来自

[[item:255846]]或[[item:255845]]盛宴。最佳

非盛宴食物是[[item:242747]]。"丰盛的"这部分很重要，因为

这种食物在死亡后仍然保留，我们强烈建议学习

[烹饪](<https://www.icy-veins.com/wow/professions-cooking>) 来轻松制作你自己的丰盛食物，因为它无法

可在拍卖行直接购买。

3.4.

#### 强化符文

在至暗之夜中，最佳强化符文是

[[item:259085]]，但每次使用可能非常昂贵

开怪或

每个地下城都使用可能非常昂贵，除非你财力雄厚，否则请节约使用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月24日：** 将液体光泽添加为长战斗中的第二瓶药水，用于斩杀阶段。
- **2026年8月24日：** 将武器附魔更新为哈什之仪。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 更新了武器附魔推荐，并修正了附魔提示链接。
- **2026年6月16日：** 澄清了武器附魔的选择。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月19日：** 更新为推荐吸血附魔而非闪避。更新了宝石建议。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月9日：** 更新了腐蚀附魔部分。
- **2025年4月21日：** 添加了腐蚀附魔信息。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月10日：** 添加了关于移动速度宝石的说明，并总体上更新了宝石配置推荐。
- **2024年9月9日：** 地心之战第1赛季的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已为10.2.5版本进行更新。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月22日：** 更新了推荐的腿部附魔，因为发现微光护甲片并不像之前认为的那样提供耐力。
- **2023年5月12日：** 更新了推荐的食物和腿部附魔。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月23日：** 根据一系列热修复再次更新了推荐的宝石。
- **2023年3月23日：** 在模拟更新以及发现新的强力组合后，更新了推荐的宝石。
- **2023年3月21日：** 根据3月21日的增益更新了黑曜石指环信息。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了推荐的药剂。
- **2022年12月11日：** 更新了最佳药水/药剂的推荐和描述。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的射击 猎人应对大秘境地下城的提示和建议。

1.

### 射击 猎人在至暗之夜第2赛季的大秘境中

在本指南中，我们将讨论如何在大秘境中充分利用你的 猎人

大秘境地下城，包括如何最佳地配置你的角色、你的

循环可能会变化，以及在最

优方式使用技能的提示和技巧。

射击 猎人拥有极其强大的爆发伤害，冷却时间为

90秒或2分钟的冷却时间，通过[[spell:288613]]，取决于你的天赋，

并且可以在该冷却可用的拉怪中占据主导地位。在这些

冷却期间之外，其伤害处于较低水平，所以

在大秘境中优化射击非常依赖于时机把握和

在那些冷却窗口期间完美发挥。

如果你不熟悉大秘境及其相关的一般机制，你可以

你可以在下方我们专门的大秘境页面上阅读更多相关内容。

1.

### 最佳大秘境天赋配置

射击 在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵在大秘境中，毫无例外。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 稍微更肉一些，但 哨兵 伤害更高，而且远

更容易上手。我们为那些偏好的玩家提供了一个黑暗游侠流派

玩法风格或主题幻想。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵大秘境天赋

2.1.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 射击 猎人大秘境天赋构建

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵大秘境构筑，以及

以AOE为主的玩法中的最优配置。它基于对真实

大秘境地下城环境的模拟，不仅看哪种配置能打出最高的DPS，还看

在团队中哪种配置能更快地通关地下城。有些配置能打出更多

AoE能力，但它们在AoE上获得的收益都不及单体输出的损失，反之

亦然。

我们在AOE战斗中使用[[spell:257621]]，将[[spell:185358]]替换为

[[spell:257620]]，使我们的技能造成AOE伤害。

2.2.

#### 猎人射击功能性天赋考量

- 你的'灵活'天赋点，按我们建议的可舍弃顺序为：
  
  
  
  
  可牺牲的：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]]只在某些地下城中有用，
    
    
    
    
    在其他地下城中则毫无价值。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmx2MmZGzwyYaGDmlttZmZmZmZmZhZWGmBAAwDMGDAzYDMAbMz2MG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMeEJRZhpx5BCKSaiqyFmMttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 大秘境天赋

2.3.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 射击 猎人大秘境天赋构建

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) 黑暗游侠 大秘境构筑，以及

以AOE为主的玩法中的最优配置。它基于对真实

大秘境地下城环境的模拟，不仅看哪种配置能打出最高的DPS，还看

在团队中哪种配置能更快地通关地下城。有些配置能打出更多

AoE能力，但它们在AoE上获得的收益都不及单体输出的损失，反之

亦然。

2.4.

#### 猎人射击功能性天赋考量

- 你的'灵活'天赋点，按我们建议的可舍弃顺序为：
  
  
  
  
  可牺牲的：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]]只在某些地下城中有用，
    
    
    
    
    在其他地下城中则毫无价值。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYWAAAAAAAAAzYmZGbzYmZMDLjpZMYW2MjZmZmZmZhZWGmBAAwDMGzMzMgAGgNmZZGD"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMiksw048ABFJNRV5CTm2Wn3HoQRS-AAAA-AGIYgow4ApyCTD-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断

[[spell:147362]] 是你的“打断”，也是你在

大秘境中最重要的功能性技能，用于打断敌人施法以造福团队，尤其是

坦克。它是 **强烈推荐** 使用焦点打断宏来完成此操作。

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 反制射击
```

这个宏会打断你的焦点目标（如果你有焦点目标），鼠标指向目标（如果你有

焦点目标），以及你的当前目标（如果两者都没有）。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用

**鼠标悬停设为焦点宏**.

```wow-macro
/focus [@mouseover]
```

确保你的界面能清晰显示焦点目标的施法，这样你

才能随时在冷却完毕时打断它，或与团队的其他成员配合

打断。

3.2.

#### 眩晕与"打断"

[[spell:474421]]是你第二重要的控制技能，并且是你的

单体“打断”，用于阻止那些通常无法被正常打断的施法。我们

建议以与你的反制射击相同的方式使用它，使用相同的宏

（当然，用胁迫替换反制射击）。通过天赋，它

也可以是一个群体打断。

[[spell:109248]] 可以在混乱时刻用来拯救你的坦克，通过

帮助他们风筝怪物并拉开距离。

[[spell:187650]] 可以作为额外的打断技能，与

[[spell:474421]]，但它的弹道速度很慢，你需要

靠近目标才能在大多数可眩晕的施法结束前命中它。

### 其他功能

3.3.

#### 其他功能

[[spell:5384]] 不仅可以用来脱离仇恨，还可以

使你身上的某些施法和引导失效。在某些情况下，这些机制只会

重新选择团队中的其他人，但偶尔该机制会被

完全消除，并带来巨大收益。如果你注意到有施法或效果作用于你，尝试

用 [[spell:5384]] 应对！点出 [[spell:459517]] 天赋后，它还会

移除你身上所有的中毒和疾病效果。

[[spell:19801]] 可以驱散敌方目标身上有益的激怒和魔法效果

，这经常很有用，而我们的构筑已经点出了

[[spell:459983]]。在某些地下城中，你可能会选择更换

你的默认天赋来获取 [[spell:109248]] 或 [[spell:199483]]。

[[spell:187698]] 可以通过减速怪物来帮助你的坦克风筝。

如果你的坦克死亡，条件反射般地放下一个 焦油陷阱 是很好的，因为它能

让其他人有更好的机会风筝并存活下来。

1.

### 应对词缀

本节包含 猎人 专属的应对各种词缀的技巧

大秘境的。

### 词缀：升腾

4.1.

#### 射击 猎人的升腾词缀应对

使用像[[spell:474421]]这样的AOE控制工具对密集的

宝珠群使用，以尽可能多地消灭它们。你可以使用[[spell:187650]]来处理

剩余的零星目标。

### 词缀：虚缚

4.2.

#### 射击 猎人的虚空束缚词缀应对

这里没什么特别要说的。利用你扎实的切换目标

能力，尽快集火击杀 虚空大使。

### 词缀：脉冲星

4.3.

#### 射击 猎人的脉冲星词缀应对

开启 [[spell:186257]] 并利用你出色的机动性四处冲刺

以尽快拾取尽可能多的球体。

### 词缀：吞噬

4.4.

#### 射击 猎人的吞噬词缀应对

[[spell:5384]] 的中毒/疾病驱散（通过 [[spell:459517]]）是

驱散移除 [[spell:440313]] 所需类型效果的来源。你也可以

用 [[spell:109304]] 治疗掉它，但那会消耗一个GCD。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 阐明了爆发模式和功能说明。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 22 日：** 将哨兵大秘境构筑中哨兵天赋树里的暮光安魂曲替换为潜行与突袭，模拟表现相同，但能带来极小的机动性收益。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月2日：** 更新了黑暗游侠大秘境天赋构筑，特别是功能性天赋选择。
- **2025年8月27日：** 扩展了关于1.5分钟和1分钟构筑的理由说明。
- **2025年8月26日：** 更新了关于黑暗游侠大秘境中在鹰眼视觉和精准射击之间切换的说明。
- **2025年8月11日：** 更新了大秘境构筑推荐。
- **2025年8月6日：** 发送了大秘境职业天赋树更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月15日：** 更新了哨兵大秘境构筑以点出欧恩哈拉之风，因为有证据表明它已被修复，现在在大秘境中能正常工作。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年4月2日：** 更新了哨兵大秘境天赋构筑，添加了关于欧恩哈拉之风存在bug的说明。
- **2025年4月2日：** 更新了大秘境天赋构筑。
- **2025年3月30日：** 添加了关于小型目标猎人可行性的说明。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月18日：** 更新了推荐的大秘境模拟路线Pastebin。更新了大秘境天赋构筑。为其添加了关于乱射的说明。
- **2025年2月27日：** 根据近期模拟工具的发展，更新了哨兵大秘境天赋配置。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月28日：** 更新了大秘境天赋配置——一点天赋的替换。
- **2024年9月27日：** 更新了阿拉卡拉提示。
- **2024年9月13日：** 更新并澄清了一些提示。
- **2024年9月9日：** 地心之战第1赛季的初步更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一些实用的宏和插件，让你在《魔兽世界》12.1.5补丁中使用射击 猎人时更加轻松。

1.

### 最佳宏

1.1.

#### 猎人通用宏

1.1.1.

##### TankMD 插件 + 宏

这会自动为团队中的坦克施放误导，无需

选择目标或设置焦点或任何其他操作。安装插件，设置好宏，你就

万事大吉了。

1. 获取 [TankMD
   
   
   
   
   插件]([https://www.curseforge.com/wow/addons/tankmd](<https://www.curseforge.com/wow/addons/tankmd>)).
2. 设置这个宏：

#### TankMD 误导 宏

```wow-macro
#showtooltip 误导

/click TankMDButton1
```

1.1.2.

##### 焦点鼠标指向宏

严肃大秘境必备的宏。将你的鼠标指向目标设置为

焦点目标，并为其标记绿色标记（除非它已被

其他标记标记过），这样你就可以用下面的宏打断它。

#### 焦点鼠标指向宏

```wow-macro
/focus [@mouseover,harm,exists,nodead][@target,harm,exists,nodead]

/tm [@mouseover,harm,exists,nodead][@target,harm,exists,nodead] 4
```

1.1.3.

##### “自动打断/眩晕”宏

这个宏会自动对随机的正在施法的目标使用你的打断

，无需选择目标、鼠标指向或焦点。我们喜欢它用于

较低层/不协调的钥匙。看到施法？按下宏。第三个宏做同样的

事情，不过是针对 [[spell:19577]]。

#### 自动打断宏（反制射击）

```wow-macro
#showtooltip 反制射击

/cast [@focus,exists,nodead,harm] 反制射击

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast 反制射击

/target focus

/clearfocus

/startattack
```

#### 自动打断宏（口袭）

```wow-macro
#showtooltip 压制

/cast [@focus,exists,nodead,harm] 压制

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast 压制

/target focus

/clearfocus

/startattack
```

#### 自动眩晕宏（胁迫）

```wow-macro
#showtooltip 

/cast [@focus,exists,nodead,harm] 胁迫

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast 胁迫

/target focus

/clearfocus

/startattack
```

请注意，如果你设置了焦点目标，它会优先打断焦点目标。如果你希望

它优先选择鼠标悬停目标，只需将"focus"替换为"mouseover"即可。

1.1.4.

##### 逃脱停止施法宏

这个宏会打断像[[spell:56641]]这样的施法并强制执行

[[spell:781]]，但它不会取消像[[spell:257044]]或

[[spell:1261193]]这样你可以在中途[[spell:781]]的引导法术。

#### 逃脱停止施法宏

```wow-macro
#showtooltip 逃脱

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/use 逃脱
```

1.1.5.

##### 地面目标技能的光标宏

这些宏跳过了使用时的绿色目标圈放置步骤

我们将其用于从[[spell:1543]]到陷阱的所有技能

再到[[spell:109248]]和[[spell:260243]]。

只需将光标放在你想要的位置即可。

#### 光标宏（冰冻陷阱）

```wow-macro
#showtooltip

/use [@cursor]冰冻陷阱
```

#### 光标宏（焦油陷阱）

```wow-macro
#showtooltip

/use [@cursor]焦油陷阱
```

#### 光标宏（束缚射击）

```wow-macro
#showtooltip

/use [@cursor]束缚射击
```

#### 光标宏（乱射）

```wow-macro
#showtooltip

/use [@cursor]乱射
```

#### 光标宏（照明弹）

```wow-macro
#showtooltip

/use [@cursor]照明弹
```

1.1.6.

##### 宠物"重置"宏

当你从悬崖跳下且确实希望宠物跟随你时，这个宏非常有用。

宠物被动和宠物跟随可以让宠物更快地"瞬移"到你身边。

[[spell:1850]]这行确保你的宠物尽可能快地回到你身边。

怪物。

#### 宠物"重置"宏

```wow-macro
/petpassive

/petfollow

/use 急奔
```

1.1.7.

##### 宠物嘲讽宏

在大秘境中，有时在强力小怪释放坦克大招之前嘲讽它们很有用，

这可以帮助保住坦克的性命。你需要使用

甲虫、野猪、Carapid（仅野兽控制）、熔火犬（仅野兽控制）、机械、鳞蜥、

可选择页岩兽（仅限野兽控制）或海龟，因为它们拥有50%减伤，其冷却时间为1分钟

50%伤害减免。

#### 宠物嘲讽宏

```wow-macro
#showtooltip

/use [@mouseover,exists,harm][@focus,exists,harm]低吼

/use 鳞墙

/use Harden Carapace

/use Bristle

/use Bulwark

/use Obsidian Skin

/use Defense Matrix

/use Solid Shell

/use Shell Shield
```

1.1.8.

##### 鼠标悬停宁神射击

对鼠标悬停的敌人使用宁神射击，如果没有有效的悬停目标

则对当前目标使用。

#### 鼠标悬停宁神射击

```wow-macro
#showtooltip

/use [@mouseover,exists,harm,nodead][]宁神射击
```

1.1.9.

##### 灵龟守护取消光环宏

默认游戏中你可以再次按下灵龟守护来取消它，但

其中内置了一个"宽限"期。这个宏跳过宽限期，让你

可以立即激活然后取消灵龟守护。如果你是

那种狂按灵龟守护的玩家，请不要使用这个宏，此宏需要你

用一次按键来有意地激活/取消！

#### 灵龟守护取消光环宏

```wow-macro
#showtooltip 灵龟守护

/stopcasting

/stopcasting

/use 灵龟守护

/cancelaura 灵龟守护
```

1.1.10.

##### 鼠标悬停多重射击

主要用于射击，该专精希望对目标使用[[spell:2643]]

目标使用[[spell:257621]]来激活技巧射击，或者

分散其标记。它没有nochanneling条目，因为射击

专精会故意用[[spell:2643]]来截断[[spell:257044]]的末尾。

#### 鼠标悬停多重射击

```wow-macro
#showtooltip 多重射击

/use [@mouseover,exists,harm,nodead][]多重射击

/petattack

/petassist
```

1.2.

#### 射击宏

1.2.1.

##### 非引导技能宏

我们应该在大多数攻击性技能宏中加入一个非引导的[[spell:257044]]条目，以确保无论我们多么频繁地按键，都不会打断/取消我们的[[spell:257044]]引导。唯一的例外是
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵在AOE战斗中的[[spell:257620]]，我们会故意用它来打断引导。那么，这里有一些技能宏展示了如何以不同方式实现这一点。

#### 非引导瞄准射击

```wow-macro
#showtooltip
/petattack
/use [nochanneling:Rapid Fire]瞄准射击
```

#### 非引导奥术射击

```wow-macro
#showtooltip
/petattack
/use [nochanneling:Rapid Fire]奥术射击
```

#### 非引导夺命射击 + 鼠标指向

```wow-macro
#showtooltip 夺命射击
/stopmacro [channeling:Rapid Fire]
/use [@mouseover,exists,harm][]夺命射击
```

#### 非引导爆炸射击 + 鼠标指向

```wow-macro
#showtooltip 爆炸射击
/stopmacro [channeling:Rapid Fire]
/use [@mouseover,exists,harm][]爆炸射击
```

#### 非引导黑蚀箭 + 鼠标指向

```wow-macro
#showtooltip 黑蚀箭
/stopmacro [channeling:Rapid Fire]
/use [@mouseover,exists,harm][]黑蚀箭
```

#### 非引导急速火焰

```wow-macro
#showtooltip
/use [nochanneling:Rapid Fire]急速射击
```

#### 非引导稳固射击

```wow-macro
#showtooltip 稳固射击
/use [nochanneling:Rapid Fire]稳固射击
```

#### 非引导弹幕 + 光标

```wow-macro
#showtooltip 乱射
/stopmacro [channeling:Rapid Fire]
/use [@cursor]乱射
```

#### 非引导猎人的印记 + 鼠标指向

```wow-macro
#showtooltip
/stopmacro [channeling:Rapid Fire]
/use [@mouseover,harm,exists,nodead][]猎人印记
```

#### 非引导百发百中 + 种族技能

```wow-macro
#showtooltip
/stopmacro [channeling:Rapid Fire]
/use 百发百中
/use 血性狂怒
/use 狂暴
/use 先祖召唤
```

1.

### 最佳插件

2.1.

#### 猎人通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可能值得看看在没有任何额外插件的情况下你能走多远，也许你甚至会享受不必每个补丁都花数小时更新和重新配置界面的感觉。

2.2.

#### 用户界面

2.2.1.

##### EllesmereUI

[EllesmereUI](<https://www.curseforge.com/wow/addons/ellesmereui>)
是对默认用户界面的完整替换。它极其用户友好，设置和掌握所需时间非常少。它还已经配备了几乎你需要的一切：单位框体、团队框体、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，使你的界面完全按照你想要的样式呈现。EllesmereUI简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松追踪基础减益效果和在战斗中快速选择新目标至关重要。虽然一些界面替换自带姓名板，但它们通常功能有限且偶尔有故障。下面列出了一些不错的替代方案。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是由
[plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发的插件，该作者以众多超级有用的插件闻名，例如
[Auctionator](<https://www.curseforge.com/wow/addons/auctionator>),
[Baganator](<https://www.curseforge.com/wow/addons/baganator>),
[Chattynator](<https://www.curseforge.com/wow/addons/chattynator>)等等。他们现在已经开发了一款非常可定制的姓名板插件，提供了大量关于减益效果、状态颜色、图标、材质等的选项。它绝对值得一看，尤其是如果你因为任何原因在使用Plater时遇到问题的话。

2.5.

#### 伤害统计插件

2.5.1.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.6.

#### 射击猎人专用插件

目前我们认为，要发挥射击猎人的全部潜力，并不需要额外的插件。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月31日：** 将自动目标切换多重射击宏替换为鼠标悬停多重射击宏。
- **2026年8月22日：** 指出了唯一一个仍然值得进行的急速 火焰 打断引导操作。
- **2026年8月18日：** 添加了目标切换多重射击宏。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 地心之战第1赛季的初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月11日：** 添加了一个不打断快速火焰的宏。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已为10.2.5版本进行更新。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月25日：** 添加了一个增压乱射宏。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
