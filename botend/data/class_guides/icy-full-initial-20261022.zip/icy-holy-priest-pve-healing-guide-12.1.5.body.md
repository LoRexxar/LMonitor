## 专精概览

欢迎来到我们的《魔兽世界》12.1.5 补丁 神圣 牧师 指南。在这里，你将学习如何在团队副本和大秘境中担任 神圣 牧师 进行治疗。我们涵盖从基础知识到极限优化技术的所有内容，以最大化你的治疗输出。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

神圣大秘境资源

[全新！顶级神圣天赋构建](<https://raider.io/specs/holy-priest/talents>)

[顶级神圣大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/priest/holy>)

[神圣大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=priest--holy>)

[热门神圣队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=priest--holy>)

1.

### 神圣 牧师 概述

神圣 牧师 是一位出色的反应型治疗者。由于能应对几乎所有类型的伤害，你手中总有工具来处理各种情况，并在游玩时保持思考。

作为牧师的神圣专精进行治疗，核心在于所选天赋以及两个神圣言：[[spell:34861]]和[[spell:2050]]。除此之外，你的大部分法术施放是法力高效的[[spell:33076]]，以及用于缩短我们强大的神圣言冷却时间的各种“填充”法术。[[spell:200183]]与[[spell:64843]]的组合为牧师的神圣专精提供了两个易于使用的冷却技能，这对于保持队友存活非常宝贵。

要正确地扮演治疗角色，你需要的不仅仅是职业专属信息。为了更好地理解治疗的通用知识，我们建议你阅读我们的 [治疗指南](<https://www.icy-veins.com/wow/healing-guide>).

反应型治疗者

神圣 牧师 主要是一位反应型治疗者，在小队持续承受伤害的期间，通过利用大量短冷却法术表现出色。虽然缺乏爆发治疗能力有限，但你将拥有工具来应对几乎所有情况下的小队治疗。

持续治疗量

神圣 牧师 在开荒团本中表现出色，提供可靠的持续治疗以及扎实的团队冷却技能，如 [[spell:64843]] 和 [[spell:200183]]。凭借众多短冷却技能以及提供可观的单体和群体治疗能力，它是任何团队中多才多艺的一员。

全能型

神圣 牧师 是大秘境中扎实的全能型治疗者，完全有能力在除最顶尖队伍之外的所有队伍中有效治疗。随着难度增加，提前规划冷却技能的使用以帮助应对高爆发伤害期变得更加重要。

独特功能

神圣 牧师 为任何团队提供了许多关键工具，使其成为令人向往的专精。然而，其中大多数并非 神圣 专属，而是所有牧师都可用的。最有用的是 [[spell:10060]]、[[spell:21562]] 和 [[spell:8122]]。在大秘境中，情境实用性也可能来自 [[spell:453]] 或 [[spell:9484]]。作为 神圣 牧师，主要的独特贡献是能够使用救命的外部技能 [[spell:47788]]。

分层防御

神圣 牧师 的生存能力来自技能组合。单独来看它们并不强大，但组合在一起你可以承受大量伤害。神圣 使用 [[spell:19236]]、[[spell:108945]]、配合 [[spell:193063]] 的 [[spell:2061]]，以及配合 [[spell:373446]] 的 [[spell:586]] 的组合。同时使用其中两个通常足以度过任何危险时刻。

机动性有限

作为 神圣 牧师，机动性将是最难克服的挑战之一，尤其是因为这个专精没有用于快速短距离移动的位移技能。对于长时间的持续移动，我们有 [[spell:121536]]，但该技能不提供任何爆发性移动。

因此，你有时可能需要依赖其他专精的外部移动技能来弥补机动性的不足。你也可以选择拥有移动种族技能的种族，例如虚空精灵的 [[spell:256948]]、地精的 [[spell:69070]]，或龙希尔的 [[spell:131347]]。

1.

### 神圣 牧师 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5 补丁对 神圣 牧师 没有重大改动。此补丁聚焦于两个新的终局内容：一个面向团队副本，一个面向 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。新的基斯希克斯团队副本掉落两件对 神圣 牧师值得关注的物品，两者都不是毕业装备，但如果你仍在使用较低物品等级的装备，它们都是有竞争力的升级。护甲物品是 [[item:281235]]，治疗饰品是 [[item:280835]]。暴击饰品 [[item:281215]] 仅在造成伤害时触发，而 神圣 牧师 造成伤害的频率不足以最大化该饰品的覆盖率，使其成为一个糟糕的选择。新的迷宫巨型地下堡让你有机会为特定部位选择物品，也非常适合填补你拥有较低物品等级装备的任何部位。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

12.1.5 补丁引入了获取 [[item:280562]] 的能力。你将能够在完全升级的 6/6 英雄和神话装备等级的武器、项链和饰品上使用它们，进一步将其升级到更高的飞升物品等级。雾玉也不再有上限，让你可以获得无限数量来升级和制作装备。我们的 12.1.5 补丁中心包含了这些改动及其他所有细节。

2.3.

#### 职业改动

12.1.5 补丁中 神圣 牧师 的唯一改动是两个天赋交换了位置：[[spell:1246517]] 和 [[spell:1215275]]。虽然我们的 [天赋](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>) 配点已更新以反映此改动，但它不会改变任何配点，因为 神圣 敏锐是一个强力天赋，所以两个天赋在各自的配点中都继续被点出。

[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**神圣 牧师**

- [[spell:1215275]] 和 [[spell:1246517]] 在专精树上交换了位置。
  
  
  
  
  - <em>开发者笔记：终极宁静是 神圣 牧师的强大工具，特别是在大秘境中。我们将其在天赋树中上移，以减少 神圣 牧师点出它所需的投资，从而在第二道门槛之后的天赋中提供更多选择。</em>

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_guardianspirit.jpg>) 点击查看上赛季第二赛季的改动
神圣 牧师 在 12.1 补丁中对关键法术的法力消耗进行了多次降低，并提高了某些技能的治疗量，同时对 [[spell:1262755]] 的运作方式进行了机制改动。主要的游戏影响是 [[spell:1262755]] 在激活时变得更加重要需要按下，并且由于每次施放 [[spell:2050]] 都会触发，因此更可靠地可用。

[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**神圣 牧师**

- [[spell:453845]] 经过了轻微重设计：创建一个 [[spell:120517]] 会使治疗效果提高 2%，持续 10 秒，最多叠加 4 层。
- [[spell:64843]]已更新：引导期间现在额外提供[[spell:47788]]。
  
  
  
  
  - <em>开发者说明：我们为引导神圣赞美诗添加了一项增益，使其更易于使用。如果你自身已经有守护之魂激活，神圣赞美诗会将其持续时间延长5秒。如果神圣赞美诗的引导提前结束，它会移除所添加时间中剩余的部分。</em>
- 所有治疗效果提高16%。
- [[spell:200183]]现在使神圣言的法力消耗降低70%（原为50%）。
- [[spell:2061]]法力消耗降低10%。
- [[spell:596]]法力消耗降低10%。
- [[spell:33076]]治疗量提高20%。
- 神谕者：[[spell:1246799]]治疗量提高30%。
- 巅峰天赋：[[spell:1262755]]治疗量提高15%。
- 巅峰天赋：[[spell:1262755]]法力消耗降低30%。
- 巅峰天赋：[[spell:1262760]]（3级）已更新：[[spell:200183]]不再将[[spell:2061]]升级为[[spell:1262755]]。[[spell:2050]]现在有100%的几率将你的下一个[[spell:2061]]升级为[[spell:1262755]]。
  
  
  
  
  - <em>开发者说明：我们希望通过将祝福的可用性扩展到神化和愈合祷言之外来解决祝福的表现问题。此外，我们正在提高祝福的治疗量，使其影响更显著，并为神圣的整体治疗量做出更多贡献。最后，我们希望通过专门针对快速治疗和治疗祷言来进一步降低神圣循环的消耗。</em>

:::

### 至暗之夜改动概述

与许多专精相比，神圣牧师在至暗之夜中的改动并不那么剧烈。我们的一些基础防御能力已移至职业天赋树，随着职业天赋树中多个主动技能的移除，有充足的点数来获取所有治疗量天赋。你剩余的点数可以用来增强你的防御能力或选择一些功能性天赋。神圣天赋树总体上变化较小，与《地心之战》非常相似，唯一的显著例外是[[spell:1246517]]。此外，随着你升级，新的英雄天赋可供选择： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者，以及新的[[spell:1262755]]巅峰天赋。

2.4.

#### 祝福巅峰天赋

升级会为你提供额外的天赋点，你可以用来解锁祝福巅峰天赋，随着你投入点数，它会提供以下增益：

- **第一点：** [[spell:1262755]]使[[spell:33076]]的弹跳周期性地将你的下一次[[spell:2061]]施放转变为[[spell:1262755]]，提高治疗量并触发一次[[spell:238136]]。
- **第二和第三点：** [[spell:1262758]]提高所有治疗量，并进一步提高[[spell:238136]]的治疗量。
- **第四点：** [[spell:1262760]]使[[spell:64843]]的每次脉冲都触发[[spell:238136]]。施放[[spell:2050]]会将你的下一个[[spell:2061]]升级为[[spell:1262755]]。

**运作方式：** 周期性的[[spell:1262755]]触发由定期施放[[spell:33076]]来触发。触发时，[[spell:2061]]会被替换为[[spell:1262755]]供你下一次施放，提供更高的治疗量并触发一次[[spell:238136]]。由于额外的治疗量，[[spell:1262755]]是一个高价值的法术，每次触发时都应在你的循环中优先使用。

2.5.

#### 英雄天赋改动

随着[[spell:120517]]从牧师职业天赋树中移除， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官的天赋位置有所调整，天赋树中的第一个天赋现在是[[spell:120517]]。大部分 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官天赋树保持不变，继续专注于强化[[spell:120517]]并为[[spell:2061]]和[[spell:596]]提供定期增益。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官的玩法与《地心之战》基本相同，唯一的例外是[[spell:1247178]]，它允许使用[[spell:596]]来消耗[[spell:109186]]。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者变化最大，天赋树在《地心之战》中的主要核心
**预警** 已被移除。取而代之的是众多专注于强化[[spell:33076]]的天赋。这包括新的[[spell:1248423]]，提供愈合祷言的额外充能，这对该专精来说是一个极佳的体验改善，尤其是与其他新天赋[[spell:1246799]]搭配时。

及时诊断是《地心之战》第3赛季的套装效果，在你对目标施放[[spell:33076]]时为目标提供可观的治疗。这个天赋有助于减少
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者天赋树的一个弱点，即其单体治疗能力的不足。

另一个值得注意的天赋是[[spell:1246802]]，它延续了旧预警系统中的虔诚效果。由于神圣牧师精通[[spell:77485]]的运作方式，这是我们治疗量的坚实提升，自然也会带来相当数量的过量治疗。

2.6.

#### 玩法变化

神圣牧师的玩法在至暗之夜中依然非常相似。仍然高度专注于尽可能多地使用你的神圣言[[spell:2050]]和[[spell:34861]]，以及你的短冷却法术如[[spell:33076]]，对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官则是[[spell:120517]]。在你的短冷却法术之间，你使用[[spell:2061]]、[[spell:596]]，有时还有[[spell:132157]]来治疗你的团队，具体取决于你所选择的天赋和承受的伤害类型。我们强大的冷却技能[[spell:64843]]和[[spell:200183]]没有发生任何重大变化。

被移除的值得注意的天赋包括 **恢复、治疗术、光明之泉、暗影魔和希望象征**。还有一些其他更具情境性的法术也被移除： **真言术：盾、真言术：生命、神圣之星和神圣之语。**

大多数法术的治疗量和法力消耗也进行了重新平衡，试图将更多重点放在主动治疗法术上，并减少被动天赋对整体治疗量的贡献。这除了让你在使用直接治疗法术如[[spell:596]]时感觉更好之外，不会对你的玩法产生影响，因为它相比被动法术如[[spell:139]]触发能提供更多的治疗量。

[[spell:1246517]]是一个值得注意的新天赋，它为[[spell:2050]]提供额外的威力，并使其为附近盟友恢复相当于其对主要目标治疗量一部分的生命值。它还使[[spell:2050]]能够从通常影响[[spell:34861]]的天赋中获益，例如[[spell:596]]减少[[spell:2050]]的冷却时间。

权衡在于，虽然投入了[[spell:1246517]]的天赋点，但你无法施放[[spell:34861]]。这个天赋旨在介于两个神圣言的功能之间，提供一个更简单的单一按钮，执行相似的治疗量。

[神圣牧师循环](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)

2.7.

#### 生存能力和功能性变化

除了像[[spell:19236]]和[[spell:586]]这样的防御能力被添加为职业天赋树中的天赋外，这个补丁对生存能力或功能性没有重大变化。对各种天赋进行了一些小的改动，包括[[spell:64129]]现在也可以从[[spell:33076]]触发，以及[[spell:9484]]现在除了亡灵外对异怪也有效。

1.

### 神圣牧师游戏基础

神圣牧师被归类为反应型治疗者，这意味着你主要需要对盟友承受的伤害做出反应，然后从你的技能库中施放相应的法术来应对伤害。虽然这种治疗风格使神圣牧师成为较容易上手的治疗者之一，但要掌握可用的治疗法术数量可能需要一些时间。学习神圣牧师时，你应该考虑这三个关键方面。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_serendipity.jpg>) **优先使用神圣言**
  
  
  
  
  神圣的核心机制是[[spell:63733]]，它使你的大多数技能减少[[spell:2050]]和[[spell:34861]]的冷却时间。为了充分利用这种冷却缩减，请优先在[[spell:2061]]和[[spell:596]]等技能之前施放你的神圣言。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_prayerofmendingtga.jpg>) **定期使用短冷却技能**
  
  
  
  
  神圣的短冷却技能应定期使用，以保持最佳的治疗输出和法力效率。[[spell:33076]]最为突出，应在可用时使用，不仅因为其高效的法力治疗，还为了触发我们的巅峰天赋[[spell:1262755]]。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官英雄天赋，你应该定期使用其[[spell:120517]]技能，以充分发挥执政官的潜力。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_surgeoflight.jpg>) **对圣光涌动触发做出反应**
  
  
  
  
  消耗[[spell:109186]]不仅降低其法力消耗，还使你的下一个相关法术变为瞬发，允许你在移动时施放。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官，这一点更为重要，因为有几个天赋增强了消耗[[spell:109186]]的法术的威力，例如[[spell:1247178]]允许你用[[spell:596]]消耗圣光涌动。

1.

### 作为神圣牧师如何配装

虽然我们始终建议你自行模拟以获得理想结果，但我们确实提供了一个专门的 神圣 配装页面。我们目前涵盖了第二赛季装备的推荐，以便你在 至暗之夜 终局内容发布时有一个良好的开端。在你获取了一些装备后，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月17日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 修复了神谕者大秘境配装的导出问题。
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月25日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 根据最新的理论计算更新了配装。
- **2026年8月25日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 更新了循环以匹配天赋配装的更新。
- **2026年8月25日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 根据最新的理论计算更新了配装。
- **2026年8月25日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 根据最新的理论计算更新了配装。
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 针对饰品热修复进行了更新。
- **2026 年 8 月 17 日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 为即将到来的热修复更新了配装。
- **2026年8月16日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 修复了损坏的执政官织光者配装。
- **2026年8月12日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 澄清了关于额外掉落的信息。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 修复了损坏的执政官织光者配装。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已为12.1补丁更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 为即将到来的热修复更新了配装和循环建议。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026 年 6 月 30 日（本页）：** 针对12.0.7补丁神圣言热修复进行了更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已根据12.0.7补丁使用孢子坠落装备进行更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 针对12.0.7补丁和全知全书进行了更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 针对12.0.7补丁功能进行了更新。
- **2026年4月23日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 根据12.0.5补丁修复更新了戒指附魔建议。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 针对12.0.5补丁进行了更新，包括属性递减阈值。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026 年 3 月 31 日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 改进了一些天赋的循环说明。
- **2026 年 3 月 31 日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 更新了灵活天赋。
- **2026年3月25日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 根据最新的理论计算和热修复更新了饰品排名。
- **2026年3月24日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 热修复后移除了关于茶的提及。
- **2026年3月24日（本页）：** 扩展了关键的神圣牧师功能。
- **2026年3月22日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 根据最新的理论计算和修复更新了饰品排名。
- **2026年3月22日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 添加了一些团本法力管理提示。
- **2026年3月22日（本页）：** 更新了没有平衡性改动的信息。
- **2026年3月21日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 根据饰品热修复进行了更新。
- **2026年3月17日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 修复了一个错误的天赋布局。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月5日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 精简了天赋树并添加了更多提示。
- **2026年3月5日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 添加了更多至暗之夜插件。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（本页）：** 为至暗之夜上线进行了更新。
- **2026年2月24日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 为至暗之夜上线再次更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 为至暗之夜前夕再次更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 为至暗之夜前夕再次更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 为至暗之夜前夕再次更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 为至暗之夜前夕再次更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（本页面）：** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对至暗之夜前夕进行更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 针对11.2.7补丁进行了审查。
- **2025年10月11日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 澄清了属性优先级。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 已针对11.2.5版本进行审查。
- **2025年9月9日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 循环修复和改进。
- **2025年9月9日（本页）：** 针对11.2补丁热修复进行了更新。
- **2025年8月15日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 因热修复进行了更新。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月13日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 更新了谜之卡特尔芯片部分。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年4月15日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 根据热修复信息进行了更新。
- **2025年4月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已根据最新热修信息更新。
- **2025年4月15日（本页）：** 已根据最新热修信息更新。
- **2025 年 3 月 25 日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 已根据最新热修信息更新。
- **2025 年 3 月 25 日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已根据最新热修信息更新。
- **2025 年 3 月 25 日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已根据最新热修信息更新。
- **2025年3月25日（本页）：** 已根据最新热修信息更新。
- **2025年3月23日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 重新格式化了页面。
- **2025年3月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 更新了一些提示和天赋。
- **2025年3月21日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 改进了部分法术的说明。
- **2025年3月18日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 改进了第2赛季的地下城提示。
- **2025年3月15日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 更新了WeakAuras字符串。
- **2025年3月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 澄清了第2赛季的一些天赋选择。
- **2025年3月15日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 扩充了部分建议，使其更加清晰。
- **2025年3月13日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 改进了饰品推荐。
- **2025年3月10日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 新增并更新了首领提示。
- **2025年2月26日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 更多11.1补丁消耗品更新。
- **2025年2月26日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 改进了天赋说明。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 因热修复进行了更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 已根据11.1补丁天赋改动更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（本页面）：** 已针对11.1补丁进行更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 根据增益效果和理论计算更新了瑟尔西的指环信息。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 添加了关于瑟尔西的指环的提及
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年11月21日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 改进了装备推荐。
- **2024年10月31日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 更新了一些额外的实用宏。
- **2024年10月22日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已为11.0.5补丁更新并添加了更多提示。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年10月10日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 改进了所有首领的提示和天赋建议。
- **2024年9月15日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 移除了赛季前的装备。
- **2024年9月10日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 添加了更多提示。
- **2024年9月10日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 精简了部分输出循环建议。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月28日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 改进了天赋和输出循环建议。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已为11.0.2补丁更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[地心之战](<https://www.icy-veins.com/wow/holy-priest-the-war-within-pve-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/holy-priest-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年6月18日（[地心之战](<https://www.icy-veins.com/wow/holy-priest-the-war-within-pve-guide>)):** 添加了页面。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/holy-priest-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月23日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 更多《巨龙时代》第4赛季饰品更新。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（本页）：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月29日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对10.2.6版本更新。
- **2024年3月29日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对10.2.6版本更新。
- **2024年3月29日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为10.2.6补丁天赋改动更新。
- **2024年3月29日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对10.2.6版本更新。
- **2024年3月29日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对10.2.6版本更新。
- **2024年3月29日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对10.2.6版本更新。
- **2024年3月29日（本页）：** 已针对10.2.6版本更新。
- **2024年3月17日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对10.2.6版本更新。
- **2024年3月17日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对10.2.6版本更新。
- **2024年3月17日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.6版本更新。
- **2024年3月17日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（本页）：** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2023年11月13日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 更新了毕业装备列表。
- **2023年11月13日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 澄清了第3赛季套装信息。
- **2023年11月8日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 更多10.2更新，包括孢子披风推荐的更改。
- **2023年11月8日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 添加了更多消耗品建议。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已根据10.2补丁改动更新。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已根据10.2补丁改动更新。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 为10.2版本进行了审查。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 为10.2版本进行了审查。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已根据10.2补丁改动更新。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已根据10.2补丁改动更新。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已根据10.2补丁改动更新。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已根据10.2补丁改动更新。
- **2023年9月6日（本页）：** 移除了一些重复信息。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已为10.1.7补丁更新，包括新的毕业装备列表。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已为10.1.7版本审核。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已为10.1.7版本审核。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已为10.1.7版本审核。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已为10.1.7版本审核。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年7月12日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 修复了天赋树显示不正确的问题。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月16日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 小幅更新，包括孢子披风漏洞。
- **2023年5月8日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 修复了一些错误的天赋建议。
- **2023年5月8日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 改进了天赋建议，为第2赛季做好准备。
- **2023年5月8日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 更新了第2赛季的天赋树和说明。
- **2023年5月8日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 改进了天赋建议，包含更多被动技能。
- **2023年5月7日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已根据最新热修改动更新。
- **2023年5月7日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 修复了天赋树缺少一个天赋的问题。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已根据10.1补丁初步信息更新。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已为10.1补丁更新，包括昂萨里克的指环部分。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已为10.1补丁更新，包含新的词缀和天赋改动。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已更新至10.1补丁。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已更新至10.1补丁。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已更新至10.1补丁。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已更新至10.1补丁。
- **2023年5月1日（本页）：** 已更新至10.1补丁。
- **2023年4月29日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 添加了一些额外的宏。
- **2023年3月31日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 进一步的10.0.7补丁更新。
- **2023年3月31日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 进一步的10.0.7补丁更新。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/holy-priest-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已为10.0.7补丁更新。
- **2023年2月27日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 天赋树更新。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已为10.0.5补丁天赋改动更新。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已为10.0.5补丁天赋改动更新。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已为10.0.5补丁天赋改动更新。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2022年12月21日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 添加了一些遗漏的饰品。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 更新了每点属性值收益和属性递减阈值。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/holy-priest-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/holy-priest-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/holy-priest-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/holy-priest-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月22日（[9.2版本分析](<https://www.icy-veins.com/wow/holy-priest-patch-9-2-changes-analysis>)):** 为9.2补丁更新了页面。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/holy-priest-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/holy-priest-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年5月19日（[9.1 补丁分析](<https://www.icy-veins.com/wow/holy-priest-patch-9-1-changes-analysis>)):** 页面已创建。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-crucible-of-storms-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-the-eternal-palace-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2019年9月21日（[永恒宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-the-eternal-palace-raid-guide>)):** 添加了更多首领提示并更新了天赋建议。
- **2019年7月28日（[永恒宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-the-eternal-palace-raid-guide>)):** 在第一个史诗周后更新了各种推荐。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月23日（[风暴熔渣页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-crucible-of-storms-raid-guide>)):** 为两个首领都添加了更多提示。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年3月8日（[达萨罗之战页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** 对首领建议进行了小幅修改。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-battle-of-dazar-alor-raid-guide>)):** 为神圣牧师添加了达萨罗之战提示。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** 针对8.1补丁进行了更新。
- **2018年9月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** 更新了一些天赋建议。
- **2018年8月31日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-uldir-raid-guide>)):** 页面已添加。

显示更多

显示更少

:::

## 练级

在本页，你将找到我们的逐级神圣牧师升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[牧师升级指南](<https://www.icy-veins.com/wow/priest-leveling-guide>).

1.

### 神圣牧师升级指南（适用于至暗之夜）

虽然神圣牧师完全有能力升级，但牧师通常以暗影专精升级，因为它提供更高的伤害，能显著加快任务进程。话虽如此，当进入地下城和PVP战场时，神圣牧师是一种有趣的节奏变换，并且在保全队友方面表现出色。

1.1.

#### 升级装备选择

作为升级中的神圣牧师，配装相当简单，尤其是智力的价值非常高。你的重点应放在尽可能多地获取装备上的智力，这意味着通常优先考虑物品等级。智力会提升你法术造成的伤害以及治疗量。副属性在升级时提供的收益类似但力量显著较小，基本可以忽略。

作为一名牧师，你的武器对伤害和治疗的贡献来自于它提供的智力。应优先选择总智力最高的武器组合，无论是法杖还是主手/副手。使用传家宝物品时，我们推荐选择带有暴击和急速的，因为它们能在升级过程中略微改善游戏体验。

1.2.

#### 至暗之夜升级实用消耗品

虽然终局附魔和消耗品在升级早期通常被禁用或大幅缩减，但仍有一些物品可以让升级过程更顺畅、更快、更少挫折。

《地心之战》的附魔在升级过程中仍然有效，是一种廉价的提升实力的方式。在装备升级稀少的早期，提供急速或速度的附魔尤其有价值。优先考虑以下附魔。

- [[item:223674]]（在你升级过程中急速下降时有所帮助）
- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

[[item:212265]]——在低等级仍可使用的战斗药水可以显著加快困难的拉怪、精英任务或剧情战斗。储备少量以备爆发伤害、治疗或生存能力至关重要的时刻。请务必在到达满级内容之前使用这些药水！

[[item:241305]]——备有一小叠生命药水可以减少对冷却技能和自我治疗的依赖，尤其是在早期等级防御技能尚不完善的时候。这些对于单刷精英任务或意外拉多怪物特别有帮助。

某些消耗品可以显著改善升级流程。

- [[item:109076]]
- [[item:132516]]或[[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]]或[[item:133576]]

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 神圣牧师80级至暗之夜升级
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAMMzsMmxMzYMzALzMzMAAAAmZsNDGPwM2MGjZDmpAYmFMEGWGgBYxMmFAmxMMzgZAMjBA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAMMzsMmxMzYMzALzMzMAAAAmZsNDmZmxmxYMbwMFAzsghwYWGgxALmxsAwMmxMzgZAmZMwA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhlvABNOUXikstHKKQxiqawwIJdmOUcRA-ghiEQRZfjkNOSYeQVsMVl6AB56yEoMB-AAAA-CEMYkow0AUgscA-
```

:::

1.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

3.1.

#### 输出循环

**等级 1–9：**从1级开始，你只有[[spell:585]]，所以目前就一直用它。

1. **等级 13 起：**在13级时你学会[[spell:88625]]，它伤害相当可观，但也会使目标迷惑。它的冷却时间会因施放[[spell:585]]而缩短，所以尽管它有1分钟的冷却时间，你通常可以更早地施放它。
2. **等级 31 起：**[[spell:200183]]在51级可用。施放时，该天赋会为你提供额外的冷却缩减，作用于施放[[spell:585]]时的[[spell:88625]]。
3. **等级 16 起：**[[spell:10060]]是你技能体系中另一个重要的长冷却技能，需要时应使用它来挤出更多伤害。
4. **等级 10 起：**[[spell:14914]]是一个高优先级的伤害法术**等级 17 起：** 无论是单体目标还是范围伤害，都得益于 [[spell:372307]]。
5. **等级 10 起：**[[spell:132157]]是你第一个也是唯一一个可连续施放的群体伤害法术，当面对3个或更多敌人时，它成为你的优先技能。
6. **等级 2–9：**[[spell:589]]是你的第一个持续伤害法术。几乎应该对你战斗的每个怪物都挂上它，这对于快速标记敌人或把它们聚在一起非常有帮助。
7. **等级 10 起：**当没有其他法术可施放时，[[spell:585]]是面对1或2个敌人时的填充法术。

**等级 22 起：**大部分时间里，在做任务时，你会使用[[spell:528]]将大量敌人聚集在一起，然后使用范围法术将它们全部一起击杀。如果你拉了太多敌人或需要逃离它们，使用[[spell:8122]]来阻止敌人攻击你。 **等级 64 起：**你也可以使用[[spell:586]]并利用[[spell:1250378]]天赋，在击杀敌人的同时分散它们的注意力。

**等级 12 起：**为了提高你的机动性，你可以使用这个宏对自己施放[[spell:121536]]，获得速度加成： **/cast [@player] 天堂之羽**.**等级 52 起：** 当你没有 天堂之羽 充能时，你可以对自己施放 [[spell:33076]]，借助 [[spell:64129]] 获得短暂的加速效果。

**等级 6 起：**在6级时，你会学到 [[spell:21562]]；请确保始终为自己和队友保持这个增益效果。

**等级 15 起：**3.2.

#### **等级 15 起：**治疗循环

**等级 15 起：**达到15级后，你就可以排队进入地下城。这条路线最适合 神圣 牧师 这样的治疗专精。正如本攻略前面提到的，建议如果你打算通过做任务升级，在大部分或全部升级旅程中切换到 暗影 专精会快得多。要全面了解完整的技能组合以及如何充分利用它，请查看我们的
[循环页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)。我们的施法优先级总结也可以在下方找到：

- **等级 11 起：**对受伤的队友使用 [[spell:2050]]。
- **等级 15–67：**当队伍中大多数人受伤时使用 [[spell:34861]]。
- **等级 81 起：**可用时使用 [[spell:1262755]]。
- **等级 11 起：**对受伤的队友使用 [[spell:33076]]。
- **等级 3 起：**使用 [[spell:2061]] 进行常规治疗。
- **等级 10 起：**在需要移动和治疗时使用 [[spell:132157]]。
- **等级 1 起：**当不需要治疗时，继续上面的输出循环。

**等级 10 起：**在10级时，你还会获得我们的基础精通技能 [[spell:77485]]。这并不会在很大程度上改变你的游戏方式；它只是以持续治疗（HoT）效果的形式，从你的法术中提供一些额外的治疗量。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月5日：** 精简了天赋树并添加了更多提示。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕再次更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月28日：** 改进了天赋和输出循环建议。
- **2024年8月21日：** 已为11.0.2补丁更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月29日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月12日：** 修复了天赋树显示不正确的问题。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月8日：** 修复了一些错误的天赋建议。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月27日：** 天赋树更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月24日：** 已为10.0.5补丁天赋改动更新。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将介绍如何在魔兽世界12.1.5补丁中轻松游玩 神圣 牧师，使用最简单的输出循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 神圣 牧师 基础知识

本页面面向刚接触游戏或该职业的玩家，无意参与史诗难度团队副本，或者只是想要一种更直接的方式来游玩自己的专精，而不想被为实现最优玩法所需考虑的众多细节和主动技能所淹没。

神圣 牧师 拥有一套多功能的治疗工具箱，通过不同的天赋构建，可以从适合群体/团队治疗转换为强大的单体治疗能力。许多 神圣 牧师 的法术需要站桩施放，这需要一些前瞻性思考才能发挥最优效果，意味着大量移动的阶段有时会很艰难，应该提前规划。在学习 神圣 牧师 时，你应该考虑这三个关键方面。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_serendipity.jpg>) **优先使用神圣言**
  
  
  
  
  神圣的核心机制是[[spell:63733]]，它使你的大多数技能减少[[spell:2050]]和[[spell:34861]]的冷却时间。为了充分利用这种冷却缩减，请优先在[[spell:2061]]和[[spell:596]]等技能之前施放你的神圣言。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_prayerofmendingtga.jpg>) **定期使用短冷却技能**
  
  
  
  
  神圣的短冷却技能应定期使用，以保持最佳的治疗输出和法力效率。[[spell:33076]]最为突出，应在可用时使用，不仅因为其高效的法力治疗，还为了触发我们的巅峰天赋[[spell:1262755]]。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官英雄天赋，你应该定期使用其[[spell:120517]]技能，以充分发挥执政官的潜力。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_surgeoflight.jpg>) **对圣光涌动触发做出反应**
  
  
  
  
  消耗 [[spell:109186]] 不仅能降低法力值消耗，还能使你的下一个相关法术变为瞬发，允许你在移动时施放。正如 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官，这一点更为重要，因为有几个天赋增强了消耗[[spell:109186]]的法术的威力，例如[[spell:1247178]]允许你用[[spell:596]]消耗圣光涌动。

1.

### 至暗之夜 中 神圣 牧师 新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者团本天赋

2.1.

#### 神圣 牧师 团本新手天赋

这些是目前在团队副本内容中最容易上手的天赋选择。请注意，其中一些建议为了易用性牺牲了一点性能，但总体而言，差距并不大。

你可以通过点击“导出天赋”轻松导入下方的天赋树，然后在游戏中进行导入。

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTBwMLYIMmtBYMwiZmZBgZMzYMMzAMzMgB"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOVXikrstHKKRoqGMMSSmmCEFWA-ghZfYei6GJRbcekmq4UskSwBCi55ZZC-AAAA-CEMYkow0AUgscE-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 地下城天赋

2.2.

#### 神圣 牧师 大秘境与地下堡新手天赋

对于大秘境和地下堡，我们建议 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者，因为它简单灵活。然而，对于
[地下堡](<https://www.icy-veins.com/wow/delves-guide>) 地下堡，我们强烈建议你以 暗影 而不是 神圣 来进行，因为 暗影 有更高的伤害输出。如果你仍然选择独自进行，以 神圣 身份，或者以 神圣 身份组队进行，请使用此构建。

你可以通过点击“导出天赋”轻松导入下方的天赋树，然后在游戏中进行导入。

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAghxsMMjZGDzwYZmZmBAAAwYmlZwMzM2MmZMgZKAmZBDhxsNAjBWMmZBgZMzYMYGgZmBMA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZfYeGJRdekmq4Usk648sMB-AAAA-CEMYkow0AUgscE-
```

:::

### 神圣 牧师 基础输出循环

2.3.

#### 神圣 牧师 团队治疗

团队治疗主要侧重于群体治疗，如下所述。你的很多决策将基于即将到来的伤害以及你可用的冷却技能。神圣 牧师 的最佳玩法是尽可能频繁地使用我们的短冷却法术，如 [[spell:2050]] 和 [[spell:33076]]。不要把这些当作需要为未知的未来情况保留的冷却技能；要经常使用它们，以受益于它们的高治疗量和较低的法力值消耗。

以下是你在团队副本中应遵循的基本优先级。你不应该施放大部分会过量治疗的法术，所以在按照优先级列表操作时请记住这一点，如果某项很可能会产生大量过量治疗，就跳过它。

请注意，以下输出循环信息无论是否有当前赛季套装都适用。

1. 对受伤的队友使用 [[spell:2050]]。
2. 冷却完毕时使用 [[spell:33076]]。
3. 使用 [[spell:1262755]] 进行通用治疗。
4. 使用 [[spell:2061]] 进行通用治疗。
5. 当不需要治疗时，对敌人使用 [[spell:585]]。
6. 如果你需要移动且不需要治疗，使用 [[spell:132157]]。

[[spell:1262755]]、[[spell:2061]] 和 [[spell:132157]] 将是你在短冷却法术不可用时的主要施法。由于 [[spell:109186]]，你的许多 [[spell:1262755]] 和 [[spell:2061]] 施法将是瞬发的。当没有需要治疗的目标时，你应该施放 [[spell:585]] 或 [[spell:132157]]，因为它们有几率产生额外的 [[spell:109186]] 层数。[[spell:33076]] 不需要太多思考，对受伤的队友施放是最好的。

每当可用时都应使用 [[spell:200183]] 来帮助应对大范围的团队伤害。在神圣化身期间，你的输出循环不会改变，但你会发现 [[spell:2050]] 可用的频率高得多。在神圣化身期间，重要的是不要让 [[spell:2050]] 的层数达到上限，一旦可用就立即施放它。

[[spell:64843]] 应在大范围团队伤害期间使用。然而，请记住，你的团队领袖可能会指示你在非常特定的时间使用它。

第2赛季的套装在很大程度上是一个被动加成。套装效果对玩法没有重大影响，并鼓励你尽可能频繁地施放 [[spell:33076]]。

2.4.

#### 神圣 牧师 地下城治疗

地下城治疗主要侧重于分诊治疗，即优先治疗最危险的队友。你的很多决策将基于即将到来的伤害以及你可用的冷却技能。尽早且频繁地使用你的冷却技能，比为未知的未来情况保留它们要好。

以下是你在地下城中应遵循的基本优先级。你不应该施放大部分会过量治疗的法术，所以在按照优先级列表操作时请记住这一点，如果某项很可能会产生大量过量治疗，就跳过它。

1. 对受伤的队友使用 [[spell:2050]]。
2. 最好对受伤的队友使用 [[spell:33076]]。
3. 对受伤的队友使用 [[spell:1262755]]。
4. 对受伤的队友使用 [[spell:2061]]。
5. 当不需要治疗时，造成伤害：
   
   
   
   
   1. [[spell:88625]].
   2. [[spell:14914]].
   3. 对3个或更多目标使用 [[spell:132157]]。
   4. 对1或2个目标使用 [[spell:585]]。

面对大量伤害时，使用 [[spell:64843]] 或 [[spell:200183]]，并继续你的常规循环优先级。由于神圣化身会增加你的技能提供的冷却缩减量，[[spell:2050]] 将更频繁地可用，一旦就绪就应使用。如果这还不够，你还可以使用 [[spell:47788]]。

在地下城中处理伤害输出常常被治疗者忽视。虽然任何额外的伤害对你的队伍都有益，但这不应以牺牲保全队伍生命为代价，这是你的首要任务。[[spell:14914]] 是你的主要伤害输出技能。当 神圣 火焰 冷却期间，[[spell:585]] 是最佳的施法选择，因为它消耗的法力值极少，并且有几率触发 [[spell:109186]]。

2.4.1.

##### 重要法术和技巧

无论你正在挑战什么内容，你都应该了解几个基本技能。

- [[spell:527]] 在大多数内容中都会使用，因为许多敌人会在你的队友身上施加魔法或疾病减益效果，可以通过对受影响的队友施放纯净术来驱散。它通常被称为 **驱散**.
- [[spell:21562]] 是一个群体增益效果，持续60分钟或直到死亡，并提供额外5%的耐力。在开始地下城或Boss战之前施加它。
- [[spell:19236]] 是一个主动防御技能，冷却时间为90秒。它会为你恢复最大生命值的一部分，并在一段时间内提高你的最大生命值；应在你的生命受到威胁时使用。

虽然我们有一个更大的章节专门讲解常见错误以及如何避免它们，但有几个值得现在提及。这些集中在我们两个最有价值的资源上：法力值和时间。

法力很容易在不经意间被浪费。最常见的浪费方式是在空闲期或治疗压力较低时 spam 不高效的法术。如果你希望在这些时段保持活跃，请坚持使用[[spell:132157]]或[[spell:585]]，因为这两个法术都有机会触发[[spell:109186]]。当法力将成为问题时，在神圣新星和惩击之外施放输出法术，也是在不经意间额外消耗法力的一种方式。

时间更难量化，但有一件非常简单的事情你可以做，以在地下城和团队副本中获得更多的治疗时间，那就是专注于减少你的移动，以最大化可以用来施放带施法时间法术的时间。在那些你确实需要移动的时段，你可以依赖我们可用的一系列瞬发法术，包括 [[spell:33076]]、[[spell:2050]]、[[spell:34861]]，以及消耗 [[spell:109186]] 层数带来的瞬发治疗。

2.4.2.

##### 冷却技能

作为一名 神圣 牧师，你有三个基础冷却技能。以下是你的使用方式。

- [[spell:64843]] 应在伤害非常密集的期间使用。
- [[spell:200183]] 也应在伤害非常密集的期间使用。
- [[spell:47788]] 的使用取决于许多因素，包括你队伍的指示。如果你不需要为特定事件保留 守护之魂，那么就把它当作坦克或另一个需要的队友的“救命技能”来使用。

2.4.3.

##### 巅峰天赋： ![Benediction Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_priest_holywordlife.jpg>) 祝福

周期性的 [[spell:1262755]] 触发是由经常施放 [[spell:33076]] 引起的。触发时，[[spell:2061]] 会被替换为 [[spell:1262755]] 供你的下一次施放使用，从而增加治疗量并触发 [[spell:238136]]。由于额外的治疗量，[[spell:1262755]] 是一个高价值的法术，一旦触发就应在你的循环中优先使用。

### 神圣 牧师 属性优先级

2.5.

#### 神圣 牧师 属性优先级

目前，智力是你评分最高的属性。因此，在比较要穿戴的装备时，你应该优先考虑物品等级。在两件物品等级相同的情况下，你应按以下顺序为团队副本优先考虑属性。

暴击

精通

全能

急速

对于地下城内容，优先级是：

暴击

全能

急速

精通

关于本页呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>).

### 暴风雪战斗助手

2.6.

#### 我应该使用战斗助手功能吗？

治疗者的战斗助手并不能帮助你治疗。相反，它提供了一个基本的1键输出循环，会根据你的天赋略有调整。请注意，它不会考虑你是否在移动。因此，如果你在移动时试图造成伤害，而战斗助手的建议有施法时间，你就需要手动施放法术。战斗助手也不会建议长冷却法术，如 [[spell:120517]] 或 [[spell:200183]]。

基本循环包括：冷却完毕时使用 [[spell:88625]]；经常使用 [[spell:14914]]；单体目标时，用 [[spell:585]] 填充间隙；多目标时，使用 [[spell:132157]]。

重要的是要注意，战斗助手不能替代对你职业及其机制的理解。它是一个帮助你在不必专注于多个额外按钮的情况下提高伤害输出的工具，是一个可靠的替代方案，可以在不增加治疗时需要考虑的更多事项的情况下增加伤害。

关于这个新功能如何工作的基本信息，请访问我们的 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 指南。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月25日：** 根据最新的理论计算更新了配装。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月15日：** 扩充了部分建议，使其更加清晰。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月29日：** 已针对10.2.6版本更新。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月8日：** 改进了天赋建议，包含更多被动技能。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月24日：** 已为10.0.5补丁天赋改动更新。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到魔兽世界12.1.5补丁中你的 神圣 牧师 的最佳天赋。我们还为团队副本或大秘境等不同类型的内容提供了默认天赋构建。如果你开启了战争模式进行游戏，我们也涵盖了你的PvP天赋。

1.

### 神圣 牧师 的最佳 至暗之夜 天赋

神圣 牧师 有两个完全不同侧重点的英雄天赋。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 为你的武器库添加了法术 [[spell:120517]]，随之带来的是更多需要应对的 [[spell:109186]] 触发，以及 [[spell:1247178]] 让你有另一个法术来消耗它们。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 是一个更简单的选择，围绕着增加像 [[spell:139]] 和 [[spell:33076]] 这样被动治疗来源的治疗量，同时也通过 [[spell:1246799]] 增加了一些单点治疗能力。

- **团队治疗** - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 目前是更强的选择，因为它提供了更持续的治疗能力。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 具有竞争力，但其治疗量更多集中在 [[spell:200183]] 和 [[spell:120517]] 窗口期内，这可能导致更高的过量治疗。
- **地下城治疗** - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 都是地下城治疗的可行选择。虽然 执政官 拥有更强的爆发治疗能力，但在 5 人环境中这样做会消耗大量法力值。神谕者 的持续治疗量使其成为有力的选择，尤其是 神谕者 在造成更多伤害方面也表现出色，这对于争取大秘境计时器非常有用。

除了英雄天赋外，不同构建之间的另一个主要区别在于选择了哪些 神圣 树的终极天赋。[[spell:1246517]] 很受欢迎，因为它与树的其余部分有很好的协同作用，简化了治疗循环，同时提供与其他选择相似的输出。[[spell:471504]] 是一个可靠的被动治疗提升。[[spell:392988]] 并不是一个强大的提升，但如果你选择了前面提到的另外两个终极天赋之一，它很容易获得。[[spell:390992]] 是另一个值得一提的终极天赋，因为它改变了你的玩法，以加强 [[spell:596]] 被你的单体法术增益的循环。目前光织者的调整与其他选项的治疗量相似，但需要更多法力值，且对错误的容忍度更低，所以通常被避免使用。

**快速开始导入代码：**

:::talents 神圣 牧师 团队副本 - 神谕者 简单模式
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTBwMLYIMmtBYMwiZmZBgZMzYMMzAMzMgB"
}
```
:::

:::talents 神圣 牧师 团队副本 - 执政官
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwwsMDzMzMMDzYAzUAgZWMDziBAGD2MzMLAaGzMGDzMbLDwAGA"
}
```
:::

:::talents 神圣 牧师 地下堡 & 大秘境 - 神谕者
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAgZmxsMMjZGDzwYZmZmBAAAwYmlZwMzM2MmZMgZKAmZBDhxsNAjBWMzMLAMjZGjBzAMzMgB"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

神谕者

团队副本

推荐

大秘境/地下堡

大秘境

执政官

团队副本

大秘境结语

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者团队副本构建

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 团队副本构建侧重于来自 [[spell:33076]] 天赋的大量被动治疗和来自 [[spell:1246799]] 的直接治疗。然后你在所有 [[spell:2050]] 和 [[spell:33076]] 施法之间用 [[spell:2061]] 及其强化版本 [[spell:1262755]]（每当触发时）来填充间隙。结合来自 [[spell:139]]、[[spell:77489]] 和 [[spell:1246802]] 的治疗， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 提供了大量稳定的全团治疗，且过量治疗率低。这个构建比 [[spell:390992]] 构建更具法力值效率。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者大秘境天赋

选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 是个人防御、伤害输出和持续治疗的结合。

对于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)，我们强烈建议你以暗影专精进行这些战斗，而不是神圣，因为暗影专精的伤害输出更高。如果你仍然选择以神圣专精单刷，或者以神圣专精组队进行这些战斗，那么请使用这套天赋。最值得做出的改动是针对地下堡的，你应该放弃[[spell:391161]]，如果是单刷则放弃[[spell:73325]]，然后点出[[spell:205364]]。心灵控制在地下堡中可以非常有用，控制一个敌人不仅能造成额外伤害，还能吸收原本会击中你和队友的伤害。

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官团本天赋

团本 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官天赋的核心是依靠[[spell:1247178]]，通过大量由[[spell:109186]]增益的[[spell:596]]施放，配合[[spell:2050]]和[[spell:1262755]]带来的稳定治疗。只要有可能，就应将[[spell:120517]]与[[spell:200183]]或[[spell:64843]]搭配使用，以获得强大的团队治疗效果。

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官大秘境余音天赋

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官余音天赋为神谕者天赋提供了一种替代方案，整体治疗量略低。每次施放[[spell:120517]]时都能提供稳定的治疗爆发，而额外的[[spell:109186]]触发效果非常适合小队紧急治疗，并能促成更多的[[spell:2050]]施放。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTBwMLYIMmtBYMwiZmZBgZMzYMMzAMzMgB"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOVXikrstHKKRoqGMMSSmmCEFWA-ghZfYei6GJRbcekmq4UskSwBCi55ZZC-AAAA-CEMYkow0AUgscE-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAgZmxsMMjZGDzwYZmZmBAAAwYmlZwMzM2MmZMgZKAmZBDhxsNAjBWMzMLAMjZGjBzAMzMgB"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZfYeGJRdekmq4Usk648sMxwwsA-AAAA-CEMYkow0AUgscE-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwwsMDzMzMMDzYAzUAgZWMDziBAGD2MzMLAaGzMGDzMbLDwAGA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOVXikrstHKKRoqGJMMSSmmEFWA-gZabfYeikmoq4GJRVs08k6ABx88EoMB-AAAA-DIMg0IY4IhBQxS-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAMMzsMgZmZYmZGLzMzMAAAAGzsMDmZmxmxMjBMTBAmZzMMbGAYMYzMjFANjZGjBzstMADYA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZabfjkSTUVYceUsk6ABx88EoMB-AAAA-DIMi0Ic4IhBQxS-
```

:::

### 天赋方案 0-0

1.5.

#### 灵活天赋

该 **神圣 牧师** 天赋树中有若干天赋点或天赋点组可以在不影响核心玩法的情况下进行调整：

- 进入每一场战斗时，[[spell:419110]]都应该是你的默认选择，而非[[spell:372370]]。只有在某种原因下你计划 **将每一次施放** 都安排在间隔超过3分钟的情况下，歌之狂风才值得点出。
- 用[[spell:392988]]或[[spell:391186]]替换[[spell:1215265]]会降低治疗量。

该 **职业天赋树** 具有一定的灵活性，你可以根据战斗情况和个人偏好更改多个不同的天赋。以下都是极佳的候选天赋，可以在特定情况下移除而不改变你的玩法：

- 如果没有疾病需要驱散，可以放弃[[spell:390632]]。
- 如果没有疾病需要驱散，也没有魔法减益需要驱散，也可以放弃[[spell:528]]。
- 如果战斗中没有需要[[spell:527]]或[[spell:32375]]应对的情况，可以放弃[[spell:341167]]。
- 如果你真的需要另一个天赋点，可以放弃[[spell:390676]]，因为它是价值最低的治疗量天赋。
- 如果你需要在天赋树底部三分之一区域多分配一个点数，[[spell:108945]]或[[spell:390667]]中的一个点是影响最小的选择。

作为替代，有几个天赋在特定情况下很有用，可以点出：

- 在移动频繁的战斗中，可以点出[[spell:64129]]以获得额外的机动性和生存能力。
- 点出[[spell:108942]]以解除减速效果。
- 点出[[spell:238100]]以提升生存能力。
- 点出[[spell:8122]]以获得更多控制能力。

通常来说，点出[[spell:1246549]]并不是一个好主意，因为它会使[[spell:132157]]不再是可频繁使用的填充法术。

### 天赋方案 1-0

1.6.

#### 灵活天赋

该 **神圣 牧师** 天赋树中有若干天赋点或天赋点组可以在不影响核心玩法的情况下进行调整：

- 如果你无法充分利用额外的[[spell:200183]]持续时间，可以将[[spell:1215245]]换成[[spell:1215241]]。
- [[spell:449874]]与[[spell:454001]]的收益大致相同，可以根据你的喜好自由互换，前提是你能利用延长的[[spell:200183]]持续时间。
- 如果你能找到办法利用[[spell:391124]]带来的额外持续时间，可以将[[spell:453726]]换成[[spell:453729]]。如果你这样做，还应考虑通过放弃[[spell:390977]]或[[spell:1247166]]来点出[[spell:196707]]。
- 进入每一场战斗时，[[spell:419110]]都应该是你的默认选择，而非[[spell:372370]]。只有在某种原因下你计划 **将每一次施放** 都安排在间隔超过3分钟的情况下，歌之狂风才值得点出。

该 **职业天赋树** 具有一定的灵活性，你可以根据战斗情况和个人偏好更改多个不同的天赋。以下都是极佳的候选天赋，可以在特定情况下移除而不改变你的玩法：

- 如果没有疾病需要驱散，可以放弃[[spell:390632]]。
- 如果没有疾病需要驱散，也没有魔法减益需要驱散，也可以放弃[[spell:528]]。
- 如果战斗中没有需要[[spell:527]]或[[spell:32375]]应对的情况，可以放弃[[spell:341167]]。
- 如果你真的需要另一个天赋点，可以放弃[[spell:390676]]，因为它是价值最低的治疗量天赋。
- 如果你需要在天赋树底部三分之一区域多分配一个点数，[[spell:108945]]或[[spell:390667]]中的一个点是影响最小的选择。

作为替代，有几个天赋在特定情况下很有用，可以点出：

- 在移动频繁的战斗中，可以点出[[spell:64129]]以获得额外的机动性和生存能力。
- 点出[[spell:108942]]以解除减速效果。
- 点出[[spell:459559]]以获得更大的施法距离。
- 点出[[spell:8122]]以获得更多控制能力。

通常来说，点出[[spell:1246549]]并不是一个好主意，因为它会使[[spell:132157]]不再是可频繁使用的填充法术。

### 天赋方案 1-1

1.7.

#### 灵活天赋

该 **职业天赋树** 在不放弃重要防御和治疗量天赋的情况下，灵活性有限。

该 **神圣天赋树** 没有太多潜在的天赋更改选项能在不影响整体治疗量和玩法的情况下进行调整。

对于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)，我们强烈建议以暗影专精进行。如果你选择坚持神圣专精，你应该以
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者.

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)专精进行，并在完成多周的任务线后提供一些细微的性能增强自定义选项。其中一些加成会影响你的治疗输出，而另一些则更偏向于防御性质。

我们建议你选择以下增益，但由于你可以随时在它们之间自由切换，如果你觉得推荐的选项收益不够，可以自行尝试其他选项：

- 第1层：[[spell:1279599]]
- 第2层：[[spell:1279603]]
- 第3层：[[spell:1287555]]
- 第4层：[[spell:1279609]]
- 第5层：[[spell:1279614]]

[[spell:1279599]]是比[[spell:1279596]]更好的选择。对于防御节点，你应该选择[[spell:1279603]]或[[spell:1279604]]。对于最终节点，虽然我们建议[[spell:1279614]]因为它能提供更可靠的治疗，但它们提供的价值大致相同，所以选择哪一个在很大程度上取决于个人偏好。

1.

### 巅峰天赋： ![Benediction Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_priest_holywordlife.jpg>) 祝福

神圣牧师的顶点天赋是[[spell:1262755]]，当你投入点数时，它会提供以下加成。

- [[spell:1262755]]（1点）：[[spell:33076]]的跳跃会周期性地将你的下一次[[spell:2061]]施放转化为[[spell:1262755]]，提高治疗量并触发一次[[spell:238136]]。
- [[spell:1262758]]（2点）：提高所有治疗量，并进一步提高[[spell:238136]]的治疗量。
- [[spell:1262760]]（1点）：使[[spell:64843]]的每次脉动都触发一次[[spell:238136]]。施放[[spell:2050]]后，你的下一个[[spell:2061]]会升级为[[spell:1262755]]。

**运作方式：** 周期性的[[spell:1262755]]触发效果由定期施放[[spell:33076]]来触发。触发时，你的下一次[[spell:2061]]施放将被替换为[[spell:1262755]]，提供更高的治疗量并触发一次[[spell:238136]]。由于额外的治疗量，[[spell:1262755]]是一个价值很高的法术，一旦触发就应在你的循环中优先使用。

:::details TCDoes ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者触发[[spell:1262755]]的次数是否多于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官？因为有更多[[spell:33076]]？
不是，

[[spell:1262755]]

以标准化速率触发，意味着两个英雄天赋的每分钟触发次数应该没有差别。只要

[[spell:33076]]

定期施放，这一点就成立。对于两个英雄天赋来说，

[[spell:33076]]

尽可能频繁地施放以最大化

[[spell:1262755]]

的触发次数都很重要。

:::

1.

### 英雄天赋

从71级开始，英雄天赋允许玩家通过选择两个互斥选项中的一个来塑造和聚焦他们的游戏玩法。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官是提供给神圣牧师的选项。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官专注于增益你的[[spell:120517]]施放。额外的更强的[[spell:109186]]触发效果非常适合提升我们的紧急治疗能力，包括通过[[spell:1247178]]增强团队治疗的能力，使[[spell:596]]能够消耗[[spell:109186]]。最后，[[spell:200183]]期间的额外治疗进一步提升了我们应对团队大量伤害的能力。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者专注于定期使用[[spell:33076]]，通过对愈合祷言、[[spell:139]]和[[spell:1246802]]的治疗加成为你的小队提供持续治疗。神谕者还通过[[spell:1246799]]提供单体紧急治疗能力。

1.

### 神圣牧师的PvP天赋（战争模式）

在开放世界中，你可以开启“战争模式”。启用战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提升。
- 练级时获得更多经验值。
- 赚取征服点数，可用于购买PvP装备。

鉴于启用战争模式对练级和PvE内容的好处，如果你能接受PvP，建议开启此功能以最大化你的练级速度和满级后的奖励。但是，这会使你成为开放世界PvP的目标，在练级或做世界任务时有可能被其他玩家攻击。

在本节中，我们将对最适合练级以及单人/小队PvE内容的PvP天赋进行排名。以下是 [神圣 牧师](<https://www.icy-veins.com/wow/holy-priest-pve-healing-guide>)专属PvE天赋的排名。

- [[spell:1256245]]可用于躲避危险的攻击。
- [[spell:196162]]非常适合快速移除危险的减益效果。
- 最后一个选择通常是单人内容选[[spell:357481]]，或者与小队一起进行世界内容时选[[spell:215982]]。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月17日：** 修复了神谕者大秘境配装的导出问题。
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月25日：** 根据最新的理论计算更新了配装。
- **2026年8月17日：** 为即将到来的热修复更新了配装。
- **2026年8月16日：** 修复了损坏的执政官织光者配装。
- **2026年8月12日：** 修复了损坏的执政官织光者配装。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 针对12.0.7补丁和全知全书进行了更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 更新了灵活天赋。
- **2026 年 3 月 17 日：** 修复了一个错误的天赋布局。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕再次更新。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月15日：** 已根据最新热修信息更新。
- **2025年3月25日：** 已根据最新热修信息更新。
- **2025年3月15日：** 澄清了第2赛季的一些天赋选择。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月29日：** 已针对10.2.6版本更新。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 已根据10.2补丁改动更新。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月8日：** 更新了第2赛季的天赋树和说明。
- **2023年5月7日：** 修复了天赋树缺少一个天赋的问题。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月24日：** 已为10.0.5补丁天赋改动更新。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何根据你的小队所承受的伤害类型来优化你的神圣牧师的循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以最大化你的治疗输出和法力效率。我们的所有内容均已针对魔兽世界12.1.5版本更新。

1.

### 神圣牧师玩法与循环指南

欢迎来到我们的神圣牧师循环部分。在这里，你将学到在团队副本和大秘境场景中作为一名神圣牧师正确进行治疗所需的一切知识。

治疗主要取决于你对小队所受伤害的反应能力，因此并没有固定的循环。相反，你必须了解哪些法术最适合战斗中可能出现的各种情况。

:::details 技巧：如何在移动中治疗？
战斗中的移动是不可避免的。不过幸运的是，大多数战斗的流程都是以相当可预测的方式编排的，这不仅能让你提前规划站位，有时甚至可以完全消除移动需求。利用

[[spell:109186]]

触发效果来施放瞬发治疗，以及使用瞬发法术

[[spell:33076]]

和

[[spell:2050]]

可以帮助你在移动中治疗。如果你没有可用的瞬发法术，你也可以使用

[[spell:132157]]

来产生

[[spell:109186]]

触发效果。

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官

团队副本

秘境+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者

团队副本

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

秘境+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:88625]]

[[spell:596]]

[[spell:120517]]

[[spell:14914]]

[[spell:1246549]]

[[spell:1247178]]

[[spell:1246799]]

[[spell:390992]]

[[spell:1246517]]

[[spell:392988]]

[[spell:372307]]

[[spell:372616]]

### 团本治疗循环

团本治疗主要侧重于团队治疗，以及对可能处于死亡危险中的目标进行优先紧急治疗。下一节概述了你在团本中应遵循的优先级。你不应该施放一个会造成大量过量治疗的法术，所以在处理优先级列表时请记住这一点。如果某一项很可能造成大量过量治疗，就跳过它。

**适用条件：Halo（启用）。** **重要提示：** 当游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官专精，你应该尽量在[[spell:64843]]或[[spell:200183]]之前不久使用[[spell:120517]]。虽然这并不总能做到，但不要让[[spell:120517]]的冷却时间空转超过30秒，否则会导致治疗量明显下降。

[[spell:200183]]和[[spell:64843]]是你应该定期使用的强大冷却技能。关于如何以及何时使用它们的更多信息，请参阅下文的“主要冷却技能”部分。

1. **适用条件：Ultimate Serenity（未启用）。** 当你的团本中有多个成员受伤时使用[[spell:34861]]。
2. 对受伤的队友使用 [[spell:2050]]。
3. **适用条件：Divine Image（启用）；神圣 Word: Chastise（启用）。** 使用[[spell:88625]]来触发[[spell:392988]]。
4. **适用条件：Prompt Prognosis（启用）。** 卡冷却使用[[spell:33076]]，最好对受伤的盟友使用。
5. **适用条件：Prompt Prognosis（未启用）。** 卡冷却使用[[spell:33076]]，通常对近战使用。
6. **适用条件：Spiritwell（启用）；治疗祷言（启用）。** 在拥有1层或更多层[[spell:109186]]时施放[[spell:596]]
7. 对受伤的队友使用 [[spell:1262755]]。
8. **适用条件：Lightweaver（启用）；治疗祷言（启用）。** 在拥有1层或更多层[[spell:390992]]时施放[[spell:596]]
9. **适用条件：治疗祷言（启用）；Spiritwell（未启用）。** 在拥有1层或更多层[[spell:109186]]时施放[[spell:2061]]
10. **适用条件：治疗祷言（启用）。** 使用[[spell:596]]进行常规的团队治疗。
11. **适用条件：治疗祷言（启用）。** [[spell:2061]] 在紧急情况下用于濒死的盟友。
12. **适用条件：治疗祷言（未启用）。** 对受伤的队友使用 [[spell:2061]]。
13. 移动中或只需少量治疗时使用 [[spell:132157]]。
14. 当不需要治疗时，对敌人使用 [[spell:585]]。

**适用条件：Lightweaver（启用）；Spiritwell（启用）。**

:::details 常见问题：我应该在没有 Lightweaver 或 Surge of Light 的情况下施放 治疗祷言 吗？
不应该。如果你没有获得其中任意一个

[[spell:390992]]

或

[[spell:109186]]

，你应该改为施放一个

[[spell:2061]]

或

[[spell:1262755]]

以触发新的

[[spell:390992]]

增益效果，供你的下一个使用

[[spell:596]]

.

:::

治疗时的总体目标是尽可能多地施放短冷却时间的法术。[[spell:2050]]、[[spell:34861]] 和 [[spell:33076]]——尽管都有冷却时间——应被视为循环法术，一旦可用就应几乎立即施放。当你的一个 神圣 之言可用时，使用优先级较低的法术被视为失误，因为它会浪费法力且治疗量更低。这种失误的例子包括：施放 [[spell:2061]] 而非 [[spell:2050]]；施放 [[spell:596]] 而非 [[spell:34861]]。

以下是一些运用天赋的技巧：

- **适用条件：Spiritwell（启用）；治疗祷言（启用）。** 由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 对于 执政官 的天赋 [[spell:1247178]]，你应该设法将所有 [[spell:109186]] 触发效果用于 [[spell:596]]。这能最大化 [[spell:453799]] 的治疗输出，同时也能充分利用 [[spell:109186]] 提供的法力消耗降低效果。
- **适用条件：Halo（启用）。** 由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 对于 执政官，[[spell:120517]] 应尽可能与你的主要冷却技能 [[spell:200183]] 和 [[spell:64843]] 配合使用。更多关于最大化其使用效率的详情，请参阅下文的冷却技能部分。
- **适用条件：Lightweaver（启用）；治疗祷言（启用）。** [[spell:1262755]] 用于生成 [[spell:390992]] 层数。这些层数随后应用于 [[spell:596]] 以提升治疗量。仅通过你的 Benediction 施法就能生成足够的 Lightweaver 层数，在没有 [[spell:109186]] 增益的情况下施放 [[spell:2061]] 会浪费法力。
- **适用条件：Prompt Prognosis（启用）。** 由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 对于 神谕者，尽可能对受伤的盟友施放 [[spell:33076]]，以充分利用 [[spell:1246799]]。如果你已达到最大充能层数，不应延迟施放 [[spell:33076]] 去等待受伤的盟友。相反，应立即施放一次 [[spell:33076]] 使其进入冷却。
- **适用条件：Empyreal Blaze（启用）。** [[spell:372616]] 能显著提升你的伤害输出，但代价是 [[spell:109186]] 的触发次数会减少，因为 [[spell:14914]] 无法触发 [[spell:109186]]。如果治疗是你的主要职责，你应该坚持将 [[spell:585]] 作为你的主要伤害技能。

1.1.

#### 法力管理技巧

如果你在较长的战斗中法力吃紧，以下是一些快速技巧，可在不过度牺牲治疗量的前提下提升你的效率。

充分利用我们高效的冷却技能。这些技能应被视为循环法术，在团队受到伤害时尽可能频繁地使用。包括：

- **适用条件：Halo（未启用）。** 较长冷却时间的 [[spell:64843]] 和 [[spell:200183]]。
- **适用条件：Halo（启用）。** 较长冷却时间的 [[spell:64843]]、[[spell:200183]] 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon 的 [[spell:120517]]。
- **适用条件：Ultimate Serenity（未启用）。** 短冷却时间的法术 [[spell:2050]]、[[spell:34861]] 和 [[spell:33076]]。
- **适用条件：Ultimate Serenity（启用）。** 短冷却时间的法术 [[spell:2050]] 和 [[spell:33076]]。

**适用条件：Spiritwell（启用）。** 尽可能优先将你的 [[spell:109186]] 施放于 [[spell:596]]。Surge of Light 会为消耗它的法术提供法力消耗降低效果，帮助你用更少的法力完成更多的治疗。

**适用条件：Spiritwell（启用）。** 只有当有人面临死亡危险，而你又没有其他可用手段（例如 [[spell:47788]]）来拯救他们时，才使用 [[spell:2061]]。

当你的盟友不需要治疗时，多施放 [[spell:132157]] 和 [[spell:585]]。这不仅能触发更多 [[spell:109186]]，还能节省法力，避免将法力浪费在对健康盟友的过量治疗上。

### 大秘境输出循环

副本治疗主要侧重于定期施放你的短冷却时间法术。你的许多决策将取决于受到的伤害以及你可用的冷却技能。尽早且频繁地使用你的冷却技能，比为未知的未来情况保留它们要好。

以下是你在副本中应遵循的优先级。你不应施放会导致大量过量治疗的法术；在按优先级列表行动时请记住这一点。如果某项很可能造成大量过量治疗，则跳过该项。

1. 应对大量团队范围伤害时使用 [[spell:64843]]。
2. 当每种 神圣 之言拥有 0 或 1 层充能时使用 [[spell:200183]]。
3. **适用条件：Ultimate Serenity（未启用）。** 当一群盟友受伤时使用 [[spell:34861]]。
4. 对受伤的队友使用 [[spell:2050]]。
5. **适用条件：Halo（启用）。** 当大多数盟友受伤时使用 [[spell:120517]]。
6. **适用条件：神圣 Word: Chastise（启用）；Divine Image（启用）。** 施放 [[spell:88625]] 以触发 [[spell:392988]]
7. 对受伤的队友使用 [[spell:1262755]]。
8. **适用条件：Prompt Prognosis（启用）。** 卡冷却使用[[spell:33076]]，最好对受伤的盟友使用。
9. **适用条件：Prompt Prognosis（未启用）。** 卡冷却使用[[spell:33076]]，通常对近战使用。
10. **适用条件：Spiritwell（未启用）。** 在拥有1层或更多层[[spell:109186]]时施放[[spell:2061]]
11. **适用条件：Spiritwell（启用）；治疗祷言（启用）。** 当拥有 1 层或更多 [[spell:109186]] 层数时施放 [[spell:596]]。
12. **适用条件：治疗祷言（启用）；Lightweaver（未启用）。** 施放 [[spell:596]] 进行常规治疗。
13. **适用条件：治疗祷言（未启用）。** 使用 [[spell:2061]] 进行通用治疗。
14. **适用条件：治疗祷言（启用）；Lightweaver（启用）。** 当拥有 1 层或更多 [[spell:390992]] 层数时施放 [[spell:596]] 进行常规治疗。
15. **适用条件：治疗祷言（启用）；Lightweaver（启用）。** 当 [[spell:390992]] 层数少于 4 层时施放 [[spell:2061]]。
16. **适用条件：神圣 Word: Chastise（启用）。** 无需治疗时对敌人施放 [[spell:88625]]。
17. **适用条件：Empyreal Blaze（启用）。** 无需治疗时对敌人施放 [[spell:14914]]。
18. **适用条件：Lightburst（未启用）。** 移动中或只需少量治疗时使用 [[spell:132157]]。
19. 当不需要治疗时，对敌人使用 [[spell:585]]。

### 输出

当你专注于团队治疗时，你唯一的伤害法术应该是 [[spell:585]] 或 [[spell:132157]]。它们的法力消耗都非常低，并且有几率触发 [[spell:109186]]。[[spell:109186]] 触发不仅能提升治疗量，还有助于移动和节省法力。如果某场战斗需要伤害而非治疗，且你发现法力不是问题，那么你可以使用完整的伤害循环。

在副本中输出伤害常常被治疗者忽视。虽然任何额外的伤害对你的团队都有益，但它不应以牺牲团队存活为代价，而保全团队才是你的首要职责。[[spell:14914]] 是你与 [[spell:372307]] 和 [[spell:372616]] 配合时的主要伤害技能。

伤害法术优先级：

1. **适用条件：Halo（启用）。** [[spell:120517]]
2. [[spell:14914]]
3. **适用条件：神圣 Word: Chastise（启用）。** [[spell:88625]]
4. **适用条件：Lightburst（未启用）。** [[spell:132157]]（4 个以上敌人）
5. **适用条件：Lightburst（未启用）。** [[spell:585]]（1-3 个敌人）
6. **适用条件：Lightburst（启用）。** [[spell:132157]]
7. **适用条件：Lightburst（启用）。** [[spell:585]]
8.

### 至暗之夜 第2赛季套装

第 2 赛季的套装效果在很大程度上是被动加成。套装加成对玩法没有重大影响，它鼓励你尽可能频繁地施放 [[spell:33076]]，以通过属性增益和额外的 [[spell:139]] 最大化套装加成提供的额外治疗量。

1.

### 职业与专精机制详解

### 神圣 之言与 [[spell:63733]]

3.1.

#### 神圣 之言

尽可能频繁地施放你的 神圣 之言是玩好 神圣 牧师 的重要组成部分。当施放相关法术时，每个 神圣 之言会通过 [[spell:63733]] 获得冷却时间缩短，使你能更频繁地施放它们：

- [[spell:2050]] - 每次由 [[spell:2061]] 缩短 6 秒。
- [[spell:34861]] - 由 [[spell:596]] 缩短 6 秒。
- [[spell:88625]] - 每次由 [[spell:585]] 和 [[spell:132157]] 缩短 4 秒。

当点出 [[spell:390994]] 天赋时，你还能从额外的法术中获得冷却时间缩短：

- [[spell:2050]] - 由 [[spell:33076]] 缩短 4 秒。
- [[spell:34861]] - 由 [[spell:120517]] 缩短 4 秒。
- [[spell:88625]] - 由 [[spell:14914]] 缩短 4 秒。

当点出 [[spell:1246517]] 天赋时，任何通常会为 [[spell:34861]] 触发冷却时间缩短的效果，都会转而缩短 [[spell:2050]] 的冷却时间。

有多种方法可以进一步增加你从施法中获得的冷却时间缩短：

- [[spell:200183]] - 当此增益激活时，你对所有 神圣 之言获得 3 倍的冷却时间缩短。
- [[spell:196985]] - 点出天赋后，你每点投入都会使所有 神圣 之言的冷却时间缩短效果提高 10%。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) Archon 的 [[spell:453828]] - 点出天赋后，在消耗 [[spell:109186]] 时提供 神圣 之言的冷却时间缩短。

虽然你不需要以任何方式主动管理这个机制，但了解它的存在并持续关注你的 神圣 之言的剩余冷却时间非常重要，这样你才能在它们可用时立即使用。

### [[spell:77489]]

3.2.

#### 精通：回响 光芒

[[spell:77485]] 是一项被动技能，使你的直接治疗法术在目标身上留下一个持续治疗效果。该效果持续 4 秒，并按原始治疗量的一定百分比进行治疗。治疗量由你的精通属性提升。该持续治疗效果的连续施放会叠加，并会短暂延长其持续时间。对同一目标连续施法不会损失精通治疗量，额外的施法只会使 回响 光芒的治疗跳数更强。

追踪此增益没有好处，因为没有任何与之相关的交互值得用额外的图标来使你的界面变得杂乱。

[[spell:77485]] 还会增加你的 [[spell:139]] 的治疗跳数。

天赋 [[spell:390967]] 会略微提升精通的治疗量，同时也提升 [[spell:139]] 的治疗量。

[神圣 牧师 属性优先级](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)

### [[spell:392988]]

3.3.

#### 神圣镜像

当点出 [[spell:392988]] 天赋时，无论你是否激活了纳鲁，你的玩法都不应有太大改变。你仍然应该强调施放适合当前情况的法术，纳鲁会相应地进行镜像。唯一的例外是 [[spell:88625]]，它可以在高强度治疗阶段之前使用，以提供额外的爆发治疗。

为了更好地利用 [[spell:392988]]，唯一值得做的微小玩法调整是确保你尽量将 [[spell:33076]] 施放在紧密聚集的盟友群中，因为 [[spell:196813]] 的弹跳半径相当小。这通常是团队中的近战 DPS，如果这样做会延迟你的 [[spell:33076]] 施放，那就不值得为此担心。

下表列出了大多数会触发 [[spell:392988]] 尝试施放类似法术的常见法术。

<table>&#10;<tr>&#10;<th>你的法术</th>&#10;<th>[[spell:392988]]</th>&#10;<th>你的法术</th>&#10;<th>[[spell:392988]]</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<ul>&#10;<li>[[spell:2061]]</li>&#10;<li>[[spell:2050]]</li>&#10;<li>[[spell:19236]]</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196809]]</td>&#10;<td>&#10;<ul>&#10;<li>[[spell:596]]</li>&#10;<li>[[spell:34861]]</li>&#10;<li>[[spell:120517]]</li>&#10;<li>[[spell:64843]]</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196810]]</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<ul>&#10;<li>[[spell:33076]]</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196813]]</td>&#10;<td rowspan="3">&#10;<ul>&#10;<li>[[spell:585]]</li>&#10;<li>[[spell:14914]]</li>&#10;<li>[[spell:88625]]</li>&#10;<li>[[spell:32379]]</li>&#10;</ul>&#10;</td>&#10;<td rowspan="3">[[spell:196811]]</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<ul>&#10;<li>-</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196816]]</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<ul>&#10;<li>[[spell:132157]]</li>&#10;</ul>&#10;</td>&#10;<td>[[spell:196812]]</td>&#10;</tr>&#10;</table>

### [[spell:1262755]] Apex 天赋

3.4.

#### 祝福巅峰天赋

在 至暗之夜 中，我们获得了 Benediction Apex 天赋，随着你投入点数，它提供以下好处：

- [[spell:1262755]]（1点）：[[spell:33076]]的跳跃会周期性地将你的下一次[[spell:2061]]施放转化为[[spell:1262755]]，提高治疗量并触发一次[[spell:238136]]。
- [[spell:1262758]]（2点）：提高所有治疗量，并进一步提高[[spell:238136]]的治疗量。
- [[spell:1262760]]（1点）：使[[spell:64843]]的每次脉动都触发一次[[spell:238136]]。施放[[spell:2050]]后，你的下一个[[spell:2061]]会升级为[[spell:1262755]]。

周期性的 [[spell:1262755]] 触发由定期施放 [[spell:33076]] 来触发。触发时，[[spell:2061]] 会在你的下一次施法中被替换为 [[spell:1262755]]，从而提升治疗量并触发 [[spell:238136]]。由于额外的治疗量，[[spell:1262755]] 是一个高价值的法术，每当它触发时都应作为你循环的一部分优先使用。

:::details TCDoes ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者触发[[spell:1262755]]的次数是否多于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官？因为有更多[[spell:33076]]？
不是，

[[spell:1262755]]

以标准化速率触发，意味着两个英雄天赋的每分钟触发次数应该没有差别。只要

[[spell:33076]]

定期施放，这一点就成立。对于两个英雄天赋来说，

[[spell:33076]]

尽可能频繁地施放以最大化

[[spell:1262755]]

的触发次数都很重要。

:::

### 其他天赋

3.5.

#### 其他天赋

3.5.1.

##### Lightweaver

点出 [[spell:390992]] 天赋后，目标是在 [[spell:2061]] 和 [[spell:596]] 之间交替施放，利用 [[spell:2061]] 生成的增益来强化 [[spell:596]] 的施放。理想情况下，你应该在 [[spell:390992]] 增益激活的情况下才施放 [[spell:596]]。如果玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 并点出 [[spell:1247178]] 天赋时，尽量保留一层 [[spell:390992]] 充能，这样你就可以用 Lightweaver 增益的 [[spell:596]] 来消耗你的下一个 [[spell:109186]]。

3.5.2.

##### 创造奇迹

[[spell:235587]] 为你的 [[spell:2050]] 和 [[spell:34861]] 各提供一层额外充能。当使用 Miracle Worker 时，你仍然要避免充能达到 2 层上限，以最大化施放其他法术提供的冷却时间缩短。例外情况是当非常近的将来会有大量伤害时，此时短暂保留 2 层充能可能是有益的。

3.5.3.

##### Epiphany

[[spell:414553]] 有很大的潜力，但许多 神圣 牧师常常忽略它。确保你有良好的方式来追踪 [[spell:33076]] 何时就绪，对于最大化该天赋的价值至关重要。

你可以通过在获得 Epiphany 触发时，尽量避免连续施放两个神圣之言（[[spell:2050]] 或 [[spell:34861]]），而是改为施放 [[spell:33076]]，来进一步最大化 [[spell:414553]] 的价值。

3.5.4.

##### 更多天赋阅读

有关各种天赋之间协同作用的更多信息，以及决定你可以更改哪些天赋及其原因，请查看 神圣 牧师 天赋页面。

[神圣 牧师 天赋](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)

1.

### 神圣 牧师 的重要冷却技能

### [[spell:200183]]

4.1.

#### 神圣化身

[[spell:200183]]是一个重要的长冷却技能，你应该尽可能频繁地使用。有数个天赋可以强化神圣化身：

- [[spell:1215245]]延长神圣化身的持续时间。
- [[spell:1215241]]强化神圣化身的爆发治疗，使其更加强力并提升你的机动性。
- [[spell:392988]]没有直接的互动，但更多的神圣言会使神圣镜像成为更有效的天赋。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官的[[spell:453917]]会在神圣化身激活期间提高你造成的治疗量。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官的[[spell:454001]]非常擅长在每分钟内提供额外几秒的神圣化身覆盖时间。

由于[[spell:200183]]还提高了施放技能时获得的神圣言冷却缩减，它提升了神圣化身期间某些法术的优先级，以帮助快速让神圣言冷却完毕：

- [[spell:33076]] - 当点出[[spell:390994]]和[[spell:392988]]时，愈合祷言成为高优先级的施法选择。由于[[spell:200183]]期间神圣言的施放次数很多，如果你点出了[[spell:414553]]，愈合祷言的冷却重置会非常频繁。
- [[spell:2061]] - 当点出 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官的[[spell:453828]]并且有[[spell:109186]]触发时，由于额外的冷却缩减，快速治疗是高优先级的。
- [[spell:120517]] - 由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官的[[spell:453783]]，在[[spell:200183]]之前或期间使用光晕对于获得额外的[[spell:109186]]触发非常重要。除此之外还有来自 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官's [[spell:453845]].

虽然由于时间轴对齐的问题并不总能实现，但理想情况下应将[[spell:200183]]与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官配合的理想使用方式如下：

1. [[spell:34861]] - 如果点出，使其进入冷却。
2. [[spell:2050]] - 使其进入冷却。
3. [[spell:88625]] - 如果点出，使其进入冷却。
4. [[spell:33076]] - 使其进入冷却。
5. [[spell:120517]] - 开始产生[[spell:109186]]触发并开始叠加[[spell:453845]]。
6. [[spell:200183]] - 恢复每种神圣言的一层充能。
7. [[spell:10060]] - 如果你不需要在特定时间使用它。
8. 恢复常规循环。

### [[spell:64843]]

4.2.

#### 神圣赞美诗

[[spell:64843]]是一个重要的长冷却技能，可以治疗所有附近盟友，在引导期间脉冲治疗。最好在团队承受大量伤害且你需要快速治疗所有人时使用。请注意该法术是引导性的，因此施法期间你无法移动或执行其他动作，不过在神圣赞美诗持续期间你会获得[[spell:47788]]来帮助你承受一些即将到来的伤害。

在团队副本中，团队领袖通常会指定你在战斗的某个特定时间使用该法术来应对一波高额爆发伤害。如果情况如此，请确保你的法术在那个时间可用。否则，你应该简单地寻找一个使用该法术有利的时机。最常见的情况是在团队承受非常猛烈的AOE伤害期间。

在进行大秘境时，[[spell:64843]]通常在伤害命中团队之前使用，因为它提供的治疗量不足以完全应对最高伤害的AOE技能。通常会这样安排时间，使神圣赞美诗的最后几秒正好是团队承受伤害的时候。这样你就能为所有盟友完全叠加神圣赞美诗的增益效果，同时仍然能够对濒死目标进行紧急治疗。

有两个主要天赋会影响你使用[[spell:64843]]的方式：

- [[spell:419110]] - 缩短神圣赞美的冷却时间，使其可以更频繁地使用。
- [[spell:372370]] - 每次神圣赞美诗脉冲时，会在附近盟友身上放置数层[[spell:33076]]。

要查看我们推荐使用哪些天赋，请参阅我们的专属天赋构筑章节！

[神圣牧师天赋与构筑](<https://www.icy-veins.com/wow/holy-priest-pve-healing-spec-builds-talents>)

### [[spell:47788]]

4.3.

#### 守护之魂

[[spell:47788]]是你能带进团队副本的最有用的工具之一。使用它会在目标身上放置一个增益效果，持续10秒，使目标受到的所有治疗提高60%。如果目标在此期间受到致命打击，他们不会死亡，而是恢复最大生命值的40%，并消耗守护之魂效果。

虽然你可以将它用在任何即将死亡且你没有其他手段拯救的团队成员身上，但将其用在一个即将承受大量伤害的坦克身上要好得多。你应该确保与坦克和其他治疗者沟通，以确保你们不会同时使用多个强力冷却技能。

你也可以使用这个法术让坦克（或其他玩家）承受一个本应避免的技能，无论是作为团队策略的一部分还是为了从失误中恢复。

请注意，你的团队领袖可能会指定你在战斗中的特定事件使用该法术。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月25日：** 更新了循环以匹配天赋配装的更新。
- **2026年8月10日：** 为即将到来的热修复更新了配装和循环建议。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 改进了一些天赋的循环说明。
- **2026 年 3 月 22 日：** 添加了一些团本法力管理提示。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕再次更新。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月9日：** 循环修复和改进。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月15日：** 根据热修复信息进行了更新。
- **2025年3月21日：** 改进了部分法术的说明。
- **2025年2月26日：** 改进了天赋说明。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月10日：** 精简了部分输出循环建议。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月29日：** 已为10.2.6补丁天赋改动更新。
- **2024年3月17日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月13日：** 澄清了第3赛季套装信息。
- **2023年11月6日：** 已根据10.2补丁改动更新。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到魔兽世界12.1.5中你的神圣牧师的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们应有尽有！

1.

### 神圣牧师毕业装备指南

欢迎来到至暗之夜的神圣牧师装备与毕业页面。查看本页了解有关为神圣牧师配装所需的一切信息，包括来自所有来源（如团队副本和大秘境）的毕业装备；最佳饰品信息；套装；以及更多内容。

由于提供副属性的装备种类繁多，对我们而言其价值都非常接近，再加上插槽或第三属性等增强，不存在一个确定的毕业装备列表。本页旨在引导你找到最佳可能的物品，特别是在饰品栏位。

对于未被套装或饰品/武器效果占用的常规物品栏位，你需要在关注物品等级的同时牢记以下几点：

- **插槽** — 约6个物品等级。
- **吸血** — 约6个物品等级。
- **闪避** — 约4个物品等级。

:::details TC我的吸血属性价值会随着获取更多而下降吗？
吸血属性的价值会随着你获取越多而递减。在你拥有2-3件带吸血的装备之前它相当有价值；之后，其价值可能会显著下降。如果你从装备中获得了这么多吸血属性，请优先考虑物品等级。

:::

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

这个列表是至暗之夜第2赛季中神圣牧师来自所有来源的毕业装备的一个很好的示例。

请注意，不存在单一、全面的“毕业（BiS）”装备。最好的装备因角色和情况而异，而且有很多装备在每秒治疗量（HPS）方面本质上是等效的，尤其是当我们只是在调整次要属性时。我们将为每个部位列出一件“毕业”装备，有时如果我们认为有显著差异，会列出两件。

:::details 常见问题我需要哪些套装部件？
由于现在可以将物品催化成套装并保留其属性，因此不再有特定的栏位是你必须追求套装的。你的首要任务仍然是尽快凑齐4件套，然后利用额外的催化次数来更好地为那些栏位配装。特别值得注意的是

[[item:271874@JAAGAAwF0YhNYYD]]

来自

[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

它可以被催化成套装头盔同时保留精通效果，使其成为一件极其强大的物品。以下是每个栏位建议催化的物品列表。

<table> <tr> <th>部位</th> <th>物品</th> <th>来源</th> </tr> <tr> <td>头部</td> <td>[[item:271874@JAAGAAwF0YhNYYD]]</td> <td><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td> </tr> <tr> <td>护肩</td> <td>套装代币，不要催化</td> <td><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td> </tr> <tr> <td>胸部</td> <td>[[item:268221@JAAEAAwF0YjM]]</td> <td><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a> 位于 <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></td> </tr> <tr> <td>手套</td> <td>[[item:268243@JAAEAAwF0ghN]]</td> <td><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td> </tr> <tr> <td>腿部</td> <td>[[item:159234@JAAEAAAg0YjM]]</td> <td><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td> </tr> </table>

:::

:::details 小贴士为什么你建议制造副手，即使它不是毕业装备？
它严格来说不是毕业装备，但非常接近，而且是在你配装初期高效使用迷雾纹章的绝佳选择。如果你能在神话难度获得副手，它会比制造的略好，但如果你想把迷雾纹章留给其他物品，制造的仍然是一个非常好的选择。

:::

:::details 常见问题：从宏伟宝库中获取什么？
由于第2赛季额外掉落机制的改变，假设你很可能在前几周通关英雄难度 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) ，你应该从你的前3个宝库中选择 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 来自你的前3次宏伟宝库。这使你可以对英雄难度的目标进行额外拾取 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) ，这将奖励1/6神话路线的物品。该Boss的全部3件物品都有强力效果且是毕业装备，因此这种方法让你能尽快获取全部3件。

一旦你从英雄难度获得了那些强力物品 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)，你就可以专注于完成其余的装备提升。通常，你的首要任务应该是尽快获得你的4件套套装奖励，然后从武器和饰品等更有影响力的栏位选择升级。如果你的宝库没有显著的升级，你可以通过使用额外掉落并将其用在相应的团队Boss身上来定向获取装备。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271555@JAACAAAG2A]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:239649@JAAKAAwt1wgNRDzViAGM]]&#10;&#10;<div>[[item:240910]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270164@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAKAAwt1wgNRDzViAGM]]&#10;&#10;<div>[[item:240910]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:270162@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268263@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span></div></td></tr></tbody></table>

### 秘境+

这个列表包含至暗之夜第2赛季大秘境中神圣牧师的毕业装备。

请注意，此毕业列表适用于来自 **来自** 地下城的物品。我们按 **装备来源**划分毕业列表。这是当你想通过仅从地下城收集装备来 **为团队副本** 提升装备时可以追求的列表。

不存在单一、全面的“毕业（BiS）”装备。最好的装备因角色和情况而异，而且有很多装备在每秒治疗量（HPS）方面本质上是等效的，尤其是当我们只是在调整次要属性时。我们将为每个部位列出一件“毕业”装备，有时如果我们认为有显著差异，会列出两件，但最终，随着你接触到更多内容，毕业装备会不断变化。

:::details 常见问题我需要哪些套装部件？
由于现在可以将物品催化成套装并保留其属性，因此不再有特定的栏位是你必须追求套装的。你的首要任务仍然是尽快凑齐4件套，然后利用额外的催化次数来更好地为那些栏位配装。以下是每个栏位建议催化的物品列表。

<table> <tr> <th>部位</th> <th>物品</th> <th>来源</th> </tr> <tr> <td>头部</td> <td>[[item:159236@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td> </tr> <tr> <td>护肩</td> <td>[[item:239031@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td> </tr> <tr> <td>胸部</td> <td>[[item:239032@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td> </tr> <tr> <td>手套</td> <td>[[item:159247@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td> </tr> <tr> <td>腿部</td> <td>[[item:159234@JAAEAAAG2wYN]]</td> <td><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td> </tr> </table>

:::

:::details 提示我应该刷哪些地下城？
如果你玩游戏的时间有限，我们建议专注于以下地下城，尝试获取不错的戒指，同时顺带获取其他装备。

- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：一个不错的暴击/精通戒指和几件其他高暴击物品。
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：一个不错的暴击/精通戒指。
- [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)：一个不错的全能/暴击戒指。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271555@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAAEAAgNygjM]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:159259@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250214@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>护腕</th><td>[[item:159263@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>饰品</th><td>[[item:250215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:193761@JAAMAAQkCYHKvbRLfYjM4ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

这个列表包含至暗之夜第2赛季团队副本中神圣牧师的毕业装备。

请注意，此毕业列表适用于来自 **来自** 团队副本。我们按 **装备来源**划分毕业列表。这是当你想通过仅从地下城收集装备来 **为团队副本** 通过仅从团队副本收集装备。

请注意，不存在单一、全面的“毕业（BiS）”装备。最好的装备因角色和情况而异，而且有很多装备在每秒治疗量（HPS）方面本质上是等效的，尤其是当我们只是在调整次要属性时。我们将为每个部位列出一件“毕业”装备，有时如果我们认为有显著差异，会列出两件，但最终，随着你接触到更多内容，毕业装备会不断变化。

:::details 常见问题我需要哪些套装部件？
由于现在可以将物品催化成套装并保留其属性，因此不再有特定的栏位是你必须追求套装的。你的首要任务仍然是尽快凑齐4件套，然后利用额外的催化次数来更好地为那些栏位配装。特别值得注意的是

[[item:271874]]

来自

[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

它可以被催化成套装头盔同时保留精通效果，使其成为一件极其强大的物品。以下是每个栏位建议催化的物品列表。

<table> <tr> <th>部位</th> <th>物品</th> <th>来源</th> </tr> <tr> <td>头部</td> <td>[[item:271874@JAAEAAgNyQWN]]</td> <td><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td> </tr> <tr> <td>护肩</td> <td>套装代币，不要催化</td> <td><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td> </tr> <tr> <td>胸部</td> <td>[[item:268221@JAACAAgNyA]]</td> <td><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a> 位于 <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></td> </tr> <tr> <td>手套</td> <td>[[item:268243@JAAEAAgNyQWN]]</td> <td><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td> </tr> <tr> <td>腿部</td> <td>[[item:268236@JAAEAAgNyQWN]]</td> <td><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></td> </tr> </table>

:::

:::details 小贴士我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:271092@JAACAAAG2A]]：一把带有副属性触发效果的武器。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:268265@JAACAAAG2A]]：一条带有额外插槽的强力项链。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:271874@JAAEAAgByYVN]]：一顶带有副属性触发效果的强力头盔，可以催化成套装同时保留触发效果。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271555@JAACAAAG2A]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268232@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268218@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270162@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></div></td></tr><tr><th>护腕</th><td>[[item:268228@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-priest-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268263@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 神圣牧师饰品推荐

此饰品梯队列表基于提升你团队副本表现的最佳属性，除非另有说明。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **神圣牧师饰品**
**毕业 -**

[[item:270162@JAAEAAgNygjM]]

和

[[item:270164@JAAEAAgNygjM]]

**次选 -**

[[item:270167@JAAEAAgNygjM]]

或

[[item:250214@JAAEAAgNygjM]]

:::

还有许多其他具有竞争力的选择，请务必查看下方的完整排名。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看神圣牧师饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270162@JAAEAAgNygjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164@JAAEAAgNygjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAMAAQkCYHKvbRLfYjM4ID]]（暴击训练）</li>&#10;<li>[[item:250214@JAAEAAgNygjM]]</li>&#10;<li>[[item:270167@JAAEAAgNygjM]]</li>&#10;<li>[[item:280835@JAAEAAgNygjM]]</li>&#10;<li>[[item:270169@JAAEAAgNygjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215@JAAEAAgNygjM]]</li>&#10;<li>[[item:273796@JAAEAAgNygjM]]</li>&#10;<li>[[item:264507@JAACAAgIyA]]</li>&#10;<li>[[item:250248@JAAEAAgNygjM]]</li>&#10;<li>[[item:249809@JAAEAAgByYVN]]</li>&#10;<li>[[item:251792@JAACAAgMyA]]</li>&#10;<li>[[item:248583@JAACAAgMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAAEAAgNygjM]]</li>&#10;<li>[[item:250254@JAAEAAgNygjM]]</li>&#10;<li>[[item:250255@JAAEAAgNygjM]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

由于可用的饰品数量众多，如果你没有在上面看到某个饰品，可以认为它是D级或更低。

:::

:::details 小贴士：我应如何最有效地使用[[item:270162@JAAEAAgNygjM]]？
[[item:270162@JAAEAAgNygjM]]

是一个非常强力的饰品，使用得当时能提供可观的吸收效果。你应该尽量让它尽可能接近冷却完毕时使用，最好是在即将到来的伤害事件前5秒。不规律地使用这个饰品会导致治疗量损失。

:::

你可以在 [QE Live](<https://questionablyepic.com/live/trinkets?spec=holypriest>) 工具上查看完整的饰品排名列表。

1.

### 虚空核心（额外奖励骰）和升腾毒石

在第2赛季中， [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可以从宏伟宝库中获取，而不是战利品选项。
[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 保证从你的目标Boss或地下城掉落战利品。虽然具体物品是随机的，但你永远不会收到重复物品，每一个新的虚空核心都保证掉落不同的物品，直到你收集完该来源的所有可用物品。

3.1.

#### 神圣牧师推荐的虚无核心使用建议

你的迷雾虚空核心是用于定向获取装备的宝贵资源，这些装备以其他方式很难获得。你的虚空核心策略应优先弥补当前装备搭配中的缺口，同时记住你已经获得的装备。将虚空核心花在接下来几周可以通过更高难度内容获取的物品上通常是低效的。以下是你应该关注的内容：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心定向优先级**
1. 来自英雄难度乌拉特克的3件独特物品全部以1/6神话掉落，将你的前3次奖励骰用在这里。
2. 神话品质副手。
3. 神话品质饰品，如[[item:270162@JAAEAAgNygjM]]。
4. 你BiS列表中影响最大的部位。

:::

:::details 小贴士为什么要在英雄难度Boss身上使用奖励骰？
将前3次奖励骰优先用于英雄难度乌拉特克的原因是，它掉落的全部3件物品都极其强大，并且通过奖励骰获得时为神话品质。这些物品在整个赛季都不会被替换，直到你最终在史诗难度击杀乌拉特克并能获取同一批物品略强一些的9/6神话版本。

:::

3.2.

#### 晋升毒液石

你的[[item:280562]]应遵循以下优先顺序：

1. 武器
2. 饰品
3. 项链
4.

### 神圣牧师最佳制造装备

自己制造装备或委托制作专业物品是提升角色实力的好方法。

作为神圣牧师，我们强烈建议尽早制造一个副手，理想情况下使用赛季前几周积攒的神话迷雾徽章。虽然这个副手严格来说并非毕业装备，但它非常强大，在前期是对你资源的高效利用。它不仅提供大量智力，还能通过在制造武器上使用你的两个特效之一来提升你的治疗输出。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **神圣牧师制造装备优先级**
- **前期战力提升：** [[item:245769@JAAIAAwt1wgNRDzViA]]搭配[[item:245876]]，如果你还没有神话品质副手的话。
- **前期战力提升：** 升级空间最大的护甲部位搭配[[item:240167]]作为你的第二个特效。
- **最终毕业：** [[item:239649@JAAKAAwt1wgNRDzViAGM]]搭配[[item:240167]]。
- **最终毕业：** [[item:239648@JAAKAAwt1wgNRDzViAGM]]搭配[[item:240167]]，一旦你拥有了完全升级的神话品质副手。
- 任何你尚未获得神话品质的物品。

:::

**英雄难度团队副本玩家** 如果你无法稳定获取神话徽章，并且不太可能在前几周通关英雄难度团本，应该调整你的制造策略，优先追求武器带来的战力提升。如果你有充足的神话徽章，可以制造上述建议的副手，然后制造任意单手神话武器。如果你缺少神话徽章，你的第一件制造品应该是一把双手法杖。制造任一武器时，特效应选择[[item:245876]]。

:::details 小贴士为什么要制造我即将替换掉的物品？
在赛季初期制造装备时，你的目标是快速凑齐2个特效，并优先选择能让你用最少的徽章和火花投资换取最多属性的物品。在赛季后期，你仍然需要保持2个特效，但由于你能获取更好的物品来填充那些高预算部位，你应该专注于将特效转移到手腕和腰带等低预算部位。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 神圣牧师最佳特效

虽然我们无法制造最强大的物品，但我们仍然可以制造带有特效的装备，使其比同物品等级的普通物品更强大。

作为神圣牧师，你的两个特效部位有几个选择，取决于你当前拥有的装备。你应该利用这些制造装备来弥补配装过程中的任何缺口或你特别需要的部位。

你还可以叠加大多数特效效果两次，这会使效果翻倍，但不会增加触发频率。

下面将你的选择分为两类：开荒期和终局。如果你正处于开荒之旅，你应该关注在花费徽章时最高效的物品。终局配置则适合你只关心在终局可获取范围内制造尽可能好的物品，而不考虑效率的情况。

4.2.

#### 为装备添加插槽

如果你不想要大宝库中的任何选项，奖励骰也不再吸引你，你可以改为获取代币。使用6个这样的代币，你可以购买消耗品[[item:275707]]，允许你为第2赛季中获得的任何头盔、腰带或护腕添加一个插槽。

1.

### 纹章使用

一旦你将某个部位升级到一定物品等级，将该部位的其他物品升级到该物品等级是免费的。使用徽章升级时，你应该将其视为升级部位而非物品。此外，由于徽章是有限资源，你应该在升级某个部位前先获取尽可能高的物品等级，因为这意味着你在该部位上总共花费的徽章会更少。

我们看到许多玩家，甚至高水平玩家，搞乱了升级优先级，过早进行升级。正确处理这一点会让你远远领先于大多数玩家。

下面是你应该升级装备的部位优先级。如果你想要偏离这一点，必须有非常好的理由。

1. 武器
2. 饰品
3. 头盔/胸甲/腿部
4. 戒指和项链
5. 肩部/手套/腰带/靴子
6. 披风和护腕

请注意，可能存在例外情况，例如某些特殊物品的物品等级成长高于其部位所暗示的。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月17日：** 针对饰品热修复进行了更新。
- **2026年8月12日：** 澄清了关于额外掉落的信息。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已根据12.0.7补丁使用孢子坠落装备进行更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月25日：** 根据最新的理论计算和热修复更新了饰品排名。
- **2026 年 3 月 22 日：** 根据最新的理论计算和修复更新了饰品排名。
- **2026 年 3 月 17 日：** 根据饰品热修复进行了更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月15日：** 因热修复进行了更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月13日：** 更新了谜之卡特尔芯片部分。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月13日：** 改进了饰品推荐。
- **2025 年 2 月 24 日：** 因热修复进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月17日：** 根据增益效果和理论计算更新了瑟尔西的指环信息。
- **2024年12月15日：** 添加了关于瑟尔西的指环的提及
- **2024年11月21日：** 改进了装备推荐。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月15日：** 移除了赛季前的装备。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月23日：** 更多《巨龙时代》第4赛季饰品更新。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月17日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月13日：** 更新了毕业装备列表。
- **2023年11月8日：** 更多10.2更新，包括孢子披风推荐的更改。
- **2023年11月6日：** 已根据10.2补丁改动更新。
- **2023年9月4日：** 已为10.1.7补丁更新，包括新的毕业装备列表。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月16日：** 小幅更新，包括孢子披风漏洞。
- **2023年5月1日：** 已根据10.1补丁初步信息更新。
- **2023年3月31日：** 进一步的10.0.7补丁更新。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月21日：** 添加了一些遗漏的饰品。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的神圣牧师的最优属性优先级。我们首先展示属性优先级，然后深入解释这些属性如何与你的专精和游戏玩法相互作用。我们的内容已针对《魔兽世界》12.1.5版本更新。

1.

### 神圣 牧师 属性优先级

欢迎来到至暗之夜资料片中神圣牧师的属性优先级页面！在这里，我们将快速介绍你应该在装备上追求的属性，以及根据你的天赋配置需要特别注意的事项。

1.1.

#### 团队副本属性优先级

暴击

精通

全能

急速

在团队副本中，我们的次要属性价值都相当接近。暴击的收益略高一些，但你不应完全忽视全能或精通，因为它们仍然是强力的治疗属性。

1.2.

#### 大秘境属性优先级

暴击

全能

急速

精通

在治疗地下城时，你希望在短时间战斗中最大化你的治疗量。由于你可以经常喝水，直接的治疗属性很重要。减伤属性也会变得更加重要，因为它们能让你在最高难度的史诗钥石地下城中存活下来那些通常无法承受的伤害。

1.

### 深入属性解析

为了帮助你理解每个属性如何影响你的表现，我们在下面提供了详细说明。这些并未按属性优先级顺序列出，具体请参考上方的章节。

**智力** 是你的主属性。你应该在所有升级中寻找这个属性。它为你提供法术强度，从而提升你治疗法术的威力。

**精通** （[[spell:77485]]）使你的每个直接治疗法术在目标身上放置一个持续治疗效果，在4秒内治疗初始治疗量的一定百分比。该持续治疗效果的连续施加会叠加。它还增加[[spell:139]]的治疗量。

**暴击** 使你的治疗效果翻倍，这也使你的精通受益。

**急速** 降低你的治疗法术施法时间以及全局冷却时间。它还减少[[spell:33076]]的冷却时间，并通过提供额外跳数来增加[[spell:139]]的治疗量。

**全能** 增加你造成的伤害和治疗量，同时减少你受到的伤害。这使它成为一个兼顾生存和治疗输出的强力全方位属性。

**吸血** 使你能被动地为自己恢复施放的每个法术治疗量/伤害量一定百分比的生命值。由于其出色的属性成长以及群体伤害机制的普遍性，它最终能提供大量的
<em>免费</em> 治疗，否则这些治疗需要由你自己或队伍中其他治疗者消耗法力值来覆盖。

**闪避** 减少你从各种范围伤害来源受到的伤害。其价值因战斗而异，但总体来说会是净收益。

**急速** 略微提高你的角色移动速度。在躲避首领机制或与队伍重新调整站位时可能有用，但不如其他属性明显。

2.1.

#### 吸血和闪避

虽然我们提供了属性偏好列表， **将装备更换为更高物品等级的物品——以及它们更高的总属性——通常会比使用物品等级较低但属性更好的物品带来更大的提升**.

这一规则的例外是带有重要三级属性（吸血和闪避）的物品，除非物品等级差距在6级或以上，否则这些物品仍应优先于没有这些属性的其他物品使用。

2.2.

#### 每点属性等级的属性收益

为了从每个属性获得1%的收益，你需要不同数量的属性等级。这意味着某些属性天然地比其他属性成长性更好，即使在某些属性相对于其他属性过多而导致收益递减之前也是如此。

1. 暴击 - 46点等级提升1%
2. 全能 - 54点等级提升1%伤害/治疗 / 0.5%受到的伤害降低
3. 精通 - 约50.6点等级提升1%
4. 急速 - 44点等级提升1%
5. 吸血 - 69点等级提升1%
6. 闪避 - 36.8点等级提升1%
7. 急速移动 - 11.5点等级提升1%

2.3.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对12.0.5补丁进行了更新，包括属性递减阈值。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月24日：** 为至暗之夜上线再次更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025年10月11日：** 澄清了属性优先级。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 更新了每点属性值收益和属性递减阈值。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页，我们列出了你的神圣牧师可以获得的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/holy-priest-pve-healing-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你将有两类宝石可供选择：稀有或史诗。稀有宝石要么是单一属性，要么是两种次要属性的组合。史诗宝石要强大得多，但你的整个角色同时只能使用一颗。

作为神圣牧师，你应该将[[item:240983]]作为你的史诗宝石选择，并在所有其他宝石插槽中镶嵌[[item:240910]]。

:::details 常见问题珠宝加工特效使用什么宝石？
某些制造物品从拥有各种颜色的宝石中获益更多。使用下面的列表来最大化你的宝石颜色，同时确保你镶嵌了[[item:240983]]。稀有宝石总共有四种不同的颜色：橄榄石（急速）、石榴石（暴击）、紫水晶（精通）和青金石（全能）。为了最佳优化你的宝石，你应该使用带有暴击和全能的宝石。

- 橄榄石：[[item:240890]]
- 石榴石：[[item:240910]]
- 紫水晶：[[item:240898]]
- 青金石：[[item:240914]]

:::

1.

### 最佳附魔和武器强化

对于你的临时武器油，你应该在所有内容中使用[[item:243733]]。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳</th>&#10;<th>备选</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:243951]]</td>&#10;<td>[[item:243949]]</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:244021]]</td>&#10;<td>[[item:244018]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;<td>[[item:244003]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240155]]</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>[[item:243983]]</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>[[item:243957]]</td>&#10;<td>[[item:243986]]</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>[[item:244029]]</td>&#10;<td>[[item:243971]]</td>&#10;</tr>&#10;</table>

虽然我们建议的用于最大化治疗输出的三级属性附魔是吸血，但考虑到神圣牧师的机动性有限，使用急速移动附魔也是一个不错的选择。

1.

### 最佳消耗品

消耗品能在有限时间内大幅提升你的角色实力。任何时候当你挑战困难内容时，建议你使用药剂、食物、药水和武器油来增益自己。

3.1.

#### 合剂

在第2赛季，你应该根据需要哪种属性来使用以下之一。

- [[item:241326]] - 暴击（更多治疗）
- [[item:241320]] - 全能（防御选择）

3.2.

#### 药水

[[item:241308]]是你的默认药水，应该与[[spell:200183]]或[[spell:64843]]配合使用以获得最大收益。[[item:241288]]是另一个有竞争力的治疗输出选择，如果制造或购买成本更低，你也可以使用它。虽然法力药水[[item:241301]]和[[item:241294]]是可用的替代品，但它们恢复的法力值不足以值得在属性药水之上使用。

从第2赛季开始，你现在可以使用[[item:271883]]，它是对第1赛季[[item:241305]]的重大升级。

3.3.

#### 食物增益

作为神圣牧师，你可以使用任何大餐或大师级食物来获得最佳效果。这包括任何提供最高次要或主属性加成的食物增益。以下是一些示例：

- [[item:255846]] - 智力大餐
- [[item:255845]] - 智力大餐
- [[item:242275]] - 智力个人食物
- [[item:255847]] - 智力个人食物

如果你想要更便宜的食物，你也可以使用[[item:242283]]或[[item:242287]]。

根据开荒内容的难度等级，你也可以选择制作大多数食物的丰盛版本，它们提供完全相同的效果，但现在增益在死亡后依然保留。制作1份丰盛版本需要消耗5份普通食物。

3.4.

#### 强化符文

你应该在任何开荒内容中使用强化符文来获得智力加成。在第2赛季，以下强化符文可用：

- [[item:259085]]（消耗品版本）

3.5.

#### 其他消耗品

除了上述物品外，作为神圣牧师，你还应该始终在背包中为团队副本和史诗钥石环境准备以下物品。

- [[item:188152]] - 可重复使用的物品，会自动点击附近的 术士 传送门。
- [[item:244639]] - 为团队提供较弱的 [[spell:2825]] 效果，在没有职业能自然提供该效果的史诗钥石地下城中很有用。
- [[item:269586]] - 可在战斗中施放的战斗复活物品，即使不是工程学专业也能使用。
- [[item:241303]] - 隐形药水，可在某些史诗钥石地下城路线中代替 [[item:212265]] 来跳过小怪。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月23日：** 根据12.0.5补丁修复更新了戒指附魔建议。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月24日：** 热修复后移除了关于茶的提及。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月23日：** 重新格式化了页面。
- **2025年2月26日：** 更多11.1补丁消耗品更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月17日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月8日：** 添加了更多消耗品建议。
- **2023年11月6日：** 已根据10.2补丁改动更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月7日：** 已根据最新热修改动更新。
- **2023年5月1日：** 已为10.1补丁更新，包括昂萨里克的指环部分。
- **2023年3月31日：** 进一步的10.0.7补丁更新。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的 神圣 牧师 挑战史诗钥石地下城的技巧和建议。

1.

### 神圣 牧师 在 至暗之夜 第2赛季的史诗钥石地下城中

在本指南中，我们将讨论如何在史诗钥石地下城中充分发挥你的 牧师 的实力，包括如何最好地配置你的角色、你的输出循环可能如何变化，以及最优化使用技能的技巧和窍门。

如果你对史诗钥石地下城及其相关的一般机制不熟悉，可以在我们专门的史诗钥石地下城页面上阅读更多内容。想了解更多关于史诗钥石地下城环境的内容，请查看我们的史诗钥石地下城职业强度排行。

神圣 牧师 有几个主要优点，使其成为 至暗之夜 中史诗钥石内容的热门专精。例如，神圣 牧师 拥有多个强大的冷却技能 [[spell:47788]] 和 [[spell:200183]]；可靠的单体伤害；可观的团队治疗潜力；以及简单直接、反应式的玩法。[[spell:10060]] 如果与一名输出职业配合得当，也能大幅提升你团队的伤害。

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 史诗钥石地下城天赋

2.1.

#### 推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者大秘境构建

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/oracle.webp>) 神谕者 是史诗钥石地下城的推荐专精，因为它通过 [[spell:33076]] 和 [[spell:1246799]] 提供稳定的团队治疗。不同的天赋选择主要是为了利用 [[spell:33076]] 和 [[spell:1246517]] 来增加团队治疗，并帮助扩散 [[spell:139]]。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAADAAAAAAghxsMmZMzYYGYZmZmBAAAwYmlZwMzM2MmZMgZKAmZBDhxsNAjBWMmZBgZMzYMYGgZmBMA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZfYeGJRbcekmqUsk648sMB-AAAA-CEMYkow0AUgscE-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 史诗钥石地下城天赋

2.2.

#### 备选 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 史诗钥石地下城配装

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 是史诗钥石地下城中具有竞争力的替代选择，因为它每次施放 [[spell:120517]] 都能提供稳定的治疗爆发。不同的天赋选择主要是为了利用 [[spell:120517]] 同时进行伤害和治疗。额外触发的 [[spell:109186]] 非常适合团队紧急处理，并促成更多的 [[spell:2050]] 施放。

总体而言，这套配装提供可靠的即时治疗，[[spell:120517]] 成为一个强大的短冷却技能。

:::talents 天赋构筑
```json
{
  "code": "CEQAAAAAAAAAAAAAAAAAAAAAAwYAAAAAAAMMzsMgZmZYmZGLzMzMAAAAGzsMDmZmxmxMjBMTBAmZzMMbGAYMYzMjFANjZGjBzstMADYA"
}
```
:::

:::details 来源计算器编码
```
#BE-WcdhluABNOUVXikstHKKQRVNYYkkMNHIKsA-ghiERZabfjkSTUVYceUsk6ABx88EoMB-AAAA-DIMi0Ic4IhBQxS-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断、昏迷和阻止

神圣 牧师 没有打断技能。相反，你只能使用眩晕和打断技能。

[[spell:8122]] 是你的“群体打断”技能。施放后，它会立即让附近的所有敌人陷入恐惧并无法攻击。由于敌人受到大量伤害，这种恐惧在史诗钥石地下城中通常几乎立刻就会被解除；不过，它仍然能够打断敌人的施法。

冷却时间可以通过点出 [[spell:196704]] 来减少。当点出该天赋时 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 的 [[spell:453918]]，它会在第一次施放后不久再次施放，充当第二次群体打断。还应注意，许多敌人免疫恐惧，特别是亡灵和小Boss类敌人。

[[spell:88625]] 是你的单体“打断”技能。我们建议以与 [[spell:8122]] 相同的方式使用它，只不过它只影响一个敌人。

[[spell:9484]] 可用于瘫痪单个亡灵或异怪50秒。有几个地下城有危险的亡灵和异怪，是锁链恐惧的很好目标。受到伤害会移除此效果。

[[spell:605]] 和 [[spell:205364]] 可以暂时控制一个敌人，让你可以移动、攻击并施放他们的一些技能。这在某些地下城中很有用，因为特定敌人拥有可以增益你团队或削弱敌人的宝贵法术。

### 其他功能

3.2.

#### 其他功能

[[spell:527]] 会驱散一名团队成员的所有魔法效果，冷却时间很短。点出 [[spell:390632]] 后，它还会移除所有疾病。这个技能在史诗钥石地下城中使用频繁，地下城中有多个重要法术应该对它使用，以使战斗更容易并防止死亡。

[[spell:528]] 是一种进攻性驱散，也称为“驱散增益”。它会移除敌人身上的一魔法增益效果。

[[spell:32375]] 同时充当 [[spell:527]] 和 [[spell:528]]，但仅限于5个友方目标和5个敌方目标身上的魔法效果。最常用于从多个团队成员身上移除危险的魔法减益效果，但也可用于从多个敌人身上驱散危险的魔法增益效果。

[[spell:453]] 提供一种独特的增益效果，减少敌人发现你和你盟友的距离。这用途相当小众，但在某些情况下可以使用，以避免拉一群敌人，而是直接从他们身边走过。

[[spell:73325]] 有很多用途，特别是与你的团队配合时。具体来说，它可以与你的坦克配合，将他们从危险中移出，并在他们与正在战斗的敌人之间拉开距离。

### 伤害输出

3.3.

#### 伤害输出

作为一名治疗者，尽管你的角色重点是通过治疗和实用技能让每个人都活下去，但你获得的任何空闲时间都应该用于提供额外的伤害。请注意，只有 [[spell:585]] 消耗的法力非常少；其他法术可能会开始消耗你的法力，因此特别是在一些较长的暴君Boss战中，你可能需要通过坚持使用伤害稍弱的惩击来稍微减少你的伤害输出。

4个以上目标的伤害法术优先级：

1. [[spell:88625]]
2. [[spell:14914]]
3. [[spell:132157]]

1-3个目标的伤害法术优先级：

1. [[spell:88625]]
2. [[spell:14914]]
3. 点出 [[spell:1246549]] 时的 [[spell:132157]]
4. [[spell:585]]

有关史诗钥石地下城中 神圣 牧师 治疗循环的更多信息，请参阅 [循环、冷却和技能](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>) 页面。

[神圣 牧师 循环和冷却](<https://www.icy-veins.com/wow/holy-priest-pve-healing-rotation-cooldowns-abilities>)

1.

### 应对词缀

### 词缀：升腾

4.1.

#### 神圣 牧师 的升腾词缀应对

宇宙能量球会定期在你的团队附近生成。作为 神圣 牧师，你可以使用以下法术来清除这些能量球：

- [[spell:8122]] - 在可能的情况下，这是你最好的选择。
- [[spell:32375]] - 上限为5个目标。
- [[spell:88625]] - 通常最好将其保留给其他东西。
- [[spell:528]] - 作为最后的手段。

### 词缀：虚缚

4.2.

#### 神圣 牧师 的虚空束缚词缀应对

当虚空束缚词缀生成时，你可以在治疗团队的间隙将其转为你的主要输出目标来协助处理。

### 词缀：脉冲星

4.3.

#### 神圣 牧师 的脉冲星词缀应对

务必注意这些能量球，并尝试在它们生成之前移动到其他玩家附近以加快收集速度。团队中的每个人都应该帮助吸收能量球。在治疗压力大的时期，要求你的团队在没有你帮助的情况下吸收它们是完全合理的，因为你的许多治疗法术需要你站着不动。

### 词缀：吞噬

4.4.

#### 神圣 牧师 的吞噬词缀应对

当 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>) 存在的那一周，你应该随时准备使用 [[spell:32375]] 或 [[spell:527]] 来尽可能频繁地驱散团队成员身上的 [[spell:440313]]。你也可以使用种族技能如 [[spell:20594]] 来移除它。如果你或你的团队成员没有驱散任何减益效果，应优先清除最脆弱的目标，最后清除坦克。如果需要，你也可以使用 [[spell:19236]] 来帮助清除你自己的减益效果。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月25日：** 根据最新的理论计算更新了配装。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕再次更新。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月25日：** 已根据最新热修信息更新。
- **2025年3月18日：** 改进了第2赛季的地下城提示。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 已为11.0.5补丁更新并添加了更多提示。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月29日：** 已针对10.2.6版本更新。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月8日：** 改进了天赋建议，为第2赛季做好准备。
- **2023年5月1日：** 已为10.1补丁更新，包含新的词缀和天赋改动。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到许多有用的宏和插件，让你在《魔兽世界》12.1.5补丁中玩你的 神圣 牧师 时更加轻松。

1.

### 最佳宏

关于 神圣 牧师 宏，我们与Elvenbane合作，他是
[Warcraft Priests 的版主](<https://discord.gg/warcraftpriests>) 以及他们广受欢迎的 [实用宏模板 的作者](<https://us.forums.blizzard.com/en/wow/t/useful-macro-templates/42937>)
指南。

我们强烈建议你的所有治疗法术，以及可以在盟友身上施放的其他实用法术（如 [[spell:47788]] 和 [[spell:527]]）都能方便快捷地使用。这可以通过使用游戏内的点击施法选项、宏或像Clique这样的插件来实现。这将使你能够更轻松地尽快将它们施放在团队成员身上。

1.1.

#### 基础治疗宏

这个宏是你所有治疗和增益法术宏的基础。你只需将 **SPELL** 替换为你想要对友方单位施放的法术，包括治疗法术和驱散法术。它的工作原理如下：

- **按住Alt键：** 对自己施放。
- **鼠标悬停友方目标：** 对鼠标悬停目标施放。
- **目标为友方：** 对目标施放。
- **目标为敌方且正在攻击友方：** 对敌人的目标施放。
- **默认施放行为：** 如同没有宏一样施放，并生成工具提示。

#### 基础治疗宏

```wow-macro
#showtooltip
/cast [mod:alt,@player] [@mouseover,help,nodead] [help] [@targettarget,help,nodead] [] SPELL
```

1.2.

#### 对自己施放 天堂之羽 宏

这是一个非常方便的宏，它使用新的@player简写在玩家脚下施放 [[spell:121536]]。

#### 对自己施放 天堂之羽 宏

```wow-macro
#showtooltip
/cast [@player] 天堂之羽
/stopspelltarget
```

1.3.

#### 在光标处施放 圣言术：灵

这个宏允许你立即在光标处施放 [[spell:34861]]，为你节省一次鼠标点击。然而，请记住，没有瞄准准星时，很难准确判断圣言术：灵会落在哪里。

#### 在光标处施放 圣言术：灵 宏

```wow-macro
#showtooltip
/cast [@cursor] 圣言术：灵
/stopspelltarget
```

1.4.

#### 取消救赎之魂

有时你会想提前取消 [[spell:20711]]。要轻松做到这一点，请使用下面的宏：

#### 取消救赎之魂宏

```wow-macro
/cancelform Spirit of Redemption
```

1.5.

#### 鼠标悬停 能量灌注 宏

此宏将对当前鼠标悬停的目标施放 [[spell:10060]]，前提是它是友方目标且未死亡。否则，它将对当前目标施放 能量灌注，最后如果没有找到有效目标，则对自己施放。

#### 鼠标悬停 能量灌注 宏

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead] [@focus,help,nodead] [] 能量灌注
/cast [@player] 能量灌注
```

1.6.

#### 信仰飞跃鼠标悬停宏

此宏将对当前鼠标悬停的目标施放 [[spell:73325]]，前提是它是友方目标且未死亡。否则，它将对当前目标施放信仰飞跃。

#### 信仰飞跃鼠标悬停宏

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead] [] 信仰飞跃
```

1.7.

#### 锁链恐惧焦点宏

此宏不仅可以让你对目标施放 [[spell:9484]]，还可以将其设置为焦点，以便你可以关注锁链并在需要时重新施放。

- **按住 变换：** 清除焦点。
- **按住Alt键：** 设置焦点并对焦点施放 [[spell:9484]]。
- **默认施放行为：** 如同没有宏一样施放，并生成工具提示。

#### 锁链恐惧焦点宏

```wow-macro
#showtooltip
/focus [mod:alt,@focus,dead] [mod:alt,@focus,noexists]
/clearfocus [@focus,dead] [mod:alt,@focus,noexists] [mod:shift]
/cast [mod:alt,@focus,exists] [] 束缚恐惧
```

1.8.

#### 基础伤害与治疗宏

这是一个基础的鼠标悬停宏，用于将进攻法术和治疗法术组合到一个按钮上。你只需将
**HELP_SPELL** 替换为你想要施放的治疗法术，并将 **伤害技能** 以及你想施放的伤害法术。

#### 基础治疗与伤害宏

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead] HELP_SPELL; [@mouseover,harm,nodead] [harm] HARM_SPELL; HELP_SPELL
```

如果你希望伤害法术显示在治疗法术之上，也可以将它们的顺序对调。

#### 基础伤害与治疗宏

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] HARM_SPELL; [@mouseover,help,nodead] [help] HELP_SPELL; HARM_SPELL
```

1.

### 最佳插件

以下是针对神圣牧师推荐的一些插件。

2.1.

#### Twintop's Resource Bar

[Twintop's Resource Bar](<https://www.curseforge.com/wow/addons/twintops-insanity-bar>) 该插件适用于神圣牧师，可让你轻松追踪当前法力值和生命值、神化增益的剩余时间（带有结束提示）以及光晕的触发。该资源条还具备追踪[[spell:2050]]、[[spell:34861]]和[[spell:88625]]状态以及你的[[spell:390992]]层数的功能。

[观看原文视频](<https://static.icy-veins.com/images/wow/classes/priest/holy-addons-trb.webm>)

<em>Twintop's Resource Bar 实战演示</em>

2.2.

#### 团队框架插件

团队框架插件可帮助你追踪小队或团队成员的生命值、增益和减益效果。暴风雪自带可自定义的团队框架。也有一些热门插件在此基础上构建，让你在使用默认团队框架时拥有更多选项和自定义功能。

玩家们也普遍会选择团队框架替换插件，以全面改造小队和团队框架的显示和配置。热门选择包括
[Grid2](<https://www.curseforge.com/wow/addons/grid2>) 和 [VuhDo](<https://www.curseforge.com/wow/addons/vuhdo>).

2.3.

#### 点击施法插件

为了通过鼠标点击轻松地对盟友施法，点击施法插件让你只需点击单位框架即可施放法术，而无需先选中目标再施法。暴风雪内置了点击施法选项，但许多玩家更倾向于使用插件以获得更多自定义功能和易用性。热门插件选择包括
[Clicked](<https://www.curseforge.com/wow/addons/clicked>) 和 [Clique](<https://www.curseforge.com/wow/addons/clique>).

2.4.

#### 牧师通用插件

2.4.1.

##### 首领模块插件：Deadly Boss Mods 或 Bigwigs

首领模块插件会警告你首领的技能，并就如何处理某些机制提供实时建议。我们强烈建议你安装这样一个插件。在Icy Veins，我们主要使用
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>)，这是最受欢迎的首领模块插件。一个不错的替代选择是
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

2.4.2.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) 是一个有用的插件，可以让你追踪其他团队成员的冷却时间，并为你提供大量其他有用的团队信息。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月21日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月5日：** 添加了更多至暗之夜插件。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月15日：** 更新了WeakAuras字符串。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月31日：** 更新了一些额外的实用宏。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年4月29日：** 添加了一些额外的宏。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
