## 专精概览

欢迎来到我们的《魔兽世界》12.1.5补丁敏锐潜行者指南。在这里，你将学习如何在团队副本和大秘境地下城中作为敏锐潜行者进行游戏：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

敏锐 大秘境资源

[全新！顶级 敏锐 天赋构建](<https://raider.io/specs/subtlety-rogue/talents>)

[顶级 敏锐 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/rogue/subtlety>)

[敏锐 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=rogue--subtlety>)

[热门 敏锐 小队配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=rogue--subtlety>)

1.

### 敏锐 潜行者 概述

敏锐 潜行者 的核心在于将尽可能多的增益效果叠加到一个短暂而激烈的爆发窗口中。爆发窗口结束后，节奏会放缓，直到下一个窗口开启。

在防御方面，敏锐 强大无比，能挺过其他职业难以应对的机制。与此同时，他们还能控制敌人，减少大秘境中小队或坦克承受的伤害量。

强力爆发与全能选手

敏锐 潜行者 拥有的伤害输出极其强大。在群体和单体环境中都拥有 90 秒冷却的爆发能力，以及强力的短冷却技能。然而在这些强力冷却技能的间隙，伤害相当平庸，在面对 2 或 3 个目标时难以跟上其他职业。

速杀团队副本的首选

敏锐 潜行者 是任何团队副本环境的绝佳选择，凭借其强大的冷却爆发和惊人的生存能力。它是最适合快速击杀小怪群或应对 Boss 特定伤害阶段（例如需要通过伤害打破的护盾）的专精之一，因为该专精提供了强大的即时爆发。

潜行者 独特的团队增益/减益效果 [[spell:381637]] 对于减少整场战斗中承受的总伤害非常有用。

狙杀与潜行，还有别的吗？

敏锐 在大秘境的所有场景中都拥有扎实的 DPS，因为他们的爆发伤害能迅速消灭危险的小怪群和/或小怪，通常在它们有机会释放技能之前，或者至少在它们第二次释放之前。

潜行者 总体上拥有一套擅长在地下城中控制或锁定敌人的技能，例如 [[spell:6770]]、[[spell:2094]] 和 [[spell:408]]。他们也是游戏中仅有的两个拥有团队潜行技能 [[spell:114018]] 的职业之一，而且由于 [[spell:382507]]，该技能还能大幅提升移动速度。

算不上最差的多面手

敏锐 可以使用许多不同的功能性法术，例如 [[spell:381637]]、[[spell:5761]]、[[spell:114018]] 或 [[spell:6770]]。虽然这些在团队副本环境中很少有稳定的应用，但一个懂得运用所有技巧的 潜行者 可以让任何大秘境之旅变得更加轻松和安全。

独特的团队增益/减益效果可能并不总是适用于所有敌人机制，但作用于整个团队的减伤效果非常有帮助。

最后存活的 潜行者

潜行者是生存之王，而 敏锐 甚至比其他潜行者专精更有优势。得益于 [[spell:31230]]、[[spell:1966]]、[[spell:31224]] 以及 敏锐 专属的防御天赋 [[spell:382514]] 和 [[spell:428486]]，你通常会是最后存活的几个人之一，即使情况不妙也能力挽狂澜击杀 Boss 或小怪。

当坦克死亡而你又能安全地为小怪群坦10秒时，备好 [[spell:5277]] 可以拯救整场进度，虽然 潜行者 在应对长时间持续伤害时往往比较吃力，但你拥有大量手段来活到最后。

说时迟那时快

敏锐 拥有扎实的机动性，可以使用冷却时间很短的 [[spell:2983]]，让你跑得比骑马的角色还快，同时还能使用 [[spell:36554]] 快速脱离危险，或接近距离较远的敌人。

还可以跳向友方目标，让你在战场上灵活移动以躲避危险攻击。潜行者 机动性的主要缺点是，当你必须独自跑向某处且没有目标可以使用 [[spell:36554]] 时。

1.

### 敏锐 潜行者 在 至暗之夜 中的表现

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5 补丁为 敏锐 潜行者 提供了一些值得注意的 Bug 修复，但补丁的主要重点是两个新的终局内容；一个面向团队副本，另一个面向 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。请务必查看关于新的基斯提克斯团队副本战斗的信息，以及令人兴奋的全新迷宫巨型地下堡！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

你现在可以通过新的 [[item:280562]] 升级你的物品，它能为你的饰品、武器和项链提供额外的物品等级！对于 敏锐 潜行者，新的饰品 [[item:281215]] 来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 在AOE场景中异常强大，但在单体目标上相当平庸。

2.3.

#### 职业改动

12.1.5 补丁中 敏锐 潜行者 的职业改动非常少，主要改动是一些看似微小的 Bug 修复。它们对该专精的数值影响很大，但看起来天赋或游戏玩法方面没有任何变化。

- [[spell:382017]] 和 [[spell:382504]] 不再对所有目标施加两次效果。
- 如果初始命中是暗影伤害法术，[[spell:382524]]、[[spell:121471]] 和 [[spell:426591]] 不再从任何暗影伤害强化天赋中受益。
- [[spell:426591]] 现在能正确回响 [[spell:280719]] 的伤害。

并非与 12.1.5 补丁一同上线，而是在其仅一周前，进行了一次增强了 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者，使其成为AoE场景中可行的英雄天赋选择。然而，对于大多数团队副本首领战， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 仍然是最佳选择，在高层大秘境中你可能仍然会看到 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 称霸，因为它相比其他天赋带来了更高的优先目标伤害 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_shadowdance.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1版本职业平衡调整 隐藏12.1版本职业平衡调整
[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**敏锐 潜行者**

<em>开发者笔记：我们对敏锐在乌拉特克诅咒中的资源经济进行了一些更新，包括修复了一个导致预期意图和战斗手感不清晰的双倍生成错误。暗影技巧的基础效果触发率和能量生成正在提高，以使暗影之舞之外的时刻感觉不那么匮乏，同时保持暗影之舞内部相同的触发率和连击点生成。能量生成在冷却期间仍应持续增长，但不会像之前那样剧烈。</em>

- **职业**
  
  
  
  
  - [[spell:381623]]现在是一个选择天赋——玩家现在可以在现有版本（除了可以主动使用外，还会在低能量时自动施放）和一个必须主动施放的新版本之间进行选择。
  - 虚弱毒药现在降低4%的伤害（原为3%）。
  - 虚弱毒药的持续时间增加至60秒（原为10秒）。在PvP战斗中持续时间保持不变。
- **敏锐**
  
  
  
  
  - 戈瑞玛的 撕咬 已重新设计——鞭击你的目标和 2 个额外的附近敌人，造成 暗影 伤害并使其在 14 秒内流血。终结技造成的所有伤害的 20% 会作为 暗影 重复施加，在受影响的敌人之间平均分配。
  - 暗影工艺已更新——当 暗影之舞 处于激活状态时，你的 暗影 技巧的触发频率提高 25%，并生成 1 个额外的连击点。
  - 造成的全部伤害提高 2%。此效果不适用于 PvP 战斗。
  - 第一支舞现在使 暗影之舞 的持续时间延长 4 秒（原为 3 秒）。
  - 无情打击现在每消耗一个连击点的终结技生成 4 点能量（原为 5 点能量）。
  - 暗影 技巧的基础效果频率提高了 40%。
  - 暗影 技巧的能量生成提高至 5（原为 4）。
  - 萦绕的 暗影 现在也适用于 袖剑风暴。
  - 暗影之舞 的说明文字已更新，包含其降低威胁值的效果。
  - 巅峰天赋：远古技艺现在在创建暗影克隆体时计算 影分身 的总伤害，而不仅仅是其初始命中。
  - 修复了一个问题，该问题导致 影分身 的次要命中的伤害被归因于召唤的宠物而不是攻击的 潜行者。
  - 一些天赋在天赋树中的位置发生了变化。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜 中 敏锐 潜行者 的总结

由于改动数量巨大，它们已被分成几个部分，以便更容易理解 敏锐 潜行者 在这个资料片中的不同之处。请注意，除了这些改动之外，还有许多法术整体平衡性的调整。这些改动大多旨在使该专精更加直观、减少困惑，同时保持该专精以 [[spell:185313]] 为核心的爆发式游戏风格。

- 以下是对基础改动影响最大的变化 **敏锐 潜行者** 法术进行了几项改动。
  
  
  
  
  ► **点击展开**
  
  
  
  
  - 从主题上看，敏锐 现在更侧重于暗影克隆体。
  - 鞭笞已被移除。
  - 死亡印记已被移除。
  - 割裂已被移除。
  - 对 [[spell:185313]] 和 [[spell:280719]] 每消耗一个连击点的冷却时间缩减已被移除。
  - [[spell:121471]] 现在使连击点生成翻倍，而不是总是将其填满。
  - [[spell:426594]] 的连击点返还部分已部分移至第 4 个巅峰天赋。
  - 一些新的/重做的天赋，如 [[spell:185314]] 和 [[spell:381988]]，使急速成为更理想的属性。
- 该 **英雄天赋** 进行了一些小幅更新。
  
  
  
  
  ► **点击展开**
  
  
  
  
  2.5.
  
  
  
  
  ### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者
  
  
  
  
  - [[spell:441367]] 不再顺劈 [[spell:196819]] 或 [[spell:185438]]。
  - [[spell:1276679]] 允许 [[spell:197835]] 触发 [[spell:441146]]。
  - [[spell:441321]] 变得更强，但现在最高叠加 5 层。
  
  
  
  
  2.6.
  
  
  
  
  ### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手
  
  
  
  
  - [[spell:457052]] 现在只能在 [[spell:457058]] 增益激活时移动。
  - [[spell:457058]] 现在可以由 5 个或更多连击点的 [[spell:196819]] 触发，而不是恰好 7 个。
  - [[spell:1272989]] 使暴击成为一种好属性，而之前对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手.
- 此外，我们的 **功能性法术**.
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:1267182]] 使 [[spell:5938]] 在需要解除狂暴时拥有更远的射程和更低的消耗。
  - 虽然大多数其他专精失去了防御天赋或法术，但 敏锐 并没有，而且还通过 [[spell:1267220]] 获得了一个新的。

这些改动极大地简化了该专精，让新玩家和回归玩家无需深入研究这样的攻略就能享受它，而在之前的版本中这几乎是必需的。它仍然围绕着施放 [[spell:185313]] 和打出大爆发，但许多额外的臃肿按钮和被动技能已被精简。

2.7.

#### 敏锐 潜行者 的巅峰天赋：远古技艺

当我们穿越并升级 至暗之夜 时，我们将获得新的巅峰天赋：[[spell:1268932]]、[[spell:1268936]] 和 [[spell:1268939]]。乍一看，或者如果你是 敏锐 潜行者 的新手，说明文字可能看起来令人困惑。但实际上，它们非常简单明了。

- [[spell:1268932]] 使我们的连击点生成技能有时会生成一个克隆体，造成额外的暗影伤害
- [[spell:1268936]] 增加被动暗影伤害，并在克隆体出现时生成额外的 [[spell:196912]] 层数
- [[spell:1268939]] 增加一个增益，当你拥有 5 个或更多 [[spell:196912]] 时触发 **掌握** 施放一个连击点生成技能
  
  
  
  
  - 该增益会在屏幕中间附近添加一个暗影光芒，并通过克隆体使你的下一个终结技造成更多伤害，同时返还连击点。

更深入的解释以及新的巅峰天赋如何影响循环，可以在循环页面找到：

[敏锐 潜行者 循环与冷却](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)

1.

### 敏锐 潜行者 游戏基础

敏锐 潜行者 是一个处理多种不同资源和几个不同冷却时间的专精。该专精的核心概念是叠加尽可能多的效果和增益，以在短时间内造成巨大的爆发伤害。

敏锐 的最基础内容可以用以下三个概念来描述。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_eviscerate.jpg>) **管理你的连击点**
  
  
  
  
  ```
  Subtlety is all about Combo Point spender abilities like [[spell:196819]], these 
  deal more damage the more Combo Points you have, so you want to use them while at the
  maximum of 7 Combo Points and not generating more until you have casted a spender.
  ```
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_findweakness.jpg>) **提前规划**
  
  
  
  
  ```
  The main Subtlety cooldown [[spell:185313]], while strong by itself really
  amplify all of the other cooldowns, so do not cast it immediately when it is ready,
  patience is key.
  ```
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_shadowdance.jpg>) **组合冷却技能**
  
  
  
  
  ```
  When cooldowns like [[spell:280719]], [[spell:426591]] or [[spell:121471]]
  become available combine them with your previously stored [[spell:185313]] charges for
  massive bursts!
  ```

1.

### 作为 敏锐 潜行者 如何配装

虽然我们始终建议你进行模拟以获得理想结果，但我们确实提供了专门的 敏锐 配装页面。我们目前涵盖了第二赛季装备的建议，以便在 至暗之夜 终局内容发布时有一个良好的开端。一旦你获得了一些装备，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已为12.1补丁更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月23日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 更新了天赋构建描述。
- **2026 年 5 月 3 日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对 5 月 5 日的平衡性调整进行更新。
- **2026 年 5 月 3 日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对 5 月 5 日的平衡性调整进行更新。
- **2026 年 5 月 3 日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对 5 月 5 日的平衡性调整进行更新。
- **2026 年 5 月 3 日（本页）：** 已针对 5 月 5 日的平衡性调整进行更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月23日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对 至暗之夜 史诗钥石发布进行审核。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对 至暗之夜 史诗钥石发布进行审核。
- **2026年3月23日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对 至暗之夜 史诗钥石发布进行审核。
- **2026 年 3 月 23 日（本页）：** 已针对 至暗之夜 史诗钥石发布进行审核。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年3月16日（本页面）：** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对 至暗之夜 进行审核。
- **2026年2月26日（本页）：** 已针对 至暗之夜 进行审核。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 为职业门槛解锁的改动更新了天赋树。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜进行更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对至暗之夜进行更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对至暗之夜进行更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对至暗之夜进行更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 为职业门槛解锁的改动更新了天赋树。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜进行更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 为职业门槛解锁的改动更新了天赋树。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对至暗之夜进行更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 为职业门槛解锁的改动更新了天赋树。
- **2026年2月10日（本页面）：** 已针对至暗之夜进行更新。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对至暗之夜进行更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜进行更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对至暗之夜进行更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对至暗之夜进行更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 为11.2.7补丁更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 为11.2.7补丁更新。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月6日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已更新，编写时考虑了套装。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对11.1版本进行更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对11.1版本进行更新。
- **2025年2月24日（本页面）：** 已针对11.1版本进行更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月23日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.5补丁进行更新。
- **2024年10月23日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对11.0.5补丁进行更新。
- **2024年10月23日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对11.0.5补丁进行更新。
- **2024年10月23日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月22日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对《地心之战》进行审阅。
- **2024年8月22日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月22日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月22日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月22日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月22日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月22日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月22日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对《地心之战》进行审阅。
- **2024年8月22日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月22日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/subtlety-rogue-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/subtlety-rogue-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对第4赛季进行审查。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对第4赛季进行审查。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对第4赛季进行审查。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对第4赛季进行审查。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对第4赛季进行审查。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对第4赛季进行审查。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对第4赛季进行审查。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对第4赛季进行审查。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对第4赛季进行审查。
- **2024年4月22日（本页）：** 已针对第4赛季进行审查。
- **2024年3月20日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（本页）：** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年11月24日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已审查并更新。
- **2023年11月24日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已更新，添加了暗影尘埃天赋构建。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 孢子披风削弱后已审查并更新。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对10.2版本进行审查和更新。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.2版本进行审查和更新。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对10.2补丁进行审核。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.2版本进行审查和更新。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对10.2版本进行审查和更新。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对10.2补丁进行审核。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2版本进行审查和更新。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对10.2版本进行审查和更新。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对10.2版本进行审查和更新。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对10.2版本进行审查和更新。
- **2023年11月6日（本页）：** 已针对10.2版本进行审查和更新。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 添加了毕业装备表格并重新排版了页面。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 重新排版了天赋表格和说明。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 已针对10.1.7版本更新和审查页面。
- **2023年7月25日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 添加了升级循环的滑动条。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.1.5版本更新页面。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5版本更新页面。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对10.1.5版本更新页面。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对10.1.5版本更新页面。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 进行了少量推荐天赋更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对10.1.5版本更新页面。
- **2023年7月10日（本页）：** 已针对10.1.5版本更新页面。
- **2023年5月11日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 将推荐天赋从黑暗酿酒改为鞭笞。
- **2023年5月11日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 将推荐天赋从黑暗酿酒改为鞭笞。
- **2023年5月11日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 将推荐天赋从黑暗酿酒改为鞭笞。
- **2023年5月9日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 添加了关于第2赛季如何使用火花的说明以及其他一些更新。
- **2023年5月9日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 添加了使用亚贝鲁斯套装的新天赋构建。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.1版本更新页面，并添加了关于埃拉诺克戒指和玛瑙纪念章的说明。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.1版本审查和更新页面。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对10.1版本审查和更新页面。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对10.1版本审查和更新页面。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1版本审查和更新页面。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对10.1版本审查和更新页面。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对10.1版本审查和更新页面。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对10.1版本审查和更新页面。
- **2023年5月1日（本页）：** 已针对10.1版本审查和更新页面。
- **2023年4月29日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对10.1版本审查和更新页面。
- **2023年4月6日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 更新了推荐的原始宝石。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/subtlety-rogue-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.0.7版本更新和审查页面。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.0.7版本审查和更新页面。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已针对10.0.7补丁进行审核。
- **2023年2月14日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 更新了推荐的单体目标天赋构建。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.0.5版本更新页面。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 更改了暗影步的宏条件并针对10.0.5版本进行了审查。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 更改了一些推荐的附魔和药水推荐，并针对10.0.5版本进行了审查。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 更新了属性推荐并针对10.0.5版本进行了审查。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 更新了天赋并针对10.0.5版本进行了审查。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.5版本更新和审查页面。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已针对10.0.5版本更新和审查页面。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已针对10.0.5版本更新页面。
- **2023年1月24日（本页）：** 已针对10.0.5版本更新和审查页面。
- **2023年1月13日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 添加了推荐的美化。
- **2022年12月17日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 对技能优先级列表进行了小幅更新。
- **2022年12月17日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 修复了单体目标专精的导入字符串。
- **2022年12月17日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 添加了多目标技能优先级列表并更新了单体目标列表。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已针对化身密库的发布进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 对武器附魔进行了小幅更改。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 对推荐的单体目标属性进行了小幅更新。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 更新了天赋推荐。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于冷酷鲜血使用的说明。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 更新了推荐天赋。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月31日（[传说物品](<https://www.icy-veins.com/wow/subtlety-rogue-best-legendaries-shadowlands>)):** 将精力充沛的暗影尘埃添加为温西尔的推荐传奇装备。
- **2022年10月31日（[盟约与羁绊](<https://www.icy-veins.com/wow/subtlety-rogue-best-covenants-soulbinds-and-conduits>)):** 将推荐的团本盟约改为温西尔。
- **2022年10月31日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-castle-nathria-raid-guide>)):** 将推荐的构建改为温西尔以及精力充沛的暗影尘埃。
- **2022年10月31日（[统御圣所页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-sanctum-of-domination-raid-guide>)):** 将推荐的构建改为温西尔以及精力充沛的暗影尘埃。
- **2022年10月31日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 将推荐的构建改为温西尔以及精力充沛的暗影尘埃。
- **2022年10月31日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已更新页面，添加了温西尔构建的起手式。
- **2022年10月31日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 更改了推荐的团本天赋构建，并添加了关于特定行中可能天赋选择的说明。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/subtlety-rogue-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/subtlety-rogue-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/subtlety-rogue-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/subtlety-rogue-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/subtlety-rogue-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月2日（[9.1 补丁分析](<https://www.icy-veins.com/wow/subtlety-rogue-patch-9-1-changes-analysis>)):** 已针对9.1.5版本更新页面。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/subtlety-rogue-patch-9-1-changes-analysis>)):** 已针对9.1版本发布更新页面。
- **2021年6月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/subtlety-rogue-patch-9-1-changes-analysis>)):** 页面创建。
- **2020年10月22日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-ny-alotha-raid-guide>)):** 更新了针对恩佐斯的主要精华推荐。
- **2020年10月14日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-ny-alotha-raid-guide>)):** 已更新页面，添加了针对各首领的新精华推荐。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年9月10日（[永恒宫殿页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-the-eternal-palace-raid-guide>)):** 已更新页面，添加了一些提示和天赋选择。
- **2019年7月12日（[永恒宫殿页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-the-eternal-palace-raid-guide>)):** 为大多数首领添加了提示。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** 本页面已针对风暴熔炉进行审查，无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对风暴熔炉进行审查，无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** 针对8.1补丁进行了更新。
- **2018年9月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** 添加了史诗难度的天赋推荐。
- **2018年9月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** 因首领更改而进行了小幅更新。
- **2018年9月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** 更改了页面格式。
- **2018年8月31日（[奥杜尔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** 已更新页面，添加了首领简介和推荐天赋。
- **2018年8月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-uldir-raid-guide>)):** 已添加页面（目前为空）。

显示更多

显示更少

:::

## 练级

在本页，您将找到我们的逐级敏锐潜行者升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[潜行者 升级指南](<https://www.icy-veins.com/wow/rogue-leveling-guide>).

1.

### 敏锐潜行者升级指南——至暗之夜

不幸的是，潜行者经常被认为是魔兽世界中最糟糕的练级职业。不过别担心，它仍然完全能够轻松应对练级之旅，即使这可能会比选择了其他职业的朋友们花的时间稍长一些。一旦你达到满级，你很快就会超过他们，并且会庆幸自己花了时间选择潜行者！

不幸的是，潜行者经常被认为是魔兽世界中升级最差的职业。然而，他们仍然完全有能力独自完成升级之旅，即使这可能不是最快的职业。

潜行者练级期间最大的优势之一，就是能够简单地潜行绕过许多麻烦。巧妙运用[[spell:2094]]、[[spell:1856]]、[[spell:6770]]和其他控制技能，你往往可以拾取重要任务物品，然后直接消失脱离，无需击杀任何敌人。

[[spell:1231418]]是一个引导治疗技能，你可以在战斗外对自己使用，这是最近新增的，在升级过程中非常实用，尤其是当你的[[spell:185311]]在冷却中而你生命值很低时。每当你的[[spell:5277]]准备就绪时，你可以拉尽可能多的怪物并尝试用AOE将它们击倒，因为你将闪避它们的所有攻击，完全不受伤！

在大多数情况下，你在[[spell:185313]]之外的伤害非常平庸，所以尽量充分利用它激活时的窗口期。

1.1.

#### 升级装备选择

一般的规则是，即使在满级时，也总是装备物品等级更高的装备。例外情况是你主手需要一把匕首。戒指、项链和 <em>某些</em>
饰品也可能是例外，因为戒指和项链没有主属性，而某些饰品的效果超过了你从更多主属性中获得的收益。在升级过程中，几乎总是最好默认装备你能获得的物品等级最高的装备。传家宝装备在升级时也很有用，让你在升级之旅的大部分时间里忽略很多配装问题。

1.2.

#### 至暗之夜中实用的升级消耗品

以下是一些消耗品的示例，可以通过显著提高移动能力或伤害来大大改善升级流程。

- [[item:109076]]
- [[item:132516]]或[[item:212268]]（需要等级71）
- [[item:168412]]
- [[item:219905]]（需要等级75，但之前资料片的其他“鼓”在更低等级也能使用）
- [[item:225592]]（需要等级75）

1.

### 升级天赋

如果你是一名刚刚开始踏上旅程的回归玩家 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)中踏上旅程的回归玩家，你可以在下面找到一个80级的导入字符串。一旦你在至暗之夜中开始升级，你可以按照下面天赋树的逐点分配进行加点。

:::talents 敏锐 80级 至暗之夜升级
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMYwMzMzYMbzMzM2mZmxDMzYAzsMAAAAMYMgxwwADYhFiNMDYmBzA"
}
```
:::

**等级 10 起：**

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTmZbZMmZMwMzMzYMbzwYbbmZmZmZAjZWGAAAAGMGwY2MMwAzCL0iNMDYmBzYYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FhpLPNMdcSNCpIDdFQ6DkXkTMsLihBhWWVc-AYjDEXM9qY9dWdBmVQwhxABhkqrbbaC-AAAA-BIOgQRzQhBTgwF-
```

:::

2.1.

#### 升级用战争模式天赋

在本节中，我们将为升级和进行单人/小型队伍PVE内容排序最佳的PVP天赋。以下是敏锐潜行者专属PVE天赋的排名。

1. [[spell:197000]]疾跑的冷却时间减少50%，持续时间减少50%。
2. [[spell:198675]]——每当潜行激活时，你会对附近的敌人施加一个减益效果，使他们从你的下一次暗影打击中额外受到5%的伤害。最多叠加8次。这没什么特别的，但仍是一个轻微的伤害提升。
3. [[spell:269513]]——终结技，使你跃向空中并施放一个[[spell:196819]]，造成额外10%的伤害。
4. 第三个选择不太重要，因为它们都没有为PVE情况提供好处。使用任何你觉得合适的。
5.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 3 起：**如果你想在不与所有敌人战斗的情况下到达任务目标，或在与敌人交战前，施放[[spell:1784]]。

**等级 1–1：**在10级之前，你能使用的伤害技能只有：[[spell:1752]]、2级的[[spell:196819]]和7级的[[spell:8676]]。

1. 一旦你有5个或更多连击点数，就施放[[spell:196819]]来消耗它们。
2. 使用[[spell:1752]]来积累连击点数。
3. **等级 10 起：**确保你始终有[[spell:315584]]增益效果。
4. **等级 11 起：**确保你始终有[[spell:3408]]增益效果。
5. **等级 13 起：**使用[[spell:121471]]，要么在冷却时使用，要么留给精英敌人。
6. **等级 37 起：**尽可能频繁地使用[[spell:426591]]。
7. **等级 9–17：**使用4个或更多连击点数来始终保持[[spell:315496]]。在18级解锁[[spell:51667]]后，你永远不需要手动施放它。
8. **等级 22 起：**作为DPS冷却技能，尽可能频繁地施放[[spell:185313]]。
9. **等级 25 起：**在冷却时施放[[spell:280719]]来消耗你的连击点数。最好在[[spell:185313]]激活时使用。
10. **等级 12 起：**在与单个敌人战斗时施放[[spell:196819]]来消耗你的连击点数。
11. **等级 74 起：**在[[spell:441423]]激活时，无论你正在与多少个敌人战斗，都施放[[spell:196819]]来消耗你的连击点数。
12. **等级 14 起：**在与2个或更多敌人战斗时施放[[spell:319175]]来消耗你的连击点数。
13. **等级 12 起：**在与单个敌人战斗时施放[[spell:53]]来产生连击点数。如果你处于[[spell:1784]]或拥有[[spell:185313]]激活，则改用[[spell:185438]]。
14. **等级 11 起：**在与2个或更多敌人战斗时施放[[spell:197835]]来产生连击点数。

3.1.

#### 功能性法术

敏锐潜行者拥有大量可用的工具，使同时与多个敌人战斗变得更容易，或者只是简单地从困境中脱身。

- [[spell:1766]]允许你打断正在施法的敌人。尽可能使用它来打断敌人，在升级过程中减少受到的伤害。
- [[spell:185311]]让你在4秒内恢复20%的最大生命值。如果你的生命值正在下降或在拉怪之间使用它。
- [[spell:6770]] 可以让你控制任何人形生物、野兽、恶魔或龙类，持续最多60秒。使用这个技能，可以在你从潜行中对一群敌人发动攻击之前，阻止单个敌人加入战斗。该控制效果会在敌人受到伤害时被打断。为了避免你的闷棍被打断，要么将其他敌人引开，要么不要使用任何范围伤害法术。
- [[spell:408]]可用于击晕单个敌人长达8秒。用它来打断危险的施法，或者简单地避免受到敌人的伤害。某些NPC可能免疫击晕。
- [[spell:5277]]使你在10秒内闪避近战和远程攻击的几率提高100%。利用这一点，在闪避冷却就绪时拉更多的怪。注意，你只有在面对敌人时才能闪避。
- [[spell:1856]]会让你脱离敌人的视野。这会重置你当前正在交战的所有敌人的战斗状态，使其在升级过程中成为一个强力的冷却技能。无论是为了逃脱必死之局，还是摆脱你不想应付的恼人敌人，都要确保善加利用消失。
- [[spell:2094]]可以让你控制一名敌人长达60秒。可以在潜行状态下使用，也可以在非潜行状态下使用。这个控制效果会在你造成伤害时打破，就像闷棍一样，所以请务必把敌人引开或避免使用范围作用技能。
- [[spell:31224]] 移除魔法效果并使你免疫魔法效果，持续5秒。这使你有可能移除可能打断你 [[spell:1784]] 的持续伤害效果、让你承受更少的伤害，或者单纯地避免某些控制或伤害效果。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年2月26日：** 已针对 至暗之夜 进行审核。
- **2026年2月10日：** 为职业门槛解锁的改动更新了天赋树。
- **2026年1月19日：** 已针对至暗之夜进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月22日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月24日：** 已审查并更新。
- **2023年11月6日：** 已针对10.2版本进行审查和更新。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月25日：** 添加了升级循环的滑动条。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将向你讲解如何在《魔兽世界》12.1.5补丁中轻松游玩敏锐潜行者，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能。

1.

### 敏锐潜行者基础

本章节适用于对游戏或职业不熟悉的玩家，没有打史诗难度团本的打算，或者只是想以更直接的方式进行游戏，而不会被为实现最优操作所需考虑的众多优先级和主动技能所淹没。

敏锐归根结底，就是积攒连击点数并消耗它们来造成伤害。其复杂性大多在于尽可能有效地使用大量可用的冷却技能，这并不意味着它们一冷却好就立刻使用。以下是入门和学习基础时可以遵循的一些快速规则：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_eviscerate.jpg>) **管理你的连击点**
  
  
  
  
  ```
  Subtlety is all about Combo Point spender abilities like [[spell:196819]], these 
  deal more damage the more Combo Points you have, so you want to use them while at the
  maximum of 7 Combo Points and not generating more until you have casted a spender.
  ```
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_findweakness.jpg>) **提前规划**
  
  
  
  
  ```
  The main Subtlety cooldown [[spell:185313]], while strong by itself really
  amplify all of the other cooldowns, so do not cast it immediately when it is ready,
  patience is key.
  ```
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_shadowdance.jpg>) **组合冷却技能**
  
  
  
  
  ```
  When cooldowns like [[spell:280719]], [[spell:426591]] or [[spell:121471]]
  become available combine them with your previously stored [[spell:185313]] charges for
  massive bursts!
  ```

1.

### 敏锐潜行者在至暗之夜的入门指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 单体天赋

2.1.

#### 单体目标天赋

你可以通过点击'导出天赋'，轻松地将下方的天赋树导入游戏中。

:::talents 团队副本/单体目标 - 欺诈者
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMjZgZmZGzMbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzGL0mNMDYmBzYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMjZgZmZGzMbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzGL0mNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBWg5hirrTk0ABZD-AAAA-BIOiQZzQhBTgwF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者多目标天赋

2.2.

#### 多目标（大秘境/地下堡）天赋

你可以通过点击“导出天赋”将下方的天赋树导入游戏中。

:::talents 团队副本/大秘境/范围伤害 - 欺诈者
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-BIOgQRzQhBTgwF-
```

:::

### 敏锐潜行者基础输出循环

2.3.

#### 新手敏锐潜行者伤害输出循环

在进入战斗之前，务必记得施加以下效果。

- **涂抹毒药、进入潜行并使用嫁祸诀窍**
  
  
  
  
  涂抹[[spell:315584]]和[[spell:381637]]。
  
  
  
  
  施放[[spell:1784]]。
  
  
  
  
  在开怪前的瞬间对你的坦克施放[[spell:57934]]。

2.4.

#### 单体目标循环

敏锐的核心在于有效地生成和消耗连击点数，同时将各种冷却技能组合起来，制造大型爆发窗口。

- **消耗技能**
  
  
  
  
  当你拥有以下连击点数时，应使用[[spell:280719]]或[[spell:196819]]： **7** 连击点数
- **产生技能**
  
  
  
  
  每当你没有7个连击点数时，如果你处于[[spell:185313]]之中，就应该施放[[spell:185438]]，否则施放[[spell:53]]。
- **冷却技能的运用**
  
  
  
  
  每当[[spell:426591]]可用时就应施放。
  
  
  
  
  应在[[spell:426591]]之后立即施放[[spell:121471]]。
  
  
  
  
  当 [[spell:280719]] 就绪且你拥有连击点时，施放 [[spell:185313]] **7** 连击点。
- **对齐冷却时间**
  
  
  
  
  每个 [[spell:121471]] 都希望在其期间包含 2 个 [[spell:185313]]，这意味着即使 [[spell:280719]] 和 [[spell:185313]] 已就绪，如果 [[spell:121471]] 还有不到 10 秒的冷却时间，你应该暂缓并等待。

2.5.

#### AOE循环

在多目标/群体环境中，敏锐 的玩法与单体环境非常相似，主要区别在于使用群体消耗技和群体产生技而非单体技能。因为群体产生技每命中一个目标给予 1 点连击点，你会获得显著更多的连击点，这意味着你能施放更多消耗技。

- **消耗技能**
  
  
  
  
  当你拥有连击点时，应使用 [[spell:280719]] 或 [[spell:319175]] **7** 连击点数
  
  
  
  
  [[spell:441423]] 是来自该天赋的 [[spell:196819]] 的强化版本 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 英雄天赋，只要可用就应该施放，即使在群体环境中也是如此，下方链接了一个可以自动完成此操作的宏。
- **产生技能**
  
  
  
  
  每当你没有 7 点连击点时，你应该施放 [[spell:197835]]。
- **冷却技能的运用**
  
  
  
  
  每当[[spell:426591]]可用时就应施放。
  
  
  
  
  应在[[spell:426591]]之后立即施放[[spell:121471]]。
  
  
  
  
  当 [[spell:280719]] 就绪且你拥有连击点时，施放 [[spell:185313]] **7** 连击点。
- **对齐冷却时间**
  
  
  
  
  每个 [[spell:121471]] 都希望在其期间包含 2 个 [[spell:185313]]，这意味着即使 [[spell:280719]] 和 [[spell:185313]] 已就绪，如果 [[spell:121471]] 还有不到 10 秒的冷却时间，你应该暂缓并等待。

你可以将 [[spell:441423]] 与你的 [[spell:319175]] 按键绑定为宏，这样每当它就绪时就会自动为你施放，宏的格式如下：

#### 致命一击 + 黑火药

```wow-macro
#showtooltip 黑火药
/cast 致命一击
/cast 黑火药
```

2.5.1.

##### 巅峰天赋

最后一个顶峰天赋 [[spell:1268939]] 有时会为你提供一个增益效果，你可以通过屏幕中央附近的暗影光芒看到。当这种情况发生时，你的下一个连击点消耗技将造成额外伤害，并且会返还你的连击点，让你能够立即再施放一个消耗技。另外两个顶峰天赋对循环没有明显影响。

2.5.2.

##### 第2赛季套装

在 至暗之夜 第 2 赛季期间，你将获得以下套装加成。

- [[spell:1296592]]
- [[spell:1296593]]

第 2 赛季套装两件套效果提供的能量消耗降低，使得几乎每一个非 [[spell:185313]] 的公共冷却都可以用 [[spell:53]] 或 [[spell:197835]] 来填充，从而使该专精在循环中的空闲时间更少。伤害增益也让这些技能更具威力。

四件套效果使 [[spell:382524]] 也能影响 [[spell:196819]] 和 [[spell:319175]]，这使得该天赋成为必选。套装效果不会改变循环的运作方式，但由于这一点，你的 [[spell:121471]] 的后半段现在会比前半段更强。

### 敏锐潜行者防御技能

2.6.

#### 敏锐潜行者的防御技能

敏锐 的被动防御相当薄弱，因此它在绝大部分情况下依赖主动技能来进行防御。

**[[spell:1966]] -** 提供对范围伤害技能 40% 的减伤，冷却时间非常短，持续时间也很短。它确实有微量的能量消耗，但作为 敏锐 能量非常充裕，所以这不太重要。基本上任何时候你觉得有危险，就施放它。

**[[spell:31224]] -** 提供对魔法效果的免疫，冷却时间为 2 分钟，让你可以站在致命的范围伤害区域内，或者从自己身上移除极其危险的减益效果。

**[[spell:185311]] -** 为自己提供一个相当微弱的持续治疗效果，冷却时间为 30 秒。该技能有能量消耗并占用一个公共冷却，使其相对较弱，主要保留给最危急的情况使用。

**[[spell:5277]] -** 提供 100% 几率闪避近战攻击，冷却时间为 2 分钟。这非常小众，因为它通常对地下城或团队副本中的范围伤害无效，但在少数罕见的有效情况下，它非常强大。

**[[spell:31230]] -** 让你在本应死亡的情况下存活下来，冷却时间为 6 分钟。这不是一个主动技能，但它是需要了解的极其强大的防御手段。

### 敏锐 潜行者 属性优先级

2.7.

#### 敏锐 潜行者 属性优先级

敏锐 潜行者 的总体属性优先级如下。如需了解本页内容的更多信息，请查看我们的主
[属性优先级页面](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>).

装备等级

精通

急速（达到700以上）

全能

暴击

由于[[spell:185314]]，敏锐有急速断点（或"上限"），超过之后急速的价值会下降。在第二赛季中，无论是单体还是多目标，目标急速量在700到1100之间。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手。与第1赛季不同，本赛季的阈值没有那么严格，因此在该范围内的任意数值都是可以接受的。

### 暴风雪战斗助手

2.8.

#### 战斗助手与一键循环

战斗助手和一键循环目前对于 敏锐 潜行者 来说效果并不理想。在单体目标场景中，使用一键循环的DPS比手动执行上述循环低约10%，在多目标AoE场景中则低多达15%。

使用战斗助手不会触发与一键循环相关的GCD惩罚，这使得两者之间的差距大大缩小，使用起来也没有那么糟糕。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年2月26日：** 已针对 至暗之夜 进行审核。
- **2026年2月10日：** 为职业门槛解锁的改动更新了天赋树。
- **2026年1月19日：** 已针对至暗之夜进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月6日：** 已更新，编写时考虑了套装。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月23日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2版本进行审查和更新。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5版本更新页面。
- **2023年5月11日：** 将推荐天赋从黑暗酿酒改为鞭笞。
- **2023年5月1日：** 已针对10.1版本审查和更新页面。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已针对10.0.5版本更新页面。
- **2022年12月17日：** 添加了多目标技能优先级列表并更新了单体目标列表。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页，你将找到《魔兽世界》12.1.5补丁中 敏锐 潜行者 的最佳天赋。我们还为团本或大秘境等不同类型的内容提供了默认天赋配置。如果你开启了战争模式，我们也为你准备了PvP天赋。

1.

### 敏锐 潜行者 的最佳 至暗之夜 天赋

在第2赛季中，敏锐 在选择英雄天赋树方面又多了一些灵活性和平衡性。我们目前的推荐如下：

- **单体目标 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 提供最强的单体目标伤害。
- **AoE -** 两个英雄天赋都可行： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 提供更高的爆发伤害，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 提供更好的单体目标伤害、优先目标伤害以及更持续的AoE DPS，这在高层大秘境中通常更受青睐。

如果你还不熟悉 敏锐 潜行者 的玩法，那么我们建议先从 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 天赋树开始用于AoE/大秘境，因为玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手.

**快速开始导入代码：**

:::talents 单体目标 - 死亡猎手
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::talents 每周大秘境 - 欺诈者
```json
{
  "code": "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAziWoFbYGwMDmxA"
}
```
:::

:::talents 高层大秘境 - 死亡猎手
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::talents 地下堡 - 欺诈者
```json
{
  "code": "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAziWoFbYGwMDmxA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

死亡猎手

团队副本/单体目标

推荐

大秘境/群体伤害

高层大秘境

欺诈者

团队副本/单体目标

大秘境/群体伤害

每周大秘境钥匙

地下堡

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 团本配置

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手在单体目标情况下能打出极高伤害，在AoE中也能提供强力的优先目标伤害。如果你还没有获得[[spell:1296593]]套装加成，请取消选择[[spell:382524]]，将那一点投入到[[spell:245687]]中。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 大秘境天赋

天赋[[spell:457055]]配合[[spell:457058]]使得 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手能够对大型优先目标造成巨量伤害，同时还能保持强大的AoE能力。

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 团本天赋

强大的爆发 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者在特定Boss战中非常有用，然而其单体伤害相比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手团本天赋有所欠缺。

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者大秘境配装

强大的爆发 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者在快速清理小怪群方面非常有用。然而其单体伤害和优先目标伤害相比
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手配置有所欠缺，这也是很多高层大秘境队伍使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手.

### 天赋方案 1-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 挖宝天赋

我们推荐的挖宝天赋，恰好与欺诈者大秘境天赋完全相同。它提供了爆发伤害和生存能力的良好结合。关于挖宝的运作方式及预期内容，请查看我们的 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 页面！

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dqUZdlBWk5hiT0ABZaiUqD-AAAA-GIOQaAEIogBFmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-GIOQaAEIogBFmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzGL0mNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dqUZdlBWk5R0ABhirjcaSC-AAAA-BIOiQZzQhBTgwF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-BIOgQRzQhBTgwF-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-BIOgQRzQhBTgwF-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

万卷书是至暗之夜中引入的一个系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，它提供了一些非常小的性能增强选项。其中一些加成提升输出，另一些则更偏向防御。

我们推荐你选择以下加成：

- 节点1：[[spell:1279599]]
- 节点2：[[spell:1279604]]
- 节点3：[[spell:1287555]]
- 节点4：[[spell:1279612]]
- 节点 5：[[spell:1279615]]

1.

### 巅峰天赋： ![Ancient Arts Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_nightblade.jpg>) 诡谋承袭

这些是至暗之夜中新增的天赋，它们位于专精天赋树下方，威力极其强大。这四个天赋都围绕着以不同方式与[[spell:196912]]交互时生成的暗影分身。虽然这些天赋的说明文字可能看起来很复杂，尤其是如果你对[[spell:196912]]的运作方式不太熟悉的话（你可以在循环页面阅读关于它们如何运作的详细解释），但实际上远古技艺相当简单直接。

1. [[spell:1268932]]——每当有东西消耗（使用/花费）你的[[spell:196912]]层数时，就有几率生成一个暗影分身，并根据消耗这些层数的法术造成额外伤害。
2. [[spell:1268936]]——被动提高你造成的所有暗影伤害，并且当你从[[spell:1268932]]或[[spell:280719]]生成暗影分身时，你会获得1层[[spell:196912]]。
3. [[spell:1268939]]——在施放连击点生成技能后，如果你还剩5层或更多层的[[spell:196912]]，你将激活一个增益效果。这个增益效果会使你的下一个连击点终结技也消耗你的[[spell:196912]]层数，这意味着你在使用终结技后立即获得一整套连击点。这还会触发来自[[spell:1268932]]的暗影分身，其伤害基于所使用的终结技。

这些巅峰天赋让我们在爆发窗口期间更高效地利用我们的[[spell:196912]]，并可以连续施放像[[spell:196819]]这样的终结技，而无需在中间使用任何连击点生成技能。你还会通过[[spell:1268936]]生成的[[spell:196912]]层数被动获得更多伤害和更多连击点，这有助于使循环更加平滑。

1.

### 敏锐 潜行者的英雄天赋

从71级开始，英雄天赋是一组互斥的天赋树，你可以从中选择，它们会轻微改变专精的玩法和特色。对于敏锐 潜行者，选择在于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者主题基于欺骗。在游戏中，这表现为像[[spell:441403]]这样的天赋将[[spell:57934]]的持续时间延长至一小时而不是短短几秒，有时用[[spell:441146]]进行攻击，以及通过[[spell:441429]]生成一大团烟雾。

在玩法方面，英雄天赋树非常注重围绕[[spell:121471]]和[[spell:280719]]的大爆发窗口，让敏锐 潜行者在需要大量即时伤害的情况下真正大放异彩。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手

追踪并专注于单一目标是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手的全部意义所在。其核心机制[[spell:457052]]与一个特定目标绑定，借助[[spell:457055]]，即使在多目标场景下，你也能将大量伤害优先倾泻到那个敌人身上。像[[spell:457057]]这样的天赋使你的目标很难逃脱你，而[[spell:457034]]是当敌人决定反击时的绝佳防御选择。

这个英雄天赋树完全围绕管理[[spell:457052]]，在正确的时间将其施放在正确的目标上。一旦标记的所有层数被消耗完毕，最大的回报就是[[spell:457058]]，它使你的下一个[[spell:196819]]造成巨额伤害。

1.

### PvP天赋（战争模式）

如果愿意，你可以启用“战争模式”。启用战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高15%。
- 赚取征服点数，每周可兑换装备。

鉴于启用战争模式对升级和PvE内容的好处，建议启用该功能以最大化你的升级效率和满级后的奖励。然而，你将使自己成为开放世界PvP的目标，并且在升级或进行世界任务时存在被“偷袭”的可能性。

在本节中，我们将为升级和进行单人/小队PvE内容排序最佳的PvP天赋。以下是通用PvP天赋和敏锐 潜行者专属PvP天赋的排名。

1. [[spell:269513]]只是更强的[[spell:196819]]。
2. [[spell:198675]]——每当潜行激活时，你会对附近的敌人施加一个减益效果，使他们从你的下一次暗影打击中额外受到5%的伤害。最多叠加8次。这没什么特别的，但仍是一个轻微的伤害提升。
3. 只有两个荣誉天赋能在户外提高我们的DPS，所以最后一个选择由你决定，选你认为最适合自己的那一个。

[[spell:198952]]、[[spell:207736]]、[[spell:197899]]、[[spell:212182]]、[[spell:221622]]、[[spell:354661]]、[[spell:354406]]、[[spell:207777]]和[[spell:197000]]在PvE内容中对提高你在开放世界中的伤害作用有限。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年5月3日：** 已针对 5 月 5 日的平衡性调整进行更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 已针对 至暗之夜 史诗钥石发布进行审核。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对 至暗之夜 进行审核。
- **2026年2月10日：** 为职业门槛解锁的改动更新了天赋树。
- **2026年1月19日：** 已针对至暗之夜进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月23日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月24日：** 已更新，添加了暗影尘埃天赋构建。
- **2023年11月6日：** 已针对10.2版本进行审查和更新。
- **2023年9月4日：** 重新排版了天赋表格和说明。
- **2023年7月10日：** 进行了少量推荐天赋更新。
- **2023年5月11日：** 将推荐天赋从黑暗酿酒改为鞭笞。
- **2023年5月9日：** 添加了使用亚贝鲁斯套装的新天赋构建。
- **2023年5月1日：** 已针对10.1版本审查和更新页面。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月14日：** 更新了推荐的单体目标天赋构建。
- **2023年1月24日：** 已针对10.0.5版本更新和审查页面。
- **2022年12月17日：** 修复了单体目标专精的导入字符串。
- **2022年12月11日：** 更新了推荐天赋。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月31日：** 更改了推荐的团本天赋构建，并添加了关于特定行中可能天赋选择的说明。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页，你将学习如何在单目标和多目标情况下优化你的敏锐 潜行者的循环。我们还有关于冷却时间、触发效果等的进阶章节，以便将你的DPS最大化。我们所有的内容均针对《魔兽世界》12.1.5补丁进行了更新。

1.

### 敏锐 潜行者玩法与循环指南

欢迎来到我们的敏锐潜行者循环页面。在本页，你将找到在团队副本和大秘境场景中游玩该专精所需了解的一切。

敏锐 潜行者是一个90秒周期的专精。每90秒，你将使用[[spell:121471]]配合2次[[spell:185313]]。尽可能充分地利用这些爆发窗口是有效游玩敏锐 潜行者的关键。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者

单目标/范围伤害

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手

单目标/范围伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

[[spell:426591]]

[[spell:381623]]

### 单体目标循环

始终以[[spell:1784]]状态开怪，并挂上[[spell:315584]]和[[spell:381637]]。

1. **适用条件：Goremaw's 撕咬（启用）。** 每当[[spell:426591]]就绪时就施放它，就在你的其他冷却技能之前。
2. **适用条件：欺诈者（启用）。** 当你有6个或更多连击点且[[spell:185313]]就绪或[[spell:121471]]激活时，施放[[spell:280719]]。
3. **适用条件：死亡猎手（启用）。** 当你有2个或更少连击点且[[spell:280719]]就绪或[[spell:121471]]激活时，施放[[spell:185313]]。
4. 在[[spell:185313]]期间施放[[spell:121471]]。
5. **适用条件：死亡猎手（启用）。** 在[[spell:457058]]激活时，以6个或更多连击点施放[[spell:196819]]。
6. 在[[spell:185313]]期间以6个或更多连击点施放[[spell:280719]]。
7. **适用条件：欺诈者（启用）。** 以6个或更多连击点施放[[spell:441423]]。
8. 以6个或更多连击点施放[[spell:196819]]。
9. 只要能用就施放[[spell:185438]]，否则施放[[spell:53]]来产生连击点。

**适用条件：死亡猎手（启用）。** 确保始终以一个[[spell:185438]]开怪来施加[[spell:457052]]。

你始终希望在[[spell:121471]]期间使用两个[[spell:185313]]，所以当[[spell:121471]]的冷却时间剩余不到10秒时不要施放它。

**适用条件：Thistle Tea（启用）。** 你不需要主动使用[[spell:381623]]，让它在你能量低时自动激活是最优的。

**适用条件：欺诈者（启用）。** 你要确保在施放[[spell:280719]]时始终有[[spell:1268939]]激活。实现这一点的方法是在你打算[[spell:185313]]之前的几秒钟内不施放任何终结技，以确保你堆叠了几个额外的[[spell:196912]]。你可以继续以满连击点施放[[spell:53]]以避免能量溢出。你可以在下方阅读更多关于如何在你的[[spell:185313]]之前进行准备的内容，以确保这一点发生。

**适用条件：死亡猎手（启用）。** 你要确保在[[spell:185313]]期间，你的[[spell:457058]]上始终有[[spell:1268939]]激活。这意味着如果你没有[[spell:1268939]]激活，你可以再按一个[[spell:185438]]来确保它触发，即使你已经满了连击点。你可以在下方阅读更多关于如何在你的[[spell:185313]]之前进行准备的内容，以确保这一点发生。

[[spell:1856]]可以在任何时候只要[[spell:185313]]未激活时使用。确保紧接着施放一个[[spell:185438]]。

### 多目标（AoE）循环

始终以[[spell:1784]]状态开怪，并挂上[[spell:315584]]和[[spell:381637]]。

1. **适用条件：Goremaw's 撕咬（启用）。** 每当[[spell:426591]]就绪时就施放它，就在你的其他冷却技能之前。
2. **适用条件：欺诈者（启用）。** 当你有6个或更多连击点且[[spell:185313]]就绪或[[spell:121471]]激活时，施放[[spell:280719]]。
3. **适用条件：死亡猎手（启用）。** 当你有2个或更少连击点且[[spell:280719]]就绪或[[spell:121471]]激活时，施放[[spell:185313]]。
4. 在[[spell:185313]]期间施放[[spell:121471]]。
5. 在[[spell:185313]]期间以6个或更多连击点施放[[spell:280719]]。
6. **适用条件：死亡猎手（启用）。** 在[[spell:457058]]激活时，以6个或更多连击点施放[[spell:196819]]
7. **适用条件：欺诈者（启用）。** 以6个或更多连击点施放[[spell:441423]]。
8. 以6个或更多连击点施放[[spell:319175]]。
9. 施放[[spell:197835]]来产生连击点。

**适用条件：死亡猎手（启用）。** 确保始终以一个[[spell:185438]]开怪来施加[[spell:457052]]。

你始终希望在[[spell:121471]]期间使用两个[[spell:185313]]，所以当[[spell:121471]]的冷却时间剩余不到10秒时不要施放它。

**适用条件：Thistle Tea（启用）。** 你不需要主动使用[[spell:381623]]，让它在你能量低时自动激活是最优的。

你要确保在施放[[spell:280719]]时始终有[[spell:1268939]]激活。实现这一点的方法是在你打算[[spell:185313]]之前的几秒钟内不施放任何终结技，以确保你堆叠了几个额外的[[spell:196912]]。你可以继续以满连击点施放[[spell:197835]]以避免能量溢出。你可以在下方阅读更多关于如何在你的[[spell:185313]]之前进行准备的内容，以确保这一点发生。

[[spell:1856]]可以在任何时候只要[[spell:185313]]未激活时使用来触发[[spell:385722]]。

### 起手式

[[spell:1784]]

[[spell:185438]]

[[spell:196819]]

[[spell:1856]]

[[spell:185438]]

[[spell:426591]]

**适用条件：死亡猎手（启用）。**

[[spell:196819]]

[[spell:121471]]

[[item:270175]]

[[item:241308]]

[[spell:33697]]

[[spell:274738]]

**适用条件：欺诈者（启用）。**

[[spell:185313]]

[[spell:280719]]

**适用条件：死亡猎手（启用）。**

[[spell:185313]]

[[spell:197835]]

**适用条件：死亡猎手（启用）。**

[[spell:280719]]

在战斗开始前20秒以上的任何时候，使用一次[[spell:185313]]来激活[[spell:470347]]。

1. [[spell:1784]]
2. [[spell:185438]]
3. [[spell:196819]]
4. [[spell:1856]]
5. [[spell:185438]]
6. [[spell:426591]]
7. **适用条件：死亡猎手（启用）。** [[spell:196819]]
8. [[spell:121471]]
9. 任意主动使用属性的饰品（例如：[[item:270175]]）、[[item:241308]]以及你可能拥有的任意种族属性技能（例如：[[spell:33697]]/[[spell:274738]]/[[spell:26297]]）
10. **适用条件：欺诈者（启用）。** [[spell:185313]] + [[spell:280719]]
11. **适用条件：死亡猎手（启用）。** [[spell:185313]] + [[spell:197835]]
12. **适用条件：死亡猎手（启用）。** [[spell:280719]]
13. 继续你的常规循环。

**适用条件：死亡猎手（启用）。** 如果你获得了很多[[spell:196912]]触发，你可能在到达[[spell:185313]]+[[spell:197835]]这一步时已经满了连击点，在这种情况下你应该改为[[spell:185313]]+[[spell:280719]]。

### 辅助高亮 & 单键助手

该 **单键助手** 系统为该专精及其众多按键提供了一个简单的入门方式，但这是有代价的。由于公共冷却时间的增加，你的DPS自然会较低。单键循环还缺少循环中一些细微的差别，以便让刚开始游戏旅程的玩家更容易上手。

所以即使使用了 **辅助高亮** 功能，你也会稍微落后于那些已经掌握了该专精所有细节的玩家。话虽如此，与最复杂、最详细的循环玩法相比，DPS的差距并没有你想象的那么大。

你可以预期比完美循环玩法低约10%的DPS，所以如果你想在进入新手DPS循环之前先熟悉一下，使用辅助高亮甚至单键助手是初学者的一个绝佳起点。

1.

### 至暗之夜 第2赛季套装

在至暗之夜第2赛季期间，你将获得以下套装奖励：

- [[spell:1296592]]
- [[spell:1296593]]

第 2 赛季套装两件套效果提供的能量消耗降低，使得几乎每一个非 [[spell:185313]] 的公共冷却都可以用 [[spell:53]] 或 [[spell:197835]] 来填充，从而使该专精在循环中的空闲时间更少。伤害增益也让这些技能更具威力。

四件套效果使 [[spell:382524]] 也能影响 [[spell:196819]] 和 [[spell:319175]]，这使得该天赋成为必选。套装效果不会改变循环的运作方式，但由于这一点，你的 [[spell:121471]] 的后半段现在会比前半段更强。

1.

### 职业与专精机制详解

为了更好地解释敏锐 潜行者技能组合的具体用法和好处，我们整理了关于循环各个部分及其机制的更详细解释，以及你最强大的冷却技能和如何最好地利用它们。

### 暗影之舞的准备

3.1.

#### 暗影之舞的准备

目前对敏锐最有影响的优化是确保你始终有[[spell:1268939]]激活以释放其最强大的技能。很多时候这会在游玩中自然发生，但有时必须用额外的连击点生成技能来强制触发，即使连击点已满，也要确保它已激活。减少你必须施放该额外生成技能次数的一种方法是，在进入你的[[spell:185313]]时保持正确的增益效果和层数激活。理想的准备方式取决于你的英雄天赋：

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者：你想要增益[[spell:280719]]，由于它是你想在[[spell:185313]]中施放的第一个法术，你需要以正确的准备状态进入。在进入[[spell:185313]]之前，确保有7个连击点、5层或更多层的[[spell:196912]]以及[[spell:1268939]]激活。这个规则的例外是在[[spell:121471]]的后半段，此时你只需要在第一个[[spell:185313]]结束后尽快施放它。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手：这里有更大的灵活性。其核心思想是确保[[spell:457058]]是 **始终** 在[[spell:185313]]期间被[[spell:1268939]]增益。你先施放哪个法术会根据你进入[[spell:185313]]时的增益效果而有所不同。以下是一些实现这一目标的准备状态示例，不过还有其他有效的组合。

- 满连击点 + 1层[[spell:457052]] + 4-5层[[spell:196912]]。
- 无连击点 + [[spell:457058]]激活 + 5层或更多层[[spell:196912]]。
- 满连击点 + [[spell:457058]]激活 + [[spell:1268939]]激活。

所有这些[[spell:457058]]优化都围绕单目标或低目标数顺劈展开。由于[[spell:457058]]对高目标数场景没有影响，你应该改为遵循 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者在多目标/AoE场景下的上述规则。

### 连击点 & 能量

3.2.

#### 连击点数与能量

作为一名潜行者，你的大多数技能都需要能量才能使用。你的能量条默认容量为100点能量，以每秒10点能量的速度回复。拥有[[spell:14983]]时，上限变为200点能量。你的能量回复速度会因以下原因提高：

- 急速（装备上的急速 + 提高急速的增益效果）。
- [[spell:58423]]被动，保证你的终结技每个连击点恢复5点能量。
- [[spell:196912]]，每次触发时奖励5点能量。由于[[spell:426594]]，它在[[spell:185313]]期间的触发频率也显著提高。
- [[spell:14983]]（如果选择）。

就敏锐 潜行者目前的玩法而言，你不需要管理或考虑你的能量。在[[spell:185313]]之外，能量不足以在每个公共冷却期间施放一个法术，这完全没问题且正常。相反，当[[spell:185313]]激活时，你可以通过通过[[spell:58423]]生成和消耗的额外连击点以及你生成的大量[[spell:196912]]层数来连发你所有的公共冷却技能。

### [[spell:196912]]

3.3.

#### 暗影技巧

这是刚开始游玩敏锐时可能看起来像“随机”额外连击点的来源。这是你角色身上获得的一个可叠加的增益效果，它使你的下一个连击点生成技能根据你拥有的增益层数生成额外的连击点。但值得注意的是，游戏永远不会消耗这些层数让你超过最大连击点，相反，增益的层数会被保留。每次效果触发并获得一层时，你还会获得5点能量。

该增益通过被动自动攻击以及通过[[spell:1268936]]叠加。然而，自动攻击的被动生成并不像说明文字暗示的那样随机。虽然它平均下来和说明文字所说的一样是28%，但实际上它是这样运作的：

1. 你的第1次攻击有0%的几率触发它
2. 你的第2次攻击有50%的几率触发它
3. 你的第3次攻击有100%的几率触发它
4. 如果第2次攻击没有触发它，第3次攻击有100%的几率触发它。
5. 每当它触发时，它都会从头开始重新计算。

当[[spell:426594]]说它“触发频率提高25%”时，它实际上在第二次攻击时有100%的几率触发。由于该专精生成的连击点有很大一部分来自[[spell:196912]]，所以[[spell:426594]]实际上是必需的，因为它使每次触发的连击点翻倍。

### 巅峰天赋：远古技艺

3.4.

#### 巅峰天赋：远古技艺

3.4.1.

##### 解释该天赋如何运作

要理解远古技艺，你必须首先理解[[spell:196912]]的运作方式，你可以在紧挨着本节的章节中阅读相关内容。

第一个巅峰天赋[[spell:1268932]]相当简单直接。每当有东西消耗（使用/花费）[[spell:196912]]层数时，就有几率生成一个造成额外暗影伤害的分身。默认情况下，这个几率是每层[[spell:196912]]15%，但你始终选择的天赋[[spell:382506]]会将几率提高到每层20%，所以如果你消耗5层或更多层[[spell:196912]]，你就有100%的几率生成该分身。

第二个巅峰天赋[[spell:1268936]]提高你造成的所有暗影伤害，并且使你每次生成分身时获得1层[[spell:196912]]。这包括[[spell:1268932]]分身和[[spell:280719]]分身。它也受益于[[spell:426594]]，所以每当你在[[spell:185313]]期间施放[[spell:280719]]时，你总共获得4层[[spell:196912]]。

第三个也是最后一个巅峰天赋[[spell:1268939]]是对循环影响最大的一个。每当你施放连击点生成技能（[[spell:185438]]、[[spell:53]]或[[spell:197835]]）并且你还剩5层或更多层[[spell:196912]]时 **之后** 该增益就会激活。游戏中该增益在屏幕中央附近有一个暗影发光指示器来通知你它已激活，它的作用是你的下一个连击点消耗技能会消耗你的[[spell:196912]]层数，就像生成技能一样，这实际上意味着你无需施放生成技能就能返还连击点，从而允许你紧接着施放另一个终结技。这也与[[spell:1268932]]协同并激活它，它随后会生成一个根据你的终结技造成伤害的分身。

1.

### 敏锐 潜行者的重要冷却技能

### [[spell:121471]]

4.1.

#### 暗影之刃

[[spell:121471]]是我们最重要的冷却技能。它每90秒可用一次，激活期间你的连击点生成技能会生成双倍连击点，并且每次攻击额外造成20%的暗影伤害。

因此，每次施放[[spell:121471]]时都应配合施放2次[[spell:185313]]，因为同时叠加多个伤害增益冷却技能可以造成更多伤害。这也是使用其他增伤效果的最佳时机，比如你的药水或任何你可能拥有的种族增益（例如[[spell:33697]]）。

### [[spell:185313]]

4.2.

#### 暗影之舞

[[spell:185313]] 是你的“看家本领”冷却技能，你的伤害输出很大程度上依赖于正确使用它。暗影之舞 有1层充能，点出[[spell:394930]]后为2层，每层20秒充能时间。其基础持续时间为6秒。

然而，天赋[[spell:185314]]会根据你角色的急速属性延长其持续时间。因此，像[[spell:2825]]或[[spell:10060]]这样的增益不会延长持续时间，但像[[item:249344]]这样的主动使用饰品会延长。

它也可以通过[[spell:382505]]天赋延长，在团队副本战斗中这个效果只会在战斗开始时触发。但延长[[spell:185313]]的持续时间非常强大，除非战斗时间很长，否则通常都值得考虑。

然而在大秘境中，这个效果可以非常频繁地触发，通常明智的做法是在开怪前等待几秒钟，尤其是当这个6秒窗口即将结束时。

通常你需要在[[spell:280719]]就绪时施放[[spell:185313]]，而[[spell:280719]]应该几乎卡着冷却使用。虽然[[spell:280719]]的冷却时间为25秒，但可以被急速缩短。

由于[[spell:185314]]会以如此多变的程度延长暗影之舞的持续时间，建议始终尽可能减少技能之间的间隔进行施放。这包括使用一个或多个宏来确保[[spell:185313]]内的第一个技能立即施放，而不是延迟0.2秒。你可以在我们的宏指南中找到这些宏：

[敏锐 潜行者插件与宏](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-macros-addons>)

4.3.

#### 防御实用性

潜行者拥有游戏中最出色的防御能力之一，这使他们成为应对必需机制和承受大量即将到来伤害的可靠人选。

- [[spell:1966]]仅消耗25点能量，就能在6秒内将受到的范围伤害降低40%。当点出[[spell:79008]]天赋后，它还会使所有其他伤害降低20%。这是游戏中最超模的技能之一，在承受大量团队伤害的战斗中是一笔巨大的财富。
- [[spell:31224]]移除所有非物理减益效果，随后5秒内所有法术都将未命中。斗篷可用于应对首领战机制，也可用于提升伤害，例如在原本需要躲避的范围伤害中停留并攻击首领。
- [[spell:31230]]是一项天赋，允许你每6分钟逃脱一次致命伤害。该伤害不能超过你最大生命值的两倍。装死非常适合用来应对无视免疫和减伤的机制，因为它能保证你的生存。它也非常适合应对可能让你措手不及的爆发性伤害，因为你每6分钟都能获得一次免费的免死金牌。
- [[spell:185311]]在极短的冷却时间内提供少量治疗。当你生命值过低或超出治疗者范围时，可用于额外的治疗。
- [[spell:5277]]在点出[[spell:79008]]天赋后提供20%的伤害减免，如果点出[[spell:457034]]天赋，对魔法伤害还会额外提供15%的减免， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手。这是一个非常可靠的冷却技能，但常常被[[spell:1966]]的强大所掩盖。闪避机制在单人内容中非常有用，但在团队环境中则非常小众。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月3日：** 已针对 5 月 5 日的平衡性调整进行更新。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年2月26日：** 已针对 至暗之夜 进行审核。
- **2026年2月10日：** 已针对至暗之夜进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月23日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2版本进行审查和更新。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 已针对10.1版本审查和更新页面。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已针对10.0.5版本更新和审查页面。
- **2022年12月17日：** 对技能优先级列表进行了小幅更新。
- **2022年12月11日：** 添加了关于冷酷鲜血使用的说明。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月31日：** 已更新页面，添加了温西尔构建的起手式。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页面中，你将找到《魔兽世界》12.1.5版本中敏锐 潜行者的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们一应俱全！

1.

### 敏锐 潜行者毕业装备指南

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备物品等级，难度更高的内容掉落的装备可以进一步升级。欲了解更多信息，请阅读我们关于如何的专门页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含来自所有来源的敏锐 潜行者最高DPS配置。请注意，还有许多其他配置在误差范围内表现相当。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，催化物品会保留其之前的属性，这意味着最佳套装部件取决于你可以放入催化器的物品。以下是催化为套装的最佳物品：

- 头盔 - 来自[[item:271875@JAAEAAAG2chN]] [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩膀 - 来自[[item:268246@JAACAAAG2A]] [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 胸甲 - 来自[[item:251159@JAACAAgNyA]] [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 手套 - 来自[[item:268234@JAACAAgNyA]] [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- 腿部 - 来自[[item:268225@JAACAAAG2A]] [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 常见问题解答：我可以使用非匕首作为副手武器吗？
不行，副手始终使用匕首。原因是

[[spell:196912]]

由于匕首攻击速度更快，因此触发更频繁。因此，使用非匕首会损失大约10%的能量和连击点。

:::

:::details 常见问题解答：我应该在哪里使用我的虚空核心（额外拾取）？
团队副本的最终首领，乌拉特克。它掉落4件非常强大的物品，全部都是毕业装备。因此建议从你的宝库中选择虚空核心（额外拾取），直到你获得所有这4件物品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271510@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271511]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271508@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:251194@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAIAAwt1ENMMYDYwA]]&#10;&#10;<div>[[item:240167]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271093@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237837@JAAIAAwt1ENMcYzy1A]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 秘境+

此列表包含来自第2赛季大秘境地下城可刷取装备的最高DPS配置。请注意，还有许多其他配置在误差范围内表现相当。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，催化物品会保留其之前的属性，这意味着最佳套装部件取决于你可以放入催化器的物品。以下是催化为套装的最佳物品：

- 头盔 - 来自[[item:251140@JAACAAgNyA]] [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 肩部 - [[item:251223@JAACAAgNyA]] 来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 胸甲 - 来自[[item:251159@JAACAAgNyA]] [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 手套 - [[item:251124@JAACAAgNyA]] 来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 腿部 - [[item:251130@JAACAAgNyA]] 来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：这个地下城几乎每件物品都很不错，而且它拥有最强的非团队副本使用型物品：[[item:250215@JAACAAgNyA]]。
- [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：物品大多都很扎实，被动饰品[[item:250259@JAACAAgNyA]]也非常强力。
- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：这里有一把非唯一的匕首，带有额外的伤害触发效果[[item:275070@JAACAAgNyA]]，以及大量用于达到阈值的高急速物品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271510@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:159317@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>护肩</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271509@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:251194@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>护腕</th><td>[[item:251135@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>饰品</th><td>[[item:250259@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:275070@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:275070@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 团队副本

本列表包含仅使用来自剧毒深渊团本装备的最高 DPS 配置。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，催化物品会保留其之前的属性，这意味着最佳套装部件取决于你可以放入催化器的物品。以下是催化为套装的最佳物品：

- 头盔 - 来自[[item:271875@JAAEAAAG2chN]] [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩膀 - 来自[[item:268246@JAACAAAG2A]] [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 胸部 - [[item:268235@JAACAAgNyA]] 来自 [内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- 手套 - 来自[[item:268234@JAACAAgNyA]] [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- 腿部 - 来自[[item:268225@JAACAAAG2A]] [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:271093]]：一把高物品等级的匕首，带有出色的伤害效果。掉落自最终首领 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- [[item:270175]]：我们最强的主动饰品。掉落自最终首领 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- [[item:268265]]：一条项链，除了拥有额外插槽外，还能触发属性加成。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271510@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271511]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271508@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:268240@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271093@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:268264@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 敏锐 潜行者饰品推荐

敏锐可选的饰品非常多，我们总是希望搭配使用一个强力的主动饰品来配合我们的[[spell:121471]]，本赛季有两个这样的选择：[[item:270175]]和[[item:250215]]。在主动饰品之外，我们还想要一个提供强力副属性增益或直接伤害触发的被动饰品。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **敏锐 潜行者饰品**
**使用型 -**

[[item:270175]]

或者，作为替代，

[[item:250215]]

**被动 -**

[[item:270165]]

或者，作为替代，

[[item:270173]]

适用于纯单体目标。

:::

还有不少其他有价值的饰品，所以请务必点击我们的排名图表，看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看更多敏锐 潜行者饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>敏锐</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]</li>&#10;<li>&#10;&#10;&#10;[[item:270173]] - <span><em>点击查看详情</em></span>&#10;<span>这个饰品在纯单体目标中表现极其出色，但一旦有额外目标存在就会变差。&#10;      </span>&#10;</li>&#10;<li>[[item:270165]]</li>&#10;<li>&#10;&#10;&#10;[[item:281215]] - <span><em>点击查看详情</em></span>&#10;<span>这个饰品在大秘境场景中表现极其出色，但在单体目标上并不亮眼。&#10;      </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270168]]</li>&#10;<li>[[item:274493]]</li>&#10;<li>&#10;&#10;&#10;[[item:248583]] - <span><em>点击查看详情</em></span>&#10;<span>通过前往祖尔'Aman的不同神龛，你可以调整触发效果给你提供的属性。你需要它给你提供精通。&#10;      </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:265657]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>&#10;&#10;&#10;[[item:159617]] - <span><em>点击查看详情</em></span>&#10;<span>如果你还没有[[item:270175]]或[[item:250215]]，这是它们的替代品。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:273796]] - <span><em>点击查看详情</em></span>&#10;<span>如果你还没有[[item:270175]]或[[item:250215]]，这是它们的替代品。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250225]]</li>&#10;<li>[[item:158374]]</li>&#10;<li>[[item:241340]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:251785]]</li>&#10;<li>[[item:251783]]</li>&#10;<li>[[item:274496]]</li>&#10;<li>[[item:274497]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:246307]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:246305]]</li>&#10;<li>[[item:246306]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

- [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 是一种你可以在每周从宝库中选取物品时选择代替的物品。它们类似于很久以前的“额外拾取”系统，实际上允许你定向获取来自特定首领或地下城的物品。你使用它们时获得的物品是随机的，然而一旦虚空核心已经给你提供过一件物品，你就无法再次获得它。这意味着下次你使用时，你会从该掉落池中获得其他可用物品之一。从这些获得的物品将对应你所进行内容的宝库物品等级，例如如果你在英雄难度下对团本最终首领使用一个，你将获得一个1/6史诗难度物品。
- 在补丁开始时，获得该物品的唯一途径是 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)的唯一方式是从每周宝库中选取，然而自12.1.5补丁起，现在还有一个每周任务每周奖励一个。

3.1.

#### 敏锐 潜行者推荐虚空核心（额外拾取）使用指南

你想要追求哪件物品很大程度上取决于你已有的物品，以及你是否预期在史诗难度下击杀某些首领，因为你不想把虚空核心浪费在几周后可能通过更高难度路线获得的物品上。优先级如下：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
   
   
   
   
   [[item:271093]]
   
   
   
   
   [[item:270175]]
   
   
   
   
   [[item:268265]]
   
   
   
   
   [[item:271875]]
   
   
   
   
   所有这些物品都掉落自团本的最终首领，乌拉特克。
2. [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
   
   
   
   
   这个首领掉落大量优质物品，包括[[item:270173]]。
3. 剩余的毕业装备列表物品

:::

3.2.

#### 至尊毒石

使用你的[[item:280562]]的优先级与使用你的纹章类似：

1. 主手武器
2. 主动使用饰品（最好是[[item:270175]]）
3. 被动饰品
4. 项链
5. 副手武器
6.

### 敏锐 潜行者最佳打造装备

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

在赛季初期，你打造物品的能力会受到严重的时间限制。因此我们强烈推荐尽快打造一件 **主手武器** ，除非你确定能从其他地方获得。当你获得一把好武器后，就开始制作你的其他镶嵌物品，之后专注于打造你目前物品等级最低的那件装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **敏锐打造装备优先级**
- [[item:237837]]搭配[[item:273060]]
- [[item:244576]]搭配[[item:240167]]
- 任何你尚未获得神话级的物品。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 敏锐 潜行者最佳镶嵌

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

由于衬饰的竞争非常激烈，你必须为你整体的DPS输出挑选出最强的两个。大多数衬饰提供的DPS收益非常相似，即使效果完全不同。对此最佳的两个选择是：

- 团本：武器上使用[[item:273060]]，腰带或护腕等另一件打造装备上使用[[item:240167]]。
- 大秘境：武器上使用[[item:273060]]，腰带或护腕等另一件打造装备上使用[[item:240167]]。

建议你进行模拟，找出最适合你的方案。如果你还玩其他两个潜行者专精，你可能想要选择对三者都适用的装饰。

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何奖励即可获得该物品。不选择奖励将最多奖励你6个代币，其中6个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，前提是你是在第2赛季获得它们的。

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于每周获得新纹章的数量有上限，而且升级不同物品消耗的纹章数量相同，你应该优先将纹章用于你短期内不打算更换的装备，和/或能带来最大收益的装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **敏锐 潜行者纹章升级优先级**
**武器（主手）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些并不是唯一值得升级的装备。它们只是在赛季初期、你的升级货币有限时能提供最高DPS收益的装备。请注意，例外情况是可能存在的，例如附带额外触发效果的特殊装备。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 已针对 至暗之夜 史诗钥石发布进行审核。
- **2026年3月16日：** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年2月26日：** 已针对 至暗之夜 进行审核。
- **2026年2月10日：** 已针对至暗之夜进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月7日：** 孢子披风削弱后已审查并更新。
- **2023年11月6日：** 已针对10.2版本进行审查和更新。
- **2023年9月4日：** 添加了毕业装备表格并重新排版了页面。
- **2023年7月10日：** 已针对10.1.5版本更新页面。
- **2023年5月9日：** 添加了关于第2赛季如何使用火花的说明以及其他一些更新。
- **2023年5月1日：** 已针对10.1版本更新页面，并添加了关于埃拉诺克戒指和玛瑙纪念章的说明。
- **2023年3月20日：** 已针对10.0.7版本更新和审查页面。
- **2023年1月24日：** 已针对10.0.5版本更新页面。
- **2023年1月13日：** 添加了推荐的美化。
- **2022年12月11日：** 已针对化身密库的发布进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面中，你将了解你的敏锐 潜行者的最佳属性优先级。我们先介绍属性优先级，然后深入解释这些属性如何与你的专精和玩法互动。我们的内容已更新至《魔兽世界》12.1.5补丁。

1.

### 敏锐 潜行者 属性优先级

我们不建议你为属性优先级纠结，因为模拟你的装备是确定最佳装备的更客观、更准确的方式，适用于 <em>你的</em> 角色。

装备等级

精通

急速（达到700以上）

全能

暴击

由于[[spell:185314]]，敏锐有急速断点（或"上限"），超过之后急速的价值会下降。在第二赛季中，无论是单体还是多目标，目标急速量在700到1100之间。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手。与第1赛季不同，本赛季的阈值没有那么严格，因此在该范围内的任意数值都是可以接受的。

暴击的影响较小，因为[[spell:457058]]已经保证了暴击。尽管如此，来自的[[item:268265]]项链 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 仍然非常出色，因为其属性总量非常高。

:::details 常见问题：敏锐的属性优先级在多目标时会改变吗？
精通在多目标战斗中价值更高。

:::

1.

### 深入属性解析

**敏捷** 是你的主要属性。你应该在所有升级中寻找它。它为你提供攻击强度，决定了你技能的伤害。

**精通** 通过[[spell:76808]]提高你的连击点终结技的伤害。

**暴击** 提高你所有法术和技能的暴击几率。暴击默认造成双倍伤害，但有几种效果可以提高你的暴击伤害，使暴击更加强力，例如：[[spell:382508]]。

**全能** 简单地提高你造成的伤害和降低你受到的伤害。

**急速** 提高你的能量回复速度、攻击速度，通过[[spell:185314]]延长[[spell:185313]]的持续时间，并减少[[spell:280719]]的冷却时间。提高的攻击速度会通过[[spell:196912]]产生额外的连击点。

:::details 常见问题：敏锐 潜行者有急速上限吗？
有的，因为

[[spell:185314]]

如果急速能让你在内多施放一个法术，那么急速就非常强力

[[spell:185313]]

否则就不那么强力。推荐的急速数值可以在内提供三个额外的公共冷却

[[spell:185313]]

并留有一点余量。它还能减少的冷却时间

[[spell:280719]]

使其大致与的冷却时间对齐

[[spell:185313]]

.

:::

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月23日：** 更新了天赋构建描述。
- **2026年5月3日：** 已针对 5 月 5 日的平衡性调整进行更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对 至暗之夜 进行审核。
- **2026年2月10日：** 已针对至暗之夜进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2版本进行审查和更新。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5版本更新页面。
- **2023年5月1日：** 已针对10.1版本审查和更新页面。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 更新了属性推荐并针对10.0.5版本进行了审查。
- **2022年12月11日：** 对推荐的单体目标属性进行了小幅更新。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的敏锐 潜行者可以获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/subtlety-rogue-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你应该在一个插槽中使用[[item:240983]]。然后，其余插槽可以根据你的角色最需要什么来填充。通常你会使用急速和精通/暴击宝石（[[item:240890]]或[[item:240892]]）直到你达到急速阈值。之后，用[[item:240908]]或[[item:240898]]填充剩余插槽。

然而，宝石的选择高度取决于你所穿的具体装备。根据你装备物品提供的属性，四个副属性中的任何一个都很容易成为你表现最好的属性，因此宝石和戒指附魔的选择可能差异很大。我们强烈建议你自己进行模拟，以找出适合你特定角色和配置的最佳宝石组合。

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>主手</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]和[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>副手</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]和[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>肩部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

你选择用闪避、吸血还是急速附魔装备取决于你自己。吸血会允许你在造成伤害时获得一些额外的被动治疗，闪避减少范围法术造成的伤害，类似于[[spell:1966]]，而急速只是提高你的移动速度。在团队副本开荒中，移动速度经常被低估，如果它能让你更快到达目标，可以带来小幅的DPS提升。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

如果你尚未达到急速阈值，应该使用 [[item:241325]]，否则使用 [[item:241322]]。

3.2.

#### 药水

最好的通用属性药水是 [[item:241308]]。乍一看 [[item:241292]] 似乎更好，但它的副作用使得近战几乎无法使用，尤其是在首领战或大秘境场景中。

在使用群体伤害天赋配置的群体伤害场景中，改用 [[item:241288]] 更好，然而
**仅限于你能从它获得精通的情况**。由于它会提升你最高的副属性，你需要调整属性配置以确保从中获得精通，如果没有的话，请继续使用 [[item:241308]]。

还要确保随身携带至少几个 [[item:271883]]，以便在危急情况下治疗自己。

3.3.

#### 食物增益

推荐的食物是 [[item:255846]] 或 [[item:242275]]。

3.4.

#### 强化符文

最好的强化符文是 [[item:259085]]。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 已针对 至暗之夜 史诗钥石发布进行审核。
- **2026年3月16日：** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年2月26日：** 已针对 至暗之夜 进行审核。
- **2026年2月10日：** 已针对至暗之夜进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕版本进行审查和更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2版本进行审查和更新。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5版本更新页面。
- **2023年5月1日：** 已针对10.1版本审查和更新页面。
- **2023年4月6日：** 更新了推荐的原始宝石。
- **2023年3月20日：** 已针对10.0.7版本审查和更新页面。
- **2023年1月24日：** 更改了一些推荐的附魔和药水推荐，并针对10.0.5版本进行了审查。
- **2022年12月11日：** 对武器附魔进行了小幅更改。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用 敏锐 潜行者 挑战大秘境地下城的技巧和建议。

1.

### 敏锐 潜行者 在 至暗之夜 第2赛季的大秘境

敏锐 在大秘境中的打法围绕着利用 [[spell:185313]] 和 [[spell:121471]] 进行大规模爆发窗口。你还需要使用 [[spell:197835]] 来比单体场景中通常情况下产生更多的连击点数，从而带来更多的终结技。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

敏锐 在大秘境中提供相当低的持续群体伤害。为此，它拥有非常强大的冷却技能，可用于首领或需要快速击杀或比周围敌人拥有更高生命值的高优先级目标。你可以根据自己的偏好选择任一英雄天赋专精来玩，但
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 在较低层数的大秘境中伤害方面独占鳌头。

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) **欺诈者**    大秘境 / AoE

2.1.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 敏锐 潜行者 在 至暗之夜 中的大秘境天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 的 敏锐 配置，提供巨大的爆发力，无论是在群体伤害还是单体目标上。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMMjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAzCL0iNMDYmBzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dq4UZdlBW4R0ABJaaiijUC-AAAA-BIOgQRzQhBTgwF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) **死亡猎手**    大秘境 / AoE

2.2.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 敏锐 潜行者 在 至暗之夜 中的大秘境天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 的 敏锐 群体伤害配置。与
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 替代方案相比，它提供略高的优先目标伤害，但爆发力略低。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CUQAAAAAAAAAAAAAAAAAAAAAAAgx2MAAAAAwsMGLTMbLjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMBmFMDzMAzYA"
}
```
:::

:::details 来源计算器编码
```
#FE-FLOfGimCY4QaiS7D84pCooMPCLLMMuhhqLh-ALYjmDE9+dqUZdlBW4R0ABJaaiijkRC-AAAA-GIOQaAEIogBFmF-
```

:::

2.3.

#### 灵活的实用天赋

潜行者作为一个整体没有太多可根据前方情况灵活调整的实用天赋点数，但有几个点可以根据偏好进行调整：

- [[spell:5938]] 及其配套的 [[spell:1267182]]，如果没有狂暴效果需要驱散。
- [[spell:423701]]，如果你想要更强的减速效果（它实际上是游戏中最强的稳定减速效果，高达72%！）
- [[spell:423662]]，如果你知道你需要 [[spell:114018]] 的冷却时间更短。
- [[spell:193546]]，如果以上都不适用。
- [[spell:200733]] 和 [[spell:1776]] 互斥。通常 [[spell:200733]] 更好，因为群体打断比额外的单体打断更有价值。

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断、昏迷和控制

[[spell:1766]]是你的，嗯，“踢”。你将打断你的目标敌人，或者，当使用焦点宏时，打断你设置为焦点的目标。

#### 焦点脚踢

```wow-macro
#showtooltip 脚踢
/cast [@focus,exists,nodead][] 脚踢
```

此宏会在你有焦点目标时脚踢你的焦点目标，在你没有焦点目标时脚踢你的目标。我们建议将此宏和常规脚踢施法都放在你的动作条上，因为你可能有多个目标需要打断，而此宏始终优先考虑焦点目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**，或在游戏按键设置中设置“焦点目标”快捷键。

#### 焦点 鼠标指向

```wow-macro
/focus [@mouseover]
```

确保你的用户界面清晰地显示焦点目标的施法，以便你始终能够在冷却完毕时打断它，或与队伍其他成员协同打断。

3.2.

#### 眩晕与"打断"

[[spell:6770]] 和 [[spell:2094]] 可用于硬控住一波小怪中的一组怪物。你也可以在坦克拉怪前使用它，因为 [[spell:379005]] 在闷棍破除时会对目标施加一个降低伤害的减益效果。

点出 [[spell:200733]] 后，[[spell:2094]] 会击中目标附近的所有敌人。这使你能够同时阻止所有敌人完成施法，这是一个非常强大的效果。

[[spell:1776]]（如果点出天赋）可用于打断敌人施放原本无法打断的法术。这需要你站在敌人面前，但在许多情况下可以用来阻止敌人使用他们最致命的一些技能。有些技能使用后会进入冷却，因此用 凿击、[[spell:408]] 或 [[spell:2094]] 打断它们会让这些怪物在一段时间内无法再次施放这些技能。

[[spell:1856]] 也可以用来 [[spell:1833]] 只能被控制而无法被打断的敌人。用 [[spell:185313]] 也可以做到这一点，但除非绝对必要，否则不推荐，因为这会让你损失大量伤害。

### 其他功能

3.3.

#### 其他功能

[[spell:114018]]在你周围投射AOE[[spell:1784]]。但需要注意的是，在当前资料片中，有更多敌人可以侦测到潜行或隐形，你需要对此保持警惕。

敏锐 潜行者还可以选择点出 [[spell:382507]]，这使你即使在不试图潜行绕过小怪时，也可以将帷幕用作团队的巨大速度提升。这在室内地下城中特别强大，那里有很长的奔跑路段且无法骑乘。然而自 至暗之夜 以来，点出这个天赋的代价是放弃一个极其优秀的防御天赋 [[spell:428486]]，这使得它比以前更加小众。

[[spell:1725]] 有助于设置帷幕跳怪，并使巡逻的小怪群原地停留10秒。确保迫使敌人背对你，以便你能潜行通过它们。

[[spell:1966]]、[[spell:31224]]、[[spell:5277]]、[[spell:185311]]和[[spell:31230]]构成了一组非常强大的防御冷却技能，是潜行者在大秘境中强大的最大原因之一。

[[spell:57934]]通常并不特别出色。然而，任何有助于你的坦克对所有敌人保持仇恨的支持都是值得鼓励的。遗憾的是，它与[[spell:379005]]是选择节点。

[[spell:5938]]可用于驱散 **激怒** 效果。

[[spell:5761]] 和 [[spell:381637]] 在大秘境中都很有用，但由于更强调小怪，[[spell:5761]] 在大多数层数中可能会胜出。然而，许多高端玩家会选择使用 [[spell:381637]]，以在极高层数中对秒杀他们的首领获得一点额外优势。

1.

### 应对词缀

至暗之夜 第2赛季只有四个提供某种应对手段的重要 词缀，称为萨拉塔斯的交易，它们每周轮换，同时只有一个处于激活状态。许多其他词缀如强韧或残暴只是给钥石添加被动效果，有四个例外是围绕萨拉塔斯进行赛季主题设计的：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将会生成三波需要打断或控制的宝珠。不幸的是 潜行者 几乎没有办法处理这种情况。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：一个 虚空大使 小怪将会生成，需要集火打断。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：宝珠会在你的队伍成员周围生成，你需要吸收这些宝珠。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有队伍成员都会受到一个治疗吸收效果的影响。你可以用 [[spell:31224]] 或像 [[spell:20594]] 这样的种族技能来移除它。如果这些对你不可用，你可以使用 [[spell:185311]] 来帮助更快地摆脱这个减益效果。如果你的治疗者资源耗尽，治疗药水或治疗石也能很好地发挥作用。

每一种词缀在被处理后都会提供一组不同的增益效果，虽然它们非常强大，但你不需要以特定的方式围绕它们进行操作。最重要的是不要让任何词缀强化敌方小怪或首领。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年2月26日：** 已针对 至暗之夜 进行审核。
- **2026年2月10日：** 为职业门槛解锁的改动更新了天赋树。
- **2026年1月19日：** 已针对至暗之夜进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审核。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5版本更新页面。
- **2023年5月11日：** 将推荐天赋从黑暗酿酒改为鞭笞。
- **2023年5月1日：** 已针对10.1版本审查和更新页面。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 更新了天赋并针对10.0.5版本进行了审查。
- **2022年12月11日：** 更新了天赋推荐。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5补丁中使用 敏锐 潜行者 时更加轻松。

1.

### 最佳宏

在某些急速阈值下，由于 [[spell:185314]] 的存在，将所有法术塞进 [[spell:185313]] 可能会非常紧张。例如，如果 [[spell:185313]] 的持续时间是7.2秒，你的最后一个法术只有0.2秒的余地。这就是为什么使用宏会非常有用，可以最大限度地减少同时按下多个不同按钮造成的延迟。

#### 暗影之舞 宏用于 欺诈者

```wow-macro
#showtooltip 暗影之舞
/cast 暗影之舞
/cast 影分身
```

如果你玩的是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 倾向于在低连击点数时进入 [[spell:185313]]，不幸的是你无法将 [[spell:185313]] 和 [[spell:185438]] 一起做进宏里。这是由于一个 bug，使得你必须在按下 [[spell:185313]] 后等待约0.2秒才能使用 [[spell:185438]]。

然而，由于 [[spell:382528]] 的存在，使用此宏而不是承受那点小延迟是可以接受的：

#### 暗影之舞 宏用于 死亡猎手

```wow-macro
#showtooltip 暗影之舞
/cast 暗影之舞
/cast 袖剑风暴
```

虽然在某些情况下你可能想将 [[spell:441423]] 留给特定的爆发窗口，但这样做基本上也能正常工作。你可以将此按钮绑定为你的 [[spell:319175]] 按钮，当它就绪时会自动改为施放 [[spell:441423]]。

#### 组合致命一击 + 黑火药

```wow-macro
#showtooltip 黑火药
/cast 致命一击
/cast 黑火药
```

如果你希望在起手/爆发序列中按键操作不那么频繁，你可以将你的主动使用饰品和药水与 [[spell:121471]] 一起做进宏里。

#### 暗影之刃 + 饰品 + 药水

```wow-macro
#showtooltip 暗影之刃
/cast 暗影之刃
/use 13
/use 14
/use 圣光潜力
```

#### 鼠标指向 暗影步

```wow-macro
#showtooltip 暗影步
/cast [target=mouseover,exists,noharm] 暗影步
```

此宏是一个可连按的鼠标指向 [[spell:36554]]。在你鼠标指向友方目标之前它不会施放 暗影步，这意味着在你需要 暗影步 友方目标的场景中，例如，你可以连续按它。

1.

### 最佳插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.1.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.2.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.2.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.2.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.2.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.3.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.3.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.3.4.

##### TankMD

[TankMD](<https://www.curseforge.com/wow/addons/tankmd>) 是一个新的插件，之前是一个WeakAura。它允许你自动将队伍的坦克作为你的[[spell:57934]]法术的目标，而无需鼠标悬停、焦点目标、切换目标或任何类似操作。

2.4.

#### 敏锐 潜行者专用插件

目前，我们认为没有必要使用额外的插件来充分发挥 敏锐 潜行者 的潜力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 已针对 至暗之夜 第 1 赛季进行审核
- **2026年2月26日：** 已针对 至暗之夜 进行审核。
- **2026年2月10日：** 已针对至暗之夜进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1版本进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审核。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年4月29日：** 已针对10.1版本审查和更新页面。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 更改了暗影步的宏条件并针对10.0.5版本进行了审查。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
