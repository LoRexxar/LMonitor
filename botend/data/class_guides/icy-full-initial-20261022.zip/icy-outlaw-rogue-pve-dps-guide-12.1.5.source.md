## 专精概览

Welcome to our Outlaw Rogue guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Outlaw Rogue in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Outlaw Mythic+ Resources

[NEW! Top Outlaw Talent Builds](<https://raider.io/specs/outlaw-rogue/talents>)

[Top Outlaw Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/rogue/outlaw>)

[Outlaw Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=rogue--outlaw>)

[Popular Outlaw Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=rogue--outlaw>)

1.

### Outlaw Rogue Overview

Ahoy! Outlaw Rogue is a specialization that centers around managing
resources while sustaining high damage to stacked targets. As in previous
expansions, Outlaw is a fantastic jack of all trades that can comfortably
handle any situation or fight type. Between the three Rogue specializations,
Outlaw is the most effective in situations involving cleave-DPS.

Sustained DPS Expert

Outlaw Rogue sports a very unique damage profile, with no high-impact CDs that
give it meaningful burst. The spec deals great sustained DPS, but falters
with large target-counts in AoE, while never reaching the top in raid encounters
either.

With most encounter strategies being tailored around the use of cooldowns to
burn down a boss or pack of adds very quickly, Outlaw unfortunately fails to deliver
on one of the most important tasks in Raiding. If you can get away with this weakness,
then Outlaw performs very well, as long as you can maintain high uptime on your
target(s).

Great Survivability, No Strong CDs

Outlaw Rogue is a decent pick for raid encounters, thanks to its strong sustained DPS,
but if an encounter requires high burst damage for a damage amplification phase,
or an add needs to be quickly taken down, then Outlaw does not offer the needed
damage profile to help with that in a meaningful capacity.

This leaves it behind most other specs that manage to still provide
useful burst DPS, even if their overall DPS output is significantly lower
than Outlaw's.

If you play in a raid environment where this kind of burst is not needed,
however, then Outlaw is a great spec to just put on the boss. Its unique
raid buff, [[spell:381637]], is a useful tool to mitigate damage on many
raid bosses, although it sadly does not work on all boss mechanics.

Damage On Every Pack, But No Burst

Outlaw can be played very comfortably in Mythic+, having good AoE damage
when talented for it, at the cost of a slight single-target DPS loss bosses. Especially
on smaller trash pulls, Outlaw always does great damage, not being beholden to
any CDs to take down enemies.

However, it does fall behind on any massive trash-pull,
so if you regularly pull 15+ mobs together, it cannot compete with other classes
that can carry a pull by themselves through the usage of their CDs.

Outlaw also has numerous utility spells at its disposal, allowing you to disrupt
and control enemies like few other specs can thanks to [[spell:6770]], [[spell:2094]],
[[spell:1776]], and [[spell:200733]], and it is one of two classes in the game
that has access to a group stealth ability in [[spell:114018]].

Great in Mythic+, Terrible in Raid

Outlaw has access to many different utility spells, like [[spell:381637]],
[[spell:114018]], [[spell:6770]], [[spell:2094]], or [[spell:1776]] or
[[spell:200733]]. With the exception of Atrophic Poison, none of these find
application in raid environments. Even with Atrophic not working on all raid boss
abilities, most groups still bring at least one Rogue of any spec to supply it.

In a Mythic+ dungeon, a Rogue who knows how to use all the tricks of their trade can help make
any run feel a lot easier and safer though, and while these benefits may not show on a DPS
meter, many tanks and healer will be thankful if you use your utility to the fullest extent.
The return of [[spell:200733]] for AoE-[[spell:2094]] is a great boon to our kit
as well, as it not only disrupts enemies, but also reduces their damage done with [[spell:379005]].

Incredibly Durable

Rogues are the kings of staying alive, especially in raid environments. Thanks to
[[spell:31230]], [[spell:1966]], [[spell:31224]], [[spell:5277]], and [[spell:185311]],
you will typically be one of the last few people standing, allowing you to clutch
out boss or trash kills even when things go wrong.

Having [[spell:5277]] ready when a tank dies and you can safely tank
a trash pack for another 10 seconds can save runs, and while Rogue tends to
struggle with high sustained damage over time, you have numerous tools at
your disposal to stay alive until the very end.

The only real struggle is with sustained damage-over-time, but by
talenting into [[spell:79008]] you can survive even the highest level of
keys reliably.

Very Quick To Move Around

Outlaw has solid mobility, having access to a low-cooldown [[spell:2983]]
that makes you run as fast as a mounted character, as well as being able to use
[[spell:195457]] to quickly get out of harms way, or connect with an enemy that is
far away from you. Being able to jump to any location in a large radius offers
great flexibility, and can even allow you to avoid certain mechanics from hitting you
entirely.

2.

### Outlaw Rogue in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 offers no meaningful changes to Rogue or Outlaw as a spec.
The main focus of the patch are 2 new pieces of endgame content instead, one for Raid groups, and one
for [Delves](<https://www.icy-veins.com/wow/delves-guide>). Make sure to check out both the information on the new Kith'ix Raid encounter,
as well as the new exciting Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) acts as an escalation to the progression of Season 2 in
Midnight, with the story surrounding Ula'tek and the Amani culminating in a new one-boss
raid, access to ascended item levels, multiple sources of catch up gear,
and access to an infinite number of Mistcrests to upgrade it. Make sure to check out our
patch hub for all the information on what is new, or has been updated with Patch 12.1.5.

2.3.

#### Class Changes

There have been no changes to Outlaw Rogue other than a single update to [[spell:381878]].

- Deft Maneuvers has been updated - No longer increases Blade Flurry's Energy cost
    by 30. Instead, it increases Blade Flurry's Energy cost by 5 per target hit, up to 30.
- <em>Developers' notes: This change is intended to make it a little less expensive
    to maintain Blade Flurry when fighting small numbers of additional targets.</em>

As a result, there are no changes to our
[Talent](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>) recommendations or
[rotational](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>) priorities. However, with the
new gear, our [gear](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>) page has been updated
with information on the new items and how to best use your [[item:280562]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_112_rogue_betweentheeyes.jpg>) Click for Previous Season 2 Changes
Patch 12.1 meant a lot of changes to both the Rogue class, as well as Outlaw
specifically. Many other classes were hit with nerfs to their cooldowns, to reduce burst-damage
and increase sustained DPS. Outlaw already excelled in this particular niche, and we have
received further damage buffs to our already very unique damage profile, while our cooldowns
were buffed a little as well!

We have also received numerous buffs to underperforming talents, so you may no longer
feel forced into playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster and [[spell:51690]]. Overall, Outlaw
will feel very familiar, with the general priorities largely remaining the same. Still,
the new talent flexibilities afford us some new opportunities we didn't have before, and
our damage will be more impactful across the board as well.

[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Outlaw Rogue**

<em>Developers’ notes: The changes to Outlaw in Curse of Ula'tek are intended to
    improve talent build diversity and flexibility. We've increased the power of some
    underperforming talents and pulled back some that could feel "locked in". Killing
    Spree's damage has been increased significantly because the damage it did wasn't
    sufficiently stronger than using other abilities during its channel would have been.
    The talent should now increase your overall damage about as much as other comparable
    talents.</em>

- **Class**
  
  
  - [[spell:381623]] is now a choice talent – Players may now choose between the
            existing version, which casts automatically at low Energy in addition to being
            usable actively, and a new version that must be cast actively.
  - Atrophic Poison now reduces damage dealt by 4% (was 3%).
  - Atrophic Poison duration increased to 60 seconds (was 10 seconds).
            Duration remains unchanged in PvP combat.

- **Hero Talents**
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound: Deal Fate now has a 60% chance to grant an extra
          combo point when you Seal Fate (was 100%).

- **Outlaw**
  
  
  - [[spell:51690]] has been updated – Duration no longer increases
            from spending combo points beyond your maximum. Each combo point spent beyond
            your maximum increases damage by 15%.
  - [[spell:13750]] now speeds up the execution of [[spell:51690]]
            by 20%, the same rate it increases the speed of your other attacks.
  - [[spell:51690]] prefers targets that are not immune to damage or taking
            less than 5% physical damage.
  - [[spell:51690]] damage increased by 60%. Does not affect PvP combat.
  - [[spell:51690]] shots have a higher chance to target your selected
            target if they're valid.
              
    
    - <em>Developers’ notes: Much of [[spell:51690]]’s value is the
                combo points it generates, so when players can spend more combo points on
                [[spell:51690]] than their maximum, such as through [[spell:470347]],
                the value of those extra points is diminished. [[spell:51690]]’s duration
                now maxes out at the time required to generate maximum combo points, and any
                extra combo points spent increase the damage of the ability by a proportional
                amount.</em>
  - [[spell:235484]] has been updated – Causes [[spell:315341]]
            critical strikes to deal 2.5 times normal damage (was 3 times).
  - [[spell:1259480]] has been updated – Now reduces the cooldown of
            [[spell:315341]] by 8 seconds (was 5 seconds) and increases the
            damage bonus from each [[spell:315341]] stack by 1%.
  - All damage increased by 9%. Does not affect PvP combat.
  - [[spell:381885]] increases the damage of attacks that generate
            combo points by 15%/30% (was 10%/20%).
  - [[spell:1259485]] value per stack reduced to 2% (was 3%).
              
    
    - <em>Developers' notes: We don't want players to feel obligated to
                use off-hand daggers to maximize the value of this talent. [[spell:1259485]]
                now has a 30% chance to not proc if triggered by a weapon with 1.8 Speed,
                giving it the same proc rate when attacking with daggers vs. other one-handed
                weapons.</em>
  - [[spell:381845]] now also increases [[spell:8676]] damage by 80%.
  - [[spell:383281]]'s chance for [[spell:8676]] to grant
            [[spell:279876]] increased to 100% of the chance for [[spell:1752]]
            to grant [[spell:279876]] (was 80%).
  - [[spell:383281]] also reduces [[spell:8676]]'s Energy cost by 5.
              
    
    - <em>Developers’ notes: [[spell:381845]] and [[spell:383281]]
                are not as strong as other talent options, so we’re adding some effects to
                them to make them more competitive.</em>
  - [[spell:381990]] increases [[spell:2098]] damage by 15%/30%
            (was 10%/20%).
  - New connectors have been added in the talent tree between [[spell:14161]]
            and [[spell:1259457]], and between the Flickering Steel choice
            node and [[spell:193358]].

:::

### Midnight   Changes Overview

The Midnight Launch has finally arrived, and there are a large amount of changes
to Outlaw Rogue, both for the Spec itself as well as changes to the Rogue
class in general. Many of these changes have already been applied with the
Pre-Patch prior to the expansion's launch, but we have listed the entire set of changes
here for returning players, and to ensure you know exactly what awaits you when you explore
Midnight on your Outlaw Rogue.

The main goal behind these changes is to strengthen the
identity of the two Hero Talent trees, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound,
and changing rotational gameplay flow by making Energy a more impactful resource again.
[[spell:315508]] received a full overhaul, so make sure to check out how it works now!

2.4.

#### Hero Talent Changes

The rolling of coins as Fatebound is now a lot more consistent, and no longer requires Vanish or the now removed
[[spell:382245]] to consistently hit the capstone buff. It also gained some
additional resource generation, which will help with Outlaw's lowered
Energy generation on all its passives, to make the spec still feel fluid and smooth
unless you get really bad procs. As a whole, these changes improves the
usability of Fatebound in all cases, giving it a more reliable benefit to our
damage profile, while still retaining its core identity of flipping coins.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster has seen very few changes, other than the addition of the three new talents
that every Hero Talent Tree gained. It continues to be a bit of a wonky option, although most of the
bugs that have plagued Trickster during The War Within have thankfully been ironed out. It still focuses
heavily on the [[spell:441146]] triggers and its capstone Coup de Grace, granting some additional
damage and CP that can help improve your rotational flow.

That being said, it trails behind Fatebound quite dramatically in every content.

2.5.

#### Apex Talent: Gravedigger

[[spell:1265861]] is our Apex Talent in Midnight, and it provides a few damage increases,
while also generating additional resources for more cooldown reduction. While not particularly
flashy, it smooths out our gameplay and fits well thematically.

Depending on the amount of points invested into the talent, you will gain the following
bonuses:

- [[spell:1265861]]: Your BtE has a chance to apply its damage amp effect twice.
- [[spell:1265862]]: When spending 5+ CP on [[spell:2098]], you deal bonus damage.
- [[spell:1265863]]: When casting Dispatch, you have a chance based on CP spent to hide a bullet
      up your sleeve. Once you get to 6 stacks of the buffs, you can unleash a BtE free of cost, with
      a 6 CP refund.

These bonuses all add more damage to our kit, and getting the occasional free BtE and more
damage amp stacks is a nice boost to our already high sustained DPS.

2.6.

#### Rotational Aspects

The Outlaw and Rogue changes in Midnight are far reaching, impacting a lot of
  our toolkit and rotational design. That being said, our gameplay loop the spec
  is built on still remains — and the spec has a clearer focus. Unfortunately, some
  of our best defensive and utility spells were removed or nerfed, like [[spell:354897]] and
  [[spell:256188]], and the addition of a cooldown to [[spell:1833]]
  will give us less stops to disrupt enemies as well.

2.6.1.

##### Roll the Bones

By far the biggest change to our rotation is the redesign of [[spell:315508]].
  It is much more consistent now, and when using RtB, you will gain a certain stage:

- **Stage 1**  
  
    Sinister Strike has a 20% increased chance to strike twice and grant Opportunity.
- **Stage 2**  
  
    Sinister Strike and Ambush generate 1 additional combo points and deal 15% increased damage.
- **Stage 3**  
  
    Restless Blades cooldown reduction increased by 30%.
- **Stage 4**  
  
    Critical strike chance increased by 10%.

Depending on which stage you enter, you will also receive all the buffs of the
previous stages. For example, if you gain Stage 3, you will not only gain the cooldown reduction
increase from Restless Blades, but also gain the bonuses to Sinister Strike and Ambush
from Stages 1 and 2.

This serves to normalize the rotational flow quite a bit, by moving most of the power
into the first two stages, which you can get the most often, while the rarer outcomes
do not offer as many benefits that feel required for rotational fluidity, yet still
offer nice bonuses you want to gain.

The current odds of receiving the buffs **seem** to be 55% chance to gain Stage 1,
30% chance to gain Stage 2, 10% chance to gain Stage 3, and a 5% chance to gain Stage 4.

2.6.2.

##### Between the Eyes

A lot of focus for Outlaw players in Midnight lies in [[spell:315341]],
which functions similarly to Guardian Druid's [[spell:192081]], in that it provides a buff
that increases your damage dealt, and each buff has its own duration and can stack
with itself. You will often maintain multiple stacks of this buff, especially when
the procs hit just right and you get its cooldown reset, and there might be some
interesting min-max opportunities when you get particularly lucky with your procs.

2.6.3.

##### Energy Generation

Our Energy generation has been lowered across the board, which in turn makes
[[spell:271877]] feel like a mandatory talent that helps in situations where
you do not get many procs or start running low on Energy.

With most of our rotational flow being improved by the Stage 1 and 2 buffs,
it is rare for us to not consistently get Sinister Strike procs that are key
to a smooth and fast-paced rotation, and while the changes may look like
Outlaw could play a lot slower and more clunky, initial experiences on Alpha
have not proven to support this concern.

2.6.4.

##### Cooldown Adjustments

[[spell:13750]] is no longer expected to have close to 100% uptime,
with it being closer to ~30-35% in the current Alpha build. Uptime on at least Stage 2
is closer to 75-80%, and the new Apex Talents also help in softening the gameplay
moments where you do not have AR up, only have the first stage of the RtB buffs, and
get unlucky with your SS and Opportunity procs.

[[spell:1856]], and by extension Stealth, are no longer a major benefit to our DPS,
and many of the stealth-related benefits it provided through certain Talents like [[spell:424044]]
or [[spell:423703]] have instead been rolled into the abilities themselves or new
talents that work without any stealth requirement.

[[spell:271877]] is a core part of the Outlaw gameplay now,
with its Energy recharge being a key component in softening the blow from bad RNG
during your rotational play, as well as a Tier set that is designed around
the ability.

[[spell:196937]] and [[spell:382245]] have also been removed, lowering
the amount of buttons needed to optimally play Outlaw and improving accessibility
without simplifying the spec too much.

3.

### Basics of Outlaw Rogue Gameplay

Outlaw Rogue is a spec that is heavily centered around the maintenance of
its buffs and cooldowns, for example, the decision to either re-roll [[spell:315508]]
whenever it comes off cooldown or sticking with the current buff(s) you have, as
well as the management of many different cooldowns, with some taking priority over
others.

Playing around **Roll the Bones** will quickly become second nature as you
watch out for not wasting any of your resources or sitting on cooldowns for too
long. Most of your cooldowns do not have a static cooldown-timer, since
[[spell:79096]] will constantly lower all your cooldowns whenever
you spend Combo Points. Utilizing this cooldown reduction is key to
playing Outlaw Rogue efficiently. We can further break things down into 
these three main concepts.

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_helmet_66.jpg>) **CD-Arrrr**  
  
    Cooldown Reduction (CDR) is the name of the game for Outlaw Rogues. Many of your offensive skills
    have a cooldown, but spending Combo Points lets you reduce the cooldown of those abilities
    thanks to [[spell:79096]]. This leads to a smooth flowing rotation where you
    juggle many different abilities for incredibly high sustained damage, as even your
    longest cooldowns will be available for use again in no time.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_pistolshot.jpg>) **Opportunity Procs**  
  
  [[spell:279876]] is a key aspect for Outlaw Rogues. Every cast of your melee builders
    (abilities that generate CP) has a chance to grant you a stack of this buff. You can consume
    these for empowered [[spell:185763]] casts, which greatly increases your ability to generate
    Combo Points. While you may encounter the occasional proc dry-streak, this is part of the Outlaw
    experience, and there is a natural ebb and flow to your rotation as a result.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_shadowworddominate.jpg>) **Reactive Gameplay**  
  
    Between [[spell:279876]] procs and your [[spell:79096]] CDR, you will have
    to keep a close eye on your abilities and resources at all times. It is easy to overcap
    on Opportunity Charges, Combo Points, or accidentally use another finisher while a
    cooldown was already available again, and that is part of the learning curve for this spec.
    With a naturally low Global Cooldown, you won't have much time to assess every ability cast
    correctly, which makes it all the more rewarding when you become more comfortable playing the spec.

4.

### How to Gear Up as a Outlaw Rogue

While we always recommend simming yourself for ideal results, we do provide a
dedicated Outlaw gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Season 2 launch and the most recent gear nerfs and changes.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **25 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Changed Ring enchant to only recommend Eyes of the Eagle.
- **25 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated Trickster M+ build with Sleight of Hand.
- **25 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated Trickster M+ build with Sleight of Hand.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **31 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated Trinket recommendations.
- **31 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated Opener info for Preparation, and Delay on Gravedigger CD refresh.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Updated for Midnight.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Midnight.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Updated for Midnight.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Midnight.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Updated for Midnight.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for Midnight.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Updated for Midnight.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Midnight.
- **26 Feb. 2026 (this page):** Updated for Midnight.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 (this page):** Page updated for Patch 11.2.7, listing all major content updates.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated info for Patch 11.2.5, added Puzzling Cartel Chip section, removed DISC Belt section.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 (this page):** Page updated for Patch 11.2.5 and Legion Remix.
- **06 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page updated with minor simplified rotation changes.
- **06 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page updated to be written with Tier-Set in mind.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Page was reviewed for Patch 11.2 and no changes were required.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2 and TWW Season 3. Added all new BiS lists. Removed information regarding Cyrce's Circlet and the Puzzling Cartel Chips. Added information for Reshii Wraps.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.2 and no changes were required.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2. Removed Corruption section.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.2 and no changes were required.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page updated for Patch 11.2 and Season 3, with weekly and high key build recommendations.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Pages updated for Patch 11.2, added tags for Talent recommendations with and without the new Tier set.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page updated for Patch 11.2, added new talent builds and updated the Hero Talent information.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Patch updated for Patch 11.2. Updated Killing Spree information.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 11.2, added No-Tier-Set disclaimer.
- **04 Aug. 2025 (this page):** Updated information for Patch 11.2.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Added information for DISC belt for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Added information for Combat Assist feature.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Added information for Combat Assist feature.
- **15 Jun. 2025 (this page):** Added information for Patch 11.1.7.
- **20 May 2025 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated Horrific Vision Enchant section to recommend Echoing Void.
- **09 May 2025 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Switched to Trickster Mythic+ build recommendation.
- **09 May 2025 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Switched recommendations of Mythic+ builds.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.5, added Puzzling Cartel Chip suggestions.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Added information for Horrific Visions enchants, reviewed page for 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 (this page):** Added information for Patch 11.1.5.
- **17 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Updated with additional tips, Gallywix info, and Mythic tips for a few bosses.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 (this page):** Page has been reviewed and updated for TWW Patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Cyrce's Circlet buffs.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Cyrce's Circlet information added for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Guide has been reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Guide has been reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Slightly updated Gem description.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Guide has been reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** Added a variety of regular and Mythic difficulty tips.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated for Path 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated Rotational and RtB priorities for The War Within Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Talent builds updated for The War Within Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Updated for The War Within Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Added class changes for Patch 11.0.5.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for TWW Season 1 with BiS Gear and Embellishments.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated for the start of Season 1 of The War Within.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for Season 1, removed pre-season build.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **24 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Added Delve Talent Build.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/outlaw-rogue-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/outlaw-rogue-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/outlaw-rogue-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 (this page):** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page has been reviewed and updated for Patch 10.2.6.
- **21 Mar. 2024 (this page):** Page has been reviewed and updated for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Page has been reviewed and updated for Patch 10.2.5.
- **14 Dec. 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Fixed BiS list for M+ gear.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 (this page):** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Added BiS Lists for 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** New layout for talents, added KIR M+ build.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **08 Aug. 2023 (this page):** Updated for class tuning from August 8th.
- **16 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated RtB priorities.
- **16 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for KiR being the stronger ST build now.
- **16 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated RtB prio for HO build.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Added Dawn of the Infinite section, removed Cataclysm Timewalking section, updated Annulet section for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated Onyx Annulet paragraph to no longer recommend farming it after 10.1.5 Annulet nerfs.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Added BF conditional while GM is active.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Patch 10.1.5, added BF conditional to rotation while GM is active.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5, updated most recent changes to the class and guide.
- **06 Jun. 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated Embellishment info.
- **06 Jun. 2023 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Added Belt Clasp and Lambent Armor Kit as alternative Leg Enchant. Added Corrupting Rage Phial discussion.
- **06 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated KIR recommendation as viable alternative to HO builds.
- **06 Jun. 2023 (this page):** Updated for most recent TC findings.
- **24 May 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Added Timewalking info.
- **14 May 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated trinket recommendations.
- **07 May 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated Embellishment recommendations for recent hotfixes.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Page fully updated for Patch 10.1. Added Flightstone and Crest information, added Season 2 BiS items and recommendations, BiS embellishments and more.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Page reviewed for Patch 10.1. Updated Onyx Annulet recommendations.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Patch 10.1 did not change the stat priority.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated tips and tricks for Patch 10.1 Affix changes.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** No rotational changes are required for Patch 10.1. Added Rotation Quick Guide.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1. The recommended build and talent tree remain the same, and the page required no updates.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** No changes were required to this page for 10.1, as no spell changes happened, besides numerical ones.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Patch 10.1. Simplified rotational priorities and talent build.
- **01 May 2023 (this page):** Updated for Patch 10.1 release. Added sections for recent and pending updates to the guide.
- **29 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Patch 10.1 required no changes to this page.
- **26 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated Primordial Gem recommendations for latest hotfixes.
- **26 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Added Talent calculator link for KIR build.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/outlaw-rogue-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Updated for Patch 10.0.5 changes.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Updated for Patch 10.0.5 changes.
- **18 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated rotational priorities for HO build and RtB priority.
- **18 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Clarified rotational priorities, updated recommended talent build.
- **05 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Updated Talent trees.
- **04 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated with raid trinkets and BiS list disclaimer.
- **04 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated stat prio and Fortune Cookie food buff.
- **04 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Added HO disclaimer for Haste.
- **04 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated talent build recommendation.
- **04 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated HO build pathing/suggestions and added KiR build alternatives.
- **04 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated information on rotational priorities, RtB buffs and talent build.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/outlaw-rogue-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/outlaw-rogue-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/outlaw-rogue-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **23 Jun. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-2-changes-analysis>)):** Page reviewed for Patch 9.2.5.
- **03 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-2-changes-analysis>)):** Updated to build 42174.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **02 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-1-changes-analysis>)):** Added 9.1.5 changes.
- **28 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-1-changes-analysis>)):** Page added.
- **28 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-ny-alotha-raid-guide>)):** Updated talent and azerite recommendations.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **11 Dec. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-the-eternal-palace-raid-guide>)):** Updated tips for all bosses.
- **15 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for all bosses.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **08 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-crucible-of-storms-raid-guide>)):** Added further boss tips.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **23 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** Minor updates.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added Outlaw Rogue advice for Battle of Dazar'alor.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-uldir-raid-guide>)):** Added boss spec-specific tips.
- **13 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-uldir-raid-guide>)):** Page added (placeholder for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Outlaw Rogue leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Rogue leveling guide](<https://www.icy-veins.com/wow/rogue-leveling-guide>).

1.

### Outlaw Rogue Leveling Guide for Midnight

Unfortunately, Rogue has often been cited as the single worst class to level
in World of Warcraft. Fret not, however, as it is still more than capable of
dealing with the leveling journey just fine, even if it will take you a
little longer than your friends who may have chosen a different class than you.
Once you hit max-level, you will surpass them in no time and be thankful you
spent the time to pick Rogue!

One of the biggest strengths of Rogue during leveling is its ability to simply
sneak past many nuisances. With clever use of [[spell:2094]], [[spell:1856]],
[[spell:6770]] and other CC abilities, you can often loot important quest items
and then simply Vanish to disappear without having to kill a single enemy.

Whenever your [[spell:5277]] is off cooldown, it is worth pulling many mobs
simultaneously and simply avoiding all damage they deal. [[spell:185311]] has
a low cooldown, so make sure to use it and the new [[spell:1231418]] spell to heal up
between pulls. Dungeons are a solid choice to level as well, once you get access to [[spell:13877]],
as it will allow you to contribute good AoE damage at all stages of the leveling
journey.

As you level up, some of your abilities will be replaced with spec-specific
ones, i.e., at Level 22, [[spell:196819]] will be replaced with [[spell:2098]].
At other times, new abilities will join your rotational priority list. Some of
these you will learn automatically as you level, others you will talent into.
If you follow the Point-by-Level path of our Talent Calculator, this guide will
immediately tell you how to use these new abilities efficiently.

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level but two secondary stats on it
instead of one.

When using Heirloom items, we recommend using those with Critical Strike
and Haste, as they will slightly improve the gameplay flow while leveling.

1.2.

#### Useful Leveling Consumables for Midnight

With the full launch of the [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), it will
once again be time for players to level up to the new maximum of 90. This means
that many will want to get as far along as possible, as fast as possible. To that
end, there are a number of <em>optional</em> consumables that can be gathered
to speed things along. There is no need to go overboard on hoarding too
many, as you will only need to level each character once.

To be as prepared as possible, look to acquire at least some of the following
items and enchants.

- [[item:191348]] — This is a tradeable consumable from the [Dragonflight](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  expansion that increases your speed stat for 30 minutes, which will also persist
  through death. Leveling is frequently about traveling quickly rather than defeating enemies any faster.
- [[item:225592]] — A food item from [The War Within](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>),
  this tradeable dish similarly grants a massive bonus to movement speed for an hour,
  but is lost on death.
- [[item:132516]] — One of the more unusual consumables, this tradeable item from
  Legion Engineering (thanks to [Engineering](<https://www.icy-veins.com/wow/professions-engineering>)) allows you to move faster than ground
  mount speed for a long duration and even enables movement over water, but breaks upon
  taking damage and cannot be activated while in combat. If in an area where you
  cannot mount, consider it your fastest movement tool.
- [[item:154168]]/[[item:154169]] — Though
  it is rare to need them, these two tradeable consumables from Battle for Azeroth can
  be paired together to grant you underwater breathing and greatly increased swim
  speed that is faster than an aquatic mount.
- [[item:109076]] — Although you are taking much less fall
  damage than most other classes, and can avoid it entirely as long as you have something
  to [[spell:36554]] to before crashing to the ground, this consumable allows you to also
  travel through the air from great heights if you are unable to mount, and at great speeds. You
  can even consider pairing one with a [[item:122124]] or [[item:104299]]!

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you, that sets you up for your next 10 levels. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

Keep in mind that the below talent tree is specifically designed for leveling, and
differs quite a bit from any max-level tree. Make sure to check out our talent section
once you've hit max level, to swap to a proper endgame build!

:::talents Outlaw Level 80 Midnight Leveling
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgBwMzgZbmZmxYmZbxMzMLTbD2mBAAAAAM2mZmZmZGGGzsMAAAAmBAMmFAMwgFahNGgZGYgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgxCYmZwsNzMzYMzstYmZmlptBbzAAAAAAGbzMzMzMDziZmZZAAAAMDAYMLGGYgZhFahNGgZGYwM"
}
```
:::

:::details 来源计算器编码
```
#EE-MphLGPAk+g8yOFVORN+MC0aDG2llVFXX3GB-hNZAVQ4MM69oYw811BVh1q6aaaZ02GH-AAAA-bYWCUYIAARBxhB-
```

:::

**等级 20 起：**2.1.

#### **等级 20 起：**War Mode Talents for Leveling

**等级 20 起：**In this section, we will rank the PvP talents best for
leveling and doing solo / small group PvE content. Below is a ranking of both
General PvP Talents and Outlaw Rogue-specific PvE talents.

1. [[spell:269513]] is the only proper damaging talent here, boosting the damage
   of Dispatch a little, at the cost of an extended animation. It does look really cool though!
2. [[spell:209752]] makes [[spell:315341]] increase the
   movement speed of all friendly players within 10 yards by 30% for 5 seconds.
   Movement speed is always nice while leveling, so this is highly recommended. [[spell:197000]]
   can work if you don't ever party up with others, but is only worth if you feel like you're
   getting to your next target fast enough already.
3. [[spell:354425]] adds a bit of extra healing to Crimson Vial.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–1：**Starting at Level 1, you only have one main attack
ability: [[spell:1752]].

1. Cast [[spell:196819]] once you have 4+ Combo Points to spend them.
2. Use [[spell:1752]] to build up Combo Points.

1. **等级 7 起：**Cast [[spell:8676]] when you can open from
   [[spell:1784]], or whenever the ability to cast it is granted to you in some other way.
2. **等级 13 起：**Use [[spell:13750]] on cooldown. Ideally,
   you want to try and pull multiple enemies when it is up so that you
   do not waste its uptime on running between enemies.
3. **等级 13 起：**When fighting more than one enemy, use
   [[spell:13877]]. Try to always hit the highest health target with your abilities
   while it is active.
4. **等级 19 起：**Cast [[spell:315508]] whenever it is off
   cooldown.
5. **等级 9 起：**Cast [[spell:315496]] to spend your Combo
   Points and maintain the buff by casting your other finishers. Only refresh it
   manually if it has fallen off.
6. **等级 17 起：**Use [[spell:315341]] on cooldown with 6+ Combo Points.
7. **等级 10–21：**Cast [[spell:196819]] to spend excess Combo
   Points.
8. **等级 22 起：**Cast [[spell:2098]] at 5+ Combo Points.
9. **等级 12 起：**Cast [[spell:185763]] when you get an
   [[spell:279876]] proc.
10. **等级 10 起：**Cast [[spell:1752]] unless you have 4+
    Combo Points.

3.1.

#### Defensive Abilities

Outlaw Rogues have a few tools at their disposal that make fighting
multiple enemies easier or that allow you to avoid debilitating effects.

- **等级 6 起：**[[spell:1766]] allows you to interrupt an enemy
  that is casting a spell. Use this frequently to avoid the damage you would
  otherwise be taking if the spell cast finishes.
- **等级 8 起：**[[spell:185311]] lets you heal 20% of your
  max Health over 4 seconds. Use this whenever you need the healing or when you are between
  pulls.
- **等级 11 起：**[[spell:6770]] lets you control any Humanoid,
  Beast, Demon, or Dragon for up to 60 seconds. Use this to keep a single enemy
  from joining the fight before you open on a group of enemies from stealth. This
  crowd control breaks when the enemy takes damage. Try to avoid hitting it with
  any of your abilities that hit multiple targets, or it will join the fight.
- **等级 13 起：**[[spell:408]] can be used to stun a single
  opponent for up to 6 seconds. Use this to interrupt a dangerous cast or
  simply
  not take damage from an enemy. Some NPCs might be immune to stuns.
- **等级 34 起：**[[spell:5277]] increases your chance to
  dodge incoming melee and ranged attacks by 100% for 10 seconds. Use this
  whenever it is available to you while you are fighting multiple enemies. You can
  only dodge enemy attacks when facing them.
- **等级 16 起：**[[spell:195457]] is a very powerful movement
  ability. This can sometimes allow you to traverse to a higher elevation or can
  be used to completely negate fall damage, saving you valuable time while
  leveling.
- **等级 23 起：**[[spell:1856]] removes you from sight. This
  essentially resets all enemies you are in combat with. If you happen to be
  close to death and you do not feel that using any other defensive or offensive
  ability might let you finish off all the enemies you are engaged with, use
  **Vanish** to survive.
- **等级 10 起：**[[spell:2094]] allows you to control an enemy
  for up to 60 seconds. This can be used from stealth or outside of it. The
  crowd-control effect breaks when the target takes damage, so make sure not to
  hit it with any of your AoE abilities or use **Blind** when the enemy
  is afflicted with one of your damage over time effects.
- **等级 24 起：**[[spell:31224]] removes and makes you
  immune to magical effects for 5 seconds. This allows you to potentially remove
  damage over time effects that could break your [[spell:1784]], allow you to
  take less damage, or simply avoid certain crowd control or damaging effects.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Page was reviewed for Patch 11.2 and no changes were required.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Guide has been reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **05 Jan. 2023:** Updated Talent trees.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Outlaw Rogue in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics for Outlaw Rogue in Midnight

If you are new to the class or spec, it is best advised to start
with a straightforward build to get a better handle on the core
mechanics and interactions. This build is only marginally worse
than the most optimal way to play the spec, so there is no need to worry at all
about potentially lagging behind fellow Rogue players while you get to know
the foundations of Outlaw. Below are some of the core concepts behind the spec.

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_helmet_66.jpg>) **CD-Arrrr**  
  
    Cooldown Reduction (CDR) is the name of the game for Outlaw Rogues. Many of your offensive skills
    have a cooldown, but spending Combo Points lets you reduce the cooldown of those abilities
    thanks to [[spell:79096]]. This leads to a smooth flowing rotation where you
    juggle many different abilities for incredibly high sustained damage, as even your
    longest cooldowns will be available for use again in no time.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_pistolshot.jpg>) **Opportunity Procs**  
  
  [[spell:279876]] is a key aspect for Outlaw Rogues. Every cast of your melee builders
    (abilities that generate CP) has a chance to grant you a stack of this buff. You can consume
    these for empowered [[spell:185763]] casts, which greatly increases your ability to generate
    Combo Points. While you may encounter the occasional proc dry-streak, this is part of the Outlaw
    experience, and there is a natural ebb and flow to your rotation as a result.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_shadowworddominate.jpg>) **Reactive Gameplay**  
  
    Between [[spell:279876]] procs and your [[spell:79096]] CDR, you will have
    to keep a close eye on your abilities and resources at all times. It is easy to overcap
    on Opportunity Charges, Combo Points, or accidentally use another finisher while a
    cooldown was already available again, and that is part of the learning curve for this spec.
    With a naturally low Global Cooldown, you won't have much time to assess every ability cast
    correctly, which makes it all the more rewarding when you become more comfortable playing the spec.

In summary, Outlaw is a specialization that revolves around the management of several
personal buffs and cooldowns. You will use generator abilities to build Combo
Points, and then spend them to unleash powerful and bursty finishers. On this page
of our Outlaw Guide we will be focusing on a setup that minimizes the number of buttons
and reactivity necessary, without unduly compromising overall damage output.

2.

### Beginner's Guide to Outlaw Rogue in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound   Single-Target Talents

2.1.

#### Beginner Single-Target Talents for Outlaw Rogue

This build is a good beginner choice for single-target, and is the premier build even
at the highest level of play. There is no easy-to-learn build anymore, due to some changes
for Patch 12.1 which forced ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound into playing [[spell:51690]] as well.

Fret not, however, as Outlaw is quite easy to pick up, even though you likely will make
some rotational mistakes as you start familiarizing yourself with the spec. That is to be expected
though, and mistakes don't get punished that hard, so keep at it even if you feel like you're
regularly overcapping on resources or wasting important cooldown times. It'll get better quickly!

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents Fatebound Raid Build
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JeowUV1tM6KZaiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound   Multi-Target Talents

2.2.

#### Beginner AoE, Delve, and Mythic+ Talents for Outlaw Rogue

This is our recommended build for cleave raid fights, [Delve](<https://www.icy-veins.com/wow/delves-guide>), and Mythic+ scenarios.
It plays ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster and is also the premiere build at the highest levels of play.
You may struggle a little at first, as Outlaw is a very fast-paced and reactive spec,
but once you've gotten the groove of things, you'll be putting out some incredible
sustained DPS and can jump straight into higher level keys, where you will still be
playing this exact same build!

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents Fatebound Raid Build
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### Outlaw Rogue   Basic Rotation

2.3.

#### Beginner Outlaw Rogue DPS Rotation

This is a very basic priority list, and some of the finer
details to get the most damage out of the spec are missing. By following the
link, you will be able to find a more detailed version of
this priority list for both single-target and AoE, as well as a deeper
explanation of some of the core concepts of Outlaw gameplay.

:::details FAQWhich Race is the Best for Outlaw Rogue?
The DPS differences between the races are fairly minimal. The best races for
DPS on Horde are Tauren, Highmountain Tauren, and Blood Elf. For Alliance Dwarf,
Void Elf, and Human are the best.

:::

Are you trying Outlaw for the first time? Here is a short list of all the meaningful
rotational priorities. You will want to have [[spell:315584]]
and your non-lethal poison of choice active at all times.

- Use [[spell:315508]] when it is not active or you are only in Stage 1.
- Use [[spell:13750]], [[spell:51690]], and
  [[spell:271877]] on cooldown. Use [[spell:1277933]] to refresh their CD.
- Use [[spell:1752]] as your main builde, and [[spell:185763]] when
  you have an [[spell:279876]] proc.
- Use [[spell:13877]] whenever there is more than 1 target to hit.
- Cast [[spell:315341]] on cooldown with 6+ CP.
- Use [[spell:2098]] as your main finisher with 6+ CP (5+ as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound).
- Use [[spell:381989]] when you are at Stage 2 or higher. Use [[spell:315508]]
  immediately after.

One important rotational aspect is to always use [[spell:51690]] when [[spell:470347]]
is active, which happens after using [[spell:13750]]. You always get two uses of it,
so make sure to use one of them with KS, and one of them with BTE.

2.3.1.

##### Apex Talent: ![Gravedigger Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_112_rogue_betweentheeyes.jpg>) Gravedigger

[[spell:1265861]] is our Apex Talent in Midnight, and it provides a few damage increases,
while also generating additional resources for more cooldown reduction. While not particularly
flashy, it smooths out our gameplay and fits well thematically.

2.3.2.

##### Season 2 Tier Set

The Midnight Season 2 Tier Set, [[spell:1296588]] and
[[spell:1296589]], has no effect on our rotation whatsoever. It simply boosts
our damage output, so there is no changes in gameplay once you acquire it.

### Outlaw Rogue   Defensive Spells

2.4.

#### Defensive Spells for Outlaw Rogue

[[spell:1966]] active spell that reduces all area damage taken. This has a
very short cooldown and should be used regularly. The DPS cost is negligible, and
it is a defensive that every other class is jealous of.

[[spell:31224]] is your immunity. It removes most Magic, Curse,
Disease, or Poison debuffs when you press it, which in some cases is not a
good thing. It also makes you immune to all magic effects and damage. Most
raid encounters tend to apply any associated debuffs anyway, but at least you
will simply not take damage.

[[spell:5277]] increases your dodge to over 100%, making you immune to
melee attacks. Rarely useful in raids, but it can save your life in Mythic+ or
overworld content.

[[spell:31230]] saves you from dying once, leaving you at low HP with a
very strong damage mitigation. This has a 6-minute cooldown and makes your
already strong defensive kit even stronger.

[[spell:1856]] is used as a DPS ability in raids, but can save your life
in world content and Mythic+. It makes all enemies lose threat on you, and if
you are the only surviving player, enemy mobs will reset without you dying. It
can also occasionally be used to avoid targeted spell casts if you Vanish
before the enemy finishes casting.

### Outlaw Rogue   Stat Priority

2.5.

#### Stat Priority for Outlaw Rogue

Currently, you will want to prioritize stats as follows.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>).

Item Level

Critical Strike to 40%

Haste to 25%

Versatility

Mastery

Critical Strike is our best stat, up to ~40%. Haste is only
useful in order to hit the 0.8-second GCD during [[spell:13750]], and
you will want to reach somewhere between 25-30% Haste in order to do so. You
will likely want to prioritize Haste and Critical Strike on many pieces,
and take as much Versatility as is unavoidable to get.

### Blizzard   Single-Button Rotation

2.6.

#### Single-Button Assistant for Outlaw Rogue

Sadly the Assisted Combat system is of little use to Outlaw for a multitude of reasons.
By far the biggest issue is the increase of the Global Cooldown. Since the spec relies
quite heavily on reducing its GCD, with our GCD being 0.8 seconds during Adrenaline
Rush (provided we have ~20% Haste), the added delay to the button presses causes
a significant DPS loss by itself. This alone drops its performance by ~25-30%.

On top of this, it also fails to properly use certain high-impact cooldowns
correctly, making it an even bigger DPS loss compared to even the simplified rotation.
As such it is not recommended to use the Combat Assist for Outlaw at this time.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **06 Sep. 2025:** Page updated to be written with Tier-Set in mind.
- **04 Aug. 2025:** Reviewed for Patch 11.2, added No-Tier-Set disclaimer.
- **15 Jun. 2025:** Added information for Combat Assist feature.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed and updated for Patch 10.2.6.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **16 Jul. 2023:** Updated RtB prio for HO build.
- **10 Jul. 2023:** Updated for Patch 10.1.5, added BF conditional to rotation while GM is active.
- **01 May 2023:** Updated for Patch 10.1. Simplified rotational priorities and talent build.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **18 Jan. 2023:** Clarified rotational priorities, updated recommended talent build.
- **04 Jan. 2023:** Updated information on rotational priorities, RtB buffs and talent build.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Outlaw Rogue in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Outlaw Rogue

Outlaw Rogue has to balance the choice between higher DPS and ease-of-play when choosing
their Hero Talents and talent builds. It is also a spec with no major cooldowns that let you
surge ahead on the damage meters, instead providing high sustained DPS with few ups and downs.

Both Hero talent trees support this niche and deepen its strength even further. The spec
has been streamlined to the point where both hero trees play almost the exact same class and spec
talents, and the rotation is almost exactly the same as well, with only small differences to
the CP threshold at which Fatebound casts [[spell:2098]]. This means that the difference
now solely comes down to numerical tuning, and Trickster has the upper hand as of now.

- **Single Target -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster is the better choice here, especially
    on encounters where you occasionally get good value out of your [[spell:13877]] cleave.
    For pure single-target encounters, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound is only slightly behind Trickster,
    but the moment adds spawn into the fight, Trickster gains a bit of a bigger edge. That
    being said, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound is close enough behind that you can play it for thematic
    purposes, if you don't mind losing a few percent of DPS (~5%).
- **AoE -** For AoE and Mythic+, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster has a bigger advantage thanks
    to the additional AoE damage scaling of [[spell:441367]]. This lets it pull ahead
    a bit in large-scale AoE packs or sustained cleave scenarios, which applies to
    quite a few bosses this raid-tier, as well as all Mythic+ or Delve Content.

With this information in hand, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster is the recommended build for
virtually all content. As mentioned previously, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound is a viable option
if you end up disliking the thematic idea or gameplay flow of Trickster, but rotationally
the two specs play almost identical at this point, so there is no longer a major
difference in execution difficulty.

**Quick Start Import Codes:**

:::talents Outlaw Single Target - Trickster
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents Outlaw AoE - Trickster
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents Outlaw Delves - Trickster
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Trickster

Raid and Single-Target

recommended

Mythic+ and Delves

recommended

Fatebound

Raid and Single-Target

Mythic+ and Delves

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster Single-Target Talents

This is our go-to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster single-target and raid build and is the only
recommended choice for higher end progression. It does more damage than Fatebound, roughly
~5%, and plays almost the exact same as the Fatebound version of the build.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster AoE Talents

This is the higher-performing AoE/Dungeon build for Outlaw, playing Trickster. It does
great sustained AoE damage, although it sacrifices a bit of single-target to do so, and sports
a significantly higher ceiling than the equivalent Fatebound build.

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound Single-Target Talents

This is our recommended ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound single-target build for the Midnight, if you
  do not want to play the higher-performing Trickster build for any reason. It sports high
  sustained single-target, at the cost of some AoE. If you are fighting a single high-difficulty
  elite, or want to swap to maximum boss damage, this is the best build you can play as Fatebound.

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound AoE Talents

This is the lower-performing AoE/Dungeon build for Outlaw, playing Fatebound. It does
great sustained AoE damage, although it sacrifices a bit of single-target to do so, and sports
a much lower ceiling than the equivalent Trickster build.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JeowUV1tM6KZaiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBMwGMjRjZDw2ALMAYmZgB"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JeowUV1tM6KZaiUARC-AAAA-YaWMQOcQoEMJgA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBMwGMjRjZDw2ALMAYmZgB"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-Sy0sAIYgc4gQJI-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend you pick the following bonuses, but as you
can freely switch between them at any time, feel free to experiment with other options
yourself if you feel you do not get enough mileage out of the recommended options:

- Node 1:[[spell:1279599]]
- Node 2:[[spell:1279603]]
- Node 3:[[spell:1287555]]
- Node 4:[[spell:1279613]]
- Node 5:[[spell:1279614]]

3.

### Apex Talent: ![Gravedigger Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_112_rogue_betweentheeyes.jpg>) Gravedigger

The new main feature for Midnight are **Apex Talents**, with Outlaw's
**Gravedigger** focusing on additional free-of-charge [[spell:315341]]
casts, as well as more damage bonuses for all your damage from BtE. Up to 4 points can
be spent here. Currently, these are arranged in a 1 ➜ 2 ➜ 1 point investment.

1. [[spell:1265861]]: Grants each of your [[spell:315341]] casts a chance to apply an additional stack of its buff.
2. [[spell:1265862]]: 2-point talent tax node that essentially just adds more damage whenever you cast
     [[spell:2098]].
3. [[spell:1265863]]: Causes you to slowly build up to a free [[spell:315341]] cast that does not incur a cooldown
     or cost any resources.

These Apex talents help smooth out the lows of the rotation by granting a consistent
way to get a free BtE every once in a while, while also granting some more bonus
damage. While not the most inspired or impactful of Apex Talents, this does help out
with the weakness of the spec in some ways.

4.

### Hero Talents

Outlaw gets to pick between two distinct Hero Talent choices:
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound sports a higher consistency in its procs. This alone makes
it a very solid choice for a spec that already boasts incredible high sustained DPS, and
due to it being a little easier to play, many Outlaw players consider Fatebound as their
first choice when starting out.

It does less damage than Trickster though, and is therefore not recommended
once you try your hands at harder content, higher-level Mythic+ keys, or
cutting-edge progression.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster

Historically, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster needed to outperform Fatebound on raw 
numbers by a bit to be worth recommending, due to the additional 
rotational fluidity that Fatebound provides, while Trickster
has more buttons to press and more rotational priorities to keep track off.

Trickster does have another upside, which is that it scales very well
into AoE thanks to [[spell:441367]]. Its capstone also provides
additional damage and automatically spends Combo Points by casting
[[spell:2098]] as if it had consumed 5 additional Combo Points.

This adds a lot of extra cooldown reduction, which can help smooth out
the rotation a bit, while adding an extra layer of complexity and skill
expression to the rotation, which is rewarded with a much higher DPS performance.

5.

### PvP Talents (War Mode)

In any major capitol, there will be the option to go into "War Mode."
Enabling War Mode provides the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended enabling the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of both General PvP Talents
and Outlaw Rogue-specific PvE talents.

1. [[spell:269513]] is the only proper damaging talent here, boosting the damage
   of Dispatch a little, at the cost of an extended animation. It does look really cool though!
2. [[spell:209752]] makes [[spell:315341]] increase the
   movement speed of all friendly players within 10 yards by 30% for 5 seconds.
   Movement speed is always nice while leveling, so this is highly recommended. [[spell:197000]]
   can work if you don't ever party up with others, but is only worth if you feel like you're
   getting to your next target fast enough already.
3. [[spell:354425]] adds a bit of extra healing to Crimson Vial.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **25 Apr. 2026:** Updated Trickster M+ build with Sleight of Hand.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Page updated for Patch 11.2, added new talent builds and updated the Hero Talent information.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **09 May 2025:** Switched recommendations of Mythic+ builds.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Talent builds updated for The War Within Patch 11.0.5.
- **09 Sep. 2024:** Updated for Season 1, removed pre-season build.
- **24 Aug. 2024:** Added Delve Talent Build.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** New layout for talents, added KIR M+ build.
- **16 Jul. 2023:** Updated for KiR being the stronger ST build now.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary.
- **06 Jun. 2023:** Updated KIR recommendation as viable alternative to HO builds.
- **01 May 2023:** Reviewed for Patch 10.1. The recommended build and talent tree remain the same, and the page required no updates.
- **26 Mar. 2023:** Added Talent calculator link for KIR build.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated HO build pathing/suggestions and added KiR build alternatives.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Outlaw Rogue in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Outlaw Rogue Gameplay and Rotation Guide

Welcome to our Rotation page for Outlaw Rogues. Here you
will find out more about your rotational priorities in both single-target
and multi-target situations, which you will apply in both Raiding and Mythic+
scenarios.

Each of the sections below explain the rotation for different environments.
Click the boxes to switch to the desired situation.

1.1.

#### Roll the Bones Rework

After years of [[spell:315508]] working the same, the ability was reworked
for Midnight. It is such an important change, that we felt it necessary to list a summary
of the rework ahead of the rotational priorities. The ability is much more consistent
now, and when using RtB, you will gain a certain stage:

- **Stage 1**  
  
    Sinister Strike has a 20% increased chance to strike twice and grant Opportunity.
- **Stage 2**  
  
    Sinister Strike and Ambush generate 1 additional combo points and deal 15% increased damage.
- **Stage 3**  
  
    Restless Blades cooldown reduction increased by 30%.
- **Stage 4**  
  
    Critical strike chance increased by 10%.

Depending on which stage you enter, you will also receive all the buffs of the
previous stages. For example, if you gain Stage 3, you will not only gain the cooldown reduction
increase from Restless Blades, but also gain the bonuses to Sinister Strike and Ambush
from Stages 1 and 2.

This serves to normalize the rotational flow quite a bit, by moving most of the power
into the first two stages, which you can get the most often, while the rarer outcomes
do not offer as many benefits that feel required for rotational fluidity, yet still
offer nice bonuses you want to gain.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound

Raid Build

Mythic+ Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster

Raid Build

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+ Build

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

### Opener for ST and AoE

[[spell:1784]]

[[spell:315584]]

[[spell:13750]]

[[spell:315508]]

[[spell:315496]]

[[spell:13877]]

[[spell:1752]]

[[spell:271877]]

[[spell:33697]]

[[item:241308]]

[[item:270175]]

[[spell:1752]]

[[spell:315341]]

[[spell:1752]]

[[spell:185763]]

[[spell:271877]]

[[spell:1752]]

[[spell:315341]]

[[spell:1752]]

[[spell:185763]]

[[spell:51690]]

[[spell:1277933]]

[[spell:315341]]

**适用条件：Trickster（启用）。** 1.2.

#### **适用条件：Trickster（启用）。** Trickster Single-Target Opener

**适用条件：Fatebound（启用）。** 1.3.

#### **适用条件：Fatebound（启用）。** Fatebound Single-Target Opener

Your opener is fairly straight-forward, although there is a bit of RNG to it due to potential [[spell:278676]] procs resetting your [[spell:315341]] cooldown. Pay attention to the [[spell:1277933]] note!

1. Always try to open from [[spell:1784]] so you can be closer to the boss on pull, and to have [[spell:315584]] active.
2. Cast [[spell:13750]], [[spell:315508]], and [[spell:315496]] immediately before the pull. SnD will not consume [[spell:470347]]. (If RtB and SnD are already up, do not use them in your opener)
3. Use [[spell:13877]] if there is any cleave opportunity.
4. Open with [[spell:271877]] (if talented) or [[spell:1752]]. Use your DPS potion, racial, and any on-use trinket you might have.
5. Build Combo Points with [[spell:1752]]
6. Use [[spell:315341]] at 6+ CP
7. Build CP with [[spell:1752]] or [[spell:185763]] if you have 3 or more [[spell:381846]] stacks
8. Build CP with [[spell:1752]] or [[spell:185763]] if you have 3 or more FtH stacks
9. Cast [[spell:51690]] at 6+ CP, even if BTE reset its cooldown.
10. Use [[spell:1277933]] if [[spell:315341]] is on cooldown, otherwise build up to and use BTE again until it goes on cooldown.

### Rotation for ST and AoE

**适用条件：Trickster（启用）。** 1.4.

#### **适用条件：Trickster（启用）。** Trickster Single-Target Rotation

**适用条件：Fatebound（启用）。** 1.5.

#### **适用条件：Fatebound（启用）。** Fatebound Single-Target Rotation

This is the general priority list on how to use your abilities. This is NOT a list that should be followed step by step; it simply serves as a good idea of which things to prioritize in your moment-to-moment gameplay, as you will often be faced with multiple choices on which buttons to press. The priority list simply highlights which buttons are more important than others.

1. Your rotational priority is virtually the same in single-target and AoE. The only difference is the usage of [[spell:13877]]. You will want to use BF on cooldown whenever there is a second target in cleave range, but try to use it at low Combo Points to gain the full benefit of [[spell:381878]]. You want to open from stealth with Blade Flurry in AoE
2. Use [[spell:315508]] on cooldown unless you are already in Stage 2 or higher.
3. Use [[spell:381989]] when you are in Stage 3. If your next [[spell:315508]] is unlikely to be used alongside [[spell:256170]], you can KIR at Stage 2 as well.
4. Use [[spell:13750]] on cooldown, at low Combo Points.
5. Use [[spell:271877]] on cooldown as if it were a regular builder (if talented).
6. Cast [[spell:315341]] on cooldown with 6+ CP.
7. Use [[spell:1277933]] to reset the cooldown of your AR, BtE, and Blade Rush.
8. Use [[spell:51690]] on cooldown, at 6+ Combo Points. Always make sure to cast it while
     [[spell:470347]] is active.
9. **适用条件：Fatebound（启用）。** Cast [[spell:2098]] as your main finisher with 5+ CP if no other finishers are available to be used.
10. **适用条件：Trickster（启用）。** Cast [[spell:2098]] as your main finisher with 6+ CP if no other finishers are available to be used.
11. Cast [[spell:185763]] if you have 6 stacks of [[spell:279876]]. If you have 3 stacks,
      use it at 1-3 CPs only.
12. Cast [[spell:1752]] to generate Combo Points.

---

**Note on [[spell:381989]] -** Holding KIR for a Stage 3 RtB may be a theoretical gain, but in practice you can end up not using it for long periods of time if luck is not on your side. You can therefore simply use it at Stage 2+ for more consistency, and less frustrating pulls.

2.

### Midnight Season 2 Tier Set

The Midnight Season 2 Tier Set, [[spell:1296588]] and
[[spell:1296589]], has no effect on our rotation whatsoever. It simply boosts
our damage output, and lets our rotation flow a bit more smoothly.

3.

### Class and Spec Mechanics Explained

To better explain the specific usage and benefits of the Outlaw Rogue
kit, we compiled a more detailed explanation on individual parts of our rotation.
From important rotational mechanics that require attention, to cooldowns
and how to use them, read below to reach your full potential when playing
Outlaw.

### Roll the Bones

3.1.

#### Roll the Bones

After years of [[spell:315508]] working the same, the ability was reworked. It is such an important
change, that we are listing it ahead of the rotational priorities. The ability is much more consistent
now, and when using RtB, you will gain a certain stage:

- **Stage 1**  
  
    Sinister Strike has a 20% increased chance to strike twice and grant Opportunity.
- **Stage 2**  
  
    Sinister Strike and Ambush generate 1 additional combo points and deal 15% increased damage.
- **Stage 3**  
  
    Restless Blades cooldown reduction increased by 30%.
- **Stage 4**  
  
    Critical strike chance increased by 10%.

Depending on which stage you enter, you will also receive all the buffs of the
previous stages. i.e. If you gain Stage 3, you will not only gain the cooldown reduction
increase from Restless Blades, but also gain the bonuses to Sinister Strike and Ambush
from Stages 1 and 2.

This serves to normalize the rotational flow quite a bit, by moving most of the power
into the first two stages, which you can get the most often, while the rarer outcomes
do not offer as many benefits that feel required for rotational fluidity, yet still
offer nice bonuses you want to gain.

The current odds of receiving the buffs **seem** to be 55% chance to gain Stage 1,
30% chance to gain Stage 2, 10% chance to gain Stage 3, and a 5% chance to gain Stage 4.

### Apex Talent

3.2.

#### Apex Talent: Gravedigger

The new main feature for Midnight are **Apex Talents**, with Outlaw's
**Gravedigger** focusing on additional free-of-charge [[spell:315341]]
casts, as well as more damage bonuses for all your damage from BtE. Up to 4 points can
be spent here. Currently, these are arranged in a 1 ➜ 2 ➜ 1 point investment:

1. **[[spell:1265861]]** <em>(1 pt)</em>  
   
     Grants each of your BtE casts a chance to apply an additional stack of its buff.
2. **[[spell:1265862]]** <em>(2 pts)</em>  
   
     2-point talent tax node that essentially just adds more damage whenever you cast
     [[spell:2098]].
3. **[[spell:1265863]]** <em>(1 pt)</em>  
   
     Causes you to slowly build up to a free BtE cast that does not incur a cooldown
     or cost any resources.

There is a slight travel time for the Gravedigger hit, which may delay the refresh of
  the final Gravedigger node. Especially on large bosses, you may end up using [[spell:315341]],
  see the ability go on cooldown, only for it to refresh its cooldown by consuming [[spell:1265863]]
  once it actually hits your target. We recommend tracking the [[spell:1265931]] buff
  with the cooldown manager, so you are aware whenever you have 6 stacks.

These Apex talents help smooth out the lows of the rotation by granting a consistent
way to get a free BtE every once in a while, while also granting some more bonus
damage. While not the most inspired or impactful of Apex Talents, this does help out
with the weakness of the spec in some ways.

### Energy Pooling

3.3.

#### Energy Pooling

It can be very beneficial to "pool" your Energy and Combo Points, which
involves auto-attacking while your Energy regenerates. The advantage this
provides is variable, meaning that pooling does not always result in damage
gained. Situations where pooling Energy and Combo Points is beneficial
include:

- Before an important add spawns, so that you can apply as much instant pressure
  as possible
- An encounter-specific buff or damage phase is imminent

Pooling Energy is not a magical DPS gain by itself. It allows you to
slightly adjust the timing of your abilities so that you fit more attacks
during periods of increased damage, provided you can properly identify when
such periods are going to happen.

### Coup de Grace

3.4.

#### Coup de Grace

When playing the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster Hero Talent tree, you will be playing around
your [[spell:441423]] procs. Coup de Grace enhances your next [[spell:2098]]
by making it much stronger, casting it as if you had used 5 additional CP. These additional CP
count towards our cooldown reduction from Restless Blades, so you will want to use this as soon
as possible.

### Fan the Hammer

3.5.

#### Fan the Hammer

[[spell:381846]] is a talent that dramatically increases your ability to use [[spell:279876]]-buffed
[[spell:185763]]s. It also lets you build multiple stacks of the buff, and consumes 2 stacks of the proc
instead of 1. This means that every Opportunity PS you cast generated 4 Combo Points, and you will want to
pay attention that you do not overcap on stacks at any point. Ideally you also avoid overcapping CP as a result of this,
but it is **more important** to not overcap on stacks, than to not overcap on CP.

4.

### Important Cooldowns for Outlaw Rogue

### [[spell:13750]]

4.1.

#### Adrenaline Rush

[[spell:13750]] increases your Energy Regen, maximum Energy, and
Attack Speed dramatically. It is not uncommon to overcap while it is active,
and you may end up wasting a lot of resources. That is normal.

There is also a hidden effect not mentioned in the tooltip: While AR is
active, your Global Cooldown is reduced by your Haste value, up to a reduction
to 0.8 seconds (down from 1 second baseline).

Reaching enough Haste to benefit from this is almost **always
recommended**, and you will want around 20-30% Haste to do so (accounting
for procs and other Haste sources).

### [[spell:315341]]

4.2.

#### Between the Eyes

[[spell:315341]] is your main finisher to deal damage, and it
increases the damage you deal with all your abilities for each use. Each cast
has its down duration though, so the amount of increased damage will ebb and
flow depending on your procs on CP generation and cooldown reduction. Make
sure to use this ability on cooldown!

### [[spell:381989]]

4.3.

#### Keep It Rolling

[[spell:381989]] extends the duration of your current [[spell:315508]] by 30 seconds,
and is particularly potent when used on a RTB that is in Stage 3 or even 4. You will generally want to use KIR
on cooldown, but if you have a [[spell:256170]] proc ready or it you will soon gain it by casting another
[[spell:13750]], you may want to hold on to Keep It Rolling.

Since Loaded Dice grants you +1 Stage, it is very likely that you will end up with a Stage 3, or possibly 4, RtB,
which you can then immediately extend with Keep It Rolling. Even if you do not end up getting a good RtB roll, use KIR
immediately after, as it has a very high cooldown and you do not want to miss out on one of its uses.

**Theoretically:** It is a minor gain for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster to only use KIR when
in Stage 3. However, while this is a theoretical gain over hundreds of thousands of pulls,
you may end up having much lower lows when you do not hit Stage 3 a single time during a fight,
and you just sit on KIR the entire time. It is therefore not recommended to play around this
rule, unless you are going for a #1 parse.

### [[spell:2094]]

4.4.

#### Blind

[[spell:2094]] is not part of our DPS kit, but still has some interesting use-cases in Mythic+ that may
not be immediately apparent. While [[spell:6770]] allows a player to safely pass a CC-ed creature without getting
into combat, a blinded enemy will walk around confused and still get into combat with the **first** player that
gets close to it. Once the Blind debuff ends, it will engage said player. It will not, however, get into combat
with any other player that gets close to it.

You can still make great use of Blind to pass enemies by abusing the fact that only one player
gets into combat with it. The best and easiest way to do this, is to ensure that after blinding the target, you
get close enough to enter combat with it, and then you and your entire group can pass the enemy. Once you
are far enough away from it, you can safely [[spell:1856]], drop combat, and skip the enemy.

This is particularly useful in situations where an entire pack of enemies is in your way that you would
like to skip, but one or two enemies are too close to pass by without body-pulling them. As a Rogue, you can
[[spell:6770]] one, and then use the above trick for the other, allowing you to skip past enemies that would either
detect you if you were to use [[spell:114018]], or if Shroud is on cooldown.

5.

### Academic Information for Outlaw Rogue

5.1.

#### Combo Points and Energy

As a Rogue, most of your abilities need Energy to be used. Your Energy
bar has a capacity of 100 Energy (200 with [[spell:14983]] chosen as a talent,
and 250 during [[spell:13750]]) and refills at a base rate of
10 Energy per second. Your Energy regeneration is increased by:

- Melee Haste (Haste + Haste-enhancing buffs)
- the [[spell:61329]] passive, which increases your Energy regen by
  25%
- your [[spell:13750]] cooldown, which temporarily increases your
  Energy regeneration by 60%
- [[spell:14983]], if talented

The faster you regenerate Energy, the more finishers you can cast, which
(via [[spell:193359]] and [[spell:79096]]) will result in
higher [[spell:13750]] uptimes.

Letting your Energy reach its maximum is something you want to avoid. You
should always try to spend your Energy by (literally) spamming your buttons.
Unlike Subtlety and Assassination Rogues, Outlaw Rogues generally do not
benefit from Energy pooling. There are many situations when you will generate
more Energy than you can spend (Haste trinket procs, [[spell:2825]] /
[[spell:32182]] / [[spell:80353]], etc.), and you should spam your
buttons even harder than usual during such times.

Combo Point generation is increased by a variety of factors, such as:

- [[spell:279876]] procs when talented into [[spell:196938]]
- [[spell:381620]] or [[spell:381846]], if talented.
- [[spell:1752]] striking twice
- [[spell:315508]] buffs
- your [[spell:14161]] passive ability, which grants your finishers
  a 20% chance per Combo Point consumed to grant a Combo Point
- Energy regeneration, allowing you to cast more generators

You should never waste Combo Points. Never cast a Combo Point-generating
ability when you are at maximum Combo Points. Be aware of situations where you
are guaranteed to generate 2 Combo Points with your generators, for example,
during [[spell:315508]] stage 2, or when using [[spell:185763]] with an Opportunity
proc when talented into [[spell:196938]].

5.2.

#### Adrenaline Rush

[[spell:13750]] increases your Energy regeneration, maximum Energy,
and your attack speed. It should be used on cooldown.
Do not hesitate to stack it with [[spell:2825]], [[spell:32182]], or
[[spell:80353]] as you will still benefit from the increased attack speed,
though you will likely Energy cap (this is not a problem).
[[spell:13750]] has a 3-minute cooldown, but this can be reduced by
[[spell:79096]].

It also reduces your global cooldown based on your Haste value, capped at a
0.8 second GCD.

5.3.

#### Outlaw Cooldown Reduction

[[spell:79096]] reduces the cooldowns of the following abilities by
1 second per Combo Point consumed by a finisher (increased by 30% if you are in Roll the
Bones Stage 3):

- [[spell:13750]]
- [[spell:315341]]
- [[spell:13877]]
- [[spell:271877]]
- [[spell:195457]]
- [[spell:381989]]
- [[spell:51690]]
- [[spell:315508]]
- [[spell:2983]]

5.4.

#### Blade Flurry

It is worth reiterating that the source of [[spell:13877]] cleave
is you, not the target. Therefore, you can stand with one mob in front
and another one behind you, and your [[spell:13877]] will
still hit behind you, even if the mobs are further than 8y apart, as you are
the source of the cleave.

5.5.

#### Defensive Utility

All Rogues come ready-made with a dizzying phalanx of defensive cooldowns,
which make them the best candidate for soaking required mechanics and dealing
with heavy incoming damage.

- [[spell:1966]] reduces AoE damage taken by 40% for 6 seconds for only 35
  Energy. When talented into [[spell:79008]], it also reduces all other
  damage by 20% and grants [[spell:5277]] a 10% damage mitigation. This is one
  of the most overpowered abilities in the game and a huge asset in fights with
  heavy raid damage.
- [[spell:31224]] provides magic immunity for a second, followed
  by 4 seconds where all spells will miss. This spell is mostly used for clearing
  debuffs that might otherwise force you out of melee range. Cloak of Shadows is
  also a fantastic tool for soaking abilities that do not pierce immunities.
- [[spell:31230]] is a talent that allows you to escape lethal damage
  once every 6 minutes. The damage cannot exceed more than twice your maximum
  health. Cheat Death is great for soaking mechanics that pierce
  immunities and damage reductions, as it guarantees your survival. It is also
  great for encounters with bursty damage that might take you by surprise, as you
  get a get-out-of-jail-free card once every 6 minutes.
- [[spell:185311]] provides a respectable amount of healing on a very
  short cooldown. Use this often in boss encounters.
- [[spell:5277]] provides a 100% increased chance to dodge enemy attacks
  as long as you are facing them. This can sometimes be used to avoid physical
  spells as well.

5.6.

#### Poisons

Your **Lethal Poison** should always be [[spell:315584]].

You have two choices for your non-lethal Poison, [[spell:3408]] and either
[[spell:5761]] or [[spell:381637]]. For raiding, you will
generally use **Atrophic Poison** unless your raid wants you to slow a specific group
of targets.

For Mythic+, you will want to use the Poison that best suits your tank or
group's needs. Crippling Poison allows your tank to more easily kite enemies,
whereas Numbing Poison slows their attack speed instead. Atrophic Poison reduces
damage to the group, not just the tank, albeit at significantly lower values, but can be
quite useful when pushing higher level keys where bosses can start one-shotting players.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Updated Opener info for Preparation, and Delay on Gravedigger CD refresh.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **06 Sep. 2025:** Page updated with minor simplified rotation changes.
- **04 Aug. 2025:** Pages updated for Patch 11.2, added tags for Talent recommendations with and without the new Tier set.
- **15 Jun. 2025:** Added information for Combat Assist feature.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated Rotational and RtB priorities for The War Within Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **16 Jul. 2023:** Updated RtB priorities.
- **10 Jul. 2023:** Added BF conditional while GM is active.
- **01 May 2023:** No rotational changes are required for Patch 10.1. Added Rotation Quick Guide.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **18 Jan. 2023:** Updated rotational priorities for HO build and RtB priority.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Outlaw Rogue in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Outlaw Rogue

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Outlaw Rogue. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
You will want to try and prioritize getting the **Shoulder, Chest, Legs, and Gloves** set pieces. However, getting the Helmet to complete one of the bonuses is still better than any other gearing choice. Long-term you will want to play a specific helmet piece from [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) though.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2, you also retain the secondary stats and any other potential passive effects like damage procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear, but if that is not possible, it is not a big deal either. It is better to have the set with slightly suboptimal stats and fix it later into the season, than missing out on the bonus for another week or two. Some optimal stat items to catalyze are:

- Helmet: [[item:271875]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:251223]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Chest: [[item:281236]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Gloves: [[item:251124]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs: We want these from the token.

Technically, only the Gloves and Helmet really need to be catalyzed, the other slots all have decent stats baseline already.

:::

:::details FAQWhat to Get From The Great Vault?
Generally speaking, your goal should be to grab a good weapon, your BIS trinkets, and of course your new tier set 4-pc bonus as quickly as you can. However, there is an alternative strategy that might end up being a bit degenerate, but could pay off if your progression ends up taking a few weeks, or months.

Instead of picking an item from the Great Vault, you can also choose to simply grab a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>). This lets you bonus roll on any dungeon or boss, and receive a 1/6 Myth track version of the item. Doing so on the [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) boss on Heroic would thus guarantee you your BIS Trinket, Weapon, Legs, as well as a mediocre Cloak and a Belt, if you follow this strategy for 5 weeks.

While this may slow down your ilvl progression a bit due to these items needing crests to fully upgrade, it would allow you to get some of your absolute best items way before actually killing the boss on Mythic. Keep in mind that dropped items from Mythic will be at 9/6 Mythic though, whereas bonus-rolled items cap out at 6/6, and that 2 of those 5 items are quite bad for Outlaw due to their high Mastery.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271875@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240914]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:244573@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271509@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268248@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:268240@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244029]]</span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup with farmable gear from Season 2 Mythic+ Dungeons.

This list is by no means a replacement for **simming yourself**. Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
You will want to try and prioritize getting the **Shoulder, Chest, Legs, and Gloves** set pieces. However, getting the Helmet to complete one of the bonuses is still better than any other gearing choice. Long-term you will want to play a specific helmet piece from [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) though.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2, you also retain the secondary stats and any other potential passive effects like damage procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear, but if that is not possible, it is not a big deal either. It is better to have the set with slightly suboptimal stats and fix it later into the season, than missing out on the bonus for another week or two. Some optimal stat items to catalyze are:

- Helmet: [[item:273791]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Shoulders: [[item:251223]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Chest: [[item:251226]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Gloves: [[item:251124]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs: [[item:159313]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)

Technically, only the Gloves and Helmet really need to be catalyzed, the other slots all have decent stats baseline already.

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>), [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>), [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): Drop multiple high-value items.
- **Weapon**: Try to run [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) for a nice off-hand weapon.
- **Trinkets**: [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>) and [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>) drop your best dungeon trinkets, although a handful of raid options tend to be considerably stronger.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:273791@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:273781@JAACAAAOyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Waist</th><td>[[item:244573@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271509@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250259@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Bracers</th><td>[[item:251135@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Trinket</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:193767@JAAKAAQkCYHKvbRLfgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244029]]</span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup, only using gear from the Venomous Abyss Raid.

This list is by no means a replacement for **simming yourself**. Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
You will want to try and prioritize getting the **Shoulder, Chest, Legs, and Gloves** set pieces. However, getting the Helmet to complete one of the bonuses is still better than any other gearing choice. Long-term you will want to play a specific helmet piece from [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) though.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2, you also retain the secondary stats and any other potential passive effects like damage procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear, but if that is not possible, it is not a big deal either. It is better to have the set with slightly suboptimal stats and fix it later into the season, than missing out on the bonus for another week or two. Some optimal stat items to catalyze are:

- Helmet: [[item:271875]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: We want these from the token.
- Chest: [[item:281236]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Gloves: We reluctantly take these from the token.
- Legs: [[item:268225]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) for the ilvl increase (only if Enlightened).

Technically, only the Gloves and Helmet really need to be catalyzed, the other slots all have decent stats baseline already. With this new system, it is highly recommended to grab a few Mythic+ pieces to catalyze for good sub stats, especially on gloves (or craft them).

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:268209]]: Our BiS Mainhand, if you can get it on Myth track. Drops from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).
- [[item:270173]]: Our best trinket. Also drops from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).
- [[item:271875]]: Our only real option for a helmet to catalyze.
- Honorable mention: [[item:268266]] from the Lair Boss [Nymrissa Wavecaller](<https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa>). If you do this as a raid group, you really want the Haste from this ring.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271875@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240914]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:244573@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268248@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a> by <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">Jewelcrafting</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:268240@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268204@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span><span>[[item:244029]]</span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Outlaw Rogue

There are a great number of Trinkets available for Outlaw, and we will always want
  to play a combination of two powerful passive trinkets like [[item:270173]] and [[item:270175]].
  Outlaw has no meaningful burst cooldowns, so playing a on-use trinket is not that powerful
  for us, but the Heart of Ula'tek is simply too strong. The new [[item:281215]]
  from Kith'ix is also a good candidate, especially if you do not have 344 ilvl versions
  of the two Mythic Venomous Abyss trinkets.

There are quite a few other valuable trinkets out there, so make sure to check our
  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Outlaw Rogue Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]] - BIS-candidate</li>&#10;<li>[[item:270173]] - BIS-candidate</li>&#10;<li>&#10;&#10;&#10;[[item:281215]] - <span><em>Click for Details</em></span>&#10;<span>A decent alternative as a passive trinket, especially if you do not have 344&#10;        versions of the 2 above. You'll likely have to sim yourself to see which is better,&#10;        especially in AoE.&#10;       </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164]]</li>&#10;<li>&#10;&#10;&#10;[[item:270165]] - <span><em>Click for Details</em></span>&#10;<span>A decent alternative as a passive trinket, but Gebbos is strictly better even&#10;        with the nerfs that happened prior to the season launch.&#10;       </span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250259]] - <span><em>Click for Details</em></span>&#10;<span>Our best Mythic+ option, but it scales badly in AoE, where raw-stats are typically&#10;        better.&#10;       </span>&#10;</li>&#10;<li>[[item:159617]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:250225]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:158374]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250245]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270168]]</li>&#10;<li>Crafted Trinkets</li>&#10;<li>Delve Trinkets</li>&#10;<li>Any other unlisted trinkets</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Patch 12.1 continues the bonus roll system that was initially introduced in Patch
12.0.7. However, the only way to acquire one, is by not picking a vault option, while
having at least 3 vault slots unlocked. Notably, bonus rolling on a Heroic raid boss
will grant you the item at 1/6 Myth track, so you can acquire some of the later raid gear
quite early, as long as you commit additional crests to upgrade it.

**[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s** can be spent after finishing a dungeon or killing
a raid boss, and will grant you a random from the dungeon's or boss's loot table.
Once an item has been looted through a Voidcore roll, it cannot appear again when you
bonus roll on the same boss or dungeon again.

After 8 weeks, you will also be granted one additional Voidcore for free from
**Orin Straylight** in Silvermoon, next to The Catalyst.

3.1.

#### Recommended Nebulous Voidcore Usage for Outlaw Rogue

Which item you want to chase after depends heavily on the items you have already acquired
  through i.e. the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), or whether you expect to down certain bosses on
  Mythic difficulty to get them on 9/6 Mythic itemlevel.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Mythic [[item:268209]]
2. Mythic [[item:270173]]
3. Remaining BiS List items

:::

3.2.

#### Ascendant Venomstones

Using your [[item:280562]] follows a similar priority list as using your
  Crests. Note that you cannot further upgrade items from Mythic Ulatek and Coiled Altar
  that are already 344, as the new maximum ilvl is 340 for Myth track items, and 338 for
  crafted items.

1. Your Mainhand weapon is the highest priority
2. Your Offhand weapon
3. Your on-use trinket
4. Your passive trinket
5. Your Necklace

You will also want to prioritize Myth track items over Hero track ones, unless
  you do not expect to get a Myth track variant of said item. I.e. it is fine to upgrade a
  Hero track [[item:270175]] or [[item:270168]] if you do not expect to kill
  Mythic Ulatek or bonus roll for a Mythic version anytime soon.

4.

### Best Crafted Items for Outlaw Rogue

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose the exact
secondary stats you want.

As your ability to craft items will be time-gated in the initial stages of
Midnight, we highly recommend getting a **Mainhand weapon** as soon as possible, unless
you can reliably get one elsewhere. Once you have a good weapon, work on your other Embellished
Item next, and then craft whichever pieces you do not have high-item-level versions
of yet.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Outlaw Crafted Gear Priority**
- [[item:237839]] with [[item:245873]] but **only** if you need a Mainhand weapon
- [[item:244569]] with [[item:240167]]
- [[item:244573]] with [[item:240167]]

:::

As for the secondary stats to get on your crafted weapons, it heavily relies on the rest
of your gear. Your two main stat goals are ~40% Critical Strike, and ~25-30% Haste, so if
you haven't reached either of them yet, a Crit/Haste craft is likely going to serve you best.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Outlaw Rogue

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

As there is a lot of competition for Embellishments, you will have to pick
and choose the two strongest ones for your overall DPS output. Most of them provide
very similar DPS benefits, even if the effects are entirely different. The two best
choices for this are:

- For Raid and Mythic+: Getting two [[item:240167]] on crafted items like Belt
  or Boots is your best choice here. If you do not have high ilvl mainhand weapon already, you
  can craft one with [[item:245873]].

It is recommended to sim yourself to find out what works best, and if you
also play the other two Rogue specs, you might want to pick Embellishments that work
well for all of them.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Outlaw Rogue Crest Upgrade Priority**
**Weapon (Mainhand)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

These are not the only items worth upgrading, of course. They simply offer
the highest DPS gain early into the tier when your upgrade currency is limited.
Note that exceptions are possible, such as special items that have additional
procs attached to them.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **18 Aug. 2026:** Updated for Season 2 launch and the most recent gear nerfs and changes.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Updated Trinket recommendations.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Updated info for Patch 11.2.5, added Puzzling Cartel Chip section, removed DISC Belt section.
- **04 Aug. 2025:** Updated for Patch 11.2 and TWW Season 3. Added all new BiS lists. Removed information regarding Cyrce's Circlet and the Puzzling Cartel Chips. Added information for Reshii Wraps.
- **15 Jun. 2025:** Added information for DISC belt for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5, added Puzzling Cartel Chip suggestions.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **17 Dec. 2024:** Updated for Cyrce's Circlet buffs.
- **15 Dec. 2024:** Cyrce's Circlet information added for Patch 11.0.7.
- **21 Oct. 2024:** Guide has been reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW Season 1 with BiS Gear and Embellishments.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **14 Dec. 2023:** Fixed BiS list for M+ gear.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Added BiS Lists for 10.1.7.
- **10 Jul. 2023:** Added Dawn of the Infinite section, removed Cataclysm Timewalking section, updated Annulet section for Patch 10.1.5.
- **06 Jun. 2023:** Updated Embellishment info.
- **24 May 2023:** Added Timewalking info.
- **14 May 2023:** Updated trinket recommendations.
- **07 May 2023:** Updated Embellishment recommendations for recent hotfixes.
- **01 May 2023:** Page fully updated for Patch 10.1. Added Flightstone and Crest information, added Season 2 BiS items and recommendations, BiS embellishments and more.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated with raid trinkets and BiS list disclaimer.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Outlaw Rogue. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Outlaw Rogue Stat Priority

For raiding and Mythic+, the secondary stat priority for Outlaw Rogue is largely the same.
The only meaningful difference between single-target and AoE, is that you do not play
[[spell:271877]] in single-target builds, which makes Haste a bit more valuable, so try
to aim for **30%** in a raid gear setup, while ～25% is enough for Mythic+ dungeons.
The general stat priority is as follows:

Item Level

Critical Strike to 40%

Haste to 25%

Versatility

Mastery

The value of Haste and Crit are somewhat dependent on how much of it you already have.
Crit starts losing in value once you reach ～40% Crit, while Haste drops off at around 25-30%
once you reach the breakpoint for getting a 0.8sec GCD during Adrenaline Rush. While you generally avoid
stacking stats on every single gear piece, you want to make sure you are
close enough to these "breakpoints", as long as you do not drop itemlevel for it.

You will likely want to prioritize Haste and Critical Strike on many pieces,
and take as much Versatility as is unavoidable to get.

2.

### In-Depth Stat Breakdown

**Agility** is your primary statistic. You should look for it in all
of your upgrades. It provides you with Attack Power, which determines the
damage your abilities do.

**Versatility** is a flat-out damage done increase and damage taken
reduction.

**Critical Strike** increases your chance to critically hit
with attacks and deal double damage. It has some interaction with
[[spell:235484]], which deals extra damage when it critically
hits.

**Haste** provides you with increased attack speed and Energy
regeneration. Besides the base Energy regeneration, Haste
gives you more Energy through [[spell:61329]]. Finally, you will have
an increased number of [[spell:86392]] procs with more Haste. It lowers
your Global Cooldown to up to 0.8sec, down from 1.0sec, during [[spell:13750]].

:::details FAQIs there a Haste Cap for Outlaw Rogue?
You will want to aim for around 20-25% Haste. This is due
to Haste affecting the GCD during

[[spell:13750]]

to some degree, up
to a reduced GCD of 0.8 seconds. Once you reach this breakpoint, excess Haste
has very low value.

:::

**Mastery** increases the damage that your [[spell:76806]]
procs will deal. This attack has a chance to trigger [[spell:61329]],
which increases your Energy regeneration.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Page was reviewed for Patch 11.2 and no changes were required.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Guide has been reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary.
- **01 May 2023:** Patch 10.1 did not change the stat priority.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Added HO disclaimer for Haste.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Outlaw Rogue, based on your [stat priority](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should use [[item:240967]] in one socket. For your secondary
stat gems, pick Crit or Haste gems, like [[item:240890]]
or [[item:240906]]. Make sure to grab at least one of each gem type, like [[item:240914]]
and [[item:240898]], and then fill the remaining slows with the higher-value
gems that we listed earlier.

Keep in mind that the choice of gems is highly dependent on your equipped gear. Each of
the four secondary stats can easily be your most worthwhile stat for gems, depending on the current gear
you are wearing, and as a result, the choice of gems can vary a lot. We highly recommend
simming yourself to find out the best set of gems for your character specifically via [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Main Hand</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Off Hand</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243981]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Chest</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Whether you choose to enchant your gear with Avoidance, Leech, or Speed is
up to you. Leech will allow you to gain some additional passive healing while
you do damage, Avoidance reduces the damage taken by Area-of-Effect spells,
similar to [[spell:1966]], and Speed simply increases your movement speed. For
Raid progression, movement speed is often underrated and can be a minor DPS
increase if it allows you to reach your target faster.

It is always recommended to sim yourself to find out what enchants provide
the best benefit to you individually.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

You will want to grab [[item:241326]] as your go-to Flask for the Crit bonus,
unless this would put you over the ~40% Crit mark, at which point you want to play [[item:241325]] instead.
You can also obtain a flask of your choice from [[item:241319]]s
provided by Alchemists.

3.2.

#### Potions

[[item:241288]] is your best option, and should be paired with major
cooldowns and [[spell:2825]] / [[spell:32182]]. You can also obtain
temporary versions of the potion from [[item:241285]] provided
by Alchemists.

In Season 2 you now have access to [[item:271883]] 
which is significantly better than [[item:241305]]. Using
this has a 5-minute cooldown, but multiple can be consumed in an extended boss
fight should it go on long enough. Additionally, Warlock's
[[item:5512]] does not share a cooldown with other healing consumables.
Remember to use it as well if you are holding one!

3.3.

#### Food Buff

Try to chomp down on [[item:255845]] or another primary stat feast if possible. If
this is not provided by your group, stick to [[item:242275]] as your personal food instead.

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s 
to increase your primary stat. Augment Runes are expensive and disappear on death, 
so use them wisely and sparingly!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **25 Apr. 2026:** Changed Ring enchant to only recommend Eyes of the Eagle.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Updated for Patch 11.2. Removed Corruption section.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **20 May 2025:** Updated Horrific Vision Enchant section to recommend Echoing Void.
- **21 Apr. 2025:** Added information for Horrific Visions enchants, reviewed page for 11.1.5.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Slightly updated Gem description.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Updated Onyx Annulet paragraph to no longer recommend farming it after 10.1.5 Annulet nerfs.
- **06 Jun. 2023:** Added Belt Clasp and Lambent Armor Kit as alternative Leg Enchant. Added Corrupting Rage Phial discussion.
- **01 May 2023:** Page reviewed for Patch 10.1. Updated Onyx Annulet recommendations.
- **26 Mar. 2023:** Updated Primordial Gem recommendations for latest hotfixes.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated stat prio and Fortune Cookie food buff.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Outlaw Rogue in World of Warcraft Patch 12.1.5.

1.

### Outlaw Rogue in Mythic+ in Midnight Season 2

The playstyle of Outlaw in Mythic+ is almost exactly the same as your
regular single-target rotation. As almost all of your damage cleaves onto
additional targets whenever [[spell:13877]] is active, maintaining a permanent
uptime on **Blade Flurry** without wasting it when enemies are about to die
is key to performing well as Outlaw.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Outlaw in Mythic+ offers both high sustained AoE damage, as well as strong
sustained single-target damage that is always available and not reliant
on major cooldowns having to be synchronized with the rest of the group. While you
won't be beating any class in burst DPS, you'll be carrying the DPS when their cooldowns
have run out. Make use of this flexibility and sustained damage, and focus on
the highest health targets at all times!

2.

### Best Mythic+ Talent Builds

Patch 12.1 saw a major change for [[spell:1224865]], as [[spell:51690]] was buffed
considerably, making it a choice for either hero talent tree. This ultimately leads to
both Hero trees playing the exact same class and spec tree, and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster
simply outperforms Fatebound on every metric. Fatebound is therefore only worth
playing if you do not mind the loss in DPS, or prefer the thematic appeal of it.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) Trickster Mythic+ Build

2.1.

#### Trickster Mythic+ Talents

This is the higher-performing AoE/Dungeon build for Outlaw, playing Trickster. It does
great sustained AoE damage, and sports a very high DPS ceiling where no matter what situation
you find yourself in, you will always have strong damage ready for a pack. While you may not
be able to keep up with other classes while they use all their cooldown, you'll overtake them
quickly once they run out of steam - something that doesn't happen to Outlaw!

Be sure to use the 'Export Talents' button to import our build ingame!

:::talents Outlaw Trickster AoE
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound Mythic+ Build

2.2.

#### Fatebound Mythic+ Talents

This is the lower-performing AoE/Dungeon build for Outlaw, playing Fatebound. It does
good sustained AoE damage, although it sacrifices a bit of single-target to do so, and sports
a lower ceiling than the equivalent Trickster build. If you prefer playing Fatebound,
then this is the build to choose.

Be sure to use the 'Export Talents' button to import our build ingame!

:::talents Fatebound AoE
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBMwGMjRjZDw2ALMAYmZgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBMwGMjRjZDw2ALMAYmZgB"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-Sy0sAIYgc4gQJI-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns, and Stops

3.1.

#### Interrupts

[[spell:1766]] is your, well, "kick". You will interrupt your targeted enemy or,
when using a Focus-Macro, the target you set up as your focus.

#### Focus Kick Macro

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists,nodead] [] Kick
```

This macro will kick your focus target if you have one and your target if you have no focus
target. We recommend keeping both the macro and a regular kick cast on your bars,
as you may have multiple targets to interrupt, and the macro always prioritizes the
focus target.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro** or setting the "Focus Target" hotkey in the game's
keybinding settings.

#### Focus Macro

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

3.2.

#### Stunning and "Stops"

[[spell:6770]] and [[spell:2094]] can be useful to hard-crowd control
multiple mobs in a single trash pack. You can also use it right before the
tank is pulling, as [[spell:379005]] applies a damage reduction debuff
to the target when Sap breaks.

With [[spell:200733]] and [[spell:379005]] talented, [[spell:2094]] turns into a
low-cooldown AoE disrupt that also drastically reduces tank damage taken
for a short period, but it only works against targets that can actually be disoriented. It
will not work against large elites or bosses.

[[spell:1856]] can be used to [[spell:1833]] enemies, stunning them thanks
to [[spell:108208]]. Only use this as a last resort, as you want to use
[[spell:1856]] as a DPS cooldown.

[[spell:1776]] (if talented) can be used to disrupt enemies from casting otherwise
uninterruptible spells. This requires you to stand in front of the enemy but
can be used in many situations to keep enemies from using some of their most lethal
abilities. Many of these abilities go on cooldown once used, so disrupting them
with Gouge, [[spell:408]], or [[spell:2094]] will keep these mobs from
re-casting these abilities for a while.

### Blind Skipping

3.3.

#### Blind Skipping

[[spell:2094]] is not part of our DPS kit, but still has some interesting use-cases in Mythic+ that may
not be immediately apparent. While [[spell:6770]] allows a player to safely pass a CC-ed creature without getting
into combat, a blinded enemy will walk around confused and still get into combat with the **first** player that
gets close to it. Once the Blind debuff ends, it will engage said player. It will not, however, get into combat
with any other player that gets close to it.

You can still make great use of Blind to pass enemies by abusing the fact that only one player
gets into combat with it. The best and easiest way to do this, is to ensure that after blinding the target, you
get close enough to enter combat with it, and then you and your entire group can pass the enemy. Once you
are far enough away from it, you can safely [[spell:1856]], drop combat, and skip the enemy.

This is particularly useful in situations where an entire pack of enemies is in your way that you would
like to skip, but one or two enemies are too close to pass by without body-pulling them. As a Rogue, you can
[[spell:6770]] one, and then use the above trick for the other, allowing you to skip past enemies that would either
detect you if you were to use [[spell:114018]], or if Shroud is on cooldown.

### Other Utility

3.4.

#### Other Utility

[[spell:114018]] projects AoE [[spell:1784]] around you. It
is important to note, however, that in the current expansion, there is a much
greater number of enemies who can detect through Stealth or Invisibility, whom
you will need to be on the lookout for.

[[spell:1725]] helps set up Shroud-skips and keeps patrolling trash
packs in place for 10 seconds. Make sure to force enemies to look away from you
to allow you to stealth past them.

[[spell:1966]], [[spell:31224]], [[spell:5277]],
[[spell:185311]] and [[spell:31230]] form a very powerful set of
defensive cooldowns and are one of the biggest reasons for Rogue's strength in
Mythic+.

[[spell:57934]] is not exceptionally great normally. However, any
kind of support that helps your tank keep aggro on all enemies is encouraged.
Sadly it is a choice-node with [[spell:379005]].

[[spell:5938]] can be used to dispel **Enrage** effects. Keep in mind
that this means you will not be able to use Shiv for DPS.

[[spell:5761]] and [[spell:381637]] are both useful in
Mythic+,
but with the heavier emphasis on trash mobs, [[spell:5761]] is likely
to win out on Fortified, with Atrophic gaining more value on Tyrannical weeks.
Communicate with your tank and healer which ones are preferable.

4.

### Dealing with Affixes

Season 2 of Midnight only has four significant Affixes that offer any kind
of counterplay, called Xal'ataths Bargains. These rotate every week, with only
one of them being active at a time. Many of the Mythic+ affixes, like Fortified or
Tyrannical, simply add a passive effect to the keystone, with these four exceptions
that are seasonally themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. [[spell:2094]] works great here as an AoE interrupt,
  thanks to [[spell:200733]]. Use [[spell:408]] or [[spell:1833]]
  only if absolutely necessary.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn that
  needs to be focus-targeted and interrupted. If you know this is happening,
  make sure to use your cooldowns on this target, and cleave off of it.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and circle
  around them. You have 15 seconds to soak all of these to buff your group. Using
  [[spell:2983]] will help you soak these faster.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb. You can remove this with [[spell:31224]] or racials like Stone
  Form. Use [[spell:185311]] if these are unavailable to you to help get rid of
  the debuff faster. Health potions or Healthstones also work well if your healer is out
  of resources.

Each of the affixes provides a different set of beneficial effects once it is dealt
with, and while they are very powerful, they are not something you play around
in a specific way. The most important part is to not let any of them buff the enemy
trash or bosses.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **25 Apr. 2026:** Updated Trickster M+ build with Sleight of Hand.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Page updated for Patch 11.2 and Season 3, with weekly and high key build recommendations.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **09 May 2025:** Switched to Trickster Mythic+ build recommendation.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Path 11.0.5.
- **09 Sep. 2024:** Updated for the start of Season 1 of The War Within.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary.
- **01 May 2023:** Updated tips and tricks for Patch 10.1 Affix changes.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated talent build recommendation.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Outlaw Rogue in World of Warcraft Patch 12.1.5.

1.

### Best Macros

You can use modifiers in case some abilities are "exclusive" to one another
without having to change your hotkeys or drag abilities into your hotkey bars
all the time. The syntax for these is as follows:

- [known:SPELLNAME] or [known:SPELLID]

and

- [noknown:SPELLNAME] or [noknown:SPELLID]

1.1.

#### Outlaw-specific Macros

Outlaw is a very simple spec and has very little in terms of macros that can help
your DPS. The only relevant macro would be to macro [[spell:195457]] to be cast on your cursor,
so you don't have to confirm the action with a left click.

1.2.

#### Specific Macros for Outlaw Rogues

#### Grapple on Cursor

```wow-macro
#showtooltip
/cast [@cursor] Grappling Hook
```

2.

### Best Addons

2.1.

#### Generic Addons for Rogues

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.4.4.

##### TankMD

[TankMD](<https://www.curseforge.com/wow/addons/tankmd>) is a new addon 
  that was previously a WeakAura. It allows you to automatically target the tank of the 
  group with your [[spell:57934]] spell without needing a mouseover, focus target, swapping target
  or anything of that sort.

2.5.

#### Specific Addons for Outlaw Rogues

Currently, we feel that there is no need for additional addons to play an
Outlaw Rogue to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Page was reviewed for Patch 11.2 and no changes were required.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary.
- **29 Apr. 2023:** Patch 10.1 required no changes to this page.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
