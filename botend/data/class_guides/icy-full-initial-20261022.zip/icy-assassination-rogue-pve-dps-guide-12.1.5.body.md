## 专精概览

欢迎来到我们的《魔兽世界》12.1.5版本奇袭潜行者指南。在这里，你将学习如何在团队副本和大秘境中扮演奇袭潜行者：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

奇袭大秘境资源

[全新！顶尖奇袭天赋构筑](<https://raider.io/specs/assassination-rogue/talents>)

[顶级 奇袭 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/rogue/assassination>)

[奇袭 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=rogue--assassination>)

[热门 奇袭 团队配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=rogue--assassination>)

1.

### 奇袭 潜行者 概览

奇袭 潜行者 通过施加和强化中毒与流血效果来造成伤害。奇袭 的伤害手段相对有限，主要专注于单体伤害输出，并在多个敌人身上扩散持续伤害效果，同时拥有非常强力的2分钟冷却爆发能力。

与其他 潜行者 专精一样，奇袭 拥有出色的防御和控制能力，使他们能够承受并存活大多数其他职业无法应对的机制，同时控制敌人以限制团队或坦克在大秘境环境中承受的伤害量。

良好的伤害分布与调校

奇袭 潜行者 拥有非常实用的伤害分布，强力的2分钟冷却在单体战斗中尤为突出。借助[[spell:381798]]，该专精还能获得强大的斩杀伤害。在第二赛季初期获得了一些小幅增强后，该专精的伤害无疑是具有竞争力的。

尚可的伤害，近乎不死

奇袭 潜行者 是任何团队副本环境中的不错选择，这得益于其强力的2分钟冷却和斩杀伤害，以及拥有惊人的生存能力。在其他职业处理小怪波次或需要快速爆发击杀的目标时，它是将伤害倾泻在首领身上的最佳专精之一，而这正是 奇袭 在此类内容中为数不多的弱点之一。

其独特的团队增益[[spell:381637]]是减轻许多团队副本首领伤害的有用工具，尽管遗憾的是它并非对所有首领机制都有效。

惊人的优先目标伤害，但预热稍慢

奇袭 在大秘境中可以非常舒适地游玩，通过天赋可以获得扎实的AOE伤害，代价是首领战中的一些单体DPS损失。这个缺点可以通过将小怪拉到首领身上来大幅弥补，因为 奇袭 拥有出色的优先目标伤害，通常被称为漏斗伤害。

它还拥有大量可用的实用技能，使你能够像极少数专精那样干扰和控制敌人。[[spell:6770]]、[[spell:2094]]、[[spell:1776]] 和[[spell:200733]]在各种情况下都很有用，而且它是游戏中仅有的两个拥有团队潜行技能[[spell:114018]]的职业之一。

大秘境表现出色，团队副本表现糟糕

奇袭 拥有许多不同的实用技能，例如[[spell:381637]]、[[spell:114018]]、[[spell:6770]]、[[spell:2094]]、[[spell:1776]] 或[[spell:200733]]。除了虚弱毒药外，这些技能在团队副本环境中都派不上用场。即使虚弱毒药并非对所有团队副本首领技能都有效，大多数团队仍然会带上至少一名任意专精的 潜行者 来提供它。

不过在大秘境中，一个懂得运用所有看家本领的 潜行者 能够让每次通关都变得更加轻松和安全，虽然这些好处可能不会体现在DPS统计上，但如果你充分发挥你的实用技能，许多坦克和治疗都会心存感激。[[spell:200733]] 恢复为AOE[[spell:2094]]对我们来说也是一大福音，因为它不仅能干扰敌人，还能通过[[spell:379005]]降低他们造成的伤害。

极其耐打

盗贼是生存之王，尤其是在团队副本环境中。多亏了[[spell:31230]]、[[spell:1966]]、[[spell:31224]]、[[spell:5277]] 和[[spell:185311]]，你通常会是最后几个存活的人之一，这使你即使在局势不利时也能力挽狂澜地击杀首领或小怪。

当坦克死亡而你能安全地再扛住一小波小怪甚至团队副本首领10秒钟时，准备好的[[spell:5277]]会非常有用，虽然盗贼在应对长时间的持续伤害方面较为吃力，但你拥有众多手段来存活到最后。

唯一真正的难点是在高层大秘境中的持续伤害，但通过点出[[spell:79008]]，你也能可靠地存活在最高层数的钥石中。

移动非常灵活

奇袭 拥有扎实的机动性，可以使用冷却时间很短的[[spell:2983]]让你跑得和骑马角色一样快，还可以使用[[spell:36554]]快速脱离危险，或接近距离你很远的敌人。

能够跳向友方和敌方目标提供了良好的灵活性，甚至可以让你完全避开某些机制。潜行者 机动性的唯一缺点是暗影步相当低的范围限制。

1.

### 奇袭 潜行者 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本补丁未对潜行者或作为专精的奇袭带来任何实质性改动。该补丁的主要重点是2项全新的终局内容，一项面向团队副本队伍，另一项面向 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。请务必查看关于新的基斯提克斯团队副本战斗的信息，以及令人兴奋的全新迷宫巨型地下堡！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

[12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>) 作为至暗之夜第2赛季进程的延续，围绕乌拉特克和阿曼尼的故事最终带来了一个全新的单首领团队副本、升级装备等级的途径、多种追赶装备来源，以及无限量的雾玉用于升级装备。请务必查看我们的补丁中心，了解补丁12.1.5的所有新增或更新信息。

2.3.

#### 职业改动

12.1.5版本对 奇袭 潜行者 没有任何改动，只有一些技能动画的小型外观更新。

因此，我们的
[天赋](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>) 推荐和
[输出循环](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>) 优先级没有任何变化。但是，随着新装备的加入，我们的 [装备](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>) 页面已经更新，包含了关于新物品以及如何最好地使用你的[[item:280562]]的信息。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_deathmark.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1版本职业平衡调整 隐藏12.1版本职业平衡调整
[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**奇袭 潜行者**

<em>开发者笔记：我们正在对乌拉泰克的诅咒中奇袭的能量循环进行一些更新。我们对坚不可摧这一巅峰天赋1级的实战表现不满意——为了让它达到最优打法而故意让毒伤效果消失是不合直觉的。我们正在更新它的设计，使得延迟刷新毒伤始终是最佳的游玩方式，并赋予它稳定的能量恢复价值。我们还进行了一些旨在增加天赋构建选择的改动。</em>

- **职业**
  
  
  
  
  - [[spell:381623]]现在是一个选择天赋——玩家现在可以在现有版本（除了可以主动使用外，还会在低能量时自动施放）和一个必须主动施放的新版本之间进行选择。
  - 虚弱毒药现在降低4%的伤害（原为3%）。
  - 虚弱毒药的持续时间增加至60秒（原为10秒）。在PvP战斗中持续时间保持不变。
- **英雄天赋**
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者：宿命之击在你封印命运时有60%的几率给予额外连击点数（原为100%）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手：修复了不动意志的加成随层数相乘的问题。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手：修复了使用技能时经常导致不动意志移除多于一层的问题。
- **奇袭**
  
  
  
  
  - 新天赋：[[spell:1298812]]——毒伤伤害提高18%，但持续时间缩短2秒。
  - 巅峰天赋：[[spell:1265385]]（1级）已更新——毒伤伤害提高10%。毒伤现在每消耗一个连击点数恢复2点能量。
  - 巅峰天赋：[[spell:1265387]]（3级）——无情打击伤害提高15%。
  - [[spell:381627]]已更新——现在在施放肾击和割裂时触发，而不再在用猩红风暴复制割裂时也施加。伤害提高10%。
  - [[spell:196861]]已更新——从潜行状态或在强化锁喉窗口期内施加的锁喉现在会使目标沉默5秒。减伤效果保持不变。
  - [[spell:381797]]已更新——毒伤的效果现在还会使你的武器毒药的暴击几率提高10%（原为5%）。你的武器上每有一个致命毒药，你的能量生成就提高4%。
  - 所有造成的伤害提高20%。
  - [[spell:360194]]使你的割裂、锁喉和致命毒药的伤害提高75%（原为100%）。
  - [[spell:385627]]伤害降低15%。
  - [[spell:385478]]使锁喉伤害提高30%（原为20%）。
  - [[spell:1250358]]使割裂伤害提高25%（原为20%）。
  - [[spell:1247993]]能量提高至30%（原为20%）。
  - [[spell:455072]]伤害加成提高至20%/40%（原为15%/30%）。
  - [[spell:79134]]在多个目标受到你的流血效果影响时会生成更多能量。
  - [[spell:328085]]的触发几率降低至10%（原为15%），目标生命值较低时为20%（原为30%）。
  - [[spell:255544]]的视觉效果已调整，使其上方的其他重要视觉效果更容易看清。
  - [[spell:382238]]和[[spell:382245]]现在能正确与[[spell:1265387]]（3级）造成的打击配合生效。
  - 数个天赋在天赋树中的位置发生了变化。
  - [[spell:1250271]]已被移除。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜改动概述

在 至暗之夜 发布之际，游戏发生了巨大的变化，无论是对专精本身还是对 潜行者 职业的整体改动。这些改动中的许多已经在资料片发布前的前夕版本中应用，但我们将整套改动列在这里，供回归玩家参考，并确保你在用 奇袭 潜行者 探索 至暗之夜 时确切知道会遇到什么。

许多改动背后的主要目标是加强两棵英雄天赋树的身份认同， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者，通过让能量再次成为更有影响力的资源来改变循环玩法的节奏，并改变AOE循环使其更接近我们的单体循环。

由于这些改动，许多技能被精简或重新设计，我们在下面概述了影响最大的改动，突出它们如何影响你的日常游戏体验，与你可能已经习惯的 奇袭 版本相比。不过请放心，循环玩法的流程仍然与 奇袭 多年来所依赖的流程非常相似，所以即使你在较长的休息后带着 至暗之夜 回归游戏，你也不会感到迷失！

2.5.

#### 英雄天赋改动

[[spell:457052]]将更容易施加，因为它不再与伏击绑定，从而移除了必须处于 **[[spell:1784]]**状态的要求。然而，切换标记变得更难，因为你不能再[[spell:1856]]和[[spell:8676]]来将其施加到你选择的目标上。切换标记的唯一方法是等待一个[[spell:457058]]触发并将标记换到另一个目标上。你还可以在5个及以上连击点数时触发至黑之夜，而不需要使用满连击点数的毒伤，这将使循环的容错性稍微提高，但在大多数情况下你仍然希望在满连击点数时使用它。

命缚者 终于能够在AOE中竞争了，这要归功于[[spell:454429]]大幅增强了[[spell:421975]]。投掷命缚者硬币现在也更加稳定，不再需要[[spell:1856]]或现已移除的[[spell:382245]]来稳定触发终极增益。这在所有情况下都提高了 命缚者 的可用性，为其伤害分布提供了更可靠的收益，同时仍保留了其抛硬币的核心特色。

2.6.

#### 循环要点

对我们循环来说最大的改动是对连续施放[[spell:32645]]的重新高度重视。有大量天赋获得了大幅增强，以鼓励在毒伤即将到期前连续施放，我们的巅峰天赋[[spell:1265385]]也进一步强调了这一特色。支持这种玩法的最具影响力的一些天赋是：

- **[[spell:1250036]]**
  
  
  
  
  树底部的一个新的选择节点天赋，在连续施放毒伤时增强我们所有的职业伤害。
- **[[spell:1250318]]**
  
  
  
  
  振奋打击的替代天赋，在正确衔接时改为给予1个连击点数。
- **[[spell:455072]]**
  
  
  
  
  该天赋获得了大幅增强，在衔接时提供30%的毒伤伤害加成。

2.7.

#### 巅峰天赋：坚不可摧

[[spell:1265385]]是我们在 至暗之夜 中的巅峰天赋，它通过在你的毒伤衔接中断时提供一波能量来弥补 奇袭 的一些弱点。这意味着一旦你的能量耗尽，你将不再有数秒钟没有任何按键可按，在[[spell:381623]]和[[spell:1265385]]之间，你可以相当快地恢复使用技能。

其他收益，[[spell:1265386]]和[[spell:1265387]]基本上只是在初始收益之上的额外DPS提升，而在使用[[spell:385627]]后自动生成连击点数也是一个受欢迎的加成。

2.8.

#### 能量生成

我们的能量生成也发生了相当大的变化。与之前《地心之战》版本的该专精不同，你从[[spell:79134]]获得的能量会少得多，转而更多地通过被动方式生成能量。这一改动也大大降低了我们在AOE中的能量生成，减少了能量溢出，并突出了在决定将资源用于哪些技能时瞬时决策的重要性。

2.9.

#### 冷却调整

[[spell:5938]]不再提供任何伤害加成，所有增强其直接伤害或使其对敌人施加额外伤害效果的天赋都已被移除。它现在作为其安抚的实用技能，同时不再是我们DPS循环的一部分。

[[spell:360194]]不再复制流血效果，而是使它们造成更多伤害，由此造成的能量损失由它自身生成能量来弥补。

[[spell:385627]]更容易获取，作为我们1分钟的冷却技能，很可能会成为任何构建的必选天赋。

2.10.

#### AOE伤害输出

我们在AOE中的循环玩法被大大简化了，我们的单体循环和AOE循环现在非常相似。这的主要原因是[[spell:1247227]]的新设计，它结合了[[spell:51723]]和[[spell:381802]]的效果，既是连击点数生成器又能扩散流血。它比刀扇消耗更多能量且伤害更低，所以你必须随时决定在AOE中将这些技能中的哪一个作为你的主要生成器。

[[spell:421975]]也已更改，不再需要激活的流血或中毒效果，而是在施放毒伤和君王之灾时触发。在AOE中不再需要使用毁伤或伏击了！

1.

### 奇袭 潜行者 玩法基础

奇袭 潜行者 是一个使用连击点数系统并通过扩散其持续伤害效果来生成额外资源的专精，同时维持几个高影响力的增益和减益效果来造成持续的DPS。其很大一部分伤害将在每2分钟通过同时使用不同的冷却技能来打出。

生成额外资源是该专精的核心组成部分，因此由于[[spell:79134]]，确保始终同时保持[[spell:703]]和[[spell:1943]]至关重要。连击点数通过在单体目标上使用[[spell:1329]]或在AOE中使用[[spell:51723]]/[[spell:1247227]]来生成。未用于割裂的多余连击点数可以用于[[spell:32645]]以造成瞬时伤害并提高你的毒药提供的被动伤害。[[spell:385627]]每60秒提供一次爆发，而[[spell:360194]]是我们的2分钟冷却技能，同步两者可以造成惊人的爆发DPS。简而言之，这三个概念将简要描述你对 奇袭 潜行者 的期望。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_speedoflight.jpg>) **管理你的资源**
  
  
  
  
  潜行者 玩法中最重要的方面之一是关注你的能量和连击点数资源。你要避免其中任何一个溢出，所以要谨慎使用它们。有些技能可以随机生成一定范围的连击点数，例如由于[[spell:14190]]的[[spell:1329]]。这自然会导致你偶尔溢出连击点数，但将这种情况降到最低是玩好 奇袭 的关键。能量永远不应该溢出，你将花费大量时间来确保在被动能量回复之外获得稳定的能量收入。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_rupture.jpg>) **我们需要更多持续伤害**
  
  
  
  
  你有两个主要的流血持续伤害技能[[spell:1943]]和[[spell:703]]，你对它们的覆盖率应该是100%。如果敌人还没有这些效果，施加它们总是有益的。你可以通过直接施放它们，或在AOE环境中让[[spell:1247227]]来做这些脏活，它会将现有的流血效果扩散到附近的敌人身上。你通过[[spell:79134]]生成额外能量，每个流血效果都意味着更多能量，这是保持你的能量高速流动的关键部分。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_disembowel.jpg>) **变得有毒（或致命）**
  
  
  
  
  奇袭玩法的很大一部分围绕着[[spell:32645]]展开，并通过将任何多余的连击点数用于它来尽可能保持该增益的覆盖。你将需要尽可能多地衔接毒伤，这意味着你在原始持续时间到期前立即重新施放它。你将无法保持该增益100%的覆盖，但最大化该增益的覆盖将始终带来更多DPS。

1.

### 作为 奇袭 潜行者 如何获取装备

虽然我们始终建议你自行模拟以获得理想结果，但我们确实提供了一个专门的 奇袭 配装页面。我们目前涵盖了第二赛季装备的推荐，以便在终局 至暗之夜 内容发布时有一个良好的开端。在你获取了一些装备后，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月25日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 更新了饰品排名。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对第2赛季上线以及最近的装备削弱和改动进行更新。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月26日（本页）：** 已针对5月26日的职业改动进行更新。
- **2026年4月24日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 更新了戒指附魔。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026 年 3 月 31 日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 更新了饰品推荐。
- **2026 年 3 月 31 日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 更新了针对 锁喉 Snapshot 的起手式。
- **2026年3月31日（本页）：** 已针对 锁喉 Snapshot 的Bug进行更新。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（本页）：** 已针对至暗之夜进行更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已针对前夕补丁进行更新。
- **2026年2月10日（本页面）：** 页面已针对前夕补丁进行更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（本页面）：** 页面已针对11.2.7补丁进行更新，列出了所有主要的内容更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对11.2.5补丁更新了信息，添加了谜之财团筹码部分，移除了DISC腰带部分。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（本页）：** 页面已针对11.2.5补丁和军团再临重制版进行更新。
- **2025年10月4日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年9月6日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已更新，包含简化的循环改动。
- **2025年9月6日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已更新，内容围绕套装进行撰写。
- **2025年9月3日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 澄清了 命缚者 Shiv 的使用方法。
- **2025年8月18日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 澄清了未点出君王之灾时死亡猎手的群体伤害输出循环。
- **2025年8月16日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 为命缚者的暴击需求添加了说明。
- **2025年8月13日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 添加了关于虚空棱晶的信息。
- **2025年8月13日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 调整了11.2版本前的天赋套装推荐。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 针对11.2版本审核了本页面，无需更改。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对11.2版本和地心之战第3赛季更新。添加了所有新的毕业装备列表。移除了关于瑟西斯的指环和令人费解的卡特尔筹码的信息。添加了关于蕾希裹布的信息。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 针对11.2版本审核了本页面，无需更改。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 移除了腐蚀部分，并审核了11.2版本的信息。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 针对11.2版本审核了本页面，无需更改。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已针对11.2版本和第3赛季更新本页面，包含每周和高层大秘境的构筑推荐。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2版本更新本页面，详细说明了命缚者和死亡猎手的套装影响。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对11.2版本更新页面，为有无新套装的天赋推荐添加了标签。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 针对11.2版本审核了本页面，无需更改。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已针对11.2版本更新，添加了套装免责声明。
- **2025年8月4日（本页面）：** 已针对11.2版本更新信息。
- **2025年6月21日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对6月20日的在线修正更新戒律牧推荐。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 为11.1.7版本添加了关于戒律牧腰带的信息。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于战斗辅助功能的信息。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 添加了关于战斗辅助功能的信息。
- **2025年6月15日（本页）：** 添加了关于11.1.7版本的信息。
- **2025年5月20日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 更新了惊魂幻象附魔部分，推荐回响虚空。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已更新至11.1.5补丁，新增了令人费解的财团代币建议。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 新增了惊魂幻境附魔信息，并为11.1.5复核了页面。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 为大秘境切换至流血流派，并为11.1.5补丁复核了页面。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 为大秘境切换至流血流派，并为11.1.5补丁复核了页面。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 为大秘境切换至流血流派，并为11.1.5补丁复核了页面。
- **2025年4月21日（本页）：** 新增了11.1.5补丁相关信息。
- **2025 年 3 月 25 日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 根据3月25日的饰品调整，更新了一些装备推荐。
- **2025 年 3 月 25 日（[解放安德迈页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 根据3月25日的职业改动，更新了一些天赋推荐。
- **2025 年 3 月 25 日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 根据3月25日的职业改动，更新了输出循环优先级。
- **2025 年 3 月 25 日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 根据3月25日的职业改动，更新了一些天赋推荐。
- **2025年3月25日（本页）：** 已根据3月25日的职业改动进行更新。
- **2025年3月17日（[解放安德迈页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 新增了额外提示、加里维克斯信息，以及数个首领的史诗难度提示。
- **2025年3月13日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对机械核心和废品大师饰品进行更新。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（本页面）：** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月25日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 更新了塞尔赛斯指环的宝石推荐。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对塞尔赛斯指环的强化进行更新。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 为11.0.7补丁新增了塞尔赛斯指环信息。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（本页）：** 页面已为11.0.7补丁复核。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已为地心之战11.0.5补丁复核。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 页面已为11.0.5补丁复核。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已为11.0.5补丁复核。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 页面已为11.0.5补丁复核。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已为11.0.5补丁复核。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** 新增了多种史诗难度和普通难度的提示。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 为11.0.5补丁更新了天赋配装。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.5补丁的玩法改动进行更新。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 为地心之战11.0.5补丁更新了天赋配装。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已为地心之战11.0.5补丁复核并更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已为地心之战11.0.5补丁更新。
- **2024年10月21日（本页）：** 新增了11.0.5补丁的职业改动。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对地心之战第1赛季更新，包含毕业装备和美化。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已针对地心之战第1赛季的开启进行更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对第1赛季更新，移除了赛季前构筑。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月24日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 新增了地下堡天赋构筑。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/assassination-rogue-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/assassination-rogue-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/assassination-rogue-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对巨龙时代第4赛季进行审核和更新。新增了鎏金和饰品部分。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（本页）：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已针对10.2.6版本进行审核和更新。
- **2024年3月21日（本页）：** 页面已针对10.2.6版本进行审核和更新。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（本页）：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月14日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 更新了新优化的单体目标起手式。
- **2023年11月14日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 更新了死亡印记和暗影之舞期间新优化的奇袭单体目标优先级。
- **2023年11月8日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 新增了关于该天赋构筑并非最高DPS选择的声明。
- **2023年11月8日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 新增了带特技的DtB大秘境构筑。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对孢子披风削弱进行更新。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（本页）：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.1.7版本更新，新增了多份毕业装备列表。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对10.1.7版本更新，采用新格式。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（本页）：** 新增了10.1.7版本以及近期5%光环和近战增益的信息。
- **2023年7月16日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 更新了永恒黎明部分，时之隙毕业装备。
- **2023年7月16日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 新增了AoE构筑天赋模拟链接。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 新增了永恒黎明部分，移除了大灾变漫游部分，针对10.1.5版本更新了永恒之戒部分。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 更新了关于黑曜石指环的段落，在10.1.5版本指环削弱后不再推荐刷取它。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年7月10日（本页）：** 为10.1.5补丁更新，更新了职业和指南的最新改动。
- **2023年6月6日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 更新了美化推荐。
- **2023年6月6日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 添加了腰带扣环和光耀护甲片作为腿部附魔的替代方案。添加了腐化之怒药剂的讨论。
- **2023年6月6日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 针对放血 bug 进行了更新。
- **2023年6月6日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 更新了败血刃伤的玩法信息。
- **2023年6月6日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 更新为使用败血刃伤替换锯齿骨刺，并完全移除了放血。
- **2023年6月6日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 为败血刃伤流派更新，在放血存在 bug 期间将其移除。
- **2023年6月6日（本页）：** 针对最新的增益和新的理论推导发现进行了更新。
- **2023年5月24日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 添加了时光漫游信息。
- **2023年5月14日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已更新饰品推荐。
- **2023年5月7日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 根据最近的热修更新了美化推荐。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对10.1补丁全面更新。新增了飞龙石和纹章信息，新增了第2赛季毕业装备及推荐、毕业美化推荐等内容。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.1补丁进行审核。更新了奥妮克希亚的印记推荐。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 10.1补丁未更改属性优先级。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 针对10.1补丁词缀更改更新了提示和技巧。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 10.1补丁无需更改循环。新增了循环速查指南。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对10.1补丁进行审核。推荐的天赋配置和天赋树保持不变，页面无需更新。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 10.1补丁无需对此页面进行更改，因为除了数值调整外没有法术更改。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已针对10.1补丁更新。简化了循环优先级。
- **2023年5月1日（本页）：** 已针对10.1补丁发布进行更新。新增了指南近期更新和待处理更新的章节。
- **2023年4月29日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 10.1补丁无需对此页面进行更改。
- **2023年3月26日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 根据最新热修更新了原始宝石推荐。
- **2023年3月26日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 将飞刀替换为强化毒药。
- **2023年3月26日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋配置，新增了模拟器链接。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/assassination-rogue-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已为10.0.7补丁更新。
- **2023年3月5日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 更新了属性优先级和暴怒词缀说明。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已针对巨龙时代10.0.5补丁更改进行更新。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对巨龙时代10.0.5补丁更改进行更新。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已针对巨龙时代10.0.5补丁更改进行更新。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已针对10.0.5补丁更改进行更新。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已针对巨龙时代10.0.5补丁更改进行更新。
- **2023年1月24日（本页）：** 已针对巨龙时代10.0.5补丁更改进行更新。
- **2023年1月4日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 更新了地下城装备列表，新增了毕业列表免责声明和团本饰品。
- **2023年1月4日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 更新了护甲片，新增了幸运饼干食物。
- **2023年1月4日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 更新了属性优先级，新增了低装等下急速的免责声明。
- **2023年1月4日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 更新了天赋和示例起手式。
- **2023年1月4日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 更新了死印和君王之灾天赋配置的循环优先级。
- **2023年1月4日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 根据最新模拟结果更新了天赋推荐和说明。
- **2023年1月4日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 更新了天赋配置。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/assassination-rogue-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/assassination-rogue-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/assassination-rogue-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/assassination-rogue-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月2日（[9.1 补丁分析](<https://www.icy-veins.com/wow/assassination-rogue-patch-9-1-changes-analysis>)):** 新增了9.1.5版本更改。
- **2021年6月28日（[9.1 补丁分析](<https://www.icy-veins.com/wow/assassination-rogue-patch-9-1-changes-analysis>)):** 页面已添加。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年11月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-the-eternal-palace-raid-guide>)):** 移除了免责声明，更新了天赋和玩法推荐，新增了史诗扎库尔章节。
- **2019年7月15日（[永恒宫殿页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-the-eternal-palace-raid-guide>)):** 新增了所有首领的提示。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月8日（[风暴熔渣页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-crucible-of-storms-raid-guide>)):** 新增了更多首领提示。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年2月23日（[达萨罗之战页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** 小幅更新。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** 新增了达萨罗之战的奇袭潜行者建议。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年9月7日（[奥杜尔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-uldir-raid-guide>)):** 新增了各首领专精专属提示。
- **2018年8月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-uldir-raid-guide>)):** 页面已添加（目前为占位内容）。

显示更多

显示更少

:::

## 练级

在此页面上，你将找到我们的逐级奇袭潜行者升级攻略，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[潜行者 升级指南](<https://www.icy-veins.com/wow/rogue-leveling-guide>).

1.

### 奇袭 潜行者的至暗之夜升级指南

不幸的是，潜行者经常被认为是魔兽世界中最糟糕的练级职业。不过别担心，它仍然完全能够轻松应对练级之旅，即使这可能会比选择了其他职业的朋友们花的时间稍长一些。一旦你达到满级，你很快就会超过他们，并且会庆幸自己花了时间选择潜行者！

潜行者练级期间最大的优势之一，就是能够简单地潜行绕过许多麻烦。巧妙运用[[spell:2094]]、[[spell:1856]]、[[spell:6770]]和其他控制技能，你往往可以拾取重要任务物品，然后直接消失脱离，无需击杀任何敌人。

每当你的[[spell:5277]]冷却完毕时，都值得同时拉多只怪物并完全规避它们造成的所有伤害。[[spell:185311]]冷却时间很短，所以务必在拉怪间隙使用它和新的[[spell:1231418]]法术来恢复生命值。玩[[spell:3408]]可以让你风筝许多敌人，它们会在你的持续伤害效果下缓慢但必然地死亡，让你能够继续对付下一个敌人。

随着你升级，你的一些技能会被专精专属技能替换。例如在22级时，[[spell:196819]]会被[[spell:32645]]替换。其他时候，新技能会加入你的输出优先级列表。其中一些你会在升级时自动学会，另一些则需要通过天赋点出。如果你按照我们天赋计算器的按等级加点路线，本指南会立即告诉你如何高效使用这些新技能。

1.1.

#### 升级装备选择

练级时，始终选择物品等级最高的装备。此规则的唯一例外是如果你有一个戒指或项链，它的物品等级略低，但拥有两个副属性而不是一个。

使用传家宝装备时，我们推荐使用带有暴击和急速的装备，因为它们会在练级过程中略微改善游戏体验。

1.2.

#### 至暗之夜升级实用消耗品

随着 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)的全面发布，玩家们将再次有机会将等级提升至新的上限90级。这意味着许多人希望尽可能快地达到最高等级。为此，有许多 <em>可选的</em> 消耗品可以收集来加快进度。不需要囤积太多，因为你只需要将每个角色练一次级。

为了做好最充分的准备，请设法获取以下至少部分物品和附魔。

- [[item:191348]] — 这是一种来自 [巨龙时代](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  资料片的一种可交易消耗品，可以持续30分钟提高你的移动速度属性，并且死亡后仍然保留。练级通常是关于快速旅行，而不是更快地击败敌人。
- [[item:225592]] —— 一种食物，来自 [地心之战](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)，这道可交易的菜肴同样能提供一小时的大量移动速度加成，但死亡后会消失。
- [[item:132516]]——这是一种比较特殊的消耗品，这个来自军团再临工程学的可交易物品（多亏了 [工程学](<https://www.icy-veins.com/wow/professions-engineering>)）可以让你在很长一段时间内移动速度超过地面坐骑速度，甚至可以在水面上移动，但受到伤害时会失效，且无法在战斗中激活。如果在无法使用坐骑的区域，可以将其视为你最快的移动工具。
- [[item:154168]]/[[item:154169]]——虽然很少需要，但这两个来自争霸艾泽拉斯的可交易消耗品可以搭配使用，为你提供水下呼吸能力和大幅提升的游泳速度，比水上坐骑还要快。
- [[item:109076]] —— 这种消耗品允许你在无法骑乘时以极快的速度从高空穿越空中。你甚至可以考虑将其与[[item:122124]]或[[item:104299]]搭配使用！请记住，作为一名潜行者，你承受的坠落伤害比大多数其他职业少得多，只要在落地前有东西可以[[spell:36554]]，就可以完全避免坠落伤害。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串，为你接下来的10个等级做好准备。一旦你开始在至暗之夜中获得等级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 奇袭 80级 至暗之夜练级
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmNDAAAAAAz2gtZAAAAAAZbmZGPwMDWmZmZZmtZmZMjZGMjZGjBYzsMwAAWGmADLGwAMDM"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmNDGAAAAAY2GsNDAAAAAIbzMzMzMDWmZmZZmtZmZMjZGMjZGjBYzsMwAWALDTghFDmZAmhxA"
}
```
:::

:::details 来源计算器编码
```
#DE-hFLGPYSBk+Oh8ymoGV+cFEaEG2FXX3GLrKC-XbCWEiJHbGwY8VBGEABV4MJJxpos07B-AAAA-GQAqcEYgQQDzSB-
```

:::

2.1.

#### 升级用战争模式天赋

在本节中，我们将对最适合练级以及进行单人/小队PvE内容的PvP天赋进行排名。以下是通用PvP天赋和奇袭 潜行者专属PvE天赋的排名。

1. [[spell:198145]] - 对受到你的[[spell:703]]、[[spell:1943]]和致命毒药影响的目标施放至少5个连击点数的[[spell:32645]]，造成自然伤害并使其移动速度降低90%，持续2秒。虽然不是特别有用，但这是额外的伤害，并且可以帮助对付那些被设定为逃跑的敌人。尽管这个天赋需要5个连击点数才能触发，但完全不值得一直用5个连击点数施放毒伤。练级期间继续在4个及以上连击点数时使用终结技。
2. [[spell:354895]] - 你的[[spell:32645]]会施加蠕动毒液，在4秒内造成自然伤害。目标移动时会刷新持续时间。这是另一个被动伤害提升，也可以通过侧移轻松维持，让敌人随你一起移动。
3. [[spell:354406]] - [[spell:408]]使用时会恢复能量，产生的能量多于消耗的能量。这使它相当值得使用，虽然从技术上讲，将连击点数用于伤害性终结技仍是更好的伤害输出，但额外的安全性对盗贼来说可能非常有价值，盗贼是练级时最脆弱的职业之一。
4.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 3 起：**如果你想在不与所有敌人战斗的情况下到达任务目标，或在与敌人交战前，施放[[spell:1784]]。

**等级 1–1：**从1级开始，你只有一个主要攻击技能：[[spell:1752]]。

1. 当你拥有4个以上连击点数时，施放[[spell:196819]]来消耗它们。
2. 使用[[spell:1752]]来积累连击点数。
3. **等级 10–10：**确保你始终施加[[spell:315584]]和[[spell:3408]]。有时，如果你不想减缓正在战斗的敌人，不使用[[spell:3408]]会更有利。只需右键点击增益图标，它就会被移除。
4. **等级 11–29：**确保你始终施加[[spell:2823]]和[[spell:3408]]。有时，如果你不想减缓正在战斗的敌人，不使用[[spell:3408]]会更有利。只需右键点击增益图标，它就会被移除。
5. **等级 15 起：**当你获得这些技能后，使用[[spell:1247227]]将[[spell:703]]和[[spell:1943]]扩散到所有目标上。
6. **等级 30 起：**确保你始终施加[[spell:2823]]和[[spell:5761]]。
7. **等级 35 起：**对首领或精英敌人使用[[spell:360194]]。
8. **等级 53 起：**对单体或高优先级目标使用[[spell:385627]]。
9. **等级 21 起：**从潜行状态施放[[spell:703]]。
10. **等级 17 起：**消耗你的连击点数以在多个目标上维持[[spell:1943]]。
11. **等级 10–21：**施放[[spell:196819]]来消耗多余的连击点数。
12. **等级 13 起：**对想要击晕的敌人使用[[spell:408]]来消耗多余的连击点数。注意那些免疫击晕的敌人。
13. **等级 22 起：**在单体目标上使用[[spell:32645]]来消耗多余的连击点数。
14. **等级 10–11：**除非你拥有4个以上连击点数，否则使用[[spell:1752]]。
15. **等级 12 起：**除非你拥有4个以上连击点数，否则使用[[spell:1329]]。
16. **等级 19 起：**在群体战斗中使用[[spell:51723]]来积累连击点数，或者如果你还有目标需要扩散流血效果，则使用[[spell:1247227]]。

3.1.

#### 防御技能

奇袭盗贼拥有几种可用的手段，可以让与多个敌人的战斗变得更容易，或让你避免受到削弱效果的影响。

- **等级 6 起：**[[spell:1766]]允许你打断正在施法的敌人。经常使用它，以避免在法术施放完成时你原本会受到的伤害。
- **等级 8 起：**[[spell:185311]]让你在4秒内恢复最大生命值的20%。在需要治疗时或在两波拉怪之间使用它。
- **等级 11 起：**[[spell:6770]]让你控制任何人型生物、野兽、恶魔或龙类，持续最多60秒。用它来防止单个敌人在你从潜行状态对一群敌人发起攻击前加入战斗。当敌人受到伤害时，这个控制效果会打破。尽量避免用任何命中多个目标的技能击中它，否则它会加入战斗。
- **等级 13 起：**[[spell:408]] 可以用来击晕单个敌人，持续最多6秒。用它来打断危险的施法，或者单纯地避免受到敌人的伤害。某些NPC可能免疫击晕。
- **等级 28 起：**[[spell:5277]] 使你在10秒内闪避近战和远程攻击的几率提高100%。在与多个敌人战斗时，只要可用就使用它。只有面对敌人时你才能闪避其攻击。
- **等级 23 起：**[[spell:1856]] 使你从视野中消失。这基本上会重置你正在战斗中的所有敌人。如果你濒临死亡，并且觉得使用其他任何防御或进攻技能都无法让你解决掉所有交战中的敌人，请使用
  **消失** 来保命。
- **等级 48 起：**[[spell:2094]] 允许你控制一个敌人最多60秒。可以在潜行状态下或非潜行状态下使用。当目标受到伤害时控制效果会中断，所以确保不要用你的任何AoE技能命中它，或者在 **致盲** 敌人身上带有你的持续伤害效果之一时使用。
- **等级 12 起：**[[spell:31224]] 移除魔法效果并使你免疫魔法效果，持续5秒。这使你有可能移除可能打断你 [[spell:1784]] 的持续伤害效果、让你承受更少的伤害，或者单纯地避免某些控制或伤害效果。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对前夕补丁进行更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 针对11.2版本审核了本页面，无需更改。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 已为地心之战11.0.5补丁复核。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将向你讲解如何在《魔兽世界》12.1.5补丁中轻松游玩 奇袭 潜行者，使用最简单的输出循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 奇袭 潜行者 在 至暗之夜 中的基础知识

如果你是这个职业或专精的新手，最好从一个简单的构筑开始，以便更好地掌握核心机制和互动。这个构筑比起该专精的最佳玩法只稍微逊色一些，尽管更容易上手，所以完全不必担心在你熟悉 奇袭 基础的时候会落后于其他 潜行者 玩家。以下是该专精的一些核心概念。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_speedoflight.jpg>) **管理你的资源**
  
  
  
  
  潜行者 玩法中最重要的方面之一是关注你的能量和连击点数资源。你要避免其中任何一个溢出，所以要谨慎使用它们。有些技能可以随机生成一定范围的连击点数，例如由于[[spell:14190]]的[[spell:1329]]。这自然会导致你偶尔溢出连击点数，但将这种情况降到最低是玩好 奇袭 的关键。能量永远不应该溢出，你将花费大量时间来确保在被动能量回复之外获得稳定的能量收入。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_rupture.jpg>) **我们需要更多持续伤害**
  
  
  
  
  你有两个主要的流血持续伤害技能[[spell:1943]]和[[spell:703]]，你对它们的覆盖率应该是100%。如果敌人还没有这些效果，施加它们总是有益的。你可以通过直接施放它们，或在AOE环境中让[[spell:1247227]]来做这些脏活，它会将现有的流血效果扩散到附近的敌人身上。你通过[[spell:79134]]生成额外能量，每个流血效果都意味着更多能量，这是保持你的能量高速流动的关键部分。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_disembowel.jpg>) **变得有毒（或致命）**
  
  
  
  
  奇袭玩法的很大一部分围绕着[[spell:32645]]展开，并通过将任何多余的连击点数用于它来尽可能保持该增益的覆盖。你将需要尽可能多地衔接毒伤，这意味着你在原始持续时间到期前立即重新施放它。你将无法保持该增益100%的覆盖，但最大化该增益的覆盖将始终带来更多DPS。

总结来说，奇袭 主要专注于维持持续伤害效果，以获得强大的持续输出和顺劈伤害。你将使用产生技能来积攒连击点数，然后消耗它们来施加持续伤害效果和直接伤害终结技，重点在于近乎永久地维持多个增益和减益效果。在我们 奇袭 攻略的这一页中，我们将专注于一种尽可能减少所需按键数量和反应速度的配置，同时不会过度损害整体伤害输出。

1.

### 奇袭 潜行者 在 至暗之夜 中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 团本天赋

2.1.

#### 奇袭 潜行者 新手团本天赋

这是我们为所有团本场景推荐的构筑，玩法为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者。虽然它的单体目标伤害比纯单体构筑略低，但它是顺劈、AoE和单体目标伤害的绝佳结合。除非你在团本中面对高血量精英或纯单体目标的战斗，否则这个构筑都会让你表现良好。我们在天赋部分为那些罕见的情况准备了纯单体构筑！

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 命缚者 团本构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPwYMzYMmZGjBYzsMwAWALDTghFDmZAGjB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AjxMjxYmZmxAYgFYGjGzGgtBsZAwMzgB"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGiCY4QaiS7D84pSooMPCLLMMuuuqrN-XbCEHTsCFNagq+ADCGw8MposwJKLrzD-AAAA-JQmUhpBIgwgxxC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 副本天赋

2.2.

#### 奇袭 潜行者 新手大秘境天赋

这是你的首选大秘境构筑，通过游玩 命缚者 来最大化其整体AoE输出，同时还能造成惊人的优先目标伤害。虽然为了更高的AoE牺牲了一些单体伤害，但这是一笔值得的取舍，可以真正暗杀你锁定的任何目标，同时对周围敌人造成出色的AoE伤害。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 命缚者 大秘境构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAbmlBGwCYZYCMsYwMDwYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzMMA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGimCY4QaiS7D84pSooMPLLMMuuuqrN-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-JQkUhpBIgwgxxC-
```

:::

### 奇袭 潜行者 基础输出循环

2.3.

#### 奇袭 潜行者 新手输出循环

这个优先级列表是非常基础的优先级列表，缺少了一些从该专精中打出最高伤害的细节。通过点击链接，你将能找到这个优先级列表的更详细版本，涵盖单体目标和AoE，以及对 奇袭 玩法一些核心概念的更深入解释。如果你想了解更多关于如何正确积攒能量以及你的起手式应该是什么样的，请查看本指南的输出循环部分。

:::details 常见问题：哪个种族最适合奇袭潜行者？
各种族之间的DPS差距非常小。部落方DPS最佳的种族是牛头人、巨魔和鲜血精灵。兽人的2分钟爆发略高一些。联盟方最佳的种族是人类、矮人和侏儒。

:::

你需要始终让[[spell:2823]]、[[spell:381664]]和你选择的非致命毒药保持激活。

至于实际的输出循环：

- 使用[[spell:1329]]作为单体连击点生成技能，使用[[spell:32645]]作为单体消耗技能。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手：如果你拥有[[spell:457058]]，确保以最大连击点数施放[[spell:32645]]。
- 始终保持[[spell:1943]]和[[spell:703]]，在AoE中使用[[spell:1247227]]将它们扩散。
- 使用[[spell:51723]]作为AoE连击点生成技能，但仅在你使用[[spell:1247227]]将流血效果扩散到所有目标之后。
- 冷却就绪时使用[[spell:385627]]和[[spell:360194]]，并在使用死亡印记之前施加由[[spell:1856]]强化的[[spell:703]]。
- 使用[[spell:381623]]避免层数溢出，与[[spell:385627]]配合使用。

2.4.

#### 奇袭潜行者的技巧与窍门

- 尽量在激活[[spell:360194]]之前刷新[[spell:1943]]和[[spell:703]]，这样你就不必在它激活期间施放这些技能。
- 你可以提前刷新你的增益和减益效果，只要在它们持续时间的最后30%以内。这被称为 **大流行** ，它使保持100%覆盖率变得容易得多。
- 始终在5个以上连击点时施放终结技。
- 当可用时，确保使用你的[[spell:457058]]触发效果，通过以7个连击点施放[[spell:32645]]来刷新[[spell:457052]]。
- [[spell:360194]]会使当前激活的流血效果伤害翻倍。如果这些流血效果通过类似[[spell:381632]]的效果获得增益，你也会将增益后的效果翻倍。

2.4.1.

##### 巅峰天赋： ![Implacable Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_disembowel.jpg>) 不屈

我们的新巅峰天赋[[spell:1265385]]通过在你的毒伤效果消失后提供额外的能量回复，帮助平滑你的能量消耗。你的目标将是尽可能长时间地连续施放毒伤，一旦你耗尽能量，我们的巅峰天赋将帮助你更快地恢复能量。它还提供一些其他的DPS加成，这些加成对你的输出循环没有任何影响。

2.4.2.

##### 第2赛季套装

至暗之夜第2赛季T2套装[[spell:1296590]]和[[spell:1296591]]对我们的输出循环完全没有影响。它只是提升我们的伤害输出，所以获得它后玩法没有任何变化。

### 奇袭潜行者防御法术

2.5.

#### 奇袭潜行者的防御法术

[[spell:1966]]是一个主动法术，可以减少你受到的所有范围伤害。它的冷却时间非常短，应该经常使用。DPS损失可以忽略不计，这是一个让其他所有职业都羡慕的防御技能。

[[spell:31224]]是你的免疫技能。当你按下它时，它会移除大多数魔法、诅咒、疾病或中毒减益效果，这在某些情况下并不是好事。它还会使你对所有魔法效果和伤害免疫。大多数团队副本战斗往往无论如何都会施加相关的减益效果，但至少你不会受到伤害。

[[spell:5277]]将你的闪避提升到100%以上，使你免疫近战攻击。在团队副本中很少有用，但它可以在大秘境或开放世界内容中救你一命。

[[spell:31230]]可以让你免于死亡一次，让你在低生命值下拥有非常强的伤害减免。它有6分钟的冷却时间，让你本已强大的防御技能组合更加强大。

[[spell:1856]]在团队副本中被用作DPS技能，但在世界内容和大秘境中可以救你一命。它会让所有敌人失去对你的仇恨，如果你是唯一存活的玩家，敌方怪物会在你不死亡的情况下重置。它偶尔也可以用来避免被锁定的法术施放，如果你在敌人完成施放之前消失的话。

### 奇袭潜行者属性优先级

2.6.

#### 奇袭潜行者的属性优先级

目前，无论是在团本还是大秘境中，你都应该按以下顺序优先考虑次要属性。有关本页面呈现内容的更多信息，请查看我们的主
[属性优先级页面](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>).

装备等级

暴击

急速

精通

全能

除了次要属性外，敏捷是迄今为止最重要的，这意味着任何物品等级的提升通常都是升级，无论次要属性如何。随着你获得新装备，次要属性的优先级会发生变化，我们强烈建议你自己进行模拟，以找出最适合你的属性。所有次要属性的价值都相当均衡，所以如果你获得一件精通/全能的装备，不要担心，它仍然是一件好装备，特别是如果它的物品等级高于你现在穿戴的装备。

### 暴风雪 单键循环

2.7.

#### 辅助高亮与单键助手，适用于 奇袭 潜行者

该 **单键助手** 系统为该专精及其众多按键提供了简单的入门方式，但这是有代价的。由于全局冷却时间的增加，你的DPS自然会降低。单键输出循环还缺少输出循环中的一些细微差别，以便让刚开始游戏之旅的玩家更容易上手，所以即使使用 **辅助高亮** 功能，你也会稍微落后于那些已经掌握该专精来龙去脉的玩家。

话虽如此，与最复杂和详细的输出循环玩法相比，DPS的差距并不像你想象的那么大。只要你正确使用你的冷却技能（单键助手不会这样做），你可以预期只比完美输出循环玩法少约5-10%的DPS。所以，如果你想在转向新手DPS输出循环之前先熟悉一下，使用辅助高亮甚至单键助手是一个很好的起点，特别是如果你刚刚迈出踏入《魔兽世界》的第一步。

遗憾的是，它目前在多目标战斗中不使用[[spell:1247227]]，这会导致巨大的 DPS 损失，除非你自己按下按钮来扩散你的流血效果。如果你想在地下城中使用单键助手，你需要这样做，否则会损失超过一半的 DPS。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对前夕补丁进行更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年9月6日：** 页面已更新，内容围绕套装进行撰写。
- **2025年8月4日：** 已针对11.2版本更新，添加了套装免责声明。
- **2025年6月15日：** 添加了关于战斗辅助功能的信息。
- **2025年4月21日：** 为大秘境切换至流血流派，并为11.1.5补丁复核了页面。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 已为地心之战11.0.5补丁更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核和更新。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月14日：** 更新了死亡印记和暗影之舞期间新优化的奇袭单体目标优先级。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年6月6日：** 为败血刃伤流派更新，在放血存在 bug 期间将其移除。
- **2023年5月1日：** 已针对10.1补丁更新。简化了循环优先级。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已针对巨龙时代10.0.5补丁更改进行更新。
- **2023年1月4日：** 更新了天赋配置。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面，你将找到魔兽世界 12.1.5 补丁中你的 奇袭 潜行者 的最佳天赋。我们还提供适用于各种内容类型的默认天赋方案，例如团队副本或大秘境。如果你开启了战争模式，我们也为你准备了 PvP 天赋。

1.

### 奇袭 潜行者 的最佳 至暗之夜 天赋

12.1 补丁中的 奇袭 潜行者 玩法与之前几乎相同，但我们的天赋推荐有所变化。我们再次回归使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手，因为它在所有内容中都拥有略高的持续单体和多目标输出潜力，优于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者。死亡猎手 也凭借英雄天赋之一的[[spell:457055]]打出惊人的优先目标伤害，这通常是该选项与另一英雄天赋树区别开来的关键。虽然管理[[spell:457052]]可能很繁琐，但一旦你点出这套天赋，你就能在技能栏上新增一个技能，让你可以轻松切换标记，当然有冷却时间。一定要好好利用它！

- **单体目标 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 是这里更好的选择，尤其是在当前的团队副本赛季中。从纸面上看， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 略强一些，但玩起来繁琐得多，更容易出错，即使在完美情况下，它最多也只多出 1-2% 的 DPS。考虑到这些因素，实在不值得推荐使用它。命缚者 的伤害几乎相同，更容易上手，可以更自由地使用[[spell:1966]]，而且整体上犯错空间小得多。
- **AoE -** 对于AoE和大秘境，这在很大程度上取决于你想推多高的层数。对于绝大多数层数， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 也是更好的选择，原因同上。然而，在打高层限时钥匙时，
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 是更好的选择。它的多目标输出与 命缚者 大致相当，但能够将额外伤害引导至主目标的能力非常有价值，且广受追捧。仅凭这一点就足以让它在这一特定环境中与竞争英雄天赋区分开来。

掌握了这些信息后， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 是几乎所有内容的推荐方案。

**快速开始导入代码：**

:::talents 奇袭 纯单体目标 - 命缚者
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYGzYMmZMMAGYBmxoxsBYbAbGAMzMGD"
}
```
:::

:::talents 奇袭 团本顺劈 - 命缚者
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AjxMjxYmZmxAYgFYGjGzGgtBsZAwMzgB"
}
```
:::

:::talents 奇袭 大秘境/地下堡 - 命缚者
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzMMA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

命缚者

纯单体目标

团本顺劈

推荐

群体伤害

秘境+

地下堡

死亡猎手

纯单体目标

团本顺劈

群体伤害

高层大秘境

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 纯单体目标方案

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 方案提供纯单体目标伤害，不点任何高价值的顺劈或多目标天赋，以完全优化单体 DPS。遗憾的是，这个副本中纯单体 Boss 并不多，所以你不会经常用到这套方案，即使在那些情况下， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 也只是表现更好的选择。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 团本顺劈方案

这是大多数可以偶尔进行顺劈的团本 Boss 的推荐方案。它仍然侧重于选择大多数单体天赋，但加入了[[spell:421975]]和[[spell:1247227]]，以确保你能在战斗中对额外的敌人做出贡献。

你可以在像这样的战斗中切换到纯单体构筑， [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
或 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)，如果你觉得额外的顺劈没有带来太多价值，但不推荐这样做。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 地下堡和大秘境方案

这是我们对大多数大秘境地下城的推荐方案，因为它不必担心处理[[spell:457052]]。它拥有与
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 相似的 DPS 潜力，更容易上手，需要你注意的循环怪癖更少，整体上是一段更加流畅和轻松的体验，而收益几乎相同。

只有在推最高层数的钥匙，或在非常特定的尖端开荒场景中，我们才会考虑切换到 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手构筑。

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手单体构筑

这是目前团本纯单体构筑，玩法为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手，牺牲了顺劈刷新小怪或额外目标的能力，以完全最大化其单体输出潜力。

我们只推荐在面对以下Boss时使用这个构筑： [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手团队顺劈构筑

这是针对大多数团队Boss的推荐构筑，在这些战斗中时不时可以顺劈到其他目标。它仍然侧重于选择大多数单体天赋，但加入了[[spell:421975]]和[[spell:1247227]]，以确保你能在战斗中对额外敌人做出贡献，同时借助[[spell:457055]]在这些情况下对优先目标造成更多伤害。

你可以在像这样的战斗中切换到纯单体构筑， [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
或 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)，如果你觉得额外的顺劈或引导伤害没有带来太多价值，但不推荐这样做。

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 大秘境+与宝库配装

这是我们专为高层钥匙打造的最强AoE构筑。它拥有惊人的集火目标能力，同时还拥有高持续AoE伤害，我们推荐你在有大规模AoE时使用这个构筑，甚至在有大量小怪的团本战斗中也可以使用，你可以利用它们将伤害引导到Boss身上。

然而，你必须兼顾相当多的额外循环优先级，并管理你的[[spell:457052]]，如果处理不当，会导致DPS大幅下降，因此这更多是一种在非常特定情况下使用的高级构筑。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYGzYMmZMMAGYBmxoxsBYbAbGAMzMGD"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUUmHhlFGGXXX11G-XbCEHRSsCNagg+CCGw8QposwJaKLrzD-AAAA-JQmUhpBIgwgxxC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AjxMjxYmZmxAYgFYGjGzGgtBsZAwMzgB"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGiCY4QaiS7D84pSooMPCLLMMuuuqrN-XbCEHTsCFNagq+ADCGw8MposwJKLrzD-AAAA-JQmUhpBIgwgxxC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzMMA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGimCY4QaiS7D84pSooMPLLMMuuuqrN-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-JQkUhpBIgwgxxC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYGzYMmZMMAbmlBGwCYZYCMsYwMDwYMA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUUmHhlFGGXXX11G-XbCEHRSsCNagg+CCGw8QposwJaKLrzD-AAAA-GIOQaAGIogBFmF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPwYMzYMmZGjBYzsMwAWALDTghFDmZAGjB"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUUmHhlFGGXXX11G-XbCEHSsELMagq+ADCGw8MposwJKLrzD-AAAA-GIOQaAGIogBFmF-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsZWGYALglhJwwiBzMAjxA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUmHhlFGGXXX1GnX-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-GIOQaAGIogBFmF-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

我们建议你选择以下增益，但由于你可以随时在它们之间自由切换，如果你觉得推荐的选项收益不够，可以自行尝试其他选项：

- 节点1：[[spell:1279599]]
- 节点 2：[[spell:1279603]]
- 节点3：[[spell:1287555]]
- 节点4：[[spell:1279610]]
- 节点5：[[spell:1279614]]

1.

### 巅峰天赋： ![Implacable Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_disembowel.jpg>) 不屈

至暗之夜为我们带来了一种新类型的天赋——巅峰天赋。这是一个4点天赋，允许你分配多个点数，根据投入的天赋点数提供不同的效果。奇袭获得了[[spell:1265385]]天赋，其效果如下：

- **第一点**：[[spell:1265385]]会在你施放毒刃时为你提供额外能量。
- **第二和第三点：**：[[spell:1265386]] 将为你提供额外的流血和自然伤害。
- 第四点：使用 [[spell:385627]] 时，[[spell:1265387]] 会造成额外伤害，并且你在接下来的一秒内还会被动获得 5 点连击点数。

我们的顶峰天赋稍微弥补了我们的弱点，让我们在能量耗尽时更快地恢复能量，类似于 [[spell:381623]] 已经实现的效果，这平滑了我们的输出循环，使我们不会长时间没有技能可按。[[spell:385627]] 的加成也相当不错，让我们在使用君王之灾后快速获得最大连击点数，而不必浪费另一个公共冷却时间在连击点数生成技能上。

总的来说，这是一套扎实的天赋，旨在让我们的弱点不那么明显，而不是进一步增强我们的优势。

1.

### 英雄天赋

奇袭 可以在两个不同的英雄天赋选择之间进行选择：
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 围绕着使用和施加 [[spell:457052]] 构建，它会对单个目标提供一系列好处，同时通过你进行的任何范围伤害（无论是多目标上毒还是仅仅是 [[spell:421975]]）获得更多的优先目标伤害。

如果你想要优化你的优先目标伤害，这是一个不错的选择，但管理 死亡猎手 的印记可能很麻烦，如果你因为切换目标而失去了它，你基本上就不再拥有英雄天赋了。这在那些会潜入但不清除减益效果的首领身上，或者在长时间从一个首领切换到另一个首领时，尤其糟糕。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 是一个宽容得多的选择，同时仍然提供与 死亡猎手 相似甚至更好的伤害。得益于增强的 [[spell:421975]]，它在范围伤害中也能跟上，并且围绕着翻转 命缚者 硬币的理念构建。这些硬币要么造成直接伤害，要么提升你所有职业技能的伤害。你对哪种硬币会为你叠加没有太多控制。虽然不是最华丽的英雄天赋选择，但它提供非常稳定的伤害，几乎不需要你额外的认知投入，使其成为一个非常适合新手的选择。

1.

### PvP天赋（战争模式）

在 至暗之夜 中，将会有进入“战争模式”的选项。启用战争模式提供以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

考虑到开启战争模式在升级和 PvE 内容中的好处，建议开启此功能以在满级时最大化你的升级速度和奖励。不过，你会使自己成为开放世界 PvP 的目标，在升级或做世界任务时存在被"偷袭"的可能性。

在本节中，我们将对最适合练级以及进行单人/小队PvE内容的PvP天赋进行排名。以下是通用PvP天赋和奇袭 潜行者专属PvE天赋的排名。

1. 当你的 [[spell:703]]、[[spell:1943]] 和致命毒药影响的目标时，使用 5 点连击点数的 [[spell:32645]] 会触发 [[spell:198145]]，造成自然伤害并将敌人的移动速度降低 90%，持续 2 秒。这相当不错，因为它是一个被动的伤害增益，并且在你没有其他控制选项可用时需要逃跑的情况下会很有用。
2. [[spell:354406]] - [[spell:408]]使用时会恢复能量，产生的能量多于消耗的能量。这使它相当值得使用，虽然从技术上讲，将连击点数用于伤害性终结技仍是更好的伤害输出，但额外的安全性对盗贼来说可能非常有价值，盗贼是练级时最脆弱的职业之一。
3. [[spell:354895]] 让你的 [[spell:32645]] 能够施加蔓延之毒，在 4 秒内造成自然伤害。当目标移动时，持续时间会刷新。这是另一个被动的伤害增加，也可以通过侧身移动导致敌人跟随你移动来轻松维持。
4.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对前夕补丁进行更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月13日：** 调整了11.2版本前的天赋套装推荐。
- **2025年8月4日：** 已针对11.2版本更新页面，为有无新套装的天赋推荐添加了标签。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年4月21日：** 为大秘境切换至流血流派，并为11.1.5补丁复核了页面。
- **2025年3月25日：** 根据3月25日的职业改动，更新了一些天赋推荐。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 为地心之战11.0.5补丁更新了天赋配装。
- **2024年9月9日：** 已针对第1赛季更新，移除了赛季前构筑。
- **2024年8月24日：** 新增了地下堡天赋构筑。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月8日：** 新增了带特技的DtB大秘境构筑。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 已针对10.1.7版本更新，采用新格式。
- **2023年7月16日：** 新增了AoE构筑天赋模拟链接。
- **2023年7月10日：** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年6月6日：** 更新为使用败血刃伤替换锯齿骨刺，并完全移除了放血。
- **2023年5月1日：** 已针对10.1补丁进行审核。推荐的天赋配置和天赋树保持不变，页面无需更新。
- **2023年3月26日：** 更新了大秘境天赋配置，新增了模拟器链接。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 已针对巨龙时代10.0.5补丁更改进行更新。
- **2023年1月4日：** 根据最新模拟结果更新了天赋推荐和说明。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面中，你将学习如何在单目标和多目标情况下优化你的 潜行者 奇袭 的输出循环。我们还提供了关于冷却时间、触发效果等的进阶部分，以最大化你的 DPS。我们所有的内容均已针对《魔兽世界》12.1.5 版本补丁更新。

1.

### 潜行者 奇袭 游戏玩法与循环指南

欢迎来到我们的 奇袭 盗贼循环页面。在这里你将了解在单目标和多目标情况下的循环优先级，这些优先级将应用于团队副本和大秘境场景。

以下每个部分都解释了不同环境下的循环和起手式。点击方框切换到所需的情况和英雄天赋选择。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手

团队副本构建

大秘境天赋构建

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者

团队副本构建

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

大秘境天赋构建

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

### 单体目标起手

[[spell:1784]]

[[spell:2823]]

[[spell:381664]]

[[spell:703]]

[[spell:1329]]

[[spell:1943]]

[[spell:703]]

[[spell:1329]]

[[spell:32645]]

[[spell:360194]]

[[item:241308]]

[[spell:26297]]

[[item:270175]]

[[spell:385627]]

**适用条件：命缚者（启用）。**

[[spell:32645]]

**适用条件：死亡猎手（启用）。**

[[spell:32645]]

[[spell:457058]]

[[spell:5938]]

**适用条件：命缚者（启用）。** 1.1.

#### **适用条件：命缚者（启用）。** 命缚者 单目标起手式

**适用条件：死亡猎手（启用）。** 1.2.

#### **适用条件：死亡猎手（启用）。** 死亡猎手 单目标起手式

务必确保从 [[spell:1784]] 状态起手，并且 [[spell:2823]] 和 [[spell:381664]] 处于激活状态。

1. 从潜行状态使用 [[spell:703]] 起手
2. 使用 [[spell:1329]] 直到你拥有 5 点以上连击点数
3. 使用 5 点以上连击点数施放 [[spell:1943]]
4. 施放 [[spell:703]] 以延长你的 [[spell:381632]]
5. 使用 [[spell:1329]] 积累到 5 点以上连击点数
6. 施放 [[spell:32645]]
7. 施放 [[spell:360194]]，并在此处使用任何药水、主动使用饰品或种族技能。
8. 施放 [[spell:385627]]
9. **适用条件：命缚者（启用）。** 继续在 5 点以上连击点数时施放 [[spell:32645]]，并使用 [[spell:1329]] 来积累连击点数。
10. **适用条件：死亡猎手（启用）。** 继续在 5 点以上连击点数时施放 [[spell:32645]]，并使用 [[spell:1329]] 来积累连击点数。当 [[spell:457058]] 激活时，务必在 7 点连击点数时施放毒伤。如果你恰好有 6 点连击点数，你应该使用 [[spell:5938]] 或 [[spell:51723]] 来达到 7 点连击点数。

这完成了你的起手式，之后你按照常规的循环优先级进行。

### 单体输出循环

**适用条件：命缚者（启用）。** 1.3.

#### **适用条件：命缚者（启用）。** 命缚者 单目标循环

**适用条件：命缚者（启用）。** 这是关于如何使用你的技能的一般优先级列表。这不是一个应该逐步遵循的列表；它只是为你提供一个关于在瞬息万变的游戏过程中优先考虑哪些事情的好主意，因为你经常会面临多个按哪个技能的选择。优先级列表只是突出了哪些技能比其他技能更重要。

1. **适用条件：命缚者（启用）。** 维持 [[spell:703]]。尽可能从 [[spell:1856]] 状态使用它（在每次 死亡印记 之前）。
2. **适用条件：命缚者（启用）。** 使用 5 点以上连击点数维持 [[spell:1943]]。
3. **适用条件：命缚者（启用）。** 可用时激活 [[spell:360194]]。
4. **适用条件：命缚者（启用）。** 冷却完毕时使用 [[spell:385627]]。确保与 死亡印记 同步使用。
5. **适用条件：命缚者（启用）。** 使用 5 点以上连击点数施放 [[spell:32645]]。
6. **适用条件：命缚者（启用）。** 每当可用时施放 [[spell:8676]] 来生成连击点数。
7. **适用条件：命缚者（启用）。** 施放 [[spell:1329]] 来生成连击点数。
8. **适用条件：命缚者（启用）。** 一旦目标超过 1 个，就使用 [[spell:51723]] 来积累连击点数。
9. **适用条件：命缚者（启用）。** 当能量较低时使用 [[spell:381623]]，或者简单地使用自动使用它的版本。两者没有区别。

**适用条件：死亡猎手（启用）。** 1.4.

#### **适用条件：死亡猎手（启用）。** 死亡猎手 单目标循环

**适用条件：死亡猎手（启用）。** 这是关于如何使用你的技能的一般优先级列表。这不是一个应该逐步遵循的列表；它只是为你提供一个关于在瞬息万变的游戏过程中优先考虑哪些事情的好主意，因为你经常会面临多个按哪个技能的选择。优先级列表只是突出了哪些技能比其他技能更重要。

1. **适用条件：死亡猎手（启用）。** 务必使用 [[spell:703]] 来施加 [[spell:457052]]。
2. **适用条件：死亡猎手（启用）。** 如果你需要切换目标并且距离 [[spell:457058]] 触发还有多个终结技的距离，请用 [[spell:1293340]] 替换你的 [[spell:457052]]。
3. **适用条件：死亡猎手（启用）。** 维持 [[spell:703]]，尽可能从 [[spell:1856]] 状态施放（在每次 死亡印记 之前）。
4. **适用条件：死亡猎手（启用）。** 使用 5 点以上连击点数维持 [[spell:1943]]。
5. **适用条件：死亡猎手（启用）。** 可用时激活 [[spell:360194]]。
6. **适用条件：死亡猎手（启用）。** 冷却完毕时使用 [[spell:385627]]。确保与 死亡印记 同步使用。
7. 冷却完毕时施放 [[spell:5938]]。
8. **适用条件：死亡猎手（启用）。** 使用 5 点以上连击点数施放 [[spell:32645]]。当 [[spell:457058]] 激活时，使用 7 点连击点数施放它。
9. **适用条件：死亡猎手（启用）。** 每当可用时施放 [[spell:8676]] 来生成连击点数。
10. **适用条件：死亡猎手（启用）。** 施放 [[spell:1329]] 来生成连击点数。
11. **适用条件：死亡猎手（启用）。** 一旦目标超过 1 个，就使用 [[spell:51723]] 来积累连击点数。
12. **适用条件：死亡猎手（启用）。** 当能量较低时使用 [[spell:381623]]，或者简单地使用自动使用它的版本。两者没有区别。
13. **适用条件：死亡猎手（启用）。** 如果你有 6 点连击点数且 [[spell:457058]] 可用，你可以使用 [[spell:5938]] 或 [[spell:51723]]。

### 多目标起手式

[[spell:1784]]

[[spell:2823]]

[[spell:381664]]

[[spell:703]]

[[spell:381632]]

[[spell:51723]]

[[spell:1943]]

[[spell:360194]]

[[item:241308]]

[[spell:26297]]

[[item:270175]]

[[spell:385627]]

[[spell:32645]]

[[spell:1247227]]

[[spell:1247227]]

[[spell:1247227]]

[[spell:1247227]]

**适用条件：命缚者（启用）。**

[[spell:32645]]

**适用条件：死亡猎手（启用）。**

[[spell:32645]]

[[spell:457058]]

[[spell:51723]]

**适用条件：命缚者（启用）。** 1.5.

#### **适用条件：命缚者（启用）。** 命缚者 范围伤害起手式

**适用条件：死亡猎手（启用）。** 1.6.

#### **适用条件：死亡猎手（启用）。** 死亡猎手 范围伤害起手式

务必确保从 [[spell:1784]] 状态起手，并且 [[spell:2823]] 和 [[spell:381664]] 处于激活状态。

1. 从潜行状态使用 [[spell:703]] 起手。施放两次以在 [[spell:381632]] 上获得最大的大流行收益
2. 施放 [[spell:51723]] 来生成连击点数
3. 使用 5 点以上连击点数施放 [[spell:1943]]
4. 施放 [[spell:360194]]，并在此处使用任何药水、主动使用饰品或种族技能。
5. 施放 [[spell:385627]]
6. 在 5 点以上连击点数时施放 [[spell:32645]]
7. 反复施放 [[spell:1247227]] 以将你的流血效果扩散到所有目标。在达到 5 点以上连击点数或所有目标都拥有所有流血效果时停止。
8. **适用条件：命缚者（启用）。** 继续在 5 点以上连击点数时施放 [[spell:32645]]，并使用 [[spell:51723]] 来积累连击点数。
9. **适用条件：死亡猎手（启用）。** 继续在 5 点以上连击点数时施放 [[spell:32645]]，并使用 [[spell:51723]] 来积累连击点数。当 [[spell:457058]] 激活时，务必在 7 点连击点数时施放毒伤。

记住在范围伤害中使用 [[spell:1247227]] 而不是 [[spell:51723]] 来积累连击点数，如果并非所有目标都已拥有你的所有流血效果。一旦你的起手式完成，遵循常规的范围伤害循环优先级。

### 多目标循环

**适用条件：死亡猎手（启用）。** 1.7.

#### **适用条件：死亡猎手（启用）。** 死亡猎手 多目标循环

**适用条件：命缚者（启用）。** 1.8.

#### **适用条件：命缚者（启用）。** 命缚者 多目标循环

1. **适用条件：死亡猎手（启用）。** 务必使用 [[spell:703]] 来施加 [[spell:457052]]。在起手式中施放两次以将 [[spell:381632]] 延长至最大持续时间。
2. **适用条件：死亡猎手（启用）。** 如果你需要切换目标并且距离 [[spell:457058]] 触发还有多个终结技的距离，请用 [[spell:1293340]] 替换你的 [[spell:457052]]。
3. 施放 [[spell:703]]，最好从 [[spell:1784]] 状态施放，并使用 5 点以上连击点数施放 [[spell:1943]]。
4. 使用 [[spell:1247227]] 作为你的范围伤害生成技能，在所有目标上维持 [[spell:703]] 和 [[spell:1943]]。
5. 使用 [[spell:1247227]] 作为你的范围伤害生成技能来扩散流血效果。如果所有目标都已有流血效果，一旦目标超过 1 个就改用 [[spell:51723]]。
6. 可用时激活 [[spell:360194]]。
7. 冷却完毕时使用 [[spell:385627]]（如果点了天赋）。如果 死亡印记 准备好了，确保与之同步使用。
8. 如果你的初始持续伤害效果即将结束，并且这波怪物还能存活约 20 秒以上，使用 [[spell:1856]] 来重新施加被 [[spell:381632]] 增强的 [[spell:703]]。
9. **适用条件：命缚者（启用）。** 使用 5 点以上连击点数施放 [[spell:32645]]。
10. **适用条件：死亡猎手（启用）。** 使用 5 点以上连击点数施放 [[spell:32645]]。当 [[spell:457058]] 激活时，使用 7 点连击点数施放它。如果你恰好有 6 点连击点数，使用 [[spell:5938]] 来达到 7 点连击点数。
11. 当能量较低时使用 [[spell:381623]]，或者简单地使用自动使用它的版本。两者没有区别。
12. **适用条件：死亡猎手（启用）。** 如果你有 6 点连击点数且 [[spell:457058]] 可用，即使在单目标情况下，你也可以使用 [[spell:5938]] 或 [[spell:51723]]。
13.

### 至暗之夜 第2赛季套装

至暗之夜 第 2 赛季套装，[[spell:1296590]] 和 [[spell:1296591]]，对我们的循环没有任何影响。它只是提升了我们的伤害输出，所以获得它后游戏玩法没有任何变化。

1.

### 职业与专精机制详解

为了更好地解释 潜行者 奇袭 技能包的具体用法和好处，我们整理了关于循环各个部分的更详细说明，从你需要注意的重要循环机制到冷却时间及其使用方法，以便你在游玩 奇袭 时能发挥全部潜力。

### 毒伤衔接

3.1.

#### 毒伤衔接

衔接 [[spell:32645]] 是 潜行者 奇袭 游戏玩法的核心方面。这指的是在上一个毒伤仍然激活时施放毒伤的机制，而不是在施放新毒伤之前让毒伤的短持续时间增益消失。奇袭 有各种天赋和被动技能可以在上一个毒伤仍然激活时施放毒伤来提升你的 DPS，但你需要特别注意不要过早这样做。

支持这种玩法的一些天赋包括：

- **[[spell:1250036]]**
  
  
  
  
  树底部的一个新的选择节点天赋，在连续施放毒伤时增强我们所有的职业伤害。
- **[[spell:1250318]]**
  
  
  
  
  振奋打击的替代天赋，在正确衔接时改为给予1个连击点数。
- **[[spell:455072]]**
  
  
  
  
  这个天赋得到了大幅增强，在衔接时提供更高的毒伤伤害。

### 巅峰天赋：坚不可摧

3.2.

#### 巅峰天赋：坚不可摧

至暗之夜 为我们提供了一种新型天赋，顶峰天赋。这是一个 4 点天赋，允许你分配多个点数，根据你投入的天赋点数提供不同的效果。奇袭 获得了 [[spell:1265385]] 天赋，其效果如下：

- **第一点**：[[spell:1265385]]会在你施放毒刃时为你提供额外能量。
- **第二和第三点：**：[[spell:1265386]] 将为你提供额外的流血和自然伤害。
- **第四点：** 使用 [[spell:385627]] 时，[[spell:1265387]] 会造成额外伤害，并且你在接下来的一秒内还会被动获得 5 点连击点数。

我们的顶峰天赋稍微弥补了我们的弱点，让我们更快地恢复能量，这平滑了我们的输出循环，使我们不会长时间没有技能可按。[[spell:385627]] 的加成也相当不错，让我们在使用君王之灾后快速获得最大连击点数，而不必浪费另一个公共冷却时间在连击点数生成技能上。

总的来说，这是一套扎实的天赋，旨在让我们的弱点不那么明显，而不是进一步增强我们的优势。

### 大流行

3.3.

#### 大流行

大流行是适用于所有具有持续时间的增益和减益效果的全游戏机制。当你在 [[spell:1943]]、[[spell:703]] 或 [[spell:315496]] 过期之前刷新它们时，剩余持续时间会添加到新施加的效果中，最多为新施加基础持续时间的 30%。

**示例** — 当 5 点连击点数的割裂剩余 7.2 秒或更少时，你可以安全地刷新它，因为它的基础持续时间是 24 秒。[[spell:193531]] 允许 6 点连击点数的割裂，持续 28 秒。6 点连击点数的割裂在剩余 8.4 秒或更少时可以安全刷新。有了 [[spell:457512]] 和 7 点最大连击点数，这变为 9.6 秒。

安全的大流行刷新时机基于 **新施加的基础持续时间** 而不是效果的原始长度。因此，2 点连击点数的割裂仍然可以从 **完整的** 大流行中受益，如果它被 5 到 7 点连击点数的割裂刷新的话。

这是在整个游戏过程中需要注意的重要机制，因为让你的流血效果完全消失会让你损失能量，而如前一节所述，衔接毒伤对你的 DPS 是巨大的提升。

### 能量囤积

3.4.

#### 能量囤积

“囤积”你的能量和连击点数可能非常有益，这涉及在能量恢复时进行自动攻击。这提供的优势是可变的，意味着囤积并不总是带来伤害增益。囤积能量和连击点数有益的情况包括：

- 在你的毒伤衔接中断后，你可能希望等到高能量再重新开始这个过程
- 在重要的小怪生成之前，以便你能施加尽可能多的即时压力
- 即将到来的特定战斗增益或伤害阶段

囤积能量本身并不是神奇的 DPS 增益。它允许你稍微调整技能的时机，以便在伤害增加期间塞入更多攻击，前提是你能正确识别此类期间何时会发生。

### 死亡猎手标记

3.5.

#### 死亡猎手标记

在游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手 英雄天赋树时，你将围绕你的 [[spell:457052]] 和 [[spell:457058]] 减益和增益效果进行游戏。印记应用于单个敌人，每当你施放终结技时，你会将其计数降低一。一旦消耗，你将获得 **至黑之夜** 这会大幅提升你下一个 [[spell:32645]] 的伤害，同时将印记重新施加到你施放它的目标上。

你需要确保自己对死亡猎手的印记的覆盖时间接近100%。例如，虽然能量规划是你游戏玩法的重要方面，但如果这意味着你的印记长时间不处于激活状态，就不要这样做。

在以下场景中，难度还会进一步增加： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手在需要频繁切换目标的战斗中，或者当Boss潜入地下而未清除其debuff时。为了仍然从你的英雄天赋选择中获益，你需要确保在Boss消失或新目标出现之前获得一次[[spell:457058]]触发，这样你就可以迅速将印记转移到新目标上。在非常难以做到这一点的战斗中，你可能更适合玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者。

你可以使用[[spell:1293340]]技能来交换你的印记，该技能会在你天赋点出死亡猎手后自动学会。这在你距离触发至黑之夜还需要多个终结技时，或者意外出现add时非常有用，可以帮助你更换印记。

### 快照

3.6.

#### 快照

[[spell:381632]]的伤害增益会在你重新施加一个未强化的流血效果覆盖你已强化的流血效果时被移除。因此，最好让DoT持续完整个持续时间后再刷新它。这个额外伤害在[[spell:360194]]期间会翻倍。

1.

### 奇袭 潜行者的重要冷却技能

### [[spell:360194]]

4.1.

#### 死亡印记

[[spell:360194]]是我们的主要冷却技能，每2分钟可用一次。它会增加你流血效果的伤害，并复制你的毒药触发，从而让你更快地叠加[[spell:385627]]层数。至关重要的是要确保你在持续时间内对不会死亡的目标使用死亡印记。

有时，不在冷却技能一好时就使用死亡印记可能会更有利。你可能想先积攒一点能量，以确保在持续时间内能使用每一个公共冷却技能，并且你需要关注即将到来的Boss机制，这些机制可能会迫使你离开近战范围。由于它是2分钟的冷却技能，你可以安全地延迟死亡印记，前提是这不会导致你在整场战斗或副本流程中损失一次完整的使用机会。

例如，在一场7分钟的战斗中，无论你在开怪时使用死亡印记然后每2分钟使用一次，还是延迟一次施法在开怪时、2分30秒、4分30秒和6分30秒使用，都没有区别。死亡印记的施放次数是相同的。

同理，如果延迟冷却时间能让它与敌人触发[[spell:381798]]的血量阈值对齐，也应如此。尽量避免在Boss血量40%时使用死亡标记，可以稍作延迟以获得完整的斩杀收益——只要你在战斗结束前不会少打一次施放。

### [[spell:385627]]

4.2.

#### 君王之灾

[[spell:385627]]是一个1分钟的冷却技能，我们希望尽可能在冷却好时就使用。它造成直接伤害，然后是持续伤害，而且它的DoT跳动频率不随急速加成而变化。

持续伤害会随着每次毒药触发而增加，直到达到上限，这使得它与死亡印记的毒药复制效果配合得非常好。在君王之灾运行期间，保持100%的近战覆盖时间和100%的[[spell:32645]]覆盖时间绝对至关重要。与死亡印记类似，延迟君王之灾可能有利，但由于它是1分钟的冷却技能，在不损失一次完整施放的情况下很难做到这一点。

这就是我们超强的生存工具包发挥作用的地方。像[[spell:5277]]或[[spell:31224]]这样的技能让我们可以无视某些机制而不被击中或受到影响，而其他近战DPS可能不得不远离Boss以避免受到致命伤害，我们可以安全地保持覆盖时间以进一步提升我们的DPS。这使得这些防御技能在某些战斗中充当DPS增益，围绕它们的使用进行规划以潜在地与危险的Boss机制重叠，是区分优秀和出色的奇袭 潜行者的关键。

### [[spell:381623]]

4.3.

#### 蓟叶茶

[[spell:381623]]是一个多充能技能，每分钟恢复一个充能。使用时会给予能量，在Boss伤害增益阶段维持毒伤连击点，或确保在你的[[spell:360194]]期间使用每一个公共冷却技能时非常有用。它在能量低于30时自动激活，手动操控它没有任何好处。

### [[spell:2094]]

4.4.

#### 致盲

[[spell:2094]]不是我们DPS工具包的一部分，但在大秘境中仍有一些可能不那么明显的有趣用途。虽然[[spell:6770]]允许玩家安全地通过被控制的生物而不进入战斗，但被致盲的敌人会困惑地四处走动，并且仍然会与 **第一个** 靠近它的玩家进入战斗。一旦致盲debuff结束，它就会攻击该玩家。然而，它不会与任何其他靠近它的玩家进入战斗。

你仍然可以很好地利用致盲来通过敌人，利用只有一个玩家会与它进入战斗的事实。做到这一点最好也最简单的方法是，在致盲目标后，确保你靠近到足以进入战斗，然后你和你的整个队伍就可以通过这个敌人。一旦你离它足够远，你就可以安全地[[spell:1856]]，脱离战斗，并跳过这个敌人。

这在有一整群敌人挡在你面前而你想跳过，但有一两个敌人太近以至于无法在不引到它们的情况下通过时特别有用。作为一个潜行者，你可以[[spell:6770]]一个，然后用上面的技巧处理另一个，让你可以跳过那些如果你使用[[spell:114018]]就会发现你，或者帷幕在冷却中的敌人。

4.5.

#### 防御实用性

所有潜行者都有相当数量的防御冷却技能，使他们成为承受必要机制和应对大量伤害的最佳人选。

- [[spell:1966]]在6秒内将受到的范围伤害降低40%，只需35点能量。在天赋点出[[spell:79008]]后，它还会将所有其他伤害降低20%，并为[[spell:5277]]提供20%的伤害减免。这是游戏中最超模的技能之一，在有大量团队伤害的战斗中是巨大的优势。
- [[spell:31224]]提供1秒的魔法免疫，随后4秒内所有法术都会未命中你。暗影斗篷有多种用途，包括先发制人和被动应对，例如单独承受机制或清除会迫使你离开近战范围的debuff。
- [[spell:5277]]在10秒内使你的闪避几率提高100%。如果你需要为几秒钟承受一些add或Boss的攻击，这可能很有用。在极少数情况下，它可以用来抵消物理远程攻击或法术。
- [[spell:31230]]是一个天赋，允许你每6分钟逃脱一次致命伤害。伤害不能超过你最大生命值的两倍。装死对于承受穿透免疫和减伤的机制非常有用，因为它保证你的生存。它对于有爆发性伤害可能让你措手不及的战斗也很有用，因为你至少能在战斗中获得一次免费的保命机会。
- [[spell:185311]]在30秒的冷却时间内提供可观的治疗量。

不要忘记这个防御工具包，因为它可能是个人和团队生存能力的主要优势，甚至可以用来留在危险区域以造成更多伤害。

1.

### 毒药

你的 **致命毒药** 应该始终是[[spell:2823]]和[[spell:381664]]。

你有三种非致命毒药的选择：[[spell:3408]]、[[spell:381637]]和[[spell:5761]]。对于团本，你将需要使用 **萎缩药膏**
，除非你的团队希望你减缓特定的目标群。对于大秘境，你将需要使用最适合你坦克需求的毒药。麻痹药膏让你的坦克更容易风筝敌人，而迟钝药膏减缓他们的攻击速度，衰弱药膏则减少团队从敌人攻击和法术中受到的伤害。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 更新了针对 锁喉 Snapshot 的起手式。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对前夕补丁进行更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年9月6日：** 页面已更新，包含简化的循环改动。
- **2025年9月3日：** 澄清了 命缚者 Shiv 的使用方法。
- **2025年8月18日：** 澄清了未点出君王之灾时死亡猎手的群体伤害输出循环。
- **2025年8月4日：** 已针对11.2版本更新本页面，详细说明了命缚者和死亡猎手的套装影响。
- **2025年6月15日：** 添加了关于战斗辅助功能的信息。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025年3月25日：** 根据3月25日的职业改动，更新了输出循环优先级。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 已针对11.0.5补丁的玩法改动进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月14日：** 更新了新优化的单体目标起手式。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年6月6日：** 更新了败血刃伤的玩法信息。
- **2023年5月1日：** 10.1补丁无需更改循环。新增了循环速查指南。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已针对巨龙时代10.0.5补丁更改进行更新。
- **2023年1月4日：** 更新了死印和君王之灾天赋配置的循环优先级。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到魔兽世界12.1.5中你的奇袭 潜行者的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们应有尽有！

1.

### 奇袭 潜行者毕业装备指南

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含奇袭 潜行者来自所有来源的最高DPS配置。请注意，还有许多其他配置在误差范围内表现相当。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
你将想要尝试优先获取 **肩膀、胸部、腿部和手套** 套装部件。然而，获取头盔以完成其中一个加成仍然比任何其他装备选择都要好。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 的变化，当你催化套装部件时，你还保留了次要属性和任何其他潜在的被动效果，如伤害触发。这意味着我们想要尝试催化那些能确保我们在装备上获得最佳可能次要属性的物品，但如果不可能的话，这也没什么大不了的。拥有次要属性稍差的套装并在赛季后期修复它，比错过一两周的加成要好。一些适合催化的好属性物品包括：

- 头盔：[[item:271875]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:251223]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 胸部：[[item:281236]]来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 手套：[[item:251124]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 腿部：[[item:268225]]，来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

从技术上讲，手套不需要被催化，因为它们已经有最佳的基础属性。

:::

:::details 常见问题：从宏伟宝库中获取什么？
一般来说，你的目标应该是尽快获取一把好武器、你的毕业饰品，当然还有你的新四件套加成。然而，有一种替代策略可能最终会有些取巧，但如果你的进度最终需要几周或几个月，它可能会有所回报。

你可以选择不从宏伟宝库中选择物品，而是简单地获取一个 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)。这让你可以在任何地下城或Boss身上使用额外拾取，并获得该物品的1/6神话品质版本。在 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) Boss身上在英雄难度下这样做，将保证你获得你的武器、头盔、项链和两个非常好的饰品，两者都是你的毕业饰品。

虽然由于这些物品需要纹章来完全升级，这可能会稍微减慢你的物品等级进度，但它将允许你在实际以神话难度击杀团本最终Boss之前很久就获得你所有绝对最好的物品。请注意，从神话难度掉落的物品将是9/6神话品质，而额外拾取的物品最高只能到6/6。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271875@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240914]][[item:273068]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271093@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237837@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 秘境+

本列表包含使用第 2 赛季大秘境可刷取装备的最高 DPS 配置。

此列表绝不能替代 **模拟你自己**。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
你将想要尝试优先获取 **肩膀、胸部、腿部和手套** 套装部件。然而，获取头盔以完成其中一个加成仍然比任何其他装备选择都要好。长期来看，你将想要使用来自 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 的特定头盔。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装部件时也会保留副属性和任何其他潜在的被动效果，如伤害触发。这意味着我们要尝试催化那些确保我们在装备上获得最佳副属性的物品，但如果不可能的话，也没关系。拥有属性稍次的套装并在赛季后期修复，比错过一两周的套装加成要好。一些催化时属性最佳的物品有：

- 头部：[[item:273791]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 肩部：[[item:251223]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 胸部：[[item:251159]]，来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 手套：[[item:251124]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 腿部：[[item:251130]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

从技术上讲，手套、头盔和腿部不需要被催化，因为它们已经有良好的基础属性。

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>), [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>), [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)：掉落多个高价值物品。
- **武器**：尝试运行 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) 以获得一把带有特殊效果的漂亮匕首。
- **饰品**: [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>) 和 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>) 掉落你最好的地下城饰品，尽管少数团本选项往往要强得多。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:273791@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>项链</th><td>[[item:273781@JAACAAAOyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>腰部</th><td>[[item:159301@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271509@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>脚部</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250259@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:240914]][[item:273068]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237837@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 团队副本

此列表包含最高DPS配置，仅显示来自剧毒深渊团本的装备。

此列表绝不能替代 **模拟你自己**。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
你将想要尝试优先获取 **肩膀、胸部、腿部和手套** 套装部件。然而，获取头盔以完成其中一个加成仍然比任何其他装备选择都要好。长期来看，你将想要使用来自 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 的特定头盔。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装部件时也会保留副属性和任何其他潜在的被动效果，如伤害触发。这意味着我们要尝试催化那些确保我们在装备上获得最佳副属性的物品，但如果不可能的话，也没关系。拥有属性稍次的套装并在赛季后期修复，比错过一两周的套装加成要好。一些催化时属性最佳的物品有：

- 头盔：[[item:271875]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:268246]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 胸部：[[item:281236]]来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 手套：我们想要这些来自代币
- 腿部：[[item:268225]]，来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

从技术上讲，只有手套和头盔真正需要被催化，其他部位都已经有不错的基础属性。在这个新系统下，强烈建议获取几个大秘境装备来催化以获得好的副属性。

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:271093@JAACAAAG2A]]：我们的毕业主手，如果你能在神话品质获得它的话。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270175@JAACAAAG2A]]：我们最好的饰品。也掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270164]]：我们最好的被动饰品。
- 荣誉提名：来自巢穴Boss的[[item:268266]] [尼姆瑞莎·唤波者](<https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa>)。如果你作为一个团队这样做，你真的很需要这个戒指提供的急速。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271875@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:240914]][[item:273068]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271093@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:237837@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 奇袭 潜行者饰品推荐

奇袭有大量可用的饰品，我们总是希望使用一个强大的主动饰品如[[item:270175]]或[[item:159617]]，以及一个提供强大次要属性加成或原始伤害触发的被动饰品的组合。确保
[宏](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)
你的主动使用饰品 [[spell:360194]] 施放！

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **奇袭 潜行者饰品**
**使用型 -**

[[item:270175]]

或者，作为替代，

[[item:159617]]

**被动 -**

[[item:281215]]

或者，作为替代，

[[item:270168]]

:::

还有相当多其他有价值的饰品，所以请务必查看我们的排名图表，看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看奇袭 潜行者饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]] - 毕业</li>&#10;<li>[[item:281215]] - 毕业</li>&#10;<li>[[item:270168]] - 略逊于触须</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>&#10;&#10;&#10;[[item:270173]] - <span><em>点击查看详情</em></span>&#10;<span>[[item:270168]]的可行替代品，在单体目标中更强，但我们无法完成套装加成，所以你不太可能从团本中获得它。&#10;       </span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164]] - <span><em>点击查看详情</em></span>&#10;<span>一个强大的被动饰品，在任何环境中都表现出色。尽管在第二赛季开始前被削弱，它仍然是我们最好的选择之一，如果你不想根据目标数量更换饰品的话。&#10;       </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:159617]] - <span><em>点击查看详情</em></span>&#10;<span>我们从大秘境来源获得的最好主动饰品。值得在早期刷取，直到你能弄到一个[[item:270175]]。&#10;       </span>&#10;</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>&#10;&#10;&#10;[[item:250225]] - <span><em>点击查看详情</em></span>&#10;<span>另一个来自大秘境的主动饰品，但比华贵金羽弱。&#10;       </span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250259]] - <span><em>点击查看详情</em></span>&#10;<span>在单体目标和双目标战斗中非常强，但在AOE中很快失去价值。&#10;        </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:250214]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>地下堡饰品</li>&#10;<li>[[item:158374]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>任何其他未列出的饰品。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

12.1版本延续了在12.0.7版本中首次引入的额外拾取系统。值得注意的是，对英雄难度团队副本Boss使用额外拾取将使你获得1/6神话等级的物品，因此只要你投入额外的纹章来升级它，就可以相当早地获得一些后期团队副本装备。

**[朦胧虚空核心](<https://www.wowhead.com/currency=3418>)** 可以在完成地下城或击杀团队副本Boss后使用，它会从地下城或Boss的掉落列表中随机奖励你一件物品。一旦通过虚空核拾取获得了一件物品，当你再次对同一Boss或地下城使用额外拾取时，该物品就不会再次出现。

8周后，你还将免费获得一个额外的虚空核心，来源为
**奥琳·微光** 免费获得一个额外的虚空核，该NPC位于银月城的催化器旁边。这将在12.1.5版本上线时发生。

3.1.

#### 奇袭 潜行者推荐的朦胧虚空核心使用

你想追求哪件装备，在很大程度上取决于你已经通过（例如） [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)，或者你是否期望以神话难度击败某些Boss以在9/6神话物品等级获得它们。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 神话[[item:271093]]
2. 神话[[item:270175]]
3. 剩余的毕业装备列表物品

:::

在一个新角色上，我们建议刷那些掉落大量套装部位的地下城，比如来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)，即使你的roll“失败”了，你也能在那里获得一些不错的饰品。套装槽位的物品可以通过催化快速获得多件神话追踪器套装物品，无需依赖大秘境宝库。 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
也会掉落不错的物品，包括一件武器、一件戒指和一条项链，它们将非常实用。最终的最佳选择取决于你从大秘境宝库和潜在团队Boss中已经获得的装备。

3.2.

#### 晋升毒液石

使用你的[[item:280562]]遵循与使用徽记类似的优先级列表。请注意，你无法进一步升级来自史诗乌拉特克和盘绕祭坛的已是344的物品，因为神话追踪器物品的新最高物品等级为340，制造物品为338。

1. 你的主手武器是最高优先级
2. 你的主动使用饰品
3. 你的被动饰品
4. 你的副手武器
5. 你的项链

你还需要优先考虑神话追踪器物品而非英雄追踪器物品，除非你预计无法获得该物品的神话追踪器版本。也就是说，如果你不预计很快击杀史诗乌拉特克或为史诗版本进行额外掉落，升级英雄追踪器的[[item:270175]]或[[item:270168]]是可以的。

1.

### 奇袭潜行者最佳制造物品

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

由于在至暗之夜初期阶段你的制造能力会受到时间限制，我们强烈建议获取一个 **主手武器** 尽早获取，除非你能在其他地方可靠地获得。一旦你有了不错的武器，接下来就制作你的另一件附魔装备，然后制作你还没有高品质版本的装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **奇袭制造装备优先级**
- [[item:237837]]搭配[[item:273060]]
- [[item:244576]]搭配[[item:273069]]
- 任何你尚未获得神话级的物品。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 奇袭潜行者最佳镶嵌效果

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

由于衬饰的竞争非常激烈，你必须为你整体的DPS输出挑选出最强的两个。大多数衬饰提供的DPS收益非常相似，即使效果完全不同。对此最佳的两个选择是：

- 团队副本：武器上使用[[item:273060]]，另一件制造物品（如护腕）上使用[[item:273069]]。
- 对于大秘境：在武器上使用[[item:273060]]，在另一件制造装备（如护腕）上使用[[item:273069]]。

建议你进行模拟，找出最适合你的方案。如果你还玩其他两个潜行者专精，你可能想要选择对三者都适用的装饰。

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于纹章每周获取量有限，而且升级不同物品所花费的纹章数量相同，你应该优先将纹章用在那些你短期内不打算更换的物品上，或是能带来最大收益的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **奇袭 潜行者 升级纹章优先级**
**武器（主手）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些并不是唯一值得升级的装备。它们只是在赛季初期、你的升级货币有限时能提供最高DPS收益的装备。请注意，例外情况是可能存在的，例如附带额外触发效果的特殊装备。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月25日：** 更新了饰品排名。
- **2026年8月18日：** 已针对第2赛季上线以及最近的装备削弱和改动进行更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 更新了饰品推荐。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对前夕补丁进行更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已针对11.2.5补丁更新了信息，添加了谜之财团筹码部分，移除了DISC腰带部分。
- **2025年8月13日：** 添加了关于虚空棱晶的信息。
- **2025年8月4日：** 已针对11.2版本和地心之战第3赛季更新。添加了所有新的毕业装备列表。移除了关于瑟西斯的指环和令人费解的卡特尔筹码的信息。添加了关于蕾希裹布的信息。
- **2025年6月21日：** 已针对6月20日的在线修正更新戒律牧推荐。
- **2025年6月15日：** 为11.1.7版本添加了关于戒律牧腰带的信息。
- **2025年4月21日：** 已更新至11.1.5补丁，新增了令人费解的财团代币建议。
- **2025年3月25日：** 根据3月25日的饰品调整，更新了一些装备推荐。
- **2025年3月13日：** 已针对机械核心和废品大师饰品进行更新。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月25日：** 更新了塞尔赛斯指环的宝石推荐。
- **2024年12月17日：** 已针对塞尔赛斯指环的强化进行更新。
- **2024年12月15日：** 为11.0.7补丁新增了塞尔赛斯指环信息。
- **2024年10月21日：** 页面已为11.0.5补丁复核。
- **2024年9月9日：** 已针对地心之战第1赛季更新，包含毕业装备和美化。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。新增了鎏金和饰品部分。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月7日：** 已针对孢子披风削弱进行更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 已针对10.1.7版本更新，新增了多份毕业装备列表。
- **2023年7月16日：** 更新了永恒黎明部分，时之隙毕业装备。
- **2023年7月10日：** 新增了永恒黎明部分，移除了大灾变漫游部分，针对10.1.5版本更新了永恒之戒部分。
- **2023年6月6日：** 更新了美化推荐。
- **2023年5月24日：** 添加了时光漫游信息。
- **2023年5月14日：** 已更新饰品推荐。
- **2023年5月7日：** 根据最近的热修更新了美化推荐。
- **2023年5月1日：** 页面已针对10.1补丁全面更新。新增了飞龙石和纹章信息，新增了第2赛季毕业装备及推荐、毕业美化推荐等内容。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了地下城装备列表，新增了毕业列表免责声明和团本饰品。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的奇袭 潜行者的最佳属性优先级。我们首先介绍属性优先级，然后深入讲解属性如何与你的专精和游戏玩法相互作用。我们的内容已针对《魔兽世界》12.1.5补丁更新。

1.

### 奇袭潜行者属性优先级

对于团队副本和大秘境，奇袭 潜行者的次要属性优先级如下：

装备等级

暴击

急速

精通

全能

除了全能之外，所有属性在表现上都非常接近，而装等是最重要的因素，因为它提供更高的敏捷。戒指和项链是例外，因为它们不提供敏捷。

你的配装策略的总体目标是尽可能多地获得急速和暴击，同时完全避免全能。

1.

### 深入属性解析

**敏捷** 是你的主要属性。你应该在所有升级中寻找它。它为你提供攻击强度，决定了你技能的伤害。

**精通** 提高你的毒药和流血伤害（通过[[spell:76803]]）。它还影响所有自然伤害类技能，如[[spell:5938]]、[[spell:255544]]和[[spell:32645]]。

**暴击** 提高你的攻击暴击几率。作为奇袭 潜行者，该属性还能通过[[spell:14190]]为你提供额外的连击点数。

**全能** 是纯粹的造成伤害提升和承受伤害降低。

**急速** 为你提供更高的攻击速度和能量回复。它还提高你的持续伤害效果的跳动频率，从而通过[[spell:79134]]获得更多能量。

:::details 常见问题：奇袭 潜行者有急速上限吗？
奇袭对于急速或其他任何属性都没有阈值。然而，随着你获得的属性越多，属性的价值会递减，所以请尽量在你最看重的属性之间保持良好平衡。

:::

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对前夕补丁进行更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 针对11.2版本审核了本页面，无需更改。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 页面已为11.0.5补丁复核。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年5月1日：** 10.1补丁未更改属性优先级。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了属性优先级，新增了低装等下急速的免责声明。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页，我们列出了你的奇袭 潜行者可以使用的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你应该在一个插槽中使用[[item:240983]]。或者你也可以选择不使用棱彩宝石，这样你可以改为堆叠更多同色的次要属性宝石。这里的差别非常小，所以你可以选择最适合你钱包的选择。

对于你的次要属性宝石，选择暴击或急速宝石，如[[item:240890]]或[[item:240906]]。如果你打算使用棱彩宝石来获得微量的暴击伤害加成，请确保至少获取每种宝石类型各一颗，如[[item:240914]]和[[item:240898]]，然后用我们之前列出的更高价值的宝石填满剩余的插槽。

你可能需要根据装备上的属性稍微调整属性和消耗品。例如，如果你有一件急速非常高的装备，如[[item:271875]]或[[item:268266]]，你可能想选择高暴击宝石和暴击合剂，否则就从这些来源获取急速。

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>主手</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>使用[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>副手</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>使用[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243981]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>胸部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

你选择用闪避、吸血还是急速附魔装备取决于你自己。吸血会允许你在造成伤害时获得一些额外的被动治疗，闪避减少范围法术造成的伤害，类似于[[spell:1966]]，而急速只是提高你的移动速度。在团队副本开荒中，移动速度经常被低估，如果它能让你更快到达目标，可以带来小幅的DPS提升。

始终建议你进行模拟，以找出哪些附魔能为你个人提供最佳收益。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

你应该选择 [[item:241325]] 作为你的首选药水来获取急速加成。不过，如果你的急速等级已经非常高，也就是说你的每件装备上都带有急速属性，那么暴击药水 [[item:241326]] 会稍微好一些。

你也可以从炼金术士提供的[[item:241319]]中获得你选择的合剂。

3.2.

#### 药水

[[item:241308]]是你的最佳选择，应与主要冷却技能和[[spell:2825]] / [[spell:32182]]配合使用。你也可以从炼金术士提供的[[item:241285]]中获得该药水的临时版本。

在第2赛季中，你现在可以使用[[item:271883]]，它明显优于[[item:241305]]。使用它有5分钟冷却时间，但如果首领战持续足够长，可以消耗多个。此外，术士的[[item:5512]]与其他治疗消耗品不共享冷却时间。如果你带着一个，记得也使用它！

3.3.

#### 食物增益

如果可能的话，尽量吃下[[item:255845]]或其他主属性盛宴。如果团队没有提供，就用[[item:242275]]作为你的个人食物。

3.4.

#### 强化符文

此外，如果负担得起，你应该使用 [[item:259085]] 来提高你的主属性。强化符文价格昂贵且死亡后消失，所以请明智而节制地使用它们！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月24日：** 更新了戒指附魔。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对前夕补丁进行更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月16日：** 为命缚者的暴击需求添加了说明。
- **2025年8月4日：** 移除了腐蚀部分，并审核了11.2版本的信息。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年5月20日：** 更新了惊魂幻象附魔部分，推荐回响虚空。
- **2025年4月21日：** 新增了惊魂幻境附魔信息，并为11.1.5复核了页面。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 页面已为11.0.5补丁复核。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 更新了关于黑曜石指环的段落，在10.1.5版本指环削弱后不再推荐刷取它。
- **2023年6月6日：** 添加了腰带扣环和光耀护甲片作为腿部附魔的替代方案。添加了腐化之怒药剂的讨论。
- **2023年5月1日：** 已针对10.1补丁进行审核。更新了奥妮克希亚的印记推荐。
- **2023年3月26日：** 根据最新热修更新了原始宝石推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了护甲片，新增了幸运饼干食物。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的奇袭 潜行者挑战大秘境地下城的技巧和建议。

1.

### 奇袭 潜行者在至暗之夜第2赛季的大秘境中

奇袭在大秘境中的玩法围绕着在多个目标上施加流血效果，提升你的能量回复，然后在目标之间循环流血效果，同时优先对单个目标使用高伤害终结技。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

奇袭AOE的一个关键特点是，虽然在多个目标之间均匀地施加持续伤害效果最为理想；但你仍然可以将伤害集中在单个目标上，多亏了[[spell:421975]]，这些伤害会溅射到附近的目标身上。额外的资源生成将使你能够弥补单体DPS上的牺牲，因此奇袭拥有游戏中最好的优先目标伤害输出之一。你可以根据自己的喜好选择任意英雄天赋专精来玩，在大秘境中，两者之间并没有真正的显著优势。

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者大秘境配装

2.1.

#### 推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者大秘境天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者为奇袭设计的大秘境配装，也是我们推荐用于几乎所有钥匙等级的配装。这套配装在较低等级的钥匙中表现特别好，因为你不必担心在面对很快死亡的敌人时管理[[spell:457052]]，但即使在高层钥匙中它也能造成出色的伤害，尽管优先目标伤害较少。这使得它在敌人可能很快死亡的环境中玩起来更舒适、更容易，但你可能需要习惯于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手配装，如果你打算冲击头衔级别的基石等级。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 奇袭 命缚者大秘境配装
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAGYBmxoxsBYbAbGAMzMGD"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzMMA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGimCY4QaiS7D84pSooMPLLMMuuuqrN-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-JQkUhpBIgwgxxC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手大秘境配装

2.2.

#### 推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手大秘境天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) 死亡猎手为奇袭设计的配装，也是我们最佳的高层大秘境配装。这套配装擅长在AOE中打出高持续的优先目标伤害，因为在高层钥匙中，小怪群的存活时间通常比你每周的钥匙通关要长得多。这套配装拥有惊人的优先目标伤害，既来自[[spell:457055]]，也来自你在AOE中生成大量连击点数并将其引导到多次[[spell:32645]]施放中的能力。建议在高层冲层钥匙中使用这套配装，但如果你想要更轻松的体验，不必管理[[spell:457052]]，通常建议改用命缚者配装。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 奇袭 死亡猎手大秘境配装
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAbmlBGwCYZYCMsYwMDwYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsZWGYALglhJwwiBzMAjxA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUmHhlFGGXXX1GnX-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-GIOQaAGIogBFmF-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和阻止

3.1.

#### 打断

[[spell:1766]]是你的，嗯，“踢”。你将打断你的目标敌人，或者，当使用焦点宏时，打断你设置为焦点的目标。

#### 焦点打断宏

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists,nodead] [] 脚踢
```

如果你有焦点目标，这个宏会打断你的焦点目标，如果没有焦点目标，则打断你的目标。我们建议将这个宏和普通的踢击施法都放在你的动作条上，因为你可能有多个目标需要打断，而宏总是优先处理焦点目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏** 或者在游戏中按键设置中设置“焦点目标”快捷键。

#### 焦点宏

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

3.2.

#### 眩晕与"打断"

[[spell:6770]]和[[spell:2094]]可用于对一组小怪中的多个怪物进行硬控。你也可以在坦克拉怪之前使用它，因为[[spell:379005]]在闷棍破除时会对目标施加一个降低伤害的减益效果。

点出[[spell:200733]]和[[spell:379005]]后，[[spell:2094]]变成一个低冷却时间的AOE干扰技能，还能在短时间内大幅降低坦克受到的伤害，但它只对真正可以被迷惑的目标有效。它对大型精英或首领无效。

[[spell:1856]]可用于[[spell:703]]敌人，多亏了[[spell:196861]]使其沉默。由于[[spell:381632]]，这也是一个DPS提升，所以巧妙规划你的冷却技能将获得更高的DPS回报。如果你不确定如何使用消失，请谨慎行事，首先将其用于沉默，而不是用于DPS。

[[spell:1776]]（如果点出天赋）可用于干扰敌人施放原本无法打断的法术。这需要你站在敌人面前，但在许多情况下可以用来阻止敌人使用他们最致命的一些技能。这些技能中许多在使用后会进入冷却，因此用凿击、[[spell:408]]或[[spell:2094]]干扰它们，将使这些小怪暂时无法再次施放这些技能。

[[spell:1856]]也可用于[[spell:1833]]一个只能被阻止、无法被打断的敌人，但这是绝对的最后手段。

### 致盲跳怪

3.3.

#### 致盲跳怪

[[spell:2094]]不是我们DPS工具包的一部分，但在大秘境中仍有一些可能不那么明显的有趣用途。虽然[[spell:6770]]允许玩家安全地通过被控制的生物而不进入战斗，但被致盲的敌人会困惑地四处走动，并且仍然会与 **第一个** 靠近它的玩家进入战斗。一旦致盲debuff结束，它就会攻击该玩家。然而，它不会与任何其他靠近它的玩家进入战斗。

你仍然可以很好地利用致盲来通过敌人，利用只有一个玩家会与它进入战斗的事实。做到这一点最好也最简单的方法是，在致盲目标后，确保你靠近到足以进入战斗，然后你和你的整个队伍就可以通过这个敌人。一旦你离它足够远，你就可以安全地[[spell:1856]]，脱离战斗，并跳过这个敌人。

这在有一整群敌人挡在你面前而你想跳过，但有一两个敌人太近以至于无法在不引到它们的情况下通过时特别有用。作为一个潜行者，你可以[[spell:6770]]一个，然后用上面的技巧处理另一个，让你可以跳过那些如果你使用[[spell:114018]]就会发现你，或者帷幕在冷却中的敌人。

### 其他功能

3.4.

#### 其他功能

[[spell:114018]]在你周围投射AOE[[spell:1784]]。但需要注意的是，在当前资料片中，有更多敌人可以侦测到潜行或隐形，你需要对此保持警惕。

[[spell:1725]]有助于设置帷幕跳怪，并使巡逻的小怪群停留10秒。确保迫使敌人背对你，以便你潜行通过他们。

[[spell:1966]]、[[spell:31224]]、[[spell:5277]]、[[spell:185311]]和[[spell:31230]]构成了一组非常强大的防御冷却技能，是潜行者在大秘境中强大的最大原因之一。

[[spell:57934]]通常并不特别出色。然而，任何有助于你的坦克对所有敌人保持仇恨的支持都是值得鼓励的。遗憾的是，它与[[spell:379005]]是选择节点。

[[spell:5938]]可用于驱散 **激怒** 效果。请记住，这意味着你将无法使用毒刃进行DPS输出。

[[spell:5761]]和[[spell:381637]]在大秘境中都很有用，但由于更强调小怪，在强韧周[[spell:5761]]可能会胜出，而在残暴周萎减则获得更多价值。与你的坦克和治疗沟通哪种更可取。

1.

### 应对词缀

至暗之夜第1赛季只有四个重要的词缀提供某种反制手段，称为萨拉塔斯的交易。这些每周轮换，一次只有一个生效。许多大秘境词缀，如强韧或残暴，只是给基石添加一个被动效果，而这四个例外则以萨拉塔斯为季节主题：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将生成三波需要打断或干扰的球体。由于[[spell:200733]]，[[spell:2094]]在这里作为AOE打断效果极佳。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：将生成一个虚空大使小怪，需要设置为焦点目标并打断。如果你知道这即将发生，请确保保留一些资源来切换到它。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：球体将在玩家周围生成并绕着他们转。你有15秒时间吸收所有这些来增益你的队伍。使用[[spell:2983]]将帮助你更快地吸收这些。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有队伍成员都会受到一个治疗吸收效果。你可以用[[spell:31224]]或石形态等种族技能移除它。如果这些对你不可用，使用[[spell:185311]]来帮助更快地摆脱减益效果。如果你的治疗者资源耗尽，治疗药水或治疗石也很有效。

每一种词缀在被处理后都会提供一组不同的增益效果，虽然它们非常强大，但你不需要以特定的方式围绕它们进行操作。最重要的是不要让任何词缀强化敌方小怪或首领。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 页面已针对前夕补丁进行更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 已针对11.2版本和第3赛季更新本页面，包含每周和高层大秘境的构筑推荐。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年4月21日：** 为大秘境切换至流血流派，并为11.1.5补丁复核了页面。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 为11.0.5补丁更新了天赋配装。
- **2024年9月9日：** 已针对地心之战第1赛季的开启进行更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月8日：** 新增了关于该天赋构筑并非最高DPS选择的声明。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年6月6日：** 针对放血 bug 进行了更新。
- **2023年5月1日：** 针对10.1补丁词缀更改更新了提示和技巧。
- **2023年3月26日：** 将飞刀替换为强化毒药。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年3月5日：** 更新了属性优先级和暴怒词缀说明。
- **2023年1月24日：** 已针对巨龙时代10.0.5补丁更改进行更新。
- **2023年1月4日：** 更新了天赋和示例起手式。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5补丁中玩你的奇袭 潜行者时更加轻松。

1.

### 最佳宏

你可以使用修饰符，以防某些技能彼此“互斥”，而无需更改快捷键或一直将技能拖到快捷键栏上。这些的语法如下：

- [known:SPELLNAME] 或 [known:SPELLID]

和

- [noknown:SPELLNAME] 或 [noknown:SPELLID]

1.1.

#### 奇袭专用宏

奇袭是一个非常简单的专精，在有助于提升DPS的宏方面几乎没有。唯一相关的宏是将[[spell:360194]]和你的主动饰品宏在一起。

#### 死亡印记 + 饰品宏

```wow-macro
#showtooltip 死亡印记
/cast 死亡印记
/use 13
```

这是你的第一个饰品栏位。如果你的主动饰品在另一个饰品栏位，你需要改为写/use 14。请注意，这对[[item:193701@JAAIAAQkCYHKvbRLfA]]无效，因为该饰品有施法时间。

1.

### 最佳插件

2.1.

#### 盗贼通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.4.4.

##### TankMD

[TankMD](<https://www.curseforge.com/wow/addons/tankmd>) 是一个新的插件，之前是一个WeakAura。它允许你自动将队伍的坦克作为你的[[spell:57934]]法术的目标，而无需鼠标悬停、焦点目标、切换目标或任何类似操作。

2.5.

#### 奇袭盗贼专用插件

目前，我们认为不需要额外的插件来充分发挥奇袭 潜行者的潜力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对前夕补丁进行更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 针对11.2版本审核了本页面，无需更改。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 页面已为11.0.5补丁复核。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 页面已针对10.1.5版本进行审核，由于奇袭在该版本中未有任何改动，因此无需更改。
- **2023年4月29日：** 10.1补丁无需对此页面进行更改。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
