## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Panthea。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-guide>)
- [练级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)

## 专精概览

欢迎来到我们的《魔兽世界》12.1.5版本防护 圣骑士指南。在这里，你将学习如何在团队副本和史诗钥石地下城中担任防护 圣骑士坦克。我们涵盖了从基础到极限优化技术的一切，以最大化你的生存能力。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

防护大秘境资源

[全新！顶级 防护 天赋构筑](<https://raider.io/specs/protection-paladin/talents>)

[顶尖防护大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/paladin/protection>)

[防护大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=paladin--protection>)

[流行的防护队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=paladin--protection>)

1.

### 防护 圣骑士 概述

作为一名防护圣骑士，你可以预期扮演一个坚实可靠的坦克角色。通常，你承受的伤害将相对平稳，许多攻击会被你的盾牌格挡或被你的强力主动减伤所缓解。没有其他坦克职业拥有像圣骑士那样丰富的手段。

伤害不错，不是最强但完全够用

防护圣骑士可以切换天赋以专注于单体伤害（团队副本）或范围伤害（大秘境），其玩法在两者之间几乎没有变化。主要的伤害爆发技能（

[[spell:384376]]

) 经常可用，有效利用你的神圣能量能让你获得更多的冷却时间可用性。与其他坦克相比，他们的伤害较低，但从综合角度来看，这足以保持威胁并为坦克造成可观的伤害量。

足以应对史诗难度中的每一场战斗

防护圣骑士和其他坦克一样，可以应对史诗难度下的每一场战斗。然而，他们最闪耀的时刻是在那些他们可以通过

[[spell:642]]

或

[[spell:204018]]

。在撰写本文时，似乎没有任何核心机制可以被完全规避。如果情况发生变化，此内容将会更新，表现评分也会相应更新以反映这一点。

强大的实用性和打断

防护是大秘境中稳定且高端的选择。虽然它并不总是最佳选择，但由于能提供大量的实用技能（见实用技能章节）和稳定的打断能力（

[[spell:375576]]

/

[[spell:31935]]

/

[[spell:96231]]

），并且可以在对所有伤害免疫的同时进行AOE嘲讽

[[spell:204077]]

.

团队辅助能力的无冕之王

防护圣骑士提供了许多强大的实用功能。你可以：

- 使用[[spell:213644]]解除毒素和疾病
- 使用[[spell:1044]]解除定身和减速效果
- 使其他玩家免疫物理伤害（[[spell:1022]]）或魔法伤害（[[spell:204018]]）
- 使用 [[spell:6940]] 为其他玩家提供外部减伤
- 用多余的 神圣 力量通过 [[spell:85673]] 治疗其他玩家，或用 [[spell:633]] 在他们生命值危险过低时拯救他们

在大多数危险场景中，你都有一个能帮助小队的工具！

生存终局内容所需的规划

第2赛季防护圣骑士的防御能力略有提升，[[spell:385438]]成为了一个你可以在天赋树中实际选择的选项。

然而，防护圣骑士仍然 **高度依赖** 依赖于良好的冷却时间规划，因为它们在所有坦克专精中生命值最低之一。有了良好的规划，它们在大多数危险场景中都能胜出，然而如果你在没有好计划的情况下进入有挑战性的内容，你可以预期会看到自己在请求战斗复活。

然而，这并非全是坏消息，防护圣骑士可以频繁使用他们的防御冷却技能，[[spell:31850]]随时可用，以至于你可以循环使用它们。这使得冷却技能规划的这一方面几乎变得微不足道。

[[spell:86659]] 现在有2层充能和更短的冷却时间，更易获取，而 [[spell:642]] 触发频率更低，但在抵挡即使是最强力的首领和小怪时也更强大。这些需要你更多地思考何时以及在何处使用它们。

[[spell:642]]甚至可以防止所有伤害，只有少数忽略此类免疫效果的伤害场景除外，而且配合[[spell:204077]]，它还可以充当群体嘲讽！

此外，新的顶峰天赋将防止你在没有神圣之力时无法保持[[spell:53600]]激活的情况。

没有马你就是马车

防护 圣骑士的机动性通过[[spell:190784]]以爆发形式实现，但这是我们仅有的机动性。一旦充能用完，我们没有任何方法快速从A点移动到B点，即使像快速清理小怪并在史诗钥石中在小怪包之间移动这样简单的事情，也比其他坦克要慢得多。

在需要大量移动的场景中，防护圣骑士会发现自己要么落后于队伍其他成员，要么需要外部机动性工具来辅助。

1.

### 防护 圣骑士在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本包含两个新内容：一个单Boss团队副本，其中每件物品都有一个加成效果，使其对所有团队成员都非常令人向往；以及新的巨型地下堡，你能够选择要获取的特定装备栏位，即使是在神话难度下！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

[12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>) 作为至暗之夜第2赛季进程的延续，围绕乌拉特克和阿曼尼的故事最终带来了一个全新的单首领团队副本、升级装备等级的途径、多种追赶装备来源，以及无限量的雾玉用于升级装备。请务必查看我们的补丁中心，了解补丁12.1.5的所有新增或更新信息。

2.3.

#### 职业改动

防护圣骑士遗憾地没有在补丁12.1.5中获得任何改动，因此最近的更新可以通过点击下方的下拉菜单查看。话虽如此，新装备和[[item:280562]]导致我们的 [装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)上出现了一些改动，所以请务必前往那里以获取所有最新信息！

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_divineshield.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 补丁12.1职业改动

补丁12.1对防护圣骑士专精天赋树进行了大幅重平衡，你现在可以轻松点出所有关键防御天赋，而无需牺牲伤害。你可以通过天赋树的标准路径点出[[spell:204018]]、[[spell:385438]]和[[spell:379021]]。这对于防护圣骑士的冷却时间一致性来说是一个很棒的改动！

单体目标伤害也有所提升，但代价是爆发性AOE伤害有所降低。

查看 [天赋](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>) 和
[配装](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>) 指南以获取更多信息。

2.5.

#### 天赋改动

[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

开发者说明：通过这些改动，我们打算降低选择哨兵所关联的机会成本，并拓宽防御天赋选项的范围。我们还将部分力量从强大的冷却窗口转移到基础持续输出中，目标是减少相关的仇恨痛点，并改善冷却技能之外的战斗体验。

以下是本次补丁中提到的改动的简要列表：

- **天赋重排：** 几个天赋在天赋树中发生了移动，使你能够点出如[[spell:385438]]这样的天赋而不牺牲伤害。[[spell:53376]]已被移除。[[spell:393114]]、[[spell:377053]]和[[spell:1238903]]都已被重新设计，[[spell:1301732]]作为新天赋引入。
- **防御增强：** [[spell:393114]]现在在激活时提供20%最大生命值，并且在假死机制触发时不再取消。[[spell:377053]]提供10%伤害减免，并对[[spell:209389]]、[[spell:1245891]]和[[spell:1244019]]有额外增益。[[spell:86659]]发生了一个细微变化，它现在有一个内部冷却时间，防止你同时使用两层充能。
- **单体目标伤害提升：** 核心循环技能得到了显著增强，[[spell:53600]]、[[spell:20271]]、[[spell:31935]]、[[spell:26573]]和[[spell:53595]]都获得了可观的伤害提升。
- **AOE伤害削弱：** 防护圣骑士的几个最强爆发AOE天赋被削弱，[[spell:429826]]、[[spell:431625]]、[[spell:433718]]和[[spell:1260429]]都受到了不同程度的削弱。

:::

### 至暗之夜改动概述

2.6.

#### 至暗之夜中防护圣骑士的改动

至暗之夜来了，随之而来的是大量的改动！许多天赋被移除，并添加了新天赋来取代它们，新增了英雄天赋，但防护圣骑士的核心循环没有太大变化。你可能会注意到的主要循环变化是[[spell:24275]]现在是一个被动技能，并在你处于[[spell:384376]]时取代[[spell:20271]]，[[spell:387174]]已被移除，[[spell:86659]]现在是一个3分钟冷却技能。

核心圣骑士天赋树看起来与在《战争之内》中非常相似。防护天赋树有了一些调整，天赋树左侧更侧重于[[spell:31935]]，右侧更侧重于[[spell:26573]]。这些改动是对法术的补充，而不是改变它们的功能。最终结果是循环并没有真正改变，所以你不需要担心重新学习如何玩防护圣骑士！

2.7.

#### 新顶点天赋

顶点天赋是防护天赋树末尾的新天赋，你可以从81级开始解锁，在81级、84级、87级和90级时获得天赋点。这些都是被动效果，对于防护圣骑士来说，它们将为你提供更多可用于循环的神圣能量并提升伤害。

[[spell:1267211]]（第2点和第3点）与[[spell:375576]]有特别好的协同作用，因为你可以通过施放[[spell:20271]]循环触发[[spell:1267203]]（第1点）的效果，而通过[[spell:355098]]免费施放的[[spell:31935]]将触发神圣能量的回复效果。

最后，[[spell:1267215]]（第4点）将使每次施放[[spell:31935]]都受益于先锋的效果，在[[spell:384376]]激活时为其提供额外伤害和神圣能量生成。实际上，这基本上会在[[spell:384376]]期间为你提供无尽的神圣能量供应。

2.8.

#### 英雄天赋改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者在功能上与在《战争之内》中的玩法完全相同，但使其在第3赛季成为强力专精的套装奖励已被移除，并作为英雄天赋以较低的强度加入。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士被增强了一些，它现在与[[spell:375576]]挂钩（因为[[spell:387174]]已被移除），这听起来可能不是什么大改动，但[[spell:31935]]现在占你总伤害的比例更大，而圣殿骑士天赋树更是进一步增强了这种力量！

2.9.

#### 生存能力改动

这个方面有几个改动。一个短冷却的防御技能被移除了（泰尔之眼），但增加了两项核心改动，使防护圣骑士在至暗之夜中防御能力非常强大。

- 精通已改为侧重于招架和法术格挡。将需要非常高的精通等级才能保证法术格挡，而这在资料片后期才能实现。
- [[spell:86659]]现在是一个3分钟冷却技能（从5分钟降低），并且有两层充能！

2.10.

#### 伤害输出改动

前面提到过[[spell:31935]]贡献了更多DPS。这主要是通过[[spell:469883]]实现的，它为命中的目标添加一个持续伤害效果，该效果从约57%的5秒伤害显著增强到100%。如果我们加上[[spell:375576]]作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士的核心技能来激活[[spell:429826]]，以及[[spell:384376]]拥有固定的1分钟冷却时间（与鸣钟相匹配），你就有了一个非常清晰的爆发DPS窗口。这还没提[[spell:1260429]]，它是圣殿骑士的一个新英雄天赋，使[[spell:375576]]以150%的强度额外施放两次。所有这些加在一起，防护圣骑士的DPS输出应该比在《战争之内》中更好。

1.

### 防护圣骑士玩法基础

总的来说，坦克意味着不仅要造成伤害和仇恨以确保怪物攻击你，还要承受这些攻击并存活下来。作为一名防护圣骑士，这通常意味着尽可能多地产生神圣能量，这样你就可以将其用于[[spell:53600]]以减少受到的伤害。有些时候承受的伤害会更高，你会想用另一个冷却技能来补充，这些场景例如拉大量敌人或首领。

分解来看，防护圣骑士将遵循以下三条简单规则。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_lightoftheprotector.jpg>) **产生并使用神圣能量**
  
  
  
  
  神圣能量是你的核心资源，上限为5。技能通常每次产生1点，这意味着你可以根据你拥有的上限有条不紊地计划接下来的几步操作。一个好的规则是，如果你有5点神圣能量，你就应该消耗它。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_shieldofvengeance.jpg>) **保持正义盾击激活**
  
  
  
  
  保持[[spell:53600]]激活是你作为防护圣骑士生存的核心。它不仅直接为你提供防御增益，还会产生一层[[spell:321136]]，使三次施放后的[[spell:85673]]免费。即使你不需要延长[[spell:53600]]的持续时间，它仍然具有防御增益。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_innerfire.jpg>) **待在你的奉献中**
  
  
  
  
  [[spell:26573]]有许多影响其收益的天赋，核心天赋是[[spell:379021]]，当你身处其中时会为你提供伤害减免。移动时别忘了重新放下[[spell:26573]]。

1.

### 如何作为防护圣骑士配装

虽然我们总是建议你自己进行模拟以获得理想结果，但我们确实提供了一个专门的防护配装页面。我们目前涵盖了第2赛季装备的建议，以便在至暗之夜终局内容发布时有一个良好的开端。一旦你获得了一些装备，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 包含来自基希克斯的新物品以及升华毒石的物品升级建议。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 更新了精通和格挡的属性阈值。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年9月21日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 饰品推荐中加入了剧毒之怒之源。
- **2026年9月21日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 更新了铸光者的建议。
- **2026年9月21日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 更新了神圣之器的起手式。
- **2026年9月21日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 更新了铸光者的天赋建议。
- **2026年9月21日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 更新了铸光者的天赋建议。
- **2026年9月11日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 更新了PvP天赋建议。
- **2026年9月11日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 更新了PvP天赋建议。
- **2026年9月4日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 修正了错误的戒指位置。
- **2026年8月18日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 更新了天赋。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 更新了配装建议，首批物品改动。
- **2026年8月18日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 更新了天赋建议并修正了迅捷召唤被选择的问题。
- **2026年8月18日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 更新了天赋建议。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 更新了补丁12.1的天赋。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 更新了补丁12.1中第2赛季的配装建议。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 针对补丁12.1更新，新增生命药水。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 针对补丁12.1进行了审查并添加了起手时间轴。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 更新了补丁12.1的天赋。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 更新了补丁12.1的天赋描述。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 更新了补丁12.1的天赋。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 更新了精通数值，包含达到100%格挡阈值的最新建模。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月23日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 为非史诗团本玩家添加了盾牌制作建议。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 移除了关于茶的提及，因为它们不再可以在副本内使用。
- **2026年3月23日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 更新了属性优先级，在标准优先级之外展示了防御属性优先级。
- **2026年3月23日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 更新了默认大秘境天赋以选择最终防御。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（本页）：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 为11.2.7补丁更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 为11.2.7补丁更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 针对补丁11.2.5更新。添加了辛迪加徽记建议。调整了更换迪斯科腰带的时机。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 更新了每个英雄天赋的属性优先级。添加了达到100%格挡的特定精通阈值。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 针对补丁11.2更新。移除了腐蚀部分，因为这在第3赛季不再有效，并将治疗药水更改为新的活力治疗药水。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 针对补丁11.2更新。降低了复仇者之盾的循环优先级。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 针对补丁11.2更新。降低了复仇者之盾在循环中的优先级。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 为11.1.7补丁更新。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月13日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 更新了辛迪加徽记建议。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-liberation-of-undermine-raid-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月18日（[解放安德迈页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-liberation-of-undermine-raid-guide>)):** 添加了加里维克斯提示。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 更新了塞尔西的指环信息。它获得了增强，现在真的值得使用了。它就是毕业装备！
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 添加了塞尔西的指环部分。简而言之：如果你的装等是636/639，那它就不是毕业装备。否则，宝石推荐已在页面上列出。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-nerub-ar-palace-raid-guide>)):** 女王提示中的错别字修正。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月26日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 更新了天赋和循环技能解锁。
- **2024年10月22日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-nerub-ar-palace-raid-guide>)):** 添加了更多提示，并根据最近铸光者的增强调整了天赋构建，使其在更多战斗中表现更好。
- **2024年10月22日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已添加地下城专属提示！
- **2024年10月22日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已针对11.0.5版本的天赋树重做进行更新。
- **2024年10月22日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对11.0.5版本的天赋树重做进行更新。
- **2024年10月22日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（本页）：** 针对11.0.5补丁进行了审阅。
- **2024年10月7日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 修复了选择英雄天赋和更新循环的问题。
- **2024年9月28日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 饰品更新。
- **2024年9月28日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 阐明惩罚也会由复仇者之盾触发。
- **2024年9月28日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 表格标题修复。
- **2024年9月16日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 更新了凡图斯符文信息。
- **2024年9月16日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-nerub-ar-palace-raid-guide>)):** 添加了安苏雷克提示。
- **2024年9月16日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 更新了英雄天赋的按钮，并在页面加载时添加了默认选项。
- **2024年9月16日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 澄清了属性优先级。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对《地心之战》发布进行更新，包含升至80级的英雄天赋选择和更新后的输出循环。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已更新为《地心之战》上线时的赛季前毕业装备。随着第1赛季临近，还将有进一步更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 为地心之战上线进行了审核。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 为地心之战正式上线更新了新的宝石、附魔和消耗品。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对《地心之战》上线进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已为地心之战上线更新，添加了不同天赋和英雄天赋的新复选框。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为《地心之战》上线进行了更新，并添加了英雄天赋。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对地心之战发布进行更新并添加了所有英雄天赋法术。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对《地心之战》上线进行更新。
- **2024年8月21日（本页）：** 已针对《地心之战》上线进行更新。
- **2024年8月19日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 为《地心之战》发布更新了天赋。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/protection-paladin-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年7月19日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年6月18日（[地心之战](<https://www.icy-veins.com/wow/protection-paladin-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月17日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/protection-paladin-mists-of-pandaria-remix-guide>)):** 将不倦之魂移至通用元宝石推荐。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/protection-paladin-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 为第4赛季进行了更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 为第4赛季进行了更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 清理了历史参考。已针对第4赛季进行审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对10.2.6版本更新。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 整理了天赋描述并移除了过时的参考内容。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 重新措辞了减伤冷却部分。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年11月28日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 更新了永恒黎明的链接，使其对应到各自的钥石地下城。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 更新了页面以考虑孢子斗篷的削弱。纹章推荐已针对此进行了更改。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已更新至第 3 赛季。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 为10.2版本进行了审查。为防护圣骑士添加了WeakAura推荐。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 添加了头盔附魔和新的治疗药水。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已更新至第 3 赛季。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已针对10.2补丁进行审查
- **2023年11月6日（本页）：** 已更新至第 3 赛季。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 更新了装备搭配，新增了毕业装备列表。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 移除了关于炽天使的引用。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 更新了天赋树布局。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 将10.1.5版本更新替换为10.1.7版本更新。
- **2023年7月14日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 更新了武器附魔和药剂推荐。武器附魔部分更明确地说明了两种选择，不过这两种选择在输出方面相当接近。药剂已改为微温全能药水，因为外部伤害来源的出现频率增加了。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 更新了昂萨贡戒指章节，说明何时更换这枚戒指。增加了10.1.5版本物品章节。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 更新了玛瑙指环和原初宝石部分，以及何时考虑替换它。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已针对10.1.5版本更新天赋树。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为10.1.5补丁更新了天赋树。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 为10.1.5补丁更新了天赋树。
- **2023年7月10日（本页）：** 用10.1.5变更替换了10.1变更。
- **2023年5月6日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 天赋修复。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 为补丁10.1更新了天赋模拟器。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 将黑曜石指环部分移至页面底部（它对伤害依然很好！）。已为第2赛季更新装备、饰品和美化。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 添加了腰带附魔（10.1版本新增）并针对第2赛季进行了审查。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 为10.1补丁更新了天赋树，为第2赛季更新了词缀信息。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 为清晰起见，将复仇者之盾添加到循环优先级列表中。已针对10.1版本进行审查。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 为补丁10.1的改动更新了法术。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已为10.1补丁更新天赋树，并将正义之盾加入输出循环优先级列表。
- **2023年5月1日（本页）：** 将10.0.7版本改动替换为10.1版本改动。
- **2023年4月3日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 为祝福之锤/正义之锤添加了说明。
- **2023年3月25日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 更新了原始宝石推荐。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/protection-paladin-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 添加了奥妮克希亚指环章节。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 添加了奥妮克希亚指环和太古宝石章节。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已为10.0.7补丁更新天赋构筑。添加了邪恶术的使用说明。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 移除了黄昏与黎明部分，因为它在10.0.7补丁中被重做为被动效果。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为10.0.7补丁改动更新了两套天赋构筑和天赋。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 针对10.0.7的改动更新了法术。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 为10.0.7补丁改动更新了两套天赋构筑和天赋。
- **2023年3月20日（本页）：** 已根据10.0.7补丁的改动进行更新。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 更新了练级天赋树以显示每个等级的正确天赋。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已针对第1赛季更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 添加了一个小章节来讨论套装对输出循环的影响。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年11月23日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 更新为表格形式。将Auras & of Dusk and Dawn分拆为独立章节。
- **2022年10月24日（[升级](<https://www.icy-veins.com/wow/protection-paladin-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/protection-paladin-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/protection-paladin-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/protection-paladin-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[装备页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[属性页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[统御圣所页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[大秘境页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[循环页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[天赋页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[法术页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月18日（[9.2版本分析](<https://www.icy-veins.com/wow/protection-paladin-patch-9-2-changes-analysis>)):** 根据最新的PTR构建更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/protection-paladin-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/protection-paladin-patch-9-1-changes-analysis>)):** 为9.1.5进行了更新。
- **2021年7月18日（[9.1 补丁分析](<https://www.icy-veins.com/wow/protection-paladin-patch-9-1-changes-analysis>)):** 移除了PTR相关内容。
- **2021年4月29日（[9.1 补丁分析](<https://www.icy-veins.com/wow/protection-paladin-patch-9-1-changes-analysis>)):** 添加了初始内容。
- **2020年10月13日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-crucible-of-storms-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2019年8月26日（[永恒宫殿页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** 更新并添加了史诗难度提示。
- **2019年7月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** 更新了扎库尔主坦克和副坦克的精华推荐。
- **2019年7月12日（[永恒宫殿页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** 更新了精华推荐。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-the-eternal-palace-raid-guide>)):** 为 防护 圣骑士添加了永恒宫殿建议。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月12日（[风暴熔渣页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-crucible-of-storms-raid-guide>)):** 更新并新增了史诗模式。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年3月5日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** 为达萨罗加入了史诗难度建议。
- **2019年1月29日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** 根据正式服机制更新了 BoD 建议。
- **2019年1月20日（[达萨罗之战页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-battle-of-dazar-alor-raid-guide>)):** 为防护圣骑士添加了BoD建议。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** 重大修订，并添加了史诗难度。
- **2018年9月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-uldir-raid-guide>)):** 新增了奥杜尔逐个首领的初步攻略大纲。

显示更多

显示更少

:::

## 练级

在本页面，你将找到我们的防护圣骑士逐级升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[圣骑士 升级指南](<https://www.icy-veins.com/wow/paladin-leveling-guide>).

1.

### 防护圣骑士在至暗之夜中的升级指南

作为坦克升级是非常宽容的。你可以始终将任务目标所需的所有敌人拉成一大群并舒适地存活下来，从而获得更快的任务体验。

作为一名坦克，如果你厌倦了做任务，你还有幸能快速排队进入地下城。完成地下城会给予大量经验值，并有助于巩固你的终局游戏风格，因为野外任务并不总是具有挑战性。

作为圣骑士，你在练级时还有另一个小优势，那就是你可以在即将落地前使用[[spell:642]]，从而安全地从高处坠落并避免所有坠落伤害！

在进入指南之前，最后一个小技巧是：在脱离战斗且生命值较低时使用[[spell:1231418]]。如果你没有神圣之力来使用[[spell:85673]]，这比自己治疗要快得多。

1.1.

#### 升级装备选择

升级时，你应始终选择物品等级最高的装备。此规则唯一的例外是，如果你有一件物品等级略低但带有两项副属性而非一项的戒指或项链。

使用传家宝物品时，优先选择带有急速的物品。这些物品会随你的等级提升而提升，意味着你升级时不需要更换它们。

1.2.

#### 至暗之夜升级实用消耗品

在至暗之夜升级时，你在地心之战期间使用的许多消耗品将继续有价值。你可以选择将你的副属性附魔更改为加速变体，例如[[item:223725]]（护腕）和[[item:223800]]（披风），并使用加速食物增益[[item:225592]]。

在做任务战斗时使用[[item:212265]]也会加快你的升级旅程，并始终激活战斗合剂，如[[item:212283]]。

当你从高崖跳下或想要覆盖长距离时，[[item:109076]]可以救你一命。

[[item:132516]]是练级时非常推荐的物品。它们提供极大幅度的移动速度提升。这个增益堪比飞行时获得的速度。强烈建议你在练级时囤积这些物品。

只要枪鞋处于激活状态，你就无法停止移动。使用这个宏两次会取消该增益，让你能够停下来。

#### 枪鞋宏

```wow-macro
#showtooltip
/use 火枪鞋
/cancelaura 火枪鞋
```

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 防护 80级 至暗之夜 练级
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiKuxxYjbFEU1NQSC1LD-YOAJwMVkBilXuHQf6ausElQJIUEKZDkG-AAAA-bYWUoEcAQMxQAB-
```

:::

2.1.

#### 升级用战争模式天赋

1. [[spell:199542]]使[[spell:190784]]的持续时间延长2秒，这意味着每次冲锋你都能行进更远的距离，让你能够快速在两个地点之间移动。但请注意，它会将靠近你的敌人击退，如果你试图将他们聚集在一起进行AOE，这可能是一个负面因素。
2. **等级 20 起：**[[spell:210341]]使[[spell:53600]]造成的伤害提高30%，代价是提供的护甲值减少。对于户外内容来说这通常没问题，因为坦克在户外内容中一般不会难以生存。
3. **等级 22 起：**选择[[spell:207028]]以对单体目标造成额外伤害，或选择[[spell:228049]]以便在[[spell:642]]之外额外获得两次免疫充能。
4.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

防护圣骑士的循环是一个优先级系统，这意味着你没有严格的循环顺序，而是当两个技能同时可用时，你需要根据下面的循环来决定优先使用哪一个。

**等级 1–9：**当你首次创建你的圣骑士时，你只会有一个可用技能：[[spell:35395]]。达到10级后，你就可以正式专精于防护了。

1. **等级 10 起：**施放[[spell:26573]]
2. **等级 26 起：**施放[[spell:375576]]。
3. **等级 71 起：**施放[[spell:429826]]
4. **等级 10 起：**施放[[spell:20271]]以产生神圣力量。如果你处于[[spell:384376]]的效果下，这将会是[[spell:24275]]
5. **等级 10 起：**当你拥有3点神圣力量（或更多）时，施放[[spell:53600]]。
6. **等级 11 起：**施放[[spell:31935]]以对多个目标造成伤害，对3个以上目标时，该法术在伤害循环中的优先级最高。
7. **等级 10–12：**施放[[spell:35395]]。
8. **等级 13–13：**你的[[spell:35395]]现在将会变成[[spell:53595]]或[[spell:204019]]。
9. **等级 14 起：**施放[[spell:53595]]/[[spell:204019]]。

**等级 2–90：**练级期间主动减伤大部分时间都能发挥作用，因为我们在2级时就已经获得了[[spell:53600]]。这意味着我们可以将神圣力量用于造成AOE伤害，同时通过增加护甲值来减少受到的物理伤害。

**等级 10 起：**从10级开始，地下城查找器开启，你现在可以排队并测试你的坦克能力了。这个等级的坦克应该不会太复杂，但确实可能非常令人沮丧，因为其他玩家通常会因为等级太低而试图速通。这意味着你在最初几个地下城中可能学不到太多关于坦克的知识，但继续玩下去，你会在练级过程中学到东西。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月11日：** 更新了PvP天赋建议。
- **2026年8月18日：** 更新了天赋。
- **2026年8月10日：** 更新了补丁12.1的天赋。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月26日：** 更新了天赋和循环技能解锁。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》发布进行更新，包含升至80级的英雄天赋选择和更新后的输出循环。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为补丁10.1更新了天赋模拟器。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 更新了练级天赋树以显示每个等级的正确天赋。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页面上，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩防护圣骑士，使用最简单的循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 至暗之夜中防护圣骑士的基础

本页面面向刚接触游戏或该职业的玩家，他们不打算参与史诗难度团队副本，或者只是想要一种更直接的方式来游玩他们的专精，而不会被为实现最优游玩所需考虑的众多细节和主动技能所淹没。

防护圣骑士遵循三条简单的规则：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_lightoftheprotector.jpg>) **产生并使用神圣能量**
  
  
  
  
  神圣能量是你的核心资源，上限为5。技能通常每次产生1点，这意味着你可以根据你拥有的上限有条不紊地计划接下来的几步操作。一个好的规则是，如果你有5点神圣能量，你就应该消耗它。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_shieldofvengeance.jpg>) **保持正义盾击激活**
  
  
  
  
  保持[[spell:53600]]激活是你作为防护圣骑士生存的核心。它不仅直接为你提供防御增益，还会产生一层[[spell:321136]]，使三次施放后的[[spell:85673]]免费。即使你不需要延长[[spell:53600]]的持续时间，它仍然具有防御增益。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_innerfire.jpg>) **待在你的奉献中**
  
  
  
  
  [[spell:26573]]有许多影响其收益的天赋，核心天赋是[[spell:379021]]，当你身处其中时会为你提供伤害减免。移动时别忘了重新放下[[spell:26573]]。

防护圣骑士是拥有非常全面技能组合的坦克。通常，你的伤害承受情况取决于[[spell:53600]]是否处于激活状态。重要的是要保持冷静，不要仅仅因为生命值低就惊慌失措，因为你拥有出色的工具来让自己摆脱低血量的困境。没有其他坦克职业像圣骑士那样拥有如此丰富的技巧和实用性。

1.

### 至暗之夜中防护圣骑士新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者单体天赋

2.1.

#### 防护圣骑士新手单体天赋

这套构建适用于你对抗单独的团队副本首领、小怪刷新不频繁的首领，或开放世界内容。如果会有多个敌人持续出现，我们会推荐AOE和大秘境构建。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 团队副本/单体目标 - 铸光者
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYGzMzMz2yYMLzilZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZDDAGzwYAwMDAmZAjF"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYGzMzMz2yYMLzilZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZDDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAZmIyAxy7TXzCXE4EqQBhCpbgu8JID-AAAA-OQURYhpBYQQBkE-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者地下城天赋

2.2.

#### 防护圣骑士新手AOE和大秘境天赋

这是我们推荐的AOE场景构建。它在团队副本的AOE战斗以及大多数大秘境中都表现良好。它可以在所有场景中使用，但如果目标数量不多，部分天赋将无法发挥作用。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents AOE/大秘境 - 铸光者（每周大秘境）
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-OQURYhpBYQQBkE-
```

:::

### 防护圣骑士基础循环

2.3.

#### 新手防护圣骑士循环

你的循环主要目标是产生[[spell:53600]]充能，同时保持奉献的覆盖率。由于大多数法术的可用性很高，它更像是一种优先级系统而非严格的循环。

- **冷却技能：** 使用[[spell:384376]]，然后在可用时使用[[spell:375576]]和[[spell:429826]]。
- 当你由于移动到新位置而没有站在[[spell:26573]]中，或者它因减伤效果超时而消失时，应使用[[spell:26573]]。
- 要消耗神圣力量，当你拥有3-5点神圣力量时使用[[spell:53600]]以防止神圣力量溢出。如果你的生命值低于50%，改用[[spell:85673]]来保命！
- 产生神圣力量的优先顺序为：[[spell:24275]]、[[spell:20271]]、[[spell:31935]]（如果你从巅峰天赋获得[[spell:1268810]]触发）、[[spell:53595]] / [[spell:204019]]
- 如果其他所有技能都在冷却中，你将使用[[spell:31935]]或[[spell:26573]]来刷新持续时间。

请注意，上述要点并未涵盖如何循环使用你的防御法术，有关更多信息，请访问本指南的防御法术部分。

2.3.1.

##### 巅峰天赋： ![Glory of the Vanguard Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_12al_armyoflight_defense_shield01.jpg>) 先锋的荣耀

当你施放[[spell:20271]]/[[spell:24275]]时，你有几率获得[[spell:1268810]]（当你拥有[[spell:384376]]激活时，此增益必定触发）。这将带来更高的神圣力量产生，特别是当你拥有[[spell:384376]]激活时，你会发现自己的[[spell:53600]]施放频率更高（**施放此技能不占用公共冷却时间，这意味着你可以同时施放它和另一个法术。**).

2.4.

#### 圣骑士光环

默认使用[[spell:465]]。如果队伍中有神圣圣骑士，改用[[spell:32223]]。

2.4.1.

##### 第2赛季套装

第2赛季的套装奖励对防护圣骑士的循环没有影响，只是对位于你[[spell:26573]]内的敌人造成更多伤害。

### 防护圣骑士防御法术

2.5.

#### 防护圣骑士的防御法术

[[spell:53600]]和[[spell:85673]]是你的两个主动减伤技能（虽然[[spell:85673]]是一个治疗技能，所以它实际上并不能减伤）。由于[[spell:53600]]不占用公共冷却时间，你可以随时在最合适的时候使用它来减少物理伤害承受而不打乱你的循环。然而，由于[[spell:85673]]占用公共冷却时间，使用它很可能会延迟你的循环。如果这次治疗能救你的命，那就没有问题。

[[spell:53600]]的覆盖率在正常游玩场景下相对较高。你的目标是尽可能让它的覆盖率接近你的装备/天赋所能允许的100%。

然而，如果你的急速较低，你需要注意不要让增益溢出。它可以延长到基础持续时间的3倍，4.5秒 x 3 = 13.5秒。如果你的持续时间超过9秒，尽量避免按下[[spell:53600]]，除非你即将超过5点神圣力量。

由于[[spell:53600]]的强大，最好根据你预期承受的伤害来有计划地使用这些冷却技能。

- [[spell:86659]]应在高伤害承受阶段之前使用，或在治疗者暂时无法治疗你时使用。
- [[spell:31850]]最好用于规避致命的战斗机制，或在危急时刻救你的命。 **或** 在战斗开始时，你获得第一个[[spell:53600]]之前使用。
- [[spell:384376]]使造成的伤害和治疗效果提高20%，并提高20%暴击几率。这是一个很好的进攻性冷却技能，但对于自我治疗来说在防御上也非常有用。
- [[spell:633]]应作为紧急反应性冷却技能使用，在你的生命值降至低点时将自己抬满。请注意，你也可以用它来拯救其他团队成员。
- [[spell:642]]可用于清除减益效果或避免致命伤害，因为在其持续时间内你对伤害免疫。[[spell:204077]]将圣盾术变成一个可用的坦克冷却技能，使你对伤害免疫，同时强制所有敌人攻击你；然而，如果没有决一死战天赋，首领不会攻击你，而是转去攻击威胁列表上的下一个目标。

### 防护圣骑士属性优先级

2.6.

#### 防护圣骑士的属性优先级

目前，装等是配装中最重要的方面，副属性的价值相当接近，但在装等相同的最优配装场景下，你应该按照下述内容进行优先级排序。有关本页面所呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>).

1. 急速
2. 精通
3. 全能 = 暴击

### 暴风雪战斗助手

2.7.

#### 防护圣骑士的战斗助手可用性

该 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 11.1.7版本加入的一键循环模式与使用正常循环相比，吞吐量有显著下降，这是由于目前使用的循环以及它在使用时对你的技能施加的额外延迟造成的。

撰写本文时，辅助循环不使用[[spell:85673]]或[[spell:384376]]。因此，它可能导致你想要自我治疗但没有可用的神圣力量的情况，从而引发潜在的生存问题，它造成的伤害也显著低于标准循环（大约低40%的DPS）。

我们建议目前避免使用它，而是遵循本页面上的循环建议。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月21日：** 更新了铸光者的天赋建议。
- **2026年8月18日：** 更新了天赋建议。
- **2026年8月10日：** 更新了补丁12.1的天赋。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对补丁11.2更新。降低了复仇者之盾在循环中的优先级。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月28日：** 表格标题修复。
- **2024年9月16日：** 澄清了属性优先级。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》上线进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为10.1.5补丁更新了天赋树。
- **2023年5月1日：** 已为10.1补丁更新天赋树，并将正义之盾加入输出循环优先级列表。
- **2023年4月3日：** 为祝福之锤/正义之锤添加了说明。
- **2023年3月20日：** 为10.0.7补丁改动更新了两套天赋构筑和天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面上，你将找到《魔兽世界》12.1.5补丁中你的防护圣骑士的最佳天赋。我们还为各种内容类型（如团队副本或大秘境）提供默认天赋构建。如果你开启了战争模式游玩，我们也为你提供了PvP天赋。

1.

### 防护圣骑士的最佳至暗之夜天赋

从历史上看 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士一直是事实上的输出型英雄天赋，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者一直是更偏防御性的一个。本赛季通过增强[[spell:26573]]以及防护圣骑士的整体伤害进行了调整。这导致了 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 现在同时具备防御性和进攻性取向，使其在大多数内容中成为更佳选择。我们目前的推荐如下：

- **团队副本 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者
- **大秘境 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者

虽然两套英雄天赋拥有相似的伤害模式， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 在原始伤害方面更胜一筹。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 可以在极短的时间窗口内提供更高的爆发伤害，但大多数战斗并非如此运作，因此你通常会默认选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 来应对几乎所有类型的内容。你可以选择使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 来应对轻松的内容，例如每周大秘境钥匙或地下堡，在这些场景中你可以充分发挥其爆发输出。

**快速开始导入代码：**

:::talents 团队副本/单体目标 - 铸光者
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYGzMzMz2yYMLzilZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZDDAGzwYAwMDAmZAjF"
}
```
:::

:::talents AOE/大秘境 - 铸光者（每周大秘境）
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::talents AOE / 大秘境+ - 铸光者（高层大秘境）
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsNLjZMzMzMLLjxYWmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::talents 地下堡 - 圣殿骑士
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZYWGzYmZmZW2GjZZWmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

铸光者

单体目标

推荐

秘境+

每周大秘境钥匙

秘境+

高层大秘境

圣殿骑士

秘境+

对新手友好

地下堡

### 天赋方案 0-0

1.1.

#### 单体目标天赋

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 配置提供高额单体目标伤害以及所有核心生存天赋。你会使用这套配置的场景主要是：在团队副本中面对没有稳定小怪刷新的首领战，或在开放世界中与1-3个敌人战斗。如果你想要一套有助于顺劈伤害输出场景的配置，我们推荐大秘境天赋。

为了追求更多伤害，你可以选择将[[spell:1245891]]替换为[[spell:1277162]]，但在进行此替换时需要注意你的神圣能量值，因为使用[[spell:53600]]时会消耗更多能量，以换取更多伤害。

### 天赋方案 0-1

1.2.

#### 每周大秘境钥匙天赋（铸光者）

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 配置使用[[spell:1245979]]，以便更轻松地在拉怪之间保持[[spell:53600]]的覆盖。

### 天赋方案 0-2

1.3.

#### 高层大秘境天赋（铸光者）

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 配置将[[spell:1245979]]替换为[[spell:1301732]]以提高治疗潜力，并将[[spell:1244070]]替换为[[spell:378405]]以获得更多治疗。

### 天赋方案 1-0

1.4.

#### 每周大秘境钥匙天赋（圣殿骑士）

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士 配置使用[[spell:1245979]]，以便更轻松地在拉怪之间保持[[spell:53600]]的覆盖。

### 天赋方案 1-1

1.5.

#### 地下堡天赋

这些天赋与大秘境天赋完全相同，因为内容的伤害模式是一样的。如果你不需要[[spell:204077]]，你可以将其替换为[[spell:378762]]以获得更多伤害。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsNDzyYGzMzMz2yYMLzilZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZDDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAZmIyAxy7TXzCXE4EqQBhCpbgu8JID-AAAA-OQURYhpBYQQBkE-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-CDGIJKV5knpB4ARRddlt1lo5Z1NQSyDEEVF-YAZcmeREBDklILuOvfA18IhSbTogQRCE-AAAA-AGU4ASyCTTgARF-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-OQURYhpBYQQBkE-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiKuxZFEU1VSKwD1YjLD-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-bYWUoEcAQMxQAB-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiKuxZFEU1VSKwD1YjLD-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-bYWUoEcAQMxQAB-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)。该系统每周为你提供一个新符文供选择，持续5周，并将略微提高你的输出。这不是一个庞大的借用能量系统，而是一种轻微的强化。

我们的建议是针对游戏中大多数内容使用以下选项。你可以根据特定内容在每一行的选项之间自由切换。例如，第4周的这一行可能会根据你当时的特定装备情况而变化：

- 第1周：[[spell:1279596]]
- 第2周：[[spell:1279604]]
- 第3周：[[spell:1287555]]
- 第4周：[[spell:1279609]]（伤害）/ [[spell:1279612]]（防御）
- 第5周：[[spell:1279616]]

1.

### 巅峰天赋： ![Glory of the Vanguard Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_12al_armyoflight_defense_shield01.jpg>) 先锋的荣耀

至暗之夜中的新内容是巅峰天赋，它们位于防护天赋树的末尾。这些天赋在81、84、87和90级解锁，全部为被动效果，会在触发时影响你的输出循环。

它们都围绕着由[[spell:20271]]触发的增益效果展开，该效果为[[spell:31935]]添加额外效果。

- 第一点（[[spell:1267203]]）：使[[spell:1268810]]对位于你和目标之间的敌人造成额外伤害。
- 第二点和第三点（[[spell:1267211]]）：[[spell:1268810]]被消耗时产生神圣能量。
- 第四点（[[spell:1267215]]）： **每次施放** [[spell:31935]]时，如果你拥有[[spell:384376]]，则具有[[spell:1268810]]的效果（神圣能量 + 额外伤害），你还会获得一些对[[spell:53600]]的额外AOE伤害。

1.

### 英雄天赋

防护圣骑士可以在以下天赋之间进行选择： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者英雄天赋，从71级开始。

第2赛季的推荐是偏向于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士天赋配置。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士专注于大爆发伤害。每次你使用[[spell:375576]]时，你将能够施放[[spell:429826]]。由于这些技能有1分钟的冷却时间，它与[[spell:384376]]（点出[[spell:204074]]天赋时）完美搭配，创造出非常高频率的高伤害爆发窗口。

这套英雄天赋树为防护圣骑士提供了一种非常有条理的输出循环流程，并在每分钟所有技能都可用时创造出令人兴奋的游戏时刻。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者更偏向实用性，因为这套英雄天赋的重点是为玩家施加[[spell:227817]] / [[spell:432472]]。[[spell:227817]]为玩家提供伤害吸收护盾，[[spell:432472]]为玩家提供额外伤害或治疗。每次你施放壁垒/武器时，你也会为其他玩家提供较弱的版本，使得一次适时的[[spell:227817]]成为一个小队吸收护盾，在大秘境中为你的治疗者提供帮助！

你也永远不需要再担心武器油了，因为你获得了[[spell:433568]]的使用权限，在那里你可以为主手武器灌注一个强大得多的增益效果，该效果仅适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者圣骑士！

1.

### PvP天赋（战争模式）

开启战争模式使你有资格参与开放世界PvP，但也会为你带来以下好处：

- 满级的世界任务奖励提高10%（如果你是联盟则为30%）。
- 升级期间获得的经验值提高10%（如果你是联盟则为30%）。
- 允许你获得征服点数，以换取每周装备奖励。
- 授予你在开放世界中使用PvP天赋的权限。

鉴于开启战争模式对升级和PvE内容的好处，我们建议你启用此功能，以最大化你的升级过程和满级后的奖励。然而，你会使自己有资格参与开放世界PvP，在升级或做世界任务时存在被“偷袭”的可能性。

本列表将假设你不太关心实际的PvP战斗，而是专注于户外PvE的最佳天赋，例如世界任务和升级。

- [[spell:210341]]使[[spell:53600]]的伤害提高30%，代价是提供的护甲值减少。这在户外内容中通常没问题，因为坦克通常不会在其中难以生存。
- [[spell:199542]]使[[spell:190784]]的持续时间延长2秒，这意味着每次冲锋你都能行进更远的距离，让你能够快速在两个地点之间移动。但请注意，它会将靠近你的敌人击退，如果你试图将他们聚集在一起进行AOE，这可能是一个负面因素。
- 选择[[spell:207028]]以对单体目标造成额外伤害，或选择[[spell:228049]]以便在[[spell:642]]之外额外获得两次免疫充能。

天赋，例如[[spell:377043]]和[[spell:215652]]，其作用与 [防护 圣骑士](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-guide>)已经做得很好的效果相同，无论使用[[spell:1044]]还是[[spell:31935]]。美德之盾最重要的是使复仇者之盾能够沉默玩家，因为它通常不会这样做，但它也会沉默周围的目标，用途非常有限。

大多数其他天赋要么非常弱，要么是使你周围的玩家受益，用途非常有限。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年9月21日：** 更新了铸光者的天赋建议。
- **2026年9月11日：** 更新了PvP天赋建议。
- **2026年8月18日：** 更新了天赋建议并修正了迅捷召唤被选择的问题。
- **2026年8月10日：** 更新了补丁12.1的天赋。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 更新了默认大秘境天赋以选择最终防御。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 已针对11.0.5版本的天赋树重做进行更新。
- **2024年9月28日：** 阐明惩罚也会由复仇者之盾触发。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为《地心之战》上线进行了更新，并添加了英雄天赋。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 整理了天赋描述并移除了过时的参考内容。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 更新了天赋树布局。
- **2023年7月10日：** 为10.1.5补丁更新了天赋树。
- **2023年5月6日：** 天赋修复。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 为10.0.7补丁改动更新了两套天赋构筑和天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何根据你将要承受的伤害类型，优化你的防护圣骑士的输出循环。我们还提供了关于冷却时间、触发效果等方面的进阶章节，以最大化你的生存能力和DPS。我们的所有内容均已针对魔兽世界12.1.5版本补丁进行更新。

1.

### 防护圣骑士游戏玩法与输出循环指南

防护圣骑士的输出循环基于优先级系统。你的循环的主要目标是产生神圣能量，你可以将其消耗在[[spell:53600]]的充能上，同时保持[[spell:26573]]的覆盖。除了这个循环之外，你还需要利用你的[[spell:53600]]（以及在较小程度上，你的[[spell:85673]]）来保持存活。

:::details 常见问题：我应该以防御还是进攻的方式游戏？
基本答案是，如果你正在开荒进度，或者你使用的是一个你还不习惯以进攻方式游戏的角色，你应该以防御方式游戏。随着你开始在你的圣骑士上变得更加熟练，你应该开始更多地关注DPS，并采用一种更混合的风格，在开始推进DPS的同时慢慢牺牲一些生存能力。

一旦你对战斗完全有信心，并且不会拖累你的团队，你就可以完全为DPS进行优化。这个时间点因人而异，因为它取决于你的团队、你的角色、你的装备和你的技术水平。

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士

单体目标

单体目标（大型首领模型）

群体伤害

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

单体目标（大型首领模型）

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:53595]]

[[spell:204019]]

[[spell:1267215]]

（最终巅峰点）

[[spell:155145]]

（鲜血精灵）

[[spell:1277162]]

### 起手式

**适用条件：Blessed Hammer（启用）。**

[[spell:26573]]

[[spell:204019]]

[[spell:62124]]

[[spell:384376]]

[[spell:375576]]

**适用条件：圣殿骑士（启用）。**

[[spell:429826]]

**适用条件：铸光者（启用）；Instrument of the Divine（启用）。**

[[spell:53600]]

**适用条件：铸光者（启用）；Instrument of the Divine（未启用）。**

[[spell:53600]]

**适用条件：Instrument of the Divine（启用）。**

[[spell:1241288]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:31935]]

**适用条件：Instrument of the Divine（未启用）。**

[[spell:1241288]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。**

[[spell:53600]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:53600]]

**适用条件：Instrument of the Divine（未启用）。**

[[spell:1241288]]

**适用条件：Instrument of the Divine（启用）。**

[[spell:1241288]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。**

[[spell:31935]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:31935]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。**

[[spell:53600]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:53600]]

**适用条件：Instrument of the Divine（未启用）。**

[[spell:1241288]]

**适用条件：Instrument of the Divine（未启用）。**

[[spell:1241288]]

**适用条件：Instrument of the Divine（启用）。**

[[spell:1241288]]

**适用条件：Instrument of the Divine（启用）。**

[[spell:1241288]]

**适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。**

[[spell:31935]]

[[spell:53600]]

1.1.

#### 作为防护圣骑士的开怪循环

当你开始一次拉怪时，你需要管理几个优先事项。首先也是最重要的是，你需要设置好你的[[spell:53600]]，然后管理你的神圣能量。以下序列应确保你不会拥有超过5点神圣能量（以防止浪费神圣能量），保持[[spell:53600]]并造成最佳伤害。

---

1. **适用条件：Blessed Hammer（启用）。** **拉怪前：** 如果你将敌人拉向你，请预先放置[[spell:26573]]，施放[[spell:204019]]以产生1点神圣能量，并使用[[spell:62124]]拉怪。
2. **适用条件：正义之锤（启用）。** **拉怪前：** 如果你将敌人拉向你，请预先放置[[spell:26573]]，并使用[[spell:62124]]拉怪。
3. [[spell:384376]]
4. [[spell:375576]]
5. **适用条件：圣殿骑士（启用）。** [[spell:429826]]
6. **适用条件：铸光者（启用）；Instrument of the Divine（启用）。** [[spell:53600]]
7. **适用条件：铸光者（启用）；Instrument of the Divine（未启用）。** [[spell:53600]]
8. **适用条件：Instrument of the Divine（启用）。** [[spell:1241288]]
9. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:31935]]
10. **适用条件：Instrument of the Divine（未启用）。** [[spell:1241288]]
11. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。** [[spell:53600]]
12. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:53600]]
13. **适用条件：Instrument of the Divine（未启用）。** [[spell:1241288]]
14. **适用条件：Instrument of the Divine（启用）。** [[spell:1241288]]
15. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。** [[spell:31935]]
16. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:31935]]
17. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（未启用）。** [[spell:53600]]
18. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:53600]]
19. **适用条件：Instrument of the Divine（未启用）。** [[spell:1241288]]
20. **适用条件：Instrument of the Divine（未启用）。** [[spell:1241288]]
21. **适用条件：Instrument of the Divine（启用）。** [[spell:1241288]]
22. **适用条件：Instrument of the Divine（启用）。** [[spell:1241288]]
23. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）；Instrument of the Divine（启用）。** [[spell:31935]]
24. [[spell:53600]]
25. **适用条件：Blessed Hammer（启用）。** [[spell:204019]]
26. **适用条件：Blessed Hammer（启用）；Glory of the Vanguard (Final Apex Point)（未启用）。** [[spell:204019]]
27. **适用条件：正义之锤（启用）。** [[spell:53595]]
28. **适用条件：Hammer of the Righteous（启用）；Glory of the Vanguard (Final Apex Point)（未启用）。** [[spell:53595]]
29. [[spell:31935]]
30. [[spell:53600]]
31. **适用条件：奥术激流（鲜血精灵）（启用）。** [[spell:155145]]

### 单体目标循环

1.2.

#### 单体目标循环优先级顺序

在起手式之外，你需要遵循技能的优先级顺序。当技能冷却完毕时，优先使用列表中位置较高的技能。

---

1. [[spell:384376]]
2. **适用条件：铸光者（启用）。** 如果你没有激活[[spell:384376]]，使用[[spell:432472]]
3. [[spell:375576]]
4. **适用条件：圣殿骑士（启用）。** [[spell:429826]]
5. 如果你没有站在其中，使用[[spell:26573]]
6. **适用条件：Glory of the Vanguard (Final Apex Point)（启用）。** 如果[[spell:1268810]]已激活，使用[[spell:31935]]
7. 当你拥有3到5点神圣能量之间时，使用[[spell:53600]]
8. [[spell:1241288]] / [[spell:20271]]
9. **适用条件：Blessed Hammer（启用）。** [[spell:204019]]
10. **适用条件：正义之锤（启用）。** [[spell:53595]]
11. [[spell:31935]]
12. **适用条件：奥术激流（鲜血精灵）（启用）。** [[spell:155145]]
13. **适用条件：圣殿骑士（启用）。** 如果你有一层[[spell:321136]]充能且生命值低于50%，使用[[spell:85673]]
14. **适用条件：铸光者（启用）。** 如果你有一层[[spell:321136]]充能，使用[[spell:85673]]
15. 如果其他所有技能都在冷却中，使用[[spell:26573]]以刷新持续时间

### AOE循环

1.3.

#### AOE循环优先级顺序

在起手式之外，你需要遵循技能的优先级顺序。当技能冷却完毕时，优先使用列表中位置较高的技能。

---

1. [[spell:384376]]
2. **适用条件：铸光者（启用）。** 如果你没有激活[[spell:384376]]，使用[[spell:432472]]
3. [[spell:375576]]
4. **适用条件：圣殿骑士（启用）。** [[spell:429826]]
5. 如果你没有站在其中，使用[[spell:26573]]
6. 如果[[spell:1268810]]已激活，使用[[spell:31935]]
7. 当你拥有3到5点神圣能量之间时，使用[[spell:53600]]
8. [[spell:31935]]
9. [[spell:1241288]] / [[spell:20271]]
10. **适用条件：Blessed Hammer（启用）。** [[spell:204019]]
11. **适用条件：正义之锤（启用）。** [[spell:53595]]
12. **适用条件：奥术激流（鲜血精灵）（启用）。** [[spell:155145]]
13. **适用条件：圣殿骑士（启用）。** 如果你有一层[[spell:321136]]充能且生命值低于50%，使用[[spell:85673]]
14. **适用条件：铸光者（启用）。** 如果你有一层[[spell:321136]]充能，使用[[spell:85673]]
15. 如果其他所有技能都在冷却中，使用[[spell:26573]]以刷新持续时间
16.

### 至暗之夜 第2赛季套装

第2赛季的套装奖励[[spell:1296658]]和[[spell:1296659]]，专注于通过让敌人处于[[spell:26573]]内部（他们默认应该在那里）来提高你的伤害。

这套套装专注于通过暴击提高你的伤害。[[spell:1296658]]将你对处于[[spell:26573]]内的敌人的暴击几率提高5%，而[[spell:1296659]]简化后使[[spell:204019]] / [[spell:53595]]和[[spell:20271]]造成20%的额外神圣伤害（暴击时可造成40%的额外伤害）。

从纯粹的DPS角度来看，这将使属性权重向暴击倾斜，以利用4件套的双倍伤害部分。

1.

### 职业与专精机制详解

为了更好地解释防护圣骑士技能组合的具体用法和好处，我们整理了关于这些细节的更详细说明，以帮助你提高对一般坦克玩法以及防护圣骑士游戏的掌握程度。

### 仇恨制造与嘲讽

3.1.

#### 仇恨制造与嘲讽

**仇恨** 是你让敌人持续攻击你的基础。这是通过伤害敌人的功能来实现的，使你成为对他们最具威胁的目标。

攻击将产生 **每点伤害产生1点威胁值**。对于坦克来说，这个数值提升至
**每点伤害产生10.5点威胁值**。这实际上意味着，只要你的DPS造成的伤害不超过你的9.5倍，你就能将威胁值保持在他们之上。这听起来相当高（确实如此），但某些DPS专精可以在冷却窗口内造成极其恐怖的爆发伤害，从而从你手中抢走威胁值。在这种情况下，你需要使用自己的冷却技能来跟上！

每个单独的敌人都有自己独立的威胁值列表，该列表基于他们从每个玩家身上承受的伤害。

:::details 常见问题：治疗怎么办？
关于治疗威胁值的规则并不是很统一，但通常来说，如果你在治疗另一名玩家，会产生威胁值；如果你是治疗者，你所做的任何治疗都会产生威胁值， **如果你治疗自己，则不会产生威胁值**，最后，出于某种奇怪的原因，如果你使用治疗药水，它会产生威胁值。

治疗威胁值会在范围内所有敌人之间分摊。

:::

3.2.

#### 威胁值产生

那么作为坦克，我们如何有效地产生威胁值呢？这非常简单，就是打出伤害。按照预期打出你的输出循环，除了极少数DPS造成极高爆发伤害的情况外，你不会遇到太多困难。在这些情况下，我们还有
**嘲讽技能** 来帮助我们。

3.3.

#### 嘲讽

[[spell:62124]]是你的嘲讽技能。它只能对单个目标生效，冷却时间为8秒，强制目标攻击你3秒（即使你当前有免疫效果生效），使你位于该怪物威胁值列表的顶端，并使你产生 **8倍的威胁值，持续3秒** （这是在原有的9.5倍修正系数基础上进行乘算的）。

### 主动减伤

3.4.

#### 防护圣骑士的主动减伤

[[spell:53600]]和[[spell:85673]]是你的两个主动减伤技能（尽管荣耀圣令是一个治疗技能，所以它并不真正
<em>减伤</em> 伤害）。

3.5.

#### 正义盾击

[[spell:53600]]是你的主要伤害减免技能。它消耗3点神圣能量，每次施放都会给你一个持续4.5秒的增益效果，提高你的护甲值（护甲值的提升量由你的力量决定）。正义盾击会对正前方的所有敌人造成伤害，且不需要选中目标即可施放。

正义盾击不在全局冷却时间内，所以你可以轻松地将它穿插在你的常规输出循环中。使用的具体时机很大程度上取决于你的情况，但总体而言，你应该力求在战斗中几乎全程保持它处于激活状态，当无法做到时，你应该利用战斗中的空档来积攒神圣能量，例如当你在团队副本中拉怪但尚未获得首领的威胁值时。

你在使用产生神圣能量的技能时，要避免在拥有5点神圣能量时溢出，但同时也要避免在拥有3点神圣能量时使用[[spell:53600]]，因为如果紧接着又需要它，你可能没有时间再次积攒神圣能量。

3.6.

#### 荣耀圣令

[[spell:85673]]消耗3点神圣能量，是一个小型治疗技能，其治疗量会根据你损失的生命值而增加。

鉴于其消耗神圣能量，你应该等待到你的生命值处于一个相对安全的低水平（大约30-50%生命值）时再使用荣耀圣令，以在不死的情况下获得最大收益。每施放3次[[spell:53600]]会让你获得一层[[spell:321136]]，使你的下一次荣耀圣令免费施放。你最多可以同时拥有两层[[spell:321136]]充能。

你的总体目标应该是只在[[spell:321136]]使其免费时才使用[[spell:85673]]。

如果你玩的是 **铸光者** 你会想要更频繁地使用你的[[spell:321136]]充能，因为它们会为你的英雄天赋技能提供冷却缩减。

**可选：** [[spell:315924]]可以在你需要帮助治疗者的情况下使用，你将有效地成为另一名治疗者来支援他们。它将使你能够获得基于其他玩家损失生命值的治疗量加成，但代价是无法使用[[spell:53600]]来造成伤害。这也带来了 **法力值耗尽** 的额外风险，因为如果你治疗其他玩家过多，你将没有法力值来进行标准输出循环，并可能因此死亡。

### 光环

3.7.

#### 作为防护圣骑士的光环

有三种光环可供选择，且整个团队同一时间只能激活其中一种。 **它们不会相互叠加**。如果你的团队中有多个圣骑士，你们每人使用不同的光环会更有利。通常这会遵循以下优先级：

- 神圣圣骑士会想要使用[[spell:465]]。
- 第二名圣骑士将使用[[spell:32223]]（这会使[[spell:190784]]更快）。
- 如果存在你无法消除的沉默效果，那么第二/第三名圣骑士应该使用[[spell:317920]]。

光环有什么作用？：

- [[spell:465]]：激活时，此光环将使范围内所有人受到的伤害降低3%。此光环默认使用，唯一的例外是当你的团队中有多个圣骑士时，其中一人会使用另一种光环以确保你们都能受益于多种光环。在你的团队中有神圣圣骑士的情况下，他们应该使用[[spell:465]]，因为他们的[[spell:31821]]会强化它使其更强。
- [[spell:32223]]：激活时，这将使范围内所有玩家的坐骑速度提高20%。有趣的是，这也适用于[[spell:190784]]。此光环主要在你骑乘坐骑时使用。
- [[spell:317920]]将使打断和沉默效果的持续时间缩短30%。

### 巅峰天赋

3.8.

#### 防护圣骑士的巅峰天赋

随着至暗之夜的到来，新增了巅峰天赋。每个专精都将获得新的天赋，而防护圣骑士将获得[[spell:1267203]]。这是一套被动技能，随着你投入更多点数，其威力会随之增强。

- [[spell:1267203]]第一点：[[spell:20271]]有几率赋予你先锋效果，这将使你的下一次[[spell:31935]]对你和目标之间的所有敌人造成伤害。
- [[spell:1267211]]第二点：当先锋效果被消耗时，你将获得1点神圣能量。[[spell:20271]]造成的伤害提高10%。
- [[spell:1267211]]第三点：神圣能量提高至3点，伤害提高至20%。
- [[spell:1267215]]最后一点：先锋效果被消耗后，[[spell:53600]]将对主要目标造成提高20%的伤害并造成一些范围伤害。在[[spell:384376]]期间，每次施放[[spell:31935]]都将受益于先锋效果。

这实际上意味着施放[[spell:20271]] / [[spell:24275]]将赋予你先锋增益。这使得[[spell:31935]]最多产生3点神圣能量，意味着你随后可以立即施放[[spell:53600]]。在[[spell:384376]]期间，由于与之一起施放[[spell:375576]]以及每5秒从[[spell:355098]]获得的免费[[spell:31935]]，你将拥有非常高的神圣能量获取量。

1.

### 防护圣骑士的重要冷却技能

### [[spell:642]]

[[spell:642]]是游戏中最强大的防御性冷却技能之一，因为它使你对几乎所有东西免疫（只有少数首领技能会无视免疫效果）。然而它有一个主要缺点。

如果你处于免疫效果下，敌人会忽略你直到效果结束。不过有办法规避这一点。

- [[spell:204077]]天赋将在[[spell:642]]持续期间，强制对周围所有敌人施加嘲讽效果。
- 你可以在嘲讽生效期间使用[[spell:62124]]，在短暂的锁定期间强制敌人攻击你。（你需要在效果结束前取消[[spell:642]]，以确保他们不会短暂攻击其他人，可以使用如下宏： [这个](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-macros-addons#divine-shield>)).
- 如果你试图消除的效果是直接对你施放的，并且施法已经开始，它将会在你身上完成。在施法开始时施加[[spell:642]]，在效果结算后移除[[spell:642]]。
- 你也可以直接使用[[spell:642]]来移除身上的有害减益效果，方法是通过取消光环宏（上文已链接）瞬间施加并移除[[spell:642]]。

关于[[spell:642]]还有一点需要注意，如果存在一个随机选择玩家的机制。如果你在目标选择过程开始前对该效果免疫，你将被完全排除在潜在目标之外。这在某些情况下是有利的，但在其他情况下可能有害，因为它会转而选择另一名玩家。

### [[spell:1022]]

[[spell:1022]]让你可以对其他玩家使用许多同样的技巧（因为它可以对任何团队成员施放）。它能移除许多物理持续伤害效果和流血效果。在有几名圣骑士的团队中，这可以消除原本复杂的机制所带来的危险。

此外，锁定随机玩家的怪物通常会忽略目标实际上对保护祝福免疫的事实。当怪物选择法系输出或治疗者作为目标时，这特别有用，因为它可以让他们跳过风筝怪物并保持完整的DPS/HPS输出。

最后，保护祝福经常以与神圣之盾相同的方式绕过目标选择机制。在目标选择过程开始前对玩家施放保护祝福可以确保他们不会被选中。这可以让他们移动到原本对自己或团队危险的位置。

### [[spell:204018]]

[[spell:204018]]在功能上与[[spell:1022]]相同，但针对的是魔法技能。它与[[spell:1022]]共享相同的冷却时间。它不像[[spell:642]]（物理/魔法）或[[spell:1022]]（仅物理）那样移除减益效果。

### [[spell:633]]

[[spell:633]]本质上是一个带有极长冷却时间的大型治疗技能。它将为你（或指定的盟友）恢复相当于你最大生命值的生命值，冷却时间为10分钟。最好作为紧急治疗使用，无论是为了你自己还是另一名团队成员

在这些情况下你应该优先使用[[spell:85673]]来治疗自己，但如果是为了另一名玩家，你应该使用[[spell:633]]来挽救他们的生命。

### [[spell:384376]]

[[spell:384376]]使造成的伤害和治疗量都提高20%。这还会将[[spell:20271]]变为[[spell:24275]]，给你造成更多伤害。在点出天赋后，你还将获得所有圣骑士技能20%的暴击几率。

### [[spell:385438]]

[[spell:385438]]取代了[[spell:384376]]。[[spell:385438]]将以15层神圣决心开始。每层给你2%最大生命值并使你受到的伤害降低2%，持续20秒。5秒后，你将每秒失去1层，但消耗3点神圣能量可以防止失去一层。你保留[[spell:384376]]的其他加成，同时拥有[[spell:385438]]（伤害提高、暴击，以及将[[spell:20271]]变为[[spell:24275]]）。

暴击加成在哨兵下得以保留是12.1补丁的新内容，使得获取[[spell:385438]]不再是DPS的损失。

### 伤害减免冷却技能

防护圣骑士拥有两个伤害减免冷却技能：[[spell:31850]]（短冷却）和[[spell:86659]]（较长冷却）。

- [[spell:86659]]为你提供50%的伤害减免，持续8秒，冷却时间为3分钟。你应该在承受大量伤害之前使用它。
- [[spell:31850]]是另一个强大的防御技能，冷却时间为1.5分钟，持续时间为8秒。激活期间，它使你受到的所有伤害降低20%，并且使对你造成的第一次致命一击改为为你恢复高达12%最大生命值而不是杀死你（后一个效果会消耗炽热防御者）。此技能最适合用于规避致命的战斗机制或在关键时刻挽救你的生命。它还允许你在低生命值下战斗并保持安全。

你不应该害怕使用[[spell:31850]]，因为它经常可用，但你对[[spell:86659]]的使用应该更有计划性，因为它没有那么容易获得。你可以通过[[spell:1246481]]获得第二层[[spell:86659]]充能，使其更容易使用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年9月21日：** 更新了神圣之器的起手式。
- **2026年8月10日：** 针对补丁12.1进行了审查并添加了起手时间轴。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对补丁11.2更新。降低了复仇者之盾的循环优先级。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024 年 10 月 7 日：** 修复了选择英雄天赋和更新循环的问题。
- **2024年9月16日：** 更新了英雄天赋的按钮，并在页面加载时添加了默认选项。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为地心之战上线更新，添加了不同天赋和英雄天赋的新复选框。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 重新措辞了减伤冷却部分。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 移除了关于炽天使的引用。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为清晰起见，将复仇者之盾添加到循环优先级列表中。已针对10.1版本进行审查。
- **2023年3月20日：** 移除了黄昏与黎明部分，因为它在10.0.7补丁中被重做为被动效果。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 添加了一个小章节来讨论套装对输出循环的影响。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到魔兽世界12.1.5版本中防护圣骑士的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们都为你准备好了！

1.

### 防护圣骑士毕业装备指南

欢迎来到至暗之夜第2赛季防护圣骑士的装备和毕业页面。查看此页面，了解关于为防护圣骑士配装你需要知道的一切，包括来自所有来源的毕业装备、团队副本和大秘境、关于最佳饰品、套装等信息。

一般来说，你会优先考虑装等提升而不是较低装等的“最优”物品，因为你的生存能力严重依赖于力量和耐力。如果在同一装等下有选择，在一般情况下，另一种选择在防御方面可能不会有太大差别。我们建议直接模拟一下选择，然后做任何能帮助你造成更多伤害的事情。

这条规则有例外，以及某些战斗中特定属性被大幅贬值的情况。你应该关注团队副本战斗指南以了解这一点。同样，某些大秘境层数和地下城需要略有不同的配装路线。我们在下方链接了相关指南，但通常我们也会在这里添加说明。

:::details 常见问题：我可以模拟自己作为坦克吗？
进攻方面，是的，你可以。SimulationCraft支持防护圣骑士的DPS模拟，这是确定物品、附魔、宝石或天赋是否能提升你的伤害输出的推荐方式。

防御方面，不行。通常不建议模拟坦克的防御。要准确模拟坦克场景，涉及的因素和变量实在太多，而且没有单一的指标能告诉你“这件物品或天赋会让你更耐抗”。例如，某样东西可以减少你的总承受伤害，但不能提高你应对伤害尖峰的能力，而这两个坦克因素的重要性会因战斗而异。遵循指南中关于防御配装的建议，会比遵循模拟结果好得多。

还值得注意的是，在评估进攻性装备选择时，模拟假设的是最优操作。如果你没有看到与模拟相似的DPS提升水平，你可能需要回顾你游戏玩法的某些方面，以评估改进的领域。我们建议上传一些游戏记录到Warcraft Logs，因为它成为一个更容易独立回顾的平台。

:::

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含至暗之夜第2赛季中来自任何来源的毕业装备。它作为参考，展示了目前防护圣骑士从所有来源可获得的最高表现装备。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。目前的毕业装备可能与下面不同，因为这将是一个终局配置的示例，并作为你应追求哪些物品的指南。

:::details 常见问题我需要哪些套装部件？
在这个赛季中，你保留了你催化物品的加成，这意味着全部5件套装部件都可以选择。对于你特别想要催化获得的物品，它们是：

- 头盔：[[item:281239@JAAGAAgsSYjMhbD]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>).
- 肩膀：[[item:251138]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>).
- 胸甲：[[item:268222@JAAEAAgsSghN]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) （9/6史诗难度）。
- 手套：[[item:268220@JAAEAAgsSYjM]]，来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>).
- 腿部：[[item:271878@JAAEAAgsSghN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) （9/6史诗难度）。

:::

:::details 常见问题：从宏伟宝库中获取什么？
关于大秘库，你有两个选择。一种是常规思路，另一种是优化思路。常规思路是，如果你已经击杀了

**史诗难度**

最后两个首领，就选择其中的物品，因为它们将是9/6史诗。接下来，来自

**史诗团本**

的其他物品在秘库中会显示为6/6史诗。最后，英雄难度的击杀将从秘库中产出1/6史诗物品。这是第二赛季的一项改动。按照优化思路，你可以选择每周从秘库中获取一个额外拾取机会（Bonus Roll），并专门针对一个掉落多种优质物品的首领（

[盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

,

[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

）。要实现这一点，你应该

**不通过常规手段获取物品**

（赢得掷骰或由分配给你），因为你的额外拾取机会有可能获得重复物品。

**这种方法只应由已经就战利品分配方式达成一致的有组织团队使用。**

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271465@JAAGAAgsSYjMhbD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271466@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAgsSghN]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAAEAAgsSghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271463@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271464@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAAEAAgsSghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271468@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268196@JAAEAAgsSgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

### 秘境+

本列表包含至暗之夜第二赛季中来自大秘境的毕业装备。它作为参考，展示了目前玩家仅通过地下城可获得的最高性能装备。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。目前的毕业装备可能与下面不同，因为这将是一个终局配置的示例，并作为你应追求哪些物品的指南。

:::details 常见问题我需要哪些套装部件？
在这个赛季中，你保留了你催化物品的加成，这意味着全部5件套装部件都可以选择。对于你特别想要催化获得的物品，它们是：

- 头部：[[item:239050@JAAEAAgsSYjM]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>).
- 肩部：[[item:251138@JAAEAAgsSYjM]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>).
- 胸部：[[item:193753@JAAMAAQkCYHKvbRLfIrE2ID]]，来自 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>).
- 手套：[[item:159413@JAAEAAgsSYjM]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>).
- 腿部：[[item:159435@JAAEAAgsSYjM]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>).

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：该地下城包含大量高价值装备栏位：武器、饰品、戒指，以及一些可用于催化套装的部件。
- [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)：拥有你想要刷的盾牌。
- [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)：拥有种类繁多且适合用于催化的战利品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271465@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271466@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:273781@JAAEAAgsSgjM]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>腰部</th><td>[[item:159418@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271463@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271464@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271468@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:159459@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250259@JAAEAAgsSgjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:250245@JAAEAAgsSgjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:251218@JAAEAAgsSgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:251150@JAAEAAgsSgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span></div></td></tr></tbody></table>

### 团队副本

本列表包含至暗之夜第二赛季中来自团本的毕业装备。它作为参考，展示了目前玩家仅通过团本可获得的最高性能装备。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。目前的毕业装备可能与下面不同，因为这将是一个终局配置的示例，并作为你应追求哪些物品的指南。

:::details 常见问题我需要哪些套装部件？
在这个赛季中，你保留了你催化物品的加成，这意味着全部5件套装部件都可以选择。对于你特别想要催化获得的物品，它们是：

- 头盔：[[item:281239@JAAGAAgsSYjMhbD]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>).
- 肩部：[[item:271444@JAAEAAgsSYjM]]，来自小怪掉落，带有急速和精通属性。
- 胸甲：[[item:268222@JAAEAAgsSghN]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) （9/6史诗难度）。
- 手套：[[item:268220@JAAEAAgsSYjM]]，来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>).
- 腿部：[[item:271878@JAAEAAgsSghN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) （9/6史诗难度）。

:::

:::details 提示：我最想要哪些团队副本物品？
各个团本中有很多优质物品。下面你可以找到一些你应该优先获取的物品。

- [[item:268209@JAAEAAgsSYjM]]：带有特殊效果的武器。一旦你获得[[item:270173@JAAEAAgsSYjM]]，它将开始顺劈。
- [[item:270173@JAAEAAgsSYjM]]：用于激活上述武器。
- [[item:268265@JAAEAAgsSYjM]]：每个人都会想要的特殊项链。
- 如果你是史诗团本玩家，最后两个首领将为你提供9/6史诗物品。这包括胸甲、腿甲、武器、饰品和腰带。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271465@JAAGAAgsSYjMhbD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271466@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAgsSghN]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAAEAAgsSghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271463@JAAEAAgsSYjM]]&#10;&#10;<div><span>小怪掉落，带有 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271464@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAAEAAgsSghN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271468@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 使用 <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268249@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAIAAgsSAGMRDDD2A]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/protection-paladin-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268196@JAAEAAgsSgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 防护圣骑士饰品推荐

作为一名防护圣骑士，或者任何坦克，你的饰品栏位可以成为解决防御问题的强大工具。在许多情况下，你的职业技能（防御性冷却技能）将完全覆盖这些需求，你可以倾向于选择更具进攻性的饰品，这些饰品将在下方排名。在你确实需要额外防御层的情况下，会有一个“防御”梯队，详细说明具有此类价值的饰品。

随着至暗之夜防护圣骑士的改动，现在以1分钟为循环运作，因此能够在此循环上使用的饰品表现会更好，因为它将与[[spell:384376]]和[[spell:375576]]对齐。这意味着1/2/3分钟冷却的饰品将比1.5分钟冷却的饰品更受青睐。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **防护圣骑士饰品**
**使用型 -**

[[item:270175@JAAEAAgsSYjM]]

**被动 -**

[[item:270173@JAAEAAgsSYjM]]

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>)  	点击查看防护圣骑士饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270175]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168]] - <span><em>点击查看详情</em></span>&#10;<span>这个饰品可以提供大量的爆发伤害，这在拥有伤害增幅阶段或爆发DPS检测的战斗中尤其有用，例如 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 或 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a>。4分钟的冷却时间可能看起来不太理想，但它能提供的伤害量弥补了这一点。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164]] - <span><em>点击查看详情</em></span>&#10;<span>这个饰品提供的增益相当不错，但你无法控制哪个副属性获得增益或何时获得增益。高触发率弥补了这一点。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215]] - <span><em>点击查看详情</em></span>&#10;<span>叠加暴击率，且拥有非常高的覆盖率。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270602]] - <span><em>点击查看详情</em></span>&#10;<span>这个饰品每分钟为你提供大量力量。它与我们的冷却时间完美契合，但有一个很大的缺点……你需要进行PVP。由于它是一件PVP物品，它将拥有固定的物品等级，并且会被完全升级的英雄轨迹饰品以及本列表中的任何史诗饰品所超越。</span>&#10;<li>&#10;&#10;&#10;[[item:273796]] - <span><em>点击查看详情</em></span>&#10;<span>2分钟冷却的随机副属性。它将与[[spell:384376]]的每次使用对齐，但可能随机到精通，使其威力大减。它还有一个缺点，就是在触发后会降低该副属性，而这通常是你失去[[spell:385438]]覆盖的时候。</span>&#10;</li>&#10;<li>[[item:158367]]</li>&#10;<li>&#10;&#10;&#10;[[item:250259]] - <span><em>点击查看详情</em></span>&#10;<span>一个简单的被动伤害饰品，带有力量属性。</span>&#10;</li>&#10;</li></ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>防御饰品</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270160]] - <span><em>点击查看详情</em></span>&#10;<span>1分30秒的大型吸收护盾。可以说这是目前可用的最佳选择，因为它既可控又能纳入你的冷却时间规划中。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250245]] - <span><em>点击查看详情</em></span>&#10;<span>随机吸收。在寻找防御饰品时，你希望它能解决一个具体问题，而这个饰品无法做到，因为你无法控制效果何时发生。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270174]] - <span><em>点击查看详情</em></span>&#10;<span>一个奇怪的饰品，为你提供固定数量的精通，但只在触发时才提供力量，所以在触发之前，作为一名坦克你会实际上更弱。平均而言，任何其他饰品都会因为被动力量（力量提供护甲，并且带来更多伤害，从而使你的循环吸收更强）而为你提供更多的防御收益。</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

额外拾取机会（Bonus Roll）在第二赛季中依然存在。你现在只需要使用1个虚空核心（Voidcore）即可对任何物品进行额外拾取（此前团本物品需要2个，其他来源需要1个）。它们的获取方式略有改变：

- **从第二赛季开始：** 你可以将虚空核心作为奖励选项从大秘库中获取。
- **从第二赛季第8周开始：** 你每周可以购买1个虚空核心。

3.1.

#### 防护圣骑士虚空核心推荐用法

你使用虚空核心的主要目标是获取难以获得的物品，例如饰品，因为它们在你的队伍中面临DPS玩家的激烈竞争。然而，如果你还没有武器或盾牌，那么它们也是值得追求的好选择。你还应该考虑潜在的战力以达成你的游戏目标，例如，如果你的公会还没有击杀史诗难度的Belo'ren，那么你存着多个虚空核心就没有价值，因为它们可以提供你在本周重置后击杀该首领所需的战力。你将在下周重置后再获得2个。总体优先顺序如下：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 史诗轨迹[[item:268209]]
2. 史诗轨迹[[item:270173]]
3. 史诗轨迹盾牌（如果你还没有锻造盾牌）
4. 剩余的毕业装备列表物品

:::

3.2.

#### 晋升毒液石

[[item:280562]]将把你的6/6英雄/史诗物品升级到8/6英雄/史诗。这些将 **不适用于** 在盘结祭坛（Coiled Altar）和乌拉特克（Ulatek）史诗难度下以9/6史诗掉落的物品。你的升级优先顺序将遵循与你的纹章优先顺序相同的顺序：

1. 主手武器为最高优先级。
2. 你的主动使用饰品（用于输出）或你的盾牌（用于防御）。
3. 你的被动饰品。
4. 你的项链。

你还需要优先考虑史诗轨迹物品，而非英雄轨迹物品。此外，如果你近期不打算在史诗难度击杀盘结祭坛或乌拉特克，那么升级英雄难度的 **额外拾取** 版本的这些物品是完全可以的，因为战力提升将远大于一件普通的史诗或英雄物品。

1.

### 防护圣骑士最佳美化

通常来说，你希望在你的两件美化物品上都使用[[item:240167]]。

然而，如果你预计在头几周内无法获得史诗武器或盾牌，这将改变你的美化优先级，因为你无法在锻造武器上使用[[item:240167]]。

下文将详细说明制作什么以及何时替换它们。

1.

### 防护圣骑士最佳锻造物品

赛季初制作物品应围绕你的进度目标。在赛季开始时，最好制作一把 **武器** ，因为它们稀缺且在几周内无法轻易获得。如果你获得了一把1/6史诗武器作为替代，它们在纹章消耗上也是持平的。然后我们将专注于获取我们的美化物品。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **防护圣骑士制作顺序**
任何使用史诗纹章制作的力量单手武器，例如

[[item:237839]]

使用

[[item:245876]]

如果你是

**非**

史诗团本玩家

[[item:237831]]

使用

[[item:240167]]

一旦你拥有了史诗轨迹武器/盾牌：

[[item:237834]]

使用

[[item:240167]]

一旦你同时替换了武器和盾牌：制作一双

[[item:237828]]

使用

[[item:240167]]

.

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

5.1.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

在至暗之夜中完成终局活动将奖励你纹章。一旦你将某个栏位升级到特定物品等级， **将该栏位的其他物品升级到该物品等级就是免费的**.

我们建议 **非** 在至暗之夜第二赛季的头几周使用史诗纹章升级装备。这样做的原因是，至暗之夜中的纹章升级成本已经增加，这意味着你每周能升级的物品更少。因此，如果可能的话，你有动力去策略性地规划你的升级，并优先制作史诗轨迹的美化物品。

**纹章优化提示：** 如果你不打算制作武器/盾牌，尽量获取一把力量双手武器（惩戒骑拾取专精）并升级它，这样升级武器和盾牌就变成了免费操作。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **防护圣骑士纹章升级优先级**
**武器**

/

**盾牌**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜ 其他护甲/模拟推荐

:::

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 包含来自基希克斯的新物品以及升华毒石的物品升级建议。
- **2026年9月21日：** 饰品推荐中加入了剧毒之怒之源。
- **2026年9月4日：** 修正了错误的戒指位置。
- **2026年8月18日：** 更新了配装建议，首批物品改动。
- **2026年8月10日：** 更新了补丁12.1中第2赛季的配装建议。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 为非史诗团本玩家添加了盾牌制作建议。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 针对补丁11.2.5更新。添加了辛迪加徽记建议。调整了更换迪斯科腰带的时机。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月13日：** 更新了辛迪加徽记建议。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月17日：** 更新了塞尔西的指环信息。它获得了增强，现在真的值得使用了。它就是毕业装备！
- **2024年12月15日：** 添加了塞尔西的指环部分。简而言之：如果你的装等是636/639，那它就不是毕业装备。否则，宝石推荐已在页面上列出。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月28日：** 饰品更新。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已更新为《地心之战》上线时的赛季前毕业装备。随着第1赛季临近，还将有进一步更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月28日：** 更新了永恒黎明的链接，使其对应到各自的钥石地下城。
- **2023年11月7日：** 更新了页面以考虑孢子斗篷的削弱。纹章推荐已针对此进行了更改。
- **2023年11月6日：** 已更新至第 3 赛季。
- **2023年9月4日：** 更新了装备搭配，新增了毕业装备列表。
- **2023年7月10日：** 更新了昂萨贡戒指章节，说明何时更换这枚戒指。增加了10.1.5版本物品章节。
- **2023年5月1日：** 将黑曜石指环部分移至页面底部（它对伤害依然很好！）。已为第2赛季更新装备、饰品和美化。
- **2023年3月20日：** 添加了奥妮克希亚指环章节。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对第1赛季更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的防护圣骑士的最佳属性优先级。我们首先展示属性优先级，然后深入解释这些属性如何与你的专精和玩法相互作用。我们的内容已针对《魔兽世界》12.1.5版本更新。

1.

### 防护圣骑士属性优先级

如果你总是担心死得太快，我们建议按照以下属性优先级选择防御性配装。

急速

全能

精通

暴击

在进攻方面，防护圣骑士的属性优先级如下：

急速

暴击

全能

精通

重要的是要考虑到，你的副属性价值都非常接近，而物品等级是装备升级中最重要的方面。在大多数情况下，这种属性优先级只有在你拥有两件相同物品等级的物品时才真正有用。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **评估你的属性优先级**
上面显示的属性优先级可能与模拟结果不同，因为你当前的装备情况可能表明其他属性更好。为了获得最佳结果，建议定期对你的升级进行模拟。

:::

1.

### 深入属性解析

**急速** 减少你的公共冷却时间以及大部分循环技能的冷却时间。急速的主要任务是提高[[spell:53600]]的覆盖率，总体上平滑伤害摄入，并使你更容易被治疗。在约20%急速时，你将拥有足够的循环神圣能量来实现正义盾击的极高覆盖率。在约25-30%急速时，你将能够在不担心正义盾击覆盖率下降的情况下施放[[spell:85673]]。一旦你达到这个急速水平，你就应该开始寻求最大化其他属性的收益，而非继续堆叠急速。

**精通**，得益于[[spell:76671]]，可以提高你格挡攻击的几率和你的攻击强度。精通还允许你以格挡值2倍的速率格挡法术和周期性伤害。最后，精通会提高你的攻击强度，这将提升你技能的伤害，但不会提升来自外部来源的伤害，例如饰品或附魔。

:::details 常见问题：我应该拥有多少精通？
在至暗之夜中，几个专门针对提高格挡几率的天赋已被移除。然而，精通已被改为每1%精通提供1%物理格挡和2%法术格挡。仅靠堆叠精通的话 **不可能达到100%格挡** ，因为有递减收益。在9200精通等级（你能拥有的最大值，超过这个值的部分会被忽略）时你能获得的最大值为：

- **93.72% 法术格挡**。使用[[spell:462854]]后提升至94.24%。
- **78.31% 物理格挡** 使用[[spell:462854]]后提升至78.86%。

:::

**全能** 提高你造成的所有伤害和治疗量，同时降低你受到的伤害。全能每点提供的减伤略高于精通，并且它在[[spell:26573]]之外也会生效。然而，由于它也缺少格挡几率，因此不如精通强力。

**暴击** 提高你的伤害和治疗输出，并且还为你提供招架，因为每1点暴击你会获得1点招架。除了招架提升之外，暴击在防御方面对你的帮助很小，而招架可以增加[[spell:85043]]触发的频率。值得注意的是，在多个来源进行物理攻击的情况下（大秘境），招架会成为一项非常有价值的防御属性。

**力量** 提高你从[[spell:53600]]获得的护甲值、你的攻击强度以及你的招架几率（少量）。

在大多数战斗中，你需要有足够的生命值，以便在下一次攻击杀死你之前有机会获得治疗。除此之外 **最低耐力值**，我们认为耐力对防护圣骑士来说仍然相当有价值。然而，你的大部分耐力天生就在装备上，但拥有额外的耐力总是个好选择，以备在必要时通过饰品、附魔和宝石（按此顺序）暂时获得。随着你对每场战斗所需的生存能力更加熟悉，你可以将部分耐力转移到其他属性上。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 更新了精通和格挡的属性阈值。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 更新了精通数值，包含达到100%格挡阈值的最新建模。
- **2026年3月23日：** 更新了属性优先级，在标准优先级之外展示了防御属性优先级。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 更新了每个英雄天赋的属性优先级。添加了达到100%格挡的特定精通阈值。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》上线进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页，我们列出了你的防护圣骑士可以获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/protection-paladin-pve-tank-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你应该在你的第一个可用插槽中使用[[item:240983]]，其余插槽全部填入[[item:240892]]。虽然还有许多其他永歌钻石选择和副属性宝石可用，但这两者提供了最佳收益。

1.

### 最佳附魔和武器强化

[[item:243733]]作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士或[[spell:433568]]作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者.

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:244643]]</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244017]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>或[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

在所有内容类型中使用[[item:241326]]作为通用合剂。

3.2.

#### 药水

[[item:241308]]应该是你的战斗药水首选。

你应该使用[[item:271883]]进行战斗中治疗。治疗药水与[[item:5512]]不共享冷却时间，所以如果你能接触到术士，你可以独立使用两者。

3.3.

#### 食物增益

如果没有盛宴可用，则使用[[item:242274]]（副属性）作为你的食物增益首选。

如果团队提供了[[item:255846]]（主属性）/[[item:242273]]（副属性），则改用它们。 **两者都可以。**

在决定使用哪种食物类型时，最好对两种选项都进行模拟，以确定哪一种对你更好。盛宴和个人食物增益都提供主属性（力量）和最高副属性选项。

3.4.

#### 强化符文

此外，如果经济允许，你应该使用[[item:259085]]来提高你的主属性。强化符文在资料片的最后一个赛季之前会很贵，且死亡时会消失，所以请明智使用！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对补丁12.1更新，新增生命药水。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 移除了关于茶的提及，因为它们不再可以在副本内使用。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对补丁11.2更新。移除了腐蚀部分，因为这在第3赛季不再有效，并将治疗药水更改为新的活力治疗药水。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月16日：** 更新了凡图斯符文信息。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战正式上线更新了新的宝石、附魔和消耗品。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 添加了头盔附魔和新的治疗药水。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月14日：** 更新了武器附魔和药剂推荐。武器附魔部分更明确地说明了两种选择，不过这两种选择在输出方面相当接近。药剂已改为微温全能药水，因为外部伤害来源的出现频率增加了。
- **2023年7月10日：** 更新了玛瑙指环和原初宝石部分，以及何时考虑替换它。
- **2023年5月1日：** 添加了腰带附魔（10.1版本新增）并针对第2赛季进行了审查。
- **2023年3月25日：** 更新了原始宝石推荐。
- **2023年3月20日：** 添加了奥妮克希亚指环和太古宝石章节。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的防护圣骑士挑战大秘境地下城的技巧和建议。

1.

### 防护圣骑士在至暗之夜第2赛季的大秘境中

防护圣骑士在大秘境中非常强大，这得益于他们的自我和团队治疗、驱散、功能性，以及使用[[spell:31935]]锁定施法怪物的能力。虽然我们缺乏强制移动敌人的能力，但我们在功能性方面弥补了这一点。

如果你想了解更多关于地心之战中大秘境的一般信息，或防护圣骑士在整体排名中的位置，请参阅下面的概述。

1.

### 最佳大秘境天赋配置

### 秘境+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士

2.1.

#### 秘境+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士将在每周钥匙中为你提供良好的爆发性DPS，[[spell:429826]]和[[spell:375576]]在每一波拉怪中都可用。它还提供了更轻松的钥匙体验。

**使用'导出天赋'按钮将最佳构建直接导入你的游戏中。**

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAAAAAAAAQTzMMjZGGzWbAYgBMD2GAAYmptZmlZAA2ssgBAjZYMAALzAmZGwYB"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiKuxxYjbFEU1NQSC1LD-YOAJwMVkBilXuHQf6ausElQJIUEKZDkG-AAAA-bYWUoEcAQMxQAB-
```

:::

### 秘境+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者

2.2.

#### 秘境+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者是本赛季更高层数钥匙的首选。它提供的总伤害比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/templar.webp>) 圣殿骑士更多，并通过[[spell:26573]]与套装奖励产生协同作用。

**使用'导出天赋'按钮将最佳构建直接导入你的游戏中。**

:::talents 天赋构筑
```json
{
  "code": "CIEAAAAAAAAAAAAAAAAAAAAAAsZsMLjZMzMzMLbjxsMmlZMAADAAAAAAaamhZMzwY2aDADMgZw2AAAAgZmltlWmZsYZBDAGzwYAwMDAmZAjF"
}
```
:::

:::details 来源计算器编码
```
#CB-DIJVVEkpnBcdB19hiqxZFEU1VSKA1YjLzjA-YOAJwMVkBil3numFuIQJUhCCFS2Ad5jG-AAAA-OQURYhpBYQQBkE-
```

:::

2.3.

#### 天赋更换选项

在这些天赋树中你可以做的主要天赋更换是将[[spell:1245979]]改为[[spell:1301732]]，以从过量治疗效果中获得更多有效生命值。随着你对专精更加熟悉，你将无需担心你的[[spell:53600]]覆盖率，或者你也可以选择忽略这个选择节点，选择[[spell:378285]]获得更多DPS，或选择[[spell:378405]]获得更多治疗。

在某些地下城中，你可能想更换一些天赋点以获得额外功能性。你可以在圣骑士树中更换的天赋包括[[spell:204054]]，或在[[spell:385427]]中投入一点以获取如[[spell:146956]]、[[spell:10326]]、[[spell:387791]]等节点。

你可以用这些点数更换的内容包括：

1. 如果地下城中有非精英亡灵怪物，你可以点出[[spell:10326]]，在它们生命值低于30%时获得秒杀能力。
2. [[spell:204054]]提供范围减速，有助于风筝敌人。
3. 如果地下城不需要[[spell:204018]]，你可以将此选择节点改为[[spell:378425]]。
4.

### 功能技能与能力

### 打断、昏迷和阻止

3.1.

#### 打断、昏迷和阻止

- [[spell:31935]]是我们大秘境工具箱中最强大的技能之一。它不仅能打断，还能沉默可被沉默的敌人3秒。这让你几乎可以独自完全锁定任何施法者，特别是如果他们还能被[[spell:853]]昏迷的话，然后让队伍其余成员去对付另一个施法者。
- [[spell:96231]]是针对近战范围内敌人的另一个打断选择。
- [[spell:853]]是一个长时间的单体昏迷，配合[[spell:234299]]天赋可以频繁使用。这可以用来让敌人在几秒钟内变得毫无威胁，或阻止他们移动。
- [[spell:115750]]可以用来迷惑10码范围内的敌人。这可以用作对可被群体控制的施法敌人的范围打断。
- [[spell:10326]]恐惧20码范围内的亡灵、畸变或恶魔目标，持续最多40秒。如果它们是非精英敌人且生命值低于30%，它们将被瞬间杀死！

### 其他功能

3.2.

#### 其他功能

- [[spell:391054]]允许你战斗复活一名小队成员。
- [[spell:465]]使你的团队受到的所有伤害降低3%。
- [[spell:213644]]可以移除一名团队成员身上的所有中毒和疾病效果。[[spell:213644]]在除破晨号和矶石仓库之外的每个地下城中都有价值。它也可以用来应对 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>) 词缀。
- [[spell:1022]]/[[spell:204018]]和[[spell:6940]]是地下城中帮助你的团队应对危险词缀和技能的绝佳工具。
- [[spell:1022]]在为目标提供物理伤害免疫之外还有两个额外好处。它会移除目标身上的任何流血效果，并使它们暂时失去对造成物理伤害的敌人的仇恨。对于那个在你放下[[spell:26573]]之前就开完所有冷却的狂怒战士来说非常有帮助！
- [[spell:305394]]有助于抵消你小队成员身上的减速/定身效果，但更重要的是，当对他人施放时，也会对自己施加[[spell:1044]]。
- [[spell:85673]]和[[spell:633]]不仅是自我治疗技能，还可以对团队成员使用并取得极佳效果，以帮助治疗者。

1.

### 应对词缀

本节包含防护圣骑士应对大秘境各种词缀的专属技巧。

### 词缀：升腾

4.1.

#### 防护圣骑士的升腾者词缀应对

[[spell:115750]]是我们唯一能处理光球的范围阻止技能。如果你是鲜血精灵，[[spell:28730]]也可以作为范围驱散使用。单体目标选择包括[[spell:853]]、[[spell:96231]]和[[spell:31935]]。

### 词缀：虚缚

4.2.

#### 防护圣骑士的虚空束缚词缀应对

虚空大使总是刷新在你身上，只需要击杀它即可。你不需要为这个词缀更换任何天赋，使用当时可用的最佳伤害技能来处理这个词缀。

### 词缀：脉冲星

4.3.

#### 防护圣骑士的脉冲星词缀应对

拾取光球。使用[[spell:190784]]或[[spell:305394]]四处跑动。

如果你需要离开你的[[spell:26573]]，确保在移动时放下一个新的。

### 词缀：吞噬

4.4.

#### 防护圣骑士的吞噬词缀应对

[[spell:213644]]驱散它。用[[spell:85673]]配合[[spell:321136]]或[[spell:633]]治疗掉它。

**不要使用[[spell:642]]来移除它，因为团队不会获得一层[[spell:465136]]。**

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年9月21日：** 更新了铸光者的建议。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 已添加地下城专属提示！
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月19日：** 为《地心之战》发布更新了天赋。
- **2024年7月19日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至第 3 赛季。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5版本更新天赋树。
- **2023年5月1日：** 为10.1补丁更新了天赋树，为第2赛季更新了词缀信息。
- **2023年3月20日：** 已为10.0.7补丁更新天赋构筑。添加了邪恶术的使用说明。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5补丁中玩防护圣骑士时更加轻松。

1.

### 最佳宏

欢迎来到我们的插件和宏页面。在这里，我们将介绍一些有用的插件，通过更信息化的UI提升你的游戏体验，同时提供一些常用的防护圣骑士宏。

1.1.

#### 圣骑士通用宏

圣骑士的大部分宏都围绕着让你对鼠标指向的目标使用功能性法术。

1.1.1.

##### 祝福鼠标指向宏

#### 鼠标指向保护祝福

```wow-macro
#showtooltip 保护祝福
/stopcasting
/cast [@mouseover, help, nodead] 保护祝福
```

#### 鼠标指向自由祝福

```wow-macro
#showtooltip 自由祝福
/stopcasting
/cast [@mouseover, help, nodead] 自由祝福
```

#### 鼠标悬停 牺牲祝福

```wow-macro
#showtooltip 牺牲祝福
/stopcasting
/cast [@mouseover, help, nodead] 牺牲祝福
```

这些宏允许你对当前鼠标指向的目标施放各种手部法术。Stopcasting用于确保你不会因为正在进行的施法而延迟施放这些法术中的任何一个。

1.1.2.

##### 圣疗术鼠标指向宏

#### 圣疗术宏

```wow-macro
#showtooltip 圣疗术
/stopcasting
/cast [@mouseover, help, nodead] 圣疗术
```

此宏将对当前鼠标指向的目标施放[[spell:633]]。

1.1.3.

##### 荣耀圣令鼠标指向宏

#### 荣耀圣令宏

```wow-macro
#showtooltip 荣耀圣令
/stopcasting
/cast [@mouseover, help, nodead] 荣耀圣令
```

此宏将对当前鼠标指向的目标施放[[spell:85673]]。如果你想在宏中添加一个保险机制，使其在鼠标指向目标不是友方时对自己施放，下面的宏涵盖了这一点。

#### 荣耀圣令带保险机制的宏

```wow-macro
#showtooltip 荣耀圣令
/stopcasting
/cast [@mouseover, help, nodead] [] 荣耀圣令
```

1.1.4.

##### 代祷（战斗复活）鼠标指向宏

#### 战斗复活宏

```wow-macro
#showtooltip 代祷
/stopcasting
/cast [@mouseover, dead, exists] 代祷
```

此宏将对你当前鼠标所指向的目标施放[[spell:391054]]。

1.1.5.

##### 清毒术鼠标指向宏

#### 驱散宏

```wow-macro
#showtooltip 清毒术
/cast [@mouseover, help, nodead] 清毒术
```

此宏将对当前鼠标指向的目标施放[[spell:213644]]。如果你想在宏中添加一个保险机制，使其在鼠标指向目标不是友方时对自己施放，下面的宏涵盖了这一点。

#### 带保险机制的驱散宏

```wow-macro
#showtooltip 清毒术
/cast [@mouseover, help, nodead] [] 清毒术
```

1.1.6.

##### 圣盾术

#### 圣盾术宏

```wow-macro
#showtooltip 圣盾术
/stopcasting
/cast 圣盾术
```

此宏将停止你当前的法术施放并施放[[spell:642]]，确保你的无敌不会被延迟。

1.1.7.

##### 责难

#### 焦点打断宏

```wow-macro
#showtooltip 责难
/stopcasting
/cast [@focus,exists][] 责难
```

这个宏会停止你当前的施法，并在你设置了焦点目标时对焦点目标施放 [[spell:96231]]。如果没有焦点目标，则会对你的当前目标施放 责难。

1.2.

#### 防护圣骑士专用宏

1.2.1.

##### 圣盾术取消光环宏

#### 圣盾术取消光环宏

```wow-macro
#showtooltip 圣盾术
/stopcasting
/cast 圣盾术
/cancelaura [noknown:决一死战] 圣盾术
```

这个宏允许你取消你的 [[spell:642]]（再次按下即可）。当你想用圣盾术快速解除一个减益效果，但又想继续坦住首领时（记得使用嘲讽让首领锁定你，因为如果你有圣盾术，首领会攻击仇恨列表中的下一个目标，除非被锁定）这非常有用。

添加 [noknown:Final Stand] 可以确保如果你点了 [[spell:204077]] 天赋，宏就不会取消 [[spell:642]]。

你总是可以将 [[spell:1022]] 和 [[spell:204018]] 都加入同一个宏，以覆盖更多情况。这意味着如果你使用了任何可能让小怪不攻击你的法术，你都可以按同一个按钮来解除其效果。而且由于在拥有 [[spell:25771]] 时无法对自己施放圣盾术，所以使用这个宏是安全的：

#### 全部免疫取消光环圣盾术宏

```wow-macro
#showtooltip 圣盾术
/stopcasting
/cast 圣盾术
/cancelaura [noknown:决一死战] 圣盾术
/cancelaura 保护祝福
/cancelaura [known:破咒祝福] 破咒祝福
```

注意，这些技能的顺序并不重要，而且如果只按一次，游戏不会在施放圣盾术后立即取消它。如果你在紧急情况下需要在全局冷却期间反复点击 [[spell:642]]，请小心，因为如果你在施放圣盾术后继续按它，你会立刻取消圣盾术。

1.

### 最佳插件

2.1.

#### 圣骑士通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.4.4.

##### Omen 仇恨统计

[Omen 仇恨统计](<https://www.curseforge.com/wow/addons/omen-threat-meter>)
是显示你当前目标仇恨水平最流行的插件。我们建议你使用它来检查你当前的仇恨水平，确保你没有被超过仇恨。

2.4.5.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) 是一个有用的插件，可以让你追踪其他团队成员的冷却时间，并为你提供大量其他有用的团队信息。

2.4.6.

##### 冷却管理器插件

你有两个流行的冷却管理器自定义插件选项
[ArcUI](<https://www.curseforge.com/wow/addons/arc-ui>) 和
[Better Cooldown Manager](<https://www.curseforge.com/wow/addons/bettercooldownmanager>)。这些插件通过允许你创建更多栏位并自定义特定法术在哪个栏位上跟踪，为冷却管理器提供了额外的自定义功能。

2.4.7.

##### Clique

[Clique](<https://www.curseforge.com/wow/addons/clique>) 允许你将特定法术绑定为鼠标悬停施法，作用于单位框架。这对于在不切换目标的情况下施放 [[spell:85673]]、[[spell:633]]、[[spell:6940]] 和 [[spell:1022]] 非常有用。

2.5.

#### 防护圣骑士专用插件

目前，我们认为你不需要任何额外的插件来充分发挥你专精的潜力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战上线进行了审核。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。为防护圣骑士添加了WeakAura推荐。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
