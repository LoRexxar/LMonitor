## 专精概览

Welcome to our Unholy Death Knight guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as an Unholy Death Knight in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Unholy Mythic+ Resources

[NEW! Top Unholy Talent Builds](<https://raider.io/specs/unholy-death-knight/talents>)

[Top Unholy Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/death-knight/unholy>)

[Unholy Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=death-knight--unholy>)

[Popular Unholy Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=death-knight--unholy>)

1.

### Unholy Death Knight Overview

Unholy Death Knight leverages plagues and summoned undead minions to
deal high Single Target damage. Our AoE relies on cleaving pets, quadratic
[[spell:207317]] damage, diseases and [[spell:55090]] cleave.
Our core rotation involves the upkeep of our DoTs, summoning a large
quantity of undead minions and dealing direct damage with attacks that
are highly effective at range. We are also one of the tankiest classes in the game,
something that is very useful in all PvE content!

Good Burst and Versatile at Range

Unholy Death Knight has a damage profile focusing on big burst windows
every 1.5 minutes with smaller bursts every 45 seconds. It has a great ability
to deal good damage from range, but struggles a bit when swapping targets as the
pets need to move over and plagues applied. We have
a strong execute and excel in fights where

[[spell:2825]]

is used
when the boss is below 35% health.

Strong Single Target and Versatile at Range

Unholy Death Knight is a solid pick for raid with high single target damage.
Our good execute, survivability, and effectiveness from range makes us a good DPS pick.
We have Grip which is nice on very specific fights, but
suffer from the lack of a proper raid buff.

Good Damage and Survivability

Unholy Death Knight deals good single target damage in Mythic+ and is complemented with good AoE.
We rely on high damage output to gain a spot in Mythic+ as our group utility is generally
lacking.

[[spell:49576]]

and

[[spell:51052]]

are nice but not sufficient.
Still, our high survivability is a nice perk that does allow pushing really high keys
as long as our damage is competitive.

Lackluster

Unholy Death Knight lacks a significant amount of really useful
utility. We have

[[spell:49576]]

, which is sometimes incredibly useful, but we
lack a significant raid and party buff otherwise.

[[spell:51052]]

is a nice
defensive magic cooldown, and we do have a stop with

[[spell:207167]]

. Compared
to other classes however, we are not brought due to strong utility unless our Grip
is a literal requirement for a given encounter.

Top Durability

Unholy Death Knight is arguably the best defensive spec in the game, tied with
Frost Death Knight.

[[spell:206967]]

,

[[spell:48263]]

,

[[spell:391571]]

and

[[spell:454842]]

are just a couple of our many passive
defensive talents. Furthermore, we have

[[spell:49998]]

that can easily
heal us up when we are in a pickle, allowing us to survive even the most scary
scenario. There is no surprise that Unholy Death Knight has the 4th fewest
deaths in raid amongst all DPS specs.

Quite Slow

Unholy Death Knight is rather famous for its lack of mobility. It has historically
been a very slow spec with more focus on avoiding displacement, rather than quickly
moving around. However, Unholy has the option of running

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse

to pick
up

[[spell:444010]]

, significantly increasing our mobility opportunity. This has
a huge impact on the overall mobility of the spec. Unholy is not
in the top, but also not at the bottom!

2.

### Unholy Death Knight in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 has no changes for Unholy Death Knights, but that doesnt mean theres no new content available.
Being a mid season patch, its a bit light on new content. But worry not, there is still a new Raid; the new Kith'ix encounter, 
and for [Delves](<https://www.icy-veins.com/wow/delves-guide>) there is the new Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

With both a new Kythu'ix raid, and the Labrynth Mega-Delve being introduced, they serve 
  as a new source of gearing for Unholy Death Knights. Kyth'ix drops incredibly powerful 
  items that are all sought after. In addition to all that, we can also upgrade our 
  Weapons, Trinkets, and Necklaces with [[item:280562]] once these become 
  available on October 20th.

2.3.

#### Class Changes

Patch 12.1.5 offers no changes to Unholy DKs so far.

As a result, there are a no changes to our
[Talent](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>) recommendations or
[rotational](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>) priorities. Though there are
new gear recommendations from the new raid and Delve Labyrinth on our
[gear](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>) page. We also have a list of 
high-value items to spend your first [[item:280562]] on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_unholypresence.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class TuningHide Patch 12.1 Class Tuning
- **Unholy 12.1 Changes**
  
  
  Unholy received a large number of changes in Patch 12.1, with significant tuning
      across our abilities and talents. We have summarised the changes and highlighted the most important ones
      below:
  
  
  
  
  - [[spell:42650]] has been reworked. It summons eight [[spell:275430]]s initially, but
        alters all our new [[spell:275430]] summons for the 30 seconds duration. Every time we
        would summon a ghoul, the existing 8 ghouls instead cast [[spell:1294264]] (single target) or 
        [[spell:1300330]] (AoE). This significantly reduces our max summon count without changing gameplay.
  - [[spell:210128]] has been renamed to [[spell:1256813]]. When you control 3 [[spell:390196]],
        sacrifice them to summon a [[spell:1256813]] for 15 seconds, casting chaining Frost Bolts. This is a fun new
        pet that emphasises stacking [[spell:390196]] spawns.
  - [[spell:343294]] now consumes up to three stacks of [[spell:1254252]] instead of stacks of [[spell:1247378]].
        Moves the usage of [[spell:1247378]] back to only the ability itself, simplifying the usage and avoiding awkward situations
        (like holding [[spell:343294]] because you do not want to use your [[spell:1247378]] stacks at that point in time).
  - [[spell:1240996]] now retains its duration when swapped to a new target, streamlining its spreading. Furthermore,
        plague duration extension has been nerfed slightly.
  - [[spell:434237]] auto-attack damage increased by 1400%, no big impact here but the number is just incredibly large.
  - [[spell:390259]] no longer extends the duration of lesser ghouls based on [[spell:77515]].
  - Blizzard tried to redistribute our damage for a less cooldown-focused profile, but did not succeed in
        doing so.
  
  
  
  
  Overall, Unholy is getting a new summon as well as a slightly reworked damage profile. The [[spell:343294]]
      change has the most impact on your rotational priority, as its usage is now decoupled from your [[spell:1247378]]
      priority.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Changes for Unholy Death Knight

Unholy Death Knight has received a significant rework in
Midnight. The [[spell:197147]]s, that have been a core aspect of
the spec since Legion, are now gone, replaced with a minion-summoning gameplay loop
at its core. More emphasis has been put on our plagues with both a
new pure single-target disease called [[spell:1240996]] as well as more disease
interaction within our talents. Our AoE is now decoupled from [[spell:43265]]
and we instead passively cleave via standard [[spell:55090]]s.
Finally, we have a new core rotational ability called
[[spell:1247378]] which we use to summon and sacrifice ghouls.

The feel of Unholy Death Knight is similar in some cases to previous expansions.
We maintain our core rotation of [[spell:85948]], [[spell:55090]]
and [[spell:47541]], but now also press [[spell:1247378]] every so often. Our
AoE rotation has seen the most change as it is now very similar to our single-target.
[[spell:1271974]] (now [[spell:1271974]]) has been introduced which creates this huge burst button
that scales off our plague durations. In general, the rotation is simpler with 
fewer opportunities for skill expression.

2.5.

#### New Apex Talents

We have received three new talents in our spec tree that we can talent into as we
level from 80 to 90. These are generally really powerful, buffing [[spell:42650]]
significantly and sending automatic [[spell:1247378]]s as your [[spell:1240996]] ticks.

2.5.1.

##### Putrefy

[[spell:1247378]] summons a lesser ghoul to leap at your target, dealing direct damage and
then exploding for AoE damage. We have several new talents that 
boost this interaction in various ways:

- [[spell:1241858]] makes your permanent ghoul temporarily do more damage when
  you cast Putrefy (multiple applications can overlap).
- [[spell:1254552]] makes the explosion effect of Putrefy extend the duration
  of your plagues and deals a portion of the damage the diseases would do in that
  duration instantly. Also applies our plagues to unaffected targets - nice synergy with our plagues 
  and a source of plague duration extension and application. This ability heavily reduces the number of [[spell:77575]]s
  we use in general.
- [[spell:210128]] reanimates the ghoul you Putrefy as a [[spell:390196]].
  Also increases the damage of our Magi
   - Major source of Magus summoning and damage increase.
- [[spell:377580]] gives you an additional charge of Putrefy and increases
  its damage - provides some nice flexibility with the additional charge
  and enables you to both use the ability more efficiently, as well as spending
  the charges in a more burst-like manner. For example, with [[spell:210128]] you
  can summon two Magus of the Dead during your [[spell:63560]] for some nice AoE
  burst.
- [[spell:276023]] reduces the Cooldown of [[spell:1247378]]
  whenever you summon a ghoul with [[spell:55090]].
- [[spell:343294]] automatically consumes all stacks of [[spell:1247378]]
  and uses them. This effectively removes the need to Putrefy when in execute.
- [[spell:1271974]] gives a charge of Putrefy when used.

All these interactions make [[spell:1247378]] an important spell to leverage that has
a big impact on your damage.

2.5.2.

##### Festering Wound Removal

[[spell:197147]]s are now completely gone from Unholy Death Knight.
Instead of applying a debuff to enemies, [[spell:85948]] now applies a buff
on you [[spell:1254252]] (2-3 stacks per Festering Strike, stacking up to 8 times). These stacks
are consumed by [[spell:55090]], summoning a lesser ghoul.
This helps significantly in target swapping and setup as the stacks on yourself
stay as you change targets. Furthermore, we get more of a necromancer fantasy feel as
we summon significant numbers of undead minions. With the removal of wounds, we also
lost some iconic abilities like [[spell:207289]] and [[spell:275699]].

2.5.3.

##### Plagues

Midnight has introduced the [[spell:1240996]] Plague, applied via
our [[spell:77575]] or [[spell:1247378]] with [[spell:1254552]], 
it deals damage to only a single enemy (can be talented to do
damage to a second one at reduced effectiveness with [[spell:390283]]) and is our new source
of [[spell:49530]] procs. It also has an interesting interaction when the target it's on dies,
triggering an explosion and spreading the Plague to a new target. This makes the Plague easy to keep
up in AoE and presents some fun scenarios where you get a chain-reaction effect 
where lots of enemies die after each other.

The talent tree also presents a lot more talents that interact with Plagues. [[spell:47541]]
and [[spell:207317]] now extend the duration of [[spell:191587]] and [[spell:1240996]]
by default. [[spell:55090]] deals extra damage based on your plagues, [[spell:455397]]
now increases plague tick-rate, and the new [[spell:1254552]] talent extends the duration
and deals damage based off your plague damage. We have a new [[spell:1271974]]
talent that interacts with our Plagues, allowing you to consume them to deal
100% of the remaining damages as a big burst. When we press [[spell:63560]],
your next [[spell:77575]] turns into this Pestilence ability. You get this gameplay loop
where you cast Dark Transformation, try to increase your Plague durations as much as possible
and then consume them for big burst damage. Especially ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn can do this effectively
due to the Plague duration increase with [[spell:434143]].

2.5.4.

##### AoE Rework

Midnight sees the rework of the [[spell:207311]] talent, no longer granting range ([[spell:55090]]
is now 30 yards by default), but instead being our AoE enabler. Every time we use Scourge Strike,
we simply cleave to one additional target, up to 4 (6 with [[spell:1242604]]) extra targets. This does not require
[[spell:43265]] at all. No more annoyance as tanks move out of your ground AoE,
you can just follow along and keep doing lots of damage. The drawback is that we get a natural
ramping nature in AoE, and you ideally want to chain-pull to maintain the stacks (they only last for
12 seconds). This is not an issue with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn which immediately gets max stacks via the
[[spell:1280658]] talent.

We also gain access to the new [[spell:1241705]] ability which grants our lesser
ghouls the Claw AoE ability during [[spell:63560]]. This is a nice additional
AoE component to our pets which used to be exclusive to our Magi and our main pet.
It makes [[spell:42650]] a stronger AoE cooldown due to the lesser ghoul summons and gives
[[spell:327082]] more AoE value!

[[spell:43265]] is in a weird spot in AoE with few interactions left in our kit. It deals okay
damage in really big pulls and have some synergy left with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn (through [[spell:1234559]]
and [[spell:434033]]). Furthermore, we now have a talent
with [[spell:1282565]] that casts it automatically when you use [[spell:455397]]. In general
however, it simply is not worthwhile to press, regardless of talent choices.
It now mainly has utility value with [[spell:273952]].

2.5.5.

##### Ranged Effectiveness

We are a lot more effective from range in the Midnight. [[spell:55090]] is 30 yards by default, and
we have lost a lot of talents that would previously benefit from us staying in melee range.
[[spell:49530]] now procs off [[spell:1240996]] hits instead of melee attacks and [[spell:377440]]
now works off your minion summons. We just need to get in melee to hit
[[spell:85948]] and can then run around for several seconds while losing minimal damage. We do
lose melee swings (2% of our damage) and our pets need to run a bit further when they are summoned.
Otherwise, we can pretend that we are ranged for significant portions of any fight.

2.6.

#### Hero Talents

Our Hero Talents have received three new talents each 
These talents are generally not very impactful, mirroring some tier set bonuses
we have had in the past.

2.7.

#### Class Tree Changes

The Death Knight class tree has also seen some minor changes. [[spell:337957]], [[spell:1266818]]
and [[spell:1266819]] have all been added. Some nice defensives and a hook to talent into [[spell:48743]]
(which is very much needed, we never pick this talent otherwise). [[spell:343294]] has moved to 
the spec tree and has been reworked to buff our minions and plagues and [[spell:327574]] has been removed altogether.

We have also had some movement of nodes around the tree. [[spell:276079]] is in a much better spot as a choice node
with [[spell:221562]]. [[spell:212552]] has moved further up the tree and is now a choice with [[spell:391546]].
[[spell:374265]] is now a 2-point talent as well. Overall we get a bit more access to certain talents and some more options
in the tree. [[spell:49998]] and [[spell:389682]] were nerfed a bit so we also lost some defensive power but not that
much in the grand scheme of things.

3.

### Basics of Unholy Death Knight Gameplay

Unholy Death Knight is a spec that is all about managing your resources and
maximizing your burst potential with correct cooldown management. This spec focuses
on delivering strong damage over time to enemies through spells such as [[spell:77575]]
while amassing an [[spell:42650]] to obliterate enemies.

Unholy gameplay revolves around buff management, proper resource use,
and damage-over-time uptime. These three focus keypoints can be described as listed below.

- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_festeringscythe.jpg>)
  **Maintain your Buffs**  
  
    Make sure to maintain your [[spell:455397]] buff (by pressing [[spell:85948]] → [[spell:455397]]).
    Furthermore, manage your [[spell:1254252]] stacks by making sure you never [[spell:55090]] with 0. 
    Build with [[spell:85948]] and consume with [[spell:55090]].
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_runic_corruption.jpg>)
  **Resource Management**  
  
    Unholy has two resources, Runes and Runic Power. Managing them is critical in maximizing your
    DPS and avoiding resource starvation. Prioritise spending your Runes (always have three recharging) 
    and then avoid overcapping Runic Power.
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_dread_plague.jpg>)
  **Plague Uptime**  
  
    Unholy has powerful Plagues that we apply to our targets. It is critical
    that you always maintain these, especially [[spell:1240996]]. They are a major
    source of your damage, both directly and indirectly.

4.

### How to Gear Up as a Unholy Death Knight

While we always recommend simming yourself for ideal results, we do provide a
dedicated Unholy gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Update for 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Update for 12.1.5.
- **05 Oct. 2026 (this page):** Adjust performance ratings after Blightfall nerf.
- **30 Sep. 2026 (this page):** Adjust performance ratings after blightfall bugfix.
- **25 Sep. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Update default talent selections to include Soul Reaper.
- **23 Sep. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Update default selection to Sanlayn.
- **23 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated the recommended single-target Raid build to San'layn.
- **23 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated the recommended builds to Blightfall.
- **08 Sep. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Update stack count recommended to cast Festering Strike.
- **08 Sep. 2026 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Fix macro description order.
- **08 Sep. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Remove Commander of the Dead interactions from mastery, these were removed in 12.1.
- **08 Sep. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.
- **08 Sep. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Priority list for hotfixed changes.
- **08 Sep. 2026 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Remove Commander of the Dead Mastery interaction, this was removed in 12.1.
- **08 Sep. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Update rotation for changed Epidemic and Graveyard  target counts.
- **08 Sep. 2026 (this page):** Add Commander of the Dead change to 12.1 changes.
- **07 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed and updated gear after hotfixes.
- **04 Sep. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated the recommended Mythic+ build to Sanlayn Minion.
- **04 Sep. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated the recommended single-target Raid build to Rider.
- **04 Sep. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated the beginner Raid build to Rider.
- **25 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified Blightfall usage.
- **24 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated to recommend Blightfall builds.
- **24 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated to recommend Sanlayn.
- **24 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated to Sanlayn for Raid and M+.
- **20 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated to Blightburst everywhere.
- **20 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated to Blightburst everywhere.
- **20 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated to Blightburst everywhere.
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Added best crafted items section.
- **13 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Expanded trinket tier list.
- **13 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Blightfall usage.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated with 12.1 bis and trinkets.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated with Patch 12.1 builds.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated with Patch 12.1 builds.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated with 12.1 changes.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **29 Jul. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Patch 12.1, adding Soul Reaper usage.
- **29 Jul. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **29 Jul. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.
- **29 Jul. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Rotation with 12.1 changes.
- **29 Jul. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Patch 12.1 with new rotation and opener.
- **29 Jul. 2026 (this page):** Updated with 12.1 changes.
- **08 Jul. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Runic Power priority in AoE.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated with 12.0.7 with sporefused gear.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Swapped to Recklessness as default potion.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7 with Omnium choices.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated with 12.0.7 changes.
- **06 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated M+ build to run ghoulish frenzy.
- **06 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated RP vs Rune priority.
- **06 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated M+ build to run ghoulish frenzy.
- **06 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated to use Ghoulish for M+ build.
- **24 May 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Fixed a gear drop location typo.
- **20 May 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Fixed runeforge with new bis list format.
- **02 May 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified DnD usage.
- **28 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated recommended ring enchant.
- **28 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated M+ build to run cycle of death.
- **28 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated Mythic+ and Raid builds.
- **28 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated M+ build to run cycle.
- **22 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Changed from abom for M+ build.
- **22 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated to BB for raid and no Abom for M+.
- **22 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated to BB for raid and no Abom for M+.
- **21 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified death and decay usage and RP prio.
- **21 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Changed to Gargoyle for Raid talents.
- **21 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Changed to Gargoyle for Raid talents.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated leveling talents with new 12.0.5 talent tree.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Added new turbo-boost items.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated bis stat distribution for 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated builds for 12.0.5 patch.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated with 12.0.5 changes to rotation.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated talents for 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated with 12.0.5 changes.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated talents and opener for 12.0.5.
- **20 Apr. 2026 (this page):** Updated with 12.0.5 changes.
- **10 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Clarified potion usage.
- **10 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Clarified recklessness value.
- **06 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated talent recommendation wording and added more Sanlayn focus.
- **02 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated builds to run 2x UA instead of GF
- **02 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated builds to run 2x UA instead of GF
- **29 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Removed major CD aspect of single button assistant.
- **29 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Removed major CD aspect of single button assistant.
- **28 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Resolved an issue with bis neck source.
- **22 Mar. 2026 (this page):** Added nerfs and buffs for first HC week.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Midnight Season 1 with new build.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Season 1 with new BiS gear and trinket recommendations.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated food recommendation and added teas.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Minor update to optimal stat allocation.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1 with new builds and affix tips.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added tier set section.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated raid talents to run unholy devotion.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **12 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for Midnight Season 1 with added death grip macro.
- **12 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Midnight Season 1 with new builds.
- **12 Mar. 2026 (this page):** Updated for Midnight Season 1 with new ratings and season 1 changes.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Added level 80 build.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Midnight with new talents.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Midnight with pre-season bis.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for Midnight with new macro copy elements.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Midnight with new enchants, gems and consumables.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated with new example stat allocation for Midnight.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for Midnight with new best talent builds.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated for Midnight.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Midnight with new builds, rotation and apex talent description.
- **26 Feb. 2026 (this page):** Updated for Midnight.
- **13 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Midnight.
- **11 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated to recommend Rider for Raid.
- **11 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Changed to Rider in Single Target.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated to coil at 2 targets.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Midnight pre-patch, changing BiS to match new stat prio and adding midnight leveling items.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Added note on rune of apocalypse for Mythic+.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated stat weights with new sanlayn build.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated builds for 12.0.1.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for patch 12.0.1.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated talents to run sanlayn with 12.0.1.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated opener for 12.0.1.
- **10 Feb. 2026 (this page):** Added 12.0.1 changes.
- **02 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added a death coil in the opener.
- **02 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Added a Death Coil in the opener.
- **25 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated to coil at 2 targets.
- **22 Jan. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated gem and ring enchant recommendations.
- **22 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated raid and M+ talents.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Midnight, changing best Runeforge and adding leveling consumables.
- **19 Jan. 2026 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 (this page):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed and updated for Patch 11.2.7, movig prism higher in trinket tier list.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Added Haste FAQ.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed and Updated for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed and updated for Patch 11.2.7, primarily fixing grammar.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed and updated for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated with new strengths and weaknesses section as well as 11.2.7 updates.
- **28 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added FAQs in the rotation page.
- **28 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Fixed a broken prio list and updated some wording.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Added Puzzling Cartel Chips.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for 11.2.5.
- **14 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated opener.
- **07 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Fixed a trinket typo and list issue.
- **07 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified Scythe usage at saturated wound count.
- **25 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated DC vs Epidemic target count.
- **18 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Swapped to AWS as first point to sac for 2-target cleave.
- **14 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS trinket.
- **10 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Added rider disease build.
- **10 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Added rider disease build.
- **07 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Apoc usage after bugfix.
- **07 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated Apoc usage after bugfix.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated after 11.2 rework.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2. Updated BiS, added new cloak and new trinkets.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for Patch 11.2, increasing Critical Strike value significantly.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated with Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2. Improved selection boxes, added new talents and updated rotations.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated with 11.2 rework.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Added 11.2 changes.
- **27 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Minor wording updates.
- **27 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Moved Rotten Touch section to rotation block and improved some Wounds and Runic Power wordings. Also added BIS usage.
- **27 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reorganised page to improve clarity.
- **27 Jun. 2025 (this page):** Fixed an issue with the image block not working.
- **23 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated best D.I.S.C effect after tuning.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Added the D.I.S.C belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Removed helm enchant disclaimer.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Fixed typo and clarified stat priority.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Added talents to an image block to help with readability.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added more image blocks to help readability and fixed some minor issues. Also added section on Combat Assistants.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Fixed a PvP talent typo.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated % values for Blood Beast after nerf.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Fixed outdated wording, added image blocks for readability and added section on the new Combat Assistant.
- **15 Jun. 2025 (this page):** Added 11.7 changes.
- **14 May 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Swapped to duskthread as general recommendation and added info on ascension on crafted weapon.
- **27 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated Cartel Chips wording.
- **27 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added 3 vamp strikes before UA in M+.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Removed "Congratulations for hitting level 80" bit.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Added corruption enchant recommendations.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** Added some more tips.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated recommended talents.
- **21 Apr. 2025 (this page):** Added class tuning in connection to 11.5 patch.
- **14 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Added extensive dungeons tips.
- **14 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Apocalypse usage in AoE rotation.
- **07 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated opener with late raise abom.
- **02 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated trinkets after tuning.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** Updated tips and talent builds.
- **16 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated M+ talents.
- **16 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified Mythic+ rotation.
- **16 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated Sanlayn Raid talents and swapped recommended Mythic+ build to Sanlayn.
- **03 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated bis after cyrce's nerfs.
- **01 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated tier set paragraph after buffs.
- **01 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated food to Haste Mastery.
- **01 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated talents after tier set buff.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS lists, trinket tier lists, embellishments, crafting recommendations and tier set portion.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified Death Coil usage in AoE for San'Layn.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Expanded on San'Layn builds.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed and updated for Patch 11.1.
- **24 Feb. 2025 (this page):** Added 11.1 changes and cleaned up guide link section.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **20 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and updated for Patch 11.1.
- **20 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed and updated for Patch 11.1.
- **20 Feb. 2025 (this page):** Reviewed and updated for Patch 11.1.
- **18 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated Cyrce's gems after news sims.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS lists to include Cyrce's Circlet after buffs.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Update for Patch 11.0.7, adding Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed and update for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Reviewed and update for Patch 11.0.7.
- **27 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Ensured correct Defile wording when talent is picked up.
- **26 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Resolved an issue in the Raid BiS list.
- **26 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified Trollbane Chains of Ice priority.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** Added more detailed tips.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added Festering Scythe gameplay bit.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Added Scythe build.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Added 11.0.5 blurb.
- **05 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS trinkets.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/unholy-death-knight-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/unholy-death-knight-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/unholy-death-knight-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Season 4, including Bullion priority and new BiS lists.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Season 4, updated leg enchant to Lambent kit.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for Season 4, changed the raw stat amounts mentioned and clarified M+ equal stats priority.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Season 4, added detailed trinket use with all new trinkets.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Season 4, no changes needed.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Season 4, mainly changing the ideal stat distribution.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **20 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.6.
- **20 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 (this page):** Reviewed for Patch 10.2.6
- **14 Feb. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added detail on Rotten Touch gameplay.
- **30 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated the Wound M+ build.
- **30 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated the wound M+ build.
- **23 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Fyralath priority after changes.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **20 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Minor clarifications to single target priotiy.
- **12 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added Legendary to Opener.
- **12 Dec. 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated M+ builds.
- **12 Dec. 2023 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Clarified DT and Garg location in opener.
- **02 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated Wound Rotation section.
- **29 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS after legendary was revealed.
- **24 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added macros to opener section.
- **22 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated Dawn drop locations to differentiate between upper and lower.
- **15 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Added Ashes to Raid BiS and moved it up in active trinket list.
- **12 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated food recommendation.
- **12 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Clarified unholy opener with Dark Transformation and Summon Gargoyle on the same line.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated BiS list and embellishment recommendations after sporecloak nerfs.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2. Added new head enchant and swapped all stat enchants to Mastery.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for Patch 10.2, added discussion on pet inheritance delay and raw stat impact on mirror procs.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for patch 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed and updated for Patch 10.1.7.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Updated for 10.1.7.
- **31 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed and updated for Patch 10.1.7.
- **21 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added Mirror to Detailed trinket usage.
- **20 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated Bis Trinket and Neck.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated trinket bis and added dawn of the infinite gear tips.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Added 10.1.5 changes.
- **25 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Max 4 coils to exactly 3 coils in opener.
- **25 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Minor opener update.
- **14 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added more detailed trinket and racial timings.
- **24 May 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Resolved issues with the opener not displaying properly.
- **10 May 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated trinket bis after Puzzle nerf.
- **08 May 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated bis list and trinket prio after changes.
- **03 May 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Added Death and Decay to opener and expanded cooldown usage section with DnD.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.
- **01 May 2023 (this page):** Reviewed for Patch 10.1.
- **30 Apr. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed and Updated for Patch 10.1.
- **30 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed and Updated for Patch 10.1.
- **30 Apr. 2023 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed and Updated for Patch 10.1.
- **30 Apr. 2023 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed and Updated for Patch 10.1.
- **30 Apr. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed and Updated for patch 10.1.
- **30 Apr. 2023 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed and Updated for patch 10.1.
- **29 Apr. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed and Updated for patch 10.1.
- **29 Apr. 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed and Updated for Patch 10.1.
- **29 Apr. 2023 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed and Updated for Patch 10.1.
- **29 Apr. 2023 (this page):** Updated for 10.1.
- **15 Apr. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Expanded on Disease build rotation.
- **12 Apr. 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated talents after 10.0.7 buffs.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/unholy-death-knight-best-legendaries-shadowlands>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Added Primordial Stone Gems recommenation.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated talents for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated talents for 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Added 10.0.7 changes.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/unholy-death-knight-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/unholy-death-knight-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/unholy-death-knight-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/unholy-death-knight-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **20 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-2-changes-analysis>)):** Reviewed and approved for Patch 9.2.
- **19 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-2-changes-analysis>)):** Updated with latest build tuning.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **17 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-1-changes-analysis>)):** Updated with recent hotfixes.
- **29 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/unholy-death-knight-patch-9-1-changes-analysis>)):** Created page.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **17 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-the-eternal-palace-raid-guide>)):** Added more information on Queen Azshara.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** Minor changes to talent selections.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **19 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** Added Mythic tips.
- **16 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **16 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **16 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **24 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated boss talent recommendations slightly.
- **18 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** Fixed the boss order.
- **08 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated talent recommendations.
- **24 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated talent recommendations.
- **22 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added first version of Unholy DK advice for Battle of Dazar'alor.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** Added information for all bosses in Uldir.
- **12 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-uldir-raid-guide>)):** Page added (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Unholy Death Knight leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Death Knight leveling guide](<https://www.icy-veins.com/wow/death-knight-leveling-guide>).

1.

### Unholy Death Knight Leveling Guide for Midnight

Unholy Death Knight is a fast leveler, both being able to
multi-dot and burst down large packs of enemies quickly, as well as being
one of the most mobile leveling class via [[spell:444008]] once you
reach level 71. Furthermore, this spec has great self-sustain via
procs of [[spell:178819]] and [[spell:49998]], staying healthy as you AoE down
pack after pack.

The ideal gameplay involves using [[spell:77575]] to pull multiple enemies,
setting up stacks of [[spell:1254252]] with [[spell:85948]]
and then cleaving down the enemies with [[spell:55090]] and [[spell:207317]].

1.1.

#### Leveling Gear Options

Item level is always more important than individual stats when leveling up. Always
choose the piece of gear with the highest item level. Items with Speed tertiary
stats can help speed up your leveling, especially during parts of extended time
spent indoors. Heirloom gear is also useful while leveling, allowing you to ignore a lot
of gearing for a large part of your leveling journey.

1.2.

#### Runeforge Choice

When you get the option to Runeforge, make sure you apply
[[spell:53344]], as it speeds up the leveling process the most!
You can also use [[spell:326977]] for some nice speed boost after
killing mobs. [[spell:327082]] is also relevant but is primarily
used at higher levels when you fight mobs for longer.

1.3.

#### Useful Leveling Consumables for Midnight

There are a couple of consumables you can use to speed up your leveling
process in Midnight. [[item:225592]] is a great
food that significantly increases your speed, improving your leveling
process. [[item:109076]] deserves a mention as it can be
a highly efficient means of transportation when you cannot
use your flying mount.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Unholy Level 80 Midnight Leveling
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMDDzmZmZa2MzYMjBAAAAAAAgZGmZAwyMmZ2mZGjZAMLGGAMLgGLYAzAAzMjZAmZGGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZmZGDzmZmZa2MzMjZMAAAAAAAAMzwMDAWmxMz2MzYMDYzsYYgBmFGasgBMDAMzMmBYmZYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYVVPTfBhAGGbZpkEhKwlSyU01lggciqc4B-RSTfdOPHvQcgVBkBVk0Y4FEwIIICqEC-AAAA-OQMEoYIohZBISB-
```

:::

2.1.

#### War Mode Talents for Leveling

This section will go over the PvP talents for leveling
content for Unholy Death Knights.

- [[spell:356512]] is the only PvP talent that provides extra DPS
  throughput.
- [[spell:410301]] gives some nice defensive benefit.

**等级 1 起：**3.

### **等级 1 起：**Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–9：**Starting, you will only have two main attack
abilities: [[spell:316239]] and [[spell:47541]].

- **等级 1–10：**[[spell:316239]] is your main Rune Spending
  ability.
- **等级 27 起：**[[spell:42650]] should be used as much as possible,
  ideally on more difficult mobs, as the cooldown brings a lot of Single Target burst.
- **等级 67 起：**Use [[spell:343294]] when you get the free use from
  [[spell:63560]] or when the target is below 35% health.
- **等级 11 起：**[[spell:77575]] should be used to apply
  [[spell:191587]] to all targets and [[spell:1240996]] on your main target.
- **等级 17 起：**Use [[spell:1247378]] as much as possible.
- **等级 21 起：**[[spell:63560]] can be used off
  cooldown. However, you should also make sure you have it available for
  larger packs or more difficult enemies.
- **等级 13 起：**Use [[spell:55090]] when you have at least one
  stack of [[spell:1254252]].
- **等级 11–12：**Use [[spell:85948]] as your Rune spender.
- **等级 1–17：**Use [[spell:47541]] to spend your Runic Power.
- **等级 18 起：**Use [[spell:47541]] to spend Runic Power at 1-3 targets.
- **等级 18 起：**Use [[spell:207317]] when there are 4+ targets.
- **等级 13 起：**Use [[spell:85948]] to build stacks of
  [[spell:1254252]]. Use it when you have 0 stacks.

There are some passive abilities that you unlock through the
leveling process that can change your play style and rotation.

- **等级 19 起：**[[spell:49530]] affects both [[spell:47541]]
  and [[spell:207317]], empowering them significantly. These procs should be used quickly to ensure that
  you do not override your current proc!
- **等级 18 起：**[[spell:178819]] is incredible for leveling,
  allowing you to easily heal and stay at high health while chain-pulling packs and
  mobs. Every time you kill a mob, your next [[spell:49998]] is free and heals for
  10% more of your health.

**等级 10 起：**3.1.

#### **等级 10 起：**Defensive and Utility Abilities

- **等级 14 起：**[[spell:48707]] is
  a very strong magic shield that also generates Runic Power when it
  absorbs magic damage. This should be used
  whenever magic damage is present to take advantage of the Runic Power
  generation.
- **等级 9 起：**[[spell:49039]] is a relatively powerful ability
  for leveling, as it provides you with a good chunk of Leech. Use this cooldown
  to take advantage of the healing and try to pair it with high AoE or
  burst combinations.
- **等级 18 起：**[[spell:48792]] is an amazing defensive
  cooldown that should be used whenever necessary in order to keep you moving
  from pack to pack.
- **等级 19 起：**[[spell:61999]] cannot be used when solo leveling,
  however, it is fantastic in dungeon groups if you decide to level that way.
- **等级 9 起：**[[spell:343257]] is one of your only movement
  speed cooldowns making it incredibly useful when leveling. The secondary
  effects of this are not too useful in leveling scenarios, except for the
  passive that prevents you from being slowed past a certain point.
- **等级 36 起：**[[spell:212552]] is a nice extra speed boost
  that we leverage as much as possible.
- **等级 8 起：**[[spell:49576]] grips your target towards
  you, allowing you to start fighting it straight away. Really useful
  to speed up the leveling process.
- **等级 20 起：**[[spell:47528]] is your interrupt which is great
  to use against casting mobs, significantly reducing the damage they deal to you!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **08 Sep. 2026:** Update stack count recommended to cast Festering Strike.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **29 Jul. 2026:** Updated for Patch 12.1, adding Soul Reaper usage.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated leveling talents with new 12.0.5 talent tree.
- **16 Mar. 2026:** Updated for Midnight Season 1 with new build.
- **02 Mar. 2026:** Added level 80 build.
- **26 Feb. 2026:** Updated for Midnight with new talents.
- **13 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Updated to coil at 2 targets.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **04 Aug. 2025:** Updated after 11.2 rework.
- **27 Jun. 2025:** Minor wording updates.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Removed "Congratulations for hitting level 80" bit.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **27 Oct. 2024:** Ensured correct Defile wording when talent is picked up.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Unholy Death Knight in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Unholy Death Knight

This page is intended for players who are new to the game or class,
or simply want a more straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Unholy gameplay revolves around the management of buffs, proper resource use
as well as the uptime of your Plagues. Three quick rules to follow when learning the spec are:

- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_festeringscythe.jpg>)
  **Maintain your Buffs**  
  
    Make sure to maintain your [[spell:455397]] buff (by pressing [[spell:85948]] → [[spell:455397]]).
    Furthermore, manage your [[spell:1254252]] stacks by making sure you never [[spell:55090]] with 0. 
    Build with [[spell:85948]] and consume with [[spell:55090]].
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_runic_corruption.jpg>)
  **Resource Management**  
  
    Unholy has two resources, Runes and Runic Power. Managing them is critical in maximizing your
    DPS and avoiding resource starvation. Prioritise spending your Runes (always have three recharging) 
    and then avoid overcapping Runic Power.
- ![](<https://static.icy-veins.com/images/wow/classes/dk/spell_dk_dread_plague.jpg>)
  **Plague Uptime**  
  
    Unholy has powerful Plagues that we apply to our targets. It is critical
    that you always maintain these, especially [[spell:1240996]]. They are a major
    source of your damage, both directly and indirectly.

2.

### Beginner's Guide to Unholy Death Knight in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse   Raid Talents

2.1.

#### Beginner Raid Talents for Unholy Death Knight

This is your go-to build in Raid encounters.

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mZmZa2MzMjZAAAAAAAAgZGGDAWmxMz2MzYmZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVFYgGxNUko015diigA-RSTdfHOPruwGBKQko0A5BGGEIIwIatB-AAAA-AeERphowgJQwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn   Mythic+ and Delves

2.2.

#### Beginner Delves and Mythic+ Talents for Unholy Death Knight

This is your go-to build in Delves or Mythic+.

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMjBGYGbassAYbwGGwMAMmZGzgZGMjxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-TCIQUJAxwBDmmF-
```

:::

### Unholy Death Knight   Basic Rotation

2.3.

#### Rotations for Unholy Death Knight

Unholy Death Knight is a melee DPS specialization that provides strong
single-target and AoE DPS.

Your main goal throughout a fight is applying the [[spell:1254252]] stacks
to yourself with  [[spell:85948]] (ensuring not to over-cap it by generating
more than 8 of them) and then
consuming these stacks with [[spell:55090]] /[[spell:433901]]. Also use
[[spell:85948]] -> [[spell:455397]] to maintain the Scythe buff.
Make sure to use [[spell:47541]] (Single Target) or [[spell:207317]] (AoE) to consume procs of
[[spell:49530]] and spend Runic Power. Furthermore, you should
aim to maintain uptime on your plagues [[spell:191587]] and [[spell:1240996]] by using
[[spell:77575]]. Finally, make sure to use [[spell:1247378]] as 
much as possible during your [[spell:63560]] window.

Our Season 2 tier set empowers our [[spell:390196]] and [[spell:1256813]] pets.
The 2-set makes them cast more powerful [[spell:198407]] and [[spell:1297091]] abilities.
The 4-set increases the damage of these new abilities by 130% against enemies below 35% health,
improving our execute power.

:::details FAQWhich Race is the Best for Unholy Death Knight?
All races are within 1% DPS so the choice has a minor impact on your overall
DPS. Still, Trolls is generall best ever so slightly ahead of Pandaren and Orc.

:::

2.3.1.

##### Basic Rotation for Unholy Death Knight

1. Cast [[spell:343294]] when the target is below 35% health or you get a free use from [[spell:63560]].
2. Cast [[spell:77575]] to maintain your
   [[spell:191587]] & [[spell:1240996]] on the target.
3. Use [[spell:455397]] to maintain the buff on yourself.
4. Use [[spell:1247378]] during your [[spell:63560]].
5. Use [[spell:47541]] when you have a
   [[spell:49530]] proc or [[spell:1242158]] is active. 
   Use [[spell:207317]] when fighting 3+ enemies (4+ during [[spell:1242158]]).
6. Use [[spell:85948]] to apply [[spell:1254252]] stacks if you have 0.
7. Use [[spell:55090]] when you have any [[spell:1254252]] stacks.
8. Use [[spell:47541]]. Use [[spell:207317]] when fighting 3+ enemies.

2.3.2.

##### Opener

1. Use [[spell:77575]]
2. Use [[spell:85948]] 2 times.
3. Use [[spell:42650]] + [[spell:63560]] + Potion + Trinket + Racial
4. Use [[spell:1247378]]
5. Use [[spell:1242174]] 2 times.
6. Use [[spell:1247378]]
7. Use [[spell:343294]]

2.3.3.

##### Multi-Target Rotation

The only difference between Single Target and AoE is the
use of [[spell:207317]]. Use this instead of [[spell:47541]]
whenever you are fighting 3 or more targets. During [[spell:1242158]],
use at 4+ targets (transforms to the [[spell:383269]] ability).

2.3.4.

##### Apex Talent: ![Forbidden Knowledge Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_dungeon_thenecroticwake_nalthor.jpg>) Forbidden Knowledge

Unholy Death Knight gets access to [[spell:1242158]] Apex Talents
as you level up from 80 to 90 in Midnight. The first rank provides a 30 seconds
buff once you cast [[spell:42650]], transforming your [[spell:47541]]
into [[spell:1242174]] and your [[spell:207317]] into [[spell:383269]].
These new abilities are powerful version of the baseline ones, notably
adding an AoE component to [[spell:47541]]. The impact to the rotation
is that [[spell:1242174]] is used at up to 3 targets in AoE, whereas [[spell:47541]]
is only used at up to 2.

Rank 2 and 3 ([[spell:1256565]]) gives Mastery when [[spell:1247378]] is cast
and adds a stack of [[spell:1254252]]. Slightly less [[spell:85948]] casts are
needed in the rotation, but not much else.

Rank 4 ([[spell:1256566]]) gives [[spell:1240996]]
a 20% chance to trigger [[spell:1247378]] at 100% effectiveness, significantly increasing
the number of [[spell:1247378]] triggered in the rotation overall.

2.3.5.

##### Cooldowns

Unholy Death Knights have access to three cooldowns.

- [[spell:42650]] should be used on cooldown.
  They are generally the first ability you use after you reach the boss. 
  Make sure to line it up [[spell:63560]] every 1.5 minutes.
- [[spell:63560]] should be used on cooldown. Make sure to align
  it with [[spell:42650]] every 1.5 minutes.
- [[spell:43265]] should only be used to help slow enemies with the [[spell:273952]] talent
  or if you run [[spell:1290864]] (at 3+ targets).

### Unholy Death Knight   Stat Priority

2.4.

#### Unholy Death Knight Stat Priorities

Currently, you will want to prioritize stats as follows. Do remember that
item level will generally be best in most scenarios!
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>).

Critical Strike

Mastery

Haste

Versatility

This can be different depending on your character's gear, so make sure you
sim yourself, to find what your stat priority is. Generally, Mastery and Crit
are a lot more valuable than Versatility and Haste and should be prioritised.
However, do not drop a lot of item levels to chase these specific stats either!

### Blizzard   Combat Assistant

2.5.

#### Combat Assistant for Unholy Death Knights

Patch 11.1.7 in The War Within introduced the Combat Assistant functionality for all specs in the game.
This comes in the form of two tools that you can use to assist your rotation. The
Assisted Highlight feature will light up the spell that you are supposed to use next,
helping you determine what button you need to press. The Single-Button Assistant
will provide you with a single button that automatically pressed the appropriate spell.
**The Single-Button Assistant has a GCD penalty of 0.2 seconds every time you
press it, artificially slowing down your rotation**. This penalty means that you will always
do less DPS when using the Single-Button Assistant compared to what you could have done
with a perfectly executed rotation.

So how good is the rotation I can get from
these assistants? If we assume that you handle your cooldown usage perfectly, the
Assisted Highlight is roughly 5-10% less DPS. 
With the Single-Button Assistant, the number is about 15%
Do bear in mind that this is compared to absolutely
optimal play. A player with less experience with the rotation might see a significantly smaller loss,
or even a gain when using the assistants.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **08 Sep. 2026:** Update rotation for changed Epidemic and Graveyard  target counts.
- **04 Sep. 2026:** Updated the beginner Raid build to Rider.
- **24 Aug. 2026:** Updated to Sanlayn for Raid and M+.
- **20 Aug. 2026:** Updated to Blightburst everywhere.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **29 Jul. 2026:** Updated for Patch 12.1 with new rotation and opener.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **06 Jun. 2026:** Updated to use Ghoulish for M+ build.
- **28 Apr. 2026:** Updated M+ build to run cycle.
- **22 Apr. 2026:** Updated to BB for raid and no Abom for M+.
- **21 Apr. 2026:** Changed to Gargoyle for Raid talents.
- **20 Apr. 2026:** Updated talents and opener for 12.0.5.
- **29 Mar. 2026:** Removed major CD aspect of single button assistant.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **12 Mar. 2026:** Updated for Midnight Season 1 with new builds.
- **26 Feb. 2026:** Updated for Midnight with new builds, rotation and apex talent description.
- **11 Feb. 2026:** Changed to Rider in Single Target.
- **10 Feb. 2026:** Updated opener for 12.0.1.
- **02 Feb. 2026:** Added a Death Coil in the opener.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **07 Aug. 2025:** Updated Apoc usage after bugfix.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **27 Jun. 2025:** Reorganised page to improve clarity.
- **15 Jun. 2025:** Fixed outdated wording, added image blocks for readability and added section on the new Combat Assistant.
- **21 Apr. 2025:** Updated recommended talents.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4, mainly changing the ideal stat distribution.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **12 Dec. 2023:** Clarified DT and Garg location in opener.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **25 Jun. 2023:** Minor opener update.
- **01 May 2023:** Reviewed for Patch 10.1.
- **29 Apr. 2023:** Reviewed and Updated for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Unholy Death Knight in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Unholy Death Knight

Welcome to the talent guide for Unholy Death Knight. Here we will
discuss all matters associated with your talent choices, providing the best
available builds as well as details regarding alternative picks
and potential talent swaps.

Unholy Death Knight can choose from two slightly different styles 
when it comes to talents; plagues or minions. Minion builds synergise 
well with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse and can also be paired with
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn for our recommended Mythic+ build. These builds pick talents such as
[[spell:1256813]] and [[spell:1241705]]. Plague builds generally 
run ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn with the [[spell:1271974]] talent to really harness
the DoT power.

For single-target raid encounters, we recommend the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse minion build.
For Mythic+, we recommend the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn pet build.

**Quick Start Import Codes:**

:::talents Unholy Single-Target
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTjZmxYGDAAAAAAAAzDMMGAsMDzsZmxMzYgBmxiGLbA2GsBgZAMzMzMmBzMYmZMA"
}
```
:::

:::talents Unholy Mythic+/Delves
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMjBGYGbassAYbwGGwMAMmZGzgZGMjxA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

San'layn

Raid

recommended

Mythic+ Blightfall

recommended

Mythic+ San'layn Pet

Rider of the Apocalypse

Raid

Mythic+

Delves

recommended

### 天赋方案 0-0

1.1.

#### Raid Talents

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn minion build is an alternative for raids. It focuses heavily
on minion damage with both [[spell:1256813]], [[spell:1238900]], as well as the minions we summon
through these talents. It is easy to play and deals a good amount of burst damage.

To gain some better AoE burst with the build, pick up [[spell:455135]]
instead of [[spell:207272]]. This loses a few percent of damage in single-target,
but adds a significant amount of cleave. If you want even more cleave, pick up
[[spell:1290864]] as well instead of [[spell:377587]]. You are then running the full
San'layn Pet Mythic+ build.

### 天赋方案 0-1

1.2.

#### San'layn Blightfall Build

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn Mythic+ build is a similar to our raid build, but it leans into more
AoE while not sacrificing too much single-target. Some people run it without [[spell:343294]] and [[spell:377514]],
but we recommend sacrificing [[spell:390270]] and [[spell:377587]] instead.

### 天赋方案 0-2

1.3.

#### San'layn Pet Build

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn Mythic+ build uses the same minion talents as the Rider build,
but replaces the Rider Hero Talents with San'layn.

### 天赋方案 1-0

1.4.

#### Raid Talents

This is our recommended ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse minion build for raids. This focuses heavily
on minion damage with both [[spell:1256813]], [[spell:1238900]], as well as the minions we summon
via Rider. It is easy to play and deals a good amount of burst damage.

[[spell:444072]] and [[spell:444069]] are close in DPS, but Fury is
slightly ahead overall, which is why we recommend it.

To gain some better AoE burst with the build, pick up [[spell:455135]]
instead of [[spell:207272]]. This loses a few percent of damage in single-target,
but adds a significant amount of cleave. If you want even more cleave, pick up
[[spell:1290864]] as well instead of [[spell:377587]]. You are then running the full
Rider Mythic+ build.

### 天赋方案 1-1

1.5.

#### Mythic+ Talents

Mythic+ put significantly more emphasis on AoE damage. We therefore sacrifice
some single-target DPS to gain AoE. However, we do not go all out, keeping talents
that are still valuable for single-target to give us a good balance. This ends up
being a slight variation of our single-target Rider build, with [[spell:455135]],
and [[spell:1290864]] being picked up instead of [[spell:377592]] and [[spell:207272]].

### 天赋方案 1-2

1.6.

#### Delves Talents

The gameplay of [Delves](<https://www.icy-veins.com/wow/delves-guide>) caters well to our Rider Dungeon build that brings a good balance
between single-target and AoE!

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMDDz2MzMTjZmxYGDAAAAAAAAzDMMGAsMDzsZmxMzYgBmxiGLbA2GsBgZAMzMzMmBzMYmZMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVabhiqrCMQj4IHKS66QRQOB-RSTdfHOPruwGBKQko0YFuxx5BGIIoJC-AAAA-JgMpCTDQgwgxhF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMGDz2MzMTzyMzYMjBAAAAAAAg5BGDDAWmhZ2MzYMjBGYGbassAYbwGGwMAmZmZGzgZGMmxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ02CFXBEYgGxRWo01higcC-RSTdfHOPruwGBIQko0kFuxx5BGIIoJC-AAAA-JiIpCTDQgwgxhF-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMjBGYGbassAYbwGGwMAMmZGzgZGMjxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-TCIQUJAxwBDmmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAwMjZMzYY2mZmZa2MzMjZAAAAAAAAgZGGDAWmxMz2MzYmZAbmFDDMwsxQjFAMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVFYgGxNUko015diigA-RSTdfHOPruwGBKQko0A5BGGEIIwIatB-AAAA-AeERphowgJQwwC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMDYzsYYgBmNGasgBMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-AeERphowgJQwwC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMDYzsZYgBmNGasgBMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-AeERphowgJQ4wC-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend you pick the following bonuses in the first couple of weeks, but as you
can freely switch between them at any time, feel free to experiment with other options
yourself if you feel you do not get enough mileage out of the recommended options:

- Week 1:[[spell:1279599]]
- Week 2:[[spell:1279604]]
- Week 3:[[spell:1287555]]
- Week 4:[[spell:1279609]]
- Week 5:[[spell:1279614]]

3.

### Apex Talent: ![Forbidden Knowledge Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_dungeon_thenecroticwake_nalthor.jpg>) Forbidden Knowledge

Unholy Death Knight gets access to [[spell:1242158]] Apex Talents
as you level up from 80 to 90 in Midnight. The first rank provides a 30 seconds
buff once you cast [[spell:42650]], transforming your [[spell:47541]]
into [[spell:1242174]] and your [[spell:207317]] into [[spell:383269]].
These new abilities are powerful version of the baseline ones, notably
adding an AoE component to [[spell:47541]]. The impact to the rotation
is that [[spell:1242174]] is used at up to 5 targets in AoE ([[spell:47541]]
is only used at up to 3).

Rank 2 and 3 ([[spell:1256565]]) gives Mastery when [[spell:1247378]] is cast
and adds a stack of [[spell:1254252]]. Slightly less [[spell:85948]]s are
needed in the rotation but not much else.

Rank 4 ([[spell:1256566]]) gives [[spell:1240996]]
a 20% chance to trigger [[spell:1247378]] at 100% effectiveness, significantly increasing
the number of [[spell:1247378]] triggered in the rotation overall.

It is crucial to maintain good [[spell:1240996]] and [[spell:455397]] 
uptime to get the most of this talent. Furthermore,
your pets must be on assist for it to function properly.

4.

### Hero Talents

Available at level 71, Hero talents are mutually exclusive trees you can
choose to slightly alter gameplay. Unholy Death Knight can choose
between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse Hero Talents focus on minion damage,
summoning Horsemen to deal heavy damage to your enemies. You have minor rotational
updates with Trollbane's Chains of Ice, where you want to burst them ASAP and you
want to stay in Mograine's [[spell:43265]] to get 5% damage boost.
Otherwise, the main benefit comes from [[spell:444010]] which is an amazing
mobility ability for Death Knights!

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn Hero Talents focus more on Plague damage and direct
damage via [[spell:433901]] and [[spell:47541]] and [[spell:207317]] boosts.
Furthermore, it has an interesting quadratic scaling component via the [[spell:434237]] ability
and can run [[spell:1271974]] which is a fun an interesting talent to play around.
The main rotational difference is the introduction of [[spell:433901]] that we get
to press lots in our [[spell:63560]] window. We also try and proc it in-between our Dark Transformation
windows to maintain the [[spell:433925]] buff.

5.

### Rotation

Talents can and usually do change your rotation or add new abilities to
your priority. For a more detailed breakdown of how your rotation will
look with optimal talents, check out our rotation page, which is linked below.

[Unholy DK Rotation and Cooldowns](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-rotation-cooldowns-abilities>)

6.

### PvP Talents (War Mode)

PvP Talents are specific talents usable in PvP content. We
can leverage these in open-world PvP to get some nice buffs.

- PvP talents enabled in the outdoor world.
- 15% more experience and quest awards gained while leveling.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended enabling the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

Below, we will rank the PvP talents best used for leveling and doing solo or 
small group PvE content.

1. [[spell:288855]] heals you for 10% of the amount your target
   afflicted by [[spell:1240996]] receives. Not relevant for PvE really.
2. [[spell:77606]] places a debuff on your enemy, activating when they
   cast a spell that uses mana. It allows you to use that same spell for some time.
   Not useful in PvE content.
3. [[spell:356520]] - your [[spell:1247378]] now applies a Necrotic Wound
   to the target, absorbing 8% of all healing received for the next 15 seconds (max 3 stacks).
   Not useful in PvE content.
4. [[spell:210128]] - Costs 30 Runic Power and reanimates a nearby corpse into a zombie.
   The zombie will slowly walk towards you target, exploding and stunning all enemies in an area
   if it reaches the target. Somewhat useful stun in PvE content.
5. [[spell:1281529]] heals you for 5% of your [[spell:275430]]s max health
   when they die (about 2.5% of your health). [[spell:49998]] sacrifices all active ghouls
   when pressed. A nice additional sustain in AoE with a DPS drawback as you might lose lesser ghoul
   uptime.
6. [[spell:47476]] silences your target for 4 seconds. Inferior to just
   running [[spell:221562]] (it replaces the talent) and a pretty useless PvE talent.
7. [[spell:356512]] causes your [[spell:47541]]s to deal 25% of your plague damage
   an additional time and slow the target by 45% for 3 seconds. Useful PvE talent is it is a DPS
   increase.
8. [[spell:202727]] adds an absorption shield to any target hit by
   [[spell:43265]] for 100% of the damage amount. Useless pretty much.
9. [[spell:410301]] provides 4 seconds of 25% physical damage reduction
   whenever you press [[spell:49998]]. Solid defensive gain!
10. [[spell:410320]] lowers the cooldown of [[spell:48707]] by 10
    seconds and allows you to use it on allies. It's just a nice defensive gain because it
    allows more AMS usage.

[[spell:356512]] is a solid choice due to its
nice DPS gain. No other talent
does much for us in PvE, and are primarily PvP choices. For a second and third option,
we don't have much to choose from. [[spell:410301]] is generally
best due to providing a good defensive gain, and [[spell:410320]] is a small
defensive gain!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **23 Sep. 2026:** Updated the recommended builds to Blightfall.
- **23 Sep. 2026:** Updated the recommended single-target Raid build to San'layn.
- **04 Sep. 2026:** Updated the recommended single-target Raid build to Rider.
- **24 Aug. 2026:** Updated to recommend Sanlayn.
- **20 Aug. 2026:** Updated to Blightburst everywhere.
- **10 Aug. 2026:** Updated with Patch 12.1 builds.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Omnium choices.
- **06 Jun. 2026:** Updated M+ build to run ghoulish frenzy.
- **28 Apr. 2026:** Updated Mythic+ and Raid builds.
- **22 Apr. 2026:** Updated to BB for raid and no Abom for M+.
- **21 Apr. 2026:** Changed to Gargoyle for Raid talents.
- **20 Apr. 2026:** Updated talents for 12.0.5.
- **06 Apr. 2026:** Updated talent recommendation wording and added more Sanlayn focus.
- **02 Apr. 2026:** Updated builds to run 2x UA instead of GF
- **16 Mar. 2026:** Updated raid talents to run unholy devotion.
- **26 Feb. 2026:** Updated for Midnight with new best talent builds.
- **11 Feb. 2026:** Updated to recommend Rider for Raid.
- **10 Feb. 2026:** Updated talents to run sanlayn with 12.0.1.
- **22 Jan. 2026:** Updated raid and M+ talents.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed and Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **18 Aug. 2025:** Swapped to AWS as first point to sac for 2-target cleave.
- **10 Aug. 2025:** Added rider disease build.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Fixed a PvP talent typo.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **16 Mar. 2025:** Updated Sanlayn Raid talents and swapped recommended Mythic+ build to Sanlayn.
- **01 Mar. 2025:** Updated talents after tier set buff.
- **24 Feb. 2025:** Expanded on San'Layn builds.
- **20 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Added Scythe build.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, no changes needed.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **30 Jan. 2024:** Updated the wound M+ build.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **12 Dec. 2023:** Updated M+ builds.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed and updated for Patch 10.1.7.
- **31 Aug. 2023:** Reviewed and updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **29 Apr. 2023:** Reviewed and Updated for Patch 10.1.
- **12 Apr. 2023:** Updated talents after 10.0.7 buffs.
- **20 Mar. 2023:** Updated talents for 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Unholy Death Knight in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Unholy Death Knight Gameplay and Rotation Guide

Welcome to our Rotation page for Unholy Death Knights. Here, we
will go over everything you will need to know to optimally play your
spec for Raiding and Mythic+ scenarios.

By selecting talents and Hero Talents below, the rotations in this guide will
update accordingly.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse

Raid

Mythic+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn

Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:1271974]]

[[spell:343294]]

[[spell:377580]]

[[spell:377514]]

[[spell:455397]]

[[spell:1254552]]

[[spell:1290864]]

### Unholy Death Knight Explained

1.1.

#### Unholy Death Knight Explained

Unholy Death Knight relies on a dual-resource system with Runes and Runic Power. Runes passively recharge over time and are spent on abilities such as [[spell:85948]], [[spell:55090]] and [[spell:1247378]]. Spending Runes generates Runic Power that we spend on abilities such as [[spell:47541]] and [[spell:207317]]. Furthermore, we maintain Plagues on our enemies via [[spell:77575]] and [[spell:1247378]] (with [[spell:1254552]]).

The rotation boils down to the following:

- Manage stacks of [[spell:1254252]] that we build and consume via [[spell:85948]] and [[spell:55090]].
- Manage your [[spell:455397]] buff by using [[spell:85948]] -> [[spell:455397]].
- Manage your Plagues applying them with [[spell:77575]]
- Manage your resources by spending Runic Power on [[spell:47541]] (Single Target) and [[spell:207317]] (AoE)
- Use your [[spell:1247378]] as much as possible during [[spell:63560]].
- Use your [[spell:343294]] when you get free procs via [[spell:63560]] or your target is below 35% health.
- Send your Cooldowns as much as possible, always aligning them ([[spell:42650]] and [[spell:63560]]).

### Single-Target Rotation

[[spell:77575]]

[[spell:85948]]

[[spell:455397]]

[[item:241288]]

[[item:249344]]

[[spell:42650]]

[[spell:63560]]

[[spell:1247378]]

[[spell:47541]]

[[spell:47541]]

**适用条件：Putrid Echoes（启用）。**

[[spell:1247378]]

**适用条件：Reaping（启用）。**

[[spell:343294]]

**适用条件：Blightfall（启用）；Reaping（启用）。**

[[spell:1271974]]

1.2.

#### Single-Target Opener for Unholy Death Knights

The opener is a set sequence of abilities you use as you engage an enemy. Memorising it helps initiate your rotation in the most optimal way possible.

1. Use [[spell:77575]].
2. Use 2x [[spell:85948]].
3. Use [[spell:42650]] + [[spell:63560]] + Trinket + Racial + Potion
4. Use [[spell:1247378]].
5. Use 2x [[spell:47541]].
6. **适用条件：Putrid Echoes（启用）。** Use [[spell:1247378]].
7. **适用条件：Reaping（启用）。** Use [[spell:343294]] 6 seconds after pressing [[spell:63560]].
8. **适用条件：Blightfall（启用）；Reaping（启用）。** Use [[spell:1271974]] just before the [[spell:343294]] buff expires.

When it comes to timing your trinkets, you can just macro
them with [[spell:42650]] in all your openers. If you are lucky enough for receive [[spell:10060]], ask for it when you cast [[spell:42650]].

**适用条件：Blightfall（启用）。** The timing of [[spell:343294]] (with Blightfall talented) in the opener is to overlap the plague damage debuff for when you consume [[spell:1271974]] after [[spell:63560]] ends.

1.3.

#### Single-Target Rotation Priority for Unholy Death Knights

The below list represents your rotation priority excluding your actual Cooldowns. Cooldown usage is discussed separately but you can generally assume that you always want to press your Cooldowns as much as possible!

1. Use [[spell:42650]] and [[spell:63560]] on Cooldown.
2. **适用条件：Blightfall（启用）。** Use [[spell:1242616]] just before [[spell:343294]] ends, follow up with [[spell:1247378]]
3. **适用条件：Blightfall（启用）；Reaping（未启用）。** Use [[spell:1242616]] just before [[spell:63560]] ends, follow up with [[spell:1247378]]
4. Use [[spell:77575]] to maintain your plagues on the target.
5. **适用条件：Festering Scythe（启用）。** Use [[spell:455397]] if its buff is close to, or has fallen off.
6. **适用条件：Reaping（启用）。** Use [[spell:343294]] if the enemy is below 35% health. If you have triggered
     the [[spell:377514]], cast this about 6 seconds after [[spell:63560]].
7. Use [[spell:1247378]] if your [[spell:63560]] buff is active.
8. Use [[spell:47541]] when you have a [[spell:49530]] proc or [[spell:1242158]] is active or your are playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn and have more than 50 Runic Power.
9. Use [[spell:85948]] if you have no stacks of [[spell:1254252]].
10. Use [[spell:55090]] if you have at least 1 stack of [[spell:1254252]].
11. Use [[spell:47541]].

Now, we will take this priority list and put it into a wordier
description!

- Use your Cooldowns as much as possible. Send [[spell:63560]] every 45 seconds and [[spell:42650]] every 90 seconds, always aligning them.
- **适用条件：Blightfall（启用）。** Use [[spell:1242616]] at the end of [[spell:343294]] and follow up with a [[spell:1247378]] to re-apply your Plagues and get value from the generated charge.
- **适用条件：Blightfall（启用）；Reaping（未启用）。** Use [[spell:1242616]] at the end of [[spell:63560]] and follow up with a [[spell:1247378]] to re-apply your Plagues and get value from the generated charge.
- Maintain your Plagues on the target by leveraging [[spell:77575]]. Your plagues do not only do damage but are also the source of your important [[spell:49530]] and [[spell:1256566]] procs so keeping them up is crucial.
- **适用条件：Soul Reaper（启用）；Blightfall（未启用）。** Cast [[spell:343294]]. Either when the target is below 35% health. If you have received the free use from [[spell:63560]] with [[spell:377514]], cast this about 6 seconds after [[spell:63560]]. Make sure to always have at least 3 stacks of [[spell:1254252]] when casting Soul Reaper.
- **适用条件：Blightfall（启用）。** Cast [[spell:343294]] either when the target is below 35% health (during [[spell:63560]]) or when you have received the free use from [[spell:63560]] with [[spell:377514]]. With [[spell:1271974]], you want to overlap the Plague damage taken debuff you get from this ability with the end of your first [[spell:1256813]]. Hold [[spell:343294]] until about 6 seconds after [[spell:63560]] use [[spell:1271974]] at the end of the [[spell:343294]] debuff window. In execute, use the free [[spell:343294]] ASAP in Dark Transformation so you get a new use after 15 seconds to overlap the end when you use Blightfall. Make sure to always have 3 stacks of [[spell:1254252]] when casting Soul Reaper.
- **适用条件：Festering Scythe（启用）。** Use [[spell:455397]] to maintain the buff on yourself. The increased tick rate this provides increases the proc chance of both [[spell:49530]] and [[spell:1256566]]. Due to this interaction it is absolutely vital to be sure this is maintained at all times.
- Use [[spell:47541]] to spend your procs of [[spell:49530]], or as a high priority during [[spell:1242158]], or you are playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn and have more than 50 Runic Power. [[spell:49530]] is a powerful proc, and you do not want to waste any. If you have [[spell:276023]] talented, you can allow yourself to stack up two charges before you spend them. However, most of the time, you simply use them as soon as possible to avoid any potential waste. Furthermore, [[spell:47541]] gains a lot of value during [[spell:1242158]] as it transforms into [[spell:1242174]], dealing significantly more damage.
- **适用条件：Soul Reaper（未启用）；Reaping（未启用）。** Use [[spell:85948]] to build up stacks of [[spell:1254252]] on yourself. We want to aim for between 2 and 4 stacks at all times to give us some flexibility when we are forced out of melee range.
- **适用条件：Reaping（未启用）。** Use [[spell:85948]] to build up stacks of [[spell:1254252]] on yourself. We want to aim for between 2 and 4 stacks at all times to give us some flexibility when we are forced out of melee range. When your target is in execute range (below 35% health), it is worth keeping at least 3 stacks of [[spell:1254252]] so you always have enough to get the full benefit of [[spell:343294]].
- **适用条件：Reaping（启用）。** Use [[spell:85948]] to build up stacks of [[spell:1254252]] on yourself. We want to aim for between 2 and 4 stacks at all times to give us some flexibility when we are forced out of melee range. When your target is in execute range (below 35% health), or just before casting [[spell:63560]], it is worth ensuring you always have at least 3 stacks of [[spell:1254252]] so you always have enough to get the full benefit of [[spell:343294]].
- Use [[spell:55090]] to consume your stacks of [[spell:1254252]].
  This is used in sync with [[spell:85948]] to keep your stack count at a
  healthy level. You generally go up to 2-4 and then use Scourge Strike to
  drop down to 0 again.
- Use [[spell:47541]] as your filler spell when you have nothing else to
  do!

When you want to deal AoE damage in your Single Target build, you really do not change much. If the adds are pulled on top of your current target, you simply use [[spell:55090]] to spread your diseases to them. If we engage a new pack, you start by applying your Plagues with [[spell:77575]]. Your Scourge Strike cleaves by default so the main decision comes when using [[spell:47541]] vs [[spell:207317]]. In general, you swap to Epidemic at 3+ targets (4+ targets during [[spell:1242158]]) but sometimes stay with Death Coil if you want to do priority damage.

### Multi-Target Rotation

[[spell:77575]]

[[spell:85948]]

[[spell:455397]]

[[item:241288]]

[[item:249344]]

[[spell:42650]]

[[spell:63560]]

[[spell:1247378]]

**适用条件：Putrid Echoes（启用）。**

[[spell:207317]]

[[spell:207317]]

**适用条件：Putrid Echoes（启用）。**

[[spell:1247378]]

**适用条件：Reaping（启用）。**

[[spell:343294]]

1.4.

#### Multi-Target Opener for Unholy Death Knights

1. Use [[spell:77575]].
2. Use 2x [[spell:85948]].
3. Use [[spell:42650]] + [[spell:63560]] + Trinket + Racial + Potion
4. Use [[spell:1247378]]
5. Use 2x [[spell:207317]].
6. **适用条件：Putrid Echoes（启用）。** Use [[spell:1247378]].
7. **适用条件：Reaping（启用）。** Use [[spell:343294]].

When it comes to timing your trinkets, you can just macro
them with [[spell:42650]] in all your openers. If you are lucky enough for receive [[spell:10060]], ask for it when you cast [[spell:42650]].

1.5.

#### Multi-Target Rotation Priority for Unholy Death Knights

The Multi-Target Rotation for Unholy Death Knights share a significant amount of priorities compared to Single Target. The main difference is that we use [[spell:207317]] instead of [[spell:47541]] when we fight 4+ targets (6+ during [[spell:1242158]]).

1. Use [[spell:42650]] and [[spell:63560]] on Cooldown.
2. **适用条件：Blightfall（启用）。** Use [[spell:1242616]] at the end of [[spell:63560]], follow up with [[spell:1247378]]
3. Use [[spell:77575]] to maintain your plagues on the target.
4. **适用条件：Cycle of Death（启用）。** Use [[spell:43265]] when fighting 3+ enemies.
5. **适用条件：Festering Scythe（启用）。** Use [[spell:455397]] if its buff is close to, or has fallen off.
6. **适用条件：Reaping（启用）。** Use [[spell:343294]] if any enemy is below 35% or you have triggered
     the [[spell:377514]] effect from [[spell:63560]].
7. **适用条件：Reaping（未启用）。** Use [[spell:343294]] if any enemy is below 35%.
8. Use [[spell:207317]] when you have a [[spell:49530]] proc or [[spell:1242158]] is active or you are playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn and have more than 50 Runic Power. Use [[spell:47541]] when fighting less than 4 targets (6 targets during [[spell:1242158]]).
9. Use [[spell:1247378]] if your [[spell:63560]] is active.
10. Use [[spell:85948]] if you have 3 or less stacks of [[spell:1254252]].
11. Use [[spell:55090]] if you have at least 1 stack of [[spell:1254252]].
12. Use [[spell:207317]]. Use [[spell:47541]] when fighting less than 4 targets (6 targets during [[spell:1242158]]).

Now, we will take this priority list and put it into a wordier
description!

- Use your Cooldowns as much as possible. Send [[spell:63560]] every 45 seconds and [[spell:42650]] every 45 seconds, always aligning them.
- **适用条件：Blightfall（启用）。** Use [[spell:1242616]] at the end of [[spell:63560]] and follow up with a [[spell:1247378]] to re-apply your Plagues and get value from the generated charge.
- Maintain your Plagues on the target by leveraging [[spell:77575]]. [[spell:1247378]] with [[spell:1254552]] can also be used but you tend to choose using Outbreak as your Putrefies are prioritised for cooldown damage.
- Use [[spell:43265]] when fighting 3+ enemies to maximise the number of [[spell:1247378]] you use during your [[spell:63560]]. Either send as many as possible during the window to get as much Cooldown Reduction as possible, or use them slightly before if you are not already at 3 stacks of [[spell:1247378]].
- Cast [[spell:343294]]. Either when any target is below 35% health or you have received the free use from [[spell:63560]] with [[spell:377514]]. It is a good idea to "snipe" low-health mobs to automatically consume your [[spell:1254252]] stacks.
- Use [[spell:207317]] during [[spell:1242158]] or to spend your procs of [[spell:49530]]. [[spell:49530]] is a powerful proc, and you do not want to waste any. If you have [[spell:276023]] talented, you can allow yourself to stack up two charges before you spend them. However, most of the time, you simply use them as soon as possible to avoid any potential waste. We only prioritise spending Runic Power during [[spell:1242158]] (oustide of the Sudden Procs), it is fine to overcap at other times. We use [[spell:47541]] when fighting less than 3 targets (4 targets during [[spell:1242158]]) as it will deal more damge.
- Use [[spell:85948]] to build up stacks of [[spell:1254252]] on yourself. We want to aim for between 4 and 6 stacks at all times to give us some flexibility, either when we are forced out of melee range. We also use [[spell:455397]] as a high priority if its buff has fallen off. In general, you will have to actively track and reapply this buff!
- Use [[spell:55090]] to consume your stacks of [[spell:1254252]].
  This is used in sync with [[spell:85948]] to keep your stack count at a
  healthy level. You go up to 4-6 and then use Scourge Strike to
  drop down to 3 again.
- Use [[spell:207317]] as your filler spell when you have nothing else to
  do! We use [[spell:47541]] over [[spell:207317]] when fighting less than 4 targets (6 targets during [[spell:1242158]]) as it will deal more damage.

### Additional Concepts

1.6.

#### Additional Concepts

This section digs slightly deeper in rotational aspects that you need to consider.

1.7.

#### Rotation during Forbidden Knowledge

When [[spell:1242158]] is active, our priority changes slightly. Our Runic Power spenders are buffed by our Apex Talent here, and the idea is to leverage this as much as possible. Using [[spell:1242174]], therefore, ends up being much higher on our priority list! Essentially, you use [[spell:1242174]] as soon as you can, either by going above 30 Runic Power or getting a proc of [[spell:49530]] (and being above 15 Runic Power).

1.8.

#### Vampiric Strike Fishing

When playing with the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn Hero Talents, the maintenance of the [[spell:433925]] buff is an important aspect to master. We quickly stack this buff 7 times during our [[spell:63560]] windows (due to unlimited [[spell:433901]]s) and then aim to extend it to our next Dark Transformation window (where we can easily maintain it again). Dark Transformation itself lasts around 20-35 seconds so we only really need to gain a single proc in between uses to bridge the 10-25 seconds gap! The importance here is to spend all your Runic power to maximise the chance of getting a proc if you are about to drop the buff!

Important to note here is that [[spell:43265]] is not worth using in Single Target, even with [[spell:434033]], [[spell:1234559]] or [[spell:1290864]]. The talent is not strong enough to justify pressing Death and Decay, even to get the extension.

2.

### Midnight Season 2 Tier Set

Our Season 2 tier set empowers our [[spell:390196]] and [[spell:1256813]] pets.
The 2-set makes them cast more powerful [[spell:198407]] and [[spell:1297091]] abilities.
The 4-set increases the damage of these new abilities by 130% against enemies below 35% health,
improving our execute power.

3.

### Class and Spec Mechanics Explained

This section deep dives into the mechanics of Unholy Death Knight, covering both
the resources we use as well as some advanced topics that can be useful when trying
to understand the rotation in more depth.

### Runes and Runic Power

3.1.

#### Runes

You have a total of 6 Runes, which are available by default. Some of your
abilities have Rune costs, and whenever you use an ability that consumes one
or more Runes, those Runes will immediately begin recharging. The exact amount
of time it takes a Rune to recharge depends on how much Haste you have.

Whenever a Rune is consumed, you gain 10 Runic Power (more on that
below).

At most, 3 of your runes can be charging up at the same time. It is
therefore optimal to keep at least 3 runes on cooldown to maximise
the recharge rate over the course of the fight.

3.2.

#### Runic Power

Runic Power is a resource that resembles Rage, in the sense that it
decays when out of combat, but does not decay during combat. As mentioned
above, consuming Runes generates 10 Runic Power per Rune spent, and this is
the primary means of generating Runic Power, although some abilities also
help with this. You can have a maximum of
100 Runic Power.

Choosing whether or not you should prioritise Runes or Runic Power
is a tricky decision as an Unholy Death Knight. We overcap on our
resources and often need to pick one or the other. In general, you
want to avoid overcapping on Runes (having more than 3) in Single Target
and avoid overcapping Runic Power (going above 100) in AoE.

### Apex Talents

3.3.

#### Apex Talents

Unholy Death Knight gets access to [[spell:1242158]] Apex Talents
as you level up from 80 to 90 in Midnight. The first rank provides a 30 seconds
buff once you cast [[spell:42650]], transforming your [[spell:47541]]
into [[spell:1242174]] and your [[spell:207317]] into [[spell:383269]].
These new abilities are powerful version of the baseline ones, notably
adding an AoE component to [[spell:47541]]. The impact to the rotation
is that [[spell:1242174]] is used at up to 5 targets in AoE ([[spell:47541]]
is only used at up to 3).

Rank 2 and 3 ([[spell:1256565]]) gives Mastery when [[spell:1247378]] is cast
and adds a stack of [[spell:1254252]]. Slightly less [[spell:85948]]s are
needed in the rotation but not much else.

Rank 4 ([[spell:1256566]]) gives [[spell:1240996]]
a 20% chance to trigger [[spell:1247378]] at 100% effectiveness, significantly increasing
the number of [[spell:1247378]] triggered in the rotation overall.

It is crucial to maintain good [[spell:1240996]] and [[spell:455397]] 
uptime to get the most of this talent. Furthermore,
your pets must be on assist for it to function properly.

### Runic Corruption

3.4.

#### Runic Corruption

[[spell:51462]] has a chance of proccing whenever we spend Runic
Power. It can also proc when we consume [[spell:49530]] and [[spell:178819]].
The proc will always return a total of 0.9 Runes, regardless of haste. The
proc also stacks on itself, adding any new duration to the previous remaining
one. All this means is that you do not need to pay attention to this process.

:::details TCDo I Need to Play Around Procs of Runic Corruption?
No. The procs stack on top of each other. Any remaining duration is simply
added to the new one if you get another proc.

:::

### Plagues

3.5.

#### Plagues

[[spell:191587]] is a Shadow damage DoT that is applied to targets
using [[spell:77575]] or [[spell:1247378]] with [[spell:1254552]]. It is
our AoE plague.

[[spell:1240996]] is a single-target only DoT (can only be applied to
one target) that is applied in the same way as [[spell:191587]]. This
is also the source of our [[spell:49530]] and [[spell:1256566]] procs.

### Anti-Magic Shell

3.6.

#### Anti-Magic Shell Usage

[[spell:48707]] absorbs 100% of all magic damage taken, up to 30%
of your maximum health, for 5 seconds and grants you Runic Power based on the
amount of damage that it absorbs.

While this ability has amazing survivability benefits, allowing you to often
taken practically no damage from various raid-damaging mechanics, it also has
great benefits for your DPS.

Indeed, the amount of Runic Power you gain if you absorb a lot of magic
damage is far from negligible. Therefore, you should always try to make use of
Anti-Magic Shell to boost your Runic Power generation throughout the fight. The
best way to do it is to know when a raid-damaging attack is coming, and to have
Anti Magic Shell up for that time. Then, simply enjoy the extra Runic Power
(and do not forget to spend it).

That said, for progression content, we fully recommend first and foremost
saving [[spell:48707]] to mitigate magic damage, before you consider
how to use it to increase your DPS.

4.

### Important Cooldowns for Unholy Death Knight

### Cooldown Timings

4.1.

#### Cooldown Timings

For raids, we always combine our cooldowns as much as possible. This works
out nicely as they all align on a 45-second cycle. A cooldown plan for a 4-minute
boss fight would look like the following:

- 00:00 — [[spell:42650]] + [[spell:63560]]
- 00:45 — [[spell:63560]]
- 01:30 — [[spell:42650]] + [[spell:63560]]
- 02:15 — [[spell:63560]]
- 03:00 — [[spell:42650]] + [[spell:63560]]
- 03:45 — [[spell:63560]]

Due to everything aligning perfectly like this, it is **crucial** that
you use your cooldowns as soon as they come up. Any delay means that your 1.5
-minute burst window will be delayed, potentially making you miss out on a
ton of value.

In Mythic+, the name of the game is cooldown efficiency. It is so easy to
lose out on a ton of value by holding your cooldowns "for that one big pack
that comes soon." As a general rule, use your cooldowns as much as possible, Especially
when you are using [[spell:63560]] on its own. It
is by far the easiest way to improve your DPS in Mythic+!

### Dark Transformation

4.2.

#### Dark Transformation

[[spell:63560]] transforms your ghoul for 15 seconds, causing its 
Claw ability to cleave all enemies near your pet. If you talent into [[spell:377514]], 
you get a free cast of [[spell:343294]] regardless of the target's HP as well! 
Furthermore, [[spell:63560]] significantly buffs your minions via the [[spell:390259]] talent!

You should use this ability on cooldown. Aligning it with [[spell:42650]]
every second time. Furthermore, it is a good idea to enter your [[spell:63560]] 
window with high stacks of [[spell:1254252]] (6-8) so that you can spend more 
time summoning pets for big burst, and less time building stacks with [[spell:85948]].

### Putrefy

4.3.

#### Putrefy

[[spell:1247378]] summons and sacrifices a [[spell:275430]] to strike the target
and then explode with AoE damage. It gains additional effects through talents,
mainly with [[spell:1254552]] making it also apply your Plagues if they
are not already up and the summoning of a [[spell:390196]] with [[spell:1256813]].

Using [[spell:1247378]] optimally is a relatively difficult game of optimisation. The primary
aspect to consider here is the large buff to the ability that you get via [[spell:390259]].
Due to this, we want to concentrate our uses within our [[spell:63560]] windows. What
this means gameplay-wise, is that you want to aggressively use your charges during
[[spell:63560]]. Do not use the charges (even at 3 stacks) in the window after
your Dark Transformation ended (before the next window). You ideally want to start every
Dark Transformation window with 2x [[spell:1247378]].

:::details TCWhy is my Putrefy damage so low?
This tends to be due to a low proc rate of your

[[spell:1256566]]

talent
which is due to low

[[spell:1240996]]

and

[[spell:455397]]

uptime. Furthermore, if
your pets are not on assist, the random procs you get won't actually function properly.

:::

### Blightfall

4.4.

#### Blightfall

[[spell:1271974]] is an interesting ability with strong synergy
with your Plagues. Once you use [[spell:63560]], your [[spell:63560]]
turns into [[spell:1271974]]. This new ability consumes all your plagues
on your target and any target it around, dealing 100% of the remaining damage in one big
burst.

The goal of Blightfall is relatively simple, stack up your DoTs to as high of a
duration as possible and then consume them, while having as many buffs active as possible.
In practice, in single-target this generally means that you use [[spell:1271974]]
towards the end of [[spell:63560]] while you still have trinket buffs up.
You then use [[spell:343294]] in a delayed manner to overlap this use.

### Death and Decay

4.5.

#### Death and Decay

[[spell:43265]] is generally not worth using for its damage. There is
synergy with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn with both [[spell:434033]] and [[spell:1234559]]
but neither of these talents are strong enough to make Death and Decay worthwhile to press.

[[spell:1290864]] does create a strong feedback loop of [[spell:1247378]] and [[spell:43265]].
When running this talent, it is worthwhile to use Death and Decay in AoE scenarios (3+ targets) for the Putrefy cooldown
reduction. Otherwise you primarily use it for the slow in conjunction with
[[spell:273952]]. You can stack it on top of itself, meaning you will be using double Death and Decay
after your [[spell:1247378]] usage in the opener in Mythic+ to get lots of charges back-to-back.

With [[spell:1290864]], you use it in the following way: If you enter your cooldowns with 3 stacks of
[[spell:1247378]], use [[spell:43265]] after you have used all your charges of Putrefy. If you
are approaching a cooldown window without max stacks of [[spell:1247378]], use [[spell:43265]]
ahead of the window to reach max stacks.

[[spell:1234559]] increases its damage but only by an average of 40% when you do
the math.

### Army of the Dead

4.6.

#### Army of the Dead

[[spell:42650]] summons several ghouls to fight at your side for 15 seconds. 
It also summons a [[spell:390196]] when talented. Finally, it transforms 
[[spell:47541]] into [[spell:1242174]] and [[spell:207317]] into [[spell:383269]] 
for 30 seconds via the [[spell:1242158]] Apex Talent.  It is a major cooldown 
that will end up being a significant part of our overall damage in any situation.

During [[spell:42650]] you cannot summon any more [[spell:275430]]. Instead,
abilities that would summon a ghoul instead make your existing ghouls cast [[spell:1294264]] (Single Target) or 
[[spell:1300330]] (AoE).

[[spell:288853]] additionally summon an Abomination for 30 seconds with this Cooldown.
The Abomination has an AoE Disease cloud that increases the damage enemies take from
your minions by 20%.

[[spell:49206]] additionally summons a Gargoyle for 25 seconds with this Cooldown.
The Gargoyle attacks your target with an attack that ramps in damage based off the amount of
Runic Power you have spent. Incentivises spending Runic Power as a priority when the pet is out.

5.

### Combat Assistant for Unholy Death Knights

Patch 11.1.7 in The War Within introduced the Combat Assistant functionality for all specs in the game.
This comes in the form of two tools that you can use to assist your rotation. The
Assisted Highlight feature will light up the spell that you are supposed to use next,
helping you determine what button you need to press. The Single-Button Assistant
will provide you with a single button that automatically pressed the appropriate spell.
**The Single-Button Assistant has a GCD penalty of 0.2 seconds every time you
press it, artificially slowing down your rotation**. This penalty means that you will always
do less DPS when using the Single-Button Assistant compared to what you could have done
with a perfectly executed rotation.

So how good is the rotation I can get from
these assistants? If we assume that you handle your cooldown usage perfectly, the
Assisted Highlight is roughly 5% less DPS. 
With the Single-Button Assistant, the number is about 15%
Do bear in mind that this is compared to absolutely
optimal play. A player with less experience with the rotation might see a significantly smaller loss,
or even a gain when using the assistants.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Sep. 2026:** Update default talent selections to include Soul Reaper.
- **23 Sep. 2026:** Update default selection to Sanlayn.
- **08 Sep. 2026:** Updated Priority list for hotfixed changes.
- **25 Aug. 2026:** Clarified Blightfall usage.
- **13 Aug. 2026:** Updated Blightfall usage.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **29 Jul. 2026:** Updated Rotation with 12.1 changes.
- **08 Jul. 2026:** Updated Runic Power priority in AoE.
- **15 Jun. 2026:** Updated for 12.0.7.
- **06 Jun. 2026:** Updated RP vs Rune priority.
- **02 May 2026:** Clarified DnD usage.
- **21 Apr. 2026:** Clarified death and decay usage and RP prio.
- **20 Apr. 2026:** Updated with 12.0.5 changes to rotation.
- **29 Mar. 2026:** Removed major CD aspect of single button assistant.
- **16 Mar. 2026:** Added tier set section.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Updated for patch 12.0.1.
- **02 Feb. 2026:** Added a death coil in the opener.
- **25 Jan. 2026:** Updated to coil at 2 targets.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **28 Nov. 2025:** Added FAQs in the rotation page.
- **28 Oct. 2025:** Fixed a broken prio list and updated some wording.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **14 Sep. 2025:** Updated opener.
- **07 Sep. 2025:** Clarified Scythe usage at saturated wound count.
- **25 Aug. 2025:** Updated DC vs Epidemic target count.
- **07 Aug. 2025:** Updated Apoc usage after bugfix.
- **04 Aug. 2025:** Updated for Patch 11.2. Improved selection boxes, added new talents and updated rotations.
- **27 Jun. 2025:** Moved Rotten Touch section to rotation block and improved some Wounds and Runic Power wordings. Also added BIS usage.
- **15 Jun. 2025:** Added more image blocks to help readability and fixed some minor issues. Also added section on Combat Assistants.
- **27 Apr. 2025:** Added 3 vamp strikes before UA in M+.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **14 Apr. 2025:** Updated Apocalypse usage in AoE rotation.
- **07 Apr. 2025:** Updated opener with late raise abom.
- **16 Mar. 2025:** Clarified Mythic+ rotation.
- **24 Feb. 2025:** Clarified Death Coil usage in AoE for San'Layn.
- **20 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **26 Oct. 2024:** Clarified Trollbane Chains of Ice priority.
- **21 Oct. 2024:** Added Festering Scythe gameplay bit.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4, added detailed trinket use with all new trinkets.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **14 Feb. 2024:** Added detail on Rotten Touch gameplay.
- **23 Jan. 2024:** Updated Fyralath priority after changes.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **20 Dec. 2023:** Minor clarifications to single target priotiy.
- **12 Dec. 2023:** Added Legendary to Opener.
- **02 Dec. 2023:** Updated Wound Rotation section.
- **24 Nov. 2023:** Added macros to opener section.
- **12 Nov. 2023:** Clarified unholy opener with Dark Transformation and Summon Gargoyle on the same line.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **21 Jul. 2023:** Added Mirror to Detailed trinket usage.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **25 Jun. 2023:** Max 4 coils to exactly 3 coils in opener.
- **14 Jun. 2023:** Added more detailed trinket and racial timings.
- **24 May 2023:** Resolved issues with the opener not displaying properly.
- **03 May 2023:** Added Death and Decay to opener and expanded cooldown usage section with DnD.
- **01 May 2023:** Reviewed for Patch 10.1.
- **29 Apr. 2023:** Reviewed and Updated for patch 10.1.
- **15 Apr. 2023:** Expanded on Disease build rotation.
- **20 Mar. 2023:** Updated rotation for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Unholy Death Knight in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Unholy Death Knight

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Unholy Death Knight. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your best next piece might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, catalysing an item retains its secondary stats (and ilvl). This provides a lot more flexibility in how we optimise our gear distribution. Due to this, we want the following pieces:

- Head: [[item:281239@JAACAAQ42A]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Shoulders: [[item:251138]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Chest: [[item:268222]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Gloves: [[item:271475]] from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- Legs: [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details FAQWhich Items Should I Prioritise?
There are a couple of items that are very high priority in your BiS gear and that you want to prioritise from Great Vault and Voidcore usage:

- [[item:268213]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): BiS weapon with higher ilvl and an extra effect making it stronger than any other option.
- [[item:270175]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS on-use trinket with a higher ilvl.
- [[item:268265]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS neck with higher ilvl and an extra effect.
- [[item:270173]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): BiS passive trinket that synergises with our BiS weapon.
- [[item:281029]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS ring with an extra effect.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:281239@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271473@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271477@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[spell:327082]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup from Mythic+ sources for Unholy Death Knight. This is not your best setup **for** Mythic+ but only **from** Mythic+.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, catalysing an item retains its secondary stats (and ilvl). From Mythic+, we want to catalyse the following pieces:

- Head - [[item:251126]]
- Shoulders - [[item:251138]]
- Chest - [[item:268222]]
- Hands - [[item:159413]]
- Legs - [[item:273776]]

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): Solid weapon, shoulders, helmet, and an okay trinket.
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): BiS ring and a solid Necklace.
- [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): Good waist and feet.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271474@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAAEAAAj1gjM]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271473@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:239656@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Feet</th><td>[[item:159412@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271477@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273797@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251134@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[spell:327082]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup from Raid sources for Unholy Death Knight.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, catalysing an item retains its secondary stats (and ilvl). From Raid, we want to catalyse the following pieces:

- Head - [[item:281239@JAACAAQ42A]]
- Shoulders - [[item:268226]]
- Chest - [[item:268222]]
- Hands - Tier Piece
- Legs - [[item:271878]]

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:268213]]: BiS weapon with higher ilvl and an extra effect making it stronger than any other option.
- [[item:270175]]: BiS on-use trinket with a higher ilvl.
- [[item:268265]]: BiS neck with higher ilvl and an extra effect.
- [[item:270173]]: BiS passive trinket that synergises with our BiS weapon.
- [[item:281029]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS ring with an extra effect.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:281239@JAAEAAgNyEuN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271475@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271472@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271473@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271477@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAMAAwt1ENMMYDYwclIcYD]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[spell:327082]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Unholy Death Knight in Season 2

Unholy Death Knight favours a combination of one active trinket and one
passive trinket. For active trinkets, [[item:270175]] is by far
our best option with great synergy with our 1.5 minute Cooldowns. It also comes at a higher
ilvl due to dropping from the final boss.

For passive trinkets, [[item:270173]] is our best option for
low-target count scenarios. It is a direct damage passive trinket which synergises with
our BiS weapon [[item:268213]]. For AoE scenarios, [[item:270165]]
will be better than Guillotine Technique.

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Unholy Death Knight Trinkets**
**On-Use -**

[[item:270175]]

or, alternatively,

[[item:273797]]

**Passive -**

[[item:270173]]

or, alternatively,

[[item:270165]]

:::

There are quite a few other valuable trinkets out there, so make sure to click on our
  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Unholy Death Knight Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;&#10;&#10;[[item:270175]] - <span><em>Click for Details</em></span>&#10;<span>Best on-use by far which synergises nicely with our 1.5 minute cooldowns. It sits almost 4% ahead of the second&#10;       best on-use so there is no real debate.&#10;       </span>&#10;&#10;&#10;&#10;[[item:270173]] - <span><em>Click for Details</em></span>&#10;<span>Best passive trinket for low target counts. The damage proc is simply too strong, especially when combined with [[item:268213]] - our BiS weapon.&#10;       </span>&#10;&#10;&#10;&#10;[[item:281215]] - <span><em>Click for Details</em></span>&#10;<span>Best passive stat trinket for AoE situations. With its high proc rate, its close to comparable to Guillotine in low target counts, &#10;        but shines in multi-target scenarios, while being particularly effective in Mythic+ content.&#10;       </span>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:249343]] (298 ilvl)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:246305]]</li>&#10;<li>[[item:241340]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:193762@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273796]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:246307]]</li>&#10;<li>[[item:270163]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Midnight's patch 12.0.5 introduced a new, yet familiar system: [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) 
allows you to target loot from specific bosses or dungeons. 
Using it guarantees a drop from that source, though the exact item is still random. 
However, once you’ve obtained an item this way, future uses will prioritize items you 
haven’t collected yet from that pool.

[[item:268552]] enhances Hero- and Myth-track gear that has already reached 
its maximum item level, as well as fully upgraded Radiance-Crafted items. It provides an 
extra power boost similar to past Turbo Boost upgrades, but can only be applied to weapons 
and trinkets.

3.1.

#### Nebulous Voidcore Recommendation

Getting a guaranteed piece of loot from a specific dungeon or boss is very useful.
In general, we recommend using these for raid encounters as you can obtain higher ilvl
pieces that way. We recommend using them on the following bosses (if you do not have the item
specified already). Always simulate yourself to find the best possible choice given your
character's gear and stats!

- [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) for [[item:268213]] and [[item:270173]].
- [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:270175]], [[item:271878]], and [[item:268265]].

3.2.

#### Ascendant Venomstone Recommendation

Prioritising the item upgrade is relatively simple: start with your weapon and then
follow-up with your trinkets, before finally upgrading your necklace.

4.

### Best Crafted Items for Unholy Death Knight

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose the exact
secondary stats you want.

Deciding what to craft is a difficult task. Our BiS crafted items are
Boots and Wrists, both with Crit Mastery and [[item:240167]].
However, crafting a 2H weapon early is often by far the largest upgrade possible
and a significantly more efficient spend of your crests. It does sit quite
a lot behind our BiS but still gives a strong early boost. Most people will
craft a 2H in general.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Unholy Death Knight Crafted Gear Priority**
- [[item:237828@JAAMAAwt1ENMMYDYwclIcYD]] with [[item:240167]]
- Any item you do not have on Myth track yet. Craft with [[item:240167]] if you dont have 2 Embellishments yet.
- [[item:237834@JAAMAAwt1ENMMYDYwclIcYD]] with [[item:240167]]

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments Unholy Death Knight

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

As there is a lot of competition for Embellishments, you will have to pick
and choose the two strongest ones for your overall DPS output. Most of them provide
very similar DPS benefits, even if the effects are entirely different. The two best
choices for this are:

- For Raid: [[item:240167]] on crafted Boots and a crafted Wrists.
- For Mythic+: [[item:240167]] on crafted Boots and a crafted Wrists.

A strong alternative is to run [[item:245876]] or [[item:273060]] on a crafted
2H weapon. This is especially powerful early in the season as it allows you
to get a high-ilvl weapon (which is the slot that provides by far the most benefit
per point of ilvl). Therefore, always consider crafting a 2H early in the season.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

[Myth Mistcrest](<https://www.wowhead.com/currency=3446>) is a currency you can use to upgrade your gear. Each
piece comes in a specific leveling track where it can be upgrade to a specific max
level. If you see an item with Myth 3/6, it means that it can be upgrade a total of
3 times to reach Myth 6/6. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Unholy Death Knight Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots/Rings**

:::

These are simply the items that tend to be the best to upgrade. Do not
follow the priority blindly as there are cases where you would want to upgrade
something else first. Always sim yourself to figure out what it your current
best option.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Update for 12.1.5.
- **07 Sep. 2026:** Reviewed and updated gear after hotfixes.
- **17 Aug. 2026:** Added best crafted items section.
- **13 Aug. 2026:** Expanded trinket tier list.
- **10 Aug. 2026:** Updated with 12.1 bis and trinkets.
- **15 Jun. 2026:** Updated with 12.0.7 with sporefused gear.
- **24 May 2026:** Fixed a gear drop location typo.
- **20 May 2026:** Fixed runeforge with new bis list format.
- **20 Apr. 2026:** Added new turbo-boost items.
- **28 Mar. 2026:** Resolved an issue with bis neck source.
- **16 Mar. 2026:** Updated for Season 1 with new BiS gear and trinket recommendations.
- **26 Feb. 2026:** Updated for Midnight with pre-season bis.
- **10 Feb. 2026:** Updated for Midnight pre-patch, changing BiS to match new stat prio and adding midnight leveling items.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7, movig prism higher in trinket tier list.
- **05 Oct. 2025:** Added Puzzling Cartel Chips.
- **07 Sep. 2025:** Fixed a trinket typo and list issue.
- **14 Aug. 2025:** Updated BiS trinket.
- **04 Aug. 2025:** Updated for Patch 11.2. Updated BiS, added new cloak and new trinkets.
- **23 Jun. 2025:** Updated best D.I.S.C effect after tuning.
- **15 Jun. 2025:** Added the D.I.S.C belt.
- **14 May 2025:** Swapped to duskthread as general recommendation and added info on ascension on crafted weapon.
- **27 Apr. 2025:** Updated Cartel Chips wording.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **02 Apr. 2025:** Updated trinkets after tuning.
- **03 Mar. 2025:** Updated bis after cyrce's nerfs.
- **01 Mar. 2025:** Updated tier set paragraph after buffs.
- **24 Feb. 2025:** Updated BiS lists, trinket tier lists, embellishments, crafting recommendations and tier set portion.
- **18 Dec. 2024:** Updated Cyrce's gems after news sims.
- **17 Dec. 2024:** Updated BiS lists to include Cyrce's Circlet after buffs.
- **15 Dec. 2024:** Update for Patch 11.0.7, adding Cyrce's Circlet.
- **26 Oct. 2024:** Resolved an issue in the Raid BiS list.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **05 Oct. 2024:** Updated BiS trinkets.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4, including Bullion priority and new BiS lists.
- **20 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **29 Nov. 2023:** Updated BiS after legendary was revealed.
- **22 Nov. 2023:** Updated Dawn drop locations to differentiate between upper and lower.
- **15 Nov. 2023:** Added Ashes to Raid BiS and moved it up in active trinket list.
- **07 Nov. 2023:** Updated BiS list and embellishment recommendations after sporecloak nerfs.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated for patch 10.1.7.
- **20 Jul. 2023:** Updated Bis Trinket and Neck.
- **10 Jul. 2023:** Updated trinket bis and added dawn of the infinite gear tips.
- **10 May 2023:** Updated trinket bis after Puzzle nerf.
- **08 May 2023:** Updated bis list and trinket prio after changes.
- **01 May 2023:** Reviewed for Patch 10.1.
- **30 Apr. 2023:** Reviewed and Updated for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Unholy Death Knight. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Unholy Death Knight Stat Priority

For raiding and Mythic+, the secondary stat priority for Unholy Death Knight
is as follows:

Critical Strike

Mastery

Haste

Versatility

Unholy mainly aims for a nice balance of Crit, Mastery and Haste. Importantly, these three
stats are significantly better than Versatility.

Usually, a higher item level piece of gear will be a bigger upgrade than a
lower item level piece of gear, even with better stats.

2.

### In-Depth Stat Breakdown

**Strength** is your primary statistic. You should look for it
in all of your upgrades. It provides you with Attack Power, which
determines the damage your abilities do.

**Mastery**, through [[spell:77515]], increases your
Shadow and minion damage. Furthermore, it increases the Critical Strike damage of
your Diseases and Minions. We get some higher-order scaling with Mastery due to
the Critical Strike damage interaction. This in turn leads to Mastery as well as Crit
being strong stats for us.

**Haste** will increase your attack speed and Rune regeneration rate. It
also reduces your Global Cooldown. For you pets, it increases their attack speed
as well as the rate at which they generate energy, making them use their abilities
more frequently.

**Critical Strike** increases your chance to critically hit with
all spells and abilities. Crits deal double damage by default, but several 
effects can increase your crit damage, and make crits even stronger.

**Versatility** increases all your damage and healing done, and decreases
all damage taken.

For Unholy, your pets and minions inherit your stats. Increasing your Haste
will make them hit faster and regenerate Energy faster. Critical strike will
increase their Critical Strike chance, etc. Stats are dynamically updated
for the pets, meaning a new buff you receive will then also be applied to any
pets you currently have. This means that you do not need to worry about applying
buffs before summoning any minions! However, it is important to recognize the
fact that this inheritance is not instantaneous! It takes anywhere between
0 and 5 seconds for the pets to actually inherit the stats from us (both when
we gain and lose the stats).

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **08 Sep. 2026:** Remove Commander of the Dead interactions from mastery, these were removed in 12.1.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **29 Jul. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated bis stat distribution for 12.0.5.
- **10 Apr. 2026:** Clarified recklessness value.
- **16 Mar. 2026:** Minor update to optimal stat allocation.
- **26 Feb. 2026:** Updated with new example stat allocation for Midnight.
- **10 Feb. 2026:** Updated stat weights with new sanlayn build.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Added Haste FAQ.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2, increasing Critical Strike value significantly.
- **15 Jun. 2025:** Fixed typo and clarified stat priority.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4, changed the raw stat amounts mentioned and clarified M+ equal stats priority.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2, added discussion on pet inheritance delay and raw stat impact on mirror procs.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **30 Apr. 2023:** Reviewed and Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Unholy Death Knight, based on your [stat priority](<https://www.icy-veins.com/wow/unholy-death-knight-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

We recommend going for [[item:240983]] as
your epic gem and then [[item:240906]] or [[item:240908]]
as your non-epic gems, prioritizing the stats that you have the least of on your gear. I.e.
if you already have lots of Haste on your gear, play the gem that provides more
Mastery, and vice versa.

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Head</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[spell:327082]] + [[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::details FAQWhat do the Different Runeforge Enchants Do?
- [[spell:327082]]: Strong synergy with all [[spell:275430]]s that
  you summon, and best Runeforge in all content.
- [[spell:53344]]: Nice strength and heal
  that falls a couple % short of [[spell:327082]].
- [[spell:53343]]: This Runeforge has more of a place with Frost
  Death Knights since Unholy does no frost damage.
- [[spell:326805]]: Provides a
  small execute effect for [[spell:49998]] and a small cheat death mechanic.
  This Runeforge has more of a place in PvP as opposed to PvE content.
- [[spell:326855]]: Provides
  small defense towards casters, making it more geared towards PvP
  situations.
- [[spell:62158]]: This Runeforge is primarily a defensive option
  that does not see play for Unholy.
- [[spell:326977]]: Sometimes used for leveling since it provides
  movement speed, Haste, and heals when you kill an enemy.

:::

3.

### Optimal Consumables

You can consume a number of different temporary items to increase your power
in Dungeons and Raids. Below is a comprehensive overview of everything you want
to use!

3.1.

#### Flask

Use [[item:241326]] as your go-to choice.
You generally want to use either [[item:241326]] or 
[[item:241322]] in all content. The choice depends on your current stats 
and is unfortunately not an obvious one. If you have
lots of Mastery and not much Crit, Shattered Sun is likely best. If you have lots of Crit
and not much Mastery, Magisters is better. You need to simulate yourself to get the most
accurate result that fits your character, but the above guidelines will serve you well in 99%
of cases.

3.2.

#### Potions

There are some options for potions that we can use, but we recommend [[item:241288]]
as your go-to potion for all content.

You should also make sure to keep up a stock of [[item:271883]]! These healing
potions are great for when you need to quickly heal yourself, helping your healers, and
ensuring that you stay alive.

3.3.

#### Food Buff

You can either pick up main stat food or secondary stat food in Midnight. For Unholy Death Knights,
main stat is the best option. This means that you either want to eat a feast such as [[item:255846]]
or [[item:255845]]. If your party or raid team does not supply a feast, you can eat
[[item:255847]] or [[item:242275]] as an alternative.

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s 
to increase your primary stat. Augment Runes are expensive and disappear on death, 
so use them wisely and sparingly!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **29 Jul. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Swapped to Recklessness as default potion.
- **28 Apr. 2026:** Updated recommended ring enchant.
- **20 Apr. 2026:** Reviewed for 12.0.5.
- **10 Apr. 2026:** Clarified potion usage.
- **16 Mar. 2026:** Updated food recommendation and added teas.
- **26 Feb. 2026:** Updated for Midnight with new enchants, gems and consumables.
- **10 Feb. 2026:** Added note on rune of apocalypse for Mythic+.
- **22 Jan. 2026:** Updated gem and ring enchant recommendations.
- **19 Jan. 2026:** Updated for Midnight, changing best Runeforge and adding leveling consumables.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Removed helm enchant disclaimer.
- **21 Apr. 2025:** Added corruption enchant recommendations.
- **01 Mar. 2025:** Updated food to Haste Mastery.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4, updated leg enchant to Lambent kit.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **12 Nov. 2023:** Updated food recommendation.
- **06 Nov. 2023:** Updated for Patch 10.2. Added new head enchant and swapped all stat enchants to Mastery.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **30 Apr. 2023:** Reviewed and Updated for Patch 10.1.
- **20 Mar. 2023:** Added Primordial Stone Gems recommenation.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Unholy Death Knight in World of Warcraft Patch 12.1.5.

1.

### Unholy Death Knight in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Unholy Death Knight in
Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

2.

### Best Mythic+ Talent Builds

Unholy Death Knight has a wide array of potential talent build in Mythic+ which
offer both unique game styles, as well as different damage profiles. We recommend
running the minion-based ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn build in Mythic+ as it brings both
strong single-target and AoE damage.

You have the option of running the [[spell:1271974]] plague build or
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse as well. The Rider build gives slightly more up-front damage,
as well as better mobility with [[spell:444010]].

### Rider Minion

2.1.

#### Rider Minion Build

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/rider-of-the-apocalypse.webp>) Rider of the Apocalypse build is very similar to
our single-target Rider build, swapping out [[spell:377587]] and
[[spell:207272]] for [[spell:455135]] and [[spell:1290864]].
The result is a versatile build that brings both high single-target as well
as respectable AoE.

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMDYzsYYgBmNGasgBMDAjZmxMAzMzYMA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-AeERphowgJQwwC-
```

:::

### San'layn Minion

2.2.

#### San'layn Minion Build

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn build significantly resembles
our single-target San'Layn build, swapping out [[spell:377587]] and
[[spell:207272]] for [[spell:455135]] and [[spell:1290864]].
The result is a versatile build that brings both high single-target as well
as respectable AoE.

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAgZGzYAwyMmZ2MzYMjBGYGbassAYbwGGwMAMmZGzgZGMjxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVBEWYgGxVko01higcC-RSTdfHOPruwGBIKQko0k5BGGEIIwIuB-AAAA-TCIQUJAxwBDmmF-
```

:::

### San'layn Blightfall

2.3.

#### San'layn Blightfall Build

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn build focuses heavily on plague damage, routing into
the [[spell:1271974]] talent. Blightfall is a really fun talent which
revolves around building up significant plague durations, and then consuming them
for great burst damage.

:::talents 天赋构筑
```json
{
  "code": "CwPAAAAAAAAAAAAAAAAAAAAAAAYmhZMzMDz2MzMTzmZGjZAAAAAAAAg5BGDDAWmhZ2MzYMjBGYGLassAYbwGGwMAmZmZGzgZGMjxA"
}
```
:::

:::details 来源计算器编码
```
#8D-WYfpBGGPSTUVVZ3CFVFYgGxVko01diigAsA-RSTdfOHPHByauqwISQoE6JIIuxxpBGA-AAAA-JgIpCTDQgwgxhF-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts, Stuns and Stops

[[spell:47528]] is your "kick" and your most important bit of utility in
Mythic+, used to stop enemy casts for the benefit of the group and especially
the tank. It is **highly recommended** to use a Focus Kick macro for this.

#### Mind Freeze Mouseover

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Mind Freeze
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

#### Focus Mouseover

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

3.2.

#### Stunning and "Stops"

[[spell:207167]] is your "AoE stop". You blind all targets in a cone in front of you, disorienting them for 5 seconds.
Great way of stopping a big pack of mobs casting, especially if the cast is immune to standard interrupt.

[[spell:221562]] is your single-target stun, lasting for 5 seconds. Not a
very common pick in our talent loadouts, but it's still a useful crowd-control tool.

[[spell:49576]] can both be used to help group up mobs, as well as
stop-casting them. Remember that you need to move the move a certain distance
to actually interrupt it, just so you do not use [[spell:49576]] when
the mob is already on top of you.

[[spell:49576]] is notably also a defensive ability. With [[spell:454822]],
it provides damage reduction against any target you use it on. Useful when you are mitigating
damage in boss fights or mini bosses.

Gnaw is your pet stun that stuns your target for 1 (2 during
[[spell:63560]]) seconds. Off the GCD so a very useful quick stop.

### Other Utility

3.3.

#### Other Utility

[[spell:61999]] is a combat-ress that you can use to bring a dead teammate back
to life, even during combat!

[[spell:207167]], [[spell:45524]] and [[spell:43265]] with
[[spell:273952]] all reduce the movement
speed of enemies hit, allowing us to help any tank that wants to kite the mobs.

[[spell:111673]] allows you to control an undead enemy in Mythic+. This is
only a crowd-control tool to be used in emergencies for Unholy. You lose your main
pet and thus a significant amount of your damage by controlling an enemy Undead.
Do it if you must to help your party from wiping.

#### Control Undead

```wow-macro
#showtooltip Control Undead
/target pet
/script PetDismiss()
/cast Control Undead
```

4.

### Dealing with Affixes

Midnight Season 2 offers four unique affixes that we can deal with to different
degrees with our kit. They rotate weekly with only one being active at a time. They
are also the only affixes that are active and require you to specifically handle them.

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. [[spell:207167]] is your most effective tool
  here to handle these orbs, with [[spell:47528]] and [[spell:49576]] handling
  any stray ones left.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn that
  needs to be focus-targeted and interrupted. Simply swap to the new add
  and focus it down. If you know it is spawning soon, considering holding your
  Cooldowns to deal with it quickly.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and circle
  around them. You have 15 seconds to soak all of these to buff your group. Use
  your movement abilities like [[spell:212552]] and [[spell:343257]]
  to quickly soak these up.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb. You can pre-immune this with [[spell:48707]]. However,
  this does mean that you miss out on the buff received when the shield is removed.
  Alternatively, help your healer to remove the shield by using [[spell:49998]]
  and Health Potions/ Healthstones if required.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **08 Sep. 2026:** Reviewed for Patch 12.1.
- **04 Sep. 2026:** Updated the recommended Mythic+ build to Sanlayn Minion.
- **24 Aug. 2026:** Updated to recommend Blightfall builds.
- **20 Aug. 2026:** Updated to Blightburst everywhere.
- **10 Aug. 2026:** Updated with Patch 12.1 builds.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **06 Jun. 2026:** Updated M+ build to run ghoulish frenzy.
- **28 Apr. 2026:** Updated M+ build to run cycle of death.
- **22 Apr. 2026:** Changed from abom for M+ build.
- **20 Apr. 2026:** Updated builds for 12.0.5 patch.
- **02 Apr. 2026:** Updated builds to run 2x UA instead of GF
- **16 Mar. 2026:** Updated for Midnight Season 1 with new builds and affix tips.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated builds for 12.0.1.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Aug. 2025:** Added rider disease build.
- **04 Aug. 2025:** Updated with Patch 11.2.
- **15 Jun. 2025:** Added talents to an image block to help with readability.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **14 Apr. 2025:** Added extensive dungeons tips.
- **16 Mar. 2025:** Updated M+ talents.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **30 Jan. 2024:** Updated the Wound M+ build.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **30 Apr. 2023:** Reviewed and Updated for patch 10.1.
- **20 Mar. 2023:** Updated talents for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Unholy Death Knight in World of Warcraft Patch 12.1.5.

1.

### Best Macros

1.1.

#### Generic Macros for Death Knights

1.1.1.

##### Raise Ally

#### Raise Ally

```wow-macro
#showtooltip Raise Ally
/cast [@mouseover,help][@target]Raise Ally
```

This macro casts [[spell:61999]] on your mouseover target, if they are a
friendly player. Otherwise, it casts Raise Ally on your current target.

1.1.2.

##### Mind Freeze

#### Mind Freeze

```wow-macro
#showtooltip Mind Freeze
/cast [@focus,harm,nodead][] Mind Freeze
```

This macro allows you to interrupt your focus target, if you have one, and
if not to simply interrupt your current target.

1.2.

#### Specific Macros for Unholy Death Knights

#### Outbreak Mouseover

```wow-macro
#showtooltip Outbreak
/cast [target=mouseover,exists] Outbreak; Outbreak
```

This macro will cast [[spell:77575]] on your mouseover target.

#### Death Grip Mouseover

```wow-macro
#showtooltip Death Grip
/cast [target=mouseover,exists] Death Grip; Death Grip
```

This macro will cast [[spell:49576]] on your mouseover target.

#### Dismiss Pet

```wow-macro
/petdismiss
```

This macro allows you to dismiss your pet, which might be required for
dungeons to avoid your pet ninja pulling.

#### Death and Decay Cursor Macro

```wow-macro
#showtooltip Death and Decay
/cast [@cursor] Death and Decay
```

#### Anti-Magic Zone Cursor Macro

```wow-macro
#showtooltip Anti-Magic Zone
/cast [@cursor] Anti-Magic Zone
```

These macros allow you to quickly plant your [[spell:43265]] or
[[spell:51052]] on your cursor.

#### Mind Freeze Mouseover

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Mind Freeze
```

This macro allows you to use your interrupt with a mouseover, avoiding
having to swap targets to interrupt.

#### Focus Mouseover

```wow-macro
/focus [@mouseover]
```

This macro enables a quick focus target setting using a mouseover.

1.2.1.

##### Pet Macros

Controlling your pet is a great way of optimizing your DPS and gameplay, here
are some useful macros for that!

#### Pet Move

```wow-macro
/petmoveto
```

#### Pet Follow

```wow-macro
/petfollow
```

Getting your pet to attack your current target is sometimes very useful. Usually
when you swap targets you want to move your pets to swap as well, to maximise the burst
you apply. This also helps when you pet gets "stuck" attacking something else, like a target
dummy in a dungeon (does happen).

#### Pet Attack

```wow-macro
/petattack
```

Resummoning the pet is sometimes the last resort to get it to you. This macro
will dismiss your pet if you have it and raise it if you do not. Be careful to
spam this as it can accidentally dismiss your pet twice, leaving you waiting
for 30 seconds before you can summon it again.

#### Pet Resummon

```wow-macro
/script PetDismiss()
/cast [nopet] Raise Dead
/petfollow
```

1.2.2.

##### Control Undead

Controlling an Undead creature in dungeons is generally a major DPS downgrade
for Unholy. However, it is sometimes needed for hard CC. The macro below automatically
dismisses the controlled pet and then controls it straight afterward:

#### Control Undead

```wow-macro
#showtooltip Control Undead
/target pet
/script PetDismiss()
/cast Control Undead
```

2.

### Best Addons

2.1.

#### Generic Addons for Death Knights

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **08 Sep. 2026:** Fix macro description order.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **12 Mar. 2026:** Updated for Midnight Season 1 with added death grip macro.
- **26 Feb. 2026:** Updated for Midnight with new macro copy elements.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed and updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed and updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed and update for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **30 Apr. 2023:** Reviewed and Updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
