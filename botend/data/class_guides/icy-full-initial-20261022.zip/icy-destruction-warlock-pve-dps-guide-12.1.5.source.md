## 专精概览

Welcome to our Destruction Warlock guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Destruction Warlock in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Destruction Mythic+ Resources

[NEW! Top Destruction Talent Builds](<https://raider.io/specs/destruction-warlock/talents>)

[Top Destruction Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warlock/destruction>)

[Destruction Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warlock--destruction>)

[Popular Destruction Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warlock--destruction>)

1.

### Destruction Warlock Overview

Destruction Warlock is a very flexible specialization that can find ways
to excel in a variety of environments. Destruction can deal a lot of bursts
to a single target and also efficiently cleave and AoE several targets at
once.

Destruction is almost always a viable candidate for progression fights, as
it has the least ramp-up time of any Warlock specialization. It can pressure
priority targets easily and also has strong cleave through [[spell:80240]].
Like all Warlock specializations, Destruction brings
[[spell:111771]], a powerful raid cooldown that can transport your
entire group 40 yards instantly.

Adaptable and Performing

Destruction Warlock brings high damage in single and multitarget, distant
cleave, funnel and hard target swap capabilities, at the expense of a rather
flat damage profile. Diabolist brings higher damage in single target while
Hellcaller elevates the multitarget capabilities.

The Turret Caster

In Midnight, Destruction is perhaps the most prone to tuning spec. Offering
high DPS capabilities and a toolkit that allows to match virtually any
encounter its only drawback is the limited mobility, exacerbated by lack of
instant spells outside execute and an increased importance on filler damage
and uptime on targets.

Master of All-Trades

Destruction scales better than most specs as the target count increases and
can be used to generate pure output of funnel damage on
key targets. As its damage profile is not as bursty as others, the spec is not
penalized by variable pull cadence.

Beside that, Midnight brings to the Warlock class a lot of
utility, in the form of Banes and AoE curses, as well as one of the highest
survivability across all classes.

High Utility

[[spell:111771]]s, most of the time, are a must in Raid environment,
while [[spell:20707]]s and [[item:5512]]s provide nice Quality
of Life.

In Dungeons the situation is different however, with Gateways
used for the rare skips, Soulstones being a cast time combat resurrection,
and Healthstones being just better potions.

Curses are in a better spot, offering AoE application and a stronger, but
timed variant in Blights. Pets can also be considered part of the utility,
but realistically it is just about using Felhunter for Spell Lock and Devour
Magic, unless a Dispel is badly needed from Imp.

Very Limited

Destruction is perhaps the most immobile of casters, especially in single
target, with only

[[spell:17962]]

and

[[spell:17877]]

being castable
on the move. In dungeons, depending on the talents, there is more mobility but
the spec identity is rooted on constantly hard casting.

Among the best

Warlock survivability is mostly fine. While the class lacks immunity or
damage reversal tools, the main mechanic is to buffer the existing Health
Pool with Overshield from

[[spell:108370]]

, mitigation
from

[[spell:108415]]

, and active spells like

[[spell:108416]]

and

[[spell:104773]]

.

2.

### Destruction Warlock in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

The patch features no Warlock changes and is instead focused on two new
endgame activities, a new Raid and the anticipated Labyrinth Mega-Delve. Make
sure to check the following links for further details:

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

This patch continues Season 2 storyline and gear progression, focusing on
quality of live improvements, new solo-focused content
with [Aqir Invasions](<https://www.icy-veins.com/wow/aqir-invasions-guide>), and much more! Make sure to visit our hub page
if you're curious what else awaits you with the 12.1.5 launch, and
beyond.

2.3.

#### Class Changes

Destruction Warlock received no changes for Patch 12.1.5, so the most recent changes to
the spec happened early into Season 2. Gear page has been updated with all the new
items from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>), as well as recommendations on how to use [[item:280562]]
once they become available.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 ChangesHide Patch 12.1 Changes
August 25 Hotfix increases Destruction AoE, lowering the relative gap with
Demonology in cleave. The resulting tuning brings all 3 Warlock spec much
more close in terms of damage.

[Midnight Hotfixes August 25](<https://us.forums.blizzard.com/en/wow/t/world-of-warcraft-midnight-hotfixes-august-25/2336376/68>)

**Warlock**

<em>Developers’ notes: We’re increasing the throughput of Affliction and
    Demonology by primarily focusing on their single-target tools with a
    secondary focus on their multi-target kit. Additionally, we’re
    considerably increasing the damage of Warlock demons so that they have a
    larger contribution to overall throughput. This should also help a bit
    more with aggro concerns during solo play.</em>

- Imp, Voidwalker, Sayaad, and Felhunter damage increased by
        350%.

**Destruction**

- Rain of Fire damage increased by 30%

Heading towards Patch 12.1 Destruction Warlock received several changes
affecting both Hero and Spec trees, alongside bugfixes to the spec and the
baseline [[spell:108370]] which now offers a more substantial defensive
layer.

The changes relative to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller shift the use case towards
single target with priority damage and spread cleave,
relegating ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist and its passive cleave to stacked multitarget
situations.

[Curse of Ula'tek Patch Notes](<https://us.forums.blizzard.com/en/wow/t/2317811>)

**Hellcaller**

<em>Developers’ notes: We’re updating Blackened Soul to give Hellcaller
    a better tool for focusing damage into a priority target, increasing the
    overall flexibility of the hero talent tree rather than have it only
    excel in situations where multiple targets are present. However, we are
    keeping the functionality of Malevolence the same, so it remains a cool
    and impactful tool in Hellcaller’s toolkit.</em>

- Blackened Soul has been redesigned: If the target is
        afflicted with your Wither, your Chaos Bolt and Shadowburn
        increase its stack count by 1. Each time Wither gains a stack it has a
        chance to collapse, consuming a stack every 1 second to deal
        Shadowflame damage to its host until 1 stack remains.
- Mark of Peroth’arn has been redesigned: Damaging critical
        strikes dealt by Wither deal 215% damage instead of the usual 200%.
        Damaging critical strikes dealt by Blackened Soul deal 225% damage
        instead of the usual 200%.
- Blackened Soul damage increased by 45%.
- Wither damage increased by 25%.

Talent tree changes are aimed at increasing Destruction single target
damage specifically, with a drawback of further reducing possible
alternatives in talent choices.

[Curse of Ula'tek Patch Notes](<https://us.forums.blizzard.com/en/wow/t/2317811/18>)

**Destruction**

<em>Developers’ notes: We are increasing the single target damage of
    each Warlock specialization and reducing Destruction’s cleave profile. We
    want Destruction to shine in 2-target situations; however, we want to
    keep that edge at a reasonable amount.</em>

- Havoc now causes spells to deal 50% of their damage to the marked
        target (was 60%).
- Soul Fire damage increased by 45%.
- Chaos Bolt damage increased by 5%.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Summary for Destruction Warlock

2.5.

#### Apex Talents

The most prominent feature of the expansion are the Apex talents which will
be gradually available during leveling. These points exists separate from the
tree and have to be invested sequentially in order to unlock the later
points.

1. [[spell:1265770]]
2. [[spell:1265772]]
3. [[spell:1265774]]

These talents mostly provide background power and do not affect the
rotation in itself broadly speaking, as any optimisation is overlapping with
existing practices already.

2.6.

#### Summary of Changes

Listed below is a breakdown of the changes separated in sections to
facilitate the read.

- **Hero Talents** received minor baseline changes and an addition of a fourth column.  
  
  
   ► **Click to expand**
  
  
  2.6.1. 
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist
  
  
  
  
  - [[spell:429893]] has been toned down to a minor damage
            	buff
  - New Talent: [[spell:1268709]] everytime you spend shards
            	summon up to 3 Oculi which will explode for AoE damage whenever a
            	Demonic Art is consumed
  - New Talent: [[spell:1268713]] while active Diabolic Oculi
            	will cast [[spell:1269892]] at your target every second
  - New Talent: [[spell:407470]] Each Diabolic Oculi exploded will
            	grant 2% intellect for 10 seconds
  
  
    
  
  
  
  2.6.2. 
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller
  
  
  
  
  - New Talent: [[spell:1266799]] increase the damage of
            	baseline shard spenders, doubled
            	during [[spell:430014]]
  - New Talent: [[spell:1266805]] [[spell:445465]] has a chance to
            	grant [[spell:430014]]
  - New Talent: [[spell:1266803]] [[spell:430014]] grants
            	additional Haste and casting the ability adds more [[spell:445465]]
            	stacks
- Substantial changes happened to core/rotational **Destruction Warlock** spells.  
  
  
   ► **Click to expand**
  
  
  - [[spell:17877]] has been changed to be usable only on
        			targets below 20% Health
  - [[spell:1245633]] now is a proc on crit that allows for a
        			free [[spell:17877]] cast, usable on any target regardless of
        			their health value
  - [[spell:1244877]] has been added as a support talent
        			for [[spell:152108]]
  - [[spell:205184]] now spread [[spell:348]] to up to 3
        			nearby targets rather than being a damage increase debuff
  - [[spell:387156]] has been removed
  - [[spell:387176]] has been removed
  - [[spell:457025]] and [[spell:457064]] have been
        			removed
  - [[spell:1280868]] is now a choice node
        			with [[spell:6353]], with [[spell:1245089]] being
        			the associated support talent
- Few noteworthy changes also happened to Warlockutility spells.  
  
  
   ► **Click to expand**
  
  
  - [[spell:1714]] and [[spell:334275]] are now
        			separate talents
  - [[spell:1265813]] has been added, allowing every curse to also
        			affect enemies around 10 yards of the main target
  - Blights were introduced, offering a more powerful version of
        			Curses, with a shorter duration and cooldown associated
  - [[spell:5484]] is now a choice node
        			with [[spell:30283]] and has a new supporting talent
        			in [[spell:1270255]], reducing its cooldown and affe
        			ting up to 10 targets
  - [[spell:755]] has been removed and its healing has been
        			added to [[spell:234153]] with [[spell:1265810]]

3.

### Basics of Destruction Warlock Gameplay

Destruction Warlock is a fairly straightforward spec, leaning towards
hard-hitting direct damage spells, strong and long-lasting cooldowns, and a
relative amount of pet management. At its core, the gameplay is about
generating and spending the Warlock's iconic resource: Soul Shards.

The basics are simple: maintain [[spell:348]] on the target(s), spend
your shards on [[spell:116858]]s or [[spell:5740]], cast
[[spell:17962]] on cooldown, and [[spell:29722]] in the downtime.
Destruction Warlock is best described by these three focal points.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_immolation.jpg>) **Maintain Immolate**  
  
  [[spell:348]] is a deceptively powerful DoT that generate a good amount 
    of Soul Shards during a fight. Make use of [[spell:152108]] and [[spell:205184]] 
    to apply and extend [[spell:348]] on every target.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_warlock_demonbolt.jpg>) **Maximise Havoc and Mayhem windows**  
   
    Since [[spell:80240]] duplicates your single target spells, it is very achievable to 
    react to a [[spell:387506]] proc and guarantee a double [[spell:17962]] and a 
    [[spell:116858]] or two [[spell:29722]]s for additional shard generation. 
    Remember that Havoc also duplicates the Shard generation of spells.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **Be Flexible in your Approach**  
  
    Destruction has a limited ability to pool resources and a Shard flow fast 
    enough to allow to recharge them quickly afterwards. Use it to your advantage 
    in order to burst down key targets when needed. [[spell:80240]] and [[spell:387506]] 
    allow you to single target without losing too much damage in AoE.

4.

### How to Gear Up as a Destruction Warlock

While we always recommend simming yourself for ideal results, we do provide a
dedicated Destruction gearing page. We currently cover recommendations for
the ongoing Season gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket list.
- **31 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated AoE rotation section.
- **25 Aug. 2026 (this page):** Updated for August 25 Hotfixes.
- **16 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated BiS lists, embellishment and trinkets to account for a new profile and trinket tuning.
- **16 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated consumables to reflect new BiS lists.
- **12 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated Shadowburn cutoffs.
- **11 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated Gems and FAQ sections.
- **11 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Gems.
- **11 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated Talent choices.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Added Omnium Folio for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **22 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated BiS list to account for different talents.
- **22 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated single target talents.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Tea section.
- **23 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated Spender section with new cutoffs.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated Trinket ranking to account for Gaze nerf.
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Expanded the Tier Set bonuses section.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Added a lv80 import for leveling to Midnight.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated talent tree for Midnight release.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Midnight Release.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Midnight release.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated Rotations and added Apex sections for Midnight release.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated talent trees and added Apex section for Midnight release.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Added Apex for Midnight release.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Added an Apex section and updated talents for Midnight Release.
- **26 Feb. 2026 (this page):** Updated Performance and Apex sections for Midnight Release.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated talent trees for the changes to each gate unlock.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated talent trees for the changes to each gate unlock.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated talent trees for the changes to each gate unlock.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **09 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated multitarget logic.
- **22 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated weapon enchants.
- **22 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated Soul Fire lines.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated DISC socket recommendation following tuning.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7 and DISC.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Added a section for Combat Assistant.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Added a section for the Combat Assistant.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **04 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket recommendations.
- **04 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated a broken import link.
- **19 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Updated talent recommendations.
- **19 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated single target setup.
- **06 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated dungeon talents reccomendations.
- **04 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated BiS lists and trinket ranking.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7. and Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **30 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated BiS list after hotfixes.
- **30 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated Single Target talent after hotfix.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** Updated talents recommendations.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Reviewed for Patch 11.0.5.
- **25 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Re-done page layout, updating sections accordingly.
- **25 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Added a Shadowburn variant to Diabolist build.
- **19 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5 and added a dungeon tooltip section.
- **12 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated weapon enchants and oils.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Added BiS lists for Season 1, updated trinket section.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated gems section, as the strategy changed.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated talent selection for Season 1 launch.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated talents recommendation for Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Updated Viability assessment to reflect Season 1 status.
- **26 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Added a Delve talents reccomendation.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Added a leveling playstyle section.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Added Pre-Season BiS list section.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Added Hero Talent sections and selectors.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated recommendations to feature Hero Trees.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated sections to account for Hero Talents.
- **21 Aug. 2024 (this page):** Updates strenghts/weaknesses and viability sections.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/destruction-warlock-mists-of-pandaria-remix-guide>)):** Page updated for The War Within pre-patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **19 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/destruction-warlock-the-war-within-pve-guide>)):** Updated for The War Within pre-patch.
- **19 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **19 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/destruction-warlock-the-war-within-pve-guide>)):** Page Created.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/destruction-warlock-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Updated for Patch 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Season 4 launch.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Updated for Dragonflight Season 4.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated trinket section for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated Talents for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **03 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated Talents and Stats.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Embellishment recommendations updated after Undulating Sporecloak has been annihilated.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated Gear recommendations for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Talents updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated talents for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Reformat of the page with BiS tables and section updates.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Restructured Talent section.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.7
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Talents updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated talents for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for talent changes in Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated talents for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Added Patch 10.1.5 and updated the viability sections.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Phial recommendation after Corrupted Rage buff.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for Patch 10.1
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Talents updated for Patch 10.1.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated talents for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for patch 10.1.
- **01 May 2023 (this page):** Added a new section for patch 10.1 and updated the viability section.
- **24 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated Onyx Annulet section to account for live hotfixes.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stones recommendations to account for the additional live hotfixes.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stones recommendations to account for 25% buff hotfix.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated talent tree for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/destruction-warlock-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Added Patch 10.0.7 new ring section. .
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Added Primordial Stones section for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Talents updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Added Madness section.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated talents for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated talent trees to reflect class changes for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated talents for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Added Patch 10.0.7 and updated the viability sections.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Added an Inferno section, and updated the talent recommendation.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated talent selection for single target and 2 targets for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated talent selection for patch 10.0.5.
- **24 Jan. 2023 (this page):** Updated for Patch 10.0.5.
- **07 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated dungeon phial to a more reliable Phial of Tepid Versatility.
- **24 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated talent selection for single target.
- **14 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated Weapon Runes.
- **13 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated Embellishment recommendations.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Season 1 launch.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated recommended build.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated selectors for the openers and priority lists.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/destruction-warlock-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/destruction-warlock-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/destruction-warlock-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/destruction-warlock-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **30 Jul. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-2-changes-analysis>)):** Updated for Season 4 tuning pass.
- **22 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-2-changes-analysis>)):** Updated to reflect Patch 9.2 launch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-1-changes-analysis>)):** Updated for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-1-changes-analysis>)):** Removed PTR disclaimer.
- **27 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-1-changes-analysis>)):** baseline changes, legendary and covenant recommendations updated.
- **05 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/destruction-warlock-patch-9-1-changes-analysis>)):** Page created.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **14 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-the-eternal-palace-raid-guide>)):** Updated Boss Tips and Talent/Essences selection.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated after recent raid nerfs.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **11 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated with better talent choices, and more tips.
- **05 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated for Battle of Dazar'alor Heroic week fixes.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-uldir-raid-guide>)):** Updated for Patch 8.1. Reviewed talent advice for all bosses.
- **09 Nov. 2018 ([Uldir page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-uldir-raid-guide>)):** Updated boss guide.
- **07 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-uldir-raid-guide>)):** Updated for Uldir.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Destruction Warlock leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Warlock leveling guide](<https://www.icy-veins.com/wow/warlock-leveling-guide>).

1.

### Destruction Warlock Leveling Guide for Midnight

Destruction Warlock strength is to burst down individual targets
before suffering retaliation, and as such, it is best to quickly kill individual
enemies and move to the next. Destruction tagging capabilities are generally
limited to [[spell:17962]] and [[spell:17877]] until later
when [[spell:445465]] is unlocked as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller.

[[spell:17877]] is the main tool used to quickly kill lesser enemies
one after the other, and its reset mechanic should be exploited as much as
possible.

Worth mentioning is Destruction AoE being difficult to utilize effectively
as spells generate high threat and [[spell:5740]] requires the target to
stay in its area.

Curses, crowd controls, and pet off-tanking can substantially reduce the amount
of incoming damage, promoting aggressive play, while all the personal
defensive cooldowns offer a degree of safety even when overpulling.

For bigger enemies such as Elites or Rares, Destruction suffers the most
from Voidwalker's lack of aggro, creating either a very slow attrition battle
with [[spell:234153]] and [[spell:1265810]] or a situation where
the player rips aggro after some [[spell:116858]]s.

1.1.

#### Leveling Gear Options

When leveling up, you should always choose the piece of loot with the
highest item level. If the item levels are equal, you should choose the piece
with stats that are most favorable to your specialization. If your current item
is an Heirloom, it should not be replaced.

While the most important aspect of Heirloom is the bonus Experience, to get
most out of their stats allocation, you want to prioritize Intellect, then
Haste, then Critical Strike. The reason behind this is that Haste generally offers a
smoother combat experience while increasing your DPS in a homogeneous way,
unlike Critical Strike, which is still important but less consistent by
nature.

Being able to cast faster offers the advantage of tagging mobs quicker and
overall has a nicer feeling when most of the actions complete quicker.

1.2.

#### Useful Leveling Consumables for Midnight

Listed below are several consumables that can be leveraged to quicken the
leveling process and are generically beneficial regardless of tuning.

The War Within enchants will still work throughout the leveling process, and can help augmenting character speed.
Prioritize the following.

- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

Combat potions give a burst of power and if anything its best to use them
before they become irrelevant at max level.

These consumables are mostly aimed at speeding up the traversal and navigation.

- [[item:109076]]
- [[item:132516]] or [[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]] or [[item:133576]]

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Destruction Level 80 Midnight Leveling
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAYMjZGNLmx2MzYWmNmZmFzMbLmBAAzMjZmZxCMwwoBAmNsxAAAjBAAwMDGzMMAAAMjxAAwMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAYMzMzoZxM2mZGzysxMzsYmZbxMAAYmZMzMLWgBmFjGzAY2wGDAAMGAAAzMYMzwsAAAYGjBAgZYA"
}
```
:::

:::details 来源计算器编码
```
#LE-ITVVUUHDPfiklbLMOJSD80kw01ZkdF1ZURB-lZawYalEpI98ABcqhhB1BSyNilrrhuC-AAAA-JUGYkAQohZBZwB-
```

:::

2.1.

#### War Mode Talents for Leveling

1. [[spell:200546]] replaces [[spell:80240]]
    with a ground-targeted AoE variant, enabling it to deal massive damage on
    any target caught in the area.
2. [[spell:200586]] is mostly useful for its movement slow while leveling.
3. [[spell:248855]] should always be
    considered to expedite your whereabouts in closed spaces where mounts
    are not usable.
4. [[spell:353753]] can offer further AoE burst
    when kiting targets around.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1 起：**

**等级 1–9：**Starting at Level 1, you only
have one main attack ability: [[spell:686]].

1. **等级 2–3：**[[spell:172]] should be used to tag and
    soften up multiple enemies whenever spamming a
    few [[spell:686]]s will not kill them
    quicker.
2. **等级 35 起：**Use [[spell:1122]] as
    often as possible.
3. **等级 67 起：**Once you talent into [[spell:1245633]],
   your critical hits will have a chance to grant a free [[spell:17877]], castable on any
   enemy regardless of their health.
4. **等级 29 起：**Use [[spell:17877]] on targets below 20%
    health to execute them and hopefully trigger the shard refund.
5. **等级 27 起：**Use [[spell:152108]] as
    often as possible.
6. **等级 19 起：**Use [[spell:80240]] when there is
    a second target to duplicate every single-target spell.
7. **等级 11 起：**Cast [[spell:116858]] whenever
    you have at least 2 Shards.
8. **等级 15 起：**Cast [[spell:5740]] when
    you have 3 shards and there are at least 3 targets stacked.
9. **等级 10 起：**Maintain [[spell:348]] on as
    many targets as possible for high damage and shard generation.
10. **等级 13 起：**Cast [[spell:17962]] when
     moving and when you do not have more than 4 and a half shards.
11. **等级 10 起：**[[spell:29722]]
     replaces [[spell:686]] with the ability to
     generate Soul Shard bits. Use it as the lowest priority spell.

TipsHealing Your Demon

Do not forget to keep your Demon healthy in combat
using [[spell:234153]] with [[spell:1265810]].

TipsDo Not Underestimate Curses!

With the introduction of [[spell:1265813]], Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:440057]] is unique to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and combines
  	the above two curses
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

4. 

## Pet Choice while Leveling

[[spell:688]] is your first available demon. This
pet is not particularly useful for leveling, but you have no choice for the
early levels.

If you are leveling alone, [[spell:697]]
can be a helpful choice while leveling up, as it takes a lot of the pressure
off you. Avoiding casting pushback can also increase leveling speed.

[[spell:691]] can be a good choice if
you are leveling in a group or venturing into dungeons. The extra interrupt
is helpful for dealing with troublesome caster mobs.

5. 

## Changelog

- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **02 Mar. 2026:** Added a lv80 import for leveling to Midnight.
- **26 Feb. 2026:** Updated talent tree for Midnight release.
- **10 Feb. 2026:** Updated talent trees for the changes to each gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Added a leveling playstyle section.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated talent tree for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less


## 快速入门

On this page, we explain how to easily play Destruction Warlock in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Destruction Warlock

This section is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

Destruction is a flexible specialization that can provide a variety of
damage types and pressure without much rotational complexity. In this section,
we will be focusing on a setup that minimizes the number of buttons and
reactivity necessary without unduly compromising overall damage output.

Listed below are three simple rules to help you understand the spec:

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_immolation.jpg>) **Maintain Immolate**  
  
  [[spell:348]] is a deceptively powerful DoT that generate a good amount 
    of Soul Shards during a fight. Make use of [[spell:152108]] and [[spell:205184]] 
    to apply and extend [[spell:348]] on every target.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_warlock_demonbolt.jpg>) **Maximise Havoc and Mayhem windows**  
   
    Since [[spell:80240]] duplicates your single target spells, it is very achievable to 
    react to a [[spell:387506]] proc and guarantee a double [[spell:17962]] and a 
    [[spell:116858]] or two [[spell:29722]]s for additional shard generation. 
    Remember that Havoc also duplicates the Shard generation of spells.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **Be Flexible in your Approach**  
  
    Destruction has a limited ability to pool resources and a Shard flow fast 
    enough to allow to recharge them quickly afterwards. Use it to your advantage 
    in order to burst down key targets when needed. [[spell:80240]] and [[spell:387506]] 
    allow you to single target without losing too much damage in AoE.

2.

### Beginner's Guide to Destruction Warlock in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist   Beginner Talents

2.1.

#### Beginner Talents for Destruction Warlock

This build is optimized for ease of use while offering a setup that
works in any situation with no adjustments required, including Raid, Mythic+,
and even Delves. This is not the optimal choice in either single target or multi-target in
terms of output, but serves as a build that can help players become familiar with the
specialization at its core before moving on to more specialized builds from our Talents page.

To import this all-rounder build directly in-game, click on the export button at the
bottom of the calculator:

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAgZmZGNLmxiZGzyshZmlZmZZZmBAAjZWmZmFwYGDbwAbDL0YhBAAGAAgZGgxMjZ2AAAMzMGAAmhB"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfhiklnELM028MTjchprrowwJbM-lZaswSYEZYo488ANRB8ASjrrNSSiilK-AAAA-AOQo0QswITgwwC-
```

:::

### Destruction Warlock   Basic Rotation

2.2.

#### Single-Target Rotation

1. Cast [[spell:1122]] on cooldown.
2. Maintain [[spell:348]] at all times.
3. Cast [[spell:116858]] if you have 5 Soul Shards.
4. Cast [[spell:17962]] if you have 2 charges.
5. Cast [[spell:152108]] when available.
6. Cast [[spell:17962]] to generate Soul Shards.
7. Cast [[spell:29722]] to generate Soul Shards.

:::details FAQWhat Pets/Demons Should I Use?
In Dungeons and Mythic+, we recommend using/sacrificing the Felhunter, as
interrupt is invaluable for such environments. This of particular importance in
higher levels of Mythic+, as certain spells can cause wipes for the group.

In Raid environments, we recommend using the Imp, if the encounter requires
[[spell:89808]] to be used or there are frequent target swaps.

The Voidwalker is recommended for leveling, or for environments where you
plan to use [[spell:108503]], but do not need the interrupt from
Felhunter. Sacrificing a Voidwalker grants the [[spell:17767]] skill
to the player, a defensive cooldown that provides increased survivability to
the player.

The Succubus generally offers slightly higher damage than Imp or Felhunter,
and can be used if you prefer the visuals, or need a permanent 50% slow on a
single target.

:::

2.3.

#### Multi-Target Rotation

Maintain [[spell:348]] on up to 3 targets by using [[spell:17962]]
on the main target with an [[spell:348]] active. [[spell:5740]]
should become your main Soul Shard-consuming spell with at least 5 targets
stacked together. Keep in mind there will be situations where
using [[spell:116858]] will be more beneficial, such as targets constantly
moving away from the [[spell:5740]] area.

:::details TipsHealing Your Demon
Do not forget to keep your Demon healthy in combat
using [[spell:234153]] with [[spell:1265810]].

:::

:::details TipsDo Not Underestimate Curses!
With the introduction of

[[spell:1265813]]

Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  can be interrupted
- [[spell:702]] delays the time between melee attacks and
  should be used when pulls are mostly comprised of melee mobs
- [[spell:440057]] is unique to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and combines
  the above two curses
- [[spell:334275]] is a movement speed slow, helpful for kiting
  but otherwise more situational

:::

2.4.

#### Apex Talent: ![Embers of Nihilam Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_shadowflame_missile.jpg>) Embers of Nihilam

Your Apex talent, [[spell:1265770]], provides passive damage procs and requires no
change in gameplay to get the full value out of.

2.5.

#### Destruction Warlock Midnight Season 2 Tier Set

Season 2 set bonuses are entirely passive and do not alter the gameplay.

### Destruction Warlock   Stat Priority

2.6.

#### Stat Priority for Destruction Warlock

Currently, you will want to prioritize secondary stats as follows.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>).

Item Level

Haste to 22%

Critical Strike

Mastery

Haste

Versatility

### Blizzard   Combat Assistant

2.7.

#### Combat Assistant For Destruction Warlock

The [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) is comprised of two main features:

- **Assisted Highlight:** Displays the next spell to be queued, in a
  	adequately accurate rotation single target and limited capabilities in
  	multitarget, best used to familiarize with the flow and cadence of the
  	spec.
- **Single Button Assistant:** Enables use of a single input for multiple
  	skills in the sequence prompted by the Assisted Highlight, at the
  	expense of a longer base global cooldown (which accounts for an
  	additional 5% to 10% dps loss)

**It is worth pointing out that these tools are accessibility features first
and foremost and should not be considered a direct replacement to learn a
spec.**

The areas where the Combat Assistant struggle the most
for Destruction Warlock are:

- DoT uptime, since there is no supported logic for the Pandemic
    mechanic, especially aggravating in multi-target
- Multi-target in general, due how it considers all targets stacked
    regardless of the situation

2.8.

#### Combat Assistant Tips

- Cooldown alignment has to be done manually, especially considering
  racials, potions, and on-use equipment
- DoTs should be refreshed within Pandemic range, as following the
  Combat Assistant blindly will result in much lower uptime
- [[spell:17962]] strength comes from the mobility associated with
  its usage, best to keep 1 charge available when movement occurs
- In general, try to maximize the amount of time spent casting,
  especially when using the Single Button Assistant, as downtime is one
  of the improvement areas at any stage of the game

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Added an Apex section and updated talents for Midnight Release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added a section for the Combat Assistant.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **04 Apr. 2025:** Updated a broken import link.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated sections to account for Hero Talents.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated talents for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated talents for Patch 10.1.5.
- **01 May 2023:** Reviewed for patch 10.1.
- **20 Mar. 2023:** Updated talents for Patch 10.0.7.
- **24 Jan. 2023:** Updated talent selection for patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Destruction Warlock in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Destruction Warlock

In Season 2 the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller rework shifts the Hero Tree identity
towards single-target and spread-cleave, and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist offers
better performance in any situation where stacked-cleave or AoE is involved.
Whilst there are still some opportunities for personal preferences and situational
adjustments, below are our current recommendations:

- **Single-Target**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller is the better option
      for single-target, as well as 2-target and spread cleave. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist
      remains competitive when encounters feature any form of stacked
      cleave.
- **AoE**— [[spell:470479]]s and [[spell:1268709]]
      offer substantial cleave opportunities, making ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist the
      better choice at any key level, particularly lower ones,
      as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller lost too much AoE with Patch 12.1.

**Quick Start Import Codes:**

:::talents Destruction Single-Target - Hellcaller
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMzmZmZWmFzMzsYMWMDAAmZGzMziNYgZxoxMAmtYjBAAGDM2AAmZwYGzYDAAwMzMAAMGG"
}
```
:::

:::talents Destruction AoE - Diabolist
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysNzYmFzYZZMAAYGjZmZBMmxwCMw2wCNWYAAgxMMsBgZGgxMjZ2AAAMzMzAAYMM"
}
```
:::

:::talents Destruction Delves - Hellcaller
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysZGzsYYZZmBAAzMjZmZxCMwsY0YGAzG2YAAgxMAAAzMYMzMmNAAAzMzMAAMDD"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Diabolist

Single-Target

Mythic+

recommended

Hellcaller

Single-Target

recommended

Mythic+

Delves

### 天赋方案 0-0

1.1.

#### Single-Target Talents

A standard single-target setup centered around [[spell:116858]] damage
and fast Rituals cycling, supplemented by increased Shard Generation
from [[spell:387173]], [[spell:6353]],
and [[spell:1280483]].

### 天赋方案 0-1

1.2.

#### AoE/Mythic+ Diabolist Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist in dungeons is suited towards priority damage and
burst, using [[spell:205184]] to spread [[spell:348]] and
leveraging any opportunity to use [[spell:17877]].

The choice between [[spell:387506]] or [[spell:80240]] is personal, with the
former offering higher uptime on cleave and the latter giving players the
choice of when and where to duplicate the damage.

### 天赋方案 1-0

1.3.

#### Single-Target Talents

The talent selection for this build is designed to
maximise [[spell:116858]] damage and the Shard generation required, with
talents like [[spell:387173]], [[spell:6353]]
and [[spell:1280483]] fueling your Chaos Bolt spam.

### 天赋方案 1-1

1.4.

#### AoE/Mythic+ Hellcaller Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller offers higher AoE bursts and single target and the
expense of worse AoE and cleave and puts a bigger emphasis on spreading the
maximum amount of [[spell:445465]] and spending shards
on [[spell:5740]].

The 2 points in [[spell:387384]] can be swapped for [[spell:152108]]
and [[spell:1244877]] to increase AoE past 7 targets or further
increase burst in short fights.

### 天赋方案 1-2

1.5.

#### Delve Talents

While the Hero Tree choice is not particularly defining,
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller offers [[spell:440057]] as a catch-all
debuff for any difficult encounter you might encounter in [Delves](<https://www.icy-veins.com/wow/delves-guide>).

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMzmZmZWmFzMzsYMWMDAAmZGzMzCYMjhFYgthFaswAAAjBGbAYmBYMjZsBAAYmZGAAGDD"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPQghklnoLM028Mtuw01JUUYENbM-lZaATswikm6MMa88ARB4w11m4RhBiiF-AAAA-OUAaYWCQUYUgwA-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysNzYmFzYZZMAAYGjZmZBMmxwCMw2wCNWYAAgxMMsBgZGgxMjZ2AAAMzMzAAYMM"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfhiklnoELM028MTjehprTwwJbM-lZaswSYEJ1FYYo0wBi6DowQxhrrNPxj-AAAA-AOQo0QowITgwwC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMmZGNLMzmZmZWmFzMzsYMWMDAAmZGzMziNYgZxoxMAmNsxAAAjBGbAAzMYMjZsBAAYmZGAAGDD"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPQghklnoLM028Mtuw01JUUYENbM-lZaATswikm6MMa88ARB4w11m4RhBiiF-AAAA-JQSU2AMQYgxBzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzysNzMzsYGLLjBAAzYMzMLWgBmFjGzAY2wGDAAMGMsBAMzgxMjZ2AAAMzMzAAYMM"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfiklnoELM028MTjchprTwwJbcI-lZaswSYEJ1FYYo0wBi6DowQxhrrNxjE-AAAA-JQSU2AIQYgxBzC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysZGzsYYZZmBAAzMjZmZxCMwsY0YGAzG2YAAgxMAAAzMYMzMmNAAAzMzMAAMDD"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfgiklnoELM028MTjehprTwwJbM-lZaswSYEJN1ZY0w55BiCowQxhrrNPSS-AAAA-JQSU2AIQYgxBzC-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

Introduced in [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), Omnium Folio is a new source of player
power that unlocks over the course of few weeks and offers a choice of small
but flexible bonuses that can be swapped at any time to match the desired
content. The selection of Runes can be tailored to offer throughput, or pivot
to survivability and utility.

The following list is the recommended guideline, point by point:

1. [[spell:1279599]]
2. [[spell:1279603]] or [[spell:1279604]]
3. [[spell:1287555]]
4. [[spell:1279609]]
5. [[spell:1279615]] and [[spell:1279614]] offer similar output

:::details FAQWhich Secondary Stat Rune is Best?
The default choice for Warlocks is

[[spell:1279609]]

. If you
have somehow managed to hit >35% Critical Strike chance and neglected Mastery
in the process, consider using

[[spell:1279612]]

.

:::

3.

### Apex Talent: ![Embers of Nihilam Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_shadowflame_missile.jpg>) Embers of Nihilam

Available during the leveling in Midnight, these talents are separated from
the rest of the spec tree and require subsequent points investment in order
to unlock the later ranks.

1. [[spell:1265770]]
2. [[spell:1265772]]
3. [[spell:1265774]]

These talents mostly provide background power and do not affect the
rotation in itself broadly speaking, as any optimisation is overlapping with
existing practices already.

4.

### Hero Talents

Available at level 71 Hero talents are mutually exclusive trees you can
choose to slightly alter gameplay and visuals. Destruction Warlocks can choose
between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist is themed around Demons and the cycle of Overlord,
Mother of Chaos and Pit Lord summoned with [[spell:470479]]. The
gameplay as a result is of predictable cadence with a higher degree of burst
potential, tied with the Hero Tree summons and spell empowerments.

In terms of utility [[spell:428911]] gives snare and root
immunity on [[spell:48020]] on top of 50% movement speed but
on the other hand [[spell:429072]] coupled
with [[spell:1270255]] enables 25s cooldown [[spell:5484]]
that can affect up to 10 targets.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller is themed around Shadowflame damage and harder
hitting DoTs. [[spell:445465]] replaces [[spell:348]] and can generate a
second Shadowflame DoT effect in [[spell:440043]]. The Hero tree offers
a more methodical approach to shard expenditure with [[spell:430014]]
bolstering burst windows every minute.

In terms of utility [[spell:440057]] offers a debuff that is
relevant on both melee and caster enemies without the need to choose and is
particularly potent with [[spell:1265813]].

5.

### PvP Talents (War Mode)

Under our Talents section, there is the option to enter "War Mode."
Enabling War Mode provides the following benefits:

- PvP talents enabled in the outdoor world
- 10% increase in World Quest rewards at maximum level
- 10% more experience gained while leveling
- Earn Conquest Points, which can reward gear every week

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended you enable the feature. In most situations, this will allow for
the maximum returns despite the risks. You will make yourself available for
open-world PvP and the possibility to be "ganked" while leveling or doing
World Quests exists.

5.1.

#### Best War Mode Talents

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of both General PvP Talents
and Destruction Warlock-specific PvE talents.

1. [[spell:353753]] allows to burst targets by dragging them away from
     the marked location.
2. [[spell:248855]] increases your gateway's range by 20 yards and
     reduces the duration of the debuff placed on players using it by 15
     seconds, making it a good choice when increased mobility is needed.
3. [[spell:212295]] summons a shield lasting 3 seconds and reflecting
     back all harmful spells targeted at you.
4. [[spell:201996]] is only relevant when dealing with a lot of
     casting mobs.

1. [[spell:200586]] causes [[spell:116858]] to create a 5 yard
     Felfire pool under the target, reducing movement speed by 50% and
     reducing healing received on all enemies by 25%. This talent seems
     great in all situations, but particularly when you are dealing with
     multiple enemies at once.
2. [[spell:200546]] causes [[spell:80240]] to become a ground-targeted
     spell. Everything inside will be treated as it was debuffed
     by [[spell:80240]].

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **11 Aug. 2026:** Updated Talent choices.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Added Omnium Folio for Patch 12.0.7.
- **22 Apr. 2026:** Updated single target talents.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated talent trees and added Apex section for Midnight release.
- **10 Feb. 2026:** Updated talent trees for the changes to each gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **19 Mar. 2025:** Updated single target setup.
- **06 Mar. 2025:** Updated dungeon talents reccomendations.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **30 Oct. 2024:** Updated Single Target talent after hotfix.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **25 Sep. 2024:** Added a Shadowburn variant to Diabolist build.
- **09 Sep. 2024:** Updated talents recommendation for Season 1.
- **26 Aug. 2024:** Added a Delve talents reccomendation.
- **21 Aug. 2024:** Updated recommendations to feature Hero Trees.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Talents updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7
- **10 Jul. 2023:** Updated talents for Patch 10.1.5.
- **01 May 2023:** Updated talents for Patch 10.1.
- **20 Mar. 2023:** Updated talents for Patch 10.0.7.
- **24 Jan. 2023:** Updated talent selection for single target and 2 targets for Patch 10.0.5.
- **24 Dec. 2022:** Updated talent selection for single target.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Destruction Warlock in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Destruction Warlock Gameplay and Rotation Guide

Welcome to our Rotation page for Destruction Warlocks. On this page, you will
find everything you need to know about actually playing the spec in Raiding
and Mythic+ scenarios.

By selecting talents and Hero Talents below, the rotations in this guide will
update accordingly.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist

Single Target

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

Active Talents

Passive Talents

[[spell:1122]]

[[spell:152108]]

[[spell:17877]]

[[spell:196447]]

[[spell:6353]]

[[spell:80240]]

[[spell:1245633]]

[[spell:1244310]]

[[spell:1244877]]

[[spell:1244928]]

[[spell:387108]]

### Single Target

1.1.

#### Single Target Priority

The Destruction specialization revolves primarily around generating Soul Shards via your filler spells before unleashing them for a large burst of damage. This specialization does not follow a strict and consistent rotation; rather, the emphasis is on leveraging opportunities as they arise.

1. **适用条件：Diabolist（启用）。** Maintain [[spell:348]] at all times.
2. **适用条件：Hellcaller（启用）。** Maintain [[spell:445465]] at all times.
3. **适用条件：Summon Infernal（启用）。** Cast [[spell:1122]].
4. **适用条件：Hellcaller（启用）。** Cast [[spell:430014]].
5. **适用条件：Shadowburn（启用）。** Cast [[spell:17877]] whenever available.
6. **适用条件：Soul Fire（启用）。** Cast [[spell:6353]] when available if below 4 shards.
7. Cast [[spell:116858]] if you are about to cap Soul Shards.
8. **适用条件：Cataclysm（启用）；Lake of Fire（启用）。** Cast [[spell:152108]] on cooldown
9. **适用条件：Diabolist（启用）。** Cast [[spell:433891]] if below 4 Shards.
10. **适用条件：Channel Demonfire（启用）。** Cast [[spell:196447]] whenever available.
11. Cast [[spell:17962]] if you have 2 charges, possibly to hasten a long cast such as [[spell:116858]].
12. Cast [[spell:17962]] to generate Soul Shards.
13. Cast [[spell:29722]] to generate Soul Shards.

### AoE

1.2.

#### Multiple Targets Priority

Destruction can thrive in environments with steady cleave, as we do it efficiently. In many cases, the presence of secondary targets actually enhances our single-target output considerably, thanks to the additional resources generated.

1. **适用条件：Diabolist（启用）。** Maintain [[spell:348]] on the main target.
2. **适用条件：Hellcaller（启用）。** Maintain [[spell:445465]] on as many targets as possible.
3. **适用条件：Summon Infernal（启用）。** Cast [[spell:1122]].
4. **适用条件：Hellcaller（启用）。** Cast [[spell:430014]] with as many targets affected by [[spell:445465]] as possible.
5. **适用条件：Roaring Blaze（未启用）；Hellcaller（未启用）。** Apply [[spell:348]] on any secondary target that will last a minimum of 10 seconds.
6. **适用条件：Roaring Blaze（启用）。** Use [[spell:17962]] on the main target to spread [[spell:348]] on secondary targets.
7. **适用条件：Roaring Blaze（启用）；Hellcaller（启用）。** Use [[spell:17962]] on the main target to spread [[spell:445465]] on secondary targets.
8. **适用条件：Cataclysm（启用）。** Cast [[spell:152108]] on cooldown unless it can be delayed a few seconds to hit additional targets.
9. **适用条件：Hellcaller（启用）；Shadowburn（启用）。** Cast [[spell:17877]] when available during [[spell:430014]].
10. **适用条件：Diabolist（启用）。** Use [[spell:116858]] or [[spell:17877]] if available to trigger [[spell:470479]]
11. **适用条件：Hellcaller（启用）。** Cast [[spell:5740]] if there are 4+ targets.
12. **适用条件：Shadowburn（启用）。** Cast [[spell:17877]] whenever available.
13. **适用条件：Diabolist（启用）。** Cast [[spell:5740]] if there are 3+ targets.
14. **适用条件：Soul Fire（启用）。** Cast [[spell:6353]] when available if below 4 shards.
15. Cast [[spell:116858]] if you have 5 Soul Shards.
16. **适用条件：Diabolist（启用）。** Cast [[spell:433891]] if below 3 Shards.
17. **适用条件：Cataclysm（启用）。** Cast [[spell:152108]].
18. **适用条件：Havoc（启用）。** Apply [[spell:80240]] if a secondary target is present.
19. **适用条件：Channel Demonfire（启用）。** Cast [[spell:196447]] when available.
20. Cast [[spell:17962]] to generate Soul Shards and [[spell:196406]] stacks.
21. Cast [[spell:29722]] to generate Soul Shards.

### Opening Sequence

**适用条件：Soul Fire（启用）。**

[[spell:6353]]

**适用条件：Soul Fire（未启用）。**

[[spell:29722]]

**适用条件：Diabolist（启用）；Soul Fire（未启用）；Lake of Fire（未启用）。**

[[spell:348]]

**适用条件：Lake of Fire（启用）；Soul Fire（未启用）。**

[[spell:152108]]

**适用条件：Hellcaller（启用）；Lake of Fire（未启用）；Soul Fire（未启用）。**

[[spell:445465]]

[[spell:17962]]

**适用条件：Lake of Fire（启用）；Soul Fire（启用）。**

[[spell:152108]]

**适用条件：Summon Infernal（启用）。**

[[spell:1122]]

[[item:250215]]

[[item:241288]]

**适用条件：Hellcaller（启用）。**

[[spell:430014]]

[[spell:116858]]

[[spell:17962]]

1.3.

#### Opening Sequence

1. **适用条件：Soul Fire（启用）。** Pre-cast [[spell:6353]].
2. **适用条件：Soul Fire（未启用）。** Pre-cast [[spell:29722]].
3. **适用条件：Diabolist（启用）；Soul Fire（未启用）；Lake of Fire（未启用）。** Pre-cast [[spell:348]].
4. **适用条件：Lake of Fire（启用）；Soul Fire（未启用）。** Pre-cast [[spell:152108]]
5. **适用条件：Hellcaller（启用）；Lake of Fire（未启用）；Soul Fire（未启用）。** Cast [[spell:445465]].
6. Cast [[spell:17962]].
7. **适用条件：Lake of Fire（启用）；Soul Fire（启用）。** Cast [[spell:152108]]
8. **适用条件：Summon Infernal（启用）。** Cast [[spell:1122]].
9. Use your trinkets and racials.
10. **适用条件：Hellcaller（启用）。** cast [[spell:430014]].
11. Cast [[spell:116858]].
12. Cast [[spell:17962]].

:::details TipsDo Not Underestimate Curses!
With the introduction of

[[spell:1265813]]

Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:440057]] is unique to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and combines
  	the above two curses
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

:::

2.

### Midnight Season 2 Tier Set

Season 2 tier set bonuses are the following:

- [[spell:1296571]] increases the damage
      of [[spell:29722]] and double the chance to
      trigger [[spell:1265770]].
- [[spell:1296572]] adds a damage amplification
      effect on target affected by [[spell:1265770]].

Both set bonuses are not particularly strong and designed to offer a
passive damage increase that do not alter the priorities or the decision
making in the gameplay.

3.

### Class and Spec Mechanics Explained

The following sections present an explanation of various mechanics
        pertinent to the Destruction and the Warlock, alongside reasons as
        to why abilities are used in a specific way.

### Pandemic Mechanic

3.1.

#### Pandemic and Learning to Efficiently Refresh DoTs

Pandemic is a hidden mechanic that allows you to refresh certain timed
    effects early without penalty. You can refresh your DoT effects when they have
    less than 30% of their maximum duration. This will add the new DoT's
    maximum duration with the remaining duration of the current DoT.

In the case of [[spell:348]] the baseline value for a safe refresh
    is 5.4 seconds, and 6.3 seconds when
    talenting [[spell:388832]].

### Havoc

3.2.

#### Havoc Usage

[[spell:80240]] is one of your most important spells. Havoc copies any
    of your direct spells, however, and it does affect the Soul Shard
    generation of your Soul Shard generating abilities (i.e., you generate
    double Soul Shards). The Soul Shard-consuming abilities still cost the
    same amount, however, and only 60% of the total damage done will be
    copied.

It is best to use [[spell:80240]] to duplicate spells that are limited
    by Soul Shards is due to the efficiency of expenditure. If possible, try
    to lead into your [[spell:80240]]s with several Soul Shards at the ready.
    Follow up by dumping [[spell:116858]] casts and double your Shard efficiency.

[[spell:80240]] range is 60 yards after you apply the debuff on a target
    and is unaffected by line of sight requirements. Over time, you will
    develop the knowledge and instinct to take full advantage of the ability.

A good way to go about building this experience is by paying close
    attention to your boss's timers. If you know that an enemy will be spawning
    in the next 10 seconds, you should hold on to your Soul Shards
    and [[spell:17962]] charges for Havoc.

If you have 4 Soul Shards ready, you can immediately cast Havoc as soon
    as the add spawns. Cast [[spell:348]], then Conflagrate, dump 2
    [[spell:116858]]s, Conflagrate again to generate a Soul Shard. When in
    doubt, however, use Havoc on cooldown when a second target is
    present.

Remember to cast [[spell:80240]] on the secondary target since it will
    only duplicate single-target spells at a percentage of their original value.

Note that [[spell:387506]] applies the [[spell:80240]] effect at a
    reduced duration (6 seconds currently).

### Apex Talent

3.3.

#### Embers of Nihilam

The idea behind Destruction's Apex talent [[spell:1265770]] is to provide a
spell damage proc that does not necessarily influence the rotation itself but
is instead happening in the background.

- Rank 1 adds a small chance on [[spell:29722]] hit,
- Rank 2 and 3, on paper, offer extra Critical Strike and Haste for a
          brief duration after each proc,
- And Rank 4 guarantees a weaker proc every time a Shard Spender
          ability is used.

For Ranks 2 and 3, their only form of guaranteed trigger is tied to shard
consumption, which makes high buff uptime a difficult task. However,
multi-target situations are an exception.

4.

### Important Cooldowns for Destruction Warlock

### Infernal

4.1.

#### Infernal

Destruction's main cooldown, [[spell:1122]], offers a rather
    straightforwards use. The Infernal stuns and damage enemies in the area at
    the time of summoning. For the whole duration it will deal both melee and
    pulsing AoE damage, as well as passively generating Shards. It is generally
    best used on cooldown, due to a relatively high uptime, especially if
    running ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist with [[spell:429581]]. [[spell:1122]]
    may not look particularly strong on its own, especially in single target, but
    the ability to empower spenders with [[spell:417234]] or shard
    generation with [[spell:266086]] make the cooldown deceptively
    strong.

### Cataclysm

4.2.

#### Cataclysm

In its current iteration and tuning [[spell:152108]] should be seen
    as a mean to apply the maximum amount of [[spell:348]] on the target
    area in a single cast, rather than a tool for AoE burst. It pairs
    especially well with [[spell:196447]] and together aid
    substantially [[spell:445465]] management in multi-target
    for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller.

While it should be used more or less on cooldown in multi-target,
    (and potentially delayed by few seconds if able to hit a higher number of
    targets), in single target its relatively weaker spell power coefficient
    makes it a spell to use to seldom refresh [[spell:348]]
    or [[spell:445465]] when they are about to expire.

With the current tuning [[spell:152108]] is not a DPS gain in pure
    single target.

5.

### Destruction Warlock Important Notes

### Soul Shards

5.1.

#### Soul Shard Generation and Consumption

You start every fight with 3 Soul Shards/30 Soul Shard Fragments. During
    combat, Soul Shards are generated through the use of your core abilities.

- [[spell:1280868]] generates 3 Soul Shard Fragments on
          cast.
- [[spell:17962]] generates 5 Soul Shard Fragments on
          cast.
- [[spell:348]] generates 1 Soul Shard Fragment on normal ticks
          and has a 50% chance for an additional 1 Soul Shard Fragment on
          critical ticks.
- [[spell:6353]] generates 10 Soul Shard Fragments on cast.
- [[spell:17877]] (if talented) returns its Soul Shard cost if
          the target dies within 5 seconds.
- [[spell:29722]] generates 2 Soul Shard Fragments on normal
          casts and an additional 1 Soul Shard Fragment on critical hits.
- [[spell:196408]] generates 1 Soul Shard Fragment on
          critical hits only when talenting [[spell:387173]].

Soul Shards will mostly be consumed with the following abilities.

- [[spell:17877]] consumes 1 Soul Shard/10 Soul Shard
          Fragments
- [[spell:116858]] consumes 2 Soul Shards/20 Soul Shard
          Fragments.
- [[spell:5740]] consumes 3 Soul Shards/30 Soul Shard
          Fragments.
- [[spell:688]], [[spell:697]], [[spell:712]],
          and [[spell:691]] consume 1 Soul Shard/10 Soul Shard
          Fragments per cast.

### Chaos Bolt

5.2.

#### Chaos Bolt

[[spell:116858]] costs 2 Soul Shards/20 Soul Shard Fragments to cast.
    Since we can only have a maximum of 5 Soul Shards/50 Fragments, this means
    that the maximum number of [[spell:116858]]s we will be able to reliably
    cast in a short window of time
    is [[spell:116858]] → [[spell:17962]] → [[spell:116858]] →
    [[spell:17962]] → [[spell:116858]]. For these reasons,
    casting [[spell:116858]] during beneficial procs is less of a priority
    now, as we cannot fit anywhere near the same amount of casts into a small
    window of time.

### Shadowburn

5.3.

#### Shadowburn

[[spell:17877]] returns in Midnight as an execute ability with few
    nuances, some tied to particular talent choices or target count.

By default the spell has a refund Shard mechanic if target dies during
    the debuff that is being applied, and the debuff is what trigger the
    refund so it is limited to 1 shard per target. [[spell:80240]] can trigger
    a second refund, however.

[[spell:387108]] benefit [[spell:17877]] immensely, as
    the buff provided is generally long enough to
    cover [[spell:1245633]] procs and naturally last during execute
    phase, resulting on average in above 95% of the casts being Critical Hits
    with damage increased correspondingly.

The following list details the target count where [[spell:17877]]
    should be prioritised over other spenders. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist:

- Up to 7 targets with just [[spell:387108]] with or
          without [[spell:1244928]]
- Up to 4 targets without [[spell:387108]]
          talented
- With [[spell:1244928]] but
          no [[spell:387108]], [[spell:17877]] should never be
          casted in multi-target.

[[spell:1245633]] increases the aforementioned target count by 1
    each.

As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller:

- Up to 4 targets with [[spell:387108]] talented, and
          up to 6 with [[spell:1245633]]
- Without [[spell:387108]], [[spell:17877]] should
          be casted exclusively with [[spell:1245633]] at up to 4
          targets

### Demon Choice

5.4.

#### Pet Choice

After 9.2 changes, Sayaad (Succubus or Incubus) has a clear advantage in
    terms of single target damage assuming no frequent distant target swap.
    However, pet choice is often dictated by the unique utility provided by each
    one: for defensive dispel, and if there are frequent swaps between distant
    targets, Imp will provide the highest uptime.

Use Felhunter whenever an interrupt or a purge effect is required.
    Voidwalker can offer some additional AoE is due to its torment ability, but
    its biggest utility comes from a taunt.

Succubus offers additional crowd control and permanent slow on a single
    target, which may be useful under certain situations.

### Movement

5.5.

#### Movement Management

While it is difficult to describe the best ways to position and move
    during a dungeon or raid encounter, it is essential to your success as a
    Destruction Warlock. [[spell:111771]] can be highly effective in
    many encounters and is under-appreciated by many players and raid groups.

Think of [[spell:111771]] as a raid cooldown that can instantly teleport
    your entire raid group 40 yards, and the potential this ability holds
    quickly becomes clear. Ask your group if they want [[spell:111771]]
    anywhere specific; if not used for your strategy, use it instead as a
    personal cooldown.

[[spell:17962]] can be used strategically to cover movement, as
    can [[spell:80240]]. [[spell:17877]] can also be a good choice on fights
    with high amounts of movement if targets are frequently dying, as you
    gain 2 charges of a new, instant-cast ability for you to leverage.

You can mitigate the need to move by positioning in locations
    central to fight movement. For instance, if a boss is being kited
    in a circle, you should stay on the inside of the kite path to ensure
    minimal movement. You should also determine how your [[spell:268358]]
    can make a fight easier for you. There are many boss mechanics that
    can be trivialized with a clever portal, which can free you up to deal
    a lot more damage.

[[spell:385899]] used in conjunction with [[spell:111771]]
    offers a quick way to cover large distances and can be used in a rush
    when the need to reposition is immediate.

5.5.1.

##### Quiet Movement

Many players will unconsciously move during fights, despite it being
    unnecessary. For example, sometimes the boss or adds will be moved by the
    tank a couple of yards, and though you are still in range to cast, you
    subconsciously mirror that movement, costing you global cooldowns.

Consciously work to "quiet" your movement, and reduce unnecessary
    movement to a minimum. The best way to see this in action is to take a
    video of your raid and then watch yourself play. Most players will be
    surprised by the amount of wasted movement they commit. When you are
    forced to move, make your path as direct and decisive as possible.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **31 Aug. 2026:** Updated AoE rotation section.
- **12 Aug. 2026:** Updated Shadowburn cutoffs.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **23 Mar. 2026:** Updated Spender section with new cutoffs.
- **17 Mar. 2026:** Expanded the Tier Set bonuses section.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated Rotations and added Apex sections for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **09 Sep. 2025:** Updated multitarget logic.
- **22 Aug. 2025:** Updated Soul Fire lines.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added a section for Combat Assistant.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **25 Sep. 2024:** Re-done page layout, updating sections accordingly.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Added Hero Talent sections and selectors.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Added Madness section.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated selectors for the openers and priority lists.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Destruction Warlock in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Destruction Warlock

Welcome to our Gearing Page for Destruction Warlock; this
section will cover everything you need to know about equipping your character
correctly.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Destruction Warlock. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces to Aim for?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

was changed to retain the base stats, and item level of the original item, which allows to acquire tier set bonuses while following a specific stat distribution. Listed below are the ideal items to catalyse, but be aware

**Chest and Legs**

are direct drops.

- Head: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:239031@JAACAAAG2A]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:271549@JAACAAgNyA]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Hands: [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: [[item:271545@JAACAAgNyA]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

Prioritise acquiring the tier set bonuses over ideal stat distribution since it is a higher DPS increase.

:::

:::details FAQWhat Items From the Great Vault Should I Pick?
Rare drops from raid and items that present the highest upgrade in

[Top Gear](<https://www.raidbots.com/simbot/topgear>)

sims should be prioritised. Listed below are few of the items to chase:

- [[item:271092]]: Best caster weapon due to item level alone
- [[item:271874@JAACAAAG2A]] and [[item:268265@JAACAAAG2A]], high item level items with strong cantrip effects
- [[item:270164@JAACAAgNyA]] is the best trinket this tier

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup from all sources for Destruction Warlock. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces to Aim for?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

was changed to retain the base stats, and item level of the original item, which allows to acquire tier set bonuses while following a specific stat distribution. Listed below are the ideal items to catalyse, but be aware

**Chest and Legs**

are direct drops.

- Head: [[item:251199@JAACAAgNyA]] from [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- Shoulders: [[item:239031@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Chest: [[item:273785@JAACAAgNyA]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Hands: [[item:159247@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Legs: [[item:251160@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

Prioritise acquiring the tier set bonuses over ideal stat distribution since it is a higher DPS increase.

:::

:::details TipsWhich Dungeons Should Be Prioritised?
If your playtime is limited consider the following dungeons to farm:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): weapon and trinket
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>):nNeck, belt, and second trinket
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): trinket and off-set pieces

:::

:::details FAQIs There a Difference Between 2H Staves and 1H + Off Hand?
As long as the item level is the same, there is no difference between both, in terms of total amount of stats.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:251199@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:251137@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup from all sources for Destruction Warlock. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

In some non-Tier slots, a max ilvl Craft will technically be optimal since you can customize the secondary stats to your liking. Your mileage here may vary.

:::details FAQWhich Tier Set Pieces to Aim for?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

was changed to retain the base stats, and item level of the original item, which allows to acquire tier set bonuses while following a specific stat distribution. Listed below are the ideal items to catalyse, but be aware

**Chest and Legs**

are direct drops.

- Head: [[item:271874@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:268241]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- Chest: [[item:271549@JAACAAgNyA]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Hands: [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs: [[item:271545@JAACAAgNyA]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

Prioritise acquiring the tier set bonuses over ideal stat distribution since it is a higher DPS increase.

:::

:::details TipsWhat Are the Most Important Drops from the Raid?
Listed below are the most significant drops worth prioritising.

- [[item:271092@JAACAAAG2A]]: Highest item level weapon. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:271874@JAACAAAG2A]]: Highest item level with good stats on a slot with a high stat budget. This drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:270164@JAACAAgNyA]]: Best trinket alternative from raid. Drops from [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270170@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/destruction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Destruction Warlock

The following list provides a general ranking for all trinkets available
for players to better understand what may be more appealing. These rankings
assume each item at its highest possible item level, thus for direct or
immediate upgrade it is still best practice to sim your own character.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Destruction Warlock Trinkets**
**Best-In-Slot -**

[[item:250215@JAACAAgNyA]]

and

[[item:281215@JAACAAgNyA]]

**Runner Up Passive-**

[[item:270164@JAACAAgNyA]]

or

[[item:250224@JAACAAgNyA]]

**Runner Up Active-**

[[item:270170@JAACAAgNyA]]

or

[[item:270168@JAACAAAG2A]]

:::

Any trinket not shown on this list is generally considered worse than all
other trinkets available on this list.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Destruction Warlock Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;<li>[[item:273649@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169@JAACAAAG2A]]</li>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:158368@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) work as bonus loot and guarantee a drop
	from the loot table of a Boss or a Dungeon. While the drop in itself is
	random, each additional Voidcore spent will guarantee no duplicate until
	the whole list has been dropped.

3.1.

#### Recommended Nebulous Voidcore Usage for Destruction Warlock

Nebulous Voidcores are a valuable yet limited resource and whilst in
general should be used to bridge gaps in a player current gearset, it is
important to remember that how quickly an item can be guaranteed depends on
how many other items have been already dropped from that source.

Not all drops are equally impactful, so listed below is a generic priority
list on what to focus on:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore Targeting Priority**
1. Mythic-track [[item:271092@JAACAAAG2A]]
2. Mythic-track [[item:271874@JAACAAAG2A]]
3. Mythic-track weapons (1H or 2H);
4. Mythic-track trinkets (especially [[item:270164@JAACAAgNyA]]);
5. Tier set pieces missing from 2 or 4-piece bonus;
6. High-impact slots from your BiS list.

:::

3.2.

#### Ascendant Venomstones

[[item:280562]] return as a mean to upgrade your equipment in
Season 2. Listed below is the order of importance of equipment slots to
upgrade:

1. Mainhand Weapon is the most important
2. Offhand weapon
3. On-use trinket
4. Passive trinket
5. Neck item.

[[item:280562]] can also be used to upgrade bonus rolled
Heroic cantrip items from last 2 bosses to 340 item level.

4.

### Best Crafted Items for Destruction Warlock

Crafting gear main limiting factor remains the weekly rollout of Sparks,
necessary for high end items, as such it is important to understand how to
approach the topic.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Destruction Warlock Crafted Gear Priority**
1. The overall best combination is [[item:240167]] in the
     	Wrists slot and [[item:273059]] in the off-hand frill,
     	but that is in the context of fully geared characters, and thus should
     	be considered a long term strategy, better suited for players who do not
     	require the highest power gain immediately, but instead opt for the
     	least amount of recrafts and resource investment.
2. If immediate power is instead the focus, then crafting
     	a [[item:245770@JAAGAAwt1ENMMYD]]
     	with [[item:273060]] using 4 Sparks and Wrists
     	with [[item:240167]] at a lower item level provide the
     	highest dps jump.

:::

The missives used for each craft are the following:

- [[item:245786]] for Weapon and Wrists
- [[item:245783]] for any other slot

:::details FAQWhy Are We Crafting a Weapon First If It Is Not Best-In-Slot?
Weapons provide the highest amount of primary stat, and especially the
first tier it is a very precious commodity. However crafted items cap 4 item
levels below fully Mythic upgraded alternatives, thus being somewhat limited
at the top end, assuming a player get access to that kind of gear.

:::

:::details FAQIs It Worth Recrafting for a Different Missive?
If the associated recrafting cost is not an issue, consider simming your
own character at any given point to get the best Missive at the moment. Changing secondary
stats on a single item is unlikely to provide more than a tenth of a percent of DPS increase.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Adding Sockets to Gear

In Season 2 [[item:275707]] is available as a
trading option at six tokens from Great Vault, which can be used to add a
sockets to any Head, Waist, or Wrist item.

5.

### Crest Usage

Mistcrests are a seasonal limited currency with a cap that increases each
week and is used to upgrade items to their respective maximum level in each
reward track.

Due to how each item slot is designed, there is a difference in power, tied
to either specific effects or simply higher stats. As a result the following
sequence highlights the most valuable slots where to invest Mistcrests:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Destruction Warlock Crest Upgrade Priority**
**Weapon**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Neck**

➜

**Off-hand**

➜

**Shoulders/Gloves/Belt/Boots**

➜

**Rings**

➜

**Wrists/Back**

:::

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **31 Aug. 2026:** Updated trinket list.
- **16 Aug. 2026:** Updated BiS lists, embellishment and trinkets to account for a new profile and trinket tuning.
- **11 Aug. 2026:** Updated Gems and FAQ sections.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **22 Apr. 2026:** Updated BiS list to account for different talents.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **17 Mar. 2026:** Updated Trinket ranking to account for Gaze nerf.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **24 Jun. 2025:** Updated DISC socket recommendation following tuning.
- **15 Jun. 2025:** Updated for Patch 11.1.7 and DISC.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **04 Apr. 2025:** Updated trinket recommendations.
- **04 Mar. 2025:** Updated BiS lists and trinket ranking.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7. and Cyrce's Circlet.
- **30 Oct. 2024:** Updated BiS list after hotfixes.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Added BiS lists for Season 1, updated trinket section.
- **21 Aug. 2024:** Added Pre-Season BiS list section.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4 launch.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated trinket section for Patch 10.2.5.
- **07 Nov. 2023:** Embellishment recommendations updated after Undulating Sporecloak has been annihilated.
- **06 Nov. 2023:** Updated Gear recommendations for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Reformat of the page with BiS tables and section updates.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **24 Mar. 2023:** Updated Onyx Annulet section to account for live hotfixes.
- **20 Mar. 2023:** Added Patch 10.0.7 new ring section. .
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Dec. 2022:** Updated Embellishment recommendations.
- **11 Dec. 2022:** Updated for Season 1 launch.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Destruction Warlock. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Destruction Warlock Stat Priority

The stat priority for a Destruction Warlock is as follows:

Item Level

Haste to 22%

Critical Strike

Mastery

Haste

Versatility

It is worth noting that our secondary stats are relatively close to
each other in value, so prioritizing item-level is generally considered the best approach,
especially as you approach hitting diminishing returns on the stat value you gain. A
more balanced stat distribution is preferable to stacking the two best stats to the point
where they diminish in value.

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. You should look for this stat in all
of your upgrades. It provides you with Spell Power, which increases the damage
of your spells.

**Haste** influences the cast speed of your spells. The tick rate
of [[spell:348]] is also increased, and the cooldown of
[[spell:17962]] is decreased. This contributes to significantly
higher Soul Shard generation at higher levels of Haste. Your demons also
scale with Haste.

**Critical Strike** increases your chance to critically hit with all
spells and abilities. [[spell:116858]] always critically hits, and its
damage is increased by your Critical Strike at a rate of 1% damage per 1%
Critical Strike. [[spell:348]] criticals have a doubled chance to produce
a Soul Shard. Your demons also scale with Critical Strike.

**Mastery**, through [[spell:77220]] increases your
damage dealt by a random amount within the specificed range. This does not
affect pet damage.

**Versatility** is a flat-out damage done increase and damage taken
reduction. Your demons also scale with Versatility.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Destruction Warlock, based on your [stat priority](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

Socketable gems are divided in two categories: Epic and Rare. The former
offer a powerful effect but is limited to 1 equipped, whereas the latter
includes single or two secondaries stats combination gems.

Gems can be applied to a Helm, Bracer, or Belt via the
[[item:275707]] item from the Great Vault.

The Dazzling Diamond Epic gems of choice
are [[item:240983]]
or [[item:240967]]. The former is better until Mythic track
gear, at which point the latter performs better.

In terms of itemization, opting for Critical Strike gems yields the best
result, due how strong that secondary stat is for Warlocks in general. [[item:240898]]
is your best gem to pair with the [[item:240983]], while it is very
important to activate the full benefit of the [[item:240967]] by
equipping 4 different-coloured rare gems.

The four rare gems you should be looking to equip are:

- Peridots: [[item:240890]]
- Lapis: [[item:240914]]
- Amethysts: [[item:240900]]
- Garnets: [[item:240906]]

<em>It is highly recommended using [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) to sim your
character's ideal gems and enchants, as they might differ from general
recommendations.</em>

**Make sure to enable the checkboxes with "Always use" and "Only 4+
Colors" in the options.**

2.

### Best Enchants and Weapon Augments

Use [[item:243733]] as your weapon oil in all content.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243973]]</li>&#10;<li>[[item:244031]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Secondary stat weapon enchants may provide better value
 than [[item:244029]], but which one is best for you
 heavily depends on the rest of your gear. As such, depending on your current stat
 distribution, you may want to [sim yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>),
 as your best secondary stat enchant may differ from the one listed above.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

For Season 2, [[item:241326]] is the default
choice.

[[item:241322]] gains a lot of value though when
using the [[item:250215]] trinket 
and [[item:244031]], so make sure to adjust your consumables.

3.2.

#### Potions

[[item:241288]] should be the first choice if your gearset
has little to no Versatility, otherwise use [[item:241308]].

[[item:271883]] is the healing potion of choice.

3.3.

#### Food

[[item:242275]] and [[item:255846]] are the recommended food to
consume. You can simply buy whichever is the cheapest, or eat from a feast when it is
provided for the group.

Hearty version of food should be considered in situations where
wiping/dying is rather frequent, as those persists through death.

3.4.

#### Augment Rune

[[item:259085]] provide around 1% dps increase and
should be evaluated during progress, especially when close to pivotal
kills.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **16 Aug. 2026:** Updated consumables to reflect new BiS lists.
- **11 Aug. 2026:** Updated Gems.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Updated Tea section.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **22 Aug. 2025:** Updated weapon enchants.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **12 Sep. 2024:** Updated weapon enchants and oils.
- **09 Sep. 2024:** Updated gems section, as the strategy changed.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated Phial recommendation after Corrupted Rage buff.
- **24 Mar. 2023:** Updated Primordial Stones recommendations to account for the additional live hotfixes.
- **22 Mar. 2023:** Updated Primordial Stones recommendations to account for 25% buff hotfix.
- **20 Mar. 2023:** Added Primordial Stones section for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **07 Jan. 2023:** Updated dungeon phial to a more reliable Phial of Tepid Versatility.
- **14 Dec. 2022:** Updated Weapon Runes.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Destruction Warlock in World of Warcraft Patch 12.1.5.

1.

### Destruction Warlock in Mythic+ in Midnight Season 2

Mythic+ has become a large part of the World of Warcraft endgame, but the 
  sheer number of different variables has left many players feeling overwhelmed.
The group composition, weekly affixes, the item level of the group, the
keystone level and the experience and comfort level of the group are just
several of the factors that will influence how you approach each dungeon. The
purpose of this page is to prepare you for the key differences that set
Mythic+ apart from the typical World of Warcraft endgame experience, including
talents and rotational anomalies that may not be obvious at first glance.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

[Destruction Warlock](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-guide>)s offer some of the highest on-demand bursts and 2 target
cleave potential across all DPS while having strong and short enough
cooldowns that can be used frequently on each pull. The spec still retains
all the class baseline toolkits comprised Healthstones, Soulstones, Curses,
skip-enabling [[spell:111771]], AoE crowd control abilities such as
[[spell:30283]] and [[spell:5484]].

2.

### Best Mythic+ Talent Builds

### Best Mythic+ Talents

2.1.

#### Mythic+ Talents for Destruction Warlock

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) Diabolist setup offers higher damage with cleave and
uses [[spell:205184]] as a main source to manage [[spell:348]] on
multiple targets. A greater emphasis is put on the [[spell:17877]]
package, as the spell offers a great potential to leverage high damage
through clever sniping of dying targets, in order to trigger shard
refunds.

Because of its faster burst, it is generally better suited for weekly keys
where fights do not last that long.

To import the build directly ingame, click on the export button at the
bottom of the calculator

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzysNzYmFzYZZMAAYGjZmZBMmxwCMw2wCNWYAAgxMMsBgZGgxMjZ2AAAMzMzAAYMM"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPfhiklnoELM028MTjehprTwwJbM-lZaswSYEJ1FYYo0wBi6DowQxhrrNPxj-AAAA-AOQo0QowITgwwC-
```

:::

### Hellcaller Variant

2.2.

#### Hellcaller Mythic+ Talents for Destruction Warlock

This variant opts for the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller tree in order to gain more
single-target damage at the expense of AoE. Due to how
important [[spell:445465]] uptime is, [[spell:205184]] is again at the
center of the build, with the option to swap 2 points in [[spell:387384]] to
get [[spell:152108]] and [[spell:1244877]] if you end up pulling more
than 7 mobs consistently.

In high keys ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller shines, since the environment regularly
sees higher-target pulls and longer fights, allowing [[spell:440043]]
to stack higher, and more [[spell:5740]] that can deal their full
damage.

To import the build directly ingame, click on the export button at the
bottom of the calculator

:::talents 天赋构筑
```json
{
  "code": "CsQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWmtZmZmFzYZZMAAYGjZmZxCMwsY0YGAzG2YAAgxghNAgZGMmZY2AAAMzMzAAYMM"
}
```
:::

:::details 来源计算器编码
```
#LE-ITUUVVDHPSfiklnoELM028MTjchprTwwJbM-lZaswSYEJ1FYYo0wBi6DowQxhrrNxjE-AAAA-JQSU2AIQYgxBzC-
```

:::

3.

### Mythic+ Flexible Talents for Destruction Warlock

### Utility / Defensive Talent Swaps

3.1.

#### Utility / Defensive Flexible Talents

In regards to AoE stops [[spell:30283]] and [[spell:5484]] are
often interchangeable, and should be evaluated in situations where stun or
fear immunity targets are present and if faster cooldowns are more
important.

[[spell:710]] is a much more niche tool to take out an Aberration, Demon
or Elemental target from the fight for up to 30 seconds. It does not work on
bosses and in boss encounter most of the time major mechanics often present
targets immune to the spell.

[[spell:268358]] and [[spell:111771]] can be considered
repositioning tools, with the latter generally allowing specific route skips
and the former used personally to handle mechanics that would force otherwise
prolonged movements.

For [[spell:108416]] supporting talents, [[spell:386664]] reduces
the Health Loss and is mostly used in situation where staying above a certain
Health threshold is preferable, but in general is less applicable than its
alternative [[spell:386686]] which offers a faster cooldown and thus
more opportunities to mitigate damage.

Inversely, for [[spell:104773]] opting for [[spell:317138]]
makes the damage mitigation more substantial and is generally preferred as
the base cooldown is long enough that a reduction with [[spell:386659]]
should be only considered if a specific fight requires double mitigation in
less than 3 minutes.

### Damage Talents Swaps

3.2.

#### DPS Flexible Talents

Both setups are optimized for the highest overall damage output while still providing
potent priority target damage and burst. That being said, [[spell:387506]] can be swapped
for [[spell:80240]] if it is more desirable to hit a priority target more often
compare to having more frequent but shorter duplication windows.

Two points in [[spell:387384]] can be moved from [[spell:152108]]
and [[spell:1244877]] to gain more single target damage.

[[spell:6353]] and [[spell:1245089]] can be swapped for 2/2
Devastation to get some more AoE and the expense of major single-target
drop.

4.

### In-Depth Rotation Tips for Mythic+

While both single and multi-target rotations do not differ substantially
from the standard priority outlined in [Rotation, Cooldowns, and Abilities page](<https://www.icy-veins.com/wow/destruction-warlock-pve-dps-rotation-cooldowns-abilities>) there
are few points worth noting:

- While [[spell:5740]] is generally strong in terms of numbers, targets
  moving out of the radius due to kiting or repositioning can affect the
  overall efficacy of the spell. In situations where it would be hard to
  leverage heavy [[spell:5740]] usage, consider cleaving
  with [[spell:80240]] [[spell:116858]]s instead.
- Destruction's toolkit is exceptional at bursting targets and funneling
  priority damage due to the insane shard generation multiple [[spell:348]]s
  can provide, so keep that in mind during weeks when it is more important to
  focus on key targets over even AoE.

5.

### Utility Kit and Abilities

While damage is the bigger reason to bring a Destruction Warlock, the class
itself offers a noticeable amount of crowd control and various supporting
abilities:

- Recently reintroduced, the Curses can offer some advantages against specific
   dangerous enemies: [[spell:1714]] can reduce the group's interrupt
   requirements. At the same time, [[spell:702]] alleviates the incoming
   damage on the tank from auto attacks. Last but not least,
   [[spell:334275]] can slow targets when kiting is required.
- [[item:5512]]s have a 1-minute cooldown and heal for 25% of max
   health, allowing for an emergency heal for each player.
- [[spell:20707]]s offer a combat resurrection that you can use reactively
   and preemptively in the case of a death run.
- [[spell:111771]] offers the unique ability to skip certain parts of
   the map, depending on the dungeon in question, avoiding specific pulls.
- [[spell:30283]] helps alleviate pressure on the tank during big pulls as
   it is a 3-second AoE stun.
- [[spell:5484]] in its current iteration is especially strong as a
   short cooldown aoe interrupt when talenting
   into [[spell:1270255]].
- [[spell:5782]] and [[spell:710]] are both spammable crowd control abilities
   that can interrupt a cast in a pinch or temporarily remove a target from combat.

:::details TipsDo Not Underestimate Curses!
With the introduction of

[[spell:1265813]]

Curses are now easier than ever
to utilise in most pulls and situations, and knowing which one to use in what
scenario can alleviate pressure on the group.

- [[spell:1714]] reduces cast speed and work on any ability that
  	can be interrupted
- [[spell:702]] delays the time between melee attacks and
  	should be used when pulls are mostly comprised of melee mobs
- [[spell:440057]] is unique to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) Hellcaller and combines
  	the above two curses
- [[spell:334275]] is a movement speed slow, helpful for kiting
  	but otherwise more situational

:::

:::details FAQHow To Best Use Blights?
Blights are much stronger version of Curses, at the expense of being tied to
a 2 minutes cooldown and lasting only 12 seconds. As such they should be
treated as a defensive cooldown for the party, in order to alleviate any
incoming damage, if applicable. Each Blight follows the same rules as their
correspective Curse:

- [[spell:1271748]] works on any attacks, reducing the frequency
  	and critical strike chance
- [[spell:1271802]] works on any cast that can be interrupted

:::

6.

### Dealing with Affixes

### Affix: Ascendant

6.1.

#### Ascendant Affix Management for Destruction Warlock

About every minute, Xal'atath will show up and summon a total of 10 Orbs of
Ascendance with a cast that needs to be interrupted. Any crowd-control or
interrupt spell will work:

- [[spell:30283]];
- [[spell:5484]] (capped to 10);
- [[spell:5782]];
- [[spell:6789]];
- Pet interrupts.

### Affix: Voidbound

6.2.

#### Voidbound Affix Management for Destruction Warlock

While in combat, Xal'atath summons a Void Emissary to empower nearby
enemies, which becomes the priority target and is best focused down.

### Affix: Pulsar

6.3.

#### Pulsar Affix Management for Destruction Warlock

While in combat, Xal'atath manifests pulsar orbs that tether and orbit
around players for 15 seconds. There is no particular suggestion for this
mechanic centered around just soaking those orbs, although the movement
reduction can be offset by [[spell:111400]].

### Affix: Devour

6.4.

#### Devour Affix Management for Destruction Warlock

Periodically, Xal'atath will cast a shield debuff on all 5 players, which
can either be removed by healing done or by dispelling. Healing abilities
such as [[spell:6789]] and [[item:5512]] can help removing the
shields if no other means to dispel them are available.

- [[spell:688]] [[spell:89808]] can dispel a single shield.

7.

### Pet Choice for Destruction Warlock

The Felhunter is typically the best choice, as it grants you an interrupt,
which is a huge advantage in Mythic+; consider swapping to Imp if you need additional
dispel.

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated talent trees for the changes to each gate unlock.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **19 Sep. 2024:** Updated for Patch 11.0.5 and added a dungeon tooltip section.
- **09 Sep. 2024:** Updated talent selection for Season 1 launch.
- **19 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated Talents for Patch 10.2.5.
- **03 Jan. 2024:** Updated Talents and Stats.
- **06 Nov. 2023:** Updated for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Restructured Talent section.
- **10 Jul. 2023:** Talents updated for Patch 10.1.5.
- **01 May 2023:** Talents updated for Patch 10.1.
- **20 Mar. 2023:** Talents updated for Patch 10.0.7.
- **24 Jan. 2023:** Added an Inferno section, and updated the talent recommendation.
- **11 Dec. 2022:** Updated recommended build.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Destruction Warlock in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Below are examples of useful macros; you can adapt them for whatever spell you deem fit.

1.1.

#### Pet Macros

These macros allow you to manage your demon, as playing with your Pet Stance
on Assist is the preferred way to play.

#### Pet Attack

```wow-macro
/petattack
```

This orders your demon to attack your target.

#### Pet Follow

```wow-macro
/petfollow
```

This orders your demon to follow you.

#### Pet Move

```wow-macro
/petmoveto
```

This orders your demon to move to a location specified by you. This macro
is especially useful for situations where you need your pet in a predetermined
position in order to accomplish a given task — such as an interrupt on a
otherwise out of range target — but can also be used to maximize Felguard
cleave/[[spell:89751]] damage, just be aware that any imparted commands will
also make your Dreadstalkers, Vilefiend (if talented) and Tyrant move,
resulting in a much bigger loss when used improperly.

1.1.1.

##### DoT Mouseover

#### Corruption Mouseover

```wow-macro
#showtooltip Corruption
/use [@mouseover,harm] [harm] Corruption
```

Casts [[spell:172]] on current mouseover target if hostile and alive,
else cast it on your current target.

Worth mentioning that Blizzard has added the ability to toggle all casts to
follow a mouseover logic in the control settings, however some abilities may
not function correctly, and thus it is still recommended to take the time and
make a macro for any ability with a mouseover use case.

1.1.2.

##### Banish Focus

#### Banish Focus

```wow-macro
#showtooltip Banish
/use [mod:shift,@focus] [] Banish
```

Cast [[spell:710]] on focus target by holding also shift, else cast
it on your current target.

1.1.3.

##### Soulstone Mouseover

#### Soulstone Mouseover

```wow-macro
#showtooltip Soulstone
/target [@mouseover] Soulstone
/use Soulstone
/targetlasttarget
```

Workaround macro for the current bug related to mouseover dead allies. The
Macro itself will target the mouseover in order to cast [[spell:20707]]
then target the previous target.

1.1.4.

##### Demonic Circle

#### Demonic Circle

```wow-macro
#showtooltip
/stopcasting
/use [mod:shift] Demonic Circle(Summon); [nomod] Demonic Circle: Teleport(Teleport)
```

Place the Demonic Circle while holding shift, or teleport to the circle
without any modifiers, while cancelling any ongoing casts. This saves you the
trouble (and the time!) of interrupting your spell cast manually.

1.1.5.

##### Shadowfury/Howl of Terror

#### Shadowfury/Howl of Terror

```wow-macro
#showtooltip
/use [known:Shadowfury,@cursor] Shadowfury; [known:Howl of Terror] Howl of Terror
```

Depending on the talent selected cast [[spell:30283]] at cursor
or [[spell:5484]] instead.

1.2.

#### Havoc

#### Havoc

```wow-macro
#showtooltip
/cast [@mouseover,harm] Havoc; [harm] Havoc
```

This macro casts [[spell:80240]] on your mouseover target if you have any,
otherwise it casts it on your target (provided it is an enemy). Mouseover
macros are not recommended for this ability, as it can easily lead to applying
Havoc to the wrong target. Only use this if mouseovers are your
preference.

1.3.

#### Cursor Rain of Fire

#### Cursor Rain of Fire

```wow-macro
#showtooltip
/cast [@cursor] Rain of Fire
```

Some people might find this macro very useful. It places the
[[spell:5740]] where your cursor is, instead of having to constantly place
the green circle where you want it. It can be a much quicker way to put
[[spell:5740]] down.

1.4.

#### Cursor Cataclysm

#### Cursor Cataclysm

```wow-macro
#showtooltip
/cast [@cursor] Cataclysm
```

Similar to the above macro, this one cast [[spell:152108]] at cursor
bypassing the reticle and the need to click twice.

1.5.

#### Shadowburn

#### Shadowburn

```wow-macro
#showtooltip
/cast [known:Shadowburn,@mouseover,harm] Shadowburn;
[known:Shadowburn,harm] Shadowburn
```

This is a mouseover macro for [[spell:17877]] as it helps sniping dying targets
from nameplates quicker than targeting them individually. If no targets are
available on mouse location it will cast on your current target instead.

2.

### Best Addons

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.1.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.2.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.2.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.2.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.2.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.3.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.3.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
