## 专精概览

Welcome to our Assassination Rogue guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as an Assassination Rogue in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Assassination Mythic+ Resources

[NEW! Top Assassination Talent Builds](<https://raider.io/specs/assassination-rogue/talents>)

[Top Assassination Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/rogue/assassination>)

[Assassination Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=rogue--assassination>)

[Popular Assassination Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=rogue--assassination>)

1.

### Assassination Rogue Overview

Assassination Rogue deals damage through the application and
empowerment of poison and bleed effects. The damage toolkit of Assassination is somewhat
limited, mainly focusing on dealing single-target damage and spreading DoT effects on
multiple enemies while sporting a very strong 2-minute cooldown burst.

As with the other Rogue specializations, Assassination offers
phenomenal defensive and crowd-control abilities that allow them to soak and
survive mechanics that most other classes cannot, while controlling enemies to
limit the amount of damage the group or tank can take in a Mythic+ environment.

Good Damage Profile and Tuning

Assassination Rogue sports a very useful damage profile, with a powerful 2-minute cooldown
that is particularly potent on single-target. It also has access to powerful Execute damage
thanks to [[spell:381798]]. With some slight buffs early into Season 2, the
spec's damage is certainly competitive.

Serviceable Damage, Nigh Immortal

Assassination Rogue is a decent pick for any raid environment,
thanks to its potent 2-minute cooldown and execute damage, as well as having incredible
survivability. It is one of the best specs to put on the boss while other classes deal with
waves of adds or targets that need to be bursted down very quickly, which is one of the
only weaknesses Assassination has in this type of content.

Its unique raid buff, [[spell:381637]]
is a useful tool to mitigate damage on many raid bosses, although it sadly does not
work on all boss mechanics.

Incredible Prio Damage, But Slow~ish Ramp

Assassination can be played very comfortably in Mythic+, having solid AoE damage
when talented for it, at the cost of some single-target DPS output on bosses. This
shortcoming can be more than made up for by pulling trash on top of bosses, as Assassination
has phenomenal priority-target damage, often called funnel-damage.

It also has numerous utility spells at its disposal, allowing you to disrupt
and control enemies like few other specs can. [[spell:6770]], [[spell:2094]],
[[spell:1776]], and [[spell:200733]] are all situationally useful, and it is one
of two classes in the game that has access to a group stealth ability in [[spell:114018]].

Great in Mythic+, Terrible in Raid

Assassination has access to many different utility spells, like [[spell:381637]],
[[spell:114018]], [[spell:6770]], [[spell:2094]], [[spell:1776]] or
[[spell:200733]]. With the exception of Atrophic Poison, none of these find
application in raid environments. Even with Atrophic not working on all raid boss
abilities, most groups still bring at least one Rogue of any spec to supply it.

In a Mythic+ dungeon, a Rogue who knows how to use all the tricks of their trade can help make
any run feel a lot easier and safer though, and while these benefits may not show on a DPS
meter, many tanks and healer will be thankful if you use your utility to the fullest extent.
The return of [[spell:200733]] for AoE-[[spell:2094]] is a great boon to our kit
as well, as it not only disrupts enemies, but also reduces their damage done with [[spell:379005]].

Incredibly Durable

Rogues are the kings of staying alive, especially in raid environments. Thanks to
[[spell:31230]], [[spell:1966]], [[spell:31224]], [[spell:5277]], and [[spell:185311]],
you will typically be one of the last few people standing, allowing you to clutch
out boss or trash kills even when things go wrong.

Having [[spell:5277]] ready when a tank dies and you can safely tank
a trash pack or even raid boss for another 10 seconds can be incredibly useful, and while
Rogues tends to struggle with high sustained damage over time, you have numerous tools at
your disposal to stay alive until the very end.

The only real struggle is with sustained damage-over-time in high Mythic+, but by
talenting into [[spell:79008]] you can survive even the highest level of
keys reliably as well.

Very Quick To Move Around

Assassination has solid mobility, having access to a low-cooldown [[spell:2983]]
that makes you run as fast as a mounted character, as well as being able to use
[[spell:36554]] to quickly get out of harms way, or connect with an enemy that is
far away from you.

Being able to jump to both friendly and hostile targets offers
good flexibility, and can even allow you to avoid certain mechanics from hitting you
entirely. The only downside of Rogue's mobility is the fairly low range limit
of Shadowstep.

2.

### Assassination Rogue in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 offers no meaningful changes to Rogue or Assassination as a spec.
The main focus of the patch are 2 new pieces of endgame content instead, one for Raid groups, and one
for [Delves](<https://www.icy-veins.com/wow/delves-guide>). Make sure to check out both the information on the new Kith'ix Raid encounter,
as well as the new exciting Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) acts as an escalation to the progression of Season 2 in
Midnight, with the story surrounding Ula'tek and the Amani culminating in a new one-boss
raid, access to ascended item levels, multiple sources of catch up gear,
and access to an infinite number of Mistcrests to upgrade it. Make sure to check out our
patch hub for all the information on what is new, or has been updated with Patch 12.1.5.

2.3.

#### Class Changes

There have been no changes for Assassination Rogue with Patch 12.1.5, other
than a few small cosmetic updates to some spell animations.

As a result, there are no changes to our
[Talent](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>) recommendations or
[rotational](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>) priorities. However, with the
new gear, our [gear](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>) page has been updated
with information on the new items and how to best use your [[item:280562]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_deathmark.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class TuningHide Patch 12.1 Class Tuning
[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Assassination Rogue**

<em>Developers’ notes: We’re making some updates to Assassination’s Energy economy
    in Curse of Ula’tek. We aren’t happy with how the Rank 1 Implacable apex talent
    is playing – it’s unintuitive for optimal play to intentionally let Envenom drop.
    We’re updating its design so refreshing Envenom late is consistently the best way
    to play and giving it consistent Energy recovery value. We’re also making some
    changes aimed at increasing talent build options.</em>

- **Class**
  
  
  - [[spell:381623]] is now a choice talent – Players may now choose between the
            existing version, which casts automatically at low Energy in addition to being
            usable actively, and a new version that must be cast actively.
  - Atrophic Poison now reduces damage dealt by 4% (was 3%).
  - Atrophic Poison duration increased to 60 seconds (was 10 seconds).
            Duration remains unchanged in PvP combat.

- **Hero Talents**
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound: Deal Fate now has a 60% chance to grant an extra
            combo point when you Seal Fate (was 100%).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker: Fixed an issue that caused Unshakable Drive's bonus
            to multiply with each stack.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker: Fixed an issue that often caused Unshakable Drive
            to remove more than one stack per ability use.

- **Assassination**
  
  
  - New Talent: [[spell:1298812]] – Envenom damage increased by 18%, but
            its duration is reduced by 2 seconds.
  - Apex Talent: [[spell:1265385]] (Rank 1) has been updated – Envenom damage
            increased by 10%. Envenom now restores 2 Energy per combo point spent.
  - Apex Talent: [[spell:1265387]] (Rank 3) – Implacable Strike damage increased
            by 15%.
  - [[spell:381627]] has been updated – Now triggers from casting
            Kidney Shot and Rupture, rather than also being applied when copying Ruptures
            with Crimson Tempest. Damage increased by 10%.
  - [[spell:196861]] has been updated – Garrotes applied from stealth or
            during the Improved Garrote window now silence the target for 5 seconds.
            Damage reduction behavior unchanged.
  - [[spell:381797]] has been updated – Envenom's effect now also
            increases the critical strike chance of your weapon poisons by 10% (was 5%).
            Your Energy generation is increased by 4% for each lethal poison on your weapons.
  - All damage dealt increased by 20%.
  - [[spell:360194]] increases the damage of your Rupture, Garrote, and
            Lethal Poisons by 75% (was 100%).
  - [[spell:385627]] damage reduced by 15%.
  - [[spell:385478]] increases Garrote damage by 30% (was 20%).
  - [[spell:1250358]] increases Rupture damage by 25% (was 20%).
  - [[spell:1247993]] Energy increased to 30% (was 20%).
  - [[spell:455072]] damage bonus increased to 20%/40% (was 15%/30%).
  - [[spell:79134]] generates more Energy when multiple targets
            are affected by your bleeds.
  - [[spell:328085]]'s chance to trigger reduced to 10% (was 15%), and
            20% when the target is at low health (was 30%).
  - [[spell:255544]]'s visual has been adjusted to make other important
            visuals on top of it easier to see.
  - [[spell:382238]] and [[spell:382245]] now work correctly with
            the strikes dealt by [[spell:1265387]] (Rank 3).
  - Several talents have changed positions in the talent tree.
  - [[spell:1250271]] has been removed.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Changes Overview

For the Midnight Launch, the game has changed dramatically, both for the Spec itself as well as changes to the Rogue
class in general. Many of these changes have already been applied with the
Pre-Patch prior to the expansion's launch, but we have listed the entire set of changes
here for returning players, and to ensure you know exactly what awaits you when you explore
Midnight on your Assassination Rogue.

The main goal behind many of the changes is to strengthen the
identity of the two Hero Talent trees, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound,
changing rotational gameplay flow by making Energy a more impactful resource again,
and changing the AoE rotation to more closely resemble our single-target rotation.

As a result of these changes, a lot of skills have been pruned or re-designed, and we
have outlined the most impactful changes below, highlighting how they affect your regular
gameplay compared to the version of Assassination that you might already be used to. Fret not,
however, as the rotational gameplay loop is still very similar to the one that Assassination
has relied on for years, so even if you are returning to the game with Midnight after a longer break,
you will not feel lost!

2.5.

#### Hero Talent Changes

[[spell:457052]] will be easier to apply as it is no longer tied to Ambush,
removing the requirement of having to be in **[[spell:1784]]**. However, it is harder to switch marks, as you can
no longer [[spell:1856]] and [[spell:8676]] to apply it to a target of your choosing. The only
way to swap marks is by waiting for a [[spell:457058]] proc and swapping the mark
to a different target. You will also be able to trigger Darkest Night at 5+ Combo Points,
instead of needing to use a maximum Combo Point Envenom, which will make the
rotation a bit more forgiving to play, but in most scenarios you will want to still use
it at maximum CP.

Fatebound is finally able to compete in AoE, thanks to [[spell:454429]]
drastically boosting [[spell:421975]]. Rolling Fatebound Coins is also more
consistent now, and no longer requires [[spell:1856]] or the now-removed [[spell:382245]] to
consistently hit the capstone buff. This improves the usability of Fatebound
in all cases, giving it a more reliable benefit to our damage profile, while
still retaining its core identity of flipping coins.

2.6.

#### Rotational Aspects

By far the biggest change to our rotation is a renewed heavy emphasis on chaining
[[spell:32645]]. There are numerous talents that received large buffs to
encourage creating long chains of casting Envenom right before it expires, and
our Apex Talent [[spell:1265385]] further emphasizes this identity as well.
Some of the most impactful talents supporting this playstyle are:

- **[[spell:1250036]]**  
  
    A new choice-node talent at the bottom of the tree, that boosts all of our
    class-damage when chaining Envenoms.
- **[[spell:1250318]]**  
  
    The alternative talent to Inspiring Strike, which grants 1 Combo Point instead
    when chaining properly.
- **[[spell:455072]]**  
  
    This talent was massively buffed to grant 30% increased Envenom damage when
    chaining.

2.7.

#### Apex Talent: Implacable

[[spell:1265385]] is our Apex Talent in Midnight, and it covers some of the weaknesses
of Assassination by providing a surge of Energy whenever your Envenom chain runs out. This
means you will not be spending seconds without any buttons to press anymore once you run out
of Energy, and between [[spell:381623]] and [[spell:1265385]], you can get back to
using your abilities quite fast.

The other benefits, [[spell:1265386]] and [[spell:1265387]] are largely just additional
DPS gains on top of the initial benefit, and generating CP automatically after using [[spell:385627]]
is a welcome bonus too.

2.8.

#### Energy Generation

Our Energy generation has been changed quite dramatically as well. Unlike
the previous The War Within iteration of the spec, you will receive much less
Energy from [[spell:79134]], and instead generate more Energy
passively. This change also heavily lowers our Energy generation in AoE,
leading to less overcapping, and highlighting the importance of the moment-to-moment
decision-making when it comes to the abilities you spend your resources on.

2.9.

#### Cooldown Adjustments

[[spell:5938]] no longer grants any bonus damage, and all talents that boosted
either its direct damage, or made it apply bonus damage effects to enemies, have
been removed. It now serves as a utility ability for its Soothe, while no longer
being part of our DPS rotation whatsoever.

[[spell:360194]] no longer duplicates bleeds, instead making them deal
more damage, and the Energy loss from that is off-set by it generating Energy by itself.

[[spell:385627]] is more accessible and will likely be a required pick
for any build as our 1-minute cooldown.

2.10.

#### AoE DPS

Our rotational gameplay in AoE has been simplified a lot, with both our single-target
and AoE rotation now being very similar to one another. The main reason for
this is the new design of [[spell:1247227]], which combines the effects of
[[spell:51723]] and [[spell:381802]] by being a CP builder that also
spreads bleeds. It costs more Energy than FoK and deals less damage, so you will have
to decide which of these abilities you will be using in AoE as your main builders at any given time.

[[spell:421975]] has also been changed to no longer require active
bleeds or poisons to be applied, and triggers off of casting Envenom and Kingsbane.
No more having to use Mutilate or Ambush in AoE!

3.

### Basics of Assassination Rogue Gameplay

Assassination Rogue is a spec that utilizes a Combo Point system and spreads
its damage over time effects to generate additional resources while maintaining
a couple of high-impact buffs and debuffs to deal sustained DPS. A large portion
of its damage will be dealt every 2 minutes by using different cooldowns
simultaneously.

Generating additional resources is a core component of the Spec, so making sure to
maintaining both [[spell:703]] and [[spell:1943]] at all times is of vital
importance due to [[spell:79134]]. Combo Points are generated by using
either [[spell:1329]] on single-target or [[spell:51723]]/[[spell:1247227]] on AoE.
Excess Combo Points that are not used on Rupture can be spent on
[[spell:32645]] to deal instant damage and to increase the passive damage your
poisons provide. [[spell:385627]] offers burst every 60 seconds, while [[spell:360194]]
is our 2-minute cooldown, and synchronizing the two can deal some incredible
burst DPS. Broken down, these three concepts will briefly describe what you can expect 
from Assassination Rogue.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_speedoflight.jpg>) **Manage Your Resources**  
  
    One of the most important aspects of Rogue gameplay is to watch your Energy and Combo Point
    resources. You want to avoid overcapping either of them, so use them with care. Some abilities
    have a random range of CP they can generate, such as [[spell:1329]] due to [[spell:14190]].
    This will naturally lead to you occasionally overcapping CP, but keeping these to a minimum
    is key to playing Assassination well. Energy should never overcap, and you will spend a lot
    of time guaranteeing a consistent Energy income beyond your passive Energy regeneration.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_rupture.jpg>) **We Need More Dots**  
  
    You have two main bleed damage-over-time abilities, [[spell:1943]] and [[spell:703]], and your uptime
    on these should be 100%. If an enemy doesn't have the effect yet, you will always be well
    served by applying them. You can do this by either casting them directly, or in AoE
    environments you can let [[spell:1247227]] do the dirty work, which will
    spread existing bleeds to nearby enemies. You generate additional Energy through
    [[spell:79134]], and each bleed effect means even more Energy, which is a key
    part of keeping your Energy flowing at high rates.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_disembowel.jpg>) **Be Toxic (or Venomous)**  
  
    A big part of Assassinations gameplay revolves around [[spell:32645]], and keeping as much uptime
    on the buff as possible by spending any excess Combo Points on it. You will want to chain Envenoms as much as you can, meaning you
    re-apply it right before the original duration expired. You will not be able to maintain
    100% uptime on the buff, but maximizing your uptime on this buff will always lead to more DPS.

4.

### How to Gear Up as a Assassination Rogue

While we always recommend simming yourself for ideal results, we do provide a
dedicated Assassination gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **25 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated trinket rankings.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Season 2 launch and the most recent gear nerfs and changes.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **26 May 2026 (this page):** Updated for May 26th class changes.
- **24 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated Ring Enchant.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **31 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated Trinket recommendations.
- **31 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated Opener for Garrote Snapshot.
- **31 Mar. 2026 (this page):** Updated with Bug for Garrote Snapshot.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Updated for Midnight.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Midnight.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Updated for Midnight.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Midnight.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Updated for Midnight.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Midnight.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Updated for Midnight.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for Midnight.
- **26 Feb. 2026 (this page):** Updated for Midnight.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page updated for Pre-Patch.
- **10 Feb. 2026 (this page):** Page updated for Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page was reviewed for Patch 11.2.7 and no changes were required.
- **30 Nov. 2025 (this page):** Page updated for Patch 11.2.7, listing all major content updates.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated info for Patch 11.2.5, added Puzzling Cartel Chip section, removed DISC Belt section.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **05 Oct. 2025 (this page):** Page updated for Patch 11.2.5 and Legion Remix.
- **04 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.2.5 and no changes were required.
- **06 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page updated with minor simplified rotation changes.
- **06 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page updated to be written with Tier-Set in mind.
- **03 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Clarified Fatebound Shiv usage.
- **18 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Clarified Deathstalker AoE rotation if Kingsbane is not talented.
- **16 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Added clarification for Fatebound Crit requirements.
- **13 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Added info for Netherprism.
- **13 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Adjusted pre-11.2 Tier Talent recommendations.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Page was reviewed for Patch 11.2 and no changes were required.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2 and TWW Season 3. Added all new BiS lists. Removed information regarding Cyrce's Circlet and the Puzzling Cartel Chips. Added information for Reshii Wraps.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.2 and no changes were required.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Removed Corruption section, and reviewed information for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.2 and no changes were required.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page updated for Patch 11.2 and Season 3, with weekly and high key build recommendations.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page updated for Patch 11.2 with detailed information on Fatebound and Deathstalker tier-set impacts.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Pages updated for Patch 11.2, added tags for Talent recommendations with and without the new Tier set.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.2 and no changes were required.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for Patch 11.2, added Tier-Set disclaimer.
- **04 Aug. 2025 (this page):** Updated information for Patch 11.2.
- **21 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** DISC recommendations updated for June 20th Hotfix.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Added information for DISC belt for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Added information for Combat Assist feature.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.1.7 and no changes were required.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Added information for Combat Assist feature.
- **15 Jun. 2025 (this page):** Added information for Patch 11.1.7.
- **20 May 2025 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated Horrific Vision Enchant section to recommend Echoing Void.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.5, added Puzzling Cartel Chip suggestions.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Added information for Horrific Visions enchants, reviewed page for 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Switched to Bleed Build for Mythic+ and reviewed page for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Switched to Bleed Build for Mythic+ and reviewed page for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 11.1.5 and no changes were required.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Switched to Bleed Build for Mythic+ and reviewed page for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Added information for Patch 11.1.5.
- **25 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated some gear recommendations for trinket tuning from March 25th.
- **25 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Updated some talent recommendations for class changes from March 25th.
- **25 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated rotational priorities for class changes from March 25th.
- **25 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated some talent recommendations for class changes from March 25th.
- **25 Mar. 2025 (this page):** Updated for class changes from March 25th.
- **17 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Updated with additional tips, Gallywix info, and Mythic tips for a few bosses.
- **13 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Mechano Core and Junkmaestro trinkets.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page has been reviewed and updated for TWW Patch 11.1.
- **24 Feb. 2025 (this page):** Page has been reviewed and updated for TWW Patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **25 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated Cyrce's Circlet gem recommendations.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Cyrce's Circlet buffs.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Cyrce's Circlet information added for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page has been reviewed for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for The War Within Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Page reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** Added a variety of tips for Mythic and regular difficulty.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated Talent builds for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for the gameplay changes in Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated Talent builds for The War Within Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Reviewed and updated for The War Within Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for The War Within Patch 11.0.5.
- **21 Oct. 2024 (this page):** Added class changes for Patch 11.0.5.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for TWW Season 1 with BiS Gear and Embellishments.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated for the start of Season 1 of The War Within.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Season 1, removed pre-season build.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **24 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Added Delve Talent Build.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/assassination-rogue-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/assassination-rogue-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/assassination-rogue-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Page has been reviewed and updated for Dragonflight Season 4. Added Bullion and Trinket sections.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page has been reviewed and updated for Dragonflight Season 4.
- **22 Apr. 2024 (this page):** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **21 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page has been reviewed and updated for Patch 10.2.6.
- **21 Mar. 2024 (this page):** Page has been reviewed and updated for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page has been reviewed and updated for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Page has been reviewed and updated for Patch 10.2.5.
- **14 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated with newly optimized Opener on single-target.
- **14 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated with newly optimized Assa single-target priority during Deathmark and Dance.
- **08 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Added disclaimer about talent build not being highest DPS option.
- **08 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Added DtB M+ build with Acro.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Sporecloak nerf.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page updated for the Patch 10.2 Rogue rework.
- **06 Nov. 2023 (this page):** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.7, added multiple BiS lists.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.7 with new formatting.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **04 Sep. 2023 (this page):** Added information for 10.1.7 and the recent 5% aura and melee buff.
- **16 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated Dawn of the Intinite section, Nick of Time BiS.
- **16 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Added AoE build talent-calc link.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Added Dawn of the Infinite section, removed Cataclysm Timewalking section, updated Annulet section for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated Onyx Annulet paragraph to no longer recommend farming it after 10.1.5 Annulet nerfs.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5, updated most recent changes to the class and guide.
- **06 Jun. 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated Embellishment recommendation.
- **06 Jun. 2023 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Added Belt Clasp and Lambent Armor Kit as alternative Leg Enchant. Added Corrupting Rage Phial discussion.
- **06 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated for Exsanguinate bug.
- **06 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated Sepsis gameplay information.
- **06 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated with Sepsis replacing Serrated Bone Spike, and removed Exsanguinate altogether.
- **06 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for Sepsis build, removed Exsanguinate while it is bugged.
- **06 Jun. 2023 (this page):** Updated for most recent buffs and new TC findings.
- **24 May 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Added Timewalking info.
- **14 May 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated trinket recommendations.
- **07 May 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated Embellishment recommendations for recent hotfixes.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Page fully updated for Patch 10.1. Added Flightstone and Crest information, added Season 2 BiS items and recommendations, BiS embellishments and more.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Page reviewed for Patch 10.1. Updated Onyx Annulet recommendations.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Patch 10.1 did not change the stat priority.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated tips and tricks for Patch 10.1 Affix changes.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** No rotational changes are required for Patch 10.1. Added Rotation Quick Guide.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1. The recommended build and talent tree remain the same, and the page required no updates.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** No changes were required to this page for 10.1, as no spell changes happened, besides numerical ones.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for Patch 10.1. Simplified rotational priorities.
- **01 May 2023 (this page):** Updated for Patch 10.1 release. Added sections for recent and pending updates to the guide.
- **29 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Patch 10.1 required no changes to this page.
- **26 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated Primordial Gem recommendations for latest hotfixes.
- **26 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Replaced Flying Daggers with Improved Poisons.
- **26 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated Mythic+ Talent build, added link to calculator.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/assassination-rogue-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7.
- **05 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated Stat prio and Raging Affix description.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight Patch 10.0.5 changes.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight Patch 10.0.5 changes.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Dragonflight Patch 10.0.5 changes.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Updated for Patch 10.0.5 changes.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for Dragonflight Patch 10.0.5 changes.
- **24 Jan. 2023 (this page):** Updated for Dragonflight Patch 10.0.5 changes.
- **04 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated Dungeon Gear list, added BiS List disclaimer and Raid trinkets.
- **04 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated Armor Kits, added Fortune Cookie food.
- **04 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Updated Stat prio, added disclaimer for Haste at lower gear levels.
- **04 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated talents and sample opener.
- **04 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated rotational priorities for DTB and Kingsbane builds.
- **04 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated Talent recommendations and descriptions according to newest sims.
- **04 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated talent build.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/assassination-rogue-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/assassination-rogue-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/assassination-rogue-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/assassination-rogue-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/assassination-rogue-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **02 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/assassination-rogue-patch-9-1-changes-analysis>)):** Added 9.1.5 changes.
- **28 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/assassination-rogue-patch-9-1-changes-analysis>)):** Page added.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **14 Nov. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-the-eternal-palace-raid-guide>)):** Removed disclaimer, updated talent and gameplay recommendations, added Mythic Zaqul section.
- **15 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for all bosses.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **08 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-crucible-of-storms-raid-guide>)):** Added further boss tips.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **23 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** Minor updates.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added Assassination Rogue advice for Battle of Dazar'alor.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **07 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-uldir-raid-guide>)):** Added boss spec-specific tips.
- **13 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-uldir-raid-guide>)):** Page added (placeholder for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Assassination Rogue leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Rogue leveling guide](<https://www.icy-veins.com/wow/rogue-leveling-guide>).

1.

### Assassination Rogue Leveling Guide for Midnight

Unfortunately, Rogue has often been cited as the single worst class to level
in World of Warcraft. Fret not, however, as it is still more than capable of
dealing with the leveling journey just fine, even if it will take you a
little longer than your friends who may have chosen a different class than you.
Once you hit max-level, you will surpass them in no time and be thankful you
spent the time to pick Rogue!

One of the biggest strengths of Rogue during leveling is its ability to simply
sneak past many nuisances. With clever use of [[spell:2094]], [[spell:1856]],
[[spell:6770]] and other CC abilities, you can often loot important quest items
and then simply Vanish to disappear without having to kill a single enemy.

Whenever your [[spell:5277]] is off cooldown, it is worth pulling many mobs
simultaneously and simply avoiding all damage they deal. [[spell:185311]] has
a low cooldown, so make sure to use it and the new [[spell:1231418]] spell to heal up
between pulls. Playing [[spell:3408]] will allow you to kite many enemies while they slowly
but surely die from your Damage over Time effects, allowing you to move on to
the next enemy.

As you level up, some of your abilities will be replaced with spec-specific
ones. For example at Level 22, [[spell:196819]] will be replaced with [[spell:32645]].
At other times, new abilities will join your rotational priority list. Some of
these you will learn automatically as you level, others you will talent into.
If you follow the Point-by-Level path of our Talent Calculator, this guide will
immediately tell you how to use these new abilities efficiently.

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level but two secondary stats on it
instead of one.

When using Heirloom items, we recommend using those with Critical Strike
and Haste, as they will slightly improve the gameplay flow while leveling.

1.2.

#### Useful Leveling Consumables for Midnight

With the full launch of [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), it will
once again be time for players to level up to the new maximum of 90. This means
that many will want to get as far along as possible, as fast as possible. To that
end, there are a number of <em>optional</em> consumables that can be gathered
to speed things along. There is no need to go overboard on hoarding too
many, as you will only need to level each character once.

To be as prepared as possible, look to acquire at least some of the following
items and enchants.

- [[item:191348]] — This is a tradeable consumable from the [Dragonflight](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  expansion that increases your speed stat for 30 minutes, which will also persist
  through death. Leveling is frequently about traveling quickly rather than defeating enemies any faster.
- [[item:225592]] — A food item from [The War Within](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>),
  this tradeable dish similarly grants a massive bonus to movement speed for an hour,
  but is lost on death.
- [[item:132516]] — One of the more unusual consumables, this tradeable item from
  Legion Engineering (thanks to [Engineering](<https://www.icy-veins.com/wow/professions-engineering>)) allows you to move faster than ground
  mount speed for a long duration and even enables movement over water, but breaks upon
  taking damage and cannot be activated while in combat. If in an area where you
  cannot mount, consider it your fastest movement tool.
- [[item:154168]]/[[item:154169]] — Though
  it is rare to need them, these two tradeable consumables from Battle for Azeroth can
  be paired together to grant you underwater breathing and greatly increased swim
  speed that is faster than an aquatic mount.
- [[item:109076]] — This consumable allows you to 
  travel through the air from great heights if you are unable to mount, and at great speeds. You
  can even consider pairing one with a [[item:122124]] or [[item:104299]]! Keep
  in mind that as a Rogue, you are taking much less fall damage than most other classes,
  and can avoid it entirely as long as you have something to [[spell:36554]] to before
  crashing to the ground.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you, that sets you up for your next 10 levels. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Assassination Level 80 Midnight Leveling
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmNDAAAAAAz2gtZAAAAAAZbmZGPwMDWmZmZZmtZmZMjZGMjZGjBYzsMwAAWGmADLGwAMDM"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmNDGAAAAAY2GsNDAAAAAIbzMzMzMDWmZmZZmtZmZMjZGMjZGjBYzsMwAWALDTghFDmZAmhxA"
}
```
:::

:::details 来源计算器编码
```
#DE-hFLGPYSBk+Oh8ymoGV+cFEaEG2FXX3GLrKC-XbCWEiJHbGwY8VBGEABV4MJJxpos07B-AAAA-GQAqcEYgQQDzSB-
```

:::

2.1.

#### War Mode Talents for Leveling

In this section, we will rank the PvP talents
best for leveling and doing solo / small group PvE content. Below is a ranking of both
General PvP Talents and Assassination Rogue-specific PvE talents.

1. [[spell:198145]] - Casting [[spell:32645]] with at least 5 Combo Points
   on a target afflicted by your [[spell:703]], [[spell:1943]], and lethal
   poison deals Nature damage and reduces their movement speed by 90% for 2 sec.
   While not incredibly useful, it is extra damage and can help with the enemies
   that are coded to run away. It is not worth casting Envenom with 5 CP at all times
   despite this talent requiring 5 CP to be triggered. Continue finishing at 4+
   while leveling.
2. [[spell:354895]] - Your [[spell:32645]] applies Creeping Venom,
   dealing Nature damage over 4 sec. The duration is refreshed when the target
   moves. This is another passive damage increase, which can also be easily maintained by
   side stepping, causing the enemies to move with you.
3. [[spell:354406]] - [[spell:408]] will restore Energy when used, generating more
   Energy than it costs. This makes it quite valuable to use, and while it's still technically
   better DPS to simply spend your CP on a damaging finisher, the added safety can be quite
   valuable for Rouge, who is one of the most vulnerable classes while leveling.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 3 起：**Cast [[spell:1784]] if you want to get to a
quest objective without fighting all enemies or before engaging enemies.

**等级 1–1：**Starting at Level 1, you only have one main
attack ability: [[spell:1752]].

1. Cast [[spell:196819]] once you have 4+ Combo
   Points to spend them.
2. Use [[spell:1752]] to build up Combo Points.

1. **等级 10–10：**Make sure you always have
   [[spell:315584]] and [[spell:3408]]
   applied. Sometimes, it can be beneficial to not use [[spell:3408]] if you
   do not want to slow the enemies you are fighting. Simply right-click on the buff
   icon, and it will be removed.
2. **等级 11–29：**Make sure you always have
   [[spell:2823]] and [[spell:3408]]
   applied. Sometimes, it can be beneficial to not use [[spell:3408]] if you
   do not want to slow the enemies you are fighting. Simply right-click on the buff
   icon, and it will be removed.
3. **等级 15 起：**Use [[spell:1247227]] to spread
   [[spell:703]] and [[spell:1943]] to all targets once you gain these abilities.
4. **等级 30 起：**Make sure you always have
   [[spell:2823]] and [[spell:5761]]
   applied.
5. **等级 35 起：**Use [[spell:360194]] on bosses or elite
   enemies.
6. **等级 53 起：**Use [[spell:385627]] on single or high-priority
   targets.
7. **等级 21 起：**Cast [[spell:703]] from stealth.
8. **等级 17 起：**Spend your Combo Points to maintain
   [[spell:1943]] on multiple targets.
9. **等级 10–21：**Cast [[spell:196819]] to spend excess
   Combo Points.
10. **等级 13 起：**Use [[spell:408]] to spend excess Combo
    Points against enemies you want to stun. Watch out for enemies that are immune
    to stuns.
11. **等级 22 起：**Use [[spell:32645]] to spend excess Combo
    Points on single-target.
12. **等级 10–11：**Use [[spell:1752]] unless you
    have 4+ Combo Points.
13. **等级 12 起：**Use [[spell:1329]] unless you have 4+
    Combo Points.
14. **等级 19 起：**Use [[spell:51723]] on AoE to build CP,
    or [[spell:1247227]] if you still have targets to spread bleeds to.

3.1.

#### Defensive Abilities

Assassination Rogues have a few tools at their disposal that make fighting
multiple enemies easier or that allow you to avoid debilitating effects.

- **等级 6 起：**[[spell:1766]] allows you to interrupt an enemy
  that is casting a spell. Use this frequently to avoid the damage you would
  otherwise be taking if the spell cast finishes.
- **等级 8 起：**[[spell:185311]] lets you heal 20% of your
  max Health over 4 seconds. Use this whenever you need the healing or when you are between
  pulls.
- **等级 11 起：**[[spell:6770]] lets you control any Humanoid,
  Beast, Demon, or Dragon for up to 60 seconds. Use this to keep a single enemy
  from joining the fight before you open on a group of enemies from stealth. This
  crowd control breaks when the enemy takes damage. Try to avoid hitting it with
  any of your abilities that hit multiple targets, or it will join the fight.
- **等级 13 起：**[[spell:408]] can be used to stun a
  single
  opponent for up to 6 seconds. Use this to interrupt a dangerous cast or
  simply
  not take damage from an enemy. Some NPCs might be immune to stuns.
- **等级 28 起：**[[spell:5277]] increases your chance to
  dodge incoming melee and ranged attacks by 100% for 10 seconds. Use this
  whenever it is available to you while you are fighting multiple enemies. You can
  only dodge enemy attacks when facing them.
- **等级 23 起：**[[spell:1856]] removes you from sight. This
  essentially resets all enemies you are in combat with. If you happen to be
  close to death and you do not feel that using any other defensive or offensive
  ability might let you finish off all the enemies you are engaged with, use
  **Vanish** to survive.
- **等级 48 起：**[[spell:2094]] allows you to control an enemy
  for up to 60 seconds. This can be used from stealth or outside of it. The
  crowd-control effect breaks when the target takes damage, so make sure not to
  hit it with any of your AoE abilities or use **Blind** when the enemy
  is afflicted with one of your damage over time effects.
- **等级 12 起：**[[spell:31224]] removes and makes you
  immune to magical effects for 5 seconds. This allows you to potentially remove
  damage over time effects that could break your [[spell:1784]], allow you to
  take less damage, or simply avoid certain crowd control or damaging effects.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Page was reviewed for Patch 11.2 and no changes were required.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for The War Within Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Assassination Rogue in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics for Assassination Rogue in Midnight

If you are new to the class or spec, it is best advised to start slow
with a straightforward build to get a better handle on the core
mechanics and interactions. This build is only slightly worse, albeit easier to play,
than the most optimal way to play the spec, so there is no need to worry at all
about potentially lacking behind fellow Rogue players while you get to know
the foundations of Assassination. Below are some of the core concepts behind the spec.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_paladin_speedoflight.jpg>) **Manage Your Resources**  
  
    One of the most important aspects of Rogue gameplay is to watch your Energy and Combo Point
    resources. You want to avoid overcapping either of them, so use them with care. Some abilities
    have a random range of CP they can generate, such as [[spell:1329]] due to [[spell:14190]].
    This will naturally lead to you occasionally overcapping CP, but keeping these to a minimum
    is key to playing Assassination well. Energy should never overcap, and you will spend a lot
    of time guaranteeing a consistent Energy income beyond your passive Energy regeneration.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_rupture.jpg>) **We Need More Dots**  
  
    You have two main bleed damage-over-time abilities, [[spell:1943]] and [[spell:703]], and your uptime
    on these should be 100%. If an enemy doesn't have the effect yet, you will always be well
    served by applying them. You can do this by either casting them directly, or in AoE
    environments you can let [[spell:1247227]] do the dirty work, which will
    spread existing bleeds to nearby enemies. You generate additional Energy through
    [[spell:79134]], and each bleed effect means even more Energy, which is a key
    part of keeping your Energy flowing at high rates.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_disembowel.jpg>) **Be Toxic (or Venomous)**  
  
    A big part of Assassinations gameplay revolves around [[spell:32645]], and keeping as much uptime
    on the buff as possible by spending any excess Combo Points on it. You will want to chain Envenoms as much as you can, meaning you
    re-apply it right before the original duration expired. You will not be able to maintain
    100% uptime on the buff, but maximizing your uptime on this buff will always lead to more DPS.

To summarize, Assassination primarily focuses on maintaining damage-over-time effects
for potent sustained damage and cleave. You will use generator abilities to build Combo
Points, and then spend them to apply DOTs and direct damaging finishers, with a big emphasis
on maintaining near permanent uptime on multiple buffs and debuffs. On this page
of our Assassination Guide we will be focusing on a setup that minimizes the number of buttons
and reactivity necessary, without unduly compromising overall damage output.

2.

### Beginner's Guide to Assassination Rogue in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound   Raid Talents

2.1.

#### Beginner Raid Talents for Assassination Rogue

This is our recommended build for all raid situations, playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound. While it does slightly less
single-target damage than the pure single-target build, it is a great blend of cleave, AoE,
and single-target damage. Unless you are facing a high-HP Elite or a pure single-target
fight in a raid, this build will serve you well. We've got pure single-target builds for those
rare occasions in our talents section!

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents Fatebound Raid Build
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPwYMzYMmZGjBYzsMwAWALDTghFDmZAGjB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AjxMjxYmZmxAYgFYGjGzGgtBsZAwMzgB"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGiCY4QaiS7D84pSooMPCLLMMuuuqrN-XbCEHTsCFNagq+ADCGw8MposwJKLrzD-AAAA-JQmUhpBIgwgxxC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound   Dungeon Talents

2.2.

#### Beginner Mythic+ Talents for Assassination Rogue

This is your go-to Mythic+ build, that plays Fatebound in order to maximize its overall
  AoE output while also dealing incredible priority-target damage. While it sacrifices
  some single-target for the higher AoE, this is a trade-off worth taking to truly
  assassinate whichever target you sight your sight on, while still doing great AoE damage
  to surrounding enemies.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents Fatebound Mythic+ Build
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAbmlBGwCYZYCMsYwMDwYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzMMA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGimCY4QaiS7D84pSooMPLLMMuuuqrN-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-JQkUhpBIgwgxxC-
```

:::

### Assassination Rogue   Basic Rotation

2.3.

#### Beginner Assassination Rogue Rotation

This priority list is a very basic priority list, and some of the finer
details to get the most damage out of the spec are missing. By following the
link, you will be able to find a more detailed version of
this priority list for both single-target and AoE, as well as a deeper
explanation of some of the core concepts of Assassination gameplay. If you
would like to know more about how to pool Energy properly and what your opener
should look like, check out the Rotation section of this guide.

:::details FAQWhich Race is the Best for Assassination Rogue?
The DPS differences between the races are fairly minimal. The best races for
DPS on Horde are Tauren, Troll, and Blood Elf. Orc has slightly higher 2-minute burst.
For Alliance, Human, Dwarf, and Gnome are the best.

:::

You will want to have [[spell:2823]], [[spell:381664]], and your
non-lethal poison of choice active at all times.

As for the actual rotation:

- Use [[spell:1329]] as your single-target builder, and [[spell:32645]]
  as your single-target spender.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker: Ensure to cast [[spell:32645]] with maximum CP if you
  have [[spell:457058]].
- Maintain [[spell:1943]] and [[spell:703]] at all times, spread them with [[spell:1247227]]
  in AoE.
- Use [[spell:51723]] as your AoE builder, but only after you have used [[spell:1247227]]
  to spread your Bleeds to all targets.
- Use [[spell:385627]] and [[spell:360194]] on cooldown, and apply [[spell:1856]]-empowered
  [[spell:703]] before using Deathmark.
- Use [[spell:381623]] to avoid overcapping charges, by using it alongside
  [[spell:385627]].

2.4.

#### Tips and Tricks for Assassination Rogue

- Try to refresh [[spell:1943]] and [[spell:703]] before activating
  [[spell:360194]], so you do not have to cast these abilities
  while it is active.
- You can refresh your buffs and debuffs early, as long as it is within the
  last 30% of their duration. This is called **Pandemic** and makes maintaining
  100% uptime a lot easier.
- Always cast finishers at 5+ Combo Points.
- When available, make sure to use your [[spell:457058]] proc by casting
  [[spell:32645]] with 7 Combo Points to refresh [[spell:457052]].
- [[spell:360194]] doubles the damage of the currently active bleeds. If these are
  buffed through something like [[spell:381632]], you will double the increased effect too.

2.4.1.

##### Apex Talent: ![Implacable Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_disembowel.jpg>) Implacable

Our new Apex talent [[spell:1265385]] helps smoothen our your energy draughts, by
granting additional Energy regen once your Envenom has dropped. Your goal will be to chain
Envenoms for as long as possible, and once you run out of Energy, our Apex talent will help
you regain Energy much faster. It also offers some other DPS bonuses, which do not have
any impact on your rotation.

2.4.2.

##### Season 2 Tier Set

The Midnight Season 2 Tier Set, [[spell:1296590]] and
[[spell:1296591]], has no effect on our rotation whatsoever. It simply boosts
our damage output, so there is no changes in gameplay once you acquire it.

### Assassination Rogue   Defensive Spells

2.5.

#### Defensive Spells for Assassination Rogue

[[spell:1966]] is an active spell that reduces all area damage taken. This
has a very short cooldown and should be used regularly. The DPS cost is
negligible, and it is a defensive that every other class is jealous of.

[[spell:31224]] is your immunity. It removes most Magic, Curse,
Disease or Poison debuffs when you press it, which in some cases is not a
good thing. It also makes you immune to all magic effects and damage. Most
raid encounters tend to apply any associated debuffs anyway, but at least you
will simply not take damage.

[[spell:5277]] increases your dodge to over 100%, making you immune to
melee attacks. Rarely useful in raids, but it can save your life in Mythic+ or
overworld content.

[[spell:31230]] saves you from dying once, leaving you at low HP with
very strong damage mitigation. This has a 6-minute cooldown and makes your
already strong defensive kit even stronger.

[[spell:1856]] is used as a DPS ability in raids but can save your life
in World Content and Mythic+. It makes all enemies lose threat on you, and if
you are the only surviving player, enemy mobs will reset without you dying. It
can also occasionally be used to avoid targeted spell casts if you Vanish
before the enemy finishes casting.

### Assassination Rogue   Stat Priority

2.6.

#### Stat Priority for Assassination Rogue

Currently, you will want to prioritize secondary stats as follows for both
Raiding and Mythic+. For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>).

Item Level

Critical Strike

Haste

Mastery

Versatility

Beyond secondary stats, Agility is by far the most important, meaning any item level increase is
typically an upgrade, regardless of secondary stats. The secondary stat
priorities shift and change as you acquire new gear, and we highly recommend
simming yourself in order to find out what stat is best for you specifically. All
secondary stats are fairly equal in value, so do not fret if you get a Mastery/Versatility
piece, it is still a good item, especially if it is higher item level than what you
are currently wearing.

### Blizzard   Single-Button Rotation

2.7.

#### Assisted Highlight & Single-Button Assistant for Assassination Rogue

The **Single-Button Assistant** system offers an easy introduction into the
spec and its many buttons, but it comes at a cost. Due to the increase of the Global
Cooldown you will naturally do lower DPS already. The One-Button rotation is also
missing out on some of the finer nuances of the rotation in order to make it more
accessible for players who have just started their journey into the game,
so even when using the **Assisted highlight** feature, you will be trailing
a little behind those who have already mastered the ins and outs of the spec.

That being said, the DPS difference compared to the most complex and detailed
rotational gameplay is not as big as you might think. You can expect to do
only around ~5-10% less DPS than you would do with perfect rotational gameplay, as long
as you correctly use your cooldowns (which the OAB will not). So, if you
want to get your bearings before moving on to the Beginner DPS Rotation, using
the Assisted Highlight or even the Single-Button Assistant is a great starting
point if you have just taken your first steps into World of Warcraft.

Unfortunately it does not currently use [[spell:1247227]] in AoE, which is a
massive loss in DPS unless you press the button yourself to spread your bleed effects.
If you want to just the SBA for dungeons, you need to do so, or risk losing more than half
your DPS.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **06 Sep. 2025:** Page updated to be written with Tier-Set in mind.
- **04 Aug. 2025:** Updated for Patch 11.2, added Tier-Set disclaimer.
- **15 Jun. 2025:** Added information for Combat Assist feature.
- **21 Apr. 2025:** Switched to Bleed Build for Mythic+ and reviewed page for Patch 11.1.5.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for The War Within Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed and updated for Patch 10.2.6.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **14 Nov. 2023:** Updated with newly optimized Assa single-target priority during Deathmark and Dance.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **06 Jun. 2023:** Updated for Sepsis build, removed Exsanguinate while it is bugged.
- **01 May 2023:** Updated for Patch 10.1. Simplified rotational priorities.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Dragonflight Patch 10.0.5 changes.
- **04 Jan. 2023:** Updated talent build.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Assassination Rogue in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Assassination Rogue

Assassination Rogue in Patch 12.1 plays virtually the same as before, but our talent
recommendations have changed. We are once again back to playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker
in all content, as it sports a slightly higher sustained single-target and AoE potential
than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound. Deathstalker also puts out some incredible priority-target
damage thanks to [[spell:457055]], one of the hero tree talents, and that is typically
what sets this option apart from the alternative hero tree. While managing [[spell:457052]]
can be cumbersome, once you talent into the build you will be able to add a new skill to
your bar that lets you easily swap the mark, on a cooldown of course. Make sure to make
use of this!

- **Single Target -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound is the better choice here, especially in
    the current raid tier. On paper, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker is ever-so-slightly stronger,
    but it is much more cumbersome to play, more prone to error, and even under perfect
    circumstances, it does at most 1-2% more DPS. It is simply not worth recommending playing
    it with those considerations in mind. Fatebound does almost the same damage, is easier to
    play, can use [[spell:1966]] more freely, and generally has much less room for error.
- **AoE -** For AoE and Mythic+, it depends heavily on how high you want to push.
    For the vast majority of keylevels, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound is the better choice as well,
    for the same reasons as above. However, when doing title-level high-keys,
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker is the better choice. It has roughly equivalent AoE as Fatebound,
    but the ability to funnel additional damage into your main target is incredibly
    valuable, and highly sought after. This alone is enough to separate it from the
    competitor hero tree in this specific environment.

With this information in hand, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker is the recommended build for
virtually all content.

**Quick Start Import Codes:**

:::talents Assassination Pure Single-Target - Fatebound
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYGzYMmZMMAGYBmxoxsBYbAbGAMzMGD"
}
```
:::

:::talents Assassination Raid Cleave - Fatebound
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AjxMjxYmZmxAYgFYGjGzGgtBsZAwMzgB"
}
```
:::

:::talents Assassination Mythic+/Delves - Fatebound
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzMMA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Fatebound

Pure Single-Target

Raid Cleave

recommended

AoE

Mythic+

Delves

Deathstalker

Pure Single-Target

Raid Cleave

AoE

high-keys

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound Pure Single-Target Build

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound build offers pure single-target damage, not taking any
of the highly valuable cleave or AoE talents to fully optimize single-target DPS. Unfortunately there
aren't that many pure ST bosses in this raid, so you won't get much use out of this build,
and even in those cases ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker is just a higher-performing option.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound Raid Cleave Build

This is the recommended build for most raid bosses where cleave is possible from time
to time. It still puts emphasis on picking most single-target talents, but adds [[spell:421975]]
and [[spell:1247227]] into it, to ensure you can contribute to additional enemies in
a fight.

You can swap to the pure single-target build on encounters like [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
or [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>), if you feel like you aren't getting much value out of the
additional cleave, but it is not recommended.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound Delve and Mythic+ Build

This is our recommended build for most Mythic+ dungeons, as it does not have to
worry about dealing with [[spell:457052]]. It sports a similar DPS potential as
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker, is easier to play, has fewer rotational quirks you need to pay
attention to, and is generally a much smoother and relaxed experience for virtually the
same benefit.

Only when pushing the absolute highest level of keys, or in very specific cutting-edge
progression scenarios, would we even consider switching to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker builds.

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker Single-Target Build

This is the current pure ST build for Raid playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker, sacrificing
the ability to cleave onto add spawns or additional targets to fully maximize its
single-target potential.

We only recommend playing this build against [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker Raid Cleave Build

This is the recommended build for most raid bosses where cleave is possible from time
to time. It still puts emphasis on picking most single-target talents, but adds [[spell:421975]]
and [[spell:1247227]] into it, to ensure you can contribute to additional enemies in
a fight, while also letting you do more priority-target damage in those situations thanks to
[[spell:457055]].

You can swap to the pure single-target build on encounters like [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
or [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>), if you feel like you aren't getting much value out of the
additional cleave or funnel damage, but it is not recommended.

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker Mythic+ and Delves Build

This is our highest-performing AoE build specifically for high-keys. It has incredible
priority-target capabilities, while also sporting high sustained AoE damage, and we
recommend you play this build whenever there is large-scale AoE, or even on raid
encounters with loads of adds that you can use to funnel damage into a boss.

However, you have to juggle quite a few extra rotational priorities, and manage your
[[spell:457052]], which when done badly, can lead to a steep drop in DPS, so
this is more of an advanced build to play in very specific situations.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYGzYMmZMMAGYBmxoxsBYbAbGAMzMGD"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUUmHhlFGGXXX11G-XbCEHRSsCNagg+CCGw8QposwJaKLrzD-AAAA-JQmUhpBIgwgxxC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsZwAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AjxMjxYmZmxAYgFYGjGzGgtBsZAwMzgB"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGiCY4QaiS7D84pSooMPCLLMMuuuqrN-XbCEHTsCFNagq+ADCGw8MposwJKLrzD-AAAA-JQmUhpBIgwgxxC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzMMA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGimCY4QaiS7D84pSooMPLLMMuuuqrN-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-JQkUhpBIgwgxxC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlxsNDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYGzYMmZMMAbmlBGwCYZYCMsYwMDwYMA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUUmHhlFGGXXX11G-XbCEHRSsCNagg+CCGw8QposwJaKLrzD-AAAA-GIOQaAGIogBFmF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPwYMzYMmZGjBYzsMwAWALDTghFDmZAGjB"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUUmHhlFGGXXX11G-XbCEHSsELMagq+ADCGw8MposwJKLrzD-AAAA-GIOQaAGIogBFmF-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsZWGYALglhJwwiBzMAjxA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUmHhlFGGXXX1GnX-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-GIOQaAGIogBFmF-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend you pick the following bonuses, but as you
can freely switch between them at any time, feel free to experiment with other options
yourself if you feel you do not get enough mileage out of the recommended options:

- Node 1:[[spell:1279599]]
- Node 2:[[spell:1279603]]
- Node 3:[[spell:1287555]]
- Node 4:[[spell:1279610]]
- Node 5:[[spell:1279614]]

3.

### Apex Talent: ![Implacable Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_disembowel.jpg>) Implacable

Midnight offers us a new type of talent, Apex Talents. This is a 4-point talent that
lets you allocate multiple points in it, providing different effects based on how many
talent points you put into it. Assassination gains the [[spell:1265385]] talent, which
does the following:

- **First Point**: [[spell:1265385]] will grant you bonus Energy whenever
      you cast Envenom.
- **Second and Third Point:**:[[spell:1265386]] will grant you additional
      Bleed and Nature damage.
- Fourth Point:[[spell:1265387]] will cause additional damage when using
      [[spell:385627]] and you will also generate 5 Combo Points passively in the next
      second.

Our Apex talent softens our weaknesses a little bit, letting us recharge Energy faster
once we run out of Energy, similar to what [[spell:381623]] already does, which smooths
out our rotation so we do not spend long periods of time without any buttons to press. The
[[spell:385627]] bonus is also quite nice, letting us quickly generate maximum Combo Points
after using KB, without having to waste another GCD on a Combo Point builder.

Overall this is a solid set of talents that aims to make our weaknesses less pronounced,
instead of further boosting our strengths.

4.

### Hero Talents

Assassination gets to pick between two distinct Hero Talent choices:
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker is built around the usage and application of [[spell:457052]],
which will grant you a number of benefits against a singular target, while gaining
further priority target damage from any kind of AoE you are doing, whether it be
multi-dotting or even just [[spell:421975]].

This makes it a good choice if you want to optimize your prio-damage, but
managing the Deathstalker's Mark can be cumbersome and if you end up losing
it due to a target-switch, you essentially do not have a Hero Talent anymore.
This is particularly egregious on bosses that submerge but do not clear their
debuffs, or when switching from one boss to another for prolonged periods of time.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound is the much more forgiving option while still sporting
similar or even better damage than Deathstalker. It can keep up in AoE thanks to a buffed
[[spell:421975]], and is built around the idea of flipping Fatebound Coins.
These can either deal direct damage, or boost the damage of all your class abilities. You
do not have much control over which coin will be stacking up for you. While not the most
flashy Hero Talent option, it provides very consistent damage with little to no additional
cognitive input required on your end, making it a very beginner-friendly choice.

5.

### PvP Talents (War Mode)

In Midnight, there will be the option to go into "War Mode."
Enabling War Mode provides the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended enabling the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of both General PvP Talents
and Assassination Rogue-specific PvE talents.

1. [[spell:198145]] deals nature damage and slows the enemy's movement
   speed by 90% for 2 seconds when you use a 5 Combo Point [[spell:32645]]
   on targets afflicted with your [[spell:703]], [[spell:1943]], and Lethal
   Poison. It is fairly good as it is a passive damage gain and can be useful if
   you need to run away without having other crowd-control options available.
2. [[spell:354406]] - [[spell:408]] will restore Energy when used, generating more
   Energy than it costs. This makes it quite valuable to use, and while it's still technically
   better DPS to simply spend your CP on a damaging finisher, the added safety can be quite
   valuable for Rouge, who is one of the most vulnerable classes while leveling.
3. [[spell:354895]] enables your [[spell:32645]] to apply Creeping
   Venom, dealing Nature damage over 4 sec. The duration is refreshed when the target
   moves. This is another passive damage increase, which can also be easily maintained by
   side stepping, causing the enemies to move with you.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **13 Aug. 2025:** Adjusted pre-11.2 Tier Talent recommendations.
- **04 Aug. 2025:** Pages updated for Patch 11.2, added tags for Talent recommendations with and without the new Tier set.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **21 Apr. 2025:** Switched to Bleed Build for Mythic+ and reviewed page for Patch 11.1.5.
- **25 Mar. 2025:** Updated some talent recommendations for class changes from March 25th.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated Talent builds for The War Within Patch 11.0.5.
- **09 Sep. 2024:** Updated for Season 1, removed pre-season build.
- **24 Aug. 2024:** Added Delve Talent Build.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **08 Nov. 2023:** Added DtB M+ build with Acro.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Updated for Patch 10.1.7 with new formatting.
- **16 Jul. 2023:** Added AoE build talent-calc link.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **06 Jun. 2023:** Updated with Sepsis replacing Serrated Bone Spike, and removed Exsanguinate altogether.
- **01 May 2023:** Reviewed for Patch 10.1. The recommended build and talent tree remain the same, and the page required no updates.
- **26 Mar. 2023:** Updated Mythic+ Talent build, added link to calculator.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Dragonflight Patch 10.0.5 changes.
- **04 Jan. 2023:** Updated Talent recommendations and descriptions according to newest sims.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Assassination Rogue in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Assassination Rogue Gameplay and Rotation Guide

Welcome to our Rotation page for Assassination Rogues. Here you
will find out more about your rotational priorities in both single-target
and multi-target situations, which you will apply in both Raiding and Mythic+
scenarios.

Each of the sections below explains the rotation and openers for different environments.
Click the boxes to switch to the desired situation and Hero Talent choice.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker

Raid Build

Mythic+ Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound

Raid Build

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+ Build

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

### Single-Target Opener

[[spell:1784]]

[[spell:2823]]

[[spell:381664]]

[[spell:703]]

[[spell:1329]]

[[spell:1943]]

[[spell:703]]

[[spell:1329]]

[[spell:32645]]

[[spell:360194]]

[[item:241308]]

[[spell:26297]]

[[item:270175]]

[[spell:385627]]

**适用条件：Fatebound（启用）。**

[[spell:32645]]

**适用条件：Deathstalker（启用）。**

[[spell:32645]]

[[spell:457058]]

[[spell:5938]]

**适用条件：Fatebound（启用）。** 1.1.

#### **适用条件：Fatebound（启用）。** Fatebound Single-Target Opener

**适用条件：Deathstalker（启用）。** 1.2.

#### **适用条件：Deathstalker（启用）。** Deathstalker Single-Target Opener

Always make sure to open from [[spell:1784]], and to have [[spell:2823]] and [[spell:381664]] active.

1. Open from Stealth with [[spell:703]]
2. Use [[spell:1329]] until you're at 5+ Combo Points
3. Cast [[spell:1943]] with 5+ Combo Points
4. Cast [[spell:703]] to extend your [[spell:381632]]
5. Build up to 5+ Combo Points with [[spell:1329]]
6. Cast [[spell:32645]]
7. Cast [[spell:360194]], and use any potions, on-use trinkets, or racials here.
8. Cast [[spell:385627]]
9. **适用条件：Fatebound（启用）。** Continue casting [[spell:32645]] at 5+ CP, and use [[spell:1329]] to build CP.
10. **适用条件：Deathstalker（启用）。** Continue casting [[spell:32645]] at 5+ CP, and use [[spell:1329]] to build CP. Make sure to cast Envenom at 7 CP when [[spell:457058]] is active. If you are at exactly 6 CP, you should use [[spell:5938]] or [[spell:51723]] to get to 7 CP.

This completes your opener, and you then follow with your regular rotational priority.

### Single-Target Rotation

**适用条件：Fatebound（启用）。** 1.3.

#### **适用条件：Fatebound（启用）。** Fatebound Single-Target Rotation

**适用条件：Fatebound（启用）。** This is the general priority list on how to use your abilities. This is NOT a list that should be followed step by step; it simply serves as a good idea of which things to prioritize in your moment-to-moment gameplay, as you will often be faced with multiple choices on which buttons to press. The priority list simply highlights which buttons are more important than others.

1. **适用条件：Fatebound（启用）。** Maintain [[spell:703]]. Use it from [[spell:1856]] when possible (before every Deathmark).
2. **适用条件：Fatebound（启用）。** Maintain [[spell:1943]] with 5+ Combo Points.
3. **适用条件：Fatebound（启用）。** Activate [[spell:360194]] when available.
4. **适用条件：Fatebound（启用）。** Use [[spell:385627]] on cooldown. Make sure to sync it with Deathmark.
5. **适用条件：Fatebound（启用）。** Cast [[spell:32645]] with 5+ Combo Points.
6. **适用条件：Fatebound（启用）。** Cast [[spell:8676]] to generate Combo Points whenever it is usable.
7. **适用条件：Fatebound（启用）。** Cast [[spell:1329]] to generate Combo Points.
8. **适用条件：Fatebound（启用）。** Use [[spell:51723]] to build CP as soon as there is more than 1 target.
9. **适用条件：Fatebound（启用）。** Use [[spell:381623]] when low on Energy, or simply play the version that auto-uses it. It makes no difference.

**适用条件：Deathstalker（启用）。** 1.4.

#### **适用条件：Deathstalker（启用）。** Deathstalker Single-Target Rotation

**适用条件：Deathstalker（启用）。** This is the general priority list on how to use your abilities. This is NOT a list that should be followed step by step; it simply serves as a good idea of which things to prioritize in your moment-to-moment gameplay, as you will often be faced with multiple choices on which buttons to press. The priority list simply highlights which buttons are more important than others.

1. **适用条件：Deathstalker（启用）。** Make sure to use [[spell:703]] to apply [[spell:457052]].
2. **适用条件：Deathstalker（启用）。** Swap your [[spell:457052]] with [[spell:1293340]] if you need to swap targets
   and are still multiple finishers away from a [[spell:457058]] proc.
3. **适用条件：Deathstalker（启用）。** Maintain [[spell:703]], casted from [[spell:1856]] when possible (before every Deathmark).
4. **适用条件：Deathstalker（启用）。** Maintain [[spell:1943]] with 5+ Combo Points.
5. **适用条件：Deathstalker（启用）。** Activate [[spell:360194]] when available.
6. **适用条件：Deathstalker（启用）。** Use [[spell:385627]] on cooldown. Make sure to sync it with Deathmark.
7. Cast [[spell:5938]] on cooldown.
8. **适用条件：Deathstalker（启用）。** Cast [[spell:32645]] with 5+ Combo Points. Cast it with 7 CP
   when [[spell:457058]] is active.
9. **适用条件：Deathstalker（启用）。** Cast [[spell:8676]] to generate Combo Points whenever it is usable.
10. **适用条件：Deathstalker（启用）。** Cast [[spell:1329]] to generate Combo Points.
11. **适用条件：Deathstalker（启用）。** Use [[spell:51723]] to build CP as soon as there is more than 1 target.
12. **适用条件：Deathstalker（启用）。** Use [[spell:381623]] when low on Energy, or simply play the version that auto-uses it. It makes no difference.
13. **适用条件：Deathstalker（启用）。** You can use [[spell:5938]] or [[spell:51723]] if at 6 CP and [[spell:457058]] is available.

### Multi-Target Opener

[[spell:1784]]

[[spell:2823]]

[[spell:381664]]

[[spell:703]]

[[spell:381632]]

[[spell:51723]]

[[spell:1943]]

[[spell:360194]]

[[item:241308]]

[[spell:26297]]

[[item:270175]]

[[spell:385627]]

[[spell:32645]]

[[spell:1247227]]

[[spell:1247227]]

[[spell:1247227]]

[[spell:1247227]]

**适用条件：Fatebound（启用）。**

[[spell:32645]]

**适用条件：Deathstalker（启用）。**

[[spell:32645]]

[[spell:457058]]

[[spell:51723]]

**适用条件：Fatebound（启用）。** 1.5.

#### **适用条件：Fatebound（启用）。** Fatebound AoE Opener

**适用条件：Deathstalker（启用）。** 1.6.

#### **适用条件：Deathstalker（启用）。** Deathstalker AoE Opener

Always make sure to open from [[spell:1784]], and to have [[spell:2823]] and [[spell:381664]] active.

1. Open from Stealth with [[spell:703]]. Cast it twice for maximum Pandemic value on [[spell:381632]]
2. Cast [[spell:51723]] to generate Combo Points
3. Cast [[spell:1943]] with 5+ Combo Points
4. Cast [[spell:360194]], and use any potions, on-use trinkets, or racials here.
5. Cast [[spell:385627]]
6. Cast [[spell:32645]] at 5+ Combo Points
7. Cast [[spell:1247227]] repeatedly to spread your bleeds to all targets. Stop at 5+ CP or when all targets have all bleeds.
8. **适用条件：Fatebound（启用）。** Continue casting [[spell:32645]] at 5+ CP, and use [[spell:51723]] to build CP.
9. **适用条件：Deathstalker（启用）。** Continue casting [[spell:32645]] at 5+ CP, and use [[spell:51723]] to build CP. Make sure to cast Envenom at 7 CP when [[spell:457058]] is active.

Remember to use [[spell:1247227]] instead of [[spell:51723]] to build Combo Points in AoE, if not all of the targets have all your bleeds active yet. Once your opener is finished, follow the regular AoE rotational priority.

### Multi-Target Rotation

**适用条件：Deathstalker（启用）。** 1.7.

#### **适用条件：Deathstalker（启用）。** Deathstalker Multi-Target Rotation

**适用条件：Fatebound（启用）。** 1.8.

#### **适用条件：Fatebound（启用）。** Fatebound Multi-Target Rotation

1. **适用条件：Deathstalker（启用）。** Make sure to use [[spell:703]] to apply [[spell:457052]]. Cast it twice to extend the
   [[spell:381632]] to its max duration on opener.
2. **适用条件：Deathstalker（启用）。** Swap your [[spell:457052]] with [[spell:1293340]] if you need to swap targets
   and are still multiple finishers away from a [[spell:457058]] proc.
3. Cast [[spell:703]], ideally from [[spell:1784]], and cast [[spell:1943]] with 5+ CP.
4. Maintain [[spell:703]] and [[spell:1943]] on all targets by using [[spell:1247227]]
   as your AoE builder.
5. Use [[spell:1247227]] as your AoE builder to spread bleeds. If all targets have bleeds already,
   use [[spell:51723]] instead as soon as there is more than 1 target.
6. Activate [[spell:360194]] when available.
7. Use [[spell:385627]] (if talented) on cooldown. Make sure to sync it with Deathmark if it is ready.
8. Use [[spell:1856]] to re-apply [[spell:703]]s buffed by [[spell:381632]] if
   your initial set of DoTs are close to running out, and the pack is going to live
   for another ~20+ seconds.
9. **适用条件：Fatebound（启用）。** Cast [[spell:32645]] with 5+ Combo Points.
10. **适用条件：Deathstalker（启用）。** Cast [[spell:32645]] with 5+ Combo Points. Cast it with 7 CP
    when [[spell:457058]] is active. Use [[spell:5938]] to get to 7 CP, if you are at exactly 6 CP.
11. Use [[spell:381623]] when low on Energy, or simply play the version that auto-uses it. It makes no difference.
12. **适用条件：Deathstalker（启用）。** You can use [[spell:5938]] or [[spell:51723]] if at 6 CP and [[spell:457058]] is available, even on single-target.

2.

### Midnight Season 2 Tier Set

The Midnight Season 2 Tier Set, [[spell:1296590]] and
[[spell:1296591]], has no effect on our rotation whatsoever. It simply boosts
our damage output, so there are no changes in gameplay once you acquire it.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Assassination Rogue
kit, we have compiled a more detailed explanation on individual parts of our rotation, from
important rotational mechanics that you need to pay attention to, to cooldowns and how to use them, so you can
reach your full potential when playing Assassination.

### Envenom Chaining

3.1.

#### Envenom Chaining

Chaining [[spell:32645]]s is a core aspect of Assassination Rogue gameplay.
This refers to the mechanic of casting Envenoms while the previous one is still active,
instead of letting the short-duration buff from Envenom fall off before casting a new one.
Assassination has a variety of talents and passives that boost your DPS when casting Envenoms
while the previous one is still active, but you will want to take
special care to not do so too early.

Some of the talents supporting this playstyle are:

- **[[spell:1250036]]**  
  
  A new choice-node talent at the bottom of the tree, that boosts all of our
  class-damage when chaining Envenoms.
- **[[spell:1250318]]**  
  
  The alternative talent to Inspiring Strike, which grants 1 Combo Point instead
  when chaining properly.
- **[[spell:455072]]**  
  
  This talent was massively buffed to grant increased Envenom damage when
  chaining.

### Apex Talent: Implacable

3.2.

#### Apex Talent: Implacable

Midnight offers us a new type of talent, the Apex Talent(s). This is a 4-point talent that
lets you allocate multiple points in it, providing different effects based on how many
talent points you put into it. Assassination gains the [[spell:1265385]] talent, which
does the following:

- **First Point**: [[spell:1265385]] will grant you bonus Energy whenever
      you cast Envenom.
- **Second and Third Point:**:[[spell:1265386]] will grant you additional
      Bleed and Nature damage.
- **Fourth Point:** [[spell:1265387]] will cause additional damage when using
      [[spell:385627]] and you will also generate 5 Combo Points passively in the next
      second.

Our Apex talent softens our weaknesses a little bit, letting us recharge Energy faster,
which smooths out our rotation so we do not spend long periods of time without any
buttons to press. The [[spell:385627]] bonus is also quite nice, letting us quickly
generate maximum Combo Points after using KB, without having to waste another GCD on a
Combo Point builder.

Overall this is a solid set of talents that aims to make our weaknesses less pronounced,
instead of further boosting our strengths.

### Pandemic

3.3.

#### Pandemic

Pandemic is a game-wide mechanic that applies to all kinds of buffs and debuffs
that have a duration. When you refresh [[spell:1943]], [[spell:703]],
or [[spell:315496]] before they expire, the remaining
duration is added to the newly applied effect, up to 30% of the newly applied
base duration.

**Example** — You can safely refresh a 5-Combo Point Rupture when it
has 7.2 seconds or less remaining because its base duration is 24 seconds.
[[spell:193531]] allows for 6 Combo Point Ruptures, which last 28
seconds. 6-Combo Point Ruptures can be refreshed safely when they have 8.4
seconds or less remaining. With [[spell:457512]] and 7 maximum
Combo Points, this changes to 9.6 seconds.

Safe Pandemic refresh timing is based on the **newly applied base
duration** and not the original length of the effect. Therefore, a 2 Combo
Point Rupture can still benefit from **full** Pandemic if it is refreshed by a 5 to 7
Combo Point Rupture.

This is an important mechanic to pay attention to throughout your gameplay,
as letting your bleeds drop entirely will make you lose out on Energy, while chaining
Envenoms is a huge boost to your DPS, as explained in the previous
section.

### Energy Pooling

3.4.

#### Energy Pooling

It can be very beneficial to "pool" your Energy and Combo Points, which
involves auto-attacking while your Energy regenerates. The advantage this
provides is variable, meaning that pooling does not always result in damage
gained. Situations where pooling Energy and Combo Points is beneficial
include:

- After your Envenom-chain drops, you will want to wait until high Energy
  before beginning the process anew
- Before an important add spawns, so that you can apply as much instant pressure
  as possible
- An encounter-specific buff or damage phase is imminent

Pooling Energy is not a magical DPS gain by itself. It allows you to
slightly adjust the timing of your abilities so that you fit more attacks
during periods of increased damage, provided you can properly identify when
such periods are going to happen.

### Deathstalker's Mark

3.5.

#### Deathstalker's Mark

When playing the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker Hero Talent tree, you will be playing around
your [[spell:457052]] and [[spell:457058]] debuff and buff. The Mark
applies to a single enemy, and whenever you finish you lower its count by one. Once consumed,
you will be granted **Darkest Night** which massively boosts the damage of your next [[spell:32645]],
while also re-applying the Mark to the target you cast it on.

You need to make sure that your uptime on Deathstalker's Mark is close to 100%.
For example, while Energy pooling is an important aspect of your gameplay, do
not do so if it means your Mark is not active for a prolonged period of time.

There is also an added layer of difficulty to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker on encounters
where you frequently have to switch targets, or bosses end up submerging without clearing their debuffs.
In order to still benefit from your Hero Talent choice, you need to ensure that you get a
[[spell:457058]] proc before the boss disappears or a new target spawns, so you can
quickly transfer the Mark to the new target. On encounters where this is very difficult to
accomplish, your may be better off playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound instead.

You can swap your Mark with the [[spell:1293340]] ability that you will learn automatically
as you talent into Deathstalker. This is useful to change marks when you're still multiple
finishers away from getting a Darkest Night proc, or when an add spawn surprises you.

### Snapshotting

3.6.

#### Snapshotting

The damage buff from [[spell:381632]] is removed when you overwrite the bleed you
empowered by re-applying an unempowered one. Therefore, it is best to let the DoT run
its full duration before refreshing it. This bonus damage gets doubled
during [[spell:360194]].

4.

### Important Cooldowns for Assassination Rogue

### [[spell:360194]]

4.1.

#### Deathmark

[[spell:360194]] is our main cooldown, available every 2 minutes. It grants
increased damage to your bleeds and duplicates your Poison procs, allowing for much
quicker build-up of your [[spell:385627]] stacks. It is paramount to ensure that
you use Deathmark on targets that do not die during its duration.

Sometimes it can be beneficial to not use Deathmark the moment it comes up. You may
want to pool a little Energy before doing so, to ensure you can use every Global Cooldown
during its duration, and you want to pay attention to upcoming boss mechanics that might
force you out of melee. Since it is a 2-minute cooldown, you can safely delay Deathmark,
provided you do not lose out a full use of it over the course of a fight or dungeon run.

i.e. On a 7-minute encounter, it makes no difference if you use DM on pull, and then every 2 minutes,
or if you end up delaying a cast, and instead use it on pull, 2:30, 4:30, and 6:30 into the fight. The
amount of DM casts is the same.

The same applies for situations where delaying the CD would make it line
up with the enemy's HP threshold for [[spell:381798]]. Try to avoid using DM at 40% boss HP, when
you can delay it a little to get the full Execute benefit — as long as
you do not lose out a cast at the end of the fight.

### [[spell:385627]]

4.2.

#### Kingsbane

[[spell:385627]] is a 1-minute cooldown that we want to use on CD as much as possible.
It deals up-front damage, and then damage-over-time, and its DoT tick-rate does not scale with Haste.

The damage over time increases with each Poison proc, up to a cap, which makes it synergize exceptionally
well with Deathmark thanks to its Poison duplication effect. It is absolutely paramount that you maintain
100% melee uptime and 100% [[spell:32645]] uptime while Kingsbane is running. Similar to Deathmark,
delaying KB can be beneficial, but as it is on a 1-minute cooldown, it is challenging to do so without
losing out on a full cast of it.

This is where our incredible survivability kit comes into play. Skills like [[spell:5277]] or
[[spell:31224]] allow us to ignore certain mechanics without getting hit or affected by
them, and where other Melee DPS may have to run away from the boss to avoid taking lethal damage,
we can safely maintain uptime to further boost our DPS. This makes these defensive abilities act
as DPS boosts in certain encounters, and planning around their usage to potentially overlap with
dangerous boss mechanics is what separates a good from a great Assassination Rogue.

### [[spell:381623]]

4.3.

#### Thistle Tea

[[spell:381623]] is a multi-charge ability, generating one charge a minute. It grants
Energy on use, and can be very useful to maintain Envenom Chains during
damage amplification phases on a boss, or to ensure you use every GCD during your [[spell:360194]].
It auto-activates at below 30 Energy, and there's no benefit to trying to play around it manually.

### [[spell:2094]]

4.4.

#### Blind

[[spell:2094]] is not part of our DPS kit, but still has some interesting use-cases in Mythic+ that may
not be immediately apparent. While [[spell:6770]] allows a player to safely pass a CC-ed creature without getting
into combat, a blinded enemy will walk around confused and still get into combat with the **first** player that
gets close to it. Once the Blind debuff ends, it will engage said player. It will not, however, get into combat
with any other player that gets close to it.

You can still make great use of Blind to pass enemies by abusing the fact that only one player
gets into combat with it. The best and easiest way to do this, is to ensure that after blinding the target, you
get close enough to enter combat with it, and then you and your entire group can pass the enemy. Once you
are far enough away from it, you can safely [[spell:1856]], drop combat, and skip the enemy.

This is particularly useful in situations where an entire pack of enemies is in your way that you would
like to skip, but one or two enemies are too close to pass by without body-pulling them. As a Rogue, you can
[[spell:6770]] one, and then use the above trick for the other, allowing you to skip past enemies that would either
detect you if you were to use [[spell:114018]], or if Shroud is on cooldown.

4.5.

#### Defensive Utility

All Rogues have a solid number of defensive cooldowns, making them the best
candidate for soaking required mechanics and dealing with heavy incoming
damage.

- [[spell:1966]] reduces AoE damage taken by 40% for 6 seconds for only 35
  Energy. When talented into [[spell:79008]], it also reduces all other
  damage by 20% and grants [[spell:5277]] a 20% damage mitigation. This is one
  of the most overpowered abilities in the game and a huge asset in fights with
  heavy raid damage.
- [[spell:31224]] provides magic immunity for 1 second, followed
  by 4 seconds where all spells will miss you. Cloak of Shadows has a variety of
  uses, both pre-emptive and reactive, such as solo soaking mechanics or clearing
  debuffs that would force you out of melee range.
- [[spell:5277]] increases your Dodge chance by 100% for 10 seconds.
  This can be useful if you have to tank some adds or the boss for a few
  seconds. In rare cases, it can be used to negate physical ranged attacks or
  spells.
- [[spell:31230]] is a talent that allows you to escape lethal damage
  once every 6 minutes. The damage cannot exceed more than twice your maximum
  health. Cheat Death is great for soaking mechanics that pierce
  immunities and damage reductions, as it guarantees your survival. It is also
  great for encounters with bursty damage that might take you by surprise, as
  you get a free get-out-of-jail-free card at least once in the encounter.
- [[spell:185311]] provides a respectable amount of healing on a 30-second
  cooldown.

Do not forget about this defensive toolkit, as it can be a major asset for
both individual and raid-wide survivability, or even used to stay in dangerous areas to
do slightly more damage.

5.

### Poisons

Your **Lethal Poison** should always be [[spell:2823]] and
[[spell:381664]].

You have three choices for your non-lethal Poison; [[spell:3408]],
[[spell:381637]], and [[spell:5761]]. For raiding, you will
want to use **Atrophic Poison**
unless your raid wants you to slow a specific group of targets. For
Mythic+, you will want to use the Poison that best suits your tank's needs.
Crippling Poison allows your tank to more easily kite enemies,
whereas Numbing Poison slows their attack speed instead, while Atrophic Poison
reduces the damage the group takes from enemy attacks and spells.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Updated Opener for Garrote Snapshot.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **06 Sep. 2025:** Page updated with minor simplified rotation changes.
- **03 Sep. 2025:** Clarified Fatebound Shiv usage.
- **18 Aug. 2025:** Clarified Deathstalker AoE rotation if Kingsbane is not talented.
- **04 Aug. 2025:** Page updated for Patch 11.2 with detailed information on Fatebound and Deathstalker tier-set impacts.
- **15 Jun. 2025:** Added information for Combat Assist feature.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **25 Mar. 2025:** Updated rotational priorities for class changes from March 25th.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for the gameplay changes in Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **14 Nov. 2023:** Updated with newly optimized Opener on single-target.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **06 Jun. 2023:** Updated Sepsis gameplay information.
- **01 May 2023:** No rotational changes are required for Patch 10.1. Added Rotation Quick Guide.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Dragonflight Patch 10.0.5 changes.
- **04 Jan. 2023:** Updated rotational priorities for DTB and Kingsbane builds.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Assassination Rogue in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Assassination Rogue

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Assassination Rogue. Keep in mind that there are many other setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
You will want to try and prioritize getting the **Shoulder, Chest, Legs, and Gloves** set pieces. However, getting the Helmet to complete one of the bonuses is still better than any other gearing choice.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2 you also retain the secondary stats and any other potential passive effects like damage procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear, but if that is not possible, it is not a big deal either. It is better to have the set with slightly suboptimal stats and fix it later into the season, than missing out on the bonus for another week or two. Some optimal stat items to catalyze are:

- Helmet: [[item:271875]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:251223]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Chest: [[item:281236]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Gloves: [[item:251124]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs: [[item:268225]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

Technically, the Gloves don't need to be catalyzed as they already have optimal stats baseline.

:::

:::details FAQWhat to Get From The Great Vault?
Generally speaking, your goal should be to grab a good weapon, your BIS trinkets, and of course your new tier set 4-pc bonus as quickly as you can. However, there is an alternative strategy that might end up being a bit degenerate, but could pay off if your progression ends up taking a few weeks, or months.

Instead of picking an item from the Great Vault, you can also choose to simply grab a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>). This lets you bonus roll on any dungeon or boss, and receive a 1/6 Myth track version of the item. Doing so on the [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) boss on Heroic would thus guarantee you your Weapon, Helmet, Neck, and two very good trinkets, both of which are your BiS trinkets.

While this may slow down your ilvl progression a bit due to these items needing crests to fully upgrade, it will allow you to get all of your absolute best items way before actually killing the raid's final boss on Mythic. Keep in mind that dropped items from Mythic will be at 9/6 Mythic though, whereas bonus-rolled items cap out at 6/6.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271875@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240914]][[item:273068]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271093@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237837@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup with farmable gear from Season 2 Mythic+ Dungeons.

This list is by no means a replacement for **simming yourself**. Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
You will want to try and prioritize getting the **Shoulder, Chest, Legs, and Gloves** set pieces. However, getting the Helmet to complete one of the bonuses is still better than any other gearing choice. Long-term you will want to play a specific helmet piece from [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) though.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2, you also retain the secondary stats and any other potential passive effects like damage procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear, but if that is not possible, it is not a big deal either. It is better to have the set with slightly suboptimal stats and fix it later into the season, than missing out on the bonus for another week or two. Some optimal stat items to catalyze are:

- Helmet: [[item:273791]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Shoulders: [[item:251223]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Chest: [[item:251159]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Gloves: [[item:251124]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs: [[item:251130]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

Technically, the Gloves, Helmet, and Legs don't need to be catalyzed as they already have good stats baseline.

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>), [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>), [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): Drop multiple high-value items.
- **Weapon**: Try to run [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) for a nice dagger with a special effect.
- **Trinkets**: [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>) and [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>) drop your best dungeon trinkets, although a handful of raid options tend to be considerably stronger.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:273791@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:273781@JAACAAAOyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Waist</th><td>[[item:159301@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271509@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Feet</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250259@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:240914]][[item:273068]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237837@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup, while only showing gear from the Venomous Abyss Raids.

This list is by no means a replacement for **simming yourself**. Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
You will want to try and prioritize getting the **Shoulder, Chest, Legs, and Gloves** set pieces. However, getting the Helmet to complete one of the bonuses is still better than any other gearing choice. Long-term you will want to play a specific helmet piece from [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) though.

With the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) changes for Season 2, you also retain the secondary stats and any other potential passive effects like damage procs when catalyzing a set piece. This means we want to try and catalyze the items that ensure we get the best possible secondary stats on our gear, but if that is not possible, it is not a big deal either. It is better to have the set with slightly suboptimal stats and fix it later into the season, than missing out on the bonus for another week or two. Some optimal stat items to catalyze are:

- Helmet: [[item:271875]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders: [[item:268246]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- Chest: [[item:281236]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Gloves: We want these from the token
- Legs: [[item:268225]] from [The Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

Technically, only the Gloves and Helmet really need to be catalyzed, the other slots all have decent stats baseline already. With this new system, it is highly recommended to grab a few Mythic+ pieces to catalyze for good sub stats.

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:271093@JAACAAAG2A]]: Our BiS Mainhand, if you can get it on Myth track. Drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270175@JAACAAAG2A]]: Our best trinket. Also drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270164]]: Our best passive trinket.
- Honorable mention: [[item:268266]] from the Lair Boss [Nymrissa Wavecaller](<https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa>). If you do this as a raid group, you really want the Haste from this ring.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271875@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">The Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:240914]][[item:273068]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/assassination-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271093@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237837@JAAKAAwt1ENMMYjViwhN]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Assassination Rogue

There are a great number of Trinkets available for Assassination, and we will always want
  to play a combination of a powerful on-use trinket like [[item:270175]] or [[item:159617]],
  and a passive trinket providing potent secondary stat buffs or raw damage procs. Make sure to
  [macro](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-macros-addons>) 
  your on-use trinket to your [[spell:360194]] cast!

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Assassination Rogue Trinkets**
**On-Use -**

[[item:270175]]

or, alternatively,

[[item:159617]]

**Passive -**

[[item:281215]]

or, alternatively,

[[item:270168]]

:::

There are quite a few other valuable trinkets out there, so make sure to check our
  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Assassination Rogue Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]] - BIS</li>&#10;<li>[[item:281215]] - BIS</li>&#10;<li>[[item:270168]] - A tiny bit behind Tendril</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>&#10;&#10;&#10;[[item:270173]] - <span><em>Click for Details</em></span>&#10;<span>A viable alternative to [[item:270168]], and better in single-target,&#10;        but we cannot complete the set bonus, so it is unlikely you will get this from raid.&#10;       </span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164]] - <span><em>Click for Details</em></span>&#10;<span>A strong passive trinket that works well in any environment. Despite being nerfed&#10;        prior to S2 starting, it is still one of our best options if you don't want to swap&#10;        trinkets based on target count.&#10;       </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:159617]] - <span><em>Click for Details</em></span>&#10;<span>Our best on-use trinket from Mythic+ sources. It is worth farming early,&#10;        until you can get your hands on a [[item:270175]].&#10;       </span>&#10;</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>&#10;&#10;&#10;[[item:250225]] - <span><em>Click for Details</em></span>&#10;<span>Another on-use from Mythic+, but weaker than Lustrous Golden Plumage.&#10;       </span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250259]] - <span><em>Click for Details</em></span>&#10;<span>Very strong in single-target and 2-target fights, but quickly loses value in&#10;        AoE.&#10;        </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:250214]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>Delve Trinkets</li>&#10;<li>[[item:158374]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>Any other unlisted trinket.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Patch 12.1 continues the bonus roll system that was initially introduced in Patch
12.0.7. Notably, bonus rolling on a Heroic raid boss will grant you the item at 1/6 Myth
track, so you can acquire some of the later raid gear quite early, as long as you commit
additional crests to upgrade it.

**[Nebulous Voidcores](<https://www.wowhead.com/currency=3418>)** can be spent after finishing a dungeon or killing
a raid boss, and will grant you a random from the dungeon's or boss's loot table.
Once an item has been looted through a Voidcore roll, it cannot appear again when you
bonus roll on the same boss or dungeon again.

After 8 weeks, you will also be granted one additional Voidcore for free from
**Orin Straylight** in Silvermoon, next to The Catalyst. This happens with the launch of
Patch 12.1.5.

3.1.

#### Recommended Nebulous Voidcore Usage for Assassination Rogue

Which item you want to chase after depends heavily on the items you have already acquired
  through i.e. the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), or whether you expect to down certain bosses on
  Mythic difficulty to get them on 9/6 Mythic itemlevel.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Mythic [[item:271093]]
2. Mythic [[item:270175]]
3. Remaining BiS List items

:::

On a new character, we recommend doing dungeons that drop a large amount of tier-slots like
chest+legs+shoulders from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>), where you can also pick up some good trinkets
even if your roll "fails". The tier-slot items you can catalyze to quickly get multiple
Myth Track tier items, without having to rely on the Great Vault. [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
also drops good items, including a weapon, ring, and neck, which will see great use. The
best choice ultimately depends on the gear you've already gotten from your Great Vaults
and potential Mythic raid bosses.

3.2.

#### Ascendant Venomstones

Using your [[item:280562]] follows a similar priority list as using your
  Crests. Note that you cannot further upgrade items from Mythic Ulatek and Coiled Altar
  that are already 344, as the new maximum ilvl is 340 for Myth track items, and 338 for
  crafted items.

1. Your Mainhand weapon is the highest priority
2. Your on-use trinket
3. Your passive trinket
4. Your Offhand weapon
5. Your Necklace

You will also want to prioritize Myth track items over Hero track ones, unless
  you do not expect to get a Myth track variant of said item. I.e. it is fine to upgrade a
  Hero track [[item:270175]] or [[item:270168]] if you do not expect to kill
  Mythic Ulatek or bonus roll for a Mythic version anytime soon.

4.

### Best Crafted Items for Assassination Rogue

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose the exact
secondary stats you want.

As your ability to craft items will be time-gated in the initial stages of
Midnight, we highly recommend getting a **Mainhand weapon** as soon as possible, unless
you can reliably get one elsewhere. Once you have a good weapon, work on your other Embellished
Item next, and then craft whichever pieces you do not have high-item-level versions
of yet.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Assassination Crafted Gear Priority**
- [[item:237837]] with [[item:273060]]
- [[item:244576]] with [[item:273069]]
- Any item you do not have on Myth track yet.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Assassination Rogue

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

As there is a lot of competition for Embellishments, you will have to pick
and choose the two strongest ones for your overall DPS output. Most of them provide
very similar DPS benefits, even if the effects are entirely different. The two best
choices for this are:

- For Raid: [[item:273060]] on a weapon and [[item:273069]] on another
  crafted item like Wrists.
- For Mythic+: [[item:273060]] on a weapon and [[item:273069]] on another
  crafted item like Wrists.

It is recommended to sim yourself to find out what works best, and if you
also play the other two Rogue specs, you might want to pick Embellishments that work
well for all of them.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Assassination Rogue Crest Upgrade Priority**
**Weapon (Mainhand)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

These are not the only items worth upgrading, of course. They simply offer
the highest DPS gain early into the tier when your upgrade currency is limited.
Note that exceptions are possible, such as special items that have additional
procs attached to them.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **25 Aug. 2026:** Updated trinket rankings.
- **18 Aug. 2026:** Updated for Season 2 launch and the most recent gear nerfs and changes.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Updated Trinket recommendations.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Updated info for Patch 11.2.5, added Puzzling Cartel Chip section, removed DISC Belt section.
- **13 Aug. 2025:** Added info for Netherprism.
- **04 Aug. 2025:** Updated for Patch 11.2 and TWW Season 3. Added all new BiS lists. Removed information regarding Cyrce's Circlet and the Puzzling Cartel Chips. Added information for Reshii Wraps.
- **21 Jun. 2025:** DISC recommendations updated for June 20th Hotfix.
- **15 Jun. 2025:** Added information for DISC belt for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5, added Puzzling Cartel Chip suggestions.
- **25 Mar. 2025:** Updated some gear recommendations for trinket tuning from March 25th.
- **13 Mar. 2025:** Updated for Mechano Core and Junkmaestro trinkets.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **25 Dec. 2024:** Updated Cyrce's Circlet gem recommendations.
- **17 Dec. 2024:** Updated for Cyrce's Circlet buffs.
- **15 Dec. 2024:** Cyrce's Circlet information added for Patch 11.0.7.
- **21 Oct. 2024:** Page reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW Season 1 with BiS Gear and Embellishments.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4. Added Bullion and Trinket sections.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **07 Nov. 2023:** Updated for Sporecloak nerf.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Updated for Patch 10.1.7, added multiple BiS lists.
- **16 Jul. 2023:** Updated Dawn of the Intinite section, Nick of Time BiS.
- **10 Jul. 2023:** Added Dawn of the Infinite section, removed Cataclysm Timewalking section, updated Annulet section for Patch 10.1.5.
- **06 Jun. 2023:** Updated Embellishment recommendation.
- **24 May 2023:** Added Timewalking info.
- **14 May 2023:** Updated trinket recommendations.
- **07 May 2023:** Updated Embellishment recommendations for recent hotfixes.
- **01 May 2023:** Page fully updated for Patch 10.1. Added Flightstone and Crest information, added Season 2 BiS items and recommendations, BiS embellishments and more.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated Dungeon Gear list, added BiS List disclaimer and Raid trinkets.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Assassination Rogue. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Assassination Rogue Stat Priority

For raiding and Mythic+, the secondary stat priority for Assassination Rogue
is as follows:

Item Level

Critical Strike

Haste

Mastery

Versatility

Except for Versatility, all stats are very close to each other in performance,
and item level is the most important factor due to the higher Agility it provides. Rings and Necks
are an exception to this as they do not provide Agility.

The overall goal for your gearing strategy is to get as much Haste and Crit as possible,
while completely avoiding Versatility.

2.

### In-Depth Stat Breakdown

**Agility** is your primary statistic. You should look for it in all
of your upgrades. It provides you with Attack Power, which determines the
damage your abilities do.

**Mastery** increases the damage that your poisons and bleeds deal
(through [[spell:76803]]). It also affects all Nature-damage
based
abilities like [[spell:5938]], [[spell:255544]], and [[spell:32645]].

**Critical Strike** increases your chance to critically hit
with attacks. As an Assassination Rogue, this statistic also contributes
to granting you extra Combo Points through [[spell:14190]].

**Versatility** is a flat-out damage done increase and damage taken
reduction.

**Haste** provides you with increased attack speed and Energy
regeneration. It also increases the tick rate of your Damage over Time effects,
which results in more Energy gained through [[spell:79134]].

:::details FAQIs there a Haste cap for Assassination Rogue?
There are no breakpoints for Assassination for Haste, or any of its other stats.
However, stats do diminish in value as you acquire more of them, so try to keep
a good balance between your most-valued stats.

:::

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Page was reviewed for Patch 11.2 and no changes were required.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Page reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **01 May 2023:** Patch 10.1 did not change the stat priority.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated Stat prio, added disclaimer for Haste at lower gear levels.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Assassination Rogue, based on your [stat priority](<https://www.icy-veins.com/wow/assassination-rogue-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should use [[item:240983]] in one socket. Alternatively you
can choose to not play a Prismatic gem, which will allow you to stack more of the same-colored
secondary stat gems instead. The difference here is very minor, so you can go with the choice
that best suits your money-bag.

For your secondary stat gems, pick Crit or Haste gems, like [[item:240890]]
or [[item:240906]]. If you plan on playing a Prismatic gem for the minor crit-damage
bonus, make sure to grab at least one of each gem type, like [[item:240914]] and [[item:240898]],
and then fill the remaining slows with the higher-value gems that we listed earlier.

You will likely have to shuffle around stats and consumables a little, based on what
stats you have on your gear. I.e. if you have a very high Haste item like [[item:271875]]
or [[item:268266]], you may want to opt for high crit gems and a Crit Flask,
otherwise grab Haste from those sources instead.

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Main Hand</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>with [[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Off Hand</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>with [[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243981]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Chest</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Whether you choose to enchant your gear with Avoidance, Leech, or Speed is
up to you. Leech will allow you to gain some additional passive healing while
you do damage, Avoidance reduces the damage taken by Area-of-Effect spells,
similar to [[spell:1966]], and Speed simply increases your movement speed. For
Raid progression movement speed is often underrated and can be a minor DPS
increase if it allows you to reach your target faster.

It is always recommended to sim yourself to find out what enchants provide
the best benefit to you individually.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

You will want to grab [[item:241325]] as your go-to Flask for the Haste bonus.
However, [[item:241326]] is also viable if you already have very high Haste
levels, i.e. if every single one of your items has Haste on them, the Crit Flask is going
to be ever-so-slightly better.

You can also obtain a flask of your choice from [[item:241319]]s
provided by Alchemists.

3.2.

#### Potions

[[item:241308]] is your best option, and should be paired with major
cooldowns and [[spell:2825]] / [[spell:32182]]. You can also obtain
temporary versions of the potion from [[item:241285]] provided
by Alchemists.

In Season 2 you now have access to [[item:271883]] 
which is significantly better than [[item:241305]]. Using
this has a 5-minute cooldown, but multiple can be consumed in an extended boss
fight should it go on long enough. Additionally, Warlock's
[[item:5512]] does not share a cooldown with other healing consumables.
Remember to use it as well if you are holding one!

3.3.

#### Food Buff

Try to chomp down on [[item:255845]] or another primary stat feast
if possible. If this isn't provided by your group, stick to [[item:242275]] as your
personal food instead.

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s 
to increase your primary stat. Augment Runes are expensive and disappear on death, 
so use them wisely and sparingly!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **24 Apr. 2026:** Updated Ring Enchant.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **16 Aug. 2025:** Added clarification for Fatebound Crit requirements.
- **04 Aug. 2025:** Removed Corruption section, and reviewed information for Patch 11.2.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **20 May 2025:** Updated Horrific Vision Enchant section to recommend Echoing Void.
- **21 Apr. 2025:** Added information for Horrific Visions enchants, reviewed page for 11.1.5.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Page reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Updated Onyx Annulet paragraph to no longer recommend farming it after 10.1.5 Annulet nerfs.
- **06 Jun. 2023:** Added Belt Clasp and Lambent Armor Kit as alternative Leg Enchant. Added Corrupting Rage Phial discussion.
- **01 May 2023:** Page reviewed for Patch 10.1. Updated Onyx Annulet recommendations.
- **26 Mar. 2023:** Updated Primordial Gem recommendations for latest hotfixes.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated Armor Kits, added Fortune Cookie food.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Assassination Rogue in World of Warcraft Patch 12.1.5.

1.

### Assassination Rogue in Mythic+ in Midnight Season 2

The playstyle of Assassination in Mythic+ revolves around setting up your
bleeds on multiple targets, ramping up your Energy regeneration, and then continuing to
cycle bleeds between targets while prioritizing a single-target with high damaging finishers.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

A key feature of Assassination AoE is that while it is most optimal
in multi-dotting evenly across several targets; you can still channel your
damage into a single target as well, which will cleave onto nearby targets
thanks to [[spell:421975]]. The additional resource generation will allow you to
make up for the sacrifices in single-target DPS, and Assassination sports one of the best
priority-target damage profiles in the game as a result. You can play this as either Hero Talent spec, depending on your preference,
with neither really being a significant gain over the other in Mythic+.

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound M+ Build

2.1.

#### Recommended ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound Mythic+ Talents

This is the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) Fatebound Mythic+ build for Assassination, and our recommended
build for almost all key-levels. This build does particularly well in lower level keys,
because you do not have to worry about managing [[spell:457052]]
against enemies that die very quickly, but even in high-keys it does great damage, albeit
less priority-target damage. This makes it a bit more comfortable and easy to play in an
environment where enemies might be dying fast, but you should probably get used to
the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker build if you plan on pushing title-level keystone
levels.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents Assassination Fatebound M+ Build
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAGYBmxoxsBYbAbGAMzMGD"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCgtBsZAwMzMMA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMOfGimCY4QaiS7D84pSooMPLLMMuuuqrN-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-JQkUhpBIgwgxxC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker M+ Build

2.2.

#### Recommended ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker Mythic+ Talents

This is the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathstalker.webp>) Deathstalker build for Assassination, and our best high-key Mythic+ build.
This build excels at high sustained priority-target damage in AoE, as trash packs tend to
live quite a bit longer in higher level keys than your weekly key runs. This build sports
incredible priority-target damage, both from [[spell:457055]] as well as your
ability to generate loads of Combo Points in AoE that you can channel into many
[[spell:32645]] casts. It is recommended to play this build at high-level push keys,
but for a more relaxing experience where you do not have to manage [[spell:457052]],
the Fatebound build is generally recommended instead.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents Assassination Deathstalker Mythic+ Build
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAbmlBGwCYZYCMsYwMDwYMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CMQAAAAAAAAAAAAAAAAAAAAAAYmlZmFDGAAAAAY2GsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsZWGYALglhJwwiBzMAjxA"
}
```
:::

:::details 来源计算器编码
```
#DE-FLMPDRVBMeINRp9Be8UJUmHhlFGGXXX1GnX-XbCEHSsELMagq+ADCGw8MposwRSKLzD-AAAA-GIOQaAGIogBFmF-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns, and Stops

3.1.

#### Interrupts

[[spell:1766]] is your, well, "kick". You will interrupt your targeted enemy, or,
when using a Focus-Macro, the target you set up as your focus.

#### Focus Kick Macro

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists,nodead] [] Kick
```

This macro will kick your focus target if you have one and your target if you have no focus
target. We recommend keeping both the macro and a regular kick cast on your bars,
as you may have multiple targets to interrupt, and the macro always prioritizes the
focus target.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro** or setting the "Focus Target" hotkey in the game's
keybinding settings.

#### Focus Macro

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

3.2.

#### Stunning and "Stops"

[[spell:6770]] and [[spell:2094]] can be useful to hard-crowd control
multiple mobs in a single trash pack. You can also use it right before the
tank is pulling, as [[spell:379005]] applies a damage reduction debuff
to the target when Sap breaks.

With [[spell:200733]] and [[spell:379005]] talented, [[spell:2094]] turns into a
low-cooldown AoE disrupt that also drastically reduces tank damage taken
for a short period, but it only works against targets that can actually be disoriented. It
will not work against large elites or bosses.

[[spell:1856]] can be used to [[spell:703]] enemies, silencing them thanks
to [[spell:196861]]. This is also a DPS increase due to [[spell:381632]],
so clever planning of your CDs will be rewarded with higher DPS. If you are unsure
about your usage of Vanish, err on the side of caution and use it for the silence
first and foremost, not for DPS.

[[spell:1776]] (if talented) can be used to disrupt enemies from casting otherwise
uninterruptible spells. This requires you to stand in front of the enemy but
can be used in many situations to keep enemies from using some of their most lethal
abilities. Many of these abilities go on cooldown once used, so disrupting them
with Gouge, [[spell:408]], or [[spell:2094]] will keep these mobs from
re-casting these abilities for a while.

[[spell:1856]] can also be used to [[spell:1833]] an enemy that
can only be stopped, not interrupted, but this is an absolute last resort play.

### Blind Skipping

3.3.

#### Blind Skipping

[[spell:2094]] is not part of our DPS kit, but still has some interesting use-cases in Mythic+ that may
not be immediately apparent. While [[spell:6770]] allows a player to safely pass a CC-ed creature without getting
into combat, a blinded enemy will walk around confused and still get into combat with the **first** player that
gets close to it. Once the Blind debuff ends, it will engage said player. It will not, however, get into combat
with any other player that gets close to it.

You can still make great use of Blind to pass enemies by abusing the fact that only one player
gets into combat with it. The best and easiest way to do this, is to ensure that after blinding the target, you
get close enough to enter combat with it, and then you and your entire group can pass the enemy. Once you
are far enough away from it, you can safely [[spell:1856]], drop combat, and skip the enemy.

This is particularly useful in situations where an entire pack of enemies is in your way that you would
like to skip, but one or two enemies are too close to pass by without body-pulling them. As a Rogue, you can
[[spell:6770]] one, and then use the above trick for the other, allowing you to skip past enemies that would either
detect you if you were to use [[spell:114018]], or if Shroud is on cooldown.

### Other Utility

3.4.

#### Other Utility

[[spell:114018]] projects AoE [[spell:1784]] around you. It
is important to note, however, that in the current expansion, there is a much
greater number of enemies who can detect through Stealth or Invisibility, whom
you will need to be on the lookout for.

[[spell:1725]] helps set up Shroud-skips and keeps patrolling trash
packs in place for 10 seconds. Make sure to force enemies to look away from you
to allow you to stealth past them.

[[spell:1966]], [[spell:31224]], [[spell:5277]],
[[spell:185311]] and [[spell:31230]] form a very powerful set of
defensive cooldowns and are one of the biggest reasons for Rogue's strength in
Mythic+.

[[spell:57934]] is not exceptionally great normally. However, any
kind of support that helps your tank keep aggro on all enemies is encouraged.
Sadly it is a choice-node with [[spell:379005]].

[[spell:5938]] can be used to dispel **Enrage** effects. Keep in mind
that this means you will not be able to use Shiv for DPS.

[[spell:5761]] and [[spell:381637]] are both useful in
Mythic+,
but with the heavier emphasis on trash mobs, [[spell:5761]] is likely
to win out on Fortified, with Atrophic gaining more value on Tyrannical weeks.
Communicate with your tank and healer which ones are preferable.

4.

### Dealing with Affixes

Season 1 of Midnight only has four significant Affixes that offer any kind
of counterplay, called Xal'ataths Bargains. These rotate every week, with only
one of them being active at a time. Many of the Mythic+ affixes, like Fortified or
Tyrannical, simply add a passive effect to the keystone, with these four exceptions
that are seasonally themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. [[spell:2094]] works great here as an AoE interrupt
  thanks to [[spell:200733]].
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn that
  needs to be focus-targeted and interrupted. If you know this is happening,
  make sure to hold some resources to switch to it.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and circle
  around them. You have 15 seconds to soak all of these to buff your group. Using
  [[spell:2983]] will help you soak these faster.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb. You can remove this with [[spell:31224]] or racials like Stone
  Form. Use [[spell:185311]] if these are unavailable to you, to help get rid of
  the debuff faster. Health potions or Healthstones also work well if your healer is out
  of resources.

Each of the affixes provides a different set of beneficial effects once it is dealt
with, and while they are very powerful, they are not something you play around
in a specific way. The most important part is to not let any of them buff the enemy
trash or bosses.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Page updated for Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Page updated for Patch 11.2 and Season 3, with weekly and high key build recommendations.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **21 Apr. 2025:** Switched to Bleed Build for Mythic+ and reviewed page for Patch 11.1.5.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated Talent builds for Patch 11.0.5.
- **09 Sep. 2024:** Updated for the start of Season 1 of The War Within.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **08 Nov. 2023:** Added disclaimer about talent build not being highest DPS option.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **06 Jun. 2023:** Updated for Exsanguinate bug.
- **01 May 2023:** Updated tips and tricks for Patch 10.1 Affix changes.
- **26 Mar. 2023:** Replaced Flying Daggers with Improved Poisons.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **05 Mar. 2023:** Updated Stat prio and Raging Affix description.
- **24 Jan. 2023:** Updated for Dragonflight Patch 10.0.5 changes.
- **04 Jan. 2023:** Updated talents and sample opener.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Assassination Rogue in World of Warcraft Patch 12.1.5.

1.

### Best Macros

You can use modifiers in case some abilities are "exclusive" to one another
without having to change your hotkeys or drag abilities into your hotkey bars
all the time. The syntax for these is as follows:

- [known:SPELLNAME] or [known:SPELLID]

and

- [noknown:SPELLNAME] or [noknown:SPELLID]

1.1.

#### Assassination-Specific Macros

Assassination is a very simple spec and has very little in terms of macros that can help
your DPS. The only relevant macro would be to macro [[spell:360194]] and your on-use trinket together.

#### Deathmark + Trinket Macro

```wow-macro
#showtooltip Deathmark
/cast Deathmark
/use 13
```

This is your first trinket-slot. If your on-use trinket is in the other trinket slot,
you will want to write /use 14 instead. Note that this will not work with [[item:193701@JAAIAAQkCYHKvbRLfA]]
due to the trinket having a cast-time.

2.

### Best Addons

2.1.

#### Generic Addons for Rogues

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.4.4.

##### TankMD

[TankMD](<https://www.curseforge.com/wow/addons/tankmd>) is a new addon 
  that was previously a WeakAura. It allows you to automatically target the tank of the 
  group with your [[spell:57934]] spell without needing a mouseover, focus target, swapping target
  or anything of that sort.

2.5.

#### Specific Addons for Assassination Rogues

Currently, we feel that there is no need for additional addons to play an
Assassination Rogue to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Page updated for Pre-Patch.
- **30 Nov. 2025:** Page was reviewed for Patch 11.2.7 and no changes were required.
- **05 Oct. 2025:** Page was reviewed for Patch 11.2.5 and no changes were required.
- **04 Aug. 2025:** Page was reviewed for Patch 11.2 and no changes were required.
- **15 Jun. 2025:** Page was reviewed for Patch 11.1.7 and no changes were required.
- **21 Apr. 2025:** Page was reviewed for Patch 11.1.5 and no changes were required.
- **24 Feb. 2025:** Page has been reviewed and updated for TWW Patch 11.1.
- **15 Dec. 2024:** Page has been reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Page reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Page has been reviewed and updated for Dragonflight Season 4.
- **21 Mar. 2024:** Page has been reviewed for Patch 10.2.6, no changes were necessary.
- **15 Jan. 2024:** Page has been reviewed and updated for Patch 10.2.5.
- **06 Nov. 2023:** Page updated for the Patch 10.2 Rogue rework.
- **04 Sep. 2023:** Page was reviewed for Patch 10.1.7 and no changes were necessary.
- **10 Jul. 2023:** Page was reviewed for Patch 10.1.5 and no changes were necessary as Assassination received no changes for the Patch.
- **29 Apr. 2023:** Patch 10.1 required no changes to this page.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
