## 专精概览

Welcome to our Restoration Shaman guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to heal as a Restoration Shaman in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your output.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Restoration Mythic+ Resources

[NEW! Top Restoration Talent Builds](<https://raider.io/specs/restoration-shaman/talents>)

[Top Restoration Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/shaman/restoration>)

[Restoration Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=shaman--restoration>)

[Popular Restoration Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=shaman--restoration>)

1.

### Restoration Shaman Overview

[Restoration Shaman](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-guide>) is an extremely flexible specialization that shines
when healing groups of clumped players. They also have a variety of unique tools 
to deal with otherwise deadly influxes of damage, such as [[spell:98008]], 
and many utility options such as the only healer interrupt in [[spell:57994]] 
or the burst movement provided by [[spell:192063]].

In order to properly play a healing role, you will need more than
just class-specific information. To better understand healing in general, we
recommend that you read our [healing guide](<https://www.icy-veins.com/wow/healing-guide>).

Stacked RNG Healing Specialist

Restoration Shaman has strong healing CDs, including the unique

[[spell:98008]]

which redistributes health among nearby players.

[[spell:73920]]

plays a central
role in healing on Season 2 due to buffs and the new tier set bonus which randomly
creates a Rain on your healing targets, which makes good RNG and group stacking
be important for high healing throughput.

[[spell:378270]]

and

[[spell:1267016]]

procs are also important random factors for healing, making Restoration capable
of doing the best or weak healing depending on luck.

Versatile Healer

Restoration Shaman is a fine pick for raiding that can easily flex between being
a spot and a raid healer with its versatile Hero Talents. They also have powerful
unique tools such as

[[spell:98008]]

and a personal combat resurrection
with

[[spell:20608]]

, both of which are particularly good against difficult
raid mechanics or during raid progression. They also bring one of the best raid
buffs,

[[spell:462854]]

, ensuring you always want at least one Shaman in any group.

Melee Party Dungeon Star

Restoration Shamans perform very well in Mythic+ as they are the only healer with
an interrupt in

[[spell:57994]]

and also have a lot of crowd control that helps
mitigate the dangerous parts of the dungeons. They can also do decent damage when
not pressured to heal heavily through

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer

Ancestors and

[[spell:378443]]

.
Their main weakness is that their healing output potential against sustained area
damage is only average, and heavily depends on everyone being stacked inside

[[spell:73920]]

,
but this weakness can easily be surpassed by joining melee-heavy groups, which tend
to also value

[[spell:462854]]

the most!

Spells For Everything

Healing Shamans have access to perhaps the strongest utility kit of all healers,
with their powerful raid buff

[[spell:462854]]

and unique cooldown

[[spell:98008]]

,
but they can also self-resurrect with

[[spell:20608]]

and remove most types
of debuffs from their groups with

[[spell:383016]]

,

[[spell:383013]]

,
and

[[spell:8143]]

, or buffs from enemies with

[[spell:370]]

. This allows
them to bring a solution to almost all utility problems by themselves.

Great Survivability Passives

The first line of defense for Shamans is the extra health provided by

[[spell:381689]]

and

[[spell:207401]]

, as their active defenses are not particularly powerful
and tend to have long cooldowns.

[[spell:108271]]

and

[[spell:198103]]

with

[[spell:1279819]]

are good defensive options, regardless.

[[spell:20608]]

,
while powerful, is also tied to a very long cooldown that does not reset on pull.
Finally,

[[spell:355630]]

is rarely a factor, but can be extremely powerful whenever
you can get full value out of it.

Diverse Mobility Tools

Restoration has decent mobility but suffers from over-reliance on

[[spell:79206]]

to perform its cast-heavy raid rotation on heavy movement encounters, which in turn
depends on having Evokers to use

[[spell:374968]]

to reset its cooldown. For
other movement, you are left with saving

[[spell:61295]]

s or

[[spell:73685]]

to use while moving. If casting while moving is not an option,

[[spell:192063]]

,

[[spell:58875]]

, and

[[spell:2645]]

are serviceable ways to quickly get
where you need to go, with Gust being particularly notable for breaking knockback
effects, while Spirit Walk breaks slows and roots. Finally,

[[spell:192077]]

allows your whole group to move faster and you can upgrade it with a lower cooldown
or snare removing effect!

2.

### Restoration Shaman in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

There are no changes to Restoration Shaman in Patch 12.1.5 however it introduces 
one new Raid encounter, Kith'ix, and a new and exciting type of [Delves](<https://www.icy-veins.com/wow/delves-guide>): 
the Labyrinth of Kindo'jan!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

There are no changes to Restoration Shaman in Patch 12.1.5, but you can find 
updated recommendations on our [gear](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>) 
page regarding new item drops from the new Raid as well as how to spend your 
[[item:280562]].

2.3.

#### Class Changes

Unfortunately, Restoration Shaman received no changes in Patch 12.1.5. However, we have
updated our [gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>) with new information
on the [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) gear, as well as recommendations on how to
spend your first [[item:280562]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritlink.jpg>)Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Changes

A new major patch means there is a ton of new content to explore! Besides new 
PvE and PvP endgame content, there is also a new zone to discover, which contains 
new rares and treasures to hunt, and there were multiple new housing and transmogrification 
items added. Blizzard also made a lot of updates to existing systems and added more 
quality of life improvements, such as better options for tracking item cooldowns 
and healer buffs on the default Cooldown Manager.

2.5.

#### Season 2 Class Changes

Restoration Shaman's core design has been kept the same in Season 2, but there 
are large buffs to [[spell:73920]] and [[spell:61295]], as well as the new 
[[spell:1312843]] talent and new tier set which will shake talent builds and 
rotational priorities. Overall, Restoration is looking to be an even stronger healer 
in Mythic+ where it was already strong and could easily be one of the dark horses 
of the RWF Raid race if the encounters are suited towards its strengths!

Thus, make sure to check out new [Talent](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>) 
recommendations, adjusted [rotational](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>) 
priorities and the new [gear](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>) recommendations!

Listed below you will find a full set of class and spec changes for Patch 12.1.

[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Restoration Shaman**

<em>Developers’ notes: We’re adjusting several talents and doing some tuning 
	for Restoration Shaman to improve upon several underperforming talents or interactions 
	that don’t feel very rewarding. We’re also improving the Chain Heal ability 
	from the Farseer Ancestors to increase their healing capabilities.</em>

- **Class**
  
  
  - [[spell:462477]] healing increased by 25%
  - [[spell:114052]] has a new icon for all three specializations.

- **Hero Talents**
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: Ancestor's [[spell:188443]] now hits up to 
    	  5 targets (was 3).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: Ancestor's [[spell:51505]] now also increases damage 
    	  by a percent equal to your critical strike chance.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: [[spell:1064]] from Ancestors now bounces to up 
    	  to 5 targets (was 3), loses 10% healing per target jump (was 30%), and had 
    	  its jump distance increased to 20 yards (was 15 yards).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: [[spell:1064]] from Ancestors healing increased 
    	  by 50%.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic: [[spell:445032]] now increases the healing 
    	  done by [[spell:444995]] by 10% (was 25%).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic: [[spell:444995]] now increases the effectiveness 
    	  of [[spell:73920]] by 10% (was 20%).

- **Restoration**
  
  
  - New Talent: [[spell:1312843]] – [[spell:5394]] and 
    		[[spell:1267016]] extend the duration of your active [[spell:61295]]s 
    		by 3 seconds when cast.
  - [[spell:77472]] healing increased by 10%.
  - [[spell:73685]] healing increased by 100%.
  - [[spell:73920]] healing increased by 20% and now heals up to 6 
    		targets in its area (was 5).
  - [[spell:73920]] now has a 12 second cooldown and an 18 second duration. 
    		Recasting Healing Rain while one is already active will despawn the previous 
    		one. This cooldown change does not affect the [[spell:444995]]'s Healing 
    		Rain from the Totemic Hero Talents.
  - [[spell:61295]] direct healing increased by 25% and its periodic healing 
    		increased by 100%.
  - [[spell:378443]] damage increased by 50%, but now causes damage every 
    		2 seconds (was 1 second).
  - Midnight Season 1 2-set bonus has been updated: [[spell:73685]]'s 
    		direct healing is increased by 50% (was 100%).
  - [[spell:1271104]] now grants an additive +20% to the healing buff 
    		from Unleash Life, rather than a multiplicative increase.
  - [[spell:404015]] now also reduces the mana cost of [[spell:1064]] 
    		by 15%.
  - [[spell:381946]] has been moved up in the talent tree.
  - [[spell:1252841]] has been removed.

:::

### Midnight   Changes Overview

2.6.

#### Restoration Shaman Changes in Midnight

The overall goal of the Midnight changes is to reduce healer burst 
healing capabilities and rotational complexity, and this is especially true for 
Restoration Shamans, which were already one of the easiest specs to pick up and 
are now perhaps the easiest healer in the game with almost half of their possible 
active buttons being gone in the Midnight, as well as almost all temporary 
buff effects to spells.

- These are the most important **core changes to the specialization tree**.  
  
  
   ► **Click to expand**
  
  
  - [[spell:157153]], [[spell:198838]], [[spell:207399]], 
    and [[spell:197995]] have been removed. **These were high-impact buttons which 
    often required good timing and skill to optimize.**
  - [[spell:157154]], [[spell:236501]], [[spell:200071]], [[spell:404522]], 
    [[spell:462375]], [[spell:1217525]], and [[spell:404019]] 
    have also been removed. **Some of these buffs were core to Restoration, and their 
    effects will now be baked into the spells they affected. [[spell:1064]] has 
    25% more jump range and 20% faster cast time in Midnight, while [[spell:77472]] 
    also casts 20% faster baseline.**
  - [[spell:73685]] was reworked to have a longer cooldown and higher healing 
    to compensate, as well as a new cast time reduction effect and support talent that 
    increases its healing further.
  - [[spell:8004]] was replaced by [[spell:77472]] and now benefits
    from effects that worked with it before, such as [[spell:337974]].
    The new talent [[spell:1253090]] also makes it crit 12% more often.
  - [[spell:114052]] is now on a choice node with [[spell:108280]]
    and talents that worked with Ascendance now also work with HTT, such as [[spell:462440]]
    and [[spell:462443]].
  - [[spell:114052]] itself has been redesigned: while active [[spell:77472]] 
    always crits and hits a second ally for 50% effect and [[spell:1064]] hits 3 
    extra targets and loses only 10% healing per jump.
  - The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic hero talent [[spell:445035]] has been renamed to [[spell:445035]] 
    and increases the healing done by [[spell:108280]] by 25% on top of 
    its old effect which doubles [[spell:5394]] healing. **When combined 
    with the Ascendance change listed above, the intent is for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic to 
    favor Healing Tide Totem while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer prefers [[spell:114052]].**
  - [[spell:73920]] now lasts 18 seconds, but also has an 18-second cooldown
    baseline. This will make it more palatable to cast for non-![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic builds,
    but without [[spell:108287]] to move it, **18 seconds will often
    lead to losing healing when players move away before its duration and cooldown are
    finished.**
  - [[spell:207778]] no longer grants a 10% health increase to allies hit,
    but it can now be improved by the [[spell:1253014]] and [[spell:1252882]]
    talents, which strengthen its healing potential considerably.
- The **Shaman class tree also had multiple important changes**.  
  
  
   ► **Click to expand**
  
  
  - [[spell:1217622]] and [[spell:462477]] are now a 
    choice node in the Class tree instead of a Restoration specialization node.
  - [[spell:51490]] is now only learnable by Elemental, and is no longer
    available to Restoration, lowering their crowd control capabilities.
  - [[spell:108270]] and [[spell:108285]] have been removed and
    replaced with passive [[spell:1270375]] and [[spell:1270350]].
    **This removes active buttons with long cooldowns but relatively weak effects.**
  - [[spell:382215]] was changed to provide a flat movement speed bonus
    on top of extra movement speed when in [[spell:2645]] form.
  - [[spell:265046]], [[spell:381689]], and [[spell:382215]] 
    are now 2-pointers instead of a single point for the same effect.
  - [[spell:57994]] now has a 30-second cooldown instead of 12, but Restoration 
    Shaman is also the only healer still having an interrupt in Midnight and it spell 
    locks targets for 4 seconds instead of 2.
  - [[spell:355630]] was converted into [[spell:355630]], which now reduces
    all spell damage taken by 15% when [[spell:57994]] interrupts an enemy instead
    of being tied to the school of the interrupted spell, but no longer stacks and lasts
    6 seconds less.

Much of their unique utility is still intact, especially the parts that depend 
on the class tree, which should maintain Restoration Shamans as one of the best 
healers for 5 man groups, despite losing [[spell:51490]].

2.7.

#### Hero Talent Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer gained extra talents: [[spell:1270446]], [[spell:1270447]],
and [[spell:1270450]]. [[spell:443451]] also lowers the cooldown
of [[spell:61295]] by 2 seconds instead of 3 in the Midnight. The new talents are 
strong and make Farseer a great spot healer.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic also gained extra talents: [[spell:1260644]],
[[spell:1263288]], and [[spell:1260874]]. These further
support [[spell:5394]] and [[spell:108280]] healing 
which is a major theme of the tree.

2.8.

#### Apex Talents: Stormstream Totem

The Apex talents of Restoration Shamans are [[spell:1267016]], the 
two-pointer [[spell:1267093]], and final talent [[spell:1267120]]. 
As a whole, these apex talents grants [[spell:61295]] a small chance to proc a 
very powerful version of [[spell:5394]] which can be cast without using 
regular HST charges once you fully unlock the talent. [[spell:378081]] 
(or [[spell:443454]]) also grant a proc when used.

The proc stays active for up to 60 seconds and stacks twice, allowing you ample 
time to wait for the best time to use it, although you will generally want to 
do so before both charges of regular [[spell:5394]] are ready to avoid 
wasting potential uses.

2.9.

#### Rotational Aspects

With many healing buttons having been pruned, you will mostly be casting [[spell:73685]], 
[[spell:61295]], [[spell:5394]], and [[spell:73920]] on cooldown, 
and filling in the rest of the time with [[spell:77472]] for single target 
healing or [[spell:1064]] for area healing.

2.10.

#### Cooldown Adjustments

[[spell:98008]] and either [[spell:108280]] or
[[spell:114052]] will still be used to counteract periods of high
damage, but you will no longer have access to both at the same time as they are 
now on a choice node with each other.

[[spell:462440]] and [[spell:462443]] used to support Ascendance and 
now also work for Healing Tide Totem but [[spell:378270]] is still 
only tied to Ascendance, making it slightly weaker for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic due to 
the new [[spell:445035]] and [[spell:1260874]] talents which boost the 
performance of [[spell:108280]].

3.

### Basics of Restoration Shaman Gameplay

Restoration Shaman, like any healer, is all about using your abilities
strategically. Rather than a fixed rotation, you will be using your flexible
spell kit to adapt and overcome whatever the game throws at you.

Cooldown abilities such as [[spell:61295]], [[spell:73685]] and [[spell:73920]]
are very efficient, and thus important to use as many times as possible throughout a fight.
Meanwhile, the likes of [[spell:77472]] and [[spell:1064]] can be thrown in 
at any time they are needed, as long as you still have Mana left. Restoration can be further 
condensed into the following three main tenants.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_unleashweapon_life.jpg>) **Keep Rotational Spells on Cooldown**  
  
    Most of your healing as a Restoration Shaman comes from short cooldowns such as 
    [[spell:73920]], [[spell:5394]], and [[spell:61295]]. These 
    spells should be kept on cooldown as much as possible, although many of them also 
    have charge systems where you can keep them on cooldown while saving most of the 
    charges for when big damage happens.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritlink.jpg>) **Plan Major Cooldowns**  
  
  [[spell:98008]], [[spell:108280]] and [[spell:114052]] 
    are your major cooldowns, and allow you to save the raid against massive incoming 
    damage. As most encounters and dungeons have specific abilities that cause massive 
    damage, it is often a good idea to save these cooldowns to deal with them, in 
    coordination with other healers in your group.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_watershield.jpg>) **Mana Management**  
  
    Due to the high cost and no cooldown of [[spell:1064]], you can exhaust your 
    Mana pool quite fast when focusing heavily on area healing, especially in long 
    encounters. Thus, you will want to make sure to pace yourself and mix in plenty 
    of [[spell:77472]] and DPS spells during low damage periods in order to make 
    your Mana last throughout the whole encounter.

4.

### How to Gear Up as a Restoration Shaman

While we always recommend simming yourself for ideal results, we do provide a
dedicated Restoration gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **02 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Changed gear and coining recommendations to account for stat changes.
- **01 Sep. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated with a cheatsheet of recommended utility talents for each S2 dungeon.
- **26 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for the latest gear stat changes.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for Midnight Season 2 launch.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for Midnight Season 2 launch.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Midnight Season 2 launch.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Season 2 launch.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Midnight Season 2 launch.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Midnight Season 2 launch.
- **10 Aug. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Midnight Season 2 launch.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Season 2 launch.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Midnight Season 2 launch.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for Midnight Season 2 launch.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Midnight Season 2 launch.
- **10 Aug. 2026 (this page):** Updated for Midnight Season 2 launch.
- **30 Jun. 2026 (this page):** Added information on the latest 4% healing buff hotfix.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Added Sporefused items to Best in Slots lists with the release of Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Revised the value of Haste up due to our much improved Mana economy.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Added an Omnium Folio section with the release of Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **19 May 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated voidcore recommendations, new best in slot table format and trinket recommendations.
- **19 May 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Added a potion recommendation section.
- **19 May 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated Mythic+ talent recommendations to Totemic.
- **19 May 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated Mythic+ talent recommendations to Totemic and explanation text.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **01 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Adjusted trinket recommendations after many trinkets were heavily buffed.
- **30 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated Gunshoes cancel macro.
- **30 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** General gear, embellishment, and trinket recommendation updates.
- **30 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated with more information on diminishing returns and stat priorities.
- **30 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated the utility cheatsheet.
- **30 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Adjusted rotations for the new talent recommendations.
- **30 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated with current meta talents.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Trinket tier adjustments post hotfixes.
- **17 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated with latest sim info for longer fights.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Midnight Season 1 launch.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1 launch.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Added a quick import string for Level 80 leveling.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for Midnight release.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for Midnight release.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Midnight release.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Midnight release.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for Midnight release.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Midnight release.
- **26 Feb. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for Midnight release.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight release.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Midnight release.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for Midnight release.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Midnight release.
- **26 Feb. 2026 (this page):** Updated for Midnight release.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Patch 12.0.1 updates and recommendation adjustments.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Patch 12.0.1 updates and talent recommendation adjustments.
- **10 Feb. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Patch 12.0.1 updates and rotation recommendation adjustments.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Patch 12.0.1 updates and recommendation adjustments.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Tidal Waves added, Whispering Waves removed.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Patch 12.0.1 updates and talent recommendation adjustments.
- **10 Feb. 2026 (this page):** Added a Patch 12.0.1 section.
- **27 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated Farseer raid rotation with the best practices from pre-patch raiding.
- **27 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated Farseer raid talent build with the best practices from pre-patch raiding.
- **24 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Typo fix with Totemic raid talents.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 (this page):** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7, revamped Strength and Weaknesses into Performance Review.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated DISC Belt post nerfs and added Puzzling Cartel Chips section.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5 with new sections on Legion Remix and Turbo Boost.
- **07 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Season 3 assuming tier set now that enough time has passed since launch.
- **15 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Added new recommended tags with and without new tier set bonuses.
- **10 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Small adjustment on Whispering Waves stat priority.
- **10 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Added more information on targeting when using Whispering Waves.
- **10 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Now recommend the Whispering Waves talents for raiding.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated with Season 3 gear and new recommendations.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Season 3 with new healing potion and augment runes.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for Season 3 and different stats for the new Whispering Waves talent build.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Revamped stat priority and reviewed for Season 3.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated with new format for Season 3, including new tier set rotational impact analysis.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Season 3 assuming no tier set is present.
- **04 Aug. 2025 (this page):** Updated for Season 3 with changes and the new Reshii Cloak.
- **16 Jun. 2025 (this page):** Added information on the new Combat Assistant feature.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Added a new section about the new "DISC" Belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added information on the new Combat Assistant feature.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Added information on the new Combat Assistant feature.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Added information on the new Combat Assistant feature.
- **15 Jun. 2025 (this page):** Updated with information on Patch 11.1.7.
- **28 May 2025 (this page):** Updated with Farseer buff hotfixes and first impressions.
- **13 May 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Revamped Farseer M+ talents based on top key pusher.
- **29 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Added more information on the upcoming Cartel Chip gear acquisition.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated with the changes of Patch 11.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Added Corruption Enchants information.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.5.
- **23 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated gear listings and Cyrce's Circlet gem recommendations.
- **23 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** New utility cheatsheet image with root totem and more clear indications.
- **23 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated talents for the current Season 2 meta.
- **18 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** Cleaned up Gallywix section.
- **03 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** Minor cleanups.
- **03 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Minor cleanups.
- **02 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** Added tips for all bosses.
- **02 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Added an utility cheatsheet image and tips for all dungeons.
- **02 Mar. 2025 (this page):** Removed old changes.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated with the changes of Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated with the new gear of Patch 11.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated with the changes of Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated with the changes of Patch 11.1.
- **24 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** First pass on Undermine boss suggestions.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated with the changes of Patch 11.1.
- **24 Feb. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated with the changes of Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated with the changes of Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated with the changes of Patch 11.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated with the changes of Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated with the changes of Patch 11.1.
- **24 Feb. 2025 (this page):** Updated with the changes of Patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated with the first calculations on Circle's Circlet gem optimizations.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated with Patch 11.0.7 information on Circle's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Stat priority reviewed and explanations updated.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** Updated the Ovinax build and added a new one for Ansurek.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Added recommended builds and minor talent recommendation adjustments for ease of play.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated with an easier to follow rotation and talent suggestions.
- **15 Dec. 2024 (this page):** Updated with Patch 11.0.7 information.
- **24 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** Slight adjustments to Ovinax recommended talents.
- **24 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Adjustments to the recommended Mythic+ talent builds.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for Patch 11.0.5 and new talent trees.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.5 and new suggested talents and timings for Ovinax.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.5 with a new section on talent adjustments for each dungeon.
- **21 Oct. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.5 with new rotational tips for Farseer Riptide build and new talent.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Patch 11.0.5 and new talent tree.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for Patch 11.0.5 with the Poison Cleansing Totem nerf.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Patch 11.0.5 with new talents.
- **21 Oct. 2024 (this page):** Updated with the changes of Patch 11.0.5 and first thoughts.
- **06 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** Tips added for most bosses.
- **06 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Raid talent adjustments and typo fixes in talent details section.
- **15 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Added a note on Weapon Oils.
- **15 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Added Farseer Chain Heal raid build and revamped Delve build.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Removed pre-season gear list and added a note on two-handed weapon crafting for crest savings early on.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Added tips for dealing with the new Mythic+ affixes.
- **09 Sep. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **29 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Added an Ancestor-tracking weak aura.
- **27 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Embellishment and crafted gear suggestion updates based on recent tuning.
- **25 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** More trinket ranking updates based on first comprehensive sims.
- **25 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** More trinket ranking updates based on first comprehensive sims.
- **25 Aug. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** More trinket ranking updates based on first comprehensive sims.
- **25 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** More trinket ranking updates based on first comprehensive sims.
- **24 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Added a recommended Delves build.
- **23 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated with S1 dungeon, raid, and trinket best in slot tables.
- **23 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Added more weak auras for The War Within.
- **23 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated with diminishing returns stat tables and Raid vs Mythic+ stat priorities.
- **23 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Added Mythic+ utility sheet for Season 1.
- **23 Aug. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added more S1 trinkets.
- **23 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Added more easy to use trinkets.
- **22 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for The War Within launch.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for The War Within launch.
- **21 Aug. 2024 (this page):** Updated for The War Within launch.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/restoration-shaman-mists-of-pandaria-remix-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for The War Within pre-patch and new Tier Set bonuses.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **22 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/restoration-shaman-the-war-within-pve-guide>)):** Massive update to reflect current Beta state.
- **22 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **18 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/restoration-shaman-the-war-within-pve-guide>)):** Page added.
- **17 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/restoration-shaman-mists-of-pandaria-remix-guide>)):** Updated recommended gems based on release tuning.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/restoration-shaman-mists-of-pandaria-remix-guide>)):** Page added.
- **11 May 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated recommended talents.
- **11 May 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated recommended talents.
- **11 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated recommended talents.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **01 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated Mythic+ Utility chart.
- **26 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Further updates with live data.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated with new gear, trinkets and embellishments for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Season 4.
- **22 Apr. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **25 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.6.
- **18 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **10 Feb. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Typo fix on the description of Wind Shear.
- **20 Jan. 2024 (this page):** Added upcoming 23th Jan hotfix buffs.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **27 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Added the wings of Dawn of Infinite where each piece of loot drops.
- **24 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated and added big on-click version of the utility per dungeon picture.
- **15 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Added image on how to spec utility talents for each dungeon.
- **09 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Various typo fixes.
- **09 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Typo fixes.
- **09 Nov. 2023 (this page):** Various typo fixes.
- **08 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated embellishment recommendations post Undulating Sporecloak nerf.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated with new gear, trinkets, and embellishments for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Added info on when Haste can be good with new tier set in Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Added a new talent build for Patch 10.2 and new Season information.
- **06 Nov. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated with new trinkets for Patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated with new talent builds for Patch 10.2 and Ascendance nerfs on talent descriptions.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Small adjustments to Ascendance description after Patch 10.2 nerfs.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated with new talents and trinkets for Patch 10.2.
- **06 Nov. 2023 (this page):** Added Patch 10.2 changes and commentary, as well as general revisions.
- **06 Oct. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.2 and the new tier set bonus.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for 10.1.7 meta and added tabs to the best in slot gear block.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated with tab-based formatting.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Reviewed for Patch 10.1.7.
- **31 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Adjusted talents to the current Season 2 dungeon meta.
- **31 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reworked how multiple talent trees are shown in the guide.
- **31 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated with Ascendance's doubled radius in recent hotfixes.
- **31 Jul. 2023 (this page):** Updated with the 5% healing buff and Ascendance buff in recent hotfixes.
- **19 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Adjustments for Echoing Tyrstone nerfs.
- **11 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Further trinket list adjustments.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Patch 10.1.5 trinkets added to the list as well as a recap on what gear can be found within the new dungeon.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Explained the Onyx Annulet nerfs and its new status as a decent, but not great, ring.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **13 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Clarified that Ascendance and Guidance should not be used together.
- **13 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Changed recommended raiding talents to use Deeply Rooted Elements and various text updates.
- **13 Jun. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Clarified that Ascendance and Guidance should not be used together.
- **13 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Clarified that Ascendance and Guidance should not be used together.
- **06 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Added Thundering Paws as anti-Entangling tech.
- **10 May 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Added the new waist enchant, Shadowed Belt Clasp.
- **09 May 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Adjusted for Corrupting Rage May 9th bug fix.
- **05 May 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Adjusted Spore Tender recommendation post 72% nerf and for Corrupting Rage bugged state.
- **05 May 2023 (this page):** Small text change to reflect Spore Tender enchant 72% nerf.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Season 2 upgrade system recap, updated Embellishment recommendation, and added some trinkets.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Added Spore Tender enchant, Phial of Corrupting Rage, and Deviously Deviled Eggs.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated with new talents, affixes and tips for Season 2 of Dragonflight (Patch 10.1.0).
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Added information on the new Tier Set and how it changes the rotation.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Talent updates for Season 2 and the new Tier Set gameplay changes.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated with Earthgrab new duration, Explosive affix removal and other changes of Patch 10.1.0.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Changed recommended talents and trinkets for Dragonflight Season 2.
- **01 May 2023 (this page):** Updated with commentary on the minor changes in Patch 10.1.0.
- **30 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.
- **30 Apr. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added Dragonflight Season 2 trinkets.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Further Onyx Annulet updates.
- **23 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated post multiple gem buffs for the Onyx Annulet making it worth using.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated post multiple gem buffs for the Onyx Annulet making it worth using.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated talents and rotation for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/restoration-shaman-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Added information on the new Onyx Annulet ring.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Added two more weak auras to support 10.0.7's new playstyle.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated with the Onyx Annulet for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated talents for Patch 10.0.7.
- **20 Mar. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated trinkets for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated rotation for Patch 10.0.7 and added Weak Auras link to addons guide page.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated talents for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated with the new spells and talents of Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated talents and rotation for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated with Patch 10.0.7 thoughts on Shaman talent tree revamp.
- **10 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Cloudburst Totem is now the default recommendation.
- **10 Mar. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Increased priority for Acid Rain usage.
- **10 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Added spell combo infographic.
- **10 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Further updates before patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Updated with 10.0.5 buffs.
- **21 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Revamped trinket recommendations and raid best in slot suggestions.
- **13 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Added Embellishment recommendations and Primal Ritual Shell.
- **13 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Changed talent build to include Acid Rain.
- **13 Dec. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added Primal Ritual Shell.
- **13 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Adjusted talents further for both Mythic+ and Raid.
- **13 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Added Primal Ritual Shell.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **30 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Added leg enchants from Tailoring Spellthreads.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([Legendaries](<https://www.icy-veins.com/wow/restoration-shaman-best-legendaries-shadowlands>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/restoration-shaman-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/restoration-shaman-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/restoration-shaman-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/restoration-shaman-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **02 Aug. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Revamped trinkets for S4.
- **31 May 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Page reviewed for Patch 9.2.5.
- **23 Mar. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Revamped stat priority for DPSing in current meta.
- **07 Mar. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added more DPS trinkets.
- **02 Mar. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-2-changes-analysis>)):** Added info on Vesper Legendary nerf hotfix.
- **22 Feb. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added more Legendary and trinket info for DPS purposes.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-2-changes-analysis>)):** Page reviewed and approved for Patch 9.2.
- **21 Feb. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Page reviewed and approved for Patch 9.2.
- **25 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-2-changes-analysis>)):** Updated with the latest PTR changes.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** Updated the page for Patch 9.1.5 release.
- **27 Aug. 2021 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Reworked the trinket list.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** Updated for Mythic Raiding and Covenant Legendary release week.
- **29 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** Updated the page for Patch 9.1 release.
- **29 Jun. 2021 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added Covenant-specific Legendaries considerations.
- **13 Jun. 2021 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Revamped the Legendary priority.
- **12 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** Added new legendary and PvP talent information.
- **28 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/restoration-shaman-patch-9-1-changes-analysis>)):** Page created with initial testing information.
- **09 Mar. 2021 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Changed the DPS rotation slightly to account for the 9.0.5 Lava Bust nerf and Chain Lightning buff.
- **22 Dec. 2020 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added a mention to Shadowlands DPS trinkets with examples.
- **05 Dec. 2020 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added weak auras to help with the DPS rotation.
- **24 Nov. 2020 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Page updated for Shadowlands launch.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **12 Oct. 2020 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Updated for Shadowlands pre-patch.
- **21 Jan. 2020 ([DPS guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)):** Added DPS guide for Restoration Shaman.
- **14 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **14 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-the-eternal-palace-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **14 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-the-eternal-palace-raid-guide>)):** Added the final mythic boss tips.
- **20 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-the-eternal-palace-raid-guide>)):** Added mythic boss tips for the first four bosses after killing them.
- **07 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-the-eternal-palace-raid-guide>)):** Page added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **11 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** Removed mention to PTR testing as the guide is now 100% complete for live servers.
- **06 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** Added Mythic Uu'nat recommendations post kill videos.
- **27 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** Added Mythic Cabal recommendations after killing it on live.
- **20 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** Added a recommendation to use Tremor Totem if a cast of Terrifying Echo will go through.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-crucible-of-storms-raid-guide>)):** Guide added.
- **09 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** Added mention to Tremor Totem temporarily dispelling the Mind Control totem at Rastakhan.
- **16 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** Changed the recommended talents for Jaina Mythic and added an explanation to the text.
- **14 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** Removed mention of the Spouting Spirits and Ascendance combo, as it no longer works in Patch 8.1.5.
- **02 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** Added new Jaina Mythic tips.
- **07 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** Corrected some typos and updated tips for Stormwall Blockade and Jaina Mythic encounters.
- **05 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** Tweaked some recommendations and added extra input based on live experience.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-battle-of-dazar-alor-raid-guide>)):** Added boss by boss guide for Restoration Shaman in Battle of Dazar'alor.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **10 Oct. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** Minor typo and talent fixes and added extra tips for Mythic G'huun.
- **08 Oct. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** Updated talent and boss information based on our full Mythic progression experience.
- **12 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** Added Tremor Totem boss information and other tips.
- **02 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** Added talent cheatsheet.
- **11 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** Updated some talent recommendations.
- **07 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** Updated MOTHER, Zul and Mythrax recommendations.
- **05 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** Added preliminary Uldir guide for Restoration Shamans.
- **28 Jul. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-uldir-raid-guide>)):** Removed Legion content in preparation for BfA.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Restoration Shaman leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Shaman leveling guide](<https://www.icy-veins.com/wow/shaman-leveling-guide>).

1.

### Restoration Shaman Leveling Guide for Midnight

As a healer, Restoration Shaman is slower than DPS or Tank specializations
when solo leveling, and recommended to be played in a group through the dungeon
finding queue or as part of a group farming specific enemies in the world for experience.

:::details FAQCan I Level as Restoration?
You can, but there is really no good reasons to do so. The playstyle in any of the
talent builds is the same as the specs they mimic, but with much lower damage. If
you choose to still level as Restoration, make sure you try to avoid any gear with
Mastery on it, and any trinkets with damage procs or on-use effects can be helpful
in taking down tougher opponents.

:::

:::details FAQWhat is the Best Race for Restoration Shamans?
The best race for Alliance players is Dwarf (

[[spell:20594]]

and

[[spell:59224]]

), while Horde players should go Tauren for PvE
(

[[spell:154743]]

) or Orc (

[[spell:20573]]

) for PvP.

:::

:::details FAQWhat is the Best Loa for Zandalari Restoration Shamans?
The Critical Strike buff provided by

[[spell:292361]]

is currently the
best choice available.

:::

You should still be contributing whatever DPS you can through [[spell:378443]],
[[spell:188443]] and your single target damage spells, as healing requirements
while leveling are usually low.

1.1.

#### Leveling Gear Options

When leveling up, you should always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level, but two secondary stats on it
instead of one.

When purchasing Heirloom Items for Leveling in general, we recommend picking
the Heirloom items that have the highest amount of Haste possible. Having high Haste
is a large DPS contribution and makes the rotation feel better to perform.

Haste is also useful for being a little bit quicker to tag mobs around you.
A split second can make the difference between you getting a tag or losing
it to another player.

1.2.

#### Useful Leveling Consumables in Midnight

There are several consumable items that can be purchased that will help you with 
your leveling speed.

- Ideally you want to have a flask buff running through the leveling process. 
  [[item:191348]] (from level 61) needs refreshing often but gives 
  Speed, which is typically more useful than combat stats for leveling. If you 
  prefer combat stats, we recommend [[item:212277]] which is 
  usable from level 71 onwards.
- Food buffs are not quite as impactful as flasks with the exception of 
  [[item:225592]] (requires level 75) which gives massive Speed. 
  Otherwise, try [[item:172063]] or [[item:133576]] as those will also 
  give you Speed after killing an enemy.
- Healing potions will help minimize downtime by allowing you to play more aggressively 
  without having to heal yourself as much. Use level-appropriate ones, such as 
  [[item:244835]] from level 71 onwards.
- The [[item:60854]] toy can be used to retrieve loot from a nearby corpse.
- [[item:109076]] is very useful for covering long distances from
  high places.
- [[item:132516]] are an Engineering item that increase your movement
  speed by 200% for 25 seconds. These will make you almost as fast as a Flying
  mount. We recommend having a lot of these, and using them whenever you are
  traveling more than ~250 yards.

The Gunshoes will not let you stop moving as long as they are active. Using this 
macro twice will click the buff off and allow you to stop.

#### Gunshoes Cancel Macro

```wow-macro
#showtooltip
/use Gunshoes
/cancelaura Gunshoes
```

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point allocation of the below 
tree once you start gaining levels in Midnight.

:::talents Restoration Level 80 Midnight Leveling
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzMzMzYmhBjFYAAzCTgxCDwsNzY0stMzwMzgFzMzYglBAAAYGAMzgZgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzMzMzYmhxiZWgBMgZhJwYhBY2mZMa2WmZ2MzMLsYmZGDmlBAAAYGAMzgZwM"
}
```
:::

:::details 来源计算器编码
```
#IE-EPUOTKLFqxNMstF0WZ6J1hx7gRqaTRJQLkQB-FMLHGEC4UOniMgUiCiILBrB1y56C45B-AAAA-OEYoQMohZBRoAA-BEI
```

:::

2.1.

#### War Mode Talents for Leveling

In this section, we will rank the PvP talents best for
leveling and doing solo / small group PvE content. Below is a ranking of both
General PvP Talents and Restoration Shaman-specific PvE talents.

1. [[spell:204331]] replicates and reflects damage you take for a 
   decent duration on a short cooldown. This can be really strong when in a high
   damage area to deal some chip damage to targets around you and convert your
   health pool into additional damage.
2. **等级 30 起：**[[spell:290250]] makes [[spell:73920]] instant, 
   cheaper, and more effective. This has great synergy with [[spell:378443]] and also 
   with [[spell:204331]], as it will provide a lot of healing for you to 
   tank mobs with while they kill themselves.
3. **等级 40 起：**[[spell:460697]] significantly increases the critical 
   effect of spells of nearby allies for a short duration whenever you use [[spell:378081]]. 
   It is good for solo play and excellent if you are doing outdoor content with others.

**等级 20 起：**Other talents have their own niches but are not as
generally useful when leveling.

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider
to select your level, and watch as the leveling rotation grows with each
level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–9：**Starting at Level 1, you only have one main damaging
ability: [[spell:188196]]. This will change at level 10 when you
select Restoration as your specialization and unlock other abilities. Until then,
use [[spell:188196]] to kill targets and make use of [[spell:188389]]
when it unlocks at level 3, and of [[spell:192106]] once it unlocks at
level 9.

1. **等级 10–11：**Keep [[spell:192106]] active on yourself
2. **等级 12–15：**Keep [[spell:52127]] active on yourself
3. **等级 16 起：**Keep [[spell:52127]] active on yourself and [[spell:974]] on yourself and the tank
4. Cast [[spell:73920]] (with [[spell:378443]]) against 3+ enemies that will live through its duration
5. Apply [[spell:188389]] if it is absent
6. **等级 11 起：**Cast [[spell:51505]] whenever available
7. Cast [[spell:188443]] against two or more targets
8. Cast [[spell:188196]] as a filler on a single target

**等级 15 起：**Starting at Level 15, you are able to queue for dungeons
with the in-game group finder. You should aim to do this whenever possible while
in Restoration specialization, as it is an efficient way to level up while
learning your healing kit. In order to understand in-depth how to use this kit,
especially at higher levels, check out our [rotation
page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-rotation-cooldowns-abilities>), but we have added a summary below:

1. **等级 71–73：**Use [[spell:73685]] on cooldown to spawn Ancestors
2. **等级 74 起：**Use [[spell:73685]] and [[spell:443454]] on cooldown to spawn Ancestors
3. Cast [[spell:61295]] and [[spell:5394]] whenever possible
4. Cast [[spell:1064]] if multiple people in your group are hurt and close to each other
5. Cast [[spell:77472]] on damaged allies
6. Use your DPS rotation (detailed above) if no healing is required

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2 launch.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **30 Mar. 2026:** Updated Gunshoes cancel macro.
- **16 Mar. 2026:** Updated for Midnight Season 1 launch.
- **02 Mar. 2026:** Added a quick import string for Level 80 leveling.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Patch 12.0.1 updates and recommendation adjustments.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated with the changes of Patch 11.5.
- **24 Feb. 2025:** Updated with the changes of Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5 and new talent trees.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **11 May 2024:** Updated recommended talents.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **25 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated talents and rotation for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Restoration Shaman in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Restoration Shaman

This section is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

Restoration Shaman is a healing specialization that excels at healing
group damage and burst single-target healing. They have a variety of cooldowns to
draw on that can suit any situation. In this section, we will be focusing on a
setup that minimizes the number of buttons while still providing flexible and potent 
healing at your fingertips.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_unleashweapon_life.jpg>) **Keep Rotational Spells on Cooldown**  
  
    Most of your healing as a Restoration Shaman comes from short cooldowns such as 
    [[spell:73920]], [[spell:5394]], and [[spell:61295]]. These 
    spells should be kept on cooldown as much as possible, although many of them also 
    have charge systems where you can keep them on cooldown while saving most of the 
    charges for when big damage happens.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritlink.jpg>) **Plan Major Cooldowns**  
  
  [[spell:98008]], [[spell:108280]] and [[spell:114052]] 
    are your major cooldowns, and allow you to save the raid against massive incoming 
    damage. As most encounters and dungeons have specific abilities that cause massive 
    damage, it is often a good idea to save these cooldowns to deal with them, in 
    coordination with other healers in your group.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_watershield.jpg>) **Mana Management**  
  
    Due to the high cost and no cooldown of [[spell:1064]], you can exhaust your 
    Mana pool quite fast when focusing heavily on area healing, especially in long 
    encounters. Thus, you will want to make sure to pace yourself and mix in plenty 
    of [[spell:77472]] and DPS spells during low damage periods in order to make 
    your Mana last throughout the whole encounter.

In Season 2, both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic had strong buffs, 
but Totemic is likely to be the easiest one to play due to its high passive healing, 
which allows you to perform well even if you are not pressing the optimal buttons 
on the moment to moment gameplay.

2.

### Beginner's Guide to Restoration Shaman in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic   Beginner Talents

2.1.

#### Beginner Talents for Restoration Shaman

These choices balance ease of use and raw power and **work for every type of 
content**. Although different talents might offer higher gains when played well, 
these same talents often result in healing losses when utilized by less experienced 
players.

The talents recommended below aim to present a setup that has very little
punishment for unfamiliarity or mistakes, minimal buttons to press or buffs, and
abilities to track, and also **includes the most used utility**. Shaman
is especially reliant on using **fight-specific talents** for its utility picks,
and you should swap talents around when needed, for example, to get [[spell:8143]]
against Fear effects.

Be sure to use the 'Export Talents' button to import our build when
playing!

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsBbwMW0YbAMDsZGmBbjZmpZbZmhZMbsMzMzYwsMAAAwMzgZGAYwM"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCVWqttx1NM0IVhp10qnHJaaxBCDwSGZq-FMcDHQqJQoIRtt9VGYIBCDEo56C1ZyC-AAAA-Jgko0AMowgxRmF-
```

:::

### Restoration Shaman   Basic Rotation

2.2.

#### Basic Rotation for Restoration Shaman

1. Keep [[spell:52127]] active on yourself and [[spell:974]] on yourself
   and the tank
2. Use [[spell:5394]] as an emergency heal or whenever you hit maximum
   charges, particularly whenever it is upgraded to [[spell:1267016]]
3. Use [[spell:444995]] and move it with [[spell:108287]] if there 
   are few people inside its area of effect
4. Cast [[spell:61295]] on cooldown
5. Use [[spell:1064]] on injured allies if group healing is needed
6. Use [[spell:77472]] to heal the most injured single players
7. DPS if no one is in danger to kill the boss faster

2.3.

#### Healing Cooldowns

Healing Cooldowns are meant to allow you to provide a big burst of healing
or survivability to your group. In exchange, each of them is typically only
usable once every 3 minutes. Below is a short description of each cooldown taken
in the above talent build and its basic applicability so that you can form an idea
of when it is best to use them.

[[spell:108280]] should be used when incoming group damage is high
but spread equally over the whole group. It provides high-spread healing over
a period of time and can be used while moving, which allows you to use it while
doing fight mechanics or casting other healing spells. It will always do its
maximum healing once you are hitting 5 targets or higher.

[[spell:98008]] grants damage reduction and also redistributes the health 
of members inside the totem every second, keeping everyone inside at equal levels 
of health percentage. This cooldown is best used when there are allies taking deadly 
damage near other allies who are healthy and is often **combined with damage reduction** 
raid or personal cooldowns and immunities, as the immune player will not take any 
damage from mechanics but still contribute to stabilizing the group through the 
totem's effect.

2.3.1.

##### Apex Talents: ![Stormstream Totem Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_shaman_manatidetotem.jpg>) Stormstream Totem

The Apex talents of Restoration Shamans are [[spell:1267016]], the 
two-pointer [[spell:1267093]], and final talent [[spell:1267120]]. 
As a whole, these apex talents grants [[spell:61295]] a small chance to proc a 
very powerful version of [[spell:5394]] which can be cast without using 
regular HST charges once you fully unlock the talent. [[spell:378081]] 
(or [[spell:443454]]) also grant a proc when used.

The proc stays active for up to 60 seconds and stacks twice, allowing you ample 
time to wait for the best time to use it, although you will generally want to 
do so before both charges of regular [[spell:5394]] are ready to avoid 
wasting potential uses.

2.3.2.

##### Season 2 Tier Set

Below are the S2 Tier Set Bonuses for Restoration Shaman in Midnight. 
After the wording of the bonus, you will find a brief note/commentary that is <em>italicised</em>.

- 2-set bonus — [[spell:77472]] and [[spell:1064]] have a chance 
  to create a [[spell:73920]] at their target's location for 8 seconds. <em>These 
  bonus rains benefit from your talents and activate talents such as [[spell:383222]] 
  and [[spell:462425]] but cannot be moved with [[spell:108287]], making 
  their actual healing dependent on landing on player clusters.</em>
- 4-set bonus — Every 1 sec, 1 ally inside of [[spell:73920]] gains 
  a watery shield that absorbs damage for 10 sec. <em>Absorbs tend to always get full 
  value in hard encounters and due to the extra rains from the 2-set bonus you will 
  be getting good value from this bonus in most situations.</em>

Overall this is another simple yet strong tier bonus, which has a lot of randomness 
involved in its 2-piece bonus. This randomness is minimized in stacked healing encounters, 
where Restoration already worked best, making this tier one where encounter design 
is particularly important for Restoration Shaman healing potential.

### Restoration Shaman   Stat Priority

2.4.

#### Stat Priority for Restoration Shaman

Currently, you will want to prioritize stats as follows.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>).

Item Level

Critical Strike

Versatility

Haste

Mastery

While we provide stat preference lists, swapping gear to higher **item level**
items — and their **higher Intellect** / total stats — should, usually,
provide a larger upgrade than using lower item-level items with better stats.
The exception to this rule are items with important tertiary stats such as **Leech**,
which should still be used ahead of other items without them unless the difference
in item level is around 7 or above.

### Blizzard   Combat Assistant

2.5.

#### Should I Use The Combat Assistant Feature?

For Restoration Shaman this will alternate between [[spell:188389]], [[spell:51505]], 
and [[spell:188196]] on two or less targets, or just spam [[spell:188443]] 
if three or more targets will be hit by it.

This is a great feature for starting players who might be overwhelmed with the 
amount of buttons Restoration uses, as it will free multiple DPS buttons while still 
allowing for decent damage output when healing is not needed.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2 launch.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Patch 12.0.1 updates and talent recommendation adjustments.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **07 Sep. 2025:** Updated for Season 3 assuming tier set now that enough time has passed since launch.
- **04 Aug. 2025:** Updated for Season 3 assuming no tier set is present.
- **15 Jun. 2025:** Added information on the new Combat Assistant feature.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated with the changes of Patch 11.1.
- **15 Dec. 2024:** Updated with an easier to follow rotation and talent suggestions.
- **21 Oct. 2024:** Updated for Patch 11.0.5 with new talents.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **25 Aug. 2024:** More trinket ranking updates based on first comprehensive sims.
- **23 Aug. 2024:** Added more easy to use trinkets.
- **21 Aug. 2024:** Updated for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **11 May 2024:** Updated recommended talents.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated with new talents and trinkets for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **31 Jul. 2023:** Updated with Ascendance's doubled radius in recent hotfixes.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **13 Jun. 2023:** Clarified that Ascendance and Guidance should not be used together.
- **01 May 2023:** Changed recommended talents and trinkets for Dragonflight Season 2.
- **20 Mar. 2023:** Updated talents and rotation for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Dec. 2022:** Added Primal Ritual Shell.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Restoration Shaman in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Restoration Shaman

In the current meta, both Hero Talent trees are viable, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic 
being the recommended one due to being much more forgiving for movement-heavy
fights. It has a larger amount of instant casts and the ability 
to reposition [[spell:444995]] with [[spell:108287]] frequently. 
Totemic also gets a lot of free [[spell:1064]] casts through [[spell:467306]], 
allowing it to do more area healing than Farseer in most situations, at the cost 
of having weaker spot-healing.

This is not to say that ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer isn't also viable, especially when you're
still using the full Season 1 tier set bonus, which boosts [[spell:73685]] instead of [[spell:73920]], 
making it more favorable for Farseer. Ancestor area healing was heavily buffed for 
Season 2 and so was [[spell:61295]], both of which are cornerstones of Farseer 
gameplay, making it much stronger than it was previously, and well worth playing 
if you enjoy a very active playstyle.

Also, make sure to adjust these builds to include any utility needed for specific 
encounters or dungeons, as the Shaman class tree is full of niche talents such as 
[[spell:8143]] which are usually useless, but can occasionally be invaluable.

**Quick Start Import Codes:**

:::talents Restoration Dungeons - Totemic
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsstMmZmZmZGjZMsBbwMW0YbAMDshxMMLzMGNLLzMbmxsxixMjhlZZAAAAzMYmBgxgZA"
}
```
:::

:::talents Restoration Raid - Totemic
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsBbwMW0YbAMDsZGmBbjZmpZbZmhZMbsMzMzYwsMAAAwMzgZGAYwM"
}
```
:::

:::talents Restoration Delves - Farseer
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzMzMzYmhxiZWgBMgZhJwYhBY2mZMa2WmZ2MzMLsYmZGDmlBAAAYGAMzgZwM"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Totemic

Raid

recommended

Mythic+

recommended

Farseer

Raid

Mythic+

Delves

recommended

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic Raid Talents

While these are the baseline recommended talents, feel free to swap to different
utility talents to suit your raid setup and boss-by-boss needs.

While [[spell:108280]] works well with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic due to the
new additional effect of [[spell:445035]] and new [[spell:1260874]] talent,
[[spell:114052]] has higher potential healing and allows for very
high single-target healing when active, while HTT is a pure raid healing cooldown,
making it a more flexible option.

The higher [[spell:114052]] uptime thanks to [[spell:378270]]
has great synergy with [[spell:16196]] through the guaranteed double [[spell:77472]]
crits on every cast, which are made faster by [[spell:462443]]. Its alternative
talent, [[spell:462440]], is a strong swap on fights with 2-minute raid damage
but is otherwise inferior due to much of your Ascendance uptime being based on random
procs.

[[spell:1064]] and its support talents combo well with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic
Hero talents as you will be able to cast many of them for free with [[spell:467306]]
whenever you use [[spell:5394]], which has a reduced cooldown thanks
to the new [[spell:1260644]] talent.

Finally, we skip [[spell:462488]] in favor of [[spell:61295]] talents such
as [[spell:382194]], [[spell:1312843]], and [[spell:381946]].
They are easier to use and do not represent a significant healing loss over
perfect usages of Downpour. While Downpour has great potential with the Season 2 set bonus,
it only does so your procced [[spell:73920]]s land at the correct spots at the
right time.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic Mythic+ Talents

While these are the baseline recommended talents, feel free to swap to different
utility talents to suit your group composition, target dungeon, and active weekly
affixes.

The general idea behind these talents is to give you high baseline healing and
utility, including picking [[spell:378443]] for extra passive DPS. [[spell:207401]]
is also a great talent to take to reduce the impact of burst damage on your allies.

[[spell:108280]] has good synergy with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic due to the
additional effect of the [[spell:445035]] and [[spell:1260874]] hero
talents, heals for a large amount instantly, and allows you to DPS or heal with
your spells while active, making it a stronger pick than [[spell:114052]]
in the current meta.

[[spell:1064]] and its support talents combo well with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic
Hero talents as you will be able to cast many of them for free with [[spell:467306]]
whenever you use [[spell:5394]], which has a reduced cooldown thanks
to the [[spell:1260644]] talent.

Finally, the new [[spell:1312843]] is picked alongside multiple [[spell:61295]]
support talents in order to allow you to consistently have everyone in your party covered
with your Riptide healing over time.

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer Raid Talents

While these are the baseline recommended talents, feel free to swap to different
utility talents to suit your raid setup and boss-by-boss needs.

Farseer has strong cast time healing due to [[spell:443447]] and
[[spell:1270447]], which compensates for having lower passive healing than Totemic
and a weaker [[spell:73920]].

The higher [[spell:114052]] uptime thanks to [[spell:378270]]
has great synergy with [[spell:16196]] through the guaranteed double [[spell:77472]]
crits on every cast, which are made faster by [[spell:462443]].

The choice between [[spell:462443]] and [[spell:462440]] comes down
to whether the healing cooldown plan for the boss you are doing requires you to
press Ascendance more often than 3-minutes or not, but by default Preeminence has
better synergy with [[spell:378270]] which we also spec.

Finally, we skip [[spell:462488]] in favor of [[spell:61295]] talents such
as [[spell:382194]], [[spell:1312843]], and [[spell:381946]]
because they synergize better with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer talents, and Downpour heals
for much less when used with [[spell:73920]] compared to [[spell:444995]].

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer Mythic+ Talents

While these are the baseline recommended talents, feel free to swap to different
utility talents to suit your group composition, target dungeon, and active weekly
affixes.

The general idea behind these talents is to give you high baseline healing and
utility, including picking [[spell:378443]] for extra passive DPS, which synergizes
well with [[spell:73920]] quality of life improvements for Farseer and the
Season 2 tier set bonuses. [[spell:207401]] is also a great talent to take
to reduce the impact of burst damage on your allies.

The choice between [[spell:462443]] and [[spell:462440]] comes down
to whether the key route you planned requires you to press Ascendance more often
than every 3 minutes, but by default, Preeminence has better synergy with
[[spell:378270]], which we also spec.

[[spell:73685]] allows for near-permanent uptime of one Ancestor, and is
a mandatory talent in ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer builds, which tend to have better spread
and spot healing due to stronger [[spell:77472]] casts with [[spell:443447]]
and [[spell:1270447]].

Finally, as the healing over time of [[spell:61295]] was massively buffed for
Season 2, it will be important to have high uptime on it on as many party members
as possible, making [[spell:382039]] less desirable than [[spell:382732]].

### 天赋方案 1-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer Delve Soloing Talents

While these are the baseline recommended talents, feel free to swap to different
utility talents to suit the kind of [Delve](<https://www.icy-veins.com/wow/delves-guide>) you are entering and its specific
challenges.

While Restoration is not particularly fast at clearing [Delve](<https://www.icy-veins.com/wow/delves-guide>)s in general,
it has the advantage of being able to do it while keeping itself healthy without
much effort through beefy self-healing with [[spell:77472]] and multiple cooldowns
that work surprisingly well when healing only yourself, and perhaps also a handful
of allies such as your [Delve](<https://www.icy-veins.com/wow/delves-guide>) companion.

For advanced players, swapping to [[spell:462477]] is actually very strong
because in a very small group setting [[spell:974]] is a major source of
healing and thus this talent accrues a lot of value from low count shield refreshes.
It is also much easier to refresh with the new [[spell:1270350]], which
refreshes all of your shields and buffs whenever you refresh [[spell:52127]].

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMYsBbwMW0YbAMDsZGmBbjZmpZbZmhZMbsMzMzYwsMAAAwMzgZGAYwM"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCVWqttx1NM0IVhp10qnHJaaxBCDwSGZq-FMcDHQqJQoIRtt9VGYIBCDEo56C1ZyC-AAAA-Jgko0AMowgxRmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsstMmZmZmZGjZMsBbwMW0YbAMDshxMMLzMGNLLzMbmxsxixMjhlZZAAAAzMYmBgxgZA"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCUWox1NM0IVhp10qnHJaxBDwSBAjgqSkC-FMDHRIQIR9FYACDsZaprLzMJC45xC1B-AAAA-Jgko0AMowgxRmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNjZGjZGzMMWMzGMgBMbMBGLmhZw2YmZa2WmZ2MjZjlZmZGDmlBAAAGzAgZGYwM"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCVWqttx1NM0IVhp10qnHZaxBCDwSGZQVB-FMcDHQKQoIRtt9VGYIBCDEo56C1ZyKD-AAAA-aYWIEKUOGYMEBA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZmltlxMzMzMzYMjxiZWgBMgZhJwYhZMDzyMjRzyyMzmZMbsYMz8ADLzyAAAAMDAmZYMYG"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCUWox1NM0IVhp10qnHZxBDwSBAjgSk+pC-FMDHRIQIR9FYACDsZaprLzMJ65xC1hD-AAAA-GcgohRIABgxShC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsssNzMzMzMzYmhxiZWgBMgZhJwYhBY2mZMa2WmZ2MzMLsYmZGDmlBAAAYGAMzgZwM"
}
```
:::

:::details 来源计算器编码
```
#IE-EPUOTKLFqxNMstF0WZ6J1hx7gRqaTRJQLkQB-FMLHGEC4UOniMgUiCiILBrB1y56C45B-AAAA-OEYoQMohZBRoAA-BEI
```

:::

The builds listed above are popular recommendations, covering various different 
talent loadouts suited to each style of endgame content. Each Talent Build will 
have its own rotation, and can also be manipulated further for specific types of 
content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new mechanic introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>) 
which grants a handful of small boosts which are unlocked as you complete a series 
of quests. Some bonuses improve throughput, while others are defensive.

We recommend the following choices. You are not locked into any option and can 
freely swap at any time so do not worry about making a mistake and feel free to 
experiment!

- Node 1:[[spell:1279599]]
- Node 2:[[spell:1279603]]
- Node 3:[[spell:1287555]]
- Node 4:[[spell:1279609]]
- Node 5:[[spell:1279614]]

The idea of this build is to make your instant smart healing from [[spell:1279599]] 
as powerful as possible, as that is the most impactful healing provided by this 
system, and to obtain Critical Strike from [[spell:1279609]] to further 
improve our healing and Mana sustainability through [[spell:16196]].

3.

### Restoration Shaman Apex Talent - Stormstream Totem

The Apex talents of Restoration Shamans are [[spell:1267016]], the 
two-pointer [[spell:1267093]], and final talent [[spell:1267120]]. 
As a whole, these apex talents grants [[spell:61295]] a small chance to proc a 
very powerful version of [[spell:5394]] which can be cast without using 
regular HST charges once you fully unlock the talent. [[spell:378081]] 
(or [[spell:443454]]) also grant a proc when used.

The proc stays active for up to 60 seconds and stacks twice, allowing you ample 
time to wait for the best time to use it, although you will generally want to 
do so before both charges of regular [[spell:5394]] are ready to avoid 
wasting potential uses.

4.

### Restoration Shaman Hero Talents

Upon reaching Level 71 on any specialization, players will gain access to one 
of two unique talent trees called Hero Talents. Restoration Shaman has the choice 
between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer is all about spawning **Ancestors**, mostly through [[spell:467646]]
and [[spell:443454]]. These are friendly NPCs that heal or deal damage
based on what spells you use while they are active, making this tree a solid all-rounder
that amplifies your burst healing potential. Hero Talents such as [[spell:443447]] 
and [[spell:1270447]] also make Farseer's base spells stronger than those of Totemic.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic is all about using **Totems**, and enables [[spell:444995]],
which replaces [[spell:73920]] with a longer duration instant cast which can 
be moved with [[spell:108287]]. This frees up a lot of casting time, especially
when combined with [[spell:467306]], and its free [[spell:1064]]s when using
throughput totems. These talents simplify gameplay greatly, at the cost of tying
your throughput potential even more to the small radius of [[spell:73920]].

5.

### PvP Talents (War Mode)

Enabling War Mode provides the following benefits:

- PvP talents that can be used in the outdoor world.
- 15% increase in World Quest rewards at max level.
- 15% more experience gained while leveling.
- Ability to earn Conquest Points in the outdoor world, which can reward powerful 
  gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility to be "ganked" while leveling or doing World Quests
exists.

In this section, we will explain the PvP talents and rank them on their
leveling and solo / small group PvE content usefulness.

1. [[spell:204331]] replicates and reflects damage you take for a 
   decent duration on a short cooldown. This can be really strong when in a high
   damage area to deal some chip damage to targets around you and convert your
   health pool into additional damage
2. [[spell:290250]] makes [[spell:73920]] instant, cheaper, and more 
   effective. This has great synergy with [[spell:378443]] and also with [[spell:204331]], 
   as it will provide a lot of healing for you to tank mobs with while they kill themselves
3. [[spell:460697]] significantly increases the critical effect of spells 
   of nearby allies for a short duration whenever you use [[spell:378081]]. 
   It is good for solo play and excellent if you are doing outdoor content with others.

The remaining talents have their own niches, but are not as generally useful
in PvE situations with War Mode active.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2 launch.
- **15 Jun. 2026:** Added an Omnium Folio section with the release of Patch 12.0.7.
- **19 May 2026:** Updated Mythic+ talent recommendations to Totemic and explanation text.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **30 Mar. 2026:** Updated with current meta talents.
- **16 Mar. 2026:** Updated for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Patch 12.0.1 updates and recommendation adjustments.
- **27 Jan. 2026:** Updated Farseer raid talent build with the best practices from pre-patch raiding.
- **24 Jan. 2026:** Typo fix with Totemic raid talents.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **15 Aug. 2025:** Added new recommended tags with and without new tier set bonuses.
- **10 Aug. 2025:** Now recommend the Whispering Waves talents for raiding.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **13 May 2025:** Revamped Farseer M+ talents based on top key pusher.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **23 Mar. 2025:** Updated talents for the current Season 2 meta.
- **24 Feb. 2025:** Updated with the changes of Patch 11.1.
- **15 Dec. 2024:** Added recommended builds and minor talent recommendation adjustments for ease of play.
- **24 Oct. 2024:** Adjustments to the recommended Mythic+ talent builds.
- **21 Oct. 2024:** Updated for Patch 11.0.5 and new talent tree.
- **06 Oct. 2024:** Raid talent adjustments and typo fixes in talent details section.
- **15 Sep. 2024:** Added Farseer Chain Heal raid build and revamped Delve build.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **24 Aug. 2024:** Added a recommended Delves build.
- **21 Aug. 2024:** Updated for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch and new Tier Set bonuses.
- **11 May 2024:** Updated recommended talents.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated with new talent builds for Patch 10.2 and Ascendance nerfs on talent descriptions.
- **04 Sep. 2023:** Updated with tab-based formatting.
- **31 Jul. 2023:** Reworked how multiple talent trees are shown in the guide.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **13 Jun. 2023:** Changed recommended raiding talents to use Deeply Rooted Elements and various text updates.
- **01 May 2023:** Talent updates for Season 2 and the new Tier Set gameplay changes.
- **20 Mar. 2023:** Updated talents for Patch 10.0.7.
- **10 Mar. 2023:** Further updates before patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Dec. 2022:** Adjusted talents further for both Mythic+ and Raid.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Restoration Shaman, depending on the type of damage your group
is receiving. We also have advanced sections about cooldowns, procs, etc.
in order to minmax your healing output and your mana efficiency. All our
content is updated for World of Warcraft Patch
12.1.5.

1.

### Restoration Shaman Gameplay and Rotation Guide

Welcome to our Rotation page for Restoration Shamans. On this page,
you will find everything you need to know about actually playing the spec in Raiding
and Mythic+ scenarios.

2.

### Restoration Shaman Pre-Pull Checklist

- [[spell:52127]] on yourself
- [[spell:974]] on tank and yourself

<em>Situationally: If the fight starts with high damage, cast [[spell:73920]] 
and as many [[spell:61295]]s as possible just before pulling.</em>

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer

Raid

Mythic+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic

Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:73920]]

[[spell:443454]]

[[spell:444995]]

[[spell:73685]]

[[spell:382039]]

[[spell:382309]]

2.1.

#### Healing Gameplay Priorities

1. **适用条件：Ancestral Awakening（启用）。** Use [[spell:5394]] / [[spell:1267016]] for emergency healing and whenever you hit maximum
   charges
2. **适用条件：Ancestral Awakening（未启用）。** Use [[spell:5394]] / [[spell:1267016]] for emergency healing, whenever you hit maximum
   charges, or while under [[spell:114052]]'s effect
3. **适用条件：Ancestral Swiftness（启用）。** Cast [[spell:73685]] and [[spell:443454]] to spawn Ancestors, proc [[spell:1267016]], and get a healing buff for your next cast
4. **适用条件：Unleash Life（启用）；Ancestral Swiftness（未启用）。** Cast [[spell:73685]] to get a healing buff for your next cast
5. **适用条件：Surging Totem（启用）。** Cast [[spell:378081]] on cooldown for [[spell:1267016]] 
   procs and use it on [[spell:1064]] preferably
6. **适用条件：Healing Rain（启用）；Surging Totem（未启用）。** Use [[spell:73920]] if multiple allies will be standing within it for most of 
   its duration
7. **适用条件：Surging Totem（启用）。** Place [[spell:444995]] in a place where it will hit as many allies and
   enemies as possible, and use [[spell:108287]] to move it as needed
8. Cast [[spell:61295]] on cooldown
9. **适用条件：Flow of the Tides（启用）。** Use [[spell:1064]] on injured allies with [[spell:61295]] (for [[spell:382039]]) 
   if group healing is needed
10. **适用条件：Flow of the Tides（未启用）。** Use [[spell:1064]] on injured allies if group healing is needed
11. Use [[spell:77472]] to heal the most injured single players
12. DPS if no one is in danger to speed up the encounter

3.

### Midnight Season 2 Tier Set

Below are the S2 Tier Set Bonuses for Restoration Shaman in Midnight. 
After the wording of the bonus, you will find a brief note/commentary that is <em>italicised</em>.

- 2-set bonus — [[spell:77472]] and [[spell:1064]] have a chance 
  to create a [[spell:73920]] at their target's location for 8 seconds. <em>These 
  bonus rains benefit from your talents and activate talents such as [[spell:383222]] 
  and [[spell:462425]] but cannot be moved with [[spell:108287]], making 
  their actual healing dependent on landing on player clusters.</em>
- 4-set bonus — Every 1 sec, 1 ally inside of [[spell:73920]] gains 
  a watery shield that absorbs damage for 10 sec. <em>Absorbs tend to always get full 
  value in hard encounters and due to the extra rains from the 2-set bonus you will 
  be getting good value from this bonus in most situations.</em>

Overall this is another simple yet strong tier bonus, which has a lot of randomness 
involved in its 2-piece bonus. This randomness is minimized in stacked healing encounters, 
where Restoration already worked best, making this tier one where encounter design 
is particularly important for Restoration Shaman healing potential.

4.

### Class and Spec Mechanics Explained

This section will expand on critical specialization mechanics such as Mana, our 
Mastery, Movement Management, and also delve deep into our Utility kit options.

:::details FAQHow Does Earth Shield Interact with Chain Heal?
[[spell:974]]

does not increase the whole

[[spell:1064]]

by 20%
when cast on a target with it. Only the first hit is increased, and this applies
to all other interactions with Earth Shield; only its target gets the healing
increase and only while Earth Shield is active.

:::

### Mana Management

4.1.

#### Mana Management

As with all healing classes, Mana management is at the core of this
specialization. It is important to choose your spells and timings wisely so
that Mana can last until the end of the encounter, especially in a progression
raid setting. Ideally, you should aim to keep your Mana pool roughly at the
same percentage as the enemy's Health Points throughout an encounter.
This ensures that you both keep enough Mana around for the later parts of the
fight and also that you end the fight around 0% Mana, thus not wasting any of
its potential healing.

Using a logging tool to analyze how your Mana was spent (or wasted) during
an encounter can be a great way to improve your Mana management. No one is
perfect in this regard, and practice is the key to success. Even seasoned
veterans of the specialization will take some time to learn each individual
encounter and how aggressively they can afford to play with their Mana pool
while still having enough reserves to last the entire fight.

### Mastery Details

4.2.

#### Mastery: Deep Healing

[[spell:77226]] is your Mastery as a Restoration Shaman.
It causes your heals to be more powerful on low-health targets. When you heal a
target with full health, you get no additional healing. When you heal a target
with 0% health (1 health point), you get the full benefit of your Mastery.

Your Mastery heavily influences the way you play a Restoration Shaman.

- When raid healing, you should focus on low-health targets more so than any
  other type of healer, as you have the most efficient tools to heal them
- When single-target healing, your Mastery has less influence because you
  should give priority to your assignment and cannot freely choose low health
  targets. By being aware of how much damage your assignment will take, you can
  optimize your heals to benefit from your Mastery

### Managing Movement

4.3.

#### Movement Management

Proper movement/usage of movement abilities is paramount to maximizing the
time you have available to heal / DPS while dodging encounter mechanics.
Unfortunately, it is quite difficult to explain how to move and reposition
within a fight, but as a healer, there are some basic principles you should
follow as much as possible.

- Position yourself central to your raid for best access to all targets
- [[spell:2645]] can allow you to avoid mechanics easily, even while
  slowed, as it stops you from being slowed below 100% movement speed
- Take advantage of your instant-cast spells and totems when you have to
  move. If none are available, use [[spell:2645]] to get to your
  destination faster
- [[spell:192063]] can help you against knockback mechanics to cross wide
  gaps, and when emergency movement is needed
- Track mechanic timers and position yourself in advance to avoid moving
  later
- If you have time, take stutter steps over an extended period to reach your
  intended destination. Every time you use an instant cast, take a few steps
  while you are locked by the Global Cooldown

Many players will unconsciously move during fights, despite it being
unnecessary. For example, sometimes the boss or adds will be moved by the tank
a couple of yards, and though you are still in range to cast, you subconsciously
mirror that movement, costing you global cooldowns. Consciously work to "quiet"
your movement, and reduce unnecessary movement to a minimum. The best way to
see this in action is to take a video of your raid then watch yourself play.
Most players will be surprised by the amount of wasted movement they commit.
When you are forced to move, make use of the tips above and make your path as
direct and decisive as possible.

[[spell:79206]] should be used during periods of heavy
movement where healing throughput is a concern. It can also be used to allow
you to reposition while continuing to heal your group.

### Utility Details

4.4.

#### Utility Details for Restoration Shamans

Restoration Shamans are well known for the high amount of **utility**
— non-healing benefits to yourself or your group — they bring. It
is not always obvious how to best use these tools to the benefit of your group,
and often, they are used as part of your guild's overall encounter strategy.

4.5.

#### Bloodlust / Heroism

[[spell:2825]] and [[spell:32182]] allow your group to dish out
increased damage/healing for a long duration, which is of critical importance
to beating soft and hard enrages on raid bosses and successfully dealing with
Mythic Keystone dungeons / PvP situations. Usually, this spell is cast at the
start of an encounter/dungeon boss when allies have their DPS cooldowns but
this can change depending on the encounter's specifics.

4.6.

#### Wind Rush Totem

If your group needs a movement speed increase to facilitate doing encounter
mechanics, [[spell:192077]] is a great help, granting a significant
group-wide speed boost every 2 minutes. As the totem's speed buff only lasts 5
seconds, but the totem itself lasts for 15 seconds; it is possible to get
multiple speed boosts from a single totem as long as you return to it once
your speed boost is gone.

4.7.

#### Earth Elemental

[[spell:198103]] calls an elemental with very high health to
taunt and tank non-boss enemies for you for a long duration. This is best used
to increase your DPS during an encounter or as an emergency tool to relieve
some pressure off your group's tank. You can also exchange its tanking capabilities 
for a 15% health buff with [[spell:1279819]] while the Elemental is active, 
making it a personal defensive.

4.8.

#### Astral Shift

[[spell:108271]] allows you to survive/ignore mechanics you usually
would not be able to and should be used whenever you feel like you might die
in the next few seconds of an encounter, preferably while you still have plenty
of health remaining.

4.9.

#### Tremor Totem

[[spell:8143]] enables you to quickly remove Fear / Sleep / Charm
effects from yourself or your group members, as long as you cast it before you
are crowd-controlled. Its PvE usefulness depends on the encounter
mechanics, and it does not work on all types of Fear / Sleep / Charm you will
find, but it is nearly always useful in PvP.

4.10.

#### Capacitor Totem

[[spell:192058]] allows you to stun a group of enemies at will,
allowing your group to dispatch them before they can deal further damage /
heal.

4.11.

#### Earthgrab / Earthbind Totem

[[spell:51485]] and [[spell:2484]] allow you to root/slow
enemies in an area. This is very useful whenever your group has to crowd-control
powerful enemies (and in PvP), but ultimately, its specific use depends on the
encounter mechanics you are dealing with.

4.12.

#### Hex

[[spell:51514]] allows you to crowd-control a humanoid or beast target for a
long while. Handy in PvP and in dungeons but of limited use in raids.

4.13.

#### Purify Spirit

[[spell:77130]] allows you to dispel Magic (and Curse when talented)
effects, something that is often essential to completing dungeons and raids
successfully. It also has great PvP uses, depending on the enemy compositions.
Keep in mind that if you dispel a target that has just been completely
dispelled by another healer, you waste Mana.

4.14.

#### Wind Shear / Purge

Restoration Shamans make ideal candidates for doing interrupt and dispel assignments, 
as they are the only healer with a **ranged** kick. Take advantage of
[[spell:57994]] whenever possible, though you should avoid compromising
raid healing if this is during a period of heavy incoming damage.
[[spell:370]] is also great on fights where a dispel is necessary, but bear
in mind that this costs Mana, so if resources are tight, consider asking a DPS to
fulfill this job.

### Farseer Ancestors

4.15.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer Ancestors

When playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer with [[spell:467646]], you can 
spawn Ancestor NPCs to help you for a short duration with [[spell:73685]] and 
[[spell:443454]].

These Ancestors cast spells that mimic what you are casting, but generally do 
not benefit or interact with your talents:

- [[spell:77472]] casts cause Ancestors to also cast Healing Wave, which 
  does significant single-target healing
- [[spell:61295]] and [[spell:73685]] result in a Healing Surge from Ancestors, 
  which is also a single target heal
- [[spell:1064]], [[spell:73920]], [[spell:5394]], and 
  [[spell:108280]] result in a Chain Heal cast by the Ancestors
- [[spell:188443]] results in a Chain Lightning from the Ancestors on your 
  target, while single target damage spells result in [[spell:51505]] casts

5.

### Important Cooldowns for Restoration Shaman

Correctly utilizing cooldowns is one of the most important things when
playing a healing specialization, and often, the organization of the healing
cooldowns is the determining factor in the success (or devastation) of a raid
group. Acclimatizing yourself to your cooldown kit and understanding when each
applies to your current situation is key to your success.

With Restoration Shaman, using your short cooldowns well is also very important, 
and while [[spell:5394]] is simple enough that it does not need further 
explanation, [[spell:378081]], [[spell:73685]], and the new 
Apex Talent [[spell:1267016]] have a detailed overview of their effects 
and how to use them optimally below.

### [[spell:98008]]

5.1.

#### Spirit Link Totem

[[spell:98008]] represents one of the most unique and flexible
cooldowns within the World of Warcraft. Every second, the health of the group
inside the totem's area of effect is redistributed, so all targets have an equal
percentage of maximum health. It also grants a 15% damage reduction to players
inside its area of effect and a massive heal shortly after its effect starts with
[[spell:462384]]. You can use Spirit Link Totem to split overwhelming
damage on a single target to everyone in the group, making it non-threatening.
Or to instantly ensure everyone has high health just before a highly damaging
ability hits the group. If you add in [[spell:196718]], you can also further
reduce the damage your group takes by 20% with no randomness involved. Finally,
because Spirit Link Totem ensures that everyone inside its effect is damaged as
long as at least one person is damaged, it allows healers to rapidly heal the
whole group efficiently with just area-of-effect healing spells.

### [[spell:108280]]

5.2.

#### Healing Tide Totem

[[spell:108280]] is on a choice node with [[spell:114052]] 
and is meant to be used by ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic players due to hero talents that boost 
its performance in this tree such as [[spell:445035]] and [[spell:1260874]]. 
As it is a totem, you can use it and immediately be free to move or cast other spells 
without needing to channel or stand still like other healer's raid cooldowns. Healing 
Tide Totem heals all allies within 40 yards for a flat amount, which is larger the 
fewer allies it heals, with maximum healing always being done as soon as you have 
at least 5 allies within range. It can also now benefit from [[spell:462440]] 
and [[spell:462443]] due to being an alternative to Ascendance.

### [[spell:114052]]

5.3.

#### Ascendance

[[spell:114052]] is on a choice node with [[spell:108280]] 
and is a powerful throughput cooldown that works very differently from [[spell:108280]], 
and is meant to be used by ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer players due to their lack of synergy 
with [[spell:108280]]. While it is active, [[spell:77472]] always 
crits and heals an additional ally at 50% effectiveness, while [[spell:1064]] 
jumps to 3 extra targets and only loses 10% healing per jump, making both spells 
much more effective. Provided you enter Ascendance prepared or react quickly to 
[[spell:378270]] procs, the potential extra healing provided by Ascendance 
is very strong.

### [[spell:378081]]

5.4.

#### Nature's Swiftness

[[spell:378081]] gives you an instant, Mana-free cast every minute 
and a [[spell:1267016]] proc. With ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic this is typically 
used for free [[spell:1064]]s, but ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer upgrades it with [[spell:443454]] 
into a half-cooldown version that empowers the instant cast spell and spawns an 
Ancestor, making it an important spell to press on cooldown.

### [[spell:73685]]

5.5.

#### Unleash Life

[[spell:73685]] allows you to amplify the healing of your next [[spell:77472]], 
[[spell:61295]], or [[spell:1064]] when used. As it also lowers the cast time 
of the affected spell, you should usually use it on Chain Heal or Healing Wave since 
Riptide is instant cast. [[spell:1271104]] further boosts the power of Unleash, 
making its direct healing more impactful.

### [[spell:1267016]]

5.6.

#### Apex Talent: Stormstream Totem

The Apex talents of Restoration Shamans are [[spell:1267016]], the 
two-pointer [[spell:1267093]], and final talent [[spell:1267120]]. 
As a whole, these apex talents grants [[spell:61295]] a small chance to proc a 
very powerful version of [[spell:5394]] which can be cast without using 
regular HST charges once you fully unlock the talent. [[spell:378081]] 
(or [[spell:443454]]) also grant a proc when used.

The proc stays active for up to 60 seconds and stacks twice, allowing you ample 
time to wait for the best time to use it, although you will generally want to 
do so before both charges of regular [[spell:5394]] are ready to avoid 
wasting potential uses.

6.

### Restoration Shaman DPS

Very often, it can be beneficial to deal damage rather than heal, especially
during periods where the incoming damage is low, and you want to recoup your Mana. 
[[spell:188196]] is cost-free, allowing you to help push some important timings 
or assist with high-priority targets while your Mana bar fills up. Shaman is also 
a well-equipped class to assist in dealing damage at minimal cost to healing time 
with instant cast [[spell:188389]] and [[spell:77756]] procs.

Learn more about this subject on our specialized page below!

[Restoration Shaman DPS Guide](<https://www.icy-veins.com/wow/restoration-shaman-pve-dps-guide>)

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2 launch.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **30 Mar. 2026:** Adjusted rotations for the new talent recommendations.
- **16 Mar. 2026:** Updated for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Patch 12.0.1 updates and rotation recommendation adjustments.
- **27 Jan. 2026:** Updated Farseer raid rotation with the best practices from pre-patch raiding.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Aug. 2025:** Added more information on targeting when using Whispering Waves.
- **04 Aug. 2025:** Updated with new format for Season 3, including new tier set rotational impact analysis.
- **15 Jun. 2025:** Added information on the new Combat Assistant feature.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated with the changes of Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5 with new rotational tips for Farseer Riptide build and new talent.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2
- **06 Oct. 2023:** Updated for Patch 10.2 and the new tier set bonus.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **13 Jun. 2023:** Clarified that Ascendance and Guidance should not be used together.
- **01 May 2023:** Added information on the new Tier Set and how it changes the rotation.
- **20 Mar. 2023:** Updated rotation for Patch 10.0.7 and added Weak Auras link to addons guide page.
- **10 Mar. 2023:** Added spell combo infographic.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Restoration Shaman in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Restoration Shaman

Welcome to our Gear and BiS Page for Restoration Shaman for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>). 
Check this page to learn everything you need to know about gearing a Restoration 
Shaman, including the BiS Gear from all sources, Raiding and Mythic+, information 
on the best Trinkets, Tier Sets, and much more.

In Midnight, **all item levels were squished**, which means the numbers on 
all items and their item level was massively reduced, allowing for all numbers to 
grow again throughout the expansion and future content without becoming too large 
to understand.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which 
lets you increase the item level of gear along tracks that relate to where you 
obtained the item, which harder content dropping gear that can be upgraded to higher 
Item Levels. For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

As usual, prioritize Leech / Avoidance pieces and the highest item level equipment you have, regardless of its secondary stat distribution.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, gear you catalyze keeps its original stats and cantrip effects, making pieces such as

[[item:268230@JAACAAgNyA]]

fantastic to use as tier pieces and removing the logic for having a favored off-piece with better stats than what tier would provide. Thus, we recommend catalyzing the following crit-heavy gear pieces:

- Helm: [[item:268230@JAACAAgNyA]]
- Shoulders: [[item:251131@JAACAAgNyA]]
- Chest: [[item:158355@JAACAAgNyA]]
- Hands: [[item:251165@JAACAAgNyA]]
- Legs: [[item:159375@JAACAAgNyA]]

:::

:::details FAQAre Two-Handed Weapons Viable?
While using a Shield is typically better due to the armor benefits, and certainly mandatory in PvP or when playing

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic

due to

[[spell:445033]]

being much stronger than

[[spell:445032]]

in Season 2, you can use a two-handed weapon in PvE when playing

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer

.

:::

**While usually crafting a two-hand is favored early in the tier, this Season is an exception due to the ease of coining a Mythic [[item:271092@JAACAAgNyA]] out of Heroic Ula'tek and the strength of [[spell:445033]].** The list below assumes an end of tier situation where catalyst charges, crests, and sparks to craft with are unlimited.

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the head from <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the gloves from <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAwo2ghNXQD]]&#10;&#10;<div>[[item:240968]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268216@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271481@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the shoulders from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268248@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></div></td></tr><tr><th>Feet</th><td>[[item:244577@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271486@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the chest from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251196@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains **only** items available in Mythic+ dungeons in Midnight. As usual, prioritize Leech / Avoidance pieces and the highest item level equipment you have, regardless of its secondary stat distribution.

:::details FAQWhich Tier Set Pieces Do I Want (Dungeon Loot only)?
In Midnight Season 2, gear you catalyze keeps its original stats and cantrip effects, making random pieces with high crit fantastic to use as tier pieces and removing the logic for having a favored off-piece with better stats than what tier would provide. Thus, we recommend catalyzing the following crit-heavy gear pieces if you only have access to Dungeon gear:

- Helm: [[item:159374@JAACAAgNyA]]
- Shoulders: [[item:251131@JAACAAgNyA]]
- Chest: [[item:158355@JAACAAgNyA]]
- Hands: [[item:251165@JAACAAgNyA]]
- Legs: [[item:159375@JAACAAgNyA]]

:::

:::details TipsWhich Dungeons Should I Farm?
We recommend you farm the following dungeons:

- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>), as multiple best in slot loot drops here, such as [[item:251131@JAACAAgNyA]], [[item:251136@JAACAAgNyA]], [[item:251132@JAACAAgNyA]], and the second best trinket, [[item:250215@JAACAAgNyA]]. [The Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>) is also quite nice with items such as [[item:251165@JAACAAgNyA]], [[item:251196@JAACAAgNyA]], and [[item:250214@JAACAAgNyA]].

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the head from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the gloves from <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Neck</th><td>[[item:273781@JAACAAAOyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Waist</th><td>[[item:251155@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271481@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the shoulders from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:244577@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271486@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the chest from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:193757@JAAKAAQkCYHKvbRLfgjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273780@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251196@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></span></div></td></tr></tbody></table>

### Raid

This list contains **only** items from the current raid. As usual, prioritize Leech / Avoidance pieces and the highest item level equipment you have, regardless of its secondary stat distribution.

:::details FAQWhich Tier Set Pieces Do I Want (Raid Loot only)?
In Midnight Season 2, gear you catalyze keeps its original stats and cantrip effects, making pieces such as

[[item:268230@JAACAAgNyA]]

fantastic to use as tier pieces and removing the logic for having a favored off-piece with better stats than what tier would provide. Thus, we recommend catalyzing the following crit-heavy gear pieces if you only have access to Raid gear:

- Helm: [[item:268230@JAACAAgNyA]]
- Shoulders: [[item:268231@JAACAAAG2A]]
- Chest: [[item:268223@JAACAAgNyA]]
- Hands: [[item:268238@JAACAAgNyA]]
- Legs: Use the token from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>) as the default version has the best stat combo

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raid leader, or simply want to focus on the most important bosses and items, we have you covered!

- [[item:268265@JAAGAAwo2ghNXQD]]: A neck with massive stats, most of which are good for us other than Mastery, making it a must-have for Restoration Shaman.
- [[item:271092@JAACAAgNyA]]: The best weapon of the tier. Unfortunately it provides Haste instead of Crit but you will have your critical strike needs met by the other [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) pieces, so some Haste here is welcomed.
- [[item:281215@JAACAAAOyA]]: The best trinket of the Season with its large passive Critical Strike bonus, provided you can deal damage to activate it, typically through [[spell:378443]] or [[spell:188389]].
- [[item:270164@JAACAAgNyA]]: Another very strong passive trinket, despite having the chance to give you a negative debuff occasionally.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the head from <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the gloves from <a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAwo2ghNXQD]]&#10;&#10;<div>[[item:240968]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268216@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the shoulders from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268248@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></div></td></tr><tr><th>Feet</th><td>[[item:244577@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271486@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the chest from <a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:244003]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240910]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAKAAwt1ENMMYzWiAGM]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-shaman-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268196@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Restoration Shaman

These are generally the strongest on-use and passive trinkets available, with 
**passive trinkets being favored** for ease of use:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Restoration Shaman Trinkets**
**On-Use -**

[[item:270162@JAACAAgNyA]]

and

[[item:250215@JAACAAgNyA]]

**Passive -**

[[item:270167@JAACAAgNyA]]

,

[[item:270164@JAACAAgNyA]]

, and

[[item:193757@JAAKAAQkCYHKvbRLfYjM]]

:::

Below we will provide a rough tier list of available trinkets. This can help
you to make quick decisions as to which trinkets are worth farming or what you
want to roll need on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Restoration Shaman Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<span>A fantastic trinket that grants a huge amount of Critical Strike, &#10;		   but does require outgoing damage to proc, which will mostly come from &#10;		   [[spell:378443]] and [[spell:188389]].</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAgNyA]] - <span><em>Click for Details</em></span>&#10;<span>A strong passive trinket which occasionally will cause you to lose &#10;		   stats rather than gain them, but overall its effect is mostly positive &#10;		   and powerful with great uptime.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270162@JAACAAgNyA]] - <span><em>Click for Details</em></span>&#10;<span>By far the best trinket of this Season for healers, especially &#10;		   if you have people die as that will allow you to use it much more often!</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270167@JAACAAgNyA]] - <span><em>Click for Details</em></span>&#10;<span>This is a strong passive trinket, which grants a lot of Intellect &#10;		   in cycles and is very powerful if you can time your healing cooldowns &#10;		   with the periods where it is at its maximum stacks.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270169]] - <span><em>Click for Details</em></span>&#10;<span>This trinket actively stacks an Intellect debuff until you use &#10;		   it, at which point you get a massive Intellect boost, which is great &#10;		   to really empower your burst healing potential, at the cost of lowered &#10;		   power in between burst windows.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:193757@JAAKAAQkCYHKvbRLfYjM]] - <span><em>Click for Details</em></span>&#10;<span>This trinket can be trained by using it on yourself with it when &#10;		   alone and out of combat to provide you with random procs of extra critical &#10;		   strike, in which case it is a strong stat stick, similar to [[item:270167]].</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAgNyA]] - <span><em>Click for Details</em></span>&#10;<span>Simple trinket with critical strike on use, which you should delay &#10;		   slightly to align with 2-minute [[spell:114052]] or use &#10;		   on cooldown to perfectly align with the 3-minute version.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:248583]] - <span><em>Click for Details</em></span>&#10;<span>A very strong delve trinket which you can configure to provide &#10;		   a reliable crit proc by using it on the Zul'Aman zone at the 52.15 80.74 &#10;		   map coordinates.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:251792]] - <span><em>Click for Details</em></span>&#10;<span>A fantastic trinket that cannot be obtained as Myth track, but &#10;		   is well worth using early on, even if you are the only player with it &#10;		   in the group.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:250214]] - <span><em>Click for Details</em></span>&#10;<span>While it is especially good if you can stand in the Mastery beam &#10;		   it occasionally provides, most of its benefit comes passively, allowing &#10;		   you to use it for its stats alone.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:273796]] - <span><em>Click for Details</em></span>&#10;<span>Using this grants you a powerful random stat buff for 15 seconds &#10;		   on a 2-minute cooldown, which is ideal to pair with 2-minute [[spell:114052]]. &#10;		   Unfortunately it will also cause you to lose a lower amount of stats &#10;		   for 15 seconds after its effect expires, which makes it more of a burst &#10;		   healing trinket.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250255]] - <span><em>Click for Details</em></span>&#10;<span>A powerful Mythic+ trinket for lifesaving on-use purposes.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250254]] - <span><em>Click for Details</em></span>&#10;<span>A powerful Mythic+ trinket for lifesaving on-use purposes, although &#10;		   its effect can take a while to activate since it depends on the person &#10;		   you used it on dropping low health.</span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:250248]] - <span><em>Click for Details</em></span>&#10;<span>Fairly decent and provides most of its benefit passively like &#10;		   [[item:250214]], but is slightly less powerful due to having &#10;		   a flat heal effect rather than Mastery potential multiplier for your &#10;		   healing.</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:273649]] - <span><em>Click for Details</em></span>&#10;<span>This trinket provides an on-use burst of Haste every 2 minutes, &#10;		   making it a perfect pair to 2-minute [[spell:114052]].</span>&#10;</li>&#10;<li>[[item:241291]]</li>&#10;<li>[[item:251788]]</li>&#10;<li>[[item:251789]]</li>&#10;<li>Any other unmentioned trinket is equal to this tier or worse.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) are used to obtain items from specific bosses or dungeons, 
by letting you gain a guaranteed piece of loot from a specific drop-location. You 
still roll within the pool available there, but the next time you use a Voidcore 
in this location/boss on that difficulty, you will gain one of the items you did 
not get the previous time(s).

**Orin Straylight** who stands near The Catalyst in Silvermoon will give you 
an extra Voidcore for free every week, starting with the launch of Patch 12.1.5.

3.1.

#### Recommended Nebulous Voidcore Usage for Restoration Shaman

Which item you want to chase after depends heavily on the items you have already 
acquired through the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) and other high-end sources, or whether 
you expect to down key bosses on Mythic difficulty, as you do not want to waste 
your Voidcores on items you may be able to get on a higher difficulty track quickly. 
The priority is as follows:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) as Restoration loot spec until you get [[item:271092@JAACAAgNyA]] 
   (and potentially [[item:268265@JAAGAAwo2ghNXQD]]).
2. Mythic [Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>) also only has useful items as Restoration 
   other than [[item:268203]] which you will hopefully avoid.
3. Mythic [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) for [[item:281215@JAACAAAOyA]].
4. Afterwards just coin for whatever best in slot items you are missing, typically 
   as Enhancement loot spec on [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) and [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>) to finish 
   your best in slot collection!

:::

3.2.

#### Ascendant Venomstones

Upgrading items with [[item:280562]] follows a similar priority 
list to using Crests:

1. Weapon
2. Trinkets
3. Necklace

Note that these upgrade items to a maximum of Item Level 344. If you are using 
special items such as Venomcursed items or items from the last 2 Mythic bosses, they 
cannot be further upgraded with Venomstones. Of course this also depends on what 
you have at Mythic track or not. You want top prioritize those, though Weapon should 
remain your first upgrade no matter what.

4.

### Best Crafted Items for Restoration Shaman

Embellishments are special effects that are either found on crafted pieces by
default or can be added to crafted pieces during the crafting process. A character
can have **two** embellishments equipped at any time.

You can find the full Embellishment sims at [QuestionablyEpic 
Live](<https://questionablyepic.com/live/>), but essentially we recommend crafting the following gear:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Restoration Crafted Gear Priority**
- [[item:237831@JAAKAAwt1ENMMYzWiAGM]] with [[item:240167]] if you lack a Mythic track shield
- Otherwise, [[item:244584@JAAKAAwt1ENMMYzWiAGM]] with [[item:240167]]
- [[item:244577@JAAKAAwt1ENMMYzWiAGM]] with [[item:240167]]
- Any item you do not have on Myth track yet.

:::

[[item:240167]] is a flexible Embellishment which can go into any 
crafted armor piece and grants a strong power up to yourself and a nearby ally 
when it procs.

Because it cannot be crafted on a weapon, new alts later on the season might 
benefit from first crafting an [[item:245770@JAAKAAwt1ENMMYzWiscN]] 
with [[item:273060]] for a massive power boost that can be obtained 
quickly after hitting max level.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with the [[item:275707]] 
consumable obtained from the Great Vault vendor when you choose the currency reward.

5.

### Crest Usage

You will usually want to start with upgrading your weapon, followed by trinkets,
and then any leech/avoidance pieces or items you won't be replacing for a long
time or pieces with large stat allocations such as helms or legs. These would be 
great choices, for example:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Restoration Shaman Crest Upgrade Priority**
**Weapon / Off-Hand**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on QE Live. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **02 Sep. 2026:** Changed gear and coining recommendations to account for stat changes.
- **26 Aug. 2026:** Updated for the latest gear stat changes.
- **10 Aug. 2026:** Updated for Midnight Season 2 launch.
- **15 Jun. 2026:** Added Sporefused items to Best in Slots lists with the release of Patch 12.0.7.
- **19 May 2026:** Updated voidcore recommendations, new best in slot table format and trinket recommendations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **01 Apr. 2026:** Adjusted trinket recommendations after many trinkets were heavily buffed.
- **30 Mar. 2026:** General gear, embellishment, and trinket recommendation updates.
- **17 Mar. 2026:** Trinket tier adjustments post hotfixes.
- **16 Mar. 2026:** Updated for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated DISC Belt post nerfs and added Puzzling Cartel Chips section.
- **04 Aug. 2025:** Updated with Season 3 gear and new recommendations.
- **15 Jun. 2025:** Added a new section about the new "DISC" Belt.
- **29 Apr. 2025:** Added more information on the upcoming Cartel Chip gear acquisition.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **23 Mar. 2025:** Updated gear listings and Cyrce's Circlet gem recommendations.
- **24 Feb. 2025:** Updated with the new gear of Patch 11.1.
- **17 Dec. 2024:** Updated with the first calculations on Circle's Circlet gem optimizations.
- **15 Dec. 2024:** Updated with Patch 11.0.7 information on Circle's Circlet.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Removed pre-season gear list and added a note on two-handed weapon crafting for crest savings early on.
- **27 Aug. 2024:** Embellishment and crafted gear suggestion updates based on recent tuning.
- **25 Aug. 2024:** More trinket ranking updates based on first comprehensive sims.
- **23 Aug. 2024:** Updated with S1 dungeon, raid, and trinket best in slot tables.
- **21 Aug. 2024:** Updated for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **26 Apr. 2024:** Further updates with live data.
- **22 Apr. 2024:** Updated with new gear, trinkets and embellishments for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **27 Nov. 2023:** Added the wings of Dawn of Infinite where each piece of loot drops.
- **09 Nov. 2023:** Various typo fixes.
- **08 Nov. 2023:** Updated embellishment recommendations post Undulating Sporecloak nerf.
- **06 Nov. 2023:** Updated with new gear, trinkets, and embellishments for Patch 10.2.
- **04 Sep. 2023:** Updated for 10.1.7 meta and added tabs to the best in slot gear block.
- **19 Jul. 2023:** Adjustments for Echoing Tyrstone nerfs.
- **11 Jul. 2023:** Further trinket list adjustments.
- **10 Jul. 2023:** Patch 10.1.5 trinkets added to the list as well as a recap on what gear can be found within the new dungeon.
- **01 May 2023:** Season 2 upgrade system recap, updated Embellishment recommendation, and added some trinkets.
- **23 Mar. 2023:** Updated post multiple gem buffs for the Onyx Annulet making it worth using.
- **20 Mar. 2023:** Added information on the new Onyx Annulet ring.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **21 Dec. 2022:** Revamped trinket recommendations and raid best in slot suggestions.
- **13 Dec. 2022:** Added Embellishment recommendations and Primal Ritual Shell.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Restoration Shaman. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Restoration Shaman Stat Priority

This stat priority will serve you well in most scenarios:

Item Level

Critical Strike

Versatility

Haste

Mastery

Haste is particularly strong in Mythic+ and short raid fights. The main reason 
why you would not want to fully stack Haste is that faster casts cause you to 
run out of Mana faster, which is less of a concern in these environments.

**Mastery** is particularly valuable when doing difficult content where players 
are more likely to drop to low health, such as **progression raiding and rated PvP**. 
It can be considered to be almost on par with Crit in these types of content.

The first priority for your gearing should be to use your highest **Item Level** 
gear pieces. These come with a lot of Intellect, which scales your spells the best 
on a point-by-point basis.

Having said that, there will be a few situations where item-level upgrades 
will not be actual upgrades. Sockets are usually worth a few item levels, Leech 
on the first 2-3 pieces is also worth a handful of item levels, Avoidance can also 
be worth lowering your overall item level for, but only in encounters where you 
take dangerous area of effect damage.

When healing **high Mythic+ dungeons**, the damage reduction of Versatility 
is very important, as it allows you to survive things you usually cannot in the 
highest Mythic keystone dungeons and generally reduces the stress to self-heal 
during high damage periods.

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. You should look for this stat in all
of your upgrades. It provides you with Spell Power, which increases the power
of your heals.

**Critical Strike** increases your throughput and gives some Mana regeneration 
boost through [[spell:16196]]. It is one of the strongest stats for pure healing 
throughput, as it scales well and improves nearly all of your healing spells, and 
also [[spell:51505]]'s critical damage since it is a guaranteed crit when 
[[spell:188389]] is on the target.

**Versatility** is a direct throughput increase that also reduces damage 
taken. It improves nearly all of your abilities but does not scale as well as 
Critical Strike for pure throughput. This is balanced by its damage reduction 
component and better DPS scaling than Critical Strike, making them close in power. 
In PvP, due to its defensive properties, it is generally the best stat in all situations.

**Haste** lowers the cast time of your spells and the duration of your 
global cooldown. Haste also causes your healing over time and damage over time 
effects to tick faster, as well as increasing the tick rate of your healing 
totems. **When Mana is not an issue, Haste is the best throughput stat** and 
is always a great stat for dealing damage due to its great scaling. However, in 
prolonged fights where you need to stop casting healing spells to conserve Mana, 
you gain more from having more powerful spells, as you cannot make full use of 
your Haste as is.

:::details FAQIs There a Haste Cap for Restoration Shamans?
There is no Haste cap. Besides increasing your potential throughput, it also
makes your rotation feel smoother and more responsive. The increased throughput
comes at the cost of Mana, however.

:::

**Mastery**, represented by [[spell:77226]], allows you to 
heal for more when targeting low-health allies. It starts off at a high value 
and does not scale well, which tends to make it perform worse as item level 
rises. Still, it does have good value on difficult content where your allies 
are likely to be at low health when you heal them, and we recommend valuing it 
on par with the top stats for progression raiding, high Mythic+, and rated PvP.

**Leech** allows you to passively self-heal for a percentage of the healing 
or damage of each spell you cast. Due to the prevalence of enemy mechanics that 
hurt everyone in the group, it ends up doing a lot of <em>free</em> healing that 
would, otherwise, need to be covered by Mana from yourself or the other healers 
in your group.

**Avoidance**'s exact power depends on the encounter mechanics but is often 
the decider on living or dying against extreme damage abilities in very high keystones. 
The damage it prevents is also very helpful in a raid setting.

**Speed** slightly increases the speed at which your character moves. This 
can be useful when trying to dodge encounter mechanics or when repositioning with 
your group, but is not as noticeable as other stats.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Midnight Season 2 launch.
- **15 Jun. 2026:** Revised the value of Haste up due to our much improved Mana economy.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **30 Mar. 2026:** Updated with more information on diminishing returns and stat priorities.
- **17 Mar. 2026:** Updated with latest sim info for longer fights.
- **16 Mar. 2026:** Updated for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Aug. 2025:** Small adjustment on Whispering Waves stat priority.
- **04 Aug. 2025:** Updated for Season 3 and different stats for the new Whispering Waves talent build.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated with the changes of Patch 11.1.
- **15 Dec. 2024:** Stat priority reviewed and explanations updated.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **23 Aug. 2024:** Updated with diminishing returns stat tables and Raid vs Mythic+ stat priorities.
- **21 Aug. 2024:** Updated for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Added info on when Haste can be good with new tier set in Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Restoration Shaman, based on your [stat priority](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You will always want to have one **Diamond** gem, ideally a maximum **Quality**
[[item:240983]] if it is your only gem socket, or a 
[[item:240968]] once you have 4+ sockets available to get the maximum
benefit out of it. When switching to the max-Mana diamond, make sure to 
have at least one gem of each type in the other sockets to max out the Mana gain 
effect, ideally one [[item:240910]], [[item:240914]], 
[[item:240890]], and [[item:240898]].

2.

### Best Enchants and Weapon Augments

[[item:243733]] is the best temporary oil, but you will usually 
be using the [[spell:382021]] talent instead.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240155]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244003]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

You will generally want to be using [[item:241326]] in raids, 
as Critical Strike is a favored stat for all talent builds, while swapping to 
[[item:241320]] in Mythic+ for its defensive benefits.

3.2.

#### Potions

[[item:241308]] is your best combat potion option, and should be paired 
with major cooldowns during moments of high group damage. You can also obtain 
[[item:245898]] from [[item:241285]] provided 
by Alchemists.

[[item:271883]] is the current best healing potion, 
which should be used in emergencies or whenever you do not have the time to heal 
yourself. It does not share a cooldown with the combat potion, and using potions 
has a 5-minute cooldown, allowing you to use multiple in long encounters.

While Mana-restoring potions do exist, they are very low value compared to [[item:241308]],
and therefore not worth using in almost all scenarios. You may want to keep a stack of them
at hand for absolute emergencies, but it is generally better to simply use a stat-potion
alongside your cooldowns.

3.3.

#### Food Buff

You should be eating from the [[item:255845]] or [[item:255846]] 
feasts whenever possible, but can also use [[item:242275]] in solo and small 
group scenarios.

Hearty versions of all foods can be created by the [Cooking](<https://www.icy-veins.com/wow/professions-cooking>) profession 
by combining 5 to 10 regular foods and, once eaten, provide their benefit 
for a full hour, even if you die midway through.

3.4.

#### Augment Rune

[[item:259085]] grant a decent amount of Intellect and come 
from many sources, including NPC crafting orders for the various professions.

As they tend to be very expensive for the stats granted, use these only in high-stakes 
situations!

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2 launch.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **19 May 2026:** Added a potion recommendation section.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Season 3 with new healing potion and augment runes.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Added Corruption Enchants information.
- **24 Feb. 2025:** Updated with the changes of Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **15 Sep. 2024:** Added a note on Weapon Oils.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Explained the Onyx Annulet nerfs and its new status as a decent, but not great, ring.
- **10 May 2023:** Added the new waist enchant, Shadowed Belt Clasp.
- **09 May 2023:** Adjusted for Corrupting Rage May 9th bug fix.
- **05 May 2023:** Adjusted Spore Tender recommendation post 72% nerf and for Corrupting Rage bugged state.
- **01 May 2023:** Added Spore Tender enchant, Phial of Corrupting Rage, and Deviously Deviled Eggs.
- **24 Mar. 2023:** Further Onyx Annulet updates.
- **23 Mar. 2023:** Updated post multiple gem buffs for the Onyx Annulet making it worth using.
- **20 Mar. 2023:** Updated with the Onyx Annulet for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **30 Nov. 2022:** Added leg enchants from Tailoring Spellthreads.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Restoration Shaman in World of Warcraft Patch 12.1.5.

1.

### Restoration Shaman in Mythic+ in Midnight Season 2

Mythic+ Dungeons, especially high ones, are the highest level of competitive
PvE content that WoW has to offer aside from Mythic raiding. As the group's healer,
their survival is in your hands. Fortunately, Restoration Shaman is great at healing 
through unexpected damage and recovering from mistakes.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our dedicated Mythic+ page below. You can also find
out more about the Mythic+ Meta on our Tier List page.

2.

### Best Mythic+ Talent Builds

Talents for dungeons should include crowd control tools such as [[spell:192058]] 
and [[spell:57994]], as well as the free damage of [[spell:378443]]. **For 
high keys** it is also recommended to have the health increase from [[spell:207401]], 
as it will have high uptime on a small group and is a good way to prevent one shots at 
higher key levels, but it is not needed when doing weekly keys.

As Restoration Shamans has many situational talents, make sure to adapt
your general tree talents from dungeon to dungeon to include situational utility
such as [[spell:8143]] for fears, [[spell:383016]] (curse dispel)
and [[spell:383013]] (poison dispel), [[spell:51514]], [[spell:378075]]
and [[spell:462820]] to remove snares, or even [[spell:260878]] for the extra 
damage reduction against one-shot mechanics!

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic Mythic+ Talent Build for Restoration Shaman

While these are the baseline recommended talents, feel free to swap to different
utility talents to suit your group composition, target dungeon, and active weekly
affixes.

The general idea behind these talents is to give you high baseline healing and 
utility, including picking [[spell:378443]] for extra passive DPS. [[spell:207401]] 
is also a great talent to take to reduce the impact of burst damage on your allies.

[[spell:108280]] has good synergy with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic due to the 
additional effect of the [[spell:445035]] and [[spell:1260874]] hero 
talents, heals for a large amount instantly, and allows you to DPS or heal with 
your spells while active, making it a stronger pick than [[spell:114052]] 
in the current meta.

[[spell:1064]] and its support talents combo well with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/totemic.webp>) Totemic
Hero talents as you will be able to cast many of them for free with [[spell:467306]] 
whenever you use [[spell:5394]], which has a reduced cooldown thanks 
to the [[spell:1260644]] talent.

Finally, the new [[spell:1312843]] is picked alongside multiple [[spell:61295]] 
support talents in order to allow you to consistently have everyone in your party 
with the Riptide heal over time at all times.

**Be sure to make use of the 'Export Talents' button to import the build directly 
into your game!**

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAgBAAAAzMzsstMmZmZmZGjZMsBbwMW0YbAMDshxMMLzMGNLLzMbmxsxixMjhlZZAAAAzMYmBgxgZA"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCUWox1NM0IVhp10qnHJaxBDwSBAjgqSkC-FMDHRIQIR9FYACDsZaprLzMJC45xC1B-AAAA-Jgko0AMowgxRmF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer Mythic+ Talent Build for Restoration Shaman

While these are the baseline recommended talents, feel free to swap to different
utility talents to suit your group composition, target dungeon, and active weekly
affixes.

The general idea behind these talents is to give you high baseline healing and 
utility, including picking [[spell:378443]] for extra passive DPS, which synergizes 
well with [[spell:73920]] quality of life improvements for Farseer and the 
Season 2 tier set bonuses. [[spell:207401]] is also a great talent to take 
to reduce the impact of burst damage on your allies.

The choice between [[spell:462443]] and [[spell:462440]] comes down 
to whether the key route you planned requires you to press Ascendance more often 
than every 3 minutes, but by default, Preeminence has better synergy with 
[[spell:378270]] which we also spec.

[[spell:73685]] allows for near-permanent uptime of one Ancestor, and is 
a mandatory talent in ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer builds, which tend to have better spread 
and spot healing due to stronger [[spell:77472]] casts with [[spell:443447]] 
and [[spell:1270447]].

Finally, as the healing over time of [[spell:61295]] was massively buffed for 
Season 2, it will be important to have high uptime on it on as many party members 
as possible, making [[spell:382039]] less desirable than [[spell:382732]].

**Be sure to make use of the 'Export Talents' button to import the build
directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CgQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYmZmltlxMzMzMzYMjxiZWgBMgZhJwYhZMDzyMjRzyyMzmZMbsYMz8ADLzyAAAAMDAmZYMYG"
}
```
:::

:::details 来源计算器编码
```
#IE-OPTCUWox1NM0IVhp10qnHZxBDwSBAjgSk+pC-FMDHRIQIR9FYACDsZaprLzMJ65xC1hD-AAAA-GcgohRIABgxShC-
```

:::

### Mythic+ Utility Talent Details

2.3.

#### Mythic+ Utility Talent Details for Restoration Shaman

Restoration Shaman provides support for the party through healing, damage,
and other additional effects, such as dispels and crowd control, as detailed below:

- [[spell:77130]] removes all Magic (and Curse, when talented) effects
  from a friendly target on an 8-second cooldown. This can often allow the purified
  ally to survive otherwise deadly situations and usually lowers the damage intake
  of that ally
- [[spell:370]] removes one beneficial Magic effect from an enemy target.
  This is very useful in Mythic+, as there are a lot of enemies with very
  powerful Magic buffs that we can remove immediately
- [[spell:57994]] is the only healer interrupt and prevents spells of the
  interrupted school from being cast for 4 seconds on a 30-second cooldown. As interruptible
  enemy casts are, often, some of the most dangerous abilities you will face in
  Mythic+, you should try to interrupt enemies as much as possible, prioritizing
  the most dangerous casts / ranged enemies that are hard for melee allies to interrupt
- [[spell:192058]] allows you to place a totem up to 30 yards away
  that, 2 seconds after being placed, explodes to stun a group of enemies in a
  16-yard diameter for 3 seconds on a 1-minute cooldown. When facing dangerous
  trash packs, 3 seconds can easily be the difference between victory and defeat
- [[spell:51485]] and [[spell:2484]] allow you to root
  / slow enemies in an area. This is very useful whenever your group has to crowd
  control powerful enemies
- [[spell:8143]] places a totem beneath you that periodically removes
  Fear, Charm, and Sleep effects from allies within 30 yards. It lasts for 10
  seconds on a 1-minute cooldown. This should be used whenever enemies are
  casting Fear, Charm, or Sleep effects on your group
- [[spell:51514]] disables a non-boss humanoid or beast enemy for 1 minute. This
  allows you to disable especially powerful enemies ahead of a pull.
- [[spell:198103]] summons an elemental with a large health pool and
  good non-boss tanking capabilities — its taunt does not work on bosses
  — for 1 minute on a 5-minute cooldown. It can be used for a minor DPS increase
  or as an emergency cooldown capable of distracting dangerous non-boss enemies. It
  can also be turned into a powerful personal defensive since it grants you 15% extra 
  maximum health with [[spell:1279819]]

3.

### Dungeon Talent Swap Cheat Sheet

For a quick reference of extra uses for your optional Restoration utility
talents, use the tool below to select a dungeon. Underneath, relevant picks will
be highlighted alongside what they're used to counter.

<table>&#10;<tr>&#10;<th colspan="2" style="text-align: center">Dungeons</th>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></td>&#10;</tr>&#10;</table>

Based on the selections above, you should run the following class talents:

- **适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Temple of Sethraliss（启用）。** [[spell:383016]]
- **适用条件：King's Rest（启用）；Temple of Sethraliss（启用）。** [[spell:51485]]
- **适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；Ruby Life Pools（启用）。** [[spell:462820]]
- **适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；Murder Row（启用）；Temple of Sethraliss（启用）；Blinding Vale（启用）；Voidscar Arena（启用）。** [[spell:383013]]
- **适用条件：Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；Temple of Sethraliss（启用）；Blinding Vale（启用）。** [[spell:370]]
- **适用条件：Den of Nalorakk（启用）；Blinding Vale（启用）。** [[spell:58875]]
- **适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）。** [[spell:378075]]
- **适用条件：Murder Row（启用）。** [[spell:8143]]

- **适用条件：Altar of Fangs（启用）。** 
  
  
  - Use [[spell:383013]] to dispel the [[spell:1307567]] from 
    **Ula'tek's Chosen**. Note that you can and should interrupt this cast instead 
    when possible.
  - Use [[spell:192077]] with [[spell:462820]] to remove 
    the [[spell:1294569]] inflicted by **Twinfang Harrower**. You can also 
    use [[spell:378075]] or [[spell:58875]] to remove it from yourself.
  - Use [[spell:383016]] to dispel the **Cursed Bones** debuff from 
    piles of bones scattered across the dungeon to increase enemy damage taken for a 
    short duration.
- **适用条件：Den of Nalorakk（启用）。** 
  
  
  - Use [[spell:58875]] to get rid of [[spell:1241463]] inflicted by 
    **Avatar of Determination**.
  - Use [[spell:383016]] to dispel [[spell:1238801]] caused 
    by **Spirit of Hunger**'s **Starvation Effigy**.
  - Use [[spell:383013]] to remove [[spell:1234846]] during 
    the **The Hoardmonger** boss encounter.
  - Use [[spell:370]] to remove [[spell:1297696]] used by **Earthwhisper 
    Tender**. Note that you can and should interrupt this cast instead when possible.
  - Use [[spell:192077]] with [[spell:462820]] to dispel the [[spell:1309919]] 
    applied by **Frigid Mauler**. Note that you can and should interrupt this 
    cast when possible. You can also use [[spell:378075]] or [[spell:58875]] 
    to remove it from yourself.
- **适用条件：King's Rest（启用）。** 
  
  
  - Use [[spell:370]] to remove the "mind control" [[spell:270920]] 
    caused by **Queen Wasi** in the "gauntlet" corridor before **Mchimba the Embalmer**.
  - Use [[spell:370]] to remove [[spell:270901]] cast by 
    **Seneschal M'bara** in the "gauntlet" corridor before **Mchimba the Embalmer**.
  - Use [[spell:51485]] to root and slow **Animated Gold** so they do 
    not reach the boss during **The Golden Serpent** boss encounter.
  - Use [[spell:383016]] to dispel [[spell:269972]] cast by 
    **Shadow-Borne Witch Doctor** and [[spell:270492]] cast by **Spectral Hex Priest**. 
    Note that both of these are casts that you can and should interrupt when possible.
- **适用条件：Murder Row（启用）。** 
  
  
  - Use [[spell:383016]] to dispel the [[spell:1217973]] cast 
    by **Corrupted Warlock**
  - Use [[spell:383013]] to remove [[spell:474515]] 
    during the first boss encounter against **Zaen Bladesorrow**
  - Use [[spell:8143]] to remove [[spell:1201554]] channeled by 
    **Seductive Sayaad**.
- **适用条件：Ruby Life Pools（启用）。** 
  
  
  - You can use [[spell:370]] to remove [[spell:373973]] from **Primalist 
    Flamedancer** to finish them off, or to remove [[spell:391031]] from 
    **Primal Thundercloud**.
  - If necessary [[spell:192077]] with [[spell:462820]] can be used to remove 
    stacks of [[spell:373803]] applied by **Infused Whelps** to prevent [[spell:373593]] 
    from occurring.
- **适用条件：Temple of Sethraliss（启用）。** 
  
  
  - [[spell:370]] the [[spell:1310739]] off **Agitated Nimbus** 
    enemies found before the third boss.
  - [[spell:51485]] can be used to prevent **Faithless Tormentor** from 
    reaching the boss during the **Avatar of Sethraliss** final boss encounter.
  - Use [[spell:383013]] to remove [[spell:267027]] caused 
    by **Venomous Ophidian** during the second boss encounter **Merektha**. 
    Note that this can and should instead be interrupted when possible.
  - Use [[spell:383016]] to dispel [[spell:1293307]] inflicted 
    by **Faithless Tender**. Note that this can and should instead by interrupted 
    when possible.
- **适用条件：Blinding Vale（启用）。** 
  
  
  - Use [[spell:58875]] to remove [[spell:1236658]] during the second 
    boss encounter **Ikuzz the Light Hunter**.
  - Use [[spell:383013]] to remove [[spell:1250937]] caused by 
    **Potatoad Matriarch**.
  - [[spell:370]] off the [[spell:1238581]] from **Spineshield Beetles**.
- **适用条件：Voidscar Arena（启用）。** 
  
  
  - Use [[spell:383013]] to remove [[spell:1226120]] during 
    the second boss encounter **Atroxus**.

4.

### Dealing with Affixes

This section has Shaman-specific tips for dealing with the various affixes of 
the current Mythic+ dungeons.

Make sure not to use [[spell:20608]] carelessly after reaching Level 12
and beyond keys, as the death penalty is massively increased to 15 seconds, heavily
punishing multiple deaths!

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Restoration Shaman

Shamans have a lot of tools to deal with this affix:

- [[spell:57994]]
- [[spell:370]]
- [[spell:192058]], which is available more often if specced into [[spell:265046]]

### Affix: Pulsar

4.2.

#### Pulsar Affix Management for Restoration Shaman

Mobility tools are great for helping soak your party's [[spell:1216858]]s:

- [[spell:192077]] to help your entire party soak them
- [[spell:79206]] so you can keep casting and gain movement from [[spell:192088]]
- [[spell:192063]] or [[spell:58875]]
- [[spell:2645]] especially with [[spell:378075]]. [[spell:382215]]
  can make you even faster, if you really need it

### Affix: Voidbound

4.3.

#### Voidbound Affix Management for Restoration Shaman

While your role at dealing with the Voidbound affix is limited, make sure to 
[[spell:188389]] and deal damage to the Void Emissary as a priority while it 
is active!

### Affix: Devour

4.4.

#### Devour Affix Management for Restoration Shaman

[[spell:383013]] will remove all [[spell:440313]] debuffs on its
own, and you can get a second one if needed with [[spell:108285]].

Alternatively, you can also simply heal through the debuff, as it is not a healing
absorb and you will still be able to heal your targets fully while they are affected,
with any left-over debuffs being easily removed by your [[spell:51886]].

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **01 Sep. 2026:** Updated with a cheatsheet of recommended utility talents for each S2 dungeon.
- **10 Aug. 2026:** Updated for Midnight Season 2 launch.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **19 May 2026:** Updated Mythic+ talent recommendations to Totemic.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **30 Mar. 2026:** Updated the utility cheatsheet.
- **16 Mar. 2026:** Updated for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Patch 12.0.1 updates and talent recommendation adjustments.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **23 Mar. 2025:** New utility cheatsheet image with root totem and more clear indications.
- **03 Mar. 2025:** Minor cleanups.
- **02 Mar. 2025:** Added an utility cheatsheet image and tips for all dungeons.
- **24 Feb. 2025:** Updated with the changes of Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5 with a new section on talent adjustments for each dungeon.
- **09 Sep. 2024:** Added tips for dealing with the new Mythic+ affixes.
- **25 Aug. 2024:** More trinket ranking updates based on first comprehensive sims.
- **23 Aug. 2024:** Added Mythic+ utility sheet for Season 1.
- **22 Aug. 2024:** Updated for The War Within launch.
- **22 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **01 May 2024:** Updated Mythic+ Utility chart.
- **22 Apr. 2024:** Updated for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **10 Feb. 2024:** Typo fix on the description of Wind Shear.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **24 Nov. 2023:** Updated and added big on-click version of the utility per dungeon picture.
- **15 Nov. 2023:** Added image on how to spec utility talents for each dungeon.
- **09 Nov. 2023:** Typo fixes.
- **06 Nov. 2023:** Added a new talent build for Patch 10.2 and new Season information.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **31 Jul. 2023:** Adjusted talents to the current Season 2 dungeon meta.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **06 Jun. 2023:** Added Thundering Paws as anti-Entangling tech.
- **01 May 2023:** Updated with new talents, affixes and tips for Season 2 of Dragonflight (Patch 10.1.0).
- **20 Mar. 2023:** Updated talents for Patch 10.0.7.
- **10 Mar. 2023:** Cloudburst Totem is now the default recommendation.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Dec. 2022:** Changed talent build to include Acid Rain.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Restoration Shaman in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Restoration Shaman macros. You can import
these by simply clicking the "Copy" button on each individual block.

1.1.

#### Dynamic Mouseover Macros

This sort of macro allows you to cast a different spell depending on whether
your cursor is hovering over a friendly target, which is helpful when reducing the 
total amount of buttons you need to use for both healing and dealing damage.

#### Dynamic Mouseover Macro

```wow-macro
#showtooltip
/cast [@mouseover,nodead,help] Chain Heal; Flame Shock
```

1.2.

#### Simple Mouseover Macros

For all your direct heals ([[spell:77472]], [[spell:8004]],
[[spell:61295]], and [[spell:1064]]), we advise you to use mouseover macros
such as:

#### Simple Mouseover Macro

```wow-macro
#showtooltip
/cast [@mouseover] Healing Wave
```

1.3.

#### Talent Conditional Macros

You can also do macros that cast different spells depending on your chosen talents:

#### Talent Conditional Macro

```wow-macro
#showtooltip
/cast [known:Unleash Life] Unleash Life; Healing Stream Totem
```

With this macro, you can always keep a relevant spell on the best keyboard buttons 
available, even when adjusting talents on the fly.

1.4.

#### Healing Rain on Cursor

This macro will place healing rain at your cursor rather than popping up a
green targeting reticle.

#### Healing Rain on Cursor Macro

```wow-macro
#showtooltip
/cast [@cursor] Healing Rain
```

1.5.

#### Wind Shear

#### Focus Interrupt

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] Wind Shear
```

This macro will stop your current cast and cast [[spell:57994]] on your
focus if available, otherwise it will be cast on your target.

1.6.

#### Purge

#### Focus Purge

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] Purge
```

This macro will stop your current cast and cast [[spell:370]] on your
focus if available, otherwise it will be cast on your target.

1.7.

#### Wind Rush Totem

Two options are available, allowing you to either instantly cast
[[spell:192077]] at your feet:

Wind Rush at Feet

#showtooltip
/stopcasting
/cast [@player] Wind Rush Totem

Or at your current cursor location:

Wind Rush at Cursor

#showtooltip
/stopcasting
/cast [@cursor] Wind Rush Totem

These remove an input and allow you to activate the totem much quicker than usual 
to get the movement speed rolling quickly.

2. 

## Best Addons

FAQWhich Raid Frames Should I Use?

Ellesmere UI provides easy to customize raid frames and has good performance,
making it the currently recommended solution. Alternatively, with the Midnight UI
changes, using default UI has never been more viable, especially if you use Harreks
Advanced Raid Frames to enable better healing over time customization.

2.1. 

### Alternative Raid Frames

For healers, raid frames are a very personal choice. While [Ellesmere UI](<https://www.curseforge.com/wow/addons/ellesmereui>) 
is the current best option, using default UI is also very viable, especially when 
combined with [Harreks Advanced Raid Frames](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>) 
for healing over time customization.

2.2. 

### Raid Buffs and Consumables Tracking

Use an addon such as [Northern Sky Raid Tools](<https://www.curseforge.com/wow/addons/northern-sky-raid-tools>) 
and/or [Method 
Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) to enable audio warnings for important enemy abilities and your own 
healing cooldown timings, on an encounter-by-encounter basis. You can also use them 
to track consumable and buff status for your raid before pulling and to create and 
distribute or receive written raid notes, which usually have important assignments 
for the boss you are facing.

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.3. 

### Ellesmere UI

[Ellesmere UI](<https://www.curseforge.com/wow/addons/ellesmereui>) 
is a complete replacement for the default User Interface, and you will often find 
the best players in the world using it for ease of customization and good performance. 
It already comes furnished with almost everything you need; unit frames, raid frames, 
buffs and debuffs, and much more. You can easily unlock, configure, and drag all 
the components around with an intuitive graphical UI, allowing you to make your 
game look exactly the way you want it to.

2.4. 

### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.4.1. 

#### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.4.2. 

#### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.4.3. 

#### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.5. 

### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.5.1. 

#### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.5.2. 

#### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and 
many more. They have now developed a very customizable Nameplate addon that offers 
numerous options for debuffs, status colors, icons, textures, and much more. It is 
definitely worth checking out, especially if you end up having any issues with Plater 
for any reason.

2.6. 

### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still 
around as a good option to customize damage and healing meters. While it may not 
offer as many tracking options as before due to the limits imposed by Blizzard, 
it is still around and kicking to help you customize the Blizzard Damage, Healing, 
and Other metrics pane.

3. 

## Changelog

- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Midnight Season 2 launch.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1 launch.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **29 Aug. 2024:** Added an Ancestor-tracking weak aura.
- **23 Aug. 2024:** Added more weak auras for The War Within.
- **21 Aug. 2024:** Updated for The War Within launch.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **18 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **30 Apr. 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Added two more weak auras to support 10.0.7's new playstyle.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less
